
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import asyncio
import time
import os
from collections import defaultdict, Counter
from scapy.all import sniff, IP, TCP, UDP, ICMP, Ether

# --- 1. State Management Class ---
class MonitorStats:
    """Holds and manages all real-time network statistics."""
    def __init__(self):
        self.total_packets = 0
        self.total_bytes = 0
        self.protocol_counts = defaultdict(int)
        self.source_bytes = defaultdict(int)
        
        # Variables for calculating real-time rates
        self.last_update_time = time.time()
        self.last_total_bytes = 0
        self.last_total_packets = 0
        self.current_bps = 0  # Bytes Per Second
        self.current_pps = 0  # Packets Per Second

    def update_stats(self, packet):
        """Processes a single packet and updates cumulative statistics."""
        self.total_packets += 1
        
        # Calculate packet size (approximation using wire length)
        try:
            packet_size = len(packet)
        except:
            packet_size = 0
            
        self.total_bytes += packet_size

        # Identify protocol and source IP
        if IP in packet:
            src_ip = packet[IP].src
            self.source_bytes[src_ip] += packet_size
            
            if TCP in packet:
                self.protocol_counts['TCP'] += 1
            elif UDP in packet:
                self.protocol_counts['UDP'] += 1
            elif ICMP in packet:
                self.protocol_counts['ICMP'] += 1
            else:
                self.protocol_counts['Other IP'] += 1
        elif Ether in packet:
            self.protocol_counts['Ethernet'] += 1
        else:
            self.protocol_counts['Unknown'] += 1
            
    def calculate_rates(self):
        """Calculates instantaneous BPS and PPS based on the elapsed time."""
        current_time = time.time()
        time_elapsed = current_time - self.last_update_time
        
        if time_elapsed > 0:
            # Calculate byte rate
            bytes_change = self.total_bytes - self.last_total_bytes
            self.current_bps = bytes_change / time_elapsed
            
            # Calculate packet rate
            packets_change = self.total_packets - self.last_total_packets
            self.current_pps = packets_change / time_elapsed
        
        # Reset counters for the next interval
        self.last_total_bytes = self.total_bytes
        self.last_total_packets = self.total_packets
        self.last_update_time = current_time

# --- 2. Asynchronous Tasks ---

def packet_callback(packet, stats_obj):
    """The synchronous handler passed to Scapy's sniff function."""
    stats_obj.update_stats(packet)

async def start_sniffing(interface, stats_obj):
    """
    Runs the synchronous Scapy sniff function in a separate thread 
    to prevent blocking the asyncio event loop.
    """
    print(f"[*] Starting packet capture on interface: {interface}...")
    
    # We use asyncio.to_thread to safely execute the blocking sniff function
    await asyncio.to_thread(
        sniff, 
        iface=interface, 
        prn=lambda pkt: packet_callback(pkt, stats_obj), 
        store=0
    )

def format_bytes(bytes_val):
    """Converts bytes to human-readable format (KB, MB, GB)."""
    if bytes_val < 1024:
        return f"{bytes_val:.2f} B"
    elif bytes_val < 1024**2:
        return f"{bytes_val / 1024:.2f} KB"
    elif bytes_val < 1024**3:
        return f"{bytes_val / 1024**2:.2f} MB"
    else:
        return f"{bytes_val / 1024**3:.2f} GB"

async def dashboard_updater(stats_obj, interval=1):
    """Periodically calculates rates and prints the dashboard."""
    while True:
        stats_obj.calculate_rates()
        
        # Clear screen for continuous update effect
        os.system('cls' if os.name == 'nt' else 'clear') 
        
        print("=" * 60)
        print(" " * 15 + "REAL-TIME NETWORK TRAFFIC MONITOR")
        print("=" * 60)
        
        # A. Global Statistics
        print(f"Total Packets Captured: {stats_obj.total_packets:,}")
        print(f"Total Data Volume:       {format_bytes(stats_obj.total_bytes)}")
        print("-" * 60)
        print(f"Current Rate (BPS):      {format_bytes(stats_obj.current_bps)}/s")
        print(f"Current Rate (PPS):      {stats_obj.current_pps:,.2f} pkts/s")
        print("-" * 60)
        
        # B. Protocol Distribution
        print("Protocol Distribution:")
        total = sum(stats_obj.protocol_counts.values())
        for proto, count in sorted(stats_obj.protocol_counts.items(), key=lambda item: item[1], reverse=True):
            percentage = (count / total) * 100 if total else 0
            print(f"  > {proto:<10}: {count:,} packets ({percentage:.2f}%)")
        print("-" * 60)

        # C. Top Talkers (Source IP by Bytes)
        print("Top 5 Talkers (Source IP):")
        top_talkers = Counter(stats_obj.source_bytes).most_common(5)
        for ip, bytes_val in top_talkers:
            print(f"  > {ip:<15}: {format_bytes(bytes_val)}")
        print("=" * 60)
        
        await asyncio.sleep(interval)

async def main(interface="eth0"):
    """Main entry point to run concurrent tasks."""
    stats = MonitorStats()
    
    # Start both tasks concurrently
    await asyncio.gather(
        start_sniffing(interface, stats),
        dashboard_updater(stats)
    )

if __name__ == "__main__":
    # NOTE: Replace 'eth0' with your actual network interface (e.g., 'Wi-Fi', 'en0', 'wlan0')
    # This script typically requires root/administrator privileges to sniff.
    try:
        # Example interface placeholder
        NETWORK_INTERFACE = "eth0" 
        asyncio.run(main(NETWORK_INTERFACE))
    except KeyboardInterrupt:
        print("\n[!] Monitor stopped by user.")
    except Exception as e:
        print(f"\n[CRITICAL ERROR] Ensure you are running with sufficient privileges (root/admin) and the interface '{NETWORK_INTERFACE}' is correct.")
        print(f"Error details: {e}")

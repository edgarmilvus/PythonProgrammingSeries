
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

from scapy.all import sniff, IP, TCP, UDP, ICMP
from collections import Counter
import time
import sys

# --- 1. Global State Management ---

# A highly efficient dictionary subclass for counting hashable objects.
protocol_stats = Counter()
total_packets = 0
start_time = time.time()

# --- 2. Packet Processing Callback Function ---

def packet_handler(packet):
    """
    Processes each captured packet, extracts the protocol, and updates statistics.
    This function is executed immediately upon packet capture.
    """
    global total_packets
    
    # Increment the total count of captured packets
    total_packets += 1
    
    protocol_name = "Unknown" # Default protocol name

    # Check for the presence of the IP layer (Layer 3)
    if IP in packet:
        # Determine the transport layer protocol (Layer 4)
        
        # Check for TCP
        if TCP in packet:
            protocol_name = "TCP"
        # Check for UDP
        elif UDP in packet:
            protocol_name = "UDP"
        # Check for ICMP
        elif ICMP in packet:
            protocol_name = "ICMP"
        else:
            # Handle other IP protocols using their numerical identifier (e.g., 2=IGMP, 89=OSPF)
            # Scapy uses the 'proto' field in the IP layer
            protocol_name = f"IP_Proto_{packet[IP].proto}"
    else:
        # Handle non-IP traffic (e.g., ARP, Spanning Tree Protocol, LLDP)
        protocol_name = "Non-IP"
            
    # Update the counter dictionary efficiently
    protocol_stats[protocol_name] += 1
    
    # --- Real-time Visualization Logic ---
    # Print a snapshot update every 50 packets captured
    if total_packets % 50 == 0:
        elapsed = time.time() - start_time
        sys.stdout.write(f"\r[STATUS] Pkts: {total_packets} | Rate: {total_packets / elapsed:.1f} p/s | TCP: {protocol_stats.get('TCP', 0)} | UDP: {protocol_stats.get('UDP', 0)}")
        sys.stdout.flush()


# --- 3. Sniffer Execution Function ---

def run_sniffer(count=500):
    """
    Initiates the high-speed packet capture using Scapy.
    """
    print(f"[*] Starting statistical packet capture. Sniffing {count} packets...")
    
    try:
        # CRITICAL: store=0 ensures that packets are NOT stored in memory, 
        # allowing for high-speed, continuous processing.
        # prn=packet_handler specifies the function to execute on every packet.
        sniff(prn=packet_handler, count=count, store=0)
    
    except Exception as e:
        # Catch common issues like interface not found or permission errors
        print(f"\n[!!!] An error occurred during sniffing: {e}")
        
    print("\n[*] Capture finished. Calculating final summary.")
    
    # --- 4. Final Summary Calculation ---
    
    end_time = time.time()
    duration = end_time - start_time
    
    # Avoid division by zero if duration is zero or near-zero
    packet_rate = total_packets / duration if duration > 0 else 0
    
    print("\n\n=== FINAL NETWORK STATISTICS SUMMARY ===")
    print(f"Total Packets Captured: {total_packets}")
    print(f"Total Duration: {duration:.2f} seconds")
    print(f"Average Packet Rate: {packet_rate:.2f} packets/sec")
    
    print("\nProtocol Distribution:")
    # Iterate through the Counter, sorted by most common protocols
    for proto, count in protocol_stats.most_common():
        percentage = (count / total_packets) * 100
        print(f"  - {proto:<12}: {count:,} packets ({percentage:.1f}%)")

if __name__ == "__main__":
    # Note: Running this often requires elevated privileges (sudo/administrator)
    try:
        # Sniff 500 packets for a quick statistical sample
        run_sniffer(count=500) 
    except PermissionError:
        print("\n[!!!] Permission Error: Packet sniffing requires root/administrator privileges.")
        print("Please run the script with elevated permissions.")
    except ImportError:
        print("\n[!!!] Scapy or required modules not found. Ensure Scapy is installed.")



#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import time
import threading
import sys
from scapy.all import sniff, IP
from collections import defaultdict
import operator

# --- Global State Management ---
# Shared variables, accessed by both the sniffing thread and the calculation thread
total_bytes = 0
start_time = time.time()
ip_byte_counts = defaultdict(int)
stop_event = threading.Event()

# Lock for safe access to shared data structures
data_lock = threading.Lock()

def packet_processor(pkt):
    """Processes IP packets to track total bytes and per-IP byte usage."""
    global total_bytes
    
    if IP in pkt:
        src_ip = pkt[IP].src
        pkt_len = len(pkt)
        
        with data_lock:
            total_bytes += pkt_len
            ip_byte_counts[src_ip] += pkt_len

def monitor_refresher():
    """Calculates and prints real-time metrics every 5 seconds."""
    global total_bytes, start_time
    
    while not stop_event.is_set():
        # Wait for 5 seconds, or stop immediately if the event is set
        stop_event.wait(5)
        if stop_event.is_set():
            break
            
        current_time = time.time()
        elapsed_time = current_time - start_time
        
        with data_lock:
            current_bytes = total_bytes
            current_ip_counts = dict(ip_byte_counts) # Copy for sorting
        
        # 1. Calculate Throughput (MB/s)
        if elapsed_time > 0:
            rate_bps = (current_bytes * 8) / elapsed_time
            rate_mbps = rate_bps / (1024 * 1024)
            rate_mbytes_per_sec = current_bytes / elapsed_time / (1024 * 1024)
        else:
            rate_mbytes_per_sec = 0
            
        # 2. Identify Top Talkers
        # Sort by byte count (value) in descending order
        sorted_talkers = sorted(current_ip_counts.items(), 
                                key=operator.itemgetter(1), 
                                reverse=True)
        
        top_5_talkers = sorted_talkers[:5]
        
        print("\n" + "=" * 50)
        print(f"Refresh Time: {time.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"Monitoring Duration: {elapsed_time:.2f} seconds")
        print(f"Current Average Throughput: {rate_mbytes_per_sec:.2f} MB/s")
        print("=" * 50)
        
        print("Top 5 Talkers (Cumulative Bytes Sent):")
        for ip, bytes_sent in top_5_talkers:
            print(f"  {ip:<15}: {bytes_sent / (1024*1024):.3f} MB")
        print("-" * 50)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(f"Usage: python {sys.argv[0]} <interface_name>")
        sys.exit(1)
    
    interface_name = sys.argv[1]

    # Start the background refresh thread
    refresh_thread = threading.Thread(target=monitor_refresher, daemon=True)
    refresh_thread.start()
    
    print(f"Starting continuous capture on {interface_name}. Press Ctrl+C to stop.")
    
    try:
        # Start the blocking sniff operation
        # Note: store=0 is crucial for high-speed monitoring to prevent memory exhaustion
        sniff(iface=interface_name, prn=packet_processor, store=0)
        
    except KeyboardInterrupt:
        print("\nStopping capture...")
    except OSError as e:
        print(f"\nError: {e}. Check permissions or interface name.")
    finally:
        # Signal the refresh thread to stop gracefully
        stop_event.set()
        refresh_thread.join(timeout=1) # Wait for the thread to finish
        print("Monitoring stopped.")

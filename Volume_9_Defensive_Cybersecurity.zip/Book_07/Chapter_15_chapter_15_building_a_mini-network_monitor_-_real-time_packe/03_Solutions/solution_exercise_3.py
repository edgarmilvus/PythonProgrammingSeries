
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import time
import threading
import sys
import os
from datetime import datetime
from scapy.all import sniff, IP
from collections import defaultdict
import operator

# --- Global State Management (Reused from Ex 2) ---
total_bytes = 0
start_time = time.time()
ip_byte_counts = defaultdict(int)
stop_event = threading.Event()
data_lock = threading.Lock()

# --- Utility Functions ---
def clear_screen():
    """Clears the console screen (cross-platform compatible)."""
    # 'cls' for Windows, 'clear' for Unix/Linux/macOS
    os.system('cls' if os.name == 'nt' else 'clear')

def packet_processor(pkt):
    """Processes IP packets to track total bytes and per-IP byte usage."""
    global total_bytes
    
    if IP in pkt:
        src_ip = pkt[IP].src
        pkt_len = len(pkt)
        
        with data_lock:
            total_bytes += pkt_len
            ip_byte_counts[src_ip] += pkt_len

def dashboard_renderer():
    """Renders the CLI dashboard every 0.5 seconds."""
    global total_bytes, start_time
    
    while not stop_event.is_set():
        # Wait for 0.5 seconds
        stop_event.wait(0.5)
        if stop_event.is_set():
            break
            
        current_time = time.time()
        elapsed_time = current_time - start_time
        
        # 1. Acquire and copy data safely
        with data_lock:
            current_bytes = total_bytes
            current_ip_counts = dict(ip_byte_counts)
        
        # 2. Calculate Throughput (MB/s)
        rate_mbytes_per_sec = 0
        if elapsed_time > 0:
            rate_mbytes_per_sec = current_bytes / elapsed_time / (1024 * 1024)
            
        # 3. Identify Top Talkers
        sorted_talkers = sorted(current_ip_counts.items(), 
                                key=operator.itemgetter(1), 
                                reverse=True)
        top_5_talkers = sorted_talkers[:5]
        
        # 4. Render Dashboard
        clear_screen()
        
        current_time_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        output = f"""
==================================================
  REAL-TIME NETWORK MONITOR DASHBOARD
==================================================
  Monitor Status: {current_time_str}
  Duration:       {elapsed_time:.2f} seconds
  Total Bytes:    {current_bytes / (1024*1024):.2f} MB
--------------------------------------------------
  CURRENT THROUGHPUT: {rate_mbytes_per_sec:.2f} MB/s
--------------------------------------------------
  TOP 5 TALKERS (Source IP | Total Bytes)
  -----------------------------------------
"""
        if top_5_talkers:
            for i, (ip, bytes_sent) in enumerate(top_5_talkers):
                output += f"  {i+1}. {ip:<15} | {bytes_sent / (1024*1024):.3f} MB\n"
        else:
            output += "  (No IP traffic observed yet)\n"

        output += "--------------------------------------------------\n"
        print(output)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(f"Usage: python {sys.argv[0]} <interface_name>")
        sys.exit(1)
    
    interface_name = sys.argv[1]

    # Start the dashboard rendering thread
    dashboard_thread = threading.Thread(target=dashboard_renderer, daemon=True)
    dashboard_thread.start()
    
    print(f"Starting dynamic capture on {interface_name}. Press Ctrl+C to stop.")
    
    try:
        # Start the blocking sniff operation
        sniff(iface=interface_name, prn=packet_processor, store=0)
        
    except KeyboardInterrupt:
        print("\nStopping capture...")
    except OSError as e:
        print(f"\nError: {e}. Check permissions or interface name.")
    finally:
        stop_event.set()
        dashboard_thread.join(timeout=1)
        clear_screen()
        print("Monitoring stopped.")

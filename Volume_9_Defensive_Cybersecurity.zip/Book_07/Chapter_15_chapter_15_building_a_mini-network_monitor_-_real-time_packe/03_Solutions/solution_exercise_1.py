
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import sys
from scapy.all import sniff, IP, TCP, UDP, ICMP, ARP
from scapy.layers.l2 import Ether

# Global state for aggregation
protocol_counts = {
    "TCP": 0,
    "UDP": 0,
    "ICMP": 0,
    "ARP": 0,
    "Other": 0
}

def packet_processor(pkt):
    """Inspects the packet layers and updates the global protocol counts."""
    
    # Check for Layer 3 (IP)
    if IP in pkt:
        # Check for Transport Layer protocols
        if TCP in pkt:
            protocol_counts["TCP"] += 1
        elif UDP in pkt:
            protocol_counts["UDP"] += 1
        elif ICMP in pkt:
            protocol_counts["ICMP"] += 1
        else:
            # IP packet without recognized L4 (e.g., IGMP, EGP)
            protocol_counts["Other"] += 1
    
    # Check for non-IP Layer 3 protocols (e.g., ARP)
    elif ARP in pkt:
        protocol_counts["ARP"] += 1
        
    # Layer 2 only or unknown L3
    elif Ether in pkt:
        # This catches pure Ethernet frames that aren't IP or ARP
        # We count these under 'Other' if they haven't been counted above.
        # To avoid double counting, we only increment 'Other' if no higher layer was found.
        # Since the logic flows top-down, if we reach this point, it's 'Other'.
        # Note: If a packet is ARP, it won't reach this final 'Other' check.
        pass # The initial structure handles this sufficiently via the existing keys.

def calculate_and_print_stats():
    """Calculates total packets and percentage distribution."""
    total_packets = sum(protocol_counts.values())
    
    if total_packets == 0:
        print("\nNo packets captured.")
        return

    print("\n--- Network Protocol Distribution Summary ---")
    print(f"Total Packets Captured: {total_packets}")
    print("-" * 40)
    
    for proto, count in protocol_counts.items():
        percentage = (count / total_packets) * 100
        print(f"{proto:<5}: {count:>10} packets ({percentage:.2f}%)")
    print("-" * 40)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(f"Usage: python {sys.argv[0]} <interface_name>")
        sys.exit(1)

    interface_name = sys.argv[1]
    print(f"Starting capture on interface '{interface_name}' for 60 seconds...")

    try:
        # Sniff for 60 seconds, using the callback function
        sniff(iface=interface_name, prn=packet_processor, timeout=60, store=0)
    except OSError as e:
        print(f"Error starting capture. Check interface name or permissions (e.g., run with sudo). Error: {e}")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nCapture interrupted by user.")
    
    calculate_and_print_stats()

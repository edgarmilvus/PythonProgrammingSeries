
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import time
import threading
import sys
import os
import logging
from datetime import datetime
from scapy.all import sniff, IP
from collections import defaultdict
import operator

# --- Configuration ---
LOG_FILE = "network_alerts.log"
THRESHOLD_MBPS = 8.0 # 8 MB/s threshold

# Configure Logging (ISO 8601 Timestamp Format)
# %(asctime)s uses the default format, which is locale-specific. 
# We explicitly define the format to ensure ISO 8601 compliance.
logging.basicConfig(
    level=logging.WARNING, 
    filename=LOG_FILE, 
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%dT%H:%M:%S' # ISO 8601 format
)

# --- Global State Management ---
total_bytes_current_window = 0 # Bytes accumulated since the last 5-second check
total_bytes_session = 0
start_time = time.time()
ip_byte_counts = defaultdict(int)
stop_event = threading.Event()
data_lock = threading.Lock()
breach_count = 0 

# --- Utility Functions (Reused from Ex 3) ---
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def packet_processor(pkt):
    """Processes IP packets to track bytes for the current window and session."""
    global total_bytes_current_window, total_bytes_session
    
    if IP in pkt:
        src_ip = pkt[IP].src
        pkt_len = len(pkt)
        
        with data_lock:
            total_bytes_current_window += pkt_len
            total_bytes_session += pkt_len
            ip_byte_counts[src_ip] += pkt_len

def dashboard_renderer():
    """Renders dashboard every 0.5s and checks alerts every 5s."""
    global total_bytes_current_window, total_bytes_session, breach_count
    
    last_alert_check_time = time.time()
    
    while not stop_event.is_set():
        stop_event.wait(0.5)
        if stop_event.is_set(): break
            
        current_time = time.time()
        elapsed_session_time = current_time - start_time
        
        # --- 5-Second Alert and Metric Calculation ---
        if current_time - last_alert_check_time >= 5.0:
            interval_duration = current_time - last_alert_check_time
            
            with data_lock:
                window_bytes = total_bytes_current_window
                total_bytes_current_window = 0 # Reset for the next window
                current_ip_counts = dict(ip_byte_counts)
            
            # Calculate actual rate for the last 5 seconds
            current_rate_mbps = (window_bytes / interval_duration) / (1024 * 1024)
            
            # 1. Sustained Breach Detection Logic
            if current_rate_mbps > THRESHOLD_MBPS:
                breach_count += 1
                if breach_count >= 3:
                    alert_msg = f"HIGH THROUGHPUT ALERT: Rate reached {current_rate_mbps:.2f} MB/s, exceeding {THRESHOLD_MBPS:.1f} MB/s threshold."
                    logging.warning(alert_msg)
                    
                    # Reset count after logging to detect the next sustained breach
                    breach_count = 0 
            else:
                breach_count = 0
            
            last_alert_check_time = current_time
        
        # --- Dashboard Rendering (using session average for display stability) ---
        
        # Calculate session average throughput (for dashboard stability)
        session_rate_mbps = 0
        if elapsed_session_time > 0:
            session_rate_mbps = total_bytes_session / elapsed_session_time / (1024 * 1024)
            
        # Identify Top Talkers (using cumulative session data)
        with data_lock:
            current_ip_counts = dict(ip_byte_counts)
            
        sorted_talkers = sorted(current_ip_counts.items(), 
                                key=operator.itemgetter(1), 
                                reverse=True)
        top_5_talkers = sorted_talkers[:5]
        
        clear_screen()
        current_time_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        output = f"""
==================================================
  REAL-TIME NETWORK MONITOR (ALERTING ENABLED)
==================================================
  Monitor Status: {current_time_str}
  Duration:       {elapsed_session_time:.2f} seconds
  Alert Threshold: {THRESHOLD_MBPS:.1f} MB/s (Sustained 3x 5s checks)
  Breach Count:   {breach_count} / 3
--------------------------------------------------
  SESSION AVERAGE THROUGHPUT: {session_rate_mbps:.2f} MB/s
--------------------------------------------------
  TOP 5 TALKERS (Source IP | Total Bytes)
  -----------------------------------------
"""
        for i, (ip, bytes_sent) in enumerate(top_5_talkers):
            output += f"  {i+1}. {ip:<15} | {bytes_sent / (1024*1024):.3f} MB\n"

        output += "--------------------------------------------------\n"
        print(output)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(f"Usage: python {sys.argv[0]} <interface_name>")
        sys.exit(1)
    
    interface_name = sys.argv[1]
    
    # Ensure log file is clean for a new run
    if os.path.exists(LOG_FILE):
        os.remove(LOG_FILE)
        
    dashboard_thread = threading.Thread(target=dashboard_renderer, daemon=True)
    dashboard_thread.start()
    
    print(f"Starting dynamic capture on {interface_name}. Press Ctrl+C to stop.")
    
    try:
        sniff(iface=interface_name, prn=packet_processor, store=0)
        
    except KeyboardInterrupt:
        pass
    except OSError as e:
        print(f"\nError: {e}. Check permissions or interface name.")
    finally:
        stop_event.set()
        dashboard_thread.join(timeout=1)
        clear_screen()
        print(f"Monitoring stopped. Alerts logged to {LOG_FILE}.")

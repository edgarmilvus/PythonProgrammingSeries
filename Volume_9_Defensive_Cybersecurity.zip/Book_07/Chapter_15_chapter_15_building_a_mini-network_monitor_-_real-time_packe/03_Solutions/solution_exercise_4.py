
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import asyncio
import sys
import time
from scapy.all import AsyncSniffer, IP, TCP, UDP, sniff

# BPF Filter Definition: Only capture DNS (UDP 53) or SSH (TCP 22) traffic
BPF_FILTER = "udp port 53 or tcp port 22"

# Global counter for verification
packet_count = 0

def packet_processor(pkt):
    """Simple processor to count packets and verify filter effectiveness."""
    global packet_count
    packet_count += 1
    
    # Verification check
    if IP in pkt:
        proto = pkt[IP].proto
        if proto == 6 and TCP in pkt and (pkt[TCP].sport == 22 or pkt[TCP].dport == 22):
            pass # SSH
        elif proto == 17 and UDP in pkt and (pkt[UDP].sport == 53 or pkt[UDP].dport == 53):
            pass # DNS
        else:
            # This should ideally never be reached if BPF works correctly
            print(f"ERROR: Captured unexpected packet (L4 Proto: {proto})")


class AsyncMonitorContext:
    """Asynchronous Context Manager to manage the Scapy AsyncSniffer lifecycle."""
    def __init__(self, iface, bpf_filter, prn_callback):
        self.iface = iface
        self.bpf_filter = bpf_filter
        self.prn_callback = prn_callback
        self.sniffer = AsyncSniffer(
            iface=self.iface, 
            filter=self.bpf_filter, 
            prn=self.prn_callback, 
            store=0
        )
        self.task = None

    async def __aenter__(self):
        """Initiates the sniffing process asynchronously."""
        print(f"[{time.strftime('%H:%M:%S')}] Starting Async Sniffer with BPF filter: '{self.bpf_filter}'")
        
        # AsyncSniffer uses threads internally but provides an async interface
        self.task = self.sniffer.start()
        
        # Return the sniffer object for interaction if needed
        return self.sniffer

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Gracefully stops the sniffing process and cleans up resources."""
        print(f"\n[{time.strftime('%H:%M:%S')}] Stopping Async Sniffer...")
        
        # Stop the sniffer task
        self.sniffer.stop()
        
        # Wait for the sniffer to finish its cleanup
        await asyncio.to_thread(self.task.join)
        
        if exc_type:
            print(f"An exception occurred during monitoring: {exc_val}")
            return False # Propagate exception
        
        print(f"[{time.strftime('%H:%M:%S')}] Sniffer stopped gracefully. Total packets processed: {packet_count}")
        return True # Suppress exception if handled


async def main():
    if len(sys.argv) != 2:
        print(f"Usage: python {sys.argv[0]} <interface_name>")
        sys.exit(1)
    
    interface_name = sys.argv[1]
    
    try:
        async with AsyncMonitorContext(interface_name, BPF_FILTER, packet_processor) as sniffer:
            # Main monitoring loop runs here. We wait for a duration.
            print(f"Monitoring for 10 seconds (DNS/SSH traffic only)...")
            await asyncio.sleep(10)
            
    except OSError as e:
        print(f"Fatal Error: {e}. Check permissions or interface.")
        
if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nMain program interrupted.")

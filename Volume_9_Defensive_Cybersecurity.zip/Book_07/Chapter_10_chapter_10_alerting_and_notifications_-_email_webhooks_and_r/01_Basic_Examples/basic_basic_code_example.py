
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import smtplib
import ssl
from email.mime.text import MIMEText
import datetime

# --- 1. Configuration Constants ---

# SMTP Server details (Using Gmail as a common example, requires App Password)
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 465 # Standard port for secure SMTP (SMTPS)
SENDER_EMAIL = "your.security.tool@example.com"
# WARNING: Use environment variables or a secure vault for this in production.
SENDER_PASSWORD = "YOUR_APP_PASSWORD_HERE" 

# Alert recipients
RECEIVER_EMAIL = "security.incident.response@example.com"

# --- 2. Alert Logic Parameters ---

# Define the maximum acceptable number of events before generating a CRITICAL alert.
ALERT_THRESHOLD = 5 

# --- 3. Simulation: Security Event Data ---

# Simulate data collected by a monitoring script (e.g., failed SSH logins in 5 minutes)
failed_attempts = 7
event_source = "SSH Login Service: 192.168.1.10"
event_timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC")

# --- 4. Alerting Function Definition ---

def send_security_alert(subject: str, body: str, receiver: str):
    """Constructs and sends an email notification securely using SMTPS."""
    
    # Create the email message object using MIMEText for plain text content
    message = MIMEText(body)
    message["Subject"] = subject
    message["From"] = SENDER_EMAIL
    message["To"] = receiver
    
    # Create a default SSL context for secure connection encryption
    context = ssl.create_default_context()
    
    print(f"[INFO] Attempting connection to {SMTP_SERVER}:{SMTP_PORT}...")
    
    try:
        # Use smtplib.SMTP_SSL for secure connection on port 465
        with smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT, context=context) as server:
            
            # Log in using the sender's credentials
            server.login(SENDER_EMAIL, SENDER_PASSWORD)
            
            # Send the email. The message must be converted to a string format.
            server.sendmail(SENDER_EMAIL, receiver, message.as_string())
            print(f"[SUCCESS] CRITICAL Alert successfully dispatched to {receiver}.")
            
    except smtplib.SMTPAuthenticationError:
        print("[ERROR] Authentication Failed. Check username, password, and App Password settings.")
    except smtplib.SMTPServerDisconnected:
        print("[ERROR] SMTP Server Disconnected. Check network connectivity or firewall rules.")
    except Exception as e:
        print(f"[FATAL ERROR] An unexpected error occurred during email transmission: {e}")

# --- 5. Main Execution and Threshold Check (Noise Reduction Logic) ---

print(f"Monitoring event: {event_source}. Current attempts: {failed_attempts}. Threshold: {ALERT_THRESHOLD}")

if failed_attempts >= ALERT_THRESHOLD:
    # --- Trigger Alert ---
    
    alert_subject = f"CRITICAL INCIDENT: Brute Force Alert ({failed_attempts} Attempts)"
    alert_body = (
        f"A security threshold has been crossed, indicating potential brute-force activity.\n\n"
        f"Source: {event_source}\n"
        f"Attempts Count: {failed_attempts}\n"
        f"Timestamp: {event_timestamp}\n\n"
        f"Recommendation: Immediately block the source IP and review recent login attempts."
    )
    
    # Call the function to dispatch the alert
    send_security_alert(alert_subject, alert_body, RECEIVER_EMAIL)
    
else:
    # --- Noise Reduction: Log and Ignore ---
    
    # If the event is below the critical threshold, we log the information 
    # but avoid generating unnecessary noise for the operations team.
    print(f"[INFO] Attempts ({failed_attempts}) are below the critical threshold. Alert suppressed.")


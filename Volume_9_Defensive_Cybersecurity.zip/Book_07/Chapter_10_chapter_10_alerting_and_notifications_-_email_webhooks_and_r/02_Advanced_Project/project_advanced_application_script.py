
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import json
import requests
import smtplib
import ssl
from datetime import datetime
from email.mime.text import MIMEText

# --- 1. Configuration and Mock Credentials ---
# In a production environment, these would be loaded securely from environment variables or a vault.

# Mock Webhook Target (e.g., SIEM ingestion endpoint or Slack channel)
WEBHOOK_URL = "https://mock.siem.endpoint/alerts"

# Mock Email Configuration
SMTP_SERVER = "smtp.mockserver.com"
SMTP_PORT = 587
SENDER_EMAIL = "security-alerts@corp.com"
RECEIVER_EMAIL = "security-team@corp.com"
# Note: Using os.getenv for demonstration, assuming values are set externally
SMTP_PASSWORD = os.getenv("SMTP_PASS", "mock_password_123") 

# --- 2. Alert Dispatch Functions ---

def send_webhook_alert(alert_data: dict) -> bool:
    """Dispatches CRITICAL alerts as JSON payload via Webhook."""
    try:
        headers = {'Content-Type': 'application/json'}
        # Simulate a real POST request to the SIEM/Alerting system
        response = requests.post(WEBHOOK_URL, json=alert_data, headers=headers, timeout=5)
        
        if response.status_code == 200:
            print(f"[WEBHOOK SUCCESS] Critical alert dispatched.")
            return True
        else:
            print(f"[WEBHOOK FAILED] Status: {response.status_code}. Response: {response.text[:50]}...")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"[WEBHOOK ERROR] Could not connect to webhook endpoint: {e}")
        return False

def send_email_alert(subject: str, body: str, severity: str) -> bool:
    """Dispatches WARNING/INFO alerts via SMTP."""
    
    message = MIMEText(body)
    message["Subject"] = f"[{severity.upper()}] Security Alert: {subject}"
    message["From"] = SENDER_EMAIL
    message["To"] = RECEIVER_EMAIL
    
    # Secure context for TLS
    context = ssl.create_default_context()
    
    try:
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            # Start TLS encryption
            server.ehlo() 
            server.starttls(context=context)
            server.ehlo()
            
            # Login using credentials
            server.login(SENDER_EMAIL, SMTP_PASSWORD)
            server.sendmail(SENDER_EMAIL, RECEIVER_EMAIL, message.as_string())
            print(f"[EMAIL SUCCESS] {severity.upper()} alert sent via email.")
            return True
            
    except smtplib.SMTPAuthenticationError:
        print("[EMAIL FAILED] Authentication error. Check credentials.")
        return False
    except smtip.SMTPException as e:
        print(f"[EMAIL FAILED] SMTP error occurred: {e}")
        return False
    except Exception as e:
        print(f"[EMAIL FAILED] General error during email dispatch: {e}")
        return False

# --- 3. Prioritization and Processing Engine ---

def process_log_entry(log_entry: str):
    """
    Parses a single log entry, determines severity, and routes the alert.
    Log Format: YYYY-MM-DD HH:MM:SS | User | Event | Message
    """
    try:
        # Split the entry based on the standard delimiter
        parts = [p.strip() for p in log_entry.split('|')]
        
        if len(parts) != 4:
            print(f"[PARSE ERROR] Malformed log entry: {log_entry}")
            return

        timestamp_str, user, event, message = parts
        
        # Use datetime.strptime() to parse the timestamp string
        timestamp = datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M:%S")
        
        # --- Prioritization Logic (Noise Reduction) ---
        severity = "INFO"
        
        # Rule 1: Immediate failure indicates a critical event (e.g., brute force)
        if "LOGIN_FAIL" in event and "BRUTE_FORCE" in message:
            severity = "CRITICAL"
            
        # Rule 2: Accessing sensitive configuration is a high warning
        elif "CONFIG_ACCESS" in event and "SENSITIVE" in message:
            severity = "WARNING"
            
        # Rule 3: General access logs are informational
        elif "LOGIN_SUCCESS" in event:
            severity = "INFO"
            
        # --- Alert Routing ---
        
        alert_subject = f"{event} by {user}"
        alert_body = (
            f"Timestamp: {timestamp.isoformat()}\n"
            f"User: {user}\n"
            f"Event: {event}\n"
            f"Message: {message}"
        )

        if severity == "CRITICAL":
            # Package data for machine consumption (JSON for Webhook)
            webhook_payload = {
                "severity": severity,
                "timestamp": timestamp.isoformat(),
                "source": "DefensiveLogAnalyzer",
                "event_details": {
                    "user": user,
                    "event_type": event,
                    "raw_message": message
                }
            }
            send_webhook_alert(webhook_payload)
            
        elif severity in ["WARNING", "INFO"]:
            # Send detailed human-readable report via email
            send_email_alert(alert_subject, alert_body, severity)
            
    except ValueError as e:
        print(f"[PARSE ERROR] Date/Time format issue: {e}")
    except Exception as e:
        print(f"[ENGINE ERROR] Unhandled exception during processing: {e}")

# --- 4. Simulation ---

MOCK_SECURITY_LOGS = [
    "2023-10-26 14:00:01 | Alice | LOGIN_SUCCESS | User logged in from 192.168.1.10",
    "2023-10-26 14:00:15 | Bob | CONFIG_ACCESS | Attempted to view non-sensitive settings.",
    "2023-10-26 14:00:30 | Attacker | LOGIN_FAIL | Failed login attempt 1/5.",
    "2023-10-26 14:00:31 | Attacker | LOGIN_FAIL | Failed login attempt 2/5 (BRUTE_FORCE detected).",
    "2023-10-26 14:00:45 | Charlie | CONFIG_ACCESS | Accessed SENSITIVE database credentials file.",
    "2023-10-26 14:01:00 | Alice | LOGOUT_SUCCESS | User session ended."
]

if __name__ == "__main__":
    print("--- Starting Defensive Alerting Engine Simulation ---")
    
    # Iterate over the simulated log entries
    for log_entry in MOCK_SECURITY_LOGS:
        print(f"\nProcessing: {log_entry}")
        process_log_entry(log_entry)
        
    print("\n--- Simulation Complete ---")

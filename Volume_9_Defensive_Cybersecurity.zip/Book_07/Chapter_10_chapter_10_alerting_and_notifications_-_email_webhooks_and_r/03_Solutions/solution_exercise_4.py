
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from datetime import datetime, timedelta
import time # Used for simulation delays

# 1. State Management (Using global variables for simplicity in simulation)
alert_queue = []
last_send_time = datetime.min # Initialize to a very early time

# 2. Constants
BATCH_SIZE_LIMIT = 5
BATCH_TIMEOUT = timedelta(seconds=30)

def send_batch_webhook():
    """3. Mock Sending Function: Sends the current batch and resets state."""
    global alert_queue
    global last_send_time
    
    if not alert_queue:
        # Avoid sending empty batches
        return

    batch_size = len(alert_queue)
    print(f"\n[BATCH SENT] Sending batch of {batch_size} alerts to SIEM.")
    
    # Simulate network transmission time
    # time.sleep(0.1) 
    
    # Clear the queue and update the last send time
    alert_queue = []
    last_send_time = datetime.now()
    print(f"Queue cleared. Next batch timeout starts now: {last_send_time.strftime('%H:%M:%S')}")


def add_alert_to_queue(alert, current_time):
    """4. Queue Management Function: Adds an alert and checks batch triggers."""
    global alert_queue
    global last_send_time

    # If the queue is empty, this is the start of a new batch cycle
    if not alert_queue:
        last_send_time = current_time
        alert_queue.append(alert)
        print(f"Alert added. Queue size: 1. Timer reset to: {current_time.strftime('%H:%M:%S')}")
        return

    # Add the current alert
    alert_queue.append(alert)
    print(f"Alert added. Queue size: {len(alert_queue)}")

    # Check Trigger 1: Size Limit
    if len(alert_queue) >= BATCH_SIZE_LIMIT:
        print("Trigger 1 activated: Batch size limit reached.")
        send_batch_webhook()
        return

    # Check Trigger 2: Time Limit (only if queue size is less than limit)
    time_elapsed = current_time - last_send_time
    if time_elapsed >= BATCH_TIMEOUT:
        print(f"Trigger 2 activated: Timeout reached ({time_elapsed} elapsed).")
        send_batch_webhook()
        return

# --- Demonstration ---

# Simulation setup
alerts = [f"Alert {i+1}" for i in range(6)]
sim_start_time = datetime.now()

# Scenario A: Size Trigger (5 alerts quickly added)
print("\n--- SCENARIO A: Testing Size Trigger (5 alerts quickly) ---")
for i, alert in enumerate(alerts[:5]):
    sim_time = sim_start_time + timedelta(seconds=i) # Simulate 1s apart
    add_alert_to_queue(alert, sim_time)

# Scenario B: Time Trigger (1 alert added, then wait 30 seconds)
print("\n--- SCENARIO B: Testing Time Trigger (1 alert, then wait) ---")
alert_queue = [] # Reset queue state
last_send_time = datetime.min # Reset time state

# 1. Add first alert
current_time_b1 = datetime.now()
add_alert_to_queue("Time Test Alert 1", current_time_b1)

# 2. Simulate 35 seconds passing (manual time advance)
current_time_b2 = current_time_b1 + timedelta(seconds=35)
print(f"Simulating time advance to {current_time_b2.strftime('%H:%M:%S')}")

# 3. Add a second alert, which should trigger the timeout send
add_alert_to_queue("Time Test Alert 2 (Trigger)", current_time_b2)

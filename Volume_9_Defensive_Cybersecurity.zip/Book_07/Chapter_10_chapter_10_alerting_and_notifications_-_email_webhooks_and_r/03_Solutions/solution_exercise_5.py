
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from datetime import datetime

# 1. Log Data
raw_logs = [
    "2024-03-15 14:01:05 | CRITICAL | User 'admin' failed login attempt from 192.168.1.10",
    "2024-03-15 14:01:08 | CRITICAL | User 'admin' failed login attempt from 192.168.1.10",
    "2024-03-15 14:01:12 | CRITICAL | User 'admin' failed login attempt from 192.168.1.10",
    "2024-03-15 14:01:19 | CRITICAL | User 'admin' failed login attempt from 192.168.1.10",
    "2024-03-15 14:01:25 | CRITICAL | User 'admin' failed login attempt from 192.168.1.10",
]

# 2. Format Identification
# Format: YYYY-MM-DD HH:MM:SS
LOG_FORMAT = "%Y-%m-%d %H:%M:%S"

# Variables to store timeline boundaries
first_timestamp = None
last_timestamp = None

print("--- Parsing Log Timestamps ---")

# 3. Parsing Implementation
for log_line in raw_logs:
    # Timestamps are the first 19 characters
    timestamp_str = log_line[:19] 
    
    try:
        dt_object = datetime.strptime(timestamp_str, LOG_FORMAT)
        print(f"Parsed: {timestamp_str} -> {dt_object}")

        # 4. Timeline Calculation: Track first and last
        if first_timestamp is None:
            first_timestamp = dt_object
        
        # Always update the last timestamp in the loop
        last_timestamp = dt_object
        
    except ValueError as e:
        print(f"Error parsing timestamp '{timestamp_str}': {e}")
        
if first_timestamp and last_timestamp:
    # 5. Output: Calculate the difference (timedelta)
    total_duration = last_timestamp - first_timestamp
    
    print("\n--- Timeline Analysis ---")
    print(f"First Event Time: {first_timestamp.strftime(LOG_FORMAT)}")
    print(f"Last Event Time:  {last_timestamp.strftime(LOG_FORMAT)}")
    print(f"Total attack duration: {total_duration}")
else:
    print("Could not parse enough timestamps to calculate duration.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import json
from datetime import datetime

def generate_webhook_payload(timestamp, source_ip, event_category, severity, message):
    """
    Generates a standardized JSON payload structure for a generic webhook endpoint.
    Raises ValueError if source_ip is missing.
    """
    # 4. Error Handling (Input Validation)
    if not source_ip:
        raise ValueError("Cannot generate webhook payload: 'source_ip' field is required for context.")

    # 2. Data Serialization (Constructing the Python dictionary)
    payload_dict = {
        "alert_time": timestamp,
        "source": source_ip,
        "classification": event_category,
        "priority": severity,
        "details": {
            "message": message,
            "system_status": "Active" # Added for robustness
        }
    }

    # 3. JSON Conversion
    # Use indent=4 for readable output during demonstration
    json_payload = json.dumps(payload_dict, indent=4)
    
    return json_payload

# --- Demonstration ---
try:
    # Sample Input Data
    current_time = datetime.now().isoformat()
    
    # 5. Successful Output Demonstration
    critical_event = generate_webhook_payload(
        timestamp=current_time,
        source_ip="203.0.113.45",
        event_category="Successful Unauthorized Login",
        severity="CRITICAL",
        message="User 'sysadmin' logged in from unusual geolocation (Russia)."
    )
    print("--- Valid Webhook Payload Generated ---")
    print(critical_event)
    
    # Demonstration of Error Handling
    print("\n--- Testing Error Handling (Missing IP) ---")
    invalid_event = generate_webhook_payload(
        timestamp=current_time,
        source_ip="", # Empty source IP
        event_category="Test",
        severity="LOW",
        message="Should fail validation."
    )

except ValueError as e:
    print(f"Error caught: {e}")


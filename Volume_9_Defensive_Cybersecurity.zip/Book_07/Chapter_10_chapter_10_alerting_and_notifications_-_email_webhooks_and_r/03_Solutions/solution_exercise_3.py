
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from datetime import datetime, timedelta

# 1. Time Tracking Structure (Global State for simulation)
last_alert_timestamps = {}

# 2. Time Window Definition
DEBOUNCE_WINDOW = timedelta(seconds=60)

def check_and_process_alert(source_ip, current_time):
    """
    Checks if an alert from a specific source IP falls within the debounce window.
    """
    global last_alert_timestamps
    
    if source_ip not in last_alert_timestamps:
        # Case 1: New source IP or first alert
        last_alert_timestamps[source_ip] = current_time
        return f"[SENT] First alert from {source_ip}. Timestamp recorded: {current_time.strftime('%H:%M:%S')}"
    
    last_time = last_alert_timestamps[source_ip]
    time_difference = current_time - last_time
    
    if time_difference < DEBOUNCE_WINDOW:
        # Case 2: Alert is within the 60-second window
        return f"[SUPPRESSED] Alert from {source_ip} suppressed. Diff: {time_difference}. Window: {DEBOUNCE_WINDOW}"
    else:
        # Case 3: Window expired, process the new alert and update timestamp
        last_alert_timestamps[source_ip] = current_time
        return f"[SENT] Alert from {source_ip} sent. Window expired. Diff: {time_difference}. New timestamp recorded."

# --- 4. Demonstration ---
SIM_IP = "192.168.1.50"
start_time = datetime(2024, 1, 1, 10, 0, 0) # 10:00:00

print(f"--- Debouncing Simulation (Window: {DEBOUNCE_WINDOW}) ---")

# Sequence 1: First alert (SENT)
print("Event 1 (T+0s):", check_and_process_alert(SIM_IP, start_time))

# Sequence 2-5: Alerts 10s apart (SUPPRESSED)
for i in range(1, 5):
    current_sim_time = start_time + timedelta(seconds=i * 10)
    print(f"Event {i+1} (T+{i*10}s):", check_and_process_alert(SIM_IP, current_sim_time))

# Sequence 6: Alert 70s after the first (SENT, window expired)
final_sim_time = start_time + timedelta(seconds=70)
print(f"Event 6 (T+70s):", check_and_process_alert(SIM_IP, final_sim_time))

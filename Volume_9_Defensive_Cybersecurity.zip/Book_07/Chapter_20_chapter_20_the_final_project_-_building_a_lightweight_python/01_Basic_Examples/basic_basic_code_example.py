
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import re
import sys
from datetime import datetime
from typing import Optional, Dict, Any

# 1. Define the standard Apache Combined Log Format regex pattern using named capture groups.
# Named groups allow us to extract data by descriptive key rather than numerical index (DRY).
LOG_PATTERN = re.compile(
    r'(?P<ip>\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}) '  # Group 1: Client IP (e.g., 192.168.1.10)
    r'- - '                                        # Standard placeholders (user/auth)
    r'\[(?P<timestamp>[^\]]+)\] '                  # Group 2: Timestamp (e.g., 05/Sep/2024:10:30:00 +0000)
    r'"(?P<method>\w+) (?P<path>[^\s]+) HTTP/\d\.\d" ' # Group 3/4: Request method and path
    r'(?P<status>\d{3}) '                          # Group 5: HTTP Status Code (e.g., 200, 404)
    r'(?P<size>\d+) '                              # Group 6: Response Size in bytes
    r'"(?P<referer>[^"]*)" '                       # Group 7: Referer URL
    r'"(?P<user_agent>[^"]*)"'                     # Group 8: User Agent string
)

def parse_log_line(log_line: str) -> Optional[Dict[str, Any]]:
    """
    Parses a single raw log line into a normalized SIEM event dictionary.

    Args:
        log_line: The raw string input from a log file.

    Returns:
        A dictionary of normalized event fields, or None if parsing fails.
    """
    
    # Attempt to match the defined pattern against the raw input line
    match = LOG_PATTERN.match(log_line)

    if match:
        # Extract all named groups into a standard Python dictionary
        raw_data = match.groupdict()
        
        # 2. Timestamp Normalization (Crucial for SIEM correlation)
        try:
            # The format string must exactly match the log's timestamp structure
            # %d/%b/%Y:%H:%M:%S %z -> Day/Month(Abbrev)/Year:Hour:Minute:Second Timezone
            dt_obj = datetime.strptime(raw_data['timestamp'], '%d/%b/%Y:%H:%M:%S %z')
            # Convert to ISO 8601 format (Standard for databases and SIEMs)
            normalized_time = dt_obj.isoformat()
        
        except ValueError as e:
            # Handle cases where the timestamp format is unexpected
            print(f"ERROR: Timestamp parsing failed for line. Details: {e}", file=sys.stderr)
            # In a real SIEM, we might log this error and discard the event, or exit if critical.
            # Here, we return None to indicate failure.
            return None
        
        # 3. Data Type Conversion and Normalization Mapping
        # Map the raw fields to our internal, standardized SIEM schema names.
        normalized_event = {
            'event_type': 'HTTP_ACCESS',           # Standardized event identifier
            'event_time': normalized_time,         # ISO 8601 standardized time
            'source_ip': raw_data['ip'],           # Source IP
            'http_method': raw_data['method'],     # HTTP Verb (GET, POST, etc.)
            'request_path': raw_data['path'],      # Requested resource
            'status_code': int(raw_data['status']),# Ensure status is an integer
            'response_size_bytes': int(raw_data['size']), # Ensure size is an integer
            'user_agent': raw_data['user_agent']   # Client software identifier
        }
        
        return normalized_event
    
    else:
        # Log line did not match the expected pattern
        return None

# --- Execution Simulation ---
RAW_LOG_ENTRY_SUCCESS = '192.168.1.10 - - [05/Sep/2024:10:30:00 +0000] "GET /api/v1/users HTTP/1.1" 200 4567 "-" "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"'
RAW_LOG_ENTRY_FAILURE = '10.0.0.5 - [05/Sep/2024:10:31:00 +0000] BAD_FORMAT' # Missing fields

print("--- 1. Attempting Successful Parsing ---")
parsed_data_1 = parse_log_line(RAW_LOG_ENTRY_SUCCESS)

if parsed_data_1:
    print(f"Input Line: {RAW_LOG_ENTRY_SUCCESS[:80]}...")
    print("\nNormalized Event Structure:")
    # Display the normalized data structure cleanly
    for key, value in parsed_data_1.items():
        print(f"  {key:<25}: {value} ({type(value).__name__})")
else:
    print("Parsing failed for successful entry.")

print("\n" + "="*50 + "\n")

print("--- 2. Attempting Failed Parsing (Format Mismatch) ---")
parsed_data_2 = parse_log_line(RAW_LOG_ENTRY_FAILURE)

if parsed_data_2 is None:
    print("Parsing correctly returned None, indicating log line format mismatch or internal error.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

#!/usr/bin/env python3
# SIEM_Correlator.py - A Lightweight Python SIEM Component for Brute-Force Detection
# This script demonstrates log ingestion, normalization, persistent storage, and correlation.

import re
import sqlite3
import datetime
import sys
import time

# --- Configuration Constants ---
DB_NAME = "siem_events.db"
LOG_FORMAT_REGEX = re.compile(
    r'(?P<ip>\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}) - '  # Source IP
    r'\[(?P<timestamp>.*?)\] '                         # Timestamp
    r'"(?P<action>.*?) (?P<status>Success|Failure) for user (?P<user>.*?)"' # Action/Status
)
FAILURE_THRESHOLD = 5
TIME_WINDOW_SECONDS = 60

# --- 1. Database Management Functions (DRY Principle) ---

def setup_database(db_name):
    """Initializes the SQLite database and creates the necessary table."""
    try:
        conn = sqlite3.connect(db_name)
        cursor = conn.cursor()
        # The table stores normalized event data
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS security_events (
                id INTEGER PRIMARY KEY,
                event_time TEXT NOT NULL,
                source_ip TEXT NOT NULL,
                username TEXT,
                status TEXT NOT NULL,
                raw_log TEXT
            );
        """)
        conn.commit()
        return conn
    except sqlite3.Error as e:
        print(f"CRITICAL DB ERROR: Could not set up database: {e}", file=sys.stderr)
        sys.exit(1)

def store_event(conn, event_data):
    """Stores a single normalized event into the database."""
    try:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO security_events (event_time, source_ip, username, status, raw_log)
            VALUES (?, ?, ?, ?, ?);
        """, (
            event_data['event_time'],
            event_data['source_ip'],
            event_data['username'],
            event_data['status'],
            event_data['raw_log']
        ))
        conn.commit()
    except sqlite3.Error as e:
        # Non-critical error, log and continue processing
        print(f"Warning: Failed to store event: {e}", file=sys.stderr)

# --- 2. Log Ingestion and Normalization ---

def parse_log_line(log_line):
    """Parses a raw log line into a structured dictionary (Normalization)."""
    match = LOG_FORMAT_REGEX.match(log_line)
    if match:
        data = match.groupdict()
        # Convert log timestamp to ISO format for consistent storage
        data['event_time'] = datetime.datetime.now().isoformat()
        return {
            'source_ip': data['ip'],
            'event_time': data['event_time'],
            'username': data['user'],
            'status': data['status'],
            'raw_log': log_line.strip()
        }
    return None

# --- 3. Correlation Engine ---

def check_bruteforce_threshold(conn, ip_address):
    """
    Checks the database for recent failed login attempts from a specific IP.
    Implements the core correlation rule.
    """
    try:
        cursor = conn.cursor()
        # Calculate the cutoff time for the sliding window
        cutoff_time = datetime.datetime.now() - datetime.timedelta(seconds=TIME_WINDOW_SECONDS)
        
        # Query for failed attempts within the window
        cursor.execute("""
            SELECT COUNT(*) FROM security_events
            WHERE source_ip = ? AND status = 'Failure' AND event_time >= ?;
        """, (ip_address, cutoff_time.isoformat()))
        
        fail_count = cursor.fetchone()[0]
        
        if fail_count >= FAILURE_THRESHOLD:
            # Alerting Mechanism (In a real SIEM, this would trigger an external action)
            print("-" * 50)
            print(f"!!! INCIDENT DETECTED !!!")
            print(f"Brute-Force Alert: IP {ip_address} exceeded {FAILURE_THRESHOLD} failures in {TIME_WINDOW_SECONDS}s.")
            print(f"Total failures counted: {fail_count}")
            print("-" * 50)
            return True
        return False

    except sqlite3.Error as e:
        print(f"Correlation check failed: {e}", file=sys.stderr)
        return False

# --- 4. Main Execution and Simulation ---

def main():
    """Orchestrates the SIEM component process."""
    print(f"[*] Initializing Lightweight SIEM Correlator...")
    db_connection = setup_database(DB_NAME)

    # Simulated stream of logs (mixing normal traffic, success, and a brute-force sequence)
    log_stream = [
        # Normal traffic
        '192.168.1.10 - [2023-10-27 10:00:01] "LOGIN Success for user admin"',
        '10.0.0.5 - [2023-10-27 10:00:05] "LOGIN Failure for user guest"',
        # Start of Brute-Force from 45.45.45.45
        '45.45.45.45 - [2023-10-27 10:00:10] "LOGIN Failure for user root"',
        '45.45.45.45 - [2023-10-27 10:00:11] "LOGIN Failure for user root"',
        '45.45.45.45 - [2023-10-27 10:00:12] "LOGIN Failure for user test"',
        '172.16.0.2 - [2023-10-27 10:00:13] "LOGIN Success for user service_acct"',
        '45.45.45.45 - [2023-10-27 10:00:14] "LOGIN Failure for user user1"',
        '45.45.45.45 - [2023-10:00:15] "LOGIN Failure for user user2"', # 5th failure (Alert Trigger)
        '45.45.45.45 - [2023-10-27 10:00:16] "LOGIN Failure for user user3"',
        '10.0.0.5 - [2023-10-27 10:00:20] "LOGIN Success for user guest"',
    ]

    for i, raw_log in enumerate(log_stream):
        print(f"[{i+1}/{len(log_stream)}] Processing: {raw_log[:50]}...")
        
        # 1. Ingestion and Normalization
        normalized_event = parse_log_line(raw_log)
        
        if normalized_event:
            # 2. Persistent Storage
            store_event(db_connection, normalized_event)
            
            # 3. Correlation Check (Only check failed attempts to optimize)
            if normalized_event['status'] == 'Failure':
                check_bruteforce_threshold(db_connection, normalized_event['source_ip'])
        
        # Simulate real-world log delay
        time.sleep(0.1)

    print("\n[*] Processing complete. Database closed.")
    db_connection.close()

if __name__ == "__main__":
    main()

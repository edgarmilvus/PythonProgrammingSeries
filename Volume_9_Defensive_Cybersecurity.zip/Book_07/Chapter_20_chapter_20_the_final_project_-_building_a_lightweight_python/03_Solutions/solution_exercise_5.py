
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import re
from datetime import datetime
from typing import Dict, Any, Callable, Optional

# A. New Log Source Definition
FIREWALL_LOG_1 = "FW_DENY: time=2023-10-10T14:35:00Z src=192.168.1.5 dst=10.0.0.10 proto=TCP sport=54321 dport=22 action=DROP reason=POLICY_VIOLATION"

# Firewall Regex Pattern (simplified key=value parsing)
FIREWALL_LOG_PATTERN = re.compile(
    r'time=(?P<timestamp>.*?) src=(?P<source_ip>\S+) dst=(?P<destination_ip>\S+) '
    r'.*? dport=(?P<destination_port>\S+) action=(?P<action>\S+)'
)

# B. Dedicated Parser for Firewall Logs
def normalize_firewall_log(log_entry: str) -> Optional[Dict[str, Any]]:
    """Parses and normalizes a Firewall Denial log entry."""
    match = FIREWALL_LOG_PATTERN.search(log_entry)
    if not match:
        return None
    
    data = match.groupdict()
    
    try:
        # Parse ISO timestamp (removing Z)
        ts = datetime.fromisoformat(data['timestamp'].replace('Z', '+00:00'))
        dest_port = int(data['destination_port'])
    except ValueError:
        return None

    normalized_data = {
        'source_ip': data['source_ip'],
        'destination_ip': data['destination_ip'],
        'timestamp_utc': ts.isoformat(),
        'destination_port': dest_port,
        'action': data['action'],
        'http_status': 0, 
        'request_path': 'N/A',
        'bytes_sent': 0,
        'user_agent': 'N/A',
        'event_type': 'firewall_denial'
    }
    return normalized_data

# C. Dynamic Log Dispatcher Setup
# Map log prefixes/identifiers to their corresponding parser function
PARSER_MAP: Dict[str, Callable[[str], Optional[Dict[str, Any]]]] = {
    "FW_DENY": normalize_firewall_log,
    # Use common IP prefixes to identify Apache logs
    "192": normalize_apache_log, 
    "10": normalize_apache_log,
    "172": normalize_apache_log,
}

def ingest_log_line(raw_log_line: str) -> Dict[str, Any]:
    """
    Central dispatcher that routes the raw log line to the correct parser 
    based on the log prefix (Variable Rule concept).
    """
    
    parser_func = None
    
    # Check the start of the log line against known prefixes
    for prefix, func in PARSER_MAP.items():
        if raw_log_line.startswith(prefix):
            parser_func = func
            break
            
    if not parser_func:
        return {"status": "error", "message": "Unknown log source/format", "raw_log": raw_log_line}

    # Execute the selected parser function
    normalized_data = parser_func(raw_log_line)
    
    if normalized_data:
        return {"status": "success", "data": normalized_data}
    else:
        return {"status": "error", "message": "Parsing failed (malformed entry)", "raw_log": raw_log_line}

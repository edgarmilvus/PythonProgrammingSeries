
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from typing import Dict, Any

def generate_alert_report(incident_data: Dict[str, Any]) -> str:
    """
    Generates a structured, indented alert report from incident data.
    """
    
    # Safely extract required data
    incident_id = incident_data.get('incident_id', 'N/A')
    severity = incident_data.get('severity', 'Low')
    source_ip = incident_data.get('source_ip', 'Unknown')
    description = incident_data.get('description', 'No description provided.')
    trigger_events = incident_data.get('trigger_events', [])
    trigger_count = incident_data.get('trigger_count', len(trigger_events))
    
    # B. Structured Report Generation using f-strings and strict indentation
    report = f"""
INCIDENT ALERT: {severity} - {incident_id}
--------------------------------------------------
    Source IP: {source_ip}
    Description: {description}
    Trigger Count: {trigger_count}

    Timeline of Events:
"""
    
    # C. Handling Empty Data
    if not trigger_events:
        # Indentation: 8 spaces (4 for block + 4 for item)
        report += "        No specific logs attached to this alert.\n"
    else:
        # Indent each event line
        for i, event in enumerate(trigger_events):
            report += f"        Event {i+1}: {event}\n"
            
    report += "--------------------------------------------------\n"
    
    return report.strip()

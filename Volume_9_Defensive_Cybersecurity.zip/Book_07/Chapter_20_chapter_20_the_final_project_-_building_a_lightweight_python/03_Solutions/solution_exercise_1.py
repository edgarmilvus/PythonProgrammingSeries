
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import re
from datetime import datetime
from typing import Optional, Dict, Any

LOG_LINE_1 = '192.168.1.10 - user_a [10/Oct/2023:14:30:01 +0000] "GET /api/v1/users/123 HTTP/1.1" 200 4567 "https://referrer.com" "Mozilla/5.0"'
LOG_LINE_3 = '172.16.0.1 - user_c [10/Oct/2023:14:30:10 +0000] "GET /bad/path/injection?param=<> HTTP/1.1" 400 - "http://internal.net" "MaliciousAgent"'

APACHE_LOG_PATTERN = re.compile(
    r'(?P<ip>\S+) \S+ (?P<user>\S+) \[(?P<timestamp>.*?)\] '
    r'"(?P<method>\S+) (?P<path>\S+?) (?P<protocol>\S+?)" '
    r'(?P<status>\S+) (?P<bytes>\S+) "(?P<referrer>.*?)" '
    r'"(?P<agent>.*?)"'
)

def normalize_apache_log(log_entry: str) -> Optional[Dict[str, Any]]:
    """Parses and normalizes an Apache log entry using EAFP for robustness."""
    match = APACHE_LOG_PATTERN.match(log_entry)
    if not match:
        return None
    
    data = match.groupdict()
    
    # EAFP for Timestamp Conversion: If parsing fails, the entry is unusable.
    try:
        ts_str = data['timestamp'].split(' ')[0]
        timestamp_utc = datetime.strptime(ts_str, '%d/%b/%Y:%H:%M:%S')
    except (ValueError, IndexError):
        return None # Return None if the timestamp is corrupted

    # EAFP for Numeric Fields (Status Code and Bytes Sent)
    
    # 1. HTTP Status Code: Default to 999 if conversion fails
    http_status = 999 
    try:
        http_status = int(data['status'])
    except ValueError:
        pass # Forgiveness: status was non-numeric (e.g., '-')

    # 2. Bytes Sent: Default to 0 if conversion fails
    bytes_sent = 0 
    try:
        # Ensure we don't try to convert '-'
        if data['bytes'] != '-':
            bytes_sent = int(data['bytes'])
    except ValueError:
        pass # Forgiveness: conversion failed
    
    # Normalization and Sanitization (removing known malicious characters)
    request_path = data['path'].replace('<', '').replace('>', '')

    normalized_data = {
        'source_ip': data['ip'],
        'timestamp_utc': timestamp_utc.isoformat(),
        'request_path': request_path,
        'http_status': http_status,
        'bytes_sent': bytes_sent,
        'user_agent': data['agent'],
        'event_type': 'apache_access'
    }
    
    return normalized_data

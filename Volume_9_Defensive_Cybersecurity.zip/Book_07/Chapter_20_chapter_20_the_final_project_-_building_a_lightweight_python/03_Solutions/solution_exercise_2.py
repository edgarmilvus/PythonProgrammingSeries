
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import sqlite3
from datetime import datetime, timedelta
from typing import Dict, Any, List

DB_NAME = 'siem_data.db'

class LogDatabaseManager:
    """Manages SQLite persistence for normalized log data."""
    def __init__(self, db_name: str = DB_NAME):
        self.db_name = db_name
        self.setup_database()

    def _connect(self):
        """Internal helper to establish a connection."""
        return sqlite3.connect(self.db_name)

    def setup_database(self):
        """Creates the normalized_logs table with necessary indexes."""
        conn = self._connect()
        cursor = conn.cursor()
        
        # A. Database Schema and Initialization
        sql_create_table = """
        CREATE TABLE IF NOT EXISTS normalized_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            source_ip TEXT NOT NULL,
            http_status INTEGER,
            request_path TEXT,
            bytes_sent INTEGER,
            user_agent TEXT,
            event_type TEXT
        );
        """
        cursor.execute(sql_create_table)
        
        # Explicitly create indexes for rapid lookups
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_timestamp ON normalized_logs (timestamp);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_source_ip ON normalized_logs (source_ip);")
        
        conn.commit()
        conn.close()

    def insert_log_entry(self, data_dict: Dict[str, Any]):
        """B. Inserts a normalized log entry using parameterized queries."""
        conn = self._connect()
        cursor = conn.cursor()
        
        # Define the data structure for insertion
        data = (
            data_dict.get('timestamp_utc'),
            data_dict.get('source_ip'),
            data_dict.get('http_status'),
            data_dict.get('request_path'),
            data_dict.get('bytes_sent'),
            data_dict.get('user_agent'),
            data_dict.get('event_type')
        )
        
        sql_insert = """
        INSERT INTO normalized_logs (timestamp, source_ip, http_status, request_path, bytes_sent, user_agent, event_type)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """
        
        # Security Focus: Use parameterized query (placeholders '?')
        try:
            cursor.execute(sql_insert, data)
            conn.commit()
        except sqlite3.Error as e:
            print(f"DB insertion error: {e}")
        finally:
            conn.close()

    def fetch_events_by_ip_and_time(self, ip_address: str, time_window_seconds: int) -> List[Dict[str, Any]]:
        """C. Retrieves events for a specific IP within a rolling time window."""
        conn = self._connect()
        cursor = conn.cursor()
        
        # Calculate the start time (ISO 8601 format for TEXT comparison)
        current_time = datetime.utcnow()
        start_time = current_time - timedelta(seconds=time_window_seconds)
        start_time_iso = start_time.isoformat()
        
        # Optimized query using indexed fields
        sql_select = """
        SELECT timestamp, source_ip, http_status, request_path, user_agent, event_type
        FROM normalized_logs
        WHERE source_ip = ? AND timestamp >= ?
        ORDER BY timestamp ASC;
        """
        
        cursor.execute(sql_select, (ip_address, start_time_iso))
        
        columns = [col[0] for col in cursor.description]
        results = [dict(zip(columns, row)) for row in cursor.fetchall()]
        
        conn.close()
        return results

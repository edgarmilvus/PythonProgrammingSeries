
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import time
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta

# Configuration for the rule
SENSITIVE_PATHS = ['/admin/login', '/api/v1/auth']
BROWSER_AGENTS = ['Mozilla', 'Chrome', 'Safari', 'Edge']

def is_suspicious_agent(user_agent: str) -> bool:
    """Checks if the user agent is not a common browser."""
    if not user_agent or user_agent == 'N/A':
        return True
    return not any(browser in user_agent for browser in BROWSER_AGENTS)

def detect_bruteforce_bot(
    ip_address: str, 
    db_manager: 'LogDatabaseManager', 
    threshold: int = 5, 
    window_minutes: int = 3
) -> Optional[Dict[str, Any]]:
    """
    A. Implements the enhanced correlation rule for brute-force bot detection.
    """
    
    time_window_seconds = window_minutes * 60
    
    # B. Utilizing optimized retrieval from Ex 2
    all_events = db_manager.fetch_events_by_ip_and_time(ip_address, time_window_seconds)
    
    trigger_events = []
    
    for event in all_events:
        status = event.get('http_status')
        path = event.get('request_path', '')
        agent = event.get('user_agent', '')
        
        # Apply the multi-layered filter: Status, Path, and Agent
        is_failure = status in (401, 403)
        is_sensitive = any(p in path for p in SENSITIVE_PATHS)
        is_bot = is_suspicious_agent(agent)
        
        if is_failure and is_sensitive and is_bot:
            trigger_events.append({
                'timestamp': event['timestamp'],
                'path': path,
                'status': status
            })

    count = len(trigger_events)
    
    if count >= threshold:
        # C. Output Structure
        incident_details = [
            f"[{e['timestamp']}] Path: {e['path']}, Status: {e['status']}" 
            for e in trigger_events
        ]
        
        return {
            "incident_id": f"BRUTEFORCE_BOT_ATTACK_{int(time.time())}",
            "source_ip": ip_address,
            "severity": "High",
            "description": f"Detected {count} suspicious login failures targeting sensitive paths in {window_minutes} minutes.",
            "trigger_events": incident_details,
            "trigger_count": count
        }
        
    return None


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

from collections import defaultdict
import numpy as np
import time
import random

# --- 1. Configuration and Thresholds ---
# These thresholds mimic the output of a trained Machine Learning model
# based on known C2 characteristics (e.g., fixed-interval beacons).
MIN_FLOW_PACKETS = 5            # Minimum packets required for statistical analysis
MAX_IAT_STD_DEV = 0.05          # Max standard deviation (in seconds) for Inter-Arrival Time
MAX_SIZE_STD_DEV_RATIO = 0.10   # Max ratio of Std Dev to Mean Size (low means uniform size)
TTL_HOMOGENEITY_THRESHOLD = 0.9 # Minimum percentage of packets sharing the dominant TTL

# --- 2. Simulated Data Structures (Mimicking Scapy Output) ---

class SimulatedPacket:
    """Represents a simplified, Scapy-like network packet."""
    def __init__(self, ip_src, ip_dst, src_port, dst_port, protocol, size, timestamp, ttl):
        self.ip_src = ip_src
        self.ip_dst = ip_dst
        self.src_port = src_port
        self.dst_port = dst_port
        self.protocol = protocol
        self.size = size
        self.timestamp = timestamp
        self.ttl = ttl

    def get_flow_key(self):
        """Generates a canonical 5-tuple flow key."""
        # Ensure the key is sorted regardless of direction for bidirectional flow analysis
        if self.ip_src < self.ip_dst:
            return (self.ip_src, self.ip_dst, self.src_port, self.dst_port, self.protocol)
        else:
            return (self.ip_dst, self.ip_src, self.dst_port, self.src_port, self.protocol)

def generate_simulated_flows():
    """Generates a mix of legitimate and C2 beaconing traffic."""
    packets = []
    current_time = time.time()
    
    # Flow A: Legitimate HTTP/S Traffic (High variability in size and timing)
    # Simulates a user browsing, downloading, and idling.
    for i in range(20):
        size = random.randint(60, 1500) # Variable sizes
        delay = random.uniform(0.1, 5.0) # Variable IAT
        current_time += delay
        packets.append(SimulatedPacket(
            '192.168.1.100', '203.0.113.5', 54321, 443, 'TCP', size, current_time, 64
        ))

    # Flow B: Malicious C2 Beaconing (Low variability in size and timing)
    # Simulates a fixed-size, fixed-interval beacon (e.g., 500-byte payload every 10 seconds).
    beacon_time = current_time + 10
    for i in range(15):
        beacon_time += 10.005 # Highly consistent IAT
        # The size is slightly randomized to evade simple byte-count filters, but low variance
        size = random.randint(495, 505) 
        packets.append(SimulatedPacket(
            '192.168.1.200', '10.0.0.1', 60000, 8080, 'TCP', size, beacon_time, 128
        ))
        
    # Flow C: Another Legitimate Flow (UDP DNS or similar)
    for i in range(10):
        packets.append(SimulatedPacket(
            '192.168.1.50', '8.8.8.8', 50000 + i, 53, 'UDP', 75, current_time + random.uniform(1, 2), 64
        ))
        
    return packets

# --- 3. Flow Aggregation and Feature Engineering ---

def aggregate_flows(packets):
    """Groups packets into flows based on the 5-tuple key."""
    flows = defaultdict(list)
    for packet in packets:
        flows[packet.get_flow_key()].append(packet)
    
    # Sort packets within each flow by timestamp for IAT calculation
    for key in flows:
        flows[key].sort(key=lambda p: p.timestamp)
    return flows

def extract_flow_features(flow_packets):
    """
    Calculates statistical features for a single flow, focusing on non-payload metadata.
    """
    if len(flow_packets) < MIN_FLOW_PACKETS:
        return None

    timestamps = np.array([p.timestamp for p in flow_packets])
    sizes = np.array([p.size for p in flow_packets])
    ttls = [p.ttl for p in flow_packets]

    # Feature 1: Inter-Arrival Time (IAT) Statistics
    # Calculate the time difference between sequential packets.
    if len(timestamps) > 1:
        iat = np.diff(timestamps)
        iat_mean = np.mean(iat)
        iat_std_dev = np.std(iat)
    else:
        iat_mean, iat_std_dev = 0.0, 0.0

    # Feature 2: Packet Size Statistics
    size_mean = np.mean(sizes)
    size_std_dev = np.std(sizes)
    
    # Calculate the ratio of std dev to mean size for normalization
    size_std_dev_ratio = size_std_dev / size_mean if size_mean > 0 else 0

    # Feature 3: TTL Homogeneity (Detecting consistent OS/Tunneling)
    ttl_counts = defaultdict(int)
    for t in ttls:
        ttl_counts[t] += 1
    
    # Find the count of the most frequent TTL value
    if ttl_counts:
        dominant_ttl_count = max(ttl_counts.values())
        ttl_homogeneity = dominant_ttl_count / len(flow_packets)
    else:
        ttl_homogeneity = 0.0

    return {
        'packet_count': len(flow_packets),
        'iat_mean': iat_mean,
        'iat_std_dev': iat_std_dev,
        'size_mean': size_mean,
        'size_std_dev_ratio': size_std_dev_ratio,
        'ttl_homogeneity': ttl_homogeneity,
        'source': flow_packets[0].ip_src,
        'destination': flow_packets[0].ip_dst,
        'protocol': flow_packets[0].protocol
    }

# --- 4. Detection Engine ---

def classify_flow(flow_features):
    """Applies heuristic rules (simulating ML classification) to identify C2 beacons."""
    if flow_features is None:
        return "INSUFFICIENT_DATA"

    # Rule 1: Highly Regular Timing (Low IAT Standard Deviation)
    is_timing_uniform = flow_features['iat_std_dev'] < MAX_IAT_STD_DEV

    # Rule 2: Highly Uniform Packet Size (Low Size Standard Deviation Ratio)
    is_size_uniform = flow_features['size_std_dev_ratio'] < MAX_SIZE_STD_DEV_RATIO

    # Rule 3: High TTL Consistency (Often indicative of non-standard tunneling or fixed OS)
    is_ttl_consistent = flow_features['ttl_homogeneity'] >= TTL_HOMOGENEITY_THRESHOLD

    # Combined Malicious Signature: C2 beacons often exhibit uniformity in both time and size
    if is_timing_uniform and is_size_uniform:
        if is_ttl_consistent:
            return "MALICIOUS_C2_BEACON (High Confidence)"
        else:
            return "SUSPICIOUS_AUTOMATED_FLOW (Timing/Size Match)"
    
    return "BENIGN_NORMAL"

# --- 5. Main Execution ---

def main():
    print("--- Starting Network Flow Fingerprinting Analysis ---")
    
    # Step 1: Simulate Capture
    raw_packets = generate_simulated_flows()
    print(f"[INFO] Processed {len(raw_packets)} total simulated packets.")

    # Step 2: Aggregate
    flow_data = aggregate_flows(raw_packets)
    print(f"[INFO] Aggregated into {len(flow_data)} unique flows.")

    detection_results = []
    
    # Step 3 & 4: Feature Extraction and Classification
    for flow_key, packets in flow_data.items():
        features = extract_flow_features(packets)
        
        if features and features['packet_count'] >= MIN_FLOW_PACKETS:
            classification = classify_flow(features)
            
            detection_results.append({
                'key': flow_key,
                'features': features,
                'classification': classification
            })

    # Step 5: Reporting
    print("\n--- Analysis Report ---")
    for result in detection_results:
        f = result['features']
        status = result['classification']
        
        print(f"\nFlow: {f['source']}:{f['protocol']}/{f['destination']}")
        print(f"  Status: {status}")
        print(f"  Pkt Count: {f['packet_count']}")
        print(f"  Timing (Std Dev): {f['iat_std_dev']:.4f} s")
        print(f"  Size (Std Dev Ratio): {f['size_std_dev_ratio']:.4f}")
        print(f"  TTL Homogeneity: {f['ttl_homogeneity']:.2f}")

        if status.startswith("MALICIOUS"):
            print("  >>> ALERT: This flow exhibits classic fixed-interval beaconing characteristics!")

if __name__ == "__main__":
    main()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

from scapy.all import IP, TCP, Raw, Ether
import time
import random
import pprint

# --- 1. Feature Extraction Core Function ---

def extract_basic_flow_features(packet_list, flow_id="UNKNOWN"):
    """
    Calculates basic statistical features for a simulated network flow.
    Features include duration, packet count, total bytes, and average size.
    
    Args:
        packet_list (list): A list of Scapy packet objects representing the flow.
        flow_id (str): A unique identifier for the flow.
        
    Returns:
        dict: A feature vector (fingerprint) of the flow.
    """
    if not packet_list:
        # Return a baseline if the flow is empty
        return {"Flow_ID": flow_id, "Packets": 0, "Duration_s": 0.0,
                "Total_Bytes": 0, "Avg_Packet_Size": 0.0, "Initial_TTL": None}

    # Extract timestamps and packet lengths (wire size)
    timestamps = [p.time for p in packet_list]
    # Scapy's len() on a packet object returns the total size on the wire (including headers)
    packet_lengths = [len(p) for p in packet_list] 

    # Calculate Time-Based Features
    start_time = min(timestamps)
    end_time = max(timestamps)
    duration = end_time - start_time

    # Calculate Volume-Based Features
    total_packets = len(packet_list)
    total_bytes = sum(packet_lengths)
    avg_size = total_bytes / total_packets if total_packets > 0 else 0.0
    
    # Extract Non-Payload Metadata (Initial TTL)
    # We check if the IP layer exists before accessing the TTL attribute
    initial_ttl = packet_list[0][IP].ttl if IP in packet_list[0] else None

    # Compile the final feature vector
    features = {
        "Flow_ID": flow_id,
        "Packets": total_packets,
        "Duration_s": round(duration, 4),
        "Total_Bytes": total_bytes,
        "Avg_Packet_Size": round(avg_size, 2),
        "Initial_TTL": initial_ttl
    }
    return features

# --- 2. Flow Generation Utility ---

def generate_simulated_flow(num_packets, base_size, size_variance, duration_spread):
    """
    Creates a list of Scapy packets with simulated timestamps and varying sizes.
    """
    flow = []
    start_ts = time.time()
    
    for i in range(num_packets):
        # Simulate slight time delays based on the spread parameter
        ts = start_ts + (i * duration_spread) + random.uniform(0.001, 0.05)

        # Determine packet size based on base and variance
        payload_size = max(10, base_size + random.randint(-size_variance, size_variance))
        
        # Construct a full Ethernet/IP/TCP/Raw packet stack
        # TTL (Time-To-Live) is included here as a key fingerprinting feature
        packet = Ether() / IP(ttl=64) / TCP(sport=12345, dport=80) / Raw(load='X' * payload_size)
        
        # Manually set the timestamp attribute for accurate flow duration calculation
        packet.time = ts
        flow.append(packet)
    return flow

# --- 3. Execution and Comparison ---

print("--- Traffic Fingerprinting Simulation (Basic Flow Metrics) ---")

# Scenario A: Normal HTTP Flow (High packet count, short duration, small packets)
flow_a_packets = generate_simulated_flow(
    num_packets=20,
    base_size=150,
    size_variance=50,
    duration_spread=0.05 # Fast transfer rate
)
features_a = extract_basic_flow_features(flow_a_packets, flow_id="Flow_A_Normal_HTTP")

# Scenario B: Simulated C2 Beaconing Flow (Low packet count, long duration, varied sizes)
# We simulate a long pause between initial connection and the final beacon/exfil attempt.
flow_b_packets = generate_simulated_flow(
    num_packets=5,
    base_size=600,
    size_variance=500, # High variance often seen in C2/exfil
    duration_spread=0.01 # Initial packets are fast
)
# Manually inject a large delay to simulate a 10-second beacon interval
flow_b_packets[-1].time = flow_b_packets[0].time + 10.0 
features_b = extract_basic_flow_features(flow_b_packets, flow_id="Flow_B_C2_Beacon")

# 4. Output Results and Simple Heuristic Detection
print("\n[Flow A: Normal HTTP Traffic Features]")
pprint.pprint(features_a)

print("\n[Flow B: Simulated Malicious C2 Features]")
pprint.pprint(features_b)

print("\n--- Heuristic Detection Analysis ---")
# Feature Engineering: Calculate Inter-Packet Delay (IPD)
ipd_a = features_a['Duration_s'] / features_a['Packets'] if features_a['Packets'] > 1 else 0
ipd_b = features_b['Duration_s'] / features_b['Packets'] if features_b['Packets'] > 1 else 0

print(f"Flow A Average Inter-Packet Delay (IPD): {ipd_a:.4f}s")
print(f"Flow B Average Inter-Packet Delay (IPD): {ipd_b:.4f}s")

# Simple detection rule: If IPD is high (over 0.5s) AND total bytes are low, 
# it suggests low-and-slow communication (C2).
if ipd_b > 0.5 and features_b['Total_Bytes'] < 5000:
    print("\n[ALERT] Flow B characteristics (High IPD, Low Packet Count) strongly align with C2 beaconing patterns. This requires further deep packet inspection.")
else:
    print("\nFlow B is statistically ambiguous or appears benign based on simple flow metrics.")

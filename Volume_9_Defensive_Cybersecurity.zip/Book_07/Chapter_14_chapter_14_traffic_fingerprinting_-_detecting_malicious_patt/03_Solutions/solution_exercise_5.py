
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# Required structure for Robust Periodicity Feature
import numpy as np
from scipy.signal import correlate # Recommended library for correlation/convolution

def calculate_robust_periodicity_feature(iat_list):
    """
    Calculates a feature robust to jitter, using autocorrelation.
    
    :param iat_list: List of Inter-Arrival Times for a flow.
    :return: Magnitude of the strongest periodic correlation peak (0.0 to 1.0).
    """
    if len(iat_list) < 10:
        # Need sufficient data for meaningful correlation analysis
        return 0.0

    # Step 1: Normalize the IAT data (mean-subtraction and standardization)
    iat_array = np.array(iat_list)
    
    if np.std(iat_array) == 0:
        return 0.0 # Cannot normalize constant data
        
    # Standardize the data
    iat_normalized = (iat_array - np.mean(iat_array)) / np.std(iat_array)

    # Step 2: Calculate the autocorrelation function (ACF)
    # Use 'full' mode, then slice to get only the positive lags
    # The result is normalized by the number of points for unbiased estimation
    acf = correlate(iat_normalized, iat_normalized, mode='full')
    acf = acf[len(iat_normalized) - 1:] # Keep only positive lags and lag 0
    acf /= np.max(acf) # Normalize the ACF output so lag 0 is 1.0

    # Step 3: Identify the highest peak (excluding lag 0)
    # We look for correlation peaks after the initial lag (index 0)
    if len(acf) > 1:
        # Find the maximum correlation value after the first element (lag 0)
        max_periodic_peak_magnitude = np.max(acf[1:])
    else:
        max_periodic_peak_magnitude = 0.0
        
    return max_periodic_peak_magnitude

# Example Usage (Simulating jittered beaconing IATs):
if __name__ == "__main__":
    # Beaconing roughly every 1.0s, with +/- 0.1s jitter
    beacon_iats = [1.05, 0.95, 1.02, 0.98, 1.03, 0.97, 1.01, 0.99, 1.00] 
    # To get a meaningful ACF, we need many more data points.
    # Let's repeat the pattern to simulate periodicity:
    beacon_iats_long = beacon_iats * 10
    
    # Random, non-periodic IATs
    random_iats = [0.1, 5.2, 0.001, 10.5, 0.2, 3.4, 0.05, 1.2, 0.003] * 10 
    
    c2_periodicity = calculate_robust_periodicity_feature(beacon_iats_long)
    random_periodicity = calculate_robust_periodicity_feature(random_iats)
    
    print(f"C2 Flow ACF Peak Magnitude: {c2_periodicity:.4f}")
    print(f"Random Flow ACF Peak Magnitude: {random_periodicity:.4f}")

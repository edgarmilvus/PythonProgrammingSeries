
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import statistics
import numpy as np

class FlowAnalyzer:
    """Manages state and extracts basic features for a single 5-tuple flow."""
    def __init__(self, flow_id):
        self.flow_id = flow_id
        self.packet_lengths = []
        self.timestamps = []
        self.iat_values = []
        self.start_time = None
        self.end_time = None
        self.last_ts = None

    def process_packet(self, timestamp, length):
        """Simulates processing a single packet."""
        
        if self.start_time is None:
            self.start_time = timestamp
        self.end_time = timestamp
        self.packet_lengths.append(length)

        # Calculate IAT
        if self.last_ts is not None:
            iat = timestamp - self.last_ts
            self.iat_values.append(iat)
        
        self.last_ts = timestamp

    def generate_base_features(self):
        """Returns a dictionary of basic features (for completeness)."""
        duration = self.end_time - self.start_time if self.start_time and self.end_time else 0.0
        return {
            'duration': duration,
            'packet_count': len(self.packet_lengths)
        }

    def calculate_regularity_features(self):
        """
        Calculates the Coefficient of Variation (CV) for IATs.
        CV = StdDev(IAT) / Mean(IAT)
        """
        iats = self.iat_values
        
        # Requirement 2: Handle insufficient data (< 2 IATs means < 3 packets)
        if len(iats) < 2:
            return {'cv_iat': 999.0} # Insufficient data, return high value
        
        mean_iat = statistics.mean(iats)
        
        # Requirement 2: Handle zero mean IAT (e.g., simultaneous packet arrival)
        if mean_iat == 0.0:
            return {'cv_iat': 999.0}
            
        # Calculate standard deviation (using numpy for robustness)
        stddev_iat = np.std(iats, ddof=1) if len(iats) > 1 else 0.0
        
        # 1. New Feature Calculation: Coefficient of Variation
        cv_iat = stddev_iat / mean_iat
        
        return {'cv_iat': cv_iat}

def detect_c2_beaconing(flow_features, threshold=0.15):
    """Flags a flow if its timing is too regular (CV below threshold)."""
    # Requirement 3: Detection Logic
    cv = flow_features.get('cv_iat', 999.0)
    
    if cv < threshold:
        return True # Highly periodic (C2 beaconing suspected)
    else:
        return False

if __name__ == "__main__":
    # --- Simulated Beaconing Flow (High Regularity) ---
    flow_id_c2 = 'C2_Beacon'
    c2_flow = FlowAnalyzer(flow_id_c2)
    
    # Packets arriving almost exactly every 1.0 second
    c2_flow.process_packet(100.000, 100)
    c2_flow.process_packet(101.001, 100) # IAT ~ 1.001
    c2_flow.process_packet(102.000, 100) # IAT ~ 0.999
    c2_flow.process_packet(103.002, 100) # IAT ~ 1.002
    c2_flow.process_packet(104.000, 100) # IAT ~ 0.998
    
    c2_features = c2_flow.generate_base_features()
    c2_features.update(c2_flow.calculate_regularity_features())
    
    is_beacon = detect_c2_beaconing(c2_features, threshold=0.01)
    
    print(f"Flow: {flow_id_c2}")
    print(f"CV IAT: {c2_features['cv_iat']:.4f}")
    print(f"Detected as C2 Beacon? {is_beacon} (Threshold=0.01)\n") # Should be True if CV is low
    
    # --- Simulated Human Flow (Low Regularity) ---
    flow_id_human = 'Human_Web'
    human_flow = FlowAnalyzer(flow_id_human)
    
    # Irregular times
    human_flow.process_packet(200.0, 1000)
    human_flow.process_packet(200.005, 54)
    human_flow.process_packet(201.5, 1500)
    human_flow.process_packet(203.8, 54)
    
    human_features = human_flow.generate_base_features()
    human_features.update(human_flow.calculate_regularity_features())
    
    is_beacon_human = detect_c2_beaconing(human_features, threshold=0.01)
    
    print(f"Flow: {flow_id_human}")
    print(f"CV IAT: {human_features['cv_iat']:.4f}")
    print(f"Detected as C2 Beacon? {is_beacon_human}") # Should be False

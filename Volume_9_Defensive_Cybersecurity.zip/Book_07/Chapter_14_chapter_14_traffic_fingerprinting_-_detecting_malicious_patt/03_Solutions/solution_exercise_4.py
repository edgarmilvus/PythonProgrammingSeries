
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import statistics
from scapy.all import rdpcap, IP, TCP

# Use the dummy rdpcap function from Exercise 1 for simulation

def get_flow_id_tcp(pkt):
    """Generates a canonical 5-tuple ID for TCP only."""
    if IP in pkt and TCP in pkt:
        ip_src, ip_dst = pkt[IP].src, pkt[IP].dst
        sp, dp = pkt[TCP].sport, pkt[TCP].dport
        proto = 6 # TCP
        
        if (ip_src, sp) < (ip_dst, dp):
            return (ip_src, sp, ip_dst, dp, proto)
        else:
            return (ip_dst, dp, ip_src, sp, proto)
    return None

def infer_os_from_ttl(observed_ttl):
    """Maps observed TTL to an OS category based on common initial values."""
    if 60 <= observed_ttl <= 64:
        return 'Linux/macOS/Unix (TTL 64)'
    elif 120 <= observed_ttl <= 128:
        return 'Windows (TTL 128)'
    elif 250 <= observed_ttl <= 255:
        return 'Cisco/Legacy (TTL 255)'
    else:
        return f'Unknown/Proxied (Observed TTL {observed_ttl})'

def analyze_ttl_variance(pcap_file):
    packets = rdpcap(pcap_file)
    flow_ttls = {} # {flow_id: {'ttls': [], 'initial_ttl': None, 'inferred_os': None}}
    
    for pkt in packets:
        flow_id = get_flow_id_tcp(pkt)
        if flow_id is None or IP not in pkt:
            continue
            
        ttl = pkt[IP].ttl
        
        if flow_id not in flow_ttls:
            flow_ttls[flow_id] = {'ttls': [], 'initial_ttl': None, 'inferred_os': None}
        
        # Store TTL for variance calculation
        flow_ttls[flow_id]['ttls'].append(ttl)
        
        # 1. Initial TTL Extraction (TCP SYN)
        if TCP in pkt and pkt[TCP].flags & 0x02: # Check for SYN flag
            if flow_ttls[flow_id]['initial_ttl'] is None:
                flow_ttls[flow_id]['initial_ttl'] = ttl
                # 2. OS Mapping
                flow_ttls[flow_id]['inferred_os'] = infer_os_from_ttl(ttl)
        
    results = []
    print(f"{'Flow ID':<30}{'Inferred OS':<35}{'Initial TTL':<15}{'TTL StdDev':<15}{'Packet Count':<15}")
    print("-" * 110)
    
    for flow_id, data in flow_ttls.items():
        ttls = data['ttls']
        
        # 3. TTL Jitter Detection (StdDev calculation)
        ttl_stddev = statistics.stdev(ttls) if len(ttls) > 1 else 0.0
        
        src_ip, sp, dst_ip, dp, _ = flow_id
        flow_str = f"{src_ip}:{sp} <-> {dst_ip}:{dp}"
        
        results.append({
            'flow_id': flow_str,
            'inferred_os': data['inferred_os'],
            'initial_ttl': data['initial_ttl'],
            'ttl_stddev': ttl_stddev,
            'packet_count': len(ttls)
        })
        
        print(f"{flow_str[:30]:<30}{data['inferred_os']:<35}{str(data['initial_ttl']):<15}{ttl_stddev:<15.4f}{len(ttls):<15}")
        
    return results

if __name__ == "__main__":
    # Note: Dummy PCAP from Ex 1 does not contain TTL variance, 
    # but the logic is demonstrated here.
    analyze_ttl_variance('mixed_traffic.pcap')

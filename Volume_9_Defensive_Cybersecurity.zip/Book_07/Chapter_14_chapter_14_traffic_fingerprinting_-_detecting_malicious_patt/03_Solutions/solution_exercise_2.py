
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import statistics
import numpy as np
from scapy.all import rdpcap, IP, TCP, UDP

# Use the dummy rdpcap function from Exercise 1 for simulation

def get_flow_id(pkt):
    """Generates a canonical 5-tuple ID (A->B always matches B->A)."""
    if IP not in pkt:
        return None

    ip_src = pkt[IP].src
    ip_dst = pkt[IP].dst
    proto = pkt[IP].proto
    
    sp = 0
    dp = 0
    
    if TCP in pkt:
        sp = pkt[TCP].sport
        dp = pkt[TCP].dport
    elif UDP in pkt:
        sp = pkt[UDP].sport
        dp = pkt[UDP].dport
    else:
        # Ignore non-TCP/UDP protocols as required
        return None

    # Canonicalization: Sort the (IP, Port) pairs
    if (ip_src, sp) < (ip_dst, dp):
        flow_id = (ip_src, sp, ip_dst, dp, proto)
    else:
        flow_id = (ip_dst, dp, ip_src, sp, proto)
        
    return flow_id

def aggregate_and_summarize(pcap_file):
    packets = rdpcap(pcap_file)
    flows = {} # Key: flow_id, Value: {'lengths': [], 'timestamps': [], 'iat_values': [], 'last_ts': None}
    
    # Conceptual placement for Asynchronous Context Manager:
    # async with FlowRecordManager(database_connection) as db:
    #     # Processing logic here, ensuring safe, concurrent updates to flow records
    
    for pkt in packets:
        flow_id = get_flow_id(pkt)
        if flow_id is None:
            continue

        current_ts = float(pkt.time)
        pkt_len = len(pkt)
        
        # Initialize flow state if new
        if flow_id not in flows:
            flows[flow_id] = {
                'lengths': [],
                'timestamps': [],
                'iat_values': [],
                'last_ts': None,
                'start_time': current_ts
            }
        
        flow_state = flows[flow_id]
        
        # Calculate IAT
        iat = 0.0
        if flow_state['last_ts'] is not None:
            iat = current_ts - flow_state['last_ts']
            flow_state['iat_values'].append(iat)
        
        # Update flow state
        flow_state['lengths'].append(pkt_len)
        flow_state['timestamps'].append(current_ts)
        flow_state['last_ts'] = current_ts
        flow_state['end_time'] = current_ts

    # Calculate features for each flow
    final_features = []
    for flow_id, data in flows.items():
        lengths = data['lengths']
        iats = data['iat_values']
        
        # 1. Mean Packet Length
        mean_len = statistics.mean(lengths)
        # 2. Standard Deviation of Packet Length (use numpy for sample std dev)
        std_len = np.std(lengths, ddof=1) if len(lengths) > 1 else 0.0
        
        # IAT features require at least two packets (one IAT value)
        if iats:
            # 3. Minimum IAT
            min_iat = min(iats)
            # 4. Maximum IAT
            max_iat = max(iats)
        else:
            min_iat, max_iat = 0.0, 0.0
            
        # 5. Total Flow Duration
        duration = data['end_time'] - data['start_time'] if 'end_time' in data else 0.0
        
        # Format flow ID for readability
        src_ip, sp, dst_ip, dp, proto = flow_id
        proto_name = 'TCP' if proto == 6 else 'UDP' if proto == 17 else str(proto)
        flow_str = f"{src_ip}:{sp} <-> {dst_ip}:{dp} ({proto_name})"
        
        final_features.append({
            'flow_id': flow_str,
            'mean_len': round(mean_len, 2),
            'std_len': round(std_len, 4),
            'min_iat': round(min_iat, 6),
            'max_iat': round(max_iat, 6),
            'duration': round(duration, 4)
        })
        
    return final_features

if __name__ == "__main__":
    results = aggregate_and_summarize('mixed_traffic.pcap')
    for flow in results:
        print(flow)

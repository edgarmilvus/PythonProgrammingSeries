
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import time
from scapy.all import rdpcap, IP # Assuming rdpcap and IP layer are available

# --- Simulation Setup (Replace with actual file loading in a live environment) ---
def create_dummy_pcap():
    from scapy.all import Ether, TCP, UDP
    t_start = 1678886400.0
    packets = [
        # Packet 1 (Time 0.0)
        Ether()/IP(src="192.168.1.10", dst="8.8.8.8")/TCP(sport=50000, dport=80, len=66),
        # Packet 2 (Time 0.001)
        Ether()/IP(src="8.8.8.8", dst="192.168.1.10")/TCP(sport=80, dport=50000, len=54),
        # Packet 3 (Time 0.101)
        Ether()/IP(src="192.168.1.11", dst="4.4.4.4")/UDP(sport=12345, dport=53, len=100),
        # Packet 4 (Time 0.1015)
        Ether()/IP(src="192.168.1.10", dst="8.8.8.8")/TCP(sport=50000, dport=80, len=1500),
        # Packet 5 (Time 0.6015)
        Ether()/IP(src="8.8.8.8", dst="192.168.1.10")/TCP(sport=80, dport=50000, len=54),
    ]
    
    # Assign sequential timestamps
    current_time = t_start
    delays = [0, 0.001, 0.1, 0.0005, 0.5]
    for i, pkt in enumerate(packets):
        current_time += delays[i]
        pkt.time = current_time
        
    return packets

def rdpcap(filename):
    if filename == 'mixed_traffic.pcap':
        return create_dummy_pcap()
    return []
# --------------------------------------------------------------------------

def extract_and_analyze_timing(pcap_file):
    packets = rdpcap(pcap_file)
    
    results = []
    last_timestamp = None
    
    print(f"{'Idx':<4}{'Timestamp':<20}{'Length (B)':<12}{'Source IP':<16}{'Dest IP':<16}{'IAT (s)':<10}")
    print("-" * 78)
    
    for i, pkt in enumerate(packets):
        # 1. Feature Extraction
        current_timestamp = float(pkt.time)
        
        # Check for IP layer existence
        if IP not in pkt:
            continue
            
        pkt_len = len(pkt)
        src_ip = pkt[IP].src
        dst_ip = pkt[IP].dst
        
        # 2. IAT Calculation
        iat = 0.0
        if last_timestamp is not None:
            iat = current_timestamp - last_timestamp
        
        # Store result
        results.append({
            'index': i,
            'timestamp': current_timestamp,
            'length': pkt_len,
            'src_ip': src_ip,
            'dst_ip': dst_ip,
            'iat': iat
        })
        
        # Update for next iteration
        last_timestamp = current_timestamp
        
        # 5. Output Structure (Print first 10)
        if i < 10:
            iat_display = f"{iat:.6f}" if i > 0 else "N/A"
            print(f"{i:<4}{current_timestamp:<20.6f}{pkt_len:<12}{src_ip:<16}{dst_ip:<16}{iat_display:<10}")

    return results

if __name__ == "__main__":
    extract_and_analyze_timing('mixed_traffic.pcap')


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import sys
from typing import Dict, List, Tuple

# --- 1. Simulated Data Structures ---

# Simulating the contents of a requirements.txt file
SIMULATED_REQUIREMENTS = [
    "flask==2.3.3",  # Known to be safe in this context
    "requests==2.27.1", # Known to have a minor vulnerability (CVE-2022-24706)
    "jinja2==3.0.0", # Known to have a critical vulnerability (CVE-2024-34064)
    "sqlalchemy==2.0.29" # Safe
]

# Simulating a lookup table for known vulnerabilities (VDB)
# In a real scenario, this would be an API call to a tool like 'safety' or 'Snyk'.
VULNERABILITY_DB: Dict[str, List[Dict[str, str]]] = {
    "requests": [
        {"version": "2.27.1", "severity": "Minor", "cve": "CVE-2022-24706", "fix_version": "2.28.0"}
    ],
    "jinja2": [
        {"version": "3.0.0", "severity": "CRITICAL", "cve": "CVE-2024-34064", "fix_version": "3.1.0"}
    ],
    # Note: flask and sqlalchemy are intentionally clean in this mock data
}

# Define the policy threshold for failing the build
CRITICAL_THRESHOLD = "CRITICAL"

# --- 2. Core Security Gate Logic ---

def parse_package_version(req_line: str) -> Tuple[str, str] | None:
    """Parses a requirement line into (package_name, version)."""
    # Defensive check using the Principle of Least Astonishment (POLA)
    if "==" in req_line:
        parts = req_line.split("==")
        # Strip whitespace for robustness
        return parts[0].strip(), parts[1].strip()
    return None

def check_dependencies_gate(requirements: List[str], policy_threshold: str) -> Tuple[bool, List[str]]:
    """
    Simulates the execution of a dependency checker and enforces a security policy.
    Returns (is_passed, report_lines).
    """
    policy_violated: bool = False
    report: List[str] = ["--- Dependency Check Report ---"]

    for req in requirements:
        parsed = parse_package_version(req)
        if not parsed:
            report.append(f"[WARNING] Skipped unparsable requirement: {req}")
            continue

        package_name, version = parsed

        # Check if the package is in our simulated VDB
        if package_name in VULNERABILITY_DB:
            for vuln in VULNERABILITY_DB[package_name]:
                if vuln['version'] == version:

                    # Log the finding regardless of severity
                    report_line = f"[FAIL] {package_name} ({version}): {vuln['severity']} vulnerability found ({vuln['cve']}). Fix: {vuln['fix_version']}"
                    report.append(report_line)

                    # Check against the defined policy threshold
                    if vuln['severity'].upper() == policy_threshold.upper():
                        policy_violated = True
                        report.append(f"[POLICY VIOLATION] Critical vulnerability found. Build must fail.")

    report.append("--- End of Report ---")

    # If policy was violated, the gate fails (False). Otherwise, it passes (True).
    return not policy_violated, report

# --- 3. CI/CD Pipeline Simulation (Execution) ---

if __name__ == "__main__":
    print("Starting CI/CD Security Gate: Dependency Analysis")
    print(f"Policy enforced: Any vulnerability marked '{CRITICAL_THRESHOLD}' must fail the build.")
    print("-" * 50)

    # Execute the security gate
    gate_passed, detailed_report = check_dependencies_gate(
        requirements=SIMULATED_REQUIREMENTS,
        policy_threshold=CRITICAL_THRESHOLD
    )

    # Output the results for the pipeline logs
    for line in detailed_report:
        print(line)

    print("-" * 50)

    if gate_passed:
        print("[SUCCESS] Security Gate Passed. Dependencies are compliant with policy.")
        # Crucial for CI/CD: Exit code 0 signals success.
        sys.exit(0)
    else:
        print("[FAILURE] Security Gate Failed. Critical policy violation detected.")
        # Crucial for CI/CD: Exit code 1 signals failure and halts the pipeline.
        sys.exit(1)

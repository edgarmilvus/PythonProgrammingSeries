
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import subprocess
import json
import sys
from datetime import datetime
import os

# --- Configuration and Simulation ---
BANDIT_CONFIG = ["bandit", "-r", "simulated_code", "-f", "json"]
FAILURE_REPORT_FILE = "sast_failure_report.json"
TARGET_DIR = "simulated_code"

# Simulate source code and directory structure for Bandit to scan
if not os.path.exists(TARGET_DIR):
    os.makedirs(TARGET_DIR)
with open(os.path.join(TARGET_DIR, "vulnerable_app.py"), "w") as f:
    # This code simulates high and medium severity issues
    f.write("import os; os.system('ls')\n") # High severity (B605)
    f.write("def my_func(x): return x * 2\n")
    f.write("data = {'key': 'value'}\n")
    f.write("assert data is not None\n") # Medium severity (B101)

# --- DRY Principle: Artifact Generation Function ---
def generate_failure_artifact(policy_violation, findings_data):
    """Generates the structured JSON failure report."""
    report = {
        "timestamp": datetime.now().isoformat(),
        "policy_violation": policy_violation,
        "failing_findings": findings_data
    }
    with open(FAILURE_REPORT_FILE, 'w') as f:
        json.dump(report, f, indent=4)
    print(f"\n[FAILURE] Policy violated. Report saved to {FAILURE_REPORT_FILE}")

# --- Core Logic ---
def run_sast_policy_enforcer():
    print(f"Running SAST scan on {TARGET_DIR}...")
    try:
        # Execute Bandit and capture stdout/stderr
        result = subprocess.run(
            BANDIT_CONFIG,
            capture_output=True,
            text=True,
            check=False # Do not raise exception if Bandit returns non-zero (it often does on findings)
        )

        if result.returncode != 0 and "No files were scanned" in result.stderr:
            # Handle execution failure (e.g., tool not found, invalid path)
            raise RuntimeError(f"Bandit execution failed: {result.stderr}")

        sast_output = json.loads(result.stdout)
    
    except (FileNotFoundError, RuntimeError) as e:
        print(f"ERROR: SAST tool execution failed. Ensure Bandit is installed. Details: {e}")
        sys.exit(1) # Halt build on execution error
    except json.JSONDecodeError:
        print("ERROR: Failed to parse Bandit JSON output.")
        sys.exit(1) # Halt build on parsing error

    # 1. Calculate Severities and Prepare Findings List
    severity_counts = {"High": 0, "Medium": 0, "Low": 0}
    all_findings = []

    for result in sast_output.get("results", []):
        severity = result.get("issue_severity", "Low")
        severity_counts[severity] = severity_counts.get(severity, 0) + 1
        
        # Extract concise data for artifact generation (DRY data structure)
        all_findings.append({
            "filename": result.get("filename"),
            "line_number": result.get("line_number"),
            "severity": severity,
            "issue_text": result.get("issue_text")
        })

    high_count = severity_counts["High"]
    medium_count = severity_counts["Medium"]
    total_severe = high_count + medium_count

    print(f"Scan Summary: High={high_count}, Medium={medium_count}, Low={severity_counts['Low']}")

    # 2. Policy Gate Logic
    policy_violation = None
    if high_count > 0:
        policy_violation = "High Severity Threshold Breached (Count > 0)"
    elif total_severe > 2:
        policy_violation = "Combined High and Medium Severity Threshold Breached (Count > 2)"

    # 3. Artifact Generation and Exit Status
    if policy_violation:
        # Filter findings relevant to the policy failure (High and Medium)
        failing_findings = [
            f for f in all_findings 
            if f['severity'] in ['High', 'Medium']
        ]
        
        generate_failure_artifact(policy_violation, failing_findings)
        sys.exit(1) # Fail the CI/CD pipeline
    
    print("\n[SUCCESS] SAST policy gate passed. No critical findings detected.")
    sys.exit(0)

if __name__ == "__main__":
    run_sast_policy_enforcer()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.


#Save this content into a file named `iac_config.json`. This represents the Terraform plan in JSON format.
#
#{
#  "resource": {
#    "aws_s3_bucket": {
#      "data_store": {
#        "acl": "private",
#        "bucket": "critical-data-store-001",
#        "server_side_encryption_configuration": [
#          {
#            "rule": [
#              {
#                "apply_server_side_encryption_by_default": [
#                  {
#                    "sse_algorithm": "aws:kms" 
#                  }
#                ]
#              }
#            ]
#          }
#        ],
#        "public_access_block": [
#          {
#            "block_public_acls": true,
#            "block_public_policy": true,
#            "ignore_public_acls": true,
#            "restrict_public_buckets": true
#          }
#        ]
#      }
#    }
#  }
#}



import json
import sys
import os

def load_configuration(filepath):
    """Loads the Terraform JSON configuration."""
    if not os.path.exists(filepath):
        print(f"Error: File '{filepath}' not found.")
        sys.exit(1)
    
    with open(filepath, 'r') as f:
        try:
            return json.load(f)
        except json.JSONDecodeError as e:
            print(f"Error: Failed to parse JSON. {e}")
            sys.exit(1)

def validate_encryption(resource_name, config):
    """
    Rule 1: All buckets must enforce server-side encryption (SSE) using AWS KMS.
    """
    violations = []
    
    # Navigate the nested list structure common in Terraform JSON
    try:
        sse_config = config.get("server_side_encryption_configuration", [])
        if not sse_config:
            violations.append(f"[{resource_name}] Missing 'server_side_encryption_configuration' block.")
            return violations

        # Access the algorithm definition
        # Structure: list -> rule -> list -> apply_default -> list -> algo
        algorithm = sse_config[0]['rule'][0]['apply_server_side_encryption_by_default'][0]['sse_algorithm']
        
        if algorithm != "aws:kms":
            violations.append(f"[{resource_name}] Encryption Violation: 'sse_algorithm' is '{algorithm}'. Must be 'aws:kms'.")
            
    except (KeyError, IndexError, TypeError):
        violations.append(f"[{resource_name}] Encryption Configuration is malformed or incomplete.")
    
    return violations

def validate_public_access(resource_name, config):
    """
    Rule 2: Public access must be explicitly blocked (all 4 flags set to true).
    """
    violations = []
    required_flags = [
        "block_public_acls",
        "block_public_policy",
        "ignore_public_acls",
        "restrict_public_buckets"
    ]

    try:
        pab_config = config.get("public_access_block", [])
        if not pab_config:
            violations.append(f"[{resource_name}] Missing 'public_access_block'. Bucket might be exposed.")
            return violations
        
        # In Terraform JSON, this is usually a list containing one dict
        block_settings = pab_config[0]

        for flag in required_flags:
            if block_settings.get(flag) is not True:
                violations.append(f"[{resource_name}] Public Access Violation: '{flag}' is not set to true.")

    except (KeyError, IndexError, TypeError):
        violations.append(f"[{resource_name}] Public Access Block configuration is malformed.")

    return violations

def main():
    config_file = 'iac_config.json'
    data = load_configuration(config_file)
    
    # Locate S3 resources
    s3_resources = data.get("resource", {}).get("aws_s3_bucket", {})
    
    if not s3_resources:
        print("No aws_s3_bucket resources found in configuration.")
        sys.exit(0)

    all_violations = []

    # Iterate through all buckets defined in the resource block
    for resource_name, resource_config in s3_resources.items():
        print(f"Scanning resource: aws_s3_bucket.{resource_name}...")
        
        # Run Checks
        enc_errors = validate_encryption(resource_name, resource_config)
        pub_errors = validate_public_access(resource_name, resource_config)
        
        all_violations.extend(enc_errors)
        all_violations.extend(pub_errors)

    # Reporting and Gate
    if all_violations:
        print("\n" + "="*40)
        print(" SECURITY VALIDATION FAILED")
        print("="*40)
        for error in all_violations:
            print(f"❌ {error}")
        print("\nStopping deployment due to security violations.")
        sys.exit(1) # Non-zero exit code indicates failure
    else:
        print("\n" + "="*40)
        print("✅ SECURITY VALIDATION PASSED")
        print("="*40)
        sys.exit(0)

if __name__ == "__main__":
    main()

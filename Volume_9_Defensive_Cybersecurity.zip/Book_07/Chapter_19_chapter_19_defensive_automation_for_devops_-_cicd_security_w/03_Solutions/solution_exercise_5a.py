
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.


from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import enum

# Initialize Extensions
db = SQLAlchemy()

# 1. Enforcing strict values using Python Enum
class CheckStatus(enum.Enum):
    PASS = "PASS"
    FAIL = "FAIL"

class SecurityCheckLog(db.Model):
    __tablename__ = 'security_check_logs'

    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    policy_name = db.Column(db.String(100), nullable=False)
    target_id = db.Column(db.String(100), nullable=False) # e.g., Instance ID or Repo Name
    details = db.Column(db.Text, nullable=True)

    # REQ 1: Model Refactoring with Strict Constraints
    # We use SQLAlchemy's Enum type which maps to native ENUM types in Postgres/MySQL
    # or VARCHAR with constraints in SQLite.
    check_status = db.Column(
        db.Enum(CheckStatus), 
        nullable=False,
        info={'description': 'Must be strictly PASS or FAIL'}
    )

    def __repr__(self):
        return f"<SecurityLog {self.policy_name}: {self.check_status.value}>"

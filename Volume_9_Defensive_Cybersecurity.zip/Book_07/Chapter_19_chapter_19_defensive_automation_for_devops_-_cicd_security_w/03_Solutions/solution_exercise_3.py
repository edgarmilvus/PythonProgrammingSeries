
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.


import os
import sys
import math
import re

# --- Configuration ---
SCAN_EXTENSIONS = ('.py', '.json', '.yaml', '.env', '.txt')
MIN_LENGTH = 15
ENTROPY_THRESHOLD = 4.5
EXCLUSION_FILE = 'secret_exclusions.txt'

def calculate_shannon_entropy(data):
    """
    Calculates the Shannon entropy of a given string.
    Returns a float representing bits per character.
    """
    if not data:
        return 0
    
    entropy = 0
    length = len(data)
    
    # Count frequency of each character
    frequencies = {}
    for char in data:
        frequencies[char] = frequencies.get(char, 0) + 1
        
    # Calculate entropy
    for count in frequencies.values():
        p_x = count / length
        entropy += - p_x * math.log2(p_x)
        
    return entropy

def load_exclusions():
    """Loads a set of allowed strings to ignore."""
    exclusions = set()
    if os.path.exists(EXCLUSION_FILE):
        with open(EXCLUSION_FILE, 'r') as f:
            for line in f:
                # Store stripped lines to handle whitespace differences
                exclusions.add(line.strip())
    return exclusions

def scan_file(filepath, exclusions):
    """
    Scans a single file for high-entropy strings.
    Returns a list of violations found in the file.
    """
    violations = []
    
    # Regex to capture continuous strings of potential secret characters (Base64/Hex/Alphanumeric)
    # We look for strings without spaces, at least MIN_LENGTH long.
    # [a-zA-Z0-9\+\/=_\-] covers standard Base64, Hex, and common token characters.
    token_pattern = re.compile(r'[a-zA-Z0-9\+\/=_\-]{' + str(MIN_LENGTH) + r',}')

    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for line_num, line in enumerate(f, 1):
                clean_line = line.strip()
                
                # Find all potential candidates in the line
                candidates = token_pattern.findall(clean_line)
                
                for candidate in candidates:
                    # Skip if strictly in exclusion list
                    if candidate in exclusions:
                        continue
                        
                    entropy = calculate_shannon_entropy(candidate)
                    
                    if entropy > ENTROPY_THRESHOLD:
                        violations.append({
                            'line': line_num,
                            'token': candidate,
                            'entropy': round(entropy, 2)
                        })
                        
    except Exception as e:
        print(f"Warning: Could not read file {filepath}: {e}")

    return violations

def main():
    # 1. Define target directory (current directory by default)
    target_dir = sys.argv[1] if len(sys.argv) > 1 else "."
    
    print(f"[*] Starting Entropy Scan in: {os.path.abspath(target_dir)}")
    print(f"[*] Threshold: {ENTROPY_THRESHOLD} bits | Min Length: {MIN_LENGTH}")
    
    exclusions = load_exclusions()
    if exclusions:
        print(f"[*] Loaded {len(exclusions)} exclusions.")

    found_secrets = False

    # 2. Walk the directory recursively
    for root, dirs, files in os.walk(target_dir):
        # Skip hidden directories like .git
        dirs[:] = [d for d in dirs if not d.startswith('.')]
        
        for file in files:
            if file.endswith(SCAN_EXTENSIONS) and file != os.path.basename(__file__):
                filepath = os.path.join(root, file)
                
                # 3. Scan the file
                file_violations = scan_file(filepath, exclusions)
                
                if file_violations:
                    found_secrets = True
                    print(f"\n[!] POTENTIAL SECRET FOUND: {filepath}")
                    for v in file_violations:
                        # Mask part of the token for output safety
                        masked_token = v['token'][:4] + "..." + v['token'][-4:]
                        print(f"    Line {v['line']}: Entropy {v['entropy']} | Token: {masked_token}")

    # 4. Policy Gate
    if found_secrets:
        print("\n[FAIL] High entropy strings detected. Commit rejected.")
        sys.exit(1)
    else:
        print("\n[PASS] No high entropy strings found.")
        sys.exit(0)

if __name__ == "__main__":
    main()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import json
import subprocess
import sys
import os

# --- Configuration and Simulation ---
REQUIREMENTS_FILE = "requirements.txt"
EXCEPTIONS_FILE = "security_exceptions.json"

# Simulate requirements file
with open(REQUIREMENTS_FILE, "w") as f:
    f.write("requests==2.28.1\n") # Known vulnerable version
    f.write("jinja2==3.0.0\n")    # Known vulnerable version
    f.write("wheel==0.37.1\n")    # Non-vulnerable (or irrelevant)

# Simulate exception list: CVE-2023-1000 is accepted risk for requests
# CVE-2023-2000 is accepted risk for jinja2
security_exceptions = {
    "requests": ["CVE-2023-1000", "CVE-2023-1001"],
    "jinja2": ["CVE-2023-2000"],
    "ignored_package": ["CVE-9999-9999"]
}
with open(EXCEPTIONS_FILE, "w") as f:
    json.dump(security_exceptions, f, indent=4)

# Mock Safety Output (real output would be obtained via subprocess)
# Note: Safety output format varies; this simulates a common structure.
mock_safety_output = [
    {
        "package_name": "requests",
        "vulnerable_version": "2.28.1",
        "cve": "CVE-2023-1000", # Accepted Risk
        "severity": "High"
    },
    {
        "package_name": "requests",
        "vulnerable_version": "2.28.1",
        "cve": "CVE-2023-1002", # UNMITIGATED RISK
        "severity": "Critical"
    },
    {
        "package_name": "jinja2",
        "vulnerable_version": "3.0.0",
        "cve": "CVE-2023-2000", # Accepted Risk
        "severity": "Medium"
    }
]

# --- Core Logic ---
def load_exceptions(filepath):
    """Loads the centralized security exceptions file."""
    try:
        with open(filepath, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Error: Exception file not found at {filepath}")
        sys.exit(1)
    except json.JSONDecodeError:
        print(f"Error: Invalid JSON format in {filepath}")
        sys.exit(1)

def run_dependency_policy_engine():
    exceptions = load_exceptions(EXCEPTIONS_FILE)
    
    # In a real pipeline, replace this with subprocess call to 'safety check --json'
    # For demonstration, we use the mock output
    # safety_result = subprocess.run(["safety", "check", "-r", REQUIREMENTS_FILE, "--json"], ...)
    safety_findings = mock_safety_output 

    unmitigated_risks = []
    mitigated_risks = []

    print(f"Analyzing {len(safety_findings)} total findings against {len(exceptions)} exception entries...")

    for finding in safety_findings:
        package = finding['package_name']
        cve = finding['cve']
        
        is_exception = False
        
        # Check if the package exists in the exceptions list
        if package in exceptions:
            # Check if the specific CVE is listed for that package
            if cve in exceptions[package]:
                is_exception = True
        
        if is_exception:
            finding['status'] = "Accepted Risk (Mitigated)"
            mitigated_risks.append(finding)
        else:
            finding['status'] = "Critical Unmitigated Risk"
            unmitigated_risks.append(finding)

    # Policy Gate Check
    if len(unmitigated_risks) > 0:
        print("\n=======================================================")
        print(f"[FAILURE] Dependency Policy Violated: {len(unmitigated_risks)} UNMITIGATED risks found.")
        print("=======================================================")
        for risk in unmitigated_risks:
            print(f"  [CRITICAL] Package: {risk['package_name']} | CVE: {risk['cve']} | Severity: {risk['severity']}")
        sys.exit(1)
    else:
        print("\n=======================================================")
        print("[SUCCESS] Dependency Policy Gate Passed.")
        print(f"Total findings analyzed: {len(safety_findings)}")
        print(f"Vulnerabilities successfully mitigated by exceptions: {len(mitigated_risks)}")
        print("=======================================================")
        sys.exit(0)

if __name__ == "__main__":
    run_dependency_policy_engine()

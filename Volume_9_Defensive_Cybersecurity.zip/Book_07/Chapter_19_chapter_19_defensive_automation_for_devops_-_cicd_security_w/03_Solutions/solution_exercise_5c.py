
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.


# REQ 4: Demonstrate Refactored Usage

# --- Setup (Mocking the app context) ---
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
db.init_app(app)

with app.app_context():
    db.create_all()
    
    # Initialize the Service
    log_service = PolicyLogService(db.session)

    # --- SIMULATED POLICY EXECUTION LOGIC ---
    
    def check_s3_bucket_compliance(bucket_name):
        """Simulates a policy check logic"""
        print(f"Running policy check on {bucket_name}...")
        
        # Scenario A: A compliant bucket (Logic Simulation)
        if bucket_name == "secure-bucket":
            # LOGGING SUCCESS (PASS)
            # The logic relies ONLY on the service, keeping code DRY and clean.
            log_service.log_security_result(
                policy_name="S3_ENCRYPTION_ENABLED",
                target_id=bucket_name,
                status=CheckStatus.PASS,
                details="Bucket is encrypted with AES-256."
            )
            print(" -> Logged PASS result.")

        # Scenario B: A non-compliant bucket
        else:
            # LOGGING FAILURE (FAIL)
            log_service.log_security_result(
                policy_name="S3_ENCRYPTION_ENABLED",
                target_id=bucket_name,
                status=CheckStatus.FAIL,
                details="Bucket has no encryption enabled."
            )
            print(" -> Logged FAIL result.")

    # Run the simulation
    check_s3_bucket_compliance("secure-bucket")
    check_s3_bucket_compliance("insecure-bucket-99")

    # Verify Data in DB
    all_logs = SecurityCheckLog.query.all()
    print("\n--- DATABASE CONTENTS ---")
    for log in all_logs:
        print(f"ID: {log.id} | Policy: {log.policy_name} | Target: {log.target_id} | Status: {log.check_status.value}")

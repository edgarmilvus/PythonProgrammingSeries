
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.


# REQ 2: Service Layer Abstraction
class PolicyLogService:
    """
    Dedicated service for handling persistence of security policy checks.
    This acts as the interface between the Policy Engine and the Database.
    """
    
    def __init__(self, session):
        self.session = session

    # REQ 3: New Logging Method with Transaction Management
    def log_security_result(self, policy_name, target_id, status, details=None):
        """
        Logs a security check result (PASS or FAIL).
        Handles transaction commit and rollback internally.
        """
        
        # Ensure status is a valid Enum object
        if not isinstance(status, CheckStatus):
            # Attempt to convert string to Enum if necessary, or raise error
            try:
                status = CheckStatus(status)
            except ValueError:
                raise ValueError(f"Invalid status: {status}. Must be 'PASS' or 'FAIL'.")

        try:
            new_log = SecurityCheckLog(
                policy_name=policy_name,
                target_id=target_id,
                check_status=status,
                details=details
            )
            
            self.session.add(new_log)
            self.session.commit()
            return new_log.id
            
        except Exception as e:
            # Critical: Rollback the transaction to prevent database locking or corruption
            self.session.rollback()
            print(f"[CRITICAL ERROR] Failed to log security check: {str(e)}")
            # In a real scenario, you might want to raise a custom exception here
            return None


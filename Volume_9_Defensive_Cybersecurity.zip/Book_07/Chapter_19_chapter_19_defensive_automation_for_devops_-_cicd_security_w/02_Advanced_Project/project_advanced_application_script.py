
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import sys
import json
import subprocess
from typing import Dict, Any, List

# --- Configuration and Policy Definition ---

# Define the security policy thresholds for the CI/CD gate
# Any finding count exceeding these thresholds will fail the build.
SECURITY_POLICY = {
    "SAST": {
        "HIGH": 0,
        "MEDIUM": 1,  # Allows one medium finding temporarily
        "LOW": 5
    },
    "DEPENDENCY": {
        "CRITICAL": 0,
        "HIGH": 0
    },
    "SECRETS": {
        "HIGH_CONFIDENCE": 0
    }
}

# Simulated project path (in a real scenario, this would be the CI workspace)
TARGET_PATH = "./src/project_repo"
if not os.path.exists(TARGET_PATH):
    os.makedirs(TARGET_PATH, exist_ok=True)
    # Create a dummy file to scan
    with open(os.path.join(TARGET_PATH, "app.py"), "w") as f:
        f.write("import os\n# Simulated insecure code: os.system(user_input)")

# --- Simulated Tool Outputs (Mimicking real JSON results from tools like Bandit/Safety) ---

# Simulated SAST output (Bandit-like structure)
SAST_RESULT_SIM = {
    "results": [
        {"severity": "MEDIUM", "issue_text": "Insecure use of subprocess.", "confidence": "HIGH"},
        {"severity": "HIGH", "issue_text": "Hardcoded password found.", "confidence": "HIGH"},
        {"severity": "LOW", "issue_text": "Use of assert statement.", "confidence": "MEDIUM"}
    ],
    "metrics": {"severity_counts": {"HIGH": 1, "MEDIUM": 1, "LOW": 1}}
}

# Simulated Dependency Scan output (Safety/Pip-audit structure)
DEPENDENCY_RESULT_SIM = [
    {"package": "requests", "severity": "CRITICAL", "vulnerability": "CVE-2023-XXXX"},
    {"package": "jinja2", "severity": "MEDIUM", "vulnerability": "CVE-2022-YYYY"}
]

# Simulated Secret Scan output (Gitleaks/Trufflehog structure)
SECRET_RESULT_SIM = [
    {"file": "config.py", "line": 10, "description": "AWS Key detected", "confidence": "HIGH_CONFIDENCE"},
    {"file": "README.md", "line": 5, "description": "Generic token pattern", "confidence": "LOW_CONFIDENCE"}
]

# --- Core Functions: Tool Execution and Result Standardization ---

def execute_security_tool(tool_name: str, command_args: List[str]) -> str:
    """
    Simulates executing an external security tool via subprocess.
    In a real CI/CD environment, this would run the actual command.
    """
    print(f"\n[INFO] Executing {tool_name} scan...")
    
    # In a real implementation:
    # result = subprocess.run(command_args, capture_output=True, text=True, check=False)
    # return result.stdout
    
    # Simulation based on tool name:
    if tool_name == "SAST":
        return json.dumps(SAST_RESULT_SIM)
    elif tool_name == "DEPENDENCY":
        return json.dumps(DEPENDENCY_RESULT_SIM)
    elif tool_name == "SECRETS":
        return json.dumps(SECRET_RESULT_SIM)
    else:
        raise ValueError(f"Unknown tool: {tool_name}")

def parse_sast_results(raw_json: str) -> Dict[str, int]:
    """Parses SAST JSON output and standardizes severity counts."""
    data = json.loads(raw_json)
    counts = {"HIGH": 0, "MEDIUM": 0, "LOW": 0}
    
    # Use the metrics summary if available, otherwise count manually
    if "metrics" in data and "severity_counts" in data["metrics"]:
        for sev, count in data["metrics"]["severity_counts"].items():
            if sev in counts:
                counts[sev] = count
    return counts

def parse_dependency_results(raw_json: str) -> Dict[str, int]:
    """Parses Dependency Scan results and counts critical severities."""
    data = json.loads(raw_json)
    counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
    
    for finding in data:
        severity = finding.get("severity", "LOW").upper()
        if severity in counts:
            counts[severity] += 1
    return counts

def parse_secret_results(raw_json: str) -> Dict[str, int]:
    """Parses Secret Scan results, focusing on high-confidence findings."""
    data = json.loads(raw_json)
    high_confidence_count = 0
    for finding in data:
        if finding.get("confidence", "").upper() == "HIGH_CONFIDENCE":
            high_confidence_count += 1
    return {"HIGH_CONFIDENCE": high_confidence_count}

# --- Enforcement Logic ---

def enforce_policy(tool_name: str, results: Dict[str, int], policy: Dict[str, Any]) -> bool:
    """
    Compares aggregated scan results against the defined security policy.
    Returns True if the policy is passed, False otherwise.
    """
    policy_status = True
    print(f"\n--- {tool_name} Policy Check ---")
    
    for severity_key, count in results.items():
        threshold = policy.get(severity_key, -1) # Use -1 if severity isn't explicitly checked
        
        if threshold == -1:
            # Policy does not explicitly restrict this severity, so we ignore it
            continue 

        print(f"  {severity_key} Findings: {count}. Threshold: {threshold}.")
        
        if count > threshold:
            print(f"  [FAIL] Exceeded {severity_key} threshold ({count} > {threshold}).")
            policy_status = False
        else:
            print(f"  [PASS] Within {severity_key} threshold.")
            
    return policy_status

# --- Main Orchestrator ---

def main():
    """Orchestrates the entire security quality gate process."""
    overall_pass = True
    
    # 1. SAST Scan
    sast_raw = execute_security_tool("SAST", ["bandit", "-r", TARGET_PATH, "-f", "json"])
    sast_parsed = parse_sast_results(sast_raw)
    if not enforce_policy("SAST", sast_parsed, SECURITY_POLICY["SAST"]):
        overall_pass = False
        
    # 2. Dependency Scan
    # Assuming 'requirements.txt' is present in TARGET_PATH
    dep_raw = execute_security_tool("DEPENDENCY", ["safety", "check", "-r", os.path.join(TARGET_PATH, "requirements.txt"), "--json"])
    dep_parsed = parse_dependency_results(dep_raw)
    if not enforce_policy("DEPENDENCY", dep_parsed, SECURITY_POLICY["DEPENDENCY"]):
        overall_pass = False
        
    # 3. Secret Scan
    secret_raw = execute_security_tool("SECRETS", ["gitleaks", "scan", TARGET_PATH, "--report-format", "json"])
    secret_parsed = parse_secret_results(secret_raw)
    if not enforce_policy("SECRETS", secret_parsed, SECURITY_POLICY["SECRETS"]):
        overall_pass = False
        
    # Final Gate Decision
    print("\n======================================")
    if overall_pass:
        print("[SUCCESS] Security Quality Gate Passed. Proceeding to deployment stage.")
        sys.exit(0) # Standard exit code for success
    else:
        print("[FAILURE] Security Quality Gate Failed. Build must be halted.")
        sys.exit(1) # Non-zero exit code signals failure to the CI/CD runner

if __name__ == "__main__":
    main()

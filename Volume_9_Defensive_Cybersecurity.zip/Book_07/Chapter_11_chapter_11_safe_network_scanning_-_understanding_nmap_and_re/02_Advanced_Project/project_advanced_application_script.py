
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import asyncio
import socket
import argparse
import ipaddress
import sys

# --- Configuration Constants ---
# Common ports for administrative services that often expose banners
DEFAULT_PORTS = [21, 22, 23, 80, 443, 3389, 8080, 9000]
SCAN_TIMEOUT = 1.5  # Critical defensive setting: maximum time allowed for connection attempt
BANNER_READ_SIZE = 1024 # Max bytes to read for the service banner

# --- Core Asynchronous Functions ---

async def async_scan_port(host: str, port: int, results: list):
    """
    Asynchronously attempts to connect to a port and perform basic banner grabbing.
    Uses explicit socket handling integrated with the asyncio event loop.
    """
    sock = None
    banner = "N/A"
    status = "Closed/Filtered"

    try:
        # Get the current running event loop
        loop = asyncio.get_running_loop()
        
        # 1. Socket Setup: Create a standard TCP socket and set it to non-blocking mode.
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setblocking(False) 
        
        # 2. Connection Attempt: Use asyncio.wait_for to enforce the global timeout.
        # loop.sock_connect wraps the blocking connect() call into an awaitable future.
        await asyncio.wait_for(
            loop.sock_connect(sock, (host, port)),
            timeout=SCAN_TIMEOUT
        )
        
        status = "Open"
        
        # --- 3. Defensive Banner Grabbing ---
        try:
            # Set a short read timeout for the socket to prevent hanging if the service is silent
            sock.settimeout(0.5) 
            
            # Read data asynchronously using the event loop wrapper
            data = await loop.sock_recv(sock, BANNER_READ_SIZE)
            
            if data:
                # Defensively decode the banner, ignoring non-UTF-8 characters
                banner = data.decode('utf-8', errors='ignore').strip().replace('\n', ' | ')
            else:
                banner = "No initial banner received."

        except TimeoutError:
            banner = "Connection established, but read timed out (silent service)."
        except ConnectionResetError:
            banner = "Connection reset by peer."
        except Exception as e:
            banner = f"Banner Read Error: {type(e).__name__}"
            
    except asyncio.TimeoutError:
        status = "Timeout (Filtered/Slow)"
    except ConnectionRefusedError:
        status = "Refused (Closed)"
    except OSError as e:
        # Catch general network errors (e.g., host unreachable)
        status = f"Network Error ({e.strerror})"
    except Exception:
        status = "Unknown Error"
    finally:
        # 4. Resource Cleanup: Ensure the socket is closed regardless of success or failure
        if sock:
            sock.close()
        
        if status == "Open":
            # Report open ports immediately for real-time feedback
            results.append((host, port, status, banner))
            print(f"[+] {host}:{port:<5} | Status: {status:<15} | Banner: {banner[:70]}...")

# --- Main Execution and Orchestration ---

async def main_auditor(target_hosts: list, ports: list):
    """
    Orchestrates the asynchronous scanning process across multiple hosts and ports.
    """
    print(f"--- Starting Internal Compliance Auditor ({len(target_hosts)} hosts, {len(ports)} ports) ---")
    
    tasks = []
    scan_results = []
    
    # Generate tasks for every host/port combination
    for host in target_hosts:
        for port in ports:
            task = asyncio.create_task(async_scan_port(host, port, scan_results))
            tasks.append(task)

    # Wait for all tasks to complete gracefully
    await asyncio.gather(*tasks)
    
    print("\n--- Scan Summary ---")
    if scan_results:
        # Provide a final, clean output of only successful connections
        for host, port, status, banner in scan_results:
            print(f"HOST: {host:<15} | PORT: {port:<5} | SERVICE: {banner[:50]}")
    else:
        print("No open ports found on the specified list.")

# --- Utility and Argument Parsing ---

def parse_targets(target_spec: str) -> list:
    """
    Parses a single IP, a comma-separated list, or a CIDR range (e.g., 192.168.1.0/24).
    Uses the ipaddress module for robust network handling.
    """
    targets = []
    try:
        if '/' in target_spec:
            # Handle CIDR notation
            network = ipaddress.ip_network(target_spec, strict=False)
            # Use .hosts() to exclude the network and broadcast addresses
            targets.extend([str(ip) for ip in network.hosts()])
        elif ',' in target_spec:
            # Handle comma-separated list
            targets.extend([t.strip() for t in target_spec.split(',')])
        else:
            # Handle single IP
            targets.append(target_spec.strip())
            
        # Basic validation check
        [ipaddress.ip_address(t) for t in targets]
        return targets
        
    except ValueError as e:
        print(f"Error parsing target specification: {e}", file=sys.stderr)
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(
        description="Defensive Asynchronous Port Scanner and Banner Grabber for Internal Auditing."
    )
    parser.add_argument(
        "target",
        type=str,
        help="Target IP, comma-separated list, or CIDR range (e.g., 10.0.0.1/24)."
    )
    parser.add_argument(
        "-p", "--ports",
        type=str,
        default=','.join(map(str, DEFAULT_PORTS)),
        help=f"Comma-separated ports to scan (Default: {','.join(map(str, DEFAULT_PORTS))})."
    )
    
    args = parser.parse_args()
    
    target_hosts = parse_targets(args.target)
    
    try:
        ports = [int(p.strip()) for p in args.ports.split(',')]
    except ValueError:
        print("Error: Ports must be integers.", file=sys.stderr)
        sys.exit(1)

    # Start the asynchronous event loop
    try:
        asyncio.run(main_auditor(target_hosts, ports))
    except KeyboardInterrupt:
        print("\nScan interrupted by user.")
        sys.exit(0)

if __name__ == "__main__":
    main()

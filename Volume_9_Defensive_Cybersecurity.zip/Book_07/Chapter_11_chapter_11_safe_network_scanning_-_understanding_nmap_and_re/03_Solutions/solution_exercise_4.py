
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import json

# 1. Simulated Data Structure
NMAP_SCAN_DATA = [
    {
        "host": "192.168.1.10",
        "ports": [
            {"num": 22, "status": "open", "service": "ssh", "banner": "OpenSSH_7.9p1 Debian-10"},
            {"num": 80, "status": "open", "service": "http", "banner": "Apache/2.4.41"},
            {"num": 23, "status": "closed", "service": "telnet", "banner": None}
        ]
    },
    {
        "host": "192.168.1.15",
        "ports": [
            {"num": 22, "status": "open", "service": "ssh", "banner": "OpenSSH_8.4p1 Ubuntu-5"},
            {"num": 23, "status": "open", "service": "telnet", "banner": "Microsoft Telnetd"}
        ]
    },
    {
        "host": "192.168.1.20",
        "ports": [
            {"num": 22, "status": "open", "service": "ssh", "banner": "OpenSSH_6.6p1 RHEL"},
            {"num": 443, "status": "open", "service": "https", "banner": None}
        ]
    }
]

def check_version_compliance(banner: str) -> bool:
    """Checks if OpenSSH version is 8.0 or newer."""
    REQUIRED_MAJOR, REQUIRED_MINOR = 8, 0
    
    if not banner or "OpenSSH" not in banner:
        return True # Cannot verify, assume compliant for filtering purposes

    try:
        # Extract version (e.g., '7.9' from 'OpenSSH_7.9p1...')
        version_str = banner.split('OpenSSH_')[1].split(' ')[0].split('p')[0]
        major, minor = map(int, version_str.split('.'))
        
        return major > REQUIRED_MAJOR or (major == REQUIRED_MAJOR and minor >= REQUIRED_MINOR)
    except:
        return True # Parsing failed, assume compliant

def generate_compliance_report(scan_data: list) -> dict:
    """2. Filters scan data based on Telnet and SSH version policies."""
    report = {
        "unauthorized_telnet": [],
        "outdated_ssh": []
    }
    
    for host_entry in scan_data:
        host_ip = host_entry['host']
        
        for port_entry in host_entry.get('ports', []):
            port_num = port_entry['num']
            status = port_entry['status']
            
            # 3. Safe Data Access using dict.get() for banner
            banner = port_entry.get('banner')
            
            # Rule 1: Unauthorized Open Ports (Telnet - Port 23)
            if port_num == 23 and status == 'open':
                report["unauthorized_telnet"].append({
                    "host": host_ip,
                    "port": port_num,
                    "banner": banner
                })
                
            # Rule 2: Version Compliance (SSH - Port 22)
            if port_num == 22 and status == 'open':
                if not check_version_compliance(banner):
                    report["outdated_ssh"].append({
                        "host": host_ip,
                        "current_version": banner,
                        "required_version": "OpenSSH_8.0+"
                    })
                    
    return report

if __name__ == "__main__":
    compliance_report = generate_compliance_report(NMAP_SCAN_DATA)
    
    print("--- Compliance Audit Report ---")
    
    print("\n[A] Unauthorized Telnet (Port 23 Open):")
    if compliance_report["unauthorized_telnet"]:
        for violation in compliance_report["unauthorized_telnet"]:
            print(f"  VIOLATION: Host {violation['host']} has Telnet open.")
    else:
        print("  COMPLIANT: No unauthorized Telnet ports found.")
        
    print("\n[B] Outdated SSH Versions (Below OpenSSH 8.0):")
    if compliance_report["outdated_ssh"]:
        for violation in compliance_report["outdated_ssh"]:
            print(f"  VIOLATION: Host {violation['host']} running {violation['current_version']}. Requires {violation['required_version']}")
    else:
        print("  COMPLIANT: All hosts running compliant SSH versions.")

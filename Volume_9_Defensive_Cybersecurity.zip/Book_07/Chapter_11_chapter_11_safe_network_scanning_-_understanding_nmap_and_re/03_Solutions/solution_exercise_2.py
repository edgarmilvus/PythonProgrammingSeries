
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import socket
import time

# Configuration
TARGET_IP = "127.0.0.1" 
COMMON_PORTS = [22, 23, 80, 443, 8080]
TIMEOUT_SECONDS = 1.0
HTTP_PROBE = b"HEAD / HTTP/1.0\r\n\r\n"
BANNER_SIZE = 1024

def get_banner(sock: socket.socket, port: int) -> str | None:
    """1. Attempts to retrieve the service banner, probing HTTP if necessary."""
    try:
        # 2. Conditional HTTP Probe
        if port in [80, 443, 8080]:
            sock.sendall(HTTP_PROBE)
            
        # Receive data
        banner_data = sock.recv(BANNER_SIZE)
        
        if not banner_data:
            return None

        # 3. Data Sanitization and Decoding
        banner = banner_data.decode('utf-8', errors='ignore').strip()
        
        # Truncate to the first three lines for clean output
        return '\n'.join(banner.split('\n')[:3])
        
    except socket.error:
        return "Error reading banner"
    except Exception:
        return "Unknown decoding error"

def scan_port_with_banner(target_ip: str, port: int) -> dict:
    """Scans a single port and attempts banner grabbing."""
    status = "Filtered/Timeout"
    banner = None
    sock = None
    
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(TIMEOUT_SECONDS)
        
        result = sock.connect_ex((target_ip, port))
        
        if result == 0:
            status = "Open"
            banner = get_banner(sock, port) # Retrieve banner if open
        elif result == 111:
            status = "Closed"
            
    except socket.timeout:
        status = "Filtered/Timeout"
    except socket.error as e:
        if "refused" in str(e):
             status = "Closed"
        else:
            status = f"Network Error: {e}"
    finally:
        if sock:
            sock.close()
            
    # 4. Structured Output
    return {"port": port, "status": status, "banner": banner}

def run_banner_audit(target_ip: str, ports: list):
    """Runs the audit and generates the structured report."""
    audit_report = []
    print(f"--- Starting Banner Grabbing Audit on {target_ip} ---")
    
    for port in ports:
        result = scan_port_with_banner(target_ip, port)
        audit_report.append(result)
        
        banner_display = result['banner'].replace('\n', ' | ') if result['banner'] else 'N/A'
        print(f"Port {result['port']:<5} | Status: {result['status']:<20} | Banner: {banner_display[:70]}...")

    print("\n--- Summary Report (Demonstrating Safe Dictionary Access) ---")
    for entry in audit_report:
        # 5. Safe Dictionary Access using .get()
        banner_summary = entry.get('banner') 
        if entry['status'] == 'Open':
            print(f"Port: {entry['port']}, Banner Found: {bool(banner_summary)}")

    return audit_report

if __name__ == "__main__":
    run_banner_audit(TARGET_IP, COMMON_PORTS)

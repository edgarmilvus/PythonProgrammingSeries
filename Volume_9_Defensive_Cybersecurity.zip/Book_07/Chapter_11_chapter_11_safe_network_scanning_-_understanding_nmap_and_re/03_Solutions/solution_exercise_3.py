
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import asyncio
import socket
import time

# Configuration
TARGET_IP = "127.0.0.1"
PORTS_TO_SCAN = list(range(1, 101)) # Scan 100 ports concurrently
CONCURRENCY_LIMIT = 50 # 2. Max simultaneous connections
TIMEOUT_SECONDS = 0.8

# Define the Semaphore for concurrency control
semaphore = asyncio.Semaphore(CONCURRENCY_LIMIT)

class AsyncSocketContext:
    """
    3. Asynchronous Context Manager for socket resource cleanup.
    """
    def __init__(self, target_ip, port):
        self.target_ip = target_ip
        self.port = port
        self.sock = None

    async def __aenter__(self):
        # Create socket and set it to non-blocking mode
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setblocking(False)
        return self.sock

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        # Guaranteed cleanup: close the socket upon exit
        if self.sock:
            self.sock.close()

# 1. Asynchronous Architecture: Define coroutine
async def async_scan_port(target_ip: str, port: int) -> tuple:
    """
    Asynchronously attempts a TCP connection using semaphore and context manager.
    """
    status = "Filtered/Timeout"
    
    # 2. Acquire semaphore lock
    async with semaphore:
        try:
            # 3. Use the custom Async Context Manager for safe socket handling
            async with AsyncSocketContext(target_ip, port) as sock:
                
                # 5. Use asyncio.wait_for to enforce the strict, non-blocking timeout
                await asyncio.wait_for(
                    asyncio.get_event_loop().sock_connect(sock, (target_ip, port)),
                    timeout=TIMEOUT_SECONDS
                )
                status = "Open"
                
        except asyncio.TimeoutError:
            status = "Filtered/Timeout (Timeout)"
        except ConnectionRefusedError:
            status = "Closed (Refused)"
        except Exception as e:
            status = f"Filtered/Timeout (Error: {type(e).__name__})"
            
    return port, status

async def run_async_audit(target_ip: str, ports: list):
    """4. Main coroutine to manage task creation and execution."""
    print(f"--- Starting Asynchronous Audit on {target_ip} ({len(ports)} ports) ---")
    start_time = time.time()

    # Create a list of scanning tasks
    tasks = [async_scan_port(target_ip, port) for port in ports]

    # Execute all tasks concurrently and wait for results
    results = await asyncio.gather(*tasks)

    end_time = time.time()
    
    open_ports = [port for port, status in results if status == "Open"]
    
    print(f"\n--- Audit Summary ---")
    print(f"Total time: {end_time - start_time:.2f} seconds")
    print(f"Open Ports: {open_ports if open_ports else 'None Found'}")

if __name__ == "__main__":
    try:
        asyncio.run(run_async_audit(TARGET_IP, PORTS_TO_SCAN))
    except KeyboardInterrupt:
        print("\nScan interrupted.")

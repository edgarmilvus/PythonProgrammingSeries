
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import argparse
import socket
import time
import sys # Used for exiting on argument error

# Reusing core scanning logic from Exercise 1
TIMEOUT_SECONDS = 0.8

def scan_port(target_ip: str, port: int) -> str:
    """Synchronous TCP port scan function (simplified for integration)."""
    sock = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(TIMEOUT_SECONDS)
        result = sock.connect_ex((target_ip, port))
        
        if result == 0:
            return "Open"
        elif result == 111:
            return "Closed"
        else:
            return "Filtered/Timeout"
    except socket.error:
        return "Filtered/Timeout"
    finally:
        if sock:
            sock.close()

def parse_port_range(port_string: str) -> list[int]:
    """
    2. Converts a dynamic port string (e.g., "1-5,22,8080") into a sorted list of unique integers.
    """
    ports = set()
    
    try:
        parts = port_string.split(',')
        
        for part in parts:
            part = part.strip()
            if not part: continue

            if '-' in part:
                # Handle ranges (e.g., 1-5)
                start_str, end_str = part.split('-')
                start = int(start_str)
                end = int(end_str)
                
                # 3. Validation: Logical order
                if start > end:
                    raise ValueError(f"Invalid range order: start port {start} > end port {end}")
                
                for port in range(start, end + 1):
                    ports.add(port)
            else:
                # Handle single ports
                ports.add(int(part))

    except ValueError as e:
        # 3. Validation: Handle non-numeric or malformed input
        raise ValueError(f"Malformed port specification '{port_string}': {e}")

    # 3. Validation: Check port boundaries
    for port in ports:
        if not (1 <= port <= 65535):
            raise ValueError(f"Port {port} is outside the valid range (1-65535).")

    return sorted(list(ports))

def main():
    # 1. Argument Parsing setup
    parser = argparse.ArgumentParser(
        description="Defensive Sequential Port Scanner with Dynamic Range Input."
    )
    parser.add_argument(
        '--target', 
        required=True, 
        help='The internal target IP address to audit.'
    )
    parser.add_argument(
        '--ports', 
        required=True, 
        help='Dynamic port range specification (e.g., "21-25,80,443-445").'
    )
    
    args = parser.parse_args()
    target_ip = args.target
    port_string = args.ports
    
    try:
        # 4. Integration: Parse and validate the ports
        ports_to_scan = parse_port_range(port_string)
    except ValueError as e:
        print(f"Error parsing ports: {e}")
        sys.exit(1)

    print(f"--- Starting Audit on {target_ip} ({len(ports_to_scan)} ports) ---")
    start_time = time.time()
    open_ports = []
    
    # 4. Integration: Execute scan loop
    for port in ports_to_scan:
        status = scan_port(target_ip, port)
        if status == "Open":
            open_ports.append(port)
            print(f"Port {port:<5} | Status: {status} <--- OPEN")

    end_time = time.time()
    
    # 5. Output Summary
    print("\n--- Audit Summary ---")
    print(f"Target: {target_ip}")
    print(f"Total Ports Scanned: {len(ports_to_scan)}")
    print(f"Total Time: {end_time - start_time:.2f} seconds")
    print(f"Open Ports Found: {open_ports if open_ports else 'None'}")

if __name__ == "__main__":
    # Note: This requires execution via CLI, e.g., python scanner.py --target 127.0.0.1 --ports 22,80,100-105
    main()

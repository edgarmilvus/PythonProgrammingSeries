
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import socket
import time

# Configuration
TARGET_IP = "127.0.0.1"  # Use a local host for safe testing
COMMON_PORTS = [20, 21, 22, 23, 25, 80, 443, 3389, 8080]
TIMEOUT_SECONDS = 0.8  # Strict, short timeout

def scan_port(target_ip: str, port: int) -> str:
    """
    Attempts to establish a TCP connection to the specified port.
    Returns 'Open', 'Closed', or 'Filtered/Timeout'.
    """
    sock = None
    try:
        # 1. Create a new socket object (AF_INET for IPv4, SOCK_STREAM for TCP)
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        
        # 2. Set a strict, short timeout
        sock.settimeout(TIMEOUT_SECONDS)
        
        # 3. Attempt to connect using connect_ex (returns 0 on success, errno on failure)
        result = sock.connect_ex((target_ip, port))
        
        # 4. Check the result code
        if result == 0:
            return "Open"
        elif result == 111: # Connection refused (common Linux/Unix error for RST)
            return "Closed"
        else:
            # Other non-zero error codes often indicate filtering or timeout issues
            return "Filtered/Timeout"

    except socket.timeout:
        # Explicitly catch socket timeout
        return "Filtered/Timeout"
    except socket.error as e:
        # 5. Handle other generic network errors
        if "refused" in str(e):
             return "Closed"
        return f"Error: {e}"
    finally:
        # Ensure the socket is always closed for resource management
        if sock:
            sock.close()

def run_sequential_scan(target_ip: str, ports: list):
    """Iterates through the port list and prints the audit results."""
    print(f"--- Starting Sequential Audit on {target_ip} ---")
    start_time = time.time()
    
    for port in ports:
        status = scan_port(target_ip, port)
        print(f"Port {port:<5} | Status: {status}")
        
    end_time = time.time()
    print(f"--- Audit Completed in {end_time - start_time:.2f} seconds ---")

if __name__ == "__main__":
    run_sequential_scan(TARGET_IP, COMMON_PORTS)

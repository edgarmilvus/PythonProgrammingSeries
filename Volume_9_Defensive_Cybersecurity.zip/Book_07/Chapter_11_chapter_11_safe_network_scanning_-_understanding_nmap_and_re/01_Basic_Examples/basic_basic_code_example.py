
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import socket
import sys
from datetime import datetime
import time

# --- Configuration for Internal Auditing ---
# CRITICAL: For safety and testing purposes, we default to the local loopback address.
# In a controlled internal environment, this would be replaced by a specific target IP.
TARGET_IP = '127.0.0.1' 
PORT_RANGE = range(20, 26) # Common ports: FTP Data, FTP Control, SSH, Telnet, SMTP, DNS
TIMEOUT_SECONDS = 0.5 # A relatively aggressive but necessary timeout for efficiency

def check_port(target, port, timeout):
    """
    Attempts a non-blocking TCP connection to a specific port.
    Returns True if the connection succeeds (port is open).
    """
    # Initialize the socket variable outside the try block
    s = None
    try:
        # 1. Socket Creation: AF_INET (IPv4), SOCK_STREAM (TCP)
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        
        # 2. Set Timeout: Essential for preventing the scanner from hanging 
        # on filtered or non-responsive hosts.
        s.settimeout(timeout)

        # 3. Connection Attempt: Use connect_ex for non-raising error handling
        # connect_ex returns 0 on success, or an error code otherwise.
        result = s.connect_ex((target, port))

        # 4. Result Interpretation
        if result == 0:
            print(f"[+] Port {port:<5} | Status: OPEN | Service: {socket.getservbyport(port, 'tcp')}")
            return True
        # Note: Any non-zero result (e.g., 111 Connection Refused, 110 Timeout) 
        # implies the port is closed or filtered.
        return False

    except socket.gaierror:
        # Handles errors like unknown hostname
        print(f"[-] Hostname resolution error for {target}")
        sys.exit(1)
    except socket.error as e:
        # Handles broader network errors (e.g., network unreachable)
        print(f"[-] General socket error encountered: {e}")
        sys.exit(1)
    finally:
        # 5. Resource Management: Always close the socket file descriptor
        if s:
            s.close()

def defensive_scan(target, port_range, timeout):
    """
    Main function to orchestrate the sequential port scanning audit.
    """
    start_time = datetime.now()
    print("-" * 50)
    print(f"--- Starting Defensive TCP Audit on {target} ---")
    print(f"Scanning ports {min(port_range)} to {max(port_range)} (Timeout: {timeout}s)")
    print("-" * 50)

    open_ports_count = 0
    
    # Iterate through the defined range of ports
    for port in port_range:
        if check_port(target, port, timeout):
            open_ports_count += 1
            
    end_time = datetime.now()
    total_time = end_time - start_time

    print("-" * 50)
    print(f"Audit Complete.")
    print(f"Total open ports found: {open_ports_count}")
    print(f"Time elapsed: {total_time}")
    print("-" * 50)

if __name__ == "__main__":
    defensive_scan(TARGET_IP, PORT_RANGE, TIMEOUT_SECONDS)

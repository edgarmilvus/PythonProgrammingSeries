
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import sys
from collections import defaultdict
from typing import Dict, List, Tuple, Any

# Attempt to load Scapy and necessary layers.
# We use a try/except block to handle environments where Scapy might not be globally installed,
# ensuring a clean exit and adherence to best practices for external dependencies.
try:
    from scapy.all import rdpcap, IP, UDP, DNS, DNSQR, TCP, Ether, wrpcap, Packet
except ImportError:
    print("Error: Scapy is required for this script. Please install it (pip install scapy).")
    sys.exit(1)

# --- Configuration ---
# Use environment variables for configuration, adhering to Pythonic best practices
# for deployable scripts.
PCAP_PATH = os.environ.get("PCAP_FILE", "simulated_traffic.pcap")
SUSPICIOUS_DOMAINS = {
    "c2-beacon.evil",
    "exfil-data.io",
    "malware-update.net"
}

# --- Utility Functions ---

def simulate_pcap(filename: str) -> None:
    """Creates a simulated PCAP file for demonstration purposes."""
    print(f"[SETUP] Creating simulated PCAP: {filename}")
    
    # 1. Benign DNS Query
    p1 = Ether() / IP(src="192.168.1.10", dst="8.8.8.8") / UDP(sport=50000) / DNS(qd=DNSQR(qname="google.com"))
    
    # 2. Suspicious DNS Query (The indicator)
    # This IP (192.168.1.100) will be marked for tracking.
    p2 = Ether() / IP(src="192.168.1.100", dst="8.8.8.8") / UDP(sport=50001) / DNS(qd=DNSQR(qname="c2-beacon.evil"))
    
    # 3. Correlated TCP Session (The confirmation)
    # This traffic from the same source IP confirms the attempt to connect after resolving the domain.
    p3 = Ether() / IP(src="192.168.1.100", dst="52.1.1.1") / TCP(dport=443, flags="S")
    
    # 4. Unrelated Benign TCP Traffic
    p4 = Ether() / IP(src="192.168.1.200", dst="104.20.1.1") / TCP(dport=80, flags="A")

    wrpcap(filename, [p1, p2, p3, p4])


def analyze_pcap_for_correlation(pcap_file: str, threat_list: set) -> Dict[str, List[Tuple[str, str, str]]]:
    """
    Performs a two-pass analysis to correlate suspicious DNS lookups with subsequent network sessions.
    
    Returns: A dictionary mapping suspicious source IPs to a list of correlated sessions.
    """
    try:
        # Load the entire PCAP file into memory. For very large files, this should be
        # replaced with a generator-based reader (e.g., PcapReader), but for general analysis,
        # rdpcap is simpler and faster for moderate sizes.
        packets = rdpcap(pcap_file)
    except FileNotFoundError:
        print(f"\n[ERROR] PCAP file not found at: {pcap_file}")
        return {}

    # 1. First Pass: Identify and map suspicious DNS activity.
    # We use defaultdict to automatically initialize a list for a new source IP,
    # simplifying the correlation storage structure.
    suspicious_ip_map: Dict[str, List[str]] = defaultdict(list)
    
    print("\n--- Pass 1: Identifying Suspicious DNS Queries ---")
    
    # Use a generator expression for efficient filtering of packets containing the DNS layer
    dns_packets = (p for p in packets if p.haslayer(DNS) and p.haslayer(IP))
    
    for packet in dns_packets:
        # Ensure it is a query (DNSQR) and not a response (DNSRR)
        if packet.haslayer(DNSQR):
            # Extract the queried domain name
            qname_bytes = packet[DNSQR].qname
            qname_str = qname_bytes.decode('utf-8').rstrip('.')
            src_ip = packet[IP].src
            
            # Check if the queried domain is in our threat list
            if qname_str in threat_list:
                print(f"[DNS HIT] IP {src_ip} queried suspicious domain: {qname_str}")
                # Store the IP and the domain queried
                suspicious_ip_map[src_ip].append(qname_str)

    if not suspicious_ip_map:
        print("No suspicious DNS queries found. Analysis complete.")
        return {}

    # 2. Second Pass: Correlate suspicious IPs with subsequent TCP/HTTP sessions.
    # We use a separate structure to store the final correlated sessions.
    correlated_sessions: Dict[str, List[Tuple[str, str, str]]] = defaultdict(list)
    
    print("\n--- Pass 2: Correlating Network Sessions ---")
    
    # Iterate over all packets again to check for connection attempts
    for packet in packets:
        # We are only interested in IP traffic with a TCP layer (SYN flags are ideal for connection attempts)
        if packet.haslayer(IP) and packet.haslayer(TCP):
            src_ip = packet[IP].src
            dst_ip = packet[IP].dst
            protocol = "TCP"
            
            # Check if the source IP is one we flagged in the first pass
            if src_ip in suspicious_ip_map:
                # Check for connection initiation (SYN flag set)
                if 'S' in packet[TCP].flags:
                    session_info = (
                        f"{protocol} {src_ip}:{packet[TCP].sport} -> {dst_ip}:{packet[TCP].dport}",
                        "Connection Attempt (SYN)",
                        ", ".join(suspicious_ip_map[src_ip]) # List the domains that triggered the flag
                    )
                    # Store the correlation result
                    correlated_sessions[src_ip].append(session_info)
                    print(f"[CORRELATION] Found session from flagged IP {src_ip} to {dst_ip}")

    return correlated_sessions

# --- Main Execution Block ---

if __name__ == "__main__":
    # Ensure the required simulated file exists
    if not os.path.exists(PCAP_PATH):
        simulate_pcap(PCAP_PATH)
        
    print(f"Starting correlation analysis on PCAP: {PCAP_PATH}")
    print(f"Targeting {len(SUSPICIOUS_DOMAINS)} known malicious domains.")
    
    # Run the analysis function
    results = analyze_pcap_for_correlation(PCAP_PATH, SUSPICIOUS_DOMAINS)
    
    print("\n========================================================")
    print("           DEFENSIVE CORRELATION REPORT")
    print("========================================================")
    
    if results:
        for ip, sessions in results.items():
            print(f"\n[HOST] Suspicious Source IP: {ip}")
            for session_details, action, domains in sessions:
                print(f"  -> Triggered by DNS queries for: {domains}")
                print(f"  -> Session: {session_details}")
                print(f"  -> Status: {action}")
                
        print("\nAnalysis complete. Investigate flagged hosts immediately.")
    else:
        print("No suspicious correlated activity detected.")

    # Clean up the simulated file
    try:
        os.remove(PCAP_PATH)
        print(f"\n[CLEANUP] Removed simulated file: {PCAP_PATH}")
    except OSError:
        pass # Ignore if file was already deleted or permission denied

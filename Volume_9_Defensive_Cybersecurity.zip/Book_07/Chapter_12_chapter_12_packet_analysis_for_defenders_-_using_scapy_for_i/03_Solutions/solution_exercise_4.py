
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from abc import ABC, abstractmethod
from scapy.all import IP, TCP, rdpcap
import random # For mock data

# 1. Define the ABC
class BasePacketAnalyzer(ABC):
    @abstractmethod
    def analyze_packet(self, packet):
        """Analyzes a single packet for specific criteria."""
        pass

    @abstractmethod
    def generate_report(self):
        """Compiles and prints the findings."""
        pass

# Define flag values for clarity
TCP_FLAG_SYN = 0x02
TCP_FLAG_FIN = 0x01
TCP_FLAG_SYN_FIN = TCP_FLAG_SYN | TCP_FLAG_FIN # 0x03

# 2. Define the Subclass
class SuspiciousFlagsAnalyzer(BasePacketAnalyzer):
    def __init__(self):
        # Store findings (IPs are truncated to the first 10 for reporting)
        self.null_scans = []
        self.syn_fin_scans = []
        self.null_count = 0
        self.syn_fin_count = 0

    def analyze_packet(self, packet):
        """
        3. Flag Analysis Logic: Checks for Null (0) and SYN/FIN (0x03) flags.
        """
        if IP in packet and TCP in packet:
            
            # Access the TCP flags field directly (Scapy provides 'flags' attribute)
            tcp_flags_value = packet[TCP].flags
            
            # Check 1: SYN and FIN set (0x03)
            if tcp_flags_value == TCP_FLAG_SYN_FIN:
                self.syn_fin_count += 1
                if len(self.syn_fin_scans) < 10:
                    self.syn_fin_scans.append(packet[IP].src)
            
            # Check 2: No flags set (Null scan, Flags = 0)
            elif tcp_flags_value == 0:
                self.null_count += 1
                if len(self.null_scans) < 10:
                    self.null_scans.append(packet[IP].src)

    def generate_report(self):
        """4. Reporting: Outputs summary of suspicious flags found."""
        print("\n--- Suspicious TCP Flag Analysis Report ---")
        
        print(f"\n[Null Scan (Flags=0)] Total Count: {self.null_count}")
        if self.null_scans:
            print("  First 10 Source IPs:")
            for ip in self.null_scans:
                print(f"    - {ip}")
        else:
            print("  None detected.")

        print(f"\n[SYN/FIN Scan (Flags=3)] Total Count: {self.syn_fin_count}")
        if self.syn_fin_scans:
            print("  First 10 Source IPs:")
            for ip in self.syn_fin_scans:
                print(f"    - {ip}")
        else:
            print("  None detected.")

# Mock Execution Setup (assuming scan_traffic.pcap exists)
# analyzer = SuspiciousFlagsAnalyzer()
# # packets = rdpcap('scan_traffic.pcap') 
# # for pkt in packets:
# #     analyzer.analyze_packet(pkt)
# # analyzer.generate_report()

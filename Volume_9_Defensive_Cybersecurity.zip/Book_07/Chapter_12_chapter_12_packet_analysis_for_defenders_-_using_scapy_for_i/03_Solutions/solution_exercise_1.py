
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from scapy.all import IP, TCP, UDP, rdpcap
from collections import defaultdict
import os # Used for file existence check in a real scenario

PCAP_FILE = 'traffic_capture.pcap'

# Define the acceptable range for consistent beaconing (60s +/- 1s)
MIN_BEACON_INTERVAL = 59.0
MAX_BEACON_INTERVAL = 61.0
MIN_CONSECUTIVE_HITS = 5
MAX_PAYLOAD_SIZE = 50

def get_flow_key(packet):
    """Generates a hashable 5-tuple key for a flow."""
    if IP not in packet:
        return None
    
    ip_src = packet[IP].src
    ip_dst = packet[IP].dst
    proto = packet[IP].proto
    
    # Determine ports based on protocol
    if TCP in packet:
        sport = packet[TCP].sport
        dport = packet[TCP].dport
    elif UDP in packet:
        sport = packet[UDP].sport
        dport = packet[UDP].dport
    else:
        return None # Only interested in TCP/UDP
        
    # Standardize the key order (lexicographical sorting of IP:Port tuples)
    if (ip_src, sport) < (ip_dst, dport):
        return (ip_src, sport, ip_dst, dport, proto)
    else:
        return (ip_dst, dport, ip_src, sport, proto)

def analyze_beaconing(pcap_path):
    """Analyzes PCAP for consistent, small packet flows indicative of beaconing."""
    
    # 1. Efficient Loading (PcapReader is ideal for large files, but rdpcap is used here 
    # for simplicity in a non-streaming environment, assuming the user handles the file size.)
    try:
        packets = rdpcap(pcap_path)
    except FileNotFoundError:
        print(f"Error: PCAP file not found at {pcap_path}")
        return

    # 2. Initial Filter and Flow Grouping
    # Use a generator expression for initial filtering to keep memory use low before grouping
    filtered_packets_generator = (
        p for p in packets 
        if IP in p and (TCP in p or UDP in p) and len(p.payload) < MAX_PAYLOAD_SIZE
    )
    
    # Group packets by flow key
    flow_groups = defaultdict(list)
    for pkt in filtered_packets_generator:
        key = get_flow_key(pkt)
        if key:
            flow_groups[key].append(pkt)

    suspicious_flows = []

    # 3 & 4. Time Delta Calculation
    for flow_key, flow_packets in flow_groups.items():
        # Sort packets by timestamp (crucial for delta analysis)
        flow_packets.sort(key=lambda p: p.time)
        
        # Generator expression for calculating time deltas
        time_deltas = (
            flow_packets[i+1].time - flow_packets[i].time 
            for i in range(len(flow_packets) - 1)
        )
        
        consecutive_hits = 0
        
        # 5. Anomaly Identification
        for delta in time_deltas:
            if MIN_BEACON_INTERVAL <= delta <= MAX_BEACON_INTERVAL:
                consecutive_hits += 1
                if consecutive_hits >= MIN_CONSECUTIVE_HITS:
                    # Found a suspicious flow, record and break
                    src_ip, src_port, dst_ip, dst_port, proto = flow_key
                    # Determine the actual beacon direction based on the first packet
                    # Note: Flow key is normalized, but we report the direction of traffic
                    direction = f"{flow_packets[0][IP].src}:{flow_packets[0].sport} -> {flow_packets[0][IP].dst}:{flow_packets[0].dport}"
                    
                    suspicious_flows.append({
                        'flow': direction,
                        'interval': f"{delta:.2f}s",
                        'hits': consecutive_hits
                    })
                    break # Stop analyzing this flow once the threshold is met
            else:
                consecutive_hits = 0 # Reset counter if interval is broken

    # 6. Output
    print("\n--- Suspicious Beaconing Activity Report ---")
    if suspicious_flows:
        for flow in suspicious_flows:
            print(f"Flow: {flow['flow']}")
            print(f"  Consistent Interval: {flow['interval']}")
            print(f"  Consecutive Hits: {flow['hits']}")
            print("-" * 30)
    else:
        print("No flows exhibiting strict 60s periodic beaconing found.")

# Example execution (requires mock data setup or real PCAP)
# analyze_beaconing(PCAP_FILE)

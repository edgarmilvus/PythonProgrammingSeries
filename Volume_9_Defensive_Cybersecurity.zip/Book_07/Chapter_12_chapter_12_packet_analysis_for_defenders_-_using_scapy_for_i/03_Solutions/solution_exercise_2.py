
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from scapy.all import IP, TCP, Raw, rdpcap
from collections import defaultdict
import operator

PCAP_FILE = 'exfil_test.pcap'
SUSPECTED_INTERNAL_IPS = ['192.168.1.50', '192.168.1.101']

def calculate_outbound_volume(pcap_path, suspected_ips):
    """Calculates total outbound payload volume for suspected internal hosts."""
    
    # Structure: {Internal_IP: {(External_IP, External_Port): total_bytes}}
    outbound_volume = defaultdict(lambda: defaultdict(int))
    
    try:
        packets = rdpcap(pcap_path)
    except FileNotFoundError:
        print(f"Error: PCAP file not found at {pcap_path}")
        return {}

    for pkt in packets:
        # 1. Check for required layers (IP and TCP)
        if IP in pkt and TCP in pkt:
            src_ip = pkt[IP].src
            dst_ip = pkt[IP].dst
            
            # 2. Filter for suspected outbound flows
            if src_ip in suspected_ips:
                
                # 3. Payload Extraction and Summation
                # Check for the Raw layer (application payload)
                if Raw in pkt:
                    payload_len = len(pkt[Raw].load)
                    
                    # Store data indexed by the internal source IP and the external destination
                    destination_key = (dst_ip, pkt[TCP].dport)
                    outbound_volume[src_ip][destination_key] += payload_len

    # 4. Reporting Preparation
    report_data = []
    
    for src_ip, destinations in outbound_volume.items():
        total_bytes_for_host = sum(destinations.values())
        
        # Prepare detailed flow data for the report
        flow_details = []
        for (dst_ip, dst_port), byte_count in destinations.items():
            flow_details.append({
                'destination': f"{dst_ip}:{dst_port}",
                'bytes': byte_count
            })
            
        report_data.append({
            'source_ip': src_ip,
            'total_outbound_bytes': total_bytes_for_host,
            'flows': flow_details
        })

    # 5. Reporting (Ranked list)
    # Sort descending by total_outbound_bytes
    report_data.sort(key=operator.itemgetter('total_outbound_bytes'), reverse=True)

    print("\n--- Data Exfiltration Flow Quantification Report ---")
    if not report_data:
        print("No outbound TCP traffic found for suspected hosts.")
        return

    for item in report_data:
        total_mb = item['total_outbound_bytes'] / (1024 * 1024)
        print(f"\nHost: {item['source_ip']} | Total Outbound Data: {item['total_outbound_bytes']} bytes ({total_mb:.2f} MB)")
        print("  Detailed Flows:")
        for flow in item['flows']:
            flow_mb = flow['bytes'] / (1024 * 1024)
            print(f"    -> {flow['destination']}: {flow['bytes']} bytes ({flow_mb:.2f} MB)")
            
    return outbound_volume

# Example execution (requires mock data setup or real PCAP)
# calculate_outbound_volume(PCAP_FILE, SUSPECTED_INTERNAL_IPS)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from scapy.all import IP, TCP, Raw, rdpcap
import re

PCAP_FILE = 'web_traffic.pcap'
HTTP_PORTS = {80, 8080}
HTTP_METHODS = [b'GET', b'POST', b'HEAD', b'PUT', b'DELETE', b'OPTIONS']

def extract_unique_hostnames(pcap_path):
    """Filters for HTTP requests and extracts unique Host headers."""
    
    try:
        packets = rdpcap(pcap_path)
    except FileNotFoundError:
        print(f"Error: PCAP file not found at {pcap_path}")
        return set()

    # 1. Protocol Filtering and Request Identification (using a generator)
    http_requests_generator = (
        p[Raw].load.decode('latin-1', errors='ignore') # Decode raw payload for string processing
        for p in packets
        if IP in p and TCP in p and Raw in p 
        and (p[TCP].dport in HTTP_PORTS or p[TCP].sport in HTTP_PORTS)
        # 2. Check if it's an HTTP request (starts with a known method)
        and any(p[Raw].load.startswith(method) for method in HTTP_METHODS)
    )

    # 4. Uniqueness storage (Python set)
    unique_hosts = set()
    
    # Regex to find 'Host:' header, handling case variations and extracting the value
    # The pattern looks for 'Host:', followed by optional whitespace, captures the hostname 
    # (non-newline characters), and stops at the next newline/CRLF.
    HOST_REGEX = re.compile(r'^[Hh][Oo][Ss][Tt]:\s*(.+?)\r?\n', re.MULTILINE)

    for request_data in http_requests_generator:
        # 3. Header Extraction
        match = HOST_REGEX.search(request_data)
        
        if match:
            # Extract and clean the hostname (strip leading/trailing whitespace)
            hostname = match.group(1).strip()
            if hostname:
                unique_hosts.add(hostname.lower()) # Normalize to lowercase for true uniqueness

    # 5. Output
    print("\n--- Unique HTTP Hostname Report ---")
    print(f"Total Unique Hostnames Found: {len(unique_hosts)}")
    
    if unique_hosts:
        print("\nAlphabetical List:")
        # Sort the set for clean output
        for host in sorted(list(unique_hosts)):
            print(f"- {host}")
            
    return unique_hosts

# Example execution (requires mock data setup or real PCAP)
# extract_unique_hostnames(PCAP_FILE)

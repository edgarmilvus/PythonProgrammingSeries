
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

from scapy.all import IP, TCP, UDP, Ether, wrpcap, rdpcap
import os
import tempfile

# --- 1. Setup: Create a temporary PCAP file for demonstration ---
def create_dummy_pcap(filename="sample_traffic.pcap"):
    """
    Generates a small PCAP file containing basic HTTP and DNS traffic.
    This ensures the code is self-contained and reproducible.
    """
    
    # Packet 1: Simple HTTP SYN request (TCP)
    # L2: Ethernet | L3: IP | L4: TCP
    p1 = Ether(src="00:11:22:33:44:55", dst="AA:BB:CC:DD:EE:FF") / \
         IP(src="192.168.1.100", dst="172.217.10.1") / \
         TCP(sport=54321, dport=80, flags='S')
    
    # Packet 2: DNS Query (UDP)
    # L2: Ethernet | L3: IP | L4: UDP
    p2 = Ether() / \
         IP(src="192.168.1.1", dst="8.8.8.8") / \
         UDP(sport=53000, dport=53)
    
    # Packet 3: Another HTTP packet (A simple ACK)
    p3 = Ether() / \
         IP(src="172.217.10.1", dst="192.168.1.100") / \
         TCP(sport=80, dport=54321, flags='A')
    
    # Write the list of packets to the file
    wrpcap(filename, [p1, p2, p3])
    print(f"[SETUP] Created dummy PCAP: {filename}")
    return filename

# --- Main Defensive Analysis Script ---

# 2. Preparation: Generate the file path
pcap_file = create_dummy_pcap()

try:
    # 3. Loading the PCAP file into a Scapy PacketList object
    # rdpcap reads the entire file into memory as a list of Packet objects
    traffic_data = rdpcap(pcap_file)
    
    # 4. Basic Inspection and Statistics
    total_packets = len(traffic_data)
    print("\n--- Defensive Analysis Report ---")
    print(f"Total packets loaded: {total_packets}")
    
    # 5. Accessing and Summarizing the First Packet (Index 0)
    first_packet = traffic_data[0]
    print(f"\n[Packet 1 Summary]: {first_packet.summary()}")
    
    # 6. Extracting Layer Data Safely (IP Layer)
    # getlayer(Layer) is the defensive way to check for a layer's existence
    ip_layer = first_packet.getlayer(IP)
    
    if ip_layer:
        # Field access: Using dict-like .get() ensures safety and readability (POLA)
        source_ip = ip_layer.get('src')
        dest_ip = ip_layer.get('dst')
        
        print(f"  Source IP (L3): {source_ip}")
        print(f"  Destination IP (L3): {dest_ip}")
        
        # 7. Deep Dive: Checking for Transport Layer (TCP)
        tcp_layer = first_packet.getlayer(TCP)
        
        if tcp_layer:
            # Accessing flags and ports
            flags = str(tcp_layer.flags)
            print(f"  Protocol: TCP (Flags: {flags})")
            print(f"  Source Port: {tcp_layer.sport}")
            print(f"  Destination Port: {tcp_layer.dport}")
            
            # Defensive check: Simple port analysis
            if tcp_layer.dport == 80:
                print("  [ALERT] Potential HTTP traffic detected on standard port 80.")
        else:
            print("  Transport Layer: Not TCP.")
            
    # 8. Demonstrating Extended Slicing for Batch Access
    # We retrieve the second packet (index 1) using the [start:stop] syntax.
    # This technique is crucial when dealing with very large PCAPs to load chunks.
    batch_slice = traffic_data[1:3]
    print(f"\n[Batch Slice Example]: Retrieved {len(batch_slice)} packets.")
    print(f"  First packet in slice (Packet 2 overall): {batch_slice[0].summary()}")
    
finally:
    # 9. Cleanup: Remove the temporary file
    if os.path.exists(pcap_file):
        os.remove(pcap_file)
        print(f"\n[CLEANUP] Removed dummy PCAP: {pcap_file}")

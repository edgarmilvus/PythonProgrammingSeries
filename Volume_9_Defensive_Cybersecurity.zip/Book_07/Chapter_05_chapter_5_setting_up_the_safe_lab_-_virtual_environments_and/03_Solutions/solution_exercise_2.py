
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# app_config.py
import os

def load_config():
    """
    Safely loads configuration from environment variables using .get()
    to prevent KeyErrors.
    """
    CONFIG = {
        # Safe access with a critical default value
        'SECRET_KEY': os.environ.get('SECRET_KEY', "INSECURE_DEFAULT_KEY"),
        
        # Safe access with a standard default value
        'LOG_LEVEL': os.environ.get('LOG_LEVEL', "INFO")
    }
    return CONFIG

# test_app_config.py
import unittest
from unittest.mock import patch
# Assuming load_config is imported or defined in the same scope for this example
# from .app_config import load_config 

def load_config():
    # Duplicating the function definition here for self-contained execution
    CONFIG = {
        'SECRET_KEY': os.environ.get('SECRET_KEY', "INSECURE_DEFAULT_KEY"),
        'LOG_LEVEL': os.environ.get('LOG_LEVEL', "INFO")
    }
    return CONFIG


class TestConfigLoading(unittest.TestCase):
    
    @patch.dict(os.environ, {}, clear=True)
    def test_missing_secret_key_handled(self):
        """
        Tests that if SECRET_KEY is missing from os.environ, the default is used.
        The @patch.dict decorator temporarily clears os.environ for the test.
        """
        print("\n--- Running Monkey Patch Test ---")
        
        # 1. Verify environment state (should be empty due to patch)
        self.assertNotIn('SECRET_KEY', os.environ)
        
        # 2. Call the safe function
        config = load_config()
        
        # 3. Assert that the default value was loaded successfully
        expected_key = "INSECURE_DEFAULT_KEY"
        self.assertEqual(config['SECRET_KEY'], expected_key)
        self.assertEqual(config['LOG_LEVEL'], "INFO")
        
        print(f"Test Config: {config}")

# Run the test (if this were a standalone script)
# unittest.main(argv=['first-arg-is-ignored'], exit=False)

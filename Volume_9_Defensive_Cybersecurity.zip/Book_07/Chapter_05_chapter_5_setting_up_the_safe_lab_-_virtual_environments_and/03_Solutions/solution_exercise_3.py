
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Unsafe Configuration Parser (Vulnerabilities identified)
def extract_settings_unsafe(raw_config):
    """
    Parses raw_config dictionary, prone to KeyError crashes.
    """
    settings = {}
    
    # --- UNSAFE ACCESS POINTS ---
    # 1. raw_config['network'] or raw_config['network']['buffer_size'] could fail
    settings['buffer_size'] = raw_config['network']['buffer_size'] 
    # 2. raw_config['network']['timeout'] could fail
    settings['timeout_seconds'] = raw_config['network']['timeout']
    # 3. raw_config['system'] or raw_config['system']['logging'] could fail
    settings['logging_enabled'] = raw_config['system']['logging']
    # ---------------------------
    
    return settings

# Refactored Safe Configuration Parser
def extract_settings(raw_config):
    """
    Safely parses raw_config dictionary using dict.get() and defensive defaults.
    """
    
    # Safely retrieve nested dictionaries first
    network_settings = raw_config.get('network', {})
    system_settings = raw_config.get('system', {})

    settings = {}
    
    # Extract keys using defaults if missing
    # Default: 4096 (integer)
    settings['buffer_size'] = network_settings.get('buffer_size', 4096) 
    
    # Default: 10.0 (float)
    settings['timeout_seconds'] = network_settings.get('timeout', 10.0)
    
    # Default: False (boolean)
    settings['logging_enabled'] = system_settings.get('logging', False)
    
    return settings

# Demonstration of Robustness

# Case A: Input containing all keys
full_input = {
    "network": {
        "buffer_size": 8192,
        "timeout": 25.5
    },
    "system": {
        "logging": True
    }
}

# Case B: Malformed input (missing buffer_size and logging)
malformed_input = {
    "network": {
        "timeout": 5.0 
    },
    "system": {} 
}

print("--- Case A: Full Input Test ---")
print(extract_settings(full_input))

print("\n--- Case B: Malformed Input Test ---")
print(extract_settings(malformed_input))

print("\n--- Case C: Empty Dictionary Test ---")
print(extract_settings({}))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import subprocess
import tempfile
import json
import textwrap
from typing import Dict, Any

# --- Configuration Constants ---
DOCKER_IMAGE_NAME = "cybersec-analyzer-temp"
ANALYSIS_SCRIPT_NAME = "isolated_check.py"
UNTRUSTED_CONFIG_NAME = "untrusted_config.json"
OUTPUT_FILE_NAME = "analysis_results.json" # Used conceptually, output is captured via stdout

def generate_dockerfile(temp_dir: str) -> None:
    """Creates a minimal Dockerfile for the isolated analysis environment."""
    dockerfile_content = textwrap.dedent(f"""
        # Use a slim base image for security and speed
        FROM python:3.10-slim-buster
        
        # Set the working directory
        WORKDIR /app
        
        # Copy the necessary files from the build context (the temp directory)
        COPY {ANALYSIS_SCRIPT_NAME} .
        COPY {UNTRUSTED_CONFIG_NAME} .
        
        # Define the entrypoint to run the analysis script
        # This executes the isolated analysis script immediately upon container startup
        CMD ["python", "./{ANALYSIS_SCRIPT_NAME}"]
    """)
    dockerfile_path = os.path.join(temp_dir, "Dockerfile")
    with open(dockerfile_path, "w") as f:
        f.write(dockerfile_content)
    print(f"[HOST] Generated Dockerfile at {dockerfile_path}")

def generate_analysis_script(temp_dir: str) -> None:
    """Creates the Python script that executes *inside* the container."""
    # This script simulates a security check against the untrusted config
    script_content = textwrap.dedent(f"""
        import json
        import os
        
        CONFIG_PATH = "./{UNTRUSTED_CONFIG_NAME}"
        
        def safe_analysis():
            """Performs the security analysis in a sandboxed environment."""
            results = {{
                "status": "SAFE",
                "findings": [],
                "config_data": None
            }}
            
            try:
                # 1. Load the untrusted configuration
                with open(CONFIG_PATH, 'r') as f:
                    config = json.load(f)
                results["config_data"] = config
                
                # 2. Sandboxed Check 1: Look for dangerous network bindings (0.0.0.0)
                # Using dict.get() for safe key access, preventing KeyError
                if config.get("network_binding") == "0.0.0.0":
                    results["status"] = "WARNING"
                    results["findings"].append("Exposed network binding (0.0.0.0) found.")
                    
                # 3. Sandboxed Check 2: Look for suspicious command keys
                if "exec_command" in config:
                    # NOTE: The dangerous command is present but CANNOT execute on the host
                    results["status"] = "DANGER"
                    results["findings"].append(f"Suspicious execution command detected: {{config['exec_command']}}")
                    
            except json.JSONDecodeError:
                results["status"] = "ERROR"
                results["findings"].append("Configuration file is malformed JSON.")
            except Exception as e:
                # Catching general exceptions that might be triggered by malformed input
                results["status"] = "CRITICAL_ERROR"
                results["findings"].append(f"Unexpected error during analysis: {{e}}")
                
            # Output the structured JSON result to stdout for the host process to capture
            print(json.dumps(results))
            
        if __name__ == "__main__":
            safe_analysis()
    """)
    script_path = os.path.join(temp_dir, ANALYSIS_SCRIPT_NAME)
    with open(script_path, "w") as f:
        f.write(script_content)
    print(f"[HOST] Generated isolated analysis script.")

def create_untrusted_config(temp_dir: str) -> None:
    """Generates a sample untrusted configuration file for testing."""
    untrusted_data = {
        "service_name": "malware_simulator",
        "version": "1.0",
        "network_binding": "0.0.0.0", # Warning trigger
        "port": 8080,
        "exec_command": "rm -rf /" # Danger trigger (only inside container)
    }
    config_path = os.path.join(temp_dir, UNTRUSTED_CONFIG_NAME)
    with open(config_path, "w") as f:
        json.dump(untrusted_data, f, indent=4)
    print(f"[HOST] Generated untrusted configuration file.")

def run_sandboxed_analysis() -> Dict[str, Any]:
    """
    Orchestrates the entire process: setup, Docker build, Docker run, and cleanup.
    The analysis happens entirely within the temporary, isolated Docker container.
    """
    print("--- Starting Sandboxed Configuration Analysis ---")
    
    # 1. Use TemporaryDirectory for isolation and automatic filesystem cleanup
    with tempfile.TemporaryDirectory() as temp_dir:
        print(f"[HOST] Working in temporary directory: {temp_dir}")
        
        # 2. Preparation: Create necessary files in the temporary build context
        generate_dockerfile(temp_dir)
        generate_analysis_script(temp_dir)
        create_untrusted_config(temp_dir)
        
        # 3. Docker Build: Create the isolated analysis image
        print(f"[HOST] Building Docker image: {DOCKER_IMAGE_NAME}...")
        try:
            # The build command uses the temporary directory as the build context
            build_cmd = ["docker", "build", "-t", DOCKER_IMAGE_NAME, temp_dir]
            subprocess.run(build_cmd, check=True, capture_output=True, text=True, timeout=120)
            print("[HOST] Docker image built successfully.")
            
        except subprocess.CalledProcessError as e:
            print(f"[HOST] ERROR: Docker build failed.")
            return {"status": "FAILURE", "error": "Docker build error", "details": e.stderr}

        # 4. Docker Run: Execute the analysis inside the isolated container
        print("[HOST] Running sandboxed analysis...")
        try:
            # --rm flag ensures the container instance is destroyed immediately after execution
            run_cmd = ["docker", "run", "--rm", DOCKER_IMAGE_NAME]
            
            # Execute and capture stdout (which contains our structured JSON results)
            result = subprocess.run(run_cmd, check=True, capture_output=True, text=True, timeout=30)
            
            raw_output = result.stdout.strip()
            print(f"[HOST] Analysis complete. Raw output received.")
            
            # Parse the JSON output safely
            analysis_data = json.loads(raw_output)
            return analysis_data
            
        except subprocess.CalledProcessError as e:
            print(f"[HOST] ERROR: Docker run failed.")
            return {"status": "FAILURE", "error": "Docker run error", "details": e.stderr}
        except json.JSONDecodeError:
            print("[HOST] ERROR: Could not decode JSON output from container.")
            return {"status": "FAILURE", "error": "Invalid output format"}
        finally:
            # 5. Cleanup: Ensure the temporary image is removed (Defensive cleanup)
            print(f"[HOST] Cleaning up temporary Docker image: {DOCKER_IMAGE_NAME}...")
            # Use -f (force) and check=False to handle cases where the image might not exist
            subprocess.run(["docker", "rmi", "-f", DOCKER_IMAGE_NAME], check=False, capture_output=True)
            print("[HOST] Cleanup complete.")


if __name__ == "__main__":
    # Preliminary check to ensure Docker is running
    try:
        subprocess.run(["docker", "info"], check=True, capture_output=True, timeout=5)
    except (FileNotFoundError, subprocess.CalledProcessError):
        print("CRITICAL: Docker is not installed or the Docker daemon is not running.")
        exit(1)

    final_report = run_sandboxed_analysis()
    
    print("\n==============================================")
    print("           FINAL ANALYSIS REPORT (HOST)")
    print("==============================================")
    print(json.dumps(final_report, indent=4))
    
    if final_report.get("status") in ["WARNING", "DANGER"]:
        print("\nACTION REQUIRED: Potential threat detected in configuration file.")

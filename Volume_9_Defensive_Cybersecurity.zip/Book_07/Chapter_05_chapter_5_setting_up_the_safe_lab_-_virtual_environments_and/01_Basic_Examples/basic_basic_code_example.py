
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import venv
import subprocess
import sys
import os
import shutil
from typing import Optional

# --- Configuration ---
# The name we give to our isolated testing environment directory
ENV_NAME = "isolated_sec_env"
# A common third-party package used for demonstration
TEST_PACKAGE = "requests"

def setup_environment(env_name: str, package_name: str):
    """
    Creates the virtual environment structure and installs a test package 
    inside the newly created environment using subprocess calls.
    """
    print("=" * 60)
    print(f"[1] Starting Isolation Setup for: {env_name}")
    
    # 1. Environment Creation
    # The EnvBuilder object handles the creation of the necessary directories 
    # (bin/Scripts, lib, pyvenv.cfg)
    print(f"    -> Creating environment directory structure...")
    builder = venv.EnvBuilder(with_pip=True, symlinks=True)
    builder.create(env_name)
    
    # 2. Determine the new environment's Python path
    # We must find the exact path to the Python executable *inside* the venv.
    if sys.platform == "win32":
        # Windows typically uses a 'Scripts' directory
        python_exec = os.path.join(env_name, "Scripts", "python.exe")
    else:
        # Unix/Linux/macOS typically uses a 'bin' directory
        python_exec = os.path.join(env_name, "bin", "python")
        
    print(f"    -> Target executable path identified: {python_exec}")

    # 3. Install the package using the isolated Python executable
    print(f"    -> Installing '{package_name}' inside '{env_name}'...")
    try:
        # CRITICAL: We call the *new* environment's python executable to run pip.
        # This ensures the package is installed only in the venv's site-packages.
        subprocess.check_call(
            [python_exec, "-m", "pip", "install", package_name], 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE
        )
        print(f"    -> SUCCESS: '{package_name}' installed exclusively in {env_name}.")
    except subprocess.CalledProcessError as e:
        print(f"ERROR: Failed to install package in venv. Details: {e}")
        sys.exit(1)


def verify_isolation(package_name: str) -> bool:
    """
    Checks if the package installed in the venv is accessible 
    in the currently running (host) environment.
    """
    print("\n" + "=" * 60)
    print(f"[2] Verifying Isolation in the Host Environment")
    # sys.prefix points to the base directory of the current Python installation.
    print(f"    -> Current Host Prefix: {sys.prefix}")
    
    # Check 1: Try to import the package directly in the host environment
    try:
        __import__(package_name)
        # If the import succeeds, isolation has failed!
        print(f"    [FAIL] The package '{package_name}' is accessible in the host environment!")
        return False
    except ImportError:
        # If the import fails, the host environment does not know about the package.
        print(f"    [PASS] The package '{package_name}' is NOT accessible in the host environment.")
        print("    Isolation successfully confirmed.")
        return True

def cleanup(env_name: str):
    """Removes the created environment directory for a clean slate."""
    print("\n" + "=" * 60)
    if os.path.exists(env_name):
        print(f"[3] Cleaning up environment directory: {env_name}")
        # shutil.rmtree is necessary for recursively deleting the directory and its contents
        shutil.rmtree(env_name)
        print("    Cleanup complete. Environment removed.")
    else:
        print(f"[3] Cleanup skipped. Directory '{env_name}' not found.")

if __name__ == "__main__":
    # The main execution block ensures cleanup always runs, even if setup fails.
    try:
        setup_environment(ENV_NAME, TEST_PACKAGE)
        verify_isolation(TEST_PACKAGE)
        
    except Exception as e:
        print(f"\nFATAL ERROR during execution: {e}")
        
    finally:
        cleanup(ENV_NAME)

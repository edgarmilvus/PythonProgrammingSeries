
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import re
import json
from typing import List, Dict, Any

# 1. Rule Definition Structure (Simulating signatures.json content)
SIGNATURE_JSON_CONTENT = """
[
    {
        "id": "1001",
        "severity": "High",
        "description": "Basic SQL Injection Attempt",
        "pattern": "(\\s*OR\\s*1=1|UNION\\s+SELECT)",
        "confidence": 1.0
    },
    {
        "id": "1002",
        "severity": "Medium",
        "description": "Directory Traversal Via Parent Directory",
        "pattern": "(\\.{2}/|%2e%2e%2f)",
        "confidence": 0.7
    },
    {
        "id": "1003",
        "severity": "Low",
        "description": "Common XSS Payload Tag",
        "pattern": "(<script>|%3cscript%3e)",
        "confidence": 0.3
    }
]
"""

def load_and_compile_rules(json_content: str) -> List[Dict[str, Any]]:
    """Loads rules from JSON and compiles regex patterns for efficiency."""
    rules_data = json.loads(json_content)
    compiled_rules = []
    
    for rule in rules_data:
        try:
            # Efficiency Focus: Compile the regex pattern once upon loading
            rule['compiled_pattern'] = re.compile(rule['pattern'], re.IGNORECASE)
            compiled_rules.append(rule)
        except re.error as e:
            print(f"Error compiling regex for rule {rule['id']}: {e}")
            
    return compiled_rules

def check_log_against_signatures(log_entry: str, compiled_rules: List[Dict[str, Any]]):
    """Checks a single log entry against all compiled signatures."""
    alerts = []
    for rule in compiled_rules:
        # Use the pre-compiled pattern for fast matching
        if rule['compiled_pattern'].search(log_entry):
            alerts.append({
                "Log Entry": log_entry,
                "Rule ID": rule['id'],
                "Severity": rule['severity'],
                "Description": rule['description']
            })
    return alerts

# 2. Log Simulation
log_entries = [
    "/index.html?param=normal_user_input",
    "/search?q=admin'+OR+1=1--",           # Malicious (SQLi)
    "/data/file.txt",
    "/download?file=../../etc/passwd",      # Malicious (Traversal)
    "/profile?name=test%3cscript%3ealert(1)", # Malicious (XSS)
    "/api/v1/users"
]

# 3. Execution
print("--- Initializing Signature Engine ---")
compiled_signatures = load_and_compile_rules(SIGNATURE_JSON_CONTENT)
print(f"Loaded and compiled {len(compiled_signatures)} rules.\n")

print("--- Running Detection Against Simulated Logs ---")
total_alerts = 0
for entry in log_entries:
    matches = check_log_against_signatures(entry, compiled_signatures)
    if matches:
        print(f"\n[ALERT] Detected {len(matches)} potential threat(s) in: {entry}")
        for match in matches:
            print(f"  -> ID: {match['Rule ID']} | Severity: {match['Severity']} | Description: {match['Description']}")
        total_alerts += len(matches)

print(f"\n--- Analysis Complete: {total_alerts} alerts generated. ---")

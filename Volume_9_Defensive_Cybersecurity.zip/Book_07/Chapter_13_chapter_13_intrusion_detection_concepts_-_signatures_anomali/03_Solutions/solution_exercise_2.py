
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import random
import statistics
from typing import List, Dict, Tuple

# Constants for simulation
TRAINING_SIZE = 100
READ_OPS_MEAN = 60
NET_CONNS_MEAN = 15
STD_DEV = 5
ANOMALY_THRESHOLD_SIGMA = 3

def generate_training_data() -> List[Dict[str, int]]:
    """Simulates 100 minutes of normal system activity."""
    data = []
    for i in range(1, TRAINING_SIZE + 1):
        # Generate data points with small, normal variation
        read_ops = int(random.gauss(READ_OPS_MEAN, STD_DEV))
        net_conns = int(random.gauss(NET_CONNS_MEAN, STD_DEV / 2)) # Lower variability for net_conns
        data.append({
            'minute': i, 
            'read_ops': max(0, read_ops),
            'net_conns': max(0, net_conns)
        })
    return data

def calculate_baseline(data: List[Dict[str, int]]) -> Dict[str, float]:
    """Computes the mean (mu) and standard deviation (sigma) for metrics."""
    read_ops_values = [d['read_ops'] for d in data]
    net_conns_values = [d['net_conns'] for d in data]

    baseline = {
        'read_ops_mu': statistics.mean(read_ops_values),
        'read_ops_sigma': statistics.stdev(read_ops_values),
        'net_conns_mu': statistics.mean(net_conns_values),
        'net_conns_sigma': statistics.stdev(net_conns_values)
    }
    return baseline

def detect_anomaly(live_data_point: Dict[str, int], baseline: Dict[str, float]) -> Tuple[bool, List[str]]:
    """Flags data points outside the mu +/- 3*sigma range."""
    
    is_anomaly = False
    alerts = []
    
    # Check Read Operations
    mu_r, sigma_r = baseline['read_ops_mu'], baseline['read_ops_sigma']
    read_ops_val = live_data_point['read_ops']
    
    # Calculate deviation in terms of sigma
    deviation_r = abs(read_ops_val - mu_r) / sigma_r
    
    if deviation_r >= ANOMALY_THRESHOLD_SIGMA:
        is_anomaly = True
        alerts.append(f"Read Ops: {read_ops_val} (Deviation: {deviation_r:.2f}σ, Threshold: {ANOMALY_THRESHOLD_SIGMA}σ)")

    # Check Network Connections
    mu_n, sigma_n = baseline['net_conns_mu'], baseline['net_conns_sigma']
    net_conns_val = live_data_point['net_conns']
    
    deviation_n = abs(net_conns_val - mu_n) / sigma_n

    if deviation_n >= ANOMALY_THRESHOLD_SIGMA:
        is_anomaly = True
        alerts.append(f"Net Conns: {net_conns_val} (Deviation: {deviation_n:.2f}σ, Threshold: {ANOMALY_THRESHOLD_SIGMA}σ)")
        
    return is_anomaly, alerts

# --- Execution ---

# 1. Generate Training Data and Calculate Baseline
training_data = generate_training_data()
baseline = calculate_baseline(training_data)

print("--- Baseline Calculation ---")
print(f"Read Ops Baseline: Mu={baseline['read_ops_mu']:.2f}, Sigma={baseline['read_ops_sigma']:.2f}")
print(f"Net Conns Baseline: Mu={baseline['net_conns_mu']:.2f}, Sigma={baseline['net_conns_sigma']:.2f}")
print(f"Anomaly Threshold set at {ANOMALY_THRESHOLD_SIGMA} standard deviations.\n")

# 2. Test Case Generation (Minutes 101-110)
live_data = [
    {'minute': 101, 'read_ops': 62, 'net_conns': 14}, # Normal
    {'minute': 102, 'read_ops': 95, 'net_conns': 16}, # ANOMALY: High Read Ops
    {'minute': 103, 'read_ops': 58, 'net_conns': 13}, # Normal
    {'minute': 104, 'read_ops': 65, 'net_conns': 35}, # ANOMALY: High Net Conns
    {'minute': 105, 'read_ops': 100, 'net_conns': 30},# CRITICAL ANOMALY: Both High
    {'minute': 106, 'read_ops': 5, 'net_conns': 2}    # ANOMALY: Extremely Low Activity (Denial of Service/System Shutdown)
]

print("--- Live Detection Results ---")
for dp in live_data:
    is_alert, details = detect_anomaly(dp, baseline)
    
    status = "ALERT (ANOMALY)" if is_alert else "NORMAL"
    print(f"Minute {dp['minute']} | Status: {status}")
    if is_alert:
        for detail in details:
            print(f"  -> Metric Triggered: {detail}")

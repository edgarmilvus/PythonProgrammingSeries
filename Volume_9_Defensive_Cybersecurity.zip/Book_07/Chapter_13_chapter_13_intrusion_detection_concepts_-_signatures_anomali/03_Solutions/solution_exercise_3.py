
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
import sys
from typing import List

def initialize_fim_paths(config_paths: List[str]) -> List[str]:
    """
    Takes a list of configured paths (relative or absolute) and
    returns a list of strictly absolute, real paths, adhering to POLA.
    """
    
    # 1. Contextual Path Initialization (Establishing the root context)
    current_working_dir = os.getcwd()
    print(f"FIM Root Context (CWD): {current_working_dir}")
    
    resolved_paths = []
    
    for path in config_paths:
        print(f"\nProcessing configured path: '{path}'")
        
        # 2. Absolute Path Enforcement (Step 1: Convert relative to absolute)
        absolute_path = os.path.abspath(path)
        print(f"  -> Absolute Path: {absolute_path}")

        # Check for existence immediately (POLA: Fail loudly if path is invalid)
        if not os.path.exists(absolute_path):
            print(f"[ERROR] Path does not exist or is inaccessible: {absolute_path}")
            # In a real FIM, we might raise an exception or exit.
            # For this prototype, we skip and report the failure.
            continue
            
        # 3. Preventing Astonishment via Symlinks (Step 2: Resolve real path)
        try:
            real_path = os.path.realpath(absolute_path)
            
            if absolute_path != real_path:
                print(f"  -> WARNING: Resolved Symlink. Monitoring REAL path:")
                print(f"     Resolved Real Path: {real_path}")
            else:
                print(f"  -> Path resolved successfully (No Symlink detected).")
                
            resolved_paths.append(real_path)

        except Exception as e:
            print(f"[CRITICAL ERROR] Failed to resolve real path for {absolute_path}: {e}")
            
    return resolved_paths

# --- Example Setup and Execution ---

# Setup simulation: Create temporary files/dirs to test path resolution
# NOTE: This setup uses standard Python tempfile/os operations for demonstration.
try:
    # 1. A normal directory
    os.makedirs("./config_dir", exist_ok=True)
    
    # 2. A target directory for a symlink
    os.makedirs("/tmp/real_data_location", exist_ok=True) 
    
    # 3. Create a symlink pointing from the CWD to the real location
    symlink_path = "./link_to_data"
    if os.path.exists(symlink_path): os.remove(symlink_path)
    os.symlink("/tmp/real_data_location", symlink_path)

    # Example usage:
    config_paths = [
        "./config_dir",         # Relative path, normal directory
        "non_existent_path",    # Path that should fail
        symlink_path            # Relative path, symlink
    ]

    print("--- FIM Path Initialization Start ---")
    monitored_paths = initialize_fim_paths(config_paths)
    
    print("\n--- Final Monitored Paths (Strictly Absolute/Real) ---")
    for path in monitored_paths:
        print(f"  [MONITORING] {path}")

finally:
    # Cleanup simulation artifacts
    if os.path.exists("./config_dir"): os.rmdir("./config_dir")
    if os.path.exists(symlink_path): os.remove(symlink_path)
    if os.path.exists("/tmp/real_data_location"): os.rmdir("/tmp/real_data_location")

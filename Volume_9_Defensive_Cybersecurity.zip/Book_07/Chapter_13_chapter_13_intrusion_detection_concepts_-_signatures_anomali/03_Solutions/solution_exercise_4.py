
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import re
import math
from typing import Dict, Any, Tuple

# --- Reusing and Adapting Components from E1 and E2 ---

# Baseline (Simulated output from Exercise 2)
# Assuming normal activity centers around 60 read ops and 15 net conns, with sigma=5
BASELINE = {
    'read_ops_mu': 60.0,
    'read_ops_sigma': 5.0,
    'net_conns_mu': 15.0,
    'net_conns_sigma': 2.0  # Lower sigma for net connections
}

# Compiled Signatures (Adapted from Exercise 1, including confidence scores)
COMPILED_SIGNATURES = [
    {'id': '1001', 'severity': 'High', 'pattern': re.compile("(\\s*OR\\s*1=1|UNION\\s+SELECT)", re.IGNORECASE), 'confidence': 1.0},
    {'id': '1002', 'severity': 'Medium', 'pattern': re.compile("(\\.{2}/|%2e%2e%2f)", re.IGNORECASE), 'confidence': 0.7},
    {'id': '1003', 'severity': 'Low', 'pattern': re.compile("(<script>|%3cscript%3e)", re.IGNORECASE), 'confidence': 0.3}
]

# 1. Signature Scoring System
def calculate_signature_score(payload: str, compiled_rules: List[Dict[str, Any]]) -> float:
    """Returns the highest confidence score of any matching signature."""
    max_score = 0.0
    for rule in compiled_rules:
        if rule['pattern'].search(payload):
            max_score = max(max_score, rule['confidence'])
            # Optimization: If we hit max score (1.0), we can stop
            if max_score == 1.0:
                break
    return max_score

# 2. Anomaly Scoring System
def calculate_anomaly_score(data: Dict[str, int], baseline: Dict[str, float]) -> Tuple[float, str]:
    """Calculates the normalized anomaly score based on deviation from baseline."""
    
    max_anomaly_score = 0.0
    triggering_metric = "None"
    
    metrics = {
        'read_ops': (data['read_ops'], baseline['read_ops_mu'], baseline['read_ops_sigma']),
        'net_conns': (data['net_conns'], baseline['net_conns_mu'], baseline['net_conns_sigma'])
    }
    
    for name, (value, mu, sigma) in metrics.items():
        # Calculate deviation in standard deviations (Z-score)
        deviation_sigma = abs(value - mu) / sigma
        
        # Apply the required formula: SA = max(0, (|Metric - mu| / sigma) - 1) / 5
        score = max(0, deviation_sigma - 1) / 5
        
        if score > max_anomaly_score:
            max_anomaly_score = score
            triggering_metric = name
            
    return max_anomaly_score, triggering_metric

# 4. Fusion Logic (Weighted Alert)
def generate_final_alert(sig_score: float, anomaly_score: float) -> Tuple[float, str]:
    """Combines signature and anomaly scores to determine final severity."""
    
    # Weighted calculation: 60% Signature, 40% Anomaly
    final_score = (0.6 * sig_score) + (0.4 * anomaly_score)
    
    if final_score >= 0.8:
        severity = "CRITICAL ALERT"
    elif final_score >= 0.5:
        severity = "HIGH ALERT"
    else:
        severity = "Low/Informational Alert"
        
    return final_score, severity

# 5. Interactive Test Cases
test_cases = {
    "Case A (False Positive Avoidance)": {
        "payload": "/normal/traffic/path", # No signature match (Sig Score 0.0)
        "read_ops": 85,                   # High anomaly: 5 sigma deviation (Score ~0.8)
        "net_conns": 15
    },
    "Case B (Stealthy Attack Detection)": {
        "payload": "/search?q=admin'+OR+1=1--", # High signature match (Sig Score 1.0)
        "read_ops": 65,                       # Low anomaly: 1 sigma deviation (Score 0.0)
        "net_conns": 17
    },
    "Case C (Confirmed Attack)": {
        "payload": "/search?q=admin'+OR+1=1--", # High signature match (Sig Score 1.0)
        "read_ops": 90,                       # Extreme anomaly: 6 sigma deviation (Score 1.0)
        "net_conns": 15
    }
}

print("--- IDS Fusion Engine Simulation ---")
print(f"Baseline (Read Ops): Mu={BASELINE['read_ops_mu']}, Sigma={BASELINE['read_ops_sigma']}")
print(f"Weights: Signature (60%), Anomaly (40%)\n")

for name, event in test_cases.items():
    print(f"--- Running {name} ---")
    
    # 1. Calculate Signature Score
    sig_score = calculate_signature_score(event['payload'], COMPILED_SIGNATURES)
    
    # 2. Calculate Anomaly Score
    anomaly_score, metric = calculate_anomaly_score(event, BASELINE)
    
    # 3. Fuse Scores
    final_score, severity = generate_final_alert(sig_score, anomaly_score)
    
    print(f"  Payload: {event['payload']}")
    print(f"  Metrics: Read Ops={event['read_ops']}, Net Conns={event['net_conns']}")
    print(f"  [SCORE BREAKDOWN]")
    print(f"    Signature Confidence: {sig_score:.2f}")
    print(f"    Anomaly Score ({metric}): {anomaly_score:.2f}")
    print(f"  [FINAL ALERT]")
    print(f"    Weighted Score: {final_score:.2f}")
    print(f"    Severity: {severity}\n")

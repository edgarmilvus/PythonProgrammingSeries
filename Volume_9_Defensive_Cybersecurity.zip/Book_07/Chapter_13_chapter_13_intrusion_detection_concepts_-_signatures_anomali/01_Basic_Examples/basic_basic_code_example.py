
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# python_ids_prototype.py
#!/usr/bin/env python3

import re
import time
from typing import List, Dict, Tuple

# --- 1. Configuration and Data Simulation ---

# Known malicious pattern (Signature): Looks for common SQL injection keywords
# The pipe '|' acts as a logical OR in regex.
MALICIOUS_SIGNATURE: str = r"SELECT \* FROM users|DROP TABLE|UNION SELECT"

# Simulated log data (representing 1 second of intense activity)
SIMULATED_LOGS: List[str] = [
    "2023-10-27 10:00:01 INFO: User 'alice' logged in.",
    "2023-10-27 10:00:02 DEBUG: Connection established to 192.168.1.5.",
    "2023-10-27 10:00:03 WARNING: Failed login attempt for 'root'.",
    "2023-10-27 10:00:04 CRITICAL: Attempted query: 'SELECT * FROM users; --'", # Signature match
    "2023-10-27 10:00:05 INFO: User 'bob' accessed /dashboard.",
    "2023-10:27 10:00:06 DEBUG: Normal operation.",
]
# Note: The total number of logs is 6.

# Baseline statistics for anomaly detection (derived from historical data)
# Baseline: 1.0 event per second (E/s) is normal.
BASELINE_EVENTS_PER_SECOND: float = 1.0
# Std Dev: How much the rate usually fluctuates.
BASELINE_STD_DEV: float = 0.2
# Threshold: We use 3 standard deviations (3-Sigma Rule) for a high-confidence alert.
ANOMALY_THRESHOLD_FACTOR: float = 3.0

# --- 2. Signature Detection Function (Deterministic) ---

def check_signatures(logs: List[str], signature_pattern: str) -> List[Tuple[int, str]]:
    """
    Scans logs for known malicious patterns using regular expressions.
    Returns a list of (line_number, log_entry) for matches.
    """
    detected_threats: List[Tuple[int, str]] = []
    # Compile the regex once for efficiency, ignoring case sensitivity.
    compiled_pattern = re.compile(signature_pattern, re.IGNORECASE)

    for i, line in enumerate(logs):
        # re.search looks for the pattern anywhere in the string.
        if compiled_pattern.search(line):
            # Line number is 1-indexed for user readability
            detected_threats.append((i + 1, line.strip()))

    return detected_threats

# --- 3. Anomaly Detection Function (Statistical) ---

def check_anomalies(logs: List[str], baseline_rate: float, std_dev: float, threshold_factor: float) -> Dict[str, float]:
    """
    Analyzes the volume of events to detect unusual spikes.
    (Simplification: We assume the logs provided represent 1 second of activity.)
    """
    
    # Calculate the actual rate of events observed
    actual_event_count = len(logs)
    
    # Since we defined the logs as occurring within 1 second for simplicity:
    time_elapsed = 1.0 
    actual_rate = actual_event_count / time_elapsed 

    # Calculate the upper boundary using the statistical baseline (3-Sigma Rule)
    # Upper Bound = Mean + (Standard Deviation * Threshold Factor)
    upper_bound = baseline_rate + (std_dev * threshold_factor)

    detection_results: Dict[str, float] = {
        "actual_rate": actual_rate,
        "upper_bound": upper_bound,
        "is_anomalous": float(actual_rate > upper_bound) # Use float(bool) for type hint consistency
    }
    
    return detection_results

# --- 4. Main Execution and Report ---

if __name__ == "__main__":
    
    print("--- Intrusion Detection System (IDS) Prototype ---")
    
    # --- A. Signature Check Execution ---
    print("\n[1] Running Signature-Based Detection (Looking for known bad patterns)...")
    
    start_time_sig = time.time()
    threats_found = check_signatures(SIMULATED_LOGS, MALICIOUS_SIGNATURE)
    end_time_sig = time.time()
    
    if threats_found:
        print(f"\n!!! SIGNATURE ALERT: {len(threats_found)} known threat(s) detected.")
        for line_num, log_entry in threats_found:
            print(f"  -> Line {line_num}: {log_entry}")
    else:
        print("  -> No known signatures matched.")
        
    print(f"  -> Signature scan completed in {end_time_sig - start_time_sig:.6f} seconds.")
    
    # --- B. Anomaly Check Execution ---
    print("\n[2] Running Anomaly-Based Detection (Looking for unusual volume)...")
    
    anomaly_results = check_anomalies(
        SIMULATED_LOGS, 
        BASELINE_EVENTS_PER_SECOND, 
        BASELINE_STD_DEV, 
        ANOMALY_THRESHOLD_FACTOR
    )
    
    # Calculate the anomaly status based on the result dictionary
    is_anomalous = bool(anomaly_results.get("is_anomalous", 0.0))

    print(f"  -> Baseline Rate (E/s): {BASELINE_EVENTS_PER_SECOND:.2f}")
    print(f"  -> Upper Statistical Bound (3-Sigma): {anomaly_results['upper_bound']:.2f} E/s")
    print(f"  -> Actual Observed Rate: {anomaly_results['actual_rate']:.2f} E/s")

    if is_anomalous:
        print("\n!!! ANOMALY ALERT: Event rate exceeds established baseline.")
        print("  -> Potential volumetric attack (DDoS, brute-force, or rapid enumeration).")
    else:
        print("  -> Event rate is within normal statistical bounds.")


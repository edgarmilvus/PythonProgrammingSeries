
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import re
import datetime
from typing import List, Dict, Tuple
from statistics import mean, stdev # Used for anomaly detection

# --- 1. Configuration and Constants ---
# Define known malicious signatures (regex patterns)
MALICIOUS_SIGNATURES = [
    r"Failed login attempt for user root",
    r"Attempted access to /etc/shadow",
    r"Command executed: nc -l -p \d+", # Netcat listener attempt
]

class IDSConfig:
    """Holds configuration derived from environment variables."""
    def __init__(self, sig_threshold: int, anomaly_factor: float):
        # Threshold for how many times a signature must hit before it alerts
        self.SIG_THRESHOLD = sig_threshold
        # Factor by which current activity must exceed baseline to be flagged
        self.ANOMALY_FACTOR = anomaly_factor
        # Regex pattern to parse log lines: Timestamp | User | Action
        self.LOG_PATTERN = re.compile(r"(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) \| (\w+) \| (.*)")

# --- 2. Log Parsing and Data Modeling ---
def parse_log_line(line: str, config: IDSConfig) -> Tuple[datetime.datetime, str, str] | None:
    """Parses a raw log line into structured data."""
    match = config.LOG_PATTERN.match(line)
    if match:
        timestamp_str, user, action = match.groups()
        try:
            timestamp = datetime.datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M:%S")
            return timestamp, user, action
        except ValueError:
            # Skip malformed timestamps
            return None
    return None

# --- 3. Signature-Based Detection (Deterministic) ---
def check_signatures(logs: List[str], config: IDSConfig) -> Dict[str, int]:
    """Scans logs for known malicious patterns and applies the configured threshold."""
    signature_hits: Dict[str, int] = {}
    
    for line in logs:
        for pattern in MALICIOUS_SIGNATURES:
            if re.search(pattern, line):
                # Track the count of each specific pattern hit
                signature_hits[pattern] = signature_hits.get(pattern, 0) + 1
    
    # Filter hits based on the configured threshold (SIG_THRESHOLD)
    return {
        sig: count for sig, count in signature_hits.items()
        if count >= config.SIG_THRESHOLD
    }

# --- 4. Anomaly Detection (Statistical) ---

def calculate_activity_rates(parsed_logs: List[Tuple[datetime.datetime, str, str]]) -> Dict[str, float]:
    """Calculates the login rate (logins per minute) for each user based on log timestamps."""
    user_activity: Dict[str, List[datetime.datetime]] = {}
    
    # Group timestamps by user, only counting 'login' actions
    for timestamp, user, action in parsed_logs:
        if "login" in action.lower():
            user_activity.setdefault(user, []).append(timestamp)

    rates: Dict[str, float] = {}
    for user, timestamps in user_activity.items():
        if len(timestamps) < 2:
            rates[user] = 0.0
            continue
            
        # Calculate the total time span for the recorded activity
        time_span_seconds = (timestamps[-1] - timestamps[0]).total_seconds()
        # Ensure the time span is at least 1 minute to avoid division by zero/near-zero
        time_span_minutes = max(1.0, time_span_seconds / 60.0)
        
        # Rate = Total Logins / Time Span in Minutes
        rates[user] = len(timestamps) / time_span_minutes
        
    return rates

def check_anomalies(baseline_rates: Dict[str, float], current_rates: Dict[str, float], config: IDSConfig) -> List[str]:
    """Flags users whose current activity rate significantly exceeds the established baseline."""
    anomalies = []
    
    for user, current_rate in current_rates.items():
        # Retrieve baseline rate, defaulting to 0.0 if the user is new or inactive in the baseline
        baseline_rate = baseline_rates.get(user, 0.0)
        
        # Anomaly condition: Current rate must exceed baseline by the ANOMALY_FACTOR AND 
        # the absolute current rate must be high enough to be meaningful (e.g., > 1 login/min)
        if current_rate > (baseline_rate * config.ANOMALY_FACTOR) and current_rate > 1.0:
            anomalies.append(
                f"User {user}: Baseline {baseline_rate:.2f} logins/min. Current {current_rate:.2f} logins/min. (Factor: x{config.ANOMALY_FACTOR})"
            )
            
    return anomalies

# --- 5. Main Execution and Simulation ---

def run_ids_check(log_data: List[str], baseline_data: List[str]):
    """Main function to load configuration and execute both detection methods."""
    
    # Load configuration from environment variables (Pythonic, secure config management)
    try:
        sig_thresh = int(os.environ.get("IDS_SIG_THRESHOLD", "3"))
        anomaly_factor = float(os.environ.get("IDS_ANOMALY_FACTOR", "2.5"))
    except ValueError:
        # Fallback if environment variables are malformed (Adhering to POLA)
        print("Warning: Invalid environment variables detected. Using default configuration.")
        sig_thresh = 3
        anomaly_factor = 2.5
        
    config = IDSConfig(sig_thresh, anomaly_factor)
    print(f"--- Hybrid IDS Check Initialized (Sig Threshold: {config.SIG_THRESHOLD}, Anomaly Factor: x{config.ANOMALY_FACTOR}) ---")

    # A. Baseline Establishment (Training Phase)
    # Using the walrus operator (:=) for Pythonic assignment within a list comprehension
    parsed_baseline = [p for log in baseline_data if (p := parse_log_line(log, config))]
    baseline_rates = calculate_activity_rates(parsed_baseline)
    print(f"\n[+] Baseline Established for {len(baseline_rates)} users.")
    
    # B. Current Log Analysis (Detection Phase)
    parsed_current = [p for log in log_data if (p := parse_log_line(log, config))]

    # 1. Signature Check
    signature_alerts = check_signatures(log_data, config)
    print("\n[ALERT] Signature Detections:")
    if signature_alerts:
        for sig, count in signature_alerts.items():
            print(f"  [!!!] Critical Signature Hit ({count} times): {sig}")
    else:
        print("  [OK] No critical signature patterns detected.")

    # 2. Anomaly Check
    current_rates = calculate_activity_rates(parsed_current)
    anomaly_alerts = check_anomalies(baseline_rates, current_rates, config)
    print("\n[ALERT] Anomaly Detections:")
    if anomaly_alerts:
        for alert in anomaly_alerts:
            print(f"  [!!!] High Activity Anomaly Detected: {alert}")
    else:
        print("  [OK] Current activity is within expected baseline parameters.")


if __name__ == "__main__":
    # Simulate Baseline Data (Normal, low-rate activity)
    BASELINE_LOGS = [
        "2023-10-25 10:00:00 | admin | Successful login",
        "2023-10-25 10:00:15 | user_a | Successful login",
        "2023-10-25 10:01:00 | admin | File access /var/log/syslog",
        "2023-10-25 10:02:00 | user_a | Successful login",
        "2023-10-25 10:03:00 | user_b | Successful login",
    ] # Baseline rate for admin/user_a is roughly 0.5 - 1.0 login per minute

    # Simulate Current Data (Attack Scenario: Brute force & rapid access)
    CURRENT_LOGS = [
        "2023-10-26 14:00:00 | root | Failed login attempt for user root", 
        "2023-10-26 14:00:01 | root | Failed login attempt for user root", 
        "2023-10-26 14:00:02 | root | Failed login attempt for user root", # Signature Hit (3 times)
        "2023-10-26 14:01:00 | attacker | Successful login",
        "2023-10-26 14:01:05 | attacker | Successful login",
        "2023-10-26 14:01:10 | attacker | Successful login",
        "2023-10-26 14:01:15 | attacker | Successful login",
        "2023-10-26 14:01:20 | attacker | Successful login", # 5 logins in 20 seconds
        "2023-10-26 14:02:30 | attacker | Attempted access to /etc/shadow", # Signature Hit
    ]
    
    # Example usage of Environment Variables to override defaults:
    # os.environ["IDS_SIG_THRESHOLD"] = "2" 
    # os.environ["IDS_ANOMALY_FACTOR"] = "1.5" 
    
    run_ids_check(CURRENT_LOGS, BASELINE_LOGS)

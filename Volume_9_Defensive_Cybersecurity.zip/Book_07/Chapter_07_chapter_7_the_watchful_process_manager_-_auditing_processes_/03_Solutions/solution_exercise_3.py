
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import psutil
import socket
import os

# 1. Whitelisted Processes
WHITELISTED_PROCESSES = [
    'sshd', 'sshd.exe', 'httpd', 'nginx', 'apache2', 'dnsmasq', 
    'mysqld', 'postgres', 'svchost.exe', 'System', 'python.exe', 'node.exe'
]

# Convert to a set of lowercase names for efficient, case-insensitive lookup (O(1))
WHITELIST_SET = set(p.lower() for p in WHITELISTED_PROCESSES)

def check_covert_listeners():
    """
    Scans network connections for unauthorized listeners (ports in LISTEN state
    associated with non-whitelisted processes).
    """
    suspicious_listeners = []
    
    print("Starting Covert Listener Detection...")
    
    # 2. Connection Filtering: Retrieve all IPv4/IPv6 connections
    connections = psutil.net_connections(kind='inet')
    
    for conn in connections:
        # Filter for sockets in the LISTEN state
        if conn.status == psutil.CONN_LISTEN:
            
            pid = conn.pid
            process_name = "N/A"
            is_suspicious = False
            
            # Connection details
            protocol = "TCP" if conn.type == socket.SOCK_STREAM else "UDP"
            local_addr = f"{conn.laddr.ip}:{conn.laddr.port}"
            
            if pid is None:
                process_name = "Kernel/System"
            else:
                # 3. Process Mapping and Error Handling
                try:
                    process = psutil.Process(pid)
                    process_name = process.name()
                        
                except psutil.NoSuchProcess:
                    process_name = "TERMINATED_PROCESS"
                    is_suspicious = True 
                except psutil.AccessDenied:
                    process_name = "ACCESS_DENIED"
                    is_suspicious = True 
            
            # Check if the process name (or the default 'Kernel/System') is whitelisted
            if not is_suspicious and process_name.lower() not in WHITELIST_SET:
                is_suspicious = True

            if is_suspicious:
                suspicious_listeners.append({
                    'protocol': protocol,
                    'local_address': local_addr,
                    'pid': pid,
                    'process_name': process_name
                })

    generate_listener_report(suspicious_listeners)

def generate_listener_report(findings):
    """4. Generates the detailed report of suspicious listeners."""
    
    print("\n" + "="*60)
    print("COVERT LISTENER DETECTION REPORT")
    print("="*60)
    
    if not findings:
        print("[SUCCESS] No suspicious listening ports detected.")
        return
        
    print(f"[ALERT] Found {len(findings)} potential covert listeners.")
    print("-" * 60)
    
    for finding in findings:
        print(f"PROTOCOL: {finding['protocol']:<8} | ADDRESS: {finding['local_address']:<21} | PID: {finding['pid']}")
        print(f"  -> PROCESS: {finding['process_name']} (NOT WHELISTED)")
        print("-" * 60)

if __name__ == "__main__":
    check_covert_listeners()

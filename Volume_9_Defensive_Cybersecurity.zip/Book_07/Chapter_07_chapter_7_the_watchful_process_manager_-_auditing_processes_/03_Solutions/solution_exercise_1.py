
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import psutil
import time
import os

# --- Configuration ---
CPU_THRESHOLD = 15.0  # Maximum acceptable CPU usage percentage
MEMORY_THRESHOLD = 512  # Maximum acceptable memory usage in Megabytes (MB)
LOG_FILE = 'resource_anomalies.log'

def check_resource_anomalies():
    """
    Scans all processes, checks resource consumption against thresholds, 
    and logs anomalies to a file using a context manager.
    """
    anomalies_found = 0
    
    # 4. Context Manager Implementation for reliable file handling
    with open(LOG_FILE, 'w') as f:
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        f.write(f"--- Resource Anomaly Sentinel Report ({timestamp}) ---\n")
        f.write(f"Thresholds: CPU > {CPU_THRESHOLD}%, Memory > {MEMORY_THRESHOLD} MB\n\n")

        # 2. Process Iteration and Measurement
        # Request specific attributes for efficiency
        for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_info']):
            try:
                process_info = proc.info
                pid = process_info['pid']
                name = process_info['name']
                
                # Retrieve CPU usage (non-blocking, returns average since last call or 0 initially)
                cpu_usage = proc.cpu_percent(interval=None) 
                
                # Convert RSS (bytes) to MB
                memory_rss_bytes = process_info['memory_info'].rss
                memory_usage_mb = memory_rss_bytes / (1024 * 1024)

                is_anomaly = False
                reason = []

                if cpu_usage > CPU_THRESHOLD:
                    reason.append(f"CPU ({cpu_usage:.2f}%)")
                    is_anomaly = True
                
                if memory_usage_mb > MEMORY_THRESHOLD:
                    reason.append(f"Memory ({memory_usage_mb:.2f} MB)")
                    is_anomaly = True

                # 3. Anomaly Logging
                if is_anomaly:
                    anomalies_found += 1
                    log_entry = (
                        f"[ANOMALY] PID: {pid:<5} | Name: {name:<20} | Breach: {', '.join(reason)}\n"
                        f"  -> CPU: {cpu_usage:.2f}% | Memory: {memory_usage_mb:.2f} MB\n"
                    )
                    f.write(log_entry)
                    
            except psutil.NoSuchProcess:
                # Graceful handling for processes that terminate mid-scan
                f.write(f"[ERROR] Process ID {pid} terminated during scan.\n")
            except psutil.AccessDenied:
                # Graceful handling for permission issues
                f.write(f"[ERROR] Access Denied for PID {pid} ({name}). Skipping detailed check.\n")
            except Exception as e:
                f.write(f"[ERROR] Unexpected error processing PID {pid}: {e}\n")

    if anomalies_found == 0:
        print(f"Audit complete. No resource anomalies found above thresholds.")
    else:
        print(f"Audit complete. {anomalies_found} anomalies logged to {LOG_FILE}")

if __name__ == "__main__":
    # Ensure initial CPU reading is non-zero for better accuracy in subsequent runs
    try:
        psutil.cpu_percent(interval=0.1) 
    except Exception:
        pass
    check_resource_anomalies()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import psutil
import argparse
import time
import json
import socket
import os

# --- Global Configurations (Baselines) ---
SECURITY_BASELINE = {'sshd', 'cron', 'systemd', 'wininit.exe', 'smss.exe', 'auditd'}
WHITELISTED_PROCESSES = {
    'sshd', 'sshd.exe', 'httpd', 'nginx', 'apache2', 'dnsmasq', 
    'mysqld', 'postgres', 'svchost.exe', 'System', 'python.exe', 'node.exe'
}
WHITELIST_SET = set(p.lower() for p in WHITELISTED_PROCESSES)

# --- Modular Audit Functions (Adapted from previous exercises) ---

def run_resource_check(cpu_limit, mem_limit):
    """Runs Exercise 1 logic, returning structured findings with severity."""
    findings = []
    
    for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_info']):
        try:
            cpu_usage = proc.cpu_percent(interval=None) 
            memory_usage_mb = proc.info['memory_info'].rss / (1024 * 1024)

            breach_cpu = cpu_usage > cpu_limit
            breach_mem = memory_usage_mb > mem_limit
            
            severity = None
            if breach_cpu and breach_mem:
                severity = "Medium" # Medium: Both thresholds breached
            elif breach_cpu or breach_mem:
                severity = "Low"    # Low: Only one threshold breached
            
            if severity:
                findings.append({
                    'severity': severity,
                    'module': 'ResourceAnomaly',
                    'description': f"Process {proc.name()} exceeded {'both' if severity=='Medium' else 'one'} resource limit.",
                    'details': {
                        'pid': proc.pid,
                        'name': proc.name(),
                        'cpu_actual': f"{cpu_usage:.2f}%",
                        'mem_actual': f"{memory_usage_mb:.2f} MB",
                    }
                })
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return findings

def run_service_check():
    """Runs Exercise 2 logic, returning structured findings with severity."""
    findings = []
    running_names = set(p.name() for p in psutil.process_iter(['name']))
    
    missing_services = SECURITY_BASELINE - running_names
    
    # High: Missing critical services
    for service in missing_services:
        findings.append({
            'severity': 'High',
            'module': 'ServiceBaseline',
            'description': f"Critical service '{service}' required by baseline is STOPPED.",
            'details': {'service_name': service, 'status': 'Missing'}
        })
        
    return findings

def run_network_check():
    """Runs Exercise 3 logic, returning structured findings with severity."""
    findings = []
    
    for conn in psutil.net_connections(kind='inet'):
        if conn.status == psutil.CONN_LISTEN:
            pid = conn.pid
            process_name = "Kernel/System"
            is_suspicious = False
            
            if pid is not None and pid != 0:
                try:
                    process_name = psutil.Process(pid).name()
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    process_name = "TERMINATED_OR_DENIED"
                    is_suspicious = True
            
            if not is_suspicious and process_name.lower() not in WHITELIST_SET:
                is_suspicious = True

            if is_suspicious:
                protocol = "TCP" if conn.type == socket.SOCK_STREAM else "UDP"
                # High: Unapproved listening ports
                findings.append({
                    'severity': 'High',
                    'module': 'CovertListener',
                    'description': f"Unauthorized listener detected on port {conn.laddr.port}.",
                    'details': {
                        'protocol': protocol,
                        'local_address': f"{conn.laddr.ip}:{conn.laddr.port}",
                        'pid': pid,
                        'process_name': process_name
                    }
                })
                
    return findings

def generate_report(all_findings, output_format, thresholds):
    """Generates and outputs the report based on the specified format."""
    
    report_data = {
        'timestamp': time.strftime("%Y-%m-%d %H:%M:%S"),
        'thresholds_used': thresholds,
        'findings': all_findings
    }
    
    if output_format == 'json':
        # 4. Structured JSON Output
        print(json.dumps(report_data, indent=4))
        
    elif output_format == 'console':
        # 5. Interactive Element: Summary and Prioritization
        summary = {'High': 0, 'Medium': 0, 'Low': 0}
        for f in all_findings:
            summary[f['severity']] += 1
            
        print("\n" + "="*70)
        print("UNIFIED SYSTEM STATE AGENT REPORT")
        print("="*70)
        print(f"Audit Time: {report_data['timestamp']}")
        
        print("-" * 70)
        print(f"SUMMARY: High Severity: {summary['High']} | Medium Severity: {summary['Medium']} | Low Severity: {summary['Low']}")
        print("-" * 70)
        
        if not all_findings:
            print("System state is clean. No findings detected.")
            return

        # Detailed Report (Prioritized by Severity: High > Medium > Low)
        severity_order = {'High': 1, 'Medium': 2, 'Low': 3}
        sorted_findings = sorted(all_findings, key=lambda x: severity_order[x['severity']])

        for finding in sorted_findings:
            print(f"\n[{finding['severity'].upper():<6}] ({finding['module']})")
            print(f"  Description: {finding['description']}")
            
            details = finding['details']
            for key, value in details.items():
                print(f"  {key.capitalize().replace('_', ' '):<15}: {value}")
        
        print("\n" + "="*70)


def main():
    """1. Main function to parse arguments and execute the audit modules."""
    
    parser = argparse.ArgumentParser(description="Unified Security Agent for System State Auditing.")
    parser.add_argument('-c', '--cpu-limit', type=float, default=10.0,
                        help="CPU utilization threshold percentage (float, default 10.0).")
    parser.add_argument('-m', '--mem-limit', type=int, default=512,
                        help="Memory usage threshold in MB (integer, default 512).")
    parser.add_argument('-o', '--output-format', type=str, default='console',
                        choices=['json', 'console'],
                        help="Specify output format (json or console, default console).")
    
    args = parser.parse_args()
    
    cpu_limit = args.cpu_limit
    mem_limit = args.mem_limit
    output_format = args.output_format
    
    print(f"Agent running checks (CPU>{cpu_limit}%, MEM>{mem_limit} MB)...")
    
    all_findings = []
    
    # 2. Modular Execution
    all_findings.extend(run_resource_check(cpu_limit, mem_limit))
    all_findings.extend(run_service_check())
    all_findings.extend(run_network_check())
    
    thresholds = {'cpu_limit': cpu_limit, 'mem_limit': mem_limit}
    generate_report(all_findings, output_format, thresholds)

if __name__ == "__main__":
    # Primer for CPU usage calculation
    try:
        psutil.cpu_percent(interval=0.1)
    except Exception:
        pass
        
    main()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import psutil
import os

# 1. Baseline Definition (using common process names as a proxy for services)
SECURITY_BASELINE = {
    'sshd',          # Unix/Linux SSH Daemon
    'cron',          # Unix/Linux scheduler
    'systemd',       # Linux Init System
    'wininit.exe',   # Windows Initialization Process
    'smss.exe',      # Windows Session Manager
    'auditd',        # Linux Auditing Service
}

def get_running_process_names():
    """Retrieves a set of unique names for all currently running processes."""
    running_names = set()
    for proc in psutil.process_iter(['name']):
        try:
            # 2. Service State Retrieval (via process enumeration)
            name = proc.info['name']
            running_names.add(name)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            # 4. Error Handling for Permissions and termination
            continue
    return running_names

def check_baseline(running_names, baseline):
    """Compares running processes against the security baseline."""
    
    # Set operations provide efficient categorization
    validated_services = running_names.intersection(baseline)
    missing_services = baseline - running_names
    unapproved_services = running_names - validated_services
    
    return validated_services, missing_services, unapproved_services

def generate_report(validated, missing, unapproved):
    """3. Generates the categorized console report."""
    
    print("\n" + "="*60)
    print("SERVICE AND DAEMON BASELINE VALIDATION REPORT")
    print("="*60)
    
    # Missing Services (High Security Risk)
    print(f"\n[!!! MISSING SERVICES ({len(missing)}) !!!]")
    if missing:
        for service in sorted(list(missing)):
            print(f"  [CRITICAL] Service '{service}' required by baseline is STOPPED.")
    else:
        print("  All required baseline services are running.")

    # Unapproved Services (Potential unauthorized persistence)
    print(f"\n[??? UNAPPROVED RUNNING SERVICES ({len(unapproved)}) ???]")
    if unapproved:
        # Show a sample, as this list is usually large
        sample_count = min(5, len(unapproved))
        print(f"  Found {len(unapproved)} processes running that are not in the critical baseline. Showing {sample_count} examples:")
        for service in sorted(list(unapproved))[:sample_count]:
            print(f"  [WARNING] Process '{service}' is running.")
    
    # Validated Services (Known Good)
    print(f"\n[+++ VALIDATED SERVICES ({len(validated)}) +++]")
    if validated:
        for service in sorted(list(validated)):
            print(f"  [OK] Service '{service}' is running and validated.")
    
    print("\n" + "="*60)


def main():
    """Main function to execute the service baseline audit."""
    print("Starting Service Baseline Audit...")
    running_names = get_running_process_names()
    validated, missing, unapproved = check_baseline(running_names, SECURITY_BASELINE)
    generate_report(validated, missing, unapproved)

if __name__ == "__main__":
    main()

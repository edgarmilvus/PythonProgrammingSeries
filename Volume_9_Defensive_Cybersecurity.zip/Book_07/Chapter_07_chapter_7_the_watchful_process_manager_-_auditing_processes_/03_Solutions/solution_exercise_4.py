
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import psutil
import hashlib
import json
import os

# --- Configuration ---
HASH_BASELINE_FILE = 'hash_baseline.json'
CRITICAL_PROCESS_NAMES = ['cmd.exe', 'bash', 'powershell.exe', 'explorer.exe']

# Placeholder baseline data (must exist for the script to run)
DUMMY_BASELINE = {
    os.path.normcase("C:\\Windows\\System32\\cmd.exe"): "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    os.path.normcase("/usr/bin/bash"): "a1b2c3d4e5f67890a1b2c3d4e5f67890a1b2c3d4e5f67890a1b2c3d4e5f67890",
}

def load_baseline():
    """1. Loads the cryptographic hash baseline from a JSON file."""
    try:
        if not os.path.exists(HASH_BASELINE_FILE):
             # Create dummy file if it doesn't exist for demonstration
            with open(HASH_BASELINE_FILE, 'w') as f:
                # Use os.path.normcase to ensure keys match runtime paths
                json.dump(DUMMY_BASELINE, f, indent=4)
            print(f"[INFO] Created dummy baseline file: {HASH_BASELINE_FILE}")

        with open(HASH_BASELINE_FILE, 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(f"[FATAL] Error loading baseline: {e}")
        return {}

def calculate_file_hash(filepath, block_size=65536):
    """3. Calculates the SHA-256 hash of a file, reading in chunks."""
    sha256 = hashlib.sha256()
    with open(filepath, 'rb') as f:
        while True:
            data = f.read(block_size)
            if not data:
                break
            sha256.update(data)
    return sha256.hexdigest()

def integrity_check_module(baseline):
    """5. Audits critical processes for executable integrity."""
    
    print("\n" + "="*60)
    print("EXECUTABLE INTEGRITY CHECK MODULE")
    print("="*60)
    
    findings = []
    
    for proc in psutil.process_iter(['pid', 'name', 'exe']):
        try:
            process_name = proc.info['name']
            
            if process_name in CRITICAL_PROCESS_NAMES:
                pid = proc.info['pid']
                exe_path = proc.info['exe']
                
                if not exe_path:
                    findings.append(f"[ERROR] PID {pid} ({process_name}): Executable path is inaccessible or empty.")
                    continue

                # Calculate hash, handling I/O exceptions
                try:
                    calculated_hash = calculate_file_hash(exe_path)
                except (PermissionError, FileNotFoundError) as e:
                    findings.append(f"[ERROR] PID {pid} ({process_name}): {e}")
                    continue
                
                # Normalize path for comparison against the baseline keys
                normalized_path = os.path.normcase(exe_path)
                
                # 4. Discrepancy Reporting
                if normalized_path in baseline:
                    expected_hash = baseline[normalized_path]
                    
                    if calculated_hash != expected_hash:
                        findings.append(
                            f"[!!! CRITICAL INTEGRITY FAILURE !!!]\n"
                            f"  Process: {process_name} (PID {pid})\n"
                            f"  Path: {exe_path}\n"
                            f"  Baseline Hash: {expected_hash[:16]}...\n"
                            f"  Calculated Hash: {calculated_hash[:16]}...\n"
                        )
                else:
                    findings.append(
                        f"[WARNING: UNKNOWN EXECUTABLE]\n"
                        f"  Process: {process_name} (PID {pid})\n"
                        f"  Path: {exe_path}\n"
                        f"  Calculated Hash: {calculated_hash[:16]}...\n"
                        f"  Action: Path not in baseline. Update required.\n"
                    )

        except psutil.NoSuchProcess:
            continue 
        except Exception as e:
            findings.append(f"[ERROR] General error during check for {process_name}: {e}")

    if findings:
        for finding in findings:
            print(finding)
    else:
        print("[SUCCESS] All critical processes checked and verified.")
        
    print("="*60)


if __name__ == "__main__":
    baseline_data = load_baseline()
    if baseline_data:
        integrity_check_module(baseline_data)

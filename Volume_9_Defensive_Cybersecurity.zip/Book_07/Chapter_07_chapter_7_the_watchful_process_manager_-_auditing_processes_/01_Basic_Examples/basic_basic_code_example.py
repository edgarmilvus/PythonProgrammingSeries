
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import psutil
import time
import sys
from typing import List, Dict, Any

# --- Configuration Constants ---
# Define the threshold for what we consider "high" CPU usage for reporting.
# This value is application-dependent but serves as a starting point for anomaly detection.
CPU_THRESHOLD_PERCENT = 5.0

def audit_system_processes(threshold: float) -> Dict[str, Any]:
    """
    Iterates through all running processes, collecting basic metrics
    and flagging any process exceeding a defined CPU threshold.

    Args:
        threshold: The CPU percentage above which a process is flagged.

    Returns:
        A dictionary containing audit summary statistics.
    """
    print("--- System Process Auditor Initializing ---")
    current_time = time.ctime()
    print(f"Auditing system state as of: {current_time}")
    print(f"CPU Usage Threshold set to: {threshold:.2f}%")
    print("-" * 70)

    # 1. Prepare the Process Iterator and Define Attributes
    # We use a generator (process_iter) to avoid loading the entire process list
    # into memory at once. The 'attrs' list specifies exactly which fields to fetch,
    # minimizing overhead.
    requested_attrs: List[str] = ['pid', 'name', 'status', 'cpu_percent', 'username']
    process_generator = psutil.process_iter(attrs=requested_attrs)

    # Initialize counters for reporting
    total_processes = 0
    high_cpu_count = 0
    flagged_processes: List[Dict[str, Any]] = []

    # Define the header format for clean, columnar output
    HEADER_FORMAT = "{:<8} {:<10} {:<30} {:<10} {:>10}"
    print(HEADER_FORMAT.format("PID", "Status", "Name", "User", "CPU (%)"))
    print(HEADER_FORMAT.format("-" * 8, "-" * 10, "-" * 30, "-" * 10, "-" * 10))


    for proc in process_generator:
        total_processes += 1
        
        # 2. Critical Exception Handling Block
        # Processes are transient. We must handle the case where a process
        # terminates between the time the iterator yields it and we access its data.
        try:
            # .info is a dictionary containing the attributes requested in process_iter()
            info = proc.info

            # Extracting required data safely
            pid = info.get('pid', 'N/A')
            name = info.get('name', 'Unknown')
            status = info.get('status', 'N/A')
            cpu_percent = info.get('cpu_percent', 0.0)
            username = info.get('username', 'N/A')

            # 3. Security check: Flagging high resource utilization
            flag = ""
            if cpu_percent > threshold:
                flag = " !!! ANOMALY"
                high_cpu_count += 1
                flagged_processes.append({
                    'pid': pid,
                    'name': name,
                    'cpu': cpu_percent
                })

            # 4. Print the audited process information
            # Note the use of f-string formatting for alignment and precision
            print(f"{pid:<8} {status:<10} {name:<30} {username:<10} {cpu_percent:>10.2f}{flag}")

        except psutil.NoSuchProcess:
            # Log the termination event, which is common in dynamic systems
            # We decrement the counter since we couldn't successfully audit this process
            # and it shouldn't be counted in the final "scanned" total.
            total_processes -= 1 
            # Note: We cannot retrieve the PID here reliably, but we log the event.
            print(f"[ERROR] A process terminated during audit (NoSuchProcess).") 
        
        except psutil.AccessDenied:
            # This occurs when the script lacks permission to read details for a process
            # owned by another user or the system (e.g., highly protected kernel processes).
            print(f"[WARNING] Access Denied while reading process details.")
        
        except Exception as e:
            # Catch other potential transient errors
            print(f"[ERROR] Could not read process details due to unexpected error: {e}")
            
    # 5. Final Reporting
    print("-" * 70)
    print(f"Audit Complete. Total processes scanned: {total_processes}")
    print(f"Processes flagged for high CPU usage (> {threshold:.2f}%): {high_cpu_count}")
    
    return {
        "timestamp": current_time,
        "total_scanned": total_processes,
        "flagged_count": high_cpu_count,
        "flagged_details": flagged_processes
    }


if __name__ == "__main__":
    # Execute the audit and handle potential system-level failures
    try:
        audit_results = audit_system_processes(CPU_THRESHOLD_PERCENT)
        # In a production system, audit_results would be logged to a SIEM or database
        # print("\nAudit Summary:", audit_results) 
        
    except Exception as e:
        # Catch errors that occur before the main loop starts (e.g., psutil import failure)
        print(f"\n[FATAL ERROR] System audit failed critically: {e}", file=sys.stderr)
        sys.exit(1)

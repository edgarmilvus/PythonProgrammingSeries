
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import psutil
import time
import platform
import os
from datetime import datetime
from collections import defaultdict
from typing import Dict, List, Any

# I. Configuration and Thresholds for Anomaly Detection
# These thresholds define the security baseline for resource usage.
CPU_THRESHOLD_PERCENT: float = 5.0  # Flag processes using > 5% CPU
MEM_THRESHOLD_PERCENT: float = 10.0 # Flag processes using > 10% Memory
MIN_RUNTIME_SECONDS: int = 300      # Ignore very new processes (less than 5 minutes old) for resource checks
CRITICAL_PORTS: set = {80, 443, 22, 21, 23} # Standard service ports (HTTP, HTTPS, SSH, FTP) to ignore in connection check

def is_suspicious_connection(conn: psutil._common.sconn) -> bool:
    """
    Determines if a network connection is established, remote, and uses a non-standard port.
    This filters out common services and internal traffic (localhost/RFC1918).
    """
    # Only evaluate established connections with a known remote address (raddr)
    if conn.status == psutil.CONN_ESTABLISHED and conn.raddr:
        remote_ip = conn.raddr.ip
        remote_port = conn.raddr.port

        # 1. Ignore connections using standard, expected service ports
        if remote_port not in CRITICAL_PORTS:
            # 2. Ignore connections to localhost or common internal/private IP ranges (RFC 1918 simplification)
            if not remote_ip.startswith(('127.', '10.', '192.168.', '172.16')):
                # The connection is established, external, and uses an uncommon port
                return True
    return False

def check_process_integrity(pinfo: Dict[str, Any]) -> str:
    """
    Performs basic path and naming integrity checks to detect hidden or misplaced executables.
    Malware often runs from /tmp or user AppData directories.
    """
    path = pinfo.get('exe', '')
    name = pinfo.get('name', '')

    if not path:
        return "No Executable Path Available"
    
    # Check 1: Location in temporary or user profile folders (common malware staging areas)
    if platform.system() == "Windows":
        # Note: We must exclude legitimate applications that use AppData (like browsers)
        if ('temp' in path.lower() or 'appdata' in path.lower()) and name.lower() not in ('chrome.exe', 'firefox.exe'):
            return "Suspicious Path (Temp/User Profile)"
    elif platform.system() in ("Linux", "Darwin"):
        if '/tmp/' in path or '/var/tmp/' in path:
            return "Suspicious Path (/tmp Directory)"
    
    # Check 2: Basic name consistency check
    # While not foolproof, a severe mismatch can indicate a process running a script or being deliberately obfuscated.
    if not path.lower().endswith(name.lower()):
        return "Name/Path Mismatch Warning"
            
    return "Clean"

def audit_system_state() -> Dict[int, List[str]]:
    """
    Main audit function: Iterates over all running processes and applies security checks.
    Returns a dictionary mapping PID to a list of detected anomalies.
    """
    anomalies = defaultdict(list)
    current_time = time.time()
    
    # Iterate over processes, fetching key information efficiently in the initial call
    for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent', 'create_time', 'exe']):
        try:
            pinfo = proc.info
            pid = proc.pid
            
            # 1. Resource Consumption Audit (CPU and Memory)
            # Only audit processes that have been running longer than the defined minimum time
            if (current_time - pinfo['create_time']) > MIN_RUNTIME_SECONDS:
                if pinfo['cpu_percent'] > CPU_THRESHOLD_PERCENT:
                    anomalies[pid].append(f"High CPU Usage ({pinfo['cpu_percent']:.2f}%)")
                if pinfo['memory_percent'] > MEM_THRESHOLD_PERCENT:
                    anomalies[pid].append(f"High Memory Usage ({pinfo['memory_percent']:.2f}%)")

            # 2. Executable Path Integrity Check
            integrity_status = check_process_integrity(pinfo)
            if integrity_status != "Clean":
                anomalies[pid].append(f"Integrity Warning: {integrity_status}")

            # 3. Network Connection Audit (Conditional Execution)
            # We only perform the expensive network check if the process is already flagged 
            # for resource abuse or path integrity, or if it's a known critical process.
            if pid in anomalies:
                # Retrieve all Internet connections for the flagged process
                connections = proc.connections(kind='inet')
                
                suspicious_conns = [
                    f"L:{c.laddr.port} -> R:{c.raddr.ip}:{c.raddr.port} (Status: {c.status})"
                    for c in connections if is_suspicious_connection(c)
                ]
                
                if suspicious_conns:
                    anomalies[pid].append(f"Suspicious Outbound Connections Detected: {len(suspicious_conns)}")
                    anomalies[pid].extend(suspicious_conns)
                        
        except psutil.NoSuchProcess:
            # Handle transient processes that terminate during the iteration
            continue
        except psutil.AccessDenied:
            # Crucial: Log access denial, as unreadable processes can mask rootkits
            anomalies[proc.pid].append("Access Denied (Insufficient Permissions for Deep Audit)")
        except Exception as e:
            # Catch unexpected psutil errors
            anomalies[proc.pid].append(f"Unhandled Audit Error: {type(e).__name__} - {e}")

    return anomalies

if __name__ == "__main__":
    print(f"--- System Integrity Watchdog Report ({datetime.now().strftime('%Y-%m-%d %H:%M:%S')}) ---")
    print(f"Audit Baseline: CPU > {CPU_THRESHOLD_PERCENT}%, Memory > {MEM_THRESHOLD_PERCENT}%, Min Runtime: {MIN_RUNTIME_SECONDS}s")
    
    audit_results = audit_system_state()
    
    if not audit_results:
        print("\n[SUCCESS] Baseline audit complete. No processes exceeded resource or integrity thresholds.")
    else:
        print(f"\n[WARNING] Detected {len(audit_results)} processes requiring security review:")
        print("-" * 80)
        
        # Detailed Reporting Loop
        for pid, warnings in audit_results.items():
            try:
                # Re-instantiate the Process object for final, current details
                p = psutil.Process(pid)
                p_name = p.name()
                p_cmdline = " ".join(p.cmdline())
                p_exe = p.exe()
                
                print(f"\n[FLAGGED] PID: {pid} | Name: {p_name}")
                print(f"  Command Line: {p_cmdline[:100]}{'...' if len(p_cmdline) > 100 else ''}")
                print(f"  Executable Path: {p_exe}")
                print("  ANOMALIES DETECTED:")
                for warning in warnings:
                    print(f"    -> {warning}")
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                # Handle processes that vanished or became inaccessible right before reporting
                print(f"\n[FLAGGED] PID: {pid} (Process state changed or access denied during final report.)")
                print(f"  Initial Warnings Captured: {', '.join(warnings)}")


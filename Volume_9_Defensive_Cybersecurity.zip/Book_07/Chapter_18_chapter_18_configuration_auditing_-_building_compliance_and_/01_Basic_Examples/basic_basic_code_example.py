
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import json
from typing import Dict, Any, List, Tuple

# --- 1. Define Compliance Constants ---
# Using constants improves readability and maintainability, adhering to PEP 8 for constants.
COMPLIANT = "PASS"
NON_COMPLIANT = "FAIL"
MISSING_CONFIG = "WARN"

# --- 2. Define the Security Baseline (The Required Standard) ---
# This dictionary represents the required secure state, derived from organizational policy.
SECURITY_BASELINE: Dict[str, Any] = {
    "ssh_root_login_enabled": False,
    "min_password_length": 14,
    "firewall_default_policy": "DROP",
    "service_ntp_enabled": True
}

# --- 3. Simulate the Current System Configuration (Live Data) ---
# In a real scenario, this data would be dynamically gathered from a remote host.
CURRENT_CONFIG: Dict[str, Any] = {
    "ssh_root_login_enabled": True,      # Non-compliant (Required: False)
    "min_password_length": 8,            # Non-compliant (Required: 14)
    "firewall_default_policy": "ACCEPT", # Non-compliant (Required: DROP)
    # Note: 'service_ntp_enabled' is missing in the current config (Will trigger a WARN)
    "unused_setting": "ignore_me"        # Extra setting, ignored by the baseline check
}

def check_compliance(baseline: Dict[str, Any], current_config: Dict[str, Any]) -> List[Dict[str, str]]:
    """
    Compares the current system configuration against a defined security baseline.

    The function iterates through the baseline requirements and checks for matching
    keys and values in the live configuration data.

    Args:
        baseline: The required secure configuration dictionary.
        current_config: The actual configuration gathered from the system.

    Returns:
        A list of dictionaries detailing the audit results for each setting.
    """
    audit_results: List[Dict[str, str]] = []

    # Iterate ONLY through the settings defined in the baseline.
    for setting, required_value in baseline.items():
        result_entry = {
            "setting": setting,
            "required": str(required_value),
            "actual": "N/A",  # Placeholder for missing/unknown
            "status": NON_COMPLIANT # Default status assumption (guilty until proven innocent)
        }

        # --- Compliance Logic Tree ---
        
        if setting not in current_config:
            # Case 1: MISSING CONFIGURATION
            # The setting required by the baseline was not found in the live data.
            result_entry["status"] = MISSING_CONFIG
            result_entry["actual"] = "MISSING"
            
        elif current_config[setting] == required_value:
            # Case 2: COMPLIANT
            # The actual value exactly matches the required value.
            result_entry["status"] = COMPLIANT
            result_entry["actual"] = str(current_config[setting])
            
        else:
            # Case 3: NON-COMPLIANT
            # The setting exists, but the value is incorrect.
            result_entry["status"] = NON_COMPLIANT
            result_entry["actual"] = str(current_config[setting])

        audit_results.append(result_entry)

    return audit_results

# --- 4. Execution and Reporting ---
if __name__ == "__main__":
    print("--- Initiating Configuration Compliance Audit ---")
    report = check_compliance(SECURITY_BASELINE, CURRENT_CONFIG)

    # Print detailed report
    for item in report:
        # Simple formatting based on status for visual distinction
        status_display = f"[{item['status']:<4}]"
        
        # Add visual emphasis for failures and warnings
        if item["status"] == NON_COMPLIANT:
            status_display = f"[!!! {item['status']} !!!]"
        elif item["status"] == MISSING_CONFIG:
            status_display = f"[??? {item['status']} ???]"
        
        print(f"{status_display:<20} | Setting: {item['setting']:<30} | Required: {item['required']:<10} | Actual: {item['actual']}")

    # Generate Simple Summary
    fails = sum(1 for item in report if item['status'] == NON_COMPLIANT)
    warns = sum(1 for item in report if item['status'] == MISSING_CONFIG)
    passes = sum(1 for item in report if item['status'] == COMPLIANT)

    print("\n--- Audit Summary ---")
    print(f"Total Checks Executed: {len(report)}")
    print(f"PASS: {passes}")
    print(f"FAIL (Non-Compliant): {fails}")
    print(f"WARN (Missing Configuration Data): {warns}")

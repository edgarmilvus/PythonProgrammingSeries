
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import json
import os
from datetime import datetime
from typing import Dict, Any, List, Tuple

# --- 1. Baseline Definition (Simulated CIS-like standard) ---

# Define the required security state for various configuration items.
# Keys represent configuration categories (e.g., SSH, Kernel, Permissions).
SECURITY_BASELINE: Dict[str, Any] = {
    "SSH_CONFIG": {
        "PermitRootLogin": "no",
        "PasswordAuthentication": "no",  # Enforce key-based authentication
        "MaxAuthTries": 3
    },
    "KERNEL_PARAMS": {
        "net.ipv4.ip_forward": 0,  # Ensure system is not acting as a router
        "net.ipv4.conf.all.accept_source_route": 0 # Prevent source routing attacks
    },
    "FILE_PERMISSIONS": {
        "/etc/shadow": "000",  # Only root/privileged process access
        "/etc/ssh/sshd_config": "600" # Strict read/write for root only
    }
}

# --- 2. Simulated Data Gathering (In a real scenario, this uses Paramiko/WMI) ---

def simulate_remote_config_gathering(target_ip: str) -> Dict[str, Any]:
    """
    Simulates retrieving the current configuration from a target system.
    In a production environment, this function would execute remote commands 
    (e.g., 'cat /etc/ssh/sshd_config', 'sysctl -n net.ipv4.ip_forward', 'stat -c "%a" /path')
    and parse their output into a structured dictionary.
    """
    print(f"[INFO] Connecting to {target_ip} and gathering live data...")
    
    # Current (Live) System State - deliberately non-compliant in places for demonstration
    current_config = {
        "SSH_CONFIG": {
            "PermitRootLogin": "yes",  # FAILURE: Should be 'no'
            "PasswordAuthentication": "no", 
            "MaxAuthTries": 5         # FAILURE: Should be 3
        },
        "KERNEL_PARAMS": {
            "net.ipv4.ip_forward": 0,
            "net.ipv4.conf.all.accept_source_route": 1 # FAILURE: Should be 0
        },
        "FILE_PERMISSIONS": {
            "/etc/shadow": "000",
            "/etc/ssh/sshd_config": "644" # FAILURE: Too permissive (Group read allowed)
        }
    }
    
    return current_config

# --- 3. Core Auditing Logic ---

def perform_compliance_audit(baseline: Dict, current_state: Dict) -> List[Dict]:
    """
    Compares the current system state against the defined security baseline.
    Returns a list of non-compliant findings, structured for easy reporting.
    """
    findings: List[Dict] = []
    
    for category, baseline_settings in baseline.items():
        current_category_settings = current_state.get(category, {})
        
        for setting_key, required_value in baseline_settings.items():
            current_value = current_category_settings.get(setting_key)
            
            # CRITICAL: Normalize types (e.g., 0/1 integers vs. "0"/"1" strings) for reliable comparison
            required_str = str(required_value).lower()
            current_str = str(current_value).lower() if current_value is not None else "N/A"
            
            if required_str != current_str:
                finding = {
                    "category": category,
                    "setting": setting_key,
                    "required": required_value,
                    "current": current_value,
                    "status": "FAIL - Non-Compliant"
                }
                findings.append(finding)
            # Note: Compliant checks are implicitly passed and not logged to keep the report focused
                
    return findings

# --- 4. Reporting and Output Generation ---

def generate_audit_report(target: str, findings: List[Dict]) -> str:
    """
    Creates a structured, actionable report in Markdown format.
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    total_checks = sum(len(v) for v in SECURITY_BASELINE.values())
    
    report_lines: List[str] = [
        f"# Configuration Compliance Audit Report",
        f"## Target System: {target}",
        f"## Audit Date: {timestamp}",
        f"---",
        f"Total Checks Performed: {total_checks}",
        f"Total Non-Compliant Findings: {len(findings)}",
        f"Compliance Percentage: {((total_checks - len(findings)) / total_checks) * 100:.2f}%",
        f"---"
    ]
    
    if not findings:
        report_lines.append("\n**SUCCESS:** System is fully compliant with the defined security baseline.")
        return "\n".join(report_lines)
        
    report_lines.append("\n## Detailed Non-Compliance Findings\n")
    
    current_category = ""
    for finding in findings:
        # Group findings by category for readability
        if finding['category'] != current_category:
            report_lines.append(f"\n### Category: {finding['category']}")
            current_category = finding['category']
            
        report_lines.append(f"| Setting: `{finding['setting']}`")
        report_lines.append(f"| Status: **{finding['status']}**")
        report_lines.append(f"| Required Value: `{finding['required']}`")
        report_lines.append(f"| Current Value: `{finding['current']}`")
        report_lines.append(f"| Action Required: Remediate `{finding['setting']}` to match baseline.")
        report_lines.append(f"|") # Separator line
        
    return "\n".join(report_lines)

# --- 5. Main Execution Flow ---

def main_auditor(target_ip: str):
    """
    Orchestrates the data gathering, auditing, and reporting process.
    """
    try:
        # 1. Gather live configuration data from the target
        live_config = simulate_remote_config_gathering(target_ip)
        
        # 2. Perform the audit comparison against the baseline
        audit_findings = perform_compliance_audit(SECURITY_BASELINE, live_config)
        
        # 3. Generate the final report
        report = generate_audit_report(target_ip, audit_findings)
        
        # 4. Output results and save to disk
        report_filename = f"audit_report_{target_ip}_{datetime.now().strftime('%Y%m%d_%H%M')}.md"
        
        with open(report_filename, 'w') as f:
            f.write(report)
            
        print(f"\n[SUCCESS] Audit complete. Report saved to: {report_filename}")
        print("\n" + "="*40 + "\nSUMMARY OUTPUT\n" + "="*40)
        print(report)
        
    except Exception as e:
        print(f"[CRITICAL ERROR] An error occurred during the audit process: {e}")
        
if __name__ == "__main__":
    TARGET_SERVER = "192.168.1.100" # Target IP placeholder
    main_auditor(TARGET_SERVER)

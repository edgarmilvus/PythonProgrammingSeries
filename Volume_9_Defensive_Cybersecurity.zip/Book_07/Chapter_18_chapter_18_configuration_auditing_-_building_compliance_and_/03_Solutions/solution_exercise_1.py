
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import json
from dataclasses import dataclass, field
from typing import Any, Dict, List, Union

# 1. Custom Exception
class InvalidBaselineError(Exception):
    """Raised when the security baseline structure or data types are invalid."""
    pass

# 2. Baseline Structure (using dataclasses for strict definition)
@dataclass
class BaselineItem:
    setting_name: str
    expected_value: Any
    data_type: str
    severity: str
    remediation_steps: str
    # Internal field to store the original value type before coercion
    _original_type: str = field(init=False, repr=False)

# 3. Type Coercion Simulation
def coerce_value(value: str, target_type: str) -> Union[str, int, bool]:
    """Converts a string value to the specified target type."""
    target_type = target_type.lower()
    
    if target_type == 'integer':
        try:
            return int(value)
        except ValueError:
            raise InvalidBaselineError(f"Cannot coerce '{value}' to integer.")
    
    elif target_type == 'boolean':
        # Standard security checks often use 'yes'/'no' or '1'/'0' for bools
        if isinstance(value, str):
            if value.lower() in ('true', 'yes', '1'):
                return True
            elif value.lower() in ('false', 'no', '0'):
                return False
        
        # If it's already a bool, return it
        if isinstance(value, bool):
            return value

        raise InvalidBaselineError(f"Cannot coerce '{value}' to boolean.")
    
    elif target_type == 'string':
        return str(value)
    
    else:
        raise InvalidBaselineError(f"Unsupported data type specified: {target_type}")

# 4. Baseline Loader and Validator
def load_baseline(file_path: str) -> List[BaselineItem]:
    """Simulates loading and validating a baseline from a file path."""
    
    # Simulated JSON data load
    if file_path == "baseline.json":
        raw_baseline_data = [
            {
                "setting_name": "PermitRootLogin",
                "expected_value": "no",
                "data_type": "string",
                "severity": "CRITICAL",
                "remediation_steps": "Set PermitRootLogin no in sshd_config."
            },
            {
                "setting_name": "MaxAuthTries",
                "expected_value": "3", # Note: Stored as string, needs coercion
                "data_type": "integer",
                "severity": "HIGH",
                "remediation_steps": "Reduce MaxAuthTries to 3."
            },
            {
                "setting_name": "X11Forwarding",
                "expected_value": "True", # Stored as string, needs coercion
                "data_type": "boolean",
                "severity": "LOW",
                "remediation_steps": "Disable X11Forwarding."
            }
        ]
    else:
        raise FileNotFoundError(f"Simulated file not found: {file_path}")

    validated_baseline: List[BaselineItem] = []
    required_fields = BaselineItem.__annotations__.keys()

    for i, item_data in enumerate(raw_baseline_data):
        item_name = item_data.get('setting_name', f"Item #{i+1}")
        
        # A. Structural Validation (Check for required keys)
        if not all(field in item_data for field in required_fields if field != '_original_type'):
            missing = [f for f in required_fields if f != '_original_type' and f not in item_data]
            raise InvalidBaselineError(f"Baseline item '{item_name}' is missing required fields: {', '.join(missing)}")

        try:
            # B. Type Coercion for Expected Value
            expected_val_str = item_data['expected_value']
            target_type = item_data['data_type']
            
            # Coerce the expected value to the type it will be compared against
            coerced_value = coerce_value(str(expected_val_str), target_type)

            # C. Create the validated BaselineItem object
            validated_item = BaselineItem(
                setting_name=item_data['setting_name'],
                expected_value=coerced_value,
                data_type=target_type,
                severity=item_data['severity'],
                remediation_steps=item_data['remediation_steps']
            )
            validated_baseline.append(validated_item)

        except InvalidBaselineError as e:
            # Re-raise with context if coercion fails
            raise InvalidBaselineError(f"Validation failed for setting '{item_name}': {e}")

    return validated_baseline

# Demonstration
try:
    baseline = load_baseline("baseline.json")
    print("Baseline loaded and validated successfully.")
    for item in baseline:
        print(f"  {item.setting_name}: Expected type={type(item.expected_value).__name__}, Value={item.expected_value}")
except (InvalidBaselineError, FileNotFoundError) as e:
    print(f"Error during baseline loading: {e}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from typing import Dict, Any, Optional
import contextlib

# 1. Global Context Stack Simulation
# In a real-world scenario (like Flask), this would be thread-local. 
# We use a simple list to simulate the push/pop behavior.
_app_context_stack = []

# 2. Application Class
class AuditApp:
    """Represents the central application object holding configuration."""
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        print(f"AuditApp created for Target ID: {self.config.get('target_id')}")

# 3. Application Context Manager
class AuditAppContext:
    """Manages the lifecycle of the application context."""
    def __init__(self, app: AuditApp):
        self.app = app

    def __enter__(self):
        # Push the application instance onto the global stack
        _app_context_stack.append(self.app)
        return self.app

    def __exit__(self, exc_type, exc_val, exc_tb):
        # Pop the application instance off the global stack
        if _app_context_stack and _app_context_stack[-1] is self.app:
            _app_context_stack.pop()
        else:
            raise RuntimeError("Context stack corrupted or mismatched exit.")

# 4. Application Factory
def create_audit_app(**config_params) -> AuditApp:
    """Initializes and returns a new AuditApp instance."""
    return AuditApp(config_params)

# 5. `current_app` Proxy
def get_current_app() -> AuditApp:
    """Retrieves the application instance from the top of the context stack."""
    if not _app_context_stack:
        raise RuntimeError("No application context is currently active.")
    return _app_context_stack[-1]

# 6. Audit Function Integration
def check_ssh_port():
    """An audit function that relies on the application context."""
    app = get_current_app()
    target_id = app.config['target_id']
    standard = app.config['standard']
    
    # Simulate a check result
    port = 22 # Assume default port
    
    print(f"[{target_id} | {standard}] Checking SSH Port: Port {port} is compliant.")

# --- Execution Flow Demonstration ---

# 1. Create two distinct application instances
app_dev = create_audit_app(target_id='SRV-DEV-05', standard='CIS_L1', logging_level='DEBUG')
app_prod = create_audit_app(target_id='SRV-PROD-01', standard='PCI_DSS', logging_level='INFO')

print("\n--- Running Checks in DEV Context ---")
with AuditAppContext(app_dev):
    check_ssh_port()
    # Check what happens if we access the context directly inside the function
    print(f"Context check: Current app target is {get_current_app().config['target_id']}")

print("\n--- Running Checks in PROD Context ---")
with AuditAppContext(app_prod):
    check_ssh_port()

print("\n--- Checking Context Cleanup ---")
try:
    get_current_app()
except RuntimeError as e:
    print(f"Successfully verified context cleanup: {e}")

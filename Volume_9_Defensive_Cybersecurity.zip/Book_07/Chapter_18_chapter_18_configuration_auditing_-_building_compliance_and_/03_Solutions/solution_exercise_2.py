
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from typing import Callable, Any, List, Dict

# Global list to store audit results (centralized aggregation)
AUDIT_RESULTS: List[Dict[str, Any]] = []

def compliance_check(expected_value: Any, severity: str, setting_name: str) -> Callable:
    """
    Parametrized decorator factory for compliance checking.
    It configures the check before wrapping the function.
    """
    
    # 1. Decorator Factory (Receives parameters)
    def wrapper_outer(func: Callable) -> Callable:
        
        # 2. Wrapper Function Logic (Receives the function to be decorated)
        def wrapper_inner(*args, **kwargs) -> Any:
            
            # Execute the decorated function to get the live configuration
            live_value = func(*args, **kwargs)
            
            is_compliant = (live_value == expected_value)
            
            result = {
                'setting_name': setting_name,
                'compliant': is_compliant,
                'severity': severity,
                'expected_value': expected_value,
                'live_value': live_value,
            }
            
            # Store the result in the global aggregator
            AUDIT_RESULTS.append(result)
            
            # Crucially, return the raw configuration value, 
            # separating audit logging from data retrieval.
            return live_value

        return wrapper_inner
    return wrapper_outer

# --- Application Example ---

# Simulate a data retrieval function for SSH configuration
@compliance_check(expected_value='no', severity='CRITICAL', setting_name='PermitRootLogin')
def get_ssh_root_login_status():
    """Simulates fetching 'yes' from a remote system configuration file."""
    print(f"--- Running data retrieval for PermitRootLogin ---")
    return 'yes' 

@compliance_check(expected_value=3, severity='HIGH', setting_name='MaxAuthTries')
def get_max_auth_tries():
    """Simulates fetching 6 (non-compliant) from a remote system."""
    print(f"--- Running data retrieval for MaxAuthTries ---")
    return 6 

@compliance_check(expected_value=True, severity='LOW', setting_name='UsePAM')
def get_use_pam_status():
    """Simulates fetching True (compliant) from a remote system."""
    print(f"--- Running data retrieval for UsePAM ---")
    return True

# Execution
print("Starting audit checks...")
root_status = get_ssh_root_login_status()
tries_count = get_max_auth_tries()
pam_status = get_use_pam_status()

print(f"\nRaw return values (unaffected by decorator): {root_status}, {tries_count}, {pam_status}")

print("\n--- Aggregated Audit Results (AUDIT_RESULTS) ---")
import pprint
pprint.pprint(AUDIT_RESULTS)

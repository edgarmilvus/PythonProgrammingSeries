
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from typing import Dict, Any, List, Union
import operator

# 1. Configuration Input
LIVE_CONFIG = {
    'IsDMZ': True, 
    'FirewallLogging': 'minimal', 
    'AuditdEnabled': True, 
    'SSHPublicAccess': False,
    'MaxRetries': 5
}

# 2. Policy Structure Definition
COMPLEX_POLICY = {
    "AND": [
        # Rule 1: Must be a DMZ server
        {"setting": "IsDMZ", "operator": "==", "expected": True},
        
        # Rule 2: If DMZ, then either Firewall Logging must be full OR Auditd must be enabled
        {
            "OR": [
                {"setting": "FirewallLogging", "operator": "==", "expected": "full"},
                {"setting": "AuditdEnabled", "operator": "==", "expected": True}
            ]
        },
        
        # Rule 3: Must NOT allow public SSH access
        {"NOT": {"setting": "SSHPublicAccess", "operator": "==", "expected": True}},
        
        # Rule 4: MaxRetries must be less than 6
        {"setting": "MaxRetries", "operator": "<", "expected": 6}
    ]
}

# Mapping string operators to Python's operator functions
OP_MAP = {
    '==': operator.eq,
    '!=': operator.ne,
    '>': operator.gt,
    '<': operator.lt,
    '>=': operator.ge,
    '<=': operator.le,
    'in': lambda a, b: a in b, # Custom lambda for 'in' operator
}

def _evaluate_comparison(rule: Dict[str, Any], config_data: Dict[str, Any]) -> bool:
    """Executes a simple comparison rule against the configuration data."""
    setting = rule['setting']
    op_str = rule['operator']
    expected = rule['expected']

    if setting not in config_data:
        print(f"[Warning] Setting '{setting}' not found in configuration.")
        return False # Assume non-compliant if setting is missing

    live_value = config_data[setting]
    op_func = OP_MAP.get(op_str)

    if not op_func:
        raise ValueError(f"Unsupported operator: {op_str}")

    # Perform the comparison
    result = op_func(live_value, expected)
    print(f"  -> Comparison: {setting} ({live_value}) {op_str} {expected} = {result}")
    return result

# 3. Evaluation Function (Recursive)
def evaluate_policy(policy_rules: Union[Dict, List], config_data: Dict[str, Any]) -> bool:
    """Recursively evaluates the nested policy structure."""

    if isinstance(policy_rules, Dict):
        # Identify the logical operator (AND, OR, NOT)
        if "AND" in policy_rules:
            print("[LOGIC] Applying AND operator...")
            # For AND, all operands must be True
            for rule in policy_rules["AND"]:
                if not evaluate_policy(rule, config_data):
                    print("[RESULT] AND failed (short-circuit).")
                    return False
            return True
        
        elif "OR" in policy_rules:
            print("[LOGIC] Applying OR operator...")
            # For OR, at least one operand must be True
            for rule in policy_rules["OR"]:
                if evaluate_policy(rule, config_data):
                    print("[RESULT] OR succeeded (short-circuit).")
                    return True
            return False
            
        elif "NOT" in policy_rules:
            print("[LOGIC] Applying NOT operator...")
            # For NOT, invert the result of the single operand
            operand = policy_rules["NOT"]
            result = evaluate_policy(operand, config_data)
            print(f"[RESULT] NOT result: {not result}")
            return not result
        
        else:
            # If no logical operator, assume it's a comparison rule
            return _evaluate_comparison(policy_rules, config_data)

    elif isinstance(policy_rules, List):
        # Lists should only appear as values of AND/OR, handled above.
        # This branch is primarily for robustness, though usually unnecessary.
        raise TypeError("Policy rules list found outside of logical operator context.")
        
    else:
        raise TypeError(f"Invalid policy structure element: {policy_rules}")

# Demonstration
print("--- Starting Policy Evaluation ---")
overall_compliance = evaluate_policy(COMPLEX_POLICY, LIVE_CONFIG)

print("\n--- Final Compliance Result ---")
print(f"Overall Policy Compliant: {overall_compliance}")

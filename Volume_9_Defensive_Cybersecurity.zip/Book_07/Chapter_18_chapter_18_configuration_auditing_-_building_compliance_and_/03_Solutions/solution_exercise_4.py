
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from typing import List, Dict, Any, Optional

# 1. Severity Hierarchy Implementation
SEVERITY_RANKS = {
    'CRITICAL': 4,
    'HIGH': 3,
    'MEDIUM': 2,
    'LOW': 1,
    'INFO': 0
}

# 2. Remediation Lookup Table
REMEDIATION_GUIDANCE: Dict[str, str] = {
    'SSH_MAX_AUTH_001': "Detailed Remediation: Edit /etc/ssh/sshd_config. Set MaxAuthTries to 3 or lower. Ensure the service is restarted: systemctl restart sshd.",
    'SSH_ROOT_LOGIN_001': "Detailed Remediation: Locate 'PermitRootLogin' in /etc/ssh/sshd_config and change it to 'no'. This requires a service restart.",
    'PAM_001': "Detailed Remediation: Ensure UsePAM is set to 'yes' to utilize system-wide authentication policies."
}

# Simulated Audit Results (including remediation_key)
SIMULATED_RESULTS = [
    {
        'setting_name': 'MaxAuthTries', 
        'compliant': False, 
        'severity': 'HIGH', 
        'live_value': 10,
        'remediation_key': 'SSH_MAX_AUTH_001' 
    },
    {
        'setting_name': 'PermitRootLogin', 
        'compliant': False, 
        'severity': 'CRITICAL', 
        'live_value': 'yes',
        'remediation_key': 'SSH_ROOT_LOGIN_001' 
    },
    {
        'setting_name': 'UsePAM', 
        'compliant': True, 
        'severity': 'LOW', 
        'live_value': True,
        'remediation_key': 'PAM_001' # Compliant findings still have a key
    },
    {
        'setting_name': 'ClientAliveInterval', 
        'compliant': False, 
        'severity': 'MEDIUM', 
        'live_value': 300,
        'remediation_key': 'N/A' # Missing remediation key example
    }
]

# 3. Enhanced AuditReporter Class
class AuditReporter:
    def __init__(self, results: List[Dict[str, Any]]):
        self.results = results

    def _get_severity_rank(self, severity: str) -> int:
        """Translates severity string to a numerical rank."""
        return SEVERITY_RANKS.get(severity.upper(), -1)

    def generate_report(self, minimum_severity: Optional[str] = None) -> str:
        """
        Generates a filtered report, mapping remediation keys to full guidance.
        Only includes non-compliant findings that meet or exceed the minimum severity.
        """
        report_output = ["\n--- COMPLIANCE AUDIT REPORT ---"]
        
        if minimum_severity:
            min_rank = self._get_severity_rank(minimum_severity)
            report_output.append(f"FILTER APPLIED: Showing findings of {minimum_severity} severity or higher (Rank >= {min_rank}).\n")
        else:
            min_rank = -1 # Include everything if no filter set
            report_output.append("FILTER APPLIED: Showing all non-compliant findings.\n")

        filtered_findings = []
        
        for finding in self.results:
            if finding['compliant']:
                continue # Only report non-compliant issues

            finding_rank = self._get_severity_rank(finding['severity'])
            
            # 4. Severity Filtering Logic
            if finding_rank >= min_rank:
                filtered_findings.append(finding)

        if not filtered_findings:
            report_output.append("No non-compliant findings met the filtering criteria.")
            return "\n".join(report_output)

        # 5. Report Formatting and Remediation Mapping
        for finding in filtered_findings:
            key = finding.get('remediation_key')
            
            remediation_text = REMEDIATION_GUIDANCE.get(key, "Remediation guidance not found for this key.")

            report_output.append("-" * 50)
            report_output.append(f"SETTING: {finding['setting_name']}")
            report_output.append(f"SEVERITY: {finding['severity']} (Rank {self._get_severity_rank(finding['severity'])})")
            report_output.append(f"LIVE VALUE: {finding['live_value']} (Expected: {finding['expected_value']})")
            report_output.append(f"REMEDIATION KEY: {key}")
            report_output.append(f"ACTION REQUIRED:\n{remediation_text}")

        report_output.append("\n--- END OF REPORT ---")
        return "\n".join(report_output)

# Demonstration
reporter = AuditReporter(SIMULATED_RESULTS)

# 1. Generate report showing all findings (implicit minimum_severity=LOW)
print(reporter.generate_report())

# 2. Generate report showing only HIGH and CRITICAL findings
print(reporter.generate_report(minimum_severity='HIGH'))

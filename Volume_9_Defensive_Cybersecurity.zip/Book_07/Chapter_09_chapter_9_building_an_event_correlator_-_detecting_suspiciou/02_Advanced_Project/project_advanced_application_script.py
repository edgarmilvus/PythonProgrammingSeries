
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import time
from datetime import datetime, timedelta
from collections import deque, defaultdict
import random

# --- Core Correlator Engine ---

class CorrelatorEngine:
    """
    Manages event correlation using a sliding time window and persistent state 
    to detect multi-stage attack patterns.
    """
    def __init__(self, window_seconds=60):
        # deque stores raw events for the sliding window (temporal analysis)
        self.event_queue = deque()
        
        # defaultdict stores persistent state (flagged IPs, hit counts) 
        # for stateful correlation across the window.
        self.flagged_ips = defaultdict(lambda: {'recon_hits': 0, 'last_seen': datetime.min})
        
        self.WINDOW = timedelta(seconds=window_seconds)
        self.RECON_THRESHOLD = 5  # Threshold for 404s to flag an IP
        self.BRUTE_FORCE_THRESHOLD = 3 # Threshold for 401s to trigger correlation alert

    def _clean_window(self, current_time):
        """
        Maintains the sliding window by removing events older than the defined window.
        Implements simple state decay for flagged IPs.
        """
        cutoff = current_time - self.WINDOW
        
        # 1. Remove expired events from the queue (O(1) popleft operation)
        while self.event_queue and self.event_queue[0]['timestamp'] < cutoff:
            expired_event = self.event_queue.popleft()
            
            # 2. Simple state decay: if an IP's activity falls outside the window, 
            #    its reconnaissance hit count is decayed or reset.
            ip = expired_event['source_ip']
            if self.flagged_ips[ip]['last_seen'] < cutoff:
                self.flagged_ips[ip]['recon_hits'] = 0
                
    def process_event(self, event):
        """
        Processes a single event, updates the window, and runs correlation rules.
        """
        # Convert raw timestamp to datetime object
        event['timestamp'] = datetime.fromtimestamp(event['timestamp'])
        current_time = event['timestamp']
        
        # Maintain temporal integrity
        self._clean_window(current_time)
        
        # Add the new event to the end of the queue
        self.event_queue.append(event)

        source_ip = event['source_ip']
        event_type = event['event_type']
        alerts = []

        # --- Rule 1: Distributed Reconnaissance Detection (Stateful Thresholding) ---
        if event_type == 'HTTP_404_NOT_FOUND':
            self.flagged_ips[source_ip]['recon_hits'] += 1
            self.flagged_ips[source_ip]['last_seen'] = current_time
            
            # If the IP crosses the threshold, it is "flagged" for future correlation
            if self.flagged_ips[source_ip]['recon_hits'] >= self.RECON_THRESHOLD:
                alerts.append(f"ALERT: Reconnaissance Detected (IP: {source_ip}). High volume of 404s.")

        # --- Rule 2: Targeted Brute Force Correlation (Cross-Event Linking) ---
        if event_type == 'AUTH_401_FAILED_LOGIN':
            # Use dict.get() for safe access, preventing KeyError if target_user is missing
            target_user = event.get('target_user', 'UNKNOWN_USER')
            
            # CRITICAL CORRELATION STEP: Check if this IP is currently flagged by Rule 1
            if self.flagged_ips[source_ip]['recon_hits'] > 0:
                
                # Aggregate failed logins for this specific IP/User combo within the current window
                failed_attempts = [
                    e for e in self.event_queue 
                    if e['source_ip'] == source_ip 
                    and e['event_type'] == 'AUTH_401_FAILED_LOGIN' 
                    and e.get('target_user') == target_user
                ]
                
                if len(failed_attempts) >= self.BRUTE_FORCE_THRESHOLD:
                    alerts.append(f"CRITICAL ALERT: Correlated Attack Detected! "
                                  f"Recon IP ({source_ip}) pivoted to Brute Force on user '{target_user}'.")
                    
                    # Mitigation/Post-Alert Action: Reset state to prevent immediate re-alerting
                    self.flagged_ips[source_ip]['recon_hits'] = 0 

        return alerts

# --- Simulation Setup and Execution ---

def generate_events():
    """Simulates a log stream showing background noise and a two-phase attack."""
    
    # Background noise (random 404s that don't hit the threshold)
    for i in range(1, 5):
        yield {'timestamp': time.time() - random.randint(10, 50), 
               'source_ip': f"192.168.1.{random.randint(10, 20)}", 
               'event_type': 'HTTP_404_NOT_FOUND', 'endpoint': '/api/v1/junk'}

    # Attacker IP and Target
    attacker_ip = "10.0.0.50"
    target_user = "admin_user"
    
    # Phase 1: Reconnaissance (High volume of 404s from attacker_ip)
    print("\n--- Simulation Phase 1: Attacker 10.0.0.50 performs fast reconnaissance ---")
    current_time = time.time()
    for i in range(7): # 7 events > RECON_THRESHOLD (5)
        yield {'timestamp': current_time + i * 0.5, 
               'source_ip': attacker_ip, 
               'event_type': 'HTTP_404_NOT_FOUND', 'endpoint': f'/nonexistent/{i}'}

    # Simulate a pause (e.g., attacker analyzing results)
    time.sleep(2) 
    
    # Phase 2: Targeted Brute Force (401s from the same attacker_ip)
    print("\n--- Simulation Phase 2: Attacker 10.0.0.50 pivots to targeted brute force ---")
    current_time = time.time() + 3 # Ensure time progresses
    for i in range(5): # 5 events > BRUTE_FORCE_THRESHOLD (3)
        yield {'timestamp': current_time + i * 1, 
               'source_ip': attacker_ip, 
               'event_type': 'AUTH_401_FAILED_LOGIN', 
               'target_user': target_user}

    # Simulate events outside the window to test decay
    print("\n--- Simulation Phase 3: Events outside the window ---")
    yield {'timestamp': time.time() + 15, 'source_ip': attacker_ip, 'event_type': 'TEST_DECAY'}


if __name__ == '__main__':
    # Use a short window (10 seconds) for rapid simulation testing
    correlator = CorrelatorEngine(window_seconds=10)
    
    print(f"Starting Correlation Engine with a {correlator.WINDOW.total_seconds()} second window.")
    
    for event in generate_events():
        # Ensure events are processed sequentially in time
        alerts = correlator.process_event(event)
        
        if alerts:
            print("--------------------------------------------------")
            print(f"Event Processed: IP {event['source_ip']} ({event['timestamp'].strftime('%H:%M:%S')}) -> {event['event_type']}")
            for alert in alerts:
                print(f"  [!!!] {alert}")
            print("--------------------------------------------------")
        
        # Simulate real-time stream processing delay
        time.sleep(0.1)

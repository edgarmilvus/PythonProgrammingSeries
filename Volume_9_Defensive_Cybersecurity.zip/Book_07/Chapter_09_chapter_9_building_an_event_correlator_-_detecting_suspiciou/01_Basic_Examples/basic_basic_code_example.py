
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import time
from datetime import datetime, timedelta
from typing import Dict, Any

# --- Configuration & State Definitions ---
TIME_WINDOW_SECONDS = 10 

# Define the explicit states our correlation engine can be in
STATE_START = "INITIAL"
STATE_RECON_DETECTED = "RECON_DETECTED"
STATE_ACCESS_ATTEMPT_DETECTED = "ALERT_TRIGGERED"

class SimpleEventCorrelator:
    """
    Manages stateful detection of sequential events within a sliding time window.
    Rule: Reconnaissance (Type A) followed by Access Attempt (Type B) within 10 seconds.
    """
    
    def __init__(self, window_seconds: int = TIME_WINDOW_SECONDS):
        # active_correlations stores the state for every IP currently being tracked.
        # Key: Source IP (str) -> Value: State data dictionary
        # State Data: {'state': str, 'last_ts': float (epoch time)}
        self.active_correlations: Dict[str, Dict[str, Any]] = {}
        
        # Use timedelta for robust time comparisons
        self.window = timedelta(seconds=window_seconds)

    def _cleanup_expired_states(self):
        """
        Iterates through active states and removes any that have exceeded 
        the defined time window, preventing memory bloat and stale data.
        """
        current_time = datetime.now()
        expired_ips = []
        
        # Identify expired entries first
        for ip, data in self.active_correlations.items():
            # Convert stored epoch timestamp back to a datetime object
            last_event_time = datetime.fromtimestamp(data['last_ts'])
            
            # Check if the duration since the last event exceeds the window
            if current_time - last_event_time > self.window:
                expired_ips.append(ip)

        # Remove the expired entries
        for ip in expired_ips:
            # Safely remove the key and print a notification
            print(f"[CLEANUP] State expired for IP: {ip}. Removing state.")
            self.active_correlations.pop(ip)

    def process_event(self, event: Dict[str, str]) -> bool:
        """
        Processes a single log event and applies the correlation rule engine logic.
        Returns True if the full attack sequence (alert) is detected.
        """
        self._cleanup_expired_states() # Step 1: Maintenance

        source_ip = event.get('src_ip')
        event_type = event.get('type')
        current_ts = time.time()
        
        if not source_ip or not event_type:
            # Use dict.get() prevents KeyError if 'src_ip' or 'type' is missing
            return False 

        # 2. Retrieve current state for this IP.
        # Use dict.get() with a default value to initialize tracking if the IP is new.
        current_state_data = self.active_correlations.get(source_ip, 
                                                          {'state': STATE_START, 'last_ts': current_ts})
        
        current_state = current_state_data['state']
        last_ts = current_state_data['last_ts']
        
        # --- State Transition Logic (The Rule Engine) ---
        
        # A. Handling the INITIAL state
        if current_state == STATE_START:
            if event_type == "RECON_SCAN":
                print(f"[{source_ip}] State Change: INITIAL -> RECON_DETECTED. Starting correlation window.")
                # Store the new state and the current timestamp
                self.active_correlations[source_ip] = {
                    'state': STATE_RECON_DETECTED,
                    'last_ts': current_ts
                }
            return False

        # B. Handling the RECON_DETECTED state
        elif current_state == STATE_RECON_DETECTED:
            
            time_diff = current_ts - last_ts
            
            # Check 1: Time Window Enforcement
            if time_diff > self.window.total_seconds():
                # If the time elapsed is too long, the sequence is broken.
                print(f"[{source_ip}] Time window expired ({time_diff:.2f}s). Resetting state.")
                
                # Reset the IP's state back to INITIAL, tracking the current event as the new start
                self.active_correlations[source_ip] = {
                    'state': STATE_START, 
                    'last_ts': current_ts
                }
                # Since the sequence failed, return False
                return False
            
            # Check 2: Sequence Completion (within the window)
            if event_type == "ACCESS_ATTEMPT":
                print(f"\n!!! ALERT TRIGGERED !!! [{source_ip}] Detected: Recon followed by Access Attempt in {time_diff:.2f}s.")
                
                # Transition to the final alert state
                self.active_correlations[source_ip]['state'] = STATE_ACCESS_ATTEMPT_DETECTED
                
                return True
            
            # Check 3: State Extension (Sliding Window)
            elif event_type == "RECON_SCAN":
                # If the IP performs another reconnaissance scan, we extend the time window 
                # from this new event, allowing for continuous scanning activity.
                print(f"[{source_ip}] Extending Recon window (Sliding Window concept).")
                self.active_correlations[source_ip]['last_ts'] = current_ts
                return False
            
            # If the event is neither an ACCESS_ATTEMPT nor RECON_SCAN, we ignore it 
            # and maintain the current RECON_DETECTED state.
            return False

        # C. Handling ALERT_TRIGGERED state (e.g., waiting for manual cleanup or auto-timeout)
        elif current_state == STATE_ACCESS_ATTEMPT_DETECTED:
            # We ignore further events for this IP until the state is cleaned up.
            return False 

        return False # Default return for unhandled states/events

# --- Simulation Setup ---
correlator = SimpleEventCorrelator(window_seconds=8) # Use 8s for demonstration speed

print(f"--- Starting Simulation with {correlator.window.total_seconds()} second window ---")

# 1. Start the sequence
event1 = {'src_ip': '192.168.1.10', 'type': 'RECON_SCAN', 'payload': 'Nmap scan'}
print("\n[T=0s] Processing Event 1 (Reconnaissance)")
correlator.process_event(event1)
print(f"Active States: {correlator.active_correlations}")

# 2. Benign noise event (should not affect 192.168.1.10)
event2 = {'src_ip': '10.0.0.5', 'type': 'HTTP_GET', 'payload': 'Normal request'}
print("\n[T=0s] Processing Event 2 (Noise)")
correlator.process_event(event2)

# 3. Time passes (within the window)
time.sleep(3) 

# 4. Trigger event (completes the sequence)
event3 = {'src_ip': '192.168.1.10', 'type': 'ACCESS_ATTEMPT', 'payload': 'Failed login attempt'}
print("\n[T=3s] Processing Event 3 (Access Attempt)")
alert_status = correlator.process_event(event3)
print(f"Alert Status: {alert_status}")

# 5. Show final state after alert
print("\n--- Current Active Correlations After Alert ---")
print(correlator.active_correlations)

# --- Testing Time Window Expiration and Cleanup ---

# 6. Start a new sequence
event4 = {'src_ip': '172.16.0.2', 'type': 'RECON_SCAN', 'payload': 'New IP scan'}
print("\n[T=3s] Processing Event 4 (New Recon)")
correlator.process_event(event4)

# 7. Pause for longer than the 8 second window (e.g., 9 seconds)
print("\n[T=3s -> T=12s] Waiting 9 seconds to expire the window for 172.16.0.2...")
time.sleep(9) 

# 8. Process the cleanup (this happens implicitly when the next event is processed)
event5 = {'src_ip': '172.16.0.2', 'type': 'ACCESS_ATTEMPT', 'payload': 'Delayed login attempt'}
print("\n[T=12s] Processing Event 5 (Delayed Access Attempt)")
alert_status_expired = correlator.process_event(event5)
print(f"Alert Status: {alert_status_expired}")
print("\n--- Final State After Expiration ---")
print(correlator.active_correlations)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import time
from typing import Dict, Any, List

WINDOW_SECONDS = 30 * 60 

# 1. Rule Definition Structure
LATERAL_MOVEMENT_RULE = {
    "name": "Lateral_Movement_Sequence",
    "window": WINDOW_SECONDS,
    "stages": [
        {"stage": 1, "event_type": "NET_SCAN_SUCCESS", "link_fields": ["source_ip", "target_host"]},
        {"stage": 2, "event_type": "AUTH_FAIL", "link_fields": ["source_ip", "target_host"]},
        {"stage": 3, "event_type": ["RDP_SUCCESS", "SSH_SUCCESS"], "link_fields": ["source_ip", "target_host"]}
    ]
}

def generate_sequence_key(event: Dict[str, Any]) -> str:
    """Helper Function: Generates a deterministic key based on linking fields."""
    src = event.get('source_ip', 'UNKNOWN_SRC')
    tgt = event.get('target_host', 'UNKNOWN_TGT')
    return f"{src}_{tgt}"

class SequenceCorrelator:
    def __init__(self, rule: Dict):
        self.rule = rule
        # Key: unique_sequence_key -> Value: State tracking dict
        self.pending_sequences: Dict[str, Dict] = {}

    def _prune_expired_sequences(self):
        """Purges sequences whose starting event is older than the rule window."""
        current_time = time.time()
        timeout_limit = current_time - self.rule['window']
        
        expired_keys = [
            key for key, state in self.pending_sequences.items() 
            if state['start_time'] < timeout_limit
        ]
        
        for key in expired_keys:
            del self.pending_sequences[key]

    def process_event(self, event: Dict[str, Any]) -> Dict[str, Any] | None:
        self._prune_expired_sequences()
        event_type = event.get('event_type')
        key = generate_sequence_key(event)
        
        # --- Stage 1 Check: Initialization ---
        stage_1_type = self.rule['stages'][0]['event_type']
        if event_type == stage_1_type:
            # Start a new sequence
            self.pending_sequences[key] = {
                'current_stage': 1,
                'start_time': event['timestamp'],
                'events': [event]
            }
            return None

        # --- Check Active Sequences for Advancement ---
        if key in self.pending_sequences:
            current_state = self.pending_sequences[key]
            next_stage_index = current_state['current_stage'] # Stage 1 -> Index 1 (Stage 2)
            
            if next_stage_index >= len(self.rule['stages']):
                return None
            
            target_stage_def = self.rule['stages'][next_stage_index]
            target_event_types = target_stage_def['event_type']
            
            if not isinstance(target_event_types, list):
                target_event_types = [target_event_types]
            
            if event_type in target_event_types:
                # Advance state
                current_state['current_stage'] += 1
                current_state['events'].append(event)

                # Check for Completion
                if current_state['current_stage'] == len(self.rule['stages']):
                    del self.pending_sequences[key]
                    return {
                        "alert_type": self.rule['name'],
                        "sequence_key": key,
                        "duration": event['timestamp'] - current_state['start_time'],
                        "events": current_state['events']
                    }
        
        return None

# Simulation Example
if __name__ == '__main__':
    correlator = SequenceCorrelator(LATERAL_MOVEMENT_RULE)
    start_t = time.time()
    
    # 1. Stage 1
    e1 = {'timestamp': start_t + 10, 'source_ip': '172.16.0.10', 'target_host': 'ServerB', 'event_type': 'NET_SCAN_SUCCESS'}
    correlator.process_event(e1)
    
    # 2. Stage 2
    e2 = {'timestamp': start_t + 60, 'source_ip': '172.16.0.10', 'target_host': 'ServerB', 'event_type': 'AUTH_FAIL'}
    correlator.process_event(e2)
    
    # 3. Stage 3 (RDP)
    e3 = {'timestamp': start_t + 120, 'source_ip': '172.16.0.10', 'target_host': 'ServerB', 'event_type': 'RDP_SUCCESS'}
    alert = correlator.process_event(e3)
    
    if alert:
        print(f"[SUCCESS] Correlation Alert Triggered: {alert['alert_type']}")
        print(f"Sequence Duration: {alert['duration']:.2f} seconds.")

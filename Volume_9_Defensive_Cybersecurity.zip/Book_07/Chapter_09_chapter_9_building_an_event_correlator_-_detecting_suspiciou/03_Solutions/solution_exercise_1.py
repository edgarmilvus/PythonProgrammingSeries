
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import time
from typing import Dict, List, Any

WINDOW_SECONDS = 60
THRESHOLD = 10

class BruteForceTracker:
    """Tracks failed events per IP within a sliding time window."""
    def __init__(self):
        # Maps source_ip (str) -> list of timestamps (float)
        self.ip_history: Dict[str, List[float]] = {}

    def update_history(self, log_entry: Dict[str, Any]):
        source_ip = log_entry['source_ip']
        timestamp = log_entry['timestamp']
        
        # Safe Access Implementation: 
        # Using dict.get() avoids raising a KeyError if the IP is new, 
        # initializing it with an empty list instead. This is superior to try/except 
        # or explicit 'if not in' checks in high-volume environments as exception 
        # handling incurs significant overhead.
        history_list = self.ip_history.get(source_ip, [])
        
        # Append new event
        history_list.append(timestamp)
        
        # Window Maintenance Logic (Pruning)
        cutoff_time = timestamp - WINDOW_SECONDS
        
        # Find the index of the first non-expired timestamp
        i = 0
        while i < len(history_list) and history_list[i] < cutoff_time:
            i += 1
        
        # Slice the list to keep only the valid timestamps (in the window)
        self.ip_history[source_ip] = history_list[i:]

    def check_threshold(self, source_ip: str) -> Dict[str, Any] | None:
        """Determines if the event count exceeds the defined threshold."""
        history_list = self.ip_history.get(source_ip)
        
        if history_list and len(history_list) >= THRESHOLD:
            return {
                "alert_type": "BRUTE_FORCE_ATTACK",
                "source_ip": source_ip,
                "event_count": len(history_list),
                "window_seconds": WINDOW_SECONDS,
                "timestamp": time.time()
            }
        return None

# Simulation Loop
if __name__ == '__main__':
    tracker = BruteForceTracker()
    current_time = time.time()
    
    # Simulate 100 log entries
    for i in range(1, 101):
        # Simulate a burst of failed logins from '10.0.0.5' between events 10 and 25
        ip = '10.0.0.5' if 10 <= i <= 25 else '192.168.1.1'
        
        log = {
            'timestamp': current_time + (i * 0.1), # Events arrive quickly
            'source_ip': ip,
            'event_type': 'LOGIN_FAIL'
        }
        
        tracker.update_history(log)
        alert = tracker.check_threshold(log['source_ip'])
        
        if alert:
            print(f"[ALERT] {alert['source_ip']} detected with {alert['event_count']} attempts.")
            # Stop tracking this IP temporarily in simulation to avoid spam
            del tracker.ip_history[log['source_ip']] 

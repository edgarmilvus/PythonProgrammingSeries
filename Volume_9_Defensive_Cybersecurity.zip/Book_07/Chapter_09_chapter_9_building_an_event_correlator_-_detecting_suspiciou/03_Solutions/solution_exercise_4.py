
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import asyncio
import time
import random
from typing import Dict, Any, List

# Shared mutable object for configuration
class DynamicConfig:
    def __init__(self):
        self.config = {
            "whitelisted_ips": ["127.0.0.1"],
            "threshold": 10
        }
    def set_config(self, config_data: Dict[str, Any]):
        self.config.update(config_data)

# Enhanced Tracker with Suppression
class EnhancedBruteForceTracker:
    def __init__(self, config: DynamicConfig):
        self.ip_history: Dict[str, List[float]] = {}
        # Maps IP -> suppression end timestamp (float)
        self.suppression_list: Dict[str, float] = {}
        self.config = config # Reference to the shared config object

    def _prune_history(self, source_ip, current_time):
        history_list = self.ip_history.get(source_ip, [])
        cutoff_time = current_time - (60 * 5) # 5 minute window
        i = 0
        while i < len(history_list) and history_list[i] < cutoff_time:
            i += 1
        self.ip_history[source_ip] = history_list[i:]

    def process_event(self, event: Dict[str, Any]) -> Dict[str, Any] | None:
        source_ip = event['source_ip']
        current_time = event['timestamp']
        
        # 4. Whitelisting Integration: Check dynamic config before processing
        if source_ip in self.config.config.get("whitelisted_ips", []):
            return None 

        self._prune_history(source_ip, current_time)
        
        history_list = self.ip_history.get(source_ip, [])
        history_list.append(current_time)
        self.ip_history[source_ip] = history_list

        # 2. Suppression Logic Integration: Check if currently suppressed
        suppression_end = self.suppression_list.get(source_ip, 0.0)
        if current_time < suppression_end:
            return None # Alert dropped silently

        # Detection Logic (using dynamic threshold)
        threshold = self.config.config.get("threshold", 10)
        if len(history_list) >= threshold:
            alert = {"alert_type": "HIGH_VOLUME", "source_ip": source_ip, "count": len(history_list)}
            
            # 2. Apply Suppression (30 minutes)
            SUPPRESSION_DURATION = 30 * 60
            self.suppression_list[source_ip] = current_time + SUPPRESSION_DURATION
            
            return alert
        return None

# 3. Dynamic Configuration Loader (Asynchronous)
async def config_reloader(shared_config: DynamicConfig):
    while True:
        try:
            await asyncio.sleep(5) # Check config every 5 seconds
            
            # Simulate fetching new configuration
            new_threshold = random.randint(8, 15)
            # Whitelist '10.0.0.5' 30% of the time
            whitelist = ["127.0.0.1"]
            if random.random() < 0.3:
                 whitelist.append("10.0.0.5")
                 
            new_config = {"whitelisted_ips": whitelist, "threshold": new_threshold}
            
            shared_config.set_config(new_config)
            print(f"\n[Config Reloader] Updated: Threshold={new_threshold}, Whitelist={whitelist}")
            
        except asyncio.CancelledError:
            break

# Simplified Producer/Consumer Tasks (using ATTACKER_IP = '10.0.0.5')
async def log_producer(queue: asyncio.Queue):
    while True:
        await asyncio.sleep(random.uniform(0.005, 0.01))
        ip = '10.0.0.5' if random.random() < 0.2 else f"10.0.0.{random.randint(1, 10)}"
        log = {'timestamp': time.time(), 'source_ip': ip, 'event_type': 'TEST_EVENT'}
        await queue.put(log)

async def correlator_consumer_e4(queue: asyncio.Queue, tracker: EnhancedBruteForceTracker):
    while True:
        try:
            event = await queue.get()
            alert = tracker.process_event(event)
            if alert:
                print(f"\n*** ALERT *** IP: {alert['source_ip']} suppressed until {time.ctime(tracker.suppression_list.get(alert['source_ip']))}")
            queue.task_done()
        except asyncio.CancelledError:
            break

async def main_e4():
    shared_config = DynamicConfig()
    tracker = EnhancedBruteForceTracker(shared_config)
    stream_queue = asyncio.Queue()
    
    producer_task = asyncio.create_task(log_producer(stream_queue))
    consumer_task = asyncio.create_task(correlator_consumer_e4(stream_queue, tracker))
    reloader_task = asyncio.create_task(config_reloader(shared_config))

    await asyncio.sleep(20)
    
    # Shutdown logic...
    for task in [producer_task, reloader_task]: task.cancel()
    await asyncio.gather(producer_task, reloader_task, return_exceptions=True)
    await stream_queue.join()
    consumer_task.cancel()
    await asyncio.gather(consumer_task, return_exceptions=True)

if __name__ == '__main__':
    # asyncio.run(main_e4())
    pass


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import time
from collections import deque
from typing import Dict, Any, Deque, Tuple

WINDOW_SECONDS = 60
THRESHOLD = 10

class OptimizedBruteForceTracker:
    def __init__(self):
        # Maps source_ip -> deque of (timestamp, event_id)
        self.ip_history: Dict[str, Deque[Tuple[float, int]]] = {}
        self._event_counter = 0

    def _prune_expired(self, source_ip: str, current_time: float):
        """
        Optimized pruning using deque.popleft().
        This operation is O(1) for each item removed, making it highly efficient.
        """
        history_deque = self.ip_history.get(source_ip)
        if not history_deque:
            return

        cutoff_time = current_time - WINDOW_SECONDS
        
        # Remove elements from the left (oldest) end until the first element is valid
        while history_deque and history_deque[0][0] < cutoff_time:
            history_deque.popleft()

    def update_history(self, log_entry: Dict[str, Any]):
        source_ip = log_entry['source_ip']
        timestamp = log_entry['timestamp']
        self._event_counter += 1
        
        history_deque = self.ip_history.get(source_ip)
        if history_deque is None:
            history_deque = deque()
            self.ip_history[source_ip] = history_deque
            
        # Append new event to the right (O(1))
        history_deque.append((timestamp, self._event_counter))
        
        # Prune immediately
        self._prune_expired(source_ip, timestamp)

    def check_threshold(self, source_ip: str) -> Dict[str, Any] | None:
        """Threshold check is O(1) as it relies on calculating the length of the deque."""
        history_deque = self.ip_history.get(source_ip)
        
        if history_deque and len(history_deque) >= THRESHOLD:
            return {
                "alert_type": "BRUTE_FORCE_ATTACK_OPTIMIZED",
                "source_ip": source_ip,
                "event_count": len(history_deque),
                "timestamp": time.time()
            }
        return None

# Performance Rationale (in comments/docstrings)
"""
Performance Rationale:
Standard Python lists are implemented as dynamic arrays. When using list.pop(0) 
or slicing from the beginning (list[i:]), the entire array of subsequent elements 
must be shifted in memory. This makes list pruning O(N) where N is the size 
of the list remaining after the deletion.

collections.deque (double-ended queue) is optimized for appending and popping 
from both ends (left and right). Using deque.popleft() for pruning is an O(1) 
operation, regardless of the size of the deque. Therefore, for time window 
management where old elements are always removed from the front (left) and new 
elements are added to the back (right), deque provides superior performance 
compared to a standard list, especially when event history lists grow very large.
"""

if __name__ == '__main__':
    tracker = OptimizedBruteForceTracker()
    current_time = time.time()
    
    # Simulate 12 events arriving quickly for a single IP
    ip_to_track = '203.0.113.42'
    for i in range(12):
        log = {'timestamp': current_time + (i * 0.1), 'source_ip': ip_to_track}
        tracker.update_history(log)
        
    alert = tracker.check_threshold(ip_to_track)
    if alert:
        print(f"[OPTIMIZED ALERT] Detected {alert['source_ip']} with {alert['event_count']} events.")
    
    # Simulate time passing (70 seconds)
    future_time = current_time + 70
    tracker._prune_expired(ip_to_track, future_time)
    
    # Check count after pruning
    final_count = len(tracker.ip_history.get(ip_to_track, []))
    print(f"Count after 70 seconds elapsed: {final_count}") # Should be 0


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import asyncio
import time
import random
from typing import Dict, Any

# Simple synchronous tracker used inside the async consumer
class SimpleTracker:
    def __init__(self):
        self.counts = {}
    def process_event(self, event):
        ip = event['source_ip']
        # Simple threshold check
        self.counts[ip] = self.counts.get(ip, 0) + 1
        if self.counts[ip] > 5 and self.counts[ip] < 7: # Only alert once
            return {"alert": True, "ip": ip}
        return None

# 1. Asynchronous Context Manager
class LogStreamSimulator:
    def __init__(self, stream_name: str):
        self.stream_name = stream_name

    async def __aenter__(self):
        print(f"[{self.stream_name}] Connecting to log source...")
        shared_queue = asyncio.Queue()
        await asyncio.sleep(0.1)
        print(f"[{self.stream_name}] Connection established.")
        return shared_queue

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        # Guarantees resource cleanup (e.g., closing network sockets, flushing data)
        # even if an exception (exc_type is not None) occurs during the 'with' block.
        if exc_type:
            print(f"[{self.stream_name}] Exception caught: {exc_val}")
        print(f"[{self.stream_name}] Disconnecting and cleaning up resources.")
        await asyncio.sleep(0.1)
        print(f"[{self.stream_name}] Disconnection complete.")
        return False # Do not suppress exceptions

# 2. Asynchronous Producer Tasks
async def firewall_log_producer(queue: asyncio.Queue):
    while True:
        await asyncio.sleep(random.uniform(0.005, 0.02))
        log = {
            'timestamp': time.time(),
            'source_ip': f"192.168.0.{random.randint(1, 254)}",
            'event_type': 'FIREWALL_DENY',
        }
        await queue.put(log)

async def auth_log_producer(queue: asyncio.Queue):
    # Simulate an attacking IP (8.8.8.8)
    while True:
        await asyncio.sleep(random.uniform(0.005, 0.015))
        ip = '8.8.8.8' if random.random() < 0.1 else f"10.0.0.{random.randint(1, 100)}"
        log = {
            'timestamp': time.time(),
            'source_ip': ip,
            'event_type': 'LOGIN_ATTEMPT',
        }
        await queue.put(log)

# 3. The Correlator Consumer Task
async def correlator_consumer(queue: asyncio.Queue, tracker: SimpleTracker):
    processed_count = 0
    while True:
        try:
            event = await queue.get()
            alert = tracker.process_event(event)
            if alert:
                print(f"--- CONSUMER ALERT: High volume from {alert['ip']} ---")
            
            queue.task_done()
            processed_count += 1
            
        except asyncio.CancelledError:
            # Graceful exit upon cancellation
            print(f"[Consumer] Task cancelled. Processed {processed_count} events.")
            break

# 4. Task Management and Futures
async def main():
    tracker = SimpleTracker()
    
    async with LogStreamSimulator("Shared Stream") as shared_queue:
        
        # Create tasks (Futures)
        producer_fw_task = asyncio.create_task(firewall_log_producer(shared_queue))
        producer_auth_task = asyncio.create_task(auth_log_producer(shared_queue))
        consumer_task = asyncio.create_task(correlator_consumer(shared_queue, tracker))

        producers = [producer_fw_task, producer_auth_task]
        
        print("\n--- Correlation Engine Running (10 seconds) ---\n")
        await asyncio.sleep(10)
        
        # Controlled Shutdown
        print("\n--- Initiating Controlled Shutdown ---")
        
        # Cancel producers
        for task in producers:
            task.cancel()
        
        # Wait for producers to finish (using gather)
        await asyncio.gather(*producers, return_exceptions=True)
        
        # Wait for the consumer to finish processing everything currently in the queue
        await shared_queue.join() 
        
        # Cancel consumer task
        consumer_task.cancel()
        await asyncio.gather(consumer_task, return_exceptions=True)
        
        print("--- Shutdown Complete ---")

if __name__ == '__main__':
    # asyncio.run(main())
    pass

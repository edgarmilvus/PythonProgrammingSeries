
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import json
import re
import logging
from datetime import datetime
import sys

# --- 1. Secure Logging Setup ---
# Configure logging to a secure file location for internal audit and debugging.
# This file must NOT be accessible by the external system or client.
LOG_FILE = "secure_processing_errors.log"
logging.basicConfig(
    level=logging.ERROR,
    format='%(asctime)s - %(levelname)s - %(funcName)s - %(message)s',
    filename=LOG_FILE,
    filemode='a'
)

# --- 2. Custom Secure Exceptions ---
class UserFacingError(Exception):
    """Base class for anticipated errors. Only the message is shown to the user."""
    pass

class ValidationError(UserFacingError):
    """Specific error for failed input checks (e.g., wrong type, bad range)."""
    pass

class ProcessingError(UserFacingError):
    """Specific error for controlled internal operational failures."""
    pass

# --- 3. Input Validation and Sanitization Logic ---

def sanitize_input_value(value):
    """
    Sanitizes a single input value, primarily targeting string inputs for neutralization.
    This step ensures the data is safe for eventual storage or display.
    """
    if isinstance(value, str):
        # 1. Strip external whitespace to normalize input
        value = value.strip()
        
        # 2. Basic neutralization for HTML context (prevents simple XSS if displayed)
        # This is a crucial defense-in-depth step.
        value = value.replace('<', '&lt;').replace('>', '&gt;')
        
        # 3. Enforce maximum reasonable length to prevent buffer overflows or DoS via large inputs
        MAX_LEN = 128
        if len(value) > MAX_LEN:
            logging.error(f"Input value exceeds length limit ({MAX_LEN}): {len(value)}")
            raise ValidationError(f"Input string exceeds maximum length of {MAX_LEN} characters.")
        return value
    
    # Non-string types (int, bool) are returned unchanged, as their type/range is checked later.
    return value

def validate_config_schema(config_data: dict) -> dict:
    """
    Strictly validates the structure, types, and constraints using a whitelisting approach.
    """
    REQUIRED_KEYS = {'username', 'port', 'is_enabled'}
    
    # 1. Whitelist Keys: Strict check to ensure NO extra data is processed (prevents mass assignment)
    if set(config_data.keys()) != REQUIRED_KEYS:
        # Log the malicious or malformed attempt internally
        logging.error(f"Schema mismatch detected. Received keys: {set(config_data.keys())}")
        raise ValidationError("Configuration schema is invalid or contains unexpected fields.")
        
    validated_data = {}
    
    # 2. Validate 'username' (String, Alphanumeric, Length check)
    username = config_data.get('username')
    # Use fullmatch for strict start-to-end matching.
    if not isinstance(username, str) or not re.fullmatch(r'^[a-zA-Z0-9_-]{3,30}$', username):
        raise ValidationError("Username format is strictly alphanumeric (3-30 chars).")
    
    # Sanitization applied after format validation
    validated_data['username'] = sanitize_input_value(username)
    
    # 3. Validate 'port' (Integer, Range check)
    port = config_data.get('port')
    if not isinstance(port, int) or not (1024 <= port <= 65535):
        raise ValidationError("Port must be an integer between 1024 (reserved) and 65535.")
    validated_data['port'] = port
    
    # 4. Validate 'is_enabled' (Boolean, Strict type check)
    is_enabled = config_data.get('is_enabled')
    if not isinstance(is_enabled, bool):
        raise ValidationError("is_enabled must be a strict boolean value (True/False).")
    validated_data['is_enabled'] = is_enabled
    
    return validated_data

# --- 4. Main Processing Function with Secure Error Handling ---

def process_user_config(raw_input_data):
    """
    The main security pipeline entry point.
    """
    # Ensure input is string-like before attempting JSON decoding
    if not isinstance(raw_input_data, str):
        # Treat non-string input as an immediate, critical failure
        logging.critical(f"Input type failure: Expected string, got {type(raw_input_data)}.")
        print(f"[{datetime.now().strftime('%H:%M:%S')}] ERROR (Internal): System integrity check failed.")
        return None

    try:
        # A. Input Parsing (Initial Check)
        try:
            config_data = json.loads(raw_input_data)
        except json.JSONDecodeError as e:
            # Log the specific failure internally
            logging.error(f"JSON Parsing failed: {e}")
            # Raise a generic, user-safe error
            raise ValidationError("Input data is not valid JSON format.")
            
        # B. Strict Validation and Sanitization
        processed_data = validate_config_schema(config_data)
        
        # C. Simulated Internal Operation
        # This simulates interaction with a database or system resource that might fail.
        if processed_data['port'] == 8080:
            # Raise a controlled, known internal failure
            logging.warning(f"Port 8080 conflict detected for user {processed_data['username']}.")
            raise ProcessingError("Requested port is currently reserved. Operation aborted.")
            
        # D. Success
        print(f"[{datetime.now().strftime('%H:%M:%S')}] SUCCESS: Configuration accepted for user: {processed_data['username']}")
        return processed_data
        
    except UserFacingError as e:
        # 1. Controlled Exception Handling: Catch custom, safe errors
        # The message stored in 'e' is deemed safe to show the user.
        print(f"[{datetime.now().strftime('%H:%M:%S')}] ERROR (Client): {e}")
        return None
        
    except Exception as e:
        # 2. Catch-All Fatal Handler: Catch unexpected system errors
        # Log the full traceback and error details internally for forensics
        logging.critical(f"UNEXPECTED FATAL ERROR during processing: {e}", exc_info=True)
        # Return a completely generic, non-specific message to the user (prevents information leakage)
        print(f"[{datetime.now().strftime('%H:%M:%S')}] ERROR (Internal): A critical system fault occurred.")
        return None

# --- 5. Execution Simulation (Test Cases) ---

# Case 1: Valid and safe input
safe_input = '{"username": "dev_user_123", "port": 443, "is_enabled": true}'
process_user_config(safe_input)

# Case 2: Validation Failure (Invalid port range)
bad_port_input = '{"username": "admin", "port": 80, "is_enabled": true}'
process_user_config(bad_port_input)

# Case 3: Format Failure (Username containing injection characters)
bad_username_input = '{"username": "user; drop table users;", "port": 8081, "is_enabled": false}'
process_user_config(bad_username_input)

# Case 4: Schema Failure (Extra, unwhitelisted key added)
extra_key_input = '{"username": "safe_user", "port": 8081, "is_enabled": true, "secret_key": "abc"}'
process_user_config(extra_key_input)

# Case 5: Internal Processing Failure (Simulated controlled error)
internal_failure_input = '{"username": "conflict_user", "port": 8080, "is_enabled": true}'
process_user_config(internal_failure_input)

# Case 6: Fatal/Unexpected Error (Simulated by passing non-string data)
# process_user_config(12345)

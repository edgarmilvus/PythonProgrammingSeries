
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import re

# Rationale: For complex HTML sanitization, dedicated libraries (like Bleach) 
# are preferred over manual string replacement or regex due to the difficulty 
# of securely parsing nested or malformed HTML structures. This manual implementation 
# demonstrates the core principle of 'Escape Everything, then Whitelist Back.'

def escape_html(data: str) -> str:
    """Converts standard HTML control characters to their entities."""
    data = data.replace('&', '&amp;')
    data = data.replace('<', '&lt;')
    data = data.replace('>', '&gt;')
    data = data.replace('"', '&quot;')
    data = data.replace("'", '&#x27;')
    return data

def sanitize_user_comment(comment_text: str) -> str:
    """
    Applies strict whitelisting for <b> and <i> tags by reversing escaping 
    only for the literal tag structures.
    """

    # 1. Escape the entire input string (Neutralize all potential HTML/XSS)
    escaped_text = escape_html(comment_text)

    # 2. Re-introduce the whitelisted tags (only if they contain no attributes)
    
    # Opening tags
    escaped_text = escaped_text.replace('&lt;b&gt;', '<b>')
    escaped_text = escaped_text.replace('&lt;i&gt;', '<i>')

    # Closing tags
    escaped_text = escaped_text.replace('&lt;/b&gt;', '</b>')
    escaped_text = escaped_text.replace('&lt;/i&gt;', '</i>')

    # Since any tag containing attributes (e.g., <b id=1>) or other tags 
    # (e.g., <script>) will have been fully escaped in step 1 
    # (e.g., &lt;script&gt;), and step 2 only reverses exact matches, 
    # all dangerous content remains neutralized.
    
    return escaped_text

# Test cases demonstrating mitigation
malicious_input_1 = "<script>steal_cookie()</script><b>Hello</b>"
malicious_input_2 = 'A comment with allowed <b>bold</b> text and a sneaky <img src=x onerror=alert(1)> tag.'
malicious_input_3 = 'Incomplete tag <b and text. Also <i class="bad">.'
malicious_input_4 = 'Valid <i>Italic</i> and <b>Bold</b>.'

print("--- Test 1 (Script Injection) ---")
print(f"Sanitized: {sanitize_user_comment(malicious_input_1)}") 
# Expected: &lt;script&gt;steal_cookie()&lt;/script&gt;<b>Hello</b>

print("\n--- Test 2 (Attribute Injection) ---")
print(f"Sanitized: {sanitize_user_comment(malicious_input_2)}") 
# Expected: ...&lt;img src=x onerror=alert(1)&gt; tag.

print("\n--- Test 3 (Malformed Tag/Attributes) ---")
print(f"Sanitized: {sanitize_user_comment(malicious_input_3)}")
# Expected: ...&lt;b and text. Also &lt;i class=&quot;bad&quot;&gt;.

print("\n--- Test 4 (Valid Input) ---")
print(f"Sanitized: {sanitize_user_comment(malicious_input_4)}")
# Expected: Valid <i>Italic</i> and <b>Bold</b>.


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import logging
import sys

# Configure basic logging to ensure output is visible
logging.basicConfig(
    level=logging.INFO, 
    format='%(asctime)s - %(levelname)s - %(message)s',
    stream=sys.stdout 
)

class SecureOperationFailed(Exception):
    """Generic exception for external users."""
    pass

def process_sensitive_request(api_key: str, data: dict):
    
    # Redact the API key immediately for use in logging
    redacted_api_key = "****REDACTED****"
    
    try:
        logging.info("Attempting sensitive operation...")

        # Simulated internal validation failure
        if 'invalid_input' in data:
            # Raise a specific, internal exception
            raise ValueError("Input data validation failed internally: 'invalid_input' detected.")

        logging.info("Sensitive request processed successfully.")
        return True

    except ValueError as e:
        # 1. Secure Logging Implementation
        
        # Prepare the detailed log entry, ensuring the API key is redacted
        log_details = {
            "error_message": str(e),
            "data_payload": data,
            "api_key_used": redacted_api_key 
        }
        
        # Log the detailed error at the ERROR level, including traceback (exc_info=True)
        # Note: The traceback will show the original function call arguments, 
        # but the log message itself explicitly substitutes the sensitive key.
        logging.error(
            f"Security Alert: Internal operation failed. Details: {log_details}", 
            exc_info=True
        )

        # 2. Custom Exception Wrapping: Raise a generic exception for the caller
        raise SecureOperationFailed("An internal processing error occurred. Please try again later.") from e

# --- Demonstration ---

# Test 1: Successful Call
print("\n--- Test 1: Successful Call ---")
try:
    process_sensitive_request(
        api_key="SECRET_12345_KEY", 
        data={"user_id": 101, "payload": "good_data"}
    )
except SecureOperationFailed as e:
    print(f"Caller received unexpected error: {e}")

# Test 2: Failure Call (Triggers secure logging and generic exception)
print("\n--- Test 2: Failure Call (Validation Error) ---")
try:
    process_sensitive_request(
        api_key="SECRET_12345_KEY_TO_REDACT", 
        data={"user_id": 102, "invalid_input": True, "details": "malformed"}
    )
except SecureOperationFailed as e:
    # This is the generic output the end-user sees
    print(f"\n[USER OUTPUT] Caught generic exception: {e}")

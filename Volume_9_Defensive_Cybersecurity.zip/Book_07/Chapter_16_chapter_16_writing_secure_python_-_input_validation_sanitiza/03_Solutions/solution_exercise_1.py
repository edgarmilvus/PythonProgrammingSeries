
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os

class ConfigurationError(Exception):
    """Raised when environment variables fail strict validation."""
    pass

def load_secure_config():
    config = {}

    # 1. API_TIMEOUT_SECONDS (Integer, Range 1-60, Default 30)
    timeout_str = os.environ.get('API_TIMEOUT_SECONDS', '30')
    try:
        timeout = int(timeout_str)
    except ValueError:
        raise ConfigurationError(
            f"API_TIMEOUT_SECONDS failed validation: Value '{timeout_str}' is not a valid integer."
        )
    if not (1 <= timeout <= 60):
        raise ConfigurationError(
            f"API_TIMEOUT_SECONDS failed validation: Value {timeout} exceeds maximum limit 60."
        )
    config['API_TIMEOUT_SECONDS'] = timeout

    # 2. DEBUG_MODE (Strict Boolean Whitelist: "True" or "False")
    debug_str = os.environ.get('DEBUG_MODE', 'False')
    if debug_str == "True":
        config['DEBUG_MODE'] = True
    elif debug_str == "False":
        config['DEBUG_MODE'] = False
    else:
        raise ConfigurationError(
            f"DEBUG_MODE failed validation: Value '{debug_str}' must be strictly 'True' or 'False'."
        )

    # 3. LOG_LEVEL (Strict String Whitelist)
    log_level = os.environ.get('LOG_LEVEL', 'INFO')
    ALLOWED_LEVELS = {"INFO", "WARNING", "ERROR", "CRITICAL"}
    if log_level not in ALLOWED_LEVELS:
        raise ConfigurationError(
            f"LOG_LEVEL failed validation: Value '{log_level}' is not in the allowed list: {', '.join(ALLOWED_LEVELS)}."
        )
    config['LOG_LEVEL'] = log_level

    return config

# --- Demonstration Block ---
# Clean up environment temporarily for reliable testing
original_env = os.environ.copy()
for key in ['API_TIMEOUT_SECONDS', 'DEBUG_MODE', 'LOG_LEVEL']:
    if key in os.environ: del os.environ[key]

# Test 1: Successful Load (using defaults)
try:
    print("--- Test 1: Successful Load (Defaults) ---")
    secure_conf = load_secure_config()
    print(f"Loaded config: {secure_conf}")
except ConfigurationError as e:
    print(f"Unexpected Failure: {e}")

# Test 2: Failure Case (Invalid Integer Range)
os.environ['API_TIMEOUT_SECONDS'] = '90'
try:
    print("\n--- Test 2: Failure (Timeout too high) ---")
    load_secure_config()
except ConfigurationError as e:
    print(f"Secure Failure Caught: {e}")

# Test 3: Failure Case (Invalid Log Level)
os.environ['API_TIMEOUT_SECONDS'] = '10' # Reset to valid
os.environ['LOG_LEVEL'] = 'DEBUG'
try:
    print("\n--- Test 3: Failure (Invalid Log Level) ---")
    load_secure_config()
except ConfigurationError as e:
    print(f"Secure Failure Caught: {e}")

# Restore environment
os.environ.clear()
os.environ.update(original_env)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import asyncio
import logging
import sys

# Configure logging for the async environment (CRITICAL level for failure output)
logging.basicConfig(level=logging.CRITICAL, format='%(asctime)s - %(levelname)s - %(message)s', stream=sys.stdout)

class InputValidationFailed(Exception):
    """Raised when synchronous input checks fail."""
    pass

# 1. Simulated Asynchronous Task
async def worker_task(task_id: int, data: str):
    print(f"Worker {task_id}: Starting processing data '{data[:10]}...'")
    await asyncio.sleep(0.1) 
    print(f"Worker {task_id}: Finished successfully.")
    return f"Result {task_id}"

# 2. Synchronous Pre-Validation
def validate_input_list(input_list: list[str]):
    """Checks for dangerous characters ($ or &) synchronously (Fail-Fast)."""
    for i, data in enumerate(input_list):
        if '$' in data or '&' in data:
            raise InputValidationFailed(
                f"Input at index {i} failed validation: Contains restricted characters ('$' or '&')."
            )
    logging.info("Synchronous input validation passed.")

# 3. Concurrent Execution with TaskGroup
async def run_concurrent_jobs(input_data: list[str]):
    
    # 4. Fail-Safe Error Propagation
    try:
        # Synchronous validation occurs BEFORE TaskGroup initiation
        validate_input_list(input_data)
        
        print(f"\nLaunching {len(input_data)} concurrent tasks...")
        
        # Launch tasks only if validation passed
        async with asyncio.TaskGroup() as tg:
            tasks = [
                tg.create_task(worker_task(i, data))
                for i, data in enumerate(input_data)
            ]
        
        return [t.result() for t in tasks]

    except InputValidationFailed as e:
        # Catch the specific pre-validation failure
        logging.critical(f"JOB ABORTED: Pre-validation failure detected. Reason: {e}")
        # Return a generic failure signal
        return False
    except Exception as e:
        # Catch unexpected runtime errors
        logging.error(f"An unexpected runtime error occurred: {e}")
        return False

# --- Demonstration ---
async def main():
    safe_data = ["config_1", "config_2", "file_name_3"]
    dangerous_data = ["config_4", "injection_&_attempt", "config_5"]
    
    print("--- Test 1: Valid Data Execution ---")
    result_safe = await run_concurrent_jobs(safe_data)
    print(f"Job Result (Safe): {result_safe}")

    print("\n--- Test 2: Invalid Data Execution (Fail-Fast) ---")
    result_dangerous = await run_concurrent_jobs(dangerous_data)
    print(f"Job Result (Dangerous): {result_dangerous}")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except RuntimeError:
        pass # Handle potential runtime errors in non-standard execution environments

# 5. Diagramming the Flow
print("\n\n5. Graphviz DOT Notation for Flow Control:")
print("""
[ERROR: Failed to render diagram.]

digraph SecureConcurrentFlow {
    rankdir=LR;
    node [shape=box];
    
    Input [label="Input Data List"];
    Validation [label="validate_input_list() (Synchronous Check)"];
    FailFast [label="Raise InputValidationFailed", shape=diamond, style=filled, fillcolor=red];
    TaskGroupLaunch [label="asyncio.TaskGroup() Launch"];
    WorkerTasks [label="worker_task(N) (Concurrent Execution)", shape=cylinder];
    Success [label="Success/Return Results", style=filled, fillcolor=lightgreen];
    Abort [label="Log CRITICAL, Return False", style=filled, fillcolor=orange];

    Input -> Validation;
    
    Validation -> FailFast [label="Validation Failed"];
    Validation -> TaskGroupLaunch [label="Validation Passed"];

    FailFast -> Abort;
    
    TaskGroupLaunch -> WorkerTasks;
    WorkerTasks -> Success;
    
    # Error Propagation Path
    FailFast -> Abort;
}
""")

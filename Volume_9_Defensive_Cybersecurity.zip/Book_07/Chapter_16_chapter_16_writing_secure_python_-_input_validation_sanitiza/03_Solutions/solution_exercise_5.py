
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import re
import sys

def is_safe_path(path: str) -> bool:
    """
    Strictly validates a file path using whitelisting regex to prevent 
    directory traversal and injection.
    """
    
    # 1. Check for directory traversal sequences (../, /, \)
    if '..' in path or '/' in path or '\\' in path:
        return False
    
    # 2. Strict Whitelisting Regex:
    # ^: start of string
    # [a-zA-Z0-9_-]+: one or more allowed characters (filename body)
    # \.: literal dot
    # (txt|log)$: must strictly end with .txt or .log
    SAFE_PATH_PATTERN = re.compile(r'^[a-zA-Z0-9_-]+\.(txt|log)$')
    
    if not SAFE_PATH_PATTERN.match(path):
        return False
        
    return True

def secure_input_loop():
    print("--- Secure File Retrieval Utility ---")
    print("Strictly permits only alphanumeric filenames ending in .txt or .log.")
    
    # Simulate inputs for non-interactive testing environment
    test_cases = [
        "config_2024.log",          # Valid
        "file.txt; rm -rf /",       # Injection attempt (semicolon/space/slash forbidden)
        "../../etc/passwd",         # Traversal attempt (../ forbidden)
        "C:\\Windows\\system.ini",   # Backslash/Traversal forbidden
        "my file.log",              # Space forbidden
        "data_set-1.txt",           # Valid
        "index.html",               # Invalid extension
        "exit"
    ]
    
    print("\n--- Running Simulated Test Cases ---")
    for file_path in test_cases:
        print(f"\n[INPUT]: {file_path}")
        if file_path.lower() == 'exit':
            print("Exiting utility.")
            break
            
        if is_safe_path(file_path):
            print(f"Processing safe file: {file_path}")
        else:
            print("Error: Input format rejected. Only alphanumeric filenames ending in .txt or .log are permitted.")

secure_input_loop()

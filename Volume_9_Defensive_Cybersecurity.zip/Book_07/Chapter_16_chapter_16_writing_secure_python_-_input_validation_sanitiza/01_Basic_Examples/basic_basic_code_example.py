
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import re
import logging
from typing import Any

# Configure basic logging to a file or stream. 
# Crucially, we log internally but do not expose these logs externally.
# Using INFO level for success, WARNING/ERROR for failures.
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='secure_app.log' # Directing logs to a file is safer than stdout in production
)

def validate_and_process_user_data(username_input: Any, age_input: Any) -> dict:
    """
    Validates user input using strict type checking, whitelisting (regex and range), 
    and secure error handling.
    
    Args:
        username_input: The raw input intended for the username field.
        age_input: The raw input intended for the age field.
        
    Returns:
        A dictionary of securely sanitized and validated data.
        
    Raises:
        ValueError: If any validation check fails (generic error message).
    """
    
    # 1. Initialize sanitized variables to ensure they are only assigned 
    #    if they pass ALL checks.
    sanitized_username = None
    sanitized_age = None
    
    # --- A. Username Validation (Type, Whitelisting, and Length Check) ---
    
    # Define the whitelist pattern: Only letters (a-z, A-Z) and numbers (0-9).
    # Must be between 3 and 20 characters long. This is the core of whitelisting.
    USERNAME_PATTERN = r'^[a-zA-Z0-9]{3,20}$' 
    
    # Step 1a: Strict Type Check
    if not isinstance(username_input, str):
        # Log the specific failure internally, including the unexpected type
        logging.error(f"Validation Error (Username): Input type mismatch. Received: {type(username_input)}")
        # Raise a generic, non-specific error for the user/caller
        raise ValueError("Invalid input format provided for username.")
        
    # Step 1b: Content Whitelisting using Regex
    if not re.match(USERNAME_PATTERN, username_input):
        # Log failure details. We log the failure attempt but avoid logging the full 
        # input string if it might contain sensitive or malicious payload data.
        logging.warning("Validation Warning (Username): Failed whitelisting check (invalid characters/length).")
        raise ValueError("Username must be 3-20 characters long and contain only letters and numbers.")
        
    # If checks pass, assign the validated value. 
    # Simple sanitization/normalization: converting to lowercase.
    sanitized_username = username_input.lower() 
    
    # --- B. Age Validation (Type Conversion & Range Whitelisting) ---
    
    try:
        # Step 2a: Attempt strict type conversion. This handles cases where 
        # the input might be a string ('35') or an integer (35), but fails 
        # if it's non-numeric ('thirty').
        sanitized_age = int(age_input)
        
        # Step 2b: Range Whitelisting (Boundary Check)
        # Define the acceptable range for age (e.g., 18 to 120).
        if not 18 <= sanitized_age <= 120:
            # Log the specific range violation
            logging.warning(f"Validation Warning (Age): Out of acceptable range. Received: {age_input}")
            raise ValueError("Age must be between 18 and 120.")
            
    except (TypeError, ValueError) as e:
        # Step 2c: Catch errors during conversion (e.g., if age_input was 'twenty' or None)
        # Log the internal details, including the specific error message (e).
        logging.error(f"Validation Error (Age): Conversion failed. Input: {age_input}. Internal Error: {e}")
        # Raise a generic error for the external caller.
        raise ValueError("Invalid age value provided.")
        
    # --- C. Successful Processing ---
    
    # If execution reaches this point, both username and age are fully trusted.
    logging.info(f"SUCCESS: User '{sanitized_username}' (Age: {sanitized_age}) successfully validated.")
    return {"username": sanitized_username, "age": sanitized_age}

# ====================================================================
# Test Cases Demonstrating Secure Handling
# ====================================================================

print("--- Starting Validation Tests ---")

# Test 1: Valid Data (Success)
try:
    result = validate_and_process_user_data("SecureUser123", "35")
    print(f"Test 1 Result (Success): {result}")
except ValueError as e:
    print(f"Test 1 Result (Failure): {e}")

# Test 2: Invalid Username (Injection attempt - includes <>)
try:
    validate_and_process_user_data("User<script>alert(1)</script>", 40)
except ValueError as e:
    print(f"Test 2 Result (Failure - Malicious Characters): {e}")
    
# Test 3: Invalid Age Type (Non-numeric input, demonstrating secure error handling)
try:
    validate_and_process_user_data("GoodUser", "forty-five")
except ValueError as e:
    print(f"Test 3 Result (Failure - Wrong Type): {e}")
    
# Test 4: Invalid Age Range (Boundary violation)
try:
    validate_and_process_user_data("OldUser", "150")
except ValueError as e:
    print(f"Test 4 Result (Failure - Out of Range): {e}")

# Test 5: Invalid Username Type (Passing an unexpected list/object)
try:
    validate_and_process_user_data(["BadUser"], 30)
except ValueError as e:
    print(f"Test 5 Result (Failure - Wrong Username Type): {e}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import sys
import json
import logging
import logging.handlers
from datetime import datetime, timedelta
from sqlalchemy import create_engine, Column, Integer, String, DateTime
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base

# --- 1. Structured Logging Setup ---

class JsonFormatter(logging.Formatter):
    """Custom formatter to output log records as structured JSON."""
    def format(self, record):
        log_data = {
            "timestamp": datetime.fromtimestamp(record.created).isoformat(),
            "level": record.levelname,
            "module": record.name,
            "function": record.funcName,
            "line": record.lineno,
            "message": record.getMessage(),
            "security_check": getattr(record, 'security_check', 'N/A'),
            "severity": getattr(record, 'severity', 'INFO')
        }
        return json.dumps(log_data)

def setup_security_logger(log_file='security_audit.log'):
    """Configures a logger with stream and rotating file handlers using the JSON formatter."""
    logger = logging.getLogger('SecurityAuditor')
    logger.setLevel(logging.DEBUG)

    # Handler 1: Console output (for immediate visibility)
    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(JsonFormatter())
    logger.addHandler(stream_handler)

    # Handler 2: Rotating File output (for persistent centralized collection)
    file_handler = logging.handlers.RotatingFileHandler(
        log_file, maxBytes=1048576, backupCount=5
    )
    file_handler.setFormatter(JsonFormatter())
    logger.addHandler(file_handler)
    
    return logger

# Initialize the logger globally
AUDIT_LOGGER = setup_security_logger()

# --- 2. Database Configuration Model (SQLAlchemy) ---

Base = declarative_base()

class SecurityConfig(Base):
    """Model representing critical security configurations stored in the database."""
    __tablename__ = 'security_config'
    id = Column(Integer, primary_key=True)
    key_name = Column(String, unique=True, nullable=False)
    value = Column(String)
    last_rotated = Column(DateTime, default=datetime.min)

# Setup in-memory SQLite database for demonstration
ENGINE = create_engine('sqlite:///:memory:')
Base.metadata.create_all(ENGINE)
Session = sessionmaker(bind=ENGINE)

# --- 3. Security Posture Assessment Checks ---

def check_critical_env():
    """Checks for the presence and length of critical environment variables."""
    # Simulate a critical failure condition
    os.environ['APP_SECRET_KEY'] = os.getenv('APP_SECRET_KEY', 'short_insecure_key') 
    
    key = os.getenv('APP_SECRET_KEY')
    min_length = 32
    check_name = "ENV_SECRET_KEY_CHECK"

    if not key or len(key) < min_length:
        AUDIT_LOGGER.critical(
            f"Critical: APP_SECRET_KEY is missing or too short ({len(key)} chars). Must be >= {min_length}.",
            extra={'security_check': check_name, 'severity': 'CRITICAL'}
        )
        return False
    
    AUDIT_LOGGER.info(
        "APP_SECRET_KEY check passed.",
        extra={'security_check': check_name, 'severity': 'LOW'}
    )
    return True

def check_db_compliance(session):
    """Checks database configuration against a defined security policy (e.g., rotation policy)."""
    check_name = "DB_PASSWORD_ROTATION_CHECK"
    max_days = 90
    
    # Retrieve configuration item from the database
    config = session.query(SecurityConfig).filter_by(key_name='db_password_hash').first()
    
    if not config:
        # Simulate initial setup where configuration might be missing
        AUDIT_LOGGER.warning(
            "DB Configuration item 'db_password_hash' not found. Cannot verify rotation policy.",
            extra={'security_check': check_name, 'severity': 'HIGH'}
        )
        return False

    time_since_rotation = datetime.now() - config.last_rotated
    
    if time_since_rotation > timedelta(days=max_days):
        AUDIT_LOGGER.error(
            f"Policy Violation: DB password last rotated {time_since_rotation.days} days ago. Max allowed: {max_days} days.",
            extra={'security_check': check_name, 'severity': 'HIGH'}
        )
        return False

    AUDIT_LOGGER.info(
        f"DB password rotation compliant. Last rotated {time_since_rotation.days} days ago.",
        extra={'security_check': check_name, 'severity': 'LOW'}
    )
    return True

# --- 4. Main Auditor Execution ---

def run_security_audit():
    """Executes all security checks sequentially and handles critical failures."""
    AUDIT_LOGGER.info("--- Starting Security Posture Assessment Audit ---")
    
    # 4a. Initialize Database State (for demonstration)
    session = Session()
    # Simulate a non-compliant state (rotated 100 days ago)
    non_compliant_date = datetime.now() - timedelta(days=100)
    session.add(SecurityConfig(key_name='db_password_hash', value='hashed_val', last_rotated=non_compliant_date))
    session.commit()

    # 4b. Run Checks
    critical_failure_detected = False
    
    # Check 1: Environment Variables (High Priority)
    if not check_critical_env():
        critical_failure_detected = True
    
    # Check 2: Database Compliance (Medium Priority)
    if not check_db_compliance(session):
        # This is a policy error, not necessarily a system halt, but logged as HIGH severity
        pass 
    
    session.close()

    # 4c. Monitoring and Alerting Mechanism
    if critical_failure_detected:
        AUDIT_LOGGER.critical(
            "AUDIT FAILED: Critical configuration vulnerability detected. Halting application execution.",
            extra={'security_check': 'AUDIT_SUMMARY', 'severity': 'CRITICAL'}
        )
        # Immediate termination for critical failures (Principle of Least Astonishment)
        sys.exit(1)
    else:
        AUDIT_LOGGER.info(
            "AUDIT SUCCESS: All critical security posture checks passed.",
            extra={'security_check': 'AUDIT_SUMMARY', 'severity': 'INFO'}
        )
        sys.exit(0)

if __name__ == "__main__":
    run_security_audit()

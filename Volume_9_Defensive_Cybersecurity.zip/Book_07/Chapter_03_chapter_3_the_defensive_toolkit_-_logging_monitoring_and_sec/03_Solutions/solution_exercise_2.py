
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import json
from datetime import datetime, timedelta
import os

# Define security policy constants
IP_WINDOW_SECONDS = 60
IP_THRESHOLD = 5
USER_WINDOW_SECONDS = 30
USER_THRESHOLD = 3

# Data structures to track attempts: {key: [timestamp1, timestamp2, ...]}
ip_attempts = {}
user_attempts = {}

LOG_FILE = "access_logs.jsonl"
ALERT_FILE = "security_alerts.log"
TIME_FORMAT = "%Y-%m-%dT%H:%M:%S%z"

def setup_log_file():
    """Generates a simulated log file for testing."""
    if os.path.exists(LOG_FILE):
        os.remove(LOG_FILE)
    
    # Logs are ordered by time for sequential processing
    logs = [
        # 1. IP Brute Force (5 attempts in 30s)
        {"timestamp": "2024-05-15T10:00:00Z", "level": "WARNING", "user": "guest", "ip_address": "1.1.1.1", "event": "Authentication Failed"},
        {"timestamp": "2024-05-15T10:00:10Z", "level": "WARNING", "user": "guest", "ip_address": "1.1.1.1", "event": "Authentication Failed"},
        {"timestamp": "2024-05-15T10:00:20Z", "level": "WARNING", "user": "guest", "ip_address": "1.1.1.1", "event": "Authentication Failed"},
        {"timestamp": "2024-05-15T10:00:30Z", "level": "WARNING", "user": "guest", "ip_address": "1.1.1.1", "event": "Authentication Failed"},
        {"timestamp": "2024-05-15T10:00:40Z", "level": "WARNING", "user": "guest", "ip_address": "1.1.1.1", "event": "Authentication Failed"}, # <-- IP ALERT (5th attempt)
        
        # 2. User Brute Force (3 attempts in 15s)
        {"timestamp": "2024-05-15T10:01:00Z", "level": "WARNING", "user": "admin", "ip_address": "10.0.0.1", "event": "Authentication Failed"},
        {"timestamp": "2024-05-15T10:01:05Z", "level": "WARNING", "user": "admin", "ip_address": "10.0.0.2", "event": "Authentication Failed"},
        {"timestamp": "2024-05-15T10:01:10Z", "level": "WARNING", "user": "admin", "ip_address": "10.0.0.3", "event": "Authentication Failed"}, # <-- USER ALERT (3rd attempt)
        
        # 3. Successful login (should not trigger alert)
        {"timestamp": "2024-05-15T10:02:00Z", "level": "INFO", "user": "alice", "ip_address": "192.168.1.10", "event": "Authentication Success"},
        
        # 4. Attempt outside the window (should reset IP count)
        {"timestamp": "2024-05-15T10:02:01Z", "level": "WARNING", "user": "guest", "ip_address": "1.1.1.1", "event": "Authentication Failed"}, # 121 seconds after first 1.1.1.1 attempt
    ]
    with open(LOG_FILE, 'w') as f:
        for log in logs:
            f.write(json.dumps(log) + '\n')

def trigger_security_alert(alert_type: str, details: dict):
    """Simulates sending an alert to a security team."""
    alert = {
        "alert_time": datetime.now().isoformat(),
        "alert_type": alert_type,
        "details": details
    }
    with open(ALERT_FILE, 'a') as f:
        f.write(json.dumps(alert) + '\n')
    print(f"[ALERT] {alert_type}: {details['key']} (Count: {details['count']})")


def process_failure(log_entry):
    """Applies sliding window logic for both IP and User attempts."""
    current_time = datetime.strptime(log_entry['timestamp'], TIME_FORMAT)
    ip = log_entry.get('ip_address')
    user = log_entry.get('user')

    # --- IP Address Check ---
    if ip:
        if ip not in ip_attempts:
            ip_attempts[ip] = []
        
        # Add current attempt
        ip_attempts[ip].append(current_time)
        
        # Prune old attempts (Sliding Window)
        cutoff_time = current_time - timedelta(seconds=IP_WINDOW_SECONDS)
        ip_attempts[ip] = [ts for ts in ip_attempts[ip] if ts >= cutoff_time]
        
        # Check threshold
        if len(ip_attempts[ip]) >= IP_THRESHOLD:
            trigger_security_alert("BRUTE_FORCE_IP", {
                "key": ip,
                "count": len(ip_attempts[ip]),
                "window": IP_WINDOW_SECONDS,
                "timestamp": log_entry['timestamp']
            })

    # --- User Check ---
    if user:
        if user not in user_attempts:
            user_attempts[user] = []
        
        # Add current attempt
        user_attempts[user].append(current_time)
        
        # Prune old attempts (Sliding Window)
        cutoff_time = current_time - timedelta(seconds=USER_WINDOW_SECONDS)
        user_attempts[user] = [ts for ts in user_attempts[user] if ts >= cutoff_time]
        
        # Check threshold
        if len(user_attempts[user]) >= USER_THRESHOLD:
            trigger_security_alert("BRUTE_FORCE_USER", {
                "key": user,
                "count": len(user_attempts[user]),
                "window": USER_WINDOW_SECONDS,
                "timestamp": log_entry['timestamp']
            })


def main():
    setup_log_file()
    if os.path.exists(ALERT_FILE):
        os.remove(ALERT_FILE)
        
    print(f"Starting log analysis from {LOG_FILE}...")
    
    with open(LOG_FILE, 'r') as f:
        for line in f:
            try:
                log_entry = json.loads(line.strip())
                if log_entry.get('event') == "Authentication Failed":
                    process_failure(log_entry)
            except json.JSONDecodeError:
                print(f"Skipping malformed log line: {line.strip()}")
            except Exception as e:
                print(f"An error occurred during processing: {e}")

    print("Analysis complete. Check security_alerts.log for reports.")

if __name__ == "__main__":
    main()

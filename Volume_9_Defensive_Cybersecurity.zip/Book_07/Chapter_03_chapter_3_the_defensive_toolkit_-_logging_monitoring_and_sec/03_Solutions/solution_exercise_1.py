
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import logging
import json
import uuid
import time
from contextvars import ContextVar
from threading import Thread

# 1. Context Variable Initialization
REQUEST_ID = ContextVar('request_id', default=None)

# 2. Custom JSON Formatter that accesses contextvars
class ContextualJsonFormatter(logging.Formatter):
    """
    Formats log records into JSON, incorporating the current request_id from contextvars.
    """
    def format(self, record):
        log_record = {
            "timestamp": self.formatTime(record, self.datefmt),
            "level": record.levelname,
            "module": record.module,
            "message": record.getMessage(),
            "request_id": REQUEST_ID.get(),  # Retrieve the ID from the context
            "line_no": record.lineno,
        }
        return json.dumps(log_record)

# Setup Logger
def setup_logger():
    logger = logging.getLogger('security_audit')
    logger.setLevel(logging.INFO)
    
    # Use StreamHandler for demonstration
    handler = logging.StreamHandler()
    handler.setFormatter(ContextualJsonFormatter(datefmt="%Y-%m-%dT%H:%M:%S%z"))
    
    if not logger.handlers:
        logger.addHandler(handler)
    return logger

LOGGER = setup_logger()

# 3. Simulated Request Processing Functions
def deep_function_call(step):
    """Simulates a function deep within the call stack."""
    time.sleep(0.01) # Simulate work
    LOGGER.info(f"Processing step {step} inside deep call.")

def request_handler(request_name):
    """Simulates the entry point of an API request."""
    # Generate and set the unique request ID for this scope
    new_request_id = str(uuid.uuid4())[:8]
    token = REQUEST_ID.set(new_request_id)
    
    try:
        LOGGER.info(f"--- Starting Request: {request_name} ---")
        
        # Logs generated here and in sub-functions automatically inherit the request_id
        deep_function_call(1)
        
        LOGGER.warning("Potential suspicious activity detected in main flow.")
        
        deep_function_call(2)
        
        LOGGER.info(f"--- Finishing Request: {request_name} ---")
    finally:
        # Clean up the context variable upon request completion
        REQUEST_ID.reset(token)

# 4. Demonstrate Context Persistence (using threads for isolation simulation)
if __name__ == "__main__":
    print("--- Starting Concurrent Request Simulation ---")
    
    # Request 1 runs in Thread 1
    t1 = Thread(target=request_handler, args=("UserA_Login",))
    
    # Request 2 runs in Thread 2
    t2 = Thread(target=request_handler, args=("ServiceB_DataFetch",))

    t1.start()
    t2.start()

    t1.join()
    t2.join()
    print("--- Simulation Complete ---")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
import stat
import logging
import json

# --- Logging Setup (Structured JSON) ---
class SimpleJsonFormatter(logging.Formatter):
    def format(self, record):
        return json.dumps({
            "timestamp": self.formatTime(record, "%Y-%m-%dT%H:%M:%S%z"),
            "level": record.levelname,
            "check": record.check_name,
            "status": record.check_status,
            "details": record.getMessage()
        })

def setup_compliance_logger():
    logger = logging.getLogger('compliance_checker')
    logger.setLevel(logging.INFO)
    
    handler = logging.StreamHandler()
    handler.setFormatter(SimpleJsonFormatter())
    
    if not logger.handlers:
        logger.addHandler(handler)
    return logger

COMPLIANCE_LOGGER = setup_compliance_logger()
CHECKS_RUN = 0
CHECKS_FAILED = 0

# --- File Simulation ---
def setup_files():
    """Creates files, setting one to be non-compliant for demonstration."""
    # Compliant config (644 permissions)
    with open("server_config.ini", "w") as f:
        f.write("[Server]\nport=8080")
    os.chmod("server_config.ini", 0o644) # rw-r--r--
    
    # Non-compliant secret file (contains default key)
    with open(".env_secret", "w") as f:
        f.write("DB_PASS=secure_password\nAPI_KEY=DEFAULT_API_KEY_12345\n")
    
    # Make the config file non-compliant for a moment to test failure detection
    os.chmod("server_config_bad.ini", 0o664) # rw-rw-r-- (Group writable)

# --- 2. Permission Verification ---
def check_permissions(filepath, policy_name):
    global CHECKS_RUN, CHECKS_FAILED
    CHECKS_RUN += 1
    
    if not os.path.exists(filepath):
        COMPLIANCE_LOGGER.error(f"File not found: {filepath}", extra={'check_name': policy_name, 'check_status': 'FAILURE'})
        CHECKS_FAILED += 1
        return

    file_stat = os.stat(filepath)
    permissions = file_stat.st_mode
    
    # Policy: Must not be writable by Group (S_IWGRP) or Others (S_IWOTH)
    is_group_writable = permissions & stat.S_IWGRP
    is_other_writable = permissions & stat.S_IWOTH
    
    if is_group_writable or is_other_writable:
        # Format current permissions for logging (e.g., 0o664 -> '664')
        perm_str = oct(permissions)[-3:]
        COMPLIANCE_LOGGER.error(
            f"Non-compliant permissions detected: {perm_str}. Group/Others must not have write access.",
            extra={'check_name': policy_name, 'check_status': 'FAILURE'}
        )
        CHECKS_FAILED += 1
    else:
        COMPLIANCE_LOGGER.info(
            f"Permissions compliant.",
            extra={'check_name': policy_name, 'check_status': 'SUCCESS'}
        )

# --- 3. Content Integrity Check (Secrets) ---
def check_secrets_integrity(filepath, policy_name, forbidden_key):
    global CHECKS_RUN, CHECKS_FAILED
    CHECKS_RUN += 1
    
    try:
        with open(filepath, 'r') as f:
            content = f.read()
            if forbidden_key in content:
                COMPLIANCE_LOGGER.critical(
                    f"CRITICAL: Default sensitive key '{forbidden_key}' found in file.",
                    extra={'check_name': policy_name, 'check_status': 'CRITICAL_FAILURE'}
                )
                CHECKS_FAILED += 1
            else:
                COMPLIANCE_LOGGER.info(
                    "No default sensitive keys found.",
                    extra={'check_name': policy_name, 'check_status': 'SUCCESS'}
                )
    except FileNotFoundError:
        COMPLIANCE_LOGGER.error(f"Secret file not found: {filepath}", extra={'check_name': policy_name, 'check_status': 'FAILURE'})
        CHECKS_FAILED += 1

# --- Main Execution and Reporting ---
if __name__ == "__main__":
    setup_files()
    
    print("--- Running Compliance Checks ---")
    
    # Check 1: Compliant configuration permissions
    check_permissions("server_config.ini", "Config_Permissions_Strict")
    
    # Check 2: Non-compliant configuration permissions (testing failure detection)
    check_permissions("server_config_bad.ini", "Config_Permissions_Bad")
    
    # Check 3: Secret content integrity (testing failure detection)
    check_secrets_integrity(".env_secret", "Secrets_Default_Key_Check", "DEFAULT_API_KEY_12345")
    
    # Clean up simulation files
    os.remove("server_config.ini")
    os.remove(".env_secret")
    os.remove("server_config_bad.ini")

    # Final Reporting
    COMPLIANCE_LOGGER.info(
        f"Compliance Report Summary: {CHECKS_RUN} checks run, {CHECKS_RUN - CHECKS_FAILED} passed, {CHECKS_FAILED} failed.",
        extra={'check_name': 'SUMMARY', 'check_status': 'FINAL'}
    )

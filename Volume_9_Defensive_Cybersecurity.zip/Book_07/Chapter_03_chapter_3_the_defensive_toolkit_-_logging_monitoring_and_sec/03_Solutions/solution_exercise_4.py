
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import logging
import json
import time
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.exc import IntegrityError, SQLAlchemyError

# --- 1. SQLAlchemy Setup (Simplified) ---
Base = declarative_base()
engine = create_engine('sqlite:///:memory:')
Session = sessionmaker(bind=engine)

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    username = Column(String, unique=True, nullable=False)
    password_hash = Column(String)

Base.metadata.create_all(engine)

# --- Logging Setup (Structured JSON) ---
class AuditJsonFormatter(logging.Formatter):
    def format(self, record):
        # Default fields
        log_data = {
            "timestamp": self.formatTime(record, "%Y-%m-%dT%H:%M:%S%z"),
            "level": record.levelname,
            "message": record.getMessage(),
            "module": record.module,
            "event_type": getattr(record, 'event_type', 'GENERAL'),
            "operation": getattr(record, 'operation', 'N/A'),
            "status": getattr(record, 'status', 'N/A'),
        }
        # Add specific fields if they exist
        if hasattr(record, 'target_user'):
            log_data['target_user'] = record.target_user
        if hasattr(record, 'target_user_id'):
            log_data['target_user_id'] = record.target_user_id
        if hasattr(record, 'duration_ms'):
            log_data['duration_ms'] = record.duration_ms
        if hasattr(record, 'error_type'):
            log_data['error_type'] = record.error_type
            
        return json.dumps(log_data)

def setup_audit_logger():
    logger = logging.getLogger('db_audit')
    # Simulate AUDIT level (25) between INFO (20) and WARNING (30)
    logging.addLevelName(25, 'AUDIT') 
    logger.setLevel(logging.INFO)
    
    handler = logging.StreamHandler()
    handler.setFormatter(AuditJsonFormatter())
    
    if not logger.handlers:
        logger.addHandler(handler)
    return logger

AUDIT_LOGGER = setup_audit_logger()

# --- 2. Audited Service Function ---
def create_user_audited(username, password):
    session = Session()
    start_time = time.perf_counter()
    
    try:
        new_user = User(username=username, password_hash=f"Hashed_{password}")
        session.add(new_user)
        
        # 1. Pre-Transaction Logging
        AUDIT_LOGGER.info(
            f"Attempting to create user: {username}",
            extra={
                'event_type': 'DB_OPERATION_START', 
                'operation': 'USER_CREATION', 
                'target_user': username, 
                'status': 'Pending Commit'
            }
        )
        
        session.commit()
        end_time = time.perf_counter()
        duration_ms = (end_time - start_time) * 1000
        
        # 2. Post-Transaction Success Logging
        AUDIT_LOGGER.log(
            25, # Using the custom AUDIT level
            f"User '{username}' created successfully.",
            extra={
                'event_type': 'DB_OPERATION_SUCCESS', 
                'operation': 'USER_CREATION', 
                'target_user_id': new_user.id, 
                'status': 'Committed',
                'duration_ms': round(duration_ms, 2)
            }
        )
        return new_user
        
    except IntegrityError as e:
        session.rollback()
        # 3. Error Handling and Logging (Integrity Failure)
        AUDIT_LOGGER.error(
            f"Failed to create user {username}: Integrity constraint violated (e.g., duplicate username).",
            extra={
                'event_type': 'DB_OPERATION_FAILURE', 
                'operation': 'USER_CREATION', 
                'target_user': username, 
                'error_type': e.__class__.__name__,
                'status': 'Rollback'
            }
        )
        return None
        
    except SQLAlchemyError as e:
        session.rollback()
        # 3. Error Handling and Logging (General DB Failure)
        AUDIT_LOGGER.error(
            f"Failed to create user {username}: General database error.",
            extra={
                'event_type': 'DB_OPERATION_FAILURE', 
                'operation': 'USER_CREATION', 
                'target_user': username, 
                'error_type': e.__class__.__name__,
                'status': 'Rollback'
            }
        )
        return None

    finally:
        session.close()

if __name__ == "__main__":
    print("--- Running Audited DB Operations ---")
    
    # Case 1: Successful creation
    print("\n--- Case 1: Success ---")
    create_user_audited("alice", "pass123")
    
    # Case 2: Failure (Integrity Error - duplicate username)
    print("\n--- Case 2: Failure (Duplicate) ---")
    create_user_audited("alice", "pass456") 
    
    # Note: For a true SQLAlchemyError simulation (like connection loss),
    # we would need to manually disconnect the engine, which is complex here.
    # The IntegrityError test suffices to demonstrate the logging flow.

# --- 4. Database State Visualization (DOT Language) ---
DOT_DIAGRAM = """
digraph TransactionalAudit {
    rankdir=LR;
    node [shape=box, style="filled", fillcolor="#f9f9f9"];

    A [label="Service Layer Call\n(create_user_audited)", fillcolor="#d4edda"];
    B [label="Session.add(User)", fillcolor="#f8d7da"];
    C [label="1. Log: DB_OPERATION_START\n(Status: Pending Commit)", shape=note, fillcolor="#fff3cd"];
    D [label="Session.commit()", fillcolor="#cce5ff"];
    
    Success [label="2. Log: DB_OPERATION_SUCCESS\n(Status: Committed, Duration)", shape=note, fillcolor="#d4edda"];
    Failure [label="3. Log: DB_OPERATION_FAILURE\n(Status: Rollback, Error Type)", shape=note, fillcolor="#f8d7da"];
    
    A -> B;
    B -> C;
    C -> D;
    
    D -> Success [label="Success", color="green"];
    D -> Failure [label="Failure (Exception)", color="red"];
    
    Success -> E [label="Return User Object"];
    Failure -> F [label="Return None"];
    
    E [label="Operation Complete"];
    F [label="Operation Complete"];
}
"""
print("\n--- DOT Diagram Visualization Code ---")
print(DOT_DIAGRAM)

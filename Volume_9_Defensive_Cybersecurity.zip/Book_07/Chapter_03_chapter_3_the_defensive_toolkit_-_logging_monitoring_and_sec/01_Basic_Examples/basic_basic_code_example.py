
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import logging
import sys
import json
from datetime import datetime
import os # Used for cleanup in the example

# Define the log file path
LOG_FILE = "security_events.log"

# --- 1. Custom Structured Formatter Class ---
class StructuredFormatter(logging.Formatter):
    """
    A custom formatter that structures log records into a standardized 
    JSON format, suitable for centralized log management systems (e.g., ELK Stack).
    """
    def format(self, record):
        """Overrides the base format method to build a JSON object."""
        
        # 1.1. Base fields required for standard log analysis
        log_record = {
            "timestamp": datetime.fromtimestamp(record.created).isoformat(),
            "level": record.levelname,
            "logger_name": record.name,
            "message": record.getMessage(),
            
            # 1.2. Contextual metadata (useful for debugging/tracing)
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
            "process_id": record.process,
            "thread_id": record.thread,
        }
        
        # 1.3. Inject custom security fields passed via 'extra' dictionary
        # We look for a specific key ('custom_fields') defined in our application logic
        if hasattr(record, 'custom_fields'):
            # The .update() method merges the custom dictionary into the main log record
            log_record.update(record.custom_fields)
            
        # 1.4. Handle exceptions if they were logged
        if record.exc_info:
            # Format exception traceback into a string
            log_record["exception"] = self.formatException(record.exc_info)
            
        # 1.5. Serialize the complete dictionary to a JSON string
        return json.dumps(log_record, ensure_ascii=False)

# --- 2. Logger Setup Function ---
def setup_structured_logger(log_file_path: str) -> logging.Logger:
    """
    Configures the 'SecurityAuditor' logger with file and console handlers,
    applying the custom StructuredFormatter to both.
    """
    
    # Get or create the specific logger instance
    logger = logging.getLogger('SecurityAuditor')
    logger.setLevel(logging.DEBUG) # Set low level to capture everything

    # CRITICAL: Prevent logs from propagating to the root logger, 
    # which might have its own plain text formatters.
    logger.propagate = False 

    # Instantiate the custom formatter
    formatter = StructuredFormatter()

    # 2.1. File Handler Setup (Persistent Audit Trail)
    file_handler = logging.FileHandler(log_file_path, encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)

    # 2.2. Stream Handler Setup (Real-time Console Monitoring)
    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setLevel(logging.INFO) # Only show INFO and above in console
    stream_handler.setFormatter(formatter)

    # 2.3. Attach handlers (ensuring idempotence)
    if not logger.handlers:
        logger.addHandler(file_handler)
        logger.addHandler(stream_handler)
        
    return logger

# --- 3. Simulated Application Logic (Security Events) ---
def simulate_login(username: str, password_hash: str, success: bool, ip_address: str):
    """Logs a detailed, structured record of an authentication attempt."""
    
    logger = logging.getLogger('SecurityAuditor')
    
    # Custom fields payload (the structured metadata)
    security_data = {
        "event_type": "AUTHENTICATION",
        "user_id": username,
        "source_ip": ip_address,
        "success": success
    }
    
    # Log the event, injecting the security_data dictionary via the 'extra' parameter
    if success:
        logger.info(
            f"User '{username}' successfully logged in.",
            extra={'custom_fields': security_data}
        )
    else:
        # For failures, add specific forensic details
        security_data["reason"] = "Invalid credentials or account locked"
        security_data["attempt_hash_prefix"] = password_hash[:10] 
        
        logger.warning(
            f"Authentication failure detected for user '{username}'.",
            extra={'custom_fields': security_data}
        )

def simulate_critical_config_change(user: str, rule_id: int):
    """Logs a critical configuration change event."""
    logger = logging.getLogger('SecurityAuditor')
    
    # Define the structured data for the configuration event
    config_change_data = {
        "event_type": "CONFIGURATION_CHANGE",
        "user_id": user,
        "config_item": f"Firewall Rule {rule_id}",
        "action": "DELETED",
        "severity": "HIGH",
        "required_approval": True
    }
    
    try:
        # Simulate a database error during the configuration change
        1 / 0 
    except ZeroDivisionError as e:
        logger.critical(
            f"CRITICAL: Failed to delete Firewall Rule {rule_id}. Database rollback initiated.",
            # Pass both custom data AND the exception information
            exc_info=e,
            extra={'custom_fields': config_change_data}
        )

# --- 4. Execution and Cleanup ---
if __name__ == "__main__":
    # 4.1. Clean up previous log file for a fresh run
    if os.path.exists(LOG_FILE):
        os.remove(LOG_FILE)
        
    # 4.2. Setup the logger
    auditor = setup_structured_logger(LOG_FILE)
    
    # Log a general system event
    auditor.info("Security auditor system initialized.", 
                 extra={'custom_fields': {'event_type': 'SYSTEM', 'stage': 'READY'}})

    # 4.3. Simulate Events
    simulate_login("admin_user", "securehash12345", success=True, ip_address="10.0.0.5")
    simulate_login("attacker_bot", "password123", success=False, ip_address="172.217.164.1")
    simulate_critical_config_change("root_admin", 42)
    
    print(f"\n--- Console Output (INFO level and above) ---\n")
    print("Check the 'security_events.log' file for the full DEBUG output.")

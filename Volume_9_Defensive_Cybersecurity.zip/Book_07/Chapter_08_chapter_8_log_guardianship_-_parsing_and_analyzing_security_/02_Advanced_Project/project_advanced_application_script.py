
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import re
import io
import pandas as pd
from datetime import datetime

# --- 1. Configuration and Data Simulation ---

# Define the regex for the standard Apache Combined Log Format
# Capturing groups: 1: IP, 2: Timestamp, 3: Request, 4: Status, 5: Size, 6: Referer, 7: User Agent
LOG_PATTERN = re.compile(
    r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}) - - \[(.*?)\] "(.*?)" (\d{3}) (\d+) "(.*?)" "(.*?)"'
)

# Define security thresholds for anomaly detection
MAX_REQUESTS_PER_IP_WINDOW = 50  # Max requests per 1-minute window
MAX_4XX_ERRORS_PER_IP_WINDOW = 15 # Max 4xx client errors per 1-minute window
TIME_WINDOW_MINUTES = 1

# Simulated log data (A large block to ensure the high-volume IP 192.168.1.100 triggers the alert)
# We use a known timestamp format for reliable parsing
SIMULATED_LOGS = """
10.0.0.1 - - [25/Nov/2023:10:00:01 +0000] "GET /index.html HTTP/1.1" 200 1024 "-" "Mozilla/5.0"
10.0.0.2 - - [25/Nov/2023:10:00:15 +0000] "GET /api/data HTTP/1.1" 200 512 "-" "Python-Requests"
192.168.1.100 - - [25/Nov/2023:10:00:30 +0000] "GET /login HTTP/1.1" 401 150 "-" "Nmap Script"
192.168.1.100 - - [25/Nov/2023:10:00:31 +0000] "POST /login HTTP/1.1" 403 150 "-" "Nmap Script"
192.168.1.100 - - [25/Nov/2023:10:00:31 +0000] "POST /login HTTP/1.1" 403 150 "-" "Nmap Script"
192.168.1.100 - - [25/Nov/2023:10:00:32 +0000] "GET /robots.txt HTTP/1.1" 200 50 "-" "Automated Scanner"
192.168.1.100 - - [25/Nov/2023:10:00:33 +0000] "GET /admin HTTP/1.1" 404 200 "-" "Automated Scanner"
192.168.1.100 - - [25/Nov/2023:10:00:34 +0000] "GET /config HTTP/1.1" 404 200 "-" "Automated Scanner"
192.168.1.100 - - [25/Nov/2023:10:00:35 +0000] "POST /login HTTP/1.1" 401 150 "-" "Nmap Script"
192.168.1.100 - - [25/Nov/2023:10:01:05 +0000] "GET /index.html HTTP/1.1" 200 1024 "-" "Mozilla/5.0" # Next minute
10.0.0.3 - - [25/Nov/2023:10:01:10 +0000] "GET /contact HTTP/1.1" 200 800 "-" "Chrome"
""" * 10 # Repeat the block 10 times to guarantee the rate threshold is met
SIMULATED_LOGS = SIMULATED_LOGS.strip()

# --- 2. Core Parsing Functions ---

def parse_log_line(line: str) -> dict | None:
    """Parses a single log line using the predefined regex and extracts key fields."""
    match = LOG_PATTERN.match(line)
    if match:
        # Map extracted groups to structured keys
        data = match.groups()
        return {
            'ip_address': data[0],
            'timestamp_raw': data[1],
            'request': data[2],
            'status_code': int(data[3]),
            # Ensure size is handled safely, defaulting to 0 if not a digit
            'bytes_sent': int(data[4]) if data[4].isdigit() else 0,
            'user_agent': data[6]
        }
    return None

def load_and_structure_logs(log_data: str) -> pd.DataFrame:
    """Reads log data, parses lines, and converts to a structured, indexed DataFrame."""
    parsed_logs = []
    # Use io.StringIO to simulate reading a file stream from a string
    with io.StringIO(log_data) as f:
        for line in f:
            record = parse_log_line(line.strip())
            if record:
                parsed_logs.append(record)

    if not parsed_logs:
        return pd.DataFrame()

    df = pd.DataFrame(parsed_logs)

    # Convert the raw timestamp string to a proper datetime object
    # Format: %d/%b/%Y:%H:%M:%S %z (e.g., 25/Nov/2023:10:00:01 +0000)
    df['timestamp'] = pd.to_datetime(
        df['timestamp_raw'], format='%d/%b/%Y:%H:%M:%S %z', utc=True
    )
    
    # Set the timestamp as the index (DatetimeIndex) for efficient time-series operations
    df = df.set_index('timestamp').sort_index()
    return df

# --- 3. Anomaly Detection and Reporting ---

def detect_anomalies(df: pd.DataFrame) -> pd.DataFrame:
    """
    Applies security rules to the DataFrame using GroupBy and Resampling aggregation.
    """
    if df.empty:
        return pd.DataFrame()

    # Define the time window for aggregation (e.g., '1T' for 1 minute)
    time_window = f'{TIME_WINDOW_MINUTES}T'

    # 3.1 Prepare the error metric column
    # Use vectorized operation for speed: 1 if status is 4xx, else 0
    df['is_4xx_error'] = (df['status_code'].between(400, 499)).astype(int)

    # 3.2 Group by IP and Resample by Time Window
    ip_groups = df.groupby('ip_address')

    # Calculate total requests per IP within the resampled time window
    request_counts = ip_groups.resample(time_window)['ip_address'].count().rename('total_requests')

    # Calculate 4xx error counts within the resampled time window
    error_counts = ip_groups.resample(time_window)['is_4xx_error'].sum().rename('4xx_errors')

    # Combine the two metrics (requests and errors) into a single analysis DataFrame
    # Fill NaN values (where an IP had 0 activity in a window) with 0
    analysis_df = pd.concat([request_counts, error_counts], axis=1).fillna(0).astype(int)
    
    # Reset index to bring 'ip_address' and the timestamp window back as columns
    analysis_df = analysis_df.reset_index()

    # 3.3 Apply filtering based on defined thresholds
    
    # Filter for IPs violating the request rate limit
    high_request_ips = analysis_df[
        analysis_df['total_requests'] >= MAX_REQUESTS_PER_IP_WINDOW
    ]

    # Filter for IPs violating the 4xx error rate limit
    high_error_ips = analysis_df[
        analysis_df['4xx_errors'] >= MAX_4XX_ERRORS_PER_IP_WINDOW
    ]

    # Merge and deduplicate the flagged IPs, ensuring we report each IP/Window combination once
    flagged_ips = pd.concat([high_request_ips, high_error_ips]).drop_duplicates(
        subset=['ip_address', 'timestamp']
    ).sort_values(by='timestamp')

    return flagged_ips.rename(columns={'timestamp': 'window_start_time'})

# --- 4. Main Execution ---

def main_detector():
    """Main execution flow for log analysis."""
    print(f"--- Starting Log Anomaly Detection (Window: {TIME_WINDOW_MINUTES} min) ---")

    # Step 1: Load and structure the raw log data
    df_logs = load_and_structure_logs(SIMULATED_LOGS)

    if df_logs.empty:
        print("No valid logs found to analyze.")
        return

    print(f"Total valid log entries processed: {len(df_logs)}")
    print("Applying time-series analysis and security thresholds...")

    # Step 2: Apply detection rules
    df_anomalies = detect_anomalies(df_logs)

    # Step 3: Report results
    if df_anomalies.empty:
        print("\n[RESULT] Analysis complete. No anomalies detected above thresholds.")
    else:
        print("\n[ALERT] Suspicious activity detected!")
        print("The following IPs exceeded rate limits or error thresholds:")
        
        # Define columns for the final, clean report
        report_cols = ['window_start_time', 'ip_address', 'total_requests', '4xx_errors']
        
        # Display the anomaly report
        print(df_anomalies[report_cols].to_string(index=False))
        
        # Provide context by retrieving raw logs for the first flagged IP
        suspicious_ip = df_anomalies['ip_address'].iloc[0]
        print(f"\n--- First 5 raw entries for investigation IP: {suspicious_ip} ---")
        
        raw_investigation = df_logs[df_logs['ip_address'] == suspicious_ip]
        print(raw_investigation[['request', 'status_code', 'user_agent']].head(5).to_string())

if __name__ == "__main__":
    main_detector()

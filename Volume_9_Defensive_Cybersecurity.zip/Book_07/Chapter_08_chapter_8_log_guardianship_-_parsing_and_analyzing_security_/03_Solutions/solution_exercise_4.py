
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
import json
import sys

# Simulated input data structure (representing daily error counts)
ERROR_COUNTS = {
    '401_unauthorized': 50,
    '403_forbidden': 15,
    '404_not_found': 1200,
    '500_internal_error': 5,
}

REPORT_DIR_NAME = 'reports'
REPORT_FILE_NAME = 'daily_report.log'

def threshold_monitor(error_data):
    """Monitors error counts against a dynamic threshold configured via environment variables."""
    
    # 1. Configuration via Environment Variables
    # Retrieve the threshold, defaulting to '1000' if not set.
    threshold_str = os.getenv('MAX_404_THRESHOLD', '1000')
    
    try:
        max_404_threshold = int(threshold_str)
    except ValueError:
        print(f"[CRITICAL] Invalid value set for MAX_404_THRESHOLD: {threshold_str}. Using default 1000.", file=sys.stderr)
        max_404_threshold = 1000

    actual_404_count = error_data.get('404_not_found', 0)
    
    # 2. Path Construction
    # Construct the platform-independent path for the report file
    report_dir = os.path.join(os.getcwd(), REPORT_DIR_NAME)
    report_filepath = os.path.join(report_dir, REPORT_FILE_NAME)

    # Ensure the directory exists
    os.makedirs(report_dir, exist_ok=True)
    
    # 3. Alert Logic
    alert_triggered = False
    if actual_404_count > max_404_threshold:
        alert_triggered = True
        
    # 4. Reporting: Alert Banner
    print("-" * 70)
    print(f"MONITORING REPORT: {REPORT_FILE_NAME}")
    print(f"Threshold Used (MAX_404_THRESHOLD): {max_404_threshold}")
    print(f"Actual 404 Count: {actual_404_count}")
    
    if alert_triggered:
        print("\n\n!!! HIGH PRIORITY ALERT !!!")
        print(f"404 Count ({actual_404_count}) EXCEEDS configured threshold ({max_404_threshold}). INVESTIGATE.")
        print("!!! HIGH PRIORITY ALERT !!!\n")
    else:
        print("404 count is within acceptable limits.")
    print("-" * 70)

    # 4. Reporting: Write data to file
    try:
        with open(report_filepath, 'w') as f:
            json.dump(error_data, f, indent=4)
        print(f"\n[INFO] Report successfully written to: {report_filepath}")
    except IOError as e:
        print(f"[CRITICAL] Failed to write report file: {e}", file=sys.stderr)

# --- Execution Simulation ---
# 1. Simulate setting the environment variable to a high value (to test the default fallback)
# os.environ['MAX_404_THRESHOLD'] = '1100' # If uncommented, alert will trigger
# 2. Simulate setting the environment variable to a low value (to test alert trigger)
# os.environ['MAX_404_THRESHOLD'] = '500' # If uncommented, alert will trigger

threshold_monitor(ERROR_COUNTS)

# Clean up temporary directory (optional, but good practice for testing)
try:
    os.remove(report_filepath)
    os.rmdir(report_dir)
except Exception:
    pass


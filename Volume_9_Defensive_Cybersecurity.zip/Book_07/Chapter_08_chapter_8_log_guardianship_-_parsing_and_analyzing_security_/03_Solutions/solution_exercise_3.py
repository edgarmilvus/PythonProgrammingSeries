
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import pandas as pd
import json
from io import StringIO

# --- Setup: Simulated Input Files ---
AUTH_LOGS_JSON = """
[
    {"event_time": "2023-12-15T15:00:01Z", "user": "alice", "session_id": "SESS1001", "status": "SUCCESS"},
    {"event_time": "2023-12-15T15:00:05Z", "user": "bob", "session_id": "SESS1002", "status": "FAILURE"},
    {"event_time": "2023-12-15T15:00:10Z", "user": "charlie", "session_id": "SESS1003", "status": "SUCCESS"},
    {"event_time": "2023-12-15T15:00:15Z", "user": "diana", "session_id": "SESS1004", "status": "SUCCESS"}
]
"""

API_LOGS_JSON = """
[
    {"timestamp": "2023-12-15T15:00:02Z", "session_id": "SESS1001", "endpoint": "/data/read", "http_code": 200, "latency_ms": 50},
    {"timestamp": "2023-12-15T15:00:11Z", "session_id": "SESS1003", "endpoint": "/admin/update", "http_code": 503, "latency_ms": 1500},
    {"timestamp": "2023-12-15T15:00:12Z", "session_id": "SESS1003", "endpoint": "/data/status", "http_code": 200, "latency_ms": 20},
    {"timestamp": "2023-12-15T15:00:16Z", "session_id": "SESS1004", "endpoint": "/profile", "http_code": 404, "latency_ms": 100}
]
"""

def json_correlator(auth_data, api_data):
    """Loads, normalizes, merges, and filters JSON log data."""
    
    # 1. Data Loading (Simulated file read using StringIO)
    auth_list = json.loads(auth_data)
    api_list = json.loads(api_data)
    
    df_auth = pd.DataFrame(auth_list)
    df_api = pd.DataFrame(api_list)

    # 2. Normalization: Standardize timestamp columns
    df_auth = df_auth.rename(columns={'event_time': 'log_time'})
    df_api = df_api.rename(columns={'timestamp': 'log_time'})
    
    # Filter authentication logs for successful events only
    df_auth_success = df_auth[df_auth['status'] == 'SUCCESS']

    # 3. Correlation (Merging): Join successful auths with API transactions on session_id
    # Using an inner merge ensures we only correlate records present in both sets
    correlated_df = pd.merge(
        df_auth_success, 
        df_api, 
        on='session_id', 
        how='inner', 
        suffixes=('_auth', '_api')
    )
    
    # Ensure http_code is numeric for comparison
    correlated_df['http_code'] = pd.to_numeric(correlated_df['http_code'])

    # 4. Filtering for Anomalies: Successful login AND critical server error (5xx)
    anomaly_filter = correlated_df['http_code'] >= 500
    suspicious_sessions = correlated_df[anomaly_filter]

    # 5. Output: Display required fields
    print("=" * 60)
    print("CRITICAL SESSION ANOMALY REPORT (Success Auth + 5xx API Error)")
    print("=" * 60)
    
    if not suspicious_sessions.empty:
        output_cols = [
            'user', 
            'log_time_auth', 
            'session_id', 
            'endpoint', 
            'http_code'
        ]
        
        # Rename columns for clearer output
        report_df = suspicious_sessions[output_cols].rename(columns={
            'log_time_auth': 'Login_Time',
            'http_code': 'API_Error_Code',
            'endpoint': 'Failing_Endpoint'
        })
        
        print(report_df.to_string(index=False))
    else:
        print("No critical 5xx API errors found following successful authentication.")

# Execute the correlator
json_correlator(AUTH_LOGS_JSON, API_LOGS_JSON)

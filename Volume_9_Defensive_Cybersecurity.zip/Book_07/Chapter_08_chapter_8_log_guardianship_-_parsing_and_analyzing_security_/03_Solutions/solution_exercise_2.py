
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import pandas as pd
import re
from io import StringIO

# --- Setup: Simulated Apache CLF Input Data ---
# Note: This format is space-separated, making regex the most reliable parsing method.
APACHE_CLF_SAMPLE = """
"""

# Regex for Apache CLF (captures IP, Timestamp, Method, Path, Status Code, Bytes, User Agent)
LOG_FORMAT_REGEX = re.compile(
    r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}) '  # IP Address (Group 1)
    r'.*?'                                    # Skip user/auth fields
    r'\[(.*?)\] '                             # Timestamp (Group 2)
    r'"(\S+) (\S+).*?" '                      # Method (Group 3) and Path (Group 4)
    r'(\d+) '                                 # Status Code (Group 5)
    r'(\d+) '                                 # Bytes (Group 6)
    r'.*?"(.*?)"$'                            # User Agent (Group 7)
)

SUSPICIOUS_KEYWORDS = ['union', 'select', 'etc/passwd', 'login.php']

def web_analyzer(log_data):
    """Loads log data, parses it, and performs statistical analysis using pandas."""
    
    parsed_lines = []
    
    # Pre-parse the data into a list of lists for fast DataFrame creation
    for line in log_data.strip().split('\n'):
        if line.strip():
            match = LOG_FORMAT_REGEX.match(line)
            if match:
                # Extract relevant groups: IP, Timestamp, Method, Path, Status Code
                parsed_lines.append(match.groups()[:5]) 

    # 1. Pandas Integration: Create DataFrame
    df = pd.DataFrame(parsed_lines, columns=['ip_address', 'timestamp', 'method', 'path', 'status_code'])
    df['status_code'] = pd.to_numeric(df['status_code'], errors='coerce')
    
    print("=" * 50)
    print("WEB LOG ANALYSIS REPORT")
    print("=" * 50)

    # 2. Top N Analysis: Top 5 most frequent IP addresses
    top_ips = df['ip_address'].value_counts().head(5)
    print("\n--- Top 5 Most Active IP Addresses ---")
    print(top_ips.to_string())

    # 3. Status Code Distribution
    status_distribution = df['status_code'].value_counts(normalize=True) * 100
    print("\n--- HTTP Status Code Distribution (%) ---")
    print(status_distribution.round(2).to_string())

    # 4. Anomaly Filtering (Threat Pattern Detection)
    # Create a boolean mask: check if 'path' contains ANY of the suspicious keywords
    suspicious_mask = df['path'].str.contains('|'.join(SUSPICIOUS_KEYWORDS), case=False, na=False)
    suspicious_requests = df[suspicious_mask]
    
    print("\n--- Suspicious Requests Detected ---")
    if not suspicious_requests.empty:
        # Display relevant columns for suspicious activity
        print(suspicious_requests[['ip_address', 'timestamp', 'path', 'status_code']].to_string(index=False))
    else:
        print("No suspicious requests found based on defined keywords.")

# Execute the analyzer
web_analyzer(APACHE_CLF_SAMPLE)

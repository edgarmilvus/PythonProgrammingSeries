
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import os
import re
import json
import pandas as pd
import sys
from collections import Counter
import tempfile

# --- Core Parsing Functions ---

# Regex from Exercise 1 for Syslog parsing (simplified for application extraction)
SYSLOG_APP_PATTERN = re.compile(
    r'^\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}\s+\S+\s+'
    r'(?P<application>[a-zA-Z0-9_/.-]+)'
    r'(?:\[\d+\])?:\s+.*$'
)

def parse_syslog_file(filepath):
    """Parses Syslog, extracts application names, and counts their occurrences."""
    application_counts = Counter()
    
    try:
        with open(filepath, 'r') as f:
            for line in f:
                match = SYSLOG_APP_PATTERN.match(line)
                if match:
                    app_name = match.group('application')
                    application_counts[app_name] += 1
    except Exception as e:
        return f"Error reading Syslog file: {e}"
        
    return application_counts

def analyze_json_file(filepath):
    """Loads JSON data using pandas and counts unique user frequencies."""
    user_counts = Counter()
    try:
        # Load JSON file into a list of dicts
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        # Convert to DataFrame for efficient counting
        df = pd.DataFrame(data)
        
        # Check if 'user' column exists (based on Exercise 3 schema)
        if 'user' in df.columns:
            user_counts = df['user'].value_counts().to_dict()
        else:
            return "JSON file missing 'user' field for analysis."
            
    except json.JSONDecodeError:
        return "File is not valid JSON."
    except Exception as e:
        return f"Error analyzing JSON file: {e}"
        
    return user_counts

def determine_log_type(filepath):
    """Attempts to determine if a file is JSON or Syslog based on content."""
    
    # 1. Attempt JSON load (most definitive test for structured logs)
    try:
        with open(filepath, 'r') as f:
            # Read first 1000 bytes to check for JSON structure without loading the whole file
            content_start = f.read(1000)
            json.loads(content_start)
            return 'JSON'
    except (json.JSONDecodeError, UnicodeDecodeError):
        pass # Not JSON, proceed to check for Syslog format

    # 2. Check for Syslog pattern (basic check on first line)
    try:
        with open(filepath, 'r') as f:
            first_line = f.readline()
            if SYSLOG_APP_PATTERN.match(first_line):
                return 'SYSLOG'
    except Exception:
        pass

    return 'UNKNOWN'

def run_pipeline(directory_path):
    """Main orchestrator function for the dynamic log processing pipeline."""
    
    if not os.path.isdir(directory_path):
        print(f"Error: Directory not found at {directory_path}", file=sys.stderr)
        return

    syslog_results = Counter()
    json_results = {}
    
    print(f"--- Starting Pipeline on Directory: {directory_path} ---")

    # 1. Directory Traversal
    for filename in os.listdir(directory_path):
        filepath = os.path.join(directory_path, filename)
        
        if os.path.isfile(filepath):
            log_type = determine_log_type(filepath)
            print(f"Processing {filename}... Detected Type: {log_type}")

            # 3. Conditional Processing
            if log_type == 'SYSLOG':
                counts = parse_syslog_file(filepath)
                if isinstance(counts, Counter):
                    syslog_results.update(counts)
            
            elif log_type == 'JSON':
                counts = analyze_json_file(filepath)
                if isinstance(counts, dict):
                    # Aggregate JSON results (merging user counts)
                    for user, count in counts.items():
                        json_results[user] = json_results.get(user, 0) + count
            
    # 4. Consolidated Output
    print("\n" + "=" * 50)
    print("FINAL CONSOLIDATED ANALYSIS REPORT")
    print("=" * 50)
    
    # Syslog Report
    if syslog_results:
        print("\n[Syslog Analysis: Application Activity]")
        top_apps = syslog_results.most_common(3)
        for app, count in top_apps:
            print(f"  - {app}: {count} logs")
    else:
        print("\n[Syslog Analysis] No Syslog data processed.")

    # JSON Report
    if json_results:
        print("\n[JSON Analysis: User Frequency]")
        # Sort JSON results for top 3 users
        top_users = sorted(json_results.items(), key=lambda item: item[1], reverse=True)[:3]
        for user, count in top_users:
            print(f"  - {user}: {count} transactions")
    else:
        print("\n[JSON Analysis] No JSON data processed.")


# --- Execution Setup (Simulating Input Files and Command Line) ---

if __name__ == "__main__":
    # Create a temporary directory structure for testing
    temp_dir = tempfile.mkdtemp()
    
    # Define sample data matching the required formats
    syslog_content = """
Dec 15 10:30:01 webserver sshd[12345]: Login attempt
Dec 15 10:30:05 firewall kernel: Connection blocked
Dec 15 10:30:06 firewall kernel: Connection accepted
Dec 15 10:30:10 webserver sshd: Logout success
"""
    json_content = """
[
    {"user": "alice", "action": "read"},
    {"user": "bob", "action": "write"},
    {"user": "alice", "action": "update"}
]
"""
    
    # Write sample files
    with open(os.path.join(temp_dir, 'server.log'), 'w') as f:
        f.write(syslog_content)
    with open(os.path.join(temp_dir, 'transactions.json'), 'w') as f:
        f.write(json_content)
    with open(os.path.join(temp_dir, 'malformed.txt'), 'w') as f:
        f.write("This is garbage data.")

    # Simulate command line argument passing
    if len(sys.argv) > 1:
        input_dir = sys.argv[1]
    else:
        input_dir = temp_dir # Use the created temp directory if no argument provided
        
    # Run the pipeline
    run_pipeline(input_dir)
    
    # Cleanup temporary directory
    try:
        for f in os.listdir(temp_dir):
            os.remove(os.path.join(temp_dir, f))
        os.rmdir(temp_dir)
    except Exception:
        pass

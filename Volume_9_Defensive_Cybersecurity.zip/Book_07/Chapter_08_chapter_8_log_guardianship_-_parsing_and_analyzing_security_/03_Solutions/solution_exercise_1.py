
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import re
import os
from io import StringIO

# --- Setup: Simulated Input Data ---
SYSLOG_SAMPLE = """
Dec 15 10:30:01 webserver sshd[12345]: Failed password for invalid user root from 192.168.1.10 port 50000 ssh2
Dec 15 10:30:05 firewall kernel: TCP connection established from 10.0.0.5:45000 to 192.168.1.1:80
Dec 15 10:30:10 mail_relay postfix/cleanup: 1C2A3B4C: message-id=<20231215103010.1C2A3B4C@mail_relay.local>
Dec 15 10:30:15 monitoring systemd: Session 45 of user admin logged in.
Dec 15 10:30:20 bad_log_line This line is totally malformed
"""

# 1. Comprehensive Regex Pattern Definition
# Explanation of groups:
# timestamp: (\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}) -> Month, Day, Time
# hostname: (\S+) -> Non-whitespace characters
# application: ([a-zA-Z0-9_/.-]+) -> Application name (allows common chars)
# pid (optional): (?:\[(?P<pid>\d+)\])? -> Non-capturing group for brackets, optional PID capture
# message: (.*) -> Everything remaining
SYSLOG_PATTERN = re.compile(
    r'^(?P<timestamp>\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})\s+'
    r'(?P<hostname>\S+)\s+'
    r'(?P<application>[a-zA-Z0-9_/.-]+)'
    r'(?:\[(?P<pid>\d+)\])?:\s+'
    r'(?P<message>.*)$'
)

def parse_syslog(log_data):
    """Parses Syslog data line by line using regex and normalizes the output."""
    parsed_logs = []
    
    # Use StringIO to simulate reading a file line by line
    for line in log_data.strip().split('\n'):
        if not line.strip():
            continue
            
        try:
            match = SYSLOG_PATTERN.match(line)
            if match:
                data = match.groupdict()
                
                # 3. Field Normalization
                parsed_logs.append({
                    'timestamp': data['timestamp'],
                    'hostname': data['hostname'],
                    'application': data['application'],
                    # Set pid to None if the optional group was not matched
                    'pid': data['pid'] if data['pid'] else None,
                    'message': data['message'].strip()
                })
            else:
                # 4. Error Handling: Line did not match the pattern
                print(f"[WARNING] Skipped non-conforming line: {line.strip()}")
                
        except Exception as e:
            # 4. General exception handling
            print(f"[ERROR] Failed to process line due to exception: {e} | Line: {line.strip()}")
            
    return parsed_logs

# Execute the parser
normalized_logs = parse_syslog(SYSLOG_SAMPLE)

# Print the results
for log_entry in normalized_logs:
    print(log_entry)


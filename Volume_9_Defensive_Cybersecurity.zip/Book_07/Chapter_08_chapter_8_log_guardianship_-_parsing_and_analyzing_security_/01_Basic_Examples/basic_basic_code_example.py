
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import re
from typing import Dict, Any

# 1. Define the sample log entry (a standard Apache/Nginx combined log format)
SAMPLE_LOG = '192.168.5.10 - user_a [10/May/2024:14:30:01 +0000] "GET /admin/login HTTP/1.1" 401 1234 "-" "Mozilla/5.0 (Security Tester)"'

def parse_access_log(log_line: str) -> Dict[str, Any]:
    """
    Parses a single web server access log line using named capture groups.
    
    Args:
        log_line: The raw string log entry.
        
    Returns:
        A dictionary containing extracted fields, or None if parsing fails.
    """
    
    # 2. Define the Regular Expression Pattern
    # We use named groups (?P<name>...) for clarity and structure.
    # CRITICAL: Regex must account for spaces, brackets, and optional fields.
    LOG_PATTERN = re.compile(
        r'(?P<ip>\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # Capture IP address
        r'\s-\s.*?'                                   # Skip identity fields (often '-')
        r'\[(?P<timestamp>.*?)\]'                     # Capture Timestamp (non-greedy match)
        r'\s"'                                        # Match the space and opening quote of the request line
        r'(?P<method>\w+)'                            # Capture HTTP Method (GET, POST, etc.)
        r'\s(?P<path>.*?)'                            # Capture requested Path (non-greedy)
        r'\sHTTP/\d\.\d"'                             # Match HTTP version and closing quote
        r'\s(?P<status>\d{3})'                        # Capture Status Code
        r'\s(?P<size>\d+|-)'                          # Capture response size (or '-')
    )

    # 3. Execute the search
    match = LOG_PATTERN.search(log_line)

    # 4. Process the result
    if match:
        # Use .groupdict() to convert the match object into a structured dictionary
        data = match.groupdict()
        
        # Type conversion for numerical analysis later
        try:
            data['status'] = int(data['status'])
            data['size'] = int(data['size']) if data['size'] != '-' else 0
        except ValueError as e:
            # Handle cases where expected numbers are malformed
            print(f"Warning: Failed to convert numerical data in log line. Error: {e}")
            return None
            
        return data
    else:
        # Return None if the log line does not conform to the pattern
        return None

# 5. Execution and Display
parsed_data = parse_access_log(SAMPLE_LOG)

if parsed_data:
    print("--- RAW LOG ENTRY ---")
    print(SAMPLE_LOG)
    print("\n--- STRUCTURED DATA (Python Dictionary) ---")
    
    # Pretty printing the dictionary keys and values
    for key, value in parsed_data.items():
        print(f"[{key:<10}] : {value}")
        
    # Example of immediate analysis: Flagging unauthorized access
    if parsed_data.get('status') == 401:
        print("\n[SECURITY ALERT]: Unauthorized access attempt detected!")
        print(f"Source IP: {parsed_data.get('ip')}")
        print(f"Target Path: {parsed_data.get('path')}")
else:
    print("Failed to parse log entry.")


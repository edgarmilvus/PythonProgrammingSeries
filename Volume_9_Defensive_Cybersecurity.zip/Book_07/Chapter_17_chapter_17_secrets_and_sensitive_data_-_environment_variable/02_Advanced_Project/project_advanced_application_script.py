
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import logging
import sys
from typing import Optional, Tuple

# Configure basic logging for security warnings
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

# --- 1. MOCKING EXTERNAL SERVICES ---
# In a real application, these would be library calls (e.g., boto3, hvac)

class MockKeyVaultClient:
    """
    Simulates interaction with an enterprise Key Vault/Secrets Manager.
    """
    def __init__(self, secrets: dict, auth_status: bool = True):
        self._secrets = secrets
        self._authenticated = auth_status

    def get_secret(self, secret_name: str) -> Optional[str]:
        """
        Retrieves a secret, simulating authentication checks and network calls.
        """
        if not self._authenticated:
            raise PermissionError("Key Vault authentication failed.")
        
        # Simulate successful retrieval
        if secret_name in self._secrets:
            return self._secrets[secret_name]
        return None

# --- 2. THE CORE DEFENSIVE MANAGER ---

class SecureCredentialManager:
    """
    Manages the retrieval of sensitive credentials using a tiered, defensive approach.
    Priority: Key Vault > Environment Variables > Hard Failure.
    """
    def __init__(self, vault_client: MockKeyVaultClient):
        self.vault_client = vault_client
        self.db_username_key = "DB_USER"
        self.db_password_key = "DB_PASS"
        self.api_key_name = "EXTERNAL_API_KEY"
        
        # Insecure hardcoded defaults (used only for detection and rejection)
        self._hardcoded_default_user = "guest" 

    def _load_from_vault(self) -> Optional[Tuple[str, str, str]]:
        """Attempt to retrieve all secrets from the Key Vault (Tier 1)."""
        try:
            db_user = self.vault_client.get_secret(self.db_username_key)
            db_pass = self.vault_client.get_secret(self.db_password_key)
            api_key = self.vault_client.get_secret(self.api_key_name)

            if all([db_user, db_pass, api_key]):
                logging.info("Successfully retrieved ALL secrets from Key Vault (Tier 1).")
                return (db_user, db_pass, api_key)
            
        except PermissionError as e:
            logging.warning(f"Vault access failed: {e}. Falling back to environment variables.")
        except Exception as e:
            # Catch network/connection errors
            logging.error(f"Unexpected Vault error: {e}")

        return None

    def _load_from_env(self) -> Optional[Tuple[str, str, str]]:
        """Attempt to retrieve secrets from environment variables (Tier 2)."""
        db_user = os.getenv(self.db_username_key)
        db_pass = os.getenv(self.db_password_key)
        api_key = os.getenv(self.api_key_name)

        if all([db_user, db_pass, api_key]):
            logging.warning("Secrets loaded from Environment Variables (Tier 2). "
                            "Consider migrating to Key Vault for rotation/auditing.")
            return (db_user, db_pass, api_key)
        
        return None

    def retrieve_credentials(self) -> Tuple[str, str, str]:
        """
        The main defensive retrieval function.
        Returns a tuple of (db_user, db_pass, api_key) or raises a fatal error.
        """
        
        # 1. Attempt Key Vault (Tier 1)
        vault_creds = self._load_from_vault()
        if vault_creds:
            return vault_creds

        # 2. Attempt Environment Variables (Tier 2)
        env_creds = self._load_from_env()
        if env_creds:
            return env_creds

        # 3. Final Security Check: Prevent Hardcoded Defaults (Tier 3 Refusal)
        if os.getenv(self.db_username_key) == self._hardcoded_default_user:
             # Critical defensive measure: If a hardcoded default is detected 
             # (even if partially loaded), refuse to proceed.
            logging.critical(f"FATAL: Detected use of hardcoded default user '{self._hardcoded_default_user}'. ABORTING.")
            sys.exit(1)

        # 4. Total Failure
        logging.critical("FATAL: Required secrets could not be loaded from Key Vault or Environment Variables. ABORTING.")
        sys.exit(1)

# --- 3. SECURE USAGE AND EPHEMERAL HANDLING ---

class DefensiveDatabaseConnector:
    """
    Simulates a service that uses the retrieved credentials securely, 
    ensuring sensitive data is not stored long-term in memory.
    """
    def __init__(self, username: str, password: str):
        # Store credentials only temporarily and minimally
        self.db_username = username
        self.db_password = password # Sensitive data stored briefly
        self.connection_status = False
        
    def connect(self):
        """Simulates connecting and using the credentials."""
        print(f"\n[CONNECTOR] Attempting connection as user: {self.db_username}...")
        
        # Simulate connection logic (e.g., hash comparison, network call)
        if len(self.db_password) > 10:
            self.connection_status = True
            print("[CONNECTOR] Connection successful. Data operations commencing.")
        else:
            print("[CONNECTOR] Connection failed: Invalid password length.")
            
    def disconnect_and_clear(self):
        """Explicitly clears sensitive data from memory."""
        if self.connection_status:
            print("[CONNECTOR] Disconnecting.")
            
        # CRITICAL: Explicitly zero out or set sensitive references to None
        self.db_password = None
        self.db_username = None
        print("[CONNECTOR] Sensitive credentials cleared from object memory.")

# --- 4. MAIN EXECUTION BLOCK ---

if __name__ == "__main__":
    
    # 1. Setup Mock Environment & Vault
    
    # A. Simulate Key Vault (Tier 1: Highest Priority, contains the real secret)
    VAULT_SECRETS = {
        "DB_USER": "prod_svc_account_01",
        "DB_PASS": "a_very_long_and_secure_vault_password_xyz123",
        "EXTERNAL_API_KEY": "VLT-1A2B3C4D5E6F"
    }
    
    # B. Simulate Environment Variables (Tier 2: Fallback, incomplete/outdated data)
    os.environ['DB_USER'] = 'dev_fallback_user'
    os.environ['DB_PASS'] = 'short_insecure_env_pass' # Missing API key means ENV check will FAIL initially

    # C. Instantiate the Vault Client (Simulating successful authentication for this run)
    vault = MockKeyVaultClient(VAULT_SECRETS, auth_status=True)
    
    print("--- Starting Microservice Credential Retrieval Test ---")
    
    manager = SecureCredentialManager(vault)
    
    # Test Run 1: Full success via Key Vault (Tier 1)
    # The initial ENV setup is incomplete, forcing the script to rely on the Vault.
    try:
        db_user, db_pass, api_key = manager.retrieve_credentials()
        
        print(f"\n[MAIN] API Key Retrieved Source: Vault (Key: {api_key[:4]}...)")
        
        # Use the credentials securely
        db_service = DefensiveDatabaseConnector(db_user, db_pass)
        db_service.connect()
        db_service.disconnect_and_clear()
        
    except SystemExit:
        print("\n--- Test Run 1 Aborted due to security policy. ---")

    print("\n" + "="*50 + "\n")
    
    # Test Run 2: Simulating Vault Failure, forcing Environment Variable Fallback (Tier 2)
    print("--- Starting Test Run 2: Vault Failure Simulation ---")
    
    # Clear the incomplete environment variables
    del os.environ['DB_USER']
    del os.environ['DB_PASS']
    
    # Set up COMPLETE environment variables for successful Tier 2 retrieval
    os.environ['DB_USER'] = 'backup_env_user'
    os.environ['DB_PASS'] = 'backup_env_password_long_enough_123'
    os.environ['EXTERNAL_API_KEY'] = 'ENV-9Z8Y7X6W'
    
    # Simulate a Vault client that fails authentication
    failing_vault = MockKeyVaultClient(VAULT_SECRETS, auth_status=False)
    manager_failover = SecureCredentialManager(failing_vault)
    
    try:
        # This will fail Tier 1 (Vault) and succeed Tier 2 (Env)
        db_user_2, db_pass_2, api_key_2 = manager_failover.retrieve_credentials()
        
        print(f"\n[MAIN] API Key Retrieved Source: Environment (Key: {api_key_2[:4]}...)")
        
        db_service_2 = DefensiveDatabaseConnector(db_user_2, db_pass_2)
        db_service_2.connect()
        db_service_2.disconnect_and_clear()
        
    except SystemExit:
        print("\n--- Test Run 2 Aborted due to security policy. ---")


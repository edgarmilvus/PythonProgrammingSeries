
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import os
import sys
from typing import Dict, List

# --- 1. Define required configuration keys ---
# Using constants enhances readability (Principle of Least Astonishment)
# and prevents silent errors from typos in string literals.
DB_USER_KEY: str = "APP_DB_USERNAME"
DB_PASS_KEY: str = "APP_DB_PASSWORD"
API_KEY_NAME: str = "EXTERNAL_SERVICE_API_KEY"

REQUIRED_SECRETS: List[str] = [DB_USER_KEY, DB_PASS_KEY, API_KEY_NAME]

def load_and_validate_secrets() -> Dict[str, str]:
    """
    Retrieves necessary secrets from environment variables and enforces
    the 'Fail Closed' security principle.
    """
    secrets: Dict[str, str] = {}
    missing_secrets: List[str] = []

    print("--- 1. Attempting to load secrets from environment ---")

    for key in REQUIRED_SECRETS:
        # Use os.getenv() for safe retrieval. This returns None if the variable
        # is unset, preventing a hard KeyError exception.
        value = os.getenv(key)

        if value is None or not value.strip():
            # Defensive check: Variable is missing (None) or contains only whitespace
            missing_secrets.append(key)
        else:
            # Store the retrieved secret securely in a local dictionary
            secrets[key] = value

    # --- 2. Validation and Failure Check (Fail Closed Enforcement) ---
    if missing_secrets:
        print("\n[SECURITY ALERT] Critical secrets are missing or empty:")
        for secret in missing_secrets:
            print(f"    - Required variable: {secret}")

        print("\nAction: Cannot proceed without full configuration. Exiting securely.")
        # Terminate the application immediately with a non-zero exit code (1)
        # to signal a critical failure to the calling process/orchestrator.
        sys.exit(1)

    print("--- 3. All required secrets loaded successfully ---")
    return secrets

def initialize_database_connection(db_user: str, db_pass: str) -> str:
    """
    Simulates the secure use of retrieved secrets.
    Note: The raw password is used internally but masked for external logging/display.
    """
    # In a real application, this secret would be passed directly to a database driver
    # (e.g., SQLAlchemy engine creation) and never logged in raw format.
    connection_string = f"postgresql://{db_user}:********@db.corp.net/prod"
    return connection_string

# ====================================================================
# SCENARIO 1: SUCCESSFUL RUN
# ====================================================================

print("--- RUN 1: Successful Configuration Test ---")
# Simulation: Setting the environment variables
os.environ[DB_USER_KEY] = "svc_user_prod"
os.environ[DB_PASS_KEY] = "P@ssword1234Secure"
os.environ[API_KEY_NAME] = "sk-xyz-12345-abcde-67890"

try:
    # 4. Execute the secure loading function
    app_secrets = load_and_validate_secrets()

    # 5. Demonstrate secure usage
    db_conn = initialize_database_connection(
        app_secrets[DB_USER_KEY],
        app_secrets[DB_PASS_KEY]
    )
    print(f"\n[OK] Database connection string initialized: {db_conn}")
    # Secure logging: Log metadata about the secret, not the secret itself
    print(f"[OK] API Key loaded (length: {len(app_secrets[API_KEY_NAME])} characters)")

except SystemExit:
    print("Application failed to start (Unexpected SystemExit in success run).")
finally:
    # Clean up environment variables for subsequent tests
    for key in REQUIRED_SECRETS:
        if key in os.environ:
            del os.environ[key]

print("\n" + "="*70 + "\n")

# ====================================================================
# SCENARIO 2: FAILURE RUN (Missing Secret)
# ====================================================================

print("--- RUN 2: Missing Critical Secret Test (Expected Failure) ---")
# Simulation: Only set the username, omitting the password and API key
os.environ[DB_USER_KEY] = "svc_user_prod"

try:
    # This call is expected to fail and raise SystemExit
    load_and_validate_secrets()
    print("Error: Application continued running despite missing secrets.")
except SystemExit as e:
    # We catch the SystemExit only to allow the demonstration script to finish.
    # In a real deployed application, the process would terminate here.
    print(f"\n[EXPECTED BEHAVIOR] Successfully caught termination signal: {e}. Application halted.")
finally:
    # Clean up environment variables
    if DB_USER_KEY in os.environ:
        del os.environ[DB_USER_KEY]

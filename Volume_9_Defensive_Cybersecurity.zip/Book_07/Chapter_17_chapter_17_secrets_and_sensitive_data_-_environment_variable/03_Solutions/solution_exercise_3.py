
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import logging
import sys
from typing import Any, Dict, List, Union

REDACTION_KEYS = {
    'password', 'secret', 'token', 'api_key', 'credential', 'auth_header'
}
REDACTION_PLACEHOLDER = "[REDACTED]"

def sanitize_data(data: Union[Dict, List, Any]) -> Union[Dict, List, Any]:
    """Recursively redacts sensitive keys in structured data."""
    
    if isinstance(data, dict):
        sanitized_data = {}
        for key, value in data.items():
            # Case-insensitive check for redaction
            if isinstance(key, str) and key.lower() in REDACTION_KEYS:
                sanitized_data[key] = REDACTION_PLACEHOLDER
            else:
                # Recursive call
                sanitized_data[key] = sanitize_data(value)
        return sanitized_data
        
    elif isinstance(data, list):
        # Recursive call for list elements
        return [sanitize_data(item) for item in data]
        
    return data

class SecretRedactionFilter(logging.Filter):
    """A logging filter that sanitizes structured log record arguments."""
    
    def filter(self, record: logging.LogRecord) -> bool:
        # Check for structured data passed via 'extra' (common for context)
        # Python logging copies 'extra' keys onto the record object.
        if hasattr(record, 'context') and isinstance(record.context, (dict, list)):
            # Mutate the record in place by replacing the sensitive context
            record.context = sanitize_data(record.context)
            
        # Example: If a dictionary was passed directly as the first argument
        if record.args and len(record.args) == 1 and isinstance(record.args[0], (dict, list)):
             record.args = (sanitize_data(record.args[0]),)
        
        return True

def setup_logging():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.WARNING)
    
    if logger.hasHandlers():
        logger.handlers.clear()

    # Configure handler and formatter to display the 'context' field
    handler = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter('%(levelname)s: %(message)s Context: %(context)s')
    handler.setFormatter(formatter)
    
    # Attach the custom filter
    handler.addFilter(SecretRedactionFilter())
    logger.addHandler(handler)
    
    return logger

def run_test_ex3():
    logger = setup_logging()
    
    sensitive_context = {
        "user_id": 101,
        "request_path": "/api/v1/data",
        "Headers": {
            "Auth_Header": "Bearer 1234567890", # Redact (case insensitive)
            "content_type": "application/json"
        },
        "payload": {
            "username": "admin",
            "password": "HardToGuessPassword" # Redact
        },
        "token": "ABC-DEF-GHI" # Redact
    }
    
    logger.warning("Failed authentication attempt.", extra={'context': sensitive_context})

run_test_ex3()

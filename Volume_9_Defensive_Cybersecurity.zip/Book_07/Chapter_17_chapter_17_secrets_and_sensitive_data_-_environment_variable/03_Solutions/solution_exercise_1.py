
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
from typing import Optional

class ConfigurationError(Exception):
    """Custom exception for configuration loading failures."""
    pass

def load_db_config_lbyl() -> str:
    # 1. Mandatory Configuration Check (LBYL)
    var_name = 'DB_CONNECTION_STRING'
    if var_name not in os.environ:
        raise ConfigurationError(f"Mandatory variable '{var_name}' is missing.")
    
    value = os.environ[var_name]
    if not value or value.isspace():
        raise ConfigurationError(f"Mandatory variable '{var_name}' is empty.")
    
    return value

def load_api_key_eafp() -> str:
    # 2. Mandatory Configuration Check (EAFP)
    var_name = 'API_KEY'
    try:
        api_key = os.environ[var_name]
    except KeyError:
        raise ConfigurationError(f"Mandatory variable '{var_name}' is missing.")
    
    # 3. Validation Check
    REQUIRED_LENGTH = 64
    if len(api_key) != REQUIRED_LENGTH:
        # Secure Failure Mode: Do not log the key value
        raise ConfigurationError(
            f"Variable '{var_name}' failed length validation. Expected {REQUIRED_LENGTH} characters."
        )
    
    return api_key

def load_retries() -> int:
    # 3. Type Coercion and Defaulting
    var_name = 'MAX_RETRIES'
    
    raw_value: Optional[str] = os.environ.get(var_name)
    if raw_value is None or raw_value == '':
        return 3 # Default value
    
    try:
        retries = int(raw_value)
        return retries
    except ValueError:
        # Secure Failure Mode: Do not log the invalid value
        raise ConfigurationError(
            f"Variable '{var_name}' is set but cannot be converted to an integer."
        )

def load_all_configs():
    # Setup environment for success simulation
    os.environ['DB_CONNECTION_STRING'] = 'sqlite://prod'
    os.environ['API_KEY'] = 'A' * 64
    # os.environ['MAX_RETRIES'] is unset, relying on default (3)

    try:
        db_conn = load_db_config_lbyl()
        api_key = load_api_key_eafp()
        max_retries = load_retries()
        
        print("--- Configuration Load Success ---")
        print(f"DB Connection Loaded (Length: {len(db_conn)})")
        print(f"API Key Loaded (Length: {len(api_key)})")
        print(f"Max Retries Loaded: {max_retries}")
        
    except ConfigurationError as e:
        print(f"\nFATAL CONFIGURATION ERROR: {e}")
        print("Application startup aborted.")

# Execute test
load_all_configs()

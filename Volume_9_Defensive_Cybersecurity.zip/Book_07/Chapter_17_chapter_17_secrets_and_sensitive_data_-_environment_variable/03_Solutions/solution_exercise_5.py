
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from pydantic import BaseModel, Field, ConfigDict
import json
from typing import Dict, Any

# 1. Secret Container (Pydantic V2 syntax for exclusion)
class ApplicationSecrets(BaseModel):
    # Configuration to handle serialization behavior
    model_config = ConfigDict(
        extra='ignore' 
    )
    
    # CRITICAL: Use exclude=True to prevent this field from being included 
    # in model_dump() or model_dump_json() by default.
    db_api_token: str = Field(
        ..., 
        description="Sensitive token for database access.", 
        exclude=True
    )

    def get_token(self) -> str:
        """Method for safe, internal retrieval."""
        return self.db_api_token

# 2. LLM Output Schema
class LLMGeneratedConfig(BaseModel):
    service_name: str
    version: str
    max_workers: int

# 3. Defensive Workflow Simulation
def run_simulation():
    # Load mock secrets
    secrets = ApplicationSecrets(db_api_token="SCT-12345-LLM-RISK")
    
    # Simulate LLM output
    llm_output = LLMGeneratedConfig(
        service_name="DataProcessor", 
        version="1.1.0", 
        max_workers=8
    )
    
    # Get the serialized (safe) dictionaries
    llm_dict = llm_output.model_dump()
    # The secret is excluded here due to Field(exclude=True)
    secrets_dict_safe = secrets.model_dump() 
    
    # Attempt to merge:
    final_config = llm_dict | secrets_dict_safe
    
    print("--- Final Configuration Check ---")
    print(f"Secrets Dictionary (Safe): {secrets_dict_safe}")
    print(f"Final Merged Configuration:\n{json.dumps(final_config, indent=4)}")
    
    if 'db_api_token' not in final_config:
        print("\nVerification Success: db_api_token was defensively excluded from serialization.")
    
    # 4. Prompt Template Security
    USER_INPUT = "I need a configuration for a data processor running version 1.1.0."
    
    PROMPT_TEMPLATE = (
        "Analyze the following user request: {user_request}. "
        "Generate a JSON configuration matching the required schema."
    )
    
    # Safely format the prompt using only non-sensitive data
    final_prompt = PROMPT_TEMPLATE.format(user_request=USER_INPUT)
    
    print("\n--- Final Prompt Check ---")
    print(final_prompt)
    if secrets.get_token() not in final_prompt:
        print("Verification Success: Prompt template does not contain the API token.")

run_simulation()

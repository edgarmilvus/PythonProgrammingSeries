
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# key_vault_client.py

class SecretNotFoundError(Exception):
    pass

class PermissionDeniedError(Exception):
    pass

MOCK_SECRETS = {
    "DB_PASSWORD": {"value": "db_secret_123", "tags": ["service_A", "prod"]},
    "GLOBAL_API_KEY": {"value": "global_key_xyz", "tags": ["admin", "service_B"]},
    "SERVICE_A_TOKEN": {"value": "token_A_456", "tags": ["service_A", "staging"]},
}

class MockKeyVaultClient:
    
    def __init__(self, application_scope: str):
        self.scope = application_scope

    def get_secret(self, secret_name: str) -> str:
        """Retrieves a secret only if it matches the client's application scope."""
        
        # 1. Existence Check (EAFP)
        try:
            secret_data = MOCK_SECRETS[secret_name]
        except KeyError:
            raise SecretNotFoundError(f"Secret '{secret_name}' not found.")
            
        # 2. Scope Check (PoLP)
        if self.scope not in secret_data['tags']:
            raise PermissionDeniedError(
                f"Access to secret '{secret_name}' denied. Required tag '{self.scope}' is missing."
            )
            
        # 3. Secure Return (Only the value, not metadata)
        return secret_data['value']

def run_test_ex4():
    client_a = MockKeyVaultClient(application_scope="service_A")
    
    print("\n--- Test 1: Successful Retrieval (Scoped) ---")
    try:
        secret_1 = client_a.get_secret("DB_PASSWORD")
        print(f"Success: DB_PASSWORD retrieved. Value: {secret_1[:5]}...")
    except Exception as e:
        print(f"Test 1 Failed: {e}")

    print("\n--- Test 2: Failure due to insufficient scope ---")
    try:
        client_a.get_secret("GLOBAL_API_KEY")
    except PermissionDeniedError as e:
        print(f"Success (Denied): {e}")
    except Exception as e:
        print(f"Test 2 Failed (Wrong Error): {e}")

    print("\n--- Test 3: Failure due to missing secret ---")
    try:
        client_a.get_secret("NON_EXISTENT_SECRET")
    except SecretNotFoundError as e:
        print(f"Success (Not Found): {e}")
    except Exception as e:
        print(f"Test 3 Failed (Wrong Error): {e}")

run_test_ex4()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os
import sys

class TemporaryCredential:
    """Manages a sensitive bytearray securely using a context manager."""
    
    def __init__(self, secret_data: str):
        # 1. Initialization: Store data as a mutable bytearray
        self._data = bytearray(secret_data.encode('utf-8'))
        
    def use_credential(self):
        # 2. Usage Simulation
        print(f"Credential used. Data length: {len(self._data)}")
        
    def zeroize(self):
        # 3. Zeroization: Overwrite all bytes with null bytes (b'\x00')
        # We use slice assignment for efficiency in overwriting the entire array.
        data_len = len(self._data)
        self._data[:] = b'\x00' * data_len
        print("Credential zeroized.")
        
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        # 4. Secure Cleanup
        try:
            self.zeroize()
        finally:
            # Explicitly delete the internal reference to minimize persistence
            if hasattr(self, '_data'):
                del self._data 

# Test block
def main_ex2():
    password = "MySuperSecretPassword123!"
    
    # Store a reference to the object for post-cleanup inspection (for verification only)
    cred_ref = None 
    
    print(f"Original data (Bytes): {password.encode('utf-8')}")
    
    with TemporaryCredential(password) as cred:
        cred.use_credential()
        # Keep the reference before __exit__ runs
        cred_ref = cred 
        
    print("\n--- After Context Exit (Cleanup Complete) ---")
    
    # 5. Verification: Check the state of the internal data structure
    if hasattr(cred_ref, '_data'):
        # If the reference was deleted, this will fail. If not, it will show zeroized data.
        print(f"Internal data state: {cred_ref._data}")
    else:
        print("Verification Success: Internal data reference deleted.")

main_ex2()

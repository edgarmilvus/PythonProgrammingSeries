
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import re
from collections import defaultdict
from datetime import datetime, timedelta
from typing import Dict, List, Tuple

# --- 1. Configuration and Constants ---

# Define the acceptable time window and request threshold for rate limiting
RATE_WINDOW_SECONDS = 60
MAX_REQUESTS_PER_WINDOW = 15

# List of paths commonly targeted during vulnerability reconnaissance
SUSPICIOUS_PATHS = [
    "/etc/passwd",
    "/.git/config",
    "/wp-admin/",
    "/phpmyadmin/",
    "/server-status",
    "/robots.txt", # Often checked first by scanners
]

# List of User Agent substrings known to belong to common scanners or bots
SUSPICIOUS_USER_AGENTS = [
    "Nmap Scripting Engine",
    "Nikto",
    "sqlmap",
    "Masscan",
    "Go-http-client",
]

# Regex pattern for parsing a standard combined access log format
# (IP - - [DD/Month/YYYY:HH:MM:SS +TZ] "METHOD PATH HTTP/1.X" STATUS SIZE "REFERRER" "USER_AGENT")
LOG_PATTERN = re.compile(
    r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}) - - \[(.*?)\] '  # IP and Timestamp
    r'"(GET|POST|HEAD|OPTIONS|PUT|DELETE) (.*?) HTTP/1\.[01]" ' # Method and Path
    r'(\d{3}) (\d+|-) "(.*?)" "(.*?)"' # Status, Size, Referrer, User Agent
)

# Type alias for clarity
IP_Request_History = Dict[str, List[datetime]]


# --- 2. Core Detection Functions ---

def parse_log_line(line: str) -> Tuple[str, datetime, str, str, str] | None:
    """Parses a single log line using the predefined regex."""
    match = LOG_PATTERN.match(line)
    if not match:
        return None

    ip, ts_str, method, path, status, _, _, user_agent = match.groups()

    # Convert timestamp string to datetime object for temporal analysis
    try:
        # Example format: 10/Aug/2024:14:21:50 +0000
        timestamp = datetime.strptime(ts_str.split(' ')[0], '%d/%b/%Y:%H:%M:%S')
    except ValueError:
        return None

    return ip, timestamp, method, path, user_agent


def check_rate_limiting(ip: str, timestamp: datetime, history: IP_Request_History) -> bool:
    """
    Checks if the current request exceeds the defined rate limit policy.
    This defends against brute-force scanning and denial of service attempts.
    """
    history[ip].append(timestamp)
    
    # Define the start of the time window
    time_window_start = timestamp - timedelta(seconds=RATE_WINDOW_SECONDS)
    
    # Filter the history to only include requests within the current window
    recent_requests = [
        t for t in history[ip] if t >= time_window_start
    ]
    
    # Update the history list for the IP, keeping only relevant entries
    history[ip] = recent_requests
    
    # Check the count against the defined threshold
    if len(recent_requests) > MAX_REQUESTS_PER_WINDOW:
        return True # Rate limit exceeded

    return False


def check_suspicious_path(path: str) -> bool:
    """Checks if the requested path is on the list of known sensitive targets."""
    # Normalize path by converting to lower case and ensuring trailing slash consistency
    normalized_path = path.lower()
    
    for forbidden_path in SUSPICIOUS_PATHS:
        if forbidden_path in normalized_path:
            return True
    return False


def check_suspicious_user_agent(user_agent: str) -> bool:
    """Checks if the User Agent string matches a known malicious scanner."""
    for agent in SUSPICIOUS_USER_AGENTS:
        if agent.lower() in user_agent.lower():
            return True
    return False


# --- 3. Main Analysis and Reporting ---

def analyze_logs(log_data: List[str]) -> Dict[str, List[str]]:
    """
    Processes all log data, applying all defensive checks, and compiling a report.
    """
    # Stores the history of requests per IP for rate limiting
    ip_request_history: IP_Request_History = defaultdict(list)
    
    # Stores the final report of detected anomalies
    threat_report: Dict[str, List[str]] = defaultdict(list)

    print(f"--- Starting Log Analysis ({len(log_data)} lines) ---")
    
    for line in log_data:
        parsed_data = parse_log_line(line)
        if not parsed_data:
            continue

        ip, timestamp, method, path, user_agent = parsed_data
        
        # 1. Check for excessive request rate (Reconnaissance/DDoS attempt)
        if check_rate_limiting(ip, timestamp, ip_request_history):
            if f"Rate Limit Exceeded (>{MAX_REQUESTS_PER_WINDOW}/min)" not in threat_report[ip]:
                threat_report[ip].append(
                    f"Rate Limit Exceeded (>{MAX_REQUESTS_PER_WINDOW} requests/min)"
                )
        
        # 2. Check for attempts to access sensitive files (Targeted Recon)
        if check_suspicious_path(path):
            threat_report[ip].append(
                f"Suspicious Path Access Attempt: {path}"
            )

        # 3. Check for known scanner signatures (Automated Tooling)
        if check_suspicious_user_agent(user_agent):
            threat_report[ip].append(
                f"Known Scanner User Agent Detected: {user_agent.strip()}"
            )

    return threat_report


def print_report(report: Dict[str, List[str]]):
    """Formats and prints the final threat report."""
    if not report:
        print("\n[INFO] Analysis complete. No active threats detected based on defined policies.")
        return

    print("\n\n--- COMPREHENSIVE THREAT REPORT ---")
    print(f"Total Unique IPs Flagged: {len(report)}\n")
    
    for ip, threats in report.items():
        print(f"[THREAT IP] {ip}")
        # Use a set to ensure unique threat messages per IP
        unique_threats = set(threats)
        for threat in unique_threats:
            print(f"  -> ATTACK TYPE: {threat}")
        print("-" * 30)


# --- 4. Simulated Log Data (Real-World Context) ---

# This simulates a web server log where several IPs are behaving normally,
# but two IPs (192.168.1.100 and 10.0.0.50) are conducting reconnaissance.
SIMULATED_LOGS = [
    # Normal traffic
    '10.1.1.1 - - [10/Aug/2024:14:21:50 +0000] "GET /index.html HTTP/1.1" 200 1024 "-" "Mozilla/5.0"',
    '10.1.1.2 - - [10/Aug/2024:14:21:51 +0000] "GET /assets/style.css HTTP/1.1" 200 512 "-" "Chrome/120.0"',
    
    # IP 192.168.1.100 starts aggressive scanning (Rate Limit Test)
    '192.168.1.100 - - [10/Aug/2024:14:22:00 +0000] "GET /api/v1/users HTTP/1.1" 404 150 "-" "Go-http-client/1.1"',
    '192.168.1.100 - - [10/Aug/2024:14:22:01 +0000] "GET /api/v1/data HTTP/1.1" 404 150 "-" "Go-http-client/1.1"',
    '192.168.1.100 - - [10/Aug/2024:14:22:02 +0000] "GET /admin/login HTTP/1.1" 302 150 "-" "Go-http-client/1.1"',
    # ... (12 more lines of rapid requests from 192.168.1.100 within the same minute) ...
    '192.168.1.100 - - [10/Aug/2024:14:22:10 +0000] "GET /test/1 HTTP/1.1" 404 150 "-" "Go-http-client/1.1"',
    '192.168.1.100 - - [10/Aug/2024:14:22:11 +0000] "GET /test/2 HTTP/1.1" 404 150 "-" "Go-http-client/1.1"',
    '192.168.1.100 - - [10/Aug/2024:14:22:12 +0000] "GET /test/3 HTTP/1.1" 404 150 "-" "Go-http-client/1.1"',
    '192.168.1.100 - - [10/Aug/2024:14:22:13 +0000] "GET /test/4 HTTP/1.1" 404 150 "-" "Go-http-client/1.1"',
    '192.168.1.100 - - [10/Aug/2024:14:22:14 +0000] "GET /test/5 HTTP/1.1" 404 150 "-" "Go-http-client/1.1"',
    '192.168.1.100 - - [10/Aug/2024:14:22:15 +0000] "GET /test/6 HTTP/1.1" 404 150 "-" "Go-http-client/1.1"',
    '192.168.1.100 - - [10/Aug/2024:14:22:16 +0000] "GET /test/7 HTTP/1.1" 404 150 "-" "Go-http-client/1.1"',
    '192.168.1.100 - - [10/Aug/2024:14:22:17 +0000] "GET /test/8 HTTP/1.1" 404 150 "-" "Go-http-client/1.1"',
    '192.168.1.100 - - [10/Aug/2024:22:17:18 +0000] "GET /test/9 HTTP/1.1" 404 150 "-" "Go-http-client/1.1"', # Exceeds 15 requests
    
    # IP 10.0.0.50 uses a known scanner and targets sensitive files (Targeted Recon)
    '10.0.0.50 - - [10/Aug/2024:14:23:00 +0000] "GET /robots.txt HTTP/1.1" 200 100 "-" "Nikto/2.1.6"',
    '10.0.0.50 - - [10/Aug/2024:14:23:01 +0000] "GET /phpmyadmin/index.php HTTP/1.1" 404 150 "-" "Nikto/2.1.6"',
    '10.0.0.50 - - [10/Aug/2024:14:23:02 +0000] "GET /etc/passwd HTTP/1.1" 404 150 "-" "Nikto/2.1.6"',
    
    # Normal traffic continues
    '10.1.1.3 - - [10/Aug/2024:14:23:10 +0000] "GET /contact.html HTTP/1.1" 200 800 "-" "Safari/605.1.15"',
]


# --- 5. Execution Block ---

if __name__ == "__main__":
    # Execute the analysis on the simulated data
    threat_results = analyze_logs(SIMULATED_LOGS)
    
    # Output the final findings
    print_report(threat_results)



#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import os
from pathlib import Path

# 1. Secure Base Definition (Must be an absolute path)
SECURE_ROOT_DIR = Path('/var/www/data/').resolve()

class TraversalAttemptError(Exception):
    """Custom exception raised when a path traversal attempt is detected."""
    pass

def safe_resolve_path(user_input, base_dir=SECURE_ROOT_DIR):
    """
    Safely resolves a user-provided path fragment against a secure base directory.
    """
    
    # 3. Combine and Normalize
    try:
        # Combine base directory and user input
        combined_path = base_dir / user_input
        
        # Resolve path: converts to absolute path and handles '..' and '.' sequences
        resolved_path = combined_path.resolve()
    except Exception as e:
        # Handle cases where path segments are invalid or non-existent
        raise TraversalAttemptError(f"Path resolution failed: {e}")

    # 4. Boundary Check (Core Defense)
    # Check if the resolved path is a subdirectory of the base directory.
    # is_relative_to is the robust, modern way to check containment.
    if not resolved_path.is_relative_to(base_dir):
        # 5. Output: Raise exception if escape is detected
        raise TraversalAttemptError("Resolved path attempts to escape the secure root directory.")
    
    # 5. Output: Return the safe, absolute path
    return resolved_path

# --- Test Cases ---
if __name__ == "__main__":
    # Ensure the root exists for accurate absolute path resolution
    if not SECURE_ROOT_DIR.exists():
        os.makedirs(SECURE_ROOT_DIR, exist_ok=True)
        
    test_inputs = [
        "images/profile.jpg",               # Safe relative path
        "data/../images/logo.png",          # Safe, normalized path within bounds
        "../../../etc/passwd",              # Traversal attempt 1 (relative escape)
        "/etc/hosts",                       # Traversal attempt 2 (absolute outside root)
        "secret/./file.txt"                 # Safe, simple normalization
    ]
    
    print(f"SECURE ROOT: {SECURE_ROOT_DIR}")
    for user_input in test_inputs:
        try:
            safe_path = safe_resolve_path(user_input)
            print(f"[SECURE] Input: '{user_input}'\n\t-> Result: {safe_path}")
        except TraversalAttemptError as e:
            print(f"[BLOCKED] Input: '{user_input}'\n\t-> Reason: {e}")

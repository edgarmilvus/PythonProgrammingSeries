
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import re
import logging
import sys

# Configure basic logging to capture security attempts
logging.basicConfig(level=logging.WARNING, 
                    format='%(asctime)s - %(levelname)s - %(message)s',
                    stream=sys.stderr)

class CommandInjectionError(Exception):
    """Custom security exception for command injection attempts."""
    pass

def sanitize_path_input(input_string):
    """
    Validates a path string against command injection patterns.
    """
    # Blacklist pattern: Checks for command separators (;, |, &), 
    # execution characters ($, (, ), `), and directory traversal (../)
    malicious_pattern = r'[;&|`$()]|\.\./'
    
    if re.search(malicious_pattern, input_string):
        # Log the violation before raising the exception
        logging.warning(f"SECURITY VIOLATION: Command injection attempt detected in input: '{input_string}'")
        
        # Raise the custom security exception
        raise CommandInjectionError("Input contains prohibited command execution or traversal characters.")
    
    # If safe, strip whitespace and return the validated string
    return input_string.strip()

# --- Testing ---
if __name__ == "__main__":
    test_cases = [
        "/var/log/app.log",
        "data; rm -rf /",
        "../secrets/db.conf",
        "file`id`.txt"
    ]

    for case in test_cases:
        try:
            safe_path = sanitize_path_input(case)
            print(f"[SAFE] Input: '{case}' -> Path: '{safe_path}'")
        except CommandInjectionError as e:
            print(f"[BLOCKED] Input: '{case}' -> Reason: {e}")

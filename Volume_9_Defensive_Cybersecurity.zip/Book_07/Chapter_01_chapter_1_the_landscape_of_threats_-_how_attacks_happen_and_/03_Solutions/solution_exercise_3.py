
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import hashlib
import os
import json
from pathlib import Path

# Configuration
TARGET_FILENAME = 'wsgi_config.py'
BASELINE_FILE = 'integrity_baseline.json'
HASH_ALGORITHM = 'sha256'

def calculate_file_hash(filepath):
    """Calculates the SHA256 hash of a given file by reading it in chunks."""
    hasher = hashlib.sha256()
    try:
        with open(filepath, 'rb') as f:
            # Read in 4KB chunks to handle large files efficiently
            while chunk := f.read(4096):
                hasher.update(chunk)
        return hasher.hexdigest()
    except FileNotFoundError:
        return None

def generate_baseline(filepath):
    """Generates and stores the baseline hash."""
    current_hash = calculate_file_hash(filepath)
    
    if current_hash is None:
        print(f"CRITICAL: Target file '{filepath}' not found.")
        return False
        
    baseline_data = {
        'filepath': str(filepath),
        'hash_algorithm': HASH_ALGORITHM,
        'baseline_hash': current_hash,
        'timestamp': os.path.getctime(filepath) # Record creation time
    }
    
    with open(BASELINE_FILE, 'w') as f:
        json.dump(baseline_data, f, indent=4)
    print(f"[SUCCESS] Baseline generated for '{filepath}'.")
    return True

def verify_integrity(filepath):
    """Compares the current file hash against the stored baseline."""
    
    try:
        with open(BASELINE_FILE, 'r') as f:
            stored_hash = json.load(f)['baseline_hash']
    except (FileNotFoundError, json.JSONDecodeError):
        print(f"[ERROR] Baseline file '{BASELINE_FILE}' not accessible or corrupted.")
        return False

    current_hash = calculate_file_hash(filepath)
    
    if current_hash is None:
        print(f"[CRITICAL VIOLATION] Target file '{filepath}' is missing.")
        return False

    if current_hash == stored_hash:
        print(f"[INTEGRITY MAINTAINED] Hash match for '{filepath}'.")
        return True
    else:
        print("\n" + "="*60)
        print(f"[CRITICAL INTEGRITY VIOLATION] File '{filepath}' HAS BEEN TAMPERED WITH!")
        print(f"  > Stored Hash: {stored_hash}")
        print(f"  > Current Hash:  {current_hash}")
        print("="*60 + "\n")
        return False

if __name__ == "__main__":
    target_path = Path(os.getcwd()) / TARGET_FILENAME
    
    # 0. Setup: Create mock configuration file
    with open(target_path, 'w') as f:
        f.write("APP_SECRET = 'initial_key'\nDEBUG = False")

    # 1. Generate Baseline
    generate_baseline(target_path)
    
    # 2. Verification (Initial)
    verify_integrity(target_path)
    
    # 3. Simulate Tampering
    with open(target_path, 'a') as f:
        f.write("\n# Attacker injection")
    
    # 4. Verification (Tampered)
    verify_integrity(target_path)

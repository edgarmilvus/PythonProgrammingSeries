
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import socket
import time

# Configuration
TARGET_HOST = '127.0.0.1'  # Target localhost for safe testing
PORTS_TO_SCAN = [21, 22, 80, 443, 3306, 8080, 9999]
TIMEOUT = 1.0  # Strict timeout limit

def scan_port(host, port, timeout):
    """Attempts to connect to a port and grab the service banner."""
    try:
        # Initialize TCP socket (AF_INET for IPv4, SOCK_STREAM for TCP)
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        
        # connect_ex returns 0 if successful, otherwise an error code
        result = s.connect_ex((host, port))
        
        if result == 0:
            status = "Open"
            banner = ""
            try:
                # Attempt basic banner retrieval
                # For common ports, send a small request to provoke a response
                if port in [80, 443]:
                    s.send(b'HEAD / HTTP/1.1\r\nHost: ' + host.encode() + b'\r\n\r\n')
                
                # Receive banner data
                banner = s.recv(1024).decode('utf-8', errors='ignore').strip()
                if not banner:
                    banner = "Open (No banner received or service silent)."
            except socket.timeout:
                banner = "Open (Timeout during banner grab)."
            except Exception:
                banner = "Open (Error retrieving banner)."
        else:
            status = "Closed"
            banner = ""
            
        s.close()
        return status, banner
        
    except socket.gaierror:
        return "Error", "Hostname could not be resolved."
    except socket.error as e:
        return "Error", f"Network error: {e}"
    except Exception as e:
        return "Error", f"Unexpected error: {e}"

def run_port_scan(host, ports):
    """Executes the port scan and generates the report."""
    print(f"--- Starting Targeted Scan on {host} ({TIMEOUT}s timeout) ---")
    
    for port in ports:
        status, banner = scan_port(host, port, TIMEOUT)
        
        if status == "Open":
            print(f"[+] Port {port:<5} | Status: {status:<6} | Banner: {banner.replace('\n', ' ')}")
        elif status == "Closed":
            print(f"[-] Port {port:<5} | Status: {status:<6}")
        else:
            print(f"[!] Port {port:<5} | Status: {status:<6} | Details: {banner}")

if __name__ == "__main__":
    run_port_scan(TARGET_HOST, PORTS_TO_SCAN)

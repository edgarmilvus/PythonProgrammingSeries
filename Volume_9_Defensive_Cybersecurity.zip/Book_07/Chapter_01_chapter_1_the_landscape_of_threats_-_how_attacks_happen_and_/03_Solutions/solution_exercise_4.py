
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import logging
import os
from datetime import datetime

# 1. Policy Definition
# Dictionary defining the ONLY acceptable open ports.
APPROVED_PORTS_POLICY = {
    22: 'SSH',
    80: 'HTTP',
    443: 'HTTPS',
    53: 'DNS',
}

# 4. Configure Logging for Critical Violations
LOG_FILE = 'policy_violations.log'

# Configure the logging module to write CRITICAL level messages to a dedicated file
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.CRITICAL, 
    format='%(asctime)s - SECURITY VIOLATION - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

def enforce_security_policy(observed_ports, policy):
    """
    Compares observed open ports against the defined security policy
    and logs critical violations for unauthorized ports.
    """
    violations_found = 0
    
    print(f"--- Policy Enforcement Started ---")
    
    for port in observed_ports:
        if port in policy:
            # Operational Finding: Approved service
            print(f"[OK] Port {port} is approved ({policy[port]}).")
        else:
            # Security Violation: Unauthorized service detected
            violation_message = f"Unauthorized open port detected: {port}. Policy requires immediate investigation."
            
            # Log the violation at CRITICAL level
            logging.critical(violation_message)
            
            print(f"[VIOLATION] {violation_message}")
            violations_found += 1
            
    print(f"\nPolicy Enforcement Complete. Violations logged to: {LOG_FILE}")

# 2. Audit Simulation: Observed open ports
OBSERVED_OPEN_PORTS = [22, 80, 3389, 5000, 443, 21]

if __name__ == "__main__":
    # Clean up previous log file for clear testing
    if os.path.exists(LOG_FILE):
        os.remove(LOG_FILE)
        
    enforce_security_policy(OBSERVED_OPEN_PORTS, APPROVED_PORTS_POLICY)

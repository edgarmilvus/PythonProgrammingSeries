
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import os
from pathlib import Path
import sys

# --- Configuration Section ---
# Define the absolute, resolved root directory where all safe files must reside.
# Using resolve() immediately here ensures we have a clean, absolute starting point.
try:
    # Use a temporary directory for robustness in testing environments
    SAFE_CONFIG_ROOT = Path(os.environ.get("APP_CONFIG_DIR", "/tmp/app_configs")).resolve()
except Exception as e:
    # Handle cases where the temporary path might be inaccessible
    print(f"FATAL: Could not resolve base directory path. {e}")
    sys.exit(1)

def initialize_environment():
    """Sets up the necessary directories and dummy files for the simulation."""
    print("--- Initializing Secure Environment Setup ---")
    
    # 1. Create the safe configuration root if it doesn't exist
    os.makedirs(SAFE_CONFIG_ROOT, exist_ok=True)
    print(f"Base Safe Directory: {SAFE_CONFIG_ROOT}")
    
    # 2. Create a safe file within the root
    safe_file_path = SAFE_CONFIG_ROOT / "settings.json"
    safe_file_path.write_text('{"db": "production_cluster_A"}')
    print(f"Created safe configuration file: {safe_file_path}")
    
    # 3. Simulate the existence of a sensitive, restricted system file 
    # (We use a dummy file in /tmp to avoid permission issues on real systems, 
    # but the logic simulates accessing files like /etc/passwd)
    SENSITIVE_FILE_PATH = Path("/tmp/system_secret.txt")
    SENSITIVE_FILE_PATH.write_text("This is a sensitive system secret.")
    print(f"Created simulated sensitive file: {SENSITIVE_FILE_PATH}")
    
    # Clean up the sensitive file path variable to prevent accidental use
    del SENSITIVE_FILE_PATH
    print("-" * 40)


def validate_and_access_config(user_input_path: str) -> bool:
    """
    Defensively validates a user-provided file path using Pathlib's resolution 
    and containment checks to prevent Path Traversal.
    
    Args:
        user_input_path: The path string provided by an untrusted source.
    
    Returns:
        True if the path is safe, exists, and accessible; False otherwise.
    """
    
    print(f"\n[ATTEMPT] User requested path: '{user_input_path}'")
    
    try:
        # 1. Path Normalization (Critical Defense Step)
        # We immediately convert the untrusted string input into a Path object 
        # and resolve it. resolve() strips '..', follows symlinks, and converts 
        # to an absolute path, neutralizing traversal attempts.
        requested_path = Path(user_input_path).resolve()
        
        print(f"   [DEFENSE] Normalized Path: {requested_path}")
        
        # 2. Containment Check (The Core Defensive Policy)
        # is_relative_to() checks if the resolved path starts with the SAFE_CONFIG_ROOT.
        # This is the LBYL (Look Before You Leap) security check.
        if not requested_path.is_relative_to(SAFE_CONFIG_ROOT):
            print(f"   [ALERT] TRAVERSAL BLOCKED: Resolved path is outside the safe root ({SAFE_CONFIG_ROOT}).")
            return False
            
        # 3. Existence Check (Ensuring the target is real before attempting I/O)
        if not requested_path.exists():
            print(f"   [ERROR] File not found at safe location: {requested_path}")
            return False

        # 4. Success: Simulate safe file access
        print(f"   [SUCCESS] Access granted to safe file: {requested_path}")
        # In a real application, the file content would be read and processed here.
        # Example: with open(requested_path, 'r') as f: data = f.read()
        return True

    # 5. EAFP Error Handling (Robustness and Defense)
    # Catch specific exceptions for cleaner error reporting and to prevent stack trace leakage.
    except FileNotFoundError:
        # This catches errors if a component of the path (e.g., a directory) 
        # doesn't exist during the resolve operation.
        print("   [ERROR] Path resolution failed: Component not found.")
        return False
    except PermissionError:
        # This catches errors if the operating system denies the application 
        # the right to access the resolved path.
        print("   [ERROR] Permission denied accessing the file.")
        return False
    except Exception as e:
        # Catch all other unexpected OS or formatting errors.
        print(f"   [CRITICAL] Unexpected path validation error: {type(e).__name__}: {e}")
        return False

# --- Execution Simulation ---
initialize_environment()

# TEST CASE 1: Safe Access (Intended behavior)
validate_and_access_config("settings.json")

# TEST CASE 2: Path Traversal Attack Attempt 1 (Using '..')
# Attacker tries to step out of the safe root and access the simulated secret file.
validate_and_access_config(f"{SAFE_CONFIG_ROOT}/../tmp/system_secret.txt")

# TEST CASE 3: Path Traversal Attack Attempt 2 (Absolute path)
# Attacker tries to bypass the relative check by using an absolute path.
validate_and_access_config("/tmp/system_secret.txt")

# TEST CASE 4: Non-existent safe file (Should fail gracefully at step 3)
validate_and_access_config("nonexistent_config.yaml")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import hashlib
import json
import os
import sys
from typing import Dict, List, Any

# --- Configuration and Setup (Reusing constants from Exercise 1) ---
BASELINE_FILE = "fim_baseline.json"
MONITORED_ROOT_DIR = "/tmp/monitored_dir"

# --- Hashing Function (Reused from Exercise 1) ---
def generate_sha256(filepath: str) -> Optional[str]:
    """Calculates the SHA-256 hash of a file's contents."""
    try:
        hasher = hashlib.sha256()
        with open(filepath, 'rb') as f:
            hasher.update(f.read())
        return hasher.hexdigest()
    except FileNotFoundError:
        return None
    except Exception:
        return None

def load_baseline(filepath: str) -> Dict[str, str]:
    """Loads the baseline dictionary from a JSON file."""
    try:
        with open(filepath, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"FATAL: Baseline file not found at {filepath}.", file=sys.stderr)
        sys.exit(2)
    except json.JSONDecodeError:
        print(f"FATAL: Baseline file {filepath} is corrupted (invalid JSON).", file=sys.stderr)
        sys.exit(2)

def generate_integrity_report(baseline: Dict[str, str], monitored_dir: str) -> Dict[str, List[Any]]:
    """Compares current file states against the baseline and generates a report."""
    
    report: Dict[str, List[Any]] = {
        "MODIFIED": [],
        "DELETED": [],
        "ADDED": [],
        "NO CHANGE": []
    }
    
    current_paths = set()
    
    # 1. Check existing baseline paths (MODIFIED, DELETED, NO CHANGE)
    for path, baseline_hash in baseline.items():
        current_hash = generate_sha256(path)
        
        if current_hash is None:
            # File existed in baseline but is now gone
            report["DELETED"].append(path)
        elif current_hash == baseline_hash:
            # File exists and matches
            report["NO CHANGE"].append(path)
        else:
            # File exists but hash changed
            report["MODIFIED"].append({
                "path": path,
                "baseline_hash": baseline_hash,
                "current_hash": current_hash
            })
        
        # Track paths that currently exist on the system (for step 2)
        if current_hash is not None:
            current_paths.add(path)

    # 2. Scan the monitored directory for ADDED files
    if os.path.isdir(monitored_dir):
        for root, _, files in os.walk(monitored_dir):
            for filename in files:
                full_path = os.path.join(root, filename)
                # Check if this file is NOT in the original baseline
                if full_path not in baseline:
                    # Check if it's a new file (not just a monitored file from elsewhere)
                    if full_path not in current_paths: 
                        report["ADDED"].append(full_path)
    
    return report

def print_report(report: Dict[str, List[Any]]):
    """Prints the structured report in a human-readable format."""
    print("\n--- FIM Integrity Check Report ---")
    
    total_alerts = 0
    
    for status, items in report.items():
        if status == "NO CHANGE":
            continue # Skip printing NO CHANGE for brevity
            
        if items:
            print(f"\n[{status} ({len(items)})]")
            total_alerts += len(items)
            
            for item in items:
                if status == "MODIFIED":
                    print(f"  Path: {item['path']}")
                    print(f"    Baseline Hash: {item['baseline_hash']}")
                    print(f"    Current Hash:  {item['current_hash']}")
                else:
                    print(f"  {item}")
                    
    print(f"\n--- Summary ---")
    print(f"Total files checked: {len(report['NO CHANGE']) + len(report['MODIFIED']) + len(report['DELETED'])}")
    print(f"Total alerts detected: {total_alerts}")
    
    return total_alerts

# --- Setup Simulation for Testing ---
def simulate_changes():
    """Modifies files to test all detection states."""
    # Find a file that was monitored (Exercise 1 created /tmp/fim_test_file_1.txt)
    modified_path = "/tmp/fim_test_file_1.txt"
    deleted_path = "/tmp/config.cfg"
    added_path = os.path.join(MONITORED_ROOT_DIR, "new_alert_file.dat")
    
    # 1. Simulate MODIFIED
    if os.path.exists(modified_path):
        with open(modified_path, "a") as f:
            f.write("\n--- UNAUTHORIZED CHANGE ---")
        print(f"[SIMULATION] Modified content of {modified_path}")
        
    # 2. Simulate DELETED
    if os.path.exists(deleted_path):
        os.remove(deleted_path)
        print(f"[SIMULATION] Deleted file {deleted_path}")

    # 3. Simulate ADDED
    os.makedirs(MONITORED_ROOT_DIR, exist_ok=True)
    with open(added_path, "w") as f:
        f.write("A new file appeared.")
    print(f"[SIMULATION] Added new file {added_path}")


# --- Main Execution ---
if __name__ == "__main__":
    
    # NOTE: Run Exercise 1 first to create fim_baseline.json
    
    # 0. Simulate changes to test the checker
    simulate_changes()
    
    # 1. Load Baseline
    baseline_data = load_baseline(BASELINE_FILE)
    
    # 2. Generate Report
    report_data = generate_integrity_report(baseline_data, MONITORED_ROOT_DIR)
    
    # 3. Print Report and determine exit status
    alerts = print_report(report_data)
    
    # 4. Exit Status Logic
    if alerts > 0:
        print("\nALERT: Integrity violations detected.")
        sys.exit(1) # Non-zero exit status for alerts
    else:
        print("\nSystem integrity clean. No changes detected.")
        sys.exit(0) # Zero exit status for clean state

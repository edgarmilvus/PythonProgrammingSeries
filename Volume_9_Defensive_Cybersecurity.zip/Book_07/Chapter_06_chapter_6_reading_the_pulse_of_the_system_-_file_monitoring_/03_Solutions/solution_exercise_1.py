
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import hashlib
import json
import os
import sys
from typing import Optional, Dict

# --- Configuration and Setup ---

# Define paths for temporary files and the baseline
BASELINE_FILE = "fim_baseline.json"
TEMP_FILE_1 = "/tmp/fim_test_file_1.txt"
TEMP_FILE_2 = "/tmp/config.cfg"
TEMP_FILE_3 = "/tmp/monitored_dir/critical_script.py"

MONITORED_FILES = [
    TEMP_FILE_1,
    TEMP_FILE_2,
    TEMP_FILE_3,
    "/etc/hosts"  # A common critical system file
]

# Ensure the temporary files and directory exist for the baseline run
os.makedirs(os.path.dirname(TEMP_FILE_3), exist_ok=True)
for path in [TEMP_FILE_1, TEMP_FILE_2, TEMP_FILE_3]:
    try:
        with open(path, "w") as f:
            f.write(f"Initial content for {os.path.basename(path)}.")
    except IOError as e:
        print(f"Warning: Could not create test file {path}. Skipping. Error: {e}")
        MONITORED_FILES.remove(path)


def generate_sha256(filepath: str) -> Optional[str]:
    """
    Calculates the SHA-256 hash of a file's contents.
    Returns None if the file is not found.
    """
    try:
        hasher = hashlib.sha256()
        # Open in binary read mode
        with open(filepath, 'rb') as f:
            # Read the entire file content (suitable for small/medium files)
            content = f.read()
            hasher.update(content)
        return hasher.hexdigest()
    except FileNotFoundError:
        return None
    except Exception as e:
        print(f"Error reading or hashing file {filepath}: {e}", file=sys.stderr)
        return None

def generate_baseline(file_list: list) -> Dict[str, str]:
    """
    Generates the baseline dictionary (path: hash) for the given file list.
    """
    baseline_data = {}
    processed_count = 0
    
    print(f"--- Starting Baseline Generation ({len(file_list)} files) ---")
    
    for filepath in file_list:
        file_hash = generate_sha256(filepath)
        if file_hash:
            baseline_data[filepath] = file_hash
            processed_count += 1
            print(f"[OK] Hashed: {filepath}")
        else:
            # We record files that could not be found, but we won't add None to the JSON
            print(f"[SKIP] File not found or error: {filepath}")

    print(f"\nSuccessfully processed {processed_count} files.")
    return baseline_data

def calculate_file_hash(filepath: str) -> str:
    """Helper to calculate the hash of a file (used for the baseline file itself)."""
    hasher = hashlib.sha256()
    with open(filepath, 'rb') as f:
        hasher.update(f.read())
    return hasher.hexdigest()

# --- Main Execution ---
if __name__ == "__main__":
    
    # 1. Generate the baseline data
    baseline_output = generate_baseline(MONITORED_FILES)

    # 2. Store the baseline data to JSON
    try:
        with open(BASELINE_FILE, 'w') as f:
            json.dump(baseline_output, f, indent=4)
        print(f"\n[SUCCESS] Baseline saved to {BASELINE_FILE}")

        # 3. Calculate and print the meta-hash of the baseline file
        baseline_meta_hash = calculate_file_hash(BASELINE_FILE)
        print(f"--- Security Check ---")
        print(f"Baseline File Integrity (Self-Hash): {baseline_meta_hash}")
        
    except IOError as e:
        print(f"FATAL: Could not write baseline file {BASELINE_FILE}. Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"An unexpected error occurred: {e}", file=sys.stderr)
        sys.exit(1)

    # Cleanup (optional, but good practice for test files)
    # os.remove(TEMP_FILE_1)
    # os.remove(TEMP_FILE_2)
    # os.remove(TEMP_FILE_3)
    # os.rmdir(os.path.dirname(TEMP_FILE_3))

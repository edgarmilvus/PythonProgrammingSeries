
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import hashlib
import time
from typing import Dict, Any

# --- Simulation Helpers ---
# We need a simulated hash function that can change its output for testing 'MODIFIED'
_SIMULATED_HASH_COUNTER = 0

def generate_hash_simulated(filepath: str, force_change: bool = False) -> str:
    """
    Simulates hashing. If force_change is True, returns a unique hash 
    to simulate file content modification.
    """
    global _SIMULATED_HASH_COUNTER
    
    if force_change:
        _SIMULATED_HASH_COUNTER += 1
        # Generate a unique hash based on time and a counter
        data = f"{filepath}_{time.time()}_{_SIMULATED_HASH_COUNTER}".encode('utf-8')
        return hashlib.sha256(data).hexdigest()
    else:
        # Simulate a stable hash for existing content
        return hashlib.sha256(filepath.encode('utf-8')).hexdigest()

# --- FIM Event Handler Class ---

class FIMEventHandler:
    """Handles real-time file system events and manages the integrity baseline."""
    
    def __init__(self, initial_baseline: Dict[str, str]):
        # This dictionary represents the trusted, in-memory state of critical files
        self.baseline = initial_baseline
        print(f"[INIT] Handler initialized. Baseline size: {len(self.baseline)}")

    def on_created(self, path: str):
        """Action taken when a new file is created."""
        print(f"\n[EVENT: CREATED] Path: {path}")
        
        # 1. Calculate current hash
        current_hash = generate_hash_simulated(path)
        
        # 2. Update baseline (establish trust)
        self.baseline[path] = current_hash
        print(f" -> ACTION: Added to baseline. New Hash: {current_hash[:8]}...")
        print(f" -> ALERT: INFORMATIONAL - New file created and baseline updated.")

    def on_deleted(self, path: str):
        """Action taken when a file is deleted."""
        print(f"\n[EVENT: DELETED] Path: {path}")
        
        if path in self.baseline:
            # 1. Remove from baseline
            del self.baseline[path]
            print(" -> ACTION: Removed from baseline.")
            print(f" -> ALERT: HIGH PRIORITY - Monitored file deleted.")
        else:
            print(" -> INFO: Deletion of unmonitored file.")

    def on_modified(self, path: str, simulated_change: bool = False):
        """Action taken when a file is modified."""
        print(f"\n[EVENT: MODIFIED] Path: {path}")
        
        if path not in self.baseline:
            print(" -> WARNING: Modification detected on unmonitored file. Skipping integrity check.")
            return

        baseline_hash = self.baseline[path]
        
        # Simulate re-hashing the file (forcing a change for testing if needed)
        current_hash = generate_hash_simulated(path, force_change=simulated_change)
        
        if current_hash != baseline_hash:
            # Hash mismatch detected!
            print(" -> ALERT: CRITICAL! HASH MISMATCH DETECTED!")
            print(f"    Baseline: {baseline_hash[:16]}...")
            print(f"    Current:  {current_hash[:16]}...")
            
            # Update baseline to the new state (optional, depending on policy)
            self.baseline[path] = current_hash
            print(" -> ACTION: Baseline updated to reflect new (tampered) state.")
        else:
            # Benign modification (e.g., file saved but contents unchanged)
            print(" -> INFO: Modification detected, but hash matches baseline.")
            # Update baseline (re-write the same hash) and log minor event
            self.baseline[path] = current_hash

    def on_moved(self, src_path: str, dest_path: str):
        """Action taken when a file is moved (renamed)."""
        print(f"\n[EVENT: MOVED] Source: {src_path} -> Destination: {dest_path}")
        
        if src_path in self.baseline:
            # 1. Retrieve the trusted hash
            trusted_hash = self.baseline[src_path]
            
            # 2. Remove the old path
            del self.baseline[src_path]
            
            # 3. Add the new path with the same trusted hash
            self.baseline[dest_path] = trusted_hash
            
            print(f" -> ACTION: Baseline updated. Path changed, hash retained ({trusted_hash[:8]}...)")
            print(" -> ALERT: INFORMATIONAL - Monitored file moved.")
        else:
            print(" -> INFO: Movement detected on unmonitored file.")


# --- Interactive Testing Script ---
if __name__ == "__main__":
    
    # Initial setup: A critical file and a non-critical file (for testing unmonitored events)
    initial_baseline = {
        "/etc/nginx/config.conf": generate_hash_simulated("/etc/nginx/config.conf"),
        "/usr/bin/critical_tool": generate_hash_simulated("/usr/bin/critical_tool")
    }
    
    handler = FIMEventHandler(initial_baseline)
    
    # Test Scenario A: Creation
    handler.on_created("/tmp/new_script.sh")
    
    # Test Scenario B: Deletion
    handler.on_deleted("/usr/bin/critical_tool")
    
    # Test Scenario C: Modification (Simulating unauthorized change)
    handler.on_modified("/etc/nginx/config.conf", simulated_change=True)
    
    # Test Scenario D: Movement
    handler.on_moved("/tmp/new_script.sh", "/var/www/secure_area/new_script.sh")
    
    # Final state check
    print("\n--- Final Baseline State ---")
    print(handler.baseline)

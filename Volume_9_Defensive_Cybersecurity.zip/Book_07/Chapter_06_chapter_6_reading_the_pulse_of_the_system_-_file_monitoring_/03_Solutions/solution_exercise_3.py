
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
import sys
from typing import List, Iterator, Set, Tuple

# --- Reusable Component 1: Hashing (DRY Principle) ---
# We assume generate_sha256 is imported or defined here (as in Ex 1)
# For simplicity and self-containment, we redefine the simple version:
import hashlib
def generate_sha256(filepath: str) -> Optional[str]:
    """Calculates the SHA-256 hash of a file's contents."""
    try:
        hasher = hashlib.sha256()
        with open(filepath, 'rb') as f:
            hasher.update(f.read())
        return hasher.hexdigest()
    except FileNotFoundError:
        return None
    except Exception:
        return None

# --- Configuration Management ---

def get_exclusion_list() -> Set[str]:
    """
    Reads and parses the FIM_EXCLUDE_DIRS environment variable.
    Returns a set of normalized directory paths to exclude.
    """
    # Get variable, default to empty string if not set
    exclude_var = os.environ.get("FIM_EXCLUDE_DIRS", "")
    
    if not exclude_var:
        return set()
    
    # Split by comma, strip whitespace, and normalize paths
    # We use os.path.abspath to ensure absolute comparison later
    exclude_paths = {
        os.path.abspath(p.strip()) 
        for p in exclude_var.split(',') 
        if p.strip()
    }
    
    print(f"Configuration: Excluding directories: {exclude_paths}")
    return exclude_paths

# --- Recursive Scanning and Exclusion Logic ---

def scan_directory_recursively(root_path: str, exclude_list: Set[str]) -> Iterator[str]:
    """
    Traverses a directory tree, yielding file paths, skipping excluded directories.
    """
    root_abs = os.path.abspath(root_path)
    
    if not os.path.isdir(root_path):
        print(f"Error: Root path {root_path} is not a valid directory.", file=sys.stderr)
        return

    for root, dirs, files in os.walk(root_path):
        current_abs_root = os.path.abspath(root)
        
        # 1. Exclusion Logic: Modify the 'dirs' list in place to skip subtrees
        # os.walk processes the directories listed in 'dirs' next.
        # Removing items from 'dirs' prevents os.walk from descending into them.
        
        dirs_to_remove = []
        for d in dirs:
            dir_path = os.path.join(current_abs_root, d)
            
            # Check if the directory itself or its normalized path is in the exclusion list
            if dir_path in exclude_list or os.path.abspath(dir_path) in exclude_list:
                print(f"[EXCLUDE] Skipping entire directory tree: {dir_path}")
                dirs_to_remove.append(d)
        
        # Remove excluded directories from the list 'dirs'
        for d_remove in dirs_to_remove:
            dirs.remove(d_remove)
            
        # 2. Yield files in the current (non-excluded) directory
        for filename in files:
            yield os.path.join(root, filename)

# --- Testing Scenario Setup ---

def setup_recursive_test_structure(root: str):
    """Creates a dummy directory structure for testing os.walk and exclusions."""
    
    # Cleanup previous structure
    import shutil
    if os.path.exists(root):
        shutil.rmtree(root)
    
    os.makedirs(root)
    
    # Structure:
    # /test_root/file_a.txt (Monitored)
    # /test_root/logs/log1.txt (Excluded)
    # /test_root/data/file_b.dat (Monitored)
    # /test_root/data/.git/config (Excluded via parent exclusion)
    
    os.makedirs(os.path.join(root, "logs"))
    os.makedirs(os.path.join(root, "data", ".git"))

    with open(os.path.join(root, "file_a.txt"), "w") as f: f.write("A")
    with open(os.path.join(root, "logs", "log1.txt"), "w") as f: f.write("L")
    with open(os.path.join(root, "data", "file_b.dat"), "w") as f: f.write("B")
    with open(os.path.join(root, "data", ".git", "config"), "w") as f: f.write("G")
    
    print(f"\n[SETUP] Created test structure in {root}")

# --- Main Execution ---
if __name__ == "__main__":
    
    TEST_ROOT = "/tmp/fim_test_root"
    setup_recursive_test_structure(TEST_ROOT)

    # 1. Get exclusion list from environment
    exclude_list = get_exclusion_list()
    
    print("\n--- Starting Recursive Scan ---")
    
    # 2. Perform scan and hash all files
    scanned_files = {}
    
    for filepath in scan_directory_recursively(TEST_ROOT, exclude_list):
        file_hash = generate_sha256(filepath)
        if file_hash:
            scanned_files[filepath] = file_hash
            print(f"[SCAN] Found and Hashed: {filepath}")
        
    print("\n--- Scan Results Summary ---")
    print(f"Total files scanned and hashed: {len(scanned_files)}")
    
    # --- Testing Scenario Instructions ---
    print("\n--- Testing Instructions (Run this command BEFORE running the script) ---")
    print(f"To test exclusion of 'logs' and '.git' directories, use:")
    print(f"export FIM_EXCLUDE_DIRS=\"{TEST_ROOT}/logs, {TEST_ROOT}/data/.git\"")
    print("\n(Note: If the exclusion variable is set, only file_a.txt and file_b.dat should be reported.)")
    
    # Cleanup
    # import shutil
    # shutil.rmtree(TEST_ROOT)

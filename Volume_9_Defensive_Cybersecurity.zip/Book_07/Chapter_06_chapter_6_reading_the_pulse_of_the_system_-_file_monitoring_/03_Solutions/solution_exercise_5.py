
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import hashlib
import os
import sys
from typing import Optional

# Define the standard block size (64 KB)
BLOCK_SIZE = 65536 
# Define the threshold for switching to chunked reading (10 MB)
SIZE_THRESHOLD_BYTES = 10 * 1024 * 1024 

def hash_large_file(filepath: str, block_size: int = BLOCK_SIZE) -> Optional[str]:
    """
    Calculates the SHA-256 hash of a file using chunked reading.
    This method is memory-efficient for arbitrarily large files.
    """
    try:
        hasher = hashlib.sha256()
        with open(filepath, 'rb') as f:
            while True:
                # Read a chunk of data
                chunk = f.read(block_size)
                if not chunk:
                    # End-of-File reached when read() returns an empty byte string
                    break
                # Update the hash object with the chunk
                hasher.update(chunk)
        
        return hasher.hexdigest()
    
    except FileNotFoundError:
        return None
    except IOError as e:
        print(f"Error reading file {filepath}: {e}", file=sys.stderr)
        return None

def generate_sha256_adaptive(filepath: str) -> Optional[str]:
    """
    Adaptive hashing function: uses simple read for small files, 
    and chunked read for files exceeding the size threshold (10 MB).
    """
    try:
        file_size = os.path.getsize(filepath)
    except FileNotFoundError:
        return None
    except Exception:
        # Handle permission issues or other file system errors
        return None

    if file_size > SIZE_THRESHOLD_BYTES:
        print(f"[ADAPTIVE] File size ({file_size / (1024*1024):.2f} MB) exceeds threshold. Using chunked hashing.")
        return hash_large_file(filepath)
    else:
        print(f"[ADAPTIVE] File size ({file_size / 1024:.2f} KB) is small. Using simple read.")
        # Simple read (as implemented in Exercise 1)
        try:
            hasher = hashlib.sha256()
            with open(filepath, 'rb') as f:
                hasher.update(f.read())
            return hasher.hexdigest()
        except Exception:
            return None

# --- Testing and Documentation ---
if __name__ == "__main__":
    
    TEST_FILE = "/tmp/adaptive_test_file.bin"
    
    # Create a small file (e.g., 1 KB)
    with open(TEST_FILE, "wb") as f:
        f.write(b"Test data" * 100)
    
    print("--- Test 1: Small File (Simple Read) ---")
    small_hash = generate_sha256_adaptive(TEST_FILE)
    print(f"Hash: {small_hash[:16]}...")

    # NOTE: We cannot practically create a 10MB+ file here, so we simulate the call
    
    print("\n--- Test 2: Simulated Large File Call ---")
    # Simulate the scenario where os.path.getsize(LARGE_FILE) > 10MB
    
    # We will manually call the efficient function to demonstrate its logic
    large_file_path = "/usr/bin/python3" # Usually large enough to demonstrate chunking principle
    
    print(f"Simulating chunked hash calculation for {large_file_path}...")
    
    if os.path.exists(large_file_path):
        large_hash = hash_large_file(large_file_path)
        print(f"Chunked Hash Result: {large_hash[:16]}...")
    else:
        print(f"Skipping large file test, {large_file_path} not found.")
    
    os.remove(TEST_FILE)
    
    # --- Documentation for Testing Strategy ---
    print("\n--- Testing Strategy Documentation ---")
    print("The primary test for memory efficiency involves verifying the chunking logic:")
    print("1. The `hash_large_file` function uses `f.read(block_size)` within a `while True` loop.")
    print("2. The loop condition (`if not chunk: break`) correctly ensures that the hashing stops only when EOF is reached (i.e., when `read()` returns an empty byte string `b''`).")
    print("3. The `hasher.update(chunk)` ensures that the hash digest is built incrementally across all chunks, maintaining the integrity of the final calculation.")
    print(f"This chunked approach is necessary because reading a file over {SIZE_THRESHOLD_BYTES / (1024*1024):.0f} MB entirely into memory (`f.read()`) risks exhausting system RAM, especially in environments with many concurrent processes.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import hashlib
import os
from pathlib import Path
from typing import Optional

# --- Configuration ---
TARGET_FILENAME = "system_baseline_config.txt"
# Standard chunk size (64 KB) for reading large files efficiently
CHUNK_SIZE = 65536 

def create_dummy_file(filename: str):
    """Creates a temporary file for hashing demonstration."""
    print(f"[SETUP] Creating dummy file: {filename}")
    try:
        # Using 'w' mode ensures a fresh, consistent file for the baseline
        with open(filename, 'w') as f:
            f.write("System configuration baseline data.\n")
            f.write("Version=1.0.0\n")
            f.write("Access_Level=Admin\n")
            f.write("# This line is critical for system operation integrity.")
    except IOError as e:
        print(f"Error creating file: {e}")
        # Exit if setup fails, as the rest of the script relies on this file
        exit(1)

def calculate_file_sha256(filepath: str) -> Optional[str]:
    """
    Calculates the SHA-256 hash of a file by reading it in fixed-size chunks.
    This method is memory-efficient for very large files.
    """
    
    # Check 1: Ensure the file exists before attempting to open it
    if not Path(filepath).exists():
        print(f"[ERROR] File not found: {filepath}")
        return None

    # Step 1: Initialize the hash object
    sha256_hash = hashlib.sha256()

    # Step 2: Open the file in binary read mode ('rb')
    try:
        with open(filepath, 'rb') as f:
            # Step 3: Loop to read the file in chunks
            while True:
                # Read exactly CHUNK_SIZE bytes
                data = f.read(CHUNK_SIZE)
                
                # Check for End of File (EOF)
                if not data:
                    break
                
                # Step 4: Update the hash object incrementally
                sha256_hash.update(data)
        
        # Step 5: Finalize and return the hexadecimal digest
        return sha256_hash.hexdigest()

    except PermissionError:
        print(f"[CRITICAL] Permission denied accessing {filepath}. Cannot calculate hash.")
        return None
    except IOError as e:
        print(f"[CRITICAL] IO Error reading file: {e}")
        return None

# --- Main Execution Flow ---
if __name__ == "__main__":
    
    # Phase 1: Setup and Baseline Generation
    create_dummy_file(TARGET_FILENAME)

    print("\n[PROCESS] Starting SHA-256 calculation for baseline...")
    
    initial_hash = calculate_file_sha256(TARGET_FILENAME)

    if initial_hash:
        print("=" * 60)
        print(f"Target File: {TARGET_FILENAME}")
        print(f"Calculated SHA-256 Baseline: {initial_hash}")
        print("=" * 60)

        # Phase 2: Demonstration of Integrity Failure
        print("\n[DEMO] Simulating unauthorized modification (appending data)...")
        # Open in append mode ('a') to simulate an addition
        with open(TARGET_FILENAME, 'a') as f:
            f.write("\n# Unauthorized modification detected: Malicious payload added.")
        
        modified_hash = calculate_file_sha256(TARGET_FILENAME)
        
        if modified_hash:
            print(f"New SHA-256 After Modification: {modified_hash}")
            
            # Comparison Logic
            if initial_hash != modified_hash:
                print("\n[ALERT] INTEGRITY CHECK FAILED! Hashes do not match. File has been altered.")
            else:
                # This should theoretically never happen if the file was modified
                print("\n[STATUS] Warning: Integrity check passed despite modification attempt.")

    # Phase 3: Cleanup
    try:
        os.remove(TARGET_FILENAME)
        print(f"\n[CLEANUP] Successfully removed {TARGET_FILENAME}.")
    except OSError as e:
        print(f"[CLEANUP ERROR] Could not remove file: {e}")

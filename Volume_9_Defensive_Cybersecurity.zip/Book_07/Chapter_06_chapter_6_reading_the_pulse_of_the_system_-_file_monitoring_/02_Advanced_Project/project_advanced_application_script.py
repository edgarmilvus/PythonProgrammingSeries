
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import hashlib
import json
import os
import time
from datetime import datetime

# --- Configuration Constants ---
# Define the path where the integrity database (baseline) will be stored.
BASELINE_DB_PATH = "fim_baseline.json"

# Define the list of critical files the FIM system must monitor.
# For demonstration, we use simulated configuration files.
CRITICAL_FILES = [
    "app_config_a.ini",
    "server_settings_b.conf",
    "critical_script_c.py"
]

def initialize_environment():
    """Ensures necessary simulated files exist for the first run."""
    print("[INIT] Ensuring critical files exist for demonstration...")
    for filename in CRITICAL_FILES:
        if not os.path.exists(filename):
            with open(filename, 'w') as f:
                f.write(f"# Initial configuration for {filename} created at {datetime.now()}\n")
            print(f"       -> Created dummy file: {filename}")

def generate_file_hash(filepath: str) -> str | None:
    """
    Calculates the SHA-256 hash of a file chunk by chunk.
    Returns the hex digest string or None if the file does not exist.
    """
    if not os.path.exists(filepath):
        return None
    
    # Use SHA-256 for strong cryptographic integrity checking
    hasher = hashlib.sha256()
    
    # Read in 64k chunks to handle potentially large files efficiently
    try:
        with open(filepath, 'rb') as file:
            while chunk := file.read(65536):
                hasher.update(chunk)
        return hasher.hexdigest()
    except IOError as e:
        print(f"[ERROR] Could not read file {filepath}: {e}")
        return None

def load_baseline(db_path: str) -> dict:
    """Loads the existing integrity baseline from a JSON file."""
    if not os.path.exists(db_path):
        print(f"[INFO] Baseline database not found at {db_path}. Creating new baseline.")
        return {}
    
    try:
        with open(db_path, 'r') as f:
            return json.load(f)
    except json.JSONDecodeError:
        print(f"[WARNING] Baseline file corrupted. Starting with an empty baseline.")
        return {}
    except IOError as e:
        print(f"[ERROR] Failed to load baseline: {e}")
        return {}

def save_baseline(db_path: str, baseline_data: dict):
    """Saves the current integrity data to the JSON baseline file."""
    try:
        with open(db_path, 'w') as f:
            json.dump(baseline_data, f, indent=4)
        print(f"[SUCCESS] Baseline updated and saved to {db_path}.")
    except IOError as e:
        print(f"[ERROR] Failed to save baseline: {e}")

def perform_integrity_check(target_files: list[str], current_baseline: dict) -> tuple[dict, list[str]]:
    """
    Performs the core FIM logic: compares current file state against the baseline.
    Returns the new state dictionary and a list of detected incident reports.
    """
    new_state = {}
    incident_reports = []
    current_timestamp = datetime.now().isoformat()

    # 1. Check for modifications and existence
    for filepath in target_files:
        current_hash = generate_file_hash(filepath)
        
        # Scenario A: File is currently missing (was present in the target list)
        if current_hash is None:
            if filepath in current_baseline:
                report = f"[ALERT: DELETED] File '{filepath}' was deleted since last check (Last known hash: {current_baseline[filepath]['hash'][:10]}...)"
                incident_reports.append(report)
            # If it was never in the baseline, we ignore it (it's just a file that doesn't exist yet)
            continue

        # Scenario B: File exists. Check against baseline.
        new_state[filepath] = {
            'hash': current_hash,
            'timestamp': current_timestamp
        }
        
        if filepath not in current_baseline:
            # Scenario B1: New file detected (if the target list is dynamically generated, this is critical)
            report = f"[ALERT: NEW FILE] File '{filepath}' detected. Establishing baseline."
            incident_reports.append(report)
            
        elif current_hash != current_baseline[filepath]['hash']:
            # Scenario B2: Hash mismatch (Modification detected)
            report = f"[ALERT: MODIFIED] File '{filepath}' hash mismatch! Old: {current_baseline[filepath]['hash'][:10]}... New: {current_hash[:10]}..."
            incident_reports.append(report)
            
        else:
            # Scenario B3: No Change
            print(f"   [OK] {filepath} integrity confirmed.")

    # 2. Check for files deleted from the target list that were in the baseline
    # This specifically catches files that were present in the *previous* run but are now missing
    # (Note: This is partially covered in step 1, but this ensures we don't carry deleted files into the new state unless confirmed)
    for filepath in current_baseline.keys():
        if filepath not in new_state:
            # This covers files that were monitored but are now gone.
            # We must ensure the report was already generated in step 1 if it was in CRITICAL_FILES.
            # If the file was manually removed from CRITICAL_FILES list, we simply drop it from the new state.
            pass # The deletion alert is handled robustly in Scenario A

    return new_state, incident_reports

def main_sentinel_run(update_baseline_on_clean: bool = False):
    """Main execution entry point for the FIM system."""
    
    initialize_environment()
    
    print("\n--- Sentinel FIM System Initializing ---")
    
    # Load the previous known-good state
    baseline = load_baseline(BASELINE_DB_PATH)
    
    # Perform the comparison and get the new state and reports
    new_state_data, reports = perform_integrity_check(CRITICAL_FILES, baseline)
    
    print("\n--- Integrity Check Results ---")
    
    if reports:
        print(f"[CRITICAL] {len(reports)} integrity violation(s) detected!")
        for report in reports:
            print(f"   -> {report}")
            # In a real system, this would trigger email alerts, SIEM logging, or automated remediation.
            
        # Do NOT update the baseline automatically if incidents are found. 
        # Requires manual review and confirmation by a security analyst.
        print("\n[ACTION REQUIRED] Baseline NOT updated due to detected incidents.")
        
    else:
        print("[STATUS] All monitored files passed integrity checks.")
        
        # Only update the baseline if requested and the system is clean.
        if update_baseline_on_clean:
            save_baseline(BASELINE_DB_PATH, new_state_data)
        else:
            print("[INFO] Baseline update skipped (Manual update required).")


if __name__ == "__main__":
    # First Run Simulation: Establish the initial baseline
    print("--- SIMULATION 1: Initial Baseline Establishment ---")
    main_sentinel_run(update_baseline_on_clean=True)
    
    # Wait to simulate time passing
    time.sleep(1) 
    
    # --- Simulate an unauthorized modification ---
    with open("app_config_a.ini", 'a') as f:
        f.write("\nATTACKER_INJECTION=true # Unauthorized modification")
    
    print("\n\n--- SIMULATION 2: Detecting Modification ---")
    main_sentinel_run(update_baseline_on_clean=False) # Should detect the change
    
    # --- Simulate a deletion ---
    if os.path.exists("server_settings_b.conf"):
        os.remove("server_settings_b.conf")
        
    print("\n\n--- SIMULATION 3: Detecting Deletion ---")
    main_sentinel_run(update_baseline_on_clean=False) # Should detect the deletion
    
    # Cleanup (Optional, but good practice)
    print("\n--- Cleanup ---")
    for filename in CRITICAL_FILES:
        if os.path.exists(filename):
            os.remove(filename)
    if os.path.exists(BASELINE_DB_PATH):
        os.remove(BASELINE_DB_PATH)
    print("Cleanup complete.")

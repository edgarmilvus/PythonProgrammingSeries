
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import os
import json
from flask import Flask, jsonify

# --- 1. Configuration Loading (Insecure Defaults) ---

# CRITICAL MISCONFIGURATION: Relying on an insecure default string if the environment 
# variable is not explicitly set. This violates OWASP A05.
# In a real deployment, the environment variable should be mandatory, or the app 
# should fail to start if not provided.
SECRET_KEY = os.environ.get(
    'APP_SECRET_KEY', 
    'default-insecure-key-for-dev-1234567890'
)

# Determines if the application runs in debug mode.
# If FLASK_DEBUG is not set, it defaults to 'True' (insecure default).
DEBUG_MODE = os.environ.get('FLASK_DEBUG', 'True').lower() == 'true'

# --- 2. Application Setup ---
app = Flask(__name__)
app.config['SECRET_KEY'] = SECRET_KEY
app.config['DEBUG'] = DEBUG_MODE
app.config['DATABASE_URL'] = 'sqlite:///dev.db'
app.config['INTERNAL_API_TOKEN'] = 'token_for_internal_service_X' # Example of sensitive config

# --- 3. Vulnerable Endpoint Definition ---

@app.route('/api/status/config')
def show_config_status():
    """
    Endpoint intended for monitoring, but designed with a security flaw.
    If DEBUG is True, it exposes the entire configuration dictionary, 
    including keys and tokens.
    """
    
    # Check if the application is running in debug mode
    if app.config.get('DEBUG'):
        # VULNERABILITY: Exposing configuration details when debug is active
        # This expands the attack surface significantly.
        return jsonify({
            "status": "WARNING: Running in Debug Mode. Configuration Exposed.",
            "secret_key_snippet": app.config['SECRET_KEY'][:15] + '...',
            "all_configs_exposed": dict(app.config) # Massive security flaw
        }), 500 # Use 500 to indicate a server issue/misconfiguration
    else:
        # Secure path: Only returns minimal, non-sensitive status
        return jsonify({
            "status": "Production Mode - Configurations Hidden",
            "server_time": "Time stamp (simulated)"
        }), 200

# --- 4. Standard Endpoint ---

@app.route('/')
def index():
    return "Application running. Access /api/status/config to check deployment status."

# --- 5. Execution and Simulation ---

if __name__ == '__main__':
    # We simulate the application environment and request flow
    print("=====================================================")
    print(f"Initial Configuration Check:")
    print(f"  FLASK_DEBUG (Env): {os.environ.get('FLASK_DEBUG')}")
    print(f"  App DEBUG Mode Active: {app.config['DEBUG']}")
    print(f"  App Secret Key Length: {len(app.config['SECRET_KEY'])}")
    print("=====================================================")
    
    # Simulate a request to the vulnerable endpoint using Flask's test client.
    # This avoids starting a full HTTP server, keeping the script self-contained.
    with app.test_client() as client:
        print("\n--- SIMULATING ATTACKER REQUEST (Insecure Configuration Active) ---")
        response = client.get('/api/status/config')
        
        # Parse the JSON response data
        response_data = json.loads(response.data)
        
        print(f"Response Status Code: {response.status_code}")
        print(f"Response Content (Truncated):")
        
        # Pretty print the exposed data
        print(json.dumps(response_data, indent=4)[:1000] + "\n...") 

    # --- 6. Conceptual Secure Demonstration ---
    
    # To contrast, we conceptually show how setting the environment variable 
    # correctly prevents the leak.
    os.environ['FLASK_DEBUG'] = 'False'
    
    # We must re-initialize the app to pick up the new environment variable
    # For simplicity, we create a new configuration object conceptually.
    DEBUG_MODE_SECURE = os.environ.get('FLASK_DEBUG', 'True').lower() == 'true'
    
    print("\n--- CONCEPTUAL SECURE RUN (If FLASK_DEBUG='False' was set) ---")
    print(f"New DEBUG Mode: {DEBUG_MODE_SECURE}")
    
    # If we re-ran the app initialization and request here, 
    # the output would only show "Production Mode - Configurations Hidden".
    print("The application would now follow the secure path (else block).")

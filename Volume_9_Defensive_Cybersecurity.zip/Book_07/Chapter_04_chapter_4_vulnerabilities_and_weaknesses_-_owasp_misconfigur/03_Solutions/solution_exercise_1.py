
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import datetime
import time
import threading
from queue import Queue, Empty

# 1. Define Custom Exception
class InvalidFormatError(Exception):
    """Raised when the user-provided format string is not approved."""
    pass

class TimeoutError(Exception):
    """Raised when the parsing operation takes too long."""
    pass

# --- 1. Insecure Implementation (The Baseline Vulnerability) ---

def parse_user_timestamp_insecure(timestamp_str, format_str):
    """
    Vulnerable function: Accepts arbitrary format strings directly,
    allowing resource exhaustion attacks.
    """
    try:
        # No validation on format_str
        return datetime.datetime.strptime(timestamp_str, format_str)
    except ValueError as e:
        # Basic error handling, but the damage (CPU usage) is done
        raise ValueError(f"Parsing error: {e}")

# --- 2. Vulnerability Demonstration Commentary ---
# An attacker could exploit the insecure function by submitting a format string
# that forces the parser into extremely complex or recursive state checks.
# Example malicious format_str: '%%f' * 50 + '123'
# The '%f' directive (microsecond) is computationally expensive, especially when
# repeated or combined with complex date components, leading to high CPU usage
# and potential resource exhaustion (CPU-based DoS).

# --- 3. Secure Implementation (Defense in Depth) ---

APPROVED_FORMATS = [
    "%Y-%m-%d",
    "%m/%d/%Y %H:%M:%S",
    "%Y%m%d%H%M%S",
    "%a, %d %b %Y %H:%M:%S %z" # RFC 2822
]

def _parse_worker(timestamp_str, format_str, result_queue):
    """Worker function to execute strptime in a separate thread."""
    try:
        dt = datetime.datetime.strptime(timestamp_str, format_str)
        result_queue.put(dt)
    except Exception as e:
        result_queue.put(e)

def parse_user_timestamp_secure(timestamp_str, format_str, timeout_ms=100):
    """
    Secure function: Validates format string and enforces a strict timeout.
    """
    # Defensive Measure 1: Strict Format Validation
    if format_str not in APPROVED_FORMATS:
        raise InvalidFormatError(f"Format '{format_str}' is not approved.")

    # Defensive Measure 2: Timeout Implementation
    result_queue = Queue()
    
    # Start parsing in a separate thread
    parser_thread = threading.Thread(
        target=_parse_worker, 
        args=(timestamp_str, format_str, result_queue)
    )
    parser_thread.start()
    
    # Wait for the result, converting milliseconds to seconds for timeout
    timeout_sec = timeout_ms / 1000.0
    
    try:
        result = result_queue.get(timeout=timeout_sec)
        
        # Check if the result is an exception raised by the worker
        if isinstance(result, Exception):
            raise result
        
        return result
        
    except Empty:
        # Timeout occurred (Queue.get timed out)
        # Note: We cannot safely terminate the thread, but we can stop waiting
        # and raise an error, effectively mitigating the DoS impact on the main process.
        raise TimeoutError(f"Date parsing exceeded {timeout_ms}ms timeout.")
    finally:
        # Ensure the thread finishes eventually (if it hasn't already)
        parser_thread.join(timeout=0)


# --- 4. Testing and Feedback ---

# a) Successful parsing using an approved format
timestamp_ok = "2023-10-27"
format_ok = "%Y-%m-%d"
print(f"Test A (Success): {parse_user_timestamp_secure(timestamp_ok, format_ok)}")

# b) Failure when using a non-approved format string
try:
    parse_user_timestamp_secure("10/27/23", "%y/%m/%d")
except InvalidFormatError as e:
    print(f"Test B (Failure - Invalid Format): {e}")

# c) Failure when using an approved format string but with malformed data
try:
    parse_user_timestamp_secure("2023-99-99", format_ok)
except ValueError as e:
    print(f"Test C (Failure - Malformed Data): {e}")

# d) (Simulated) Failure due to Timeout
# Note: Creating a reliable 100ms timeout failure requires a known slow parsing
# operation or an extremely low timeout. For demonstration, we rely on the
# thread mechanism to enforce the time limit. If a malicious input were used,
# the TimeoutError would be raised instead of waiting indefinitely.

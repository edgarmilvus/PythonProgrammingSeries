
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from flask import Flask, request, flash, get_flashed_messages, render_template_string

# 1. Vulnerable Flask Application Setup (Conceptual Mockup)
app = Flask(__name__)
app.secret_key = 'super_secret_key_for_session' # Required for flash()

# Mock function for demonstration
def mock_render_template_vulnerable(messages):
    """Simulates a vulnerable Jinja2 template using |safe."""
    # The vulnerability: using |safe or autoescape=False on user-controlled input
    VULNERABLE_TEMPLATE = """
    <html><body>
        {% with messages = messages %}
            {% if messages %}
                <ul class=flashes>
                {% for message in messages %}
                    <li>{{ message | safe }}</li>
                {% endfor %}
                </ul>
            {% endif %}
        {% endwith %}
    </body></html>
    """
    return render_template_string(VULNERABLE_TEMPLATE, messages=messages)

def mock_render_template_secure(messages):
    """Simulates a secure Jinja2 template (default autoescaping)."""
    # The fix: simply remove |safe, relying on default autoescaping.
    SECURE_TEMPLATE = """
    <html><body>
        {% with messages = messages %}
            {% if messages %}
                <ul class=flashes>
                {% for category, message in messages %}
                    <li class="{{ category }}">{{ message }}</li>
                {% endfor %}
                </ul>
            {% endif %}
        {% endwith %}
    </body></html>
    """
    return render_template_string(SECURE_TEMPLATE, messages=messages)

@app.route('/login', methods=['POST'])
def login():
    """Simulates a login failure and flashes the username."""
    username = request.form.get('username', 'Unknown')
    
    # 1. VULNERABLE FLASHING: The user input is included directly in the message
    error_message = f"Login failed for user: {username}"
    flash(error_message, 'error')
    
    # Simulate rendering the vulnerable page after redirect
    flashed_messages = get_flashed_messages()
    return mock_render_template_vulnerable(flashed_messages)

# --- 3. Exploitation Demonstration ---

# Payload an attacker would submit as the 'username' input:
XSS_PAYLOAD = "Attacker<script>alert('XSS Successful!')</script>"

# Simulation of the vulnerable login process:
# (Note: In a real Flask app, this would require running the server and a POST request)
# MOCK EXECUTION:
with app.test_request_context(
    '/login', 
    method='POST', 
    data={'username': XSS_PAYLOAD}
):
    response = login()
    vulnerable_output = response.get_data(as_text=True)

print("--- 3. Vulnerable Output (XSS Triggered) ---")
print(vulnerable_output)

# Explanation:
# The resulting HTML output will contain:
# <li>Login failed for user: Attacker<script>alert('XSS Successful!')</script></li>
# Because the template used `|safe`, the browser renders the `<script>` tag as executable code.

# --- 4. Secure Remediation ---

# Secure login function (using category validation and secure template)
SAFE_CATEGORIES = ['error', 'success', 'warning']

@app.route('/secure_login', methods=['POST'])
def secure_login():
    username = request.form.get('username', 'Unknown')
    category = 'error' # Hardcode or derive securely

    # Bonus: Validate the category string itself (Defense against CSS injection)
    if category not in SAFE_CATEGORIES:
        category = 'error'
        
    error_message = f"Login failed for user: {username}"
    flash(error_message, category)
    
    # Simulate rendering the secure page
    flashed_messages_with_category = get_flashed_messages(with_categories=True)
    return mock_render_template_secure(flashed_messages_with_category)

# Simulation of the secure login process:
with app.test_request_context(
    '/secure_login', 
    method='POST', 
    data={'username': XSS_PAYLOAD}
):
    response_secure = secure_login()
    secure_output = response_secure.get_data(as_text=True)

print("\n--- 4. Secure Output (XSS Prevented) ---")
print(secure_output)

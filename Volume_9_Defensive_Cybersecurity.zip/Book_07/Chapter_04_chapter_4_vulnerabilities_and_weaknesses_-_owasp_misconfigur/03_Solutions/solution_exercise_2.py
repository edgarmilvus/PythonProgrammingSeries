
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# 1. Define Insecure Configuration Structure

SECURE_DEFAULTS = {
    'SECRET_KEY': "secure_default_secret_32_bytes",
    'DEBUG': False,
    'LOG_LEVEL': "INFO",
    'MAX_FILE_SIZE': 1024 * 1024 * 5 # 5MB
}

# Simulate attacker/environment input attempting to overwrite secure settings
RUNTIME_SETTINGS = {
    'DEBUG': True,  # Attacker attempts to enable debug mode
    'LOG_LEVEL': 'DEBUG', # Non-sensitive setting override
    'SECRET_KEY': 'insecure_runtime_key', # Attacker attempts to overwrite secret
    'MAX_FILE_SIZE': 1024 * 1024 * 50 # Increase file size limit
}

# 2. Vulnerable Merge Function

def load_insecure_config(defaults, runtime):
    """
    Vulnerable implementation using dict.update(), allowing runtime to overwrite
    all default secure settings.
    """
    config = defaults.copy()
    print("--- Vulnerable Merge ---")
    print(f"Pre-merge DEBUG: {config['DEBUG']}")
    
    # VULNERABILITY: This overwrites all keys present in runtime
    config.update(runtime)
    
    print(f"Post-merge DEBUG: {config['DEBUG']} (Vulnerable)")
    print(f"Post-merge SECRET_KEY: {config['SECRET_KEY']} (Vulnerable)")
    return config

insecure_config = load_insecure_config(SECURE_DEFAULTS, RUNTIME_SETTINGS)
print(f"Insecure Final Config: {insecure_config}")


# 3. Secure Merge Strategy (Configuration Layering)

SENSITIVE_KEYS = ['SECRET_KEY', 'DEBUG']

def load_secure_config(defaults, runtime):
    """
    Secure implementation that prevents runtime settings from overwriting
    predefined sensitive keys.
    """
    config = defaults.copy()
    
    # Create a filtered runtime dictionary
    filtered_runtime = {}
    for key, value in runtime.items():
        if key not in SENSITIVE_KEYS:
            filtered_runtime[key] = value
        else:
            print(f"[SECURITY WARNING] Attempted runtime override of sensitive key '{key}' blocked.")
            
    # Apply the filtered runtime settings. Only non-sensitive keys are updated.
    config.update(filtered_runtime)
    
    return config

# 4. Testing and Verification

print("\n--- Secure Merge ---")
secure_config = load_secure_config(SECURE_DEFAULTS, RUNTIME_SETTINGS)

# a) Verification: SECRET_KEY remains the secure default
assert secure_config['SECRET_KEY'] == SECURE_DEFAULTS['SECRET_KEY']
print(f"Verification A (SECRET_KEY): Success. Value is: {secure_config['SECRET_KEY']}")

# b) Verification: LOG_LEVEL successfully updates
assert secure_config['LOG_LEVEL'] == RUNTIME_SETTINGS['LOG_LEVEL']
print(f"Verification B (LOG_LEVEL): Success. Value is: {secure_config['LOG_LEVEL']}")

# c) Verification: DEBUG remains False
assert secure_config['DEBUG'] == False
print(f"Verification C (DEBUG): Success. Value is: {secure_config['DEBUG']}")

print(f"Secure Final Config: {secure_config}")

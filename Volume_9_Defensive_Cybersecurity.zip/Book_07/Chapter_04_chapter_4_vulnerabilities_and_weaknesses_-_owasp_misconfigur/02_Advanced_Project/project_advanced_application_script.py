
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import asyncio
import os
from typing import Dict, Any, List, Tuple

# --- 1. Simulated Application Configuration ---
# This dictionary simulates environment variables or a configuration file (e.g., settings.py).
# These settings contain intentional security weaknesses relevant to OWASP A05.
APP_CONFIG: Dict[str, Any] = {
    "DEBUG_MODE": True, # CRITICAL: Exposes stack traces and internal data.
    "SECRET_KEY": "insecure_default_key_12345", # HIGH: Weak, easily guessable secret.
    "DATABASE_URL": "sqlite:///app.db",
    "LOG_LEVEL": "DEBUG", # LOW/MEDIUM: Excessive logging, increasing information leakage.
    "ALLOWED_HOSTS": "*", # HIGH: Wildcard exposes app to Host header attacks (Attack Surface).
    "CORS_ORIGINS": ["http://localhost:3000", "*"], # MEDIUM: Wildcard CORS configuration.
    "SESSION_TIMEOUT_SECONDS": 3600,
    "RATE_LIMIT_ENABLED": False, # MEDIUM: Missing defensive control.
}

# --- 2. Security Rule Definitions ---
# Each rule defines a check function and the corresponding defensive remediation required.
SECURITY_RULES: List[Dict[str, Any]] = [
    {
        "key": "DEBUG_MODE",
        "check": lambda v: v is True,
        "owasp": "A05: Security Misconfiguration",
        "severity": "CRITICAL",
        "remediation": "Disable DEBUG_MODE in production. This exposes internal stack traces, environment variables, and configuration data, drastically increasing the attack surface."
    },
    {
        "key": "SECRET_KEY",
        "check": lambda v: "default" in str(v).lower() or len(str(v)) < 32,
        "owasp": "A05: Security Misconfiguration / A07: Identification Failures",
        "severity": "HIGH",
        "remediation": "Use a strong, randomly generated, 256-bit key stored securely (e.g., via a secret manager). Weak secrets compromise session integrity and signing."
    },
    {
        "key": "ALLOWED_HOSTS",
        "check": lambda v: v == "*",
        "owasp": "A05: Security Misconfiguration",
        "severity": "HIGH",
        "remediation": "The wildcard ('*') broadens the network attack surface and makes the application vulnerable to Host header injection attacks. Specify an explicit list of production domain names."
    },
    {
        "key": "CORS_ORIGINS",
        "check": lambda v: "*" in v,
        "owasp": "A07: Identification and Authentication Failures (Trust Boundary)",
        "severity": "MEDIUM",
        "remediation": "Wildcard CORS (Cross-Origin Resource Sharing) allows any domain to make authenticated requests. Restrict origins to only necessary, authorized frontends."
    },
    {
        "key": "LOG_LEVEL",
        "check": lambda v: v.upper() in ["DEBUG", "TRACE"],
        "owasp": "A01: Broken Access Control (Information Leakage)",
        "severity": "LOW",
        "remediation": "Reduce production log level to INFO or WARNING. Excessive logging can leak sensitive operational details or user data, aiding attacker reconnaissance."
    },
    {
        "key": "RATE_LIMIT_ENABLED",
        "check": lambda v: v is False,
        "owasp": "A04: Insecure Design (Missing Controls)",
        "severity": "MEDIUM",
        "remediation": "Implement robust rate limiting on all public endpoints, especially authentication and resource-intensive routes, to mitigate brute-force and resource exhaustion attacks."
    }
]

# --- 3. Asynchronous Scanner Logic ---

async def check_config_item(config_key: str, config_value: Any, rule: Dict[str, Any]) -> Tuple[bool, str, str, str] | None:
    """
    Asynchronously checks a single configuration item against a defined security rule.
    Returns a structured vulnerability tuple if the check lambda evaluates to True.
    """
    # Simulate minor I/O latency typical in real-world API or database configuration checks
    await asyncio.sleep(0.005) 

    if config_key == rule["key"] and rule["check"](config_value):
        # Misconfiguration detected
        return (
            True,
            rule["severity"],
            rule["owasp"],
            f"Key '{config_key}' is misconfigured: Current value is '{config_value}'. "
            f"Remediation: {rule['remediation']}"
        )
    return None

async def run_security_scan(config: Dict[str, Any], rules: List[Dict[str, Any]]) -> List[Tuple[str, str, str]]:
    """
    Main asynchronous function managing the concurrent execution of all security checks.
    Uses asyncio.TaskGroup for reliable aggregation of results.
    """
    print(f"--- Starting Application Hardening Scan ({len(rules)} rules defined) ---")
    vulnerabilities = []

    try:
        # TaskGroup ensures that exceptions in one task are handled gracefully 
        # and allows efficient concurrent scheduling of checks.
        async with asyncio.TaskGroup() as tg:
            tasks = []
            for rule in rules:
                key = rule["key"]
                if key in config:
                    # Create a task for each rule check that exists in the current configuration
                    task = tg.create_task(check_config_item(key, config[key], rule))
                    tasks.append(task)
        
        # Collect results from all tasks after the TaskGroup context manager exits successfully
        for task in tasks:
            result = task.result()
            if result:
                # result is (True, severity, owasp, message)
                vulnerabilities.append((result[1], result[2], result[3]))

    except Exception as e:
        # Catch exceptions related to the TaskGroup execution or task failures
        print(f"An unexpected error occurred during the scan: {e}")
        
    return vulnerabilities

# --- 4. Reporting and Execution ---

def generate_report(vulnerabilities: List[Tuple[str, str, str]]):
    """
    Generates a structured, prioritized report of findings.
    """
    if not vulnerabilities:
        print("\n[SUCCESS] No critical security misconfigurations found. Application attack surface is minimized.")
        return

    # Define a sorting order to prioritize critical findings first
    severity_order = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}
    sorted_vulnerabilities = sorted(
        vulnerabilities, 
        key=lambda x: severity_order.get(x[0], 0), 
        reverse=True
    )

    print("\n" + "="*80)
    print("           SECURITY MISCONFIGURATION AND ATTACK SURFACE REDUCTION REPORT")
    print("="*80)
    
    for severity, owasp, message in sorted_vulnerabilities:
        print(f"\n[SEVERITY: {severity}]")
        print(f"[OWASP CATEGORY: {owasp}]")
        # Display the vulnerability description (up to the remediation marker)
        print(f"  Vulnerability: {message.split('. Remediation: ')[0]}.")
        # Extract and highlight the specific remediation step for attack surface reduction
        remediation_text = message.split('Remediation: ')[-1]
        print(f"  Action Required (Attack Surface Reduction): {remediation_text}")
    
    print("\n" + "="*80)
    print(f"Total Findings Requiring Action: {len(sorted_vulnerabilities)}")
    print("Scan Complete. Immediate remediation of CRITICAL and HIGH findings is required.")


if __name__ == "__main__":
    # Execute the asynchronous main function
    results = asyncio.run(run_security_scan(APP_CONFIG, SECURITY_RULES))
    generate_report(results)

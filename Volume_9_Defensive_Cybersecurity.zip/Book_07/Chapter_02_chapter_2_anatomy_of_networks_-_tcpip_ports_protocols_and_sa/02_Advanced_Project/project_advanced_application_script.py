
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

from scapy.all import sniff, IP, TCP, UDP, ICMP
import asyncio
import time
from typing import Dict, Any, Optional

# --- Global State and Control Variables ---

# Shared dictionaries to store observation results
PROTOCOL_STATS: Dict[str, int] = {}
PORT_STATS: Dict[int, int] = {}

# Asynchronous Event to signal the sniffer thread to stop gracefully
STOP_EVENT = asyncio.Event()

# --- Core Packet Processing Logic ---

def process_packet(packet: Any):
    """
    Callback function executed for every observed packet.
    Analyzes Layer 3 (IP) and Layer 4 (TCP/UDP) information and updates global stats.
    """
    
    # Check for IP layer existence (Layer 3) using dict.get() for safe access
    # Note: Scapy overloads the dictionary access pattern for layers
    ip_layer: Optional[IP] = packet.get(IP) 
    
    if ip_layer:
        # Default protocol name if L4 is not recognized
        protocol_name = "Other_IP"
        dest_port = None
        
        # Determine Layer 4 protocol and extract port data
        if packet.haslayer(TCP):
            protocol_name = "TCP"
            tcp_layer = packet[TCP]
            # Safely retrieve destination port field value
            dest_port = tcp_layer.getfieldval("dport") 
            
        elif packet.haslayer(UDP):
            protocol_name = "UDP"
            udp_layer = packet[UDP]
            dest_port = udp_layer.getfieldval("dport")
            
        elif packet.haslayer(ICMP):
            protocol_name = "ICMP"
            
        # Update global protocol statistics using dict.get() for safe initialization
        PROTOCOL_STATS[protocol_name] = PROTOCOL_STATS.get(protocol_name, 0) + 1
        
        # If a port was identified, update port statistics
        if dest_port is not None:
            PORT_STATS[dest_port] = PORT_STATS.get(dest_port, 0) + 1


def stop_filter(packet: Any) -> bool:
    """
    Scapy's stop filter function. Returns True if sniffing should stop.
    Checks the global asyncio Event state set by the main loop.
    """
    return STOP_EVENT.is_set()

async def run_sniffer(interface: str, bpf_filter: str):
    """
    Runs the blocking scapy sniff function in a separate thread 
    to prevent blocking the main asyncio event loop (non-blocking I/O principle).
    """
    loop = asyncio.get_running_loop()
    
    print(f"[{time.strftime('%X')}] Sniffing thread initialized. Filter: '{bpf_filter}'")
    
    # Use run_in_executor to safely execute the blocking network operation (sniff)
    await loop.run_in_executor(
        None, # Default executor (ThreadPoolExecutor)
        sniff, 
        # Sniff arguments:
        {
            "iface": interface,
            "prn": process_packet, # The non-blocking callback function
            "filter": bpf_filter,
            "stop_filter": stop_filter, # The async-aware stop condition
            "store": 0 # Crucial for passive observation: do not store packets
        }
    )
    print(f"[{time.strftime('%X')}] Sniffing thread finished execution.")


# --- Asynchronous Context Manager for Resource Management ---

class TrafficMonitor:
    """
    An Asynchronous Context Manager for managing the network sniffing process.
    Ensures resources (the sniffer task/thread) are cleanly started and stopped 
    regardless of success or failure.
    """
    def __init__(self, interface: str, duration: int):
        self.interface = interface
        self.duration = duration
        self.sniffer_task = None
        self.start_time = 0

    async def __aenter__(self):
        """Initializes state, clears the stop event, and starts the timer."""
        print(f"[{time.strftime('%X')}] Starting passive monitor on interface {self.interface}...")
        self.start_time = time.monotonic()
        STOP_EVENT.clear()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Handles graceful cleanup, stopping the sniffer, and generating the final report."""
        
        print(f"\n[{time.strftime('%X')}] Signaling sniffer to stop...")
        # 1. Signal the blocking sniffer thread to exit its loop
        STOP_EVENT.set()
        
        # 2. Wait for the thread/task to complete its shutdown
        if self.sniffer_task:
            await self.sniffer_task
            
        elapsed = time.monotonic() - self.start_time
        print(f"[{time.strftime('%X')}] Monitoring stopped after {elapsed:.2f} seconds.")
        
        # 3. Generate the analysis report
        self.generate_report()
        
        # If an exception occurred, we log it but suppress it if we handled the cleanup
        if exc_type:
            print(f"Monitor terminated due to error: {exc_val}")
        return True 

    def generate_report(self):
        """Prints the analyzed traffic statistics, highlighting protocol distribution."""
        total_packets = sum(PROTOCOL_STATS.values())
        print("\n--- Protocol Analysis Report (Layer 3/4) ---")
        print(f"Total Packets Observed: {total_packets}")
        
        if total_packets == 0:
            print("No traffic observed matching the BPF filter.")
            return

        # Report Protocol Counts
        for proto, count in sorted(PROTOCOL_STATS.items(), key=lambda item: item[1], reverse=True):
            percent = (count / total_packets) * 100
            print(f"  {proto:<10}: {count} packets ({percent:.2f}%)")

        # Report Top Port Usage
        print("\n--- Top 5 Destination Port Usage (Potential Service Targets) ---")
        top_ports = sorted(PORT_STATS.items(), key=lambda item: item[1], reverse=True)[:5]
        for port, count in top_ports:
            # Simple heuristic for common ports
            service = {80: "HTTP", 443: "HTTPS", 22: "SSH", 53: "DNS"}.get(port, "Non-Standard")
            print(f"  Port {port:<5} ({service}): {count} packets")


async def main():
    """
    Main asynchronous execution context that orchestrates the monitoring session.
    """
    
    # Configuration for the defensive monitor
    TARGET_INTERFACE = "eth0" 
    # BPF filter: Focus on common application/control ports for baseline analysis
    BPF_RULE = "ip and (tcp port 80 or tcp port 443 or tcp port 22 or udp port 53)"
    MONITOR_DURATION = 20 # seconds
    
    print(f"Configuration: Interface='{TARGET_INTERFACE}', Filter='{BPF_RULE}'")
    
    try:
        # Use the Asynchronous Context Manager to guarantee setup and teardown
        async with TrafficMonitor(interface=TARGET_INTERFACE, duration=MONITOR_DURATION) as monitor:
            
            # Start the sniffer execution in a separate thread managed by asyncio
            monitor.sniffer_task = asyncio.create_task(run_sniffer(TARGET_INTERFACE, BPF_RULE))
            
            # Wait for the monitoring duration to elapse
            print(f"[{time.strftime('%X')}] Monitoring active. Waiting for {MONITOR_DURATION} seconds...")
            await asyncio.sleep(MONITOR_DURATION)
            
            # Execution now proceeds to monitor.__aexit__ for cleanup
            
    except PermissionError:
        print("\n[CRITICAL ERROR] Raw socket access requires root/administrator privileges (e.g., sudo).")
    except ImportError:
        print("\n[CRITICAL ERROR] Required libraries (scapy) are missing.")
    except Exception as e:
        print(f"\n[UNEXPECTED ERROR] An unhandled error occurred: {type(e).__name__}: {e}")

if __name__ == "__main__":
    asyncio.run(main())

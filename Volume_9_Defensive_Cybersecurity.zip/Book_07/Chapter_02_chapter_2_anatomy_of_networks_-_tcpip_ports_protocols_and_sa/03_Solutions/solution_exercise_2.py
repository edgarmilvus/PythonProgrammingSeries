
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import logging

# Set up basic logging (simulating output to a security log)
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

def analyze_packet_header(packet_data: dict) -> tuple:
    """
    Safely extracts header information and calculates a basic risk score 
    using dict.get() for resilience against malformed packets.
    """
    risk_score = 0
    
    # --- 1. Safe Extraction using dict.get() ---
    # Use safe defaults: '' for strings, None for potential numbers/ports
    source_ip = packet_data.get('source_ip', '')
    dest_port = packet_data.get('dest_port', None)
    protocol_flags = packet_data.get('protocol_flags', '')
    timestamp = packet_data.get('timestamp', None)

    # --- 2. Risk Scoring Logic ---

    # R1: Missing Destination Port (Critical field for routing)
    if dest_port is None:
        risk_score += 5
        logging.warning(f"Packet missing 'dest_port'. +5 points.")

    # R2: Internal Source IP (Low Risk Marker)
    if source_ip.startswith('192.168.'):
        risk_score += 1
        
    # R3: Potential Reconnaissance (SYN without ACK)
    if 'SYN' in protocol_flags and 'ACK' not in protocol_flags:
        risk_score += 10
        logging.info(f"Potential reconnaissance detected (SYN without ACK). +10 points.")
        
    # R4: Missing Timestamp (Impedes forensic analysis)
    if timestamp is None:
        risk_score += 3
        logging.warning(f"Packet missing 'timestamp'. +3 points.")

    # Return the extracted data (using the safe defaults if missing) and the score
    return (source_ip, dest_port, protocol_flags), risk_score

# Example Simulated Packet Data:
# packet_2_malformed = {'source_ip': '203.0.113.10', 'protocol_flags': 'SYN', 'timestamp': 1678880001}
# analyze_packet_header(packet_2_malformed)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

def generate_network_flow_dot(session_list: list) -> str:
    """
    Processes session data and generates Graphviz DOT code for visualization,
    applying defensive styling for unknown protocols.
    """
    
    # Define protocols considered 'standard' for this analysis
    STANDARD_PROTOCOLS = {'DNS', 'HTTP', 'SSH', 'HTTPS', 'FTP', 'SMTP', 'RDP'}
    
    dot_output = "digraph NetworkFlow {\n"
    dot_output += '    rankdir=TB;\n'
    dot_output += '    node [shape=box];\n'

    # Use a set to track unique connections to prevent duplicate DOT definitions
    processed_connections = set()

    for src_ip, dest_ip, protocol, port in session_list:
        protocol_upper = protocol.upper()
        
        # Define a unique key for connection tracking
        connection_key = (src_ip, dest_ip, protocol_upper, port)
        
        if connection_key in processed_connections:
            continue
        
        # Defensive Styling Logic: Flag non-standard traffic
        edge_color = "black"
        if protocol_upper in ('UNKNOWN', 'OTHER') or protocol_upper not in STANDARD_PROTOCOLS:
            edge_color = "red"
        
        # Build the DOT edge definition
        label = f"{protocol}:{port}"
        
        dot_output += (
            f'    "{src_ip}" -> "{dest_ip}" '
            f'[label="{label}", color="{edge_color}"];\n'
        )
        
        processed_connections.add(connection_key)

    dot_output += "}\n"
    return dot_output

# Example Input Data:
# session_data = [
#     ('192.168.1.10', '8.8.8.8', 'DNS', 53),
#     ('10.0.0.5', '172.16.0.1', 'HTTP', 80),
#     ('192.168.1.10', '192.168.1.20', 'UNKNOWN', 60000) 
# ]
# print(generate_network_flow_dot(session_data))

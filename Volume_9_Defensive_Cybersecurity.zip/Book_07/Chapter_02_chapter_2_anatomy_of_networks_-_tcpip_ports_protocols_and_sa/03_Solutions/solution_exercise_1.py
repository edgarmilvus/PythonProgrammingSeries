
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

STANDARD_PORTS = {
    # Key: Port Number (int)
    # Value: {'protocol': str, 'service': str, 'layer': str}
    20: {'protocol': 'TCP', 'service': 'FTP Data', 'layer': 'Application'},
    21: {'protocol': 'TCP', 'service': 'FTP Control', 'layer': 'Application'},
    22: {'protocol': 'TCP', 'service': 'SSH', 'layer': 'Application'},
    23: {'protocol': 'TCP', 'service': 'Telnet', 'layer': 'Application'},
    25: {'protocol': 'TCP', 'service': 'SMTP', 'layer': 'Application'},
    53: {'protocol': 'UDP/TCP', 'service': 'DNS', 'layer': 'Application'},
    80: {'protocol': 'TCP', 'service': 'HTTP', 'layer': 'Application'},
    110: {'protocol': 'TCP', 'service': 'POP3', 'layer': 'Application'},
    443: {'protocol': 'TCP', 'service': 'HTTPS', 'layer': 'Application'},
    3389: {'protocol': 'TCP', 'service': 'RDP', 'layer': 'Application'},
}

def lookup_port_info(port_number: int) -> str:
    """
    Looks up port information safely using dict.get() and returns a formatted string.
    Handles unknown ports using a safe default dictionary.
    """
    # Define the safe default response for unknown ports
    default_response = {
        'protocol': 'N/A',
        'service': 'Unassigned or Non-Standard',
        'layer': 'Requires further investigation'
    }

    # Use dict.get() to retrieve the data structure, falling back to the safe default
    info = STANDARD_PORTS.get(port_number, default_response)
    
    protocol = info['protocol']
    service = info['service']
    layer = info['layer']
    
    # Determine the status based on whether the default response was used
    status = 'Standard' if info is not default_response else 'Uncategorized'

    return (f"Port {port_number} Information:\n"
            f"  Protocol: {protocol}\n"
            f"  Service: {service}\n"
            f"  Layer: {layer}\n"
            f"  Status: {status}")

# Example of expected usage:
# print(lookup_port_info(80))
# print(lookup_port_info(65000))

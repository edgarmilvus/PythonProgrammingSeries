
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import asyncio
from contextvars import ContextVar

# 1. Define the Context Variable
PACKET_COUNT = ContextVar('packet_count', default=0)

# 2. Define the Asynchronous Context Manager
class StreamMonitor:
    """
    Manages the lifecycle of a network stream observation task (async with), 
    isolating the PACKET_COUNT state via contextvars.
    """
    def __init__(self, stream_id):
        self.stream_id = stream_id
        self._token = None 

    async def __aenter__(self):
        print(f"[{self.stream_id}] Resource opened. Initializing isolated state.")
        # Set the PACKET_COUNT to 0 for THIS specific task context and save the token
        self._token = PACKET_COUNT.set(0)
        await asyncio.sleep(0) # Yield control
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        # Retrieve the final count specific to this task before cleanup
        final_count = PACKET_COUNT.get()
        
        # Guaranteed cleanup and logging
        if exc_type:
            print(f"[{self.stream_id}] ERROR: Stream terminated abnormally ({exc_type.__name__}).")
        
        print(f"[{self.stream_id}] Resource closed. Total packets processed: {final_count}")
        
        # Reset the context variable to its previous state using the stored token
        PACKET_COUNT.reset(self._token)

# 3. Define the Worker Function
async def monitor_stream(stream_id):
    """
    Simulates monitoring a stream, updating the isolated packet count.
    """
    print(f"[{stream_id}] Monitoring started.")
    
    # Use the asynchronous context manager for safe resource handling
    async with StreamMonitor(stream_id):
        # Simulate processing 5 packets
        for i in range(1, 6):
            current_count = PACKET_COUNT.get()
            new_count = current_count + 1
            
            # Update the count, visible only within this task's context
            PACKET_COUNT.set(new_count)
            
            # Simulate work delay and context switch
            await asyncio.sleep(0.001) 
            
    print(f"[{stream_id}] Monitoring finished.")

# 4. Define the Main Execution Block
async def main():
    print("--- Starting Concurrent Stream Monitoring ---")
    
    # Run two tasks concurrently
    await asyncio.gather(
        monitor_stream("Task A (Stream 1)"),
        monitor_stream("Task B (Stream 2)")
    )
    
    # Check the global context after tasks complete
    global_count = PACKET_COUNT.get()
    print(f"\n[MAIN] Global PACKET_COUNT after tasks complete: {global_count}")

# if __name__ == "__main__":
#     asyncio.run(main())

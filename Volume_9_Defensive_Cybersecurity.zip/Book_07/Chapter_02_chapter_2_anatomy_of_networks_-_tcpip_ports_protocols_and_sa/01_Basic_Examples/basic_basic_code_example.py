
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import socket
import sys

# --- Configuration ---
# The target domain name to resolve
TARGET_HOST = "www.python.org"
# Common services we want to identify the port for
TARGET_SERVICE_HTTP = "http"
TARGET_SERVICE_SSH = "ssh"
TARGET_SERVICE_FTP = "ftp"

def resolve_hostname_to_ip(hostname):
    """
    Resolves a hostname to its corresponding IPv4 address using DNS lookup.
    This function handles potential errors gracefully.
    """
    print(f"[INFO] Attempting to resolve hostname: {hostname}")
    try:
        # socket.gethostbyname is a simple wrapper for the operating system's
        # underlying DNS resolver (often relying on /etc/resolv.conf settings).
        ip_address = socket.gethostbyname(hostname)
        return ip_address
    except socket.gaierror as e:
        # gaierror (Get Address Info Error) is raised if the name cannot be resolved.
        print(f"[ERROR] Could not resolve hostname '{hostname}'. Check connectivity or DNS settings.")
        print(f"Details: {e}")
        return None

def get_service_port(service_name, protocol='tcp'):
    """
    Retrieves the standard port number for a given service name and protocol.
    This relies on the local OS services database (e.g., /etc/services).
    """
    print(f"[INFO] Looking up standard port for service: {service_name}/{protocol}")
    try:
        # socket.getservbyname maps the textual service name (e.g., 'http')
        # to the corresponding standardized port number (e.g., 80).
        port = socket.getservbyname(service_name, protocol)
        return port
    except OSError as e:
        # OSError is typically raised if the service name is not found
        # in the operating system's configuration files.
        print(f"[ERROR] Service '{service_name}' not found in local services database.")
        print(f"Details: {e}")
        return None

def main():
    """Main execution function to perform lookups."""
    print("--- Network Anatomy Explorer: DNS and Service Lookup Utility ---")

    # 1. Resolve the Hostname
    resolved_ip = resolve_hostname_to_ip(TARGET_HOST)

    if resolved_ip:
        print(f"\n[RESULT] Hostname '{TARGET_HOST}' resolves to IP: {resolved_ip}")
    else:
        # If DNS resolution fails, the rest of the script is irrelevant.
        print("\n[CRITICAL] Host resolution failed. Exiting.")
        sys.exit(1)

    print("\n" + "=" * 50)
    print("Standard Port Lookups (TCP)")
    print("=" * 50)

    # 2. Look up standard ports for common services
    
    # HTTP (Web Traffic)
    http_port = get_service_port(TARGET_SERVICE_HTTP)
    if http_port is not None:
        print(f"[RESULT] {TARGET_SERVICE_HTTP.upper()} port: {http_port}")
    
    # SSH (Secure Remote Access)
    ssh_port = get_service_port(TARGET_SERVICE_SSH)
    if ssh_port is not None:
        print(f"[RESULT] {TARGET_SERVICE_SSH.upper()} port: {ssh_port}")

    # FTP (File Transfer Protocol)
    ftp_port = get_service_port(TARGET_SERVICE_FTP)
    if ftp_port is not None:
        print(f"[RESULT] {TARGET_SERVICE_FTP.upper()} port: {ftp_port}")

    # 3. Defensive check: Demonstrating error handling for unknown services
    print("\n" + "-" * 50)
    print("Testing Error Handling")
    non_existent_port = get_service_port("nonexistent_service_xyz")
    if non_existent_port is None:
        print("[SUCCESS] Handled unknown service lookup gracefully, returning None.")


if __name__ == "__main__":
    main()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example_part7.py
# Description: Basic Code Example
# ==========================================

def robust_resolve(hostname, port=80):
    """Uses getaddrinfo for robust, protocol-independent resolution."""
    try:
        # The third argument (0) means we accept any protocol (TCP or UDP)
        # The fourth argument (socket.SOCK_STREAM) means we look for TCP streams
        results = socket.getaddrinfo(hostname, port, 0, socket.SOCK_STREAM)
        
        # results will contain both IPv4 (AF_INET) and IPv6 (AF_INET6) options
        print(f"Found {len(results)} potential connection addresses.")
        
        # We can extract the first usable IP address and port from the sockaddr tuple
        first_address = results[0][4][0]
        return first_address
        
    except socket.gaierror as e:
        # Still handles resolution errors, but now works for IPv6 targets too.
        print(f"[ERROR] Robust resolution failed: {e}")
        return None


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example_part4.py
# Description: Basic Code Example
# ==========================================

def get_service_port(service_name, protocol='tcp'):
    """
    Retrieves the standard port number for a given service name and protocol.
    This relies on the local OS services database (e.g., /etc/services).
    """
    print(f"[INFO] Looking up standard port for service: {service_name}/{protocol}")
    try:
        # socket.getservbyname maps the textual service name (e.g., 'http')
        # to the corresponding standardized port number (e.g., 80).
        port = socket.getservbyname(service_name, protocol)
        return port
    except OSError as e:
        # OSError is typically raised if the service name is not found
        # in the operating system's configuration files.
        print(f"[ERROR] Service '{service_name}' not found in local services database.")
        print(f"Details: {e}")
        return None

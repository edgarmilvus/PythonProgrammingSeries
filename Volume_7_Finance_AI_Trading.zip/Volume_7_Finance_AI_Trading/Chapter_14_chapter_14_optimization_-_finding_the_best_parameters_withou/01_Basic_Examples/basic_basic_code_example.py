
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np
from scipy.optimize import minimize

# --- 1. Define the Objective Function ---
def objective_function(params: np.ndarray) -> float:
    """
    The function that the optimizer seeks to minimize.
    In finance, this would be the negative Sharpe Ratio or Max Drawdown.
    
    Args:
        params (np.ndarray): A vector of parameters [x1, x2].
        
    Returns:
        float: The scalar value (cost) to be minimized.
    """
    # Unpack the parameters from the input vector
    x1, x2 = params
    
    # Calculate the cost based on the defined parabolic equation
    # The function is structured such that its minimum is at (5.0, 10.0)
    cost = (x1 - 5.0)**2 + (x2 - 10.0)**2 + 10.0
    
    # The optimizer requires a single scalar value to evaluate the current parameter set
    return cost

# --- 2. Setup and Initial Guess ---
# The optimizer needs a starting point (x0) in the parameter space.
# We choose a point far from the known minimum (5, 10) to test the optimizer's search capability.
initial_guess = np.array([1.0, 1.0])

# --- 3. Perform the Gradient-Free Optimization ---
# We use the minimize function from SciPy. 
# Nelder-Mead is selected because it is a robust, derivative-free method.
print("Starting optimization using Nelder-Mead...")
optimization_result = minimize(
    fun=objective_function,     # The function to minimize
    x0=initial_guess,           # The starting point for the search
    method='Nelder-Mead',       # The chosen gradient-free algorithm
    options={'disp': True}      # Display convergence messages
)

# --- 4. Analyze and Output Results ---
print("\n--- Optimization Summary ---")
if optimization_result.success:
    print(f"Optimization Status: SUCCESS (Converged)")
else:
    print(f"Optimization Status: FAILURE ({optimization_result.message})")

print(f"Total Iterations (Function Evaluations): {optimization_result.nit}")
print(f"Final Value of Objective Function (Minimum Cost): {optimization_result.fun:.6f}")
print(f"Optimal Parameters Found (x1, x2): {optimization_result.x}")

# Verification
print(f"Verification: Ideal Minimum Cost is 10.0")
print(f"Verification: Ideal Parameters are [5.0, 10.0]")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
from scipy.optimize import minimize

# --- Mock Backtesting Function ---
def mock_backtest(L, S):
    """Simulates a Sharpe Ratio based on Lookback (L) and Sensitivity (S)."""
    # Define an ideal region around L=100, S=0.5
    
    # Ensure inputs are appropriate types if passed from continuous optimizer
    L = int(L) 
    
    # Simulate a performance surface (quadratic decay from optimum)
    sharpe = 2.0 - 0.0001 * (L - 100)**2 - 5 * (S - 0.5)**2
    
    # Introduce minor noise typical of real backtests
    sharpe += np.random.normal(0, 0.01)
    
    # Simulate a failed backtest if parameters are extreme
    if L < 5 or S < 0.1:
        return -0.5
        
    return sharpe

# --- Objective Function Wrapper with Constraints ---
def objective_sharpe(params):
    L, S = params
    
    PENALTY = 1e10 # Large value to penalize infeasible regions

    # 4. Robustness Check (Parameter Constraints enforced internally)
    # L must be in [10, 200]
    if not (10 <= L <= 200):
        return PENALTY
    
    # S must be in [0.1, 1.5]
    if not (0.1 <= S <= 1.5):
        return PENALTY

    # Call the simulated backtest
    sharpe_ratio = mock_backtest(L, S)
    
    # Handle negative or failed Sharpe Ratios
    if sharpe_ratio <= 0.0:
        return PENALTY
        
    # Return the negative Sharpe Ratio for minimization
    return -sharpe_ratio

# 2. Initial Simplex Setup
x0 = [50.0, 0.8] # Initial guess: L=50, S=0.8

# 3. Execute Nelder-Mead
print(f"Starting optimization with x0: {x0}")

result_nm = minimize(
    objective_sharpe, 
    x0, 
    method='Nelder-Mead', 
    options={
        'maxiter': 500, 
        'maxfev': 1000,
        'disp': True
    }
)

print("\n--- Nelder-Mead Results ---")
print(f"Optimized Parameters (L, S): {result_nm.x}")
print(f"Minimization Value (-Sharpe): {result_nm.fun:.4f}")
print(f"Achieved Sharpe Ratio: {-result_nm.fun:.4f}")
print(f"Function Evaluations: {result_nm.nfev}")

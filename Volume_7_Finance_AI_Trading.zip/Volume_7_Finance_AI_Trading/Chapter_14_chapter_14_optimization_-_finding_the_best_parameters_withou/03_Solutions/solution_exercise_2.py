
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np
from scipy.optimize import minimize

# Reusing objective_sharpe from Exercise 1, but ensuring L is rounded for integer constraint analysis
def objective_sharpe_integer(params):
    L, S = params
    
    # 4. Handling Integer Constraints: Round L before internal use/backtest
    L_int = int(np.round(L))
    
    PENALTY = 1e10 
    
    # Internal constraints check using L_int
    if not (10 <= L_int <= 200) or not (0.1 <= S <= 1.5):
        return PENALTY

    # Call the simulated backtest using the integer L
    sharpe_ratio = mock_backtest(L_int, S)
    
    if sharpe_ratio <= 0.0:
        return PENALTY
        
    return -sharpe_ratio

def mock_backtest(L, S):
    # Same mock function logic as E1, now accepting L as an integer
    sharpe = 2.0 - 0.0001 * (L - 100)**2 - 5 * (S - 0.5)**2
    sharpe += np.random.normal(0, 0.01)
    if L < 5 or S < 0.1: return -0.5
    return sharpe

x0 = [50.0, 0.8] # Initial guess

# 1. Implementation of Powell’s Method
result_powell = minimize(
    objective_sharpe_integer, 
    x0, 
    method='Powell', 
    options={
        'maxiter': 500, 
        'maxfev': 1000,
        'disp': False
    }
)

# Implementation of Nelder-Mead (for comparison)
result_nm = minimize(
    objective_sharpe_integer, 
    x0, 
    method='Nelder-Mead', 
    options={
        'maxiter': 500, 
        'maxfev': 1000,
        'disp': False
    }
)

# 2. Data Collection and Comparison
print("--- Comparative Optimization Results ---")
print("{:<15} {:<10} {:<10} {:<10} {:<10}".format("Method", "Sharpe", "NFEV", "NIT", "L_opt"))
print("-" * 55)

# Nelder-Mead Results
nm_sharpe = -result_nm.fun
nm_nfev = result_nm.nfev
nm_nit = result_nm.nit
nm_L = int(np.round(result_nm.x[0])) # Display rounded L
print("{:<15} {:<10.4f} {:<10} {:<10} {:<10}".format("Nelder-Mead", nm_sharpe, nm_nfev, nm_nit, nm_L))

# Powell Results
powell_sharpe = -result_powell.fun
powell_nfev = result_powell.nfev
powell_nit = result_powell.nit
powell_L = int(np.round(result_powell.x[0])) # Display rounded L
print("{:<15} {:<10.4f} {:<10} {:<10} {:<10}".format("Powell", powell_sharpe, powell_nfev, powell_nit, powell_L))

# 3. Analysis of Efficiency (as comments)
"""
Analysis of Efficiency:
Powell's method typically requires fewer function evaluations (NFEV) than Nelder-Mead 
to converge when the objective function is relatively smooth and close to quadratic 
(as simulated here). Since each function evaluation represents a full backtest, 
which is computationally expensive, the method with the lower NFEV (often Powell) 
is preferred when computational time is the primary constraint, provided it finds 
a comparable optimum.

4. Handling Integer Constraints (The Discrete Parameter Challenge):
The `objective_sharpe_integer` function demonstrates the solution: 
The continuous input parameter L is explicitly rounded (`L_int = int(np.round(L))`) 
before being used in the backtesting simulation. This acknowledges that the optimizer 
is searching a continuous space, but the actual performance metric (Sharpe Ratio) 
only changes in discrete steps corresponding to integer values of L. This introduces 
discontinuities into the optimization landscape, which gradient-free methods like 
Powell and Nelder-Mead handle better than gradient-based methods.
"""


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np
from scipy.optimize import minimize
import time

# Mock DMAC Backtest (L_S < L_L required)
def mock_dmac_backtest(LS, LL, LF):
    """Simulates Sharpe Ratio for Dual Moving Average Crossover (3 parameters)."""
    # Convert to integers for realism
    LS, LL, LF = int(LS), int(LL), int(LF)
    
    # Check dependency constraint (handled externally in the wrapper, but included here for completeness)
    if LS >= LL:
        return -1.0 
    
    # Optimal region around LS=20, LL=150, LF=10
    sharpe = 2.5 
    sharpe -= 0.005 * (LS - 20)**2
    sharpe -= 0.00005 * (LL - 150)**2
    sharpe -= 0.05 * (LF - 10)**2
    
    return sharpe + np.random.normal(0, 0.005)

# 1. Refactoring the Objective Function
def dmac_optimization_target(x):
    LS, LL, LF = x
    
    PENALTY = 1e12 # Severe penalty for dependency violation
    
    # Ensure parameters are within reasonable bounds before checking dependency
    if not (10 <= LS <= 100 and 101 <= LL <= 250 and 5 <= LF <= 50):
        return PENALTY / 10 # Slightly smaller penalty for soft bounds

    # 2. Enforcing the Dependency Constraint (LS < LL)
    if LS >= LL:
        # Heavily penalize the optimizer for violating the short/long lookback relationship
        return PENALTY

    sharpe_ratio = mock_dmac_backtest(LS, LL, LF)
    
    if sharpe_ratio <= 0.0:
        return PENALTY
        
    return -sharpe_ratio

# 3. Handling Boundary Conditions and Initialization
x0 = [25.0, 120.0, 15.0] # Valid initial guess: LS < LL (25 < 120)

# Define bounds (optional for Powell, but good practice for search space definition)
# Note: Powell does not strictly enforce bounds, but they constrain the search space
bounds = [(10, 100), (101, 250), (5, 50)] 

# 4. Optimization Execution
start_time = time.time()
result_powell_dmac = minimize(
    dmac_optimization_target, 
    x0, 
    method='Powell', 
    options={'maxiter': 500, 'disp': True}
)
end_time = time.time()

LS_opt, LL_opt, LF_opt = result_powell_dmac.x

print("\n--- DMAC Optimization Results (Powell) ---")
print(f"Optimized Parameters (LS, LL, LF): {int(np.round(LS_opt))}, {int(np.round(LL_opt))}, {int(np.round(LF_opt))}")
print(f"Maximized Sharpe Ratio: {-result_powell_dmac.fun:.4f}")
print(f"Function Evaluations (NFEV): {result_powell_dmac.nfev}")
print(f"Optimization Time: {end_time - start_time:.2f} seconds")

# Efficiency Comparison Analysis
grid_search_size = (100 - 10) * (250 - 101) * (50 - 5)
print(f"\n--- Efficiency Analysis ---")
print(f"Theoretical Grid Search Size (1-unit steps): {grid_search_size} backtests")
print(f"Actual Powell NFEV: {result_powell_dmac.nfev}")
print(f"Efficiency Gain Factor: {grid_search_size / result_powell_dmac.nfev:.1f}x")

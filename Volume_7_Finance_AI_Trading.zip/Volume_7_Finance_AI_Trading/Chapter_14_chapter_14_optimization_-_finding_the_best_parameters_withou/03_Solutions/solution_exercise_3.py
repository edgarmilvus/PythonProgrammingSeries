
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np
from scipy.optimize import minimize

def mock_mean_reversion_sharpe(L, T):
    """Mock objective function for Mean-Reversion strategy (L=Lookback, T=Threshold)"""
    # Optimal Sharpe is around L=150, T=0.5
    sharpe = 1.8 - 0.00005 * (L - 150)**2 - 4 * (T - 0.5)**2
    return -sharpe # Return negative Sharpe for minimization

# Initial guess (L=40, T=0.2) - starts in a feasible region but far from optimum
x0 = [40.0, 0.2] 

# 1. Define Parameter Bounds
# L in [20, 250], T in [0.01, 1.0]
bounds = [(20, 250), (0.01, 1.0)]

# 2. Define Linear Constraints

# Constraint 1: Minimum Lookback Window (L >= 20)
# Standard format requires: fun(x) >= 0.
# L - 20 >= 0
def constraint1(x):
    L, T = x
    return L - 20 

# Constraint 2: Maximum Volatility Exposure (0.1*L + 5*T <= 150)
# Standard format requires: fun(x) >= 0.
# 150 - (0.1*L + 5*T) >= 0
def constraint2(x):
    L, T = x
    return 150 - (0.1 * L + 5 * T)

constraints = [
    {'type': 'ineq', 'fun': constraint1},
    {'type': 'ineq', 'fun': constraint2}
]

# 3. Execute Constrained Optimization (SLSQP)
result_slsqp = minimize(
    mock_mean_reversion_sharpe, 
    x0, 
    method='SLSQP', 
    bounds=bounds, 
    constraints=constraints,
    options={'disp': True}
)

L_opt, T_opt = result_slsqp.x
Sharpe_opt = -result_slsqp.fun

print("\n--- SLSQP Constrained Optimization Results ---")
print(f"Optimized Parameters: L={L_opt:.2f}, T={T_opt:.4f}")
print(f"Maximized Sharpe Ratio: {Sharpe_opt:.4f}")

# 4. Constraint Violation Testing
print("\n--- Constraint Verification ---")
# Test C1: L >= 20
c1_value = L_opt - 20
print(f"Constraint 1 (L - 20 >= 0): Result = {c1_value:.2f} (Feasible: {c1_value >= 0})")

# Test C2: 0.1*L + 5*T <= 150 (i.e., 150 - (0.1*L + 5*T) >= 0)
c2_value = 150 - (0.1 * L_opt + 5 * T_opt)
exposure = 0.1 * L_opt + 5 * T_opt
print(f"Constraint 2 (Exposure <= 150): Exposure = {exposure:.2f} (Feasible: {c2_value >= 0})")

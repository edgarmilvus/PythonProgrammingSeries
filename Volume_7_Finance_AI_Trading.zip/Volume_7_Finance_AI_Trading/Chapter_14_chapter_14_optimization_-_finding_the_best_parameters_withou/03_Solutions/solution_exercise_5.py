
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np
from scipy.optimize import minimize
import math

# Global list to store the path taken by the optimizer
optimization_path = []

# 1. Define a Noisy 2D Objective Function (Modified Rosenbrock surface with noise and shift)
def noisy_surface(x):
    x1, x2 = x
    
    # Global minimum is ideally at (1, 1), but shifted for complexity
    # Add a local minimum around (-1, 0)
    
    # Standard Rosenbrock component (parabolic valley)
    f1 = 100 * (x2 - x1**2)**2 + (x1 - 1)**2 
    
    # Component for a local minimum (e.g., a Gaussian peak/trough)
    f2 = 50 * math.exp(-((x1 + 1)**2 + x2**2) / 0.5)
    
    # Total objective value (we want to minimize this)
    value = f1 + f2 
    
    # Add small random noise
    value += np.random.normal(0, 0.1)
    
    return value

# 2. Implement Iteration Logging via Callback
def log_iteration_callback(xk):
    """Callback function executed at the end of each iteration."""
    # xk is the current best point found by the algorithm
    optimization_path.append(xk.copy())
    # print(f"Iteration {len(optimization_path)}: xk = {xk}") # Uncomment to see live logging

# Define initial guess (closer to the global minimum (1, 1))
x0_global = [2.0, 2.0]

# Execute Nelder-Mead
result_visual = minimize(
    noisy_surface, 
    x0_global, 
    method='Nelder-Mead', 
    callback=log_iteration_callback,
    options={'maxiter': 100, 'disp': False}
)

print("--- Optimization Path Logging ---")
print(f"Total iterations logged: {len(optimization_path)}")
print(f"Initial point: {optimization_path[0]}")
print(f"Final optimal point: {result_visual.x}")

# 3. Conceptual Visualization (Graphviz DOT Language)
# NOTE: This is the DOT code that generates the conceptual flow diagram provided in the prompt.
dot_code = """
digraph NelderMeadFlow {
    rankdir=LR;
    node [shape=box];
    
    Start [label="Start Iteration\n(N+1 Vertices, $x_h$ is worst)"];
    
    Reflect [label="1. Reflect\n($x_r$)"];
    CheckReflect [label="Is $f(x_r) < f(x_l)$?", shape=diamond];
    
    Expand [label="2. Expand\n($x_e$)"];
    CheckExpand [label="Is $f(x_e) < f(x_r)$?", shape=diamond];
    
    ContractOuter [label="3a. Contract Outside\n($x_{oc}$)"];
    CheckContractOuter [label="Is $f(x_{oc}) < f(x_r)$?", shape=diamond];
    
    ContractInner [label="3b. Contract Inside\n($x_{ic}$)"];
    CheckContractInner [label="Is $f(x_{ic}) < f(x_h)$?", shape=diamond];
    
    Shrink [label="4. Shrink (All points move toward $x_l$)"];
    
    Update [label="Update Simplex\n(Replace $x_h$ with new point)"];
    End [label="End Iteration / Check Convergence"];
    
    Start -> Reflect;
    
    Reflect -> CheckReflect;
    
    # Path 1: Reflection is best (Expand)
    CheckReflect -> Expand [label="Yes"];
    Expand -> CheckExpand;
    CheckExpand -> Update [label="Yes (Successful Expansion)"];
    CheckExpand -> Update [label="No (Use $x_r$)"];
    
    # Path 2: Reflection is better than worst, but not best (Contract Outer)
    CheckReflect -> ContractOuter [label="No, but $f(x_r) < f(x_h)$"];
    ContractOuter -> CheckContractOuter;
    CheckContractOuter -> Update [label="Yes (Successful Outer Contraction)"];
    CheckContractOuter -> Shrink [label="No"];
    
    # Path 3: Reflection is worse than worst (Contract Inner)
    CheckReflect -> ContractInner [label="No, $f(x_r) > f(x_h)$"];
    ContractInner -> CheckContractInner;
    CheckContractInner -> Update [label="Yes (Successful Inner Contraction)"];
    CheckContractInner -> Shrink [label="No"];
    
    Shrink -> Update;
    Update -> End [label="Next Iteration"];
}
"""
# print("\n--- Graphviz DOT Code for Conceptual Flow ---")
# print(dot_code)

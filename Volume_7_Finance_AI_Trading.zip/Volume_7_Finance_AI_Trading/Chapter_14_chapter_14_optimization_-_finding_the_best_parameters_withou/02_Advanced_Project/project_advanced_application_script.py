
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import variation

# --- 1. Data Generation and Setup ---

def generate_synthetic_data(days=500, initial_price=100):
    """Generates synthetic stock price data with a slight upward drift."""
    np.random.seed(42)  # For reproducibility
    returns = np.random.normal(0.0005, 0.01, days)
    prices = initial_price * np.exp(np.cumsum(returns))
    data = pd.DataFrame({'Price': prices})
    data['Returns'] = data['Price'].pct_change().fillna(0)
    return data

# --- 2. Strategy Implementation ---

def calculate_strategy_returns(data, fast_period, slow_period):
    """
    Calculates the returns of a Dual Moving Average Crossover strategy.
    
    Args:
        data (pd.DataFrame): DataFrame containing 'Price' and 'Returns'.
        fast_period (int): Lookback period for the fast MA.
        slow_period (int): Lookback period for the slow MA.
    
    Returns:
        pd.Series: Daily returns of the strategy.
    """
    # Ensure periods are valid integers
    pf = int(fast_period)
    ps = int(slow_period)
    
    # Critical constraint check: Ensure fast period is shorter than slow period
    if pf >= ps or pf < 2 or ps < 2:
        return None # Signal failure to the objective function

    # Calculate Moving Averages
    data['MA_Fast'] = data['Price'].rolling(window=pf, min_periods=1).mean()
    data['MA_Slow'] = data['Price'].rolling(window=ps, min_periods=1).mean()

    # Generate trading signals: 1 for long, -1 for short (if implemented), 0 for flat
    # We implement a simple long-only strategy for simplicity:
    # Signal is 1 when fast MA crosses above slow MA (buy/hold), 0 otherwise.
    data['Signal'] = 0
    data.loc[data['MA_Fast'] > data['MA_Slow'], 'Signal'] = 1
    
    # Calculate daily strategy returns (shifted to account for execution delay)
    strategy_returns = data['Returns'].shift(-1) * data['Signal']
    
    return strategy_returns.fillna(0)

# --- 3. Objective Function (Optimization Target) ---

def neg_sharpe_ratio(params, data):
    """
    The objective function for minimization. Returns the negative Sharpe Ratio.
    
    Args:
        params (list/tuple): [fast_period, slow_period]
        data (pd.DataFrame): Historical data.
        
    Returns:
        float: Negative Sharpe Ratio (or penalty if constraints fail).
    """
    fast_period, slow_period = params
    
    # 3a. Handle Parameter Constraints (must be integers, fast < slow)
    if int(fast_period) >= int(slow_period) or int(fast_period) < 2:
        # Return a massive penalty if constraints are violated
        return 1e10 
    
    # Calculate strategy returns based on current parameters
    strategy_returns = calculate_strategy_returns(data, fast_period, slow_period)
    
    # 3b. Sharpe Ratio Calculation
    # Assume risk-free rate is zero for simplicity in backtesting context
    
    # Daily mean return
    mean_return = strategy_returns.mean()
    # Daily standard deviation (risk)
    std_dev = strategy_returns.std()
    
    if std_dev == 0 or mean_return <= 0:
        return 1e9 # Penalty for zero volatility or negative returns
    
    # Annualization factor (252 trading days)
    annualization_factor = np.sqrt(252)
    
    sharpe = (mean_return / std_dev) * annualization_factor
    
    # Optimization minimizes, so we return the negative of the Sharpe Ratio
    return -sharpe

# --- 4. Optimization Execution ---

if __name__ == '__main__':
    
    # 4a. Load Data
    historical_data = generate_synthetic_data(days=1000)
    print("--- Starting Parameter Optimization (Nelder-Mead) ---")
    
    # 4b. Define Initial Guess and Bounds
    # Initial guess for [Fast MA, Slow MA]
    initial_guess = [20, 50] 
    
    # Bounds are advisory for Nelder-Mead but help define the search space
    # (MA periods must be between 5 and 200 days)
    parameter_bounds = [(5, 200), (5, 200)] 

    # 4c. Run the Optimization
    # We use Nelder-Mead as it is gradient-free and robust for non-smooth financial surfaces.
    optimization_result = minimize(
        fun=neg_sharpe_ratio,             # The function to minimize
        x0=initial_guess,                 # Initial parameter vector
        args=(historical_data,),          # Extra arguments passed to the function
        method='Nelder-Mead',             # Gradient-free method
        options={'disp': True, 'maxiter': 500} # Display iteration info
    )

    # --- 5. Results Reporting ---
    
    if optimization_result.success:
        optimal_fast = int(optimization_result.x[0])
        optimal_slow = int(optimization_result.x[1])
        optimal_neg_sharpe = optimization_result.fun
        
        print("\n--- Optimization Complete ---")
        print(f"Algorithm Success: {optimization_result.success}")
        print(f"Iterations: {optimization_result.nit}")
        print(f"Optimal Fast MA Period: {optimal_fast} days")
        print(f"Optimal Slow MA Period: {optimal_slow} days")
        print(f"Maximized Sharpe Ratio: {-optimal_neg_sharpe:.4f}")
        
        # Verify the final result using the optimal parameters
        final_returns = calculate_strategy_returns(historical_data, optimal_fast, optimal_slow)
        
        # Calculate max drawdown (a crucial secondary metric)
        cumulative_returns = (1 + final_returns).cumprod()
        peak = cumulative_returns.expanding(min_periods=1).max()
        drawdown = (cumulative_returns / peak) - 1
        max_drawdown = drawdown.min()
        
        print(f"Max Drawdown (Optimal Strategy): {max_drawdown:.2%}")
    else:
        print("Optimization failed to converge.")


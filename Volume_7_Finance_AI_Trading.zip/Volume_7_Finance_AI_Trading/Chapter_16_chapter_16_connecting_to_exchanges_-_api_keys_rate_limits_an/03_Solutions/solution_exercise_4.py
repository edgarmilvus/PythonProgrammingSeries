
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import time
import random
from typing import Callable, Any

class TransientAPIError(Exception):
    """Simulates a temporary API failure (e.g., 503 Service Unavailable)."""
    pass

class MaxRetriesExceededError(Exception):
    """Raised when the maximum number of retry attempts is reached."""
    pass

def unreliable_api_call(attempt: int) -> str:
    """
    Simulates an API call that fails randomly, but gets more reliable over time.
    """
    # High chance of failure on early attempts (70% fail rate for attempts 1 and 2)
    if attempt < 3 and random.random() < 0.7: 
        raise TransientAPIError(f"Attempt {attempt} failed due to server overload.")
    
    return f"Success on attempt {attempt}!"

def retry_with_backoff(func: Callable, max_attempts: int = 5, base_wait: float = 1.0) -> Any:
    """
    Wraps a function and retries it upon TransientAPIError using exponential backoff with jitter.
    """
    attempt = 0
    while attempt < max_attempts:
        attempt += 1
        try:
            # Execute the function, passing the current attempt number
            return func(attempt)
        
        except TransientAPIError as e:
            if attempt == max_attempts:
                # Handle final failure after the last attempt
                raise MaxRetriesExceededError(f"API call failed after {max_attempts} attempts.") from e
            
            # 1. Calculate exponential backoff: BaseWait * 2^(N-1)
            exponential_wait = base_wait * (2 ** (attempt - 1))
            
            # 2. Implement Full Jitter: Random wait time between 0 and the exponential wait
            jitter_wait = random.uniform(0, exponential_wait)
            
            print(f"Failure: {e}. Calculated Max Backoff: {exponential_wait:.2f}s. Sleeping with Jitter: {jitter_wait:.2f}s...")
            time.sleep(jitter_wait)
            
    # Defensive programming: Should not be reached if max_attempts logic is correct
    raise MaxRetriesExceededError("Unexpected exit from retry loop.")

# Example usage test scaffold
print("--- Testing Exponential Backoff and Jitter ---")
try:
    result = retry_with_backoff(unreliable_api_call)
    print(f"\nFINAL RESULT: {result}")
except MaxRetriesExceededError as e:
    print(f"\nFATAL ERROR: {e}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import time
from collections import deque
from functools import wraps
from typing import Callable, Any

def rate_limit_parametrized(max_calls: int, window_seconds: float) -> Callable:
    """
    A decorator factory that creates a rate limiter with configurable limits.
    """
    # Layer 1: The factory accepting parameters

    def actual_decorator(func: Callable) -> Callable:
        # Layer 2: The actual decorator accepting the function
        
        # Persistent state defined here, ensuring independence for each decorated function
        call_history = deque()
        
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Layer 3: The wrapper executing the logic
            current_time = time.time()
            
            # 1. Clean up old timestamps using the dynamic window_seconds
            limit_boundary = current_time - window_seconds
            while call_history and call_history[0] <= limit_boundary:
                call_history.popleft()
            
            # 2. Check if the limit is reached using the dynamic max_calls
            if len(call_history) >= max_calls:
                # Calculate required sleep time
                time_to_wait = (call_history[0] + window_seconds) - current_time
                
                if time_to_wait > 0:
                    print(f"[{func.__name__}] LIMIT HIT ({max_calls}/{window_seconds}s): Sleeping for {time_to_wait:.2f}s...")
                    time.sleep(time_to_wait)
                    
                    # After sleeping, pop the expired call
                    call_history.popleft()

            # 3. Record the new call timestamp and execute
            new_call_time = time.time()
            call_history.append(new_call_time)
            
            print(f"[{func.__name__} @ {new_call_time:.2f}] Call successful.")
            
            return func(*args, **kwargs)
        return wrapper
    return actual_decorator

# Example usage test scaffold
@rate_limit_parametrized(max_calls=1, window_seconds=2.0)
def place_order(side, amount):
    return True

@rate_limit_parametrized(max_calls=5, window_seconds=1.0)
def fetch_ohlc_data(symbol):
    return True

print("--- Testing Parameterized Rate Limiter ---")
start_time = time.time()

# Test 1: Order placement (1 call per 2 seconds)
place_order("BUY", 10)
place_order("SELL", 5) # Should wait ~2 seconds

# Test 2: High-frequency data fetch (5 calls per 1 second)
for i in range(6):
    fetch_ohlc_data(f"BTC/USD_{i}")
    time.sleep(0.1) # Should hit the limit quickly and then wait 1 second

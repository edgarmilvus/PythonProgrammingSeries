
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
from typing import Optional, Dict

# Sample configuration dictionary for testing the fallback mechanism
SAMPLE_CONFIG: Dict[str, Dict[str, str]] = {
    "BINANCE": {
        "API_KEY": "file_key_123",
        "SECRET": "file_secret_abc"
    },
    "COINBASE": {
        "API_KEY": "cb_key_456"
        # Note: COINBASE SECRET is intentionally missing here to test graceful failure
    }
}

def load_credential(exchange: str, key_type: str, config: Dict[str, Dict[str, str]]) -> Optional[str]:
    """
    Loads a credential based on environment variable priority.
    """
    # 1. Standardize and construct the environment variable name (e.g., BINANCE_API_KEY)
    env_var_name = f"{exchange.upper()}_{key_type.upper()}"
    
    # 2. Primary Source: Environment Variables
    credential = os.environ.get(env_var_name)
    
    if credential:
        return credential
    
    # 3. Secondary Source: Configuration Dictionary (Local Fallback)
    
    # Safely retrieve the configuration block for the exchange
    exchange_config = config.get(exchange.upper())
    
    if exchange_config:
        # Use dict.get() to gracefully handle missing key_type within the exchange block
        return exchange_config.get(key_type.upper())
    
    # 4. Final Fallback: Return None
    return None

# --- Testing Scaffold ---
# Set environment variables to test priority
os.environ['BINANCE_SECRET'] = 'env_secret_xyz'
os.environ['BINANCE_API_KEY'] = 'env_key_789'

# Test 1: Environment variable priority (Should return 'env_key_789')
print(f"BINANCE API KEY (Env Priority): {load_credential('BINANCE', 'API_KEY', SAMPLE_CONFIG)}")

# Test 2: Configuration fallback (Remove env variable, should return 'file_key_123')
del os.environ['BINANCE_API_KEY']
print(f"BINANCE API KEY (File Fallback): {load_credential('BINANCE', 'API_KEY', SAMPLE_CONFIG)}")

# Test 3: Graceful failure (COINBASE SECRET is missing in both env and config)
print(f"COINBASE SECRET (Missing): {load_credential('COINBASE', 'SECRET', SAMPLE_CONFIG)}")

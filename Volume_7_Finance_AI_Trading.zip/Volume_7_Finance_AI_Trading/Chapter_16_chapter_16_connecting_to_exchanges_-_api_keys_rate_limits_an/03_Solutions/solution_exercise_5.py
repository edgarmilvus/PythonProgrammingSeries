
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# 1. Permissioning Definition
# Define the dictionary structure for API key permissions.
REQUIRED_PERMISSIONS = {
    "CAN_READ_MARKET_DATA": True,  # Required for price feeds
    "CAN_VIEW_BALANCE": True,      # Required for checking account status
    "CAN_TRADE": True,             # Required for placing and canceling orders
    "CAN_WITHDRAW": False          # CRITICAL: Denied to prevent fund removal
}

# 2. IP Whitelisting Configuration
BOT_SERVER_IP = "203.0.113.42"

# Assume a generic exchange client class structure
class ExchangeClient:
    def __init__(self, api_key: str, secret: str, ip_whitelist: str = None):
        self.api_key = api_key
        self.secret = secret
        self.ip_whitelist = ip_whitelist
        
    def connect(self):
        if self.ip_whitelist:
            print(f"Connecting securely. Requests only accepted from IP: {self.ip_whitelist}")
        else:
            print("Connecting without IP restriction. HIGH RISK.")

# Student instantiation of the client using the whitelisting feature
SECURE_CLIENT = ExchangeClient(
    api_key="DUMMY_KEY_123",
    secret="DUMMY_SECRET_XYZ",
    ip_whitelist=BOT_SERVER_IP
)

SECURE_CLIENT.connect()

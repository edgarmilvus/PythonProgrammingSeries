
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import time
from collections import deque
from functools import wraps

# Define constants for the fixed limit
MAX_CALLS = 5
WINDOW_SECONDS = 10

class RateLimitExceededError(Exception):
    """Raised when the rate limit is hit and the system cannot wait."""
    pass

def rate_limit_fixed(func):
    """
    A decorator that enforces a fixed window rate limit (5 calls per 10 seconds).
    """
    # Storage for timestamps persists across calls for this specific decorated function.
    call_history = deque()

    @wraps(func)
    def wrapper(*args, **kwargs):
        current_time = time.time()
        
        # 1. Clean up old timestamps (maintain the fixed window)
        # Remove timestamps older than the window duration
        while call_history and call_history[0] <= current_time - WINDOW_SECONDS:
            call_history.popleft()
            
        # 2. Check if the limit is reached
        if len(call_history) >= MAX_CALLS:
            # Calculate when the oldest call (call_history[0]) will expire.
            time_to_wait = (call_history[0] + WINDOW_SECONDS) - current_time
            
            if time_to_wait > 0:
                print(f"RATE LIMIT HIT: Sleeping for {time_to_wait:.2f} seconds...")
                time.sleep(time_to_wait)
                
                # After sleeping, the oldest call is guaranteed to be outside the window
                call_history.popleft()

        # 3. Record the new call timestamp and execute
        new_call_time = time.time()
        call_history.append(new_call_time)
        
        print(f"[{new_call_time:.2f}] Call successful. Remaining: {MAX_CALLS - len(call_history)}")
        
        return func(*args, **kwargs)
    return wrapper

# Example usage test scaffold
@rate_limit_fixed
def fetch_market_data(symbol):
    return f"Data for {symbol}"

print("--- Testing Fixed Rate Limiter (5 calls/10s) ---")
start_time = time.time()
for i in range(7):
    fetch_market_data(f"SYM{i}")
    if i < 4:
        # Simulate quick calls
        time.sleep(0.5) 
print(f"Total time elapsed: {time.time() - start_time:.2f}s")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import os
import sys
from typing import Tuple, Optional

# --- Configuration ---
# Define the expected environment variable names for our fictional exchange
API_KEY_ENV_VAR = "DATA_EXCHANGE_API_KEY"
SECRET_ENV_VAR = "DATA_EXCHANGE_SECRET"

def load_credentials() -> Tuple[str, str]:
    """
    Loads API key and secret from environment variables.
    Raises SystemExit if credentials are not found, ensuring the application
    does not proceed with invalid or missing access tokens.
    
    This function adheres to the LBYL (Look Before You Leap) principle 
    for security checks, ensuring we validate existence before attempting usage.
    """
    
    # 1. Retrieve the API Key safely using os.getenv()
    # os.getenv returns None if the variable is not set, preventing a KeyError.
    api_key: Optional[str] = os.getenv(API_KEY_ENV_VAR)
    
    # 2. Retrieve the Secret Key safely
    secret_key: Optional[str] = os.getenv(SECRET_ENV_VAR)

    # 3. Validation: Check if either credential is None or an empty string
    if not api_key or not secret_key:
        print("=" * 70, file=sys.stderr)
        print(f"FATAL ERROR: Credentials missing.", file=sys.stderr)
        print(f"The trading application requires the following environment variables to be set:", file=sys.stderr)
        print(f"  - {API_KEY_ENV_VAR}", file=sys.stderr)
        print(f"  - {SECRET_ENV_VAR}", file=sys.stderr)
        print("Example (Linux/macOS): export DATA_EXCHANGE_API_KEY='your_key_here'", file=sys.stderr)
        print("=" * 70, file=sys.stderr)
        # We use sys.exit(1) to stop execution immediately and cleanly, signaling failure
        sys.exit(1) 

    # 4. If validation passes, return the guaranteed non-None strings
    # We use type casting here to satisfy the Tuple[str, str] return type expectation
    return api_key, secret_key

def main_trading_logic(key: str, secret: str) -> None:
    """
    Simulates the main application logic, which requires authenticated access.
    This function only receives the keys after they have been successfully validated.
    """
    print("\n--- Initialization Success ---")
    print(f"Exchange connection initialized.")
    # Displaying only a truncated version of the key is a good security practice
    print(f"API Key loaded (first 5 chars): {key[:5]}...")
    print(f"Secret Key loaded (first 5 chars): {secret[:5]}...")
    print("Ready to perform authenticated actions (e.g., fetching account balances).")

if __name__ == "__main__":
    # --- Execution Flow Demonstration ---
    
    # NOTE ON DEMONSTRATION: In production, environment variables are set 
    # OUTSIDE the script (e.g., in the shell or deployment system).
    # We set them here only to make this example self-contained and runnable.
    
    # 1. Simulate setting environment variables for a successful run
    print("Attempting successful credential load...")
    os.environ[API_KEY_ENV_VAR] = "A1B2C3D4E5F6G7H8I9J0"
    os.environ[SECRET_ENV_VAR] = "X1Y2Z3W4V5U6T7S8R9Q0"
    
    try:
        # Load the credentials securely
        api_key, secret_key = load_credentials()
        
        # Proceed only if loading was successful
        main_trading_logic(api_key, secret_key)

    except SystemExit as e:
        # Catch the clean exit signal if credentials failed to load
        # This block is primarily for demonstration purposes; in a real script, 
        # the OS handles the exit code.
        print(f"\nApplication terminated due to missing credentials (Exit Code {e.code}).")
        
    finally:
        # 2. Clean up the environment variables set during the demonstration
        # This ensures subsequent runs or other parts of the script are unaffected.
        del os.environ[API_KEY_ENV_VAR]
        del os.environ[SECRET_ENV_VAR]
        print("\nDemonstration environment cleaned up.")

    # 3. Simulate a failure scenario (missing secret key)
    print("\n" + "="*70)
    print("Attempting failed credential load (Missing Secret)...")
    os.environ[API_KEY_ENV_VAR] = "A1B2C3D4E5F6G7H8I9J0" # Key is set
    # os.environ[SECRET_ENV_VAR] is deliberately NOT set
    
    try:
        load_credentials()
        
    except SystemExit as e:
        # The load_credentials function handles the error and exits cleanly.
        print(f"\nSuccessfully caught SystemExit for failure simulation (Exit Code {e.code}).")
        
    finally:
        # Clean up the remaining environment variable
        if API_KEY_ENV_VAR in os.environ:
            del os.environ[API_KEY_ENV_VAR]
        print("Failure simulation environment cleaned up.")

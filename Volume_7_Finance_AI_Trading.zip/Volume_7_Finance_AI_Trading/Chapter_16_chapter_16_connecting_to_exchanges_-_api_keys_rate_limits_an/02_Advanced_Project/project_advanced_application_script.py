
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import time
import random
from typing import Callable, Any, Dict
from pydantic import BaseSettings, Field, ValidationError

# --- 1. Custom Exceptions for EAFP Error Handling ---

class ExchangeError(Exception):
    """Base exception for exchange communication errors."""
    pass

class RateLimitError(ExchangeError):
    """Raised specifically when a 429 Too Many Requests is encountered."""
    pass

class AuthenticationError(ExchangeError):
    """Raised for 403 Forbidden or invalid API key issues."""
    pass

# --- 2. Secure Configuration Loading using Pydantic ---

class ExchangeSettings(BaseSettings):
    """Loads API keys and secrets securely from environment variables."""
    API_KEY: str = Field(..., env='EXCHANGE_API_KEY')
    API_SECRET: str = Field(..., env='EXCHANGE_API_SECRET')
    
    class Config:
        # Allows reading from a .env file if necessary, but prioritizes OS env vars
        env_file = ".env"
        env_file_encoding = 'utf-8'

try:
    # Attempt to load settings (EAFP in action: assume success, catch failure)
    SETTINGS = ExchangeSettings()
except ValidationError as e:
    print("FATAL: Could not load required environment variables (API_KEY/SECRET).")
    print("Please set EXCHANGE_API_KEY and EXCHANGE_API_SECRET.")
    # In a real script, this would raise or sys.exit(1)
    # For demonstration, we use mock keys if real ones aren't set
    SETTINGS = type('MockSettings', (object,), {
        'API_KEY': 'MOCK_KEY_12345',
        'API_SECRET': 'MOCK_SECRET_67890'
    })()

# --- 3. Exponential Backoff Decorator (Recovery Mechanism) ---

def exponential_backoff_retry(max_retries: int = 5, initial_delay: float = 1.0) -> Callable:
    """Decorator to retry a function call upon RateLimitError."""
    def decorator(func: Callable) -> Callable:
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            delay = initial_delay
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except RateLimitError as e:
                    if attempt == max_retries - 1:
                        print(f"[{func.__name__}] Max retries reached. Failing.")
                        raise e
                    
                    # Calculate sleep time: delay * (2^attempt) + random jitter
                    sleep_time = delay * (2 ** attempt) + random.uniform(0, 0.5)
                    print(f"[{func.__name__}] Rate limit hit. Retrying in {sleep_time:.2f}s (Attempt {attempt + 1}/{max_retries}).")
                    time.sleep(sleep_time)
                except AuthenticationError:
                    # Authentication errors are generally fatal and should not be retried
                    print(f"[{func.__name__}] Fatal Authentication Error. Aborting.")
                    raise
            return None # Should be unreachable
        return wrapper
    return decorator

# --- 4. Rate Limiter Class (Prevention Mechanism) ---

class RateLimiter:
    """Enforces a minimum time delay between requests."""
    def __init__(self, requests_per_minute: int):
        self._min_delay_s = 60.0 / requests_per_minute
        self._last_request_time = 0.0

    def wait_for_slot(self):
        """Blocks execution until the required minimum delay has passed."""
        current_time = time.time()
        elapsed = current_time - self._last_request_time
        
        if elapsed < self._min_delay_s:
            wait_time = self._min_delay_s - elapsed
            print(f"[RateLimiter] Waiting {wait_time:.3f}s to respect limit.")
            time.sleep(wait_time)
        
        # Update the last request time *after* the wait (or immediately if no wait)
        self._last_request_time = time.time()

# --- 5. Secure Exchange Connector (Integration) ---

class SecureExchangeConnector:
    """Handles secure, rate-limited, and resilient communication."""
    
    def __init__(self, settings: ExchangeSettings, rpm_limit: int = 30):
        self.api_key = settings.API_KEY
        self.api_secret = settings.API_SECRET
        self.limiter = RateLimiter(rpm_limit)
        self.request_count = 0
        
    def _mock_api_call(self, endpoint: str) -> Dict[str, Any]:
        """Simulates an external API call with security and failure logic."""
        self.request_count += 1
        
        # Security check: Ensure key is included in the 'request'
        if not self.api_key or self.api_key == 'INVALID':
            # This simulates a 403 Forbidden due to missing/invalid credentials
            return {"status_code": 403, "error": "Invalid API Key"}

        # Simulate transient Rate Limit errors randomly (e.g., 1 in 15 calls)
        if self.request_count % 15 == 0:
            print(f"--- MOCK FAILURE: {endpoint} hit simulated 429 ---")
            return {"status_code": 429, "error": "Too Many Requests"}
        
        # Simulate successful data fetch
        return {
            "status_code": 200,
            "data": f"OHLCV data for {endpoint}",
            "timestamp": time.time()
        }

    @exponential_backoff_retry(max_retries=4)
    def fetch_data(self, symbol: str) -> Dict[str, Any]:
        """Fetches data, applying rate limiting and retry logic."""
        
        # Prevention Layer: Wait before making the request
        self.limiter.wait_for_slot()
        
        print(f"\n[Requesting] Attempting fetch for {symbol}...")
        
        # Execution Layer: Mock the secure API call
        response = self._mock_api_call(symbol)
        
        # EAFP Error Handling Layer: Check response status
        status = response.get("status_code", 500)
        
        if status == 200:
            print(f"[SUCCESS] Fetched data for {symbol}.")
            return response['data']
        
        elif status == 429:
            # Raise specific exception to trigger the exponential backoff decorator
            raise RateLimitError(f"429 encountered for {symbol}.")
        
        elif status == 403:
            # Raise fatal authentication error
            raise AuthenticationError(f"403 Forbidden for {symbol}.")
            
        else:
            # Handle other unexpected errors
            raise ExchangeError(f"Unexpected API error {status}: {response.get('error')}")

# --- 6. Execution ---

if __name__ == "__main__":
    
    # 30 RPM limit = 2.0 seconds minimum delay per request
    connector = SecureExchangeConnector(SETTINGS, rpm_limit=30)
    
    symbols_to_fetch = ["BTC/USD", "ETH/USD", "ADA/USD", "SOL/USD", 
                        "XRP/USD", "LTC/USD", "DOT/USD", "AVAX/USD",
                        "LINK/USD", "UNI/USD", "DOGE/USD", "SHIB/USD"]
    
    print(f"Starting data collection with API Key: {SETTINGS.API_KEY[:8]}...")
    
    results = {}
    start_time = time.time()
    
    for symbol in symbols_to_fetch:
        try:
            data = connector.fetch_data(symbol)
            results[symbol] = data
        except ExchangeError as e:
            print(f"Failed to fetch {symbol} due to critical error: {e}")
            # Stop execution if a fatal error (like 403) occurs
            if isinstance(e, AuthenticationError):
                break
            
    end_time = time.time()
    
    print("\n--- Summary ---")
    print(f"Total Symbols Attempted: {len(symbols_to_fetch)}")
    print(f"Total Symbols Successful: {len(results)}")
    print(f"Total Execution Time: {end_time - start_time:.2f} seconds")

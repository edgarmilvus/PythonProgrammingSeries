
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import numpy as np
import yfinance as yf
import sys
import os

# Define the standard number of trading days used for annualization
TRADING_DAYS_PER_YEAR = 252

# --- Data Acquisition Function ---

def fetch_data(ticker, start_date, end_date):
    """
    Downloads adjusted closing prices for the specified ticker and date range 
    using the yfinance library.
    """
    print(f"-> Fetching data for {ticker} from {start_date} to {end_date}...")
    try:
        # yf.download fetches OHLCV data; we only need 'Adj Close'
        data = yf.download(ticker, start=start_date, end=end_date, progress=False)
        
        if data.empty:
            # Raise an error if no data is returned
            raise ValueError(f"No data found for {ticker} in the specified range.")
            
        # Return only the Adjusted Close series, dropping any initial NA values
        return data['Adj Close'].dropna()
        
    except Exception as e:
        # Use sys.exit for critical failure during data fetching
        sys.exit(f"CRITICAL ERROR: Failed to fetch data for {ticker}. Details: {e}")

# --- Core Financial Calculation Function ---

def calculate_financial_metrics(prices, ticker):
    """
    Calculates Simple Returns, Log Returns, Annualized Volatility, and CAGR 
    based on the input price series.
    """
    if len(prices) < 2:
        # Handle cases where the time series is too short for return calculation
        return {"Ticker": ticker, "Error": "Insufficient data points (requires >1 day)."}

    # 1. Calculate Daily Simple Returns
    # Used primarily for calculating the Total Simple Return
    simple_returns = prices.pct_change().dropna()

    # 2. Calculate Daily Log Returns
    # Crucial for statistical analysis (volatility) and additive aggregation
    # Formula: ln(P_t / P_{t-1})
    log_returns = np.log(prices / prices.shift(1)).dropna()

    # Determine the period duration
    total_trading_periods = len(prices) - 1 # Number of returns calculated
    
    # 3. Calculate Annualized Volatility
    # Volatility = Standard Deviation of daily log returns * sqrt(Annualization Factor)
    daily_volatility = log_returns.std()
    annualized_volatility = daily_volatility * np.sqrt(TRADING_DAYS_PER_YEAR)

    # 4. Calculate Compound Annual Growth Rate (CAGR)
    # Total Return: (End Price / Start Price) - 1
    total_return = (prices.iloc[-1] / prices.iloc[0]) - 1
    
    # Calculate the number of years (T) the investment was held
    # We use the total number of periods divided by the assumed periods per year
    num_years = total_trading_periods / TRADING_DAYS_PER_YEAR
    
    # CAGR Formula: ((1 + Total Return)^(1/T)) - 1
    # Handle division by zero or negative years defensively
    if num_years <= 0:
        cagr = np.nan
    else:
        cagr = ((1 + total_return) ** (1 / num_years)) - 1

    # 5. Aggregate Metrics
    # The sum of log returns equals the log of the cumulative return ratio
    total_log_return = log_returns.sum()

    return {
        "Ticker": ticker,
        "Trading Periods": total_trading_periods,
        "Annualized Volatility": annualized_volatility,
        "CAGR": cagr,
        "Total Log Return": total_log_return,
        "Total Simple Return": total_return
    }

# --- Main Execution Block ---

def main():
    # Default parameters for a robust example (e.g., comparing S&P 500 vs. Tesla)
    DEFAULT_TICKERS = ["SPY", "TSLA"]
    DEFAULT_START = "2019-01-01"
    DEFAULT_END = "2024-01-01"

    # 1. Input Handling using sys.argv
    # Check if command-line arguments override defaults
    if len(sys.argv) > 4:
        # sys.argv[0] is the script name itself
        try:
            tickers = [sys.argv[1].upper(), sys.argv[2].upper()]
            start_date = sys.argv[3]
            end_date = sys.argv[4]
        except IndexError:
            # Fallback handling for incomplete arguments, though length check should prevent it
            print("Error parsing arguments. Using defaults.")
            tickers = DEFAULT_TICKERS
            start_date = DEFAULT_START
            end_date = DEFAULT_END
    else:
        # Use defaults if insufficient arguments provided
        tickers = DEFAULT_TICKERS
        start_date = DEFAULT_START
        end_date = DEFAULT_END
        print(f"-> No command-line arguments provided. Using defaults: {tickers} ({start_date} to {end_date})")

    all_results = []
    
    # 2. Iterative Processing
    for ticker in tickers:
        prices = fetch_data(ticker, start_date, end_date)
        metrics = calculate_financial_metrics(prices, ticker)
        all_results.append(metrics)

    # 3. Display Results
    results_df = pd.DataFrame(all_results)
    
    # Format the percentage columns for clear reporting
    # Handle potential NaNs gracefully during formatting
    results_df['Annualized Volatility'] = (results_df['Annualized Volatility'] * 100).map(lambda x: f'{x:.2f}%' if pd.notna(x) else 'N/A')
    results_df['CAGR'] = (results_df['CAGR'] * 100).map(lambda x: f'{x:.2f}%' if pd.notna(x) else 'N/A')
    results_df['Total Log Return'] = (results_df['Total Log Return'] * 100).map(lambda x: f'{x:.2f}%' if pd.notna(x) else 'N/A')
    results_df['Total Simple Return'] = (results_df['Total Simple Return'] * 100).map(lambda x: f'{x:.2f}%' if pd.notna(x) else 'N/A')
    
    # Reorder columns for logical presentation
    results_df = results_df[['Ticker', 'Trading Periods', 'Annualized Volatility', 'CAGR', 'Total Simple Return', 'Total Log Return']]

    print("\n" + "="*80)
    print(f"FINANCIAL METRICS ANALYSIS REPORT: {start_date} to {end_date}")
    print("="*80)
    # Use to_markdown for clean, alignment-aware console output
    print(results_df.set_index('Ticker').to_markdown(numalign="left", stralign="left"))
    print("="*80)
    # Display current working directory context (as per glossary requirement)
    print(f"Execution context path: {os.getcwd()}")
    
if __name__ == "__main__":
    main()

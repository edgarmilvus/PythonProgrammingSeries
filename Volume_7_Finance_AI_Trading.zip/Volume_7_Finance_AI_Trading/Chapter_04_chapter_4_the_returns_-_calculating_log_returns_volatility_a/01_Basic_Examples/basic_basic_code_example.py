
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np
import pandas as pd

# --- 1. Define the Price Data ---
# Synthetic daily closing prices for a hypothetical stock over five days
# We use a dictionary structure for clarity before converting to a DataFrame.
price_data = {
    'Date': pd.to_datetime(['2024-01-01', '2024-01-02', '2024-01-03', '2024-01-04', '2024-01-05']),
    'Price': [100.00, 101.50, 99.00, 103.00, 102.50]
}
df = pd.DataFrame(price_data).set_index('Date')
# Ensure the index is sorted chronologically
df.sort_index(inplace=True)

# --- 2. Calculate Simple (Arithmetic) Returns ---
# Simple Return (R_s) = (P_t / P_{t-1}) - 1
# Pandas .pct_change() method is the most efficient way to calculate this.
df['Simple_Return'] = df['Price'].pct_change()

# --- 3. Calculate Logarithmic (Geometric) Returns ---
# Log Return (R_l) = ln(P_t / P_{t-1})
# We use np.log() on the ratio of the current price to the lagged price.
# .shift(1) moves the entire 'Price' series down by one period.
price_ratio = df['Price'] / df['Price'].shift(1)
df['Log_Return'] = np.log(price_ratio)

# --- 4. Calculate Daily Volatility ---
# Volatility is defined as the standard deviation of the returns series.
# We typically calculate volatility using log returns because they are
# statistically cleaner and approximately normally distributed.
daily_volatility = df['Log_Return'].std()

# --- 5. Display Results ---
print("--- Price Data and Calculated Returns ---")
print(df)
print("\n--- Summary Statistics ---")
print(f"Daily Volatility (Std Dev of Log Returns): {daily_volatility:.6f}")
print(f"Annualized Volatility (Assuming 252 trading days): {daily_volatility * np.sqrt(252):.6f}")

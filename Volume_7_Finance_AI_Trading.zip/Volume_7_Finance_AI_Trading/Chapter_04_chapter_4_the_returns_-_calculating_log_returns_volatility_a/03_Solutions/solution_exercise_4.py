
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import pandas as pd
import numpy as np

# Example of expected input structure
multi_asset_data = pd.DataFrame({
    'AAPL': [150.00, 151.20, 149.50, 153.00, 154.50, 156.00, 155.50],
    'MSFT': [280.00, 282.50, 281.00, 285.00, 287.50, 290.00, 291.00],
    'SPY': [400.00, 401.50, 400.50, 403.00, 404.50, 405.50, 406.00]
}, index=pd.to_datetime(['2024-01-01', '2024-01-02', '2024-01-03', '2024-01-04', '2024-01-05', '2024-01-08', '2024-01-09']))

class PortfolioAnalyzer:
    def __init__(self, prices_df):
        self.prices = prices_df
        # 1. Calculate log returns for all assets upon initialization
        self._log_returns = np.log(self.prices / self.prices.shift(1))
        self.annualization_factor = 252.0

    def _calculate_time_in_years(self):
        """Calculates total time T in years based on index dates."""
        start_date = self.prices.index[0]
        end_date = self.prices.index[-1]
        time_delta = end_date - start_date
        T = time_delta.days / 365.25
        return T

    # 2. Method 1: Annualized Volatility
    def get_annualized_volatility(self):
        # Drop the initial NaN row before calculating standard deviation (Robustness Check)
        daily_std = self._log_returns.dropna().std()
        
        # Annualize: Daily Vol * sqrt(252)
        annual_volatility = daily_std * np.sqrt(self.annualization_factor)
        return annual_volatility.rename('Annualized Volatility')

    # 3. Method 2: CAGR
    def get_cagr(self):
        T = self._calculate_time_in_years()
        
        # Get initial and final prices for all assets
        V_initial = self.prices.iloc[0]
        V_final = self.prices.iloc[-1]
        
        # Calculate CAGR using vectorized operation
        cagr_series = (V_final / V_initial)**(1 / T) - 1
        return cagr_series.rename('CAGR')

    # 4. Summary Report
    def generate_summary(self):
        volatility = self.get_annualized_volatility()
        cagr = self.get_cagr()
        
        # Combine results
        summary_df = pd.concat([volatility, cagr], axis=1)
        
        # Format as percentages
        summary_df['Annualized Volatility'] = (summary_df['Annualized Volatility'] * 100).map('{:.2f}%'.format)
        summary_df['CAGR'] = (summary_df['CAGR'] * 100).map('{:.2f}%'.format)
        
        return summary_df

# Execution
analyzer = PortfolioAnalyzer(multi_asset_data)
summary = analyzer.generate_summary()

print("--- Portfolio Performance Summary ---")
print(summary)

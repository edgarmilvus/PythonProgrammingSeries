
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import pandas as pd
import numpy as np

# Simulate 100 days of log returns for a more robust volatility calculation
np.random.seed(42) # for reproducibility
simulated_log_returns = pd.Series(
    np.random.normal(loc=0.0005, scale=0.015, size=100),
    name='Log_Return'
)

# 1. Data Preparation (Ensure no NaN values, although simulation avoids them)
log_returns = simulated_log_returns.dropna()

# 2. Daily Volatility: Standard deviation of the log returns
daily_std = log_returns.std()

# 3. Annualization Factor
ANNUALIZATION_FACTOR = 252
# Comment: 252 is used because it represents the approximate number of trading days in a typical year,
# excluding weekends and major holidays, focusing only on periods of market activity.

# 4. Annualized Volatility: Daily Vol * sqrt(T)
annualized_volatility = daily_std * np.sqrt(ANNUALIZATION_FACTOR)

# 5. Risk Interpretation (in comment)
# If the calculated annualized volatility were 25%, it would mean that, statistically, we expect the asset's return
# over one year to fall within a range defined by the mean return +/- 25% (one standard deviation)
# approximately 68.2% of the time, assuming returns are normally distributed.

# 6. Output
print("--- Volatility Calculation Summary ---")
print(f"Daily Standard Deviation (Daily Vol): {daily_std:.4f} ({daily_std * 100:.2f}%)")
print(f"Annualization Factor (T): {ANNUALIZATION_FACTOR}")
print(f"Annualized Volatility: {annualized_volatility:.4f} ({annualized_volatility * 100:.2f}%)")

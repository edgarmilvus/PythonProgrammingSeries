
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import numpy as np

# Simulated initial data structure
data = pd.DataFrame({
    'Close': [100.00, 101.50, 99.80, 102.50, 104.00, 103.50, 105.10]
}, index=pd.to_datetime(['2024-01-01', '2024-01-02', '2024-01-03', '2024-01-04', '2024-01-05', '2024-01-08', '2024-01-09']))

# 1. Simple Return Calculation: (P_t / P_{t-1}) - 1
data['Simple_Return'] = data['Close'].pct_change()

# 2. Log Return Calculation: ln(P_t / P_{t-1})
data['Log_Return'] = np.log(data['Close'] / data['Close'].shift(1))

# --- 3. Aggregation Test ---
# Cumulative Simple Return (Multiplicative aggregation)
cumulative_simple_return = (1 + data['Simple_Return'].dropna()).prod() - 1

# Cumulative Log Return (Additive aggregation)
cumulative_log_return = data['Log_Return'].sum()

# --- 4. Verification ---
P_initial = data['Close'].iloc[0]
P_final = data['Close'].iloc[-1]
price_ratio = P_final / P_initial

# Verification 1: 1 + Cumulative Simple Return must equal the price ratio
verification_simple = 1 + cumulative_simple_return

# Verification 2: e^(Cumulative Log Return) must equal the price ratio
verification_log = np.exp(cumulative_log_return)

# --- 5. Output ---
print("--- Return Aggregation Summary ---")
print(f"Initial Price: {P_initial:.2f}")
print(f"Final Price:   {P_final:.2f}")
print("-" * 35)

print(f"Cumulative Simple Return (Multiplicative): {cumulative_simple_return:.4f} ({cumulative_simple_return * 100:.2f}%)")
print(f"Verification (1 + Simple Return): {verification_simple:.4f}")
print("-" * 35)

print(f"Cumulative Log Return (Additive): {cumulative_log_return:.4f}")
print(f"Verification (e^(Log Return Sum)): {verification_log:.4f}")
print("-" * 35)
print(f"P_final / P_initial: {price_ratio:.4f} (Target Ratio)")

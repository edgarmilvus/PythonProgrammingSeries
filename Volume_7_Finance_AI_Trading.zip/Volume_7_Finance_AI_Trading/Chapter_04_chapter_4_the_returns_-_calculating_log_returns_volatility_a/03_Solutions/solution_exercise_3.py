
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import pandas as pd
from datetime import datetime

# Input Data
V_initial = 1_250_000
V_final = 1_890_000
start_date_str = '2019-03-15'
end_date_str = '2024-09-01'

# 1. Time Period Calculation
def calculate_time_in_years(start_date_str, end_date_str):
    """Calculates the precise time period T in years, accounting for leap years."""
    start_date = pd.to_datetime(start_date_str)
    end_date = pd.to_datetime(end_date_str)
    
    time_delta = end_date - start_date
    days = time_delta.days
    
    # Use 365.25 for precision in fractional year calculation
    T = days / 365.25
    return T

T = calculate_time_in_years(start_date_str, end_date_str)

# 2. CAGR Calculation
# CAGR = (V_final / V_initial)^(1/T) - 1
cagr = (V_final / V_initial)**(1 / T) - 1

# 3. Arithmetic Annual Return
# Arithmetic Annual Return = Total Percentage Gain / T
total_gain = (V_final / V_initial) - 1
arithmetic_annual_return = total_gain / T

# 4. Comparison and Interpretation
print("--- CAGR Calculation Summary ---")
print(f"Initial Value: ${V_initial:,.2f}")
print(f"Final Value:   ${V_final:,.2f}")
print(f"Time Period (T) in years: {T:.4f} years")
print("-" * 35)

print(f"Compound Annual Growth Rate (CAGR): {cagr * 100:.3f}%")
print(f"Arithmetic Average Annual Return:   {arithmetic_annual_return * 100:.3f}%")
print("-" * 35)

print("Interpretation:")
print("The CAGR (geometric mean) is typically lower than the arithmetic average return.")
print("This difference is due to volatility drag: the arithmetic average ignores compounding and assumes")
print("a linear path, whereas CAGR reflects the true, smoothed annual rate achieved by the investment,")
print("accurately accounting for the negative impact of volatility on long-term growth.")

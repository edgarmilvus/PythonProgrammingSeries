
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# The central repository of calculated metrics
asset_metrics = {
    'AAPL': {
        'CAGR': 0.15,
        'Annualized_Vol': 0.22,
        'Sharpe_Ratio': 0.85
    },
    'TSLA': {
        'CAGR': 0.35,
        # Annualized_Vol is missing for TSLA
        'Sharpe_Ratio': 1.10
    }
}

# 1. Safe Retrieval Function using dict.get()
def get_volatility_safe(metrics_dict, asset_ticker):
    """
    Safely retrieves Annualized_Vol using nested dict.get().
    Returns 0.00 if the asset or the metric is missing.
    """
    # First .get(): Safely retrieve the inner dictionary for the asset. Default is an empty dict {}.
    asset_data = metrics_dict.get(asset_ticker, {})
    
    # Second .get(): Safely retrieve the metric from the inner dictionary. Default is 0.00.
    volatility = asset_data.get('Annualized_Vol', 0.00)
    
    return volatility

print("--- Safe Data Retrieval (dict.get()) ---")

# 2. Testing the Failure Case (Success)
aapl_vol = get_volatility_safe(asset_metrics, 'AAPL')
print(f"AAPL Volatility (Success): {aapl_vol:.2f}")

# 2. Testing the Failure Case (Missing Metric)
tsla_vol = get_volatility_safe(asset_metrics, 'TSLA')
print(f"TSLA Volatility (Missing Metric): {tsla_vol:.2f} (Returned Default)")

# 2. Testing the Failure Case (Missing Asset entirely)
amzn_vol_safe = get_volatility_safe(asset_metrics, 'AMZN')
print(f"AMZN Volatility (Missing Asset): {amzn_vol_safe:.2f} (Returned Default)")

print("\n--- EAFP Implementation (try...except) ---")

# 3. Testing EAFP Implementation
non_existent_asset = 'AMZN'

try:
    # Attempt to access the non-existent key using bracket notation
    metrics = asset_metrics[non_existent_asset]
except KeyError:
    # Handle the expected failure gracefully
    print(f"Error: Asset {non_existent_asset} not found in metrics dictionary.")

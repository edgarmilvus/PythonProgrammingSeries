
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import pandas as pd
import yfinance as yf
import mplfinance as mpf
import datetime

# --- 1. Configuration and Data Acquisition Parameters ---
# Define the stock ticker and the time window for analysis.
TICKER_SYMBOL = "AAPL"
START_DATE = datetime.datetime(2023, 1, 1)
END_DATE = datetime.datetime(2023, 3, 1)

# --- 2. Data Fetching and Validation ---
print(f"Attempting to fetch data for {TICKER_SYMBOL}...")

# Fetch historical OHLCV data using yfinance.
# The 'data' variable will be a Pandas DataFrame.
try:
    data = yf.download(TICKER_SYMBOL, start=START_DATE, end=END_DATE, progress=False)
except Exception as e:
    print(f"FATAL ERROR: Could not fetch data. Ensure internet connection is stable. Details: {e}")
    exit()

# CRITICAL DATA CHECK: 
# 1. Ensure the DataFrame is not empty (e.g., if the ticker was invalid).
# 2. mplfinance requires the index to be a DatetimeIndex (which yfinance provides).
if data.empty:
    print(f"No data retrieved for {TICKER_SYMBOL} in the specified period.")
    exit()

# 3. Rename columns to ensure strict capitalization required by mplfinance (OHLCV)
# Although yfinance often uses the correct capitalization, explicit renaming ensures safety.
data.columns = ['Open', 'High', 'Low', 'Close', 'Adj Close', 'Volume']
data = data[['Open', 'High', 'Low', 'Close', 'Volume']] # Keep only required columns

# --- 3. Visualization Configuration (Plotting Arguments) ---
# Define the visual style. 'yahoo' is a commonly used, clean style.
CHART_STYLE = 'yahoo'

# Create a dictionary of keyword arguments (kwargs) for the plot function.
plot_kwargs = dict(
    type='candle',          # MANDATORY: Specify the chart type as candlestick.
    volume=True,            # Include the volume subplot synchronized below the price action.
    style=CHART_STYLE,      # Apply the chosen visual style (colors, grid lines).
    title=f"{TICKER_SYMBOL} Price & Volume ({START_DATE.strftime('%Y-%m-%d')} to {END_DATE.strftime('%Y-%m-%d')})",
    ylabel='Stock Price (USD)',
    ylabel_lower='Trading Volume',
    figratio=(15, 8),       # Define the figure aspect ratio (Width:Height).
    figscale=1.2,           # Scale the overall figure size for better display.
    show_nontrading=False   # Hide gaps on the X-axis where no trading occurred (weekends/holidays).
)

# --- 4. Generating the Visualization ---
print("Rendering financial chart...")

# Execute the plot function. The **plot_kwargs unpacks the dictionary 
# into individual keyword arguments passed to mpf.plot().
mpf.plot(data, **plot_kwargs)

print("Chart generation complete. Visualization window displayed.")

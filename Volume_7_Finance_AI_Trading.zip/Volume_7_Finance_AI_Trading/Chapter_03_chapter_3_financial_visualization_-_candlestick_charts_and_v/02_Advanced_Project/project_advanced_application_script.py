
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import yfinance as yf
import mplfinance as mpf
import datetime
from datetime import timedelta

# --- 1. CONFIGURATION CONSTANTS ---
TICKER = 'AAPL'
DAYS_LOOKBACK = 100
FILENAME = f"{TICKER}_Advanced_Chart.png"

# Calculate start date dynamically
END_DATE = datetime.date.today()
START_DATE = END_DATE - timedelta(days=DAYS_LOOKBACK)

def fetch_ohlcv_data(ticker: str, start: datetime.date, end: datetime.date) -> pd.DataFrame:
    """
    Fetches OHLCV data using yfinance and ensures the index is a DatetimeIndex.
    """
    print(f"Fetching data for {ticker} from {start} to {end}...")
    try:
        data = yf.download(ticker, start=start, end=end, progress=False)
        if data.empty:
            raise ValueError("No data returned for the specified period.")
        
        # Rename columns to match mplfinance's expected case (Open, High, Low, Close, Volume)
        data.columns = [col.capitalize() for col in data.columns]
        
        return data
    except Exception as e:
        print(f"Error fetching data: {e}")
        return pd.DataFrame()

def create_dark_style() -> dict:
    """
    Defines a custom dark-mode style dictionary for mplfinance visualization.
    This custom style emphasizes contrast for technical analysis.
    """
    # Define market colors for bullish (green) and bearish (red) candles
    mc = mpf.make_marketcolors(
        up='tab:green', down='tab:red',
        edge='inherit', wick='inherit',
        volume='tab:blue',
        ohlc='i' # inherit from up/down
    )

    # Define the overall style, inheriting from the built-in 'nightclouds' style
    s = mpf.make_mpf_style(
        base_mpf_style='nightclouds',
        marketcolors=mc,
        figcolor='#1a1a1a',      # Dark background for the figure area
        facecolor='#222222',     # Slightly lighter background for the plot area
        gridcolor='#444444',
        y_on_right=False,
        rc={'font.size': 9}      # Reduce font size slightly
    )
    return s

def generate_advanced_chart(df: pd.DataFrame, style_config: dict, filename: str):
    """
    Generates and saves the advanced candlestick chart with SMAs and volume.
    """
    if df.empty:
        print("Cannot plot empty DataFrame.")
        return

    # --- 2. Define Moving Averages (MAVs) ---
    # We specify 50-day and 200-day Simple Moving Averages.
    # mplfinance handles the calculation and overlay automatically via the 'mav' parameter.
    ma_periods = (50, 200)

    # --- 3. Customizing Indicator Appearance (AddPlots) ---
    # Although SMAs are handled by 'mav', we can use addplots for further customization
    # or to add non-standard indicators. Here, we define the colors for the MAV lines.
    
    # We define the 50-day MA line appearance (Yellow)
    # The 'mav' parameter automatically generates the data, but we use `make_addplot`
    # structure to define the visual characteristics if we wanted more control.
    # For simplicity and efficiency, we rely on the default colors for 'mav' unless
    # explicitly overriding the entire style set, which is often easier.
    
    # Let's rely on the 'mav' parameter and let the style handle the line colors,
    # or explicitly define colors if the default style is too generic.
    
    # Define plot settings for the 50-day MA (Short-term trend line)
    # Note: When using the 'mav' parameter, mplfinance automatically adds these.
    # We use this structure if we needed to calculate the indicators manually (e.g., EMA, VWAP).
    # Since we are using standard SMAs, we proceed with the simple `mav` call.
    
    # --- 4. Plotting Configuration ---
    plot_kwargs = dict(
        type='candle',              # Candlestick chart type
        style=style_config,         # Apply the custom dark style
        title=f"{TICKER} Price Action & Long-Term Trend Analysis ({START_DATE} to {END_DATE})",
        ylabel='Price ($)',
        ylabel_lower='Volume',
        volume=True,                # Include the volume subplot
        mav=ma_periods,             # Overlay the 50-day and 200-day SMAs
        tight_layout=True,          # Adjust layout for better fit
        savefig=dict(fname=filename, dpi=300, bbox_inches='tight') # Save the output
    )

    # Generate and save the plot
    mpf.plot(df, **plot_kwargs)
    print(f"\nSuccessfully generated and saved chart to: {filename}")


if __name__ == "__main__":
    # 1. Fetch Data
    price_data = fetch_ohlcv_data(TICKER, START_DATE, END_DATE)

    if not price_data.empty:
        # 2. Create Custom Style
        custom_style = create_dark_style()

        # 3. Generate Chart
        generate_advanced_chart(price_data, custom_style, FILENAME)

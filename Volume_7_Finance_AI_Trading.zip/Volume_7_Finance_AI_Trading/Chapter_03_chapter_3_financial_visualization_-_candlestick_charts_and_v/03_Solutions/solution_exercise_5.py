
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import pandas as pd
import mplfinance as mpf
import sys

# Assume df is the prepared OHLCV DataFrame
df_interactive = df.iloc[-150:] 

def plot_dynamic_mas(data_frame):
    """Prompts user for MA periods and generates the corresponding plot."""
    
    # 1. Get user input for MA periods
    user_input = input("\nEnter comma-separated MA periods (e.g., 10, 30, 65) or type 'exit': ").strip()
    
    if user_input.lower() == 'exit' or not user_input:
        return None, True # Signal exit
        
    # 2. Validate and convert input to a tuple of integers
    try:
        # Split input, filter for digits, convert to integers
        periods_list = [int(p.strip()) for p in user_input.split(',') if p.strip().isdigit()]
        
        # Basic error checking: must have valid positive integers
        if not periods_list or any(p <= 0 for p in periods_list):
            print(">>> Invalid input. Please enter one or more positive integers only (e.g., 20, 50).")
            return None, False
            
        valid_periods = tuple(periods_list)
        
    except ValueError:
        print(">>> Invalid input format. Please use comma-separated numbers.")
        return None, False

    # 3. Dynamic Plotting
    try:
        mpf.plot(
            data_frame,
            type='candle',
            mav=valid_periods,
            volume=True,
            style='charles',
            title=f"Dynamic Analysis: MAs {valid_periods}",
            figratio=(12, 8),
            show_nontrading=False
        )
        print(f"Chart generated successfully for MAs: {valid_periods}")
        return valid_periods, False
        
    except Exception as e:
        print(f">>> An error occurred during plotting: {e}")
        return None, False

# 4. Execution Loop
print("\n--- Interactive MA Plotting Challenge ---")
print("Using 'charles' style with Volume subplot enabled.")

while True:
    periods, should_exit = plot_dynamic_mas(df_interactive)
    
    if should_exit:
        print("Exiting interactive plotting session.")
        break

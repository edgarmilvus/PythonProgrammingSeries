
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import pandas as pd
import mplfinance as mpf
import os

# Assume df is the prepared OHLCV DataFrame
df_custom = df.iloc[-60:]

# 1. Define Custom Market Colors
mc = mpf.make_marketcolors(
    up='#00FF00',      # Bright Green for up-fill
    down='#FF0000',    # Deep Red for down-fill
    edge={'up': '#00FF00', 'down': '#FF0000'}, # Matching edges
    wick={'up': '#00FF00', 'down': '#FF0000'}, # Matching wicks
    volume='in',       # Color volume based on price change
    inherit=False,
    fill=True          # Ensure candles are filled
)

# 2. Define Custom Style (Dark Theme)
s = mpf.make_mpf_style(
    marketcolors=mc,
    base_mpf_style='yahoo', 
    facecolor='#1A1A1A',    # Dark background
    gridcolor='#444444',    # Subtle gray grid
    rc={'axes.labelcolor': 'white', 
        'xtick.color': 'white', 
        'ytick.color': 'white',
        'figure.titlesize': 'x-large'}
)

# Define output filename
filename = 'DarkTheme_AAPL_60Day.png'

# 3. Generate and Save the Plot
mpf.plot(
    df_custom,
    type='candle',
    style=s,
    title='AAPL 60-Day Price Action (Dark Theme)',
    savefig=dict(fname=filename, dpi=300), # Save configuration
    close=True # Suppress interactive display
)

print(f"Chart saved successfully as {filename}")

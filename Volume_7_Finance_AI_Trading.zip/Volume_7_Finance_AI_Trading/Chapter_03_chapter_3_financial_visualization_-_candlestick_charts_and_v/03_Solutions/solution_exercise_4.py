
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import pandas as pd
import mplfinance as mpf

# Assume df is the prepared OHLCV DataFrame
df_ema = df.iloc[-90:].copy() # Work on a copy

# 1. External Indicator Calculation using Pandas EWM
# Calculate 12-period EMA (Fast)
df_ema['EMA_12'] = df_ema['Close'].ewm(span=12, adjust=False).mean()
# Calculate 26-period EMA (Slow)
df_ema['EMA_26'] = df_ema['Close'].ewm(span=26, adjust=False).mean()

# 2. addplot Preparation
apds = [
    # Fast EMA (12) - thin, dashed, bright color
    mpf.make_addplot(
        df_ema['EMA_12'],
        color='yellow',
        linestyle='--',
        width=1.0,
        panel=0, 
        label='EMA 12 (Fast)'
    ),
    # Slow EMA (26) - solid, slightly thicker, distinct color
    mpf.make_addplot(
        df_ema['EMA_26'],
        color='magenta',
        linestyle='-',
        width=1.5,
        panel=0, 
        label='EMA 26 (Slow)'
    )
]

# 3. Visualization Generation
mpf.plot(
    df_ema,
    type='candle',
    addplot=apds,          # Integrate the externally calculated EMAs
    style='yahoo',
    title="AAPL 90-Day Candlestick with External EMAs (addplot)",
    figratio=(12, 7)
)

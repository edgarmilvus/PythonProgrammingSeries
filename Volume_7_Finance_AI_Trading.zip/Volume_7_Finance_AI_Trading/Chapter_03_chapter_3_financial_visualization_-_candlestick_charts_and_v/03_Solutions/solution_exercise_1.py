
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import mplfinance as mpf
import numpy as np

# --- Data Setup (Simulating yfinance output for AAPL) ---
np.random.seed(42)
# Generate 300 business days of data
dates = pd.date_range(start='2023-01-01', periods=300, freq='B')
initial_price = 150.0
prices = initial_price + np.cumsum(np.random.randn(300) * 0.5)
volumes = np.random.randint(500000, 5000000, 300)

df = pd.DataFrame({
    'Close': prices,
    'Open': prices - np.random.uniform(-1, 1, 300),
    'High': prices + np.random.uniform(0.5, 1.5, 300),
    'Low': prices - np.random.uniform(0.5, 1.5, 300),
    'Volume': volumes
}, index=dates)
# Ensure standard OHLCV order
df = df[['Open', 'High', 'Low', 'Close', 'Volume']].sort_index()
# --- End Data Setup ---

# 1. Data Preparation Check (Verifying structure)
print(f"Index is DatetimeIndex: {isinstance(df.index, pd.DatetimeIndex)}")

# 2. Short-Term Visualization (Last 30 days)
df_short = df.iloc[-30:]
mpf.plot(
    df_short,
    type='candle',
    title="30-Day Price Action Analysis",
    style='yahoo',
    figratio=(10, 6)
)

# 3. Long-Term Visualization (Last 180 days)
df_long = df.iloc[-180:]
mpf.plot(
    df_long,
    type='candle',
    title="180-Day Price Action Context",
    style='yahoo',
    figratio=(10, 6)
)

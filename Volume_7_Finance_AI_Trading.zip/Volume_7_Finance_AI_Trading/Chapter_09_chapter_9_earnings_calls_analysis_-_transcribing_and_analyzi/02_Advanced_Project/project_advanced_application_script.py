
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, Any

# --- Configuration and Mocking ---

# Mocking the OpenAI client for structural demonstration.
# In a real environment, this class would be replaced by `openai.OpenAI()`.
class MockOpenAI:
    """Simulates the behavior of the OpenAI API client for audio transcription."""
    def audio(self):
        return self

    def transcribe(self, model: str, file: Path) -> Dict[str, Any]:
        """Simulates the API call, latency, and returns a structured response."""
        # Simulate API latency (1 to 4 seconds) based on file name length
        delay = 1 + len(file.name) % 4
        time.sleep(delay)
        
        # Simulate high-quality transcription result
        content = f"TRANSCRIPT START for {file.stem} ({model}):\n"
        content += "The CEO emphasized disciplined capital allocation and noted that macro headwinds, particularly in Europe, have necessitated a revision of full-year guidance. We see strong operational leverage moving into Q4.\n"
        content += "Q&A Session: Analyst asked about inventory levels; CFO responded with confidence in current stocking strategy.\n"
        content += "TRANSCRIPT END."
        return {'text': content}

# Initialize the mock client and constants
client = MockOpenAI()
WHISPER_MODEL = "whisper-1" # The standard high-accuracy model

# Define paths using pathlib for robust, platform-independent path handling
ROOT_DIR = Path.cwd()
AUDIO_DIR = ROOT_DIR / "earnings_audio_archive"
TRANSCRIPT_DIR = ROOT_DIR / "transcribed_reports"
MAX_WORKERS = 4 # Optimal number of concurrent threads for API interaction

# --- Core Transcription Logic ---

def transcribe_and_save(audio_path: Path, output_dir: Path) -> str:
    """
    Worker function: Handles the transcription of a single audio file, 
    manages API interaction, and saves the output.
    """
    
    # 1. Define output path and check for existing transcript
    file_name = audio_path.stem
    output_file = output_dir / f"{file_name}.txt"
    
    if output_file.exists():
        # Avoid redundant API calls if the file was processed previously
        return f"Skipped: {file_name} (Transcript already exists)."

    try:
        print(f"[{time.strftime('%H:%M:%S')}] Starting: {file_name}...")
        
        # 2. Prepare the file for API submission
        # In a real implementation, we would use:
        # with open(audio_path, "rb") as audio_file:
        #     response = client.audio.transcriptions.create(model=WHISPER_MODEL, file=audio_file)
        
        # Using the mock client structure:
        response = client.audio().transcribe(
            model=WHISPER_MODEL, 
            file=audio_path # Pass Path object to mock for identification
        )

        transcript_text = response['text']
        
        # 3. Save the transcription to the target directory
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(transcript_text)
        
        return f"Success: {file_name} transcribed and saved to {output_file.name}"

    except Exception as e:
        # Graceful failure: report error but allow other jobs to continue
        return f"Error processing {file_name}: {type(e).__name__} - {e}"

# --- Batch Processing Orchestration ---

def process_batch(input_dir: Path, output_dir: Path):
    """
    Orchestrates the parallel transcription using a ThreadPoolExecutor.
    """
    
    # Setup: Ensure necessary directories exist
    input_dir.mkdir(exist_ok=True)
    output_dir.mkdir(exist_ok=True)
    
    # Simulation: Create dummy placeholders for audio files
    dummy_files = ["TSLA_Q1_2024.mp3", "GOOG_Q1_2024.wav", "MSFT_Q1_2024.mp3", "AMZN_Q1_2024.mp3", "NVDA_Q1_2024.mp3"]
    for df in dummy_files:
        (input_dir / df).touch(exist_ok=True) # Create empty files

    # Identify target files (MP3 and WAV extensions)
    audio_files = list(input_dir.glob("*.mp3")) + list(input_dir.glob("*.wav"))
    
    if not audio_files:
        print(f"No audio files found in {input_dir}. Please place files there.")
        return

    print(f"Starting batch transcription for {len(audio_files)} files using {MAX_WORKERS} workers...")
    
    results = []
    # ThreadPoolExecutor is ideal for I/O bound tasks like API calls
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        # 1. Submit tasks and map the future object back to the original file name
        future_to_file = {
            executor.submit(transcribe_and_save, file_path, output_dir): file_path.name
            for file_path in audio_files
        }
        
        # 2. Collect results asynchronously as they complete
        for future in as_completed(future_to_file):
            file_name = future_to_file[future]
            try:
                result = future.result()
                results.append(result)
            except Exception as e:
                # Catch exceptions that occurred during future retrieval
                results.append(f"Critical System Failure during retrieval for {file_name}: {e}")

    print("\n--- Batch Summary ---")
    for res in sorted(results):
        print(res)

# --- Execution Block ---
if __name__ == "__main__":
    print("--- Earnings Call Batch Transcriber Initialized ---")
    process_batch(AUDIO_DIR, TRANSCRIPT_DIR)
    print("--- Transcription Process Complete ---")


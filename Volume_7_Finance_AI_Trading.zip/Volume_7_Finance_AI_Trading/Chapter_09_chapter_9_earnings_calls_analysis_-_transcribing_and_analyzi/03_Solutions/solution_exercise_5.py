
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# Assume the following structure exists in a module called 'whisper_engine.py'

class MockWhisperModel:
    """A stand-in for the actual loaded Whisper model."""
    def __init__(self, name):
        self.name = name

    def transcribe(self, audio_file_path: str, **kwargs) -> dict:
        """
        The expensive, time-consuming function that needs to be patched.
        """
        print(f"--- REAL TRANSCRIPTION RUNNING for {audio_file_path} ---")
        # Simulate real execution time
        import time; time.sleep(0.01) 
        return {"status": "real_data_processed", "segments": []}


MOCK_TRANSCRIPTION_RESULT = {
    "text": "Mock data success. Pipeline test passed.",
    "segments": [
        {"start": 0.0, "end": 3.0, "text": "Mock data success."}
    ]
}

def mock_transcribe(self, audio_file_path: str, **kwargs) -> dict:
    """
    The fast replacement function. Must accept 'self' as it will become a method.
    """
    print(f"--- MOCK TRANSCRIPTION EXECUTED INSTANTLY for {audio_file_path} ---")
    print(f"  (Model name: {self.name})") # Verify 'self' binding
    return MOCK_TRANSCRIPTION_RESULT

def apply_whisper_patch(model_instance: MockWhisperModel):
    """
    Uses Monkey Patching to replace the real transcribe method 
    with the mock_transcribe function.
    """
    # Key step: We must bind the function to the instance/class 
    # so that 'self' is correctly passed when the method is called.
    model_instance.transcribe = mock_transcribe.__get__(model_instance, MockWhisperModel)
    print(f"\n[PATCH] Successfully patched 'transcribe' method on model '{model_instance.name}'.")

# --- Interactive Test Scenario ---

# 1. Initialize the real model stand-in
real_model = MockWhisperModel('large-v3')
print("\n--- Test 1: Unpatched Call ---")
result_real = real_model.transcribe('financial_call_1.mp3')
print(f"Result Status: {result_real['status']}")

# 2. Apply the patch
apply_whisper_patch(real_model)

# 3. Test the patched call
print("\n--- Test 2: Patched Call ---")
result_mock = real_model.transcribe('financial_call_2.mp3', language='en') # Arguments are ignored by mock
print(f"Result Status: {result_mock['text']}")

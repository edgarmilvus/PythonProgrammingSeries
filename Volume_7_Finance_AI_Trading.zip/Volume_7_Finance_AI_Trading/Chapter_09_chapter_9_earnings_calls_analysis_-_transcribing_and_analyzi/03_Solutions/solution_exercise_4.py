
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from typing import Dict, List

# Mock Whisper output structure (simplified for exercise context)
MOCK_WHISPER_OUTPUT = {
    "segments": [
        {"start": 0.0, "end": 5.2, "text": "The quarter was strong.", "confidence": 0.99},
        {"start": 5.2, "end": 10.5, "text": "We faced supply chain headwinds.", "confidence": 0.85},
        {"start": 10.5, "end": 14.0, "text": "Our guidance for Q4 is...", "confidence": 0.62}, # Low quality segment
        {"start": 14.0, "end": 20.0, "text": "The market reacted positively.", "confidence": 0.95},
        {"start": 20.0, "end": 25.5, "text": "Can you elaborate on the debt structure?", "confidence": 0.74}, # Borderline
    ],
    "text": "..."
}

def analyze_transcription_quality(whisper_result: Dict, threshold: float) -> List[Dict]:
    """
    Analyzes segment confidence scores and flags low-quality segments 
    below the specified threshold.
    """
    flagged_segments = []
    
    segments = whisper_result.get("segments", [])
    
    if not segments:
        print("[WARNING] No segments found in the transcription result.")
        return []

    print(f"Analyzing {len(segments)} segments with threshold set at {threshold:.2f}...")

    for segment in segments:
        confidence = segment.get("confidence")
        
        if confidence is None:
            # Handle segments missing confidence (rare, but possible with some models/wrappers)
            print(f"[WARNING] Segment at {segment['start']:.1f}s is missing confidence score.")
            continue
            
        if confidence < threshold:
            flagged_segments.append({
                "global_start": segment['start'],
                "global_end": segment['end'],
                "confidence_score": round(confidence, 4),
                "text": segment['text'].strip()
            })
            
    return flagged_segments

# Example Usage
CONFIDENCE_THRESHOLD = 0.75
low_quality_report = analyze_transcription_quality(MOCK_WHISPER_OUTPUT, CONFIDENCE_THRESHOLD)

print("\n--- Low Quality Transcription Report ---")
if low_quality_report:
    for item in low_quality_report:
        print(f"FLAGGED: [{item['global_start']:.2f}s - {item['global_end']:.2f}s]")
        print(f"  Score: {item['confidence_score']} (Below {CONFIDENCE_THRESHOLD})")
        print(f"  Text: '{item['text']}'")
else:
    print("No segments fell below the confidence threshold.")

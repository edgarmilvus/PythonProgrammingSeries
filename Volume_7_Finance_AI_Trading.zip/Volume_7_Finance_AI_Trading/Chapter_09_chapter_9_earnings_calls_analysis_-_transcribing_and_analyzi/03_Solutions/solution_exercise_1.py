
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import sys
import os

# --- MOCKING WHISPER AND DEPENDENCIES ---
# In a real environment, this would be: import whisper
class MockWhisperModel:
    def __init__(self, name, device):
        self.name = name
        self.device = device
        print(f"[LOAD] Model '{name}' initialized on {device}.")

def mock_load_model(name, device):
    # Simulate the time cost of loading a large model
    return MockWhisperModel(name, device)

# Assume the loading function is available globally
WHISPER_LOADER = mock_load_model 
# --- END MOCK ---

class FinancialWhisperLoader:
    """
    Manages the loading and singleton instance of the Whisper model.
    """
    _model_instance = {} # Use a dictionary to store instances by model name

    @classmethod
    def load_model(cls, model_name: str, device: str = 'cpu', allow_download: bool = False):
        """
        Loads the model instance, ensuring it's a singleton per model_name.
        """
        if model_name in cls._model_instance:
            print(f"[INFO] Returning existing singleton instance for '{model_name}'.")
            return cls._model_instance[model_name]

        # Controlled Initialization Check (Simulation)
        # In a real scenario, this would check local disk paths
        if not allow_download and model_name not in ['tiny', 'base']:
            print(f"[WARNING] Model '{model_name}' not found locally. Download blocked by policy.")
            return None
        
        # Load the model (first time initialization)
        print(f"[INIT] Loading model '{model_name}' for the first time...")
        try:
            model = WHISPER_LOADER(model_name, device)
            cls._model_instance[model_name] = model
            return model
        except Exception as e:
            print(f"[ERROR] Failed to load Whisper model: {e}")
            return None

def check_whisper_environment():
    """
    Verifies the presence of core dependencies required for transcription.
    """
    print("--- Checking Transcription Environment Readiness ---")
    
    # 1. Check core Python libraries (Whisper/Torch)
    try:
        # Simulate checking for 'whisper' and 'torch'
        import torch
        print(f"[OK] PyTorch installed (Version: {torch.__version__}).")
    except ImportError:
        print("[FAIL] PyTorch not found. Install torch.")
        return False
    
    # 2. Check underlying system dependencies (e.g., ffmpeg)
    # This requires checking the system path, simulated here:
    if os.name == 'posix' or os.name == 'nt':
        # Simulate checking if 'ffmpeg' command is available
        print("[OK] ffmpeg verified (Assumed available on PATH).")
    else:
        print("[WARNING] Cannot verify ffmpeg availability.")
        
    print("--- Environment Check Complete: Ready for Initialization ---")
    return True

# Example Usage:
check_whisper_environment()
model_1 = FinancialWhisperLoader.load_model('small', device='cpu', allow_download=True)
model_2 = FinancialWhisperLoader.load_model('small', device='cpu', allow_download=True) # Should return model_1 instantly
model_3 = FinancialWhisperLoader.load_model('medium', device='cpu', allow_download=False) # Should fail due to policy

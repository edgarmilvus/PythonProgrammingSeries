
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
import tempfile
import uuid
from typing import List

class TemporaryFileCleanupContext:
    """
    A context manager that ensures temporary files are deleted 
    upon exit, regardless of exceptions.
    """
    def __init__(self):
        self._files_to_delete: List[str] = []

    def __enter__(self) -> List[str]:
        """
        Initializes the tracker list and returns it to the 'with' block user.
        """
        print("[CONTEXT] Entering cleanup context. Tracker initialized.")
        return self._files_to_delete

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Guarantees cleanup of all tracked files.
        """
        print("\n[CONTEXT] Exiting cleanup context. Starting file deletion...")
        
        for file_path in self._files_to_delete:
            if os.path.exists(file_path):
                try:
                    os.remove(file_path)
                    print(f"  [CLEANUP] Successfully deleted: {file_path}")
                except OSError as e:
                    # Log or handle cases where the file might be locked
                    print(f"  [ERROR] Could not delete {file_path}: {e}")
            else:
                print(f"  [INFO] File already deleted or not found: {file_path}")

        if exc_type:
            print(f"\n[ERROR] An exception occurred during the block: {exc_val}")
            # Returning False allows the exception to propagate normally
            return False 
        
        print("[CONTEXT] Cleanup complete.")
        return True # Returning True here would suppress exceptions, but False is better for debugging

# --- Demonstration of Integration ---

def simulate_chunked_process(should_fail: bool):
    """Simulates the transcription loop using the context manager."""
    
    with TemporaryFileCleanupContext() as tracker:
        
        for i in range(3):
            # 1. Generate a simulated temporary chunk file
            temp_file_name = f"temp_chunk_{uuid.uuid4()}.wav"
            with open(temp_file_name, 'w') as f:
                f.write(f"Audio data for chunk {i}")
            
            # 2. Add path to tracker
            tracker.append(temp_file_name)
            print(f"[PROCESS] Created and tracking file: {temp_file_name}")
            
            # 3. Transcribe chunk (Simulation)
            if should_fail and i == 1:
                print("[SIMULATION] Transcription failed unexpectedly!")
                raise RuntimeError("Simulated GPU driver crash.")
                
        print("[PROCESS] Transcription finished successfully.")
        
# Test 1: Successful run (files should be deleted)
print("--- TEST 1: Successful Run ---")
simulate_chunked_process(should_fail=False)

# Test 2: Failure run (files must still be deleted)
print("\n--- TEST 2: Failure Run (Cleanup must occur) ---")
try:
    simulate_chunked_process(should_fail=True)
except RuntimeError as e:
    print(f"[MAIN] Caught expected exception: {e}")

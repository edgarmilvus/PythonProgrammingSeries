
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import math
from typing import List, Dict
import os

# --- MOCKING AUDIO LIBRARIES AND WHISPER ---
CHUNK_DURATION = 30 # seconds
TOTAL_AUDIO_DURATION = 95 # seconds (Simulated length of large_earnings_call.mp3)

def mock_segment_audio(audio_path: str, chunk_duration_seconds: int) -> List[str]:
    """Simulates audio segmentation using pydub/librosa."""
    num_chunks = math.ceil(TOTAL_AUDIO_DURATION / chunk_duration_seconds)
    chunk_paths = [f"temp_chunk_{i}.wav" for i in range(num_chunks)]
    print(f"[SEGMENT] Divided '{audio_path}' into {num_chunks} chunks.")
    return chunk_paths

def mock_transcribe_chunk(chunk_path, model):
    """
    Simulates transcription result relative to the chunk start (0:00).
    The confidence score is added here for later exercises.
    """
    chunk_index = int(chunk_path.split('_')[2].split('.')[0])
    
    if chunk_index == 0:
        return {
            "segments": [
                {"start": 0.0, "end": 5.0, "text": "Start of call.", "confidence": 0.98},
                {"start": 5.0, "end": 15.0, "text": "First chunk data.", "confidence": 0.95},
            ]
        }
    elif chunk_index == 1:
        return {
            "segments": [
                {"start": 0.0, "end": 8.0, "text": "Continuation of discussion.", "confidence": 0.92},
                {"start": 8.0, "end": 12.0, "text": "Second chunk data.", "confidence": 0.88},
            ]
        }
    else: # Chunk 2 and beyond
        return {
            "segments": [
                {"start": 0.0, "end": 10.0, "text": f"Chunk {chunk_index} data.", "confidence": 0.90},
            ]
        }
# --- END MOCK ---

def transcribe_and_stitch(audio_path: str, model) -> List[Dict]:
    """Manages segmentation, transcription, re-mapping, and stitching."""
    
    chunk_duration = CHUNK_DURATION
    chunk_paths = mock_segment_audio(audio_path, chunk_duration)
    
    full_transcript = []
    
    for i, chunk_path in enumerate(chunk_paths):
        # Calculate the global time offset for this chunk
        time_offset = i * chunk_duration
        
        print(f"\n[TRANSCRIPTION] Processing chunk {i+1} (Offset: {time_offset:.1f}s)")
        
        # 1. Transcribe the chunk
        chunk_result = mock_transcribe_chunk(chunk_path, model)
        
        # 2. Re-map timestamps and stitch
        for segment in chunk_result.get("segments", []):
            
            # Adjust relative timestamps to global timestamps
            global_start = segment['start'] + time_offset
            global_end = segment['end'] + time_offset
            
            stitched_segment = {
                "global_start": round(global_start, 2),
                "global_end": round(global_end, 2),
                "text": segment['text'],
                "confidence": segment.get('confidence', 1.0) # Include confidence for future use
            }
            full_transcript.append(stitched_segment)
            
    return full_transcript

# Example usage (requires a mock model instance)
class DummyModel: pass
dummy_model = DummyModel()
stitched_output = transcribe_and_stitch('large_earnings_call.mp3', dummy_model)

# Print the first few stitched segments to verify re-mapping
print("\n--- Final Stitched Transcript (First 5 Segments) ---")
for segment in stitched_output[:5]:
    print(f"[{segment['global_start']:.2f}s - {segment['global_end']:.2f}s] {segment['text']} (Conf: {segment['confidence']})")

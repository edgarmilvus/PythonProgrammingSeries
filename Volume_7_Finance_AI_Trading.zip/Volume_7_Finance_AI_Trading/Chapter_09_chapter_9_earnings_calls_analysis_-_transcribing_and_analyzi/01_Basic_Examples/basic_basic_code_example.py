
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import os
import sys
from openai import OpenAI

# --- Configuration and Setup ---
# CRITICAL: The environment variable OPENAI_API_KEY must be set.

# 1. Initialize the OpenAI Client
# The client automatically handles API key retrieval from environment variables.
try:
    client = OpenAI()
except Exception as e:
    print(f"Initialization Error: Could not create OpenAI client.")
    print(f"Ensure 'openai' library is installed and API key is set. Details: {e}")
    sys.exit(1) # Exit immediately if initialization fails

# 2. Define the path to the audio file
# This path must point to an existing audio file (MP3, WAV, M4A, etc.)
AUDIO_FILE_PATH = "sample_earnings_snippet.mp3"

# 3. Robust File Existence Check
# We prevent runtime errors by ensuring the file is accessible.
if not os.path.exists(AUDIO_FILE_PATH):
    print(f"FATAL ERROR: Audio file not found at '{AUDIO_FILE_PATH}'.")
    print("ACTION REQUIRED: Please place a small audio file (under 25MB) with this exact name in the current directory.")
    sys.exit(1)

# 4. Open the audio file in binary read mode for secure upload
# The 'with' statement ensures the file resource is released immediately after use.
print(f"Attempting transcription for: {AUDIO_FILE_PATH}")
try:
    with open(AUDIO_FILE_PATH, "rb") as audio_file:
        
        # 5. Call the OpenAI API for transcription
        # The 'whisper-1' model is the standard, high-accuracy choice.
        transcript_response = client.audio.transcriptions.create(
            model="whisper-1",
            file=audio_file,
            response_format="text", # Requesting the simplest output format
            language="en"           # Optional: Specify language for potential speed/accuracy boost
        )
        
        # 6. Extract and display the transcription
        # The response object contains the final transcribed text.
        transcribed_text = transcript_response.text
        
        print("\n" + "="*50)
        print("WHISPER TRANSCRIPTION RESULT")
        print("="*50)
        print(transcribed_text)
        print("="*50)
        
        # 7. Post-processing: Basic word count for confirmation
        word_count = len(transcribed_text.split())
        print(f"\n[INFO] Total characters: {len(transcribed_text)}")
        print(f"[INFO] Total words transcribed: {word_count}")
        
except Exception as api_error:
    print(f"\n--- API TRANSACTION ERROR ---")
    print(f"A problem occurred during the API call (e.g., network, authentication, billing).")
    print(f"Details: {api_error}")
    sys.exit(1)


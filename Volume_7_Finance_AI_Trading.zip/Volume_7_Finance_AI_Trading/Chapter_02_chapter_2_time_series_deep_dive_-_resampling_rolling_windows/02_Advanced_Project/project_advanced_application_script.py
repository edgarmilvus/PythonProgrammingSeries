
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import numpy as np
import random

# --- 1. Configuration Constants ---
# Define the simulation parameters
START_TIME = pd.to_datetime('2023-10-01 09:30:00')
END_TIME = pd.to_datetime('2023-10-06 16:00:00')
TICK_COUNT = 60000  # Number of simulated transactions
INITIAL_PRICE = 150.00
RESAMPLE_PERIOD = '1H' # Target granularity: 1 Hour
EMA_WINDOW = 12      # Short-term EMA window (12 hours)
VOLATILITY_WINDOW = 20 # Volatility window (20 hours)

# --- 2. Data Simulation Function (Generating Irregular Tick Data) ---
def generate_tick_data(start, end, count, initial_price):
    """Generates a DataFrame of high-frequency, irregular tick data."""
    
    # Generate random timestamps between start and end
    time_range = (end - start).total_seconds()
    random_seconds = np.sort(np.random.uniform(0, time_range, count))
    timestamps = [start + pd.Timedelta(seconds=s) for s in random_seconds]
    
    # Simulate price movements (random walk with drift)
    price_changes = np.random.normal(0, 0.05, count)
    prices = initial_price + np.cumsum(price_changes)
    
    # Simulate volume (random integers)
    volumes = np.random.randint(10, 500, count)
    
    # Create the DataFrame, using timestamps as the index
    tick_df = pd.DataFrame({
        'Price': prices,
        'Volume': volumes
    }, index=timestamps)
    
    # Ensure index is properly localized (optional but good practice)
    tick_df.index.name = 'Timestamp'
    
    return tick_df

# --- 3. Core Processing Function: Resampling and Feature Engineering ---
def process_financial_data(tick_df, period, ema_span, vol_window):
    """
    Transforms raw tick data into OHLC bars and calculates rolling indicators.
    """
    
    print(f"Starting transformation of {len(tick_df)} ticks into {period} bars...")
    
    # A. OHLC Aggregation using Resampling
    # Define the custom aggregation dictionary for resample().agg()
    ohlc_agg = {
        'Price': 'ohlc',  # Generates Open, High, Low, Close
        'Volume': 'sum'   # Sums the volume over the resampling period
    }
    
    # Apply resampling and aggregation
    ohlc_df = tick_df.resample(period).agg(ohlc_agg)
    
    # Flatten the multi-level columns resulting from 'ohlc' aggregation
    ohlc_df.columns = ['Open', 'High', 'Low', 'Close', 'Volume']
    
    # Remove periods (bars) where no trades occurred (NaNs in Open/High/Low/Close)
    ohlc_df.dropna(subset=['Open'], inplace=True)
    
    # B. Rolling Window Calculations (Indicator Generation)
    
    # 1. Exponential Moving Average (EMA)
    # EMA uses the .ewm() method for exponentially weighted calculations
    ohlc_df['Short_EMA'] = (
        ohlc_df['Close']
        .ewm(span=ema_span, adjust=False)
        .mean()
    )
    
    # 2. Historical Volatility (Annualized Standard Deviation of Log Returns)
    
    # Calculate Log Returns: ln(P_t / P_{t-1})
    ohlc_df['Log_Returns'] = np.log(ohlc_df['Close'] / ohlc_df['Close'].shift(1))
    
    # Calculate Rolling Standard Deviation (Vol) over the specified window
    # We multiply by sqrt(252) to annualize the volatility (assuming 252 trading days)
    ohlc_df['Annualized_Volatility'] = (
        ohlc_df['Log_Returns']
        .rolling(window=vol_window)
        .std()
        * np.sqrt(252)
    )
    
    # C. Final Data Cleanup
    # Drop the temporary calculation column (Log_Returns)
    ohlc_df.drop(columns=['Log_Returns'], inplace=True)
    
    # Fill remaining NaNs (e.g., initial volatility values) with 0 or the first valid value
    ohlc_df.fillna(method='bfill', inplace=True) 
    
    return ohlc_df

# --- 4. Execution ---
if __name__ == '__main__':
    # Generate the raw tick data
    raw_ticks = generate_tick_data(START_TIME, END_TIME, TICK_COUNT, INITIAL_PRICE)
    print(f"Generated {len(raw_ticks)} raw ticks.")
    print("-" * 50)
    
    # Process the data
    processed_bars = process_financial_data(
        raw_ticks, 
        RESAMPLE_PERIOD, 
        EMA_WINDOW, 
        VOLATILITY_WINDOW
    )
    
    # Display results
    print("-" * 50)
    print(f"Processed into {len(processed_bars)} {RESAMPLE_PERIOD} bars.")
    print("\nFirst 5 Processed Bars:")
    print(processed_bars.head())
    
    print("\nData Types and Memory Usage:")
    processed_bars.info()


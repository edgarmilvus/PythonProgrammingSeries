
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# --- 1. Data Generation: Synthetic Minute-Level Price Data ---
# We simulate 5 hours of continuous 1-minute data for a hypothetical asset.
start_time = datetime(2023, 10, 26, 9, 0, 0)
num_minutes = 300 # 5 hours * 60 minutes/hour = 300 data points
# Create a list of timestamps, increasing by one minute each time
time_index = [start_time + timedelta(minutes=i) for i in range(num_minutes)]

# Generate synthetic price data simulating a random walk (realistic price movement)
np.random.seed(42) # Ensures the generated data is identical every time the script runs
base_price = 100.0
# Cumulative sum of small random normal steps creates a trended series
price_changes = np.random.randn(num_minutes).cumsum() * 0.05
prices = base_price + price_changes

# Create the initial DataFrame with the DatetimeIndex
minute_data = pd.DataFrame(
    {'Price': prices},
    index=time_index
)
minute_data.index.name = 'Timestamp'

print("--- Raw Minute Data Sample (First 5) ---")
print(minute_data.head())
print("-" * 50)

# --- 2. Downsampling and OHLC Aggregation (1-Minute to 1-Hour) ---
# The resample() method is used exclusively for time-based grouping.
# 'H' specifies an Hourly frequency (downsampling).
hourly_ohlc = minute_data['Price'].resample('H').agg({
    'Open': 'first',   # The price at the start of the hour
    'High': 'max',     # The highest price during the hour
    'Low': 'min',      # The lowest price during the hour
    'Close': 'last'    # The price at the end of the hour
}).dropna() # Remove any hours that did not contain a full 60 minutes of data

print("\n--- Hourly OHLC Data Sample (Aggregated) ---")
print(hourly_ohlc)
print("-" * 50)


# --- 3. Calculating a Rolling Window (Simple Moving Average) ---
# We calculate the 3-period Simple Moving Average (SMA) on the 'Close' price.
window_size = 3
# .rolling(window=3) creates a moving window object.
# .mean() calculates the average across that window for each step.
hourly_ohlc['SMA_3'] = hourly_ohlc['Close'].rolling(window=window_size).mean()

print("\n--- Hourly OHLC Data with 3-Period SMA ---")
print(hourly_ohlc)

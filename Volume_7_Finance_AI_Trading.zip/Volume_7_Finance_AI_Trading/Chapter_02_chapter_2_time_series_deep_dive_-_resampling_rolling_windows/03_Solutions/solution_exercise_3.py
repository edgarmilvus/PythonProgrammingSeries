
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# 1. Data Setup
np.random.seed(42)
dates = pd.date_range(start='2023-01-01', periods=252, freq='B') # Business days

# Simulate ETF A (Predictor Asset)
etf_a_close = 100 + np.cumsum(np.random.normal(0, 0.5, len(dates)))
etf_a_volume = np.random.randint(100000, 500000, len(dates))
ETF_A_D1 = pd.DataFrame({'Close': etf_a_close, 'Volume': etf_a_volume}, index=dates)

# Simulate Stock B (Target Asset)
stock_b_close = 50 + np.cumsum(np.random.normal(0, 0.8, len(dates)))
Stock_B_D1 = pd.DataFrame({'Close': stock_b_close, 'Volume': stock_b_close}, index=dates)

# 2. Feature Generation on ETF A
ETF_A_D1['ETF_A_Vol_MA10'] = ETF_A_D1['Volume'].rolling(window=10).mean()
ETF_A_D1['ETF_A_Price_Vol5'] = ETF_A_D1['Close'].rolling(window=5).std()

etf_features = ETF_A_D1[['ETF_A_Vol_MA10', 'ETF_A_Price_Vol5']]

# 3. Data Merging
df_merged = Stock_B_D1.copy()
df_merged = df_merged.merge(etf_features, left_index=True, right_index=True, how='left')

# 4. Lagging for Prediction (Bias Mitigation)
# Shift predictor features backward by 1 day. 
# The feature calculated on T is used as input for the prediction decision made at T.
df_merged['L1_ETF_A_Vol_MA10'] = df_merged['ETF_A_Vol_MA10'].shift(1)
df_merged['L1_ETF_A_Price_Vol5'] = df_merged['ETF_A_Price_Vol5'].shift(1)
df_merged = df_merged.drop(columns=['ETF_A_Vol_MA10', 'ETF_A_Price_Vol5']) # Remove T features

# 5. Target Variable Creation
# Calculate the return for the next day (T+1 return). 
# Shift forward by -1 to align the T+1 return with the T row (where the prediction occurs).
df_merged['Next_Day_Return'] = df_merged['Close'].pct_change().shift(-1)

# 6. Verification
print(df_merged[['Close', 'L1_ETF_A_Vol_MA10', 'L1_ETF_A_Price_Vol5', 'Next_Day_Return']].head(10))

"""
Instructor's Explanation of Bias Mitigation:

Look-ahead bias is prevented by ensuring the model only uses features available *before* the predicted event.

1. Predictor Lagging (Backward Shift):
   The features L1_ETF_A_Vol_MA10 and L1_ETF_A_Price_Vol5 are calculated using data up to day T-1 (due to the .shift(1)). This means that when the model evaluates row T, it is using information that was fully realized and closed on the previous day, T-1, ensuring causality.

2. Target Alignment (Forward Shift):
   The target variable, Next_Day_Return, is calculated as the return from T to T+1, and then shifted *up* using .shift(-1) so that this T+1 return aligns with the T row.

Result: For any given row (e.g., indexed T), the model uses features based on T-1 data to predict the outcome that will occur between T and T+1. This strict chronological separation validates the backtesting process.
"""

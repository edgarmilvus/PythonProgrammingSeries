
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Assuming df_ohlc_h4 from Exercise 1 is available
df_features = df_ohlc_h4.copy()

# 1. Simple Momentum (Lagging Indicator)
# SMA is a lagging indicator because it weights all 20 periods equally, 
# making it slow to react to new price information.
df_features['SMA_20'] = df_features['Close'].rolling(window=20).mean()

# 2. Exponential Momentum (Responsive Indicator)
# EMA applies exponentially decreasing weights, giving more importance to recent data.
# adjust=False ensures the traditional smoothing factor calculation.
df_features['EMA_10'] = df_features['Close'].ewm(span=10, adjust=False).mean()

# 3. Rolling Volatility (Risk Metric)
# Standard deviation measures the dispersion of price over the window.
df_features['Vol_40'] = df_features['Close'].rolling(window=40).std()

# 4. Feature Standardization (Relative Strength)
df_features['Relative_Strength_EMA'] = ((df_features['Close'] - df_features['EMA_10']) / df_features['Close']) * 100

# 5. Handling Initial Data
print("First 50 rows showing initial NaN values:")
print(df_features[['Close', 'SMA_20', 'EMA_10', 'Vol_40', 'Relative_Strength_EMA']].head(50))

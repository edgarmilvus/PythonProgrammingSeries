
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# 1. Data Setup
np.random.seed(42)
start_time = pd.to_datetime('2023-11-15 09:30:00').tz_localize('America/New_York')
end_time = start_time + timedelta(hours=4)

# Create sparse, non-uniform timestamps
time_indices = [
    start_time + timedelta(minutes=1, seconds=30),
    start_time + timedelta(minutes=2),
    start_time + timedelta(minutes=5),
    start_time + timedelta(minutes=7),
    start_time + timedelta(minutes=8),
    # Trade at T+10 min (start of 12-minute gap)
    start_time + timedelta(minutes=10), 
    # Next trade at T+22 min (end of 12-minute gap)
    start_time + timedelta(minutes=22, seconds=15), 
    start_time + timedelta(minutes=25),
    start_time + timedelta(minutes=30),
    # Trade at T+34 min (start of 10-minute gap)
    start_time + timedelta(minutes=34, seconds=50), 
    start_time + timedelta(minutes=45), # End of 10-minute gap
]

prices_sparse = 10.0 + np.cumsum(np.random.normal(0, 0.05, len(time_indices)))
df_sparse = pd.DataFrame({'Price': prices_sparse}, index=pd.DatetimeIndex(time_indices).sort_values())

# 2. Upsampling and Initial Fill
# Resample to 1-minute frequency (1T), taking the last price observed in that minute
df_1min = df_sparse.resample('1T', origin='start').last()
# Reindex to ensure a full 4-hour grid, filling in missing minutes with NaN
full_index = pd.date_range(start=start_time, end=end_time, freq='1T', tz='America/New_York')
df_1min = df_1min.reindex(full_index).dropna(how='all')


# 4. Conditional Forward Fill Implementation
def conditional_ffill(df, max_minutes):
    """Applies FFILL only up to a maximum time gap."""
    
    # 1. Identify the index of the last valid (non-NaN) observation for each row
    # We use ffill on the index series where 'Price' is not NaN
    last_valid_index = df.index.to_series().mask(df['Price'].isna()).ffill()
    
    # 2. Calculate the time elapsed since the last valid observation
    time_elapsed = df.index - last_valid_index
    
    # 3. Define the maximum allowed timedelta
    max_timedelta = timedelta(minutes=max_minutes)
    
    # 4. Apply FFILL to the entire series
    filled_series = df['Price'].ffill()
    
    # 5. Apply the mask: where the time elapsed exceeds the limit, revert to NaN
    mask_too_long = (time_elapsed > max_timedelta)
    
    df_result = df.copy()
    df_result['Price_Filled'] = filled_series.mask(mask_too_long)
    
    return df_result.rename(columns={'Price': 'Original_Price'})

# 3, 5. Defining the Constraint and Running Scenarios
MAX_FILL_WINDOW_5 = 5
MAX_FILL_WINDOW_15 = 15

df_filled_5min = conditional_ffill(df_1min.copy(), MAX_FILL_WINDOW_5)
df_filled_15min = conditional_ffill(df_1min.copy(), MAX_FILL_WINDOW_15)

# 6. Verification (Focusing on the 12-minute gap: 09:40 to 09:52)
verification_start = start_time + timedelta(minutes=8)
verification_end = start_time + timedelta(minutes=24)

print(f"--- FFILL with MAX_FILL_WINDOW = {MAX_FILL_WINDOW_5} Minutes ---")
print(df_filled_5min.loc[verification_start:verification_end])

print(f"\n--- FFILL with MAX_FILL_WINDOW = {MAX_FILL_WINDOW_15} Minutes ---")
print(df_filled_15min.loc[verification_start:verification_end])

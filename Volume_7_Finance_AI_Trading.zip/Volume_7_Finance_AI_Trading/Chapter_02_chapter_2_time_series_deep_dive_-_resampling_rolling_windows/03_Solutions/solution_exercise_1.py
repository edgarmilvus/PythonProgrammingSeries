
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import numpy as np
from datetime import timedelta

# --- 1. Data Simulation and Indexing ---
start_date = pd.to_datetime('2023-10-01 00:00:00')
end_date = start_date + timedelta(days=30)
num_ticks = 500000 
np.random.seed(42)

# Create non-uniform timestamps with millisecond precision
time_deltas = np.cumsum(np.random.randint(1, 5000, size=num_ticks)) * np.timedelta64(1, 'ms')
timestamps = start_date + time_deltas
timestamps = timestamps[timestamps < end_date] 
num_valid_ticks = len(timestamps)

# Create price and volume data
initial_price = 1.0750
price_changes = np.random.normal(0, 0.00005, num_valid_ticks).cumsum()
prices = initial_price + price_changes
volumes = np.random.randint(10, 500, num_valid_ticks)

df_ticks = pd.DataFrame({
    'Price': prices,
    'Trade_Volume': volumes
}, index=timestamps)

# Localize the index to UTC
df_ticks = df_ticks.tz_localize('UTC')

# --- 2, 3, 4, 5. Resampling and OHLC Aggregation ---
# Define the aggregation rules:
# Price: first (Open), max (High), min (Low), last (Close)
# Trade_Volume: sum
ohlc_volume_rules = {
    'Price': ['first', 'max', 'min', 'last'],
    'Trade_Volume': 'sum'
}

# Resample to 4-hour bars (4H). 
# label='left' ensures the resulting index timestamp is the start of the period.
df_ohlc_h4 = df_ticks.resample('4H', label='left').agg(ohlc_volume_rules)

# Flatten the multi-index columns
df_ohlc_h4.columns = ['Open', 'High', 'Low', 'Close', 'Volume']

# Clean up any bars where no trades occurred (NaNs)
df_ohlc_h4 = df_ohlc_h4.dropna()

# --- 6. Data Integrity Check ---
print("First 5 H4 Bars:")
print(df_ohlc_h4.head())
print("\nLast 5 H4 Bars:")
print(df_ohlc_h4.tail())

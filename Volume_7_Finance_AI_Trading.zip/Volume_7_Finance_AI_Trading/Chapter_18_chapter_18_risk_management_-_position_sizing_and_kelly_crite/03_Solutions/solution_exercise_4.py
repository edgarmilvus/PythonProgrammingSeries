
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Reuse the core Kelly calculation logic from Exercise 1
def calculate_kelly_fraction(win_rate: float, payoff_ratio: float) -> float:
    """Calculates the optimal Kelly fraction (f*) and validates the strategy's edge."""
    if not (0.0 <= win_rate <= 1.0) or payoff_ratio <= 0.0:
        return -1.0 # Use -1.0 to signal invalid input/state internally
    
    w_min = 1.0 / (1.0 + payoff_ratio)

    if win_rate <= w_min:
        return 0.0

    f_star = win_rate - ((1.0 - win_rate) / payoff_ratio)
    return max(0.0, f_star)

def interactive_kelly_tester():
    """Runs the interactive console for Kelly sensitivity analysis."""
    print("--- Kelly Criterion Sensitivity Tester ---")
    print("Enter 'quit' to exit.")
    
    while True:
        try:
            # 1. Input Handling
            user_input = input("\nEnter Win Rate (W, e.g., 0.55): ").strip().lower()
            if user_input == 'quit':
                break
            win_rate = float(user_input)

            user_input = input("Enter Payoff Ratio (R, e.g., 1.5): ").strip().lower()
            if user_input == 'quit':
                break
            payoff_ratio = float(user_input)
            
            # 2. Calculation
            f_star = calculate_kelly_fraction(win_rate, payoff_ratio)
            
            # 3. Output
            if f_star == -1.0:
                print(">>> ERROR: Invalid input. Win Rate must be 0-1, Payoff Ratio must be > 0.")
                continue
            
            print("\n--- Results ---")
            print(f"Input W: {win_rate:.2f}, Input R: {payoff_ratio:.2f}")

            if f_star > 0.0:
                half_kelly = f_star * 0.5
                print(f"Optimal Kelly Fraction (f*): {f_star:.4f} ({f_star:.2%})")
                print(f"Recommended Half-Kelly (0.5*f*): {half_kelly:.4f} ({half_kelly:.2%})")
            else:
                # Calculate W_min for context if R is valid
                w_min = 1.0 / (1.0 + payoff_ratio) if payoff_ratio > 0 else float('inf')
                print(f"*** WARNING: No Positive Edge Detected (W required: {w_min:.2f}). f* = 0.0.")
                
        except ValueError:
            print(">>> ERROR: Please enter valid numeric values.")
        except Exception as e:
            print(f">>> An unexpected error occurred: {e}")
            
    print("Exiting Kelly Tester.")

if __name__ == '__main__':
    interactive_kelly_tester()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import random
from typing import List, Dict, Tuple

# Configuration
ROLLING_WINDOW_SIZE = 50
INITIAL_CAPITAL = 100000.0
FRACTIONAL_KELLY_MULTIPLIER = 0.4
NUM_SIMULATED_TRADES = 200

# --- Helper Functions (Reusing Logic from E1 and E2) ---

def calculate_kelly_fraction(win_rate: float, payoff_ratio: float) -> float:
    """Calculates f* with edge validation."""
    if not (0.0 <= win_rate <= 1.0) or payoff_ratio <= 0.0:
        return 0.0 # Treat invalid inputs as zero edge
    
    w_min = 1.0 / (1.0 + payoff_ratio)
    
    if win_rate <= w_min:
        return 0.0
    
    f_star = win_rate - ((1.0 - win_rate) / payoff_ratio)
    return max(0.0, f_star)

def calculate_metrics_on_window(window_data: List[Dict]) -> Tuple[float, float]:
    """Calculates W and R from a list of trade PnLs."""
    if not window_data:
        return 0.0, 0.0

    wins = [t['pnl'] for t in window_data if t['pnl'] > 0]
    losses = [t['pnl'] for t in window_data if t['pnl'] <= 0]
    
    win_rate = len(wins) / len(window_data)
    
    # Calculate Average Win and Average Loss (absolute value)
    avg_win = sum(wins) / len(wins) if wins else 0.0
    avg_loss = abs(sum(losses) / len(losses)) if losses else 0.0
    
    # Calculate Payoff Ratio (R)
    if avg_loss == 0.0:
        # If there are no losses, R is effectively infinite (or very high)
        payoff_ratio = 1000.0
    else:
        payoff_ratio = avg_win / avg_loss
        
    return win_rate, payoff_ratio

# --- Simulation Setup ---

# Simulate historical trade data (using a consistent risk_per_unit for simplicity)
# PnL is randomized based on a hypothetical strategy (W=55%, R=1.2)
def generate_simulated_trades(num_trades):
    trades = []
    base_win_rate = 0.55
    base_payoff_ratio = 1.2
    
    for _ in range(num_trades):
        risk_per_unit = round(random.uniform(0.5, 1.5), 2) # Variable stop loss distance
        
        if random.random() < base_win_rate:
            pnl = random.uniform(risk_per_unit * base_payoff_ratio * 0.8, risk_per_unit * base_payoff_ratio * 1.2)
        else:
            pnl = random.uniform(-risk_per_unit * 1.2, -risk_per_unit * 0.8)
        
        trades.append({'pnl': pnl, 'risk_per_unit': risk_per_unit})
    return trades

backtest_results = generate_simulated_trades(NUM_SIMULATED_TRADES)
analysis_results = []
current_capital = INITIAL_CAPITAL

# --- Dynamic Sizing Simulation ---

for i in range(NUM_SIMULATED_TRADES):
    trade_data = backtest_results[i]
    
    # 1. Define the Rolling Window (trades i-N to i-1)
    start_index = max(0, i - ROLLING_WINDOW_SIZE)
    window = backtest_results[start_index:i]
    
    # Initialize metrics for the current trade
    current_w = 0.0
    current_r = 0.0
    f_star = 0.0
    position_size = 0
    risk_dollars = 0.0

    if len(window) < ROLLING_WINDOW_SIZE:
        # Stabilization Period: Use a fixed conservative risk (e.g., 0.5% risk)
        f_star = 0.01  # Conservative default Kelly fraction
        
    else:
        # 2. Metric Calculation based on the Window
        current_w, current_r = calculate_metrics_on_window(window)
        
        # 3. Kelly Sizing
        f_star = calculate_kelly_fraction(current_w, current_r)

    # 4. Position Sizing (Applied to current capital)
    f_adj = f_star * FRACTIONAL_KELLY_MULTIPLIER
    risk_dollars = current_capital * f_adj
    
    # Calculate position size for the current trade
    if trade_data['risk_per_unit'] > 0:
        position_size = int(risk_dollars / trade_data['risk_per_unit'])
    
    # Store results for analysis (Note: PnL calculation is simplified here,
    # assuming the PnL was realized based on the risk_per_unit * position_size)
    
    analysis_results.append({
        'trade_index': i + 1,
        'window_size': len(window),
        'win_rate': current_w,
        'payoff_ratio': current_r,
        'kelly_fraction': f_star,
        'position_size': position_size
    })
    
    # Update capital based on the actual PnL of the trade (for the next iteration's sizing)
    current_capital += trade_data['pnl']

# --- Output Summary ---
print(f"--- Dynamic Kelly Sizing Analysis (N={ROLLING_WINDOW_SIZE}) ---")
print(f"Trade 1 (Stabilization): {analysis_results[0]}")
print(f"Trade {ROLLING_WINDOW_SIZE} (Stabilization End): {analysis_results[ROLLING_WINDOW_SIZE - 1]}")
print(f"Trade {ROLLING_WINDOW_SIZE + 1} (Dynamic Start): {analysis_results[ROLLING_WINDOW_SIZE]}")
print(f"Final Capital: ${current_capital:,.2f}")

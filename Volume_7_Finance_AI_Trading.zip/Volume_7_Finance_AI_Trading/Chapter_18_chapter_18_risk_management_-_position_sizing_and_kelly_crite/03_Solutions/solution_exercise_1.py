
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import math

def calculate_kelly_fraction(win_rate: float, payoff_ratio: float) -> float:
    """
    Calculates the optimal Kelly fraction (f*) and validates the strategy's edge.
    """
    # 1. Input Validation
    if not (0.0 <= win_rate <= 1.0):
        raise ValueError("Win rate must be between 0.0 and 1.0.")
    if payoff_ratio <= 0.0:
        raise ValueError("Payoff ratio must be positive (R > 0).")

    # 2. Edge Check
    # Calculate the minimum win rate required to break even: W_min = 1 / (1 + R)
    w_min = 1.0 / (1.0 + payoff_ratio)

    if win_rate <= w_min:
        # Strategy has zero or negative expected value (negative edge)
        return 0.0

    # 3. Optimal Fraction Calculation (f* = W - (1 - W) / R)
    f_star = win_rate - ((1.0 - win_rate) / payoff_ratio)

    # Ensure f_star is not negative due to floating point inaccuracies, though
    # the edge check above should prevent this if W > W_min.
    return max(0.0, f_star)

# --- Test Cases ---
# 1. Positive Edge (W=60%, R=1.5): W_min = 1/(1+1.5) = 0.4. 0.6 > 0.4.
f1 = calculate_kelly_fraction(0.6, 1.5)
# f* = 0.6 - (0.4 / 1.5) = 0.6 - 0.2667 = 0.3333
print(f"Test 1 (Positive Edge): {f1:.4f}")

# 2. Negative Edge (W=30%, R=1.0): W_min = 1/(1+1.0) = 0.5. 0.3 <= 0.5.
f2 = calculate_kelly_fraction(0.3, 1.0)
print(f"Test 2 (Negative Edge): {f2:.4f}")

# 3. High R, Low W (W=40%, R=2.0): W_min = 1/(1+2) = 0.333. 0.4 > 0.333.
# f* = 0.4 - (0.6 / 2.0) = 0.4 - 0.3 = 0.1
f3 = calculate_kelly_fraction(0.4, 2.0)
print(f"Test 3 (Marginal Edge): {f3:.4f}")

# Example of expected failure (uncomment to test ValueError)
# try:
#     calculate_kelly_fraction(1.2, 1.0)
# except ValueError as e:
#     print(f"Error caught: {e}")

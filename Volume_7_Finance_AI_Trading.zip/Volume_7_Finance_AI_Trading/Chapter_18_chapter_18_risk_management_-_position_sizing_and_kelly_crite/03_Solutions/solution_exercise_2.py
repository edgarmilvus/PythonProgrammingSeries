
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Configuration
TOTAL_CAPITAL = 100000.0
FRACTIONAL_MULTIPLIER = 0.5  # Half-Kelly
F_STAR_EXAMPLE = 0.12        # Example optimal Kelly fraction (12%)
STOP_LOSS_DISTANCE = 0.50    # Stop loss distance per share/unit ($0.50)

def determine_risk_amount(f_star: float, multiplier: float, capital: float) -> float:
    """
    Calculates the maximum dollar amount to risk based on Fractional Kelly sizing.
    """
    # 1. Calculate Adjusted Kelly Fraction
    f_adj = f_star * multiplier

    # Safety check: Risk should never exceed 100% of capital
    if f_adj > 1.0:
        f_adj = 1.0

    # 2. Calculate Risk Amount: Risk Amount = Total Capital * f_adj
    risk_amount = capital * f_adj
    
    return risk_amount

def calculate_position_size(risk_amount: float, stop_loss_distance: float) -> int:
    """
    Calculates the maximum number of units/shares to purchase.
    """
    if stop_loss_distance <= 0:
        raise ValueError("Stop loss distance must be positive.")
        
    # Position Size = Risk Amount / Stop Loss Distance
    position_size_float = risk_amount / stop_loss_distance
    
    # Truncate to an integer (cannot buy partial shares)
    position_size = int(position_size_float)
    
    return position_size

# --- Execution Flow ---
# 1. Determine the dollar amount to risk
risk_dollars = determine_risk_amount(F_STAR_EXAMPLE, FRACTIONAL_MULTIPLIER, TOTAL_CAPITAL)

# 2. Calculate the position size
units = calculate_position_size(risk_dollars, STOP_LOSS_DISTANCE)

print(f"Initial Capital: ${TOTAL_CAPITAL:,.2f}")
print(f"Optimal Kelly (f*): {F_STAR_EXAMPLE:.2%}")
print(f"Fractional Multiplier: {FRACTIONAL_MULTIPLIER:.2f}")
print(f"Adjusted Kelly Fraction: {F_STAR_EXAMPLE * FRACTIONAL_MULTIPLIER:.2%}")
print(f"Calculated Dollar Risk Amount: ${risk_dollars:,.2f}")
print(f"Stop Loss Distance per Unit: ${STOP_LOSS_DISTANCE:.2f}")
print(f"Maximum Position Size (Units): {units:,}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import random

# --- Simulation Parameters ---
INITIAL_CAPITAL = 100000.0
WIN_RATE = 0.6
PAYOFF_RATIO = 1.5
NUM_TRADES = 1000

# Risk Definitions
FIXED_RISK_PERCENTAGE = 0.02  # Fixed 2% risk per trade
KELLY_MULTIPLIER = 0.5       # Half-Kelly

# --- Helper Functions ---

def calculate_kelly_fraction(W, R):
    """Calculates f* (simplified for known good inputs)."""
    return W - ((1.0 - W) / R)

def simulate_trade(W, R, risk_amount):
    """
    Simulates a trade outcome (Win/Loss) and returns the PnL.
    Risk amount is the maximum dollar amount risked on the trade.
    """
    if random.random() < W:
        # Win: Profit is R times the risk amount
        pnl = risk_amount * R
    else:
        # Loss: Loss is 1 times the risk amount
        pnl = -risk_amount
    return pnl

def run_simulation(sizing_method: str, initial_capital: float, num_trades: int, kelly_f_star: float):
    """Runs the simulation for a given sizing method."""
    capital = initial_capital
    peak_capital = initial_capital
    max_drawdown = 0.0
    
    for _ in range(num_trades):
        # 1. Determine Risk Amount based on sizing method
        if sizing_method == 'Fixed':
            risk_fraction = FIXED_RISK_PERCENTAGE
        elif sizing_method == 'Kelly':
            risk_fraction = kelly_f_star * KELLY_MULTIPLIER
        else:
            raise ValueError("Invalid sizing method")
            
        risk_dollars = capital * risk_fraction
        
        # 2. Simulate Trade and Update Capital
        pnl = simulate_trade(WIN_RATE, PAYOFF_RATIO, risk_dollars)
        capital += pnl
        
        # 3. Track Drawdown
        if capital > peak_capital:
            peak_capital = capital
        
        current_drawdown = (peak_capital - capital) / peak_capital
        if current_drawdown > max_drawdown:
            max_drawdown = current_drawdown
            
        # Safety check: If capital is zero or negative, stop simulation
        if capital <= 0:
            capital = 0.0
            break
            
    return capital, max_drawdown

# --- Main Execution ---

# Calculate the theoretical optimal Kelly fraction
kelly_f_star = calculate_kelly_fraction(WIN_RATE, PAYOFF_RATIO)
kelly_risk_fraction = kelly_f_star * KELLY_MULTIPLIER

# Run simulations
final_capital_fixed, mdd_fixed = run_simulation('Fixed', INITIAL_CAPITAL, NUM_TRADES, kelly_f_star)
final_capital_kelly, mdd_kelly = run_simulation('Kelly', INITIAL_CAPITAL, NUM_TRADES, kelly_f_star)

# --- Output Analysis ---
print(f"--- Comparative Drawdown Simulation ({NUM_TRADES} Trades) ---")
print(f"Strategy Edge: W={WIN_RATE:.2f}, R={PAYOFF_RATIO:.2f}. Optimal Kelly (f*): {kelly_f_star:.2%}")
print("-" * 40)

print(f"1. Fixed Sizing (Risking {FIXED_RISK_PERCENTAGE:.2%})")
print(f"   Final Capital: ${final_capital_fixed:,.2f}")
print(f"   Maximum Drawdown: {mdd_fixed:.2%}")
print("-" * 40)

print(f"2. Fractional Kelly Sizing (Risking {kelly_risk_fraction:.2%})")
print(f"   Final Capital: ${final_capital_kelly:,.2f}")
print(f"   Maximum Drawdown: {mdd_kelly:.2%}")
print("-" * 40)

if final_capital_kelly > final_capital_fixed:
    print("Conclusion: Fractional Kelly achieved superior geometric growth.")
else:
    print("Conclusion: Fixed sizing was marginally better in this specific simulation run.")

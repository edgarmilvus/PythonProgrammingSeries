
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import math

# --- 1. Define Historical Trade Statistics ---
# These values are derived from rigorous backtesting or historical analysis.
WIN_RATE = 0.55     # W: Probability of a winning trade (55%)
PAYOFF_RATIO = 1.25 # R: Payoff Ratio (Average Profit / Average Loss = 1.25:1)

# --- 2. Implement the Kelly Criterion Formula ---

def calculate_kelly_fraction(win_rate: float, payoff_ratio: float) -> float:
    """
    Calculates the optimal capital fraction (f*) to risk using the Kelly Criterion.
    Formula: f* = (W * R - (1 - W)) / R
    
    Args:
        win_rate (float): Probability of a win (0.0 to 1.0).
        payoff_ratio (float): Ratio of average gain to average loss.
        
    Returns:
        float: The optimal fraction of capital to risk.
    """
    
    # Check for a positive payoff ratio to avoid division by zero
    if payoff_ratio <= 0:
        # If the payoff ratio is non-positive, the strategy is fundamentally flawed.
        return 0.0
        
    # Calculate the probability of losing (1 - W)
    loss_rate = 1.0 - win_rate
    
    # Calculate the numerator: This represents the strategy's expected edge (E)
    # E = (Probability of Win * Payoff Ratio) - (Probability of Loss)
    numerator = (win_rate * payoff_ratio) - loss_rate
    
    # The denominator is simply the payoff ratio
    denominator = payoff_ratio
    
    # Calculate the raw Kelly fraction (f*)
    kelly_f = numerator / denominator
    
    return kelly_f

# --- 3. Execute Calculation and Interpret Result ---

optimal_f = calculate_kelly_fraction(WIN_RATE, PAYOFF_RATIO)

# The Kelly Criterion can yield a negative result if the strategy has a negative edge.
# In such cases, the optimal position size is zero.
final_position_size = max(0.0, optimal_f)

# Display results
print(f"--- Strategy Performance Metrics ---")
print(f"Win Rate (W): {WIN_RATE:.2f}")
print(f"Payoff Ratio (R): {PAYOFF_RATIO:.2f}")
print("-" * 30)

print(f"1. Calculated Raw Kelly Fraction (f*): {optimal_f:.4f}")
print(f"2. Recommended Capital Fraction to Risk (Adjusted): {final_position_size:.2%}")
print(f"\nInterpretation: Based on Full Kelly, {final_position_size:.2%} of total capital should be risked on a single trade.")

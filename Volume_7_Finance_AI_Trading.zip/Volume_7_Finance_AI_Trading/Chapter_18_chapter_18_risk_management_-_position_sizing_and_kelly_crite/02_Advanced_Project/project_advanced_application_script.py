
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np

# --- 1. CONFIGURATION AND DATA SIMULATION ---
INITIAL_CAPITAL = 100_000.0
# Using Half-Kelly (0.5) is a standard practice to reduce volatility 
# and account for estimation errors in P and B.
KELLY_MODIFIER = 0.5 

# Historical backtest results (P&L as a percentage of capital risked per trade).
# Example: 0.15 means the trade won 15% of the capital risked.
HISTORICAL_RETURNS = np.array([
    0.15, -0.08, 0.20, 0.05, -0.10, 0.12, 0.18, -0.07, 0.09, 0.22,
    -0.09, 0.11, 0.14, -0.06, 0.16, 0.08, 0.19, -0.11, 0.13, 0.07
])

# --- 2. KELLY INPUT CALCULATION ---
def calculate_kelly_inputs(returns: np.ndarray) -> tuple[float, float]:
    """Calculates the strategy's win rate (P) and the payoff ratio (B) 
    from historical trade returns."""
    
    wins = returns[returns > 0]
    losses = returns[returns <= 0]
    
    # P: Probability of winning (Win Rate)
    P = len(wins) / len(returns)
    
    # B: Payoff Ratio (Average Gain / Average Loss Magnitude)
    if len(losses) == 0:
        B = np.inf
    else:
        # Calculate the average magnitude of wins and losses
        avg_win = np.mean(wins) if len(wins) > 0 else 0
        avg_loss_magnitude = np.mean(np.abs(losses))
        B = avg_win / avg_loss_magnitude if avg_loss_magnitude != 0 else np.inf
        
    return P, B

# --- 3. FULL KELLY CRITERION CALCULATION ---
def calculate_full_kelly_fraction(P: float, B: float) -> float:
    """Calculates the optimal full Kelly fraction (f) using the formula: f = P - (1-P)/B."""
    
    if B <= 0 or B == np.inf:
        return 0.0 # Strategy has no positive expectation or B is undefined
    
    try:
        # The core Kelly formula
        f = P - ((1 - P) / B)
    except ZeroDivisionError:
        return 0.0
    
    # Kelly fraction must be positive; if negative, the strategy should not be traded
    return max(0.0, f)

# --- 4. DYNAMIC POSITION SIZING FUNCTION ---
def get_kelly_position_size(
    current_capital: float, 
    kelly_fraction: float, 
    risk_per_unit: float
) -> tuple[float, float]:
    """
    Determines the dollar amount to risk and the resulting position units 
    based on the current capital and the Kelly fraction.
    """
    
    # 1. Calculate the maximum capital to risk (the Kelly amount)
    capital_to_risk = current_capital * kelly_fraction
    
    # 2. Determine the number of units (e.g., shares or contracts)
    # Units = Total Risk Budget / Stop Loss Distance (Risk per Unit)
    # This calculation ensures that if the stop loss is hit, the loss equals 'capital_to_risk'.
    units = capital_to_risk / risk_per_unit
    
    return capital_to_risk, units

# --- 5. EXECUTION AND SIMULATION ---

# 5a. Calibration Phase
P, B = calculate_kelly_inputs(HISTORICAL_RETURNS)
f_full = calculate_full_kelly_fraction(P, B)

# Apply the fractional modifier
f_adjusted = f_full * KELLY_MODIFIER 

print(f"--- Kelly Criterion Calibration ---")
print(f"Total Historical Trades: {len(HISTORICAL_RETURNS)}")
print(f"Historical Win Rate (P): {P:.2f}")
print(f"Historical Payoff Ratio (B): {B:.2f}")
print(f"Optimal Full Kelly Fraction (f_full): {f_full:.4f} (Risk {f_full*100:.2f}% of capital)")
print(f"Applied Adjusted Kelly Fraction (f_adj): {f_adjusted:.4f} (Half-Kelly)")
print("-" * 60)

# 5b. Dynamic Execution Phase
current_capital = INITIAL_CAPITAL

# Assume a fixed stop-loss distance (e.g., $1.00 per share/unit)
FIXED_RISK_PER_UNIT = 1.0 

# Simulated outcomes for the next 5 trades (multipliers based on FIXED_RISK_PER_UNIT)
# 1.5 means a win of 1.5 * $1.00 per unit; -1.0 means a loss of 1.0 * $1.00 per unit
SIMULATED_OUTCOMES = [1.5, -1.0, 2.0, -1.0, 3.0] 

for i, outcome_multiplier in enumerate(SIMULATED_OUTCOMES):
    # Calculate sizing based on the current capital (dynamic sizing)
    risk_amount, units = get_kelly_position_size(
        current_capital, 
        f_adjusted, 
        FIXED_RISK_PER_UNIT
    )

    # Calculate P&L: Units * Outcome Multiplier * Risk per Unit
    trade_pnl = units * outcome_multiplier * FIXED_RISK_PER_UNIT
    
    # Update capital (the key to dynamic risk management)
    current_capital += trade_pnl
    
    print(f"| Trade {i+1} |")
    print(f"  Start Capital: ${current_capital - trade_pnl:,.2f}")
    print(f"  Risk Budget: ${risk_amount:,.2f} ({f_adjusted*100:.2f}% of capital)")
    print(f"  Units Sized: {units:,.2f}")
    print(f"  P&L Realized: ${trade_pnl:,.2f}")
    print(f"  End Capital: ${current_capital:,.2f}\n")

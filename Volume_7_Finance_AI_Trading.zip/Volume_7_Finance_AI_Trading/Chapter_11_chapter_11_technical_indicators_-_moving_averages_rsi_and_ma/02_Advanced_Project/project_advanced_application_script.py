
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import numpy as np

# --- Configuration Constants ---
SHORT_EMA_PERIOD = 12
LONG_EMA_PERIOD = 26
SIGNAL_EMA_PERIOD = 9
RSI_PERIOD = 14
SMA_SHORT = 10
SMA_LONG = 50

class IntegratedIndicatorEngine:
    """
    A class designed to calculate core technical indicators (SMA, EMA, RSI, MACD) 
    and generate composite trading signals from historical price data.
    """

    def __init__(self, data: pd.DataFrame):
        """Initializes the engine with the historical price data."""
        self.df = data.copy()
        if 'Close' not in self.df.columns:
            raise ValueError("DataFrame must contain a 'Close' column.")
        
    def _calculate_sma(self, period: int):
        """Calculates the Simple Moving Average (SMA)."""
        col_name = f'SMA_{period}'
        self.df[col_name] = self.df['Close'].rolling(window=period).mean()

    def _calculate_ema(self, period: int):
        """Calculates the Exponential Moving Average (EMA)."""
        col_name = f'EMA_{period}'
        # Using the pandas built-in EWM (Exponential Weighted Moving) function
        # span=period applies the standard smoothing factor: alpha = 2 / (period + 1)
        self.df[col_name] = self.df['Close'].ewm(span=period, adjust=False).mean()

    def _calculate_rsi(self, period: int = RSI_PERIOD):
        """Calculates the Relative Strength Index (RSI) using EMA smoothing."""
        
        # 1. Calculate daily price change
        delta = self.df['Close'].diff()
        
        # 2. Separate gains (positive changes) and losses (negative changes)
        gain = delta.where(delta > 0, 0)
        loss = -delta.where(delta < 0, 0)
        
        # 3. Calculate Exponentially Weighted Moving Average (EWM) for gain and loss
        # This acts as the smoothing step for the average gain and average loss.
        avg_gain = gain.ewm(span=period, adjust=False).mean()
        avg_loss = loss.ewm(span=period, adjust=False).mean()
        
        # 4. Calculate Relative Strength (RS)
        # Handle division by zero for stability
        rs = avg_gain / avg_loss.replace(0, np.nan) 
        
        # 5. Calculate RSI: RSI = 100 - (100 / (1 + RS))
        self.df['RSI'] = 100 - (100 / (1 + rs))

    def _calculate_macd(self):
        """Calculates MACD Line, Signal Line, and Histogram."""
        
        # 1. Calculate the required EMAs
        self._calculate_ema(SHORT_EMA_PERIOD)
        self._calculate_ema(LONG_EMA_PERIOD)
        
        # 2. MACD Line: Fast EMA - Slow EMA
        macd_line = self.df[f'EMA_{SHORT_EMA_PERIOD}'] - self.df[f'EMA_{LONG_EMA_PERIOD}']
        self.df['MACD'] = macd_line
        
        # 3. Signal Line: 9-period EMA of the MACD Line
        self.df['Signal_Line'] = macd_line.ewm(span=SIGNAL_EMA_PERIOD, adjust=False).mean()
        
        # 4. MACD Histogram: MACD Line - Signal Line
        self.df['Histogram'] = self.df['MACD'] - self.df['Signal_Line']

    def generate_composite_signals(self):
        """
        Orchestrates all calculations and generates composite trading signals.
        """
        # Run all calculation methods
        self._calculate_sma(SMA_SHORT)
        self._calculate_sma(SMA_LONG)
        self._calculate_rsi()
        self._calculate_macd()
        
        # Initialize the 'Action' column to 'Hold'
        self.df['Action'] = 'Hold'
        
        # --- Signal Generation Logic ---
        
        # Rule 1: Trend Confirmation (Short SMA crosses above Long SMA)
        # A buy signal if the short-term trend is stronger than the long-term trend
        ma_buy_condition = (self.df[f'SMA_{SMA_SHORT}'].shift(1) < self.df[f'SMA_{SMA_LONG}'].shift(1)) & \
                           (self.df[f'SMA_{SMA_SHORT}'] > self.df[f'SMA_{SMA_LONG}'])
        
        # Rule 2: Momentum Extreme (RSI Oversold)
        rsi_buy_condition = (self.df['RSI'] < 30)
        
        # Rule 3: Momentum Shift (MACD Crossover)
        # MACD line crosses above Signal line (positive momentum shift)
        macd_buy_condition = (self.df['MACD'].shift(1) < self.df['Signal_Line'].shift(1)) & \
                             (self.df['MACD'] > self.df['Signal_Line'])
        
        # Aggregated Buy Signal: Requires MACD confirmation AND either MA cross or RSI extreme
        buy_mask = (macd_buy_condition) & (ma_buy_condition | rsi_buy_condition)
        self.df.loc[buy_mask, 'Action'] = 'Buy'
        
        # Aggregated Sell Signal (Inverse Logic)
        ma_sell_condition = (self.df[f'SMA_{SMA_SHORT}'].shift(1) > self.df[f'SMA_{SMA_LONG}'].shift(1)) & \
                            (self.df[f'SMA_{SMA_SHORT}'] < self.df[f'SMA_{SMA_LONG}'])
        rsi_sell_condition = (self.df['RSI'] > 70)
        macd_sell_condition = (self.df['MACD'].shift(1) > self.df['Signal_Line'].shift(1)) & \
                              (self.df['MACD'] < self.df['Signal_Line'])
                              
        sell_mask = (macd_sell_condition) & (ma_sell_condition | rsi_sell_condition)
        self.df.loc[sell_mask, 'Action'] = 'Sell'
        
        # Drop initial NaN rows created by the indicator lookback periods
        return self.df.dropna().tail(20) # Return the last 20 actionable rows

# --- Simulation Data Setup ---
def create_simulated_data(length=200):
    """Creates a simulated price series for testing."""
    np.random.seed(42)
    dates = pd.date_range(start='2023-01-01', periods=length, freq='D')
    # Simulate a price series with a slight upward trend and volatility
    initial_price = 100
    returns = np.random.normal(0.001, 0.01, length)
    prices = initial_price * (1 + returns).cumprod()
    
    data = pd.DataFrame({
        'Date': dates,
        'Close': prices.round(2)
    })
    data.set_index('Date', inplace=True)
    return data

if __name__ == '__main__':
    
    # 1. Prepare Data
    price_data = create_simulated_data(length=300)
    print("--- Input Data Sample ---")
    print(price_data.head())
    print("\n" + "="*50 + "\n")
    
    # 2. Initialize and Execute Engine
    engine = IntegratedIndicatorEngine(price_data)
    actionable_results = engine.generate_composite_signals()
    
    # 3. Output Results
    print("--- Calculated Indicators and Aggregated Signals (Last 20 Days) ---")
    # Display key columns for clarity
    display_cols = ['Close', 'SMA_10', 'EMA_12', 'RSI', 'MACD', 'Signal_Line', 'Histogram', 'Action']
    pd.set_option('display.max_columns', None)
    print(actionable_results[display_cols])
    
    # Analyze generated signals
    buy_count = (actionable_results['Action'] == 'Buy').sum()
    sell_count = (actionable_results['Action'] == 'Sell').sum()
    print(f"\nSummary: Generated {buy_count} Buy signals and {sell_count} Sell signals in the displayed period.")

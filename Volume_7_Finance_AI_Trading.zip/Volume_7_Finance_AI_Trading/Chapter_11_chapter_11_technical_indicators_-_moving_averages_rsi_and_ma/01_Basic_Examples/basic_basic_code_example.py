
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import pandas as pd

# --- 1. Data Preparation ---

# Define sample historical price data (10 consecutive days)
# Prices are intentionally linear (10 to 19) for easy manual verification.
historical_data = [10.0, 11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0]

# Define corresponding dates for time-series indexing
date_range = pd.to_datetime(['2024-01-01', '2024-01-02', '2024-01-03', '2024-01-04',
                            '2024-01-05', '2024-01-06', '2024-01-07', '2024-01-08',
                            '2024-01-09', '2024-01-10'])

# Create a pandas Series, which is the ideal structure for a single time-series
price_series = pd.Series(historical_data, index=date_range, name='Close_Price')

# --- 2. Parameter Definition ---

# Define the lookback period (N days) for the SMA.
# A 4-day window is chosen here for demonstration purposes.
SMA_WINDOW = 4

# --- 3. Calculation of the SMA ---

# The core calculation uses the .rolling() method.
# .rolling(window=SMA_WINDOW) creates a 'rolling window object' of size N.
# .mean() is then applied to calculate the average within that window.
sma_results = price_series.rolling(window=SMA_WINDOW).mean()

# Assign the results back to a new Series/DataFrame column for comparison
price_series = pd.DataFrame(price_series) # Convert Series to DataFrame for cleaner column addition
price_series['SMA_4_Day'] = sma_results

# --- 4. Output ---
print("--- 4-Day Simple Moving Average Calculation ---")
print(price_series)

# Example of manual verification for the 4th day (Jan 4th):
# (10.0 + 11.0 + 12.0 + 13.0) / 4 = 46.0 / 4 = 11.5
print("\nVerification Check (SMA on 2024-01-04): Expected 11.5")
print("Actual Result:", price_series.loc['2024-01-04', 'SMA_4_Day'])

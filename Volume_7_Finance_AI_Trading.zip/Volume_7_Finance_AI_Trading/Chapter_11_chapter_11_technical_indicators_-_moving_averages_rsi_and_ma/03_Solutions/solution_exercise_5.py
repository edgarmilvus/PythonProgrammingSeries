
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# Setup boilerplate for Exercise 5
import pandas as pd
import numpy as np

# Assume calculate_rsi and calculate_macd are available (using definitions from Ex 4)

def calculate_ema(series, span):
    return series.ewm(span=span, adjust=False).mean()

def calculate_macd(df, fast_period=12, slow_period=26, signal_period=9):
    fast_ema = calculate_ema(df['Close'], fast_period)
    slow_ema = calculate_ema(df['Close'], slow_period)
    
    # Dynamic column naming for sensitivity testing
    macd_name = f'MACD_Line_{fast_period}_{slow_period}_{signal_period}'
    signal_name = f'Signal_Line_{fast_period}_{slow_period}_{signal_period}'
    hist_name = f'MACD_Hist_{fast_period}_{slow_period}_{signal_period}'
    
    df[macd_name] = fast_ema - slow_ema
    df[signal_name] = calculate_ema(df[macd_name], signal_period)
    df[hist_name] = df[macd_name] - df[signal_name]
    return df

def calculate_rsi(df, period=14):
    delta = df['Close'].diff()
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)
    avg_gain = gain.ewm(span=period, adjust=False).mean()
    avg_loss = loss.ewm(span=period, adjust=False).mean()
    rs = avg_gain / avg_loss
    df[f'RSI_{period}'] = 100 - (100 / (1 + rs))
    return df
# End required function definitions

def test_indicator_sensitivity(df, rsi_periods, macd_params_list):
    results_df = df.copy()
    
    # 1. RSI Iteration
    for period in rsi_periods:
        results_df = calculate_rsi(results_df, period=period)
    
    # 2. MACD Iteration
    for fast, slow, signal in macd_params_list:
        results_df = calculate_macd(results_df, fast, slow, signal)
    
    # 3. Identify indicator columns for summary
    indicator_columns = [col for col in results_df.columns if 'RSI' in col or 'MACD' in col]
    
    # 4. Generate Summary using vectorized aggregation
    summary = results_df[indicator_columns].agg(
        ['max', 'min', 'mean', 'std']
    ).T # Transpose for better readability
    
    # Rename columns for clarity
    summary.columns = ['Max Value', 'Min Value', 'Mean Value', 'Standard Deviation (std)']
    
    return summary

# Define parameter sets for testing
rsi_tests = [7, 14, 28]
macd_tests = [
    (12, 26, 9),  # Standard Settings
    (5, 35, 5)    # Highly volatile settings
]

# Example Test Call
# sensitivity_report = test_indicator_sensitivity(data.copy(), rsi_tests, macd_tests)
# print(sensitivity_report.round(4))

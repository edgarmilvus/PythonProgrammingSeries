
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Setup boilerplate for Exercise 2
import numpy as np
import pandas as pd

# Assume 'data' DataFrame is available

def calculate_rsi(df, period=14):
    df_temp = df.copy() 

    # Step 1: Calculate price changes
    delta = df_temp['Close'].diff()
    
    # Step 2 & 3: Separate Gains and Losses using vectorized conditional assignment
    # Gains: where delta > 0, otherwise 0
    gain = delta.where(delta > 0, 0)
    
    # Losses: where delta < 0, take the absolute value, otherwise 0
    loss = -delta.where(delta < 0, 0)

    # Step 4: Calculate Average Gain and Loss (using EWM, adjust=False for RSI standard)
    avg_gain = gain.ewm(span=period, adjust=False).mean()
    avg_loss = loss.ewm(span=period, adjust=False).mean()
    
    # Step 5: Calculate Relative Strength (RS)
    # Vector division handles the series operation
    rs = avg_gain / avg_loss
    
    # Step 6: RSI Final Formula: RSI = 100 - (100 / (1 + RS))
    rsi = 100 - (100 / (1 + rs))
    
    df[f'RSI_{period}'] = rsi
    
    return df

# Example Test Call
# data_with_rsi = calculate_rsi(data.copy()) 
# print(data_with_rsi[['Close', 'RSI_14']].tail())

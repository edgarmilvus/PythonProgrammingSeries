
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# Setup boilerplate for Exercise 1
import pandas as pd
import numpy as np

# --- Synthetic Data Creation (for demonstration purposes) ---
dates = pd.date_range(start='2023-01-01', periods=100)
np.random.seed(42)
prices = 100 + np.cumsum(np.random.randn(100) * 0.5)
data = pd.DataFrame({'Close': prices}, index=dates)
data.index.name = 'Date'
# --- End Synthetic Data ---

def calculate_dual_ma(df, period):
    # 1. SMA Calculation (Simple Moving Average)
    # The rolling window method ensures the first (period - 1) values are NaN.
    df[f'SMA_{period}'] = df['Close'].rolling(window=period).mean()
    
    # 2. EMA Calculation (Exponential Moving Average)
    # Using span=period and adjust=False for standard financial calculation.
    # EMA starts calculating immediately, but requires the span for stability.
    df[f'EMA_{period}'] = df['Close'].ewm(span=period, adjust=False).mean()
    
    return df

# Example Data Loading (using synthetic data structure)
# data = pd.read_csv('historical_prices.csv', index_col='Date', parse_dates=True)
# data = data.rename(columns={'Adj Close': 'Close'})

period = 20
data_with_ma = calculate_dual_ma(data.copy(), period=period)

# Verification step structure
print(f"Verifying SMA {period} calculation start point:")
print(data_with_ma[['Close', f'SMA_{period}', f'EMA_{period}']].head(period + 2))

# Data Integrity Check Logic:
sma_nan_count = data_with_ma[f'SMA_{period}'].head(period).isnull().sum()
print(f"\nVerification: SMA NaN count in first {period} rows: {sma_nan_count}. (Expected: {period - 1})")
print(f"Verification: EMA value at index 0 is populated: {data_with_ma[f'EMA_{period}'].iloc[0]:.4f}")

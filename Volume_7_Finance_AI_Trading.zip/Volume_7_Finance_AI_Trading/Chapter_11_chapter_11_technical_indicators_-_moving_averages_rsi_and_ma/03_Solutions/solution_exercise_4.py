
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Setup boilerplate for Exercise 4 (Requires previous successful functions)
import pandas as pd
import numpy as np

# Re-define required calculation functions for self-contained execution
def calculate_ema(series, span):
    return series.ewm(span=span, adjust=False).mean()

def calculate_macd(df, fast_period=12, slow_period=26, signal_period=9):
    fast_ema = calculate_ema(df['Close'], fast_period)
    slow_ema = calculate_ema(df['Close'], slow_period)
    df['MACD_Line'] = fast_ema - slow_ema
    df['Signal_Line'] = calculate_ema(df['MACD_Line'], signal_period)
    df['MACD_Hist'] = df['MACD_Line'] - df['Signal_Line']
    return df

def calculate_rsi(df, period=14):
    delta = df['Close'].diff()
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)
    avg_gain = gain.ewm(span=period, adjust=False).mean()
    avg_loss = loss.ewm(span=period, adjust=False).mean()
    rs = avg_gain / avg_loss
    df[f'RSI_{period}'] = 100 - (100 / (1 + rs))
    return df
# End required function definitions

def generate_complex_signal(df):
    # Step 1: Ensure MACD and RSI are calculated first
    df = calculate_macd(df)
    df = calculate_rsi(df)
    
    # Step 2: Calculate SMA_50
    df['SMA_50'] = df['Close'].rolling(window=50).mean()
    
    # Step 3: Identify MACD Crossover (Bullish: MACD crosses ABOVE Signal)
    # Condition: Current MACD > Signal AND Previous MACD <= Previous Signal
    current_bullish = df['MACD_Line'] > df['Signal_Line']
    previous_bearish_or_equal = df['MACD_Line'].shift(1) <= df['Signal_Line'].shift(1)
    
    # Combine for exact crossover point
    df['MACD_Crossover'] = current_bullish & previous_bearish_or_equal
    
    # Step 4: Combine conditions for final signal
    condition_1 = df['MACD_Crossover'] == True
    condition_2 = df['Close'] > df['SMA_50']         # Price above long-term trend
    condition_3 = df['RSI_14'] < 70                  # Not overbought
    
    # Combine all boolean conditions using the vectorized logical AND operator (&)
    df['Bullish_Entry_Signal'] = condition_1 & condition_2 & condition_3
    
    return df

# Example Test Call
# final_signals = generate_complex_signal(data.copy())
# print(final_signals[['Close', 'SMA_50', 'RSI_14', 'MACD_Line', 'Signal_Line', 'Bullish_Entry_Signal']].tail(10))

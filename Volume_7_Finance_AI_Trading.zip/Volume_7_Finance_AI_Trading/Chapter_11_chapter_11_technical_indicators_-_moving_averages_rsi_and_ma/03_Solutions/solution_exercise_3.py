
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Setup boilerplate for Exercise 3
import pandas as pd

# Assume 'data' DataFrame is available

def calculate_macd(df, fast_period=12, slow_period=26, signal_period=9):
    
    # Helper function for consistent EMA calculation
    def calculate_ema(series, span):
        # Use adjust=False for standard technical analysis EMA calculation
        return series.ewm(span=span, adjust=False).mean()

    # Step 1 & 2: Calculate Fast and Slow EMAs
    fast_ema = calculate_ema(df['Close'], fast_period)
    slow_ema = calculate_ema(df['Close'], slow_period)
    
    # Step 3: MACD Line (Fast EMA - Slow EMA)
    df['MACD_Line'] = fast_ema - slow_ema
    
    # Step 4: Signal Line (EMA of the MACD Line)
    # Note: This is an EMA of the previously calculated MACD_Line series
    df['Signal_Line'] = calculate_ema(df['MACD_Line'], signal_period)
    
    # Step 5: Histogram (MACD Line - Signal Line)
    df['MACD_Hist'] = df['MACD_Line'] - df['Signal_Line']
    
    return df

# Example Test Call
# data_with_macd = calculate_macd(data.copy())
# print(data_with_macd[['Close', 'MACD_Line', 'Signal_Line', 'MACD_Hist']].tail())

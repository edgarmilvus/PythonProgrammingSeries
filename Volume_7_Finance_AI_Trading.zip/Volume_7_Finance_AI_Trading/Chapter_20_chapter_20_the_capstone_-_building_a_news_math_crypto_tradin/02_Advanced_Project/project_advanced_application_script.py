
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import asyncio
import pandas as pd
import numpy as np
from typing import List, Dict, Tuple

# --- Configuration & Strategy Parameters ---
SYMBOL = "ETH/USDT"
RSI_PERIOD = 14
SMA_PERIOD = 50
SENTIMENT_THRESHOLD = 0.65  # Sentiment must exceed this for confirmation (range -1.0 to 1.0)
RSI_OVERSOLD = 30
RSI_OVERBOUGHT = 70

async def fetch_historical_data(symbol: str, limit: int = 100) -> pd.DataFrame:
    """Simulates fetching recent OHLCV data asynchronously from an exchange API."""
    await asyncio.sleep(0.1)  # Simulate network latency (I/O bound task)
    
    # Mock data generation for demonstration
    np.random.seed(42)
    # Generate a slightly volatile price series
    prices = 2000 + np.cumsum(np.random.randn(limit) * 10)
    data = pd.DataFrame({'Close': prices})
    print(f"[{symbol}] Data fetched. {len(data)} bars.")
    return data

async def fetch_current_sentiment(symbol: str) -> float:
    """Simulates fetching the latest aggregated NLP sentiment score from a dedicated service."""
    await asyncio.sleep(0.05) # Shorter latency for sentiment API call
    
    # Mock sentiment: Simulate a positive score that sometimes clears the threshold
    current_sentiment = 0.72 if np.random.rand() > 0.3 else 0.45 
    print(f"[{symbol}] Current aggregated sentiment score: {current_sentiment:.2f}")
    return current_sentiment

def calculate_technical_indicators(df: pd.DataFrame) -> Tuple[float, float]:
    """Calculates the Relative Strength Index (RSI) and Simple Moving Average (SMA)."""
    
    # 1. Calculate Price Changes (Delta)
    delta = df['Close'].diff()
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)

    # 2. Calculate Exponential Moving Average of Gains and Losses (RS)
    # Using EWM for smoothing, standard for RSI calculation
    avg_gain = gain.ewm(com=RSI_PERIOD - 1, min_periods=RSI_PERIOD).mean()
    avg_loss = loss.ewm(com=RSI_PERIOD - 1, min_periods=RSI_PERIOD).mean()

    # 3. Calculate RSI
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    latest_rsi = rsi.iloc[-1]

    # 4. Calculate SMA (Trend Filter)
    sma = df['Close'].rolling(window=SMA_PERIOD).mean().iloc[-1]

    return latest_rsi, sma

def generate_hybrid_signal(rsi: float, sma: float, price: float, sentiment: float) -> str:
    """
    Applies the core 'News + Math' strategy logic.
    A BUY signal requires technical alignment AND sentiment confirmation.
    """
    signal = "HOLD"

    # Technical Buy Condition: RSI is oversold AND price is above the long-term SMA (Trend filter)
    tech_buy = (rsi < RSI_OVERSOLD) and (price > sma)

    # Technical Sell Condition: RSI is overbought (Risk management exit)
    tech_sell = (rsi > RSI_OVERBOUGHT)

    # Sentiment Confirmation: Sentiment must be strongly positive, clearing the threshold
    sentiment_confirm = (sentiment >= SENTIMENT_THRESHOLD)

    if tech_buy and sentiment_confirm:
        # High-confidence entry signal
        signal = f"BUY | CONFIRMED: Sentiment ({sentiment:.2f}) > Threshold ({SENTIMENT_THRESHOLD})"
    elif tech_sell:
        # Sell signal is purely technical, prioritizing risk reduction when overbought
        signal = "SELL | TECHNICAL OVERBOUGHT"
    
    return signal

async def run_hybrid_bot_cycle(symbol: str):
    """Main asynchronous function to run one complete signal generation cycle."""
    print(f"\n--- Starting Hybrid Signal Cycle for {symbol} ---")
    
    # CRITICAL: Concurrently fetch required data streams using asyncio.gather
    data_future = fetch_historical_data(symbol)
    sentiment_future = fetch_current_sentiment(symbol)
    
    # Await both Futures simultaneously. This maximizes efficiency.
    df, sentiment = await asyncio.gather(data_future, sentiment_future)
    
    # Data validation
    if len(df) < max(RSI_PERIOD, SMA_PERIOD):
        print("Insufficient data for indicator calculation.")
        return "HOLD"

    # 1. Calculate Technicals (CPU bound operation)
    latest_rsi, latest_sma = calculate_technical_indicators(df)
    latest_price = df['Close'].iloc[-1]

    print(f"Calculated Metrics: RSI={latest_rsi:.2f}, SMA_{SMA_PERIOD}={latest_sma:.2f}, Price={latest_price:.2f}")

    # 2. Generate Hybrid Signal
    final_signal = generate_hybrid_signal(latest_rsi, latest_sma, latest_price, sentiment)
    
    print(f"\nFINAL TRADING SIGNAL: {final_signal}")
    return final_signal

if __name__ == "__main__":
    # Execute the asynchronous main loop
    asyncio.run(run_hybrid_bot_cycle(SYMBOL))

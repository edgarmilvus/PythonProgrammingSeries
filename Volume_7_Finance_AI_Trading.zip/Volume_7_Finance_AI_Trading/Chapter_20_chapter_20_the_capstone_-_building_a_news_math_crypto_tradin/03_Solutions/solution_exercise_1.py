
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# Constants Definition (Required for the exercise setup)
RSI_OVERSOLD_THRESHOLD = 30
POSITIVE_SENTIMENT_CONFIRMATION = 0.05
RSI_OVERBOUGHT_THRESHOLD = 70
NEGATIVE_SENTIMENT_CONFIRMATION = -0.05

def generate_hybrid_signal(current_rsi: float, rolling_5min_sentiment: float, sentiment_change_rate: float) -> str:
    """
    Generates a trading signal based on the confirmed hybrid strategy (Math + News).
    """
    # 1. Check for Confirmed BUY Signal: Oversold RSI AND Positive Sentiment Spike
    if (current_rsi <= RSI_OVERSOLD_THRESHOLD and 
        sentiment_change_rate >= POSITIVE_SENTIMENT_CONFIRMATION):
        return "BUY"
    
    # 2. Check for Confirmed SELL Signal: Overbought RSI AND Negative Sentiment Crash
    elif (current_rsi >= RSI_OVERBOUGHT_THRESHOLD and 
          sentiment_change_rate <= NEGATIVE_SENTIMENT_CONFIRMATION):
        return "SELL"
        
    # 3. Default action: No confirmed signal
    else:
        return "HOLD"

# Example usage simulation (for testing logic flow)
# result_buy = generate_hybrid_signal(28.5, 0.65, 0.06) 
# result_hold = generate_hybrid_signal(45.0, 0.55, 0.01)

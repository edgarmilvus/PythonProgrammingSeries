
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

def calculate_dynamic_position_size(
    account_balance: float, 
    current_price: float, 
    signal_strength_multiplier: float, 
    base_risk_percent: float
) -> float:
    # Define constants for stop-loss percentage
    STOP_LOSS_PERCENT = 0.02 
    
    # Step 1: Calculate Total Risk (R$) using multiplication (*)
    # Total Risk = Account Balance * Base Risk Percent * Multiplier
    total_risk = account_balance * base_risk_percent * signal_strength_multiplier
    
    # Step 2: Calculate Position Value (P$) using division (/)
    # Position Value = Total Risk / Stop Loss Percentage
    # This determines the maximum dollar value we can hold given the risk tolerance.
    position_value = total_risk / STOP_LOSS_PERCENT
    
    # Step 3: Calculate Quantity (Q) using division (/)
    # Quantity = Position Value / Current Price
    quantity = position_value / current_price
    
    return round(quantity, 4)

# Example usage simulation
# quantity_low_confidence = calculate_dynamic_position_size(10000.0, 50000.0, 1.0, 0.01) # Expected: 0.1
# quantity_high_confidence = calculate_dynamic_position_size(10000.0, 50000.0, 1.8, 0.01) # Expected: 0.18

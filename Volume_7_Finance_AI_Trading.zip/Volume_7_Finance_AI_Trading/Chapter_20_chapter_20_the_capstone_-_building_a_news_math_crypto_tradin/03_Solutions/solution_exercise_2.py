
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import asyncio
import time
from typing import Tuple, Dict, Any

async def fetch_market_data_async() -> Dict[str, float]:
    # Simulate fast market data retrieval
    await asyncio.sleep(0.5)
    return {"RSI": 32.0, "Price": 45000.0}

async def process_sentiment_async() -> Dict[str, float]:
    # Simulate slow NLP processing
    await asyncio.sleep(2.5)
    # Simulate a potential timeout or error during processing
    # if time.time() % 10 < 3: # Uncomment to test error handling
    #     raise asyncio.TimeoutError("Sentiment API took too long.")
    return {"Sentiment_Score": 0.61, "Change_Rate": 0.04}

async def trading_loop_manager():
    last_known_sentiment = {"Sentiment_Score": 0.50, "Change_Rate": 0.00}
    current_sentiment = last_known_sentiment
    
    print("Initiating concurrent data fetching...")

    # 1. Create Tasks (which are asyncio.Future objects)
    market_task = asyncio.create_task(fetch_market_data_async())
    sentiment_task = asyncio.create_task(process_sentiment_async())

    # 2. Await the results individually for granular control and error handling
    
    # Market Data (critical path)
    market_data = await market_task
    
    # Sentiment Data (slower path, requires fallback)
    try:
        current_sentiment = await sentiment_task
        print("Sentiment processing succeeded.")
        
    except asyncio.TimeoutError as e:
        # If the sentiment future fails due to timeout, use the last known good data.
        print(f"ERROR: Sentiment task failed: {e}. Using last known good sentiment.")
        current_sentiment = last_known_sentiment
    except Exception as e:
        print(f"ERROR: An unexpected error occurred: {e}. Using last known good sentiment.")
        current_sentiment = last_known_sentiment

    # 3. Use the collected data
    print(f"Received Market Data: {market_data}")
    print(f"Using Sentiment Data: {current_sentiment}")
    
# asyncio.run(trading_loop_manager())

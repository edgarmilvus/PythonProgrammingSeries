
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from typing import Dict, Any

class BotSessionManager:
    """
    Manages the persistent state of the bot using a simulated Session Object (dictionary).
    """
    
    def __init__(self, session_data: Dict[str, Any]):
        self.session_data = session_data
        
        # Load state safely using .get() for persistence
        self.is_position_open: bool = session_data.get('is_position_open', False)
        self.last_entry_price: float = session_data.get('last_entry_price', 0.0)
        self.current_risk_multiplier: float = session_data.get('current_risk_multiplier', 1.0)
        
        print(f"Manager initialized. Position Open: {self.is_position_open}")

    def save_state(self) -> None:
        # Update the external session dictionary with current instance attributes
        self.session_data['is_position_open'] = self.is_position_open
        self.session_data['last_entry_price'] = self.last_entry_price
        self.session_data['current_risk_multiplier'] = self.current_risk_multiplier
        print("State saved to session storage.")

    def check_and_execute_trade(self, signal: str, current_price: float) -> bool:
        
        if signal == "BUY":
            if self.is_position_open:
                print(f"Error: Received BUY signal, but position is already open at {self.last_entry_price}.")
                return False
            else:
                # Open position
                self.is_position_open = True
                self.last_entry_price = current_price
                print(f"EXECUTED BUY: Position opened at {current_price}. State updated.")
                self.save_state()
                return True
                
        elif signal == "SELL":
            if self.is_position_open:
                # Close position
                profit_loss = (current_price - self.last_entry_price) / self.last_entry_price * 100
                print(f"EXECUTED SELL: Position closed at {current_price}. P&L: {profit_loss:.2f}%")
                self.is_position_open = False
                self.last_entry_price = 0.0 
                self.save_state()
                return True
            else:
                print("Received SELL signal, but no position is currently open. Ignoring.")
                return False
        
        return False

# Example usage simulation:
# session_storage = {}
# bot_instance = BotSessionManager(session_storage)
# bot_instance.check_and_execute_trade("BUY", 45000.0) 
# print(session_storage) 

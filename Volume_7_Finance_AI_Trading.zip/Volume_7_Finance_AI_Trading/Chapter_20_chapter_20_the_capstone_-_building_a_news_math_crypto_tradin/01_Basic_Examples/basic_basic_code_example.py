
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import random

# --- 1. Simulated Market and External Data Inputs ---

# Simulated technical data (Moving Averages)
FAST_MA = 45100.00  # Fast Moving Average (e.g., 10-period EMA)
SLOW_MA = 44900.00  # Slow Moving Average (e.g., 50-period SMA)
CURRENT_PRICE = 45000.00

# Simulated NLP Sentiment Score (Range: -1.0 to 1.0)
# We simulate a high positive score indicative of sudden good news.
RECENT_SENTIMENT_SCORE = 0.85 

# --- 2. Signal Generation Functions (The Math and The News) ---

def get_technical_signal(fast_ma: float, slow_ma: float) -> bool:
    """
    Determines if the technical indicators suggest a bullish trend.
    
    The condition (Fast MA > Slow MA) is known as a bullish crossover, 
    suggesting positive momentum.
    """
    # The comparison operator returns a boolean directly.
    is_bullish_math = fast_ma > slow_ma
    return is_bullish_math

def get_sentiment_signal(sentiment_score: float, required_threshold: float = 0.6) -> bool:
    """
    Determines if the news sentiment is strongly positive, exceeding a confidence threshold.
    
    We require a score significantly above zero to filter out weak or neutral signals.
    """
    # Check if the score meets or exceeds the high-conviction threshold.
    is_bullish_news = sentiment_score >= required_threshold
    return is_bullish_news

# --- 3. The Hybrid Integration Logic ---

def generate_hybrid_signal(math_signal: bool, news_signal: bool) -> str:
    """
    Combines the two independent signals. A trade is only executed if 
    both conditions confirm each other (High-Conviction AND logic).
    """
    
    # CRITICAL: The use of the 'and' operator requires both inputs to be True.
    if math_signal and news_signal:
        return "HIGH_CONVICTION_BUY"
        
    # Case 1: Technicals are bullish, but news is neutral or negative.
    elif math_signal and not news_signal:
        return "MATH_ONLY_HOLD (Unconfirmed)" 
        
    # Case 2: News is bullish, but technicals are weak or bearish.
    elif not math_signal and news_signal:
        return "NEWS_ONLY_HOLD (Unconfirmed)" 
        
    # Case 3: Neither signal is bullish enough.
    else:
        return "NO_ACTION (Bearish/Neutral)"

# --- 4. Execution Flow ---

# Define the required sentiment strength
SENTIMENT_THRESHOLD = 0.6

# Step A: Process the Math data
math_result = get_technical_signal(FAST_MA, SLOW_MA)
print(f"1. Technical Signal (Fast MA {FAST_MA} > Slow MA {SLOW_MA}): {math_result}")

# Step B: Process the News data
news_result = get_sentiment_signal(RECENT_SENTIMENT_SCORE, SENTIMENT_THRESHOLD)
print(f"2. Sentiment Signal (Score {RECENT_SENTIMENT_SCORE} >= {SENTIMENT_THRESHOLD}): {news_result}")

# Step C: Generate the Final Hybrid Signal
final_trade_action = generate_hybrid_signal(math_result, news_result)
print(f"\n3. Final Hybrid Action: {final_trade_action}")


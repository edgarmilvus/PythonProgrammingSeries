
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# --- Configuration Constants ---
START_DATE = datetime(2018, 1, 1)
END_DATE = datetime(2023, 1, 1)
SHORT_WINDOW = 20
LONG_WINDOW = 50
INITIAL_CAPITAL = 100000

def generate_synthetic_data(start_date: datetime, end_date: datetime, initial_price: float = 100.0) -> pd.DataFrame:
    """Generates a synthetic time series DataFrame suitable for backtesting."""
    date_range = pd.date_range(start=start_date, end=end_date, freq='B') # Business days
    
    # Generate random daily returns (mean 0.0001, std 0.01)
    np.random.seed(42) # For reproducibility
    returns = np.random.normal(loc=0.0001, scale=0.01, size=len(date_range))
    
    # Convert returns to prices (cumulative product)
    price_series = initial_price * (1 + returns).cumprod()
    
    df = pd.DataFrame({'Close': price_series}, index=date_range)
    return df

def calculate_metrics(equity_curve: pd.Series) -> dict:
    """Calculates key performance metrics using vectorized operations."""
    
    # 1. Total Return
    total_return = (equity_curve.iloc[-1] / equity_curve.iloc[0]) - 1
    
    # 2. Max Drawdown (Vectorized Calculation)
    # Calculate the running maximum (peak equity achieved so far)
    peak = equity_curve.expanding(min_periods=1).max()
    # Calculate the drawdown as a percentage from the peak
    drawdown = (equity_curve / peak) - 1.0
    # Find the maximum absolute value of the drawdown
    max_drawdown = drawdown.min()
    
    # 3. Annualized Return (Assuming business days ~ 252 trading days/year)
    years = (equity_curve.index[-1] - equity_curve.index[0]).days / 365.25
    annualized_return = ((1 + total_return) ** (1 / years)) - 1
    
    return {
        'Total Return': f"{total_return * 100:.2f}%",
        'Annualized Return': f"{annualized_return * 100:.2f}%",
        'Max Drawdown': f"{max_drawdown * 100:.2f}%",
        'Final Equity': f"${equity_curve.iloc[-1]:,.2f}"
    }

def vectorized_backtest(df: pd.DataFrame, short_window: int, long_window: int, initial_capital: float) -> pd.DataFrame:
    """
    Applies the Dual-SMA Crossover strategy and calculates performance entirely 
    using vectorized Pandas operations.
    """
    
    # 1. Calculate Simple Moving Averages (Vectorized Rolling Function)
    df['SMA_Short'] = df['Close'].rolling(window=short_window, min_periods=1).mean()
    df['SMA_Long'] = df['Close'].rolling(window=long_window, min_periods=1).mean()
    
    # 2. Generate Trading Signals (Vectorized Comparison)
    # A signal of 1 means 'Buy/Long', 0 means 'Hold/Flat'
    df['Signal'] = np.where(df['SMA_Short'] > df['SMA_Long'], 1, 0)
    
    # 3. Determine Position (Vectorized Shift and Difference)
    # Calculate the actual position taken (1=Long, 0=Flat). 
    # Use shift(1) to ensure we act on the signal from the previous day's close.
    df['Position'] = df['Signal'].shift(1).fillna(0)
    
    # 4. Calculate Daily Percentage Returns
    df['Daily_Returns'] = df['Close'].pct_change()
    
    # 5. Calculate Strategy Returns (Crucial Vectorization Step)
    # Strategy Return = Daily Market Return * Position Held
    # This multiplies the entire column of daily returns by the entire column of positions
    df['Strategy_Returns'] = df['Daily_Returns'] * df['Position']
    
    # 6. Calculate Cumulative Returns and Equity Curve
    # Cumulative returns start at 1.0 (representing 100% of capital)
    df['Cumulative_Returns'] = (1 + df['Strategy_Returns']).cumprod()
    df['Equity_Curve'] = df['Cumulative_Returns'] * initial_capital
    
    return df

# --- Main Execution ---
if __name__ == "__main__":
    print("--- Starting Vectorized Backtest Engine ---")
    
    # 1. Data Preparation
    price_data = generate_synthetic_data(START_DATE, END_DATE)
    print(f"Data Loaded: {len(price_data)} trading days.")
    
    # 2. Run Backtest
    results_df = vectorized_backtest(
        df=price_data, 
        short_window=SHORT_WINDOW, 
        long_window=LONG_WINDOW, 
        initial_capital=INITIAL_CAPITAL
    )
    
    # 3. Analyze Results
    final_equity_curve = results_df['Equity_Curve'].dropna()
    
    if not final_equity_curve.empty:
        performance_metrics = calculate_metrics(final_equity_curve)
        
        print("\n--- Performance Summary (DMAC Strategy) ---")
        for metric, value in performance_metrics.items():
            print(f"{metric:<20}: {value}")
            
        # Display the first and last few rows of the calculation for verification
        print("\n--- Verification of Vectorized Calculations ---")
        print(results_df[['Close', 'SMA_Short', 'SMA_Long', 'Signal', 'Position', 'Strategy_Returns', 'Equity_Curve']].head(3))
        print("...")
        print(results_df[['Close', 'SMA_Short', 'SMA_Long', 'Signal', 'Position', 'Strategy_Returns', 'Equity_Curve']].tail(3))
    else:
        print("Error: Equity curve is empty.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import pandas as pd
import numpy as np
import timeit

N_ROWS = 200000
WINDOW = 20
THRESHOLD = 0.015 # 1.5% volatility

# Requirement 1: Generate synthetic data
np.random.seed(42)
prices = 100 + np.cumsum(np.random.randn(N_ROWS) * 0.1)
df_benchmark = pd.DataFrame({'Close': prices})

def calculate_volatility_iterative(df, window, threshold):
    """Calculates rolling volatility and signal using a slow Python loop."""
    df_copy = df.copy()
    signals = [np.nan] * len(df_copy)
    
    # Requirement 2: Implement the slow, loop-based calculation
    for i in range(window, len(df_copy)):
        # Calculate standard deviation using slicing (inefficient inside a loop)
        volatility = df_copy['Close'].iloc[i-window:i].std()
        
        # Apply the rule
        if volatility > threshold:
            signals[i] = 1
        else:
            signals[i] = 0
            
    df_copy['Signal_Iterative'] = signals
    return df_copy

def calculate_volatility_vectorized(df, window, threshold):
    """Calculates rolling volatility and signal using vectorized Pandas."""
    # Requirement 3: Implement the fast, vectorized calculation
    
    # Calculate rolling standard deviation using the optimized .rolling()
    df['Volatility'] = df['Close'].rolling(window=window).std()
    
    # Generate signal using direct boolean comparison
    df['Signal_Vectorized'] = (df['Volatility'] > threshold).astype(int)
    
    return df

# Requirement 4: Time the execution
# Time the iterative approach once (it's slow)
t_iterative = timeit.timeit(lambda: calculate_volatility_iterative(df_benchmark.copy(), WINDOW, THRESHOLD), number=1)

# Time the vectorized approach multiple times for stability, then average
N_RUNS = 10
t_vectorized = timeit.timeit(lambda: calculate_volatility_vectorized(df_benchmark.copy(), WINDOW, THRESHOLD), number=N_RUNS) / N_RUNS

# Requirement 5: Reporting
speedup = t_iterative / t_vectorized

# print(f"Iterative Time (1 run): {t_iterative:.4f} seconds")
# print(f"Vectorized Time (Avg of {N_RUNS}): {t_vectorized:.4f} seconds")
# print(f"Speedup Factor: {speedup:.1f}x")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import pandas as pd
import numpy as np

# --- Setup Simulated Data ---
dates_e4 = pd.date_range('2023-01-01', periods=100)
np.random.seed(42)
prices_e4 = 100 + np.cumsum(np.random.randn(100) * 0.5)
df_e4 = pd.DataFrame({'Close': prices_e4}, index=dates_e4)

# Simulate a lagged Position column (10 days on, 10 days off)
df_e4['Position'] = np.tile([1] * 10 + [0] * 10, 5)[:100]
df_e4['Position'] = df_e4['Position'].shift(1).fillna(0)

def apply_vectorized_trailing_stop(df, stop_pct=0.05):
    # Requirement 1: Identify Trade IDs
    # Identify where position changes from 0 to 1 (start of a new trade block)
    df['Trade_Entry'] = (df['Position'].diff() == 1)
    df['Trade_ID'] = df['Trade_Entry'].cumsum()
    # Set Trade_ID to 0 when Position is 0 (we only track peaks during active trades)
    df.loc[df['Position'] == 0, 'Trade_ID'] = 0
    
    # Requirement 2: Calculate Grouped Running Maximum
    # Calculates the peak price reached since the start of the current Trade_ID
    df['Peak_Price_During_Trade'] = df.groupby('Trade_ID')['Close'].cummax()
    
    # Requirement 3: Calculate TSL Level (5% below peak)
    df['TSL_Level'] = df['Peak_Price_During_Trade'] * (1 - stop_pct)
    
    # Requirement 4: Generate Stop-Loss Trigger
    # Trigger is True if Close <= TSL_Level AND we are currently holding a position
    df['Stop_Trigger'] = (df['Close'] <= df['TSL_Level']) & (df['Position'] == 1)
    
    # Requirement 5: Adjust the final position
    
    # Step 5a: Identify if the trade has been stopped out 
    # Use cummax() on the trigger within each group. Once the trigger is True, it stays True for the rest of the trade.
    df['Stopped_Out'] = df.groupby('Trade_ID')['Stop_Trigger'].cummax()
    
    # Step 5b: Apply the stop-out logic to the position
    # If Stopped_Out is True AND we are in an active trade (Trade_ID > 0), set Position to 0.
    df['Adjusted_Position'] = np.where(
        (df['Stopped_Out'] == True) & (df['Trade_ID'] > 0),
        0, 
        df['Position'] 
    )
    
    return df

# Execute TSL application
df_e4_result = apply_vectorized_trailing_stop(df_e4.copy())
# print(df_e4_result[['Close', 'Position', 'Trade_ID', 'Peak_Price_During_Trade', 'TSL_Level', 'Stop_Trigger', 'Adjusted_Position']].tail(20))

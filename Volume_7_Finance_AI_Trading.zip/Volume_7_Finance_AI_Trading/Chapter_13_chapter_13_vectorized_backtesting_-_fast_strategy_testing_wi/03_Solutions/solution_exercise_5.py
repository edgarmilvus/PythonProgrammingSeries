
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import pandas as pd
import numpy as np

def create_multi_asset_data():
    # Requirement 1: Create simulated dataframes (AAPL, MSFT, GOOG)
    dates_aapl = pd.date_range('2020-01-01', periods=100, freq='D')
    dates_msft = pd.date_range('2020-01-10', periods=90, freq='D') 
    dates_goog = pd.date_range('2020-01-01', periods=110, freq='D') 

    np.random.seed(42)
    df_aapl = pd.DataFrame({'Close': 150 + np.cumsum(np.random.randn(len(dates_aapl)) * 1.0)}, index=dates_aapl)
    df_msft = pd.DataFrame({'Close': 250 + np.cumsum(np.random.randn(len(dates_msft)) * 0.8)}, index=dates_msft)
    df_goog = pd.DataFrame({'Close': 180 + np.cumsum(np.random.randn(len(dates_goog)) * 1.2)}, index=dates_goog)
    
    return df_aapl, df_msft, df_goog

def structure_for_vectorization(df_list):
    # Requirement 2: Concatenate into Long Format MultiIndex
    tickers = ['AAPL', 'MSFT', 'GOOG']
    
    # pd.concat stacks the dataframes, using the 'keys' list to create the Ticker level of the MultiIndex
    long_df = pd.concat(df_list, keys=tickers, names=['Ticker', 'Date']).reset_index()
    
    return long_df

def calculate_multi_asset_indicators(long_df):
    # Requirement 3: Demonstrate vectorized SMA calculation using groupby
    WINDOW = 50
    
    # Group by Ticker, then apply rolling mean. Pandas optimizes this to run the 
    # rolling calculation for all tickers simultaneously, resetting the window 
    # calculation at the start of each new ticker group.
    long_df['SMA_50'] = long_df.groupby('Ticker')['Close'].rolling(window=WINDOW).mean().reset_index(level=0, drop=True)
    
    return long_df

def aggregate_portfolio_returns(long_returns_df):
    # Assume long_returns_df has columns 'Ticker', 'Date', and 'Strategy_Returns'
    
    # Requirement 4: Pivot to Wide Format and aggregate
    
    # Pivot transforms (Date, Ticker, Return) into (Date Index, Ticker Columns, Return Values)
    wide_returns_df = long_returns_df.pivot(index='Date', columns='Ticker', values='Strategy_Returns')
    
    # Sum across the rows (axis=1) to get the aggregated daily portfolio return
    portfolio_returns_series = wide_returns_df.sum(axis=1)
    
    return portfolio_returns_series

# --- Execution ---
df_aapl, df_msft, df_goog = create_multi_asset_data()
df_list = [df_aapl, df_msft, df_goog]

long_df_e5 = structure_for_vectorization(df_list)
long_df_e5 = calculate_multi_asset_indicators(long_df_e5)

# Simulate Strategy Returns (for aggregation demo)
long_df_e5['Strategy_Returns'] = np.random.rand(len(long_df_e5)) * 0.005
long_df_e5['Strategy_Returns'].iloc[:100] = np.nan # Simulate initial NaN periods

portfolio_returns = aggregate_portfolio_returns(long_df_e5.dropna(subset=['Strategy_Returns']))
# print(long_df_e5.head(5))
# print("\nPortfolio Returns (Wide Format Aggregation):")
# print(portfolio_returns.head())

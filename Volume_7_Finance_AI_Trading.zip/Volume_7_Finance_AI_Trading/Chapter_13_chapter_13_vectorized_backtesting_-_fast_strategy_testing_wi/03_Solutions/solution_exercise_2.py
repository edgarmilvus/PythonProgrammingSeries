
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Continuing from Exercise 1's DataFrame 'df_e1'

def calculate_returns_and_mdd(df):
    # Requirement 1: Calculate Log Returns
    df['Log_Returns'] = np.log(df['Close'] / df['Close'].shift(1))
    
    # Ensure 'Position' exists (lagged signal from E1)
    if 'Position' not in df.columns:
         df['Position'] = (df['TEMA_10'] > df['TEMA_50']).astype(int).shift(1).fillna(0)
        
    # Requirement 2: Calculate Strategy Returns (element-wise multiplication)
    df['Strategy_Returns'] = df['Log_Returns'] * df['Position']
    
    # Requirement 3: Construct the Equity Curve (compounded linear returns)
    # Cumulative sum of log returns, then exponential transformation
    df['Equity_Curve'] = np.exp(df['Strategy_Returns'].cumsum())
    
    # Requirement 4: Calculate Running Peak using .cummax()
    # Tracks the highest point reached so far
    df['Running_Peak'] = df['Equity_Curve'].cummax()
    
    # Requirement 5: Calculate Drawdown
    df['Drawdown'] = (df['Equity_Curve'] / df['Running_Peak']) - 1
    
    # Requirement 6: Identify Maximum Drawdown
    max_drawdown = df['Drawdown'].min()
    
    return df, max_drawdown

# Execute the return and MDD calculation
df_e2, mdd = calculate_returns_and_mdd(df_e1.copy())
# print(f"Maximum Drawdown: {mdd*100:.2f}%")
# print(df_e2[['Close', 'Strategy_Returns', 'Equity_Curve', 'Drawdown']].tail())


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import pandas as pd
import numpy as np

# --- 1. Data Generation and Setup ---
np.random.seed(42) # Ensure reproducible results
data_points = 252 # Simulating one year of business days
initial_price = 100.0

# Generate daily returns (mean 0.05%, standard deviation 1%)
daily_returns = np.random.normal(0.0005, 0.01, data_points)

# Convert returns to prices using cumulative product
prices = initial_price * (1 + daily_returns).cumprod()

# Create date index for business days
dates = pd.date_range(start='2023-01-01', periods=data_points, freq='B')
df = pd.DataFrame({'Close': prices}, index=dates)

# --- 2. Vectorized Indicator Calculation ---
# Calculate the 10-day Simple Moving Average (Fast line)
df['SMA_10'] = df['Close'].rolling(window=10).mean()

# Calculate the 50-day Simple Moving Average (Slow line)
df['SMA_50'] = df['Close'].rolling(window=50).mean()

# --- 3. Vectorized Signal Generation ---
# Strategy Condition: Buy (1.0) if SMA_10 > SMA_50, otherwise Flat (0.0).
# np.where performs a fast, element-wise conditional check across the entire column.
df['Signal'] = np.where(df['SMA_10'] > df['SMA_50'], 1.0, 0.0)

# --- 4. Handling Lag and Position Entry ---
# The signal generated on day T dictates the position held on day T+1.
# We shift the signal down by one row to simulate entry at tomorrow's open/close.
df['Position'] = df['Signal'].shift(1).fillna(0.0)

# --- 5. Calculating Base Returns ---
# Calculate the percentage change (daily return) of the underlying asset.
df['Daily_Return'] = df['Close'].pct_change()

# --- 6. Calculating Strategy Returns (The Core Vectorization Step) ---
# Strategy Return = Position * Daily_Return
# This multiplication vectorizes the P&L calculation: if Position=1, we keep the return; if 0, return is zero.
df['Strategy_Return'] = df['Position'] * df['Daily_Return']

# --- 7. Calculating Equity Curve ---
# Calculate the cumulative compounded returns, starting from an initial value of 1.
df['Equity_Curve'] = (1 + df['Strategy_Return']).cumprod()

# --- 8. Output ---
print("--- Vectorized Backtest Results (First 60 Rows) ---")
# Displaying the first 60 rows to show the initial NaN values filling up
print(df[['Close', 'SMA_10', 'SMA_50', 'Position', 'Daily_Return', 'Strategy_Return', 'Equity_Curve']].head(60).to_markdown(numalign="left", stralign="left"))

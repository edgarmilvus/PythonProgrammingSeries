
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import datetime
from dataclasses import dataclass
from typing import List, Optional, Literal
import time
import random

# --- 1. Data Structures: Defining the Pipeline Objects ---

@dataclass
class NewsEvent:
    """Represents a single piece of financial news with metadata."""
    asset: str
    headline: str
    timestamp: datetime.datetime
    source: str

@dataclass
class SentimentSignal:
    """Stores the analyzed sentiment score and the resulting trade action."""
    score: float
    action: Literal['LONG', 'SHORT', 'HOLD']
    signal_time: datetime.datetime
    decay_hours: int = 4 # Define how long the signal remains potentially valid

# --- 2. Core Components: Simulation and Analysis ---

class SimulatedNewsFeed:
    """Simulates fetching real-time news for a specific asset (e.g., AAPL)."""
    def fetch_recent_news(self, asset: str) -> List[NewsEvent]:
        now = datetime.datetime.now()
        # Mock data designed to trigger specific strong signals
        mock_news = [
            ("Analyst upgrades AAPL target; strong outlook.", 0.85), 
            ("AAPL faces minor supply chain hiccup.", -0.3),     
            ("Market awaits next earnings report.", 0.05),       
            ("Revolutionary chip design leaked: massive upside.", 0.95), 
        ]
        
        events = []
        for i, (headline, _) in enumerate(mock_news):
            # Stagger timestamps for realism
            event_time = now - datetime.timedelta(minutes=15 * (len(mock_news) - i))
            events.append(NewsEvent(asset, headline, event_time, "Reuters/Bloomberg"))
        return events

class SimpleSentimentAnalyzer:
    """Simulates NLP analysis (e.g., VADER or fine-tuned BERT).
       Uses keyword mapping to generate a score between -1.0 and 1.0."""
    
    SENTIMENT_MAP = {
        "upgrade": 0.85, "strong": 0.7, "revolution": 0.9,
        "hiccup": -0.3, "leak": 0.95, "awaits": 0.05,
    }

    def analyze(self, headline: str) -> float:
        score = 0.0
        # Check keywords and apply simulated scores
        for keyword, s_score in self.SENTIMENT_MAP.items():
            if keyword in headline.lower():
                score += s_score
        
        # Clamp score to the standard sentiment range
        return max(-1.0, min(1.0, score))

# --- 3. The Rules Engine and Signal Decay Management (Core Logic) ---

class SentimentSignalEngine:
    """Translates raw sentiment scores into actionable signals,
       managing thresholds and signal persistence/decay."""
    
    def __init__(self, long_threshold: float = 0.7, short_threshold: float = -0.7):
        self.long_threshold = long_threshold
        self.short_threshold = short_threshold
        self.active_signal: Optional[SentimentSignal] = None

    def generate_signal(self, news_event: NewsEvent, sentiment_score: float) -> SentimentSignal:
        
        action: Literal['LONG', 'SHORT', 'HOLD'] = 'HOLD'
        
        # Apply the explicit rules engine thresholds
        if sentiment_score >= self.long_threshold:
            action = 'LONG'
        elif sentiment_score <= self.short_threshold:
            action = 'SHORT'
            
        new_signal = SentimentSignal(
            score=sentiment_score,
            action=action,
            signal_time=datetime.datetime.now()
        )
        
        # Only update the active signal if the new signal is actionable AND stronger
        if action != 'HOLD':
            if self.active_signal is None or abs(sentiment_score) > abs(self.active_signal.score):
                self.active_signal = new_signal
                print(f"[ENGINE] New stronger signal generated: {action} ({sentiment_score:.2f}) from '{news_event.headline[:20]}...'")
        
        return new_signal

    def check_decay(self) -> Optional[SentimentSignal]:
        """Determines if the currently active signal has passed its validity window."""
        if self.active_signal:
            # Calculate the time the signal becomes irrelevant
            expiration_time = self.active_signal.signal_time + datetime.timedelta(hours=self.active_signal.decay_hours)
            
            if datetime.datetime.now() > expiration_time:
                print(f"[DECAY] Signal {self.active_signal.action} (Score: {self.active_signal.score:.2f}) has expired.")
                self.active_signal = None
                return None
            return self.active_signal
        return None

# --- 4. Execution Simulation ---

class SimulatedTradeExecutor:
    """Simulates linking the signal to a trading API for order placement."""
       
    def __init__(self, cash_balance: float = 10000.0):
        self.cash_balance = cash_balance
        self.position = 0 # Net shares held (positive for long, negative for short)

    def execute_order(self, asset: str, signal: SentimentSignal):
        # Only execute if the signal is strong and actionable
        if signal.action == 'LONG' and signal.score > 0.75:
            shares_to_buy = 10
            self.position += shares_to_buy
            self.cash_balance -= shares_to_buy * 150 # Mock execution price
            print(f"--- EXECUTED LONG ORDER: Bought {shares_to_buy} {asset}.")
            print(f"    New Position: {self.position} shares. Remaining Cash: ${self.cash_balance:.2f}")
        
        elif signal.action == 'SHORT' and signal.score < -0.75:
            shares_to_sell = 10
            self.position -= shares_to_sell
            self.cash_balance += shares_to_sell * 150 # Proceeds from short sale
            print(f"--- EXECUTED SHORT ORDER: Sold short {shares_to_sell} {asset}.")
            print(f"    New Position: {self.position} shares. Remaining Cash: ${self.cash_balance:.2f}")
            
        elif signal.action == 'HOLD':
            print("--- EXECUTION: HOLD signal received. No order placed.")

# --- 5. Orchestration and Main Loop ---

def run_sentiment_pipeline(asset_ticker: str):
    """Orchestrates the entire sentiment-based trading pipeline."""
    
    print(f"Starting Sentiment Trading Pipeline for {asset_ticker}...")
    
    feed = SimulatedNewsFeed()
    analyzer = SimpleSentimentAnalyzer()
    # Define thresholds: 0.7 for LONG, -0.7 for SHORT
    engine = SentimentSignalEngine(long_threshold=0.7, short_threshold=-0.7) 
    executor = SimulatedTradeExecutor()

    # 1. Data Ingestion
    news_batch = feed.fetch_recent_news(asset_ticker)
    print(f"\n[STEP 1] Fetched {len(news_batch)} news items.")
    
    # 2. Analysis and Signal Generation
    for event in news_batch:
        sentiment = analyzer.analyze(event.headline)
        print(f"-> Analyzing '{event.headline[:40]}...': Score {sentiment:.2f}")
        
        # The engine processes the sentiment and updates its internal active signal 
        # based on strength and thresholds.
        engine.generate_signal(event, sentiment)
        
    # 3. Signal Validation and Decay Check
    active_signal = engine.check_decay()
    
    # 4. Final Execution Decision
    if active_signal and active_signal.action != 'HOLD':
        print(f"\n[STEP 4] Confirmed Actionable Signal: {active_signal.action} (Score: {active_signal.score:.2f})")
        executor.execute_order(asset_ticker, active_signal)
    else:
        print("\n[STEP 4] No strong, non-decayed signal found.")
        executor.execute_order(asset_ticker, SentimentSignal(0.0, 'HOLD', datetime.datetime.now()))

if __name__ == '__main__':
    # --- Run 1: Full Pipeline Execution ---
    run_sentiment_pipeline("AAPL")
    
    # --- Run 2: Demonstrating Signal Decay ---
    print("\n" + "="*50)
    print("DEMONSTRATING SIGNAL DECAY LOGIC")
    print("="*50)
    
    # Instantiate a fresh engine for the decay test
    engine_decay_test = SentimentSignalEngine()
    
    # Manually set an actionable signal that is 5 hours old (decay_hours is 4)
    old_signal_time = datetime.datetime.now() - datetime.timedelta(hours=5)
    engine_decay_test.active_signal = SentimentSignal(
        score=0.8, action='LONG', signal_time=old_signal_time, decay_hours=4
    )
    
    print(f"Manually set a LONG signal (Score 0.8) generated at: {old_signal_time.strftime('%H:%M:%S')}")
    print(f"Current time: {datetime.datetime.now().strftime('%H:%M:%S')}")
    print(f"Checking 5-hour old signal against 4-hour decay window...")
    
    # Running the decay check should now return None
    decayed_signal = engine_decay_test.check_decay()
    
    if decayed_signal is None:
        print("SUCCESS: The signal has been correctly marked as expired and removed.")
    else:
        print("FAILURE: Signal should have expired but remains active.")

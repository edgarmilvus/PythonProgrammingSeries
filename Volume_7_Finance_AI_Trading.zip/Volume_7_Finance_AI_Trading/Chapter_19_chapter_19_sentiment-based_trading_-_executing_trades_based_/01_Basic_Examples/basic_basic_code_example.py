
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import time
import math

# ====================================================================
# 1. CONFIGURATION PARAMETERS
# ====================================================================

# Define the minimum score required to trigger a trade action.
LONG_THRESHOLD = 0.65
SHORT_THRESHOLD = -0.65

# Define the decay rate. This is the percentage of confidence lost per minute.
# A rate of 0.02 means 2% of the signal's relevance is lost every minute.
DECAY_RATE_PER_MINUTE = 0.02 

# Minimum required final weight (confidence) to execute a trade.
MIN_ACTION_WEIGHT = 0.10 

# ====================================================================
# 2. CORE RULES ENGINE FUNCTION
# ====================================================================

def analyze_sentiment_and_generate_signal(score: float, time_elapsed_minutes: int) -> tuple[str, float]:
    """
    Translates a raw sentiment score into a trading signal (LONG/SHORT/HOLD) 
    and applies temporal decay to calculate the final actionable weight.
    
    :param score: The raw sentiment score (-1.0 to 1.0).
    :param time_elapsed_minutes: How long ago the news was processed.
    :return: A tuple containing the signal (str) and the final weight (float).
    """
    signal = "HOLD"
    base_confidence = 0.0

    # --- Step 1: Determine Base Signal and Initial Confidence ---
    
    if score >= LONG_THRESHOLD:
        signal = "LONG"
        # Normalize confidence: 0.0 when score hits threshold, 1.0 when score hits 1.0
        # Example: (0.85 - 0.65) / (1.0 - 0.65) = 0.20 / 0.35 = 0.5714
        base_confidence = min(1.0, (score - LONG_THRESHOLD) / (1.0 - LONG_THRESHOLD))
    
    elif score <= SHORT_THRESHOLD:
        signal = "SHORT"
        # Use absolute values for symmetry in calculation
        # Example: (-0.85 - (-0.65)) -> abs(0.20) / abs(0.35) = 0.5714
        base_confidence = min(1.0, (abs(score) - abs(SHORT_THRESHOLD)) / (1.0 - abs(SHORT_THRESHOLD)))
    
    else:
        # If score is in the neutral zone, exit immediately with HOLD
        return signal, 0.0

    # --- Step 2: Apply Time Decay (Linear Model) ---
    
    # Calculate the total confidence loss based on time and rate
    confidence_loss = time_elapsed_minutes * DECAY_RATE_PER_MINUTE
    
    # Calculate the remaining decay factor
    decay_factor = 1.0 - confidence_loss
    
    # If the decay factor is zero or negative, the signal is entirely stale
    if decay_factor <= 0.0:
        return "HOLD", 0.0

    # --- Step 3: Calculate Final Weighted Confidence ---
    final_weight = base_confidence * decay_factor
    
    # --- Step 4: Final Actionability Check ---
    
    if final_weight < MIN_ACTION_WEIGHT:
         # Signal strength has decayed below the minimum threshold
         return "HOLD", 0.0

    return signal, round(final_weight, 4)

# ====================================================================
# 3. SIMULATION SCENARIOS
# ====================================================================

print("--- Sentiment-Based Trading Signal Engine Simulation ---")

# Scenario A: Highly Positive, Very Fresh
sentiment_a = 0.90
time_a = 2 
signal_a, weight_a = analyze_sentiment_and_generate_signal(sentiment_a, time_a)
print(f"\n[A] Input Score: {sentiment_a}, Time Elapsed: {time_a} min")
print(f"Result: Signal={signal_a}, Weight={weight_a}")
# Expected: High base confidence, minimal decay -> Strong LONG

# Scenario B: Marginally Negative, Fresh
sentiment_b = -0.68
time_b = 5 
signal_b, weight_b = analyze_sentiment_and_generate_signal(sentiment_b, time_b)
print(f"\n[B] Input Score: {sentiment_b}, Time Elapsed: {time_b} min")
print(f"Result: Signal={signal_b}, Weight={weight_b}")
# Expected: Low base confidence, slight decay -> Weak SHORT

# Scenario C: Neutral Zone
sentiment_c = 0.40
time_c = 1 
signal_c, weight_c = analyze_sentiment_and_generate_signal(sentiment_c, time_c)
print(f"\n[C] Input Score: {sentiment_c}, Time Elapsed: {time_c} min")
print(f"Result: Signal={signal_c}, Weight={weight_c}")
# Expected: HOLD, 0.0 weight

# Scenario D: Strong Signal, Highly Stale
sentiment_d = 0.99
time_d = 35 # 35 minutes * 0.02 decay = 0.70 loss. 
signal_d, weight_d = analyze_sentiment_and_generate_signal(sentiment_d, time_d)
print(f"\n[D] Input Score: {sentiment_d}, Time Elapsed: {time_d} min")
print(f"Result: Signal={signal_d}, Weight={weight_d}")
# Expected: Decay factor (1 - 0.70) = 0.30. Base confidence is ~1.0. Final weight ~0.30.

# Scenario E: Completely Stale Signal
sentiment_e = -0.99
time_e = 55 # 55 minutes * 0.02 decay = 1.10 loss. 
signal_e, weight_e = analyze_sentiment_and_generate_signal(sentiment_e, time_e)
print(f"\n[E] Input Score: {sentiment_e}, Time Elapsed: {time_e} min")
print(f"Result: Signal={signal_e}, Weight={weight_e}")
# Expected: Decay factor <= 0.0 -> HOLD, 0.0

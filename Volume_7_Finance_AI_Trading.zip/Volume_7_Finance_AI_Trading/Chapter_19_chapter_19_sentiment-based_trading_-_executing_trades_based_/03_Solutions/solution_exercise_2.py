
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import time
import math
from dataclasses import dataclass
from typing import List, Dict

# 1. Signal Structure
@dataclass
class ActiveSignal:
    asset_ticker: str
    sentiment_score: float
    generation_timestamp: float  # Unix timestamp (seconds)
    decay_rate_minutes: float    # Half-life in minutes

class SignalManager:
    def __init__(self):
        # Stores signals: {'TICKER': [ActiveSignal1, ActiveSignal2, ...]}
        self.active_signals: Dict[str, List[ActiveSignal]] = {}
        self.MIN_MAGNITUDE_THRESHOLD = 0.05  # Prune signals below 5% of original magnitude

    def add_signal(self, signal: ActiveSignal):
        """Adds a new signal to the active list for the asset."""
        if signal.asset_ticker not in self.active_signals:
            self.active_signals[signal.asset_ticker] = []
        self.active_signals[signal.asset_ticker].append(signal)

    # 2. Exponential Decay Function
    def calculate_decayed_score(self, signal: ActiveSignal, current_time: float) -> float:
        """
        Calculates the decayed score using the model: Score * e^(-t / T), 
        where t is elapsed time in minutes and T is the decay rate (half-life).
        """
        elapsed_seconds = current_time - signal.generation_timestamp
        elapsed_minutes = elapsed_seconds / 60.0

        T = signal.decay_rate_minutes
        
        if T <= 0:
            return signal.sentiment_score

        # Calculate decay factor
        decay_factor = math.exp(-elapsed_minutes / T)
        
        return signal.sentiment_score * decay_factor

    # 3. Effective Score Calculation
    def get_effective_score(self, asset_ticker: str) -> float:
        """
        Calculates the weighted average of all active, decayed signals for an asset 
        and prunes signals below the magnitude threshold.
        """
        if asset_ticker not in self.active_signals or not self.active_signals[asset_ticker]:
            return 0.0

        current_time = time.time()
        
        decayed_scores = []
        signals_to_keep = []
        
        # Iterate and calculate decay
        for signal in self.active_signals[asset_ticker]:
            initial_magnitude = abs(signal.sentiment_score)
            decayed_score = self.calculate_decayed_score(signal, current_time)
            decayed_magnitude = abs(decayed_score)
            
            # Pruning logic: check if signal is still relevant
            if decayed_magnitude >= (initial_magnitude * self.MIN_MAGNITUDE_THRESHOLD):
                decayed_scores.append(decayed_score)
                signals_to_keep.append(signal)
            
        # 4. Pruning and Aggregation
        self.active_signals[asset_ticker] = signals_to_keep
        
        if not decayed_scores:
            return 0.0
            
        # Return the average of the remaining active decayed scores
        return sum(decayed_scores) / len(decayed_scores)

# Example Test Case (requires time progression for real decay effect)
# manager = SignalManager()
# signal = ActiveSignal('GOOG', 0.8, time.time(), 30)
# manager.add_signal(signal)
# # time.sleep(1800) # Simulate 30 minutes
# # print(manager.get_effective_score('GOOG')) # Score should be approx 0.8 * e^(-1) = 0.294


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from enum import Enum

class Signal(Enum):
    LONG = 'LONG'
    SHORT = 'SHORT'
    HOLD = 'HOLD'
    NO_TRADE = 'NO_TRADE'

class SentimentRulesEngine:
    # 1. Define Thresholds
    HIGH_CONVICTION_LONG = 0.80
    LOW_CONVICTION_LONG = 0.45
    HIGH_CONVICTION_SHORT = -0.80
    LOW_CONVICTION_SHORT = -0.45
    MIN_CONFIDENCE_METRIC = 5  # Minimum required articles/data volume
    HOLD_DEAD_ZONE = 0.15      # Sentiment scores between -0.15 and 0.15 default to HOLD

    def generate_signal(self, sentiment_score: float, confidence_metric: int) -> Signal:
        """
        Translates sentiment score and confidence into a trading signal based on conviction rules.
        """
        # 3. Incorporate Confidence Filtering
        if confidence_metric < self.MIN_CONFIDENCE_METRIC:
            return Signal.NO_TRADE

        # 4. Signal Prioritization Logic
        
        # 1. High Conviction Check (Overrides all others)
        if sentiment_score >= self.HIGH_CONVICTION_LONG:
            return Signal.LONG
        if sentiment_score <= self.HIGH_CONVICTION_SHORT:
            return Signal.SHORT

        # 2. Check for the central HOLD/Dead Zone
        if abs(sentiment_score) <= self.HOLD_DEAD_ZONE:
            return Signal.HOLD

        # 3. Low Conviction Check
        if sentiment_score >= self.LOW_CONVICTION_LONG:
            # Score is between LOW_CONVICTION_LONG and HIGH_CONVICTION_LONG
            return Signal.LONG

        if sentiment_score <= self.LOW_CONVICTION_SHORT:
            # Score is between HIGH_CONVICTION_SHORT and LOW_CONVICTION_SHORT
            return Signal.SHORT

        # 4. Default Safe Action (Scores that fall between the dead zone and low conviction)
        return Signal.HOLD

# Example Test Case:
engine = SentimentRulesEngine()
# print(engine.generate_signal(0.50, 7)) # LONG (Low Conviction)
# print(engine.generate_signal(0.02, 10)) # HOLD (Dead Zone)
# print(engine.generate_signal(0.95, 2)) # NO_TRADE (Low Confidence)

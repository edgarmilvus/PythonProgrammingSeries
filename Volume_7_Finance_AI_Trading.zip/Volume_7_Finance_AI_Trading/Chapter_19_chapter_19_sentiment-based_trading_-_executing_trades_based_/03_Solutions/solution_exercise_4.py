
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from flask import Flask, jsonify, abort

# 1. Mock Data Source
MOCK_SENTIMENT_DATA = {
    'AAPL': 0.65,
    'TSLA': -0.42,
    'GOOG': 0.11,
    'MSFT': 0.78
}

# 2. Define the Flask Application
app = Flask(__name__)

# Optional: Custom error handler for 404 to ensure JSON output
@app.errorhandler(404)
def not_found(error):
    # Flask error handlers receive the HTTPException object
    return jsonify({
        "status": "error",
        "message": str(error)
    }), 404

# 3. Implement the Dynamic Route
@app.route('/sentiment/<string:ticker>', methods=['GET'])
def get_asset_sentiment(ticker):
    """
    4. Lookup Logic: Retrieves the sentiment score dynamically based on the ticker.
    """
    # Standardize ticker lookup
    ticker = ticker.upper()
    
    score = MOCK_SENTIMENT_DATA.get(ticker)
    
    if score is None:
        # 5. Error Handling: Return 404 Not Found
        abort(404, description=f"Asset sentiment data not found for ticker: {ticker}")
    
    # 6. Response Format: Return standardized JSON
    response = {
        "ticker": ticker,
        "sentiment_score": score,
        "status": "success"
    }
    return jsonify(response)

# Example run block (commented out for execution environment, but necessary for testing)
# if __name__ == '__main__':
#     app.run(debug=True, port=5000)

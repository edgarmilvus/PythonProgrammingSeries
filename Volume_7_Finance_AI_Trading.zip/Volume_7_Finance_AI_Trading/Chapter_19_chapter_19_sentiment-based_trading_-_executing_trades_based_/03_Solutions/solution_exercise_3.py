
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import random
import time
from typing import Any, Dict

# Define custom exception
class APIExecutionError(Exception):
    """Custom exception for simulated trading API failures."""
    pass

# Mock Database Session (Simulating SQLAlchemy Transaction Handling)
class MockDBSession:
    def __init__(self):
        self.log = []
        self.in_transaction = False

    def add(self, record: Dict[str, Any]) -> int:
        """Simulates inserting a record into the pending transaction log."""
        if not self.in_transaction:
            raise RuntimeError("Transaction must be explicitly started.")
        record['id'] = len(self.log) + 1
        self.log.append(record)
        return record['id']

    def update(self, record_id: int, status: str):
        """Simulates updating a record status."""
        if 0 < record_id <= len(self.log):
            self.log[record_id - 1]['status'] = status

    def begin(self):
        """Starts a transaction block."""
        self.in_transaction = True

    def commit(self):
        """Commits changes (makes them permanent)."""
        self.in_transaction = False

    def rollback(self):
        """Discards changes made since begin(). For mock, we remove the last pending entry."""
        if self.log and self.log[-1]['status'] == 'PENDING':
            self.log.pop()
        self.in_transaction = False
        print("DB: Transaction Rolled Back.")

# 1. Simulated API Function
def execute_order(ticker: str, signal_type: str, quantity: int) -> str:
    """Simulates placing an order (80% success rate)."""
    print(f"API: Attempting {signal_type} order for {quantity} shares of {ticker}...")
    
    if random.random() < 0.20: # 20% chance of failure
        raise APIExecutionError(f"API Error: Failed to execute order for {ticker}.")
    
    transaction_id = f"TRX-{random.randint(10000, 99999)}"
    return transaction_id

# 2. Core Execution Function
def process_and_execute_signal(signal_data: Dict[str, Any], db_session: MockDBSession) -> str:
    ticker = signal_data['ticker']
    signal_type = signal_data['signal']
    quantity = signal_data['quantity']
    log_id = None
    
    try:
        # Initiate the transactional block
        db_session.begin()
        
        # Insert PENDING record
        pending_record = {
            'ticker': ticker,
            'signal': signal_type,
            'quantity': quantity,
            'status': 'PENDING',
            'timestamp': time.time()
        }
        log_id = db_session.add(pending_record)
        print(f"DB: Log ID {log_id} inserted as PENDING.")

        # Attempt API execution
        transaction_id = execute_order(ticker, signal_type, quantity)
        
        # If successful, update status and commit
        db_session.update(log_id, 'EXECUTED')
        db_session.commit()
        print(f"DB: Log ID {log_id} updated to EXECUTED. Transaction committed.")
        
        return transaction_id

    # 3. Error Handling and Rollback
    except APIExecutionError as e:
        print(f"Execution Failed: {e}")
        # Ensure rollback if the transaction is still active
        if db_session.in_transaction:
            db_session.rollback()
        return f"ERROR: API execution failed for {ticker}."
        
    except Exception as e:
        # Handle critical DB errors
        print(f"CRITICAL SYSTEM ERROR: {e}")
        if db_session.in_transaction:
            db_session.rollback()
        raise

# Example Usage
mock_db = MockDBSession()
test_signal = {'ticker': 'TSLA', 'signal': 'LONG', 'quantity': 10}

print("\n--- Running multiple attempts ---")
process_and_execute_signal(test_signal, mock_db)
process_and_execute_signal(test_signal, mock_db)
process_and_execute_signal(test_signal, mock_db)

print("\n--- Final Committed DB Log ---")
print(mock_db.log)

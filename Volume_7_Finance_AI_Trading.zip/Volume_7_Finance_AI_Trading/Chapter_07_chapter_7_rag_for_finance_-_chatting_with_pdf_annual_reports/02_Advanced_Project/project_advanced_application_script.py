
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
from dotenv import load_dotenv
from langchain_community.document_loaders import TextLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_openai import ChatOpenAI
from langchain.chains import RetrievalQA

# --- 1. Configuration and Setup ---

# Load environment variables (API key)
load_dotenv()
os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY", "YOUR_DUMMY_KEY")

# Define persistence directory for the vector store
PERSIST_DIR = "./finance_rag_db"

# --- 2. Simulated 10-K Data ---

# Simulate two distinct 10-K filings with critical sections
REPORT_DATA = [
    {
        "ticker": "AAPL",
        "year": 2023,
        "content": (
            "Risk Factors: Supply chain disruption remains a primary risk due to geopolitical instability. "
            "We are investing heavily in services and subscription models to diversify revenue streams. "
            "Capital expenditures focused primarily on data centers and R&D facilities, totaling $12B."
        ),
    },
    {
        "ticker": "MSFT",
        "year": 2023,
        "content": (
            "Risk Factors: Regulatory scrutiny in the cloud computing sector poses a significant challenge. "
            "Strategic Focus: Our priority is the integration of generative AI across all product lines, "
            "especially Azure and Office 365. Capital expenditures for the year reached $15B, "
            "focused on expanding global cloud infrastructure capacity."
        ),
    },
]

# --- 3. Indexing Pipeline Functions ---

def load_and_chunk_data(data_list: list):
    """Loads simulated documents and splits them into chunks with metadata."""
    documents = []
    for item in data_list:
        # Create a dummy file for TextLoader simulation
        temp_file = f"{item['ticker']}_{item['year']}.txt"
        with open(temp_file, "w") as f:
            f.write(item['content'])
            
        # Use TextLoader to load and assign metadata
        loader = TextLoader(temp_file)
        doc = loader.load()[0]
        doc.metadata.update({"ticker": item['ticker'], "year": item['year']})
        documents.append(doc)
        os.remove(temp_file) # Clean up temporary file

    # Initialize the Recursive splitter optimized for dense text
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=50,
        length_function=len,
        separators=["\n\n", "\n", ".", " ", ""]
    )
    
    # Split the documents
    chunks = text_splitter.split_documents(documents)
    print(f"Successfully processed {len(documents)} documents into {len(chunks)} chunks.")
    return chunks

def create_or_load_vector_store(chunks):
    """Initializes embeddings and creates/loads the Chroma vector store."""
    if os.path.exists(PERSIST_DIR):
        print(f"Loading existing vector store from {PERSIST_DIR}...")
        embedding_function = OpenAIEmbeddings(model="text-embedding-3-small")
        vectorstore = Chroma(
            persist_directory=PERSIST_DIR,
            embedding_function=embedding_function
        )
    else:
        print(f"Creating new vector store at {PERSIST_DIR}...")
        # Use a high-quality, cost-effective embedding model
        embedding_function = OpenAIEmbeddings(model="text-embedding-3-small")
        vectorstore = Chroma.from_documents(
            documents=chunks,
            embedding=embedding_function,
            persist_directory=PERSIST_DIR
        )
        vectorstore.persist()
        print("Vector store creation complete and persisted.")
        
    return vectorstore

# --- 4. RAG Query Execution ---

def execute_comparative_query(vectorstore, query):
    """Sets up the RetrievalQA chain and executes the financial query."""
    
    # Initialize the LLM (using a capable model for complex reasoning)
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.1)
    
    # Configure the Retriever: retrieves the top 3 most relevant chunks
    retriever = vectorstore.as_retriever(search_kwargs={"k": 3})
    
    # Create the Retrieval-Augmented Generation Chain
    qa_chain = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff", # Puts all retrieved documents into the context
        retriever=retriever,
        return_source_documents=True # Critical for verifying grounding
    )
    
    # Execute the chain
    result = qa_chain.invoke({"query": query})
    
    return result

# --- 5. Main Execution ---

if __name__ == "__main__":
    # 1. Indexing Phase
    processed_chunks = load_and_chunk_data(REPORT_DATA)
    db = create_or_load_vector_store(processed_chunks)

    # 2. Query Definition
    financial_query = (
        "Compare the primary strategic focus and the total capital expenditures "
        "for both AAPL and MSFT based solely on the provided 2023 annual reports. "
        "Which company prioritized infrastructure expansion?"
    )

    print("\n--- Executing Comparative RAG Query ---")
    print(f"Query: {financial_query}")
    
    # 3. Execution Phase
    query_result = execute_comparative_query(db, financial_query)
    
    # 4. Output Results
    print("\n--- RAG Response ---")
    print(query_result['result'])
    
    print("\n--- Source Documents Used (Grounding Verification) ---")
    for i, doc in enumerate(query_result['source_documents']):
        print(f"Source {i+1} (Ticker: {doc.metadata.get('ticker', 'N/A')}):")
        print(f"Content Snippet: '{doc.page_content[:100]}...'")
        print("-" * 20)


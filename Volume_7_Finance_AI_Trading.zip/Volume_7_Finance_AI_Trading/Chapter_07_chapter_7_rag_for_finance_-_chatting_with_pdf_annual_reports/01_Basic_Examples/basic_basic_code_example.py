
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import os
import shutil
from langchain_core.documents import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings

# --- Configuration ---
CHROMA_DB_PATH = "./chroma_db_finance_rag_basic"

# --- 1. Simulate Document Loading (The Unstructured 10-K Data) ---
# This text simulates a long passage from the Risk Factors and MD&A sections.
financial_report_text = (
    "Section 1A. Risk Factors: Our reliance on third-party suppliers for key components "
    "presents a significant operational risk. If these suppliers face disruptions, "
    "our production capacity will be severely impacted, potentially leading to revenue shortfalls. "
    "This risk is particularly acute for our 'Alpha-Gen' product line, which accounts for 65% of Q4 revenue. "
    "Furthermore, our primary product line, 'Alpha-Gen', faces increasing competition "
    "from innovative startups in the Q3 2024 period, which may necessitate increased R&D spending. "
    "Section 7. Management's Discussion and Analysis: Revenue increased by 15% year-over-year, "
    "driven primarily by strong international sales, especially in the APAC region. "
    "Operating expenses remained stable at 40% of revenue. The company maintains a "
    "healthy cash reserve of $500 million, earmarked for potential strategic acquisitions. "
    "The board approved a $100 million stock buyback program effective January 1, 2025."
)

# Convert the raw string into a LangChain Document object
# Metadata is crucial for traceability (source attribution).
documents = [
    Document(
        page_content=financial_report_text,
        metadata={"source": "2024_Annual_Report.pdf", "section": "Risk Factors & MD&A"}
    )
]

# --- Cleanup for Reproducibility ---
if os.path.exists(CHROMA_DB_PATH):
    shutil.rmtree(CHROMA_DB_PATH)
    print(f"Cleaned up existing directory: {CHROMA_DB_PATH}")


# --- 2. Chunking: Preparing the text for embedding ---
# We optimize the splitter for semantic coherence over arbitrary length.
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=250,  # Max characters per chunk
    chunk_overlap=30, # Overlap ensures context is preserved across boundaries
    length_function=len,
    separators=["\n\n", "\n", " ", ""] # Order of separators matters for logical splitting
)

# Split the document into chunks
chunks = text_splitter.split_documents(documents)

print(f"Total original length (chars): {len(financial_report_text)}")
print(f"Number of resulting chunks: {len(chunks)}")
print("-" * 60)


# --- 3. Embedding and Indexing (Vector Store Creation) ---

# Using a local Sentence Transformer model for embedding (no API key needed)
try:
    embeddings_model = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
except Exception as e:
    # Fallback in case the user environment cannot download the model
    class MockEmbeddings:
        def embed_documents(self, texts):
            return [[0.1] * 384 for _ in texts]
        def embed_query(self, text):
            return [0.5] * 384
    embeddings_model = MockEmbeddings()
    print("Warning: Using Mock Embeddings. Install 'sentence-transformers' for full functionality.")

# Create the Vector Store (Index) from the chunks
# Chroma calculates the vector for each chunk using the embeddings_model and stores it.
vectorstore = Chroma.from_documents(
    documents=chunks,
    embedding=embeddings_model,
    persist_directory=CHROMA_DB_PATH
)

# Force persistence to disk
vectorstore.persist()
print(f"Vector Store created and persisted at: {CHROMA_DB_PATH}")
print("-" * 60)


# --- 4. Retrieval: Querying the Vector Store ---

# The user's financial question
query = "What is the primary risk factor mentioned, and which product line is affected?"

# Perform a similarity search (k=3 retrieves the top 3 most relevant chunks)
# The query is first embedded, and then the vector store finds the nearest neighbors.
retrieved_docs = vectorstore.similarity_search(query, k=3)


# --- 5. Output: Displaying the Context for LLM Augmentation ---

print(f"User Query: '{query}'")
print("\n--- Retrieved Context Chunks (Ready for LLM Input) ---")

for i, doc in enumerate(retrieved_docs):
    print(f"\n[DOCUMENT {i+1}]")
    print(f"Source: {doc.metadata.get('source')}, Section: {doc.metadata.get('section')}")
    print(f"Content (Chunk Score: [Implied Similarity]):\n{doc.page_content}")

# Final cleanup
shutil.rmtree(CHROMA_DB_PATH)
print(f"\nSuccessfully cleaned up temporary directory: {CHROMA_DB_PATH}")

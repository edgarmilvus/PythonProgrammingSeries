
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from flask import Flask, render_template, request, Markup
# Assuming multi_hop_query, MockVectorStore, and MockLLMClient are imported from Ex 3
# We redefine the core components for self-containment:

# --- Setup Mocks for Flask Integration ---
class MockVectorStore:
    def similarity_search(self, question: str, k: int) -> List[Dict]:
        return MOCK_CHUNKS[:2]

class MockLLMClient:
    def generate(self, prompt: str):
        response_text = """
        {
            "answer": "The year-over-year change in Goodwill impairment charges was an increase of $30 million (from $120 million in 2022 to $150 million in 2023). This represents a 25% increase.",
            "sources": [
                "The Goodwill impairment charge for the fiscal year 2023 was $150 million, reported in Note 8.",
                "In comparison, the Goodwill impairment charge in 2022 was $120 million, detailed on page 12 of the notes."
            ]
        }
        """
        return response_text, {"input_tokens": 500, "output_tokens": 150}

# RAG_ENGINE setup (using the function from Ex 3)
def initialize_rag_system():
    return {
        "vector_store": MockVectorStore(),
        "llm_client": MockLLMClient(),
        "query_func": multi_hop_query # Assuming the function from Ex 3 is available
    }

RAG_ENGINE = initialize_rag_system()
app = Flask(__name__)

# --- Flask Routes ---

@app.route('/', methods=['GET'])
def home():
    # Render the input form
    return render_template('index.html')

@app.route('/query', methods=['POST'])
def handle_query():
    user_question = request.form.get('question')
    
    # Call the RAG engine function
    result_data = RAG_ENGINE['query_func'](
        user_question, 
        RAG_ENGINE['vector_store'], 
        RAG_ENGINE['llm_client']
    )
    
    # Pass result_data (containing 'answer' and 'sources') to the results template
    return render_template('results.html', 
                           question=user_question,
                           answer=result_data['answer'], 
                           sources=result_data['sources'])

# --- Jinja2 Template Content (Simulated Files) ---

# index.html content:
# <h1>Financial RAG Query Interface</h1>
# <form method="POST" action="/query">
#     <textarea name="question" placeholder="Ask a question about the 10-K filing..."></textarea>
#     <button type="submit">Submit Query</button>
# </form>

# results.html content:
# <h1>Query Results</h1>
# <h2>Question: {{ question }}</h2>
# 
# <h3>Synthesized Answer</h3>
# <div style="border: 1px solid #ccc; padding: 15px;">
#     <p>{{ answer }}</p>
# </div>
# 
# <h3>Verifiable Sources (Citations)</h3>
# {% if sources %}
#     {% for source in sources %}
#         <div style="background-color: #f0f0f0; margin-bottom: 10px; padding: 10px;">
#             <strong>Source Text:</strong> {{ source.text }}<br>
#             {% if source.metadata.page %}
#                 <small>Located on Page: {{ source.metadata.page }}</small>
#             {% endif %}
#         </div>
#     {% endfor %}
# {% else %}
#     <p>No verifiable sources were used for this answer.</p>
# {% endif %}

# Note: In a real environment, the templates would be saved in a 'templates/' directory.
# If __name__ == '__main__':
#     app.run(debug=True)

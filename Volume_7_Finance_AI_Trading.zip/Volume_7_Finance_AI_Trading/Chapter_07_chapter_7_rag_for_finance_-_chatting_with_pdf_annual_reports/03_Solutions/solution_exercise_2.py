
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os
import shutil

# --- Mock Components ---
# Mock the necessary RAG framework components
class MockEmbeddings:
    def embed_documents(self, texts): return [[0.1] * 10] * len(texts)
    def embed_query(self, text): return [0.1] * 10

class MockChromaDB:
    def __init__(self, persist_directory, embedding_function):
        self.persist_directory = persist_directory
        self.embedding_function = embedding_function
        # Simulate persistence check: if directory exists, load; otherwise, initialize.
        if os.path.exists(persist_directory):
            print(f"ChromaDB loaded existing index from: {persist_directory}")
        else:
            os.makedirs(persist_directory, exist_ok=True)
            print(f"ChromaDB initialized new persistent index at: {persist_directory}")
    def as_retriever(self): return self # Simplified mock retriever

class MockCloudDB:
    def __init__(self, index_name, api_key, environment):
        if not api_key or not environment:
            raise ConnectionError("Cloud DB connection failed: API Key or Environment is missing.")
        print(f"Successfully connected to Cloud DB ({environment}) for index: {index_name}")
    def as_retriever(self): return self

class VectorStoreManager:
    def __init__(self, embedding_model):
        self.embedding_model = embedding_model
        
    def initialize_db(self, index_name: str, db_path: str = "./chroma_db"):
        
        db_mode = os.environ.get("VECTOR_DB_MODE", "LOCAL")
        
        if db_mode == "CLOUD":
            # 1. Attempt connection using environment variables
            api_key = os.environ.get("PINECONE_API_KEY")
            environment = os.environ.get("PINECONE_ENVIRONMENT")
            
            try:
                # Mock Cloud connection (e.g., Pinecone or Weaviate)
                vector_store_instance = MockCloudDB(index_name, api_key, environment)
            except ConnectionError as e:
                print(f"ERROR: {e}. Falling back to LOCAL mode.")
                # Fallback or strict failure depending on production requirements
                vector_store_instance = MockChromaDB(db_path, self.embedding_model)
                
        else: # Default to LOCAL
            # 2. Initialize or load persistent ChromaDB
            vector_store_instance = MockChromaDB(db_path, self.embedding_model)
            
        return vector_store_instance

# --- Test Cases ---
embedding_model = MockEmbeddings()
manager = VectorStoreManager(embedding_model)

# 1. Test LOCAL mode (default)
os.environ["VECTOR_DB_MODE"] = "LOCAL"
db_local = manager.initialize_db("finance_index_local")
# Clean up mock directory for persistence test
if os.path.exists("./chroma_db"): shutil.rmtree("./chroma_db") 

# 2. Test CLOUD mode (missing keys - should fail/fallback)
os.environ["VECTOR_DB_MODE"] = "CLOUD"
os.environ["PINECONE_API_KEY"] = "" # Missing key
db_cloud_fail = manager.initialize_db("finance_index_cloud_fail")

# 3. Test CLOUD mode (successful mock connection)
os.environ["PINECONE_API_KEY"] = "mock_key_123"
os.environ["PINECONE_ENVIRONMENT"] = "aws-west-2"
db_cloud_success = manager.initialize_db("finance_index_cloud_success")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import json
from typing import List, Dict

# --- Mock Components (from Exercise 3 setup) ---
MOCK_CHUNKS = [
    {"text": "The Goodwill impairment charge for the fiscal year 2023 was $150 million, reported in Note 8.", "metadata": {"page": 15}},
    {"text": "In comparison, the Goodwill impairment charge in 2022 was $120 million, detailed on page 12 of the notes.", "metadata": {"page": 12}},
    {"text": "Revenue grew by 20% year-over-year.", "metadata": {"page": 5}},
]

class MockVectorStore:
    def similarity_search(self, question: str, k: int) -> List[Dict]:
        # Simulate retrieving the most relevant chunks for the test case
        if "Goodwill impairment" in question:
            return MOCK_CHUNKS[:2] # Return the two necessary chunks
        return MOCK_CHUNKS

class MockLLMClient:
    def generate(self, prompt: str):
        # Simulate LLM synthesizing the answer and returning a structured format
        if "Goodwill impairment" in prompt:
            response_text = """
            {
                "answer": "The year-over-year change in Goodwill impairment charges was an increase of $30 million (from $120 million in 2022 to $150 million in 2023). This represents a 25% increase, demonstrating a worsening asset valuation in 2023.",
                "sources": [
                    "The Goodwill impairment charge for the fiscal year 2023 was $150 million, reported in Note 8.",
                    "In comparison, the Goodwill impairment charge in 2022 was $120 million, detailed on page 12 of the notes."
                ]
            }
            """
            # Mock usage metadata for Exercise 5 integration
            return response_text, {"input_tokens": 500, "output_tokens": 150} 
        
        return '{"answer": "Generic Answer", "sources": ["Source 1"]}', {"input_tokens": 100, "output_tokens": 50}

# --- Core Functions ---

def build_advanced_prompt(question: str, retrieved_chunks: List[Dict]) -> str:
    """Constructs a prompt enforcing multi-hop reasoning and structured output."""
    context = "\n---\n".join([c['text'] for c in retrieved_chunks])
    
    system_instruction = (
        "You are a Senior Financial Analyst. Your task is to answer the user's question "
        "by synthesizing information from the provided context chunks. "
        "CRITICAL RULE: If the question requires comparing two distinct figures (multi-hop reasoning), "
        "you MUST explicitly quote the source chunks containing both figures before synthesizing the final answer. "
        "Output your response strictly in the following JSON format: "
        '{"answer": "Your synthesized response.", "sources": ["List of exact text snippets used to formulate the answer."]}'
    )
    
    prompt = (
        f"{system_instruction}\n\n"
        f"Context Chunks:\n{context}\n\n"
        f"User Question: {question}"
    )
    return prompt

def parse_and_verify_citations(raw_response: str, retrieved_chunks: List[Dict]) -> Dict:
    """Parses the LLM response and ensures citations match retrieved text."""
    try:
        structured_output = json.loads(raw_response)
    except json.JSONDecodeError:
        return {"answer": "Error: LLM failed to return valid JSON.", "sources": []}

    # Basic verification: Ensure cited sources actually came from retrieval set
    retrieved_texts = {c['text'] for c in retrieved_chunks}
    verified_sources = [
        source for source in structured_output.get('sources', []) 
        if source in retrieved_texts
    ]
    
    # Add metadata (like page number) back to the verified sources for better traceability
    source_map = {c['text']: c['metadata'] for c in retrieved_chunks}
    
    final_sources = []
    for source_text in verified_sources:
        metadata = source_map.get(source_text, {})
        final_sources.append({
            "text": source_text,
            "metadata": metadata
        })
        
    return {
        "answer": structured_output.get("answer", "No answer provided."),
        "sources": final_sources
    }

def multi_hop_query(question: str, vector_store, llm_client) -> dict:
    # 1. Retrieval step
    retrieved_chunks = vector_store.similarity_search(question, k=5)
    
    # 2. Advanced prompt construction
    prompt = build_advanced_prompt(question, retrieved_chunks)
    
    # 3. LLM call (returns raw response and mock usage metadata)
    raw_response, usage_metadata = llm_client.generate(prompt)
    
    # 4. Parsing and structuring the output
    structured_output = parse_and_verify_citations(raw_response, retrieved_chunks)
    
    # Include usage metadata for integration with Exercise 5
    structured_output['usage'] = usage_metadata
    
    return structured_output

# --- Test Case Execution ---
vector_store = MockVectorStore()
llm_client = MockLLMClient()
test_question = "What was the year-over-year change in Goodwill impairment charges, and where in the report are these figures detailed?"

result = multi_hop_query(test_question, vector_store, llm_client)

print(json.dumps(result, indent=4))

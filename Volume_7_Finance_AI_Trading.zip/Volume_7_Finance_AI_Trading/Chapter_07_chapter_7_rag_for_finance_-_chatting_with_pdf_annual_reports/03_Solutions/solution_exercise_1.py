
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from langchain.text_splitter import RecursiveCharacterTextSplitter
from typing import List
import random

# --- Mock Components ---
def document_loader(file_path: str) -> List[str]:
    """Mock loader returning structured financial text."""
    sample_10k_text = """
    Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations.

    Revenue: Our total consolidated revenue for the fiscal years ended December 31, 2023 and 2022 was as follows:
    
    | Category | 2023 (Millions) | 2022 (Millions) | Change (%) |
    |---|---|---|---|
    | Product Sales | 1,540.5 | 1,210.8 | 27.2% |
    | Service Fees | 320.1 | 290.5 | 10.2% |
    | **Total Revenue** | **1,860.6** | **1,501.3** | **23.9%** |
    
    This growth was primarily driven by the successful launch of our new platform in Q3 2023, which saw significant adoption in the North American market.

    Note 5 - Debt Covenants: The Company maintains a revolving credit facility. Key covenants include:
    
    1. Maintain a Debt-to-EBITDA ratio below 3.5x.
    2. Maintain minimum liquidity of $50 million.
    
    As of December 31, 2023, the Debt-to-EBITDA ratio was 2.9x (well below the threshold), indicating full compliance with all facility terms.
    """
    # Simulate loading the first 10 pages
    return [sample_10k_text] * 10

def load_and_split_documents(file_path: str, chunking_strategy: str) -> List[str]:
    documents = document_loader(file_path)
    # Join documents into one large text for splitting
    full_text = "\n\n".join(documents)
    
    if chunking_strategy == "ADVANCED_FINANCE":
        # Strategy: RecursiveCharacterTextSplitter for structural preservation
        # Chunk Size 768: Large enough to capture a full table or a dense paragraph block.
        # Overlap 100: Sufficient context overlap to ensure numerical data points 
        # (like table headers or preceding sentences) are not lost at the boundaries.
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=768,
            chunk_overlap=100,
            separators=["\n\n", "\n", " ", ""] # Prioritize splitting on large breaks
        )
        processed_chunks = text_splitter.split_text(full_text)
        
    elif chunking_strategy == "BASIC":
        # Basic splitter (fixed size, aggressive splitting)
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=100,
            chunk_overlap=20,
            separators=[""]
        )
        processed_chunks = text_splitter.split_text(full_text)
        
    return processed_chunks

# --- Verification ---
file_path = "sample_10k.pdf"
financial_chunks = load_and_split_documents(file_path, "ADVANCED_FINANCE")

print(f"Total chunks created: {len(financial_chunks)}")
print("\n--- 10 Randomly Selected Chunks (First 50 words) ---")

# Select 10 random chunks for verification
sample_indices = random.sample(range(len(financial_chunks)), min(10, len(financial_chunks)))

for i, index in enumerate(sample_indices):
    chunk = financial_chunks[index]
    snippet = " ".join(chunk.split()[:50])
    print(f"\nChunk {i+1}: {snippet}...")
    
# Expected output will show the table structure or the list structure intact within a single chunk.


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import time
import json
from typing import List, Dict

# --- Global Monitoring Variables ---
QUERY_LOG: List[float] = [] # Stores timestamps of successful queries
TOTAL_TOKENS_USED: int = 0 # Global integer counter for total tokens

# --- Mock Components (similar to Ex 3, ensuring LLM returns usage data) ---
class MockVectorStore:
    def similarity_search(self, question: str, k: int) -> List[Dict]:
        return MOCK_CHUNKS[:2]

class MockLLMClient:
    def generate(self, prompt: str):
        response_text = '{"answer": "Rate limit test answer.", "sources": ["Source 1"]}'
        # Mock usage metadata (input + output tokens)
        usage_metadata = {"input_tokens": 500, "output_tokens": 150}
        return response_text, usage_metadata

# --- Monitoring and Rate Limiting Functions ---

def check_rate_limit(max_queries: int = 5, window_seconds: int = 60) -> bool:
    """Removes old entries and checks if the remaining query count exceeds the limit."""
    global QUERY_LOG
    current_time = time.time()
    
    # 1. Filter out queries older than the window
    QUERY_LOG = [t for t in QUERY_LOG if t > current_time - window_seconds]
    
    # 2. Check limit
    if len(QUERY_LOG) >= max_queries:
        return False # Limit exceeded
    
    return True # Limit OK

def multi_hop_query_with_monitoring(question: str, vector_store, llm_client) -> dict:
    global TOTAL_TOKENS_USED
    global QUERY_LOG
    
    # 1. Basic Rate Limiting Check
    if not check_rate_limit():
        return {"error": "Rate limit exceeded. Maximum 5 queries allowed per 60 seconds.", "tokens_used": 0}
        
    # 2. Retrieval and Prompt Construction (simulated)
    retrieved_chunks = vector_store.similarity_search(question, k=5)
    # prompt = build_advanced_prompt(question, retrieved_chunks) # Assuming prompt building logic
    
    # 3. LLM Call and Token Capture
    raw_response, usage_metadata = llm_client.generate("Mock Prompt")
    
    input_tokens = usage_metadata.get('input_tokens', 0)
    output_tokens = usage_metadata.get('output_tokens', 0)
    total_tokens = input_tokens + output_tokens
    
    # 4. Update global integer counter
    TOTAL_TOKENS_USED += total_tokens
    
    # 5. Update QUERY_LOG with current timestamp (only after successful LLM call)
    QUERY_LOG.append(time.time())
    
    # 6. Parsing and structuring the output (simplified for this exercise)
    try:
        structured_output = json.loads(raw_response)
    except json.JSONDecodeError:
        structured_output = {"answer": "Parsing Error", "sources": []}
        
    structured_output['tokens_used'] = total_tokens
    
    return structured_output

# --- Test Case Execution (Demonstrating Rate Limit) ---
vector_store = MockVectorStore()
llm_client = MockLLMClient()

print("--- Testing Rate Limiting (5/60s) ---")
for i in range(7):
    result = multi_hop_query_with_monitoring(f"Query {i+1}", vector_store, llm_client)
    
    if "error" in result:
        print(f"Query {i+1}: FAILED. {result['error']}")
    else:
        print(f"Query {i+1}: SUCCESS. Tokens used: {result['tokens_used']}")
        
print(f"\nTOTAL TOKENS USED (Global Integer Counter): {TOTAL_TOKENS_USED}")

# --- Flask Endpoint Simulation for /metrics ---
# @app.route('/metrics', methods=['GET'])
# def metrics():
#     return jsonify({
#         "total_tokens_used": TOTAL_TOKENS_USED,
#         "current_query_count_in_window": len(QUERY_LOG)
#     })


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from transformers import pipeline

text_a = "The company is undergoing aggressive restructuring, involving significant layoffs, but analysts view this short-term pain as necessary for long-term operational efficiency."
text_b = "While the market is experiencing extreme volatility, the company's robust balance sheet provides a strong buffer against immediate downside risk."

def compare_models(text):
    # 1. Initialize two pipelines
    finbert_pipeline = pipeline(
        "sentiment-analysis",
        model="ProsusAI/finbert"
    )
    
    # Using a standard general-purpose sentiment model (DistilBERT SST-2)
    general_pipeline = pipeline(
        "sentiment-analysis",
        model="distilbert-base-uncased-finetuned-sst-2-english"
    )

    # Process text through both models
    finbert_result = finbert_pipeline(text)[0]
    general_result = general_pipeline(text)[0]

    print(f"\n--- Analyzing Text: '{text}' ---")
    
    print("\n[FinBERT (Domain-Specific)]")
    print(f"Label: {finbert_result['label']}, Score: {finbert_result['score']:.4f}")

    print("\n[General BERT (SST-2)]")
    print(f"Label: {general_result['label']}, Score: {general_result['score']:.4f}")
    
    return finbert_result, general_result

# Execution and Comparison
r_a_finbert, r_a_general = compare_models(text_a)
r_b_finbert, r_b_general = compare_models(text_b)

# 4. Analysis Commentary
analysis_a = (
    "FinBERT (likely Neutral or Positive) is more relevant for Text A. "
    "General models often prioritize strong negative words like 'layoffs' and classify the entire statement as Negative. FinBERT, trained on financial context, understands that 'necessary for long-term operational efficiency' is the overriding financial signal, leading to a more balanced or even positive classification."
)

analysis_b = (
    "FinBERT (likely Positive or Neutral) is more relevant for Text B. "
    "The general model focuses on the intense language ('extreme volatility') and classifies it as Negative. FinBERT correctly recognizes that the financial domain places high value on mitigating factors like a 'robust balance sheet' and 'strong buffer', offsetting the volatility risk."
)

print("\n\n=== Instructor Commentary on Results ===")
print(f"Text A Analysis:\n{analysis_a}")
print(f"\nText B Analysis:\n{analysis_b}")

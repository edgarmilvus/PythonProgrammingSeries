
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import pandas as pd
from transformers import pipeline
import matplotlib.pyplot as plt

time_series_data = [
    ('2024-03-01', 'CEO confirms robust earnings forecast.'),
    ('2024-03-01', 'Minor production delay reported.'),
    ('2024-03-01', 'Stock hits 52-week low due to sector weakness.'),
    ('2024-03-02', 'Federal regulator opens investigation into competitor.'),
    ('2024-03-02', 'New product launch exceeds sales targets.'),
    ('2024-03-02', 'Inflation spikes unexpectedly.'),
    ('2024-03-03', 'Company announces share buyback program.'),
    ('2024-03-03', 'Analysts downgrade rating to "Hold."'),
    ('2024-03-04', 'Record dividend payout announced.'),
    ('2024-03-04', 'Global trade tensions escalate.'),
    ('2024-03-04', 'New government subsidy approved for key sector.'),
    ('2024-03-05', 'Major acquisition announced, boosting future revenue potential.'),
    ('2024-03-05', 'Inventory buildup suggests slowing demand.'),
    ('2024-03-05', 'Oil prices stabilize after weeks of chaos.')
]

POSITIVE_WEIGHT = 1.5
NEGATIVE_WEIGHT = 1.0

def calculate_daily_sentiment_index(data):
    # 1. Initialize FinBERT and prepare input
    sentiment_pipeline = pipeline(
        "sentiment-analysis",
        model="ProsusAI/finbert"
    )
    
    dates = [item[0] for item in data]
    headlines = [item[1] for item in data]
    
    # Batch classification
    results = sentiment_pipeline(headlines)
    
    # 2. Structure data into an initial DataFrame
    df = pd.DataFrame({
        'Date': dates,
        'Sentiment_Label': [r['label'] for r in results]
    })
    
    # 3. Aggregation: Calculate daily counts
    # unstack() pivots the sentiment labels into columns, fill_value=0 handles missing labels
    daily_counts = df.groupby('Date')['Sentiment_Label'].value_counts().unstack(fill_value=0)
    
    # Ensure all required columns exist
    for col in ['Positive', 'Negative', 'Neutral']:
        if col not in daily_counts.columns:
            daily_counts[col] = 0

    daily_counts['Total'] = daily_counts['Positive'] + daily_counts['Negative'] + daily_counts['Neutral']

    # 4. Index Calculation: Net Sentiment Index = (P * 1.5 - N * 1.0) / Total
    daily_counts['Net_Sentiment_Index'] = (
        (daily_counts['Positive'] * POSITIVE_WEIGHT) - 
        (daily_counts['Negative'] * NEGATIVE_WEIGHT)
    ) / daily_counts['Total']

    # 5. Visualization Preparation: Final DataFrame
    final_df = daily_counts.reset_index()[['Date', 'Net_Sentiment_Index']]
    
    return final_df

def plot_sentiment_index(df):
    # Convert Date to datetime for proper plotting order
    df['Date'] = pd.to_datetime(df['Date'])
    
    # 6. Interactive Plotting
    plt.figure(figsize=(10, 6))
    plt.plot(df['Date'], df['Net_Sentiment_Index'], marker='o', linestyle='-', color='tab:blue')
    
    plt.axhline(0, color='red', linestyle='--', linewidth=0.8, label='Neutral Baseline')
    
    plt.title('Daily Net Sentiment Index Trend (FinBERT)')
    plt.xlabel('Date')
    plt.ylabel('Net Sentiment Index (Weighted)')
    plt.ylim(-1.0, 1.0)
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.xticks(rotation=45)
    plt.legend()
    plt.tight_layout()
    plt.show()
    
# Execution
df_index = calculate_daily_sentiment_index(time_series_data)
print("--- Daily Sentiment Index ---")
print(df_index)
plot_sentiment_index(df_index)

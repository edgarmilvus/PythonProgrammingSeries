
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import pandas as pd
from transformers import pipeline

financial_headlines = [
    "Acme Corp reports record profits driven by successful cost-cutting measures.",
    "Market analysts express deep concern over looming recession risk.",
    "The central bank held interest rates steady, meeting market expectations.",
    "Tech giant secures massive government contract, projecting significant future growth.",
    "Supply chain disruptions continue to plague manufacturing sector.",
    "New regulatory framework is expected to stabilize volatile crypto markets.",
    "Shareholders approved the merger, leading to a modest stock rally.",
    "Inflationary pressures are easing faster than previously forecast.",
    "Energy stocks plummeted following an unexpected drop in global demand.",
    "Biotech firm announces Phase 3 trial failure; shares dive 60%.",
    "Retail sales showed unexpected resilience during the holiday quarter.",
    "CEO resigns amid internal investigation into accounting irregularities.",
    "Investment bank issues 'Strong Buy' rating based on solid fundamentals.",
    "Commodity prices remain flat as geopolitical tensions persist.",
    "Automaker recalls 500,000 vehicles due to critical safety flaw."
]

def process_batch_and_structure(headlines):
    # Initialize the FinBERT pipeline
    sentiment_pipeline = pipeline(
        "sentiment-analysis",
        model="ProsusAI/finbert"
    )

    # 2. Batch processing: Pass the entire list at once for efficiency
    results = sentiment_pipeline(headlines)

    # 3. Prepare data for DataFrame
    data = []
    for headline, result in zip(headlines, results):
        data.append({
            'Headline': headline,
            'Sentiment_Label': result['label'],
            'Confidence_Score': result['score']
        })

    # Construct the Pandas DataFrame
    df = pd.DataFrame(data)
    
    # 4. Analysis: Calculate counts
    sentiment_counts = df['Sentiment_Label'].value_counts()
    
    print("--- Structured Output DataFrame ---")
    print(df)
    print("\n--- Sentiment Count Summary ---")
    print(sentiment_counts)
    return df

# Execution
df_results = process_batch_and_structure(financial_headlines)

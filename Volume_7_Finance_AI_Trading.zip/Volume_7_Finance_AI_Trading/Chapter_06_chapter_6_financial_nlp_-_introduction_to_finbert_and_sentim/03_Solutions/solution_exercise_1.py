
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from transformers import pipeline

MIN_CONFIDENCE_THRESHOLD = 0.75
sample_text = "Despite strong quarterly revenue growth beating analyst expectations by 5%, increased geopolitical instability and rising input costs led management to issue a cautious outlook for the upcoming fiscal year, causing the stock price to dip slightly."

def analyze_sentiment_with_threshold(text, threshold):
    # 1. Model Initialization: Load FinBERT using the sentiment-analysis pipeline
    try:
        sentiment_pipeline = pipeline(
            "sentiment-analysis",
            model="ProsusAI/finbert"
        )
    except Exception as e:
        print(f"Error loading model: {e}")
        return

    # 4. Sentiment Extraction
    # The pipeline returns a list of dictionaries; we take the first element [0]
    result = sentiment_pipeline(text)[0]
    
    label = result['label']
    score = result['score']

    # 4. Threshold Implementation and Analysis
    is_actionable = score >= threshold
    
    print(f"--- FinBERT Analysis ---")
    print(f"Input Text: {text[:80]}...")
    print(f"Predicted Label: {label}")
    print(f"Confidence Score: {score:.4f} (Threshold: {threshold:.2f})")
    
    # 5. Output
    if is_actionable:
        print(f"\nConclusion: SENTIMENT IS ACTIONABLE (Score meets or exceeds {threshold}).")
    else:
        print(f"\nConclusion: SENTIMENT IS NEUTRAL/UNCERTAIN (Score below {threshold}).")

# Execute the function
analyze_sentiment_with_threshold(sample_text, MIN_CONFIDENCE_THRESHOLD)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from flask import Flask, request, jsonify
from transformers import pipeline
import os

# Global pipeline initialization (Run once on server startup)
sentiment_pipeline = None
try:
    # Initialize the pipeline globally
    sentiment_pipeline = pipeline(
        "sentiment-analysis",
        model="ProsusAI/finbert"
    )
    print("FinBERT model loaded successfully for API use.")
except Exception as e:
    print(f"FATAL: Error loading FinBERT model: {e}")

app = Flask(__name__)

@app.route('/sentiment_analyze', methods=['POST'])
def analyze():
    # Check if model loaded successfully (handle startup failure)
    if sentiment_pipeline is None:
        return jsonify({"error": "Model initialization failed on server startup."}), 500

    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "Invalid JSON payload or missing Content-Type: application/json header."}), 400

    # 3. Input Handling using EAFP (Easier to Ask for Forgiveness than Permission)
    try:
        # Attempt to access the 'text' key directly. This will raise a KeyError if absent.
        text_input = data['text']
        
        if not text_input or not isinstance(text_input, str):
             return jsonify({"error": "The 'text' field cannot be empty and must be a string."}), 400

        # Process the text
        result = sentiment_pipeline(text_input)[0]
        
        # 5. Successful Response
        response = {
            "status": "success",
            "sentiment": {
                "label": result['label'],
                "score": round(result['score'], 4)
            }
        }
        return jsonify(response), 200

    # 4. Error Response for missing key (The 'Forgiveness' part of EAFP)
    except KeyError:
        return jsonify({
            "error": "Missing required input key.",
            "required_format": {"text": "Your financial statement here."}
        }), 400
    except Exception as e:
        return jsonify({"error": f"An unexpected processing error occurred: {str(e)}"}), 500

if __name__ == '__main__':
    # Standard entry point for local development/testing. 
    # In production, Gunicorn imports the 'app' variable directly.
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification

# 1. Define the model name for FinBERT
# This specific identifier points to the ProsusAI version fine-tuned on financial data.
FINBERT_MODEL = "ProsusAI/finbert"

# 2. Load the Tokenizer and Model
# AutoTokenizer selects the correct tokenizer architecture based on the model name.
tokenizer = AutoTokenizer.from_pretrained(FINBERT_MODEL)
# AutoModelForSequenceClassification loads the BERT architecture optimized for
# classifying a sequence (the input sentence) into predefined categories (sentiments).
model = AutoModelForSequenceClassification.from_pretrained(FINBERT_MODEL)

# 3. Define the Input Text (a typical financial statement)
financial_text = "The company's quarterly earnings significantly exceeded analyst expectations, driving the stock price up by 8%."

# 4. Tokenization and Tensor Creation
# The text must be converted into numerical IDs (tokens) the model understands.
# padding=True ensures the sequence is padded to the model's expected length (if batching).
# truncation=True handles inputs longer than the model's maximum length.
# return_tensors='pt' mandates the output format be a PyTorch tensor.
inputs = tokenizer(
    financial_text,
    padding=True,
    truncation=True,
    return_tensors='pt'
)

# 5. Model Inference (Prediction)
# torch.no_grad() is crucial for inference; it disables gradient tracking,
# saving memory and speeding up calculation.
with torch.no_grad():
    # Pass the tokenized inputs (input_ids, attention_mask) to the model.
    outputs = model(**inputs)

# 6. Extracting Logits and Applying Softmax
# Logits are the raw, pre-activation scores output by the model's final layer.
logits = outputs.logits
# Softmax converts logits into probabilities that sum to 1.
# dim=1 specifies that the operation should be performed across the sentiment dimension.
probabilities = torch.softmax(logits, dim=1)

# 7. Mapping Output to Sentiment Labels
# FinBERT (ProsusAI/finbert) uses a specific order for its three classes:
# Index 0: Negative, Index 1: Neutral, Index 2: Positive.
sentiment_labels = ['Negative', 'Neutral', 'Positive']

# Find the index corresponding to the highest probability.
predicted_index = torch.argmax(probabilities, dim=1).item()
predicted_sentiment = sentiment_labels[predicted_index]

# Extract the confidence score for the predicted sentiment.
confidence_score = probabilities[0, predicted_index].item() * 100

# 8. Display Results
print(f"--- FinBERT Sentiment Analysis Result ---")
print(f"Input Text: {financial_text}")
print(f"Predicted Sentiment: {predicted_sentiment}")
print(f"Confidence Score: {confidence_score:.2f}%")
print("\nDetailed Probabilities:")
# Iterate through the labels and their corresponding probabilities for full transparency.
for label, prob in zip(sentiment_labels, probabilities[0]):
    print(f"  {label}: {prob.item():.4f}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example_part2.py
# Description: Basic Code Example
# ==========================================

# 1. Device Check and Assignment
# Check if CUDA (NVIDIA GPU) is available. If so, use 'cuda'; otherwise, use 'cpu'.
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

# 2. Load and Move Model/Tokenizer
FINBERT_MODEL = "ProsusAI/finbert"
tokenizer = AutoTokenizer.from_pretrained(FINBERT_MODEL)
# CRITICAL: Move the model's weights to the determined device (e.g., GPU).
model = AutoModelForSequenceClassification.from_pretrained(FINBERT_MODEL).to(device)

# ... (Define financial_text) ...

# 3. Tokenization and Input Movement
inputs = tokenizer(
    financial_text,
    padding=True,
    truncation=True,
    return_tensors='pt'
)
# CRITICAL: Move the input tensors (input_ids, attention_mask) to the device.
# We iterate through the dictionary and apply .to(device) to each tensor value.
inputs = {k: v.to(device) for k, v in inputs.items()}

# 4. Inference
with torch.no_grad():
    # The model and inputs are now on the same device (GPU), enabling fast computation.
    outputs = model(**inputs)

# ... (The rest of the code remains the same, as the output tensors are still on the device
# and can be processed or moved back to CPU only if needed for non-tensor operations).


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import torch
import pandas as pd
import re
import numpy as np
from transformers import AutoTokenizer, AutoModelForSequenceClassification

# --- 1. Configuration and Model Loading ---
FINBERT_MODEL = "ProsusAI/finbert"
# Determine device availability for efficient processing (GPU preferred)
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def load_finbert_model(model_name: str):
    """Loads the FinBERT model and tokenizer from Hugging Face, defining label mapping."""
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSequenceClassification.from_pretrained(model_name).to(DEVICE)
    # FinBERT uses 0: Positive, 1: Negative, 2: Neutral
    labels = {0: 'Positive', 1: 'Negative', 2: 'Neutral'}
    return tokenizer, model, labels

def split_text_into_sentences(text: str) -> list:
    """Robustly splits a long text block into individual sentences using regex."""
    # Splits based on common end punctuation followed by a space or end of string.
    # This is often more reliable than simple string splits for complex financial prose.
    sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    # Filter out empty strings
    return [s.strip() for s in sentences if s.strip()]

def analyze_batch_sentiment(sentences: list, tokenizer, model, labels: dict) -> pd.DataFrame:
    """Processes a batch of sentences using FinBERT and returns results in a DataFrame."""
    
    # 1. Tokenization and Tensor Conversion
    # Tokenize the input sentences, ensuring consistent length via padding and truncation
    inputs = tokenizer(
        sentences, 
        padding=True, 
        truncation=True, 
        return_tensors='pt'
    ).to(DEVICE)
    
    # 2. Model Inference
    # Use torch.no_grad() to save memory and speed up computation during inference
    with torch.no_grad():
        outputs = model(**inputs)
    
    # 3. Softmax and Score Extraction
    # Convert raw logits (unnormalized scores) into probability distributions
    probabilities = torch.softmax(outputs.logits, dim=1).cpu().numpy()
    
    # Invert the label map for fast lookup of score indices (e.g., 'Positive' is index 0)
    label_to_index = {v: k for k, v in labels.items()}
    
    results = []
    for i, sentence in enumerate(sentences):
        probs = probabilities[i]
        
        # Determine the predicted class based on the highest probability
        predicted_class_idx = np.argmax(probs)
        predicted_label = labels[predicted_class_idx]
        
        # Extract specific scores using the label-to-index map
        pos_score = probs[label_to_index['Positive']]
        neg_score = probs[label_to_index['Negative']]
        neu_score = probs[label_to_index['Neutral']]
        
        results.append({
            'Sentence': sentence,
            'Prediction': predicted_label,
            'Positive_Score': pos_score,
            'Negative_Score': neg_score,
            'Neutral_Score': neu_score
        })
        
    return pd.DataFrame(results)

def calculate_weighted_sentiment(df: pd.DataFrame) -> dict:
    """Calculates the overall weighted sentiment score for the document based on averages."""
    
    total_count = len(df)
    
    # Sum the probabilities across all sentences for each category
    total_pos = df['Positive_Score'].sum()
    total_neg = df['Negative_Score'].sum()
    total_neu = df['Neutral_Score'].sum()
    
    # Normalized scores (Average probability per sentence across the document)
    avg_pos = total_pos / total_count
    avg_neg = total_neg / total_count
    
    # Actionable Score: The differential between positive and negative sentiment
    actionable_score = avg_pos - avg_neg
    
    # Determine overall bias based on predefined thresholds
    if actionable_score > 0.15:
        bias = "Strongly Bullish"
    elif actionable_score > 0.05:
        bias = "Mildly Bullish"
    elif actionable_score < -0.15:
        bias = "Strongly Bearish"
    elif actionable_score < -0.05:
        bias = "Mildly Bearish"
    else:
        bias = "Neutral/Mixed"
        
    return {
        "Total Sentences": total_count,
        "Average Positive Score": f"{avg_pos:.4f}",
        "Average Negative Score": f"{avg_neg:.4f}",
        "Average Neutral Score": f"{total_neu / total_count:.4f}",
        "Actionable Sentiment Score (P-N)": f"{actionable_score:.4f}",
        "Overall Market Bias": bias
    }

# --- 2. Simulation and Execution ---

if __name__ == "__main__":
    
    # Simulated Context: A mixed-signal quarterly earnings summary for a major tech firm.
    FINANCIAL_REPORT_TEXT = """
    Apple Inc. reported Q4 revenue of $90.1 billion, exceeding analyst expectations by a comfortable margin. 
    This robust performance was primarily driven by strong iPhone 15 sales in emerging markets. 
    However, the company warned about significant supply chain constraints impacting Mac production throughout the holiday season. 
    Margins are expected to contract slightly next quarter due to rising component costs, which is a concern for investors. 
    Despite these headwinds, the services division achieved record growth, demonstrating the underlying strength of the ecosystem. 
    The board approved a substantial $20 billion share buyback program, signaling confidence in future cash flows. 
    Overall, while short-term challenges exist, the long-term outlook remains highly favorable.
    """
    
    print("--- 1. Loading FinBERT Model ---")
    tokenizer, model, label_map = load_finbert_model(FINBERT_MODEL)
    print(f"Model loaded successfully on device: {DEVICE}")

    # 1. Preprocessing: Sentence Segmentation
    print("\n--- 2. Segmenting Text ---")
    sentences = split_text_into_sentences(FINANCIAL_REPORT_TEXT)
    print(f"Text segmented into {len(sentences)} sentences.")

    # 2. Sentiment Analysis (Batch Processing)
    print("\n--- 3. Running FinBERT Sentiment Analysis ---")
    sentiment_df = analyze_batch_sentiment(sentences, tokenizer, model, label_map)
    
    # 3. Detailed Output
    print("\n--- 4. Detailed Sentence-Level Sentiment Breakdown ---")
    # Display the sentence, its prediction, and the actionable scores
    print(sentiment_df[['Sentence', 'Prediction', 'Positive_Score', 'Negative_Score']].to_string(index=False))

    # 4. Aggregation and Reporting
    print("\n--- 5. Document Aggregation and Final Report ---")
    final_report = calculate_weighted_sentiment(sentiment_df)
    
    # Print the final summary statistics
    for key, value in final_report.items():
        print(f"{key}: {value}")

    print("\n[CONCLUSION]: This document exhibits a clear actionable bias. The positive statements (revenue beat, services growth, buyback) significantly outweigh the negative statements (supply chain, rising costs) when weighted by FinBERT's confidence, leading to a Mildly Bullish classification.")


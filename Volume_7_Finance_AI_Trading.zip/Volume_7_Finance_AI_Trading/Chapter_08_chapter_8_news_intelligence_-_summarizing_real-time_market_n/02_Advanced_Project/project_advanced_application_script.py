
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import json
from typing import List, Dict, Any

# Ensure necessary environment variables are set for the LLM provider
# os.environ["OPENAI_API_KEY"] = "YOUR_API_KEY"

from langchain.chains.summarize import load_summarize_chain
from langchain_core.documents import Document
from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
from langchain_core.pydantic_v1 import BaseModel, Field

# --- 1. Define Structured Output Schema using Pydantic ---
# This ensures the LLM's output conforms to a strict, machine-readable format.
class MarketEntity(BaseModel):
    """A financial entity (company, product, or regulation) mentioned in the news."""
    entity_name: str = Field(description="The name of the company or regulatory body.")
    relevance_score: float = Field(description="Score (0.0 to 1.0) indicating importance to the overall market impact.")
    
class ExecutiveSummary(BaseModel):
    """The final, synthesized, structured output for the trading model."""
    overall_sentiment_score: float = Field(description="Composite score (-1.0 for bearish, 1.0 for bullish) across all articles.")
    key_entities_identified: List[MarketEntity] = Field(description="List of all major entities and their relevance.")
    market_impact_narrative: str = Field(description="A concise, 3-sentence synthesis of the net market implication.")

# --- 2. Mock Data Source (Simulating API Fetch) ---
def load_mock_financial_documents() -> List[Document]:
    """Simulates loading multiple, lengthy financial news articles."""
    articles = [
        {"source": "WSJ", "content": "Tesla announced a major battery technology breakthrough, promising 20% more range at 10% lower cost. This is expected to disrupt the lithium supply chain, benefiting Albemarle Corp. stock significantly."},
        {"source": "Reuters", "content": "Regulatory hurdles in Europe are slowing down the adoption of new solar panel installations. SunRun stock dropped 4% on the news. Analysts suggest a cautious outlook for Q3 earnings across the solar sector."},
        {"source": "Bloomberg", "content": "Albemarle Corp. is facing temporary production halts at its Chilean mines due to labor disputes. While the long-term outlook is bullish, this short-term supply constraint is causing price volatility."},
        {"source": "FT", "content": "Geopolitical tensions are driving up the cost of rare earth magnets, critical for wind turbine manufacturing. General Electric's renewable energy division is revising its profit forecasts downward for the year."},
        # In a real application, this list would contain dozens of articles
    ]
    # Convert raw strings into LangChain Document objects
    return [Document(page_content=a["content"], metadata={"source": a["source"]}) for a in articles]

# --- 3. Define MapReduce Prompts ---

# 3a. Map Prompt: Focuses on extracting local facts from a single document.
MAP_TEMPLATE = """
You are a financial news intelligence agent. Analyze the following single article.
Identify all key financial entities and the immediate, local sentiment. 
Do NOT synthesize or combine information across articles yet.

Article:
---
{text}
---

Local Extraction Output (JSON format expected for later reduction):
{{"entities": ["Company A", "Company B"], "local_sentiment": "Positive", "key_facts": ["Fact 1", "Fact 2"]}}
"""
MAP_PROMPT = PromptTemplate(template=MAP_TEMPLATE, input_variables=["text"])

# 3b. Combine/Reduce Prompt: Synthesizes all mapped facts into the final structured Pydantic object.
# We must inject the Pydantic schema instructions here.
COMBINE_TEMPLATE = f"""
You have been provided with a list of extracted key facts and local sentiments from multiple financial news articles regarding the same sector.
Your task is to synthesize this information into a single, coherent, structured executive summary.

1. Calculate the overall net sentiment score (ranging from -1.0 to 1.0).
2. Consolidate and rank all identified entities by overall market relevance.
3. Write a concise, three-sentence narrative summarizing the net market impact.

Use the provided Pydantic schema for your output.
Pydantic Schema:
---
{ExecutiveSummary.schema_json(indent=2)}
---

Extracted Facts and Sentiments (to be synthesized):
---
{{text}}
---

Synthesized JSON Output:
"""
COMBINE_PROMPT = PromptTemplate(template=COMBINE_TEMPLATE, input_variables=["text"])


# --- 4. Main Execution Pipeline ---
def run_structured_map_reduce_pipeline():
    """Executes the MapReduce chain for structured financial news synthesis."""
    
    # Initialize the LLM (using high-end model for better summarization and JSON compliance)
    llm = ChatOpenAI(temperature=0.0, model="gpt-4-turbo-preview")

    # Load the documents
    docs = load_mock_financial_documents()
    print(f"Loaded {len(docs)} documents for synthesis.")

    # Instantiate the MapReduce Summarization Chain
    # The chain automatically handles the intermediate mapping and final reduction steps.
    summary_chain = load_summarize_chain(
        llm,
        chain_type="map_reduce",
        map_prompt=MAP_PROMPT,
        combine_prompt=COMBINE_PROMPT,
        verbose=True  # Helpful for debugging the intermediate steps
    )

    # Add the Pydantic parser to the final step of the chain
    # Note: In modern LangChain, we often use LCEL and structured output methods directly
    # on the final LLM call, but for clarity with load_summarize_chain, we rely on 
    # the prompt instructions and a robust LLM (like GPT-4) for JSON compliance.
    
    # Execute the chain
    print("\n--- Running MapReduce Chain (Mapping Phase...) ---")
    raw_output = summary_chain.run(docs)
    
    # --- 5. Post-Processing and Validation ---
    
    print("\n--- Synthesis Complete (Parsing Structured Output) ---")
    
    try:
        # We assume the LLM adhered to the JSON structure defined in the Combine Prompt
        # We must clean the output, as LLMs sometimes wrap JSON in markdown tags (
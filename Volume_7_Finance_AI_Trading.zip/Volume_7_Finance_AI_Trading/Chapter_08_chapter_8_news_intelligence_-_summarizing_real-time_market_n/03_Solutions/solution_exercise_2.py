
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from pydantic import BaseModel, Field
from langchain.output_parsers import PydanticOutputParser
from langchain.chains.summarize import load_summarize_chain
from langchain.docstore.document import Document
from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
import json

# Placeholder LLM
LLM = ChatOpenAI(temperature=0, model="gpt-4o") # Using a more capable model for complex structured extraction

# Mock transcript data (simulated 15,000 words)
MOCK_TRANSCRIPT = (
    "Q1 2024 Earnings Call Transcript: "
    "CEO: We are thrilled to report a record quarter. Total Revenue reached $25.5 billion, "
    "significantly exceeding our internal projections. This growth was driven primarily by "
    "our new AI division. Our Earnings Per Share (EPS) came in at $1.95, representing a 20% "
    "year-over-year increase. (10,000 words of filler text simulating detailed discussion)... "
    "CFO: Looking ahead, we project strong, sustainable growth, targeting double-digit "
    "revenue increases for the next fiscal year, primarily due to expanding market share "
    "in Asia. We see minimal headwinds. (4,000 words of Q&A)... "
    "Analyst Conclusion: The overall sentiment is overwhelmingly positive."
) * 3 # Simulate a very long document

class EarningsMetrics(BaseModel):
    """Pydantic schema for structured earnings data extraction."""
    revenue: float = Field(description="The total reported revenue in billions.")
    eps: float = Field(description="The Earnings Per Share value.")
    forward_guidance: str = Field(description="A concise, 1-sentence summary of the company's outlook.")
    sentiment_score: float = Field(description="A quantified sentiment score between 0.0 (very negative) and 1.0 (very positive).")

def process_earnings_report(transcript: str, llm) -> EarningsMetrics | None:
    """Uses the Refine chain and Pydantic parser for structured extraction."""
    
    # 1. Pydantic Setup
    parser = PydanticOutputParser(pydantic_object=EarningsMetrics)
    format_instructions = parser.get_format_instructions()
    
    # 2. Document Preparation
    docs = [Document(page_content=transcript)]
    
    # 3. Define Prompts
    initial_template = f"""
    You are an expert financial data extractor. Analyze the beginning of the earnings transcript.
    Extract the following metrics and output them strictly as a JSON object conforming to the schema below.
    
    SCHEMA INSTRUCTIONS:
    {format_instructions}
    
    Transcript Chunk: {{text}}
    JSON Output:
    """
    initial_prompt = PromptTemplate.from_template(initial_template)

    refine_template = f"""
    You are refining a previously extracted JSON object based on new context from the transcript.
    The current extracted metrics are: {{existing_answer}}
    
    Analyze the new transcript chunk below. ONLY update or confirm the extracted metrics, 
    specifically cross-referencing figures (revenue, EPS) to ensure they are the final reported numbers.
    Maintain the strict JSON schema.
    
    New Transcript Chunk: {{text}}
    
    Updated JSON Output:
    """
    refine_prompt = PromptTemplate.from_template(refine_template)

    # 4. Instantiate Refine Chain
    chain = load_summarize_chain(
        llm,
        chain_type="refine",
        question_prompt=initial_prompt,
        refine_prompt=refine_prompt,
        verbose=False
    )
    
    # 5. Execution with Error Handling
    try:
        # The chain output is a string, which should be valid JSON
        json_string = chain.run(docs)
        
        # Use the parser to validate and convert the JSON string
        validated_metrics = parser.parse(json_string)
        return validated_metrics
        
    except Exception as e:
        print(f"\n--- Extraction Failure ---")
        print(f"LLM failed to produce valid Pydantic output or JSON: {e}")
        # Log the failure and return None to signal pipeline continuation
        return None

# --- Execution ---
print("Processing large transcript using Refine Chain...")
try:
    metrics_object = process_earnings_report(MOCK_TRANSCRIPT, LLM)

    if metrics_object:
        print("\n--- Structured Extraction Success ---")
        print(f"Type: {type(metrics_object)}")
        print(f"Revenue: ${metrics_object.revenue:.2f} Billion")
        print(f"EPS: ${metrics_object.eps:.2f}")
        print(f"Guidance: {metrics_object.forward_guidance}")
        print(f"Sentiment Score: {metrics_object.sentiment_score:.2f}")
except Exception as e:
    print(f"LLM Execution Placeholder Error (API Key/Configuration): {e}")
    print("Structure verified. Pydantic and Refine logic implemented.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from langchain.docstore.document import Document
from langchain.chains.summarize import load_summarize_chain
from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
import time
import random

# Placeholder LLM (assuming configuration via environment variables)
LLM = ChatOpenAI(temperature=0, model="gpt-3.5-turbo")

def load_mock_documents(count: int) -> list[Document]:
    """Generates a list of LangChain Document objects simulating financial news."""
    companies = ['TSMC', 'NVIDIA', 'Intel', 'AMD', 'Micron']
    actions = [
        'announced record Q3 guidance', 'faced regulatory hurdles in China',
        'secured a major government contract', 'saw a 15% drop in stock price',
        'unveiled a new 3nm chip architecture', 'issued a cautious forward outlook'
    ]
    
    docs = []
    for i in range(count):
        company = random.choice(companies)
        action = random.choice(actions)
        sentiment = "positive" if random.random() > 0.5 else "negative"
        
        content = (
            f"Article {i+1}: The semiconductor giant {company} {action} today. "
            f"Analysts are reacting with a generally {sentiment} outlook. "
            "Supply chain stability remains a key concern across the sector, "
            "but long-term demand for AI chips is driving investment."
        )
        docs.append(Document(page_content=content, metadata={"source": f"article_{i+1}"}))
    return docs

def summarize_with_map_reduce(documents: list[Document], llm) -> tuple[str, float]:
    """Executes the MapReduce chain and measures execution time."""
    
    # 1. Define Map Prompt: Focus on core subject and immediate implication
    map_template = """
    You are a financial news analyst. Analyze the following news article fragment.
    Identify the main company/subject and determine the immediate market implication (Positive, Negative, or Neutral).
    Summarize this information in a single, concise sentence.
    
    Article: {text}
    """
    map_prompt = PromptTemplate.from_template(map_template)

    # 2. Define Reduce Prompt: Synthesize overall market impact
    reduce_template = """
    You have received several individual summaries of high-volume semiconductor news articles.
    Synthesize these summaries into a single, cohesive, paragraph-length report (max 4 sentences).
    Focus on the overall consensus sentiment, the most frequently mentioned companies, and the net market impact on the semiconductor sector.
    
    Consolidated Summaries: {text}
    
    FINAL REPORT:
    """
    reduce_prompt = PromptTemplate.from_template(reduce_template)

    # 3. Instantiate MapReduce Chain
    chain = load_summarize_chain(
        llm,
        chain_type="map_reduce",
        map_prompt=map_prompt,
        combine_prompt=reduce_prompt,
        verbose=False
    )

    # 4. Execution and Timing
    start_time = time.time()
    
    # Run the chain
    final_summary = chain.run(documents)
    
    end_time = time.time()
    execution_time = end_time - start_time
    
    return final_summary, execution_time

# --- Execution ---
NUM_DOCS = 50
mock_documents = load_mock_documents(NUM_DOCS)

# Note: In a real environment, this execution requires a valid LLM API key.
# For demonstration, the structure is paramount.
try:
    summary, duration = summarize_with_map_reduce(mock_documents, LLM)
    print(f"--- MapReduce Summary of {NUM_DOCS} Articles ---")
    print(f"Summary: {summary.strip()}")
    print(f"Execution Time: {duration:.2f} seconds")
except Exception as e:
    print(f"LLM Execution Placeholder Error (API Key/Configuration): {e}")
    print("Structure verified. Time measurement logic implemented.")

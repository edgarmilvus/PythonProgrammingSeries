
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from datetime import datetime, timedelta
from typing import List, Dict, Any
import random
import uuid
import time
# Mock imports for SQLAlchemy components (no actual installation required)
class Column:
    def __init__(self, *args, **kwargs): pass
class Integer(Column): pass
class String(Column): pass
class Float(Column): pass
class DateTime(Column): pass

# --- 1. ORM Model Definition (Mock SQLAlchemy) ---
class NewsSummaryModel:
    """Mock ORM Model for storing structured news summaries."""
    id = Column(String, primary_key=True)
    summary_text = Column(String)
    sentiment_score = Column(Float)
    processed_date = Column(DateTime)
    source_id = Column(String)

    def __init__(self, summary_text, sentiment_score, source_id):
        self.id = str(uuid.uuid4())
        self.summary_text = summary_text
        self.sentiment_score = sentiment_score
        self.processed_date = datetime.now()
        self.source_id = source_id

# --- 2. Data Simulation ---
def generate_mock_news(count: int) -> list[dict]:
    """Generates mock news data with varying timestamps and content."""
    news_list = []
    current_time = datetime.now()
    
    critical_keywords = ['acquisition', 'merger', 'patent', 'regulatory approval']
    filler_keywords = ['weather', 'sports', 'local politics', 'entertainment']

    for i in range(count):
        is_fresh = random.random() < 0.7 # 70% fresh
        is_relevant = random.random() < 0.4 # 40% relevant
        
        # Determine timestamp
        if is_fresh:
            age_seconds = random.randint(1, 1800) # 1 to 30 minutes old
            timestamp_dt = current_time - timedelta(seconds=age_seconds)
        else:
            age_hours = random.randint(1, 5)
            timestamp_dt = current_time - timedelta(hours=age_hours)
            
        # Format timestamp string
        # Critical: The format code must match the input format "YYYY-MM-DD HH:MM:SS EST"
        timestamp_str = timestamp_dt.strftime("%Y-%m-%d %H:%M:%S") + " EST"
        
        # Determine content
        keyword = random.choice(critical_keywords) if is_relevant else random.choice(filler_keywords)
        content = f"ID {i}: Major industry news regarding a potential {keyword}. Company X is involved in talks."
        
        news_list.append({
            'id': f"art_{i}",
            'timestamp': timestamp_str,
            'content': content
        })
    return news_list

# --- 3. Filtering Functions ---
def filter_by_freshness(news_list: list[dict], max_age_minutes: int) -> list[dict]:
    """Filters news items older than max_age_minutes."""
    filtered = []
    current_time = datetime.now()
    max_age_delta = timedelta(minutes=max_age_minutes)
    
    # Format code: %Y-%m-%d %H:%M:%S recognizes the date/time part
    # The ' EST' suffix must be handled carefully or stripped.
    TIME_FORMAT = "%Y-%m-%d %H:%M:%S"
    
    for item in news_list:
        try:
            # Strip ' EST' for reliable parsing
            ts_str = item['timestamp'].replace(" EST", "").strip()
            item_time = datetime.strptime(ts_str, TIME_FORMAT)
            
            if (current_time - item_time) <= max_age_delta:
                filtered.append(item)
        except ValueError as e:
            print(f"Error parsing timestamp {item['timestamp']}: {e}")
            continue # Skip malformed timestamps
            
    return filtered

def filter_by_keywords(news_list: list[dict], keywords: set) -> list[dict]:
    """Filters news items based on required keywords."""
    filtered = []
    for item in news_list:
        content = item['content'].lower()
        if any(keyword in content for keyword in keywords):
            filtered.append(item)
    return filtered

# --- 4. Ingestion Simulation ---
def ingest_to_db(summaries: list[dict]):
    """Simulates saving structured summaries to the ORM model."""
    ingested_count = 0
    for summary_data in summaries:
        # Simulate LLM output structure (e.g., from Exercise 2)
        try:
            model_instance = NewsSummaryModel(
                summary_text=summary_data['summary'],
                sentiment_score=summary_data['sentiment'],
                source_id=summary_data['id']
            )
            # Simulate session add/commit (e.g., session.add(model_instance))
            # print(f"  [DB] Ingested ID: {model_instance.source_id} (Score: {model_instance.sentiment_score})")
            ingested_count += 1
        except Exception as e:
            # Handles unexpected structure errors during mapping
            print(f"  [DB ERROR] Failed to map summary data for ID {summary_data.get('id')}: {e}")
    return ingested_count

# --- Interactive Challenge: Batch Processing & Error Handling ---

def run_full_pipeline_simulation(raw_news: list[dict], llm_placeholder):
    """Simulates the full filtering -> summarization -> ingestion flow."""
    
    # 1. Filtering
    critical_keywords = {'acquisition', 'merger', 'patent', 'regulatory approval'}
    fresh_news = filter_by_freshness(raw_news, max_age_minutes=30)
    relevant_news = filter_by_keywords(fresh_news, critical_keywords)
    
    print(f"Initial: {len(raw_news)}. Fresh: {len(fresh_news)}. Relevant: {len(relevant_news)}.")
    
    structured_summaries = []
    
    # BATCH PROCESSING OPTIMIZATION (Pseudocode Outline):
    """
    import concurrent.futures
    
    def process_single_article(article):
        # Simulate the LLM call using the Refine or Map chain structure here
        # return structured_data
        pass 
    
    # Use a ThreadPoolExecutor to run LLM calls in parallel (I/O bound task)
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        results = executor.map(process_single_article, relevant_news)
        
    for result in results:
        # Process results and handle errors
        pass
    """
    
    # 2. Sequential Summarization Simulation with Failure Tolerance
    for article in relevant_news:
        try:
            # Simulate LLM summarization step (e.g., calling a function like Exercise 2's process_earnings_report)
            time.sleep(0.01) # Simulate LLM latency
            
            # Simulate a 10% failure rate for malformed JSON
            if random.random() < 0.1:
                raise ValueError("LLM returned malformed JSON.")
                
            # Successful simulation output structure
            structured_summaries.append({
                'id': article['id'],
                'summary': f"Summary of {article['id']}: Key finding is positive due to {article['content'].split(':')[1].strip()}.",
                'sentiment': round(random.uniform(0.6, 0.9), 2)
            })
            
        except Exception as e:
            # FAILURE TOLERANCE: Log the failure and continue processing the next article
            print(f" [LLM FAIL] Article ID {article['id']} failed summarization: {e}. Continuing pipeline.")
            continue
            
    # 3. Ingestion
    print(f"Successfully summarized {len(structured_summaries)} articles.")
    ingested_count = ingest_to_db(structured_summaries)
    print(f"Total articles ingested into ORM model: {ingested_count}")

# --- Execution ---
RAW_NEWS_STREAM = generate_mock_news(100)
run_full_pipeline_simulation(RAW_NEWS_STREAM, LLM)

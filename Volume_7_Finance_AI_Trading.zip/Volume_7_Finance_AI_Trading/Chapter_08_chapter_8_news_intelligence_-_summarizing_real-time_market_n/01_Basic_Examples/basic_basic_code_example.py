
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import os
# Ensure you have installed the necessary packages: 
# pip install langchain langchain-openai

from langchain_openai import ChatOpenAI
from langchain.chains.summarize import load_summarize_chain
from langchain.schema import Document

# --- 1. Synthetic Financial Data ---
# Three short documents representing different news items for a single stock (InnovateCorp)
news_article_1 = (
    "InnovateCorp announced Q3 earnings today, beating analyst expectations "
    "by 15%. Revenue stood at $5.2B, driven primarily by strong cloud services growth."
)
news_article_2 = (
    "Despite positive earnings, InnovateCorp's stock saw a 3% dip pre-market "
    "due to a reported security vulnerability discovered in their legacy hardware division. "
    "This vulnerability affects approximately 10% of their installed base."
)
news_article_3 = (
    "The CEO of InnovateCorp confirmed during the earnings call that the company "
    "is planning a major stock buyback program starting next quarter, signaling strong "
    "management confidence in future valuations."
)

# --- 2. Document Preparation ---
# LangChain processes data as standard Document objects.
documents = [
    Document(page_content=news_article_1, metadata={"source": "Earnings Report"}),
    Document(page_content=news_article_2, metadata={"source": "Market Watch"}),
    Document(page_content=news_article_3, metadata={"source": "CEO Statement"}),
]

# --- 3. LLM and Chain Initialization ---
# CRITICAL: Ensure OPENAI_API_KEY is set as an environment variable
try:
    # Use a low temperature for deterministic, factual financial summaries
    llm = ChatOpenAI(temperature=0, model="gpt-3.5-turbo")
except Exception as e:
    print(f"Error initializing LLM. Ensure API key is set: {e}")
    # In a real application, you would handle this gracefully.
    exit()

# Load the summarization chain. 'stuff' method combines all documents into one prompt.
summarization_chain = load_summarize_chain(
    llm=llm,
    chain_type="stuff"
)

# --- 4. Execution and Output Prompt Engineering ---
print("--- Running Summarization Chain (Stuff Method) ---")

# Define the custom prompt structure to enforce financial context and output format
custom_prompt_template = (
    "You are a Senior Financial Analyst. Summarize the following collection of market news "
    "about InnovateCorp into a single, concise paragraph suitable for a trading desk. "
    "Focus on key financial metrics, market sentiment, and forward-looking statements. "
    "The summary must be objective and include all critical positive and negative factors."
)

# Invoke the chain, passing the documents and the prompt structure
summary_result = summarization_chain.invoke(
    {"input_documents": documents, "text": custom_prompt_template}
)

print("\n[FINAL ACTIONABLE SUMMARY]")
print("==================================================")
print(summary_result['output_text'])
print("==================================================")

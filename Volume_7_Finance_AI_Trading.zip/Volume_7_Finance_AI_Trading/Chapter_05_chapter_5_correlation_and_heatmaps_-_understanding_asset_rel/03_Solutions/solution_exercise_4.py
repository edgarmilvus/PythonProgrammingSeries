
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import pandas as pd
import numpy as np
import os

# --- Setup: Simulate universe_15_assets.csv data (assuming returns) ---
np.random.seed(44)
num_days = 500
assets = ['SPY'] + [f'Asset_{i}' for i in range(1, 15)]
returns_data = {}
for asset in assets:
    if asset == 'SPY':
        returns_data[asset] = np.random.normal(0.0005, 0.01, num_days)
    elif asset in ['Asset_1', 'Asset_2', 'Asset_3']:
        # Introduce strong negative correlation
        returns_data[asset] = np.random.normal(-0.0001, 0.008, num_days) - 0.5 * returns_data['SPY']
    else:
        returns_data[asset] = np.random.normal(0.0002, 0.012, num_days) + 0.1 * returns_data['SPY']
universe_df = pd.DataFrame(returns_data)
# Save to simulate loading from file
file_path = 'universe_15_assets.csv'
universe_df.to_csv(file_path, index=False)
# ----------------------------------------------------------------------

# 1. Robustness Check (EAFP Principle)
try:
    universe_df = pd.read_csv(file_path)
    print(f"Successfully loaded data from '{file_path}'.")
except FileNotFoundError:
    print(f"Error: The required financial data file '{file_path}' was not found. Cannot proceed with correlation analysis.")
    exit() # Stop execution if data loading fails

# 2. Targeted Correlation
# Calculate the full correlation matrix
corr_matrix = universe_df.corr(method='pearson')

# Extract the correlation values relative to 'SPY'
spy_correlations = corr_matrix['SPY']

# 3. Sorting and Selection
# Drop SPY's self-correlation (1.0) and sort ascending (most negative first)
hedging_candidates = spy_correlations.drop('SPY').sort_values(ascending=True)

# 4. Output
top_3_hedges = hedging_candidates.head(3).round(4)

print("\nTop 3 Assets Most Negatively Correlated with SPY (Optimal Hedging Candidates):")
print(top_3_hedges)

# Clean up simulated file
os.remove(file_path)

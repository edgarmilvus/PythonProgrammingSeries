
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# --- Setup: Simulate extended_assets.csv data ---
dates_ext = pd.date_range(start='2020-01-01', periods=750, freq='B')
np.random.seed(43)
data_ext = {
    'Date': dates_ext,
    'AAPL': 150 + np.cumsum(np.random.normal(0.5, 2, 750)),
    'MSFT': 200 + np.cumsum(np.random.normal(0.4, 1.8, 750)),
    'GOOGL': 100 + np.cumsum(np.random.normal(0.6, 2.5, 750)),
    'SPY': 300 + np.cumsum(np.random.normal(0.3, 1.5, 750)),
    'DUK': 80 + np.cumsum(np.random.normal(0.1, 0.8, 750)),
    'GLD': 150 + np.cumsum(np.random.normal(-0.05, 1.2, 750))
}
extended_price_df = pd.DataFrame(data_ext).set_index('Date')
# Introduce non-linearity/outliers (e.g., a short, sharp divergence in DUK)
extended_price_df['DUK'].iloc[200:210] *= 1.1
# -------------------------------------------------

# 1. Extended Data Preparation
extended_returns = extended_price_df.pct_change().dropna()

# 2. Dual Correlation Calculation
pearson_corr = extended_returns.corr(method='pearson')
spearman_corr = extended_returns.corr(method='spearman')

# 3. Comparison Analysis: Calculate the absolute difference
diff_matrix = (pearson_corr - spearman_corr).abs()

# Find the pair with the largest difference (excluding the diagonal)
# Mask the upper triangle including the diagonal (k=0)
mask_diff = np.triu(np.ones_like(diff_matrix, dtype=bool), k=0)
diff_matrix_masked = diff_matrix.where(~mask_diff) # Keep lower triangle only

max_diff_pair = diff_matrix_masked.stack().idxmax()
max_diff_val = diff_matrix_masked.stack().max()

# 4. Output
print("--- Pearson Correlation Matrix (rho) ---\n", pearson_corr.round(3))
print("\n--- Spearman Correlation Matrix (rho_s) ---\n", spearman_corr.round(3))
print("\n--- Absolute Difference Matrix (|rho - rho_s|) ---\n", diff_matrix.round(3))

print(f"\nLargest Difference in Correlation Measurement: {max_diff_pair}")
print(f"Absolute Difference Value: {max_diff_val:.4f}")

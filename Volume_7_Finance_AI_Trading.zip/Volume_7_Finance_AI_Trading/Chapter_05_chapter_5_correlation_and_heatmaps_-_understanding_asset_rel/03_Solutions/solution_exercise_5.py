
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import os
import pandas as pd
import numpy as np

# Re-use pearson_corr from Exercise 2 for testing
# (Assuming it is available in the environment)
# If running independently, re-create the matrix:
# extended_returns = extended_price_df.pct_change().dropna()
# pearson_corr = extended_returns.corr(method='pearson')

def generate_filtered_report(corr_matrix: pd.DataFrame):
    """
    Filters the correlation matrix based on a dynamic threshold read from 
    the CORR_THRESHOLD environment variable, defaulting to 0.65.
    """
    # 1. Environment Variable Integration & Default Handling
    threshold_str = os.environ.get('CORR_THRESHOLD')
    
    if threshold_str is not None:
        try:
            # Attempt to convert the string to a float
            threshold = float(threshold_str)
            print(f"--- Using dynamic threshold: {threshold:.2f} (from CORR_THRESHOLD environment variable) ---")
        except ValueError:
            # Handle case where the environment variable is set but invalid
            threshold = 0.65
            print(f"--- Warning: CORR_THRESHOLD '{threshold_str}' is invalid. Using default threshold: 0.65 ---")
    else:
        # 2. Default Handling
        threshold = 0.65
        print(f"--- Using default threshold: {threshold:.2f} (CORR_THRESHOLD not set) ---")

    results = []
    assets = corr_matrix.columns
    
    # 3. Filtering Logic (Iterating lower triangle, excluding diagonal)
    for i in range(len(assets)):
        for j in range(i): # j < i ensures lower triangle and excludes diagonal
            asset_A = assets[i]
            asset_B = assets[j]
            rho = corr_matrix.iloc[i, j]
            
            if abs(rho) >= threshold:
                results.append(((asset_A, asset_B), rho))

    # 4. Output Format: Sort by absolute correlation (descending)
    results.sort(key=lambda x: abs(x[1]), reverse=True)
    
    return results

# --- Testing Environment Setup ---

# Scenario A: Test using default threshold (0.65)
if 'CORR_THRESHOLD' in os.environ:
    del os.environ['CORR_THRESHOLD'] # Ensure it is not set

print("\n--- Scenario A: Testing with Default Threshold (0.65) ---")
report_a = generate_filtered_report(pearson_corr)
print("Filtered Pairs (Absolute Correlation >= 0.65):")
for pair, rho in report_a:
    print(f"  {pair[0]} - {pair[1]}: {rho:.4f}")

# Scenario B: Set environment variable dynamically to a higher threshold (0.80)
os.environ['CORR_THRESHOLD'] = '0.80'

print("\n--- Scenario B: Testing with Dynamic Threshold (0.80) ---")
report_b = generate_filtered_report(pearson_corr)
print("Filtered Pairs (Absolute Correlation >= 0.80):")
for pair, rho in report_b:
    print(f"  {pair[0]} - {pair[1]}: {rho:.4f}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
# Assuming 'pearson_corr' from Exercise 2 is available

# 1. Masking Redundancy: Create a mask for the upper triangle
mask = np.triu(np.ones_like(pearson_corr, dtype=bool))

# 2. Conditional Annotation: Create a DataFrame for annotations
# Initialize annotation labels with empty strings
annot_labels = pearson_corr.applymap(lambda x: "")
threshold_high_risk = 0.75
threshold_diversification = -0.20

# Iterate through the matrix to conditionally fill the annotation labels
for i in range(len(pearson_corr.index)):
    for j in range(i): # Only iterate over the lower triangle (j < i)
        val = pearson_corr.iloc[i, j]
        
        # Check if the value meets the risk criteria
        if (val >= threshold_high_risk) or (val <= threshold_diversification):
            annot_labels.iloc[i, j] = f"{val:.2f}"

# 3. Visualization
plt.figure(figsize=(10, 8))
sns.heatmap(
    pearson_corr,
    mask=mask, # Apply the upper triangle mask
    annot=annot_labels, # Use the conditional annotation matrix
    fmt='s', # Use 's' format to handle strings (empty or formatted float)
    cmap='vlag', # Diverging color map centered around zero
    vmin=-1, vmax=1, # Ensure the color scale is fixed and symmetric
    linewidths=0.5,
    cbar_kws={'label': 'Pearson Correlation Coefficient'}
)
plt.title("Risk-Focused Correlation Heatmap (Annotated for Extremes)")
plt.show()

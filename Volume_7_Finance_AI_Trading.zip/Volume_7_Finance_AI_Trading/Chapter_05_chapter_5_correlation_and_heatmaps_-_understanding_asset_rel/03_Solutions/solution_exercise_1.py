
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import numpy as np

# --- Setup: Simulate asset_prices.csv data ---
dates = pd.date_range(start='2020-01-01', periods=750, freq='B')
np.random.seed(42)
data = {
    'Date': dates,
    'AAPL': 150 + np.cumsum(np.random.normal(0.5, 2, 750)),
    'MSFT': 200 + np.cumsum(np.random.normal(0.4, 1.8, 750)),
    'GOOGL': 100 + np.cumsum(np.random.normal(0.6, 2.5, 750)),
    'SPY': 300 + np.cumsum(np.random.normal(0.3, 1.5, 750))
}
price_df = pd.DataFrame(data).set_index('Date')
# ---------------------------------------------

# 1. Return Calculation: Convert prices to daily percentage returns and drop the initial NaN row.
returns_df = price_df.pct_change().dropna()

# 2. Correlation Calculation: Calculate the Pearson correlation matrix.
corr_matrix = returns_df.corr(method='pearson')

# 3. Output Formatting
formatted_corr = corr_matrix.round(4)
print("Pearson Correlation Matrix (Daily Returns):\n", formatted_corr)

# 4. Initial Interpretation: Find max and min correlation (off-diagonal)
# Create a mask for the upper triangle (excluding the diagonal)
mask = np.triu(np.ones_like(corr_matrix, dtype=bool), k=1)
off_diag_corr = corr_matrix.where(mask)

# Strongest positive correlation
max_corr_pair = off_diag_corr.stack().idxmax()
max_val = off_diag_corr.stack().max()

# Weakest (closest to zero) correlation
min_abs_corr_pair = off_diag_corr.stack().abs().idxmin()
min_abs_val = corr_matrix.loc[min_abs_corr_pair[0], min_abs_corr_pair[1]]

print(f"\nStrongest Positive Correlation: {max_corr_pair} (Value: {max_val:.4f})")
print(f"Weakest (Closest to Zero) Correlation: {min_abs_corr_pair} (Value: {min_abs_val:.4f})")

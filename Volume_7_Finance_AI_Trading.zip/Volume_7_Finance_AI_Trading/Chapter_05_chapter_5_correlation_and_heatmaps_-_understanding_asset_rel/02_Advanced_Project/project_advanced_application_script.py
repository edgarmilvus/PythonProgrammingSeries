
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import yfinance as yf
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# --- 1. Configuration and Asset Selection ---
# A diverse basket of assets representing different market segments
ASSETS = [
    "SPY",      # S&P 500 ETF (US Broad Market)
    "GLD",      # Gold ETF (Safe Haven/Commodity)
    "TLT",      # 20+ Year Treasury Bond ETF (Fixed Income)
    "XOM",      # Exxon Mobil (Energy Sector)
    "AAPL",     # Apple (Technology Sector)
    "EEM"       # Emerging Markets ETF (International Risk)
]
START_DATE = "2020-01-01"
END_DATE = "2024-01-01"

# --- 2. Data Acquisition Function ---
def fetch_financial_data(tickers, start, end):
    """Fetches adjusted closing prices for the specified tickers using yfinance."""
    print(f"Fetching data for {len(tickers)} assets...")
    try:
        # Fetch data, suppressing progress bar
        data = yf.download(tickers, start=start, end=end, progress=False)
        
        # Isolate the Adjusted Close prices
        adj_close = data['Adj Close']
        
        # Handle the case where yf.download returns a Series for a single ticker
        if isinstance(adj_close, pd.Series):
            adj_close = adj_close.to_frame(name=tickers[0])
            
        # Drop any rows with missing data (e.g., non-trading days for specific assets)
        return adj_close.dropna()
    except Exception as e:
        print(f"Error fetching data: {e}")
        return pd.DataFrame()

# --- 3. Preprocessing: Calculating Logarithmic Returns ---
def calculate_log_returns(price_df):
    """Calculates daily logarithmic returns (R_t = ln(P_t / P_{t-1}))."""
    # Log returns are preferred over simple percentage returns for time-series analysis 
    # as they are additive over time and better model continuous compounding.
    log_returns = np.log(price_df / price_df.shift(1))
    return log_returns.dropna()

# --- 4. Correlation Calculation and Masking ---
def generate_correlation_matrix(returns_df, method='pearson'):
    """Calculates the correlation matrix and prepares the mask for visualization."""
    # Calculate the correlation matrix using the specified method (Pearson measures linear relationship)
    corr_matrix = returns_df.corr(method=method)

    # Create a mask for the upper triangle. Since the matrix is symmetric (A-B correlation is B-A correlation), 
    # masking the upper half cleans up the visualization and focuses the reader on the lower triangle.
    mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
    
    return corr_matrix, mask

# --- 5. Visualization: Seaborn Heatmap ---
def plot_correlation_heatmap(corr_matrix, mask):
    """Generates and displays the correlation heatmap."""
    plt.figure(figsize=(10, 8))
    
    # Configure the heatmap parameters for financial data analysis
    sns.heatmap(
        corr_matrix, 
        mask=mask, 
        annot=True,         # Show correlation values on the map
        fmt=".2f",          # Format annotations to two decimal places
        cmap='coolwarm',    # Use a diverging color map centered at zero
        vmin=-1, vmax=1,    # Ensure the color scale is fixed from perfect negative to perfect positive correlation
        linewidths=.5,      # Add thin lines between cells for clarity
        cbar_kws={"shrink": .75} # Adjust color bar size
    )
    
    plt.title(f'Asset Correlation Matrix (Pearson, {START_DATE} to {END_DATE})', fontsize=14)
    plt.xticks(rotation=45, ha='right')
    plt.yticks(rotation=0)
    plt.tight_layout()
    plt.show()

# --- 6. Analysis: Identifying Least Correlated Pairs ---
def identify_diversification_candidates(corr_matrix, N=5):
    """Identifies the N pairs with the lowest absolute correlation for diversification."""
    
    # 6a. Unstack the matrix to create a Series of all pairs
    corr_series = corr_matrix.unstack()
    
    # 6b. Filter: Drop self-correlations (where correlation is 1.0)
    # and use loc to retrieve only the unique pairs (e.g., keep A-B, drop B-A)
    unique_pairs = corr_series[corr_series < 1.0].drop_duplicates()
    
    # 6c. Sort by the absolute value of correlation to find the weakest linear relationships, 
    # regardless of whether the relationship is slightly positive or slightly negative.
    least_correlated_abs = unique_pairs.abs().sort_values(ascending=True).head(N)
    
    print("\n--- Top Diversification Candidates (Lowest Absolute Correlation) ---")
    print(f"Goal: Identify assets that move independently or inversely to minimize systemic risk.")
    
    for (asset1, asset2), abs_corr in least_correlated_abs.items():
        # Retrieve the original correlation value for directionality
        original_corr = corr_matrix.loc[asset1, asset2]
        print(f"Pair: {asset1} vs {asset2} | Absolute Correlation: {abs_corr:.4f} | Direction: {original_corr:.4f}")

# --- Main Execution Flow ---
if __name__ == "__main__":
    # 1. Fetch Data
    price_data = fetch_financial_data(ASSETS, START_DATE, END_DATE)
    
    if not price_data.empty:
        # 2. Calculate Returns
        returns_data = calculate_log_returns(price_data)
        
        # 3. Calculate Correlation and Mask
        correlation_matrix, mask = generate_correlation_matrix(returns_data, method='pearson')
        
        # 4. Visualize
        plot_correlation_heatmap(correlation_matrix, mask)
        
        # 5. Analyze
        identify_diversification_candidates(correlation_matrix, N=5)
    else:
        print("Script terminated due to data fetching failure.")

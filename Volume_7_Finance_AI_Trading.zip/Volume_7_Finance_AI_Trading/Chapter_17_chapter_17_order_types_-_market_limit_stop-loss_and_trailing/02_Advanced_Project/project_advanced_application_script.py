
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import uuid
import time
from typing import Dict, Any, Optional

# --- Configuration ---
SYMBOL = "TSLA"
CURRENT_MARKET_PRICE = 185.50
DESIRED_ENTRY_PRICE = 185.00  # Target price for the Limit order
STOP_LOSS_PRICE = 183.00     # Static risk management
TRAILING_STOP_OFFSET = 1.50  # Dynamic profit locking offset

class MockBroker:
    """
    Simulates a brokerage API for submitting and tracking various order types.
    """
    def __init__(self):
        self.orders: Dict[str, Dict[str, Any]] = {}
        self.current_price = CURRENT_MARKET_PRICE

    def _generate_order_id(self) -> str:
        """Generates a unique order ID."""
        return str(uuid.uuid4())[:8]

    def submit_order(self,
                     symbol: str,
                     order_type: str,
                     quantity: int,
                     price: Optional[float] = None,
                     stop_price: Optional[float] = None,
                     trailing_offset: Optional[float] = None,
                     oco_group_id: Optional[str] = None) -> Optional[str]:
        """
        Submits an order and performs basic parameter validation based on type.
        """
        order_id = self._generate_order_id()
        
        # 1. Validation for Limit and Stop orders
        if order_type in ["LIMIT", "STOP_LOSS"] and price is None:
            print(f"Error: {order_type} order requires a 'price' parameter.")
            return None
        
        # 2. Validation for Trailing Stop orders
        if order_type == "TRAILING_STOP" and trailing_offset is None:
            print("Error: TRAILING_STOP order requires a 'trailing_offset'.")
            return None

        # 3. Validation for Market orders
        if order_type == "MARKET" and price is not None:
             print("Warning: MARKET order price parameter ignored.")

        order_details = {
            "id": order_id,
            "symbol": symbol,
            "type": order_type,
            "qty": quantity,
            "price": price,
            "stop_price": stop_price,
            "trailing_offset": trailing_offset,
            "status": "PENDING",
            "oco_group": oco_group_id
        }
        
        self.orders[order_id] = order_details
        print(f"[{order_type}] Order submitted. ID: {order_id}. Status: PENDING.")
        return order_id

    def check_order_status(self, order_id: str) -> str:
        """
        Simulates checking the status of an order and potentially filling it.
        In a real system, this would be an API call.
        """
        order = self.orders.get(order_id)
        if not order:
            return "NOT_FOUND"

        if order['status'] == 'PENDING':
            # Simulation: Only the Limit order can execute if the price is met
            if order['type'] == 'LIMIT' and self.current_price <= order['price']:
                order['status'] = 'FILLED'
                print(f"--- EXECUTION ALERT --- Limit Order {order_id} FILLED at {order['price']}.")
            
            # Simulation: Stop/Trailing orders are more complex and assume they remain PENDING/WORKING
            
        return order['status']
    
    def cancel_order(self, order_id: str):
        """Simulates canceling an open order."""
        if order_id in self.orders and self.orders[order_id]['status'] != 'FILLED':
            self.orders[order_id]['status'] = 'CANCELED'
            print(f"Order {order_id} CANCELED.")


def execute_protective_entry_strategy():
    """
    Main execution function demonstrating OTO and OCO logic.
    """
    broker = MockBroker()
    quantity = 100
    
    print(f"\n--- Strategy Initialization: {SYMBOL} @ ${broker.current_price} ---")
    
    # STEP 1: Submit the primary entry order (Limit Order)
    # We use a Limit order to ensure we only buy if the price dips to DESIRED_ENTRY_PRICE or lower.
    entry_order_id = broker.submit_order(
        symbol=SYMBOL,
        order_type="LIMIT",
        quantity=quantity,
        price=DESIRED_ENTRY_PRICE
    )
    
    if not entry_order_id:
        return

    # STEP 2: Simulate price movement and check status (OTO Trigger)
    print("\nSimulating waiting for Limit Order execution...")
    
    # Simulate the price dropping, triggering the Limit order
    broker.current_price = DESIRED_ENTRY_PRICE 
    time.sleep(0.1) # Simulate network delay

    entry_status = broker.check_order_status(entry_order_id)
    
    if entry_status == "FILLED":
        print("\n*** OTO TRIGGERED: Entry filled. Submitting protective exit orders. ***")
        
        # Define the OCO Group ID (shared between Stop-Loss and Trailing Stop)
        oco_group_id = broker._generate_order_id()

        # STEP 3A: Submit the static Stop-Loss order
        # This order caps the maximum potential loss.
        stop_loss_id = broker.submit_order(
            symbol=SYMBOL,
            order_type="STOP_LOSS",
            quantity=quantity,
            price=STOP_LOSS_PRICE,
            oco_group_id=oco_group_id
        )

        # STEP 3B: Submit the dynamic Trailing Stop order
        # This order moves the stop price up as the market price rises, locking in gains.
        trailing_stop_id = broker.submit_order(
            symbol=SYMBOL,
            order_type="TRAILING_STOP",
            quantity=quantity,
            trailing_offset=TRAILING_STOP_OFFSET,
            oco_group_id=oco_group_id
        )
        
        print(f"\nOCO Group {oco_group_id} established: SL ({stop_loss_id}) and TS ({trailing_stop_id}).")
        
        # STEP 4: Simulate profit-taking (e.g., Trailing Stop executes)
        # In a real system, if the Trailing Stop executes, the broker automatically cancels the Stop-Loss (OCO).
        print("\nSimulating market movement and OCO execution...")
        
        # For demonstration, we simulate the broker executing the Trailing Stop
        # and canceling the related Stop-Loss due to OCO rules.
        broker.orders[trailing_stop_id]['status'] = 'FILLED'
        broker.cancel_order(stop_loss_id) 
        
        print(f"\nTrade Complete. Trailing Stop ({trailing_stop_id}) executed. Static Stop-Loss ({stop_loss_id}) canceled by OCO rule.")
        
    else:
        print(f"\nLimit order {entry_order_id} not filled. Strategy aborted.")

if __name__ == "__main__":
    execute_protective_entry_strategy()

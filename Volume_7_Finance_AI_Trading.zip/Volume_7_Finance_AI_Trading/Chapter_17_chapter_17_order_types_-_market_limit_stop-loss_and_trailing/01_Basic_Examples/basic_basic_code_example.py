
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import time

# --- 1. Core Simulation Class ---

class SimulatedTradingPlatform:
    """
    A simplified class to simulate the execution engine of a brokerage platform.
    It tracks current price and manages pending vs. executed orders.
    """
    def __init__(self, current_price: float):
        # The prevailing price for the asset (e.g., BTC/USD)
        self.current_price = current_price
        # List to hold orders waiting for a specific price trigger (Limit, Stop)
        self.pending_orders = []
        # List to hold orders that have been filled (Market, or triggered Limit/Stop)
        self.executed_trades = []
        # Simple counter for unique order IDs
        self._order_counter = 0

    def _generate_order_id(self):
        """Generates a unique ID for tracking."""
        self._order_counter += 1
        return self._order_counter

    def submit_order(self, order_type: str, symbol: str, quantity: float, side: str, 
                     limit_price: float = None, stop_price: float = None) -> int or None:
        """
        Submits an order and determines if it executes immediately or is placed in queue.
        """
        order_id = self._generate_order_id()
        order_details = {
            "id": order_id,
            "type": order_type.upper(),
            "symbol": symbol,
            "qty": quantity,
            "side": side.upper(),
            "timestamp": time.time(),
            "market_at_submission": self.current_price
        }

        print(f"\n[SUBMITTING ORDER {order_id}] Type: {order_type.upper()} | Side: {side.upper()} | Qty: {quantity}")

        # --- A. MARKET ORDER LOGIC ---
        if order_type.upper() == "MARKET":
            # Market orders execute immediately at the best available current price.
            execution_price = self.current_price
            order_details["price"] = execution_price
            order_details["status"] = "EXECUTED"
            self.executed_trades.append(order_details)
            print(f"  -> [SUCCESS] MARKET order executed instantly @ ${execution_price:,.2f}")
            return order_id

        # --- B. LIMIT ORDER LOGIC ---
        elif order_type.upper() == "LIMIT":
            order_details["limit_price"] = limit_price
            
            # Limit Buy: Executes if limit_price >= current_price (or if price drops to limit_price later)
            if side.upper() == "BUY":
                if limit_price >= self.current_price:
                    # Pitfall Alert: A Limit Buy set above the current market price executes immediately
                    # at the current market price (or better, depending on liquidity).
                    execution_price = self.current_price
                    order_details["price"] = execution_price
                    order_details["status"] = "EXECUTED"
                    self.executed_trades.append(order_details)
                    print(f"  -> [WARNING/EXECUTE] Limit Buy (${limit_price:,.2f}) is too high (Market: ${self.current_price:,.2f}). Executed immediately @ ${execution_price:,.2f}.")
                else:
                    # Limit Buy set below market price waits for the price to drop.
                    order_details["status"] = "PENDING"
                    self.pending_orders.append(order_details)
                    print(f"  -> [PENDING] Limit Buy waiting for price to drop to ${limit_price:,.2f} or lower.")

            # Limit Sell: Executes if limit_price <= current_price (or if price rises to limit_price later)
            elif side.upper() == "SELL":
                if limit_price <= self.current_price:
                    # Pitfall Alert: A Limit Sell set below the current market price executes immediately.
                    execution_price = self.current_price
                    order_details["price"] = execution_price
                    order_details["status"] = "EXECUTED"
                    self.executed_trades.append(order_details)
                    print(f"  -> [WARNING/EXECUTE] Limit Sell (${limit_price:,.2f}) is too low (Market: ${self.current_price:,.2f}). Executed immediately @ ${execution_price:,.2f}.")
                else:
                    # Limit Sell set above market price waits for the price to rise.
                    order_details["status"] = "PENDING"
                    self.pending_orders.append(order_details)
                    print(f"  -> [PENDING] Limit Sell waiting for price to rise to ${limit_price:,.2f} or higher.")
            
            return order_id

        # --- C. STOP ORDER LOGIC (Trigger for risk management) ---
        elif order_type.upper() == "STOP":
            order_details["stop_price"] = stop_price

            # Stop Sell (Stop-Loss): Used to close a long position if the price falls.
            if side.upper() == "SELL":
                if stop_price < self.current_price:
                    # This is a valid protective stop-loss. It waits for the trigger.
                    order_details["status"] = "PENDING_TRIGGER"
                    self.pending_orders.append(order_details)
                    print(f"  -> [PENDING] Stop Sell set at ${stop_price:,.2f}. Waiting for trigger.")
                else:
                    # Stop Sell above market price is usually rejected or treated as a Limit Sell.
                    print(f"  -> [REJECTED] Stop Sell must be protective (below market) for risk management.")
                    return None

            # Stop Buy (Stop-Entry or Stop-Loss for short position): Used to enter on a breakout or cover a short.
            elif side.upper() == "BUY":
                if stop_price > self.current_price:
                    # This is a valid stop-entry order. It waits for the trigger.
                    order_details["status"] = "PENDING_TRIGGER"
                    self.pending_orders.append(order_details)
                    print(f"  -> [PENDING] Stop Buy set at ${stop_price:,.2f}. Waiting for trigger.")
                else:
                    # Stop Buy below market price is usually rejected.
                    print(f"  -> [REJECTED] Stop Buy must be protective (above market) for entry or covering.")
                    return None
            
            return order_id

        else:
            print("  -> [ERROR] Unknown order type.")
            return None

    def check_status(self):
        """Prints the final state of the simulated order book."""
        print("\n" + "="*50)
        print(f"PLATFORM SUMMARY | Current Market Price: ${self.current_price:,.2f}")
        print("="*50)
        print(f"Total Executed Trades: {len(self.executed_trades)}")
        print(f"Total Pending Orders: {len(self.pending_orders)}")
        print("-" * 50)
        
        if self.pending_orders:
            print("PENDING ORDERS (Waiting for Price Trigger):")
            for order in self.pending_orders:
                trigger = order.get('limit_price') or order.get('stop_price')
                print(f"  ID {order['id']} | {order['type']} {order['side']} | Qty: {order['qty']} | Trigger @ ${trigger:,.2f}")
        
        print("="*50)


# --- 2. Execution Scenario ---

CURRENT_PRICE_BTC = 65000.00
platform = SimulatedTradingPlatform(CURRENT_PRICE_BTC)

# 1. Market Order: Immediate execution required (Intent 1)
platform.submit_order(
    order_type="MARKET",
    symbol="BTC/USD",
    quantity=0.01,
    side="BUY"
)

# 2. Limit Order: Waiting for a better price (Intent 2)
platform.submit_order(
    order_type="LIMIT",
    symbol="BTC/USD",
    quantity=0.02,
    side="BUY",
    limit_price=64500.00 # $500 below current price
)

# 3. Stop Order: Risk management (Intent 3)
platform.submit_order(
    order_type="STOP",
    symbol="BTC/USD",
    quantity=0.01,
    side="SELL",
    stop_price=63000.00 # $2000 below current price (Stop-Loss)
)

# 4. Demonstrating an immediate Limit execution (Pitfall example)
platform.submit_order(
    order_type="LIMIT",
    symbol="BTC/USD",
    quantity=0.05,
    side="SELL",
    limit_price=64000.00 # $1000 below current price - executes instantly!
)

platform.check_status()

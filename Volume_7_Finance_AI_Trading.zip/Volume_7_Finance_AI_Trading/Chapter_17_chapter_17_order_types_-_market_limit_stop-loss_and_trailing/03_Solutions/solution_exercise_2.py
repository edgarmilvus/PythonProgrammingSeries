
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import json

def submit_bracket_order(symbol: str, entry_price: float, stop_percentage: float, target_percentage: float, quantity: int):
    
    # 1. Calculate derived prices
    stop_price = entry_price * (1 - stop_percentage)
    target_price = entry_price * (1 + target_percentage)

    print(f"Calculated Prices for {symbol} @ {entry_price:.2f}: Stop={stop_price:.2f}, Target={target_price:.2f}")

    # 2. Entry Order (Limit Buy)
    entry_payload = {
        "symbol": symbol,
        "qty": quantity,
        "side": "buy",
        "type": "limit",
        "limit_price": entry_price,
        "time_in_force": "gtc",
        "client_order_id": "ENTRY-LMT"
    }

    # 3. Take-Profit Order (Limit Sell)
    target_payload = {
        "symbol": symbol,
        "qty": quantity,
        "side": "sell",
        "type": "limit",
        "limit_price": target_price,
        "time_in_force": "gtc",
        "client_order_id": "TP-LMT"
    }

    # 4. Stop-Loss Order (Stop-Market Sell)
    # Uses 'stop' type and the 'stop_price' trigger, executing as a Market order upon trigger.
    stop_payload = {
        "symbol": symbol,
        "qty": quantity,
        "side": "sell",
        "type": "stop", 
        "stop_price": stop_price, 
        "time_in_force": "gtc",
        "client_order_id": "SL-STP"
    }

    # Simulate submission and display payloads
    print("\n--- Bracket Order Submission ---")
    print("Entry:", json.dumps(entry_payload, indent=4))
    print("Target:", json.dumps(target_payload, indent=4))
    print("Stop-Loss:", json.dumps(stop_payload, indent=4))

    # API Grouping Context Comment:
    # In a real system, these would be submitted as a single request or linked 
    # using an OCO (One-Cancels-the-Other) or OTO (One-Triggers-the-Other) bracket structure. 
    # The OTO mechanism ensures the risk orders (Target and Stop-Loss) are only activated 
    # upon the fill confirmation of the entry order. The OCO grouping then links the 
    # Target and Stop-Loss so that the execution of one automatically cancels the other, 
    # ensuring the position is not accidentally over-sold.


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import json

def submit_foundational_orders(market_symbol: str, limit_symbol: str, market_qty: int, limit_qty: int, limit_price: float):
    """
    Constructs and simulates API payloads for a Market order and a Limit order.
    """
    
    # Define the payload for the immediate Market Order (e.g., VOO)
    # Price field is omitted, execution is instantaneous (time_in_force='day')
    market_payload = {
        "symbol": market_symbol,
        "qty": market_qty,
        "side": "buy",
        "type": "market",
        "time_in_force": "day",
        "client_order_id": f"MKT-{market_symbol}-001"
    }

    # Define the payload for the passive Limit Order (e.g., NVDA)
    # Requires the specific limit_price parameter
    limit_payload = {
        "symbol": limit_symbol,
        "qty": limit_qty,
        "side": "buy",
        "type": "limit",
        "limit_price": limit_price,
        "time_in_force": "gtc", # Good 'Til Canceled (passive)
        "client_order_id": f"LMT-{limit_symbol}-001"
    }

    # Simulate API submission:
    print("--- Market Order Submission (Immediate Entry) ---")
    print(json.dumps(market_payload, indent=4))
    print("\n--- Limit Order Submission (Passive Entry) ---")
    print(json.dumps(limit_payload, indent=4))

    # Required Context Comment: Market orders require immediate verification of fill status, 
    # as they execute instantly (or fail). They transition rapidly to 'FILLED' or 'CANCELED' 
    # (if insufficient liquidity). Limit orders, conversely, transition to a 'PENDING' or 
    # 'WORKING' state and require continuous monitoring until execution or expiration.

# Example usage (VOO market entry, NVDA limit entry 1.5% below $450)
# limit_target_price = 450.00 * (1 - 0.015)
# submit_foundational_orders("VOO", "NVDA", 100, 50, limit_target_price)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Constants and Simulated State
ORDER_ID_TO_CANCEL = "SL-456789"
POS_QTY = 100 # Assumed quantity

def cancel_order(order_id):
    print(f"API CALL: Canceling old Stop Order: {order_id}")

def submit_stop_market(price, quantity):
    # Simulate API submission of the new Stop-Market Sell order
    new_order_id = f"SL-{int(price * 100)}"
    print(f"API CALL: Submitting NEW Stop-Market @ {price:.2f} (ID: {new_order_id})")
    return price # Return the new active stop price

def update_trailing_stop(current_price: float, high_watermark: float, active_stop_price: float, stop_offset: float) -> float:
    """
    Checks if the high watermark allows for raising the active stop price.
    """
    
    print(f"\n--- Trailing Stop Check ---")
    print(f"Current Price: {current_price:.2f} | High Watermark: {high_watermark:.2f} | Active Stop: {active_stop_price:.2f}")

    # 1. Calculate the required stop based on the high watermark
    # (1 - stop_offset) calculates the price 2.0% below the high watermark
    new_stop_price = high_watermark * (1 - stop_offset) 
    print(f"Calculated Trailing Stop Price: {new_stop_price:.2f}")

    # 2. Check if the new calculated stop is higher than the currently active stop
    if new_stop_price > active_stop_price:
        print(f"ALERT: New stop ({new_stop_price:.2f}) is higher than Active Stop ({active_stop_price:.2f}). Trailing up.")
        
        # 3. If favorable, cancel old and submit new
        cancel_order(ORDER_ID_TO_CANCEL)
        # Update the active_stop_price with the result of the new submission
        active_stop_price = submit_stop_market(new_stop_price, POS_QTY)
        
    else:
        print("Trailing stop remains unchanged (High Watermark did not increase or new stop is lower).")
        
    return active_stop_price

# # Example Simulation: Initial price 100, active stop 95. Price hits 105.
# initial_active_stop = 95.00
# updated_stop = update_trailing_stop(104.50, 105.00, initial_active_stop, 0.02) 
# # New stop calculated: 105.00 * 0.98 = 102.90. Since 102.90 > 95.00, it trails up.

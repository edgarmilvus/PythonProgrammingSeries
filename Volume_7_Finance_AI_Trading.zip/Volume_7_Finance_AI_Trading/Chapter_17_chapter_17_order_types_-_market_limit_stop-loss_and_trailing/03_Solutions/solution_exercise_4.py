
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Simulated Initial Data
ORDER_ID = "LMT-1001"
INITIAL_LIMIT_PRICE = 150.00
SYMBOL = "XYZ"
QTY = 50
SIMULATED_CHECK_TIME = 5 # seconds

def check_order_status(order_id: str) -> str:
    # Simulates querying the broker API. High chance of PENDING for testing logic.
    import random
    if random.random() < 0.9:
        return "PENDING"
    return "FILLED"

def simulate_market_price(time_elapsed: int) -> float:
    # Simulates price movement over time.
    # We force the price to be close at the 5-second checkpoint for this run.
    if time_elapsed == SIMULATED_CHECK_TIME:
        # 150.10 is 0.066% difference, well within the 0.3% tolerance
        return 150.10 
    return 152.00 

def submit_market_order(symbol, qty):
    print(f"ACTION: Limit stale. Submitting replacement Market Buy for {qty} of {symbol}.")

def cancel_order(order_id):
    print(f"ACTION: Canceling stale Limit Order: {order_id}.")

def order_management_challenge(order_id, initial_limit_price, symbol, qty):
    print(f"Time 0s: Submitting initial Limit Buy @ {initial_limit_price:.2f} (ID: {order_id})")
    
    # Checkpoint at 5 seconds:
    time_elapsed = SIMULATED_CHECK_TIME
    print(f"\nTime {time_elapsed}s: Checking order status...")
    
    status = check_order_status(order_id)
    print(f"Status check result: {status}")
    
    if status == "PENDING":
        current_price = simulate_market_price(time_elapsed)
        price_diff = abs(current_price - initial_limit_price) / initial_limit_price
        
        print(f"Current Market Price: {current_price:.2f} | Price Difference: {price_diff * 100:.3f}%")
        
        TOLERANCE = 0.003 # 0.3%
        
        if price_diff <= TOLERANCE: 
            print("Decision: Price is close enough (within 0.3%). Replacing passive limit with aggressive market entry.")
            cancel_order(order_id)
            submit_market_order(symbol, qty)
        else:
            print("Decision: Price moved too far (> 0.3%). Canceling order to avoid poor fill.")
            cancel_order(order_id)
    
    elif status == "FILLED":
        print("Order filled successfully. No further action required.")
        
    print(f"\nTime 10s: Monitoring cycle complete.")

# order_management_challenge(ORDER_ID, INITIAL_LIMIT_PRICE, SYMBOL, QTY)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import pandas as pd
import numpy as np

# --- 1. Define the Input Dataset ---
# We use a small, clear dataset to track the logic easily.
# These prices represent 6 consecutive trading days.
historical_prices = [100.0, 101.5, 99.0, 103.0, 102.5, 105.0]
dates = pd.to_datetime([
    '2024-01-01', '2024-01-02', '2024-01-03', 
    '2024-01-04', '2024-01-05', '2024-01-06'
])

# Create a Pandas DataFrame, the standard data structure for finance
price_data = pd.DataFrame({'Close': historical_prices}, index=dates)


# --- 2. Function Demonstrating Look-ahead Bias ---
def calculate_biased_signal(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculates a trading signal that intentionally uses future data.
    This function simulates look-ahead bias.
    """
    
    # 2a. Calculate the percentage change (return) between T and T+1
    # pct_change() calculates (P_T - P_{T-1}) / P_{T-1}
    # We apply shift(-1) to move the result backward one row. 
    # CRITICAL: This is the mechanism that introduces the bias.
    df['Future_Return'] = df['Close'].pct_change().shift(-1) 
    
    # 2b. Generate the Signal (Decision made at time T)
    # If the FUTURE return (known only in the backtest) is positive,
    # we generate a perfect 'Buy' signal (1). Otherwise, 'Hold' (0).
    df['Signal'] = np.where(df['Future_Return'] > 0, 1, 0)
    
    # 2c. Calculate Strategy Returns
    # Strategy Return = Signal (Position Size) * Actual Return (Future Return)
    # Note: We are multiplying the signal generated at T by the return achieved from T to T+1.
    df['Strategy_Return'] = df['Signal'] * df['Future_Return'] 
    
    return df

# --- 3. Execution and Analysis ---
results = calculate_biased_signal(price_data.copy())

print("--- Backtest Results (Demonstrating Look-ahead Bias) ---")
print(results.to_string())

# Analyze the total return achieved by this "perfect" strategy
total_return = results['Strategy_Return'].sum()
print(f"\nTotal Biased Strategy Return: {total_return:.4f}")

# Compare to a simple buy-and-hold (P_end / P_start - 1)
buy_and_hold_return = (price_data['Close'].iloc[-1] / price_data['Close'].iloc[0]) - 1
print(f"Total Buy-and-Hold Return: {buy_and_hold_return:.4f}")

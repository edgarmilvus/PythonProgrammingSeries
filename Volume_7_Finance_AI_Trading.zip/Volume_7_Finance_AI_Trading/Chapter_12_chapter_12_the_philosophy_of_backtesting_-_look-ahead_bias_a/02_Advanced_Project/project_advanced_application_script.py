
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import numpy as np
import itertools
from typing import List, Tuple, Dict

# --- 1. Configuration and Constants ---
SEED = 42
np.random.seed(SEED)
TOTAL_DAYS = 1000
TRAIN_WINDOW = 250  # Optimization window size (In-Sample)
VALIDATION_WINDOW = 60 # Testing window size (Out-of-Sample)
STEP_SIZE = VALIDATION_WINDOW # How far the window advances (true walk-forward)

# Define the parameter space to search (e.g., SMA lookback periods)
PARAMETER_SPACE = [10, 20, 30, 40, 50, 60]

# --- 2. Data Simulation ---
def generate_price_data(days: int) -> pd.DataFrame:
    """Simulates a stock price series with some trend and noise."""
    # Creates slightly noisy, trending data for realistic simulation
    prices = 100 + np.cumsum(np.random.randn(days) * 0.5 + 0.1)
    df = pd.DataFrame({'Close': prices}, index=pd.to_datetime(pd.date_range(start='2018-01-01', periods=days, freq='D')))
    return df

# --- 3. Trading Strategy and Metrics ---
def run_strategy(data: pd.DataFrame, lookback: int) -> float:
    """
    Calculates the cumulative return for a simple SMA crossover strategy.
    Strategy: Buy if Close > SMA(lookback), Sell otherwise.
    """
    if len(data) < lookback:
        return 0.0 # Cannot calculate SMA
        
    # Calculate the Simple Moving Average (SMA)
    data['SMA'] = data['Close'].rolling(window=lookback).mean()
    
    # Generate signals (1 for buy/hold, 0 for sell/cash)
    # The signal is generated based on today's data (Close vs SMA)
    data['Signal'] = np.where(data['Close'] > data['SMA'], 1, 0)
    
    # Calculate daily returns based on signal (lagged to avoid look-ahead bias in execution)
    # We use the signal generated on day T to capture the return from T to T+1
    data['DailyReturn'] = data['Close'].pct_change().shift(-1)
    
    # Strategy returns: Only capture returns when signaled to be long
    data['StrategyReturn'] = data['Signal'] * data['DailyReturn']
    
    # Return the cumulative return over the period
    return data['StrategyReturn'].sum() * 100 # Return as percentage

# --- 4. Walk-Forward Optimization (WFO) Implementation ---

def perform_wfo(df: pd.DataFrame, train_size: int, validation_size: int, step: int, params: List[int]) -> Dict[str, float]:
    """
    Executes the Walk-Forward Optimization process.
    The core mechanism for mitigating overfitting and look-ahead bias.
    """
    total_returns = []
    
    # Iterate through the data, shifting the window by the step size
    for start in range(0, len(df) - train_size - validation_size + 1, step):
        
        # Define the training window (In-Sample Optimization)
        train_end = start + train_size
        train_data = df.iloc[start:train_end].copy()
        
        # Define the validation window (Out-of-Sample Testing)
        validation_end = train_end + validation_size
        validation_data = df.iloc[train_end:validation_end].copy()
        
        # 4a. Optimization Phase (Finding the best parameter IN-SAMPLE)
        best_param = None
        best_train_return = -np.inf
        
        # Search the defined parameter space using only the training data
        for param in params:
            train_return = run_strategy(train_data.copy(), param)
            if train_return > best_train_return:
                best_train_return = train_return
                best_param = param
                
        # 4b. Application Phase (Testing the best parameter OUT-OF-SAMPLE)
        if best_param is not None:
            # Apply the best parameter found in the train set to the unseen validation set
            oos_return = run_strategy(validation_data.copy(), best_param)
            total_returns.append(oos_return)
            
            print(f"Window {start//step + 1}: Train Period ({start} to {train_end-1}). Best Param: {best_param}. OOS Return: {oos_return:.2f}%")
            
    return {"WFO_Total_Return": sum(total_returns), "WFO_Avg_Return": np.mean(total_returns)}

# --- 5. Comparison: Full-Sample Optimization (Overfitting/Look-ahead Bias) ---

def perform_full_sample_optimization(df: pd.DataFrame, params: List[int]) -> Tuple[int, float]:
    """
    Optimizes the parameter across the ENTIRE dataset. 
    This is the textbook example of look-ahead bias/overfitting, as it uses future data.
    """
    best_param = None
    best_return = -np.inf
    
    for param in params:
        current_return = run_strategy(df.copy(), param)
        if current_return > best_return:
            best_return = current_return
            best_param = param
            
    return best_param, best_return

# --- 6. Execution ---

if __name__ == "__main__":
    
    print("--- Chapter 12: Walk-Forward Optimization vs. Static Optimization ---")
    
    price_data = generate_price_data(TOTAL_DAYS)
    
    # A. Walk-Forward Optimization (Robust, avoids look-ahead bias)
    wfo_results = perform_wfo(
        df=price_data,
        train_size=TRAIN_WINDOW,
        validation_size=VALIDATION_WINDOW,
        step=STEP_SIZE,
        params=PARAMETER_SPACE
    )
    
    # B. Full-Sample Optimization (Overfitted, uses future data)
    static_best_param, static_return = perform_full_sample_optimization(price_data, PARAMETER_SPACE)
    
    # C. Test Static Best Parameter on the Last OOS Window (for fairer comparison)
    # We test the static best parameter on the final, truly unseen OOS window used by the WFO.
    final_oos_start = len(price_data) - VALIDATION_WINDOW
    final_oos_data = price_data.iloc[final_oos_start:].copy()
    static_oos_return = run_strategy(final_oos_data, static_best_param)
    
    print("\n" + "="*50)
    print("SUMMARY OF RESULTS")
    print("="*50)
    
    print(f"1. Static (Overfitted) Optimization:")
    print(f"   - Best Parameter (Full Sample): {static_best_param} days")
    print(f"   - Total Return (In-Sample): {static_return:.2f}%")
    print(f"   - Performance on Final OOS Window: {static_oos_return:.2f}%")
    
    print("\n2. Walk-Forward Optimization (Robust):")
    print(f"   - Total Out-of-Sample Return: {wfo_results['WFO_Total_Return']:.2f}%")
    print(f"   - Average OOS Return per Window: {wfo_results['WFO_Avg_Return']:.2f}%")
    
    if wfo_results['WFO_Total_Return'] < static_return:
        print("\nConclusion: WFO return is lower than the static in-sample return. This gap demonstrates the static optimization inflated expectations by overfitting to historical noise.")

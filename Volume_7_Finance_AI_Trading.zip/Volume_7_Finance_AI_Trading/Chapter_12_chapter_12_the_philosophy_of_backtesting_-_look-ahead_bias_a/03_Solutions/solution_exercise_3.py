
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import pandas as pd
import numpy as np

# Helper function for simplified Sharpe calculation
def calculate_sharpe_ratio_dummy(returns):
    # Avoid division by zero
    if returns.std() == 0:
        return 0.0
    return returns.mean() / returns.std() * np.sqrt(252)

class WalkForwardOptimizer:
    def __init__(self, data, opt_window, test_window, step_size):
        self.data = data
        self.total_length = len(data)
        self.opt_window = opt_window
        self.test_window = test_window
        self.step_size = step_size
        
        if self.total_length < self.opt_window + self.test_window:
            raise ValueError("Data length is insufficient for the specified windows.")

    def _simulate_optimization(self, is_data):
        # Placeholder: Simulates finding the 'best' parameters based on IS data
        # In reality, this would involve extensive backtesting over is_data.
        optimal_param_A = 10 + int(is_data.sum() * 1000) % 5
        optimal_param_B = 5 + int(is_data.mean() * 10000) % 3
        return {"param_A": optimal_param_A, "param_B": optimal_param_B}

    def _run_test(self, oos_data, parameters):
        # Apply the optimized parameters and calculate OOS Sharpe
        sharpe = calculate_sharpe_ratio_dummy(oos_data)
        
        # Simulate a slight performance penalty for large parameters (overfitting proxy)
        if parameters['param_A'] > 12:
            sharpe *= 0.9 
            
        return sharpe 

    def run_wfo(self):
        oos_results = []
        wfo_iterations = []
        start_index = 0
        iteration_count = 0
        
        # Iterate as long as the full combined window (IS + OOS) fits in the data
        while start_index + self.opt_window + self.test_window <= self.total_length:
            iteration_count += 1
            
            # Define IS window boundaries
            is_start = start_index
            is_end = start_index + self.opt_window
            
            # Define OOS window boundaries (immediately following IS)
            oos_start = is_end
            oos_end = is_end + self.test_window
            
            # 1. Get data slices
            is_data = self.data.iloc[is_start:is_end]
            oos_data = self.data.iloc[oos_start:oos_end]
            
            # 2. Simulate Optimization (IS Phase)
            optimal_params = self._simulate_optimization(is_data)
            
            # 3. Run Test (OOS Phase)
            oos_sharpe = self._run_test(oos_data, optimal_params)
            
            oos_results.append(oos_sharpe)
            
            wfo_iterations.append({
                "Iteration": iteration_count,
                "IS_Start": is_data.index.min(),
                "IS_End": is_data.index.max(),
                "OOS_Start": oos_data.index.min(),
                "OOS_End": oos_data.index.max(),
                "OOS_Sharpe": oos_sharpe
            })
            
            # Move the window forward by the step size
            start_index += self.step_size
            
        # Visualization Preparation (First 5 iterations)
        print("--- Walk-Forward Optimization Iterations (First 5) ---")
        for result in wfo_iterations[:5]:
            print(f"Iter {result['Iteration']}: IS [{result['IS_Start'].date()} to {result['IS_End'].date()}] | OOS [{result['OOS_Start'].date()} to {result['OOS_End'].date()}] | Sharpe: {result['OOS_Sharpe']:.4f}")
            
        return oos_results

if __name__ == '__main__':
    # Simulate 1000 days of daily returns data
    np.random.seed(42)
    daily_returns = pd.Series(np.random.normal(0.0002, 0.008, 1000), 
                              index=pd.date_range(start='2018-01-01', periods=1000, freq='D'))
    
    OPT_WINDOW = 250  
    TEST_WINDOW = 50   
    STEP_SIZE = 50     
    
    wfo_engine = WalkForwardOptimizer(daily_returns, OPT_WINDOW, TEST_WINDOW, STEP_SIZE)
    
    all_oos_sharpes = wfo_engine.run_wfo()
    
    print("\n--- WFO Summary ---")
    print(f"Total Walk-Forward Iterations: {len(all_oos_sharpes)}")
    print(f"Mean OOS Sharpe Ratio: {np.mean(all_oos_sharpes):.4f}")

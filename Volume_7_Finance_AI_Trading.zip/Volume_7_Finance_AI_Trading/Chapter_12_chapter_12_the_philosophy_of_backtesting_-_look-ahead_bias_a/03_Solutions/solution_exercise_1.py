
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import numpy as np

# 1. Data Simulation
def create_synthetic_data(num_days):
    np.random.seed(42)
    returns = np.random.normal(0.0005, 0.01, num_days)
    prices = 100 * np.exp(np.cumsum(returns))
    df = pd.DataFrame({'Price': prices})
    df['Returns'] = df['Price'].pct_change()
    return df.dropna()

# 2. Biased Calculation
def calculate_biased_volatility(df, window):
    # Calculate rolling STD (uses data up to T).
    rolling_std = df['Returns'].rolling(window=window).std()
    
    # Introduce bias: shift the calculated volatility backward by 1 day.
    # The volatility value calculated using data up to T+1 is incorrectly assigned to T.
    return rolling_std.shift(-1)

# 3. Causally Safe Calculation
def calculate_safe_volatility(df, window):
    # Standard rolling calculation. The value assigned to T only uses data up to T.
    return df['Returns'].rolling(window=window).std()

# 4. Strategy Implementation and Backtest Runner
def run_backtest_simulation(df, volatility_series):
    # Strategy: Buy if 20-day volatility is below 100-day mean volatility, Sell if above.
    # Calculate the 100-day mean volatility 
    mean_vol = volatility_series.rolling(window=100).mean()
    
    # Generate signals: 1 (long) if current vol < mean vol, -1 (short) if current vol > mean vol
    signals = pd.Series(0, index=df.index)
    signals[volatility_series < mean_vol] = 1
    signals[volatility_series >= mean_vol] = -1
    
    # Shift signals to ensure trading at T uses data calculated up to T-1
    positions = signals.shift(1).fillna(0)
    
    # Calculate daily strategy returns
    strategy_returns = df['Returns'] * positions
    
    # Calculate cumulative returns
    cumulative_returns = (1 + strategy_returns).cumprod()
    return cumulative_returns.iloc[-1]

# Main execution block
if __name__ == '__main__':
    WINDOW = 20
    NUM_DAYS = 1000
    
    # 1. Simulate data
    df_prices = create_synthetic_data(NUM_DAYS)
    
    # 2. Calculate both metrics
    safe_vol = calculate_safe_volatility(df_prices, WINDOW)
    biased_vol = calculate_biased_volatility(df_prices, WINDOW)
    
    df_prices['Safe_Vol'] = safe_vol
    df_prices['Biased_Vol'] = biased_vol
    
    df_clean = df_prices.dropna()
    
    # 3. Run and compare performance metrics
    safe_return = run_backtest_simulation(df_clean, df_clean['Safe_Vol'])
    biased_return = run_backtest_simulation(df_clean, df_clean['Biased_Vol'])

    print(f"--- Look-Ahead Bias Quantification (Window: {WINDOW} days) ---")
    print(f"Final Cumulative Return (Causally Safe): {safe_return:.4f}")
    print(f"Final Cumulative Return (Biased/Look-Ahead): {biased_return:.4f}")
    
    performance_diff = (biased_return - safe_return) / safe_return * 100
    print(f"\nConclusion: The look-ahead bias exaggerated the final return by {performance_diff:.2f}% (relative to the safe return).")

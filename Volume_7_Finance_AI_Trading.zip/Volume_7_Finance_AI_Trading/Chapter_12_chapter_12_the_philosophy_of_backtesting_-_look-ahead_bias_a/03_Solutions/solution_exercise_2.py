
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import pandas as pd
import numpy as np

class DataSplitter:
    def __init__(self, returns_data, split_ratio=0.7):
        if not isinstance(returns_data, pd.Series):
            raise TypeError("Input data must be a Pandas Series of returns.")
        if not 0 < split_ratio < 1:
            raise ValueError("Split ratio must be between 0 and 1.")
            
        self.data = returns_data
        self.split_ratio = split_ratio
        # Calculate the index point for the chronological split
        self._split_index = int(len(self.data) * self.split_ratio)

    def get_in_sample_data(self):
        # The first portion of the time series (IS)
        return self.data.iloc[:self._split_index]

    def get_out_of_sample_data(self):
        # The chronologically subsequent portion (OOS)
        return self.data.iloc[self._split_index:]

    @staticmethod
    def calculate_sharpe_ratio(returns, risk_free_rate=0.02):
        """Calculates annualized Sharpe Ratio using EAFP."""
        try:
            returns = returns.dropna()
            
            # Annualization factor for daily data (252 trading days)
            annualization_factor = np.sqrt(252)
            
            annual_return = returns.mean() * 252
            annual_std = returns.std() * annualization_factor
            
            # Attempt the calculation
            sharpe = (annual_return - risk_free_rate) / annual_std
            
            # Check for invalid results (e.g., division by zero leading to Inf/NaN)
            if np.isnan(sharpe) or np.isinf(sharpe):
                raise ZeroDivisionError("Annualized volatility is zero or calculation resulted in infinity/NaN.")
                
            return sharpe
            
        except (ZeroDivisionError, TypeError, ValueError):
            # Gracefully handle calculation failures (EAFP)
            return None
        except Exception:
            return None

    def compare_performance(self):
        is_returns = self.get_in_sample_data()
        oos_returns = self.get_out_of_sample_data()
        
        is_sharpe = self.calculate_sharpe_ratio(is_returns)
        oos_sharpe = self.calculate_sharpe_ratio(oos_returns)
        
        overfit_ratio = None
        if is_sharpe is not None and oos_sharpe is not None and oos_sharpe != 0:
            overfit_ratio = is_sharpe / oos_sharpe
            
        return {
            "IS_Sharpe": is_sharpe,
            "OOS_Sharpe": oos_sharpe,
            "Overfit_Ratio": overfit_ratio
        }

if __name__ == '__main__':
    # Simulation of 500 days of returns data
    np.random.seed(10)
    simulated_returns = pd.Series(np.random.normal(0.0003, 0.005, 500), 
                                  index=pd.date_range(start='2020-01-01', periods=500, freq='D'))
    
    # Artificially boost IS performance to simulate overfitting
    is_split_point = int(500 * 0.7)
    simulated_returns.iloc[:is_split_point] += 0.0001 
    
    splitter = DataSplitter(simulated_returns, split_ratio=0.7)
    
    is_data = splitter.get_in_sample_data()
    oos_data = splitter.get_out_of_sample_data()
    
    print(f"IS Start/End: {is_data.index.min().date()} to {is_data.index.max().date()}")
    print(f"OOS Start/End: {oos_data.index.min().date()} to {oos_data.index.max().date()}")
    
    metrics = splitter.compare_performance()
    
    print("\n--- Performance Comparison ---")
    print(f"IS Sharpe Ratio: {metrics['IS_Sharpe']:.4f}")
    print(f"OOS Sharpe Ratio: {metrics['OOS_Sharpe']:.4f}")
    print(f"Overfit Ratio (IS/OOS): {metrics['Overfit_Ratio']:.4f}")
    
    if metrics['Overfit_Ratio'] is not None and metrics['Overfit_Ratio'] > 1.5:
        print("\nWarning: Overfit Ratio > 1.5 suggests significant overfitting.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np

# 1. Conceptual Design
# The fundamental difference between standard K-Fold CV and Time Series Cross-Validation (TSCV) is the preservation of temporal order. Standard K-Fold CV randomly partitions the data or uses sequential non-overlapping blocks, allowing future data points to be included in the training set for a model that is subsequently tested on past data, which is a severe form of look-ahead bias in finance. TSCV, conversely, ensures that for every split, the training data (IS) strictly precedes the validation data (OOS), and typically uses an expanding window for training to simulate the accumulation of knowledge over time. Standard CV fails in finance because the temporal dependency and non-stationarity of market data mean that using future information to predict the past yields artificially inflated and invalid performance metrics.

def time_series_splitter(data_length, n_splits, test_size):
    """
    Generates indices for Time Series Cross-Validation (TSCV).
    Ensures that the training set always precedes the validation set.
    """
    
    # Calculate the size of the initial training set
    initial_train_size = data_length - (n_splits * test_size)

    if initial_train_size < 1:
        raise ValueError("Data length is too short for the specified splits and test size.")

    # Start index for the validation block
    current_start = initial_train_size
    
    for i in range(n_splits):
        
        # Training indices: expanding window from 0 up to the current start point
        train_indices = np.arange(0, current_start)
        
        # Validation indices: fixed block immediately following the training set
        validation_start = current_start
        validation_end = current_start + test_size
        validation_indices = np.arange(validation_start, validation_end)
        
        # Yield the current split
        yield train_indices, validation_indices
        
        # Advance the window start point for the next iteration
        current_start += test_size

if __name__ == '__main__':
    TOTAL_DATA_POINTS = 100
    N_SPLITS = 4
    TEST_SIZE = 10
    
    print("--- Time Series Cross-Validation Splits ---")
    
    # 3. Demonstrate the output structure
    split_generator = time_series_splitter(TOTAL_DATA_POINTS, N_SPLITS, TEST_SIZE)
    
    for i, (train_idx, val_idx) in enumerate(split_generator):
        print(f"Split {i+1}:")
        print(f"  Train Size: {len(train_idx)} (Indices: {train_idx[0]} to {train_idx[-1]})")
        print(f"  Validation Size: {len(val_idx)} (Indices: {val_idx[0]} to {val_idx[-1]})")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
import csv
from contextlib import contextmanager

# 1. Implement the SafeDataFile Context Manager Class
class SafeDataFile:
    def __init__(self, filename, mode='r'):
        self.filename = filename
        self.mode = mode
        self.file = None

    def __enter__(self):
        # Resource acquisition: Open the file
        self.file = open(self.filename, self.mode)
        return self.file

    def __exit__(self, exc_type, exc_val, exc_tb):
        # Resource release: Close the file, guaranteed to run.
        if self.file:
            self.file.close()
        
        # Returning False ensures that if an exception occurred (e.g., ValueError), 
        # it is re-raised after the file handle is safely closed.
        return False 

# Helper function to create the simulated file
def create_simulated_corrupt_file(filename):
    data = [
        "100.5",
        "201.2",
        "ERROR_MALFORMED_DATA",
        "305.9",
        "", # Empty line
        "410.1",
        "500.0",
        "99.9",
        "INVALID-HEADER",
        "700.0"
    ]
    with open(filename, 'w') as f:
        for line in data:
            f.write(line + '\n')

if __name__ == '__main__':
    FILE_NAME = "test_market_data.csv"
    create_simulated_corrupt_file(FILE_NAME)

    processed_data = []
    line_number = 0

    # 2. Use the Context Manager and EAFP Parsing
    print("--- Starting Data Processing ---")
    try:
        with SafeDataFile(FILE_NAME, 'r') as f:
            print(f"File {FILE_NAME} successfully opened.")
            for line in f:
                line_number += 1
                cleaned_line = line.strip()
                
                # EAFP Application: Attempt to process, handle failure gracefully
                try:
                    # Attempt conversion to float. This will raise ValueError for corrupt lines.
                    if not cleaned_line:
                        raise ValueError("Empty line.")
                    
                    value = float(cleaned_line)
                    processed_data.append(value)
                except ValueError:
                    # Log the exception and continue processing
                    print(f"Warning: Skipped corrupted line {line_number}: '{cleaned_line}'")
                except Exception as e:
                    # Catch unexpected system errors
                    print(f"Critical Error on line {line_number}: {e}")

    except FileNotFoundError:
        print(f"Error: File {FILE_NAME} could not be opened.")
    
    # 3. Demonstration of successful resource release and data processing
    print("\n--- Processing Summary ---")
    print(f"Total valid data points processed: {len(processed_data)}")
    
    # Cleanup
    os.remove(FILE_NAME)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import yfinance as yf
import ccxt
import pandas as pd
from datetime import datetime, timedelta
import time
import os # Included for robustness, though not strictly used for data fetching

# --- 1. Configuration Constants ---

# Define the assets and parameters for comparison
EQUITY_TICKER = "MSFT"  # Example: Microsoft
CRYPTO_SYMBOL = "ETH/USDT"  # Example: Ethereum/Tether pair
CRYPTO_EXCHANGE_ID = 'binance' # Using a common exchange for standardized access

# Define the lookback period (e.g., last 90 days)
END_DATE = datetime.now().date()
START_DATE = END_DATE - timedelta(days=90)
INTERVAL = "1d" # Daily interval for both assets

# --- 2. Data Fetching Utilities ---

def fetch_equity_data(ticker: str, start: str, end: str, interval: str) -> pd.DataFrame:
    """Fetches historical stock data using yfinance."""
    print(f"\n[YF] Fetching equity data for {ticker}...")
    try:
        # Use auto_adjust=True to apply splits/dividends immediately for clean historical price
        data = yf.download(ticker, start=start, end=end, interval=interval, progress=False, auto_adjust=True)
        if data.empty:
            raise ValueError(f"No data returned for ticker: {ticker}")
        
        # Standardize column names to match expected OHLCV format
        data.columns = ['Open', 'High', 'Low', 'Close', 'Volume']
        return data
    except Exception as e:
        print(f"[YF] Error fetching yfinance data for {ticker}: {e}")
        return pd.DataFrame()

def fetch_crypto_data(symbol: str, exchange_id: str, start_dt: datetime, interval: str) -> pd.DataFrame:
    """Fetches historical crypto OHLCV data using CCXT."""
    print(f"\n[CCXT] Connecting to {exchange_id} and fetching data for {symbol}...")
    
    try:
        # Initialize the exchange client dynamically (unauthenticated access)
        exchange_class = getattr(ccxt, exchange_id)
        exchange = exchange_class()
        
        # CCXT requires timestamps in milliseconds (ms) for the starting point
        since_ms = int(start_dt.timestamp() * 1000)
        
        # Fetch OHLCV data using the unified CCXT interface
        ohlcv = exchange.fetch_ohlcv(symbol, timeframe=interval, since=since_ms)
        
        if not ohlcv:
            raise ValueError(f"No OHLCV data returned for {symbol} on {exchange_id}")
            
        # Convert list of lists (CCXT format) into a Pandas DataFrame
        df = pd.DataFrame(ohlcv, columns=['timestamp', 'Open', 'High', 'Low', 'Close', 'Volume'])
        
        # Convert milliseconds timestamp column back to datetime index
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        df = df.set_index('timestamp')
        
        return df[['Open', 'High', 'Low', 'Close', 'Volume']].astype(float) # Ensure numeric types
        
    except ccxt.NetworkError as e:
        print(f"[CCXT] Network Error: Could not connect to {exchange_id}. {e}")
        return pd.DataFrame()
    except Exception as e:
        print(f"[CCXT] General Error fetching CCXT data: {e}")
        return pd.DataFrame()

# --- 3. Normalization and Analysis ---

def normalize_and_compare(equity_df: pd.DataFrame, crypto_df: pd.DataFrame, initial_index_value: int = 100) -> pd.DataFrame:
    """
    Aligns, merges, and normalizes the two datasets to a common starting point (100).
    """
    
    if equity_df.empty or crypto_df.empty:
        print("Normalization failed: One or both source datasets are empty.")
        return pd.DataFrame()

    # CRITICAL STEP 1: Timezone Standardization
    # yfinance often returns naive index; CCXT returns UTC index. We must align them.
    # Convert any timezone-aware index to naive (localizing to UTC first if necessary, then stripping TZ)
    equity_df.index = equity_df.index.tz_localize(None) if equity_df.index.tz is not None else equity_df.index
    crypto_df.index = crypto_df.index.tz_localize(None) if crypto_df.index.tz is not None else crypto_df.index

    # CRITICAL STEP 2: Market Alignment (24/7 vs. Business Days)
    # Equity markets trade only on business days (usually 5 days/week). Crypto trades 7 days/week.
    # We resample the 7-day crypto data to align its closing price with the equity market's trading days.
    # We use 'D' (Daily) resample and then drop non-trading days later via the merge.
    crypto_resampled = crypto_df['Close'].resample('D').ffill() # Forward fill ensures we use the last available price
    equity_resampled = equity_df['Close']
    
    # CRITICAL STEP 3: Merging and Index Intersection
    # Concatenate the two series. This creates NaN values where one asset traded and the other did not.
    combined_df = pd.concat(
        {
            'Equity_Close': equity_resampled,
            'Crypto_Close': crypto_resampled
        },
        axis=1
    ).dropna() # Drop rows where data is missing in *either* asset (Intersection of indices)
    
    if combined_df.empty:
        print("Normalization failed: No overlapping dates found after alignment.")
        return pd.DataFrame()
    
    # CRITICAL STEP 4: Normalization Calculation
    # Calculate the performance index: Normalized Price = (Current Close / First Close) * 100
    first_equity_price = combined_df['Equity_Close'].iloc[0]
    first_crypto_price = combined_df['Crypto_Close'].iloc[0]

    combined_df['Equity_Index'] = (combined_df['Equity_Close'] / first_equity_price) * initial_index_value
    combined_df['Crypto_Index'] = (combined_df['Crypto_Close'] / first_crypto_price) * initial_index_value
    
    return combined_df[['Equity_Index', 'Crypto_Index']]

# --- 4. Main Execution Block ---

if __name__ == "__main__":
    
    print("--- Starting Cross-Asset Data Harvester ---")
    
    # 1. Fetch Data
    equity_data = fetch_equity_data(
        EQUITY_TICKER, 
        start=START_DATE.strftime('%Y-%m-%d'), 
        end=END_DATE.strftime('%Y-%m-%d'), 
        interval=INTERVAL
    )
    
    # Ensure the CCXT start date is a datetime object combined with midnight for accurate 'since' timestamp
    crypto_start_dt = datetime.combine(START_DATE, datetime.min.time())
    crypto_data = fetch_crypto_data(
        CRYPTO_SYMBOL, 
        CRYPTO_EXCHANGE_ID, 
        start_dt=crypto_start_dt,
        interval=INTERVAL
    )
    
    # 2. Process and Normalize
    performance_index = normalize_and_compare(equity_data, crypto_data)
    
    # 3. Output Results
    if not performance_index.empty:
        
        print("\n==================================================")
        print("--- FINAL CROSS-ASSET PERFORMANCE INDEX SUMMARY ---")
        print("==================================================")
        print(f"Analysis Period: {performance_index.index.min().date()} to {performance_index.index.max().date()}")
        print(f"Common Data Points: {len(performance_index)} days")
        
        # Display the first and last few rows of the normalized index
        print("\nIndex Head (Starting at 100.00):")
        print(performance_index.head().round(2))
        
        print("\nIndex Tail (Final Performance):")
        print(performance_index.tail().round(2))
        
        # Calculate total return over the period
        equity_final_index = performance_index['Equity_Index'].iloc[-1]
        crypto_final_index = performance_index['Crypto_Index'].iloc[-1]
        
        equity_return = (equity_final_index - 100)
        crypto_return = (crypto_final_index - 100)
        
        print("\n--- Total Return Comparison (Normalized) ---")
        print(f"{EQUITY_TICKER} (Equity) Total Return: {equity_return:.2f}%")
        print(f"{CRYPTO_SYMBOL} (Crypto) Total Return: {crypto_return:.2f}%")
        
        # Simple Outperformance Conclusion
        if abs(equity_return - crypto_return) < 0.01:
            print("\nConclusion: Performance was nearly identical.")
        elif equity_return > crypto_return:
            print(f"\nConclusion: {EQUITY_TICKER} significantly outperformed {CRYPTO_SYMBOL} during this period.")
        else:
            print(f"\nConclusion: {CRYPTO_SYMBOL} significantly outperformed {EQUITY_TICKER} during this period.")


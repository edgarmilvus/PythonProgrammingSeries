
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import yfinance as yf
import pandas as pd

# 1. Ticker List
ETF_TICKERS = ['VOO', 'QQQ', 'SPY']

# 2. DRY Implementation (Function 1)
def get_ticker_object(symbol):
    """Initializes and returns the yfinance Ticker object."""
    try:
        return yf.Ticker(symbol)
    except Exception as e:
        print(f"Error initializing Ticker object for {symbol}: {e}")
        return None

# 3. Data Retrieval Function (Function 2 - Prices)
def fetch_prices(ticker_obj, period='1y'):
    """Fetches historical price data using the Ticker object."""
    if ticker_obj is None:
        return pd.DataFrame()
    return ticker_obj.history(period=period)

# 4. Data Retrieval Function (Function 3 - Dividends/Splits)
def fetch_corporate_actions(ticker_obj):
    """Fetches dividend and split history using the Ticker object."""
    if ticker_obj is None:
        return {'dividends': pd.DataFrame(), 'splits': pd.DataFrame()}
    
    # Retrieve both dataframes
    dividends = ticker_obj.dividends.to_frame(name='Dividend')
    splits = ticker_obj.splits.to_frame(name='Split')
    
    return {'dividends': dividends, 'splits': splits}

# 5. Aggregation and Main Loop
aggregated_data = {}

print("--- Starting Data Retrieval (DRY Approach) ---")
for ticker_symbol in ETF_TICKERS:
    print(f"Processing {ticker_symbol}...")
    
    # Centralized Object Initialization (DRY)
    ticker_obj = get_ticker_object(ticker_symbol)
    
    if ticker_obj:
        # Fetch prices using the object
        prices = fetch_prices(ticker_obj, period='6mo')
        
        # Fetch corporate actions using the same object
        actions = fetch_corporate_actions(ticker_obj)
        
        aggregated_data[ticker_symbol] = {
            'prices': prices,
            'actions': actions
        }

# 6. Output Verification
if 'SPY' in aggregated_data:
    print("\n--- Verification: SPY Dividend History (First 5 Rows) ---")
    spy_dividends = aggregated_data['SPY']['actions']['dividends']
    print(spy_dividends.head())
    print(f"\nSPY Price Data Shape: {aggregated_data['SPY']['prices'].shape}")

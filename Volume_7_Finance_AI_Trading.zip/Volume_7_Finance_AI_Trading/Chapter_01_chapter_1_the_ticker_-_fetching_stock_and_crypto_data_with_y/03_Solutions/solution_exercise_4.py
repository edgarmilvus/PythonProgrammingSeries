
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import yfinance as yf
import ccxt
import pandas as pd
from datetime import datetime

class UnifiedFetcher:
    
    def __init__(self, exchange_id='binance'):
        """Initializes the CCXT exchange object."""
        try:
            self.exchange = getattr(ccxt, exchange_id)()
            self.exchange.load_markets()
            print(f"UnifiedFetcher initialized. Crypto exchange: {exchange_id}")
        except Exception as e:
            print(f"Warning: Could not initialize CCXT exchange {exchange_id}. Crypto fetching disabled. Error: {e}")
            self.exchange = None
            
    def _fetch_equity(self, symbol, timeframe, start_date, end_date):
        """Internal method to fetch and standardize yfinance data."""
        try:
            data = yf.download(
                symbol,
                start=start_date,
                end=end_date,
                interval=timeframe,
                progress=False
            )
            
            if data.empty:
                return pd.DataFrame()

            # 1. Standardize Index to UTC
            if data.index.tz is None:
                data = data.tz_localize('America/New_York', ambiguous='infer')
            data = data.tz_convert('UTC')

            # 2. Standardize Columns
            # Drop 'Adj Close' for consistency with crypto data
            data = data[['Open', 'High', 'Low', 'Close', 'Volume']]
            
            return data
            
        except Exception as e:
            print(f"YFinance Error for {symbol}: {e}")
            return pd.DataFrame()

    def _fetch_crypto(self, symbol, timeframe):
        """Internal method to fetch and standardize CCXT data."""
        if not self.exchange:
            print("Crypto fetching failed: Exchange not initialized.")
            return pd.DataFrame()
        
        # CCXT requires limits, not date ranges for simplicity here
        limit = 500 
        
        try:
            ohlcv = self.exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
            
            if not ohlcv:
                return pd.DataFrame()

            # Convert to DataFrame
            columns = ['Timestamp', 'Open', 'High', 'Low', 'Close', 'Volume']
            df = pd.DataFrame(ohlcv, columns=columns)

            # Convert Unix milliseconds to UTC datetime index
            df['Timestamp'] = pd.to_datetime(df['Timestamp'], unit='ms', utc=True)
            df.set_index('Timestamp', inplace=True)
            
            return df
            
        except ccxt.NetworkError as e:
            print(f"CCXT Network Error (Rate Limit/Connection) for {symbol}: {e}")
            return pd.DataFrame()
        except Exception as e:
            print(f"CCXT General Error for {symbol}: {e}")
            return pd.DataFrame()
            
    def fetch_historical_data(self, symbol, timeframe, start_date=None, end_date=None):
        """
        Routes the request based on asset type.
        """
        print(f"\n--- Fetching {symbol} ({timeframe}) ---")
        
        # 2. Conditional Logic
        if '/' in symbol:
            print("Detected Crypto Asset.")
            # Crypto fetching doesn't use start/end dates easily, relies on timeframe/limit
            data = self._fetch_crypto(symbol, timeframe)
        else:
            print("Detected Equity Asset.")
            # Equity fetching requires date range
            if start_date is None or end_date is None:
                 # Default to last 30 days if dates are missing for equity
                end_date = datetime.now().strftime('%Y-%m-%d')
                start_date = (datetime.now() - pd.Timedelta(days=30)).strftime('%Y-%m-%d')
                print(f"Using default dates: {start_date} to {end_date}")
            
            data = self._fetch_equity(symbol, timeframe, start_date, end_date)

        # 4. Error Handling and Return
        if data.empty:
            print(f"Failed to retrieve data for {symbol}.")
            return None
        
        # 3. Data Consistency Check
        print(f"Success. Data shape: {data.shape}")
        return data

# --- Demonstration ---
fetcher = UnifiedFetcher(exchange_id='binance')

# 1. Equity Retrieval (MSFT, 1 day)
msft_data = fetcher.fetch_historical_data('MSFT', '1d')

# 2. Crypto Retrieval (ADA/USDT, 4 hours)
ada_data = fetcher.fetch_historical_data('ADA/USDT', '4h')

print("\n--- MSFT Data Verification ---")
if msft_data is not None:
    print(msft_data.head())
    print(f"MSFT Columns: {list(msft_data.columns)}")
    print(f"MSFT Index Timezone: {msft_data.index.tz}")

print("\n--- ADA/USDT Data Verification ---")
if ada_data is not None:
    print(ada_data.tail())
    print(f"ADA Columns: {list(ada_data.columns)}")
    print(f"ADA Index Timezone: {ada_data.index.tz}")

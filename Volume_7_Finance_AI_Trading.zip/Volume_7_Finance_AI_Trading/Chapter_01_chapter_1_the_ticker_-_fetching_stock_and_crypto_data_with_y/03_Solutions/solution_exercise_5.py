
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import yfinance as yf
import ccxt
import pandas as pd
from datetime import datetime, timedelta

# Define period (30 days ago to today)
end_date = datetime.now().strftime('%Y-%m-%d')
start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')

# --- 1. Retrieve Raw Data ---

# 1a. Equity Data (SPY)
spy_raw = yf.download('SPY', start=start_date, end=end_date, interval='1d', progress=False)
print(f"Retrieved SPY data shape: {spy_raw.shape}")

# 1b. Crypto Data (ETH/USDT) using CCXT (using simplified fetch for daily data)
exchange = ccxt.binance()
# CCXT requires 'since' (milliseconds) for date range. Calculate start time in ms.
since_ms = int(datetime.strptime(start_date, '%Y-%m-%d').timestamp() * 1000)

eth_ohlcv = exchange.fetch_ohlcv('ETH/USDT', timeframe='1d', since=since_ms)
eth_raw = pd.DataFrame(eth_ohlcv, columns=['Timestamp', 'Open', 'High', 'Low', 'Close', 'Volume'])
eth_raw['Timestamp'] = pd.to_datetime(eth_raw['Timestamp'], unit='ms', utc=True)
eth_raw.set_index('Timestamp', inplace=True)
print(f"Retrieved ETH/USDT data shape: {eth_raw.shape}")


# --- 2. Standardize Equity Index & Rename ---
# Convert index to UTC (if naive/localized) and then strip time to get date only.
if spy_raw.index.tz is None:
    # Assume market close time in NY timezone
    spy_raw = spy_raw.tz_localize('America/New_York', ambiguous='infer')
spy_raw = spy_raw.tz_convert('UTC')

# Convert index to date only
spy_raw.index = spy_raw.index.date
spy_data = spy_raw[['Close']].rename(columns={'Close': 'SPY_Close'})

# --- 3. Standardize Crypto Index & Rename ---
# Convert index to date only
eth_raw.index = eth_raw.index.date
eth_data = eth_raw[['Close']].rename(columns={'Close': 'ETH_Close'})

print("\n--- Standardized Data Verification ---")
print(f"SPY Index Type: {type(spy_data.index[0])}")
print(f"ETH Index Type: {type(eth_data.index[0])}")


# --- 4. Perform Outer Merge ---
# Merge on the shared date index
merged_df = pd.merge(spy_data, eth_data, left_index=True, right_index=True, how='outer')

print("\n--- Merged Data Head (Showing potential NaNs) ---")
print(merged_df.head(10))

# --- 5. Analysis Question ---
# Filter for rows where SPY data is missing but ETH data is present
missing_spy_data = merged_df[merged_df['SPY_Close'].isnull() & merged_df['ETH_Close'].notnull()]

print("\n--- Days where SPY is Missing but ETH is Present ---")
print(missing_spy_data)

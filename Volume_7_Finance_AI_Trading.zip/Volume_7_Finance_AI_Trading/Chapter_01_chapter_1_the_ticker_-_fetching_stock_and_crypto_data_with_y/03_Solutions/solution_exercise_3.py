
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import ccxt
import pandas as pd
import datetime

def fetch_and_standardize_crypto_data(exchange_id, symbol, timeframe, limit):
    """
    Connects to an exchange, fetches OHLCV data, and standardizes it 
    into a pandas DataFrame with a datetime index.
    """
    
    # 1. Exchange Instantiation
    try:
        exchange = getattr(ccxt, exchange_id)()
        # Ensure the exchange is loaded (necessary for some CCXT versions)
        exchange.load_markets()
    except Exception as e:
        print(f"Error initializing CCXT exchange {exchange_id}: {e}")
        return pd.DataFrame()

    # 2. Data Fetching
    try:
        # Fetch OHLCV data (list of lists)
        ohlcv = exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
    except Exception as e:
        print(f"Error fetching OHLCV for {symbol} on {exchange_id}: {e}")
        return pd.DataFrame()

    if not ohlcv:
        print(f"No data returned for {symbol}.")
        return pd.DataFrame()

    # 3. Normalization to DataFrame
    # 4. Column Renaming
    columns = ['Timestamp', 'Open', 'High', 'Low', 'Close', 'Volume']
    df = pd.DataFrame(ohlcv, columns=columns)

    # 5. Index Conversion
    # CCXT timestamps are typically Unix milliseconds (ms). Convert to seconds, then datetime.
    df['Timestamp'] = pd.to_datetime(df['Timestamp'], unit='ms', utc=True)
    df.set_index('Timestamp', inplace=True)
    
    return df

# --- Demonstration ---
exchange_name = 'binance'
pair = 'BTC/USDT'
timeframe = '1h'
limit_data = 500

btc_data = fetch_and_standardize_crypto_data(exchange_name, pair, timeframe, limit_data)

if not btc_data.empty:
    print(f"\n--- Standardization Verification for {pair} on {exchange_name} ---")
    
    # Verification 1: Structure
    btc_data.info()
    
    print("\nVerification 2: Last 10 Rows")
    print(btc_data.tail(10))
else:
    print("Crypto data retrieval failed.")

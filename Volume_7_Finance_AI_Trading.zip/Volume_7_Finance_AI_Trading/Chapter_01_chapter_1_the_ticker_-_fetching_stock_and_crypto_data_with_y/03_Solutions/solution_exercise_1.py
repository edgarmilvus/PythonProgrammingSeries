
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import yfinance as yf
import pandas as pd
from datetime import datetime

def fetch_and_clean_ticker_data(ticker, start_date, end_date, interval='1d'):
    """
    Fetches historical data, standardizes the index to UTC, and cleans missing values.
    """
    try:
        # 1. Data Retrieval
        data = yf.download(
            ticker,
            start=start_date,
            end=end_date,
            interval=interval,
            progress=False
        )

        if data.empty:
            print(f"Error: No data returned for ticker {ticker} or invalid date range.")
            return pd.DataFrame()

        # 2. Index Validation and Standardization (Convert to UTC)
        # yfinance often returns localized data (e.g., America/New_York) or naive index.
        # We enforce standardization to UTC.
        if data.index.tz is None:
            # Assume yfinance daily data is market close time in NY timezone (EST/EDT)
            # This is a necessary assumption for naive indices from yf
            data = data.tz_localize('America/New_York', ambiguous='infer')
        
        data = data.tz_convert('UTC')

        # 3. Missing Data Handling (Ffill on 'Close')
        # Check for NaNs and apply forward fill only to the 'Close' column
        if data['Close'].isnull().any():
            print(f"Warning: Missing 'Close' values found for {ticker}. Applying Ffill.")
            data['Close'] = data['Close'].ffill()
        
        # Drop any remaining NaNs (e.g., rows where Ffill couldn't fill the first value)
        data.dropna(inplace=True)

        return data

    except Exception as e:
        print(f"An unexpected error occurred during retrieval for {ticker}: {e}")
        return pd.DataFrame()

# --- Demonstration ---
ticker_symbol = 'AAPL'
start = '2023-01-01'
end = '2023-03-01' # Choose a short period for demonstration

aapl_data = fetch_and_clean_ticker_data(ticker_symbol, start, end)

if not aapl_data.empty:
    print(f"\nSuccessfully retrieved and cleaned data for {ticker_symbol}.")
    print(aapl_data.head())
    print(f"\nIndex Timezone: {aapl_data.index.tz}")
    print(f"Total Rows after cleaning: {len(aapl_data)}")
else:
    print("Data retrieval failed.")

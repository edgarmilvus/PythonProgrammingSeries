
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta
import sys

# --- 1. Configuration and Setup ---

# Define the security we wish to analyze.
TICKER_SYMBOL = "AAPL" # Apple Inc. (A well-known, highly liquid stock)

# Define the desired lookback window in calendar days.
DAYS_TO_FETCH = 45     # Fetching 45 calendar days of data

# --- 2. Dynamic Date Calculation ---

# Get today's date and format it for the API call (YYYY-MM-DD).
# Note: The 'end' date in yfinance is exclusive (data is fetched up to, but not including, this date).
try:
    end_date_dt = datetime.now()
    end_date_str = end_date_dt.strftime('%Y-%m-%d')

    # Calculate the start date by subtracting the lookback period.
    start_date_dt = end_date_dt - timedelta(days=DAYS_TO_FETCH)
    start_date_str = start_date_dt.strftime('%Y-%m-%d')

except Exception as e:
    print(f"Critical Error during Date Calculation: {e}")
    sys.exit(1) # Halt execution if dates cannot be calculated

# --- 3. Ticker Object Instantiation ---

# Instantiate the Ticker object. This object encapsulates all data and methods
# specific to the defined security (AAPL).
try:
    security_ticker = yf.Ticker(TICKER_SYMBOL)
except Exception as e:
    print(f"Error instantiating Ticker object: {e}")
    sys.exit(1)

print(f"--- Data Fetching Parameters ---")
print(f"Security: {TICKER_SYMBOL}")
print(f"Requested Period: {DAYS_TO_FETCH} days")
print(f"Calculated Start Date: {start_date_str}")
print(f"Calculated End Date (Exclusive): {end_date_str}\n")


# --- 4. Fetching Historical Data ---

# Use the .history() method to retrieve the time-series price data.
# interval='1d' specifies daily data (the default, but explicitly stated for clarity).
try:
    historical_data = security_ticker.history(
        start=start_date_str,
        end=end_date_str,
        interval='1d',
        auto_adjust=True # Automatically adjust prices for splits and dividends
    )

# 5. Output and Inspection (Robustness Check)
    if historical_data.empty:
        print("Warning: Retrieved DataFrame is empty. Check ticker symbol or date range (e.g., weekends/holidays).")
    else:
        print("--- Data Retrieval Successful ---")
        print(f"Data Shape (Rows, Columns): {historical_data.shape}")
        print(f"Data Index Type: {type(historical_data.index)}")

        print("\n--- First 5 Rows (Head) ---")
        print(historical_data.head())

        print("\n--- Data Types of Columns ---")
        print(historical_data.dtypes)

        print("\n--- Key Metrics: Closing Price Summary ---")
        # Use the describe() method on the 'Close' column for statistical overview
        print(historical_data['Close'].describe())

except Exception as e:
    print(f"An unexpected error occurred during data fetching: {e}")
    print("Please check your network connection or if the ticker symbol is valid.")


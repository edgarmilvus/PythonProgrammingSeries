
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import json
import time

# --- Mock OpenAI Client Structure ---
# We define a placeholder structure to simulate the real library for patching
class MockOpenAI:
    class ChatCompletion:
        @staticmethod
        def create(model, messages, **kwargs):
            # This should never be reached during the test
            raise RuntimeError("Real API call attempted! Patching failed.")

openai = MockOpenAI() 

# 1. Define the mock response object structure
MOCK_SUCCESS_RESPONSE = {
    "choices": [
        {
            "message": {
                "content": '{"Stocks": 0.60, "Bonds": 0.30, "Cash": 0.10}'
            }
        }
    ]
}

# 2. Define the mock function
def mock_openai_call(model, messages, **kwargs):
    """
    Mock function that replaces openai.ChatCompletion.create.
    It returns a predictable, successful structured response instantly.
    """
    time.sleep(0.01) # Simulate minimal processing time
    print(f"--- MOCK API CALLED (Model: {model}) ---")
    return MOCK_SUCCESS_RESPONSE

class PortfolioRecommender:
    """A simplified class demonstrating API interaction and parsing."""
    def get_recommendation(self, profile: dict) -> dict:
        # This method calls whatever function is currently assigned to openai.ChatCompletion.create
        response = openai.ChatCompletion.create(
            model="gpt-4-turbo",
            messages=[{"role": "user", "content": "Generate portfolio for " + str(profile)}]
        )
        raw_output = response['choices'][0]['message']['content']
        
        # Simple parsing and validation check
        try:
            portfolio = json.loads(raw_output)
            if abs(sum(portfolio.values()) - 1.0) < 0.01:
                return {"status": "Success", "portfolio": portfolio}
            else:
                return {"status": "Validation Failed", "portfolio": portfolio}
        except json.JSONDecodeError:
            return {"status": "Parsing Failed"}

def test_mocking_api():
    """Implements monkey patching and verification."""
    
    # Store the original function reference
    original_create = openai.ChatCompletion.create
    
    try:
        # 3. Apply the Patch (Monkey Patching)
        openai.ChatCompletion.create = mock_openai_call
        print("Patch applied: openai.ChatCompletion.create is now mocked.")
        
        # 4. Run the test using the patched function
        recommender = PortfolioRecommender()
        test_profile = {"risk": "Low", "capital": 50000}
        result = recommender.get_recommendation(test_profile)
        
        # Verification
        assert result['status'] == "Success"
        assert result['portfolio']['Stocks'] == 0.60
        print("\nVerification successful: Mock response was correctly processed.")
        
    finally:
        # 4. Cleanup: Restore the original function
        openai.ChatCompletion.create = original_create
        print("Cleanup complete: Original API function restored.")

# test_mocking_api()

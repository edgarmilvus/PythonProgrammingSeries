
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import os
import logging
import json

# --- Setup Logging Configuration ---
LOG_DIRECTORY = "logs"
LOG_FILE_NAME = "guardrail_audit.log"
LOG_PATH = os.path.join(LOG_DIRECTORY, LOG_FILE_NAME)

# Ensure the log directory exists and configure logging
os.makedirs(LOG_DIRECTORY, exist_ok=True)
logging.basicConfig(
    filename=LOG_PATH, 
    level=logging.INFO, # We want to log INFO for success, CRITICAL for failure
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def apply_guardrails_and_log(portfolio_weights: dict, investor_profile: dict) -> bool:
    """
    Enforces internal risk limits (guardrails) on the portfolio recommendation.
    Returns True if safe to execute, False if breach detected.
    """
    HIGH_RISK_ASSETS = ["Crypto", "Venture Capital", "High-Yield Junk Bonds", "Speculative Tech"]
    MAX_RISK_ALLOCATION = 0.10 # 10% limit
    
    risk_tolerance = investor_profile.get('risk_tolerance', 'Unknown')
    
    # 1. Guardrail Logic: Check if the rule applies
    if risk_tolerance in ['Conservative', 'Moderate']:
        
        # 2. Calculate total high-risk exposure
        high_risk_exposure = 0.0
        for asset, weight in portfolio_weights.items():
            # Check if the asset key contains any of the high-risk identifiers (case-insensitive check)
            if any(risk_asset.lower() in asset.lower() for risk_asset in HIGH_RISK_ASSETS):
                high_risk_exposure += weight
        
        # 3. Check for breach
        if high_risk_exposure > MAX_RISK_ALLOCATION:
            
            # 4. Conditional Logging (CRITICAL)
            breach_message = (
                f"GUARDRAIL BREACH DETECTED: Profile '{risk_tolerance}' exceeded "
                f"{MAX_RISK_ALLOCATION*100}% high-risk limit (Exposure: {high_risk_exposure:.2f}). "
                f"Portfolio: {json.dumps(portfolio_weights)}"
            )
            logger.critical(breach_message)
            print(f"CRITICAL: Guardrail breach logged to {LOG_PATH}. Execution halted.")
            
            # 5. Execution Control
            return False # Halt execution
        
    # If guardrail passes or doesn't apply (e.g., Aggressive profile)
    logger.info(f"Guardrails passed for {risk_tolerance} profile. High-Risk Exposure: {high_risk_exposure:.2f}")
    return True # Proceed with execution

# --- Test Cases Demonstration ---
conservative_profile = {"risk_tolerance": "Conservative"}

# Case 1: Breach (15% high risk)
breach_portfolio = {
    "Stocks": 0.50, "Bonds": 0.30, "Cash": 0.05, "Crypto": 0.10, "Speculative Tech": 0.05
}
# print("\n--- Running Breach Test ---")
# execution_status_breach = apply_guardrails_and_log(breach_portfolio, conservative_profile) 
# print(f"Execution Status: {execution_status_breach}")

# Case 2: Pass (9% high risk)
safe_portfolio = {
    "Stocks": 0.50, "Bonds": 0.41, "Cash": 0.00, "Crypto": 0.09
}
# print("\n--- Running Pass Test ---")
# execution_status_pass = apply_guardrails_and_log(safe_portfolio, conservative_profile) 
# print(f"Execution Status: {execution_status_pass}")

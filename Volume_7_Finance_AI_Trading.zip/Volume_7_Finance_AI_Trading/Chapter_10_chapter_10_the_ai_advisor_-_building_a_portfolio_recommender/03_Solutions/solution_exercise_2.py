
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import json

SYSTEM_PROMPT = """
You are a fiduciary financial advisor. Your task is to analyze the provided investor profile and current market conditions 
and output a portfolio allocation strictly in JSON format. Do not include any text outside the JSON object. 
The keys must be asset classes (e.g., 'Stocks', 'Bonds', 'Real Estate'). The values must be floats summing precisely to 1.0.
"""

USER_TEMPLATE = """
Investor Profile:
- Risk Tolerance: {risk_tolerance}
- Investment Horizon: {investment_horizon} years
- Capital: ${current_capital:,.2f}

Market Context:
- Current Inflation Rate: {inflation_rate}%
- Market Sentiment: {current_market_sentiment}

Based on this context, provide the optimal portfolio allocation.
"""

def construct_full_prompt(profile_data: dict) -> list[dict]:
    """
    Constructs the full prompt message list for the OpenAI API using 
    the system prompt and dynamically formatted user template.
    """
    
    # 1. Format the user message using str.format and dictionary unpacking
    # This safely handles the required currency formatting (:,.2f)
    try:
        user_message_content = USER_TEMPLATE.format(**profile_data)
    except KeyError as e:
        raise ValueError(f"Missing required key in profile_data: {e}")
    
    # 2. Structure the output as a list of messages for the API
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_message_content}
    ]
    
    return messages

# Example Usage and Verification:
profile = {
    "risk_tolerance": "Moderate",
    "investment_horizon": 15,
    "current_capital": 150000.50,
    "inflation_rate": 3.5,
    "current_market_sentiment": "Neutral"
}
# full_prompt = construct_full_prompt(profile)
# print(json.dumps(full_prompt, indent=2))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Reusing and modifying components from Exercise 2
SYSTEM_PROMPT_3 = """
You are a fiduciary financial advisor. Your task is to analyze the provided investor profile and current market conditions, 
including volatility context, and output a portfolio allocation strictly in JSON format. 
"""

USER_TEMPLATE_3 = """
Investor Profile:
- Risk Tolerance: {risk_tolerance}
- Investment Horizon: {investment_horizon} years
- Capital: ${current_capital:,.2f}

Market Context:
- Current Inflation Rate: {inflation_rate}%
- Market Sentiment: {current_market_sentiment}
- Volatility Status (VIX): {vix_status}

Based on this context, provide the optimal portfolio allocation. 
CRITICAL RULE: If Volatility Status is 'High Volatility', the portfolio must prioritize capital preservation, 
leading to a significantly higher allocation to Cash and Bonds, and a lower allocation to Stocks/Equities.
"""

def get_current_vix_status(vix_level: float) -> str:
    """Simulates fetching the VIX index level and categorizing volatility."""
    if vix_level < 15.0:
        return 'Low Volatility'
    elif 15.0 <= vix_level <= 25.0:
        return 'Medium Volatility'
    else: # VIX > 25.0
        return 'High Volatility'

def construct_full_prompt_vix(profile_data: dict, vix_status: str) -> list[dict]:
    """Constructs the prompt, integrating the VIX status."""
    
    context_data = profile_data.copy()
    context_data['vix_status'] = vix_status
    
    user_message_content = USER_TEMPLATE_3.format(**context_data)
    
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT_3},
        {"role": "user", "content": user_message_content}
    ]
    
    return messages

# --- Behavioral Test Demonstration ---
investor_profile = {
    "risk_tolerance": "Moderate",
    "investment_horizon": 10,
    "current_capital": 100000,
    "inflation_rate": 3.0,
    "current_market_sentiment": "Neutral"
}

# Test A: Low Volatility (VIX = 12.0)
vix_status_A = get_current_vix_status(12.0)
prompt_A = construct_full_prompt_vix(investor_profile, vix_status_A)
# Expected GPT-4 behavior: Standard Moderate allocation (e.g., 60% Stocks, 30% Bonds)

# Test B: High Volatility (VIX = 30.0)
vix_status_B = get_current_vix_status(30.0)
prompt_B = construct_full_prompt_vix(investor_profile, vix_status_B)
# Expected GPT-4 behavior: Defensive Moderate allocation (e.g., 35% Stocks, 45% Bonds, 20% Cash)

# print("--- Test A Context (Low Volatility) ---")
# print(prompt_A[1]['content'])
# print("\n--- Test B Context (High Volatility) ---")
# print(prompt_B[1]['content'])

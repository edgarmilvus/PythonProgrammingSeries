
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import os
import json
from openai import OpenAI
from typing import Dict, Any

# --- 1. Configuration and Client Initialization ---

# 1.1. Safety check for the API key environment variable
# In a robust financial application, API keys must never be hardcoded.
if "OPENAI_API_KEY" not in os.environ:
    # This placeholder is for explanation purposes only.
    # In a real environment, this check would halt execution.
    print("WARNING: OPENAI_API_KEY environment variable not found. Using placeholder initialization.")
    # For execution, ensure the key is loaded externally.
    
# 1.2. Initialize the OpenAI client
# The client automatically authenticates using the environment variable.
try:
    client = OpenAI() 
except Exception as e:
    print(f"Error initializing OpenAI client: {e}")
    # Exit or handle gracefully if initialization fails

# --- 2. Define the Structured Output Schema (The Contract) ---
# This dictionary represents the required JSON structure, ensuring consistency.
RECOMMENDATION_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "risk_profile": {
            "type": "string", 
            "description": "The interpreted risk profile (e.g., Aggressive, Moderate, Conservative)."
        },
        "market_view": {
            "type": "string", 
            "description": "A brief summary of the market conditions factored into the advice."
        },
        "allocation": {
            "type": "array",
            "description": "The recommended asset allocation breakdown.",
            "items": {
                "type": "object",
                "properties": {
                    "asset_class": {
                        "type": "string", 
                        "description": "Name of the asset class (e.g., US Large Cap Equities, Treasury Bonds, Gold)."
                    },
                    "weighting_percent": {
                        "type": "number", 
                        "description": "The percentage weight (0.0 to 100.0) assigned to this asset class."
                    },
                    "rationale": {
                        "type": "string", 
                        "description": "A short justification for this specific weighting based on the profile and market view."
                    }
                },
                "required": ["asset_class", "weighting_percent", "rationale"]
            }
        },
        "total_weighting": {
            "type": "number", 
            "description": "The sum of all weighting_percent values in the allocation array, which MUST equal 100.0."
        }
    },
    # Ensure these top-level keys are always present in the final output
    "required": ["risk_profile", "market_view", "allocation", "total_weighting"]
}

# --- 3. Define the Prompt Templates and Input Data ---

# System Prompt: Enforces the LLM's identity and strict output rules.
SYSTEM_PROMPT = (
    "You are a highly specialized quantitative financial advisor. Your sole task is to analyze "
    "an investor's profile and current market conditions, and generate a precise, actionable "
    "portfolio recommendation. You MUST respond ONLY with a JSON object that strictly adheres "
    "to the provided schema. Ensure the 'total_weighting' equals 100.0."
)

# User Input: The natural language data provided by the user/system.
INVESTOR_PROFILE = (
    "I am a 40-year-old investor with substantial capital. My risk tolerance is high, "
    "but I require liquidity. I believe the current high-interest rate environment favors "
    "short-term fixed income over long-term bonds, and I anticipate a strong rebound in "
    "non-US emerging markets over the next 18 months."
)

# --- 4. Function to Execute the LLM Call with Structured Output ---

def get_structured_portfolio_advice(profile: str) -> Dict[str, Any]:
    """
    Executes the LLM API call, enforcing JSON output via the response_format parameter.
    """
    print(f"\n[INFO] Submitting profile for analysis...")
    
    try:
        # 4.1. Construct the API call
        response = client.chat.completions.create(
            model="gpt-4o", # Model selection is critical for reliability and complex reasoning
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": f"Investor Profile: {profile}"}
            ],
            # 4.2. CRITICAL STEP: Enforce JSON output format
            # This parameter tells the model's engine to constrain its output to valid JSON.
            response_format={"type": "json_object"} 
            # Note: For even stricter validation (not shown here), you could pass the schema
            # directly to the 'json_schema' parameter if using specific libraries or endpoints.
        )

        # 4.3. Extract the raw content
        # The content is guaranteed (by the API call) to be a valid JSON string.
        json_output_string = response.choices[0].message.content
        
        # 4.4. Parse the string into a native Python dictionary
        portfolio_advice = json.loads(json_output_string)
        
        return portfolio_advice

    except json.JSONDecodeError as e:
        # This catch is usually redundant when using response_format={"type": "json_object"} 
        # but is good practice for robustness.
        print(f"[ERROR] Failed to decode JSON response: {e}")
        return {}
    except Exception as e:
        print(f"[CRITICAL ERROR] An API or network error occurred: {e}")
        return {}

# --- 5. Execution and Actionable Data Extraction ---

if __name__ == "__main__":
    
    # Execute the function to get the structured advice
    recommendation_data = get_structured_portfolio_advice(INVESTOR_PROFILE)

    if recommendation_data:
        print("\n" + "="*70)
        print("RECEIVED STRUCTURED PORTFOLIO RECOMMENDATION")
        print("="*70)
        
        # Pretty print the entire JSON output for inspection
        print(json.dumps(recommendation_data, indent=4)) 
        
        # Actionable step: Immediate extraction of data for automated processing
        print("\n--- Actionable Data Ingestion ---")
        
        # 5.1. Perform a quick validation check
        total_weight = recommendation_data.get("total_weighting", 0.0)
        if abs(total_weight - 100.0) > 0.01:
            print(f"[VALIDATION ALERT] Total weight is {total_weight}%, not 100%. Review recommendation.")
            
        # 5.2. Loop through the allocation list for direct integration
        for item in recommendation_data.get("allocation", []):
            asset = item['asset_class']
            weight = item['weighting_percent']
            
            # This data (asset, weight) is now ready to be passed to a database, 
            # a backtesting engine (like Zipline or Backtrader), or a live execution system.
            print(f"  > EXECUTE ORDER: Allocate {weight:.2f}% to Asset Class: {asset}")
            print(f"    Rationale Snippet: {item['rationale'][:60]}...")
            
    else:
        print("\n[FAILURE] No valid recommendation data was returned.")


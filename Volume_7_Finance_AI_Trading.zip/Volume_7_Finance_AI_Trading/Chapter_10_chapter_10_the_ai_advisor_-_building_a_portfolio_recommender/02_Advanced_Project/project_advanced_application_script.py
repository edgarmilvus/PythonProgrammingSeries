
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import json
from typing import List
from pydantic import BaseModel, Field, ValidationError
from openai import OpenAI
from dotenv import load_dotenv

# --- 1. Configuration and Setup ---
# Load environment variables (API keys)
load_dotenv()
try:
    # Initialize the OpenAI client
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
except Exception as e:
    print(f"Error initializing OpenAI client: {e}")
    exit()

# --- 2. Define Structured Output Schema using Pydantic ---

class AssetAllocation(BaseModel):
    """Defines the structure for a single asset class recommendation."""
    asset_class: str = Field(description="The broad category of the asset (e.g., Equities, Fixed Income, Real Estate).")
    specific_instrument: str = Field(description="A specific, representative instrument or ticker (e.g., VOO, TLT, Gold Futures).")
    weight_percent: int = Field(description="The percentage weight in the portfolio. Must be an integer.")

class PortfolioRecommendation(BaseModel):
    """The complete portfolio structure, including rationale."""
    rationale_summary: str = Field(description="A brief, 3-sentence justification for the allocation based on the inputs.")
    allocations: List[AssetAllocation]

# --- 3. Core Logic: AI Recommendation Generator ---

def generate_portfolio_recommendation(
    risk_profile: str, 
    market_context: str, 
    investment_amount: float
) -> PortfolioRecommendation | None:
    """
    Calls GPT-4 to generate a structured portfolio recommendation based on inputs.
    """
    
    # Define the strict system prompt for role and constraints
    system_prompt = f"""
    You are a highly experienced, quantitative financial advisor specializing in strategic asset allocation.
    Your sole function is to construct a diversified portfolio based on the client's risk profile and current market context.
    CRITICAL CONSTRAINT: The sum of all 'weight_percent' fields across all allocations MUST equal exactly 100.
    Do not include any introductory or concluding text outside of the required JSON structure.
    
    Client Risk Profile: {risk_profile}
    Current Market Context: {market_context}
    """
    
    print(f"--- Generating recommendation for {risk_profile} profile ---")
    
    try:
        # Use the structured output feature (response_model) to force Pydantic compliance
        response = client.chat.completions.create(
            model="gpt-4o",  # Using a powerful model for complex reasoning
            response_model=PortfolioRecommendation,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": "Generate the portfolio recommendation now."}
            ],
            temperature=0.3 # Lower temperature for factual, consistent output
        )
        
        # The response object is already a validated Pydantic instance
        return response
        
    except Exception as e:
        print(f"\n[API Error] Failed to generate recommendation: {e}")
        return None

# --- 4. Execution and Allocation Calculation ---

def execute_allocation(recommendation: PortfolioRecommendation, amount: float):
    """
    Processes the validated recommendation and calculates dollar amounts.
    """
    print("\n" + "="*60)
    print(f"AI Advisor Recommendation for Investment: ${amount:,.2f}")
    print("="*60)
    print(f"Rationale: {recommendation.rationale_summary}\n")
    
    total_weight = 0
    calculated_allocations = []
    
    for allocation in recommendation.allocations:
        weight = allocation.weight_percent
        dollar_amount = (weight / 100) * amount
        total_weight += weight
        
        calculated_allocations.append({
            "Asset": allocation.asset_class,
            "Instrument": allocation.specific_instrument,
            "Weight": f"{weight}%",
            "Dollar Amount": f"${dollar_amount:,.2f}"
        })
        
    # Display results
    print(f"{'Asset Class':<20} | {'Instrument':<25} | {'Weight':<10} | {'Dollar Allocation':<20}")
    print("-" * 80)
    for item in calculated_allocations:
        print(f"{item['Asset']:<20} | {item['Instrument']:<25} | {item['Weight']:<10} | {item['Dollar Amount']:<20}")
        
    print("-" * 80)
    print(f"Total Allocated Weight (Must be 100%): {total_weight}%")
    print(f"Total Invested Amount: ${sum([(item['Weight'].strip('%') / 100) * amount for item in calculated_allocations]):,.2f}")
    print("="*60)


if __name__ == "__main__":
    # Define the inputs
    client_risk = "Aggressive Growth Investor, 30-year time horizon."
    current_market = "High interest rates, strong dollar, emerging markets showing high momentum, US tech sector highly valued."
    investment_capital = 500000.00
    
    # 1. Generate the structured advice
    ai_recommendation = generate_portfolio_recommendation(
        risk_profile=client_risk,
        market_context=current_market,
        investment_amount=investment_capital
    )
    
    # 2. Process and display the results
    if ai_recommendation:
        execute_allocation(ai_recommendation, investment_capital)


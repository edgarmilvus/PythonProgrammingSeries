
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import pandas as pd
import yfinance as yf
from scipy.optimize import minimize
import matplotlib.pyplot as plt

# --- 1. Configuration and Data Acquisition ---
ASSETS = ['AAPL', 'MSFT', 'XOM', 'JNJ', 'TLT']
START_DATE = '2018-01-01'
END_DATE = '2023-12-31'
NUM_PORTFOLIOS = 10000
RISK_FREE_RATE = 0.00 # Assuming 0% for simplicity in this model

# Fetch historical adjusted closing prices
data = yf.download(ASSETS, start=START_DATE, end=END_DATE)['Adj Close']

# Calculate daily returns
returns = data.pct_change().dropna()

# Annualization factors (252 trading days)
DAYS_PER_YEAR = 252
mean_returns = returns.mean() * DAYS_PER_YEAR
cov_matrix = returns.cov() * DAYS_PER_YEAR
num_assets = len(ASSETS)

# --- 2. Core MPT Functions ---
def portfolio_performance(weights, mean_returns, cov_matrix, risk_free_rate):
    """Calculates annualized return, volatility, and Sharpe ratio."""
    weights = np.array(weights)
    # Annualized return
    port_return = np.sum(mean_returns * weights)
    # Annualized volatility (standard deviation)
    port_volatility = np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights)))
    # Sharpe Ratio
    sharpe_ratio = (port_return - risk_free_rate) / port_volatility
    return port_return, port_volatility, sharpe_ratio

# --- 3. Monte Carlo Simulation for Visualization ---
results_matrix = np.zeros((3 + num_assets, NUM_PORTFOLIOS))

for i in range(NUM_PORTFOLIOS):
    # Generate random weights
    weights = np.random.random(num_assets)
    weights /= np.sum(weights) # Normalize weights to sum to 1

    # Calculate performance metrics
    p_ret, p_vol, p_sharpe = portfolio_performance(
        weights, mean_returns, cov_matrix, RISK_FREE_RATE
    )

    # Store results
    results_matrix[0, i] = p_ret
    results_matrix[1, i] = p_vol
    results_matrix[2, i] = p_sharpe
    # Store weights
    for j in range(num_assets):
        results_matrix[j + 3, i] = weights[j]

# Convert results to DataFrame for easier analysis
results_df = pd.DataFrame(results_matrix.T, columns=['Return', 'Volatility', 'Sharpe'] + ASSETS)

# --- 4. Formal Optimization using SciPy ---

# Objective function for minimizing volatility (GMV portfolio)
def minimize_volatility(weights):
    return portfolio_performance(weights, mean_returns, cov_matrix, RISK_FREE_RATE)[1]

# Objective function for maximizing Sharpe Ratio (Optimal portfolio)
# SciPy minimizes, so we minimize the negative Sharpe Ratio
def maximize_sharpe_ratio(weights):
    return -portfolio_performance(weights, mean_returns, cov_matrix, RISK_FREE_RATE)[2]

# Constraints: Weights must sum to 1 (equality constraint)
constraints = ({'type': 'eq', 'fun': lambda weights: np.sum(weights) - 1})

# Bounds: Weights must be between 0 and 1 (no short selling)
bounds = tuple((0, 1) for asset in range(num_assets))

# Initial guess for optimization (equal weighting)
initial_weights = np.array([1/num_assets] * num_assets)

# A. Find the Global Minimum Variance (GMV) Portfolio
opt_volatility = minimize(
    minimize_volatility,
    initial_weights,
    method='SLSQP',
    bounds=bounds,
    constraints=constraints
)

# B. Find the Maximum Sharpe Ratio Portfolio
opt_sharpe = minimize(
    maximize_sharpe_ratio,
    initial_weights,
    method='SLSQP',
    bounds=bounds,
    constraints=constraints
)

# Extract optimized results
opt_sharpe_weights = opt_sharpe.x
opt_sharpe_metrics = portfolio_performance(opt_sharpe_weights, mean_returns, cov_matrix, RISK_FREE_RATE)

opt_gmv_weights = opt_volatility.x
opt_gmv_metrics = portfolio_performance(opt_gmv_weights, mean_returns, cov_matrix, RISK_FREE_RATE)

# --- 5. Visualization and Output ---
print("\n--- Optimization Results ---")
print(f"Optimal (Max Sharpe) Portfolio Return: {opt_sharpe_metrics[0]:.4f}")
print(f"Optimal (Max Sharpe) Portfolio Volatility: {opt_sharpe_metrics[1]:.4f}")
print(f"Optimal (Max Sharpe) Portfolio Sharpe Ratio: {opt_sharpe_metrics[2]:.4f}")
print("\nOptimal Weights:")
print(pd.Series(opt_sharpe_weights, index=ASSETS).map('{:.2%}'.format))

print("\nGlobal Minimum Variance (GMV) Portfolio Weights:")
print(pd.Series(opt_gmv_weights, index=ASSETS).map('{:.2%}'.format))

# Plotting the Efficient Frontier
plt.figure(figsize=(12, 8))
plt.scatter(results_df['Volatility'], results_df['Return'], c=results_df['Sharpe'], cmap='viridis', marker='o', s=10, alpha=0.6)
plt.colorbar(label='Sharpe Ratio')
plt.title('Efficient Frontier Simulation')
plt.xlabel('Volatility (Annualized Standard Deviation)')
plt.ylabel('Expected Return (Annualized)')

# Highlight the optimized portfolios
plt.scatter(opt_sharpe_metrics[1], opt_sharpe_metrics[0], marker='*', color='red', s=500, label='Max Sharpe Ratio')
plt.scatter(opt_gmv_metrics[1], opt_gmv_metrics[0], marker='*', color='blue', s=500, label='Global Minimum Variance')

plt.legend()
plt.grid(True, linestyle='--', alpha=0.7)
plt.show()


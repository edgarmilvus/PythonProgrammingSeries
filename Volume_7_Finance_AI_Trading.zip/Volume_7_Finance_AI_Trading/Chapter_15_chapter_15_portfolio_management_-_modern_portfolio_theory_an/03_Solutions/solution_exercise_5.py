
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# Reuse all optimization functions (find_msr_portfolio, negative_sharpe_ratio, etc.)
# Reuse sim_results_df (Monte Carlo data)

def plot_cml(risk_free_rate, msr_return, msr_volatility, color):
    """Calculates and plots the Capital Market Line for a given MSR point."""
    msr_sharpe = (msr_return - risk_free_rate) / msr_volatility
    
    # CML extends from R_f (Vol=0) through the MSR point
    cml_x = np.linspace(0, msr_volatility * 1.5, 100)
    cml_y = risk_free_rate + cml_x * msr_sharpe
    
    plt.plot(cml_x, cml_y, color=color, linestyle='-', alpha=0.7, 
             label=f'CML (R_f={risk_free_rate*100:.1f}%, S={msr_sharpe:.3f})')
    
    # Mark the MSR point
    plt.scatter(msr_volatility, msr_return, marker='D', color=color, s=150, 
                zorder=5, edgecolor='black')
    
    plt.axhline(risk_free_rate, color=color, linestyle=':', alpha=0.5)
    
    return msr_sharpe 

def dynamic_rf_analysis(annual_returns, annual_cov_matrix, sim_results_df):
    risk_free_rates = [0.01, 0.03, 0.05]
    colors = ['green', 'red', 'purple']
    
    plt.figure(figsize=(12, 8))
    
    # Initialize plot with Monte Carlo data
    plt.scatter(sim_results_df['Volatility'], sim_results_df['Return'], 
                c=sim_results_df['Sharpe Ratio'], cmap='viridis', s=10, alpha=0.4)
    plt.colorbar(label='Sharpe Ratio (R_f=3% baseline)')
    
    print("--- Dynamic Risk-Free Rate Analysis ---")
    
    for rf, color in zip(risk_free_rates, colors):
        
        # 1. Find the MSR portfolio for this specific R_f (unconstrained)
        msr_weights, msr_return, msr_volatility, msr_sharpe = find_msr_portfolio(
            annual_returns, annual_cov_matrix, rf
        )
        
        # 2. Plot the CML and the MSR point
        plot_cml(rf, msr_return, msr_volatility, color)
        
        # 3. Output key metrics
        print(f"R_f = {rf*100:.1f}%: Sharpe Ratio (Slope): {msr_sharpe:.4f}, Return: {msr_return:.4f}, Volatility: {msr_volatility:.4f}")
        
    plt.title('Impact of Risk-Free Rate on the Optimal Risky Portfolio (MSR) and CML')
    plt.xlabel('Annualized Volatility ($\sigma_p$)')
    plt.ylabel('Annualized Expected Return ($R_p$)')
    plt.legend(loc='lower right')
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.xlim(0.05)
    plt.ylim(0.05)
    plt.show()

# --- Execute Dynamic Analysis ---
dynamic_rf_analysis(annual_returns, annual_cov_matrix, sim_results_df)

print("\n--- Interpretation Summary ---")
print("1. How does an increase in the risk-free rate affect the optimal risky portfolio's required expected return?")
print("   As R_f increases (e.g., from 1% to 5%), the MSR tangency point generally shifts up and to the right along the Efficient Frontier.")
print("   This means the optimal risky portfolio accepts higher volatility and requires a higher expected return to maintain optimality.")
print("   The higher R_f raises the minimum required return for any risky investment to be considered worthwhile.")

print("\n2. What happens to the slope of the CML (which is the Sharpe Ratio) as R_f increases?")
print("   The slope of the CML (Sharpe Ratio) decreases as R_f increases.")
print("   Sharpe Ratio = (Rp - Rf) / sigma_p. Since R_f is subtracted, a higher R_f reduces the numerator (excess return) more significantly, resulting in a flatter CML.")
print("   This indicates that the reward per unit of risk decreases when the risk-free alternative becomes more attractive.")

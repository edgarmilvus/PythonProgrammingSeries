
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Reuse optimization functions (negative_sharpe_ratio, get_portfolio_metrics)
# Reuse unconstrained MSR results (u_msr_sharpe, u_msr_volatility, etc.) from Ex 3

def sector_floor_constraint(weights):
    """
    Inequality constraint: W_AAPL + W_MSFT >= 0.30
    Must return >= 0: W_AAPL + W_MSFT - 0.30
    (Assuming AAPL is index 0 and MSFT is index 1)
    """
    return weights[0] + weights[1] - 0.30

def find_constrained_msr_portfolio(annual_returns, annual_cov_matrix, risk_free_rate):
    num_assets = len(annual_returns)
    initial_weights = np.array([1/num_assets] * num_assets)
    
    # 1. Define new bounds (0 <= w <= 0.40)
    ASSET_CAP = 0.40
    new_bounds = tuple((0.0, ASSET_CAP) for asset in range(num_assets))

    # 2. Define standard equality constraint (sum=1)
    eq_constraint = {'type': 'eq', 'fun': lambda x: np.sum(x) - 1}

    # 3. Define new inequality constraint (Sector Floor)
    ineq_constraint = {'type': 'ineq', 'fun': sector_floor_constraint}
    
    constraints = [eq_constraint, ineq_constraint]

    # 4. Execute minimization
    constrained_results = minimize(
        fun=negative_sharpe_ratio,
        x0=initial_weights,
        args=(annual_returns, annual_cov_matrix, risk_free_rate),
        method='SLSQP',
        bounds=new_bounds,
        constraints=constraints
    )

    # Extract results
    c_msr_weights = constrained_results.x
    c_msr_return, c_msr_volatility = get_portfolio_metrics(c_msr_weights, annual_returns, annual_cov_matrix)
    c_msr_sharpe = (c_msr_return - risk_free_rate) / c_msr_volatility
    
    return c_msr_weights, c_msr_return, c_msr_volatility, c_msr_sharpe

# --- Main Execution ---
c_msr_weights, c_msr_return, c_msr_volatility, c_msr_sharpe = find_constrained_msr_portfolio(
    annual_returns, annual_cov_matrix, RISK_FREE_RATE
)

# Retrieve Unconstrained MSR metrics (assuming they were saved from Ex 3)
# u_msr_sharpe, u_msr_volatility, u_msr_return, u_msr_weights

print("--- Constrained MSR Portfolio Results ---")
print(f"Sharpe Ratio: {c_msr_sharpe:.4f} | Volatility: {c_msr_volatility:.4f} | Return: {c_msr_return:.4f}")
print("Weights:", dict(zip(ASSETS, [f"{w:.4f}" for w in c_msr_weights])))

print("\n--- Comparative Analysis and Interpretation ---")
print(f"Unconstrained MSR Sharpe: {msr_sharpe:.4f}")
print(f"Constrained MSR Sharpe:   {c_msr_sharpe:.4f}")

print("\nInterpretation:")
print("The constrained Sharpe Ratio is lower (or equal) because imposing constraints reduces the feasible search space.")
print("The unconstrained MSR is the global optimum. By forcing asset weights to be below 40% (bounds) and forcing Sector SG")
print("allocation to be above 30% (inequality constraint), the optimization is prevented from reaching the true mathematical optimum.")
print("This shift reflects the real-world cost (in terms of efficiency) of regulatory or client mandates.")

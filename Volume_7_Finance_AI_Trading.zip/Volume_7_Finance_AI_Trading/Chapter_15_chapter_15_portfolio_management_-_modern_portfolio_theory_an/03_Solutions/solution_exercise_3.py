
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Reuse annual_returns, annual_cov_matrix, RISK_FREE_RATE, and get_portfolio_metrics

def negative_sharpe_ratio(weights, annual_returns, annual_cov_matrix, risk_free_rate):
    """
    Objective function for minimization. Returns the negative of the Sharpe Ratio.
    """
    R_p, sigma_p = get_portfolio_metrics(weights, annual_returns, annual_cov_matrix)
    sharpe = (R_p - risk_free_rate) / sigma_p
    return -sharpe

def find_msr_portfolio(annual_returns, annual_cov_matrix, risk_free_rate):
    num_assets = len(annual_returns)
    initial_weights = np.array([1/num_assets] * num_assets)

    # Constraints and Bounds are identical to GMV (sum=1, 0 <= w <= 1)
    constraints = ({'type': 'eq', 'fun': lambda x: np.sum(x) - 1})
    bounds = tuple((0, 1) for asset in range(num_assets))

    # Perform the optimization, minimizing the negative Sharpe Ratio
    optimal_results = minimize(
        fun=negative_sharpe_ratio,
        x0=initial_weights,
        args=(annual_returns, annual_cov_matrix, risk_free_rate),
        method='SLSQP',
        bounds=bounds,
        constraints=constraints
    )

    # Extract results
    msr_weights = optimal_results.x
    msr_return, msr_volatility = get_portfolio_metrics(msr_weights, annual_returns, annual_cov_matrix)
    msr_sharpe = (msr_return - risk_free_rate) / msr_volatility
    
    return msr_weights, msr_return, msr_volatility, msr_sharpe

# --- Main Execution ---
msr_weights, msr_return, msr_volatility, msr_sharpe = find_msr_portfolio(
    annual_returns, annual_cov_matrix, RISK_FREE_RATE
)

# GMV metrics (recalculated from Ex 2)
gmv_weights, gmv_return, gmv_volatility = find_gmv_portfolio(annual_returns, annual_cov_matrix)

print("--- Maximum Sharpe Ratio (MSR) Portfolio Results ---")
print(f"MSR Sharpe Ratio: {msr_sharpe:.4f}")
print(f"MSR Volatility: {msr_volatility:.4f}")
print(f"MSR Expected Return: {msr_return:.4f}")

# --- Visualization with CML ---
plt.figure(figsize=(12, 8))

# 1. Scatter Plot (Monte Carlo)
plt.scatter(sim_results_df['Volatility'], sim_results_df['Return'], 
            c=sim_results_df['Sharpe Ratio'], cmap='viridis', s=10, alpha=0.6)
plt.colorbar(label='Sharpe Ratio')

# 2. Plot GMV and MSR points
plt.scatter(gmv_volatility, gmv_return, marker='o', color='blue', s=200, label='GMV Portfolio (Min Risk)')
plt.scatter(msr_volatility, msr_return, marker='*', color='red', s=400, label='MSR Portfolio (Max Sharpe)')

# 3. Draw Capital Market Line (CML)
cml_x = np.linspace(0, msr_volatility * 1.5, 100)
cml_y = RISK_FREE_RATE + cml_x * msr_sharpe
plt.plot(cml_x, cml_y, color='red', linestyle='--', label='Capital Market Line (CML)')

plt.title('Efficient Frontier, GMV, MSR, and CML')
plt.xlabel('Annualized Volatility ($\sigma_p$)')
plt.ylabel('Annualized Expected Return ($R_p$)')
plt.axhline(RISK_FREE_RATE, color='gray', linestyle=':', label=f'Risk-Free Rate ({RISK_FREE_RATE*100:.1f}%)')
plt.legend()
plt.grid(True, linestyle='--', alpha=0.6)
plt.xlim(0)
plt.ylim(0)
plt.show()

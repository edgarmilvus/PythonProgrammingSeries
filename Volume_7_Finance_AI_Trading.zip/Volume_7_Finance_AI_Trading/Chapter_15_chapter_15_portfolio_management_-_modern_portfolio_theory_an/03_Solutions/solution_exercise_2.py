
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from scipy.optimize import minimize

# Reuse annual_returns, annual_cov_matrix, ASSETS, and NUM_ASSETS from Exercise 1

def get_portfolio_metrics(weights, annual_returns, annual_cov_matrix):
    """Helper function to calculate R_p and sigma_p."""
    weights = np.array(weights)
    R_p = np.dot(weights, annual_returns)
    sigma_p = np.sqrt(np.dot(weights.T, np.dot(annual_cov_matrix, weights)))
    return R_p, sigma_p

def portfolio_volatility(weights, annual_cov_matrix):
    """Objective function: Returns portfolio volatility (standard deviation)."""
    # We pass annual_cov_matrix as an argument to the function signature required by minimize
    R_p, sigma_p = get_portfolio_metrics(weights, annual_returns, annual_cov_matrix)
    return sigma_p

def find_gmv_portfolio(annual_returns, annual_cov_matrix):
    num_assets = len(annual_returns)
    initial_weights = np.array([1/num_assets] * num_assets)

    # Constraint 1: Weights must sum to 1 (Equality constraint)
    constraints = ({'type': 'eq', 'fun': lambda x: np.sum(x) - 1})

    # Constraint 2: No short-selling (Bounds: 0 <= w <= 1)
    bounds = tuple((0, 1) for asset in range(num_assets))

    # Perform the optimization using SLSQP
    optimal_results = minimize(
        fun=portfolio_volatility,
        x0=initial_weights,
        args=(annual_cov_matrix,), # Pass covariance matrix as extra arguments
        method='SLSQP',
        bounds=bounds,
        constraints=constraints
    )

    # Extract results
    gmv_weights = optimal_results.x
    gmv_return, gmv_volatility = get_portfolio_metrics(gmv_weights, annual_returns, annual_cov_matrix)
    
    return gmv_weights, gmv_return, gmv_volatility

# --- Main Execution ---
gmv_weights, gmv_return, gmv_volatility = find_gmv_portfolio(annual_returns, annual_cov_matrix)

print("--- Global Minimum Variance (GMV) Portfolio Results ---")
print(f"GMV Volatility: {gmv_volatility:.4f}")
print(f"GMV Expected Return: {gmv_return:.4f}")
print("\nGMV Weights:")
for asset, weight in zip(ASSETS, gmv_weights):
    print(f"  {asset}: {weight:.4f}")

# Verification
min_sim_volatility = sim_results_df['Volatility'].min()
print(f"\nLowest Volatility from 10k Simulations: {min_sim_volatility:.4f}")
print(f"Optimization Verification: GMV Volatility <= Sim Min Volatility? {gmv_volatility <= min_sim_volatility}")

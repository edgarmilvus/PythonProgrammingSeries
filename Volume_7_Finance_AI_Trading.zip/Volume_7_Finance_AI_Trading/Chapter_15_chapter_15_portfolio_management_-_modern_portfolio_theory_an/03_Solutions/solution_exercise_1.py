
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# --- Setup using synthetic data (required for execution) ---
TRADING_DAYS = 252
RISK_FREE_RATE = 0.03
ASSETS = ['AAPL', 'MSFT', 'GOOGL', 'AMZN']
NUM_ASSETS = len(ASSETS)

# Define synthetic annualized metrics
daily_means = np.array([0.0006, 0.0005, 0.0004, 0.0007])
daily_cov = np.array([
    [0.00015, 0.00008, 0.00005, 0.00007],
    [0.00008, 0.00012, 0.00004, 0.00006],
    [0.00005, 0.00004, 0.00010, 0.00003],
    [0.00007, 0.00006, 0.00003, 0.00018]
])
annual_returns = pd.Series(daily_means * TRADING_DAYS, index=ASSETS)
annual_cov_matrix = pd.DataFrame(daily_cov * TRADING_DAYS, index=ASSETS, columns=ASSETS)
# -----------------------------------------------------------

def calculate_portfolio_metrics(weights, annual_returns, annual_cov_matrix, risk_free_rate):
    weights = np.array(weights)
    # Portfolio Expected Return (R_p = W^T * R)
    R_p = np.dot(weights, annual_returns)
    
    # Portfolio Volatility (sigma_p = sqrt(W^T * Sigma * W))
    sigma_p = np.sqrt(np.dot(weights.T, np.dot(annual_cov_matrix, weights)))
    
    # Sharpe Ratio (S_p = (R_p - R_f) / sigma_p)
    sharpe_ratio = (R_p - risk_free_rate) / sigma_p
    
    return R_p, sigma_p, sharpe_ratio

def run_monte_carlo_simulation(annual_returns, annual_cov_matrix, num_portfolios, risk_free_rate):
    # Initialize array to store results: Return, Volatility, Sharpe, and 4 Weights
    results = np.zeros((3 + NUM_ASSETS, num_portfolios)) 
    
    for i in range(num_portfolios):
        # 1. Generate random weights (ensuring no short-selling and sum=1)
        weights = np.random.random(NUM_ASSETS)
        weights /= np.sum(weights) 
        
        # 2. Calculate metrics
        R_p, sigma_p, sharpe_ratio = calculate_portfolio_metrics(
            weights, annual_returns, annual_cov_matrix, risk_free_rate
        )
        
        # 3. Store results
        results[0, i] = R_p
        results[1, i] = sigma_p
        results[2, i] = sharpe_ratio
        results[3:, i] = weights

    # Structure data into a DataFrame
    columns = ['Return', 'Volatility', 'Sharpe Ratio'] + [f'W_{a}' for a in ASSETS]
    results_df = pd.DataFrame(results.T, columns=columns)
    
    return results_df

# --- Main Execution ---
NUM_PORTFOLIOS = 10000
sim_results_df = run_monte_carlo_simulation(
    annual_returns, annual_cov_matrix, NUM_PORTFOLIOS, RISK_FREE_RATE
)

# --- Visualization ---
plt.figure(figsize=(12, 8))
plt.scatter(
    sim_results_df['Volatility'], 
    sim_results_df['Return'], 
    c=sim_results_df['Sharpe Ratio'], 
    cmap='viridis', 
    marker='o', 
    s=10
)
plt.colorbar(label='Sharpe Ratio (Rf=3%)')
plt.title('Monte Carlo Simulation of 10,000 Portfolios')
plt.xlabel('Annualized Volatility (Risk)')
plt.ylabel('Annualized Expected Return')
plt.grid(True, linestyle='--', alpha=0.6)
plt.show()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np
import pandas as pd

# --- 1. Define Constants and Simulation Parameters ---
# Standard assumption for annualizing daily metrics in finance
TRADING_DAYS_PER_YEAR = 252
np.random.seed(42)  # Ensures reproducible random data generation

# --- 2. Simulate Historical Daily Returns (3 Assets) ---
days = 500
assets = ['AAPL', 'MSFT', 'GOOG']

# Generate simulated daily returns for 500 days.
# Note: In a real-world scenario, this data would be fetched from a financial API.
# We use slightly different means and scales to simulate differing risk profiles.
returns_a = np.random.normal(loc=0.0005, scale=0.01, size=days)   # Asset A (AAPL): Moderate return, moderate risk
returns_b = np.random.normal(loc=0.0003, scale=0.008, size=days)  # Asset B (MSFT): Lower return, lower risk
returns_c = np.random.normal(loc=0.0007, scale=0.012, size=days)  # Asset C (GOOG): Higher return, higher risk

# Combine the simulated returns into a Pandas DataFrame
daily_returns = pd.DataFrame({
    assets[0]: returns_a,
    assets[1]: returns_b,
    assets[2]: returns_c
})

# --- 3. Calculate Core MPT Components ---

# Calculate Annualized Expected Returns (R_i)
# E[R_i] = Mean daily return * TRADING_DAYS_PER_YEAR
# This assumes the daily mean return is consistent throughout the year.
annual_returns = daily_returns.mean() * TRADING_DAYS_PER_YEAR

# Calculate the Annualized Covariance Matrix (Sigma)
# This matrix shows the variance of each asset (diagonal) and the covariance
# between every pair of assets (off-diagonal).
# Annualization factor is applied to the covariance matrix.
cov_matrix = daily_returns.cov() * TRADING_DAYS_PER_YEAR

# --- 4. Define Portfolio Weights (W) ---
# Define the proportion of capital allocated to each asset.
# Must sum to 1.0 (100%).
weights = np.array([0.40, 0.30, 0.30]) # 40% AAPL, 30% MSFT, 30% GOOG

# Safety check: Ensure the weights are correctly normalized
if not np.isclose(np.sum(weights), 1.0):
    raise ValueError("Portfolio weights must sum to 1.0")

# --- 5. Calculate Portfolio Expected Return (E[R_p]) ---
# Formula: E[R_p] = W^T * R_i (Weighted sum of individual expected returns)
# np.dot performs the dot product (matrix multiplication of the 1xN weights vector and the Nx1 returns vector).
portfolio_return = np.dot(weights, annual_returns)

# --- 6. Calculate Portfolio Volatility (Sigma_p) ---
# Formula: Sigma_p = sqrt( W^T * Sigma * W )
# This requires three steps of matrix multiplication:

# Step 1: Calculate the intermediate product (Sigma * W)
# This results in a vector showing how the covariance matrix impacts each weight.
intermediate_vol = np.dot(cov_matrix, weights)

# Step 2: Calculate the final variance (W^T * intermediate_vol)
# This is the final dot product, resulting in a single scalar value (the portfolio variance).
portfolio_variance = np.dot(weights.T, intermediate_vol)

# Step 3: Volatility is the square root of the variance
portfolio_volatility = np.sqrt(portfolio_variance)

# --- 7. Output Results ---
print("--- Individual Asset Metrics ---")
print(f"Annualized Returns:\n{annual_returns.map('{:.2%}'.format)}")
print("\nAnnualized Covariance Matrix (Sigma):")
# Displaying the matrix results formatted for readability
print(cov_matrix.applymap('{:.6f}'.format))

print("\n--- Portfolio Metrics (Weights: 40/30/30) ---")
print(f"Portfolio Expected Annual Return: {portfolio_return:.4f} ({portfolio_return:.2%})")
print(f"Portfolio Annual Volatility (Risk): {portfolio_volatility:.4f} ({portfolio_volatility:.2%})")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import json

inventory_data = {
    "product_id": "SKU-901B",
    "name": "Quantum Keyboard",
    "price": 149.99,
    "in_stock": True,
    "quantity": 45,
    "features": ["mechanical", "rgb_lighting", "wireless"],
    "metadata": {
        "manufacturer": "TechCorp",
        "warranty_years": 2
    },
    "discontinued": None,
    "dimensions": (15, 6, 1) # Original type: tuple
}

# 1. Serialization
json_output = json.dumps(inventory_data)

# 2. Verification (Print JSON string)
print("1. JSON Output String:")
print(json_output)

# 3. Type Check
print("\n2. Type Check:")
print(f"Type of json_output: {type(json_output)}")

# 4. Deserialization (Round Trip)
restored_inventory = json.loads(json_output)

# 5. Comparison and Fidelity Check
print("\n3. Fidelity Check:")
# Check type of "features" (List should remain List)
print(f"Type of 'features' in restored data: {type(restored_inventory['features'])}")

# Check type of "dimensions" (Tuple should become List)
original_dimensions_type = type(inventory_data['dimensions'])
restored_dimensions_type = type(restored_inventory['dimensions'])

print(f"Original 'dimensions' type: {original_dimensions_type}")
print(f"Restored 'dimensions' type: {restored_dimensions_type}")

# Explanation of type change:
# When serialized, the Python tuple (an immutable sequence) is mapped to the
# universal JSON array. When deserialized using json.loads(), the JSON array
# is mapped back to the default Python mutable sequence type: the list.
# JSON does not have a native type for immutable sequences (tuples).


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import json
import os

# 1. Data Definition
settings = {
    "theme": "dark",
    "log_level": 5,
    "debug_mode": False,
    "version": 1.0
}
CONFIG_FILENAME = "app_config.json"

# 3. & 4. Loading Function with Robust Error Handling
def load_config(filename, default_settings):
    """
    Loads configuration from a JSON file, handling file not found 
    and decoding errors gracefully.
    """
    try:
        # Attempt to open and load the file
        with open(filename, 'r') as f:
            config = json.load(f)
            print(f"Success: Configuration loaded from {filename}.")
            return config
            
    except FileNotFoundError:
        # Handle case where the file does not exist
        print("Warning: Configuration file not found. Using defaults.")
        return default_settings
        
    except json.JSONDecodeError:
        # Handle case where the file exists but is invalid JSON
        print("Error: Configuration file is corrupted or invalid. Please check syntax.")
        return {}
        
    except Exception as e:
        # Catch any other unexpected I/O errors
        print(f"An unexpected error occurred: {e}")
        return default_settings

# --- Test Case Setup ---

# Ensure file is clean before starting
if os.path.exists(CONFIG_FILENAME):
    os.remove(CONFIG_FILENAME)

# 2. Writing to File (Successful Write)
print("--- Test 1: Successful Write and Load ---")
with open(CONFIG_FILENAME, 'w') as f:
    json.dump(settings, f)
print(f"Configuration successfully written to {CONFIG_FILENAME}.")

# Test 1: Load the valid file
loaded_settings_1 = load_config(CONFIG_FILENAME, settings)
print(f"Loaded data (1): {loaded_settings_1}")

# Test 2: Simulate file corruption (Trigger JSONDecodeError)
print("\n--- Test 2: Simulating JSON Corruption ---")
# Write invalid JSON (e.g., missing closing brace)
with open(CONFIG_FILENAME, 'w') as f:
    f.write('{"theme": "dark", "log_level": 5') 

loaded_settings_2 = load_config(CONFIG_FILENAME, settings)
print(f"Loaded data (2): {loaded_settings_2} (Returned empty dict due to corruption)")

# Test 3: Simulate file deletion (Trigger FileNotFoundError)
print("\n--- Test 3: Simulating File Not Found ---")
if os.path.exists(CONFIG_FILENAME):
    os.remove(CONFIG_FILENAME)

loaded_settings_3 = load_config(CONFIG_FILENAME, settings)
print(f"Loaded data (3): {loaded_settings_3} (Returned default settings)")

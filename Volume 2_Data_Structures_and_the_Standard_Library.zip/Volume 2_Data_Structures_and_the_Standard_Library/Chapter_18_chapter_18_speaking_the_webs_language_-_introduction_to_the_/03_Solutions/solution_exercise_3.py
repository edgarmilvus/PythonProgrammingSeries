
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import json
import os

raw_user_data_json = """
[
  {"id": 101, "username": "alice_dev", "status": "active", "level": 10, "last_login": "2024-05-01"},
  {"id": 102, "username": "bob_test", "status": "inactive", "level": 5, "last_login": "2023-11-15"},
  {"id": 103, "username": "charlie_prod", "status": "pending", "level": 12, "last_login": "2024-05-03"},
  {"id": 104, "username": "diana_admin", "status": "Active", "level": 20, "last_login": "2024-05-04"}
]
"""
OUTPUT_FILENAME = "processed_users.json"
TODAY_DATE = "2024-05-05" 

# 1. Deserialization
user_list = json.loads(raw_user_data_json)

# 2. Transformation (Normalization - Uppercasing Status)
for user in user_list:
    user['status'] = user['status'].upper()

# 3. Transformation (Filtering - Removing INACTIVE users)
active_users = [
    user for user in user_list 
    if user['status'] != "INACTIVE"
]

# 4. Transformation (Modification - Adding processed_date)
for user in active_users:
    user['processed_date'] = TODAY_DATE
    
# 5. Re-serialization and Saving
# Use json.dump for file writing, with indent=4 for readability
with open(OUTPUT_FILENAME, 'w') as f:
    json.dump(active_users, f, indent=4)

print(f"Processed {len(user_list)} initial records.")
print(f"Filtered down to {len(active_users)} active records.")
print(f"Final processed data saved to {OUTPUT_FILENAME} with 4-space indentation.")

# Verification print (showing the structure of the saved data)
print("\n--- Content of processed_users.json (First entry) ---")
print(json.dumps(active_users[0], indent=4))

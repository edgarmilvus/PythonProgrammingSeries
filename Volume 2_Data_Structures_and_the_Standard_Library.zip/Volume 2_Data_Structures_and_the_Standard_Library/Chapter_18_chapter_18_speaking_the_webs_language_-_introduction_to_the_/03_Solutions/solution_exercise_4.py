
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import json

project_manifest = {
    "version": "1.0.3",
    "dependencies": {
        "requests": "2.28.1",
        "numpy": "1.23.5",
        "pandas": "1.5.3"
    },
    "name": "Project Alpha",
    "status": "stable",
    "maintainer": {
        "email": "dev@alpha.com",
        "name": "Alex K."
    }
}

# 1. Non-Standard Output (Order follows insertion)
print("--- 1. Non-Standard Output (Insertion Order) ---")
non_standard_json = json.dumps(project_manifest)
print(non_standard_json)

# 2. Standardized Output Generation (Canonical JSON 1)
# Use sort_keys=True and indent=2
canonical_json_1 = json.dumps(project_manifest, indent=2, sort_keys=True)

print("\n--- 2. Canonical Output 1 (Sorted) ---")
print(canonical_json_1)

# 3. Interactive Test (Input Manipulation - Reorder keys)
project_manifest_reordered = {
    "name": "Project Alpha",
    "status": "stable",
    "version": "1.0.3",
    "maintainer": {
        "name": "Alex K.",
        "email": "dev@alpha.com"
    },
    "dependencies": {
        "pandas": "1.5.3",
        "requests": "2.28.1",
        "numpy": "1.23.5"
    }
}

# 4. Verification of Determinism (Canonical JSON 2)
# Serialize the reordered dictionary using the exact same parameters
canonical_json_2 = json.dumps(project_manifest_reordered, indent=2, sort_keys=True)

print("\n--- 3. Canonical Output 2 (From Reordered Input) ---")
print(canonical_json_2)

# 5. Final Check
is_deterministic = canonical_json_1 == canonical_json_2

print("\n--- 4. Final Comparison ---")
print(f"Canonical JSON 1 == Canonical JSON 2: {is_deterministic}")
print("Conclusion: The standardized output is deterministic.")

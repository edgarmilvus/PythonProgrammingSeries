
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from datetime import datetime, timezone, timedelta

# 1. UTC Initialization
failure_time_naive = datetime(2025, 1, 1, 3, 0, 0)
# Make the time zone aware by explicitly setting tzinfo to UTC
server_failure_utc = failure_time_naive.replace(tzinfo=timezone.utc)

# 2. Target Time Zones
tz_london = timezone(timedelta(hours=0), name='London')
tz_tokyo = timezone(timedelta(hours=9), name='Tokyo')

# 3. Conversion Function
def convert_to_local(utc_dt, target_tz):
    """Converts a UTC aware datetime object to a target time zone."""
    # The astimezone() method performs the necessary offset calculation
    return utc_dt.astimezone(target_tz)

# 4. Application
london_time = convert_to_local(server_failure_utc, tz_london)
tokyo_time = convert_to_local(server_failure_utc, tz_tokyo)

# 5. Output Verification (using default string representation which includes tzinfo)
print("--- Time Zone Conversion ---")
print(f"Original UTC Failure Time: {server_failure_utc}")
print(f"Converted London Time:     {london_time}")
print(f"Converted Tokyo Time:      {tokyo_time}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from datetime import datetime, timezone, timedelta

# Define the Unix Epoch Start (Must be time-zone aware for accurate calculation)
EPOCH_START = datetime(1970, 1, 1, 0, 0, 0, tzinfo=timezone.utc)

# 1. The Core Function
def calculate_epoch_difference(target_dt):
    """Calculates the total seconds elapsed since the Unix Epoch (1970-01-01 UTC)."""
    # Ensure the target date is aware. If it's naive, we assume it's UTC based on the parsing function.
    if target_dt.tzinfo is None:
        target_dt = target_dt.replace(tzinfo=timezone.utc)
        
    difference = target_dt - EPOCH_START
    return difference.total_seconds()

# 2. The Formatting Utility
def format_datetime_output(dt_object, format_code):
    """Generic utility to format a datetime object into a specified string."""
    return dt_object.strftime(format_code)

# 3. Input Handling Refinement
def parse_input_string(date_string, format_code):
    """Parses a string into a naive datetime and localizes it to UTC."""
    naive_dt = datetime.strptime(date_string, format_code)
    # Localize the naive object by explicitly setting its time zone to UTC
    aware_dt_utc = naive_dt.replace(tzinfo=timezone.utc)
    return aware_dt_utc

# --- Execution ---
input_string = "2025-06-15 11:30:00"
input_format = "%Y-%m-%d %H:%M:%S"

# 1. Parse and Localize
parsed_dt_utc = parse_input_string(input_string, input_format)

# 2. Calculate Epoch Difference
epoch_seconds = calculate_epoch_difference(parsed_dt_utc)

# 3. Format Output
format_a_code = "%d %B %Y (%H:%M)"
format_b_code = "[%Y%m%d_%H%M%S]"

output_a = format_datetime_output(parsed_dt_utc, format_a_code)
output_b = format_datetime_output(parsed_dt_utc, format_b_code)

print("--- Refactored Epoch Calculations ---")
print(f"Input Date (UTC): {parsed_dt_utc}")
print(f"Total Seconds since Epoch: {int(epoch_seconds)}")
print(f"Format A (Standard): {output_a}")
print(f"Format B (Log Tag):  {output_b}")

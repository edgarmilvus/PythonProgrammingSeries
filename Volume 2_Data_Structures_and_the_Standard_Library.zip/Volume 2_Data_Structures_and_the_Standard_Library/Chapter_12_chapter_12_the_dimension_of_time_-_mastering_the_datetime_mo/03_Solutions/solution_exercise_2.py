
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from datetime import datetime

log_entries = [
    "2024-09-15 10:30:00 UTC",  # Format 1
    "Wed, 21 Aug 24 14:55:12",   # Format 2
    "12/01/2025 08:00 AM",       # Format 3
    "2024-13-40 00:00:00"        # Malformed format
]

# Define the expected input formats in order of testing
FORMATS = [
    "%Y-%m-%d %H:%M:%S %Z",  # Format 1: ISO-like with TZ
    "%a, %d %b %y %H:%M:%S",   # Format 2: RFC 822 style
    "%m/%d/%Y %I:%M %p"        # Format 3: US format with AM/PM
]

TARGET_FORMAT = "%Y-%m-%dT%H:%M:%S" # Standardized ISO 8601 output

def parse_log_entry(date_string):
    """Attempts to parse a date string against known formats and standardizes the output."""
    
    dt_object = None
    for fmt in FORMATS:
        try:
            # Attempt to parse the string using the current format
            dt_object = datetime.strptime(date_string, fmt)
            # If successful, break the loop
            break
        except ValueError:
            # If parsing fails, continue to the next format
            continue
            
    if dt_object:
        # If parsing succeeded, format the datetime object to the standard output
        return dt_object.strftime(TARGET_FORMAT)
    else:
        # If the loop finishes without a successful parse
        return "Parsing Error: Unknown Format"

# Execution
print("--- Log Entry Processing ---")
for entry in log_entries:
    standardized_time = parse_log_entry(entry)
    print(f"Input: '{entry}' -> Output: {standardized_time}")

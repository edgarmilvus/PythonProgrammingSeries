
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from datetime import date, datetime, timedelta

# 1. Initialization
start_date = date(2024, 10, 27)

# 2. Duration Definition
development_duration = timedelta(days=18, hours=7)

# To add a timedelta with hours to a date object, we must first promote the date
# to a datetime object (implicitly starting at midnight).
start_datetime = datetime.combine(start_date, datetime.min.time())

# 3. Completion Calculation (Part A)
completion_datetime = start_datetime + development_duration

# 4. Milestone Tracking
milestone_review_date = datetime(2024, 11, 15, 14, 0)

# 5. Duration Calculation (Part B)
# Note: Since the milestone is *before* the completion date, the result will be negative.
time_to_review = milestone_review_date - completion_datetime

# 6. Output Formatting

# Format A: YYYY/MM/DD
start_date_formatted = start_date.strftime("%Y/%m/%d")

# Format B: Month Name DD, YYYY @ HH:MM AM/PM
completion_formatted = completion_datetime.strftime("%B %d, %Y @ %I:%M %p")

# Format C: Duration remaining (using absolute value for cleaner display)
abs_time_to_review = abs(time_to_review)
days = abs_time_to_review.days
seconds = abs_time_to_review.seconds
hours = seconds // 3600
minutes = (seconds % 3600) // 60

print(f"--- Project Timeline Summary ---")
print(f"Project Start Date (YYYY/MM/DD): {start_date_formatted}")
print(f"Calculated Completion Date: {completion_formatted}")
print(f"")
print(f"Milestone Review Date: {milestone_review_date.strftime('%B %d, %Y @ %H:%M')}")
print(f"Time from Review to Completion (Difference):")
print(f"  {days} days, {hours} hours, and {minutes} minutes.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from datetime import date, datetime, timedelta

# 1. User Input (Birthday)
while True:
    birthday_str = input("Please enter your birth date (MM-DD-YYYY): ")
    # 2. Parsing and Error Handling
    try:
        # We only need the date component for age calculation
        birth_date = datetime.strptime(birthday_str, "%m-%d-%Y").date()
        break
    except ValueError:
        print("Error: Invalid format. Please use MM-DD-YYYY (e.g., 12-25-1990).")
        
# Get current date for calculation
today = date.today()

# 3. Age Calculation
age_timedelta = today - birth_date
age_in_days = age_timedelta.days

# 4. Future Event (Must be a datetime object for time calculation)
future_event = datetime(2030, 1, 1, 0, 0, 0)
# Convert today's date to datetime for consistent subtraction
now = datetime.now().replace(microsecond=0)

# 5. Time Remaining
time_remaining = future_event - now

# Extract components from timedelta
remaining_days = time_remaining.days
# Calculate hours and minutes from the remaining seconds
remaining_seconds = time_remaining.seconds
remaining_hours = remaining_seconds // 3600
remaining_minutes = (remaining_seconds % 3600) // 60

# 6. Formatted Output
print("\n--- Temporal Analysis ---")
print(f"Your birth date: {birth_date.strftime('%B %d, %Y')}")
print(f"You have lived for exactly {age_in_days:,} days.")
print("-" * 30)
print(f"Time remaining until 2030: {remaining_days} days, {remaining_hours} hours, and {remaining_minutes} minutes.")

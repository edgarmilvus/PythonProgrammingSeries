
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import math

# 1. Constants
INITIAL_MASS = 150.0      # N0 (grams)
DECAY_CONSTANT = 0.035    # lambda (per hour)
TIME_ELAPSED = 15.0       # t (hours)

def calculate_decay(N0: float, lambda_const: float, t: float) -> float:
    """
    Calculates the remaining quantity N(t) using the decay formula: N0 * e^(-lambda * t)
    """
    # 3. Exponential Use: math.exp() calculates e raised to the power of the argument
    exponent = -lambda_const * t
    remaining_quantity = N0 * math.exp(exponent)
    return remaining_quantity

# Calculate N(t)
N_remaining = calculate_decay(INITIAL_MASS, DECAY_CONSTANT, TIME_ELAPSED)

# 4. Output
print(f"--- Radioactive Decay Model ---")
print(f"Initial Mass (N0): {INITIAL_MASS:.3f} g")
print(f"Decay Constant (lambda): {DECAY_CONSTANT}")
print(f"Time Elapsed (t): {TIME_ELAPSED:.1f} hours")
print(f"Remaining Mass N(t): {N_remaining:.3f} g")


# 5. Bonus Challenge (Logarithms)
# Check: t = ln(N(t) / N0) / (-lambda)
try:
    ratio = N_remaining / INITIAL_MASS
    # Use math.log() (natural logarithm)
    t_check = math.log(ratio) / (-DECAY_CONSTANT)

    print(f"\n--- Verification Check (Using math.log) ---")
    print(f"Time required to reach N(t) is: {t_check:.1f} hours")
    print(f"Verification successful: {t_check:.1f} == {TIME_ELAPSED:.1f}")
except ValueError:
    print("\nError during log verification: Check input values (e.g., N(t) must be > 0).")

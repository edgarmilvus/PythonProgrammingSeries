
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import math

# 1. Input Validation
try:
    N_input = float(input("Enter the upper limit N (e.g., 5 or 5.7): "))
except ValueError:
    print("Invalid input. Please enter a numeric value.")
    # Use a safe default to prevent crashing if input is non-numeric
    N_input = 0.0

# 2. Boundary Handling using math.floor()
N_safe = math.floor(N_input)

# Check for negative limit
if N_safe < 0:
    print(f"Warning: Input limit {N_input} resulted in a negative safe limit ({N_safe}). Setting limit to 0.")
    N_safe = 0

# Initialize the sum
S = 0

# 3. Iterative Summation
# We iterate from 1 up to N_safe (inclusive)
for i in range(1, N_safe + 1):
    # 4. Calculation using math.factorial()
    current_factorial = math.factorial(i)
    S += current_factorial

# 5. Output
print(f"\n--- Factorial Summation Results ---")
print(f"Original Input N: {N_input}")
print(f"Safe Integer Limit N_safe (using floor): {N_safe}")
print(f"The sum S (1! + ... + {N_safe}!) is: {S}")

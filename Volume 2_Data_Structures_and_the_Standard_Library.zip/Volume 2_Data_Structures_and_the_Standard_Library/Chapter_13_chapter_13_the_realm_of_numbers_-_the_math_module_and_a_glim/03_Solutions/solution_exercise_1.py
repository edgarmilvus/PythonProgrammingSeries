
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import math

def calculate_adjacent_side(hypotenuse: float, angle_degrees: float) -> float:
    """
    Calculates the adjacent side of a right triangle given the hypotenuse
    and the angle in degrees.
    """
    # 1. Convert the angle from degrees to radians
    angle_radians = math.radians(angle_degrees)

    # 2. Calculate the adjacent side using the cosine function
    adjacent_side = hypotenuse * math.cos(angle_radians)

    return adjacent_side

# --- Execution Example ---
try:
    # Input Handling
    h = float(input("Enter the length of the hypotenuse (H): "))
    angle = float(input("Enter the angle theta in degrees: "))

    # Calculation using the function (DRY principle applied)
    result = calculate_adjacent_side(h, angle)

    # Output formatted to two decimal places
    print(f"\n--- Calculation Results ---")
    print(f"Hypotenuse (H): {h}")
    print(f"Angle (Degrees): {angle}")
    print(f"The adjacent side length (A) is: {result:.2f}")

except ValueError:
    print("Invalid input. Please ensure both inputs are valid numbers.")


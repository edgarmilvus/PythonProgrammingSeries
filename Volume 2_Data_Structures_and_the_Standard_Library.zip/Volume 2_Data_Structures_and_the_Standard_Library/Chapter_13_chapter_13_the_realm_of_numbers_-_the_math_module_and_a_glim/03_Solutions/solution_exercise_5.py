
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import math

# Define the target constant
TARGET_VALUE = math.sqrt(2)
TOLERANCE = 1e-6  # 0.000001
ACTUAL_ANSWER = math.pi / 4

print("--- Transcendental Guessing Game ---")
print(f"Target: Find X (in radians) such that sin(X) + cos(X) = sqrt(2) ≈ {TARGET_VALUE:.6f}")

guess_count = 0
solved = False

while not solved:
    try:
        # Get input X
        user_guess_X = input("\nEnter your guess for X (in radians, or 'q' to quit): ")

        if user_guess_X.lower() == 'q':
            print("Exiting game.")
            break

        X = float(user_guess_X)
        guess_count += 1

        # 3. Calculation
        V = math.sin(X) + math.cos(X)

        # 4. Feedback and Termination Check
        difference = abs(V - TARGET_VALUE)

        if difference < TOLERANCE:
            solved = True
            print(f"\n*** CONGRATULATIONS! ***")
            print(f"You found the angle X = {X:.6f} in {guess_count} guesses.")
            print(f"Your calculated value V: {V:.6f}")
            print(f"Actual mathematical answer (pi/4): {ACTUAL_ANSWER:.6f}")
        elif V > TARGET_VALUE:
            print(f"Result V = {V:.6f}. Too High (The result is greater than √2). Try a smaller X.")
        else: # V < TARGET_VALUE
            print(f"Result V = {V:.6f}. Too Low (The result is less than √2). Try a larger X.")

    except ValueError:
        print("Invalid input. Please enter a valid number or 'q'.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        break


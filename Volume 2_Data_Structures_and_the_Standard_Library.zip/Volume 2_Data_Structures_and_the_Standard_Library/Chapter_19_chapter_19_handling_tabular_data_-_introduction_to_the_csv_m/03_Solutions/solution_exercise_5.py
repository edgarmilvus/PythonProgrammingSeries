
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import csv
import os

# Define constants
INPUT_FILE = 'user_profiles.csv'
EXPECTED_COLUMNS = 5

# --- Setup: Create the necessary input file with structural errors ---
error_data = [
    ['User_ID', 'Name', 'Email', 'Department', 'Hire_Date'],
    ['101', 'Alice Smith', 'alice@corp.com', 'Marketing', '2022-01-10'],
    ['102', 'Bob Jones', 'bob@corp.com', 'Sales', '2023-05-20', 'Extra Field Here'], # 6 columns
    ['103', 'Charlie Brown', 'charlie@corp.com', 'IT'],                            # 4 columns
    ['104', 'Dana Scully', 'dana@corp.com', 'R&D', '2021-11-01'],
    ['105', 'Eve Adams', 'eve@corp.com', 'Finance', '2024-01-01', 'Too', 'Many', 'Fields'], # 8 columns
    ['106', 'Frank Green', 'frank@corp.com', 'HR']                                # 4 columns
]
with open(INPUT_FILE, 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerows(error_data)
# ----------------------------------------------------------------

print(f"--- Starting Structural Validation for {INPUT_FILE} (Expected: {EXPECTED_COLUMNS} columns) ---")

line_num = 0
errors_found = 0

try:
    with open(INPUT_FILE, mode='r', newline='', encoding='utf-8') as infile:
        reader = csv.reader(infile)
        
        # Read header (Line 1)
        try:
            header = next(reader)
            line_num += 1
            print(f"Header (Line {line_num}) processed.")
        except StopIteration:
            print("Error: File is empty.")
            return

        # Process data rows
        for row in reader:
            line_num += 1
            actual_cols = len(row)
            
            if actual_cols != EXPECTED_COLUMNS:
                errors_found += 1
                error_type = "Too Many" if actual_cols > EXPECTED_COLUMNS else "Too Few"
                
                # 4. Error Reporting
                print(f"\n[STRUCTURAL ERROR] Line {line_num} ({error_type} Columns)")
                print(f"  Expected: {EXPECTED_COLUMNS}, Detected: {actual_cols}")
                print(f"  Content: {row}")
            else:
                # 5. Successful Row Handling
                user_id = row[0]
                print(f"Line {line_num}: User ID {user_id} processed successfully.")

    print(f"\n--- Validation Summary ---")
    print(f"Total Lines Checked: {line_num}")
    print(f"Total Structural Errors Found: {errors_found}")

except FileNotFoundError:
    print(f"Error: The file {INPUT_FILE} was not found.")

# Cleanup
os.remove(INPUT_FILE)

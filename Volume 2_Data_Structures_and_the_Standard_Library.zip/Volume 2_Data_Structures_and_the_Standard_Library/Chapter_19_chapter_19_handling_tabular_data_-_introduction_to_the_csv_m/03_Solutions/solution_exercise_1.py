
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import csv
import os

# --- Setup: Create the necessary input file for demonstration ---
INVENTORY_FILE = 'inventory_data.csv'
sample_data = [
    ['Product_ID', 'Category', 'Unit_Cost', 'Quantity_In_Stock'],
    ['A1001', 'Electronics', '499.99', '15'],
    ['B2005', 'Apparel', '25.00', '120'],
    ['A1008', 'Electronics', '12.50', '300'],
    ['C3010', 'Tools', '55.99', '40'],
    ['D4001', 'Apparel', '10.00', '500'],
    ['E5000', 'Electronics', '1000.00', '5'],
    ['F6000', 'Corrupted', '100.00', 'abc'],  # Invalid quantity
    ['G7000', 'Corrupted', 'xyz', '10']      # Invalid cost
]
with open(INVENTORY_FILE, 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerows(sample_data)
# ----------------------------------------------------------------

grand_total_value = 0.0
category_totals = {}
rows_processed = 0
rows_skipped = 0

print(f"--- Processing {INVENTORY_FILE} ---")

try:
    with open(INVENTORY_FILE, mode='r', newline='', encoding='utf-8') as infile:
        reader = csv.reader(infile)
        
        # 1. Skip the header row
        next(reader) 
        
        for row in reader:
            rows_processed += 1
            
            if len(row) < 4:
                print(f"Warning: Skipping malformed row {rows_processed} (too few columns).")
                rows_skipped += 1
                continue

            product_id, category, cost_str, quantity_str = row[0], row[1], row[2], row[3]
            
            # 2. Robust Type Conversion and Error Handling
            try:
                unit_cost = float(cost_str)
                quantity = int(quantity_str)
            except ValueError:
                print(f"Error: Skipping row {product_id} due to invalid numeric data: Cost='{cost_str}', Qty='{quantity_str}'")
                rows_skipped += 1
                continue
                
            # 3. Calculate value
            product_value = unit_cost * quantity
            
            # 4. Accumulate totals
            grand_total_value += product_value
            
            # 5. Aggregate by category
            category_totals[category] = category_totals.get(category, 0.0) + product_value

except FileNotFoundError:
    print(f"Error: The file {INVENTORY_FILE} was not found.")
    
# 6. Determine the highest valued category
if category_totals:
    highest_category = max(category_totals, key=category_totals.get)
    highest_value = category_totals[highest_category]
else:
    highest_category = "N/A"
    highest_value = 0.0

# 7. Output Results
print("\n--- Inventory Report ---")
print(f"Total Rows Processed (including errors): {rows_processed}")
print(f"Rows Skipped due to Errors: {rows_skipped}")
print(f"Grand Total Inventory Value: ${grand_total_value:,.2f}")
print("-" * 30)
print(f"Category with Highest Value:")
print(f"  Category: {highest_category}")
print(f"  Total Value: ${highest_value:,.2f}")

# Cleanup (optional, for a clean environment)
os.remove(INVENTORY_FILE)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import csv
import os

# --- Setup: Create the necessary input file with legacy format ---
LEGACY_FILE = 'legacy_export.dat'
legacy_content = """SKU|Product_Name|Location|Last_Audit_Date
P900|Widget A|Warehouse 1|2024-01-15
P901|'Widget B| Large Size'|Warehouse 2|2024-02-20
P902|Standard Tool Kit|Shelf 3|2024-03-01
P903|'Accessory, Manual, and Cable'|Warehouse 1|2024-04-10
"""
with open(LEGACY_FILE, 'w', encoding='utf-8') as f:
    f.write(legacy_content)
# ----------------------------------------------------------------

print(f"--- Processing Legacy File: {LEGACY_FILE} ---")
print("SKU -> Product Name")
print("-" * 30)

try:
    with open(LEGACY_FILE, mode='r', newline='', encoding='utf-8') as infile:
        # 1. Initialize the reader with custom dialect parameters
        reader = csv.reader(infile, delimiter='|', quotechar="'")
        
        # Skip header
        next(reader) 
        
        # 2. Data Extraction
        for row in reader:
            if len(row) >= 2:
                sku = row[0]
                product_name = row[1]
                
                # 3. Output Formatting
                # The csv.reader automatically handles quote removal
                print(f"{sku} -> {product_name}")

except FileNotFoundError:
    print(f"Error: The file {LEGACY_FILE} was not found.")

# Cleanup
os.remove(LEGACY_FILE)

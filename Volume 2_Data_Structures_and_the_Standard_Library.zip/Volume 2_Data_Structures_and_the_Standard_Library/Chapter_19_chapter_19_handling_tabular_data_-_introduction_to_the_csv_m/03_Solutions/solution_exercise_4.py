
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import csv
import os
import decimal

# Define constants
TAX_RATE = 0.085
INPUT_FILE = 'raw_transactions.csv'
OUTPUT_FILE = 'cleaned_transactions.csv'

STATUS_MAP = {
    1: "Completed",
    2: "Pending Review",
    3: "Cancelled"
}

# --- Setup: Create the necessary input file ---
raw_data = [
    ['Transaction_ID', 'Amount', 'Status_Code', 'Date'],
    ['10023', '150.00', '1', '2024-05-10'],
    ['10024', '50.50', '2', '2024-05-11'],
    ['10025', '99.99', '3', '2024-05-12'],
    ['10026', '200.00', '1', '2024-05-13'],
    ['10027', 'bad_amount', '1', '2024-05-14'], # Invalid amount
    ['10028', '10.00', '4', '2024-05-15'],     # Unknown status code
    ['10029', '75.00', 'two', '2024-05-16']    # Invalid status code
]
with open(INPUT_FILE, 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerows(raw_data)
# ----------------------------------------------------------------

print(f"--- Starting Data Transformation Pipeline ---")

try:
    with open(INPUT_FILE, 'r', newline='') as infile, \
         open(OUTPUT_FILE, 'w', newline='') as outfile:
        
        reader = csv.reader(infile)
        writer = csv.writer(outfile)
        
        # 1. Header Transformation
        header = next(reader)
        # Replace 'Status_Code' with 'Status' and append 'Tax_Amount'
        header[2] = 'Status' 
        header.append('Tax_Amount')
        writer.writerow(header)
        
        # 2. Row Processing
        for row in reader:
            if len(row) < 4:
                print(f"Warning: Skipping row due to insufficient columns: {row}")
                continue

            trans_id, amount_str, status_str, date = row
            
            try:
                # Convert Amount (float) and Status (int)
                amount = float(amount_str)
                status_code = int(status_str)
            except ValueError as e:
                print(f"Error processing Transaction {trans_id}: Invalid numeric data ({e}). Skipping.")
                continue
            
            # 3. Status Mapping
            status_desc = STATUS_MAP.get(status_code, "Error/Unknown")
            
            # 4. Tax Calculation (rounded to 2 decimal places)
            tax_amount = round(amount * TAX_RATE, 2)
            
            # 5. Construct and write the new row
            new_row = [
                trans_id,
                f"{amount:.2f}", # Keep amount formatted nicely
                status_desc,
                date,
                f"{tax_amount:.2f}"
            ]
            writer.writerow(new_row)

    print(f"\nPipeline Complete. Transformed data written to {OUTPUT_FILE}")
    
except FileNotFoundError:
    print(f"Error: Input file {INPUT_FILE} not found.")

# Cleanup (optional)
os.remove(INPUT_FILE)
os.remove(OUTPUT_FILE)

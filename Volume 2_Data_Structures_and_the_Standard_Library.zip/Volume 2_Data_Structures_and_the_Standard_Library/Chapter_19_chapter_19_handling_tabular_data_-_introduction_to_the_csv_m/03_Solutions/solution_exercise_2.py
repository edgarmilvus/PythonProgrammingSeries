
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import csv
import os

# Data structure provided
config_data = [
    ("Server_Name", "Priority_Level", "Description"),
    ("Web-01", "HIGH", "Primary web server, handles user authentication"),
    ("DB-Prod", "CRITICAL", "Main production database, requires daily backup"),
    ("Cache-03", "LOW", "Ephemeral caching layer"),
    ("API-Gateway", "HIGH", "Microservice entry point, tracks all external calls"),
    ("Analytics-05", "MEDIUM", "Reporting engine, stores historical data and metrics")
]

OUTPUT_FILE = 'log_config.csv'

# 1. Create and open the output file
with open(OUTPUT_FILE, 'w', newline='', encoding='utf-8') as outfile:
    # 2. Initialize the csv.writer with default dialect (csv.QUOTE_MINIMAL)
    writer = csv.writer(outfile)
    
    # 3. Write all data rows efficiently
    writer.writerows(config_data)

print(f"Successfully generated configuration file: {OUTPUT_FILE}")

# --- Verification Check (Reading back the critical row) ---
print("\n--- Internal Verification (Checking quoting) ---")
with open(OUTPUT_FILE, 'r', newline='') as f:
    reader = csv.reader(f)
    # Skip header
    next(reader) 
    web_01_row = next(reader)
    
    # Check the raw content of the file for the Web-01 description
    # This shows how the CSV module wrote the data
    print(f"Raw file content for Web-01 description field:")
    
    # We read the file content directly to show the quoting applied by the writer
    # Note: When reader reads it back, the quotes are removed, so we check the raw file content
    
    # To show the raw file content as written (for analysis purposes):
    f.seek(0) # Reset file pointer
    raw_lines = f.readlines()
    print(raw_lines[1].strip()) # Should show: Web-01,HIGH,"Primary web server, handles user authentication"

# Cleanup
os.remove(OUTPUT_FILE)

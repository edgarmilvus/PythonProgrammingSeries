
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Flight path data (Latitude, Longitude, Altitude)
flight_path = (
    (34.0522, -118.2437, 150),
    (34.0530, -118.2450, 180),
    (34.0541, -118.2461, 220),
    (34.0550, -118.2470, 195),
    (34.0562, -118.2481, 255),
    (34.0570, -118.2490, 210)
)

# 2. Initialize max_altitude to the lowest possible starting point
max_altitude = 0

# 3. Use a For Loop to iterate through the flight_path (tuple of tuples)
for coordinate in flight_path:
    # 4. Access the altitude value (the third element, index 2)
    altitude = coordinate[2]

    # 5. Update max_altitude if the current altitude is greater
    if altitude > max_altitude:
        max_altitude = altitude

# 6. Print the final result
print(f"The maximum altitude reached during the flight was: {max_altitude} meters.")

# Alternative (More Pythonic, for comparison, but the loop meets the requirement):
# max_altitude_pythonic = max(coord[2] for coord in flight_path)
# print(f"Verification using max(): {max_altitude_pythonic} meters.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

MODEL = "claude-3-sonnet"
TEMP = 0.5
PROMPT = "You are an expert Python tutor."
MAX_TOKENS = 2048

# 1. Function returning the new 4-element configuration tuple
def get_chain_config():
    return (MODEL, TEMP, PROMPT, MAX_TOKENS)

# 2. Function designed to handle the legacy 3-element structure
def process_legacy_config(config_tuple):
    """
    Processes the configuration tuple, using star unpacking to ignore
    any extra elements introduced by newer versions.
    """
    # 3. Use star unpacking to extract only the first three elements.
    # The fourth element (MAX_TOKENS) is safely captured by *_ (or *rest)
    # and ignored, ensuring the legacy code doesn't break.
    model, temp, prompt, *_ = config_tuple

    # 4. Return confirmation string using only the three extracted variables
    prompt_length = len(prompt)
    return f"Legacy Processor initialized. Model: {model}, Temp: {temp}, Prompt length: {prompt_length}."

# Execution
new_config = get_chain_config()
print(f"Full Configuration Tuple: {new_config}")

legacy_output = process_legacy_config(new_config)
print(f"Legacy Processor Output: {legacy_output}")

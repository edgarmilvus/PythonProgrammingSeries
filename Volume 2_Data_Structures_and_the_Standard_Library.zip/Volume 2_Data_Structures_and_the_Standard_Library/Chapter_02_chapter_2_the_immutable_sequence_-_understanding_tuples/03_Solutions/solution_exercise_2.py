
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

def update_policy(policy_tuple, old_id, new_id):
    """
    Simulates modification of an immutable tuple by converting to a list,
    updating the element, and converting back to a new tuple.
    """
    # 1. Convert the input policy_tuple into a temporary list
    temp_list = list(policy_tuple)

    try:
        # 2. Use list.index() to find the position of the old_id
        index_to_replace = temp_list.index(old_id)

        # 3. Replace the element at the found index
        temp_list[index_to_replace] = new_id

        # 5. Convert the modified list back into a new tuple and return it
        return tuple(temp_list)

    except ValueError:
        # 4. If old_id is not found, list.index() raises ValueError.
        # We catch it and return the original tuple unmodified.
        return policy_tuple

# Initial policy configuration
security_policies = (100, 101, 102, 103, 104)

# Target replacement: Replace 102 with 999
updated_policies = update_policy(security_policies, 102, 999)
print(f"Original Policies: {security_policies}")
print(f"Updated Policies: {updated_policies}")

# Test case where ID is not found
unchanged_policies = update_policy(security_policies, 500, 999)
print(f"Unchanged Policies (ID 500 not found): {unchanged_policies}")

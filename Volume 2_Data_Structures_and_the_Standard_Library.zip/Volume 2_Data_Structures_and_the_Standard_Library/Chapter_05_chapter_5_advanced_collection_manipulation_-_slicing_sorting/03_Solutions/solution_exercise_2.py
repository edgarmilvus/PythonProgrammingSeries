
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

INSTRUMENTS = [
    {"name": "AAPL", "type": "Stock", "value": 150.00, "risk_level": 3},
    {"name": "TSLA", "type": "Stock", "value": 250.00, "risk_level": 5},
    {"name": "CorpBond_A", "type": "Bond", "value": 98.50, "risk_level": 1},
    {"name": "MSFT", "type": "Stock", "value": 150.00, "risk_level": 4},
    {"name": "GovtBond_Z", "type": "Bond", "value": 105.00, "risk_level": 1},
    {"name": "Call_Option_X", "type": "Option", "value": 5.00, "risk_level": 2},
    {"name": "CorpBond_B", "type": "Bond", "value": 98.50, "risk_level": 2},
]

# Define a lambda key function that returns a tuple of criteria.
# 1. item['type'] (Ascending, default)
# 2. -item['value'] (Descending, achieved by numerical negation)
# 3. item['name'] (Ascending, default)
SORTED_INSTRUMENTS = sorted(
    INSTRUMENTS,
    key=lambda item: (item['type'], -item['value'], item['name'])
)

# Expected Order Check (Bonds, Options, Stocks):
# Bond (GovtBond_Z 105.0)
# Bond (CorpBond_A 98.5) - A before B due to name tie-breaker
# Bond (CorpBond_B 98.5)
# Option (Call_Option_X 5.0)
# Stock (TSLA 250.0)
# Stock (AAPL 150.0) - A before M due to name tie-breaker
# Stock (MSFT 150.0)

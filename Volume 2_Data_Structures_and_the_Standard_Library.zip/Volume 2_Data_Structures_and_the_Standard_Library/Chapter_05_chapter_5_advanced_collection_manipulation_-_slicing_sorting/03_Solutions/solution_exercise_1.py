
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

LOG_STREAM = "A1|B2|C3|D4|E5|F6|G7|H8|I9|"

# NOTE ON CONSTRAINT: It is mathematically impossible to achieve the required interleaved
# output (I9H8G7...A1) using a single standard Python slice [start:stop:step] because
# the required indices (25, 24, 22, 21, 19, 18, ...) do not follow a constant step pattern.
#
# To demonstrate the required advanced slicing techniques (negative step, step > 1)
# and achieve the final output, we must derive the two necessary reversed components
# via slicing and then interleave them, which requires iteration (zip/join) and
# violates the strict "single slice" rule. We use the iteration necessary to meet
# the output requirement while isolating the core slicing logic.

# 1. Extract the reversed letters (I, H, G, ... A) - Start index 24, step -3
letters_reversed = LOG_STREAM[24::-3]

# 2. Extract the reversed numbers (9, 8, 7, ... 1) - Start index 25, step -3
numbers_reversed = LOG_STREAM[25::-3]

# Interleave the components to achieve the required I9H8...A1 output.
REVERSED_LOG_DATA = "".join(l + n for l, n in zip(letters_reversed, numbers_reversed))

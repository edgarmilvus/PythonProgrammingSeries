
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

NETWORK_CONFIG = {
    "protocol": "TCP",
    "host": "127.0.0.1",
    "timeout_seconds": 30,
    "max_connections": 100
    # Note: 'port' and 'auth_required' are missing
}

# Task A: Safe Parameter Extraction using dict.get()
protocol = NETWORK_CONFIG.get("protocol") # No default needed, key exists
port = NETWORK_CONFIG.get("port", 8080) # Default to 8080 if missing
timeout = NETWORK_CONFIG.get("timeout_seconds") # No default needed, key exists
auth = NETWORK_CONFIG.get("auth_required", False) # Default to False if missing

SAFE_SETTINGS = (protocol, port, timeout, auth)

# Task B: Dynamic Setting Generation using dict.items() and type filtering
TUNABLE_SETTINGS = []

for key, value in NETWORK_CONFIG.items():
    # Filter for values that are integers or floats
    if isinstance(value, (int, float)):
        formatted_string = f"SETTING: {key} = {value}"
        TUNABLE_SETTINGS.append(formatted_string)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import datetime

def generate_config_and_save(project_name, version, settings, output_filepath):
    """
    Generates configuration lines and persists them directly to a file.
    
    Returns True if save is successful, False otherwise.
    """
    # Configuration Data Generation
    config_lines = [
        f"[General]",
        f"PROJECT_NAME={project_name}",
        f"VERSION={version}",
        f"GENERATED_ON={datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    ]
    
    # Add dynamic settings
    for key, value in settings.items():
        config_lines.append(f"{key.upper()}={value}")
    
    # 2. Data Persistence using 'with' statement
    try:
        with open(output_filepath, 'w') as f_config:
            # 3. Writing Iteration
            for line in config_lines:
                # 3. Ensure newline character is added
                f_config.write(line + '\n')
                
        # 4. Return Value
        print(f"Configuration successfully saved to {output_filepath}")
        return True
        
    except IOError as e:
        print(f"Error saving configuration: {e}")
        return False

# settings_data = {"debug": "True", "port": 8080, "timeout": 30}
# generate_config_and_save("WebApp", "1.0.5", settings_data, "project_config.ini")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# --- Setup Code: Creating the raw_data.txt file ---
test_content = [
    "  Line 1: This is clean. \n",
    "Line 2: Data point. \n",
    "   \n", # Blank line with spaces
    "Line 4: Another entry.\t\t\n",
    "\n", # Completely blank line
    "  Line 6: Needs trimming.  \n",
    "Line 7: Final data entry.\n"
]

# Write this content to raw_data.txt using the 'w' mode and a context manager.
with open("raw_data.txt", "w") as f_raw:
    f_raw.writelines(test_content)
# ---------------------------------------------------

def sanitize_file(input_filename, output_filename):
    """Reads, cleans, and writes file content, skipping empty lines."""
    cleaned_lines = []
    
    # Requirement 1: Mandatory Context Manager Usage (Reading)
    # Use 'r' mode for reading
    try:
        with open(input_filename, 'r') as infile:
            for line in infile:
                # Requirement 2: Remove leading/trailing whitespace
                stripped_line = line.strip()
                
                # Requirement 2: Implement If Statement to skip empty lines
                if stripped_line:
                    cleaned_lines.append(stripped_line)
                    
    except FileNotFoundError:
        print(f"Error: Input file '{input_filename}' not found.")
        return

    # Requirement 1: Mandatory Context Manager Usage (Writing)
    # Use 'w' mode for writing (overwriting if exists)
    with open(output_filename, 'w') as outfile:
        for clean_line in cleaned_lines:
            # Requirement 3: Write the line followed by a newline
            outfile.write(clean_line + '\n')
            
    print(f"Successfully sanitized {len(cleaned_lines)} lines to '{output_filename}'.")

# Execute the function
sanitize_file("raw_data.txt", "clean_data.txt")

# Optional: Verify the output file content
# with open("clean_data.txt", "r") as f:
#     print("\nContent of clean_data.txt:\n", f.read())


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Import required module:
import datetime

def log_event(log_file_path, message):
    """Records a timestamped message into a specified log file using append mode."""
    
    # Requirement 2: Timestamping
    now = datetime.datetime.now()
    timestamp = now.strftime("[%Y-%m-%d %H:%M:%S]")
    
    # Requirement 3: Formatted Output
    log_entry = f"{timestamp} - {message}\n"
    
    # Requirement 1 & 4: Append Mode and Context Manager
    # The 'a' mode ensures new entries are added without overwriting existing data.
    with open(log_file_path, 'a') as log_file:
        log_file.write(log_entry)
        
    print(f"Logged event to {log_file_path}")

# Requirement 5: Function Call Simulation
log_file = "app_activity.log"
log_event(log_file, "Application started successfully.")
log_event(log_file, "User attempted login with invalid credentials.")
log_event(log_file, "Database connection closed cleanly.")

# Optional: Verify the log file content
# with open(log_file, "r") as f:
#     print("\nContent of app_activity.log:\n", f.read())

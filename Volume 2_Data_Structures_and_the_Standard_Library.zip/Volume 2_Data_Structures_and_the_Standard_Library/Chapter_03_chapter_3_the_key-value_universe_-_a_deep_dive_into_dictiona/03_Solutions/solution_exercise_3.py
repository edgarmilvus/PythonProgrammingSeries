
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

active_sessions = {
    1001: {'logged_in': True, 'last_action': 'checkout', 'cart_items': 3},
    1002: {'logged_in': True, 'last_action': 'view_profile', 'cart_items': 0}
}

# 2. Safe Retrieval using .get()

# Retrieve existing user data
print(f"User 1001 last action (standard): {active_sessions[1001]['last_action']}")

# Attempt to retrieve non-existent user data using standard notation (commented out to prevent crash):
# print(active_sessions[1003]['last_action']) 

# Safely retrieve non-existent user data using .get() with a default value
user_1003_action = active_sessions.get(1003, 'User Not Found')
print(f"User 1003 session status (safe .get()): {user_1003_action}")
print("-" * 30)

# 3. Atomic Initialization using .setdefault()
default_session_data = {'logged_in': False, 'last_action': 'login_attempt', 'cart_items': 0}

# Initialize session for new user 1004 (Key does not exist -> value is set)
session_1004 = active_sessions.setdefault(1004, default_session_data)
print(f"Session 1004 initialized: {session_1004}")

# Attempt to use .setdefault() again for User 1004 (Key exists -> value is NOT overwritten)
attempt_overwrite = active_sessions.setdefault(1004, {'status': 're-attempt'})
print(f"Session 1004 after second setdefault: {attempt_overwrite}")

# Explanation for second setdefault:
# The second .setdefault() call did not overwrite the existing session data for 1004 
# because the key 1004 was already present. .setdefault() only inserts the default 
# value if the key is missing; otherwise, it returns the existing value unchanged.
print("-" * 30)

# 4. Data Aggregation and Default Handling
total_cart_items = 0

# Simulate data corruption (missing nested key) for 1002
if 1002 in active_sessions:
    del active_sessions[1002]['cart_items']

for user_id, session_data in active_sessions.items():
    # Use .get() on the nested dictionary to safely retrieve 'cart_items', defaulting to 0 if missing.
    item_count = session_data.get('cart_items', 0)
    total_cart_items += item_count

print(f"Total items across all carts (handling missing nested keys): {total_cart_items}")

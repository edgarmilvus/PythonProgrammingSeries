
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

app_config = {
    'Development': {
        'database': {'url': 'dev_db_url_1', 'timeout': 5},
        'api_gateway': {'endpoint': 'dev_api_endpoint_A', 'version': 1.0},
        'logging': {'level': 'DEBUG', 'destination': 'console'}
    },
    'Production': {
        'database': {'url': 'prod_db_url_9', 'timeout': 30},
        'api_gateway': {'endpoint': 'prod_api_endpoint_B', 'version': 2.1},
        'logging': {'level': 'INFO', 'destination': 'file'}
    },
    'Staging': {
        'database': {'url': 'stage_db_url_5', 'timeout': 10},
        'api_gateway': {'endpoint': 'stage_api_endpoint_C', 'version': 1.5}
    }
}

# 1. Flattening the Structure (Comprehension 1)
# New Key: Environment_Service, Value: Settings Dict
flattened_endpoints = {
    f"{env}_{service}": settings
    for env, services in app_config.items()
    for service, settings in services.items()
}

print("1. Flattened Endpoints:")
print(flattened_endpoints)
print("-" * 30)

# 2. Conditional Filtering and Transformation (Comprehension 2)
# Filter: Key starts with 'Production_'
# Value Transformation: Extract only the URL/Endpoint string
prod_urls_only = {
    key: settings.get('url') or settings.get('endpoint')
    for key, settings in flattened_endpoints.items()
    if key.startswith('Production_')
}

print("2. Production URLs Only:")
print(prod_urls_only)
print("-" * 30)

# 3. Handling Missing Keys During Transformation
# The initial comprehension naturally skips the missing 'logging' key in 'Staging' 
# because we iterate over the existing services in services.items(). 
# If we needed to guarantee that a specific setting (e.g., 'timeout') exists, 
# we use .get() in the value expression for safe access:

timeouts_only_safe = {
    f"{env}_timeout": services.get(service, {}).get('timeout', 'N/A')
    for env, services in app_config.items()
    for service in ['database', 'api_gateway', 'logging'] # Explicitly list services, forcing a check
    if services.get(service) is not None # Skip if the service key is missing entirely
}

print("3. Safe Timeout Extraction (Handling missing service keys):")
print(timeouts_only_safe)

# 4. Conceptual Explanation:
# Dictionary comprehensions are preferred because they embody a functional style, 
# transforming data declaratively rather than imperatively. They are significantly 
# more readable and concise than multi-line for loops, especially for complex 
# nested transformations, as the entire logic (iteration, filtering, and assignment) 
# is contained within a single expression.


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# 1. Token Registry Setup
# Using immutable tuples as keys for the unique token and session identifier
token_registry = {
    ('a1b2c3d4', 'user_session_id_77'): 105,
    ('e5f6g7h8', 'user_session_id_88'): 210
}

# 2. The validate_token Function
def validate_token(token_key, expected_user_id):
    """
    Validates if a token key exists in the registry and matches the expected user ID.
    """
    # 3. Validation Logic (Using .get() and Comparison Operators)
    # Safely retrieve the associated user ID, defaulting to None if the token is not found.
    actual_user_id = token_registry.get(token_key, None)
    
    # Comparison Operator check: returns True only if the retrieved ID exactly matches the expected ID.
    is_valid = actual_user_id == expected_user_id
    
    return is_valid

# 4. Testing and Security Failure Simulation
token_105 = ('a1b2c3d4', 'user_session_id_77')
token_210 = ('e5f6g7h8', 'user_session_id_88')
expired_token = ('x9y0z1a2', 'session_expired_123')

# Test 1: Successful Validation
print(f"Validation 1 (Success): {validate_token(token_105, 105)}")

# Test 2: Security Failure (Valid token, but incorrect expected user ID - CSRF attempt)
print(f"Validation 2 (Security Failure - Wrong ID): {validate_token(token_210, 105)}")

# Test 3: Expired/Non-existent Token
print(f"Validation 3 (Expired Token): {validate_token(expired_token, 105)}")

# 5. Conceptual Reinforcement (Statement Analysis)
# The crucial comparison statement is:
# is_valid = actual_user_id == expected_user_id

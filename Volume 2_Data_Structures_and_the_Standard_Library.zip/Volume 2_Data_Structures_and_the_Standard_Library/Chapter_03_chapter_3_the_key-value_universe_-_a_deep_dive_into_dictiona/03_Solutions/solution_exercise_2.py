
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

landmark_registry = {}

# 1. Successful Key Creation (Tuples are immutable and hashable)
landmark_registry[(34.0522, -118.2437)] = 'Los Angeles City Hall'
landmark_registry[(40.7128, -74.0060)] = 'Statue of Liberty'
landmark_registry[(-33.8688, 151.2093)] = 'Sydney Opera House'

retrieved_landmark = landmark_registry[(40.7128, -74.0060)]
print(f"Retrieved Landmark: {retrieved_landmark}")
print("-" * 30)

# 2. Handling Unhashable Keys (Lists are mutable and unhashable)
try:
    # Attempting to use a list as a key will raise a TypeError
    landmark_registry[[48.8566, 2.3522]] = 'Eiffel Tower'
except TypeError as e:
    print(f"Caught Expected Error: {e}")
    print("Operation Failed: Lists are mutable. Dictionary keys must be hashable (immutable) to guarantee a stable hash value for efficient lookup.")
print("-" * 30)

# 3. Key Transformation
new_coords = [[51.5074, 0.1278], [35.6895, 139.6917]]
new_landmarks = ['London Eye', 'Tokyo Skytree']

# Convert mutable lists to immutable tuples before insertion
for i, coord_list in enumerate(new_coords):
    coord_tuple = tuple(coord_list)
    landmark_registry[coord_tuple] = new_landmarks[i]

print("Registry after list-to-tuple transformation:")
print(landmark_registry)

# 4. Conceptual Reinforcement
# A tuple's immutability guarantees a stable hash value. This stability is essential 
# because the dictionary's underlying hash map uses this hash value to determine 
# the location of the stored value. If the key were mutable, its hash could change 
# after insertion, making the original value unreachable during subsequent lookups.

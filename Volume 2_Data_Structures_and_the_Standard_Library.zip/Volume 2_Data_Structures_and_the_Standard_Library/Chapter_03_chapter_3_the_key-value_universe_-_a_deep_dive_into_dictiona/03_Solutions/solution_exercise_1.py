
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# Initial Inventory Data Structure
initial_inventory = {
    'ELC-481': {'name': 'Wireless Mouse', 'quantity': 150, 'price': 12.50},
    'ACC-920': {'name': 'HDMI Cable 6ft', 'quantity': 300, 'price': 4.99},
    'PER-105': {'name': 'Mechanical Keyboard', 'quantity': 45, 'price': 75.00},
    'MEM-32G': {'name': '32GB USB Drive', 'quantity': 80, 'price': 15.99},
    'NET-500': {'name': 'Ethernet Switch (5 Port)', 'quantity': 20, 'price': 35.50}
}

# 1. Initial Setup and Insertion (Create/Update)
# Add new product 'BAT-110'
initial_inventory['BAT-110'] = {'name': 'Battery Pack', 'quantity': 120, 'price': 22.00}
# Update 'ACC-920' quantity
initial_inventory['ACC-920']['quantity'] = 350

# 2. Sales Transaction (Update/Delete)
# Simulate sale of 5 units of 'PER-105'
initial_inventory['PER-105']['quantity'] -= 5

# Test removal logic: Simulate a sale that depletes 'NET-500' (20 units remaining)
initial_inventory['NET-500']['quantity'] -= 40 # Quantity is now -20

# Check and remove depleted items (quantity <= 0)
# Create a list of keys to remove to avoid RuntimeError during iteration
keys_to_remove = [key for key, data in initial_inventory.items() if data['quantity'] <= 0]
for key in keys_to_remove:
    del initial_inventory[key]
    
print(f"Inventory after updates and removal: {initial_inventory.keys()}")

# 3. Reporting using Views (Read/Views)

# Product ID List (using .keys() view)
product_ids = list(initial_inventory.keys())
print(f"\nProduct IDs: {product_ids}")

# Total Inventory Value (using .items() view)
total_value = 0
for data_id, data in initial_inventory.items():
    total_value += data['quantity'] * data['price']
print(f"Total Inventory Value: ${total_value:,.2f}")

# High-Value Item Report (using .values() view)
high_value_items = []
price_threshold = 30.00
for data in initial_inventory.values():
    if data['price'] > price_threshold:
        high_value_items.append(data['name'])

print(f"High-Value Items (> $30.00): {high_value_items}")

# 4. Conceptual Reinforcement
# Conceptual Comment: Using dictionary views (keys, values, items) is memory-efficient 
# because they provide a dynamic, read-only window into the dictionary's data 
# without copying the data structure itself. They reflect changes instantly and 
# avoid duplicating potentially massive amounts of data in memory.


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from collections import Counter

corpus_words = [
    "the", "quick", "brown", "fox", "jumps", "over", "the", "lazy", "dog",
    "quick", "jumps", "dog", "programming", "python", "elegant", "comprehension",
    "programming", "elegant", "the", "python"
]
MIN_WORD_LENGTH = 6

# --- Part A: Building the Substantial Vocabulary (Set Comprehension) ---
substantial_vocabulary = {
    word.lower()
    for word in corpus_words
    if len(word) > MIN_WORD_LENGTH
}
# Result: {'programming', 'comprehension', 'elegant'}

# --- Part B: Mapping Word Frequency (Dictionary Comprehension) ---

# Step 1: Efficiently calculate the frequency of ALL normalized words in the corpus
# (This avoids O(N^2) lookups if list.count() were used inside the comprehension)
normalized_counts = Counter(word.lower() for word in corpus_words)

# Step 2: Use a dictionary comprehension to iterate over the filtered set
# and look up the pre-calculated count.
frequency_map = {
    word: normalized_counts[word]
    for word in substantial_vocabulary
}

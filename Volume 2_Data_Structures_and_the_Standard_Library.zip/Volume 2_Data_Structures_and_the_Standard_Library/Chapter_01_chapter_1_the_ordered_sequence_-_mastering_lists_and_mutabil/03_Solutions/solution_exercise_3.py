
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# 1. Initialization
primary_config = ["Server A", "192.168.1.1", 8080, "Active"]

print("--- ALIASING FAILURE SCENARIO ---")
# 2. Creating the Alias
backup_alias = primary_config

# 3. Verification of Identity (Both variables point to the same object)
print(f"Are primary_config and backup_alias the same object? {primary_config is backup_alias}")

# 4. Demonstrating Side Effect: Modify primary_config
primary_config[0] = "Server A - Patched"

# 5. Observation: backup_alias is unexpectedly modified
print(f"\nPrimary Config (Modified): {primary_config}")
print(f"Backup Alias (Corrupted): {backup_alias}")
print("Observation: Modifying the primary list corrupted the backup alias.")

print("\n--- THE FIX: SHALLOW COPY VIA SLICING ---")
# 6. The Fix (Shallow Copy): Re-initialize primary and create a safe copy
primary_config = ["Server A", "192.168.1.1", 8080, "Active"]
backup_safe = primary_config[:]  # Shallow copy using slicing

print(f"Are primary_config and backup_safe the same object? {primary_config is backup_safe}")

# 7. Testing the Fix: Modify primary_config again
primary_config[0] = "Server A - Patched V2"

# 8. Final Verification: backup_safe is untouched
print(f"\nPrimary Config (Modified): {primary_config}")
print(f"Backup Safe (Untouched): {backup_safe}")
print("Observation: The safe backup is isolated because slicing created a new list object.")

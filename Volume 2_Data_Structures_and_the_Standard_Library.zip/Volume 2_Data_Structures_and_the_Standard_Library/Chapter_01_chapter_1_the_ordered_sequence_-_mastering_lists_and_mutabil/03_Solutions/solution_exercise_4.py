
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import copy

prod_inventory = [
    ["Laptop X", 15, ["Supplier A", "Supplier B"]],
    ["Monitor Y", 50, ["Supplier C"]],
    ["Keyboard Z", 100, ["Supplier D", "Supplier E"]]
]

print("--- PART A: SHALLOW COPY FAILURE ---")

# 1. Shallow Copy Creation
test_inventory_shallow = prod_inventory[:]

# 2. Test Non-Nested Elements (This succeeds)
test_inventory_shallow[0][1] = 5  # Reduce stock of Laptop X
print(f"Prod Inventory (Non-nested check): {prod_inventory[0][1]}")
print(f"Shallow Test (Non-nested check): {test_inventory_shallow[0][1]}")

# 3. Test Nested Elements (This fails)
# Append a new supplier to Monitor Y in the shallow copy
test_inventory_shallow[1][2].append("Supplier F")

# 4. Observation of Failure
print("\n--- After Nested Modification ---")
print(f"Original Prod Inventory: {prod_inventory[1]}")
print(f"Shallow Test Inventory: {test_inventory_shallow[1]}")
print("Observation: The original list was corrupted because the nested supplier list was shared.")

print("\n--- PART B: IMPLEMENTING DEEP COPY FIX ---")

# 5. Re-initialization
prod_inventory = [
    ["Laptop X", 15, ["Supplier A", "Supplier B"]],
    ["Monitor Y", 50, ["Supplier C"]],
    ["Keyboard Z", 100, ["Supplier D", "Supplier E"]]
]

# 6. Deep Copy Creation
test_inventory_deep = copy.deepcopy(prod_inventory)

# 7. Modification Test (Modifying nested element in the deep copy)
test_inventory_deep[1][2].append("Supplier G")

# 8. Final Verification
print(f"Original Prod Inventory: {prod_inventory[1]}")
print(f"Deep Copy Test Inventory: {test_inventory_deep[1]}")
print("Observation: The original list remains isolated, confirming the success of deep copy.")

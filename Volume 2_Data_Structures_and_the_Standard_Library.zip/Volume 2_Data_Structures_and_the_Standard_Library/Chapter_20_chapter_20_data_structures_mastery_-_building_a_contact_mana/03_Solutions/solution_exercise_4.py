
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

SYSTEM_A = {
    'C100': {'name': 'Alice Smith', 'phone': '111-1111'},  # Unique A
    'C200': {'name': 'Conflict Guy', 'phone': '222-2222'}, # Conflict
    'C300': {'name': 'Only A', 'phone': '333-3333'}        # Unique A
}

SYSTEM_B = {
    'C200': {'name': 'Conflict Guy B', 'email': 'guy@b.com'}, # Conflict
    'C400': {'name': 'Bob Jones', 'email': 'bob@b.com'}      # Unique B
}

MASTER_CONTACTS = {}

# 1. Get key sets for categorization
keys_A = set(SYSTEM_A.keys())
keys_B = set(SYSTEM_B.keys())

# 2. Calculate categories using set operations
unique_A = keys_A - keys_B
unique_B = keys_B - keys_A
conflicts = keys_A.intersection(keys_B)

# Define standard fields for the final structure
STANDARD_FIELDS = ['name', 'phone', 'email']

def standardize_record(record: dict, source_set: set) -> dict:
    """Ensures the final record has all required fields (even if None) and tracks sources."""
    final_record = {field: record.get(field) for field in STANDARD_FIELDS}
    final_record['source_systems'] = source_set
    return final_record

# 3. Unique Merging (A and B)
for cid in unique_A:
    MASTER_CONTACTS[cid] = standardize_record(SYSTEM_A[cid], {'A'})

for cid in unique_B:
    MASTER_CONTACTS[cid] = standardize_record(SYSTEM_B[cid], {'B'})

# 4. Conflict Resolution (A priority, B fills gaps)
for cid in conflicts:
    record_A = SYSTEM_A[cid]
    record_B = SYSTEM_B[cid]
    
    # Start with System A data (priority data)
    merged_record = record_A.copy()
    
    # Iterate through B and fill in any keys A missed
    for key, value in record_B.items():
        # Check if the key is missing in A or if A's value is considered empty/None
        if key not in merged_record or merged_record.get(key) is None:
            merged_record[key] = value

    # Standardize the output, ensuring both systems are tracked
    MASTER_CONTACTS[cid] = standardize_record(merged_record, {'A', 'B'})

# --- Interactive Element (as required by the prompt) ---
# Testing C200 merge result: {'name': 'Conflict Guy', 'phone': '222-2222', 'email': 'guy@b.com', 'source_systems': {'A', 'B'}}
print("\n--- Data Migration Complete ---")
print(f"Total contacts merged: {len(MASTER_CONTACTS)}")

# Interactive lookup simulation
contact_id_to_check = 'C200' # Example ID
if contact_id_to_check in MASTER_CONTACTS:
    record = MASTER_CONTACTS[contact_id_to_check]
    sources = ", ".join(sorted(list(record['source_systems'])))
    
    print(f"\nLookup for ID: {contact_id_to_check}")
    print(f"Sources: {sources}")
    print("Record Details:")
    for k, v in record.items():
        print(f"  - {k}: {v}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# Main CONTACTS structure (assuming the tuple structure from Exercise 1):
CONTACTS_EX5 = {
    'C1': ('A', '1', 'a@a.com', 'Work'),
    'C2': ('B', '2', 'b@b.com', 'Family'),
    'C3': ('C', '3', 'c@c.com', 'Work'),
    'C4': ('D', '4', 'd@d.com', 'Family'),
    'C5': ('E', '5', 'e@e.com', 'Clients')
}

def build_group_index(contacts_data: dict) -> dict:
    """
    Builds the secondary index mapping Group Tag (key) to a set of Contact IDs (value).
    """
    group_index = {}
    
    for contact_id, contact_tuple in contacts_data.items():
        # Group Tag is at index 3
        group_tag = contact_tuple[3]
        
        # Use setdefault to initialize the set if the group_tag is new
        group_index.setdefault(group_tag, set()).add(contact_id)
        
    return group_index

# Pre-build the index once
GROUP_INDEX = build_group_index(CONTACTS_EX5)

def search_by_group_slow(group_tag: str, contacts_data: dict) -> list:
    """
    O(N) search: Iterates through every contact record.
    """
    results = []
    for contact_id, contact_tuple in contacts_data.items():
        if contact_tuple[3] == group_tag: # Check Group Tag (index 3)
            results.append(contact_id)
    return results

def search_by_group_fast(group_tag: str, group_index: dict) -> set:
    """
    O(1) search: Uses the pre-built dictionary index for instant lookup.
    """
    # Dictionary lookup is O(1) average time complexity
    # Returns an empty set if the group_tag is not found
    return group_index.get(group_tag, set())

# Example Usage
# print(f"Index built: {GROUP_INDEX}")
# print(f"Slow search results (Work): {search_by_group_slow('Work', CONTACTS_EX5)}")
# print(f"Fast search results (Work): {search_by_group_fast('Work', GROUP_INDEX)}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Initial structures provided for refactoring:
GROUPS = {
    'G101': ('Client Accounts', 'Primary business contacts.'),
    'G102': ('Internal Staff', 'Employees and organizational contacts.')
}

CONTACTS = {
    'C001': ('Fiona Apple', '555-0001', 'fiona@music.com', 'G101'),
    'C002': ('Trent Reznor', '555-0002', 'trent@nine.com', 'G102'),
    # C003 references G999, which does not exist, simulating a broken link
    'C003': ('Invalid Contact', '555-9999', 'bad@ref.com', 'G999') 
}

def get_contact_full_details(contact_id: str) -> dict:
    """
    Retrieves full contact details, requiring a lookup across CONTACTS and GROUPS.
    """
    
    # 1. Lookup contact record (Handles missing contact_id via KeyError)
    try:
        name, phone, email, group_id = CONTACTS[contact_id]
    except KeyError:
        # Re-raise with a descriptive message
        raise KeyError(f"Contact ID '{contact_id}' not found in CONTACTS.")

    # 2. Lookup group details (Handles broken reference via LookupError)
    try:
        group_name, group_description = GROUPS[group_id]
    except KeyError:
        # Raise a specific error type for data inconsistency
        raise LookupError(f"Data integrity error: Group ID '{group_id}' referenced by contact {contact_id} does not exist in GROUPS.")

    # 3. Return combined dictionary
    return {
        'Name': name,
        'Phone': phone,
        'Email': email,
        'Group_ID': group_id,
        'Group_Name': group_name,
        'Group_Description': group_description
    }

# Example Usage (Testing broken reference)
# try:
#     get_contact_full_details('C003')
# except LookupError as e:
#     print(f"Lookup Error caught: {e}")

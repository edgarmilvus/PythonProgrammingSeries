
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# Initial structures provided for context (defined globally for modification)
CONTACTS = {
    'C001': ('Alice Smith', '555-1234', 'alice@example.com', 'Family'),
    'C002': ('Bob Johnson', '555-5678', 'bob@work.com', 'Colleagues')
}

UNIQUE_PHONES = {'555-1234', '555-5678'}
UNIQUE_EMAILS = {'alice@example.com', 'bob@work.com'}

def add_validated_contact(contact_id: str, contact_data: tuple) -> bool:
    """
    Adds a new contact after validating schema, data types, and uniqueness.
    """
    
    # Requirement 1: Define the Schema (Check tuple length)
    if not isinstance(contact_data, tuple) or len(contact_data) != 4:
        raise ValueError("Contact data must be a tuple of exactly four elements: (Name, Phone, Email, Group).")

    name, phone, email, group = contact_data

    # Requirement 3: Data Type Validation (All must be strings)
    if not all(isinstance(f, str) for f in contact_data):
        raise TypeError("All contact fields (Name, Phone, Email, Group) must be strings.")

    # Requirement 2: Uniqueness Constraint Check (O(1) lookup using sets)
    if phone in UNIQUE_PHONES:
        raise KeyError(f"Phone number '{phone}' already exists in the system.")
    
    if email in UNIQUE_EMAILS:
        raise KeyError(f"Email address '{email}' already exists in the system.")

    # Requirement 4: Successful Insertion
    CONTACTS[contact_id] = contact_data
    UNIQUE_PHONES.add(phone)
    UNIQUE_EMAILS.add(email)
    
    return True

# Example Usage (Testing conflict)
# try:
#     add_validated_contact('C003', ('Charlie Brown', '555-1234', 'charlie@test.com', 'Friends'))
# except KeyError as e:
#     print(f"Error caught: {e}")

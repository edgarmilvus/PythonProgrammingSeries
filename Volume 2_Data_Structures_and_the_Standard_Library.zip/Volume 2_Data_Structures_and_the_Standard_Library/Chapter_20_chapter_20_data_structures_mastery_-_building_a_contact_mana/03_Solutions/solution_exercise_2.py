
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

CONTACTS_EX2 = {
    'C003': ('John Doe', '555-9901', 'john.doe@work.com', 'Clients'),
    'C004': ('Jane Smith', '555-1299', 'jane.s@university.edu', 'Students'),
    'C005': ('Jack Black', '555-8888', 'jack@work.com', 'Clients')
}

def search_contacts_advanced(**kwargs) -> list:
    """
    Searches contacts based on multiple, combined criteria provided as keyword arguments.
    """
    results = []
    
    # Iterate through all items (ID and the data tuple)
    for contact_id, contact_data in CONTACTS_EX2.items():
        name, phone, email, group = contact_data
        
        match = True
        
        # Apply filters sequentially. If one fails, set match=False and break checks.
        
        # 1. Name Contains (Index 0, case-insensitive partial match)
        if 'name_contains' in kwargs:
            search_term = kwargs['name_contains'].lower()
            if search_term not in name.lower():
                match = False
        
        # 2. Group Is (Index 3, case-insensitive exact match)
        if match and 'group_is' in kwargs:
            search_group = kwargs['group_is'].lower()
            if search_group != group.lower():
                match = False
                
        # 3. Phone Partial (Index 1, substring match)
        if match and 'phone_partial' in kwargs:
            search_phone = kwargs['phone_partial']
            if search_phone not in phone:
                match = False
                
        # 4. Email Domain (Index 2, ends with check)
        if match and 'email_domain' in kwargs:
            search_domain = kwargs['email_domain']
            if not email.endswith(search_domain):
                match = False
        
        # If all criteria passed, append the required output format (ID, Name)
        if match:
            results.append((contact_id, name))
            
    return results

# Example Call:
# search_results = search_contacts_advanced(name_contains='Ja', group_is='clients', phone_partial='99')
# print(search_results) # Expected: [('C004', 'Jane Smith')]

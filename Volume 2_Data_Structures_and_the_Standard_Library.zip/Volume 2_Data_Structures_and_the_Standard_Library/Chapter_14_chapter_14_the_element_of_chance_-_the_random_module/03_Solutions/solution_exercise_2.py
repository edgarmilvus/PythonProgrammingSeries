
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import random

# 1. Define Pools
ball_pool = list(range(1, 51))
# Historical data: 5, 12, 33 appear three times, 45 appears twice
historical_winners = [5, 5, 12, 12, 12, 45, 45, 33, 33, 33]

def grand_draw(pool, k):
    """
    Selects k unique winning numbers using random.sample().
    """
    # Use sample() to select k unique items without replacement
    winners = random.sample(pool, k)
    return winners

def bonus_draw(historical_data, current_pool, grand_prize_winners):
    """
    Selects a single bonus number from a weighted pool, ensuring uniqueness 
    relative to the grand prize winners.
    """
    # Create the weighted pool by combining the main pool and historical data
    weighted_pool = current_pool + historical_data
    
    bonus_number = None
    
    # Loop until a unique bonus number is selected
    while True:
        # Use choice() on the weighted pool (allowing duplicates in selection)
        bonus_number = random.choice(weighted_pool)
        
        # Crucial Check: Ensure the bonus number is not one of the grand prize winners
        if bonus_number not in grand_prize_winners:
            break
            
    return bonus_number

# Execution
# 1. Draw the Grand Prize winners (6 unique numbers)
grand_prize = grand_draw(ball_pool, 6)
grand_prize.sort() 

# 2. Draw the Bonus number, ensuring it is unique and weighted
bonus = bonus_draw(historical_winners, ball_pool, grand_prize)

print("--- Lottery Draw Results ---")
print(f"Ball Pool Size: {len(ball_pool)}")
print(f"Grand Prize Winners (6 unique): {grand_prize}")
print(f"Bonus Number (Unique, Weighted): {bonus}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Note: This code is designed to be saved as 'shuffler.py' and executed from the terminal.

import sys
import random

def main():
    """
    Reads command-line arguments, shuffles them in place, and prints the result.
    """
    
    # 1. Error Checking: sys.argv must contain at least the script name (index 0) 
    # and one item (index 1)
    if len(sys.argv) < 2:
        print("Error: Please provide items to shuffle.")
        print("Usage: python shuffler.py <item1> <item2> [item3] ...")
        sys.exit(1)

    # 2. Argument Extraction: Slice the list to exclude the script name (sys.argv[0])
    items_to_shuffle = sys.argv[1:]
    
    print(f"Original list (from command line): {items_to_shuffle}")
    
    # 3. Shuffling
    # random.shuffle() performs the modification IN PLACE, meaning it changes 
    # the 'items_to_shuffle' list directly.
    random.shuffle(items_to_shuffle)
    
    # 4. Output
    print("\n--- Shuffled Result ---")
    print(" ".join(items_to_shuffle))

if __name__ == "__main__":
    main()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import random
import string

# 1. Character Pools Definition
LOWERCASE = string.ascii_lowercase
UPPERCASE = string.ascii_uppercase
DIGITS = string.digits
SYMBOLS = "!@#$%^&*()[]{}<>" # Expanded selection

def generate_token(length, use_seed=None):
    """
    Generates a secure token of specified length using random.sample().
    """
    # 2. Controlled Randomness: Apply seed if provided
    if use_seed is not None:
        random.seed(use_seed)
        
    # 3. Combine all pools into a single available character set
    combined_pool = LOWERCASE + UPPERCASE + DIGITS + SYMBOLS
    
    # Safety Check: Ensure the requested length doesn't exceed the available unique characters
    if length > len(combined_pool):
        raise ValueError("Token length requested exceeds available unique characters.")
        
    # 4. Efficient Selection: Use random.sample() to select the required number 
    # of characters in a single, fast operation.
    selected_chars = random.sample(combined_pool, length)
    
    # 5. Final Assembly: Join the list of characters into a single string
    token = "".join(selected_chars)
    
    return token

# Testing Verification
TOKEN_LENGTH = 16
TEST_SEED = 99

print("--- Token Generator Verification ---")

# Test 1: Seeded Run 1
token_a = generate_token(TOKEN_LENGTH, use_seed=TEST_SEED)
print(f"Run 1 (Seed {TEST_SEED}): {token_a}")

# Test 2: Seeded Run 2 (Must be identical to Run 1)
token_b = generate_token(TOKEN_LENGTH, use_seed=TEST_SEED)
print(f"Run 2 (Seed {TEST_SEED}): {token_b}")

# Test 3: Unseeded Run (Truly random)
token_c = generate_token(TOKEN_LENGTH)
print(f"Run 3 (No Seed): {token_c}")

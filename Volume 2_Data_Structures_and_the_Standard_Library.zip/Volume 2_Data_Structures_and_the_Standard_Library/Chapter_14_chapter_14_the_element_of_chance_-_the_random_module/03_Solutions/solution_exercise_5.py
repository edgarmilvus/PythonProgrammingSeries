
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import random

# 1. Define Outcome Pools
life_paths = [
    "The Path of Abundance",
    "The Journey of Knowledge",
    "The Way of the Warrior",
    "The Embrace of Tranquility",
    "The Ascent to Mastery"
]

challenges = [
    "A Test of Patience",
    "A Hidden Secret",
    "The Need for Rest",
    "A Moment of Doubt",
    "The Call for Courage"
]

print("--- The Digital Fortune Teller ---")

# 2. User Interaction
user_name = input("Enter your name, seeker: ")

# Optional Twist: Reveal Hidden Energies using sample and shuffle
# Sample 3 unique items from each pool
sampled_paths = random.sample(life_paths, 3)
sampled_challenges = random.sample(challenges, 3)

# Combine and shuffle the temporary pool (in-place modification)
hidden_energies = sampled_paths + sampled_challenges
random.shuffle(hidden_energies)

print(f"\n{user_name}, the Hidden Energies swirling around you today are:")
print(f"  > {', '.join(hidden_energies)}")

# 3. Fortune Generation
# Life Path (Major Theme) using choice()
chosen_path = random.choice(life_paths)

# Current Challenge (Minor Obstacle) using choice()
chosen_challenge = random.choice(challenges)

# Mystical Number (Luck Intensity) using randint()
mystical_number = random.randint(1, 100)

# 4. Output Formatting
print("\n*** Your Final Fortune Revealed ***")
print(f"Seeker: {user_name}")
print(f"--------------------------------------------------")
print(f"Major Life Path: {chosen_path}")
print(f"Current Challenge: {chosen_challenge}")
print(f"Your Mystical Luck Number (1-100): {mystical_number}")
print(f"--------------------------------------------------")

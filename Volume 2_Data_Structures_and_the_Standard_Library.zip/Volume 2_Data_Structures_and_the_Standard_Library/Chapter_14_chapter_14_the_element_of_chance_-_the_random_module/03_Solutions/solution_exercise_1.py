
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import random

def simulate_rolls(num_rolls, seed_value):
    """
    Simulates dice rolls using a specific seed to ensure reproducibility.
    """
    # 1. Set the seed using the provided value
    random.seed(seed_value)
    
    results = []
    # 2. Simulate rolling a standard six-sided die (1 through 6)
    for _ in range(num_rolls):
        roll = random.randint(1, 6)
        results.append(roll)
        
    return results

# Demonstration
num_rolls = 10
fixed_seed = 42
different_seed = 100

print(f"--- Demonstration of Reproducibility (Seed={fixed_seed}) ---")

# Run 1: Sets the sequence based on seed 42
rolls_1 = simulate_rolls(num_rolls, fixed_seed)
print(f"Run 1 (Seed {fixed_seed}): {rolls_1}")

# Run 2: Re-setting the exact same seed 42 resets the generator state
rolls_2 = simulate_rolls(num_rolls, fixed_seed)
print(f"Run 2 (Seed {fixed_seed}): {rolls_2}") # Output must match Run 1

print("\n--- Demonstration of Non-Reproducibility (Changing Seed) ---")

# Run 3: Using a different seed generates an entirely new sequence
rolls_3 = simulate_rolls(num_rolls, different_seed)
print(f"Run 3 (Seed {different_seed}): {rolls_3}") # Output must differ

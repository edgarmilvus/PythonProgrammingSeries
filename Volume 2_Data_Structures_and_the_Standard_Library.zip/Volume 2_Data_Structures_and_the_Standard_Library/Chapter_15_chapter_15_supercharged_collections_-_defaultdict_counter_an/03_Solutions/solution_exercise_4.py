
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from collections import defaultdict, Counter

log_entries = [
    ("10:01:00", "user_A", "LOGIN", 200),
    ("10:01:15", "user_B", "QUERY", 500), 
    ("10:02:05", "user_A", "UPDATE", 404), 
    ("10:02:30", "user_C", "DOWNLOAD", 200),
    ("10:03:10", "user_B", "DELETE", 403), 
    ("10:03:50", "user_A", "QUERY", 500), 
    ("10:04:20", "user_B", "LOGIN", 200),
    ("10:05:00", "user_C", "UPDATE", 500), 
    ("10:05:30", "user_A", "QUERY", 500),
    ("10:06:00", "user_D", "PING", 200),
    ("10:06:30", "user_D", "UPLOAD", 404),
    ("10:07:00", "user_C", "DELETE", 500),
]

CRITICAL_ERRORS = {403, 404, 500}

# Initialize the nested structure: Outer key (user_id) defaults to an empty Counter
user_error_report = defaultdict(Counter)

# Process log entries
for _, user_id, _, status_code in log_entries:
    
    # 1. Filtering: Check if the status code is a critical error
    if status_code in CRITICAL_ERRORS:
        
        # 2. Aggregation: Accessing user_error_report[user_id] automatically creates 
        # a new Counter object if the user is new.
        # We then increment the count for the specific status_code within that user's Counter.
        user_error_report[user_id][status_code] += 1

print("--- Detailed User Error Report ---")
# Convert the defaultdict back to a standard dict for clean printing
final_report = dict(user_error_report)

for user, errors in final_report.items():
    print(f"\nUser ID: {user}")
    print(f"  Total Errors: {sum(errors.values())}")
    # Print the Counter object which holds the detailed counts
    print(f"  Error Breakdown: {dict(errors)}")

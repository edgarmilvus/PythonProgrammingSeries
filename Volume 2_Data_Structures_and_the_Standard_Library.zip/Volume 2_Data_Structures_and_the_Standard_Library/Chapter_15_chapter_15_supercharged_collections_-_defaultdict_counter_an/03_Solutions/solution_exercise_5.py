
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import time
from collections import deque

NUM_OPERATIONS = 100000

# --- 1. Benchmarking Standard List Operations (O(N)) ---
list_test = []
start_time_list = time.perf_counter()

# Insertion at the head (slow)
for i in range(NUM_OPERATIONS):
    list_test.insert(0, i)

# Removal from the head (slow)
for i in range(NUM_OPERATIONS):
    list_test.pop(0)

end_time_list = time.perf_counter()
time_list = end_time_list - start_time_list

print(f"--- List Performance ({NUM_OPERATIONS * 2} operations) ---")
print(f"Total time taken by List (insert(0) and pop(0)): {time_list:.4f} seconds")
print("-" * 50)


# --- 2. Benchmarking Deque Operations (O(1)) ---
deque_test = deque()
start_time_deque = time.perf_counter()

# Insertion at the head (fast)
for i in range(NUM_OPERATIONS):
    deque_test.appendleft(i)

# Removal from the head (fast)
for i in range(NUM_OPERATIONS):
    deque_test.popleft()

end_time_deque = time.perf_counter()
time_deque = end_time_deque - start_time_deque

print(f"--- Deque Performance ({NUM_OPERATIONS * 2} operations) ---")
print(f"Total time taken by Deque (appendleft() and popleft()): {time_deque:.4f} seconds")
print("-" * 50)

# Calculate factor (using illustrative timing results)
if time_deque > 0:
    # Use placeholder values if running in a non-interactive environment for analysis
    # Example results: List ~10.0s, Deque ~0.01s
    # The actual factor will vary based on hardware, but will be massive (1000x+)
    print(f"Deque vs List Factor (Approx.): List is roughly {time_list / time_deque:.0f} times slower.")

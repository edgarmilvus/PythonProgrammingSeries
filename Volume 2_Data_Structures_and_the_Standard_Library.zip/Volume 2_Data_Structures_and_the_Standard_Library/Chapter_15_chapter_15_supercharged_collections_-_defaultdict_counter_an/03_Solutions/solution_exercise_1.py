
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from collections import defaultdict

sales_data = [
    ("Laptop Pro", "Electronics", 1200.00),
    ("Coffee Maker X", "Appliances", 85.50),
    ("Mechanical Keyboard", "Electronics", 150.00),
    ("Blender 5000", "Appliances", 49.99),
    ("Python Textbook", "Books", 65.00),
    ("Monitor 4K", "Electronics", 350.00),
    ("Novel: The Code", "Books", 15.99),
    ("Vacuum Cleaner", "Appliances", 299.99),
]

# 1. Initialize defaultdict with the list factory
categorized_sales = defaultdict(list)

# 2. Iterate and group the data
for product, category, amount in sales_data:
    # Accessing 'category' automatically creates an empty list if it doesn't exist,
    # allowing immediate appending of the sales record.
    record = (product, amount)
    categorized_sales[category].append(record)

# Convert back to a standard dict for final display (optional, but clean)
final_report = dict(categorized_sales)

print("--- Categorized Sales Report ---")
for category, items in final_report.items():
    print(f"\n{category}:")
    for item, price in items:
        print(f"  - {item}: ${price:.2f}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from collections import Counter
import string

document_text = """
The Counter object is a specialized dictionary subclass used for counting 
hashable objects. Data structures are essential. The collections module offers 
default dictionaries, counters, and deques. These specialized collections 
simplify complex data tasks. A counter is perfect for frequency analysis. 
A deque is better than a list for queue operations. Always choose the right 
structure for the data task. The counter is fast.
"""

# 1. Preprocessing: Convert to lowercase
text_lower = document_text.lower()

# 2. Preprocessing: Remove punctuation
# Create a translation table to map all standard punctuation characters to None (removal)
translator = str.maketrans('', '', string.punctuation)
text_no_punct = text_lower.translate(translator)

# 3. Split the cleaned text into a list of words, filtering out empty strings
words = [word for word in text_no_punct.split() if word]

# 4. Use Counter to calculate frequencies
word_counts = Counter(words)

# 5. Find the top 5 most common words
top_five = word_counts.most_common(5)

print("--- Top 5 Word Frequencies ---")
for word, count in top_five:
    print(f"Word: '{word}' | Count: {count}")

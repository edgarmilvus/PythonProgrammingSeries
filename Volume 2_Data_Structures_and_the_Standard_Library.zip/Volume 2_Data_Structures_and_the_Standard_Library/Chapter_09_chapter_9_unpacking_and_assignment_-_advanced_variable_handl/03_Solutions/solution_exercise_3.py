
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Test Case 1: Full Payload
response_1 = ['v1.2', {'user': 'Alice'}, {'permissions': ['read', 'write']}, 200]

# Test Case 2: Empty Payload (Header and Footer only)
response_2 = ['v1.2', 404]

# 1. Apply extended unpacking (same logic works for both)
version_1, *data_body_1, status_code_1 = response_1
version_2, *data_body_2, status_code_2 = response_2

# 4. Verification
print("--- Test Case 1 (Full Payload) ---")
print(f"Version: {version_1}, Status: {status_code_1}")
print(f"Data Body (Type: {type(data_body_1)}): {data_body_1}")

print("\n--- Test Case 2 (Empty Payload) ---")
print(f"Version: {version_2}, Status: {status_code_2}")
# Note: data_body_2 is correctly an empty list
print(f"Data Body (Type: {type(data_body_2)}): {data_body_2}")

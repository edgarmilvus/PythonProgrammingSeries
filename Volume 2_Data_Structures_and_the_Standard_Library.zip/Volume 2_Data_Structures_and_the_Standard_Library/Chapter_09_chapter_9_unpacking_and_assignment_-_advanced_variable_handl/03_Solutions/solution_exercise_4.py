
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Test Case 1: Full Configuration
settings_list_1 = ['Development', '127.0.0.1', 8080, 'logging', 'metrics', 'caching', 300]

# Test Case 2: Minimal Configuration (No features)
settings_list_2 = ['Production', 'remote_db', 5432, 60]

# 1. Single-Line Refactoring using extended unpacking
app_mode_1, db_host_1, db_port_1, *active_features_1, connection_timeout_1 = settings_list_1
app_mode_2, db_host_2, db_port_2, *active_features_2, connection_timeout_2 = settings_list_2

# 4. Verification
print("--- Test Case 1 (Full Features) ---")
print(f"Active Features: {active_features_1}")
print(f"Timeout: {connection_timeout_1}")

print("\n--- Test Case 2 (No Features) ---")
print(f"Active Features: {active_features_2}")
print(f"Timeout: {connection_timeout_2}")

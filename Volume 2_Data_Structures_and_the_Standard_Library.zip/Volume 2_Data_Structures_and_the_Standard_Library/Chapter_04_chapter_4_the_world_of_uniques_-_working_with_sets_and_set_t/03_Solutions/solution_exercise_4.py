
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# 1. Define Keyword Sets
mandatory_keywords = {'SQLAlchemy', 'ORM', 'database', 'migration', 'schema'}
prohibited_stop_words = {
    'the', 'a', 'is', 'maybe', 'not_relevant', 
    'placeholder', 'if', 'and', 'but', 'or', 'example'
}

# 2. Simulate Document Tokens
# Document A: Meets criteria
document_a_tokens = {
    'SQLAlchemy', 'ORM', 'database', 'migration', 'schema', 
    'performance', 'index', 'query', 'code'
} 

# Document B: Fails criteria (missing 'migration', contains 'placeholder')
document_b_tokens = {
    'SQLAlchemy', 'ORM', 'database', 'query', 
    'placeholder', 'example', 'index', 'code'
} 

# 3. Filtering Logic Function
def evaluate_document(token_set, mandatory_keywords, prohibited_stop_words):
    """Evaluates a document token set based on keyword requirements and stop words."""
    
    # Check 1: Mandatory Presence (Set Relationship: Is the document a superset of keywords?)
    mandatory_present = token_set.issuperset(mandatory_keywords)
    
    # Check 2: Prohibited Absence (Set Operation: Intersection must be empty)
    # If the intersection is empty, no prohibited words were found.
    prohibited_found = token_set.intersection(prohibited_stop_words)
    prohibited_absent = len(prohibited_found) == 0
    
    print(f"\n--- Evaluation for Document (Length: {len(token_set)}) ---")
    print(f"Mandatory Check Status: {mandatory_present}")
    if not mandatory_present:
        print(f"  Missing: {mandatory_keywords - token_set}")
    
    print(f"Prohibited Check Status: {prohibited_absent}")
    if not prohibited_absent:
        print(f"  Found Prohibited: {prohibited_found}")
        
    return mandatory_present and prohibited_absent

# 4. Execution and Output
result_a = evaluate_document(document_a_tokens, mandatory_keywords, prohibited_stop_words)
print(f"Document A is valid: {result_a}")

result_b = evaluate_document(document_b_tokens, mandatory_keywords, prohibited_stop_words)
print(f"Document B is valid: {result_b}")

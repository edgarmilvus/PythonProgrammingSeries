
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# 1. Define Configurations
# Baseline must be immutable to prevent accidental modification
baseline_packages = frozenset({
    'nginx', 'python3', 'git', 'openssh', 'vim', 
    'docker', 'curl', 'tmux', 'jq', 'rsync'
})

# Current state is a standard mutable set
current_server_packages = {
    'nginx', 'python3', 'git', 'vim', 'docker', 
    'curl', 'tmux', 'jq', # Essentials present
    'unauthorized_db', 'temp_script', 'old_library', # Unauthorized additions
    # Missing from baseline: 'openssh', 'rsync'
}

# 2. Identify Missing Essentials (Difference)
# Baseline MINUS Current = what should be there but isn't
missing_packages = baseline_packages - current_server_packages
print(f"Missing Essential Packages: {missing_packages}")

# 3. Identify Unauthorized Additions (Difference)
# Current MINUS Baseline = what is there but shouldn't be
unauthorized_packages = current_server_packages - baseline_packages
print(f"Unauthorized Additions (Cruft): {unauthorized_packages}")

# 4. Calculate Total Drift (Symmetric Difference)
# All items that are unique to either set
total_drift = baseline_packages ^ current_server_packages
print(f"Total Configuration Drift (Missing + Unauthorized): {total_drift}")

# 5. Verification of Immutability
try:
    # Attempt to modify the frozenset
    # This line is expected to raise an AttributeError
    baseline_packages.add('new_tool')
    print("Modification successful (ERROR: Should not happen)")
except AttributeError as e:
    print(f"\nVerification Check: Attempt failed as expected.")
    print(f"Error raised: {e}")

# Minimal code correction to security_config allowing master_config_set creation:
# security_config = ('JWT_SECRET', 'super_secret_key') 

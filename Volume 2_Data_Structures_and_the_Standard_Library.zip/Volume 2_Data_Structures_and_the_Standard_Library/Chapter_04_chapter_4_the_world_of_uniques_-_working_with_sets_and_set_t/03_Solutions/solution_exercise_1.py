
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# 1. Data Initialization
raw_emails = [
    "UserA@Example.com", "userb@service.net", "UserA@example.com",
    "admin@service.com", "Admin@service.com", "test@botmail.ru",
    "john.doe@corp.org", "JOHN.DOE@corp.org", "spam1@junkserver.org",
    "valid1@gmail.com", "valid2@gmail.com", "valid3@gmail.com",
    "test@botmail.ru", "support@example.com", "support@example.com",
    "user_x@spamfarm.net", "user_y@spamfarm.net", "clean@outlook.com",
    "clean@outlook.com", "final_check@corp.org"
]

spam_domains = {'botmail.ru', 'spamfarm.net', 'junkserver.org', 'testspam.com'}

# 2. Normalization and Deduplication
def clean_and_deduplicate(email_list):
    # Using a set inherently handles deduplication
    unique_subscribers = set()
    for email in email_list:
        # Normalization: convert to lowercase before adding
        unique_subscribers.add(email.lower())
    return unique_subscribers

unique_subscribers = clean_and_deduplicate(raw_emails)

# 3. Blacklist Filtering (Set Difference Logic)
valid_subscribers = set()
blacklisted_emails = set()

# We iterate through the unique set and apply the filtering logic
for email in unique_subscribers:
    # Extract the domain (the part after the last '@')
    domain = email.split('@')[-1]
    
    # Check membership in the spam_domains set (O(1) average time)
    if domain not in spam_domains:
        valid_subscribers.add(email)
    else:
        blacklisted_emails.add(email)

# 4. Reporting
print(f"Total raw entries received: {len(raw_emails)}")
print(f"Total unique entries after normalization: {len(unique_subscribers)}")
print(f"Total entries filtered (blacklisted): {len(blacklisted_emails)}")
print(f"Final number of valid subscribers: {len(valid_subscribers)}")

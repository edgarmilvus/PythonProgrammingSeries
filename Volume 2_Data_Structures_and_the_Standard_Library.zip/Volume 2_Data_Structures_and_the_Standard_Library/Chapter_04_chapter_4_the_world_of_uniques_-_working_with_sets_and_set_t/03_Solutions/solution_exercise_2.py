
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# 1. Define Service Requirements
auth_service_vars = {'DB_HOST', 'DB_PORT', 'JWT_SECRET', 'LOG_LEVEL', 'REDIS_URL'}
ingestion_pipeline_vars = {'DB_HOST', 'S3_BUCKET_NAME', 'KAFKA_TOPIC', 'LOG_LEVEL'}
reporting_dashboard_vars = {'DB_HOST', 'API_KEY', 'REPORT_PERIOD', 'REDIS_URL'}

# 2. System-Wide Requirements (Union)
# Calculates the set of all unique variables needed by any service.
total_system_vars = auth_service_vars.union(ingestion_pipeline_vars, reporting_dashboard_vars)

# 3. Critical Shared Variables (Intersection)
# Calculates the variables mandatory for ALL three services.
critical_shared_vars = auth_service_vars.intersection(ingestion_pipeline_vars, reporting_dashboard_vars)

# 4. Service-Specific Variables (Difference)
# Variables needed by Auth Service, excluding any variable needed by Ingestion OR Reporting.
other_vars = ingestion_pipeline_vars.union(reporting_dashboard_vars)
auth_only_vars = auth_service_vars - other_vars

# Output Results
print(f"--- Dependency Resolution Report ---")
print(f"Total unique variables required (Union): {total_system_vars}")
print(f"Number of total variables: {len(total_system_vars)}")
print("-" * 30)
print(f"Critical shared variables (Intersection): {critical_shared_vars}")
print(f"Number of critical shared variables: {len(critical_shared_vars)}")
print("-" * 30)
print(f"Variables required ONLY by Auth Service (Difference): {auth_only_vars}")

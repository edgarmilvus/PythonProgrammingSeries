
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
import sys

# 1. Argument Parsing
if len(sys.argv) < 2:
    print(f"Usage: python {sys.argv[0]} <archive_path> [--dry-run]")
    sys.exit(1)

# Determine the archive path (always the first positional argument)
archive_path = sys.argv[1]

# Check for the dry-run flag anywhere in the arguments
is_dry_run = '--dry-run' in sys.argv

# 2. Path Validation
if not os.path.exists(archive_path) or not os.path.isdir(archive_path):
    print(f"Error: Archive path '{archive_path}' does not exist or is not a directory.")
    sys.exit(1)

mode_label = "DRY RUN" if is_dry_run else "LIVE EXECUTION"
print(f"--- Starting Log Cleanup in {mode_label} Mode ---")

# 3. Traversal
for root, dirs, files in os.walk(archive_path):
    for filename in files:
        # 4. File Identification (Construct absolute path)
        file_path = os.path.join(root, filename)
        
        # In a real scenario, we would check file modification time here.
        # For this exercise, we process all files found.
        
        # 5. Conditional Execution (Dry Run vs. Deletion)
        if is_dry_run:
            print(f"[DRY RUN] Would delete: {file_path}")
        else:
            try:
                # Actual deletion
                os.remove(file_path)
                print(f"[DELETING] Removing: {file_path}")
            except OSError as e:
                print(f"[ERROR] Could not delete {file_path}: {e}")

print("--- Cleanup Process Complete ---")
sys.exit(0)

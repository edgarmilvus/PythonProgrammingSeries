
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
import sys

# 1. Retrieve mandatory variable using os.getenv()
LOG_FILENAME = os.getenv('LOG_FILENAME')

# 2. Mandatory Variable Check
if not LOG_FILENAME:
    print("Error: LOG_FILENAME environment variable is mandatory and not set.")
    sys.exit(1)

# 3. Retrieve optional variable and handle default
DATA_ROOT = os.getenv('DATA_ROOT')

if DATA_ROOT:
    base_path = DATA_ROOT
    print(f"Using DATA_ROOT from environment: {base_path}")
else:
    # Default to current working directory
    base_path = os.getcwd()
    print(f"DATA_ROOT not set. Defaulting to Current Working Directory: {base_path}")

# 4. Path Construction using os.path.join()
# This function automatically handles the appropriate path separators (/, \)
final_log_path = os.path.join(base_path, LOG_FILENAME)

# 5. Output
print("\n--- Configuration Summary ---")
print(f"Constructed Log Path: {final_log_path}")

sys.exit(0)

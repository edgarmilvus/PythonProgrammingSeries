
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import os
import sys

def check_path_status(path):
    """Checks and reports the status of a given file system path."""
    
    # 4. Existence Check
    if not os.path.exists(path):
        return "[STATUS] Path does not exist."

    # 5. Type Check
    if os.path.isfile(path):
        return "[STATUS] Path exists and is a file."
    elif os.path.isdir(path):
        return "[STATUS] Path exists and is a directory."
    elif os.path.islink(path):
        # Optional: Checking for symbolic links
        return "[STATUS] Path exists and is a symbolic link."
    else:
        # Handles pipes, sockets, device files, etc.
        return "[STATUS] Path exists but is an unknown type (e.g., device or socket)."

# 1. Loop Structure
print("--- Path Status Checker ---")
print("Type 'quit' or 'exit' to stop.")

while True:
    try:
        # 2. User Input
        user_input = input("Enter path (or 'quit'): ")
    except EOFError:
        # Handle Ctrl+D/Ctrl+Z
        break 

    clean_input = user_input.strip().lower()

    # 3. Exit Condition
    if clean_input in ('quit', 'exit'):
        print("Exiting tool.")
        break

    if not clean_input:
        continue # Ignore empty input

    # 6. Reporting
    status = check_path_status(user_input)
    print(status)
    print("-" * 20)

sys.exit(0)

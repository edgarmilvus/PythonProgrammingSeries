
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os
import sys

# 1. Input Handling and Validation
if len(sys.argv) != 2:
    print(f"Usage: python {sys.argv[0]} <starting_directory_path>")
    sys.exit(1)

start_path = sys.argv[1]

# 2. Path Validation
if not os.path.isdir(start_path):
    print(f"Error: '{start_path}' is not a valid directory or does not exist.")
    sys.exit(1)

print(f"Searching for .txt files in: {start_path}")
print("-" * 30)

# 3. Traversal using os.walk()
for root, dirs, files in os.walk(start_path):
    for filename in files:
        # 4. Filtering by extension
        if filename.endswith('.txt'):
            
            # 5. Construct Absolute Path using os.path.join()
            # os.path.join handles cross-platform separator issues
            full_path = os.path.join(root, filename)
            
            # 6. Ensure the path is absolute for unambiguous reporting
            absolute_path = os.path.abspath(full_path)
            
            # 7. Output Format
            print(absolute_path)

sys.exit(0)

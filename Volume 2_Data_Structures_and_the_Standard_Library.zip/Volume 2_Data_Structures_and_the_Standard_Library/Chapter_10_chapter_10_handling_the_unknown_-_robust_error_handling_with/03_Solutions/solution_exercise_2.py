
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# 1. Custom Exception Definition
class InvalidUsernameError(ValueError):
    """Custom exception raised when a username violates security or formatting rules."""
    pass

def validate_username(username):
    """
    Validates a username against length and content rules. 
    Raises InvalidUsernameError if validation fails.
    """
    # Rule A: Length check
    if not 6 <= len(username) <= 20:
        # Use raise keyword to halt execution with the custom exception
        raise InvalidUsernameError(
            "Username length violation: Must be between 6 and 20 characters."
        )
        
    # Rule B: Content check (case-insensitive 'admin')
    if "admin" in username.lower():
        # Use raise keyword to halt execution with the custom exception
        raise InvalidUsernameError(
            "Username content violation: Cannot contain the reserved word 'admin'."
        )
        
    print(f"Validation successful for: {username}")
    return True

# --- Handling and Test Cases ---
test_cases = [
    'short',                        # Too short (Rule A)
    'system_administrator_user_1',  # Too long (Rule A)
    'user_admIn_test',              # Contains 'admin' (Rule B)
    'valid_user_2024'               # Valid
]

for name in test_cases:
    print(f"\nAttempting validation for: '{name}'")
    try:
        validate_username(name)
    
    # 4. Handling the Custom Exception specifically
    except InvalidUsernameError as e:
        # The variable 'e' holds the exception instance and its message
        print(f"--> Caught Validation Error: {e}")
        print("Validation failed. Please try a different name.")
    
    except Exception as e:
        # Catch any other unexpected error
        print(f"An unknown error occurred: {e}")

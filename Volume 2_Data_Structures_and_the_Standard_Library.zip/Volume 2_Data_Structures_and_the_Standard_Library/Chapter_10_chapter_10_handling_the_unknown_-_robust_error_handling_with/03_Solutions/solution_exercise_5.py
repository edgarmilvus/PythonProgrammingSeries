
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

def execute_dynamic_operation(user_input):
    """
    Executes an operation that dynamically triggers specific exceptions 
    based on user input and handles each one uniquely.
    """
    print(f"\nAttempting operation with input: '{user_input}'")
    
    try:
        # 2. Triggering Logic
        if user_input == "TYPE_FAIL":
            print("Triggering TypeError...")
            # Operation guaranteed to fail: string + integer
            result = "hello" + 5 
            
        elif user_input == "INDEX_FAIL":
            print("Triggering IndexError...")
            # Operation guaranteed to fail: accessing index 5 in a 2-element list
            data = [10, 20]
            result = data[5] 
            
        elif user_input == "VALUE_FAIL":
            print("Triggering ValueError...")
            # Operation guaranteed to fail: trying to convert non-numeric string to int
            result = int("not_a_number") 
            
        else:
            print("Operation successful (No trigger detected).")
            
    # 3. Specific Exception Handling (most specific first)
    except TypeError:
        print("Error Type Identified: Incompatible data types used in calculation.")
        
    except IndexError:
        print("Error Type Identified: Accessing element outside valid range of the data structure.")
        
    except ValueError:
        print("Error Type Identified: Data format conversion failed. Check input string.")
        
    # 4. General Fallback
    except Exception as e:
        print(f"An unexpected system error occurred: {e} - Contact support.")
        
    else:
        # If the try block completed without exception
        print("Operation completed gracefully.")


# 5. Interactive Test Loop
print("--- Dynamic Error Handler Test ---")
print("Enter one of the following to test specific handlers:")
print("TYPE_FAIL, INDEX_FAIL, VALUE_FAIL, or EXIT to quit.")

while True:
    try:
        user_input = input("Enter command: ").strip().upper()
    except EOFError:
        user_input = "EXIT"

    if user_input == "EXIT":
        print("Exiting interactive test.")
        break
    
    execute_dynamic_operation(user_input)

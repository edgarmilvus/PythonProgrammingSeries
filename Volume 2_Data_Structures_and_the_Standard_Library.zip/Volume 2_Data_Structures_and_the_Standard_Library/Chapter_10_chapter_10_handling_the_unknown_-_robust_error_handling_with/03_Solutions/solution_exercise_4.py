
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

def run_pipeline(config_value):
    """
    Runs a conceptual data pipeline demonstrating multi-exception handling 
    and separation of error categories.
    """
    result = None
    
    try:
        # Stage 1: Reading configuration
        print("Stage 1: Configuration loaded.")
        
        # Stage 2: Calculation (Potential ZeroDivisionError)
        result = 100 / config_value
        print(f"Stage 2: Calculation successful. Result: {result}")
        
        # Stage 3: Writing report (Potential TypeError or OSError)
        
        # Simulate a TypeError if the result is used improperly
        if config_value == 5:
            # This line forces a TypeError (float + string)
            report = result + " report" 
            print(f"Stage 3: Report generated.")
        
        # Simulate an OSError (e.g., disk full, permission denied)
        elif config_value == -1:
            raise OSError("Simulated system failure during file write.")
        
        else:
            print("Stage 3: Report generated successfully.")
            
    # 5. Multi-Exception Catching (Data Errors)
    except (ZeroDivisionError, TypeError) as e:
        error_type = type(e).__name__
        print(f"\n[HANDLER 1 - Data Error] Caught {error_type}: {e}")
        print("Pipeline interrupted due to critical data failure.")
        
    # 6. Catching OS Errors (System Errors)
    except OSError as e:
        print(f"\n[HANDLER 2 - System Error] Caught OSError: {e}")
        print("CRITICAL SYSTEM FAILURE: Cannot write report. Check disk access.")
        
    finally:
        # 7. Guaranteed Logging
        print("\nPipeline execution complete. Resources released.")

# --- Test Cases ---

print("--- Test Case 1: Trigger ZeroDivisionError (Data Error) ---")
run_pipeline(0)

print("\n--- Test Case 2: Trigger TypeError (Data Error) ---")
run_pipeline(5) # Triggers the simulated TypeError in Stage 3

print("\n--- Test Case 3: Trigger OSError (System Error) ---")
run_pipeline(-1) # Triggers the simulated OSError in Stage 3

print("\n--- Test Case 4: Successful Run ---")
run_pipeline(25)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os

def load_connection_setting(filepath):
    """
    Attempts to load a connection setting (integer) from a file, handling 
    FileNotFoundError and ValueError specifically, returning 10 as default on failure.
    """
    default_setting = 10
    
    try:
        # 1. Attempt to open and read the file
        with open(filepath, 'r') as f:
            raw_data = f.read().strip()
        
        # 2. Attempt to convert the data to an integer
        setting = int(raw_data)
        
    except FileNotFoundError:
        print(f"CRITICAL: Configuration file not found at {filepath}. Using default value.")
        return default_setting
        
    except ValueError:
        print("WARNING: Invalid data format in configuration. Using default value.")
        return default_setting
        
    except Exception as e:
        # Catch any other unexpected I/O or system errors
        print(f"UNEXPECTED ERROR: {e}. Using default value.")
        return default_setting
        
    else:
        # Executes only if the try block completed without raising an exception
        print("SUCCESS: Connection setting loaded successfully.")
        return setting

# --- Test Setup (Creating temporary files for testing) ---
VALID_FILE = 'temp_valid_config.txt'
INVALID_DATA_FILE = 'temp_invalid_config.txt'

# Scenario 2: Invalid data
with open(INVALID_DATA_FILE, 'w') as f:
    f.write("A_LOT")

# Scenario 3: Valid data
with open(VALID_FILE, 'w') as f:
    f.write("50")

# --- Test Cases ---
print("\n--- Test Case 1: Missing File ---")
result_1 = load_connection_setting('config/missing.txt')
print(f"Result 1: {result_1}\n")

print("--- Test Case 2: Invalid Data Format ---")
result_2 = load_connection_setting(INVALID_DATA_FILE)
print(f"Result 2: {result_2}\n")

print("--- Test Case 3: Successful Load ---")
result_3 = load_connection_setting(VALID_FILE)
print(f"Result 3: {result_3}\n")

# Cleanup
os.remove(VALID_FILE)
os.remove(INVALID_DATA_FILE)

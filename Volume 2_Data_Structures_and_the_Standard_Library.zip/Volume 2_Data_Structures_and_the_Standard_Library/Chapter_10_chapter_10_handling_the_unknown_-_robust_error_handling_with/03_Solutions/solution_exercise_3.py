
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os

def process_and_log_data(data_list, filename):
    """
    Performs a calculation and logs the result, guaranteeing file closure 
    using the 'finally' block.
    """
    f = None  # 2. Initialization: File handle initialized to None
    
    # 1. Path Construction: Use os.path.join for cross-platform compatibility
    filepath = os.path.join('logs', filename)
    
    # Ensure the logs directory exists for testing
    os.makedirs('logs', exist_ok=True)
    
    print(f"Attempting operation and logging to: {filepath}")
    
    try:
        # 3. Open the file for writing
        f = open(filepath, 'w')
        
        # 3. Calculation Logic
        x = data_list[0]
        result = 100 / x
        
        # 5. Successful Execution: Write result
        f.write(f"SUCCESS: Calculation result is {result}")
        print("Calculation successful.")
        
    except ZeroDivisionError:
        # 4. Error Simulation and Catching
        print("ZeroDivisionError caught.")
        if f is not None:
            f.write("ERROR: Zero Division Attempted. Calculation failed.")
            
    except IndexError:
        # Handle case where data_list is empty
        print("IndexError caught. Data list is empty.")
        if f is not None:
            f.write("ERROR: Data list was empty.")
            
    finally:
        # 6. Guaranteed Cleanup: Executes regardless of success or failure
        if f is not None:
            f.close()
            print("Resource cleanup complete. File handle closed.")
        else:
            print("Resource cleanup complete. File handle was not opened.")

# --- Test Cases ---

# Test Case 1: Causes ZeroDivisionError
print("\n--- Test Case 1: Failure Scenario (Zero Division) ---")
process_and_log_data([0, 5], 'log_failure.txt')

# Test Case 2: Successful Calculation
print("\n--- Test Case 2: Success Scenario ---")
process_and_log_data([20, 5], 'log_success.txt')

# Cleanup the created log files and directory (optional, but good practice)
os.remove(os.path.join('logs', 'log_failure.txt'))
os.remove(os.path.join('logs', 'log_success.txt'))
os.rmdir('logs')

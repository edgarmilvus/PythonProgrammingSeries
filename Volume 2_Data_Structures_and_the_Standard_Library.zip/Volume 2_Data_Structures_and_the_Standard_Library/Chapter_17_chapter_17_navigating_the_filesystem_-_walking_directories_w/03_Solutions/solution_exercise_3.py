
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os

START_DIR = 'Project_Archive'
EXCLUSION_LIST = ['Temp_Builds', '.git']

def traverse_and_prune(start_dir):
    """
    Traverses the archive while actively pruning specified directories for efficiency.
    """
    print(f"Files found (excluding contents of {EXCLUSION_LIST}):")
    
    for root, dirs, files in os.walk(start_dir):
        
        # 1. Pruning Logic: In-place modification of the 'dirs' list.
        # This list comprehension modifies the original 'dirs' list (passed by reference) 
        # to only contain directories that are NOT in the exclusion list.
        # os.walk will then skip descending into the removed directories.
        dirs[:] = [d for d in dirs if d not in EXCLUSION_LIST]
        
        # 2. Verification: List all successfully traversed files
        for filename in files:
            full_path = os.path.join(root, filename)
            print(f"  {full_path}")

# Efficiency Rationale:
# Modifying the 'dirs' list is superior because it prevents os.walk from ever making 
# system calls (CPU time and I/O) to list the contents of the excluded directories. 
# This is significantly faster than allowing traversal and then filtering the results afterward.

# traverse_and_prune(START_DIR)

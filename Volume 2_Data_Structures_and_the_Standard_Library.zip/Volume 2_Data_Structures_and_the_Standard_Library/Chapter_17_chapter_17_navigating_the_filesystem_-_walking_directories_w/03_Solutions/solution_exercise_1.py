
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os

START_DIR = 'Project_Archive'

def find_specific_files(start_dir):
    """
    Traverses the directory tree to find files matching specific extensions.
    """
    found_paths = []
    target_extensions = ('.py', '.md')
    
    # Ensure traversal starts from a known, absolute path for clear output
    start_path = os.path.abspath(start_dir)
    
    # os.walk yields (root directory path, list of subdirectories, list of files)
    for root, dirs, files in os.walk(start_path):
        for filename in files:
            # Check if the filename ends with one of the target extensions (case-insensitive check)
            if filename.lower().endswith(target_extensions):
                # Construct the complete, actionable path
                full_path = os.path.join(root, filename)
                print(full_path)
                found_paths.append(full_path) # Store for verification/return
    
    return found_paths

# Example execution (assuming Project_Archive exists relative to the script)
# find_specific_files(START_DIR) 

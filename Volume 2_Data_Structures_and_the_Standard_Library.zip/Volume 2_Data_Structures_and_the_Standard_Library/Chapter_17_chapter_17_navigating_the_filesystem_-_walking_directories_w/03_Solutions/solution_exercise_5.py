
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import os

START_DIR = 'Project_Archive'
INDENT_CHAR = '|--- '

def create_directory_map(start_dir):
    """
    Generates an indented map of the directory structure.
    """
    # Normalize the starting path to handle absolute vs. relative inputs consistently
    start_path_abs = os.path.abspath(start_dir)
    
    print(f"Directory Map for: {os.path.basename(start_path_abs)}/")
    
    # 1. Traversal Focus: We only need the 'root' from the yielded tuple
    for root, dirs, files in os.walk(start_dir):
        
        # Calculate path relative to the starting directory
        relative_path = os.path.relpath(root, start_dir)
        
        if relative_path == '.':
            # This is the starting directory, already printed or handled
            continue
        
        # 2. Depth Calculation: Split the relative path by the OS separator. 
        # The number of resulting segments determines the depth.
        # Example: 'Source_Code/Temp_Builds' splits into 2 segments, depth 2.
        path_segments = relative_path.split(os.path.sep)
        depth = len(path_segments)
        
        # Get the current directory's base name for clean printing
        dir_name = os.path.basename(root)
        
        # 3. Indentation Logic: Apply indentation based on depth
        indentation_prefix = INDENT_CHAR * (depth - 1) # Subtract 1 because depth 1 is the first level of subfolders
        
        # 4. Output Format: Print the indented directory name
        print(f"{indentation_prefix}{dir_name}/")

# create_directory_map(START_DIR)

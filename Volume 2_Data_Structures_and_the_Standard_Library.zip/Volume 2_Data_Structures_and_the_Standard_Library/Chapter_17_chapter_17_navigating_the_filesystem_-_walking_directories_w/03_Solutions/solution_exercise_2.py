
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os

START_DIR = 'Project_Archive'
# Define the standard conversion factor for Megabytes (1024 * 1024 bytes)
MB_CONVERSION = 1024 * 1024 

def calculate_archive_size(start_dir):
    """
    Calculates the total size of all files in the directory tree in MB.
    """
    total_bytes = 0
    
    for root, dirs, files in os.walk(start_dir):
        for filename in files:
            full_path = os.path.join(root, filename)
            
            try:
                # Retrieve the size of the file in bytes
                size = os.path.getsize(full_path)
                total_bytes += size
            except (FileNotFoundError, PermissionError):
                # Handle cases where the file is deleted or inaccessible
                # This ensures the script doesn't crash on system files or volatile directories.
                continue
                
    # Convert the total byte count to megabytes and format the output
    total_megabytes = total_bytes / MB_CONVERSION
    
    print(f"Total size of '{start_dir}': {total_megabytes:.2f} MB")
    return total_megabytes

# Example execution (will yield 0.00 MB if files don't exist, but logic is sound)
# calculate_archive_size(START_DIR)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import random

def log_streamer(num_entries):
    """Simulates yielding log entries one by one."""
    levels = ["INFO", "DEBUG", "WARNING", "ERROR", "CRITICAL"]
    users = ["guest", "admin_01", "system", "user_100"]
    for i in range(num_entries):
        level = random.choice(levels)
        user = random.choice(users)
        yield (i, user, level, f"Log message {i}")

# 1. Input Stream (Simulating 1 million logs)
raw_stream = log_streamer(1_000_000)

# 2. Filtering Generator: Only CRITICAL logs from admin users
# Filters the stream lazily (index 2 is level, index 1 is user)
critical_admin_logs = (
    log_entry
    for log_entry in raw_stream
    if log_entry[2] == "CRITICAL" and log_entry[1].startswith("admin")
)

# 3. Transformation Generator: Formats the filtered output
# Iterates over the filtered stream, extracting timestamp (0) and message (3).
transformed_output = (
    f"[{ts}] -> {msg}"
    for ts, _, _, msg in critical_admin_logs
)

# 4. Consumption (Only the first 5 are processed)
print("--- First 5 Processed Logs ---")
for i, record in enumerate(transformed_output):
    if i >= 5:
        break
    print(record)
print("------------------------------")

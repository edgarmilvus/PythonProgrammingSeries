
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

def read_sensor_data(count):
    """Simulates reading raw Celsius temperatures (returns a list)."""
    return [celsius / 10.0 for celsius in range(count)]

# Set the massive data size
DATA_SIZE = 10_000_000
raw_data_list = read_sensor_data(DATA_SIZE)

# 1. Fahrenheit Conversion Generator
# Takes Celsius (C) from the list and yields Fahrenheit (F = C * 9/5 + 32)
fahrenheit_data = (
    (c * 9/5) + 32
    for c in raw_data_list
)

# 2. Normalization Generator
# Takes Fahrenheit (F) from the previous generator and subtracts the baseline (32.0)
normalized_data = (
    f - 32.0
    for f in fahrenheit_data
)

# 3. Aggregation and Output
# sum() consumes the generator lazily, calculating the total without storing 10M results.
final_sum = sum(normalized_data)
print(f"Total Sum of Normalized Data: {final_sum}")

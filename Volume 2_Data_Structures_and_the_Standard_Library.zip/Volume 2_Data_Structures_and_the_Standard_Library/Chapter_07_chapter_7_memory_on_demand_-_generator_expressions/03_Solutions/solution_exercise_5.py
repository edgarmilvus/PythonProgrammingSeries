
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# 1. Input Data provided above
config_data = [
    ("network_timeout", 500),
    ("cpu_cores", 8),
    ("network_buffer", 2048),
    ("disk_size", 1024),
    ("network_retries", 3),
    ("cache_limit", 4096)
] * 1000  # Simulate 6000 entries

# 2. Filtering Generator
# Yields only (key, value) tuples that start with "network" AND value > 100.
filtered_settings = (
    (key, value)
    for key, value in config_data
    if key.startswith("network") and value > 100
)

# 3. Dictionary Construction
# dict() consumes the generator lazily, building the map from the yielded (key, value) tuples.
network_config_map = dict(filtered_settings)

# 4. Verification
print(network_config_map)
# Conceptual Explanation: Even when iterating over an existing list, the generator ensures that
# complex filtering or transformation logic (if present) is only executed for the items
# that meet the final criteria, and the intermediate results (the filtered tuples) are not
# stored in a temporary list before being passed to dict().

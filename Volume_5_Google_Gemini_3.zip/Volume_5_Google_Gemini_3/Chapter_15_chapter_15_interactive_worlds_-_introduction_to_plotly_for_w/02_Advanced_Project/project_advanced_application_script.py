
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, timedelta

# --- 1. Data Generation: Creating Synthetic Financial Data ---
def generate_synthetic_data(num_days=365):
    """Generates a year's worth of synthetic stock data for demonstration."""
    np.random.seed(42)
    start_date = datetime(2023, 1, 1)
    dates = [start_date + timedelta(days=i) for i in range(num_days)]

    # Simulate price movement (random walk with slight drift)
    initial_price = 100
    price_changes = np.random.normal(0.001, 0.01, num_days)
    prices = initial_price * np.exp(np.cumsum(price_changes))

    # Simulate trading volume, correlating it slightly with price volatility
    volume_base = 500000
    volumes = volume_base + (np.abs(price_changes) * 10000000) + np.random.normal(0, 50000, num_days)
    volumes = np.round(volumes)

    # Assign a dummy sector for categorical visualization in the volume chart
    sectors = np.random.choice(['Tech', 'Finance', 'Energy'], num_days)

    data = pd.DataFrame({
        'Date': dates,
        'Price': prices,
        'Volume': volumes,
        'Sector': sectors
    })
    return data

# Load the generated data
df_stock = generate_synthetic_data()

# --- 2. Advanced Plotly Figure Construction using Subplots ---
def create_interactive_financial_dashboard(df: pd.DataFrame):
    """
    Creates a complex, interactive Plotly figure combining a time-series
    chart (Price) and a distribution chart (Volume) using subplots.
    """
    
    # Initialize the figure with subplots: 2 rows, 1 column
    # shared_xaxes=True is critical for linking the zoom/pan functionality
    fig = make_subplots(
        rows=2, cols=1, 
        row_heights=[0.7, 0.3],       # Allocate 70% height to the main price chart
        shared_xaxes=True,            # Ensures zooming in one chart affects the other
        vertical_spacing=0.05,        # Minimal space between the linked charts
        subplot_titles=("Daily Closing Price Trend", "Daily Trading Volume Distribution")
    )

    # --- 2a. Top Plot: Time Series (Price) using Graph Objects ---
    
    # Use go.Scatter for precise control over line appearance and hover text
    price_trace = go.Scatter(
        x=df['Date'], 
        y=df['Price'], 
        mode='lines', 
        name='Closing Price',
        line=dict(color='#007BFF', width=2),
        hovertemplate='Date: %{x|%Y-%m-%d}<br>Price: $%{y:.2f}<extra></extra>'
    )
    
    # Add the price trace to the first row
    fig.add_trace(price_trace, row=1, col=1)

    # Add Range Slider and Range Selector functionality (standard dashboard features)
    fig.update_layout(
        xaxis1=dict(
            rangeselector=dict(
                buttons=list([
                    dict(count=1, label="1m", step="month", stepmode="backward"),
                    dict(count=6, label="6m", step="month", stepmode="backward"),
                    dict(count=1, label="YTD", step="year", stepmode="todate"),
                    dict(count=1, label="1y", step="year", stepmode="backward"),
                    dict(step="all")
                ])
            ),
            rangeslider=dict(visible=True, thickness=0.08),
            type="date"
        )
    )

    # --- 2b. Bottom Plot: Distribution (Volume) integrating Plotly Express ---
    
    # Use Plotly Express to quickly generate a clustered bar chart (histogram)
    # This chart visualizes volume and uses 'Sector' for color separation
    volume_hist_fig = px.bar(
        df, 
        x='Date', 
        y='Volume', 
        color='Sector', 
        color_discrete_map={'Tech': '#28A745', 'Finance': '#FFC107', 'Energy': '#DC3545'},
        title='Daily Volume'
    )
    
    # Extract the traces (data) generated by PX and add them to the GO subplot figure
    # This seamlessly merges the PX output into the GO layout structure
    for trace in volume_hist_fig.data:
        fig.add_trace(trace, row=2, col=1)

    # --- 3. Final Layout Customization and Interaction Settings ---
    
    fig.update_layout(
        title_text="Financial Instrument Performance Analysis (Dual View Dashboard Component)",
        height=800,
        # Crucial setting: Synchronize hover tooltips across all linked subplots
        hovermode="x unified", 
        template="plotly_white",
        margin=dict(t=100, b=50, l=50, r=50),
        legend_title_text="Sector Contribution"
    )
    
    # Update axis labels and hide redundant elements
    fig.update_xaxes(title_text="Date", row=2, col=1)
    fig.update_yaxes(title_text="Price ($)", row=1, col=1)
    fig.update_yaxes(title_text="Volume", row=2, col=1)
    
    # Hide the x-axis tick labels on the top chart since the axes are shared
    fig.update_xaxes(showticklabels=False, row=1, col=1) 

    # Set an initial zoomed range for better first-load visualization
    three_months_ago = df['Date'].max() - timedelta(days=90)
    fig.update_xaxes(range=[three_months_ago, df['Date'].max()], row=1, col=1)

    return fig

# --- 4. Execution ---
if __name__ == '__main__':
    # Generate and display the interactive figure
    dashboard_figure = create_interactive_financial_dashboard(df_stock)
    
    # In a production Dash environment, this figure object is returned to a callback.
    dashboard_figure.show()

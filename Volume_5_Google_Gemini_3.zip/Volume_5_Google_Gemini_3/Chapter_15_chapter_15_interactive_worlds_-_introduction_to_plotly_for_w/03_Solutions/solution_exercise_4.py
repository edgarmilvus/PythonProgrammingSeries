
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# 2. Custom Data Array (Must be a NumPy array of shape (N, 2))
custom_data_array = df_sales[['Transaction_ID', 'Profit_Margin']].values

# 1. Base Visualization using go.Scatter
trace3 = go.Scatter(
    x=df_sales['Sales'],
    y=df_sales['Profit'],
    mode='markers',
    marker=dict(
        size=df_sales['Sales'] / 50, # Scale size for visual distinction
        sizemode='area',
        color=df_sales['Category'],
        colorscale='Viridis',
        showscale=False,
        line=dict(width=1, color='White')
    ),
    name='Sales Transactions',
    customdata=custom_data_array, # Assign the custom data array
    
    # 3. Advanced Hover Template
    hovertemplate=(
        '<b>Sales:</b> $%{x:,.2f}<br>' +
        '<b>Profit:</b> $%{y:,.2f}<br>' +
        '<hr>' +
        '<b>TXN ID:</b> %{customdata[0]}<br>' +
        '<b>Margin:</b> %{customdata[1]:.1%}<br>' + # Access index 1 and format as percentage
        '<extra></extra>' # Hides the default trace name label
    )
)

fig3 = go.Figure(data=[trace3])
fig3.update_layout(
    title="Bubble Chart with Embedded Custom Data (Hover over points)",
    xaxis_title="Sales",
    yaxis_title="Profit"
)

# fig3.show()

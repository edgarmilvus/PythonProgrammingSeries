
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# 1. Base Figure Generation (3D Scatter)
fig4 = px.scatter_3d(
    df_sales,
    x='Sales',
    y='Profit',
    z='Profit_Margin',
    color='Category', # Initial coloring
    title="3D Sales Distribution with Dynamic Coloring"
)

# Prepare the data arrays for restyle
color_data = {
    'Category': df_sales['Category'].tolist(),
    'Profit': df_sales['Profit'].tolist(),
    'Region': df_sales['Region'].tolist()
}

# 2. & 3. Button Structure and restyle Implementation
buttons = []

for name, data_key in zip(
    ['Category (Discrete)', 'Profit (Continuous)', 'Region (Discrete)'],
    ['Category', 'Profit', 'Region']
):
    
    color_array = color_data[data_key]
    
    # Base restyle arguments
    restyle_args = {'marker.color': [color_array]}
    
    # Adjust marker properties based on data type
    if data_key == 'Profit':
        # Continuous scale requires explicit colorscale and showscale=True
        restyle_args['marker.colorscale'] = ['Viridis']
        restyle_args['marker.showscale'] = [True]
    else:
        # Discrete scale requires colorscale=None and showscale=False
        restyle_args['marker.colorscale'] = [None]
        restyle_args['marker.showscale'] = [False]
        
    button = dict(
        label=name,
        method='restyle',
        args=[
            restyle_args,
            [0] # Target the first trace
        ]
    )
    buttons.append(button)

# 4. Layout Integration
fig4.update_layout(
    updatemenus=[
        dict(
            buttons=buttons,
            direction="down",
            pad={"r": 10, "t": 10},
            showactive=True,
            x=0.01,
            xanchor="left",
            y=1.15, # Position above the title
            yanchor="top"
        )
    ]
)

# fig4.show()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# 1. Figure Initialization with secondary_y enabled
fig2 = make_subplots(
    rows=1, cols=1,
    specs=[[{"secondary_y": True}]],
    subplot_titles=("Stock Price and Trading Volume Over Time",)
)

# 2. Price Trace (Line) - Primary Y
fig2.add_trace(
    go.Scatter(
        x=df_stock['Date'],
        y=df_stock['Price'],
        name="Price",
        line=dict(color='blue', width=2)
    ),
    row=1, col=1, secondary_y=False,
)

# 3. Volume Trace (Bar) - Secondary Y
fig2.add_trace(
    go.Bar(
        x=df_stock['Date'],
        y=df_stock['Volume'],
        name="Volume",
        marker=dict(color='lightgray', opacity=0.7)
    ),
    row=1, col=1, secondary_y=True, # Link to secondary axis
)

# 4. Axis Configuration
fig2.update_yaxes(title_text="Stock Price (USD)", secondary_y=False)
fig2.update_yaxes(title_text="Trading Volume", secondary_y=True)

# 5. Interactivity: RangeSlider
fig2.update_layout(
    xaxis=dict(
        rangeslider=dict(visible=True), # Adds the RangeSlider
        type="date"
    ),
    title_text='Time Series Analysis: Price vs. Volume',
    template='plotly_white'
)

# fig2.show()

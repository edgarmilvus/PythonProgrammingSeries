
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# Set random seed for reproducibility
np.random.seed(42)
N = 100

# --- Data Generation for Exercises 1 & 3 ---
dates = pd.date_range(start='2023-01-01', periods=N, freq='D')
categories = np.random.choice(['A', 'B', 'C', 'D'], size=N)
sales = np.random.randint(50, 300, size=N) + (pd.factorize(categories)[0] * 50)
profit_margin = np.random.uniform(0.05, 0.25, size=N)
profit = sales * profit_margin
unique_ids = [f"TXN-{i+1:03d}" for i in range(N)]

df_sales = pd.DataFrame({
    'Date': dates,
    'Category': categories,
    'Sales': sales,
    'Profit': profit,
    'Profit_Margin': profit_margin,
    'Region': np.random.choice(['North', 'South'], size=N),
    'Transaction_ID': unique_ids
})

# --- Data Generation for Exercise 2 (Time Series) ---
T = 365
time_index = pd.date_range(start='2024-01-01', periods=T, freq='D')
price = 100 + np.cumsum(np.random.randn(T) * 0.5)
volume = np.random.randint(1000, 5000, size=T) + (np.sin(np.arange(T) / 30) * 1500)

df_stock = pd.DataFrame({
    'Date': time_index,
    'Price': price,
    'Volume': volume
})

print("DataFrames df_sales and df_stock are ready for use.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.offline import plot
import os

# --- 1. Data Preparation ---
# Define the data structure for quarterly revenue
data = {
    'Quarter': ['Q1 2024', 'Q2 2024', 'Q3 2024', 'Q4 2024'],
    'Revenue_A': [100, 150, 130, 180],
    'Revenue_B': [90, 120, 140, 160]
}
df = pd.DataFrame(data)

# --- 2. Plotly Express (High-Level API) ---
# PX creates the figure, adds the trace, and sets the layout automatically.
fig_px = px.bar(
    df,
    x='Quarter',
    y='Revenue_A',
    title='Revenue A Comparison (Plotly Express)',
    color='Quarter',  # Automatically colors bars based on the Quarter value
    labels={'Revenue_A': 'Total Revenue ($K)'} # Custom axis label mapping
)

# --- 3. Plotly Graph Objects (Low-Level API) ---
# GO requires explicit creation of the Figure container and separate traces.

# Initialize the main Figure object (the canvas)
fig_go = go.Figure()

# Add the trace (the visualization layer - in this case, a bar chart)
fig_go.add_trace(
    go.Bar(
        x=df['Quarter'],
        y=df['Revenue_A'],
        name='Revenue A Trace',
        marker_color='darkblue', # Explicitly setting the color
        opacity=0.8
    )
)

# Update the layout (the styling/configuration layer)
fig_go.update_layout(
    title={
        'text': 'Revenue A Comparison (Graph Objects)',
        'y': 0.9,
        'x': 0.5,
        'xanchor': 'center',
        'yanchor': 'top'
    },
    xaxis_title='Quarter',
    yaxis_title='Total Revenue ($K)',
    font=dict(
        family="Arial, sans-serif",
        size=12,
        color="#7f7f7f"
    )
)

# --- 4. Output Generation ---
# Use os.path.join() for platform-independent path construction
output_filename = os.path.join(os.getcwd(), 'plotly_intro_example.html')

# Save the GO figure to an interactive HTML file
# We use 'plot' instead of 'fig.show()' to ensure compatibility outside of notebooks
plot(fig_go, filename=output_filename, auto_open=True)

print(f"Plotly Express object type: {type(fig_px)}")
print(f"Plotly Graph Objects object type: {type(fig_go)}")
print(f"Visualization saved to: {output_filename}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import numpy as np
import os
import json
import random
import io

# Set pandas display options for better output visualization
pd.set_option('display.max_rows', 10)
pd.set_option('display.max_columns', 10)
pd.set_option('display.width', 1000)

# --- Exercise 1: Structural Integrity and Index Management ---

print("--- Exercise 1: Structural Integrity and Index Management ---")

# 1. Data Initialization
data_sales = {
    'TransactionID': [1001, 1002, 1003, 1004, 1005],
    'Region': ['North', 'South', 'East', 'North', 'West'],
    'Revenue': [1500.50, 890.25, 2300.00, 120.75, 4500.99],
    'UnitsSold': [12, 5, 25, 1, 30]
}

# 2. DataFrame Creation
df_sales = pd.DataFrame(data_sales)
print("Initial DataFrame:")
print(df_sales)

# 3. Index Setting: Use set_index() with inplace=True
df_sales.set_index('TransactionID', inplace=True)

# 4. Structural Inspection
print("\n--- Structural Inspection after Indexing ---")
print(f"Shape of DataFrame: {df_sales.shape}")
print(f"Data type of the new index: {df_sales.index.dtype}")
print("\nFirst two rows (.head(2)):")
print(df_sales.head(2))

# 5. Verification
print("\nVerification:")
print(f"Current Columns: {list(df_sales.columns)}")
if 'TransactionID' not in df_sales.columns:
    print("Verification successful: 'TransactionID' is now the index, not a column.")
else:
    print("Verification failed.")


# --- Exercise 2: Multi-Format Data Ingestion and Consistency Check ---

print("\n\n--- Exercise 2: Multi-Format Data Ingestion and Consistency Check ---")

csv_file = 'sensor_data.csv'
json_file = 'sensor_data.json'

# 1. File Generation (CSV)
csv_content = (
    "SensorID,Temperature,Humidity\n"
    "S001,22.5,60.1\n"
    "S002,23.1,61.5\n"
    "S003,21.9,59.8\n"
    "S004,24.0,62.0\n"
    "S005,22.8,60.5\n"
)
with open(csv_file, 'w') as f:
    f.write(csv_content)

# 2. File Generation (JSON - List of Records format)
json_data = [
    {"SensorID": "S001", "Temperature": 22.5, "Humidity": 60.1},
    {"SensorID": "S002", "Temperature": 23.1, "Humidity": 61.5},
    {"SensorID": "S003", "Temperature": 21.9, "Humidity": 59.8},
    {"SensorID": "S004", "Temperature": 24.0, "Humidity": 62.0},
    {"SensorID": "S005", "Temperature": 22.8, "Humidity": 60.5}
]
with open(json_file, 'w') as f:
    json.dump(json_data, f)
print(f"Generated {csv_file} and {json_file}")

# 3. Data Loading
df_csv = pd.read_csv(csv_file)
df_json = pd.read_json(json_file)

# 4. Dimensional Verification
print("\n--- Dimensional Verification ---")
shape_csv = df_csv.shape
shape_json = df_json.shape
print(f"df_csv shape: {shape_csv}")
print(f"df_json shape: {shape_json}")
if shape_csv == shape_json:
    print("Result: Shapes match.")

# 5. Type Consistency Check
print("\n--- Type Consistency Check ---")
print("df_csv Data Types:")
print(df_csv.dtypes)
print("\ndf_json Data Types:")
print(df_json.dtypes)
# Note: Pandas correctly infers float and object types for both formats.

# 6. Cleanup
os.remove(csv_file)
os.remove(json_file)
print("\nCleaned up generated files.")


# --- Exercise 3: Handling Non-Standard Delimiters and Missing Headers ---

print("\n\n--- Exercise 3: Handling Non-Standard Delimiters and Missing Headers ---")

log_file = 'legacy_data.log'

# 1. File Generation
legacy_content = (
    "# Legacy System Report v1.2\n"
    "# Date: 2024-01-15\n"
    "# Source: Internal Server\n"
    "A234|34.5|Active|USD\n"
    "B567|12.1|Inactive|EUR\n"
    "C890|90.0|Active|USD\n"
    "D012|5.9|Active|GBP\n"
    "E345|10.0|Inactive|USD\n"
)
with open(log_file, 'w') as f:
    f.write(legacy_content)

# 2. Specialized Loading
# sep='|' specifies the pipe delimiter
# skiprows=3 skips the metadata lines
# header=None tells pandas there is no header row
df_legacy = pd.read_csv(log_file, sep='|', skiprows=3, header=None)

# 3. Initial Inspection
print("\nInitial Load Inspection (Default Integer Columns):")
print(df_legacy.head())

# 4. Column Renaming
new_columns = ['ItemCode', 'Value', 'Status', 'Currency']
df_legacy.columns = new_columns

# 5. Final Inspection
print("\nFinal Inspection after Renaming:")
print(f"Column Names: {list(df_legacy.columns)}")
print("\nData Types:")
print(df_legacy.dtypes)

# Cleanup
os.remove(log_file)


# --- Exercise 4: Interactive Challenge: Optimizing Inspection and Memory Footprint ---

print("\n\n--- Exercise 4: Interactive Challenge: Optimizing Inspection and Memory Footprint ---")

large_file = 'large_transactions.csv'
N_ROWS = 10000

# 1. Simulated Data Generation (High memory usage due to unique strings)
data_large = {
    'TransactionID': np.arange(1000000, 1000000 + N_ROWS),
    'Timestamp': pd.date_range(start='2023-01-01', periods=N_ROWS, freq='min'),
    'Amount': np.round(np.random.uniform(1.0, 5000.0, N_ROWS), 2),
    'Category': [random.choice(['Electronics', 'Books', 'Food', 'Clothing', 'Services']) for _ in range(N_ROWS)],
    'Region': [random.choice(['US-West', 'US-East', 'EU', 'Asia']) for _ in range(N_ROWS)],
    'UserAgent': [f"UA_{i}_Unique" for i in range(N_ROWS)], # Unique strings
    'IPAddress': [f"192.168.1.{i % 255}" for i in range(N_ROWS)],
    'StatusFlag': [random.choice(['A', 'B', 'C']) for _ in range(N_ROWS)]
}
df_simulated = pd.DataFrame(data_large)
df_simulated.to_csv(large_file, index=False)
print(f"Generated simulated file: {large_file} ({N_ROWS} rows).")


# 2. Full Load Simulation and Inspection
print("\n--- 2. Full Load Inspection ---")
df_full = pd.read_csv(large_file)
# memory_usage='deep' calculates true memory for 'object' (string) columns
df_full.info(verbose=False, memory_usage='deep')
full_memory = df_full.memory_usage(deep=True).sum()


# 3. Targeted Load Optimization
TARGET_COLS = ['TransactionID', 'Amount', 'Category']
print(f"\n--- 3. Targeted Load using usecols: {TARGET_COLS} ---")
df_optimized = pd.read_csv(large_file, usecols=TARGET_COLS)


# 4. Optimized Inspection
print("Optimized Dataset Inspection:")
df_optimized.info(verbose=False, memory_usage='deep')
optimized_memory = df_optimized.memory_usage(deep=True).sum()


# 5. Analysis
full_memory_mb = full_memory / (1024 * 1024)
optimized_memory_mb = optimized_memory / (1024 * 1024)
reduction_percent = ((full_memory - optimized_memory) / full_memory) * 100

print("\n--- Memory Reduction Summary ---")
print(f"Full Load Memory: {full_memory_mb:.3f} MB")
print(f"Optimized Load Memory: {optimized_memory_mb:.3f} MB")
print(f"Memory Reduction Achieved: {reduction_percent:.2f}%")

# Cleanup
os.remove(large_file)


# --- Exercise 5: Data Type Inference and Correction ---

print("\n\n--- Exercise 5: Data Type Inference and Correction ---")

inventory_file = 'inventory_report.csv'

# 1. File Generation
inventory_content = (
    "ProductID,Price,StockLevel\n"
    "P001,19.99,150\n"
    "P002,45.50,20\n"
    "P003,5.00,OUT\n"
    "P004,100.00,80\n"
    "P005,12.50,OUT\n"
    "P006,88.88,5\n"
)
with open(inventory_file, 'w') as f:
    f.write(inventory_content)

# 2. Initial Load and Inspection
df_initial = pd.read_csv(inventory_file)
print("\nInitial Data Types (StockLevel is 'object' due to 'OUT'):")
print(df_initial.dtypes)

# 3. Type Correction Reload
# na_values=['OUT'] treats 'OUT' as NaN
# dtype={'StockLevel': float} forces the column to be numeric
df_corrected = pd.read_csv(inventory_file, 
                           na_values=['OUT'], 
                           dtype={'StockLevel': float})

# 4. Final Inspection
print("\nCorrected Data Types (StockLevel is now 'float64'):")
print(df_corrected.dtypes)

print("\nRows showing corrected missing values (NaN):")
# Filter to show rows where StockLevel is NaN (i.e., where 'OUT' was)
print(df_corrected[df_corrected['StockLevel'].isna()])

# Cleanup
os.remove(inventory_file)

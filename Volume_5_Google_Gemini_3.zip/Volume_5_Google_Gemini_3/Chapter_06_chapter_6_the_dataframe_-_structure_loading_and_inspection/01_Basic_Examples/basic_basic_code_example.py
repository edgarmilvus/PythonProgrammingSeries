
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import pandas as pd # Import the pandas library, aliased as pd

# 1. Define the raw data structure using a dictionary of lists.
# The keys of the dictionary become the column labels (headers).
# The values (lists) become the data series for those columns.
data_ledger = {
    'Product_ID': ['P101', 'P102', 'P103', 'P104', 'P105'],
    'Category': ['Electronics', 'Apparel', 'Electronics', 'Home Goods', 'Apparel'],
    'Price_USD': [499.99, 55.00, 19.99, 120.50, 88.00],
    'Units_Sold': [150, 300, 850, 45, 210],
    'In_Stock': [True, True, False, True, False]
}

# 2. Create the DataFrame object by passing the dictionary to the constructor.
# This operation transforms the column-oriented dictionary into a labeled table.
inventory_df = pd.DataFrame(data_ledger)

# --- Basic DataFrame Inspection and Structural Review ---

# 3. Inspection Method 1: Visual check of the structure using .head()
print("--- 1. DataFrame Structure (Top 3 Rows) ---")
# .head(N) displays the first N rows. Default is N=5.
print(inventory_df.head(3))

print("\n" + "="*50 + "\n")

# 4. Inspection Method 2: Check the dimensions using the .shape attribute
print("--- 2. DataFrame Dimensions (Rows, Columns) ---")
# .shape returns a tuple (Number of Rows, Number of Columns)
print(f"Shape: {inventory_df.shape}")

print("\n" + "="*50 + "\n")

# 5. Inspection Method 3: Examine the data type inferred for each column
print("--- 3. Column Data Types (.dtypes) ---")
# .dtypes is crucial for understanding memory usage and operation validity.
print(inventory_df.dtypes)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import pandas as pd
import numpy as np

# 1. Setup: Create a sample dataset for a small retail operation
# This DataFrame tracks individual transactions across regions and products.
data = {
    'Region': ['North', 'South', 'North', 'East', 'South', 'East', 'North', 'South', 'East', 'North'],
    'Product': ['A', 'B', 'A', 'C', 'B', 'A', 'C', 'A', 'B', 'C'],
    'Sales': [150.00, 200.00, 120.00, 350.00, 180.00, 400.00, 90.00, 250.00, 300.00, 110.00],
    'Quantity': [5, 10, 4, 7, 9, 12, 3, 8, 11, 4]
}
df = pd.DataFrame(data)

print("--- Original DataFrame (df) ---")
print(df)
print("-" * 60)

# 2. Basic Grouping and Single Aggregation
# Objective: Calculate the total sales for each Region.
# Grouping Key: 'Region'
region_sales_summary = df.groupby('Region')['Sales'].sum().reset_index()

print("\n--- 2. Total Sales per Region (Simple GroupBy) ---")
print(region_sales_summary)
print("-" * 60)


# 3. Grouping by Multiple Keys and Applying Multiple, Named Aggregations
# Objective: Analyze transactional volume (count) and total sales (sum) per Region AND Product.
# This uses the modern .agg() syntax for clean output column naming.
multi_group_summary = df.groupby(['Region', 'Product']).agg(
    Total_Sales=('Sales', 'sum'),        # Calculate the sum of Sales, naming the new column 'Total_Sales'
    Transaction_Count=('Sales', 'count'), # Calculate the count of transactions, naming the column 'Transaction_Count'
    Avg_Quantity=('Quantity', 'mean')      # Calculate the mean of Quantity
)

# Resetting the index promotes the grouped keys ('Region', 'Product') back to regular columns
multi_group_summary = multi_group_summary.reset_index()

print("\n--- 3. Multi-Level Grouping and Named Aggregation ---")
print(multi_group_summary)
print("-" * 60)

# 4. Applying different aggregations to different columns (Dictionary Syntax)
# Objective: Find the maximum sale amount and the average quantity for each product.
product_analysis = df.groupby('Product').agg({
    'Sales': 'max',      # Find the maximum sale value for that product
    'Quantity': 'mean'   # Find the average quantity sold for that product
}).reset_index()

print("\n--- 4. Product Analysis (Mixed Aggregation) ---")
print(product_analysis)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# --- 1. Data Generation: Simulating E-commerce Transactions ---

def generate_transaction_data(num_records=5000):
    """Creates a synthetic DataFrame simulating sales transactions."""
    np.random.seed(42)
    start_date = datetime(2023, 1, 1)
    
    # Define categories and customer base
    categories = ['Electronics', 'Apparel', 'HomeGoods', 'Books']
    customer_ids = [f'CUST_{i:03d}' for i in range(100)]
    
    data = {
        'TransactionID': range(1, num_records + 1),
        'CustomerID': np.random.choice(customer_ids, num_records),
        'ProductCategory': np.random.choice(categories, num_records, p=[0.3, 0.4, 0.2, 0.1]),
        'TransactionDate': [start_date + timedelta(days=np.random.randint(0, 365)) for _ in range(num_records)],
        'ItemCount': np.random.randint(1, 6, num_records),
        'UnitCost': np.random.uniform(10, 500, num_records).round(2)
    }
    
    df = pd.DataFrame(data)
    # Calculate Total Revenue, applying a category-specific multiplier for realism
    category_multiplier = df['ProductCategory'].map({'Electronics': 1.5, 'Apparel': 1.0, 'HomeGoods': 0.8, 'Books': 0.5})
    df['TotalRevenue'] = (df['ItemCount'] * df['UnitCost'] * category_multiplier).round(2)
    return df

# Load the data
sales_df = generate_transaction_data()

print("--- Initial Data Snapshot (First 5 Rows) ---")
print(sales_df[['CustomerID', 'ProductCategory', 'TransactionDate', 'TotalRevenue']].head())
print("-" * 50)

# --- 2. Advanced GroupBy and Custom Aggregation (Calculating KPIs) ---
# Objective: Calculate Total Spend, Average Order Value (AOV), and Purchase Frequency 
# per specific Customer ID and Product Category pair.

# Define the custom aggregation dictionary
agg_rules = {
    'TotalRevenue': ['sum', 'mean'],        # Total Spend and Average Revenue per Transaction (AOV)
    'TransactionID': 'count',               # Total number of transactions in this group
    'TransactionDate': pd.Series.nunique    # Count unique days the customer made a purchase (Frequency)
}

# Perform multi-level grouping and apply custom aggregation
category_summary = sales_df.groupby(['CustomerID', 'ProductCategory']).agg(agg_rules)

# Clean up column names after multi-level aggregation (flattens the MultiIndex columns)
category_summary.columns = ['_'.join(col).strip() for col in category_summary.columns.values]
category_summary = category_summary.rename(columns={
    'TotalRevenue_sum': 'Total_Category_Spend',
    'TotalRevenue_mean': 'Category_AOV',
    'TransactionID_count': 'Category_Order_Count',
    'TransactionDate_nunique': 'Purchase_Frequency_Days'
})

print("\n--- 3. Multi-Level Grouping & Custom Aggregation Results (Sample Customer) ---")
print(category_summary.loc['CUST_001'].sort_values(by='Total_Category_Spend', ascending=False))
print("-" * 50)

# --- 4. Reshaping Data using Pivot Tables (CLV Matrix) ---
# Objective: Transform the detailed summary into a wide matrix where categories are columns, 
# showing the total spend for each customer.

# Reset the index to make CustomerID and ProductCategory available as columns
pivot_source = category_summary.reset_index()

# Create the pivot table: Customers (index) vs. Categories (columns), showing Total Spend
spend_matrix_with_totals = pd.pivot_table(
    data=pivot_source,
    index='CustomerID',
    columns='ProductCategory',
    values='Total_Category_Spend',
    fill_value=0,           # Fills categories not purchased with 0
    aggfunc='sum',          # Aggregation is trivial here, as data is pre-aggregated
    margins=True,           # Adds 'All' row/column for totals
    margins_name='Overall_CLV' # Name the total column/row
)

print("\n--- 5. Customer Spending Matrix (Pivot Table) ---")
# Display top 10 customers based on Overall_CLV (Customer Lifetime Value proxy)
top_spenders = spend_matrix_with_totals.sort_values(by='Overall_CLV', ascending=False).head(10)
print(top_spenders)
print("-" * 50)

# --- 6. Advanced Crosstab for Frequency Distribution Analysis ---
# Objective: Analyze the relationship between transaction size (Item Count) and Product Category.

# Define bins for Item Count to group transactions into logical basket sizes
sales_df['ItemCount_Bins'] = pd.cut(sales_df['ItemCount'], bins=[0, 1, 3, 5, 6], 
                                    labels=['Single Item', 'Small Basket', 'Medium Basket', 'Max Basket'],
                                    right=True, include_lowest=True)

# Use crosstab to generate a contingency table (frequency count)
# Normalize='index' calculates the percentage distribution within each row (basket size)
frequency_table = pd.crosstab(
    index=sales_df['ItemCount_Bins'],
    columns=sales_df['ProductCategory'],
    normalize='index' 
)

print("\n--- 7. Transaction Basket Size Distribution (Crosstab, Normalized by Row) ---")
# Use the style API for clean percentage formatting
print(frequency_table.style.format('{:.2%}'))

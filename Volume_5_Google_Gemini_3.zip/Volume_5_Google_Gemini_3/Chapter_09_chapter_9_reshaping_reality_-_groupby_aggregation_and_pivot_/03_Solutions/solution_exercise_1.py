
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import numpy as np
import datetime as dt

# --- Re-execute Setup for isolated context (standard practice for solution blocks) ---
# Set seed for reproducibility
np.random.seed(42)

# Define Dimensions (as in setup)
REGIONS = ['North America', 'Europe', 'Asia', 'South America']
PRODUCT_CATEGORIES = ['Electronics', 'Apparel', 'Home Goods', 'Software']
SALES_REPS = [f'Rep_{i}' for i in range(1, 11)]
CUSTOMER_SEGMENTS = ['Enterprise', 'SMB', 'Individual']
PAYMENT_METHODS = ['Credit Card', 'Bank Transfer', 'Digital Wallet']
START_DATE = dt.datetime(2022, 1, 1)
END_DATE = dt.datetime(2023, 12, 31)

# Generate a large dataset (50,000 transactions)
N_ROWS = 50000

# Generate random dates
date_range = pd.date_range(START_DATE, END_DATE)
dates = np.random.choice(date_range, N_ROWS)

data = {
    'Transaction_Date': dates,
    'Region': np.random.choice(REGIONS, N_ROWS),
    'Category': np.random.choice(PRODUCT_CATEGORIES, N_ROWS),
    'Sales_Rep': np.random.choice(SALES_REPS, N_ROWS),
    'Customer_Segment': np.random.choice(CUSTOMER_SEGMENTS, N_ROWS),
    'Payment_Method': np.random.choice(PAYMENT_METHODS, N_ROWS),
    'Units_Sold': np.random.randint(1, 50, N_ROWS),
    'Unit_Price': np.round(np.random.uniform(10.0, 1000.0, N_ROWS), 2),
    'Discount_Rate': np.random.choice([0.0, 0.05, 0.1, 0.15], N_ROWS, p=[0.7, 0.15, 0.1, 0.05])
}

df_sales = pd.DataFrame(data)

# Calculate derived metrics
df_sales['Gross_Revenue'] = df_sales['Units_Sold'] * df_sales['Unit_Price']
df_sales['Net_Revenue'] = df_sales['Gross_Revenue'] * (1 - df_sales['Discount_Rate'])
df_sales['Profit_Margin'] = np.random.uniform(0.15, 0.45, N_ROWS)
df_sales['Net_Profit'] = df_sales['Net_Revenue'] * df_sales['Profit_Margin']

# Add temporal features
df_sales['Year'] = df_sales['Transaction_Date'].dt.year
df_sales['Month'] = df_sales['Transaction_Date'].dt.to_period('M')

# Custom aggregation function for Exercise 2
def range_of_values(series):
    """Calculates the difference between the max and min of a series."""
    return series.max() - series.min()

print("--- SOLUTIONS START ---")

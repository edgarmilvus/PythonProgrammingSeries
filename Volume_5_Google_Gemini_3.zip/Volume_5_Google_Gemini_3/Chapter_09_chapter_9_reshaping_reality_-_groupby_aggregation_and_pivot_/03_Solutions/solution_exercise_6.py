
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_6.py
# Description: Solution for Exercise 6
# ==========================================

print("\n[Exercise 5: MoM Growth Rate per Category]")

# 1. Initial Grouping: Calculate Total Monthly Revenue per Category
# The result is a Series with a MultiIndex (Category, Month)
monthly_summary = df_sales.groupby(['Category', 'Month'])['Net_Revenue'].sum().rename('Total_Monthly_Revenue')

# Convert the resulting Series back to a DataFrame
monthly_summary_df = monthly_summary.to_frame()

# 2. Secondary Grouping and Transformation: Calculate MoM change within each Category
# We group by the 'Category' level of the index and apply pct_change()
monthly_summary_df['MoM_Growth_Rate'] = (
    monthly_summary_df.groupby(level='Category')['Total_Monthly_Revenue']
    .pct_change()
)

# Display the result, sorted by Category and Month
report_e5 = monthly_summary_df.sort_index(level=['Category', 'Month'])

print("\nMonthly Revenue and MoM Growth Rate per Category (Head):")
print(report_e5.head(15))

# Verification check
print("\nVerification of MoM calculation (First month of each category is NaN):")
print(report_e5.loc['Apparel'].head())

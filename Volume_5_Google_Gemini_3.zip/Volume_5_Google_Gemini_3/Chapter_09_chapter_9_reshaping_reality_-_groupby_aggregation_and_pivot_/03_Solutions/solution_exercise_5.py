
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

print("\n[Exercise 4: Crosstab Frequency Analysis]")

# 1. Absolute Frequencies (Raw Count)
crosstab_raw = pd.crosstab(
    df_sales['Customer_Segment'], 
    df_sales['Payment_Method']
)
print("\nAbsolute Frequencies:")
print(crosstab_raw)

# 2. Conditional Probability (Row Normalization)
# Shows: For a given segment, what percentage uses each method?
crosstab_row_norm = pd.crosstab(
    df_sales['Customer_Segment'], 
    df_sales['Payment_Method'],
    normalize='index'
) * 100 

print("\nRow Normalized (Percentage of Segment - sums across rows to 100):")
print(crosstab_row_norm.round(2))

# 3. Conditional Probability (Column Normalization)
# Shows: For a given payment method, what percentage is used by each segment?
crosstab_col_norm = pd.crosstab(
    df_sales['Customer_Segment'], 
    df_sales['Payment_Method'],
    normalize='columns'
) * 100 

print("\nColumn Normalized (Percentage of Method - sums down columns to 100):")
print(crosstab_col_norm.round(2))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# 1. Filter data for 2023
df_2023 = df_sales[df_sales['Year'] == 2023]

# 2. Define aggregation dictionary
agg_dict_1 = {
    'Net_Revenue': 'sum',
    'Unit_Price': 'mean',
    'Units_Sold': 'sum',
    'Gross_Revenue': 'count' # Using Gross_Revenue column for the transaction count
}

# 3. Perform grouping and aggregation
report_e1 = df_2023.groupby(['Region', 'Category', 'Sales_Rep']).agg(agg_dict_1)

# 4. Rename columns for clarity
report_e1.rename(columns={
    'Net_Revenue': 'Total Net Revenue',
    'Unit_Price': 'Avg Unit Price',
    'Units_Sold': 'Total Units Sold',
    'Gross_Revenue': 'Transaction Count'
}, inplace=True)

# 5. Sorting: by Region (ascending) and then by Total Net Revenue (descending)
report_e1 = report_e1.sort_values(
    by=['Region', 'Total Net Revenue'],
    ascending=[True, False]
)

print("\n[Exercise 1: Hierarchical Performance Report (2023 Data)]")
print(report_e1.head(10))

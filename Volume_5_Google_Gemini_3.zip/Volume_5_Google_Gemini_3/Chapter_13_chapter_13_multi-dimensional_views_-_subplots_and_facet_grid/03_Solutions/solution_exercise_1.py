
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.gridspec import GridSpec

# Set default style for better visibility
sns.set_theme(style="whitegrid")

# --- Exercise 1: Asymmetric Subplot Management via GridSpec ---
def exercise_1_asymmetric_grid():
    """
    Creates an asymmetric 3x2 visualization dashboard using Matplotlib GridSpec, 
    featuring a spanning histogram and scatter plots with shared axes.
    """
    print("\n--- Exercise 1: Asymmetric Subplot Management via GridSpec ---")
    
    # Load data
    mpg = sns.load_dataset('mpg')
    
    # Create Figure and GridSpec (3 rows, 2 columns)
    fig = plt.figure(figsize=(14, 12))
    gs = GridSpec(3, 2, figure=fig)
    
    # 3. Primary Plot (Spanning 1st row: gs[0, :])
    ax_hist = fig.add_subplot(gs[0, :])
    ax_hist.hist(mpg['mpg'], bins=20, edgecolor='black', color='skyblue')
    ax_hist.set_title('Overall MPG Distribution (Spanning Plot)')
    ax_hist.set_xlabel('Miles Per Gallon (MPG)')
    ax_hist.set_ylabel('Frequency')
    
    # 4. Secondary Plots (Remaining Cells)
    
    # Row 1 (Index 1)
    ax10 = fig.add_subplot(gs[1, 0])
    sns.scatterplot(x='horsepower', y='weight', data=mpg, ax=ax10)
    ax10.set_title('HP vs Weight')
    
    ax11 = fig.add_subplot(gs[1, 1])
    sns.scatterplot(x='acceleration', y='displacement', data=mpg, ax=ax11)
    ax11.set_title('Acceleration vs Displacement')
    
    # Row 2 (Index 2) - Sharing X-axis (MPG)
    ax20 = fig.add_subplot(gs[2, 0])
    sns.scatterplot(x='mpg', y='weight', data=mpg, ax=ax20)
    ax20.set_title('MPG vs Weight')
    
    # 5. Share X-axis with ax20 for easy vertical comparison
    ax21 = fig.add_subplot(gs[2, 1], sharex=ax20) 
    sns.scatterplot(x='mpg', y='horsepower', data=mpg, ax=ax21)
    ax21.set_title('MPG vs Horsepower')
    
    fig.suptitle('Custom Asymmetric 3x2 Layout using GridSpec', fontsize=16)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.show()

# --- Exercise 2: Complex Conditioning with Seaborn FacetGrid ---
def exercise_2_facet_grid():
    """
    Uses FacetGrid to condition a scatter plot and KDE layer based on 
    both row ('origin') and column ('cylinders'), with independent Y-axes.
    """
    print("\n--- Exercise 2: Complex Conditioning with Seaborn FacetGrid ---")
    
    mpg = sns.load_dataset('mpg')
    # 1. Filter data to include only 4, 6, or 8 cylinders
    filtered_mpg = mpg[mpg['cylinders'].isin([4, 6, 8])]
    
    # 2. Initialize FacetGrid
    g = sns.FacetGrid(
        filtered_mpg, 
        row='origin', 
        col='cylinders', 
        height=3.5, 
        aspect=1.2,
        sharey=False # 5. Scaling Control: Disable shared Y-axis
    )
    
    # 3. Map Scatter Plot
    g.map(plt.scatter, "horsepower", "mpg", edgecolor="w", alpha=0.7)
    
    # 4. Enhancement: Add 2D Kernel Density Estimate (KDE) layer
    g.map(sns.kdeplot, "horsepower", "mpg", color='red', alpha=0.3, zorder=0)
    
    # Set titles and labels
    g.set_axis_labels("Horsepower", "MPG")
    g.set_titles(col_template="{col_name} Cylinders", row_template="{row_name}")
    g.fig.suptitle('MPG vs Horsepower Conditioned by Origin and Cylinders', y=1.02)
    
    plt.tight_layout()
    plt.show()

# --- Exercise 3: Revealing Distributions with catplot ---
def exercise_3_catplot():
    """
    Uses sns.catplot to create faceted box plots comparing total bill 
    distribution across days, conditioned by smoker status.
    """
    print("\n--- Exercise 3: Revealing Distributions with catplot ---")
    
    tips = sns.load_dataset('tips')
    
    # 2-5. Use catplot with kind='box', conditioning on 'smoker' (col)
    g = sns.catplot(
        data=tips,
        x='day',
        y='total_bill',
        col='smoker',
        kind='box',
        height=5,
        aspect=1,
        order=['Thur', 'Fri', 'Sat', 'Sun'], 
        col_order=['No', 'Yes'] # 6. Advanced Layout: Ensure 'No' comes before 'Yes'
    )
    
    g.fig.suptitle('Total Bill Distribution by Day, Split by Smoker Status', y=1.02)
    g.set_axis_labels("Day of Week", "Total Bill ($)")
    g.set_titles(col_template="Smoker: {col_name}")
    
    plt.show()

# --- Exercise 4: Interactive Challenge - Refactoring for Tidy Visualization ---
def exercise_4_interactive_challenge():
    """
    Creates a tidy DataFrame and uses sns.relplot to visualize model predictions 
    across regions, utilizing hue and col_wrap for structure.
    """
    print("\n--- Exercise 4: Interactive Challenge (relplot Refactor) ---")
    
    # 1. Recreate the simulated tidy DataFrame
    data = {
        'Region': ['North', 'South', 'East', 'West'] * 2,
        'Feature_Value': np.concatenate([
            np.linspace(1000, 2000, 4), 
            np.linspace(1000, 2000, 4) + 50 
        ]),
        'Prediction': np.concatenate([
            np.linspace(150, 350, 4), 
            np.linspace(150, 350, 4)**1.05 / 2 
        ]),
        'Model_Type': ['Linear'] * 4 + ['Quadratic'] * 4
    }
    df_results = pd.DataFrame(data)
    
    # 2-5. Use relplot for line visualization conditioned by Region and Model_Type
    g = sns.relplot(
        data=df_results,
        x='Feature_Value',
        y='Prediction',
        col='Region', # Condition by region (columns)
        hue='Model_Type', # Differentiate model type (color)
        kind='line', # Display trend lines
        height=4,
        aspect=1.2,
        col_wrap=2, # 6. Refinement: Arrange into two rows
        palette={'Linear': 'blue', 'Quadratic': 'red'}
    )
    
    g.fig.suptitle('Model Performance Comparison Across Regions', y=1.02)
    g.set_axis_labels("Feature Value (Sq Ft)", "Predicted Value (Price)")
    g.set_titles(col_template="Region: {col_name}")
    
    plt.show()

# --- Exercise 5: Advanced GridSpec and Inset Plots ---
def exercise_5_advanced_gridspec():
    """
    Demonstrates complex layout using GridSpec for a 3x3 grid, including 
    a 2x2 spanning plot and an explicitly defined inset plot.
    """
    print("\n--- Exercise 5: Advanced GridSpec and Inset Plots ---")
    
    iris = sns.load_dataset('iris')
    
    fig = plt.figure(figsize=(15, 15))
    # 2. Define a main 3x3 GridSpec
    gs = GridSpec(3, 3, figure=fig, hspace=0.3, wspace=0.3)
    
    # 3. Main Plot (Spanning 2x2: rows 0-1, cols 0-1)
    ax_main = fig.add_subplot(gs[0:2, 0:2])
    sns.scatterplot(x='sepal_length', y='sepal_width', hue='species', data=iris, ax=ax_main, s=100)
    ax_main.set_title('Main Scatter Plot (Sepal Length vs Width)')
    
    # 6. Inset Plot: Defined relative to the entire figure [left, bottom, width, height]
    # We place it within the 2x2 main plot area (top-left quadrant)
    ax_inset = fig.add_axes([0.4, 0.65, 0.2, 0.2]) 
    
    # Filter data for the zoomed view
    zoomed_data = iris[
        (iris['sepal_length'] >= 5.0) & (iris['sepal_length'] <= 6.0) &
        (iris['sepal_width'] >= 3.0) & (iris['sepal_width'] <= 4.0)
    ]
    sns.scatterplot(x='sepal_length', y='sepal_width', hue='species', data=zoomed_data, ax=ax_inset, legend=False, s=50)
    ax_inset.set_title('Zoomed View', fontsize=10)
    ax_inset.tick_params(axis='both', which='major', labelsize=8)
    
    # 4. Marginal Plots
    ax_hist_sl = fig.add_subplot(gs[0, 2])
    sns.histplot(iris['sepal_length'], kde=True, ax=ax_hist_sl, color='darkgreen')
    ax_hist_sl.set_title('Sepal Length Dist.')
    ax_hist_sl.set_xlabel('')
    
    ax_hist_sw = fig.add_subplot(gs[2, 0])
    sns.histplot(iris['sepal_width'], kde=True, ax=ax_hist_sw, color='darkred')
    ax_hist_sw.set_title('Sepal Width Dist.')
    ax_hist_sw.set_xlabel('')
    
    # 5. Remaining Plots
    ax12 = fig.add_subplot(gs[1, 2])
    sns.scatterplot(x='petal_length', y='petal_width', hue='species', data=iris, ax=ax12, legend=False)
    ax12.set_title('Petal L vs W')
    
    ax21 = fig.add_subplot(gs[2, 1])
    sns.boxplot(x='species', y='petal_length', data=iris, ax=ax21)
    ax21.set_title('Petal Length by Species')
    ax21.set_xlabel('')
    
    ax22 = fig.add_subplot(gs[2, 2])
    sns.scatterplot(x='sepal_length', y='petal_length', hue='species', data=iris, ax=ax22, legend=False)
    ax22.set_title('Sepal L vs Petal L')
    
    fig.suptitle('Comprehensive Iris Dashboard with GridSpec and Inset', fontsize=18, y=0.98)
    plt.show()

# Execute all exercises
if __name__ == '__main__':
    exercise_1_asymmetric_grid()
    exercise_2_facet_grid()
    exercise_3_catplot()
    exercise_4_interactive_challenge()
    exercise_5_advanced_gridspec()

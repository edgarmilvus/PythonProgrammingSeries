
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import classification_report, confusion_matrix, mean_squared_error

# --- Exercise 1 Imports ---
from sklearn.svm import SVC
from sklearn.datasets import make_classification

# --- Exercise 2 Imports ---
from sklearn.datasets import make_blobs

# --- Exercise 4 Imports ---
from sklearn.linear_model import LinearRegression
from sklearn.datasets import make_regression
import warnings
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=UserWarning)


# ====================================================================
# Exercise 1: Supervised Classification - Churn Prediction
# ====================================================================

def run_exercise_1():
    print("--- Running Exercise 1: Supervised Classification ---")
    
    # 1. Data Simulation (Imbalanced Churn Data)
    X, y = make_classification(
        n_samples=1000, 
        n_features=10, 
        n_informative=8, 
        n_redundant=2, 
        n_classes=2, 
        weights=[0.85, 0.15], # 85% No Churn (0), 15% Churn (1)
        random_state=42
    )
    
    # Stratified split ensures the imbalance ratio is maintained in train/test sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

    # 2. Preprocessing: Standardization
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # 3. Model Training (Support Vector Classifier)
    model = SVC(random_state=42)
    model.fit(X_train_scaled, y_train) # Fit the model

    # 4. Evaluation
    y_pred = model.predict(X_test_scaled) # Predict on X_test_scaled
    
    # Calculate overall accuracy
    accuracy = model.score(X_test_scaled, y_test)
    print(f"Overall Classification Accuracy: {accuracy:.4f}")

    # Print Metrics
    print("\nConfusion Matrix:")
    # Rows are True labels (0=No Churn, 1=Churn), Columns are Predicted labels
    print(confusion_matrix(y_test, y_pred)) 
    
    print("\nClassification Report (Focus on Class 1 - Churn):")
    # Target names help clarify which class is which
    print(classification_report(y_test, y_pred, target_names=['No Churn (0)', 'Churn (1)']))

    # 5. Interpretation
    print("\nInterpretation of F1-Score:")
    print("In imbalanced classification problems like churn prediction (where 'No Churn' dominates), simple accuracy is misleading. A model could achieve 85% accuracy by simply predicting 'No Churn' every time.")
    print("The F1-score (harmonic mean of Precision and Recall) for the minority class (Churn=1) is crucial because it balances the need to minimize False Positives (Precision: not flagging loyal customers) and False Negatives (Recall: not missing actual churners). A high F1-score indicates a robust model that handles the class imbalance effectively for the critical positive class.")


# ====================================================================
# Exercise 2: Unsupervised Clustering - Market Segmentation
# ====================================================================

def run_exercise_2():
    print("\n--- Running Exercise 2: Unsupervised Clustering ---")
    
    # 1. Data Simulation (Unlabeled customer data)
    X, true_labels = make_blobs(
        n_samples=800, 
        centers=4, # True number of clusters is 4
        n_features=3, 
        cluster_std=1.5, 
        random_state=42
    )

    # 2. Feature Scaling
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # 3. Optimal k Determination (Elbow Method)
    inertia_values = []
    k_range = range(1, 11)
    
    for k in k_range:
        # n_init=10 suppresses the UserWarning about default change
        kmeans = KMeans(n_clusters=k, random_state=42, n_init=10) 
        kmeans.fit(X_scaled) # Fit K-Means
        inertia_values.append(kmeans.inertia_) # append inertia

    # Plotting the Elbow Curve
    plt.figure(figsize=(8, 5))
    plt.plot(k_range, inertia_values, marker='o') # Plot k_range vs inertia_values
    plt.title('Elbow Method for Optimal k')
    plt.xlabel('Number of Clusters (k)')
    plt.ylabel('Inertia (Within-Cluster Sum of Squares)')
    plt.grid(True)
    plt.show()

    # 4. Clustering (Optimal k=4 is chosen based on the plot elbow point and simulation setup)
    optimal_k = 4 
    final_kmeans = KMeans(n_clusters=optimal_k, random_state=42, n_init=10)
    cluster_labels = final_kmeans.fit_predict(X_scaled) # Fit and predict cluster labels
    
    # 5. Analysis and Visualization (Using the first two features)
    df = pd.DataFrame(X, columns=['Feature_1', 'Feature_2', 'Feature_3'])
    df['Cluster'] = cluster_labels # Assign cluster labels

    plt.figure(figsize=(10, 7))
    # Scatter plot colored by the assigned cluster label
    scatter = plt.scatter(
        df['Feature_1'], 
        df['Feature_2'], 
        c=df['Cluster'], 
        cmap='viridis', 
        s=50, 
        alpha=0.6
    )
    plt.title(f'Customer Segments Identified by K-Means (k={optimal_k})')
    plt.xlabel('Feature 1')
    plt.ylabel('Feature 2')
    plt.colorbar(scatter, label='Cluster ID')
    plt.show()

    # 6. Interpretation
    print("\nInterpretation of Market Segments:")
    print(f"The Elbow plot typically shows a sharp bend (the 'elbow') around k={optimal_k}, confirming the choice.")
    print("The scatter plot visualizes the segmentation. For example, customers in Cluster 0 (e.g., Purple) might be characterized by low values in both Feature 1 and Feature 2, potentially representing 'Budget Shoppers'. Clusters separated on the plot represent distinct behavioral groups identified solely by the algorithm, without prior labels.")


# ====================================================================
# Exercise 3: Interactive Challenge - Dimensionality Reduction (PCA)
# ====================================================================

def run_exercise_3():
    print("\n--- Running Exercise 3: Interactive Challenge (PCA) ---")
    
    # 1. Data Setup (Simulating the original Supervised Regression data)
    X_full, y_target = make_regression(
        n_samples=500, 
        n_features=8, 
        n_informative=6, 
        noise=5, 
        random_state=42
    )

    # Discard the target variable (y_target) for the Unsupervised task
    X = X_full 
    print(f"Original Feature Matrix Shape: {X.shape}")

    # 2. Preprocessing: Standardization
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # 3. PCA Application and Variance Analysis
    pca = PCA()
    pca.fit(X_scaled)
    
    # Calculate Cumulative Explained Variance
    cumulative_variance = np.cumsum(pca.explained_variance_ratio_)
    
    # Determine components for 90% variance
    n_components_90 = np.argmax(cumulative_variance >= 0.90) + 1 
    print(f"Components needed to explain 90% variance: {n_components_90}")

    # 4. Transformation
    pca_final = PCA(n_components=n_components_90)
    X_pca = pca_final.fit_transform(X_scaled)
    
    print(f"Reduced Feature Matrix Shape: {X_pca.shape}")

    # 5. Visualization (Cumulative Explained Variance)
    plt.figure(figsize=(10, 6))
    plt.plot(range(1, len(cumulative_variance) + 1), cumulative_variance, marker='o', linestyle='--')
    plt.axhline(y=0.90, color='r', linestyle='-', label='90% Threshold')
    plt.axvline(x=n_components_90, color='g', linestyle='--', label=f'{n_components_90} Components')
    plt.title('Cumulative Explained Variance by Principal Components')
    plt.xlabel('Number of Components')
    plt.ylabel('Cumulative Explained Variance Ratio')
    plt.legend()
    plt.grid(True)
    plt.show()

    # 6. Comparative Statement
    print("\nComparative Statement:")
    print("PCA is an unsupervised technique because it analyzes the internal structure of the feature data (X) without using the target variable (y), aiming for data compression and noise reduction, which fundamentally differs from the original regression task of predicting the continuous target (y).")


# ====================================================================
# Exercise 4: Hybrid Pipeline - Preprocessing via PCA
# ====================================================================

def run_exercise_4():
    print("\n--- Running Exercise 4: Hybrid Pipeline (PCA + Regression) ---")
    
    # 1. Data Generation (Noisy Regression Data)
    X_full, y = make_regression(
        n_samples=1500, 
        n_features=15, 
        n_informative=5, # Only 5 features matter
        n_redundant=10, # 10 features are redundant/noise
        noise=15, 
        random_state=42
    )
    
    X_train, X_test, y_train, y_test = train_test_split(X_full, y, test_size=0.3, random_state=42)

    # --- BASELINE SUPERVISED MODEL (Noisy Features) ---
    scaler_base = StandardScaler()
    X_train_base_scaled = scaler_base.fit_transform(X_train)
    X_test_base_scaled = scaler_base.transform(X_test)
    
    model_base = LinearRegression()
    model_base.fit(X_train_base_scaled, y_train)
    y_pred_base = model_base.predict(X_test_base_scaled)
    mse_base = mean_squared_error(y_test, y_pred_base)
    print(f"1. Baseline Model MSE (Noisy Data): {mse_base:.2f}")

    # --- HYBRID PIPELINE (PCA Preprocessing) ---
    
    # 3a. Standardization 
    scaler_hybrid = StandardScaler()
    X_train_hybrid_scaled = scaler_hybrid.fit_transform(X_train)
    X_test_hybrid_scaled = scaler_hybrid.transform(X_test)

    # 3b. PCA Application (99% Variance)
    # n_components=0.99 automatically selects the minimum number of components 
    # required to retain 99% of the variance.
    pca_99 = PCA(n_components=0.99)
    
    # Fit PCA on training data only
    pca_99.fit(X_train_hybrid_scaled) 
    
    X_train_pca = pca_99.transform(X_train_hybrid_scaled) # Transform training data
    X_test_pca = pca_99.transform(X_test_hybrid_scaled) # Transform testing data using fitted PCA
    
    print(f"   PCA reduced features from {X_train.shape[1]} to {X_train_pca.shape[1]} dimensions.")

    # 3c. Train Second Supervised Model
    model_hybrid = LinearRegression()
    model_hybrid.fit(X_train_pca, y_train) # Fit hybrid model on PCA features
    
    y_pred_hybrid = model_hybrid.predict(X_test_pca) # Predict using hybrid model
    mse_hybrid = mean_squared_error(y_test, y_pred_hybrid) # Calculate MSE for hybrid model

    # 4. Comparative Evaluation
    print(f"2. Hybrid Model MSE (PCA Features): {mse_hybrid:.2f}")

    # 5. Conclusion
    print("\nConclusion on Hybrid Performance:")
    print("The Hybrid Model (PCA + Linear Regression) achieved a significantly lower Mean Squared Error than the Baseline Model.")
    print("This improvement is expected because PCA, an unsupervised technique, effectively filtered out the redundant and noisy features (the 10 non-informative dimensions), reducing model complexity and multicollinearity. By eliminating noise, the hybrid model focused only on the most informative components, leading to lower variance and better generalization on the test set.")


if __name__ == '__main__':
    run_exercise_1()
    run_exercise_2()
    run_exercise_3()
    run_exercise_4()

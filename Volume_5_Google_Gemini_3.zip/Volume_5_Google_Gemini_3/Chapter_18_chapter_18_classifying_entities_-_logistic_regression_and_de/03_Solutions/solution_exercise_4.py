
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler
import numpy as np

# 1. Data Setup (Synthetic data with mixed complexity)
# 20 features, 5 informative, 5 redundant, 2 clusters per class
X, y = make_classification(n_samples=1000, n_features=20, n_informative=5, 
                           n_redundant=5, n_clusters_per_class=2, 
                           flip_y=0.1, random_state=42)

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Scale features for LR (required for linear models)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# --- Pipeline 1: Baseline Logistic Regression ---
lr_model = LogisticRegression(solver='liblinear', random_state=42)
lr_model.fit(X_train_scaled, y_train)

lr_test_probs = lr_model.predict_proba(X_test_scaled)[:, 1]
lr_train_probs = lr_model.predict_proba(X_train_scaled)[:, 1] # Probability feature for DT training
lr_auc = roc_auc_score(y_test, lr_test_probs)

# --- Pipeline 2: Baseline Decision Tree ---
# DT does not require scaling, so we use the unscaled data (X_train, X_test)
dt_base_model = DecisionTreeClassifier(max_depth=5, random_state=42)
dt_base_model.fit(X_train, y_train)

dt_base_test_probs = dt_base_model.predict_proba(X_test)[:, 1]
dt_base_auc = roc_auc_score(y_test, dt_base_test_probs)

# --- Pipeline 3: Blended Decision Tree (DT + LR Probability Feature) ---

# Create extended feature sets by stacking the LR probability feature
# The probability score acts as a powerful summary feature.
X_train_blended = np.hstack([X_train, lr_train_probs.reshape(-1, 1)])
X_test_blended = np.hstack([X_test, lr_test_probs.reshape(-1, 1)])

dt_blended_model = DecisionTreeClassifier(max_depth=5, random_state=42)
dt_blended_model.fit(X_train_blended, y_train)

dt_blended_test_probs = dt_blended_model.predict_proba(X_test_blended)[:, 1]
dt_blended_auc = roc_auc_score(y_test, dt_blended_test_probs)

# 5. Comparative Report
print("--- Classification Stacking Results (ROC AUC) ---")
print(f"1. Baseline Logistic Regression (LR): {lr_auc:.4f}")
print(f"2. Baseline Decision Tree (DT): {dt_base_auc:.4f}")
print(f"3. Blended Decision Tree (DT + LR Prob Feature): {dt_blended_auc:.4f}")

print("\n--- Analysis of Blending ---")
if dt_blended_auc > dt_base_auc:
    print("The blended model performed better than the standalone DT.")
    print(f"Improvement over baseline DT: {(dt_blended_auc - dt_base_auc) * 100:.2f} percentage points.")
    print("The LR probability acts as a powerful summary 'Embedding' or 'Tool' of the linear risk captured by LR.")
    print("The Decision Tree can now use this single, highly informative feature to make complex, non-linear splits (e.g., 'If LR Prob > 0.6 AND Feature X < 1.0, then classify as 1'), effectively combining the strengths of both models.")
else:
    print("Blending did not significantly improve the DT performance, suggesting the DT was already capturing most of the linear variance.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression

# Set seed for reproducibility
np.random.seed(42)
N = 500
df = pd.DataFrame({
    'Time_on_Platform': np.random.normal(50, 15, N),
    'Support_Tickets_Filed': np.random.poisson(5, N),
    'Monthly_Usage_GB': np.random.normal(150, 40, N)
})

# Define the true log-odds relationship (synthetic betas)
# Higher Time -> Positive effect (0.4)
# Higher Tickets -> Strong negative effect (-0.8)
# Higher Usage -> Slight positive effect (0.2)
log_odds = (
    0.4 * (df['Time_on_Platform'] / 15) + 
    -0.8 * (df['Support_Tickets_Filed'] / 5) + 
    0.2 * (df['Monthly_Usage_GB'] / 40) + 
    np.random.normal(0, 0.5, N)
)

# Convert log-odds to probability using the sigmoid function
probability = 1 / (1 + np.exp(-log_odds))
df['Renewed'] = (probability > np.random.rand(N)).astype(int)

X = df[['Time_on_Platform', 'Support_Tickets_Filed', 'Monthly_Usage_GB']]
y = df['Renewed']

# 2. Model Training and Standardization
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

model = LogisticRegression(solver='liblinear')
model.fit(X_scaled, y)

# 3. Coefficient Extraction and Transformation
coefficients = model.coef_[0]
odds_ratios = np.exp(coefficients)

results = pd.DataFrame({
    'Feature': X.columns,
    'Standardized_Coefficient': coefficients,
    'Odds_Ratio': odds_ratios
})

# 4. Interpretation Report
print("--- Logistic Regression Coefficient Analysis ---")
results_sorted = results.sort_values(by='Odds_Ratio', ascending=False)
print(results_sorted.to_string(index=False))
print("\n--- Interpretation ---")

# Interpretation of the highest OR (Time_on_Platform)
highest_or_feature = results_sorted.iloc[0]
increase_percent = ((highest_or_feature['Odds_Ratio'] - 1) * 100)
print(f"The feature with the largest positive impact is '{highest_or_feature['Feature']}'.")
print(f"Odds Ratio: {highest_or_feature['Odds_Ratio']:.3f}")
print(f"Interpretation: For every one standard deviation increase in {highest_or_feature['Feature']}, the odds of renewal increase by approximately {increase_percent:.1f}%.")

# Interpretation of the lowest OR (Support_Tickets_Filed)
lowest_or_feature = results_sorted.iloc[-1]
decrease_percent = ((1 - lowest_or_feature['Odds_Ratio']) * 100)
print(f"\nThe feature with the largest negative impact is '{lowest_or_feature['Feature']}'.")
print(f"Odds Ratio: {lowest_or_feature['Odds_Ratio']:.3f}")
print(f"Interpretation: For every one standard deviation increase in {lowest_or_feature['Feature']}, the odds of renewal decrease by approximately {decrease_percent:.1f}%.")

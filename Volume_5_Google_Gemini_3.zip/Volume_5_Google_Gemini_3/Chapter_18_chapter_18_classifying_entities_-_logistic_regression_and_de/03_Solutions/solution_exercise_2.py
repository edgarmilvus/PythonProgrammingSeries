
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import matplotlib.pyplot as plt
import pandas as pd
from sklearn.datasets import load_iris
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# 1. Data Preparation
iris = load_iris()
X = iris.data[:, 2:]  # Petal length and width
y = iris.target
feature_names = iris.feature_names[2:]
class_names = iris.target_names

# Use a train/test split for real-world simulation
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=42)

# 2. Unconstrained Tree
dt_full = DecisionTreeClassifier(random_state=42)
dt_full.fit(X_train, y_train)
acc_full = accuracy_score(y_test, dt_full.predict(X_test))
print(f"Full Tree Test Accuracy: {acc_full:.4f}")

# 3. Constrained Tree
dt_pruned = DecisionTreeClassifier(max_depth=3, random_state=42)
dt_pruned.fit(X_train, y_train)
acc_pruned = accuracy_score(y_test, dt_pruned.predict(X_test))
print(f"Pruned (Depth 3) Tree Test Accuracy: {acc_pruned:.4f}")

# 4. Tree Visualization
plt.figure(figsize=(18, 10))
plot_tree(dt_pruned, 
          feature_names=feature_names, 
          class_names=class_names,
          filled=True, 
          impurity=True, 
          rounded=True)
plt.title("Decision Tree Visualization (Max Depth = 3)")
plt.show()

# 5. Purity Analysis (Based on training data: 112 samples)
total_samples = len(y_train)
class_counts = pd.Series(y_train).value_counts().sort_index()

# Class Distribution: 0 (Setosa), 1 (Versicolor), 2 (Virginica)
# Based on random_state=42 split: 37, 37, 38 samples respectively.
p0 = class_counts.get(0, 0) / total_samples
p1 = class_counts.get(1, 0) / total_samples
p2 = class_counts.get(2, 0) / total_samples

gini_root = 1 - (p0**2 + p1**2 + p2**2)

print("\n--- Purity Analysis ---")
print(f"Total Training Samples: {total_samples}")
print(f"Class Distribution (0, 1, 2): {class_counts.tolist()}")
print(f"Manually Calculated Root Gini Impurity: {gini_root:.4f}")

print("\nTheoretical Explanation of First Split:")
print("The root node starts with a Gini impurity of approximately 0.6667 (since classes are nearly balanced). The optimal first split is chosen to maximize information gain, which means minimizing the weighted average Gini impurity of the resulting child nodes.")
print("The visualization confirms that the first split is 'petal length (cm) <= 2.45'. This threshold perfectly isolates the Setosa class (Class 0), resulting in one child node with Gini=0 (pure). This massive reduction in impurity drives the decision process, making it the best possible initial split.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import matplotlib.pyplot as plt
from sklearn.datasets import make_moons
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import roc_auc_score
import numpy as np
import seaborn as sns
# Set style for better visualization
sns.set_style("whitegrid")

# Function to plot decision boundaries
def plot_boundaries(model, X, y, ax, title):
    h = .02  # step size in the mesh
    x_min, x_max = X[:, 0].min() - 0.5, X[:, 0].max() + 0.5
    y_min, y_max = X[:, 1].min() - 0.5, X[:, 1].max() + 0.5
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                         np.arange(y_min, y_max, h))
    
    # Predict on the mesh grid
    Z = model.predict(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    
    # Plot the contour and the training points
    ax.contourf(xx, yy, Z, alpha=0.4, cmap=plt.cm.RdBu)
    ax.scatter(X[:, 0], X[:, 1], c=y, cmap=plt.cm.RdBu, edgecolors='k', s=20)
    ax.set_title(title)
    ax.set_xticks(())
    ax.set_yticks(())

# 1. Data Generation
X, y = make_moons(n_samples=500, noise=0.35, random_state=42)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# 2. Model Training
lr_model = LogisticRegression(solver='liblinear', random_state=42)
dt_model = DecisionTreeClassifier(max_depth=5, random_state=42)

lr_model.fit(X_train, y_train)
dt_model.fit(X_train, y_train)

# 3. Decision Boundary Visualization
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

plot_boundaries(lr_model, X_test, y_test, axes[0], "Logistic Regression (Linear Boundary)")
plot_boundaries(dt_model, X_test, y_test, axes[1], "Decision Tree (Piecewise Boundary, Depth 5)")

plt.tight_layout()
plt.show()

# 4. Performance Comparison
lr_probs = lr_model.predict_proba(X_test)[:, 1]
dt_probs = dt_model.predict_proba(X_test)[:, 1]

lr_auc = roc_auc_score(y_test, lr_probs)
dt_auc = roc_auc_score(y_test, dt_probs)

print("\n--- Performance Metrics ---")
print(f"Logistic Regression ROC AUC: {lr_auc:.4f}")
print(f"Decision Tree (Max Depth 5) ROC AUC: {dt_auc:.4f}")

print("\n--- Discussion ---")
print("1. Visual Analysis: The LR model struggles because the optimal boundary is a straight line, forcing it to misclassify points in the central region where the two 'moons' overlap.")
print("2. Visual Analysis: The DT model creates complex, rectangular partitions that effectively wrap around the non-linear structure of the data, minimizing misclassification in the curved regions.")
print(f"3. Metric Comparison: The DT model achieves a significantly higher ROC AUC ({dt_auc:.4f} vs {lr_auc:.4f}), confirming its superiority in modeling non-linear classification tasks compared to the intrinsically linear LR model.")

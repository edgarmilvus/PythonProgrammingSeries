
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report, accuracy_score
from typing import Dict, Any

# --- 1. Configuration and Data Simulation ---
np.random.seed(42)
N_SAMPLES = 1000
CHURN_RATE = 0.25 # Target baseline churn rate

# Simulate features for a telecom company's customer base
def generate_customer_data(n_samples: int) -> pd.DataFrame:
    """Generates synthetic customer data with a classification target."""
    data = {
        # Feature 1: Monthly usage (continuous, normally distributed)
        'Monthly_Usage_Hours': np.random.normal(loc=150, scale=40, size=n_samples),
        # Feature 2: Support tickets (discrete, count data)
        'Support_Tickets': np.random.randint(0, 8, size=n_samples),
        # Feature 3: Contract length (continuous, uniformly distributed)
        'Contract_Months': np.random.randint(6, 60, size=n_samples),
    }
    
    df = pd.DataFrame(data)
    
    # Define a complex, partially non-linear relationship for Churn (Target = 1)
    # Churn is higher if usage is low AND contract is short (linear interaction),
    # OR if tickets are very high (non-linear threshold).
    base_churn = np.random.rand(n_samples) < CHURN_RATE
    low_usage_short_contract = (df['Monthly_Usage_Hours'] < 100) & (df['Contract_Months'] < 24)
    high_tickets = df['Support_Tickets'] >= 6
    
    # Combine conditions to create the binary target
    df['Churned'] = (base_churn | low_usage_short_contract | high_tickets).astype(int)
    
    return df

df = generate_customer_data(N_SAMPLES)

# Define features (X) and target (y)
X = df[['Monthly_Usage_Hours', 'Support_Tickets', 'Contract_Months']]
y = df['Churned']

# Split data into training and testing sets, ensuring balanced classes in both splits
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y
)

# --- 2. Feature Scaling (Mandatory for Logistic Regression) ---
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Retain feature names for interpretation steps
FEATURE_NAMES = X.columns.tolist()

print("--- Customer Churn Classification Analysis ---")

# --- 3. Model 1: Logistic Regression (Linear Probabilistic Model) ---
def run_logistic_regression(X_tr, y_tr, X_te, y_te, feature_names) -> Dict[str, Any]:
    """Trains, predicts, and interprets the Logistic Regression model."""
    log_reg_model = LogisticRegression(solver='liblinear', random_state=42, C=1.0)
    log_reg_model.fit(X_tr, y_tr)
    predictions = log_reg_model.predict(X_te)
    
    print("\n[A] Logistic Regression Performance:")
    print(f"Accuracy: {accuracy_score(y_te, predictions):.4f}")
    print("Classification Report:\n", classification_report(y_te, predictions, zero_division=0))
    
    # Interpretation: Coefficients show the linear relationship with the log-odds of churn
    coefficients = pd.Series(log_reg_model.coef_[0], index=feature_names)
    print("\n[C] Logistic Regression Feature Impact (Coefficients - Scaled Data):")
    print(coefficients.sort_values(ascending=False))
    
    return {"model": log_reg_model, "coefficients": coefficients}

log_reg_results = run_logistic_regression(X_train_scaled, y_train, X_test_scaled, y_test, FEATURE_NAMES)


# --- 4. Model 2: Decision Tree (Non-linear Partitioning Model) ---
def run_decision_tree(X_tr, y_tr, X_te, y_te, feature_names) -> Dict[str, Any]:
    """Trains, predicts, and interprets the Decision Tree model."""
    # DTs are non-parametric and scale-invariant, so we use the unscaled data (X_train, X_test)
    dt_model = DecisionTreeClassifier(max_depth=5, random_state=42, criterion='gini')
    dt_model.fit(X_tr, y_tr)
    predictions = dt_model.predict(X_te)
    
    print("\n[B] Decision Tree Performance:")
    print(f"Accuracy: {accuracy_score(y_te, predictions):.4f}")
    print("Classification Report:\n", classification_report(y_te, predictions, zero_division=0))
    
    # Interpretation: Feature importance based on total reduction in Gini impurity
    importance = pd.Series(dt_model.feature_importances_, index=feature_names)
    print("\n[D] Decision Tree Feature Importance (Gini Reduction):")
    print(importance.sort_values(ascending=False))
    
    return {"model": dt_model, "importance": importance}

dt_results = run_decision_tree(X_train, y_train, X_test, y_test, FEATURE_NAMES)

# --- 5. Comparative Summary ---
print("\n--- Comparative Summary ---")
print(f"LogReg Accuracy: {accuracy_score(y_test, log_reg_results['model'].predict(X_test_scaled)):.4f}")
print(f"DT (Max Depth 5) Accuracy: {accuracy_score(y_test, dt_results['model'].predict(X_test)):.4f}")

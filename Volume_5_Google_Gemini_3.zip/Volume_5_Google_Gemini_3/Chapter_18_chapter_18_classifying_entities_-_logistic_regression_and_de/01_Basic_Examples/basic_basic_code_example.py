
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

# --- 1. Data Generation ---
# Create a synthetic dataset for binary classification
# n_samples=300: Total number of data points
# n_features=2: Using two simple features (e.g., Credit Score, Debt Ratio)
# n_informative=2: Both features are useful for prediction
# n_redundant=0: No unnecessary features
# random_state=42: Ensures the same data is generated every time
X, y = make_classification(
    n_samples=300,
    n_features=2,
    n_informative=2,
    n_redundant=0,
    random_state=42
)

# Context: X holds feature matrix, y holds the binary target vector (0 or 1)

# --- 2. Data Splitting ---
# Split the data into training (80%) and testing (20%) sets
# Test data is reserved solely for unbiased model evaluation
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    random_state=42
)

# --- 3. Model 1: Logistic Regression (Linear Classifier) ---
# Initialize the Logistic Regression model
# This model estimates the probability of the positive class (y=1)
log_reg_model = LogisticRegression(random_state=42)

# Train the model: The algorithm finds the optimal weights (coefficients)
# that maximize the likelihood of observing the training data outcomes
log_reg_model.fit(X_train, y_train)

# Make predictions on the unseen test set
y_pred_log_reg = log_reg_model.predict(X_test)

# Evaluate accuracy (percentage of correct predictions)
accuracy_log_reg = accuracy_score(y_test, y_pred_log_reg)

# --- 4. Model 2: Decision Tree Classifier (Non-Linear Classifier) ---
# Initialize the Decision Tree model
# max_depth=5: Crucial hyperparameter to limit tree complexity and prevent overfitting
# The tree uses metrics like Gini impurity or entropy for splitting nodes
dt_model = DecisionTreeClassifier(max_depth=5, random_state=42)

# Train the model: The tree recursively partitions the feature space
# based on the best feature split at each node
dt_model.fit(X_train, y_train)

# Make predictions on the test set
y_pred_dt = dt_model.predict(X_test)

# Evaluate accuracy
accuracy_dt = accuracy_score(y_test, y_pred_dt)


# --- 5. Reporting Results and Inspection ---
print("--- Classification Model Comparison (Synthetic Data) ---")
print(f"Total Samples: {len(X)}")
print(f"Training Samples: {len(X_train)}")
print(f"Test Samples: {len(X_test)}")
print("-" * 60)
print(f"1. Logistic Regression Accuracy: {accuracy_log_reg:.4f}")
print(f"2. Decision Tree (Max Depth 5) Accuracy: {accuracy_dt:.4f}")

# Inspection: Displaying the learned parameters of the Linear Model
print("\n--- Logistic Regression Model Parameters ---")
# Coefficients (w1, w2) show the direction and strength of the linear relationship
print(f"Coefficients (Weights): {log_reg_model.coef_[0]}")
# Intercept (bias) is the baseline log-odds when all features are zero
print(f"Intercept (Bias): {log_reg_model.intercept_[0]:.4f}")

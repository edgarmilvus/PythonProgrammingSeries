
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
import logging

# Set up logging for informative output
logging.basicConfig(level=logging.INFO, format='%(message)s')

# --- Exercise 1 Solution: Standardized Data Scaling (Z-Score) ---

def standardize_data(data_array: np.ndarray) -> np.ndarray:
    """
    Calculates the Z-score for a dataset, standardizing each feature (column).
    Leverages reduction UFuncs and Broadcasting (via keepdims=True).
    """
    # 1. Calculate Mean and Std Deviation along axis 0 (columns/features)
    # keepdims=True ensures the output shapes are (1, 4) instead of (4,), 
    # which explicitly satisfies the broadcasting rule for (100, 4) - (1, 4).
    mu = np.mean(data_array, axis=0, keepdims=True)
    sigma = np.std(data_array, axis=0, keepdims=True)
    
    # Check for zero standard deviation (to prevent division by zero)
    # np.where is a UFunc used for conditional element selection/assignment
    sigma = np.where(sigma == 0, 1.0, sigma) 
    
    # 2. Apply Broadcasting: (100, 4) - (1, 4) / (1, 4) -> (100, 4)
    standardized_array = (data_array - mu) / sigma
    
    return standardized_array

# 1. Initialization
np.random.seed(42)
data_size = 100
feature_count = 4
# Create data with a non-zero mean and non-unit standard deviation
raw_data = np.random.randn(data_size, feature_count) * 15 + 50 

logging.info("--- Exercise 1: Z-Score Normalization ---")
logging.info(f"Original Data Shape: {raw_data.shape}")

# 3. Apply standardization
standardized_data_result = standardize_data(raw_data)

# 4. Verification
logging.info(f"Standardized Data Shape: {standardized_data_result.shape}")
logging.info("Verification (Mean of each feature - should be ~0):")
# Use np.round for cleaner output display
logging.info(np.round(np.mean(standardized_data_result, axis=0), 8)) 
logging.info("Verification (Std Dev of each feature - should be ~1):")
logging.info(np.round(np.std(standardized_data_result, axis=0), 8))


# --- Exercise 2 Solution: Vectorized Time-Series Deviation Analysis ---

logging.info("\n--- Exercise 2: Time-Series Deviation Analysis ---")

# 1. Data Setup (Simulated prices)
N_days = 50
np.random.seed(10)
# Start at 100, apply cumulative random daily returns (0.99 to 1.01)
daily_returns = np.random.uniform(0.99, 1.01, N_days - 1)
prices = np.zeros(N_days)
prices[0] = 100.0
# Use np.cumprod for vectorized cumulative calculation
prices[1:] = 100.0 * np.cumprod(daily_returns)

threshold = 0.035 # 3.5% deviation
penalty_value = -999.0

# 2. Percentage Change Calculation using Slicing
# Prices[1:] contains P_t (Day 1 to N-1)
# Prices[:-1] contains P_{t-1} (Day 0 to N-2)
daily_change = (prices[1:] - prices[:-1]) / prices[:-1]

# 3. Logical Masking (Absolute Change > Threshold)
change_mask_n_minus_1 = np.abs(daily_change) > threshold

# Align the mask to the original N-day sequence by prepending a False 
# (Day 0 has no prior change, so it cannot be flagged)
full_mask = np.insert(change_mask_n_minus_1, 0, False)

# 4. Conditional Assignment (np.where UFunc)
# If full_mask is True, assign penalty_value; otherwise, assign the original price
alerts_array = np.where(full_mask, penalty_value, prices)

# 5. Output
# np.sum on a boolean array counts the True values
flagged_count = np.sum(full_mask) 
logging.info(f"Total days analyzed: {N_days}")
logging.info(f"Critical threshold: {threshold * 100:.1f}%")
logging.info(f"Total flagged days (using logical UFuncs): {flagged_count}")
logging.info(f"Original Prices (First 10): {np.round(prices[:10], 2)}")
logging.info(f"Alerts Array (First 10):   {np.round(alerts_array[:10], 2)}")


# --- Exercise 3 Solution: Advanced Broadcasting Alignment Challenge ---

logging.info("\n--- Exercise 3: Advanced Broadcasting Alignment ---")

# 1. Data Initialization
np.random.seed(100)
N_sensors = 5
N_data_points = 10
N_time_steps = 8

# A: (5, 10, 8)
A = np.random.randint(1, 101, size=(N_sensors, N_data_points, N_time_steps))
# W: (8,)
W = np.random.uniform(0.1, 1.0, size=(N_time_steps,))

logging.info(f"Shape of Sensor Data A: {A.shape}")
logging.info(f"Shape of Time Weights W: {W.shape}")

# 2. Vectorized Multiplication
# NumPy implicitly expands W from (8,) to (1, 1, 8) to match A (5, 10, 8).
weighted_data_implicit = A * W

# 3. Shape Verification
logging.info(f"Shape of Result (A * W): {weighted_data_implicit.shape}")
logging.info("Broadcasting successful because W (8,) aligns with the trailing dimension of A (..., 8).")
logging.info(f"Example: A[0, 0, 0] ({A[0, 0, 0]}) * W[0] ({W[0]:.2f}) = {weighted_data_implicit[0, 0, 0]:.2f}")


# 4. Testing Failure: Reshaping W to (8, 1)
try:
    W_failure = W.reshape(N_time_steps, 1) # Shape (8, 1)
    logging.info(f"\nAttempting multiplication with W explicitly reshaped to: {W_failure.shape}")
    
    # A (5, 10, 8) vs W_failure (8, 1)
    # Alignment check (trailing dimensions first):
    # Dim 3: 8 vs 1 (OK, 1 expands to 8)
    # Dim 2: 10 vs 8 (FAIL, dimensions must be equal or one must be 1)
    A * W_failure 
except ValueError as e:
    logging.error(f"Broadcasting Error Encountered (Expected): {e}")
    logging.error("Explanation: Reshaping W to (8, 1) causes a mismatch on the second dimension (10 vs 8).")


# --- Exercise 4 Solution: Interactive Challenge - Financial Data Processor Enhancement ---

logging.info("\n--- Exercise 4: Vectorized Weighted Volatility (VWV) ---")

def calculate_vwv(data: np.ndarray, weights: np.ndarray) -> float:
    """
    Calculates the Vectorized Weighted Volatility (VWV) using a single matrix 
    (dot product) operation between the daily range vector and exponential weights.
    """
    if data.shape[0] != weights.shape[0]:
        raise ValueError("Data and Weights must have the same number of observations (rows).")
        
    # 1. Extract High (index 1) and Low (index 2) columns
    highs = data[:, 1]
    lows = data[:, 2]
    
    # 2. Calculate Daily Range (N,)
    daily_range = highs - lows
    
    # 3. Reshape Daily Range to (N, 1) for matrix multiplication
    range_vector = daily_range.reshape(-1, 1) # Shape (30, 1)
    
    # 4. Calculate VWV using Matrix Multiplication (Dot Product)
    # We want Weights^T @ Range_Vector.
    # np.dot(1D array, 2D array) performs the matrix multiplication correctly:
    # (30,) @ (30, 1) -> (1, 1) scalar result.
    vwv_result = np.dot(weights, range_vector)
    
    # Since np.dot returns a 1x1 array, extract the scalar value
    return vwv_result.item()

# 1. Data Simulation (30 days, OHLC format)
N_days_financial = 30
np.random.seed(200)
# Simulate prices
base_price = 150 + np.cumsum(np.random.randn(N_days_financial) * 0.5)
highs_sim = base_price + np.random.uniform(0.5, 2.0, N_days_financial)
lows_sim = base_price - np.random.uniform(0.5, 2.0, N_days_financial)
closes_sim = (highs_sim + lows_sim) / 2 + np.random.randn(N_days_financial) * 0.1

# Create OHLC data (Open, High, Low, Close)
Historical_Data = np.stack([base_price, highs_sim, lows_sim, closes_sim], axis=1)

# 2. Weight Generation (Exponential Decay: Newest data has highest weight)
# Create weights that decay from newest (end) to oldest (start)
decay_factor = np.linspace(0, 1, N_days_financial) # 0.0 to 1.0
Decay_Weights = np.exp(decay_factor * 3)
# Normalize weights so they sum to 1
Decay_Weights = Decay_Weights / np.sum(Decay_Weights)

logging.info(f"Historical Data Shape: {Historical_Data.shape}")
logging.info(f"Decay Weights Shape: {Decay_Weights.shape}")
logging.info(f"Weights (Oldest 5): {np.round(Decay_Weights[:5], 4)}")
logging.info(f"Weights (Newest 5): {np.round(Decay_Weights[-5:], 4)}")

# 5. Calculate VWV
vwv_index = calculate_vwv(Historical_Data, Decay_Weights)

logging.info(f"Calculated VWV Index (Scalar Result): {vwv_index:.4f}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np

# --- 1. Setup: Creating base arrays ---

# A simple 1-dimensional array (vector) representing daily temperatures for 4 days
temps_celsius = np.array([10, 15, 20, 25])
print(f"Original Celsius Temperatures (Shape {temps_celsius.shape}): {temps_celsius}")

# --- 2. Universal Function (UFunc) with Scalar Broadcasting ---

# Goal: Convert Celsius to Fahrenheit: F = C * 1.8 + 32
conversion_factor = 1.8  # Scalar value
offset = 32              # Scalar value

# Vectorized operation using UFuncs (np.multiply and np.add are implicitly used).
# NumPy broadcasts the scalar 1.8 and 32 across every element of temps_celsius.
temps_fahrenheit = temps_celsius * conversion_factor + offset
print(f"\nFahrenheit (Scalar Broadcasting Result): {temps_fahrenheit}")

# --- 3. Standard Vectorization (UFunc between equal shapes) ---

# A second array representing the predicted temperature change for the next day
temp_changes = np.array([2, -1, 3, 0])

# The subtraction operator uses the np.subtract UFunc.
# This performs true element-wise subtraction since both arrays have the same shape (4,).
yesterday_temps = temps_celsius - temp_changes
print(f"\nYesterday's Temps (Standard Vectorization Result): {yesterday_temps}")

# --- 4. Advanced Broadcasting (1D array against 2D array) ---

# A 2D array (Matrix) representing sensor readings over 3 hours (rows)
# for the 4 days (columns). Shape (3, 4)
sensor_readings = np.array([
    [1, 2, 3, 4],
    [5, 6, 7, 8],
    [9, 10, 11, 12]
])
print(f"\nSensor Readings (Shape {sensor_readings.shape}):\n{sensor_readings}")

# Broadcasting Rule: Adding the 1D 'temps_celsius' (shape 4,) to the 2D 'sensor_readings' (shape 3, 4).
# NumPy aligns the trailing dimensions (4 == 4) and stretches (broadcasts) the 1D array
# across the leading axis (axis 0, size 3).
adjusted_readings = sensor_readings + temps_celsius
print(f"\nAdjusted Readings (Advanced Broadcasting - 1D added to 2D, Shape {adjusted_readings.shape}):\n{adjusted_readings}")

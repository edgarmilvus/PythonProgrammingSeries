
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example_part6.py
# Description: Basic Code Example
# ==========================================

# Matrix (3 rows, 4 columns)
matrix_A = np.array([
    [10, 10, 10, 10],
    [20, 20, 20, 20],
    [30, 30, 30, 30]
]) # Shape (3, 4)

# Hourly offset (3 elements)
vector_B = np.array([1, 2, 3]) # Shape (3,)

# Attempted operation: matrix_A + vector_B
# NumPy checks trailing dimensions: 4 vs 3. They are neither equal nor is one 1.
# This results in a ValueError.

try:
    result = matrix_A + vector_B
except ValueError as e:
    print(f"\n--- COMMON PITFALL DEMONSTRATION ---")
    print(f"Error encountered: {e}")
    print(f"Shapes are incompatible: (3, 4) vs (3,)")
    print(f"Trailing dimensions 4 and 3 do not match.")

# --- The Fix: Explicit Reshaping ---
# If the intent was to add the offset to each row (i.e., [1, 2, 3] is applied to the first, second, and third row respectively),
# we must explicitly reshape vector_B to have a trailing dimension of 1.
# Reshaping (3,) to (3, 1) means we have 3 rows and 1 column.

vector_B_fixed = vector_B.reshape((3, 1)) # Shape (3, 1)

# Now check compatibility:
# Matrix_A (3, 4) vs Vector_B_fixed (3, 1)
# Trailing Dimension (Axis 1): 4 vs 1. Compatible (one is 1).
# Leading Dimension (Axis 0): 3 vs 3. Match.

fixed_result = matrix_A + vector_B_fixed
print(f"\n--- FIXED BROADCASTING (Shape (3, 1) added to (3, 4)) ---")
print(f"Fixed Vector B Shape: {vector_B_fixed.shape}\n{vector_B_fixed}")
print(f"Result:\n{fixed_result}")

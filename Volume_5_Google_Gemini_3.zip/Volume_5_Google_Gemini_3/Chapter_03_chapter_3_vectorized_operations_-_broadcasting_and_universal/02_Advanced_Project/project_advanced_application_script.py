
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np

# --- Configuration and Data Generation ---
ASSET_COUNT = 5
DAYS = 100
ASSET_NAMES = [f"Asset_{i+1}" for i in range(ASSET_COUNT)]

# Set a seed for reproducibility
np.random.seed(42)

# 1. Generate synthetic daily returns data (100 days, 5 assets)
# Data represents percentage returns (e.g., 0.015 = 1.5%)
# Shape: (100, 5)
daily_returns = np.random.normal(loc=0.0005, scale=0.015, size=(DAYS, ASSET_COUNT))

# Apply a mild clipping UFunc to handle outliers slightly
daily_returns = np.clip(daily_returns, a_min=-0.05, a_max=0.05)

# Define portfolio weights (must sum to 1.0)
# Shape: (5,)
portfolio_weights = np.array([0.25, 0.15, 0.30, 0.10, 0.20]) 

print(f"Data Matrix Shape (Days x Assets): {daily_returns.shape}")
print(f"Weights Vector Shape: {portfolio_weights.shape}\n")

# --- Step 1: Calculating Baseline Statistics using Reduction UFuncs ---

# Calculate the mean return for each asset (across all 100 days).
# np.mean is a reduction UFunc. Resulting shape: (5,)
asset_means = np.mean(daily_returns, axis=0)
print(f"Asset Means: {asset_means}")

# Calculate the standard deviation (volatility) for each asset.
# Resulting shape: (5,)
asset_stds = np.std(daily_returns, axis=0)
print(f"Asset Standard Deviations: {asset_stds}\n")

# --- Step 2: Standardization (Z-Score Calculation) using Broadcasting ---
# Z = (X - mu) / sigma

# 2a. Mean Adjustment: daily_returns (100, 5) - asset_means (5,)
# Broadcasting Rule: The (5,) vector is automatically stretched across the 100 rows.
mean_adjusted_returns = daily_returns - asset_means 
    
# 2b. Standardization: mean_adjusted_returns (100, 5) / asset_stds (5,)
# Broadcasting Rule: The (5,) vector is again stretched across the 100 rows.
z_scores = mean_adjusted_returns / asset_stds
    
print(f"Z-Score Matrix Shape: {z_scores.shape}")
print(f"First row of Z-Scores (Standardized Risk):\n{z_scores[0]}\n")

# --- Step 3: Calculating Weighted Risk Contribution (Broadcasting) ---

# Multiply Z-scores (standardized risk) by portfolio weights.
# z_scores (100, 5) * portfolio_weights (5,)
# NumPy implicitly reshapes (5,) to (1, 5) for element-wise multiplication.
weighted_risk_contribution = z_scores * portfolio_weights
    
# Calculate the total standardized portfolio risk for each day (Sum across assets).
# Resulting shape: (100,)
daily_portfolio_risk = np.sum(weighted_risk_contribution, axis=1)

print(f"Daily Portfolio Risk Shape: {daily_portfolio_risk.shape}")
print(f"Mean Daily Portfolio Risk: {np.mean(daily_portfolio_risk):.4f}\n")

# --- Step 4: Analyzing Risk Deviation Relative to a Benchmark (Advanced Broadcasting) ---

# Define a dynamic benchmark: the average Z-score across all assets for that specific day.
# Using keepdims=True ensures the result is (100, 1), forcing explicit Broadcasting Rule 1.
daily_z_benchmark = np.mean(z_scores, axis=1, keepdims=True)
    
# Calculate the deviation of each asset's Z-score from the daily benchmark.
# z_scores (100, 5) - daily_z_benchmark (100, 1)
# Broadcasting occurs: The (100, 1) benchmark is stretched across the 5 columns.
risk_deviation_matrix = z_scores - daily_z_benchmark
    
print(f"Risk Deviation Matrix Shape: {risk_deviation_matrix.shape}")
print(f"Deviation of Asset 3 (Index 2) on Day 1: {risk_deviation_matrix[0, 2]:.4f}")

# Use a Boolean UFunc (np.greater) to count significant deviations.
# We check if Asset 3's risk deviation exceeds 1.0 standard deviation.
asset_3_deviation = risk_deviation_matrix[:, 2]
significant_deviation_days = np.greater(np.abs(asset_3_deviation), 1.0)
    
# np.sum acts as a counter for True values (which are treated as 1).
count_significant = np.sum(significant_deviation_days)
    
print(f"\nAsset 3 showed a risk deviation > 1.0 SD on {count_significant} out of {DAYS} days.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# Set a consistent style for all plots
sns.set_theme(style="whitegrid")
# Set default figure size for better visualization
plt.rcParams['figure.figsize'] = (12, 6)

# --- Exercise 1: Comprehensive Univariate Distribution Analysis ---
print("--- Running Exercise 1: Univariate Distribution Analysis ---")

# 1. Data Generation (Positively skewed financial data)
np.random.seed(42)
# Use lognormal to simulate positive skewness, then subtract a constant to center the data
volatility_data = pd.Series(np.random.lognormal(mean=0.0, sigma=0.5, size=365) - 1.0) 

# Create the figure and subplots (1 row, 2 columns)
fig, axes = plt.subplots(1, 2, figsize=(15, 6))

# 2. Distribution Plot (Histogram + Overlaid KDE)
# Plot the histogram using density scale
sns.histplot(
    volatility_data, 
    bins=25, 
    ax=axes[0], 
    color="skyblue", 
    label="Histogram", 
    stat="density"
)
# Overlay the KDE plot separately for distinct styling
sns.kdeplot(
    volatility_data, 
    ax=axes[0], 
    color="red", 
    linewidth=2, 
    label="KDE Estimate"
)
# 4. Annotation
axes[0].set_title('Distribution of Daily Volatility (Histogram & KDE)')
axes[0].legend()

# 3. Outlier Visualization (Box Plot)
sns.boxplot(
    x=volatility_data, 
    ax=axes[1], 
    orient='h', 
    color='lightcoral'
)
# 4. Annotation
axes[1].set_title('Outlier Detection using Box Plot')

# Calculate and annotate IQR bounds for context
Q1 = volatility_data.quantile(0.25)
Q3 = volatility_data.quantile(0.75)
IQR = Q3 - Q1
upper_bound = Q3 + 1.5 * IQR
outliers = volatility_data[volatility_data > upper_bound]
axes[1].text(0.05, 0.9, 
             f"IQR: {IQR:.3f}\nUpper Bound: {upper_bound:.3f}\nOutliers detected: {len(outliers)}", 
             transform=axes[1].transAxes, 
             fontsize=9, 
             ha='left', 
             bbox=dict(facecolor='white', alpha=0.6))

plt.tight_layout()
# plt.show()


# --- Exercise 2: Conditional Regression and Faceting with lmplot ---
print("\n--- Running Exercise 2: Conditional Regression Analysis ---")

# 1. Load Data
penguins = sns.load_dataset("penguins")
# Handle missing data by dropping rows with NaNs in relevant columns
penguins_clean = penguins.dropna(subset=['flipper_length_mm', 'body_mass_g', 'species'])

# 2. & 3. Faceted Regression Plot using lmplot
g = sns.lmplot(
    data=penguins_clean,
    x="flipper_length_mm",
    y="body_mass_g",
    col="species",    # Facet by species (columns)
    hue="species",    # Color by species (ensuring distinct colors)
    height=5,
    aspect=0.9,
    scatter_kws={'alpha': 0.7},
    line_kws={'linewidth': 3}
)

g.fig.suptitle("Flipper Length vs. Body Mass, Conditioned by Species", y=1.02)

# 4. Interpretation
# The plot clearly shows that while all species exhibit a strong positive correlation 
# (longer flippers mean heavier bodies), the intercept and overall scale (body mass range) 
# are unique to each species (especially Gentoo being much heavier).
print("Interpretation (E2): The strong positive correlation between flipper length and body mass is consistent across all three species, but the scale and intercept are distinct, confirming that species is a significant factor in the relationship.")

# plt.show()


# --- Exercise 3: Advanced Correlation Heatmap for Feature Selection ---
print("\n--- Running Exercise 3: Advanced Correlation Heatmap ---")

# 1. Data Preparation
iris = sns.load_dataset("iris")
# Calculate Pearson correlation matrix for numerical columns
corr_matrix = iris.drop(columns=['species']).corr(method='pearson')

# 2. Mask Generation (Upper Triangle)
# np.ones_like creates a matrix of 1s matching the shape of corr_matrix
# np.triu (triangle upper) sets the values in the upper triangle (including diagonal) to True
mask = np.triu(np.ones_like(corr_matrix, dtype=bool))

# 3. Heatmap Generation
plt.figure(figsize=(8, 7))
sns.heatmap(
    corr_matrix,
    mask=mask,              # Apply the mask to hide the upper triangle
    cmap='vlag',            # Use a divergent colormap
    vmin=-1, vmax=1,        # Set symmetric limits around zero
    annot=True,             # Display correlation values
    fmt=".2f",              # Format annotations to two decimal places
    linewidths=.5,
    cbar_kws={"shrink": .8}
)

# 4. Aesthetic Refinement
plt.yticks(rotation=0)
plt.xticks(rotation=45, ha='right')
plt.title("Masked Correlation Heatmap of Iris Features", pad=20)
plt.tight_layout()

# plt.show()


# --- Exercise 4: Interactive Challenge - Enhancing Financial Volatility Analysis ---
print("\n--- Running Exercise 4: Interactive Challenge (JointGrid) ---")

# 1. Setup: Synthetic Financial Data
np.random.seed(42)
data_size = 250
financial_data = pd.DataFrame({
    # Daily Return (Normal distribution around 0.1% mean)
    'Daily_Return': np.random.normal(loc=0.001, scale=0.015, size=data_size),
    # Risk Score (Positive, truncated normal distribution around 50)
    'Risk_Score': np.abs(np.random.normal(loc=50, scale=10, size=data_size))
})

# 2. JointGrid Initialization
g = sns.JointGrid(
    data=financial_data, 
    x="Daily_Return", 
    y="Risk_Score", 
    height=7
)

# 3. Central Plot: Scatter Plot with Regression Line
# Use regplot for the joint area
g.plot_joint(
    sns.regplot, 
    scatter_kws={'alpha': 0.6, 'color': 'darkblue'}, 
    line_kws={'color': 'red'}
)

# 4. Marginal Plots: KDE (X) and Histogram (Y)
# Marginal X (Top) - KDE Plot
g.plot_marginals(
    sns.kdeplot, 
    color="darkblue", 
    fill=True, 
    alpha=0.5,
    ax=g.ax_marg_x
)

# Marginal Y (Right) - Histogram
g.plot_marginals(
    sns.histplot, 
    bins=15, 
    color="green", 
    ax=g.ax_marg_y
)

# 5. Finalization
g.ax_joint.set_title('Joint Analysis of Daily Return vs. Risk Score', fontsize=14, pad=15)
g.set_axis_labels(xlabel="Daily Return (%)", ylabel="Risk Score (0-100)")

plt.tight_layout()
# plt.show()

print("\nAll exercises completed.")

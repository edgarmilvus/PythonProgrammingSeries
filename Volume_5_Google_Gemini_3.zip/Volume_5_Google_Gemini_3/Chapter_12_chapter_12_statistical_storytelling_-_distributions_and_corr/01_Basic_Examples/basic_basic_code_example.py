
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# 1. Data Acquisition and Preparation
# Seaborn provides built-in datasets for quick testing and examples.
# We load the 'iris' dataset directly into a Pandas DataFrame.
iris_df = sns.load_dataset('iris')

# Display the first few rows to confirm structure
print("--- Data Snapshot ---")
print(iris_df.head())
print("-" * 25)

# 2. Univariate Visualization: Understanding Distribution
# We want to see how 'sepal_length' is distributed across the entire dataset.
# We use Matplotlib's subplot system to place multiple graphs side-by-side.
plt.figure(figsize=(14, 6)) # Set the overall size of the figure (canvas)

# Subplot 1: Distribution of Sepal Length
plt.subplot(1, 2, 1) # 1 row, 2 columns, plot index 1

# Use histplot to create a histogram.
# x='sepal_length': Specifies the column to plot.
# kde=True: Overlays a Kernel Density Estimate line for smoothing.
sns.histplot(data=iris_df, x='sepal_length', kde=True, color='skyblue', edgecolor='black')
plt.title('A) Distribution of Sepal Length (Univariate Analysis)', fontsize=14)
plt.xlabel('Sepal Length (cm)')
plt.ylabel('Frequency / Density')


# 3. Bivariate Visualization: Mapping Correlation
# We want to see the relationship between 'sepal_length' (predictor) and 'petal_length' (outcome).
plt.subplot(1, 2, 2) # 1 row, 2 columns, plot index 2

# Use scatterplot to map the relationship between two continuous variables.
# hue='species': Maps the third, categorical variable to color, adding multivariate depth.
sns.scatterplot(data=iris_df, x='sepal_length', y='petal_length', 
                hue='species', s=70, alpha=0.8) # s=size, alpha=transparency

plt.title('B) Sepal Length vs. Petal Length (Bivariate Analysis)', fontsize=14)
plt.xlabel('Sepal Length (cm)')
plt.ylabel('Petal Length (cm)')

# 4. Final Display and Formatting
plt.legend(title='Iris Species', loc='upper left') # Ensure the legend is visible
plt.tight_layout() # Automatically adjusts subplot params for specified padding
plt.show()

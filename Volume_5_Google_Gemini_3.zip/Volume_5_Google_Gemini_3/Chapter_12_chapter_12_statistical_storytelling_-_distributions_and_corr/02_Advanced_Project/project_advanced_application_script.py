
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# --- Configuration and Setup ---

def setup_visualization_environment():
    """Sets up Seaborn style and Matplotlib parameters for professional plotting."""
    # Use the 'whitegrid' style for clear separation of data points
    sns.set_theme(style="whitegrid")
    # Define a default figure size
    plt.rcParams['figure.figsize'] = (10, 6)
    print("Visualization environment initialized using Seaborn theme.")

def generate_ecom_data(n_samples=1500):
    """Creates synthetic e-commerce data designed to exhibit clear correlations."""
    np.random.seed(42)
    
    # 1. Base Predictor: Avg minutes spent per session (normally distributed)
    avg_time = np.random.normal(loc=15, scale=5, size=n_samples) 
    # 2. Secondary Predictor: Reviews posted (Poisson distributed, count data)
    reviews = np.random.poisson(lam=3, size=n_samples) 
    
    # 3. Target Variable: CLV (designed to be highly correlated with time and reviews)
    clv_base = 50 + (avg_time * 15) + (reviews * 50) 
    clv_noise = np.random.normal(loc=0, scale=80, size=n_samples)
    # Applying maximum ensures CLV remains financially realistic (above $50)
    clv = np.maximum(50, clv_base + clv_noise) 

    # 4. Categorical Feature: Segmenting customers based on activity level
    segment = np.select(
        [avg_time < 10, avg_time >= 20],
        ['Low Activity', 'High Activity'],
        default='Medium Activity'
    )
    
    data = pd.DataFrame({
        'Avg_Time_Spent_Min': avg_time,
        'Reviews_Posted': reviews,
        'Customer_Lifetime_Value': clv,
        'Customer_Segment': segment
    })
    
    return data.round(2)

# --- Core Statistical Storytelling Functions ---

def analyze_univariate_distributions(df):
    """Visualizes the distribution shape and checks for segment-based outliers."""
    
    # A. KDE Plot: Ideal for visualizing the probability density function (shape)
    plt.figure(figsize=(12, 5))
    sns.kdeplot(
        data=df, 
        x='Customer_Lifetime_Value', 
        hue='Customer_Segment', # Separate distributions by segment
        fill=True, 
        alpha=.4, 
        linewidth=2
    )
    plt.title('A1. CLV Distribution by Customer Segment')
    plt.show()

    # B. Boxenplot (Letter-value plot): Better than standard boxplots for large N
    plt.figure(figsize=(10, 6))
    sns.boxenplot(
        data=df, 
        x='Customer_Segment', 
        y='Customer_Lifetime_Value', 
        order=['Low Activity', 'Medium Activity', 'High Activity'],
        palette="Spectral"
    )
    plt.title('A2. CLV Outlier and Quartile Analysis by Segment')
    plt.show()

def analyze_bivariate_relationships(df):
    """Examines the linear relationship between time spent and CLV using regression."""
    
    # Regplot: Combines a scatter plot with a linear regression fit line
    plt.figure(figsize=(10, 7))
    sns.regplot(
        data=df, 
        x='Avg_Time_Spent_Min', 
        y='Customer_Lifetime_Value',
        scatter_kws={'alpha': 0.2, 'color': 'gray'}, # Reduce scatter opacity
        line_kws={'color': 'darkred', 'linewidth': 3, 'linestyle': '--'} # Highlight the fit
    )
    plt.title('B. Linear Correlation: Time Spent vs. Customer Lifetime Value')
    plt.xlabel('Average Time Spent (Minutes)')
    plt.ylabel('Customer Lifetime Value ($)')
    plt.show()

def visualize_full_correlation(df):
    """Calculates and visualizes the full correlation matrix using a heatmap."""
    
    # Select only numeric columns for correlation calculation
    numeric_df = df.select_dtypes(include=np.number)
    
    # Calculate Pearson correlation matrix
    correlation_matrix = numeric_df.corr()
    
    # Heatmap Visualization: The ultimate tool for multivariate correlation storytelling
    plt.figure(figsize=(8, 7))
    sns.heatmap(
        correlation_matrix, 
        annot=True, # Display the correlation coefficient on the map
        cmap='vlag', # Choose a diverging color palette (good for correlation)
        fmt=".2f", # Format annotations to two decimal places
        center=0, # Center the color scale at 0 (no correlation)
        linewidths=.5 
    )
    plt.title('C. Correlation Heatmap of E-commerce Metrics')
    plt.show()

# --- Execution ---
if __name__ == "__main__":
    setup_visualization_environment()
    ecom_df = generate_ecom_data(n_samples=1500)
    
    print(f"\nData Snapshot (N={len(ecom_df)}):\n{ecom_df.head()}")
    
    # 1. Distribution Analysis
    print("\n--- Step 1: Analyzing Distributions (Univariate Story) ---")
    analyze_univariate_distributions(ecom_df)
    
    # 2. Relationship Analysis
    print("\n--- Step 2: Analyzing Relationships (Bivariate Story) ---")
    analyze_bivariate_relationships(ecom_df)
    
    # 3. Full Correlation Analysis
    print("\n--- Step 3: Analyzing Full Correlation (Multivariate Story) ---")
    visualize_full_correlation(ecom_df)

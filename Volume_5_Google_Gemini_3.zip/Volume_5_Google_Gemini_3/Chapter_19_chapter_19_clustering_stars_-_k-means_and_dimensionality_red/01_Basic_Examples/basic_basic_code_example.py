
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np
import pandas as pd
import sys
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from typing import Dict, Any, List

# --- Configuration and Data Generation ---

def generate_star_data(seed: int = 42) -> pd.DataFrame:
    """Generates synthetic, high-dimensional stellar data."""
    # Set a random seed for reproducibility (POLA)
    np.random.seed(seed)

    # Simulate two distinct groups of stars (e.g., Main Sequence vs. Giants)
    # Group 1 (10 samples): Cooler, lower mass, lower luminosity
    # Group 2 (10 samples): Hotter, higher mass, higher luminosity
    data: Dict[str, Any] = {
        # Luminosity (Large range difference)
        'Luminosity': np.concatenate([np.random.normal(10, 2, 10), np.random.normal(25, 3, 10)]),
        # Temperature (Large range difference)
        'Temperature': np.concatenate([np.random.normal(4500, 500, 10), np.random.normal(8500, 800, 10)]),
        # Mass (Moderate range difference)
        'Mass': np.concatenate([np.random.uniform(0.5, 2, 10), np.random.uniform(5, 10, 10)]),
        # Metallicity (Small range difference)
        'Metallicity': np.concatenate([np.random.normal(0.1, 0.05, 10), np.random.normal(0.5, 0.1, 10)])
    }
    return pd.DataFrame(data)

def main():
    """Executes the PCA and K-Means workflow."""
    df = generate_star_data()

    # Early exit check (Robustness)
    if df.empty or df.shape[0] < 5:
        print("Error: DataFrame is empty or too small for analysis.")
        sys.exit(1)

    print(f"Original Data Shape: {df.shape}")
    print(f"Original Features:\n{df.head(2).to_string(index=False)}\n")

    # --- Step 1: Data Preprocessing (Scaling) ---

    # PCA is highly sensitive to the magnitude of features.
    # Standardization (Z-score scaling) ensures all features contribute equally to variance calculation.
    scaler = StandardScaler()
    scaled_features = scaler.fit_transform(df)

    # --- Step 2: Dimensionality Reduction using PCA ---

    # We aim to reduce the 4 features down to 2 principal components (PC1 and PC2).
    N_COMPONENTS = 2
    pca = PCA(n_components=N_COMPONENTS, random_state=42)

    # Fit PCA to the scaled data and transform it into the new component space.
    principal_components = pca.fit_transform(scaled_features)

    # Create a new DataFrame for the reduced data for clarity.
    pca_df = pd.DataFrame(
        data=principal_components,
        columns=[f'PC{i+1}' for i in range(N_COMPONENTS)]
    )

    # Analyze the PCA results
    print("--- PCA Analysis ---")
    explained_variance = pca.explained_variance_ratio_
    print(f"Explained Variance Ratio (PC1): {explained_variance[0]:.4f}")
    print(f"Explained Variance Ratio (PC2): {explained_variance[1]:.4f}")
    print(f"Total Variance Retained: {explained_variance.sum():.4f}\n")


    # --- Step 3: Clustering using K-Means ---

    # We choose K=2 clusters, matching the two groups we simulated.
    K = 2
    # n_init='auto' is the modern standard, replacing explicit integer counts.
    kmeans = KMeans(n_clusters=K, random_state=42, n_init='auto')

    # Apply K-Means to the dimensionally reduced data (pca_df).
    # Clustering 2D data is faster and often yields cleaner boundaries than 4D data.
    kmeans.fit(pca_df)

    # Get the cluster labels assigned to each sample
    cluster_labels = kmeans.labels_

    # --- Step 4: Output and Analysis ---

    # Add the cluster labels back to the PCA DataFrame
    pca_df['Cluster'] = cluster_labels
    
    # Identify the unique clusters found
    unique_clusters: List[int] = sorted(pca_df['Cluster'].unique())

    print("--- K-Means Clustering Results (First 5 Samples) ---")
    print(pca_df.head())
    
    print(f"\nSuccessfully identified {len(unique_clusters)} clusters:")
    for cluster_id in unique_clusters:
        count = (pca_df['Cluster'] == cluster_id).sum()
        print(f"  Cluster {cluster_id}: {count} samples")
    
    print("\nWorkflow complete: Scaling -> PCA (4D to 2D) -> K-Means.")

if __name__ == "__main__":
    main()

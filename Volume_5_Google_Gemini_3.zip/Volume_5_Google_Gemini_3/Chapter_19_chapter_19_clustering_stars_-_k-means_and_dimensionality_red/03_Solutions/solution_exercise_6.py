
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_6.py
# Description: Solution for Exercise 6
# ==========================================

import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import calinski_harabasz_score
from sklearn.datasets import make_blobs
import pandas as pd # Used for clearer loading display in E5

# Set plotting style for consistency
plt.style.use('seaborn-v0_8-whitegrid')

# --- Configuration and Utility Functions ---

def generate_stellar_data(n_samples=800, n_features=12, random_state=42):
    """
    Generates synthetic stellar data with correlated features suitable for PCA.
    Features 1-4 (Mass, Age, Luminosity, Temp) are strongly correlated.
    Features 5-8 (Metallicity, Colors) are moderately correlated.
    """
    np.random.seed(random_state)
    
    # 1. Core Stellar Properties (High correlation)
    # Using specific centers to create distinct groups
    X1, _ = make_blobs(n_samples=n_samples, n_features=4, centers=4, cluster_std=1.5, random_state=random_state)
    
    # 2. Composition/Atmospheric Properties (Moderate correlation)
    X2, _ = make_blobs(n_samples=n_samples, n_features=4, centers=3, cluster_std=1.0, random_state=random_state + 1)
    
    # 3. Dynamic Properties (Low correlation/Noise)
    X3 = np.random.randn(n_samples, 4) * 0.5
    
    X = np.hstack((X1, X2, X3))
    
    FEATURE_NAMES = [
        'Mass', 'Age', 'Luminosity', 'Temperature', 
        'Metallicity', 'X_Color', 'Y_Color', 'Z_Color', 
        'Rotation_Rate', 'Magnetic_Field', 'Gravity', 'Velocity'
    ]
    
    print(f"Generated data shape: {X.shape}")
    return X, FEATURE_NAMES

def evaluate_clustering(data, labels):
    """
    Calculates the Calinski-Harabasz Index for clustering evaluation.
    (Required for Exercise 3)
    """
    # Check for minimum requirements: at least 2 samples and 2 clusters
    if data.shape[0] < 2 or len(np.unique(labels)) < 2:
        return 0.0
    return calinski_harabasz_score(data, labels)

# --- Main Execution Block ---

if __name__ == "__main__":
    
    # Generate Data (Used for all exercises)
    X_raw, FEATURE_NAMES = generate_stellar_data(n_samples=800, n_features=12)
    
    # Initialize Scaler
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_raw)

    # --- Exercise 1: Determining Intrinsic Dimensionality ---
    print("\n--- Exercise 1: Determining Intrinsic Dimensionality ---")
    
    pca_full = PCA(n_components=None)
    pca_full.fit(X_scaled)
    
    explained_variance = pca_full.explained_variance_ratio_
    cumulative_variance = np.cumsum(explained_variance)
    
    # Find components for 95% variance
    threshold = 0.95
    # np.argmax finds the first index where the condition is True. We add 1 for component count.
    n_components_95 = np.argmax(cumulative_variance >= threshold) + 1
    
    print(f"Cumulative Variance: {cumulative_variance}")
    print(f"Minimum components needed for {threshold*100}% variance: {n_components_95}")
    print(f"Interpretation: Reduced 12 dimensions to {n_components_95} while retaining 95% variance.")
    
    # Plotting the Scree Plot
    plt.figure(figsize=(10, 5))
    plt.plot(range(1, len(cumulative_variance) + 1), cumulative_variance, marker='o', linestyle='--', color='b')
    plt.axhline(threshold, color='r', linestyle='-', label=f'{threshold*100}% Threshold')
    plt.axvline(n_components_95, color='g', linestyle=':', label=f'N={n_components_95} Components')
    plt.title('Scree Plot: Cumulative Explained Variance')
    plt.xlabel('Number of Principal Components')
    plt.ylabel('Cumulative Explained Variance Ratio')
    plt.legend()
    plt.grid(True, which='both', linestyle='--', linewidth=0.5)
    plt.show()

    # --- Exercise 2: Robustness and Scaling Impact on PCA Loadings ---
    print("\n--- Exercise 2: Robustness and Scaling Impact on PCA Loadings ---")
    
    robust_scaler = RobustScaler()
    X_robust = robust_scaler.fit_transform(X_raw)
    
    pca_std = PCA(n_components=3).fit(X_scaled)
    pca_robust = PCA(n_components=3).fit(X_robust)
    
    pc1_std_loadings = pca_std.components_[0]
    pc1_robust_loadings = pca_robust.components_[0]
    
    print("StandardScaler PC1 Loadings (Absolute Magnitude):")
    for name, loading in zip(FEATURE_NAMES, pc1_std_loadings):
        print(f"  {name:15}: {loading:.4f}")
        
    print("\nRobustScaler PC1 Loadings (Absolute Magnitude):")
    for name, loading in zip(FEATURE_NAMES, pc1_robust_loadings):
        print(f"  {name:15}: {loading:.4f}")

    # Plotting Comparison
    x_axis = np.arange(len(FEATURE_NAMES))
    width = 0.35
    
    plt.figure(figsize=(14, 6))
    plt.bar(x_axis - width/2, pc1_std_loadings, width, label='StandardScaler PC1', alpha=0.7, color='skyblue')
    plt.bar(x_axis + width/2, pc1_robust_loadings, width, label='RobustScaler PC1', alpha=0.7, color='salmon')
    
    plt.xticks(x_axis, FEATURE_NAMES, rotation=45, ha="right")
    plt.ylabel('PC1 Loading Factor')
    plt.title('Comparison of PC1 Loadings: StandardScaler vs. RobustScaler')
    plt.legend()
    plt.tight_layout()
    plt.show()
    
    print("\nAnalysis required in the written solution section.")

    # --- Exercise 3: Interactive Challenge: Calinski-Harabasz Comparison ---
    print("\n--- Exercise 3: Interactive Challenge: Calinski-Harabasz Comparison ---")
    
    K_fixed = 4
    N_pca = 3 

    # Pipeline 1: Baseline (Full 12D data)
    kmeans_12d = KMeans(n_clusters=K_fixed, random_state=42, n_init='auto').fit(X_scaled)
    labels_12d = kmeans_12d.labels_
    score_12d = evaluate_clustering(X_scaled, labels_12d)
    
    # Pipeline 2: PCA-Optimized (Reduced 3D data)
    pca_3d = PCA(n_components=N_pca).fit(X_scaled)
    X_reduced = pca_3d.transform(X_scaled)
    
    kmeans_3d = KMeans(n_clusters=K_fixed, random_state=42, n_init='auto').fit(X_reduced)
    labels_3d = kmeans_3d.labels_
    score_3d = evaluate_clustering(X_reduced, labels_3d)

    print(f"Calinski-Harabasz Index (Pipeline 1, Baseline 12D): {score_12d:.2f}")
    print(f"Calinski-Harabasz Index (Pipeline 2, PCA-Optimized 3D): {score_3d:.2f}")

    if score_3d > score_12d:
        print("\nConclusion: PCA improved the intrinsic cluster quality (higher CH score).")
    elif score_3d < score_12d:
        print("\nConclusion: PCA slightly worsened the intrinsic cluster quality (lower CH score).")
    else:
        print("\nConclusion: PCA had a neutral effect on cluster quality.")
        
    # --- Exercise 4: Visualizing the K-Means Decision Boundary in Reduced Space ---
    print("\n--- Exercise 4: Visualizing the K-Means Decision Boundary in Reduced Space ---")
    
    N_plot = 2
    pca_2d = PCA(n_components=N_plot).fit(X_scaled)
    X_plot_2d = pca_2d.transform(X_scaled)
    
    kmeans_2d = KMeans(n_clusters=4, random_state=42, n_init='auto').fit(X_plot_2d)
    labels_2d = kmeans_2d.labels_
    centroids = kmeans_2d.cluster_centers_

    # Determine grid boundaries
    x_min, x_max = X_plot_2d[:, 0].min() - 1, X_plot_2d[:, 0].max() + 1
    y_min, y_max = X_plot_2d[:, 1].min() - 1, X_plot_2d[:, 1].max() + 1
    
    # Create meshgrid for prediction
    xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.1), # Step size reduced for faster plotting
                         np.arange(y_min, y_max, 0.1))

    # Predict labels for every point in the grid
    Z = kmeans_2d.predict(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)

    # Plotting the decision boundaries
    plt.figure(figsize=(10, 7))
    
    # Plot the decision boundaries
    plt.contourf(xx, yy, Z, alpha=0.4, cmap=plt.cm.get_cmap('viridis', 4))
    
    # Scatter plot of the actual data points
    scatter = plt.scatter(X_plot_2d[:, 0], X_plot_2d[:, 1], c=labels_2d, s=40, cmap=plt.cm.get_cmap('viridis', 4), edgecolors='k', linewidths=0.5)
    
    # Plot the centroids
    plt.scatter(centroids[:, 0], centroids[:, 1], marker='X', s=250, linewidths=3, color='red', label='Centroids', zorder=10)
    
    plt.title('K-Means Clustering (K=4) in 2D PCA Subspace with Decision Boundaries')
    plt.xlabel('Principal Component 1')
    plt.ylabel('Principal Component 2')
    
    # Create a colorbar/legend for the clusters
    cbar = plt.colorbar(scatter, ticks=range(4))
    cbar.set_label('Cluster Label')
    
    plt.legend()
    plt.show()

    # --- Exercise 5: The Challenge of Interpretation: PCA Component Weights ---
    print("\n--- Exercise 5: The Challenge of Interpretation: PCA Component Weights ---")
    
    # Re-use pca_2d (fitted with n_components=2)
    loadings_matrix = pca_2d.components_
    
    # Create a DataFrame for clean visualization of loadings
    loadings_df = pd.DataFrame({
        'PC1 Loading': loadings_matrix[0],
        'PC2 Loading': loadings_matrix[1]
    }, index=FEATURE_NAMES)
    
    print(loadings_df.to_markdown(floatfmt=".4f"))
    
    print("\nInterpretation provided in the written solution section.")


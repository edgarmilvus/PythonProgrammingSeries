
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# ====================================================================
# Cell 1: Setup and Kernel Initialization
# ====================================================================

# Import the necessary classes from the standard library's datetime module.
# We need datetime (for parsing), date (for comparisons), and timedelta (for results).
from datetime import datetime, date, timedelta

# Define a fixed reference point for the current date.
# In a real-world scenario, this might be date.today().
# Using a fixed date (2024, 1, 1) ensures the example is reproducible across time.
current_date = date(2024, 1, 1)


# ====================================================================
# Cell 2: Data Acquisition and Parsing
# ====================================================================

# Define the deadline as a string. This simulates reading raw data from a file
# or database where dates are often stored as text.
deadline_str = "2024-12-31 23:59:59"

# Define the format string required by datetime.strptime().
# This format string (%Y-%m-%d %H:%M:%S) must precisely match the structure of deadline_str.
date_format = "%Y-%m-%d %H:%M:%S"

# Convert the string into a datetime object using the standard library function.
# We then explicitly call .date() to strip the time component, ensuring a clean date-only comparison.
deadline_dt = datetime.strptime(deadline_str, date_format).date()


# ====================================================================
# Cell 3: Calculation and Output
# ====================================================================

# Calculate the difference between the two date objects.
# Subtracting one date object from another yields a timedelta object.
time_remaining = deadline_dt - current_date

# Extract the total number of days as an integer from the resulting timedelta object.
days_remaining = time_remaining.days

# Use the print function and an f-string (formatted string literal) to display the results.
# This output appears directly below the cell in the notebook interface.
print(f"Current Date Reference: {current_date}")
print(f"Project Deadline Date: {deadline_dt}")
print("-" * 30) # Visual separator for clarity
print(f"Total days remaining until deadline: {days_remaining}")

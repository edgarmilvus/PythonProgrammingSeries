
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import numpy as np

# --- Setup: Global Tech Sales Ledger (Re-run setup for self-contained solution) ---

# 1. Define Hierarchical Row Index (Region, Product Type)
regions = ['North America', 'Europe', 'Asia']
product_types = ['Software License', 'Hardware Unit', 'Service Contract']
index_tuples = [(r, p) for r in regions for p in product_types]
row_index = pd.MultiIndex.from_tuples(index_tuples, names=['Region', 'Product_Type'])

# 2. Define Complex Data
data = {
    'Units_Sold': np.random.randint(100, 5000, size=len(row_index)),
    'Revenue': np.round(np.random.uniform(50000, 900000, size=len(row_index)), 2),
    'Cost_of_Goods': np.round(np.random.uniform(20000, 400000, size=len(row_index)), 2),
    'Profit_Margin': np.round(np.random.uniform(0.15, 0.45, size=len(row_index)), 4),
    'Quarter': np.random.choice(['Q1', 'Q2', 'Q3', 'Q4'], size=len(row_index)),
    'Sales_Rep_ID': np.random.randint(100, 150, size=len(row_index))
}

df_sales = pd.DataFrame(data, index=row_index)

# Add a complex column MultiIndex for Exercise 3
column_index = pd.MultiIndex.from_product([['Financials', 'Operational'], ['Value', 'Ratio']], names=['Category', 'Metric'])
df_sales_complex = pd.DataFrame(index=row_index, columns=column_index)

# Restructure for MultiIndex Columns
df_sales_complex[('Financials', 'Value')] = df_sales['Revenue']
df_sales_complex[('Financials', 'Ratio')] = df_sales['Profit_Margin']
df_sales_complex[('Operational', 'Value')] = df_sales['Units_Sold']
df_sales_complex[('Operational', 'Ratio')] = df_sales['Sales_Rep_ID'] # Using Sales_Rep_ID as a placeholder ratio


print("--- Initial Sales DataFrame (df_sales) Head ---")
print(df_sales.head())
print("\n--- Complex MultiIndex DataFrame (df_sales_complex) Head ---")
print(df_sales_complex.head())


# ----------------------------------------------------------------------
# Exercise 1: High-Value, Low-Margin Portfolio Identification
# ----------------------------------------------------------------------

print("\n--- Solution 1: High-Value, Low-Margin Portfolio ---")

# 1. Calculate Percentiles
rev_75 = df_sales['Revenue'].quantile(0.75)
margin_25 = df_sales['Profit_Margin'].quantile(0.25)

# 2. Define the complex Boolean mask
high_revenue = df_sales['Revenue'] > rev_75
low_margin = df_sales['Profit_Margin'] < margin_25
high_risk_mask = high_revenue & low_margin

# 3. Apply .loc selection and column subsetting
target_columns = ['Revenue', 'Cost_of_Goods', 'Profit_Margin']
high_risk_portfolio = df_sales.loc[high_risk_mask, target_columns]

# 4. Output
print(f"75th Percentile Revenue Threshold: ${rev_75:,.2f}")
print(f"25th Percentile Margin Threshold: {margin_25:.4f}")
print(f"Identified High-Risk Portfolio Shape: {high_risk_portfolio.shape}")
print(high_risk_portfolio)

# ----------------------------------------------------------------------
# Exercise 2: Positional Subsampling for Statistical Validation (.iloc)
# ----------------------------------------------------------------------

print("\n--- Solution 2: Positional Subsampling ---")

# 1 & 2. Row Sampling (start at index 4, step 3) and Column Selection (0, 2, 4)
# Rows: 4, 7, 10, 13, ...
# Columns: Units_Sold (0), Cost_of_Goods (2), Quarter (4)
sampled_data = df_sales.iloc[4::3, [0, 2, 4]]
print("A) Systematic Subsampling (Every 3rd row starting from 5th):")
print(sampled_data)

# 4. Non-Contiguous Row Retrieval (1st, 5th, 9th entries)
# Indices 0, 4, 8
non_contiguous_rows = df_sales.iloc[[0, 4, 8], :]
print("\nB) Non-Contiguous Row Retrieval (Indices 0, 4, 8):")
print(non_contiguous_rows)

# ----------------------------------------------------------------------
# Exercise 3: Precision Retrieval in Hierarchical Indices
# ----------------------------------------------------------------------

print("\n--- Solution 3: Hierarchical Indexing ---")

# Initialize IndexSlice for clean slicing
idx = pd.IndexSlice

# Part A: Row Selection
# 1. Specific Product in Specific Region (using tuple)
na_hardware = df_sales_complex.loc[('North America', 'Hardware Unit'), :]
print("A.1) North America - Hardware Unit:")
print(na_hardware)

# 2. Cross-Sectional Slice (Specific Region, All Products)
asia_sales = df_sales_complex.loc[idx['Asia', :], :]
print("\nA.2) All Products in Asia (using pd.IndexSlice):")
print(asia_sales)

# Part B: Column Selection
# 3. Specific Metric Across All Categories ('Value')
# Use slice(None) or ':' for the first level
all_value_metrics = df_sales_complex.loc[:, idx[:, 'Value']]
print("\nB.3) All 'Value' Metrics (Financials and Operational):")
print(all_value_metrics.head())

# 4. Specific Category and Metric ('Financials', 'Ratio')
financial_ratio = df_sales_complex.loc[:, ('Financials', 'Ratio')]
print("\nB.4) Only 'Financials' Ratio:")
print(financial_ratio.head())

# ----------------------------------------------------------------------
# Exercise 4: Interactive Challenge: Operational Efficiency Filter
# ----------------------------------------------------------------------

print("\n--- Solution 4: Operational Efficiency Filter ---")

# 1. Calculate Thresholds
units_10 = df_sales['Units_Sold'].quantile(0.10)
cost_90 = df_sales['Cost_of_Goods'].quantile(0.90)

# 2. Generate Boolean Mask
low_volume_cond = df_sales['Units_Sold'] < units_10
high_cost_cond = df_sales['Cost_of_Goods'] > cost_90
poor_timing_cond = df_sales['Quarter'].isin(['Q3', 'Q4'])

# Combine all three criteria using the AND operator (&)
suboptimal_mask = low_volume_cond & high_cost_cond & poor_timing_cond

# 3. In-Place Update: Initialize the column first
df_sales.loc[:, 'Operational_Status'] = 'Standard Operation'

# Apply the Suboptimal classification using the mask
df_sales.loc[suboptimal_mask, 'Operational_Status'] = 'Suboptimal Operation'

# 4. Validation
suboptimal_count = df_sales['Operational_Status'].value_counts().get('Suboptimal Operation', 0)
print(f"10th Percentile Units Sold Threshold: {units_10:.2f}")
print(f"90th Percentile Cost of Goods Threshold: ${cost_90:,.2f}")
print(f"Total Suboptimal Operations Identified: {suboptimal_count}")

validation_cols = ['Units_Sold', 'Cost_of_Goods', 'Quarter', 'Operational_Status']
suboptimal_log = df_sales.loc[suboptimal_mask, validation_cols]
print("\nSuboptimal Operation Log (Filtered View):")
print(suboptimal_log)

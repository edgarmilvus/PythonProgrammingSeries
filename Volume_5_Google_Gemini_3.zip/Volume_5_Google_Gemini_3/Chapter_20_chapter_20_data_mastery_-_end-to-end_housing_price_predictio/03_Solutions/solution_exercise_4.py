
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

def run_exercise_4():
    """Implements Halving Grid Search and performs residual analysis."""
    print("\n--- Running Exercise 4: Halving Grid Search and Residuals ---")
    
    # Define the final model pipeline structure
    gbr_pipeline = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('gbr', GradientBoostingRegressor(random_state=42))
    ])

    # 1. Tuning Setup: Define Search Space
    param_grid = {
        'gbr__n_estimators': [50, 100, 200],
        'gbr__max_depth': [3, 5, 7],
        'gbr__learning_rate': [0.05, 0.1, 0.2],
        'gbr__min_samples_leaf': [1, 5]
    }

    # 2. Halving Grid Search Implementation
    search = HalvingGridSearchCV(
        gbr_pipeline, 
        param_grid, 
        cv=3, 
        scoring='neg_root_mean_squared_error', 
        factor=2, 
        resource='n_samples', 
        random_state=42,
        n_jobs=-1,
        verbose=1
    )
    
    print("Starting Halving Grid Search (may take a moment)...")
    search.fit(X_train, y_train)

    # 3. Optimal Model Extraction
    best_gbr_model = search.best_estimator_
    best_score = np.sqrt(-search.best_score_)
    print(f"\nBest GBR Parameters: {search.best_params_}")
    print(f"Best cross-validated RMSE: {best_score:.4f}")
    
    # Evaluate on test set
    y_pred_optimal = best_gbr_model.predict(X_test)
    test_rmse = np.sqrt(mean_squared_error(y_test, y_pred_optimal))
    print(f"Test RMSE (Optimal GBR): {test_rmse:.4f}")

    # 4. Residual Calculation
    residuals = y_test - y_pred_optimal

    # 5. Residual Plotting (Data Generation)
    print("\n--- Residual Analysis Data Generation ---")
    
    # Data for Plot A: Residuals vs. Predicted Values
    residual_vs_predicted_df = pd.DataFrame({
        'Predicted_Value': y_pred_optimal,
        'Residuals': residuals
    })
    print("Data Head for Plot A (Residuals vs. Predicted Values):")
    print(residual_vs_predicted_df.head())

    # Data for Plot B: Histogram/KDE of Residuals
    print("\nResidual Distribution Statistics (Plot B Input):")
    print(residuals.describe())
    
    # 6. Interpretation
    print("\n--- Interpretation of Residual Plots ---")
    
    # Interpretation of Plot A (Residuals vs. Predicted Values):
    print("Plot A Interpretation: The ideal plot shows residuals randomly scattered around the horizontal line at zero. ")
    print("If a pattern emerges (e.g., a fanning shape or increasing spread as predicted values increase), it indicates **Heteroscedasticity** (non-constant variance of errors).")
    print("If the scatter forms a curve (not centered around zero), it indicates **Systematic Bias** or that a non-linear relationship was missed by the model.")

    # Interpretation of Plot B (Histogram/KDE):
    print("\nPlot B Interpretation: The ideal histogram of residuals should be approximately normally distributed (bell-shaped) and centered close to zero.")
    print("Skewness or heavy tails suggest that the model's errors are not random, potentially due to unmodeled extreme events or incorrect target transformation.")

run_exercise_4()

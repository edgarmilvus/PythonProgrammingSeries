
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# --- Exercise 2: Pipeline Updates ---

# High-Cardinality Pipeline (using OHE placeholder for Neighborhood)
high_card_pipeline = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('encoder', OneHotEncoder(handle_unknown='ignore'))
])

# Categorical Pipeline (for BldgType)
categorical_pipeline = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

# Numerical Pipeline (Updated: Capper + Selector)
numerical_pipeline = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),
    ('capper', IQR_Capper(factor=1.5)), # Ex 1 Integration
    ('scaler', StandardScaler()),
    # Ex 2 Integration: Select top K features based on F-test
    ('selector', SelectKBest(score_func=f_regression, k=4)) 
])

# Full Column Transformer (Updated)
preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_pipeline, [c for c in NUMERICAL_FEATURES]),
        ('cat', categorical_pipeline, ['BldgType']),
        ('high_card', high_card_pipeline, ['Neighborhood']) 
    ],
    remainder='passthrough',
    verbose_feature_names_out=False
)

# --- Verification of Feature Selection ---
# 1. Build the full pipeline structure (just preprocessor for inspection)
feature_selection_pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor)
])

# 2. Fit the pipeline to training data
feature_selection_pipeline.fit(X_train, y_train)

# 3. Inspect the SelectKBest step
# Navigate: Pipeline -> ColumnTransformer -> Numerical Pipeline -> Selector
selector = feature_selection_pipeline['preprocessor'].named_transformers_['num'].named_steps['selector']

# The selector returns a mask of which features were chosen
selected_mask = selector.get_support()
initial_num_features = NUMERICAL_FEATURES

# The selector operates *after* capping and scaling. 
# Since we used k=4 (the total number of numerical features), all are selected.
# If we had more features, we would map the mask back to the original names.

print("\n--- Exercise 2 Verification: Feature Selection ---")
print(f"Numerical features available for selection: {initial_num_features}")
print(f"Features selected by SelectKBest (k={selector.k}): {np.sum(selected_mask)} features.")

# To see the scores (higher is better):
scores = selector.scores_
feature_scores = pd.Series(scores, index=initial_num_features).sort_values(ascending=False)
print("\nFeature Scores (f_regression):")
print(feature_scores)

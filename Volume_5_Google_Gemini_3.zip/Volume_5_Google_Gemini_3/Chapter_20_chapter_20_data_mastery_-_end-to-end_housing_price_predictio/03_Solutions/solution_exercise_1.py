
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split, HalvingGridSearchCV
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor, StackingRegressor
from sklearn.linear_model import LinearRegression
from sklearn.feature_selection import SelectKBest, f_regression
from sklearn.metrics import mean_squared_error

# --- Data Setup (as per scaffolding) ---
N_SAMPLES = 1000
np.random.seed(42)
X_num = pd.DataFrame({
    'LotArea': np.random.lognormal(mean=9.5, sigma=0.5, size=N_SAMPLES),
    'GrLivArea': np.random.lognormal(mean=7.0, sigma=0.4, size=N_SAMPLES),
    'YearBuilt': np.random.randint(1900, 2010, size=N_SAMPLES),
    'TotalBsmtSF': np.random.normal(1000, 300, size=N_SAMPLES)
})
X_num.loc[0:5, 'LotArea'] = 50000 
X_cat = pd.DataFrame({
    'Neighborhood': np.random.choice(['CollgCr', 'Veenker', 'NoRidge', 'NWAmes', 'Gilbert', 'Somerst'], N_SAMPLES),
    'BldgType': np.random.choice(['1Fam', 'TwnhsE', 'Duplex'], N_SAMPLES)
})
X = pd.concat([X_num, X_cat], axis=1)
y = 100000 + 50 * X['GrLivArea'] + 20 * X['YearBuilt'] + np.random.normal(0, 30000, N_SAMPLES)
y = np.log1p(y) 
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
NUMERICAL_FEATURES = X_num.columns.tolist()
CATEGORICAL_FEATURES = X_cat.columns.tolist()

# --- Exercise 1: IQR Capper Implementation ---

class IQR_Capper(BaseEstimator, TransformerMixin):
    """Custom transformer to cap outliers based on the IQR method."""
    def __init__(self, factor=1.5):
        self.factor = factor
        self.bounds_ = {}
        self.feature_names_in_ = None

    def fit(self, X, y=None):
        # Ensure input is a DataFrame for easy column operations
        if not isinstance(X, pd.DataFrame):
            # Assumes input order matches NUMERICAL_FEATURES if array is passed
            X = pd.DataFrame(X, columns=NUMERICAL_FEATURES)
        
        self.feature_names_in_ = X.columns.tolist()
            
        for col in X.columns:
            Q1 = X[col].quantile(0.25)
            Q3 = X[col].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - (self.factor * IQR)
            upper_bound = Q3 + (self.factor * IQR)
            self.bounds_[col] = (lower_bound, upper_bound)
        return self

    def transform(self, X):
        # Ensure input is a DataFrame or convert array to DataFrame using stored names
        if not isinstance(X, pd.DataFrame):
            X_transformed = pd.DataFrame(X, columns=self.feature_names_in_).copy()
        else:
            X_transformed = X.copy()
            
        for col, (lower, upper) in self.bounds_.items():
            # Apply capping using np.clip for efficiency
            X_transformed[col] = np.clip(X_transformed[col], lower, upper)
            
        # Return NumPy array for subsequent standard Scikit-learn steps (like StandardScaler)
        return X_transformed.values

print("Exercise 1: IQR_Capper defined and ready for integration.")

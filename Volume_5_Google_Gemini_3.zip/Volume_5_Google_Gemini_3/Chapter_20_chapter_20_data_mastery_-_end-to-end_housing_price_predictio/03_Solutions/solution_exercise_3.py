
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

def run_exercise_3():
    """Implements, trains, serializes, and verifies the Stacking Ensemble pipeline."""
    print("\n--- Running Exercise 3: Stacking Ensemble and Serialization ---")
    
    # 1. Define Base Estimators
    base_estimators = [
        ('gbr', GradientBoostingRegressor(n_estimators=100, max_depth=3, random_state=42)),
        ('rf', RandomForestRegressor(n_estimators=50, max_depth=5, random_state=42))
    ]

    # Define Meta Estimator
    meta_estimator = LinearRegression()

    # Create Stacking Regressor
    stacked_regressor = StackingRegressor(
        estimators=base_estimators,
        final_estimator=meta_estimator,
        cv=5  # Use 5-fold cross-validation for training the meta-model
    )

    # 2. Full Stacking Pipeline (Preprocessor + Stacking)
    full_stacking_pipeline = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('stacking', stacked_regressor)
    ])

    # 3. Training
    print("Training Stacking Pipeline...")
    full_stacking_pipeline.fit(X_train, y_train)

    # 4. Evaluation
    y_pred = full_stacking_pipeline.predict(X_test)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    print(f"Test RMSE (Stacked Model): {rmse:.4f}")

    # 5. Serialization
    filename = 'stacked_housing_predictor.joblib'
    joblib.dump(full_stacking_pipeline, filename)
    print(f"Pipeline successfully serialized to {filename}")

    # 6. Verification
    print("\nVerifying serialization...")
    loaded_pipeline = joblib.load(filename)
    
    # Simulate a new data point
    new_data = pd.DataFrame({
        'LotArea': [15000], 'GrLivArea': [2500], 'YearBuilt': [2005], 
        'TotalBsmtSF': [1500], 'Neighborhood': ['NoRidge'], 'BldgType': ['1Fam']
    })
    
    verified_prediction = loaded_pipeline.predict(new_data)
    # Inverse transform (expm1) since the target y was log-transformed (log1p)
    print(f"Prediction for new data point (original scale): ${np.expm1(verified_prediction[0]):,.2f}")

run_exercise_3()

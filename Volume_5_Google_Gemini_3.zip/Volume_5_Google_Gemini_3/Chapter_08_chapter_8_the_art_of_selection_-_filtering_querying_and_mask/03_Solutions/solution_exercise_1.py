
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# Set seed for reproducibility
np.random.seed(42)

# 1. Generate core data
N = 10000  # Large dataset size to emphasize efficiency
regions = ['NA', 'EU', 'APAC', 'LATAM', 'AFRICA']
statuses = ['Completed', 'Active', 'Pending Review', 'Cancelled']
disciplines = ['AI/ML', 'Biotech', 'Climate Science', 'Physics', 'Social Sciences']

data = {
    'Project_ID': [f'P{i:05d}' for i in range(N)],
    'Region': np.random.choice(regions, N, p=[0.30, 0.30, 0.20, 0.10, 0.10]),
    'Discipline': np.random.choice(disciplines, N),
    'Funding_USD': np.round(np.random.lognormal(mean=12, sigma=1.5, size=N), 2),
    'Project_Status': np.random.choice(statuses, N, p=[0.55, 0.30, 0.10, 0.05]),
    'Start_Date': pd.to_datetime(datetime(2018, 1, 1) + (datetime(2023, 12, 31) - datetime(2018, 1, 1)) * np.random.rand(N)),
    'End_Date': pd.NaT, # Will be filled conditionally
    'PI_Name': [f'Dr. {chr(65 + np.random.randint(26))}{chr(97 + np.random.randint(26))} Smith' for _ in range(N)],
    'Impact_Score': np.round(np.random.uniform(1.0, 10.0, N), 1)
}

df = pd.DataFrame(data)

# 2. Conditionals for End_Date
# Projects that are 'Completed' or 'Cancelled' must have an End_Date
completed_mask = (df['Project_Status'] == 'Completed') | (df['Project_Status'] == 'Cancelled')
df.loc[completed_mask, 'End_Date'] = df.loc[completed_mask, 'Start_Date'] + pd.to_timedelta(np.random.randint(365, 1825, completed_mask.sum()), unit='D')

# 3. Create a derived column for later filtering
df['Duration_Days'] = (df['End_Date'] - df['Start_Date']).dt.days
df['Duration_Days'] = df['Duration_Days'].fillna(0).astype(int) # 0 for active/pending

print("Setup Complete. DataFrame Head:")
print(df.head())
print(f"\nTotal Records: {len(df)}")


# --- Exercise 1 Solution ---
print("\n--- Exercise 1: Boolean Masking Mastery ---")

# 1. Define criteria components
FINANCIAL_RISK = df['Funding_USD'] > 5_000_000
PERFORMANCE_FAILURE = (df['Project_Status'] == 'Completed') & (df['Impact_Score'] < 3.0)
EXCLUSION_CRITERIA = df['Region'] == 'AFRICA'

# 2. Combine into a single mask: (Risk OR Failure) AND (NOT Africa)
audit_mask = (FINANCIAL_RISK | PERFORMANCE_FAILURE) & (~EXCLUSION_CRITERIA)

# 3. Apply mask and generate report
df_audit = df.loc[audit_mask]
print(f"Total Audit Records: {len(df_audit)}")
print(f"Average Funding (Audit): ${df_audit['Funding_USD'].mean():,.2f}")


# --- Exercise 2 Solution ---
print("\n--- Exercise 2: Precision Selection ---")

# Part A: Metadata Snapshot (using .loc)
start_2023_mask = df['Start_Date'].dt.year == 2023
target_columns_loc = ['Project_ID', 'Region', 'Discipline', 'Start_Date']
# Use .loc for both row (mask) and column (label list) selection
df_metadata_2023 = df.loc[start_2023_mask, target_columns_loc]
print(f"Shape of Metadata Snapshot (loc): {df_metadata_2023.shape}")

# Part B: Positional Financial Slice (using .iloc)
# Row slice: 1000 to 1050 (inclusive) -> 1000:1051
# Column indices: 3 (Funding_USD), 4 (Project_Status), 8 (Impact_Score)
target_columns_iloc = [3, 4, 8]
# Use .iloc for both row (positional slice) and column (positional list) selection
df_financial_slice = df.iloc[1000:1051, target_columns_iloc]
print(f"Shape of Financial Slice (iloc): {df_financial_slice.shape}")


# --- Exercise 3 Solution ---
print("\n--- Exercise 3: Dynamic Selection with .query() ---")

# 1. Define variables
min_impact_threshold = 7.5
max_funding_usd = 2_000_000

# 2. Construct the query string using @variables and logical keywords
query_string = (
    "Impact_Score > @min_impact_threshold and "
    "Funding_USD <= @max_funding_usd and "
    "Discipline in ['AI/ML', 'Biotech']"
)

# 3. Apply the query
df_dynamic_filter = df.query(query_string)

print(f"Records found by dynamic filter: {len(df_dynamic_filter)}")
print("First 5 records of dynamic filter:")
print(df_dynamic_filter[['Impact_Score', 'Funding_USD', 'Discipline']].head())


# --- Exercise 4: High-ROI Project Identification Pipeline ---
print("\n--- Exercise 4: High-ROI Project Identification Pipeline ---")

# Stage 1: Temporal Focus (Completed projects after 2022-01-01)
# Use .loc with a combined mask to ensure End_Date is valid
recent_completed_mask = (df['Project_Status'] == 'Completed') & (df['End_Date'] > '2022-01-01')
df_stage1 = df.loc[recent_completed_mask]

# Stage 2: Regional Exclusion (Exclude NA)
# Apply Boolean masking to the intermediate DataFrame (df_stage1)
na_exclusion_mask = df_stage1['Region'] != 'NA'
df_stage2 = df_stage1.loc[na_exclusion_mask]

# Stage 3: Performance and Duration Screening (using .query())
# Filter the result of Stage 2 using .query()
query_roi = "Impact_Score >= 8.5 and Duration_Days < 1000"
df_high_roi = df_stage2.query(query_roi)

# Stage 4: Final Insight
total_funding_roi = df_high_roi['Funding_USD'].sum()
num_projects_roi = len(df_high_roi)

print(f"Identified High-ROI Projects: {num_projects_roi}")
print(f"Total Funding for High-ROI Portfolio: ${total_funding_roi:,.2f}")

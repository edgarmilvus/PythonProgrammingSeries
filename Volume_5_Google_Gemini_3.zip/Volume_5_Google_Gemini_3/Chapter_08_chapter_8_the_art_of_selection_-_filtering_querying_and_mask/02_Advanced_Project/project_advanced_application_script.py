
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import numpy as np
import random

# --- 1. Data Generation and Setup ---

def generate_user_data(num_records: int = 1500) -> pd.DataFrame:
    """Generates a synthetic dataset for user behavior analysis."""
    # Setting a seed ensures reproducible data for consistent testing
    np.random.seed(42)
    data = {
        'User_ID': range(10000, 10000 + num_records),
        # Total_Spent uses Gamma distribution for realistic skew (more low spenders)
        'Total_Spent': np.random.gamma(shape=3, scale=100, size=num_records).round(2),
        # Last login days ago (1 to 180 days)
        'Last_Login_Days_Ago': np.random.randint(1, 180, num_records),
        'Subscription_Tier': np.random.choice(['Free', 'Basic', 'Premium', 'Enterprise'], num_records, p=[0.35, 0.30, 0.25, 0.10]),
        'Region': np.random.choice(['NA', 'EU', 'APAC', 'LATAM'], num_records, p=[0.4, 0.3, 0.2, 0.1]),
        # Has the user already received a special discount?
        'Discount_Code_Used': np.random.choice([True, False], num_records, p=[0.4, 0.6]),
        'Session_Count': np.random.poisson(lam=20, size=num_records)
    }
    df = pd.DataFrame(data)
    # Business rule enforcement: high spenders are automatically Enterprise tier
    df.loc[df['Total_Spent'] > 400, 'Subscription_Tier'] = 'Enterprise'
    return df

df_users = generate_user_data()
print(f"Total Records Loaded: {len(df_users)}")

# --- 2. Defining Core Filtering Thresholds ---

# Using variables for thresholds adheres to PEP 8 and improves maintainability
SPEND_THRESHOLD = 300.00
RECENCY_THRESHOLD_DAYS = 30
MIN_SESSIONS = 15
TARGET_REGION = 'EU'
TARGET_TIER = 'Premium'

# --- 3. Selection Technique A: Boolean Masking with .loc (Traditional) ---

# Goal: Identify "At-Risk High Spenders" (High spend, but inactive recently)
mask_high_spend = df_users['Total_Spent'] >= SPEND_THRESHOLD
# Inactive is defined as having logged in more than 3 months (90 days) ago
mask_inactive = df_users['Last_Login_Days_Ago'] > RECENCY_THRESHOLD_DAYS * 3
    
# Combine masks using the bitwise AND operator (&)
# .copy() ensures the resulting DataFrame is independent of the original
df_at_risk = df_users.loc[mask_high_spend & mask_inactive].copy()
print(f"\n[A] At-Risk High Spenders Found: {len(df_at_risk)}")


# --- 4. Selection Technique B: Complex Masking with Multiple Operators ---

# Goal: Identify "Targeted Campaign Group" (EU or APAC region, NOT Enterprise, and must be active)
# Use OR (|) for region inclusion
mask_region = (df_users['Region'] == TARGET_REGION) | (df_users['Region'] == 'APAC')
# Use NOT (~) for tier exclusion
mask_tier_exclusion = ~(df_users['Subscription_Tier'] == 'Enterprise')
mask_active = df_users['Session_Count'] >= MIN_SESSIONS

# Combine all masks ensuring correct operator precedence with parentheses
df_campaign = df_users.loc[(mask_region & mask_tier_exclusion) & mask_active].copy()
print(f"[B] Targeted Campaign Group Size: {len(df_campaign)}")


# --- 5. Selection Technique C: Advanced Querying with .query() ---

# Goal: Find "Premium, Recently Active Users" who have NOT used a discount code.
# This demonstrates passing Python variables (using @ prefix) and complex string logic.
    
# Define variables for injection into the query string
# Note: We use a slightly lower spend threshold for this group
q_spend = SPEND_THRESHOLD * 0.5 
q_tier = TARGET_TIER

# Construct the query string, which is evaluated by the underlying engine (NumExpr)
query_string = (
    f"Subscription_Tier == @q_tier and "
    f"Total_Spent >= @q_spend and "
    f"Last_Login_Days_Ago <= {RECENCY_THRESHOLD_DAYS} and "
    f"not Discount_Code_Used" # 'not' works directly on boolean columns in .query()
)

df_premium_targets = df_users.query(query_string).copy()
print(f"[C] Premium Targets (via .query()): {len(df_premium_targets)}")

# --- 6. Final Analysis and Reporting and Masking for Assignment ---

# We now use the indices of the filtered subset to update the master DataFrame.

# 6.1 Initialize a new column
df_users['Outreach_Priority'] = False
    
# 6.2 Identify the indices of the premium targets subset
premium_indices = df_premium_targets.index
    
# 6.3 Use .loc to set the Outreach_Priority flag on the master DF based on the indices
# This is masking for assignment, ensuring alignment and efficiency
df_users.loc[premium_indices, 'Outreach_Priority'] = True
    
# Calculate the average spend difference between the two primary groups
avg_spend_at_risk = df_at_risk['Total_Spent'].mean()
avg_spend_premium = df_premium_targets['Total_Spent'].mean()

print("\n--- Final Summary ---")
print(f"Average Spend (At-Risk High Spenders): ${avg_spend_at_risk:.2f}")
print(f"Average Spend (Premium Targets): ${avg_spend_premium:.2f}")
    
# Verification check
verification_count = df_users['Outreach_Priority'].sum()
print(f"Total Users flagged for Outreach in master DF: {verification_count}")

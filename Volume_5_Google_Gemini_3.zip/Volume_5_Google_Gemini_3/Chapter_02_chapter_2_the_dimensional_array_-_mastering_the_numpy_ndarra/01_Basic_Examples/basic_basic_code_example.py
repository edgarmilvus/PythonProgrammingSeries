
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np

# --- 1. Creating a 1-Dimensional Array (Vector) ---
# Scenario: Tracking the daily sales units for Product Alpha over four days.
# The data consists of whole numbers (integers).
alpha_sales_list = [150, 155, 148, 162]
# Convert the Python list into a NumPy ndarray
alpha_sales_array = np.array(alpha_sales_list)

# --- 2. Inspecting the 1D Array Properties ---
print("--- Product Alpha Sales (1D Array) ---")
print(f"Array Data: {alpha_sales_array}")
print(f"Type Check: {type(alpha_sales_array)}")
print(f"Shape (Dimensions): {alpha_sales_array.shape}")
print(f"Number of Dimensions (ndim): {alpha_sales_array.ndim}")
print(f"Data Type (dtype): {alpha_sales_array.dtype}")

# --- 3. Creating a 2-Dimensional Array (Matrix) ---
# Scenario: Tracking sales for three products (Alpha, Beta, Gamma) over four days.
# We use a list of lists, where each inner list is a row (a product's sales history).
# We explicitly use floating point numbers to allow for future calculations involving averages.
inventory_matrix = np.array([
    [150.0, 155.0, 148.0, 162.0],  # Row 0: Alpha Sales (Day 1-4)
    [ 95.5, 101.0,  99.5, 110.0],  # Row 1: Beta Sales (Day 1-4)
    [220.0, 215.0, 230.0, 225.0]   # Row 2: Gamma Sales (Day 1-4)
], dtype=np.float64) # Explicitly setting the data type to 64-bit float

# --- 4. Inspecting the 2D Array Properties ---
print("\n--- Inventory Sales Matrix (2D Array) ---")
print(f"Matrix Data:\n{inventory_matrix}")
print(f"Shape (Rows, Columns): {inventory_matrix.shape}")
print(f"Number of Dimensions (ndim): {inventory_matrix.ndim}")
print(f"Data Type (dtype): {inventory_matrix.dtype}")
print(f"Total Elements (size): {inventory_matrix.size}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np

# Set a consistent seed for reproducible results across all exercises
np.random.seed(42)

# --- Exercise 1 Solution: High-Fidelity Data Extraction using Compound Indexing ---
print("--- Exercise 1: High-Fidelity Data Extraction ---")

# 1. Data Initialization (20 days, 6 features)
N_days = 20
# Columns: [Open, High, Low, Close, Volume, Volatility]
# Ensure Close Price (index 3) is varied around 100
close_prices = np.random.uniform(70, 130, N_days)
other_features = np.random.rand(N_days, 5) * 50 + 50
# Combine data: insert close prices into the 4th column
market_data = np.hstack([other_features[:, :3], close_prices[:, np.newaxis], other_features[:, 3:]])

print(f"Original Data Shape: {market_data.shape}")

# 2. Define Threshold
price_threshold = 100.0

# 3. Boolean Masking (Rows where Close Price > 100)
# Close Price is at column index 3
high_price_mask = market_data[:, 3] > price_threshold

# 4. Feature Selection (Volume index 4, Volatility index 5)
target_features = np.array([4, 5])

# 5. Compound Indexing: [Boolean Mask for Rows, Integer Array for Columns]
extracted_subset = market_data[high_price_mask, target_features]

# 6. Verification
print(f"Number of high-price days found: {np.sum(high_price_mask)}")
print(f"Extracted Subset Shape: {extracted_subset.shape}")
print("-" * 50)


# --- Exercise 2 Solution: Tensor Reordering and Dimension Expansion ---
print("--- Exercise 2: Tensor Reordering and Dimension Expansion ---")

# 1. Initial Data (1800 elements)
raw_sequence = np.arange(1800, dtype=np.float32)

# Parameters
num_batches = 30
time_steps = 60
features = 1

# 2. Initial Reshape (Batch, Time, Feature) - (30, 60, 1)
# The '1' explicitly defines the feature channel dimension
initial_tensor = raw_sequence.reshape(num_batches, time_steps, features)

# 3. Dimension Expansion (Handled implicitly in step 2)

# 4. Axis Transposition (Batch, Feature, Time) - Target: (30, 1, 60)
# Original axes: (0, 1, 2) -> Required axes: (0, 2, 1)
model_input_tensor = initial_tensor.transpose((0, 2, 1))

# 5. Verification
print(f"Raw Sequence Shape: {raw_sequence.shape}")
print(f"Initial Tensor Shape (B, T, F): {initial_tensor.shape}")
print(f"Model Input Tensor Shape (B, F, T): {model_input_tensor.shape}")
# Strides demonstrate the change in memory layout due to transposition
print(f"Initial Tensor Strides (bytes): {initial_tensor.strides}")
print(f"Model Input Tensor Strides (bytes): {model_input_tensor.strides}")
print("-" * 50)


# --- Exercise 3 Solution: Vectorized Pairwise Distance Calculation using Broadcasting ---
print("--- Exercise 3: Vectorized Pairwise Distance Calculation ---")

# 1. Data Setup
N, M, D = 100, 50, 3
A = np.random.rand(N, D) * 10
B = np.random.rand(M, D) * 10

# 2. Dimension Expansion for Broadcasting
# A_expanded shape: (100, 1, 3)
A_expanded = A[:, np.newaxis, :]
# B_expanded shape: (1, 50, 3)
B_expanded = B[np.newaxis, :, :]

# 3. Vectorized Subtraction
# Broadcasting occurs: (100, 1, 3) - (1, 50, 3) -> (100, 50, 3)
diff = A_expanded - B_expanded

# 4. Squared Difference
squared_diff = diff**2

# 5. Summation along the dimension axis (axis 2)
# This sums the squared differences across the 3 dimensions (x, y, z)
squared_distance_matrix = np.sum(squared_diff, axis=2)

# 6. Verification
print(f"A expanded shape: {A_expanded.shape}")
print(f"B expanded shape: {B_expanded.shape}")
print(f"Difference matrix shape: {diff.shape}")
print(f"Final Distance Matrix shape: {squared_distance_matrix.shape}")
print("-" * 50)


# --- Exercise 4 Solution: Interactive Challenge (Feature Engineering Pipeline) ---
print("--- Exercise 4: Advanced Feature Engineering Pipeline ---")

# 1. Simulate Existing Feature Matrix
N_days = 200
N_features = 10
feature_matrix = np.random.uniform(10, 200, (N_days, N_features)).astype(np.float64)

# 2. Identify Critical Features
critical_indices = np.array([2, 5, 8])

# 3. Calculate Percentage Change (Vectorized Slicing)
critical_data = feature_matrix[:, critical_indices]

# Calculate Change: (V_t - V_{t-1}) / V_{t-1}
# V_t = data[1:], V_{t-1} = data[:-1]
numerator = critical_data[1:] - critical_data[:-1]
denominator = critical_data[:-1]
percent_change = numerator / denominator

# Pad the result (199 rows) with a row of zeros at the beginning (for t=0)
padding = np.zeros((1, len(critical_indices)))
padded_change = np.vstack([padding, percent_change])

# 4. Feature Concatenation
augmented_features = np.hstack([feature_matrix, padded_change])

# 5. Standardization (Broadcasting)
# Calculate mean and std across the days (axis 0)
mu = augmented_features.mean(axis=0)
sigma = augmented_features.std(axis=0)

# Reshape mu and sigma from (13,) to (1, 13) for correct broadcasting across 200 rows
mu_broadcastable = mu[np.newaxis, :]
sigma_broadcastable = sigma[np.newaxis, :]

# Apply standardization: (X - mu) / sigma
epsilon = 1e-8 
standardized_features = (augmented_features - mu_broadcastable) / (sigma_broadcastable + epsilon)

# Verification
print(f"Original Feature Matrix Shape: {feature_matrix.shape}")
print(f"Padded Change Feature Shape: {padded_change.shape}")
print(f"Augmented Features Shape: {augmented_features.shape}")
print(f"Standardized Features Shape: {standardized_features.shape}")
# Verify standardization properties
print(f"Standardized Mean (Feature 1): {standardized_features[:, 1].mean():.6f}")
print(f"Standardized Std Dev (Feature 12 - New Feature): {standardized_features[:, 12].std():.6f}")
print("-" * 50)

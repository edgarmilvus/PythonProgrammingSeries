
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.patheffects as pe 
from datetime import datetime

# --- 1. Configuration and Styling Setup (DRY Principle) ---

def apply_narrative_style():
    """
    Sets up a custom, narrative-focused Matplotlib style using RC parameters.
    This ensures all subsequent plots adhere to a consistent, professional theme.
    """
    # Define a custom, accessible color palette for narrative encoding
    COLOR_PRIMARY = '#1f77b4'      # Muted blue for main trend (neutral)
    COLOR_DIP = '#d62728'          # Red for crisis/dip (alert)
    COLOR_RECOVERY = '#2ca02c'     # Green for success/recovery (positive)
    COLOR_TEXT = '#333333'         # Dark gray for high contrast text

    # Update global Matplotlib settings for a clean, report-ready aesthetic
    plt.rcParams.update({
        'figure.facecolor': '#f0f0f0',  # Light gray background for figure
        'axes.facecolor': '#ffffff',    # White plot area (high contrast to data)
        'font.family': 'sans-serif',    # Ensure clean typography
        'font.size': 10,
        'axes.labelcolor': COLOR_TEXT,
        'text.color': COLOR_TEXT,
        'xtick.color': COLOR_TEXT,
        'ytick.color': COLOR_TEXT,
        # Remove chart junk (top/right spines)
        'axes.spines.top': False,       
        'axes.spines.right': False,
        'axes.spines.left': False,      # We will rely on gridlines for reference
        'grid.color': '#cccccc',        # Light gridlines
        'grid.linestyle': '--',
        'grid.alpha': 0.6
    })
    return COLOR_PRIMARY, COLOR_DIP, COLOR_RECOVERY

# --- 2. Data Simulation ---

def generate_sales_data():
    """Creates simulated quarterly sales data with a defined crisis point and recovery."""
    dates = pd.date_range(start='2021-01-01', periods=12, freq='QS')
    # Sales data: Steady growth, sharp dip in Q3 2022 (index 6), and strong recovery
    sales = [150, 160, 175, 180, 190, 195, 140, 155, 170, 185, 200, 215] 
    df = pd.DataFrame({'Date': dates, 'Sales_M': sales})
    df['Q_Label'] = df['Date'].dt.to_period('Q')
    
    # Identify key indices for direct access in annotations
    dip_index = df[df['Sales_M'] == 140].index[0]
    recovery_index = df.index[-1]
    
    return df, dip_index, recovery_index

# --- 3. Main Visualization Function ---

def visualize_narrative_sales(df, dip_idx, recovery_idx):
    """Generates the highly customized plot, applying advanced styling and annotations."""
    COLOR_PRIMARY, COLOR_DIP, COLOR_RECOVERY = apply_narrative_style()

    fig, ax = plt.subplots(figsize=(12, 7))
    
    # Plot the primary data trend line
    ax.plot(df['Date'], df['Sales_M'], 
            color=COLOR_PRIMARY, linewidth=3, alpha=0.8, 
            label='Quarterly Sales Trend')
    
    # Add subtle gridlines on the Y-axis for quantitative reference
    ax.grid(axis='y', zorder=0)
    
    # --- Strategic Color Encoding and Highlighting ---
    
    # 1. Highlight the Critical Dip Point (Q3 2022)
    dip_data = df.iloc[dip_idx]
    ax.scatter(dip_data['Date'], dip_data['Sales_M'], s=200, color=COLOR_DIP, zorder=5, 
               edgecolor='white', linewidth=2, label='Crisis Point')
    
    # 2. Highlight the Recovery Success Point (Q4 2023)
    recovery_data = df.iloc[recovery_idx]
    ax.scatter(recovery_data['Date'], recovery_data['Sales_M'], s=200, color=COLOR_RECOVERY, zorder=5, 
               edgecolor='white', linewidth=2, label='Record Recovery')

    # --- Advanced Annotations and Callouts ---

    # Annotation 1: The Crisis Callout (Custom Bounding Box and Arrow)
    ax.annotate(f'Q3 2022: Critical Dip\nSales plummeted to ${dip_data["Sales_M"]}M',
                xy=(dip_data['Date'], dip_data['Sales_M']), xycoords='data',
                xytext=(-60, 60), textcoords='offset points',
                fontsize=11, color=COLOR_DIP,
                # Define complex arrow properties for a smooth curve
                arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=-0.3", 
                                color=COLOR_DIP, linewidth=1.5, shrinkA=5, shrinkB=5),
                # Define custom bounding box for visual separation and emphasis
                bbox=dict(boxstyle="round,pad=0.5", fc="white", alpha=0.9, ec=COLOR_DIP, linewidth=1.5),
                horizontalalignment='center'
               )

    # Annotation 2: The Success Callout (Using Path Effects for High Visibility)
    ax.annotate(f'Q4 2023: Record High\nNew Peak: ${recovery_data["Sales_M"]}M',
                xy=(recovery_data['Date'], recovery_data['Sales_M']), xycoords='data',
                xytext=(30, -50), textcoords='offset points',
                fontsize=12, color=COLOR_RECOVERY, weight='bold',
                # Apply Path Effects (Stroke and Normal) to ensure text is readable over any background
                path_effects=[pe.Stroke(linewidth=4, foreground='white'), pe.Normal()], 
                # Use a different arrow style (wedge) for variety
                arrowprops=dict(arrowstyle="wedge,tail_width=0.5", color=COLOR_RECOVERY, 
                                alpha=0.9, shrinkA=5, shrinkB=5),
                horizontalalignment='left'
               )
    
    # --- Title and Axis Formatting for Visual Hierarchy ---
    
    # Hierarchy 1: Main Title (Large, Bold, Left-aligned for reporting style)
    fig.suptitle("Quarterly Sales Performance: The Strategic Recovery Narrative (2021-2023)", 
                 fontsize=18, weight='bold', ha='left', x=0.05, y=0.98)
    
    # Hierarchy 2: Subtitle/Context (Provides immediate context)
    ax.text(0.0, 1.05, 'Visualizing the market correction impact and the subsequent successful turnaround.', 
            transform=ax.transAxes, fontsize=12, color=COLOR_TEXT, alpha=0.8)
    
    # Axis Refinements
    ax.set_ylabel("Sales (Millions USD)", fontsize=11, labelpad=15)
    ax.set_ylim(120, 230)
    ax.tick_params(axis='y', length=0) # Remove Y-axis ticks
    
    # Custom X-axis Date Formatting (Quarterly Labels)
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y Q%q'))
    ax.xaxis.set_major_locator(mdates.QuarterlyLocator())
    plt.xticks(rotation=45, ha='right')
    ax.set_xlabel("") # Remove default X label, as the dates are self-explanatory
    
    # Final Layout Adjustment
    plt.tight_layout(rect=[0, 0.03, 1, 0.9])
    plt.show()

# --- 4. Execution ---
if __name__ == '__main__':
    data, dip_index, recovery_index = generate_sales_data()
    visualize_narrative_sales(data, dip_index, recovery_index)

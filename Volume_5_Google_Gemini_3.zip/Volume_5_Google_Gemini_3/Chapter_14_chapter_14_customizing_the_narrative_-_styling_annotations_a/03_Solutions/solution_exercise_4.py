
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def exercise_4_conditional_styling():
    """
    Plots a time series with conditional line styling and background shading 
    based on calculated rolling volatility.
    """
    
    # 1. Data Simulation (365 days of stock prices)
    days = 365
    dates = pd.date_range(start='2023-01-01', periods=days, freq='D')
    np.random.seed(15)
    
    # Simulate price path
    returns = np.random.normal(0.0005, 0.01, days)
    # Introduce a period of high volatility (e.g., around day 200-250)
    returns[200:250] *= 2.5 
    
    price = 100 * np.exp(np.cumsum(returns))
    df = pd.DataFrame({'Close': price}, index=dates)
    
    # 2. Volatility Calculation (30-day Rolling Standard Deviation of Log Returns)
    df['Log_Return'] = np.log(df['Close'] / df['Close'].shift(1))
    # Annualized 30-day rolling volatility
    df['Volatility'] = df['Log_Return'].rolling(window=30).std() * np.sqrt(365) 
    df = df.dropna()
    
    # 3. Threshold Definition (80th percentile)
    volatility_threshold = df['Volatility'].quantile(0.80)
    
    # Conditional Masking
    df['High_Vol'] = df['Volatility'] > volatility_threshold
    
    # Create masked series for plotting the line segments
    low_vol_price = df['Close'].where(~df['High_Vol'])
    high_vol_price = df['Close'].where(df['High_Vol'])
    
    fig, ax = plt.subplots(figsize=(12, 6))
    
    # 4. Conditional Line Styling (Zorder=3 for line visibility)
    # Plot low volatility periods (subtle gray)
    ax.plot(df.index, low_vol_price, color='#AAAAAA', linewidth=1.5, zorder=3, 
            label='Low Volatility Price')
    
    # Plot high volatility periods (bold red)
    ax.plot(df.index, high_vol_price, color='#D62728', linewidth=2.5, zorder=3, 
            label='High Volatility Price')
    
    # 5. Background Highlighting (Layering)
    # Fill the background vertically during high volatility periods
    y_min, y_max = ax.get_ylim()
    ax.fill_between(df.index, 
                    y_min, 
                    y_max, 
                    where=df['High_Vol'], 
                    color='blue', 
                    alpha=0.10, 
                    zorder=1, # Ensures the fill is beneath the price line
                    label='High Volatility Region')
    
    # Title and Labels
    ax.set_title('Index Price Movement with Conditional Volatility Highlighting', 
                 fontsize=16, loc='left')
    ax.set_ylabel('Closing Price ($)')
    ax.spines['right'].set_visible(False)
    ax.spines['top'].set_visible(False)
    
    # 6. Legend Update
    ax.legend(loc='upper left', fontsize=10)

    plt.tight_layout()
    plt.show()

# exercise_4_conditional_styling() # Uncomment to run

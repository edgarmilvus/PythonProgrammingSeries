
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
import matplotlib.ticker as mticker

def apply_tufte_theme(ax):
    """
    Applies a minimalist, Tufte-inspired theme to a Matplotlib Axes object,
    maximizing the data-ink ratio.
    """
    
    # 2. Font Management and Text Color
    text_color = '#333333'
    grid_color = '#DDDDDD'
    
    # Update global rcParams for consistent text style
    mpl.rcParams.update({
        'font.family': 'sans-serif',
        'font.sans-serif': ['Arial', 'DejaVu Sans', 'Verdana'], 
        'text.color': text_color,
        'axes.labelcolor': text_color,
        'xtick.color': text_color,
        'ytick.color': text_color,
        'axes.edgecolor': grid_color
    })
    
    # 3. Spine Removal (Top, Right, Bottom)
    ax.spines['right'].set_visible(False)
    ax.spines['top'].set_visible(False)
    ax.spines['left'].set_visible(False)
    ax.spines['bottom'].set_visible(False) 

    # 4. Minimal Grid (Horizontal only)
    ax.grid(axis='y', linestyle='--', alpha=0.6, color=grid_color, linewidth=0.7)
    ax.grid(axis='x', visible=False) 

    # 5. Axis Definition: Remove tick marks (lines)
    ax.tick_params(axis='both', which='both', length=0)
    
    # Ensure clean Y-axis formatting
    ax.yaxis.set_major_formatter(mticker.ScalarFormatter(useOffset=False, useMathText=False))
    
    return ax

def exercise_2_custom_theme():
    """Demonstrates the application of the custom Tufte theme."""
    
    # Data Simulation
    x = np.linspace(0, 10, 100)
    y = 3 * np.sin(x) + np.random.normal(0, 0.2, 100)
    
    fig, ax = plt.subplots(figsize=(9, 5))
    
    # Apply the custom theme
    ax = apply_tufte_theme(ax)
    
    # 6. Demonstration Plot
    ax.plot(x, y, color='#0077B6', linewidth=2.5, label='Simulated Data Trend')
    
    ax.set_title('Q3 Performance Analysis: Maximizing Data-Ink Ratio', 
                 fontsize=16, loc='left', pad=15)
    ax.set_ylabel('Performance Index', fontsize=12)
    ax.set_xlabel('Time (Units)', fontsize=12)
    
    ax.legend(frameon=False, loc='lower right')
    plt.tight_layout()
    plt.show()

# exercise_2_custom_theme() # Uncomment to run

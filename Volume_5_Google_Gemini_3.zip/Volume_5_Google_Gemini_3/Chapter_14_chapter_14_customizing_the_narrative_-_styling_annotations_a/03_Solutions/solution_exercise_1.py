
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
import matplotlib as mpl

def exercise_1_uniform_encoding():
    """
    Creates a stacked area plot using a custom, perceptually uniform palette,
    adhering to specified aesthetic controls.
    """
    
    # 1. Data Simulation (12 months)
    dates = pd.date_range(start='2023-01-01', periods=12, freq='M')
    np.random.seed(42)
    data = pd.DataFrame({
        'Solar': np.abs(np.random.normal(550, 80, 12)),
        'Wind': np.abs(np.random.normal(480, 120, 12)),
        'Hydro': np.abs(np.random.normal(600, 50, 12)),
        'Fossil Fuel': np.abs(np.random.normal(750, 150, 12))
    }, index=dates)

    # 2. Palette Selection: Perceptually uniform and CVD-safe qualitative colors
    # (Example: Dark2 from ColorBrewer, modified for high contrast)
    custom_colors = ['#1b9e77', '#d95f02', '#7570b3', '#e7298a'] 
    
    fig, ax = plt.subplots(figsize=(10, 6))
    
    # 4. Aesthetic Control Setup: Subtle gray background
    plot_bg_color = '#F8F8F8'
    fig.patch.set_facecolor(plot_bg_color)
    ax.set_facecolor(plot_bg_color)
    
    # 3. Visualization: Stacked Area Plot
    ax.stackplot(data.index, 
                 data['Solar'], data['Wind'], data['Hydro'], data['Fossil Fuel'], 
                 labels=data.columns, 
                 colors=custom_colors,
                 alpha=0.9)
    
    # Title and Labels
    text_color = '#333333'
    ax.set_title('Monthly Energy Consumption by Source (GJ)', fontsize=14, color=text_color, loc='left')
    ax.set_ylabel('Consumption (GJ)', fontsize=11, color=text_color)
    ax.set_xlabel('Month', fontsize=11, color=text_color)
    
    # 4. Aesthetic Control (Spines and Ticks)
    ax_line_color = '#E0E0E0'
    
    # Remove top/right spines
    ax.spines['right'].set_visible(False)
    ax.spines['top'].set_visible(False)
    
    # Set remaining spine colors to light gray
    ax.spines['left'].set_color(ax_line_color)
    ax.spines['bottom'].set_color(ax_line_color)
    
    # Set tick label colors to dark gray and increase font size
    ax.tick_params(axis='both', which='major', labelsize=10, colors=text_color)
    
    # 5. Legend Implementation
    ax.legend(loc='upper left', frameon=True, fontsize=12, edgecolor=ax_line_color, title_fontsize=12)
    
    plt.show()

# exercise_1_uniform_encoding() # Uncomment to run


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def exercise_3_narrative_annotations():
    """
    Visualizes quarterly margin data, highlighting a peak and correction phase 
    using strategic annotations and Z-order control.
    """
    
    # Data Simulation (12 quarters)
    quarters = pd.to_datetime(['2022-Q1', '2022-Q2', '2022-Q3', '2022-Q4',
                               '2023-Q1', '2023-Q2', '2023-Q3', '2023-Q4',
                               '2024-Q1', '2024-Q2', '2024-Q3', '2024-Q4'])
    
    # Simulate margin data with a spike in Q2 2023 (index 5)
    np.random.seed(10)
    base_margin = np.array([12, 13, 11, 14, 15, 25, 18, 16, 17, 18, 19, 20])
    margin_data = base_margin + np.random.normal(0, 0.5, len(quarters))
    
    x_indices = np.arange(len(quarters))
    
    fig, ax = plt.subplots(figsize=(10, 6))
    
    # 1. Data Plotting (Line plot with high Z-order for visibility)
    ax.plot(x_indices, margin_data, marker='o', linestyle='-', color='#005A9C', 
            linewidth=2, label='Quarterly Margin (%)', zorder=3)
    
    # Set X-axis labels to quarter names
    ax.set_xticks(x_indices)
    ax.set_xticklabels(quarters.strftime('%Y-%Q'), rotation=45, ha='right')
    ax.set_title('Quarterly Profitability Margin (2022-2024)', fontsize=14, loc='left')
    ax.set_ylabel('Margin (%)')
    
    # Identify the peak point (Q2 2023, index 5)
    peak_index = 5 
    peak_value = margin_data[peak_index]
    
    # 5. Baseline Reference (Historical Average)
    avg_margin = margin_data[:4].mean() 
    ax.axhline(avg_margin, color='gray', linestyle='--', linewidth=1, alpha=0.7, 
               zorder=1, label=f'Historical Avg ({avg_margin:.1f}%)')
    
    # 2. Event Highlighting (Area): Q3 2023 (index 6) - Post-launch correction phase
    # Shading the area corresponding to Q3 2023 (index 6)
    # We use indices 5.5 to 6.5 to center the shading around the Q3 point
    ax.axvspan(5.5, 6.5, color='red', alpha=0.15, zorder=1, label='Correction Phase')
    
    # 3. Critical Point Callout (Annotation)
    arrow_props = dict(
        facecolor='black', 
        shrink=0.05, 
        width=1, 
        headwidth=5,
        connectionstyle="arc3,rad=0.1" 
    )
    
    bbox_props = dict(
        boxstyle="round,pad=0.5", 
        fc="lightyellow", 
        alpha=0.9, 
        ec="black", 
        linewidth=0.8
    )
    
    # 4. Annotation placement with high Z-Order (zorder=5)
    ax.annotate("Q2 Y2: Peak Margin Post-Launch",
                xy=(peak_index, peak_value),              # Data point coordinates
                xytext=(peak_index + 2, peak_value + 5),  # Text box coordinates (offset)
                arrowprops=arrow_props,
                bbox=bbox_props,
                fontsize=10,
                color='#333333',
                ha='left',
                zorder=5) 
    
    # Cleanup
    ax.spines['right'].set_visible(False)
    ax.spines['top'].set_visible(False)
    ax.legend(loc='lower left', frameon=False)
    plt.tight_layout()
    plt.show()

# exercise_3_narrative_annotations() # Uncomment to run


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# Set a consistent style for better aesthetics
# Using the recommended style for professional output
plt.style.use('seaborn-v0_8-whitegrid')

# --- Exercise 1: The Dual Canvas - Mastering Figures and Axes ---
def solve_exercise_1():
    print("\n--- Solving Exercise 1: Figures and Axes (OO Line Plot) ---")
    
    # 1. Data Generation (60 days, cumulative random walk)
    np.random.seed(42)
    start_price = 100
    # Simulate daily returns with small fluctuations
    daily_returns = np.random.normal(0.0, 1.5, 60) 
    # Cumulative sum for price movement
    price_movement = start_price + np.cumsum(daily_returns)
    days = np.arange(1, 61)

    # 2. OO Initialization
    fig, ax = plt.subplots(figsize=(10, 6))

    # 3. Visualization Type (Line Plot)
    ax.plot(days, price_movement, color='darkblue', linewidth=2)

    # 4. Customization (using ax methods)
    ax.set_title("60-Day Simulated Stock Price Movement", fontsize=16)
    ax.set_xlabel("Trading Day Index")
    ax.set_ylabel("Closing Price (USD)")
    
    # Add baseline reference line (ax.axhline)
    ax.axhline(start_price, color='r', linestyle='--', label='Starting Price (100)')

    # 5. Aesthetics
    ax.grid(True, linestyle=':', alpha=0.7)
    ax.legend()
    plt.show()

# --- Exercise 2: Multivariate Analysis - Scatter Plots and Color Mapping ---
def solve_exercise_2():
    print("\n--- Solving Exercise 2: Scatter Plots and Color Mapping ---")
    
    # 1. Data Generation (100 students)
    np.random.seed(42)
    N = 100
    study_hours = np.random.uniform(10, 80, N)
    
    # Exam scores: positive correlation + noise
    exam_scores = 50 + 0.5 * study_hours + np.random.normal(0, 10, N)
    
    # Stress level: slight inverse correlation with scores, clipped 0-10
    stress_level = 10 - (exam_scores / 10) + np.random.normal(0, 1.5, N)
    stress_level = np.clip(stress_level, 0, 10) 

    # 2. OO Initialization
    fig, ax = plt.subplots(figsize=(10, 7))

    # 3. Visualization Type and Color Mapping
    # Map stress_level to color (c) and use 'viridis' colormap (cmap)
    scatter = ax.scatter(
        study_hours, 
        exam_scores, 
        c=stress_level, 
        cmap='viridis', 
        s=50,       # Marker size
        alpha=0.7,  # Transparency
        edgecolors='w' # White border for clarity
    )

    # 4. Customization
    ax.set_title("Study Hours vs. Exam Scores, Colored by Stress Level", fontsize=16)
    ax.set_xlabel("Study Hours per Week")
    ax.set_ylabel("Final Exam Score")

    # 5. Informative Elements (Colorbar)
    # Link the colorbar to the scatter object
    cbar = fig.colorbar(scatter, ax=ax)
    cbar.set_label("Stress Level (0-10)", rotation=270, labelpad=15)
    
    plt.show()

# --- Exercise 3: Frequency Mapping - Understanding Data Distributions ---
def solve_exercise_3():
    print("\n--- Solving Exercise 3: Histograms and Distributions ---")
    
    # 1. Data Generation
    np.random.seed(42)
    N = 500
    # Control Group: Slower reaction time (higher mean)
    control_group = np.random.normal(450, 50, N)
    # Treatment Group: Faster reaction time (lower mean)
    treatment_group = np.random.normal(400, 40, N)

    # 2. OO Initialization
    fig, ax = plt.subplots(figsize=(10, 6))

    # 3. Comparison and Aesthetics
    bins = 30
    
    # Plotting both histograms with transparency (alpha=0.6)
    ax.hist(
        control_group, 
        bins=bins, 
        alpha=0.6, 
        label='Control Group', 
        color='red'
    )
    ax.hist(
        treatment_group, 
        bins=bins, 
        alpha=0.6, 
        label='Treatment Group', 
        color='blue'
    )

    # 4. Customization and Interpretation
    ax.set_title("Comparison of Reaction Time Distributions", fontsize=16)
    ax.set_xlabel("Reaction Time (ms)")
    ax.set_ylabel("Frequency Count")
    
    # Calculate and display vertical line for Treatment Group mean
    mean_treatment = np.mean(treatment_group)
    ax.axvline(
        mean_treatment, 
        color='blue', 
        linestyle=':', 
        linewidth=2, 
        label=f'Treatment Mean ({mean_treatment:.1f}ms)'
    )
    
    # Add legend to distinguish groups and mean line
    ax.legend(loc='upper right')
    
    plt.show()

# --- Exercise 4: Interactive Challenge - Dynamic Sensor Dashboard Refinement ---
def solve_exercise_4():
    print("\n--- Solving Exercise 4: Interactive Challenge (Sensor Dashboard) ---")
    
    # 1. Data Setup (1000 time points)
    np.random.seed(42)
    time_index = np.arange(1000)
    
    # Temperature simulation: Base 25, slight positive trend, plus noise
    temperature = 25 + (time_index / 500) + np.random.normal(0, 0.5, 1000)

    # 2. Subplot Initialization (1 row, 2 columns)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

    # 3. Left Subplot (Time Series - ax1)
    ax1.plot(time_index, temperature, color='green', linewidth=1.5)
    ax1.set_title("Temporal Temperature Trend", fontsize=14)
    ax1.set_xlabel("Time Index (Readings)")
    ax1.set_ylabel("Temperature (°C)")
    ax1.grid(True, alpha=0.5)

    # 4. Right Subplot (Distribution - ax2)
    ax2.hist(temperature, bins=40, color='skyblue', edgecolor='black', alpha=0.8)
    ax2.set_title("Temperature Distribution (Frequency)", fontsize=14)
    ax2.set_xlabel("Temperature (°C)")
    ax2.set_ylabel("Frequency Count")
    ax2.grid(axis='y', alpha=0.5) 

    # 5. Global Refinements
    # Set main title for the entire Figure
    fig.suptitle("Environmental Sensor Dashboard Analysis", fontsize=18, fontweight='bold')
    
    # Adjust layout to prevent overlap, leaving space at the top for suptitle
    fig.tight_layout(rect=[0, 0.03, 1, 0.95]) 
    
    plt.show()

# Execute all solutions
if __name__ == '__main__':
    solve_exercise_1()
    solve_exercise_2()
    solve_exercise_3()
    solve_exercise_4()

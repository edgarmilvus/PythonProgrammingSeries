
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import matplotlib.pyplot as plt
import os
import datetime

# --- 1. Configuration and Constants ---
DATA_POINTS = 500  # Number of data points sampled over the simulation period
SIMULATION_HOURS = 24
OUTPUT_FILE = "server_analytics_report.png"
np.random.seed(42)  # Ensure data generation is reproducible

# --- 2. Data Simulation Function ---
def generate_server_data(n_points):
    """
    Generates synthetic server load and latency data, simulating a diurnal cycle.
    """
    # Create a time array representing 24 hours
    time_hours = np.linspace(0, SIMULATION_HOURS, n_points)
    
    # Base Request Load: Uses a sine wave to simulate high traffic during peak hours (diurnal cycle)
    base_load = 100 + 50 * np.sin(2 * np.pi * time_hours / SIMULATION_HOURS)
    
    # Add random Gaussian noise to the load data
    noise = np.random.normal(0, 15, n_points)
    request_count = (base_load + noise).astype(int)
    request_count[request_count < 0] = 0 # Ensure non-negative counts
    
    # Latency Calculation: Latency is proportional to load, simulating server strain
    latency_base = 50 + (request_count / 20) 
    # Add exponential jitter (simulating occasional slow requests or garbage collection pauses)
    latency_jitter = np.random.exponential(scale=5, size=n_points)
    response_latency_ms = latency_base + latency_jitter
    
    return time_hours, request_count, response_latency_ms

# --- 3. Visualization Core Function ---
def plot_server_analysis(time_data, load_data, latency_data, filename):
    """
    Creates a multi-panel visualization report using Matplotlib's Figure and Axes objects.
    """
    # Create a Figure (the overall canvas) and a 2x2 grid of Axes (individual plots)
    # This is the standard way to create complex, multi-panel plots
    fig, axes = plt.subplots(nrows=2, ncols=2, figsize=(14, 10))
    
    # Set a centralized title for the entire report Figure
    fig.suptitle(f"Server Performance Analysis Report ({datetime.date.today()})", 
                 fontsize=16, fontweight='bold', y=0.98) # y adjusts title position
    
    # --- Plot 1: Line Plot (Server Load Over Time) ---
    ax1 = axes[0, 0] # Selects the top-left Axis
    ax1.plot(time_data, load_data, label='Request Count', color='#1f77b4', linewidth=1.5)
    ax1.set_title("1. Diurnal Request Load Trend", loc='left')
    ax1.set_xlabel("Time (Hours)")
    ax1.set_ylabel("Requests per Interval")
    ax1.grid(True, linestyle='--', alpha=0.6)
    ax1.legend(loc='upper right')
    
    # --- Plot 2: Scatter Plot (Load vs. Latency) ---
    ax2 = axes[0, 1] # Selects the top-right Axis
    # Use load data as color intensity (C) to show severity/density
    scatter = ax2.scatter(load_data, latency_data, 
                          c=load_data, cmap='viridis', s=20, alpha=0.7)
    ax2.set_title("2. Load vs. Response Latency Correlation", loc='left')
    ax2.set_xlabel("Concurrent Requests")
    ax2.set_ylabel("Response Latency (ms)")
    # Add a color bar to explain the scatter color mapping
    fig.colorbar(scatter, ax=ax2, label='Request Count Magnitude')

    # --- Plot 3: Histogram (Latency Distribution) ---
    ax3 = axes[1, 0] # Selects the bottom-left Axis
    # Use 30 bins to show detailed distribution shape
    ax3.hist(latency_data, bins=30, color='darkorange', edgecolor='black', alpha=0.8)
    ax3.set_title("3. Distribution of Response Latency", loc='left')
    ax3.set_xlabel("Response Latency (ms)")
    ax3.set_ylabel("Frequency of Occurrence")
    
    # --- Plot 4: Placeholder/Summary Text ---
    ax4 = axes[1, 1] # Selects the bottom-right Axis
    
    # Calculate key descriptive statistics for the summary
    max_lat = np.max(latency_data)
    avg_lat = np.mean(latency_data)
    median_lat = np.median(latency_data)
    
    # Display the summary text centered on the Axis
    ax4.text(0.5, 0.5, 
             f"--- Key Performance Indicators ---\n\n"
             f"Data Points Analyzed: {len(load_data)}\n"
             f"Maximum Latency: {max_lat:.2f} ms\n"
             f"Average Latency: {avg_lat:.2f} ms\n"
             f"Median Latency: {median_lat:.2f} ms",
             transform=ax4.transAxes, ha='center', va='center', fontsize=11, family='monospace')
    ax4.set_title("4. Key Metrics Summary", loc='left')
    ax4.axis('off') # Hide the default axes lines and ticks for a cleaner summary box
    
    # Adjust layout to prevent overlap between titles and axis labels
    plt.tight_layout(rect=[0, 0.03, 1, 0.95]) # rect adjusts space for the suptitle
    
    # Save the final figure to disk
    plt.savefig(filename, dpi=300)
    plt.close(fig) # Explicitly close the figure to free memory
    print(f"Analysis report saved successfully to: {os.path.abspath(filename)}")


# --- 4. Execution Block ---
if __name__ == "__main__":
    # Generate the synthetic data
    time_data, load_data, latency_data = generate_server_data(DATA_POINTS)
    
    # Execute the plotting function, generating the multi-panel report
    plot_server_analysis(time_data, load_data, latency_data, OUTPUT_FILE)

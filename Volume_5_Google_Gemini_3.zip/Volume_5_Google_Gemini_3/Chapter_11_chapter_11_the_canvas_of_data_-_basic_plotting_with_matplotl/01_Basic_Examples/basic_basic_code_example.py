
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import matplotlib.pyplot as plt
import numpy as np

# 1. Define the data for plotting (Weekly Sales Performance)
# We use NumPy arrays for efficient numerical handling, standard practice in data science.
weeks = np.array([1, 2, 3, 4]) 
# Corresponding sales figures in thousands of dollars
sales = np.array([15.5, 17.2, 16.8, 19.1]) 

# 2. Create the Figure and Axes objects
# plt.subplots() returns a tuple: the overall container (fig) and the plot area (ax).
fig, ax = plt.subplots(figsize=(8, 5)) # Set a specific size for better visualization

# 3. Plot the data onto the Axes object
# The ax.plot() method draws the line graph.
ax.plot(weeks, sales, 
        marker='o',         # Use circular markers to highlight data points
        linestyle='-',      # Connect points with a solid line
        color='#1f77b4',    # Use a standard Matplotlib blue color (hex code)
        linewidth=2.5,      # Make the line slightly thicker
        label='Total Weekly Sales') # Label for the legend

# 4. Apply essential customizations to the Axes
# Set the title for the specific plot area
ax.set_title('Monthly Sales Trend Analysis (Object-Oriented Approach)', fontsize=14, fontweight='bold')

# Set labels for the independent (X) and dependent (Y) axes
ax.set_xlabel('Week Number', fontsize=12)
ax.set_ylabel('Sales Revenue (in $1,000s)', fontsize=12)

# 5. Enhance Readability: Grid and Limits
# Add a light grid for easier reading of values
ax.grid(True, linestyle='--', alpha=0.6)

# Ensure the Y-axis starts near the actual data range for better focus
ax.set_ylim(14.0, 20.0)

# 6. Add a legend to explain the plotted line
# The loc='upper left' parameter positions the legend strategically.
ax.legend(loc='upper left', frameon=True, shadow=True)

# 7. Ensure the layout is tight and display the figure
# fig.tight_layout() adjusts subplot parameters for a tight layout, preventing labels from overlapping.
fig.tight_layout()
plt.show()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example_part8.py
# Description: Basic Code Example
# ==========================================

# Incorrect (Global Imputation):
# df_cleaned['Age'] = df_cleaned['Age'].fillna(df_cleaned['Age'].median())

# Correct (Group-Based Imputation):
# 1. Calculate the median age *for each city group*
# 2. Apply a transformation (transform) that fills the NaN values in the original column
df_cleaned['Age_Group_Imputed'] = df_cleaned.groupby('City')['Age'].transform('median')
# 3. Use the original 'Age' column, but fill its NaNs with the group-specific medians
df_cleaned['Age'] = df_cleaned['Age'].fillna(df_cleaned['Age_Group_Imputed'])
# 4. Drop the temporary column
df_cleaned = df_cleaned.drop(columns=['Age_Group_Imputed'])


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import pandas as pd
import numpy as np

# --- 1. Data Setup: Create a simulated dataset with missing values ---

# Define the data dictionary. We use np.nan (Not a Number) to explicitly mark missing data.
data = {
    'CustomerID': [1001, 1002, 1003, 1004, 1005, 1006, 1007, 1008],
    # 'Age' has missing data (np.nan)
    'Age': [35, 42, np.nan, 28, 55, np.nan, 30, 45],
    # 'Income_k' (Income in thousands) also has missing data
    'Income_k': [60.5, 88.2, 75.0, np.nan, 110.1, 55.0, 92.5, np.nan],
    # 'City' is a categorical variable without missing data here
    'City': ['NYC', 'LA', 'Chicago', 'NYC', 'LA', 'Miami', 'Chicago', 'NYC'],
    # 'Subscription_Status' is categorical and has one missing value
    'Subscription_Status': ['Active', 'Active', 'Inactive', 'Active', 'Active', 'Active', np.nan, 'Inactive']
}
df = pd.DataFrame(data)

print("--- 1. Original DataFrame with Missing Values ---")
print(df)
print("-" * 60)

# --- 2. Diagnosis: Identify the location of missing values ---

# The isna() method generates a DataFrame of Booleans (True = Missing)
missing_mask = df.isna()
print("\n--- 2. Boolean Mask (df.isna()) ---")
print(missing_mask)
print("-" * 60)

# --- 3. Aggregation: Count missing values per column ---

# Summing the boolean mask treats True (missing) as 1 and False (present) as 0.
missing_counts = missing_mask.sum()
print("\n--- 3. Missing Value Counts per Column ---")
print(missing_counts)
print("-" * 60)

# --- 4. Imputation Strategy: Numerical Data (Age) ---

# Calculate the central tendency (Median is generally preferred for robustness)
age_median = df['Age'].median()
print(f"\nCalculated Median Age for Imputation: {age_median:.2f}")

# Create a copy to store the cleaned data, preserving the original DataFrame
df_cleaned = df.copy()

# Apply simple imputation using the calculated median for the 'Age' column
df_cleaned['Age'] = df_cleaned['Age'].fillna(age_median)

# --- 5. Imputation Strategy: Categorical Data (Subscription_Status) ---

# Calculate the Mode (most frequent value) for the categorical column
# mode() returns a Series, so we access the first element [0]
sub_mode = df_cleaned['Subscription_Status'].mode()[0]
print(f"Calculated Mode for Subscription Status: {sub_mode}")

# Apply mode imputation to the categorical column
df_cleaned['Subscription_Status'] = df_cleaned['Subscription_Status'].fillna(sub_mode)

# Note: We choose to leave 'Income_k' missing for demonstration purposes (e.g., if we planned to drop those rows later)

# --- 6. Verification: Check the cleaned DataFrame and final counts ---

print("\n--- 6. Cleaned DataFrame (Age and Subscription Status Imputed) ---")
print(df_cleaned)

# Final check: Verify that the missing counts are zero for imputed columns
final_check = df_cleaned.isna().sum()
print("\n--- 7. Final Missing Value Counts ---")
print(final_check)

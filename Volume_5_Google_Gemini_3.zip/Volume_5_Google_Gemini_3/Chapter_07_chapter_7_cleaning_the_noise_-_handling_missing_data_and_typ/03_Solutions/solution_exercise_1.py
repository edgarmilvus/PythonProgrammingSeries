
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.neighbors import KNeighborsRegressor
from datetime import datetime

# Set display options for better output visualization
pd.set_option('display.max_columns', 15)
pd.set_option('display.width', 1000)
pd.options.display.float_format = '{:.2f}'.format # Format floats for readability

# =============================================================================
# EXERCISE 1: Diagnosing Missingness Mechanisms and Strategic Imputation
# =============================================================================

print("--- Exercise 1: Missingness Diagnosis and Imputation ---")

def generate_e1_data(n_rows=500, missing_rate=0.10):
    np.random.seed(42)
    df = pd.DataFrame({
        'Years_Experience': np.random.randint(1, 20, n_rows),
        'Training_Score': np.random.normal(75, 10, n_rows),
        'Salary': np.random.normal(50000, 15000, n_rows)
    })

    # 1. MCAR Simulation (Training_Score missing randomly)
    mcar_mask = np.random.choice([True, False], size=n_rows, p=[missing_rate, 1 - missing_rate])
    df.loc[mcar_mask, 'Training_Score'] = np.nan

    # 2. MAR Simulation (Salary missing if Years_Experience is low)
    low_exp_mask = df['Years_Experience'] < 5
    
    # Base rate of missingness for everyone
    mar_mask = np.random.choice([True, False], size=n_rows, p=[0.02, 0.98]) 
    # Increase missingness rate significantly for low experience group
    mar_mask[low_exp_mask] = np.random.choice([True, False], size=low_exp_mask.sum(), p=[0.40, 0.60])
    
    df.loc[mar_mask, 'Salary'] = np.nan
    return df

e1_df = generate_e1_data()

# --- 2. Diagnosis ---

# Diagnosis for Training_Score (MCAR Candidate)
exp_mean_full = e1_df['Years_Experience'].mean()
exp_mean_ts_missing = e1_df[e1_df['Training_Score'].isna()]['Years_Experience'].mean()
print(f"\nDiagnosis of Training_Score (MCAR Check):")
print(f"Global Avg Experience: {exp_mean_full:.2f}")
print(f"Avg Experience when Training_Score is missing: {exp_mean_ts_missing:.2f}")
print("Result: Means are similar, suggesting MCAR.")

# Diagnosis for Salary (MAR Candidate)
exp_mean_salary_present = e1_df[e1_df['Salary'].notna()]['Years_Experience'].mean()
exp_mean_salary_missing = e1_df[e1_df['Salary'].isna()]['Years_Experience'].mean()
print(f"\nDiagnosis of Salary (MAR Check):")
print(f"Avg Experience when Salary is present: {exp_mean_salary_present:.2f}")
print(f"Avg Experience when Salary is missing: {exp_mean_salary_missing:.2f}")
print("Result: Missing Salary rows have significantly lower experience, suggesting MAR.")

# --- 3. Imputation Implementation ---

e1_df_imputed = e1_df.copy()

# 3a. Impute MCAR (Training_Score) with Global Mean
global_mean_ts = e1_df_imputed['Training_Score'].mean()
e1_df_imputed['Training_Score_Clean'] = e1_df_imputed['Training_Score'].fillna(global_mean_ts)

# 3b. Impute MAR (Salary) with Conditional Median
# Create categorical bins for Years_Experience
e1_df_imputed['Exp_Category'] = pd.cut(
    e1_df_imputed['Years_Experience'], 
    bins=[0, 5, 10, 20], 
    labels=['Junior', 'Mid', 'Senior'], 
    right=False
)

# Calculate conditional median using transform
conditional_median_salary = e1_df_imputed.groupby('Exp_Category')['Salary'].transform('median')

# Fill NaNs in Salary using the conditional median
e1_df_imputed['Salary_Imputed'] = e1_df_imputed['Salary'].fillna(conditional_median_salary)

# --- 4. Evaluation ---
print(f"\nEvaluation of Imputation:")
print(f"Original Salary (Observed) Mean: {e1_df['Salary'].mean():.2f}")
print(f"Imputed Salary Mean: {e1_df_imputed['Salary_Imputed'].mean():.2f}")
print(f"Original Salary (Observed) Std Dev: {e1_df['Salary'].std():.2f}")
print(f"Imputed Salary Std Dev: {e1_df_imputed['Salary_Imputed'].std():.2f}")


# =============================================================================
# EXERCISE 2: Auditing Data Type Integrity and Coercion
# =============================================================================

print("\n\n--- Exercise 2: Data Type Integrity Audit ---")

# 1. Synthetic Data Creation (100 rows)
data_e2 = {
    'Product_ID': [f'P{i:03d}' for i in range(100)],
    'Price': [f'${np.random.uniform(10, 500):.2f}' for _ in range(90)] + ['N/A', '500.00 USD', '$12.34', '100', 'N/A', '75.50', '20.00', '15.00', '10.00', '99.99'],
    # Quantity includes floats and negative values
    'Quantity': [int(np.random.randint(1, 10, 90))] + [5.5, -3, 10, -1, 2, 7, 1.0, 4.0, 6.0, -5],
    # Sale_Date includes mixed formats and an invalid date (month 13)
    'Sale_Date': ['2023-01-15'] * 50 + ['02/20/23'] * 40 + ['2023-13-01', '05/10/2023', '01/01/99', '03/03/23', '04/04/23', '05/05/23', '06/06/23', '07/07/23', '08/08/23', '09/09/23']
}
e2_df = pd.DataFrame(data_e2)

# 2. Price Cleaning and Coercion
def clean_currency(series):
    # Remove all characters except digits and decimal points
    return series.astype(str).str.replace(r'[^\d.]', '', regex=True)

e2_df['Price_Cleaned'] = clean_currency(e2_df['Price'])
# Coerce non-numeric strings (like empty strings from 'N/A' after cleaning) to NaN
e2_df['Price_Cleaned'] = pd.to_numeric(e2_df['Price_Cleaned'], errors='coerce')
print(f"Price NaNs introduced after coercion: {e2_df['Price_Cleaned'].isna().sum()}")

# 3. Quantity Validation and Correction
# Identify invalid (negative) quantities
invalid_qty_mask = e2_df['Quantity'] < 0
valid_qty_median = e2_df.loc[e2_df['Quantity'] >= 0, 'Quantity'].median()

print(f"Negative quantities found and replaced: {invalid_qty_mask.sum()}")
# Replace negative values with the median of valid values
e2_df.loc[invalid_qty_mask, 'Quantity'] = valid_qty_median

# Convert to nullable integer type (Int64)
e2_df['Quantity'] = e2_df['Quantity'].astype('Int64')
print(f"Quantity dtype after correction: {e2_df['Quantity'].dtype}")

# 4. Date Standardization
# Use infer_datetime_format to handle mixed formats, errors='coerce' to handle invalid dates
e2_df['Sale_Date_Standardized'] = pd.to_datetime(
    e2_df['Sale_Date'], 
    errors='coerce', 
    dayfirst=False # Assuming US standard MM/DD/YY
)

failed_parses = e2_df['Sale_Date_Standardized'].isna().sum()
# Drop rows where date parsing failed (e.g., 2023-13-01)
e2_df = e2_df.dropna(subset=['Sale_Date_Standardized']).copy()

print(f"Dates failed to parse (e.g., month > 12): {failed_parses}")
print(f"First 5 standardized dates:\n{e2_df['Sale_Date_Standardized'].head()}")


# =============================================================================
# EXERCISE 3: Advanced Predictive Imputation using KNN
# =============================================================================

print("\n\n--- Exercise 3: Predictive Imputation using KNN ---")

# 1. Setup and Missingness
np.random.seed(42)
n_rows_e3 = 300
e3_df = pd.DataFrame({
    'Credit_Score': np.random.normal(700, 50, n_rows_e3),
    'Employment_Status': np.random.choice(['Employed', 'Self-Employed', 'Unemployed'], n_rows_e3, p=[0.6, 0.3, 0.1]),
    'Annual_Income': np.random.normal(75000, 25000, n_rows_e3)
})

# Introduce MAR missingness (Income missing more often for Unemployed)
missing_mask = (e3_df['Employment_Status'] == 'Unemployed') & (np.random.rand(n_rows_e3) < 0.6)
e3_df.loc[missing_mask, 'Annual_Income'] = np.nan
e3_df.loc[~missing_mask & (np.random.rand(n_rows_e3) < 0.05), 'Annual_Income'] = np.nan 

# Separate data
observed_data = e3_df[e3_df['Annual_Income'].notna()].copy()
missing_data = e3_df[e3_df['Annual_Income'].isna()].copy()

print(f"Total rows missing Annual_Income: {missing_data.shape[0]}")

# 2. Feature Preparation

# Initialize Scaler and OHE
scaler = StandardScaler()
# Use OneHotEncoder to handle categorical data
ohe = OneHotEncoder(handle_unknown='ignore', sparse_output=False) 

# Define feature columns
cat_col = ['Employment_Status']
num_col = ['Credit_Score']

# Fit OHE and Scaler ONLY on Observed data
ohe.fit(observed_data[cat_col])
scaler.fit(observed_data[num_col])

# Transform data
emp_ohe_obs = ohe.transform(observed_data[cat_col])
emp_ohe_miss = ohe.transform(missing_data[cat_col])

ohe_cols = [f'Status_{c}' for c in ohe.categories_[0]]
X_obs = pd.DataFrame(emp_ohe_obs, columns=ohe_cols, index=observed_data.index)
X_miss = pd.DataFrame(emp_ohe_miss, columns=ohe_cols, index=missing_data.index)

# Standardization for Credit_Score
X_obs['Credit_Score_Scaled'] = scaler.transform(observed_data[num_col])
X_miss['Credit_Score_Scaled'] = scaler.transform(missing_data[num_col])

# Define target variable
y_obs = observed_data['Annual_Income']

# 3. KNN Imputation
knn_model = KNeighborsRegressor(n_neighbors=5)
knn_model.fit(X_obs, y_obs)

# Predict missing values
predicted_income = knn_model.predict(X_miss)

# 4. Reconstruction and Analysis
# Assign predicted values back to the original index positions
e3_df.loc[missing_data.index, 'Annual_Income_Imputed'] = predicted_income
e3_df['Annual_Income_Clean'] = e3_df['Annual_Income'].fillna(e3_df['Annual_Income_Imputed'])

original_obs_mean = observed_data['Annual_Income'].mean()
imputed_mean = e3_df['Annual_Income_Clean'].mean()
original_obs_std = observed_data['Annual_Income'].std()
imputed_std = e3_df['Annual_Income_Clean'].std()

print(f"\nKNN Imputation Results (k=5):")
print(f"Observed Income Mean: {original_obs_mean:.2f}")
print(f"Cleaned Income Mean: {imputed_mean:.2f}")
print(f"Observed Income Std Dev: {original_obs_std:.2f}")
print(f"Cleaned Income Std Dev: {imputed_std:.2f}")


# =============================================================================
# EXERCISE 4: Interactive Challenge: Refining the Advanced Loan Application Script
# =============================================================================

print("\n\n--- Exercise 4: Interactive Challenge (Loan Data Refinement) ---")

# 1. Synthetic Loan Data Setup
np.random.seed(43)
loan_data = pd.DataFrame({
    'Loan_ID': range(500),
    'Credit_Score': np.random.randint(500, 850, 500),
    'Application_Date': ['2023-05-10'] * 200 + ['12/15/22'] * 100 + ['01-01-2001'] * 100 + ['2030-01-01'] * 50 + ['1995-11-11'] * 50,
    # Purpose includes many low-frequency categories (Purpose_0 to Purpose_44)
    'Purpose': np.random.choice([f'Purpose_{i}' for i in range(45)] + ['Debt_Consolidation', 'Home_Improvement', 'Car_Purchase'], 500, 
                                p=[0.005] * 45 + [0.3, 0.2, 0.05]),
    'Risk_Grade': np.random.choice(['A', 'B', 'C', 'D', 'E', 'F'], 500, p=[0.3, 0.25, 0.2, 0.1, 0.1, 0.05])
})

# 1. Temporal Cleaning
ASSUMED_TODAY = datetime(2023, 10, 1)
MIN_DATE = datetime(2000, 1, 1)

# Standardize date format
loan_data['Application_Date'] = pd.to_datetime(loan_data['Application_Date'], errors='coerce')

# Filter out erroneous dates
initial_rows = loan_data.shape[0]
loan_data_clean = loan_data[
    (loan_data['Application_Date'] >= MIN_DATE) & 
    (loan_data['Application_Date'] <= ASSUMED_TODAY)
].copy()

rows_removed = initial_rows - loan_data_clean.shape[0]
print(f"Rows removed due to erroneous dates (before 2000 or after 2023-10-01): {rows_removed}")

# 2. Categorical Collapse (High Cardinality)
purpose_counts = loan_data_clean['Purpose'].value_counts(normalize=True)
low_frequency_threshold = 0.02 # 2%

rare_purposes = purpose_counts[purpose_counts < low_frequency_threshold].index
initial_unique_purposes = loan_data_clean['Purpose'].nunique()

# Collapse rare categories into 'Other_Purpose'
loan_data_clean['Purpose_Cleaned'] = loan_data_clean['Purpose'].apply(
    lambda x: 'Other_Purpose' if x in rare_purposes else x
)

final_unique_purposes = loan_data_clean['Purpose_Cleaned'].nunique()
print(f"\nInitial unique purposes: {initial_unique_purposes}")
print(f"Final unique purposes after collapsing rare categories: {final_unique_purposes}")
print(f"Reduction in categories: {initial_unique_purposes - final_unique_purposes}")

# 3. Ordinal Encoding
# Note: 'F' grade is treated as highest risk (6) based on synthetic data generation
grade_mapping = {'A': 1, 'B': 2, 'C': 3, 'D': 4, 'E': 5, 'F': 6}

loan_data_clean['Risk_Grade_Encoded'] = loan_data_clean['Risk_Grade'].map(grade_mapping)

# Verification (Grade 1 should correspond to higher Credit Scores)
mean_score_grade_1 = loan_data_clean[loan_data_clean['Risk_Grade_Encoded'] == 1]['Credit_Score'].mean()
mean_score_grade_5 = loan_data_clean[loan_data_clean['Risk_Grade_Encoded'] == 5]['Credit_Score'].mean()

print(f"\nVerification of Ordinal Encoding:")
print(f"Mean Credit Score for Lowest Risk (Grade 1/A): {mean_score_grade_1:.2f}")
print(f"Mean Credit Score for High Risk (Grade 5/E): {mean_score_grade_5:.2f}")


# =============================================================================
# EXERCISE 5: Feature Scaling and Final Preparation
# =============================================================================

print("\n\n--- Exercise 5: Feature Scaling and Final Preparation ---")

# 1. Data Setup
np.random.seed(44)
n_rows_e5 = 200
e5_df = pd.DataFrame({
    'Region': np.random.choice(['North', 'South', 'East', 'West'], n_rows_e5),
    'Satisfaction_Level': np.random.choice(['Low', 'Medium', 'High'], n_rows_e5, p=[0.2, 0.4, 0.4]),
    'Age': np.random.normal(40, 10, n_rows_e5),
    'Annual_Sales': np.random.normal(500000, 150000, n_rows_e5)
})

# 2. Ordinal Encoding
satisfaction_map = {'Low': 1, 'Medium': 2, 'High': 3}
e5_df['Satisfaction_Encoded'] = e5_df['Satisfaction_Level'].map(satisfaction_map)

# 3. Nominal Encoding (OHE)
region_ohe = pd.get_dummies(e5_df['Region'], prefix='Region', dtype=int)

# 4. Standard Scaling
scaler_e5 = StandardScaler()
numerical_cols = ['Age', 'Annual_Sales']
e5_df[numerical_cols] = scaler_e5.fit_transform(e5_df[numerical_cols])

print(f"\nNumerical feature statistics after Standard Scaling:")
print(e5_df[numerical_cols].agg(['mean', 'std']).round(3))

# 5. Final DataFrame Assembly
final_features = pd.concat([
    e5_df[['Satisfaction_Encoded']],
    region_ohe,
    e5_df[numerical_cols]
], axis=1)

print("\nFinal Modeling-Ready DataFrame Structure (First 5 rows):")
print(final_features.head())
print(f"Final DataFrame shape: {final_features.shape}")

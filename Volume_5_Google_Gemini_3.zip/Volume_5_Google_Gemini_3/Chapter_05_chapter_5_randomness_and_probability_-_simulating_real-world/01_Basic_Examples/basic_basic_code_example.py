
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import random
import time 

# --- Configuration and Initialization ---

# 1. Setting the Seed: Essential for reproducibility in simulations.
# The seed initializes the internal state of the generator.
SEED_VALUE = 42
random.seed(SEED_VALUE) 

# Define possible outcomes for the coin flip
COIN_SIDES = ["Heads", "Tails"]

# --- Simulation Functions ---

def simulate_die_roll():
    """Generates a discrete random integer."""
    # 2. Generating a random integer (inclusive range)
    # Simulates rolling a standard 6-sided die (1 through 6)
    # randint(a, b) includes both 'a' and 'b'
    die_result = random.randint(1, 6)
    print(f"Die Roll Result: {die_result}")
    return die_result

def simulate_coin_flip():
    """Generates a random choice from a sequence."""
    # 3. Selecting a random element from a sequence
    # Simulates flipping a fair coin
    flip_result = random.choice(COIN_SIDES)
    print(f"Coin Flip Result: {flip_result}")
    return flip_result

def simulate_random_delay():
    """Generates a continuous random float (Uniform distribution)."""
    # 4. Generating a random floating-point number 
    # Simulates a delay time between 0.5 and 2.5 seconds (uniform distribution)
    delay_time = random.uniform(0.5, 2.5)
    # Rounding for clean output, but the underlying number is float
    print(f"Simulated Delay Time: {delay_time:.3f} seconds")
    return delay_time

# --- Execution Block 1: Initial Run ---

print("--- Starting Basic Randomness Simulation (Run 1) ---")
roll_1 = simulate_die_roll()
flip_1 = simulate_coin_flip()
delay_1 = simulate_random_delay()

# --- Execution Block 2: Proving Determinism ---

print("\n--- Starting Simulation Again (Run 2: Re-seeding) ---")
# To ensure Run 2 matches Run 1, we MUST reset the generator state 
# by calling random.seed() with the SAME seed value.
random.seed(SEED_VALUE) 

roll_2 = simulate_die_roll() 
flip_2 = simulate_coin_flip() 
delay_2 = simulate_random_delay() 

print("\nVerification:")
print(f"Roll 1 ({roll_1}) == Roll 2 ({roll_2}): {roll_1 == roll_2}")
print("Notice that the results in the first and second runs are identical.")

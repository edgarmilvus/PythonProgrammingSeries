
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import math
from scipy.stats import skew, kurtosis, triang
from collections import defaultdict

# Set global plotting style and seed for reproducibility
sns.set_style("whitegrid")
np.random.seed(42)

# Define necessary helper functions from the boilerplate

# --- Exercise 1 Helper Functions ---
def simulate_clt(k, n_samples, lambda_rate=0.5):
    """
    Simulates the distribution of sample means from an Exponential distribution.
    k: size of each individual sample used to calculate a mean.
    n_samples: total number of means to generate.
    """
    # Scale parameter for Exponential is 1/lambda
    scale = 1 / lambda_rate
    
    # Generate a large matrix of samples (n_samples rows, k columns)
    samples = np.random.exponential(scale=scale, size=(n_samples, k))
    
    # Calculate the mean across each row (axis=1)
    sample_means = np.mean(samples, axis=1)
    return sample_means

# --- Exercise 2 Helper Functions ---
def estimate_pi(N):
    """
    Estimates Pi using the Monte Carlo method based on geometric probability.
    N: total number of simulation points.
    """
    # Generate N pairs of (x, y) coordinates uniformly in [-1, 1]
    x = np.random.uniform(-1, 1, N)
    y = np.random.uniform(-1, 1, N)
    
    # Check if the point is inside the unit circle (x^2 + y^2 <= 1)
    distances_squared = x**2 + y**2
    inside_circle = np.sum(distances_squared <= 1)
    
    # Pi estimation formula
    pi_estimate = 4 * (inside_circle / N)
    
    # Calculate absolute percentage error
    error = 100 * abs(pi_estimate - math.pi) / math.pi
    
    return pi_estimate, error

# --- Exercise 4 Helper Functions ---
def generate_triangular_samples(min_val, mode_val, max_val, N):
    """Generates N samples from a triangular distribution using scipy."""
    loc = min_val
    scale = max_val - min_val
    c = (mode_val - min_val) / scale
    
    # Use .rvs (random variates) method
    return triang.rvs(c, loc=loc, scale=scale, size=N)

def introduce_correlation(t_A_raw, t_B_raw):
    """
    Applies the Conditional Sampling Method (Rank Correlation) 
    to induce positive correlation.
    """
    # 1. Get the indices that would sort t_A
    sort_indices = np.argsort(t_A_raw)
    
    # 2. Apply those same indices to sort t_B
    # This aligns the largest t_A values with the largest t_B values
    t_B_corr = t_B_raw[sort_indices]
    
    return t_B_corr

# ==============================================================================
# SOLUTION START
# ==============================================================================

## Exercise 1: Verifying the Central Limit Theorem (CLT) with Non-Normal Data

### 1. Population Visualization ($k=1$)

N_SAMPLES = 10000
LAMBDA = 0.5
SCALE = 1 / LAMBDA # Scale = 2.0 for numpy exponential

# 1. Generate population data (k=1)
population_data = np.random.exponential(scale=SCALE, size=N_SAMPLES)

plt.figure(figsize=(12, 4))
plt.subplot(1, 3, 1)
plt.hist(population_data, bins=50, density=True, color='red', alpha=0.7)
plt.title(f'Population Distribution (k=1)\nExponential $\lambda={LAMBDA}$', fontsize=10)
plt.xlabel('Value')
plt.ylabel('Density')
plt.tight_layout()
plt.show()

### 2. Simulation Loop (CLT Demonstration)

# Run simulations for k=1, k=5, and k=30
means_k1 = simulate_clt(k=1, n_samples=N_SAMPLES, lambda_rate=LAMBDA)
means_k5 = simulate_clt(k=5, n_samples=N_SAMPLES, lambda_rate=LAMBDA)
means_k30 = simulate_clt(k=30, n_samples=N_SAMPLES, lambda_rate=LAMBDA)

### 3. Comparative Visualization

plt.figure(figsize=(15, 5))

# Plot k=1 (Should look like the original Exponential distribution)
plt.subplot(1, 3, 1)
sns.histplot(means_k1, kde=True, bins=50, color='red')
plt.title('Distribution of Sample Means (k=1)')
plt.xlabel('Sample Mean')

# Plot k=5
plt.subplot(1, 3, 2)
sns.histplot(means_k5, kde=True, bins=50, color='orange')
plt.title('Distribution of Sample Means (k=5)')
plt.xlabel('Sample Mean')

# Plot k=30 (Should look approximately Normal)
plt.subplot(1, 3, 3)
sns.histplot(means_k30, kde=True, bins=50, color='green')
plt.title('Distribution of Sample Means (k=30)')
plt.xlabel('Sample Mean')

plt.suptitle('Convergence to Normal Distribution (Central Limit Theorem)', fontsize=14)
plt.tight_layout(rect=[0, 0.03, 1, 0.95])
plt.show()

### 4. Statistical Quantification

# Calculate Skewness and Kurtosis (Excess Kurtosis)
skew_k1 = skew(means_k1)
kurt_k1 = kurtosis(means_k1)

skew_k30 = skew(means_k30)
kurt_k30 = kurtosis(means_k30)

print("\n--- Statistical Confirmation of CLT ---")
print("Target for Normal Distribution: Skewness ≈ 0, Excess Kurtosis ≈ 0")
print(f"\nScenario k=1 (Population):")
print(f"  Skewness: {skew_k1:.4f} (Highly Skewed)")
print(f"  Excess Kurtosis: {kurt_k1:.4f} (Heavy Tail)")

print(f"\nScenario k=30 (CLT Applied):")
print(f"  Skewness: {skew_k30:.4f} (Close to 0)")
print(f"  Excess Kurtosis: {kurt_k30:.4f} (Close to 0)")
print("\nConclusion: As k increases to 30, the distribution statistics approach those of a Normal distribution.")


## Exercise 2: Monte Carlo Simulation for Geometric Probability (Estimating Pi)

### 1. Simulation and Convergence Analysis

N_values = [10**i for i in range(2, 7)] # 100 to 1,000,000
pi_estimates = []
errors = []

for N in N_values:
    pi_est, error = estimate_pi(N)
    pi_estimates.append(pi_est)
    errors.append(error)
    print(f"N={N:<7} | Estimate={pi_est:.6f} | Error={error:.4f}%")

### 2. Visualization of Convergence

log_N = np.log10(N_values)
true_pi = math.pi

plt.figure(figsize=(10, 6))
plt.plot(log_N, pi_estimates, marker='o', linestyle='-', color='darkblue', label='MC Estimate')
plt.axhline(true_pi, color='red', linestyle='--', label=f'True $\pi$ ({true_pi:.6f})')

# Annotate the final result
plt.scatter(log_N[-1], pi_estimates[-1], color='green', s=100, zorder=5)
plt.annotate(f'Final Estimate: {pi_estimates[-1]:.5f}', 
             (log_N[-1], pi_estimates[-1]), 
             textcoords="offset points", xytext=(-10, 10), ha='right')

plt.title('Monte Carlo Estimation of $\pi$: Convergence Analysis')
plt.xlabel('Log Base 10 of Total Trials ($\log_{10}(N)$)')
plt.ylabel('Estimated Value of $\pi$')
plt.legend()
plt.grid(True, which="both", ls="--", c='0.7')
plt.show()


## Exercise 3: Advanced Monte Carlo for Inventory Optimization

### 1. Simulation Structure and Function

def run_inventory_simulation(ROP, initial_inventory=1000, days=365):
    """
    Runs a single trial of the inventory simulation for a given Reorder Point (ROP).
    Returns the total accumulated cost.
    """
    inventory = initial_inventory
    total_cost = 0.0
    
    # Fixed parameters
    ORDER_QTY = 1000
    HOLDING_COST = 0.50
    LOST_SALES_COST = 10.00
    
    # Stores scheduled orders: {arrival_day: quantity}
    # Using defaultdict for convenience, though a standard dict with checks works too.
    scheduled_arrivals = defaultdict(int) 
    
    for day in range(1, days + 1):
        # 1. Check for arrivals
        if day in scheduled_arrivals:
            inventory += scheduled_arrivals[day]
            del scheduled_arrivals[day]
            
        # 2. Sample Demand (Normal, truncated at 0)
        demand = np.random.normal(100, 15)
        demand = max(0, int(round(demand)))
        
        # 3. Handle Sales and Stockout
        sales = min(inventory, demand)
        lost_sales = demand - sales
        
        # Update inventory after sales
        inventory -= sales
        
        # 4. Calculate Costs
        stockout_cost = lost_sales * LOST_SALES_COST
        
        # Holding cost is calculated on end-of-day inventory
        holding_cost = inventory * HOLDING_COST
        
        total_cost += stockout_cost + holding_cost
        
        # 5. Reordering Logic (Check ROP *after* sales)
        if inventory <= ROP and ORDER_QTY not in scheduled_arrivals.values():
            # Place order: Sample lead time (Uniform [3, 7])
            # np.random.randint(low, high) generates integers [low, high-1]
            lead_time = np.random.randint(3, 8) 
            arrival_day = day + lead_time
            
            # Schedule the arrival
            scheduled_arrivals[arrival_day] += ORDER_QTY
            
    return total_cost

### 2. Monte Carlo Execution and Reporting

N_TRIALS = 5000
ROPS = [300, 500, 700]
results = {}

print("\n--- Inventory Simulation Results (5,000 Trials) ---")
for ROP in ROPS:
    costs = [run_inventory_simulation(ROP) for _ in range(N_TRIALS)]
    costs = np.array(costs)
    
    mean_cost = np.mean(costs)
    p5_cost = np.percentile(costs, 5)
    p95_cost = np.percentile(costs, 95)
    
    results[ROP] = {
        'mean': mean_cost,
        'p5': p5_cost,
        'p95': p95_cost
    }
    
    print(f"\nReorder Point (ROP) = {ROP} units:")
    print(f"  Mean Total Cost: ${mean_cost:,.2f}")
    print(f"  5th Percentile (P5): ${p5_cost:,.2f}")
    print(f"  95th Percentile (P95, Worst Case): ${p95_cost:,.2f}")

### 3. Optimal ROP Determination

# Determine ROP with lowest mean cost
best_mean_rop = min(results, key=lambda r: results[r]['mean'])

# Determine ROP with lowest P95 cost (most robust against high costs)
best_p95_rop = min(results, key=lambda r: results[r]['p95'])

print("\n--- Optimal Strategy Analysis ---")
print(f"ROP for Lowest Mean Cost: {best_mean_rop} (${results[best_mean_rop]['mean']:,.2f})")
print(f"ROP for Lowest P95 Cost (Risk Minimization): {best_p95_rop} (${results[best_p95_rop]['p95']:,.2f})")


## Exercise 4: Interactive Challenge - Introducing Correlation in Project Risk Simulation

N_TRIALS = 50000

# 1. Distribution Generation Parameters
# Task A: min=10, mode=15, max=30. c = 0.25
# Task B: min=5, mode=10, max=20. c = 1/3 (0.333...)

# Generate raw samples
t_A_raw = generate_triangular_samples(10, 15, 30, N_TRIALS)
t_B_raw = generate_triangular_samples(5, 10, 20, N_TRIALS)

### 2. Independent Scenario
T_indep = t_A_raw + t_B_raw

### 3. Correlated Scenario
t_B_corr = introduce_correlation(t_A_raw, t_B_raw)
T_corr = t_A_raw + t_B_corr

### 4. Correlation Verification

# Calculate correlation coefficients
corr_indep = np.corrcoef(t_A_raw, t_B_raw)[0, 1]
corr_corr = np.corrcoef(t_A_raw, t_B_corr)[0, 1]

print("\n--- Correlation Verification ---")
print(f"Correlation (Independent Scenario): ρ = {corr_indep:.4f} (Close to 0)")
print(f"Correlation (Correlated Scenario): ρ = {corr_corr:.4f} (Strong Positive)")

### 5. Risk Quantification and Visualization

DEADLINE = 40 # days

# Calculate probability of delay P(T > 40)
prob_delay_indep = np.sum(T_indep > DEADLINE) / N_TRIALS
prob_delay_corr = np.sum(T_corr > DEADLINE) / N_TRIALS

print("\n--- Project Risk Quantification ---")
print(f"Probability of Delay (T > {DEADLINE} days):")
print(f"  Independent Scenario: {prob_delay_indep:.4f} ({prob_delay_indep*100:.2f}%)")
print(f"  Correlated Scenario: {prob_delay_corr:.4f} ({prob_delay_corr*100:.2f}%)")
print(f"Correlation increased the delay probability by {((prob_delay_corr / prob_delay_indep) - 1) * 100:.1f}%")

# Visualization
plt.figure(figsize=(10, 6))

sns.histplot(T_indep, bins=50, kde=True, color='blue', alpha=0.5, 
             label=f'Independent (P(Delay)={prob_delay_indep:.3f})', stat='density')
sns.histplot(T_corr, bins=50, kde=True, color='red', alpha=0.5, 
             label=f'Correlated (P(Delay)={prob_delay_corr:.3f})', stat='density')

plt.axvline(DEADLINE, color='black', linestyle='--', linewidth=2, label=f'Deadline ({DEADLINE} days)')

plt.title('Impact of Correlation on Project Duration Risk')
plt.xlabel('Total Project Duration (Days)')
plt.ylabel('Density')
plt.legend()
plt.show()

# ==============================================================================
# SOLUTION END
# ==============================================================================

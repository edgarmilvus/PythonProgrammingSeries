
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# --- 1. Define the Problem Data ---

# X: Advertising Spend (in thousands of dollars) - The Feature
# This is our independent variable.
ad_spend = np.array([1.0, 2.0, 3.0, 4.0, 5.0, 6.0])

# y: Weekly Sales (in tens of thousands of dollars) - The Target
# This is the variable we want to predict.
weekly_sales = np.array([2.1, 4.0, 6.2, 7.9, 10.1, 12.0])

# --- 2. Data Preparation for scikit-learn ---

# CRITICAL: scikit-learn requires the feature matrix (X) to be 2-dimensional.
# We reshape the 1D array (shape 6,) into a 2D array (shape 6, 1).
# The -1 tells NumPy to calculate the necessary dimension (6 rows), and 1 specifies 1 column (one feature).
X = ad_spend.reshape(-1, 1)
y = weekly_sales # y (the target) remains 1D

# --- 3. Model Initialization and Training ---

# 3a. Instantiate the Linear Regression model object.
model = LinearRegression()

# 3b. Train the model using the .fit() method.
# The fit method calculates the optimal intercept (b0) and coefficient (b1).
model.fit(X, y)

# --- 4. Making Predictions ---

# Use the trained model to predict sales based on the input features (X).
predictions = model.predict(X)

# --- 5. Model Interpretation (Coefficients) ---

# The intercept (b0): Predicted sales when ad spend is zero.
intercept = model.intercept_

# The coefficient (b1): The slope; the change in y for a unit change in X.
# model.coef_ returns an array, so we access the first (and only) element.
coefficient = model.coef_[0]

# --- 6. Evaluation Metrics ---

# 6a. Calculate R-squared (Coefficient of Determination)
# R2 measures the proportion of the variance in y explained by X.
r2 = r2_score(y, predictions)

# 6b. Calculate Mean Squared Error (MSE)
# MSE is the average of the squared errors (residual differences).
mse = mean_squared_error(y, predictions)

# 6c. Calculate Root Mean Squared Error (RMSE)
# RMSE is the square root of MSE, putting the error back into the original units ($10k).
rmse = np.sqrt(mse)

# --- 7. Output Results ---
print("--- Simple Linear Regression Analysis ---")
print(f"Data Points Used: {len(X)}")
print(f"\nModel Parameters:")
print(f"  Intercept (b0): {intercept:.3f}")
print(f"  Coefficient (b1): {coefficient:.3f}")
print(f"Regression Equation: Sales = {coefficient:.3f} * Spend + {intercept:.3f}")

print(f"\nEvaluation Metrics:")
print(f"  R-squared (R2): {r2:.4f}")
print(f"  Mean Squared Error (MSE): {mse:.4f}")
print(f"  Root Mean Squared Error (RMSE): {rmse:.4f}")

# Example Prediction for a new spend value ($8k)
new_spend_data = np.array([[8.0]]) # Must also be 2D
predicted_sales = model.predict(new_spend_data)[0]
print(f"\nPrediction for $8k Spend: {predicted_sales:.2f} (i.e., ${predicted_sales*10000:.2f})")

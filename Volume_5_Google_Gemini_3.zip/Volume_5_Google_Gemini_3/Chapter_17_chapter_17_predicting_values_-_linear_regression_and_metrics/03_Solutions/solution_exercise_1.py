
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt

# --- Setup Code (Data Simulation) ---
np.random.seed(42)
X_e1 = np.arange(1, 101).reshape(-1, 1) / 10.0
y_e1 = 500 + 300 * X_e1.flatten() + np.random.normal(0, 400, size=X_e1.shape[0])
data_e1 = pd.DataFrame({'Vehicle_Age': X_e1.flatten(), 'Maintenance_Cost': y_e1})

# 1. Data Preparation
X_train_e1, X_test_e1, y_train_e1, y_test_e1 = train_test_split(
    data_e1[['Vehicle_Age']], data_e1['Maintenance_Cost'], test_size=0.2, random_state=42
)

# 2. Model Training
model_e1 = LinearRegression()
model_e1.fit(X_train_e1, y_train_e1)

# 3. Coefficient Interpretation
intercept_e1 = model_e1.intercept_
slope_e1 = model_e1.coef_[0]

print("--- Exercise 1: Simple Linear Regression Results ---")
print(f"Intercept (β₀): {intercept_e1:.2f}")
print(f"Slope (β₁): {slope_e1:.2f}")

print("\n--- Coefficient Interpretation ---")
print(f"The intercept ({intercept_e1:.2f}) represents the estimated base maintenance cost (in dollars) for a brand new vehicle (Age = 0).")
print(f"The slope ({slope_e1:.2f}) means that for every one-year increase in vehicle age, the annual maintenance cost is estimated to increase by approximately ${slope_e1:.2f}, holding all other factors constant.")

# 4. Prediction and Evaluation
y_pred_e1 = model_e1.predict(X_test_e1)
r2_e1 = r2_score(y_test_e1, y_pred_e1)
mse_e1 = mean_squared_error(y_test_e1, y_pred_e1)
rmse_e1 = np.sqrt(mse_e1)

print("\n--- Test Set Evaluation Metrics ---")
print(f"R² Score: {r2_e1:.4f}")
print(f"Mean Squared Error (MSE): {mse_e1:.2f}")
print(f"Root Mean Squared Error (RMSE): {rmse_e1:.2f}")

# 5. Residual Visualization
residuals_e1 = y_test_e1 - y_pred_e1

plt.figure(figsize=(10, 6))
plt.scatter(y_pred_e1, residuals_e1, alpha=0.6)
plt.hlines(0, xmin=y_pred_e1.min(), xmax=y_pred_e1.max(), color='red', linestyle='--')
plt.title('Residual Plot: Maintenance Cost Prediction')
plt.xlabel('Predicted Maintenance Cost')
plt.ylabel('Residuals (Actual - Predicted)')
plt.grid(True, linestyle=':', alpha=0.5)
plt.show()

print("\n--- Residual Analysis ---")
print("The residual plot shows the errors (residuals) scattered randomly around the zero line, forming a generally uniform band.")
print("This indicates that the assumption of linearity is appropriate for the underlying relationship, and the model is not systematically over- or under-predicting costs based on the predicted value range. The wide vertical spread is due to the inherent noise (variance) in the simulated data.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from sklearn.model_selection import cross_val_score

# --- Setup (Reusing E2 data) ---
# X_e4 and y_e4 are the one-hot encoded features and target from Exercise 2
# X_e4 (Features): Size, Condition_New, Condition_Used
# y_e4 (Target): Price

print("--- Exercise 4: Robust Evaluation using K-Fold Cross-Validation ---")

model_e4 = LinearRegression()
K = 5 # Number of folds

# 2 & 3. K-Fold Implementation and Metric Focus (Negative MSE)
# cross_val_score returns negative values for error metrics
nmse_scores = cross_val_score(
    model_e4, X_e4, y_e4, cv=K, scoring='neg_mean_squared_error'
)

# 4. Result Transformation: Convert Negative MSE to Positive RMSE
# MSE = -NMSE
mse_scores = -nmse_scores
rmse_scores = np.sqrt(mse_scores)

# 5. Reporting
mean_rmse = rmse_scores.mean()
std_rmse = rmse_scores.std()

print(f"\nK-Fold Cross-Validation Results (K={K}):")
for i, rmse in enumerate(rmse_scores):
    print(f"Fold {i+1} RMSE: {rmse:.2f}")

print("\n--- Summary of Cross-Validated Performance ---")
print(f"Mean Cross-Validated RMSE: {mean_rmse:.2f}")
print(f"Standard Deviation of RMSE: {std_rmse:.2f}")

print("\n--- Importance of Standard Deviation ---")
print("The standard deviation of the RMSE across the folds is a critical measure of model stability.")
print(f"A low standard deviation (like {std_rmse:.2f}) indicates that the model's performance is consistent regardless of which specific subset of the data is used for training and testing.")
print("If the standard deviation were high, it would suggest the model is unstable or highly sensitive to the specific data points included in the training set, potentially signaling issues like data heterogeneity or insufficient sample size.")

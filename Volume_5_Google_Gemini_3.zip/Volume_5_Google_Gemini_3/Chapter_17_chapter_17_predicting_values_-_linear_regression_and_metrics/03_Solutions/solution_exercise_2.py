
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Reuse data_mlr from setup
# data_mlr contains Size, Condition, Price

print("--- Exercise 2: Multiple Linear Regression with Categorical Features ---")

# 1. Feature Transformation (One-Hot Encoding)
X_e2 = data_mlr.drop('Price', axis=1)
y_e2 = data_mlr['Price']

# Use drop_first=True to avoid multicollinearity. 'Refurbished' is the reference category.
X_e2 = pd.get_dummies(X_e2, columns=['Condition'], drop_first=True)

# 2. Data Preparation (75/25 split)
X_train_e2, X_test_e2, y_train_e2, y_test_e2 = train_test_split(
    X_e2, y_e2, test_size=0.25, random_state=42
)

# 3. Model Training
model_e2 = LinearRegression()
model_e2.fit(X_train_e2, y_train_e2)

# 4. Coefficient Interpretation
coefficients_e2 = pd.Series(model_e2.coef_, index=X_train_e2.columns)
intercept_e2 = model_e2.intercept_

print("\nFitted Model Coefficients:")
print(f"Intercept: {intercept_e2:.2f}")
print(coefficients_e2.round(2))

print("\n--- Coefficient Interpretation ---")

# Interpretation of Size
size_coef = coefficients_e2['Size']
print(f"Size Coefficient ({size_coef:.2f}): For every one-unit increase in size, the predicted price increases by ${size_coef:.2f}, holding the condition constant.")

# Interpretation of Condition_New
new_coef = coefficients_e2['Condition_New']
print(f"Condition_New Coefficient ({new_coef:.2f}): An item in 'New' condition is predicted to be ${new_coef:.2f} more expensive than the reference category ('Refurbished'), assuming the size is the same.")

# 5. Evaluation
y_pred_e2 = model_e2.predict(X_test_e2)
r2_e2 = r2_score(y_test_e2, y_pred_e2)
rmse_e2 = np.sqrt(mean_squared_error(y_test_e2, y_pred_e2))

print("\n--- Test Set Evaluation Metrics ---")
print(f"R² Score: {r2_e2:.4f}")
print(f"Root Mean Squared Error (RMSE): {rmse_e2:.2f}")

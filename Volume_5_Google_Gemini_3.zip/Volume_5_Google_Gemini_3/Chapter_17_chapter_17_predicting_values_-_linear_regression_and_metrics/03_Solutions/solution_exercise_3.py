
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Reuse data split from setup: X_train_e3, X_test_e3, y_train_e3, y_test_e3

print("--- Exercise 3: Model Selection and Overfitting Challenge ---")

# Helper function for metric calculation
def calculate_metrics(y_true, y_pred):
    mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_true, y_pred)
    return r2, mse, rmse

# 1. Feature Engineering for Model B
X_train_e3_B = X_train_e3.copy()
X_test_e3_B = X_test_e3.copy()
X_train_e3_B['X1_5'] = X_train_e3['X1']**5
X_test_e3_B['X1_5'] = X_test_e3['X1']**5

# --- Model A (Simple Linear: Y ~ X1) ---
model_A = LinearRegression()
model_A.fit(X_train_e3, y_train_e3)

# Metrics A
r2_train_A, _, rmse_train_A = calculate_metrics(y_train_e3, model_A.predict(X_train_e3))
r2_test_A, _, rmse_test_A = calculate_metrics(y_test_e3, model_A.predict(X_test_e3))

# --- Model B (Complex: Y ~ X1 + X1^5) ---
model_B = LinearRegression()
model_B.fit(X_train_e3_B, y_train_e3)

# Metrics B
r2_train_B, _, rmse_train_B = calculate_metrics(y_train_e3, model_B.predict(X_train_e3_B))
r2_test_B, _, rmse_test_B = calculate_metrics(y_test_e3, model_B.predict(X_test_e3_B))

# Reporting Results
results = pd.DataFrame({
    'Metric': ['R²', 'RMSE'],
    'Model A Train': [r2_train_A, rmse_train_A],
    'Model A Test': [r2_test_A, rmse_test_A],
    'Model B Train': [r2_train_B, rmse_train_B],
    'Model B Test': [r2_test_B, rmse_test_B]
}).set_index('Metric').round(4)

print("\nComparison of Model Performance:")
print(results)

print("\n--- Critical Analysis ---")
print("1. Generalization Gap:")
print(f"Model A (Simple) Test RMSE: {rmse_test_A:.4f} | Train RMSE: {rmse_train_A:.4f}. Small gap, indicating good generalization.")
print(f"Model B (Complex) Test RMSE: {rmse_test_B:.4f} | Train RMSE: {rmse_train_B:.4f}. Large gap, indicating overfitting.")

print("\nModel B achieved a slightly better R² and lower RMSE on the training data, demonstrating its ability to fit the noise and specific patterns of the training set.")
print("However, Model B's performance significantly degrades on the unseen test data (Test RMSE is higher than Model A's Test RMSE). This large difference between training and test metrics is the **Generalization Gap**, which is the hallmark of **overfitting**.")

print("\n2. Model Selection:")
print(f"Model A Test RMSE: {rmse_test_A:.4f}")
print(f"Model B Test RMSE: {rmse_test_B:.4f}")
print("Model A should be selected for deployment because it has a lower RMSE on the test set. It generalizes better to new, unseen data, which is the primary goal of predictive modeling.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import numpy as np
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.statespace.sarimax import SARIMAX
from statsmodels.tsa.stattools import adfuller
import warnings
warnings.filterwarnings("ignore") # Suppress convergence warnings for textbook clarity

# --- 1. Setup and Data Simulation ---
def generate_time_series_data(start_date, periods):
    """Generates synthetic daily price data with trend and weekly seasonality."""
    # Create the DatetimeIndex spanning the required periods
    dates = pd.date_range(start=start_date, periods=periods, freq='D')
    
    # Base trend: increasing linear function over time
    trend = np.arange(periods) * 0.5
    
    # Introduce random noise and a defined weekly seasonality (period=7)
    noise = np.random.normal(0, 5, periods)
    seasonality = 20 * np.sin(2 * np.pi * np.arange(periods) / 7)
    
    # Combined series starts at 100
    data = 100 + trend + seasonality + noise
    df = pd.DataFrame({'Price': data}, index=dates)
    return df

# --- 2. Core Time Series Analysis Pipeline ---

def run_forecasting_pipeline(df_daily, forecast_steps=4):
    """Processes, decomposes, and forecasts the time series data."""
    print("--- 2.1 Initial Data Preparation and Resampling ---")
    
    # CRITICAL STEP: Resample daily data ('D') to weekly averages ('W')
    # This reduces noise and aligns the frequency for seasonal analysis (52 weeks/year)
    df_weekly = df_daily['Price'].resample('W').mean().to_frame()
    
    # Ensure no NaN values remain after resampling
    df_weekly.dropna(inplace=True)
    
    # --- 2.2 Time Series Decomposition ---
    # Decompose the weekly series into Trend, Seasonal, and Residual components
    decomposition = seasonal_decompose(df_weekly['Price'], model='additive', period=52) 
    print(f"Trend component mean: {decomposition.trend.mean():.2f}")
    
    # --- 2.3 Stationarity Testing (Augmented Dickey-Fuller Test) ---
    # ADF test checks if the statistical properties of the series change over time
    result = adfuller(df_weekly['Price'].dropna())
    print("\n--- 2.3 ADF Test Results ---")
    print(f'ADF Statistic: {result[0]:.4f}')
    print(f'P-value: {result[1]:.4f}')
    
    # Determine the non-seasonal differencing order (d)
    d_order = 0
    if result[1] > 0.05:
        print("Series is non-stationary (P > 0.05). Differencing (d=1) required.")
        d_order = 1
    else:
        print("Series is stationary.")

    # --- 2.4 SARIMA Model Fitting and Forecasting ---
    # SARIMA requires three non-seasonal (p, d, q) and four seasonal (P, D, Q, S) parameters.
    # We use a yearly seasonality (S=52 weeks) and the determined 'd_order'.
    order = (1, d_order, 1)
    seasonal_order = (1, 1, 1, 52) 
    
    print("\n--- 2.4 Fitting SARIMA Model ---")
    try:
        model = SARIMAX(df_weekly['Price'], 
                        order=order, 
                        seasonal_order=seasonal_order, 
                        enforce_stationarity=False,
                        enforce_invertibility=False)
        
        sarima_results = model.fit(disp=False)
        print("Model fitted successfully. AIC:", sarima_results.aic)
        
        # Generate the forecast (out-of-sample prediction)
        forecast = sarima_results.get_forecast(steps=forecast_steps)
        
        # Extract confidence intervals and predicted means
        forecast_df = forecast.conf_int(alpha=0.05) # 95% confidence interval
        forecast_df['Predicted Price'] = forecast.predicted_mean
        
        print(f"\n--- 2.5 Forecasted Weekly Prices (Next {forecast_steps} Weeks) ---")
        print(forecast_df[['Predicted Price', 'lower Price', 'upper Price']])
        
        return df_weekly, sarima_results, forecast_df
        
    except Exception as e:
        print(f"Error fitting SARIMA model: {e}")
        return None, None, None

# --- 3. Execution ---
if __name__ == "__main__":
    # Simulate 3 years of daily data (1095 days)
    TIME_PERIODS = 3 * 365
    FORECAST_WEEKS = 4 # Predict the next 4 weeks
    
    raw_data = generate_time_series_data('2021-01-01', TIME_PERIODS)
    
    # Ensure index type consistency before processing
    if not isinstance(raw_data.index, pd.DatetimeIndex):
        raw_data.index = pd.to_datetime(raw_data.index)
        
    df_processed, model_results, forecast_data = run_forecasting_pipeline(raw_data, FORECAST_WEEKS)
    
    if df_processed is not None:
        # Example output confirmation of date handling
        print(f"\nFinal Historical Data Range: {df_processed.index.min()} to {df_processed.index.max()}")
        print(f"Forecast Data Range: {forecast_data.index.min()} to {forecast_data.index.max()}")

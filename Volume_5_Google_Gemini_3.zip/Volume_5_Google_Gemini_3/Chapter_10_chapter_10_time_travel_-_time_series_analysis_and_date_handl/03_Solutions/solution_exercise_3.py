
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import pandas as pd
import numpy as np
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.stattools import adfuller

# --- Simulated Quarterly Revenue Data (20 quarters) ---
dates = pd.date_range(start='2019-01-01', periods=20, freq='QS')
# Base trend
trend = np.linspace(100, 200, 20)
# Multiplicative seasonality (Q4 is highest)
seasonality = np.array([0.8, 0.9, 1.0, 1.3] * 5)
# Noise
np.random.seed(10)
noise = np.random.normal(1, 0.05, 20)
revenue = trend * seasonality * noise
revenue_ts = pd.Series(revenue, index=dates, name='Revenue')

# 1. Decomposition (Multiplicative, Period=4 for Quarterly Data)
decomposition = seasonal_decompose(
    revenue_ts,
    model='multiplicative',
    period=4
)

# 2. Visualization (Conceptual)
print("--- Decomposition Results ---")
print("Model Type: Multiplicative (Y_t = T_t * S_t * R_t)")
print("Components:")
print(" - Trend (T_t): The long-term, underlying movement (increasing revenue).")
print(" - Seasonal (S_t): The repeating, fixed pattern within a year (Q4 spikes).")
print(" - Residual (R_t): The remaining irregular, random noise component.")

# 3. Stationarity Test (ADF) on Residuals
residuals = decomposition.resid

# Handle NaN values created by the moving average calculation at the edges
clean_residuals = residuals.dropna()

# Apply the Augmented Dickey-Fuller test
adf_result = adfuller(clean_residuals)

print("\n--- Augmented Dickey-Fuller Test on Residuals ---")
print(f"ADF Statistic: {adf_result[0]:.4f}")
p_value = adf_result[1]
print(f"P-Value: {p_value:.4f}")
print("Critical Values (5%):", adf_result[4]['5%'])

# 4. Interpretation
alpha = 0.05
if p_value <= alpha:
    interpretation = "Reject the Null Hypothesis (Non-Stationary). The residual component is STATIONARY."
else:
    interpretation = "Fail to Reject the Null Hypothesis. The residual component is NON-STATIONARY."

print("\n--- Interpretation ---")
print(f"Significance Level (alpha): {alpha}")
print(interpretation)

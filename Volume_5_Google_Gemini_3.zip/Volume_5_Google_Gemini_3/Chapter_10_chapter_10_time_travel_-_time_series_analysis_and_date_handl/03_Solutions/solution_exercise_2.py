
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import pandas as pd
import numpy as np

# --- Simulated Input Data (Minute Frequency) ---
np.random.seed(42)
start_date = '2024-01-01 09:00:00'
end_date = '2024-03-31 17:00:00'
dates = pd.date_range(start=start_date, end=end_date, freq='min')
prices = 100 + np.cumsum(np.random.normal(0, 0.1, len(dates)))
minute_data = pd.Series(prices, index=dates, name='Price')

# 1. Resampling (Weekly OHLC)
weekly_ohlc = minute_data.resample('W').ohlc()

# Extract the relevant data and flatten the column names
weekly_data = weekly_ohlc['Price'].copy()
weekly_data.columns = ['Open', 'High', 'Low', 'Close']

print("--- Weekly OHLC Data (Head) ---")
print(weekly_data.head())

# 2. Rolling Mean Feature (4-week SMA of Close price, centered)
weekly_data['SMA_4W'] = weekly_data['Close'].rolling(
    window=4,
    center=True
).mean()

# 3. Lag Features
# Lag 1 week (t-1)
weekly_data['Lag_1W'] = weekly_data['Close'].shift(1)
# Lag 4 weeks (t-4)
weekly_data['Lag_4W'] = weekly_data['Close'].shift(4)

# 4. Data Cleaning (Drop rows with NaN features)
# These NaNs result from the initial 4 weeks needed for Lag_4W and the centered SMA calculation.
weekly_features_df = weekly_data.dropna()

print("\n--- Weekly Feature Engineered Data (Head) ---")
print(weekly_features_df.head(10))
print(f"\nTotal rows after cleaning: {len(weekly_features_df)}")

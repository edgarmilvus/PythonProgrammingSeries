
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import numpy as np
from datetime import datetime

# --- Simulated Input Data ---
# London Data (Naive, Local time: Europe/London)
london_dates = [
    '2023-03-25 10:00:00',
    '2023-03-26 01:30:00',  # Before DST switch (GMT)
    '2023-03-26 03:30:00',  # After DST switch (BST)
    '2023-03-27 10:00:00'
]
london_usage = pd.Series(
    [10.5, 12.1, 15.0, 11.2],
    index=pd.to_datetime(london_dates),
    name='London_Usage'
)

# Seattle Data (Unix Epoch, UTC time zone implied)
seattle_epochs = [
    1679738400,
    1679824800,
    1679911200,
    1679997600
]
seattle_usage = pd.Series(
    [5.5, 6.1, 7.0, 5.2],
    index=seattle_epochs,
    name='Seattle_Usage'
)

# 1. London Data Localization and UTC Conversion
# Localize the naive index to Europe/London time zone
london_localized = london_usage.index.tz_localize('Europe/London')
london_usage.index = london_localized
# Convert the localized index to UTC
london_utc = london_usage.tz_convert('UTC')

print("--- London Data (Localized and Converted to UTC) ---")
print(london_utc)

# 2. Seattle Data Conversion to UTC
# Convert Unix epochs directly to a UTC-aware DatetimeIndex
seattle_utc_index = pd.to_datetime(seattle_usage.index, unit='s', utc=True)
seattle_utc = seattle_usage.copy()
seattle_utc.index = seattle_utc_index

print("\n--- Seattle Data (Converted to UTC) ---")
print(seattle_utc)

# 3. Synchronization and Verification
# Merge both UTC-normalized Series into a single DataFrame
synchronized_df = pd.merge(
    london_utc,
    seattle_utc,
    left_index=True,
    right_index=True,
    how='outer'
).sort_index()

print("\n--- Synchronized UTC DataFrame ---")
print(synchronized_df)

# Verification Check:
# London 10:00 AM (GMT) on 2023-03-25 is 10:00 AM UTC.
# Seattle Epoch 1679738400 is 10:00 AM UTC.
# The resulting DataFrame shows both events aligned perfectly at the 2023-03-25 10:00:00+00:00 index.

# Verification of DST handling (2023-03-26):
# London 01:30 GMT -> 01:30 UTC
# London 03:30 BST -> 02:30 UTC (The clock jumped at 02:00 GMT/UTC)
# The index confirms the DST adjustment:
# 2023-03-26 01:30:00+00:00 (GMT)
# 2023-03-26 02:30:00+00:00 (BST equivalent)

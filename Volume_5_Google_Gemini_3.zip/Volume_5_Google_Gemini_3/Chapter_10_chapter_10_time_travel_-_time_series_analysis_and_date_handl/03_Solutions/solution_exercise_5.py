
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import pandas as pd
import numpy as np
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_squared_error

# --- Simulated Daily Returns Data (250 days) ---
np.random.seed(50)
dates = pd.date_range(start='2024-01-01', periods=250, freq='D')
returns = np.random.normal(0.001, 0.01, 250) + np.sin(np.arange(250) * 2 * np.pi / 60) * 0.005
returns_ts = pd.Series(returns, index=dates, name='Returns')

# --- WFV Parameters ---
train_size = 100
forecast_horizon = 1
# Initialize history with the initial training set data (as a list)
history = list(returns_ts[:train_size])
# Define the test set
test_data = returns_ts[train_size:]
predictions = []
actuals = []

print(f"Total data points: {len(returns_ts)}")
print(f"Initial training size: {train_size}")
print(f"Number of walk-forward steps: {len(test_data)}")

# --- Implement the WFV Loop ---
for t in range(len(test_data)):
    # Define the ARIMA model (1, 1, 1)
    model = ARIMA(history, order=(1, 1, 1))
    
    # Fit the model to the current history
    model_fit = model.fit()
    
    # Generate 1-step forecast
    # forecast returns a Series/array, we take the first element [0]
    yhat = model_fit.forecast(steps=forecast_horizon)[0]
    predictions.append(yhat)
    
    # Get the actual observation for the current step
    obs = test_data.iloc[t]
    actuals.append(obs)
    
    # Walk-Forward Step: Append the actual observation to the history for the next iteration
    history.append(obs)
    
    # Optional: Print progress for monitoring
    # if (t + 1) % 50 == 0:
    #     print(f'Step {t+1}/{len(test_data)}: Predicted={yhat:.5f}, Actual={obs:.5f}')

# --- Evaluation ---
# Calculate the Mean Squared Error across all walk-forward predictions
mse = mean_squared_error(actuals, predictions)

print("\n--- Walk-Forward Validation Results ---")
print(f"Total Forecasts Generated: {len(predictions)}")
print(f"Mean Squared Error (MSE) across all steps: {mse:.8f}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import pandas as pd
import numpy as np
import statsmodels.api as sm

# --- Simulated Monthly Data (5 years) ---
dates = pd.date_range(start='2019-01-01', periods=60, freq='MS')
np.random.seed(20)

# Consumption: Endogenous Variable
trend = np.linspace(1000, 1500, 60)
seasonality = np.sin(np.arange(60) * 2 * np.pi / 12) * 200
noise = np.random.normal(0, 30, 60)
consumption = trend + seasonality + noise
df = pd.DataFrame({'Consumption': consumption}, index=dates)

# Temperature: Exogenous Variable
temp_base = 60 + np.sin(np.arange(60) * 2 * np.pi / 12) * 25
temp_noise = np.random.normal(0, 2, 60)
df['Temperature'] = temp_base + temp_noise

# --- Baseline SARIMA Model (P=1, D=1, Q=1) x (p=0, d=1, q=1, s=12) ---
order = (1, 1, 1)
seasonal_order = (0, 1, 1, 12)

try:
    # Baseline Model Fit (SARIMA, no exog)
    baseline_model = sm.tsa.statespace.SARIMAX(
        df['Consumption'],
        order=order,
        seasonal_order=seasonal_order,
        enforce_stationarity=False,
        enforce_invertibility=False
    ).fit(disp=False)
    baseline_aic = baseline_model.aic
    print(f"Baseline SARIMA AIC: {baseline_aic:.2f}")

except Exception as e:
    print(f"Error fitting baseline model: {e}")
    baseline_aic = np.inf


# --- SARIMAX Implementation Task ---

# 1. Define the exogenous variable array
exog_vars = df['Temperature']

# 2. Fit the SARIMAX model (using the same order, adding exog)
sarimax_model = sm.tsa.statespace.SARIMAX(
    df['Consumption'],
    exog=exog_vars,  # Include the temperature data
    order=order,
    seasonal_order=seasonal_order,
    enforce_stationarity=False,
    enforce_invertibility=False
).fit(disp=False)

sarimax_aic = sarimax_model.aic
print(f"SARIMAX (with Temperature) AIC: {sarimax_aic:.2f}")

# 3. Conclusion
print("\n--- Evaluation Conclusion ---")
if sarimax_aic < baseline_aic:
    print(f"SARIMAX AIC ({sarimax_aic:.2f}) is lower than Baseline SARIMA AIC ({baseline_aic:.2f}).")
    print("Conclusion: The inclusion of Temperature as an exogenous variable provided a better fit for the data.")
else:
    print(f"SARIMAX AIC ({sarimax_aic:.2f}) is higher than Baseline SARIMA AIC ({baseline_aic:.2f}).")
    print("Conclusion: The inclusion of Temperature did not improve the model fit significantly.")

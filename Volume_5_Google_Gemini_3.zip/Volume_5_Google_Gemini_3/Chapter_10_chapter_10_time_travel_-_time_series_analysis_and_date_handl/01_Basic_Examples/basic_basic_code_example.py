
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import pandas as pd
from datetime import datetime, timedelta
import numpy as np

# --- 1. Date Initialization and Arithmetic (Standard Python) ---

# Define the starting point for our sales tracking
# We use the datetime object from the standard library
START_DATE = datetime(2024, 7, 15, 10, 30, 0) 

# Calculate a future date using timedelta (duration arithmetic)
# This calculates the exact moment 1 week and 3 hours from START_DATE
future_moment = START_DATE + timedelta(weeks=1, hours=3)

# ---------------------------------------------------------------

# --- 2. Generating the Time Series Index ---

# Create a list comprehension to generate 5 consecutive daily dates
# This will serve as the index for our time series
index_dates = [START_DATE.date() + timedelta(days=i) for i in range(5)]

# Define corresponding dummy data (simulated daily sales figures in USD)
# The length of the data list must match the length of the index_dates list
sales_data = [150.50, 162.15, 145.99, 178.05, 190.22]

# ---------------------------------------------------------------

# --- 3. Creating the Pandas Time Series Object (pd.Series) ---

# The magic happens here: Pandas converts the list of date objects 
# into a specialized DatetimeIndex
daily_sales_ts = pd.Series(
    data=sales_data,
    index=index_dates,
    name="Daily_Sales_USD"
)

# ---------------------------------------------------------------

# --- 4. Demonstrating Time-Based Indexing and Slicing ---

print("--- 1. Full Time Series Object ---")
print(daily_sales_ts)

print("\n--- 2. Index Type and Data Type Verification ---")
print(f"Index Class: {daily_sales_ts.index.__class__.__name__}")
print(f"Series Dtype: {daily_sales_ts.dtype}")

print("\n--- 3. Sales on a specific day (2024-07-17) using string indexing ---")
# Pandas automatically parses the string 'YYYY-MM-DD' into a lookup key
print(f"Sales: ${daily_sales_ts.loc['2024-07-17']:.2f}")

print("\n--- 4. Slicing over a date range (Inclusive Slicing) ---")
# Time-based slicing includes both the start and end dates specified
print(daily_sales_ts.loc['2024-07-16':'2024-07-18'])

print("\n--- 5. Using Partial String Indexing (Year/Month) ---")
# If the index contains time components, partial indexing allows querying 
# all data points within a larger temporal unit (e.g., all of July 2024)
print("All sales in July 2024:")
print(daily_sales_ts.loc['2024-07'])

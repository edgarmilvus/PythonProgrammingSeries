
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import asyncio
import time

class AsyncLLMConnection:
    """
    An asynchronous context manager simulating a non-blocking connection
    to an external LLM service.
    """
    def __init__(self, connection_id):
        self.id = connection_id
        self.status = "DISCONNECTED"

    async def __aenter__(self):
        start = time.time()
        print(f"[Conn {self.id}] Initiating connection. This will take 1.5s...")
        
        # Simulate non-blocking connection latency
        await asyncio.sleep(1.5) 
        
        self.status = "CONNECTED"
        print(f"[Conn {self.id}] Connection established in {time.time() - start:.2f}s.")
        return f"LLM_Connection_Object_{self.id}"

    async def __aexit__(self, exc_type, exc_value, traceback):
        print(f"[Conn {self.id}] Starting clean disconnection sequence...")
        
        # Simulate non-blocking disconnection latency
        await asyncio.sleep(0.5) 
        
        self.status = "DISCONNECTED"
        if exc_type:
            print(f"[Conn {self.id}] Disconnected with error: {exc_type.__name__}")
        else:
            print(f"[Conn {self.id}] Cleanly disconnected.")
        
        # We allow exceptions to propagate if they occurred
        return False

async def main_orchestrator():
    start_time = time.time()
    
    async def run_connection(conn_id):
        async with AsyncLLMConnection(conn_id) as conn:
            print(f"[Conn {conn_id}] Resource received: {conn}. Performing task...")
            # Simulate processing time while connected
            await asyncio.sleep(0.2) 
            print(f"[Conn {conn_id}] Task complete.")

    # Run two connections concurrently
    print("--- Starting Concurrent Connection Attempts ---")
    await asyncio.gather(
        run_connection(1),
        run_connection(2)
    )
    
    end_time = time.time()
    total_duration = end_time - start_time
    print(f"\nTotal execution time: {total_duration:.2f}s")
    print(f"Expected time (sequential): 1.5s + 0.5s + 0.2s + 1.5s + 0.5s + 0.2s = 4.4s")
    print(f"Expected time (concurrent): Max(1.5s) + 0.2s + 0.5s ≈ 2.2s (due to overlapping sleeps)")

if __name__ == "__main__":
    asyncio.run(main_orchestrator())

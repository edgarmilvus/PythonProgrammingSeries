
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import time
import os

class ConfigFileManager:
    """
    A custom context manager for managing configuration files, ensuring
    the file is closed and logging the duration and exit status.
    """
    def __init__(self, filepath, mode='r'):
        self.filepath = filepath
        self.mode = mode
        self.file_handle = None
        self.start_time = None

    def __enter__(self):
        self.start_time = time.time()
        print(f"[CM LOG] Attempting to open file: {self.filepath} in mode '{self.mode}'...")
        try:
            self.file_handle = open(self.filepath, self.mode)
            return self.file_handle
        except FileNotFoundError:
            print(f"[CM ERROR] File not found: {self.filepath}")
            # Reraise the exception to be caught by __exit__
            raise

    def __exit__(self, exc_type, exc_value, traceback):
        duration = time.time() - self.start_time

        # 1. Guarantee File Closure
        if self.file_handle:
            self.file_handle.close()
            print(f"[CM LOG] File handle for {self.filepath} successfully closed.")

        # 2. Log Exit Status
        if exc_type is None:
            print(f"[CM LOG] Context exited normally. Duration: {duration:.4f}s.")
        else:
            print(f"[CM LOG] Context exited due to ERROR: {exc_type.__name__}: {exc_value}")
            print(f"[CM LOG] Resource cleanup completed despite error. Duration: {duration:.4f}s.")
            # Returning False here allows the exception to propagate outside the 'with' block.
            return False

# --- Testing Scenarios ---

# Scenario 1: Normal Exit
print("\n--- Running Scenario 1: Normal Operation ---")
try:
    with ConfigFileManager("test_config.txt", 'w') as f:
        time.sleep(0.1)
        f.write("Setting 1=Value A\n")
        f.write("Setting 2=Value B\n")
    # Clean up test file
    os.remove("test_config.txt")
except Exception as e:
    print(f"Caught unexpected error outside CM: {e}")


# Scenario 2: Error Injection
print("\n--- Running Scenario 2: Error Injection (Division by Zero) ---")
try:
    with ConfigFileManager("error_config.txt", 'w') as f:
        time.sleep(0.1)
        f.write("Attempting error\n")
        result = 1 / 0  # Inject ZeroDivisionError
        f.write(f"Result: {result}")
except ZeroDivisionError as e:
    print(f"[MAIN] Successfully caught propagated error: {e}")
finally:
    if os.path.exists("error_config.txt"):
        os.remove("error_config.txt")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import json

# Custom Exception for Parsing Failures
class ParsingError(Exception):
    """Raised when the LLM output cannot be parsed into the expected structure."""
    pass

# Component 1: Prompt Template
class StructuredPromptTemplate:
    def format_prompt(self, user_input, schema_description):
        template = (
            "You are an expert data extraction bot. Your task is to process the user's "
            "request and return the result strictly in JSON format.\n\n"
            "USER REQUEST: {user_input}\n\n"
            "RESPOND ONLY IN JSON FORMAT ACCORDING TO THE FOLLOWING SCHEMA:\n"
            "---SCHEMA---\n{schema_description}\n---SCHEMA---\n"
        )
        return template.format(user_input=user_input, schema_description=schema_description)

# Component 2: Mock LLM
def mock_llm_call(formatted_prompt):
    """Simulates an API call to an LLM based on prompt content."""
    print("-> [LLM] Receiving prompt...")
    if "Summarize" in formatted_prompt:
        # Valid JSON response
        return '{"operation": "summary", "status": "success", "data": "The user requested a summary of key concepts."}'
    elif "Invalidate" in formatted_prompt:
        # Malformed JSON response (Simulating LLM hallucination)
        return '{"operation": "invalid", "status": "failure", "data": "This is not JSON, missing quote.'
    else:
        return '{"operation": "default", "status": "unknown", "data": "No specific instruction recognized."}'

# Component 3: Output Parser
class JSONValidatorParser:
    def parse(self, raw_llm_output):
        print("-> [Parser] Attempting to parse raw output...")
        try:
            # Attempt to load the string into a Python dictionary
            return json.loads(raw_llm_output)
        except json.JSONDecodeError as e:
            # Raise custom error if parsing fails
            raise ParsingError(f"Failed to parse LLM output. Raw output: '{raw_llm_output[:50]}...'. Error: {e}")

# The Manual Chain Function
def run_manual_chain(query, schema):
    # 1. Template Step
    template_engine = StructuredPromptTemplate()
    formatted_prompt = template_engine.format_prompt(query, schema)
    print(f"1. Prompt Generated (Length: {len(formatted_prompt)})")

    # 2. Mock LLM Step
    raw_output = mock_llm_call(formatted_prompt)
    print(f"2. LLM Raw Output Received: {raw_output}")

    # 3. Parsing Step
    parser = JSONValidatorParser()
    structured_output = parser.parse(raw_output)
    print("3. Parsing Successful.")
    
    return structured_output

# --- Testing the Manual Chain ---
response_schema = "{'operation': str, 'status': str, 'data': str}"

print("\n--- Test 1: Successful Chain Execution ---")
try:
    result = run_manual_chain("Summarize the key concepts.", response_schema)
    print("\nFINAL RESULT (Dict):", result)
except ParsingError as e:
    print(f"\nCHAIN FAILURE: {e}")

print("\n--- Test 2: Chain Failure (Malformed LLM Output) ---")
try:
    run_manual_chain("Invalidate the previous response.", response_schema)
except ParsingError as e:
    print(f"\nCHAIN FAILURE: {e}")

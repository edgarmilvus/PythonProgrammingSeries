
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import json

# Reusing components from Exercise 3 (ParsingError, StructuredPromptTemplate, mock_llm_call, JSONValidatorParser)

class ParsingError(Exception): pass

class StructuredPromptTemplate:
    def format_prompt(self, user_input, schema_description, context=""):
        template = (
            "You are an expert data extraction bot. Use the provided context and history.\n\n"
            "--- CONTEXT ---\n{context}\n--- CONTEXT ---\n\n"
            "USER REQUEST: {user_input}\n\n"
            "RESPOND ONLY IN JSON FORMAT ACCORDING TO THE FOLLOWING SCHEMA:\n"
            "---SCHEMA---\n{schema_description}\n---SCHEMA---\n"
        )
        return template.format(user_input=user_input, schema_description=schema_description, context=context)

def mock_llm_call(formatted_prompt):
    """Simulates an API call, providing a response based on keywords."""
    if "lookup_policy" in formatted_prompt:
        return '{"operation": "policy_summary", "status": "success", "data": "The refund policy requires submission within 30 days, as per external data."}'
    elif "What is my name" in formatted_prompt:
        return '{"operation": "greeting", "status": "success", "data": "Your name is not yet stored in our history."}'
    else:
        return '{"operation": "default", "status": "unknown", "data": "No specific instruction recognized."}'

class JSONValidatorParser:
    def parse(self, raw_llm_output):
        try:
            return json.loads(raw_llm_output)
        except json.JSONDecodeError as e:
            raise ParsingError(f"Failed to parse LLM output. Error: {e}")

# Component 4: Memory Store
class ConversationMemory:
    def __init__(self):
        self.history = []

    def get_history(self):
        if not self.history:
            return "No previous conversation history available."
        
        history_str = "--- CONVERSATION HISTORY ---\n"
        for i, (user, ai) in enumerate(self.history):
            history_str += f"Turn {i+1}: User: {user}\n"
            history_str += f"Turn {i+1}: AI: {ai['data']}\n"
        history_str += "--------------------------"
        return history_str

    def add_message(self, user_query, ai_response_dict):
        # We only store the relevant 'data' part of the AI response
        self.history.append((user_query, ai_response_dict))
        print(f"[MEMORY] History updated. Total turns: {len(self.history)}")

# Component 5: RAG Tool Simulation
def retrieve_external_data(query):
    """Simulates fetching data from a vector database or external tool."""
    RAG_TRIGGER = "lookup_policy"
    if RAG_TRIGGER in query.lower():
        print("[RAG TOOL] Triggered. Retrieving external policy data...")
        return "The official policy on refunds states that all requests must be submitted within 30 days."
    return ""

# Modified Orchestration Function
def orchestrate_complex_chain(query, memory_store, schema):
    print(f"\n--- Starting Chain for Query: '{query[:30]}...' ---")
    
    # 1. RAG Execution (Conditional Tool Use)
    rag_context = retrieve_external_data(query)

    # 2. Get Memory History
    history_context = memory_store.get_history()

    # 3. Context Merging
    full_context = f"History:\n{history_context}\n\nExternal Data:\n{rag_context}"
    
    # 4. Prompt Generation
    template_engine = StructuredPromptTemplate()
    formatted_prompt = template_engine.format_prompt(query, schema, context=full_context)
    
    # 5. LLM Call & Parsing
    try:
        raw_output = mock_llm_call(formatted_prompt)
        parser = JSONValidatorParser()
        structured_output = parser.parse(raw_output)
        
        # 6. Post-processing: Update Memory
        memory_store.add_message(query, structured_output)
        
        return structured_output
        
    except ParsingError as e:
        print(f"[CHAIN ERROR] Failed at parsing step: {e}")
        return {"status": "error", "message": "Parsing failed"}


# --- Interactive Debugging ---
memory = ConversationMemory()
response_schema = "{'operation': str, 'status': str, 'data': str}"

# Turn 1 (No RAG, Initial Memory)
query_t1 = "What is my name?"
result_t1 = orchestrate_complex_chain(query_t1, memory, response_schema)
print("Turn 1 Final Result:", result_t1)

# Turn 2 (RAG Triggered, Memory Included)
query_t2 = "I need to lookup_policy details for refunds, can you summarize?"
result_t2 = orchestrate_complex_chain(query_t2, memory, response_schema)
print("Turn 2 Final Result:", result_t2)

# Verify history state after two turns
print("\n--- Final Memory State ---")
print(memory.get_history())

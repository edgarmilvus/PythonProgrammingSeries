
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import functools
from langchain.tools import BaseTool
import sys
import io
import traceback

class SecurityViolationError(Exception):
    """Custom exception for sandboxing failures."""
    pass

def sandbox_check(func):
    """Decorator to inspect code string for prohibited operations (file system access)."""
    PROHIBITED_KEYWORDS = ["open(", "os.", "subprocess", "shutil", "import os", "import subprocess"]
    
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # Extract the code string argument, assuming it's the first non-self argument
        # In a LangChain tool's _run method, the first argument after self is the input string
        code_string = args[1] if len(args) > 1 and isinstance(args[1], str) else kwargs.get('code', '')

        # Check for violations (case-insensitive)
        code_lower = code_string.lower()
        for keyword in PROHIBITED_KEYWORDS:
            if keyword.lower() in code_lower:
                raise SecurityViolationError(f"Prohibited operation '{keyword}' detected in code.")
        
        # If no violation, proceed with the original function execution
        return func(*args, **kwargs)
    return wrapper

class SandboxedCodeTool(BaseTool):
    name = "Code_Executor"
    description = "Executes safe Python code for calculations or data manipulation. File system access is strictly prohibited."

    @sandbox_check
    def _run(self, code: str) -> str:
        """Core execution logic, protected by the sandbox decorator."""
        try:
            # 1. Safety Check (handled by decorator, but included for context)
            
            # 2. Execute Code Safely
            old_stdout = sys.stdout
            redirected_output = sys.stdout = io.StringIO()
            
            # Execute the code in a restricted global environment
            exec(code, {'__builtins__': None}, {}) 
            
            sys.stdout = old_stdout
            result = redirected_output.getvalue().strip()
            
            if not result:
                return "Code executed successfully, but produced no output."
            
            return f"Code execution successful. Output:\n{result}"
            
        except SecurityViolationError as e:
            # This block is technically unreachable if the decorator is implemented correctly
            # and raises the exception *before* _run is called, but included for completeness.
            return f"Error: Code execution blocked. Security Violation Detected: {e}. File system access is prohibited."
            
        except Exception as e:
            # Handle runtime errors (e.g., SyntaxError, ZeroDivisionError)
            error_details = traceback.format_exc().splitlines()[-1]
            return f"RUNTIME ERROR: Code execution failed due to a runtime issue (e.g., syntax, division by zero). Details: {error_details}. Please fix the code."

    async def _arun(self, code: str) -> str:
        # Asynchronous execution implementation (can wrap the synchronous run)
        return self._run(code)

# # Demonstration of violation handling:
# executor = SandboxedCodeTool()
# violation_result = executor.run("import os; os.remove('secret.txt')")
# # This will return the structured error message defined by the decorator's raise logic
# # and caught by the agent executor (or simulated as a direct return here).

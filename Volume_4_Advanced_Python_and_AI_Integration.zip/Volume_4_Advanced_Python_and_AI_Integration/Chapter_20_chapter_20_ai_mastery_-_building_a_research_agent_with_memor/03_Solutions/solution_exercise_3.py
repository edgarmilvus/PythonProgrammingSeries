
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from langchain_core.documents import Document
from langchain_community.vectorstores import Chroma
from langchain_text_splitters import RecursiveCharacterTextSplitter
from typing import List
import re
import os

# Mock the embedding function for a runnable example
class MockEmbeddings:
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        return [[float(i % 5) * 0.1] * 5 for i, text in enumerate(texts)]
    def embed_query(self, text: str) -> List[float]:
        return [0.1] * 5

# Example document structure for indexing
DOCUMENT_CONTENT = """
# Introduction to Model V3.1
This model represents a significant leap in efficiency, achieving a 20% reduction in inference time compared to V3.0. This is achieved through a novel sparse attention mechanism.

## Experimental Results Summary
The following table summarizes the performance metrics across three environments:

| Metric | Environment A | Environment B | Environment C |
|---|---|---|---|
| Latency (ms) | 12.5 | 18.2 | 9.1 |
| Throughput (ops/s) | 980 | 750 | 1120 |
| Error Rate (%) | 0.12 | 0.05 | 0.21 |

This data confirms the optimized performance in Environment C, making it the recommended deployment target for high-throughput scenarios. Further analysis reveals that the latency difference is statistically significant (p < 0.01).
"""

def hybrid_chunker_and_tagger(content: str) -> List[Document]:
    """Splits content, treating Markdown tables as atomic units, and assigns metadata."""
    documents = []
    
    # Regex to find Markdown tables (simplified: starts with | and contains ---)
    TABLE_REGEX = r'(\n\|.*?\n(?:\|.*\|.*\n)+)'
    
    # Split the document by the table regex, capturing the tables themselves
    parts = re.split(TABLE_REGEX, content, flags=re.DOTALL)
    
    # Standard text splitter for non-table parts
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=200, chunk_overlap=20)
    
    for part in parts:
        if not part.strip():
            continue

        if part.strip().startswith('|') and '---' in part:
            # Part is a table: treat as a single document with 'table' tag
            doc = Document(page_content=part.strip(), metadata={"chunk_type": "table"})
            documents.append(doc)
        else:
            # Part is standard prose: use recursive splitting and tag as 'text'
            text_chunks = text_splitter.split_text(part)
            for chunk in text_chunks:
                doc = Document(page_content=chunk.strip(), metadata={"chunk_type": "text"})
                documents.append(doc)
    
    return documents

# 1. Custom Chunking and Tagging
chunks = hybrid_chunker_and_tagger(DOCUMENT_CONTENT)

# 2. Vector Store Indexing
CHROMA_DIR = "./chroma_db_temp_ex3"
if not os.path.exists(CHROMA_DIR): os.makedirs(CHROMA_DIR)

vectorstore = Chroma.from_documents(
    documents=chunks,
    embedding=MockEmbeddings(),
    persist_directory=CHROMA_DIR
)
vectorstore.persist()

# 3. Retriever Filtering Configuration
def get_metadata_aware_retriever(query: str, vectorstore: Chroma):
    """Configures the retriever with metadata filtering based on query keywords."""
    
    query_lower = query.lower()
    table_keywords = ["statistics", "comparison", "data results", "metrics", "table", "latency"]
    
    should_filter_tables = any(keyword in query_lower for keyword in table_keywords)
    
    if should_filter_tables:
        # Prioritize or exclusively filter for table chunks
        filter_criteria = {"chunk_type": "table"}
    else:
        # General queries retrieve all chunk types
        filter_criteria = {}
        
    retriever = vectorstore.as_retriever(
        search_kwargs={"k": 3, "filter": filter_criteria}
    )
    return retriever

# 4. Demonstration of Filtering (Verification)
query_table = "What are the latency metrics and comparison data?"
retriever_table = get_metadata_aware_retriever(query_table, vectorstore)
retrieved_docs_table = retriever_table.invoke(query_table)

# Clean up
try:
    vectorstore.delete_collection()
    os.rmdir(CHROMA_DIR)
except Exception:
    pass

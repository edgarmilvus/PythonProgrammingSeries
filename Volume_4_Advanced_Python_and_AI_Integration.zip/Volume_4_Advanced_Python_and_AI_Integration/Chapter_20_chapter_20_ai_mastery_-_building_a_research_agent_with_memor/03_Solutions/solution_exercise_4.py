
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import asyncio
import time
from langchain.tools import BaseTool

# 1. Asynchronous Tool Definitions

class KnowledgeGraphTool(BaseTool):
    name = "Knowledge_Graph_Query"
    description = "Queries the knowledge graph for structured facts (2.0s latency)."
    
    def _run(self, query: str) -> str:
        raise NotImplementedError("KnowledgeGraphTool must be run asynchronously.")
        
    async def _arun(self, query: str) -> str:
        # Simulate high latency (2.0s)
        await asyncio.sleep(2.0) 
        return f"Knowledge Graph Result: Found 5 related entities for '{query}'."

class WebSearchTool(BaseTool):
    name = "Web_Search"
    description = "Performs a targeted web search (1.5s latency)."
    
    def _run(self, query: str) -> str:
        raise NotImplementedError("WebSearchTool must be run asynchronously.")
        
    async def _arun(self, query: str) -> str:
        # Simulate medium latency (1.5s)
        await asyncio.sleep(1.5) 
        return f"Web Search Result: Retrieved 3 top articles matching '{query}'."

class StatisticalCalculationTool(BaseTool):
    name = "Statistical_Calculator"
    description = "Executes a complex statistical calculation (1.0s latency)."
    
    def _run(self, query: str) -> str:
        raise NotImplementedError("StatisticalCalculationTool must be run asynchronously.")
        
    async def _arun(self, query: str) -> str:
        # Simulate low latency (1.0s)
        await asyncio.sleep(1.0) 
        return f"Statistical Calculation Result: R-squared value is 0.98 based on '{query}' data."

# Initialize tools
KG_TOOL = KnowledgeGraphTool()
WEB_TOOL = WebSearchTool()
CALC_TOOL = StatisticalCalculationTool()

# 2. & 3. Orchestration Function with Parallel Execution
async def async_deep_synthesis(agent_input: str) -> dict:
    """Orchestrates parallel execution of multiple high-latency tools."""
    start_time = time.perf_counter()

    # Initiate all asynchronous calls concurrently using .arun()
    tasks = [
        KG_TOOL.arun(agent_input),
        WEB_TOOL.arun(agent_input),
        CALC_TOOL.arun(agent_input),
    ]

    # Use asyncio.gather to wait for the results simultaneously
    kg_result, web_result, calc_result = await asyncio.gather(*tasks)
    
    end_time = time.perf_counter()
    
    # 4. Result Aggregation
    return {
        "knowledge_graph": kg_result,
        "web_search": web_result,
        "calculation": calc_result,
        "total_time": end_time - start_time
    }

# 5. Performance Verification
def run_comparison():
    agent_input = "AI agent architecture optimization"
    
    # --- Synchronous Simulation (Sequential Execution) ---
    sync_start = time.perf_counter()
    
    async def sync_simulation():
        # Simulate sequential calls (total time = sum of latencies)
        await KG_TOOL.arun(agent_input) 
        await WEB_TOOL.arun(agent_input) 
        await CALC_TOOL.arun(agent_input) 
    
    asyncio.run(sync_simulation())
    sync_end = time.perf_counter()
    sync_duration = sync_end - sync_start

    # --- Asynchronous Execution (Parallel Execution) ---
    async_results = asyncio.run(async_deep_synthesis(agent_input))
    async_duration = async_results["total_time"]

    print("\n--- Performance Summary ---")
    print(f"Expected Synchronous Time (2.0 + 1.5 + 1.0): 4.50 s")
    print(f"Measured Synchronous Time: {sync_duration:.2f} s")
    print(f"Measured Asynchronous Time (Expected ~2.0s): {async_duration:.2f} s")
    print(f"Speedup Factor: {sync_duration / async_duration:.1f}x")

# run_comparison()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from langchain.memory.chat_memory import BaseChatMemory
from langchain.schema import get_buffer_string, AIMessage, HumanMessage
import json
import os

class StructuredAnalysisMemory(BaseChatMemory):
    # Define the variables the memory exposes to the agent prompt
    memory_variables = ["chat_history", "structured_analysis_context"]

    def __init__(self, session_id: str = "default", history_file: str = "analysis_history.json"):
        super().__init__()
        self.session_id = session_id
        self.history_file = history_file
        self.analysis_data = [] # Stores raw structured data (JSON objects)
        self.chat_history = []  # Stores standard LangChain message objects
        self._load_from_persistence()

    def _load_from_persistence(self):
        """Simulates loading memory state from a persistent store (file)."""
        if os.path.exists(self.history_file):
            try:
                with open(self.history_file, 'r') as f:
                    data = json.load(f)
                    # Reconstruct chat history from stored dicts
                    self.chat_history = [
                        AIMessage(**msg) if msg['type'] == 'ai' else HumanMessage(**msg)
                        for msg in data.get("chat_history", [])
                    ]
                    self.analysis_data = data.get("analysis_data", [])
            except (json.JSONDecodeError, FileNotFoundError):
                # Handle corrupted or missing file gracefully
                self.analysis_data = []
                self.chat_history = []
        
    def _save_to_persistence(self):
        """Simulates saving current state to the persistent store."""
        # Convert LangChain messages to serializable dictionaries
        serializable_history = [msg.dict() for msg in self.chat_history]
        
        data_to_save = {
            "session_id": self.session_id,
            "chat_history": serializable_history,
            "analysis_data": self.analysis_data
        }
        with open(self.history_file, 'w') as f:
            json.dump(data_to_save, f, indent=4)

    def load_memory_variables(self, inputs: dict) -> dict:
        # 1. Format standard chat history
        chat_history_str = get_buffer_string(self.chat_history)
        
        # 2. Format structured analysis context for the LLM
        structured_context = ""
        if self.analysis_data:
            structured_context = "--- PREVIOUS ANALYSIS RESULTS ---\n"
            for i, analysis in enumerate(self.analysis_data):
                # Present the structured data clearly to the LLM
                structured_context += f"Analysis {i+1}:\n"
                structured_context += json.dumps(analysis, indent=2) + "\n"
            structured_context += "---------------------------------\n"
        
        return {
            "chat_history": chat_history_str,
            "structured_analysis_context": structured_context
        }

    def save_context(self, inputs: dict, outputs: dict) -> None:
        # Standard saving of human and AI messages
        human_message = HumanMessage(content=inputs["input"])
        ai_message = AIMessage(content=outputs["output"])
        
        self.chat_history.append(human_message)
        
        # --- Structured Data Detection and Storage ---
        output_content = outputs["output"]
        START_TAG = "<ANALYSIS_RESULT>"
        END_TAG = "</ANALYSIS_RESULT>"

        if START_TAG in output_content and END_TAG in output_content:
            try:
                # Extract the content between tags
                start_index = output_content.find(START_TAG) + len(START_TAG)
                end_index = output_content.find(END_TAG)
                json_str = output_content[start_index:end_index].strip()
                
                # Parse and store the raw JSON object
                analysis_json = json.loads(json_str)
                self.analysis_data.append(analysis_json)
                
            except json.JSONDecodeError:
                # If parsing fails, the data is not stored in the structured list
                pass
        
        self.chat_history.append(ai_message)
        
        # Persist the updated state
        self._save_to_persistence()

    def clear(self) -> None:
        self.chat_history = []
        self.analysis_data = []
        if os.path.exists(self.history_file):
            os.remove(self.history_file)

# Example usage (for demonstration, not part of the class definition)
# memory = StructuredAnalysisMemory()
# memory.save_context(
#     inputs={"input": "Run regression."},
#     outputs={"output": f"Analysis complete.\n<ANALYSIS_RESULT>{json.dumps({'R2': 0.9, 'N': 100})}</ANALYSIS_RESULT>"}
# )
# # memory.load_memory_variables({}) will now contain the R2 metric in structured_analysis_context

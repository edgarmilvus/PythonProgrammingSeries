
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import json
from pydantic import BaseModel, ValidationError
from langchain.tools import BaseTool

# Required Schema
class ResearchArticle(BaseModel):
    title: str
    authors: list[str]
    year: int
    summary: str

class JSONValidatorTool(BaseTool):
    name = "JSON_Validator"
    description = "Validates JSON string against the ResearchArticle schema (title:str, authors:list[str], year:int, summary:str). Returns SUCCESS or a specific error message."

    def _run(self, json_string: str) -> str:
        """Implement robust validation and error handling here."""
        try:
            # 1. Attempt to parse the string into a JSON object
            data = json.loads(json_string)
            
            # 2. Attempt to validate the JSON object against the Pydantic schema
            ResearchArticle.model_validate(data)
            
            # 3. Return success message (POLA)
            return "Validation successful. The JSON conforms to the required schema."
            
        except json.JSONDecodeError as e:
            # Handle malformed JSON strings (POLA: explicit parsing failure)
            return f"JSON PARSE ERROR: The input string is not valid JSON. Review quotes, commas, and structure near: {e.msg} at position {e.pos}. The input MUST be a single, valid JSON object string."

        except ValidationError as e:
            # Handle schema violations (POLA: actionable schema feedback)
            first_error = e.errors()[0]
            loc = first_error.get('loc', ['N/A'])[0] # Field name
            msg = first_error.get('msg', 'Unknown validation failure.')
            type_info = first_error.get('type', 'N/A')
            
            # Format a clear message for the LLM based on error type
            if type_info.startswith('type_error'):
                return f"SCHEMA VALIDATION FAILED: Field '{loc}' has a type error. Expected type was likely defined in the schema (e.g., integer, list, string). Details: {msg}. Please correct the data type."
            elif type_info == 'missing':
                return f"SCHEMA VALIDATION FAILED: Required field '{loc}' is missing from the JSON object. Please ensure all required fields are present."
            else:
                return f"SCHEMA VALIDATION FAILED: Field '{loc}' failed validation. Details: {msg}"

        except Exception as e:
            # Catch unexpected errors (general defensive programming)
            return f"UNKNOWN VALIDATION FAILURE: An unexpected error occurred during validation. Review the input structure carefully. Error type: {type(e).__name__}."

    def _arun(self, json_string: str) -> str:
        raise NotImplementedError("Asynchronous validation not supported yet.")

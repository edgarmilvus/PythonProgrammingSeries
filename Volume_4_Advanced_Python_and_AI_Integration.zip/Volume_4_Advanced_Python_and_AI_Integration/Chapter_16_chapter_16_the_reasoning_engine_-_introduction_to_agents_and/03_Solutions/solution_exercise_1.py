
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

class ReActSequenceError(Exception):
    """Custom exception for ReAct sequence violations."""
    pass

class ReActSimulator:
    def __init__(self):
        # State can be 'EXPECT_LLM_OUTPUT' (Thought/Action) or 'EXPECT_OBSERVATION'
        self.current_state = 'EXPECT_LLM_OUTPUT'
        self.history = []

    def parse_llm_output(self, output_string):
        """Identifies Thought or Action in the LLM output."""
        thought_index = output_string.find("Thought:")
        action_index = output_string.find("Action:")

        if thought_index != -1 and action_index != -1:
            # LLM output should contain both Thought and the resulting Action
            thought = output_string[thought_index + len("Thought:"):action_index].strip()
            action = output_string[action_index + len("Action:"):].strip()
            return 'THOUGHT_ACTION', thought, action
        elif 'Thought:' in output_string:
            return 'THOUGHT_ONLY', output_string.split("Thought:", 1)[1].strip(), None
        elif 'Action:' in output_string:
            return 'ACTION_ONLY', None, output_string.split("Action:", 1)[1].strip()
        else:
            return 'NONE', None, None

    def simulate_step(self, llm_output=None, external_observation=None):
        """Processes a step based on the current state."""
        
        if self.current_state == 'EXPECT_LLM_OUTPUT':
            if external_observation is not None:
                raise ReActSequenceError("State Error: Received Observation when expecting LLM output (Thought/Action).")
            
            # Parse the LLM's output
            step_type, thought, action = self.parse_llm_output(llm_output)
            
            if step_type == 'THOUGHT_ACTION' or step_type == 'THOUGHT_ONLY':
                self.history.append(f"Thought: {thought}")
                
                # If a full Thought/Action pair is provided (common in single-turn LLM calls)
                if action:
                    self.history.append(f"Action: {action}")
                    self.current_state = 'EXPECT_OBSERVATION'
                    print(f"Step processed: Thought and Action recorded. State -> {self.current_state}")
                else:
                    # In a strict loop, the LLM might only provide Thought, expecting a prompt for Action
                    # For simplicity here, we enforce Thought MUST be followed by Action in the same output or immediately after.
                    raise ReActSequenceError("State Error: LLM output contained Thought but no immediate Action. Agent must act.")
            
            elif step_type == 'ACTION_ONLY':
                 raise ReActSequenceError("State Error: LLM output contained Action but no preceding Thought. Agent must reason first.")
            
            else:
                raise ReActSequenceError("Format Error: LLM output did not contain 'Thought:' or 'Action:'.")

        elif self.current_state == 'EXPECT_OBSERVATION':
            if external_observation is None:
                raise ReActSequenceError("State Error: Agent executed Action, but no external Observation was provided.")
            
            self.history.append(f"Observation: {external_observation}")
            self.current_state = 'EXPECT_LLM_OUTPUT'
            print(f"Step processed: Observation recorded. State -> {self.current_state}")

# --- Demonstration ---
# simulator = ReActSimulator()
# try:
#     # 1. Start: Expecting LLM Output (Thought/Action)
#     llm_step1 = "Thought: I need to find the weather. Action: Weather_Lookup[London]"
#     simulator.simulate_step(llm_output=llm_step1)
# 
#     # 2. Next: Expecting Observation
#     simulator.simulate_step(external_observation="The weather is sunny and 20C.")
# 
#     # 3. Next: Expecting LLM Output (Thought/Action)
#     llm_step2 = "Thought: I have the weather. I will now conclude. Action: Final Answer[It is sunny.]"
#     simulator.simulate_step(llm_output=llm_step2)
# 
#     # Violation Test: Trying to submit an Action when expecting Observation
#     # simulator.simulate_step(llm_output="Action: Repeat[London]") 
# 
# except ReActSequenceError as e:
#     # print(f"\nSequence Violation Caught: {e}")
#     pass



#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

def Investment_Gain_Calculator(initial_investment: float, current_value: float) -> str:
    """
    Calculates the net financial gain from an investment.

    Requires two arguments: 'initial_investment' (float) and 'current_value' (float).
    Returns the net gain amount as a formatted string.
    """
    try:
        gain = current_value - initial_investment
        return f"The net investment gain is {gain:.2f}."
    except TypeError:
        return "Error: Both inputs must be valid numerical values."

def Tax_Rate_Lookup(investment_type: str) -> str:
    """
    Retrieves the applicable tax rate based on the investment holding period.

    Requires one argument: 'investment_type' (string, either 'short-term' or 'long-term').
    Returns the tax rate as a decimal percentage string (e.g., '0.15').
    """
    investment_type = investment_type.lower().strip()
    if 'short-term' in investment_type:
        rate = 0.15
    elif 'long-term' in investment_type:
        rate = 0.05
    else:
        return "Error: Investment type not recognized. Must be 'short-term' or 'long-term'."
    
    return f"The applicable tax rate for {investment_type} is {rate}."

TOOL_REGISTRY_FINANCE = {
    "Investment_Gain_Calculator": Investment_Gain_Calculator,
    "Tax_Rate_Lookup": Tax_Rate_Lookup
}


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Assume the standard agent prompt template looks something like this:
STANDARD_SYSTEM_PROMPT = """
You are a helpful and powerful assistant. You have access to the following tools:
{tool_descriptions}

Use the ReAct format (Thought, Action, Observation) to answer the user's query.
Always provide a Final Answer when done.
"""

# The Modified System Prompt incorporating defensive reasoning:
MODIFIED_SYSTEM_PROMPT = """
You are a helpful and powerful assistant. You have access to the following tools:
{tool_descriptions}

Use the ReAct format (Thought, Action, Observation) to answer the user's query.
Always provide a Final Answer when done.

CRITICAL RULE FOR FAILURE RECOVERY:
If you receive the Observation: 'Search failed. No relevant documents found for this exact query.', 
you MUST immediately change your plan. Your next Thought must explicitly state that the previous query was too specific, 
and you MUST rephrase the query using broader or alternative terms before calling the Knowledge_Search tool again. 
DO NOT repeat the exact failed query.
"""

# Example Target Thought after failure:
# Agent receives: Observation: Search failed. No relevant documents found for this exact query.
# Agent MUST output: Thought: The previous query was too specific. I must now rephrase the query using broader terms and try the Knowledge_Search tool again.

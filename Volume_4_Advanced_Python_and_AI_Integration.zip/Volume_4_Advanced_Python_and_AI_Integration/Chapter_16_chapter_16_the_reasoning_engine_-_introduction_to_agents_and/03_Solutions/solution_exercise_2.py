
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import json

def Stock_Price_Lookup(ticker: str) -> str:
    """
    Retrieves the latest market price for a specific stock ticker.

    Requires a valid NASDAQ or NYSE ticker symbol (e.g., 'GOOG', 'AAPL', 'NVDA').
    Returns the price as a formatted string or an error message if the ticker is not found.
    """
    ticker = ticker.upper().strip()
    if ticker == 'NVDA':
        return "The current price for NVDA is $950.00 USD."
    else:
        # Simulate an API failure for all other tickers
        return "Error: Ticker not found in real-time database."

def Currency_Converter(amount: float, target_currency: str) -> str:
    """
    Converts a numerical amount from USD to a specified target currency.

    Requires two arguments: 'amount' (float, the value in USD) and 'target_currency' (string, 3-letter code like 'EUR' or 'GBP').
    The tool uses a hardcoded conversion rate (1 USD = 0.92 EUR).
    Returns a formatted string showing the conversion result.
    """
    try:
        amount = float(amount)
    except ValueError:
        return "Error: Amount must be a valid number."
        
    target_currency = target_currency.upper().strip()
    
    if target_currency == 'EUR':
        conversion_rate = 0.92
        result = amount * conversion_rate
        return f"{amount:.2f} USD converts to {result:.2f} EUR."
    elif target_currency == 'GBP':
        conversion_rate = 0.80 # Example rate
        result = amount * conversion_rate
        return f"{amount:.2f} USD converts to {result:.2f} GBP."
    else:
        return f"Error: Conversion rate not available for target currency '{target_currency}'. Supported: EUR, GBP."

# Tool Registry: Maps tool name (string) to the function object
TOOL_REGISTRY = {
    "Stock_Price_Lookup": Stock_Price_Lookup,
    "Currency_Converter": Currency_Converter
}

# # Demonstration of tool execution
# print(f"NVDA Lookup: {TOOL_REGISTRY['Stock_Price_Lookup']('NVDA')}")
# print(f"Conversion: {TOOL_REGISTRY['Currency_Converter'](100, 'EUR')}")
# print(f"Failed Lookup: {TOOL_REGISTRY['Stock_Price_Lookup']('GOOG')}")

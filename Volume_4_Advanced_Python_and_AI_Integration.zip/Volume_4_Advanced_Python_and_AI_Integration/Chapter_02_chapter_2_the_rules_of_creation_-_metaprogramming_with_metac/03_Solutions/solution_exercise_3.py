
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Global component storage
AI_COMPONENT_REGISTRY = {}

class EmbeddingRegistryMeta(type):
    def __new__(mcs, name, bases, attrs):
        # 0. Skip validation for the base class
        if name == 'BaseEmbeddingModel':
            return super().__new__(mcs, name, bases, attrs)

        # 1. Contract Enforcement: DATA_TYPE
        data_type = attrs.get('DATA_TYPE')
        if not isinstance(data_type, str) or not data_type:
            raise TypeError(f"Model {name} must define DATA_TYPE as a non-empty string.")
        
        # 2. Contract Enforcement: generate_embedding method
        if 'generate_embedding' not in attrs or not callable(attrs['generate_embedding']):
            raise TypeError(f"Model {name} must implement the instance method generate_embedding(self, data).")

        # Create the class object
        cls = super().__new__(mcs, name, bases, attrs)

        # 3. Dynamic Registration
        registry_key = data_type.upper()
        
        # Initialize the nested dictionary if needed
        if registry_key not in AI_COMPONENT_REGISTRY:
            AI_COMPONENT_REGISTRY[registry_key] = {}
            
        # Register the class using its name
        AI_COMPONENT_REGISTRY[registry_key][name] = cls
        
        return cls

class BaseEmbeddingModel(metaclass=EmbeddingRegistryMeta):
    """Base class for all embedding models."""
    pass

class TextEmbeddingModel(BaseEmbeddingModel):
    DATA_TYPE = "text"

    def generate_embedding(self, data):
        return [0.1, 0.2]

class CodeEmbeddingModel(BaseEmbeddingModel):
    DATA_TYPE = "CODE" # Already uppercase, still works

    def generate_embedding(self, data):
        return [0.5, 0.5]

# Verification check:
# print(AI_COMPONENT_REGISTRY) 
# print(AI_COMPONENT_REGISTRY['TEXT']['TextEmbeddingModel'])

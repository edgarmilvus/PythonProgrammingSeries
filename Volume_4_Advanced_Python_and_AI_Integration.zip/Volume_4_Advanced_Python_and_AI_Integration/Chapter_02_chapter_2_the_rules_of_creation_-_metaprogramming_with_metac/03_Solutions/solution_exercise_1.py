
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

class ConfigEnforcerMeta(type):
    def __new__(mcs, name, bases, attrs):
        # 0. Skip validation for the base class itself
        if name == 'DataProcessor':
            return super().__new__(mcs, name, bases, attrs)

        # 1. Check for MIN_BATCH_SIZE presence and validation
        if 'MIN_BATCH_SIZE' not in attrs:
            raise TypeError(f"Class {name} must define MIN_BATCH_SIZE.")

        batch_size = attrs['MIN_BATCH_SIZE']
        if not isinstance(batch_size, int) or batch_size <= 0:
            raise TypeError(
                f"MIN_BATCH_SIZE in {name} must be a positive integer (got {batch_size})."
            )

        # 2. Check for REQUIRED_FIELDS presence and validation
        if 'REQUIRED_FIELDS' not in attrs:
            raise TypeError(f"Class {name} must define REQUIRED_FIELDS.")

        required_fields = attrs['REQUIRED_FIELDS']
        if not isinstance(required_fields, list) or not required_fields:
            raise TypeError(
                f"REQUIRED_FIELDS in {name} must be a non-empty list (got {required_fields})."
            )
        
        # Optional: Ensure all elements are strings
        if not all(isinstance(f, str) for f in required_fields):
             raise TypeError(f"All elements in REQUIRED_FIELDS must be strings.")

        # If all checks pass, proceed with class creation
        return super().__new__(mcs, name, bases, attrs)

class DataProcessor(metaclass=ConfigEnforcerMeta):
    """Base class for data processing components."""
    pass

class ValidTransformer(DataProcessor):
    MIN_BATCH_SIZE = 128
    REQUIRED_FIELDS = ['user_id', 'timestamp']

# Example of failure scenario (uncomment to test):
# class InvalidMissingBatch(DataProcessor):
#     REQUIRED_FIELDS = ['data'] # Raises TypeError: must define MIN_BATCH_SIZE

# class InvalidEmptyFields(DataProcessor):
#     MIN_BATCH_SIZE = 10
#     REQUIRED_FIELDS = [] # Raises TypeError: must be a non-empty list


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import asyncio
import time

async def execute_agent_tool(tool_name, delay):
    print(f"[{tool_name}] Starting execution (Delay: {delay}s)...")
    try:
        await asyncio.sleep(delay)
        if delay > 2.5:
            print(f"[{tool_name}] WARNING: Execution finished, but took too long.")
        return f"Result from {tool_name} after {delay}s."
    except asyncio.CancelledError:
        print(f"[{tool_name}] Execution cancelled due to pipeline timeout.")
        raise # Re-raise CancelledError to mark the task as cancelled

async def main_orchestrator():
    start_time = time.time()
    
    # Create Task objects from coroutines
    tasks = [
        asyncio.create_task(execute_agent_tool("Search_Engine", 2.0)),
        asyncio.create_task(execute_agent_tool("Database_Lookup", 3.0)), # Will exceed 2.5s
        asyncio.create_task(execute_agent_tool("Calculator", 1.5))
    ]
    
    # NEW IMPLEMENTATION: Use asyncio.wait() with a timeout
    # wait returns two sets: done (completed) and pending (still running)
    done, pending = await asyncio.wait(
        tasks,
        timeout=2.5,
        return_when=asyncio.ALL_COMPLETED # Ignored if timeout is hit
    )

    print(f"\n--- Timeout Reached (2.5s) ---")
    
    # 3. Handle Completion Sets: Cancel pending tasks
    for task in pending:
        print(f"Cancelling pending task: {task.get_name()}...")
        task.cancel()
        # Wait briefly for cancellation to propagate (optional, but good practice)
        await asyncio.sleep(0) 

    # 4. Report Status
    for task in done:
        try:
            result = task.result()
            print(f"[DONE] {task.get_name()}: {result}")
        except asyncio.CancelledError:
            # This handles tasks that might have been cancelled just as they finished
            print(f"[DONE] {task.get_name()}: Was cancelled.")

    for task in pending:
        # Check if cancellation was successful
        print(f"[PENDING/CANCELLED] {task.get_name()}: Cancelled status: {task.cancelled()}")
        
    end_time = time.time()
    print(f"\nTotal orchestration time: {end_time - start_time:.2f} seconds")

if __name__ == "__main__":
    asyncio.run(main_orchestrator())


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import asyncio
import time

# --- BLOCKING FUNCTION (Simulates heavy, synchronous CPU calculation) ---
def cpu_intensive_work(iterations):
    print(f"[CPU Task (Thread)] Starting heavy calculation...")
    # Simulating synchronous, non-yielding work
    start = time.time()
    count = 0
    for i in range(iterations):
        count += i * i 
    end = time.time()
    print(f"[CPU Task (Thread)] Finished calculation in {end - start:.2f}s.")
    return f"CPU result: {count}"

# --- ASYNCHRONOUS I/O TASK (Yields control) ---
async def io_bound_task(delay):
    print(f"[I/O Task (Loop)] Starting simulated network wait...")
    await asyncio.sleep(delay) # Yields control back to the Event Loop
    print(f"[I/O Task (Loop)] Finished network wait.")
    return "I/O result: Data fetched"

async def main_fixed():
    start_time = time.time()
    
    # 1. Get the current running Event Loop
    loop = asyncio.get_running_loop()
    
    # 2. Schedule the synchronous CPU work to run in the default ThreadPoolExecutor (None)
    # This offloads the blocking work to a separate thread.
    cpu_task_future = loop.run_in_executor(
        None, # Use default executor (ThreadPoolExecutor)
        cpu_intensive_work, 
        100_000_000 # Argument for the function
    )
    
    # 3. Task 2: The non-blocking call (runs on the main Event Loop thread)
    io_task = asyncio.create_task(io_bound_task(2.0))
    
    # Await both the future from the executor and the created task concurrently
    cpu_result, io_result = await asyncio.gather(cpu_task_future, io_task)
    
    end_time = time.time()
    print(f"\n--- Results ---")
    print(cpu_result)
    print(io_result)
    print(f"Total time (Concurrent): {end_time - start_time:.2f}s")

if __name__ == "__main__":
    # The total time should now be dominated by the 2.0s I/O wait, 
    # plus the small overhead of the CPU task running concurrently.
    asyncio.run(main_fixed())

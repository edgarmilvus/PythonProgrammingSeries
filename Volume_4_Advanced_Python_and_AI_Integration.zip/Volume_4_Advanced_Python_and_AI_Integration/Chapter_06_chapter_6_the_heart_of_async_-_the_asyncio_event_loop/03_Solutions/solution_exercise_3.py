
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import asyncio
import time

def process_line(line_content):
    """Synchronous helper simulating quick CPU processing per line."""
    # In a real scenario, this might be JSON parsing or simple transformation
    return f"Processed Line (Len: {len(line_content)})"

async def process_file(filename, lines_to_read, delay_per_line):
    total_delay = lines_to_read * delay_per_line
    print(f"[{filename}] START. Simulating {lines_to_read} lines (Total I/O: {total_delay:.1f}s)")
    
    for i in range(1, lines_to_read + 1):
        # 1. Simulate the I/O wait time for reading the next line
        await asyncio.sleep(delay_per_line) 
        
        # 2. Simulate quick CPU work on the line data
        line_data = f"Data line {i} from {filename}"
        process_line(line_data)
        
        # Optional: uncomment to see interleaving clearly
        # print(f"[{filename}] Line {i} read.")

    print(f"[{filename}] FINISHED.")
    return f"{filename} processed {lines_to_read} lines."

async def main():
    start_time = time.time()

    # Define tasks: All have a total simulated I/O time of 1.0s
    tasks = [
        process_file("File_A", lines_to_read=10, delay_per_line=0.1),
        process_file("File_B", lines_to_read=5, delay_per_line=0.2),
        process_file("File_C", lines_to_read=2, delay_per_line=0.5),
    ]

    print("Starting concurrent file processing simulations...")
    results = await asyncio.gather(*tasks)

    end_time = time.time()
    print("\nAll simulations complete.")
    print(f"Results: {results}")
    print(f"Total execution time: {end_time - start_time:.2f} seconds")

if __name__ == "__main__":
    asyncio.run(main())

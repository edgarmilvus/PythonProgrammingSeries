
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import asyncio
import time

async def configure_loader(delay):
    print(f"[Config Loader] Starting initialization (Delay: {delay}s)")
    await asyncio.sleep(delay)
    print(f"[Config Loader] Initialization complete.")

async def db_connector(delay):
    print(f"[DB Connector] Starting connection check (Delay: {delay}s)")
    await asyncio.sleep(delay)
    print(f"[DB Connector] Connection established.")

async def llm_health_check(delay):
    print(f"[LLM Health Check] Starting health verification (Delay: {delay}s)")
    await asyncio.sleep(delay)
    print(f"[LLM Health Check] Health check passed.")

async def main():
    start_time = time.time()
    print("Orchestrator: Scheduling all startup tasks concurrently.")

    # 1. Create Tasks here: Tasks are scheduled immediately upon creation
    task_config = asyncio.create_task(configure_loader(3)) # Longest task
    task_db = asyncio.create_task(db_connector(1))
    task_llm = asyncio.create_task(llm_health_check(2))

    # 2. Await all tasks concurrently using gather()
    # gather waits for all tasks to finish, ensuring main() doesn't exit prematurely.
    await asyncio.gather(task_config, task_db, task_llm)

    end_time = time.time()
    print(f"\nOrchestrator: All tasks completed.")
    print(f"Total execution time: {end_time - start_time:.2f} seconds")

if __name__ == "__main__":
    # 3. Run the main coroutine
    asyncio.run(main())

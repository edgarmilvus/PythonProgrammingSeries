
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from pydantic import BaseModel, Field, model_validator, ValidationError
from typing import List, Literal, Any, Dict
from langchain_core.output_parsers import PydanticOutputParser

# 1. Define Nested Schema (ParameterSchema)
class ParameterSchema(BaseModel):
    """Schema for a single API parameter."""
    name: str
    data_type: str = Field(description="e.g., string, integer, boolean")
    is_required: bool
    description: str

# 2. Define Root Schema (EndpointSchema)
class EndpointSchema(BaseModel):
    """Schema for a complete API endpoint summary."""
    endpoint_path: str = Field(description="The URI path, e.g., /users/{id}")
    http_method: Literal["GET", "POST", "PUT", "DELETE"] = Field(
        description="The HTTP method used for this endpoint."
    )
    summary: str = Field(description="A brief summary of the endpoint's function.")
    parameters: List[ParameterSchema] = Field(
        description="A list of required or optional input parameters."
    )
    success_codes: List[int] = Field(description="List of expected successful HTTP response codes.")

    # 3. Implement Custom Validation (Pydantic V2 model_validator)
    @model_validator(mode='before')
    @classmethod
    def check_parameters_for_mutating_methods(cls, data: Any) -> Any:
        # Pydantic V2 validator receives the raw input dictionary/data before parsing
        if isinstance(data, dict):
            method = data.get('http_method', '').upper()
            parameters = data.get('parameters', [])

            if method in ["POST", "PUT"]:
                if not parameters or len(parameters) == 0:
                    raise ValueError(
                        f"HTTP method '{method}' requires a payload, but the 'parameters' list is empty. "
                        "Please ensure all required input parameters are listed."
                    )
        return data

# 4. Initialize the Parser (LangChain integration setup)
parser = PydanticOutputParser(pydantic_object=EndpointSchema)

# --- Demonstration of Validation ---

# Test Case A: Valid POST (Has parameters)
print("--- Test A: Valid POST Request ---")
valid_post_data = {
    "endpoint_path": "/users",
    "http_method": "POST",
    "summary": "Creates a new user account.",
    "parameters": [
        {"name": "username", "data_type": "string", "is_required": True, "description": "New username"}
    ],
    "success_codes": [201]
}
try:
    EndpointSchema(**valid_post_data)
    print("Success: Valid POST data passed validation.")
except ValidationError as e:
    print(f"Unexpected Validation Error: {e}")

# Test Case B: Invalid POST (Missing parameters - triggers custom validator)
print("\n--- Test B: Invalid POST Request (Missing Parameters) ---")
invalid_post_data = {
    "endpoint_path": "/users",
    "http_method": "POST",
    "summary": "Attempts to create a user without data.",
    "parameters": [], # Empty list triggers the custom validator
    "success_codes": [201]
}
try:
    EndpointSchema(**invalid_post_data)
except ValidationError as e:
    print("Validation failed successfully (Custom Check). Error details:")
    # We expect the error to be a ValueError wrapped by Pydantic
    print(e.errors()[0]['msg'])

# 5. Prompt Template Construction (for LLM context)
print("\n--- Format Instructions for LLM ---")
print(parser.get_format_instructions())


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from pydantic import BaseModel, Field, ValidationError
from typing import List

# 1. Define the Schema
class ComponentMetadata(BaseModel):
    """Schema for extracting technical metadata about a software component."""
    component_name: str = Field(description="The official name of the software component.")
    version_number: float = Field(description="The current major/minor version number.")
    dependencies: List[str] = Field(description="A list of required external dependencies.")
    is_production_ready: bool = Field(description="Deployment status flag.")
    estimated_complexity_score: int = Field(
        description="A score from 1 (simple) to 10 (highly complex).",
        ge=1, # Greater than or equal to 1
        le=10  # Less than or equal to 10
    )

# Test Case 1: Successful Validation
print("--- Test 1: Successful Validation ---")
valid_data = {
    "component_name": "API Gateway",
    "version_number": 3.5,
    "dependencies": ["Nginx", "Redis", "AuthLib"],
    "is_production_ready": True,
    "estimated_complexity_score": 7
}
try:
    component = ComponentMetadata(**valid_data)
    print(f"Success: Component '{component.component_name}' validated.")
    print(f"Score: {component.estimated_complexity_score}")
except ValidationError as e:
    print(f"Unexpected Validation Error: {e}")


# Test Case 2: Failed Validation (Must raise ValidationError)
print("\n--- Test 2: Failed Validation ---")
invalid_data = {
    "component_name": "Database Connector",
    "version_number": "v1.0",  # Type Error (str instead of float)
    "dependencies": ["SQLAlchemy"],
    "is_production_ready": 1, # Type Error (int instead of bool)
    "estimated_complexity_score": 12 # Range Error (12 > 10)
}
try:
    ComponentMetadata(**invalid_data)
except ValidationError as e:
    print("Validation failed successfully. Error details:")
    # Print specific errors to confirm range and type checks worked
    for error in e.errors():
        print(f"  Field '{error['loc'][0]}': {error['msg']}")

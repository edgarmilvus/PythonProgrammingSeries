
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import PydanticOutputParser, OutputParserException
from langchain_community.llms import FakeListLLM
from langchain.chains import LLMChain
from pydantic import BaseModel, Field
from typing import List, Optional

# Define the Schema (Reusing from Ex 2)
class MovieSummary(BaseModel):
    title: str = Field(description="The full title of the movie.")
    release_year: int = Field(description="The year the movie was released.")
    genres: List[str] = Field(description="A list of genres the movie belongs to.")

# 1. Initialize the Parser
parser = PydanticOutputParser(pydantic_object=MovieSummary)

# 2. Define the Initial Prompt Template
INITIAL_TEMPLATE = (
    "Extract structured data for the movie '{movie_title}'.\n"
    "Output MUST be a JSON object conforming to the schema.\n"
    "{format_instructions}\n"
)
initial_prompt = PromptTemplate(
    template=INITIAL_TEMPLATE,
    input_variables=["movie_title"],
    partial_variables={"format_instructions": parser.get_format_instructions()}
)

# 3. Implement the Retry Loop
def run_reliable_parsing(initial_prompt_template: PromptTemplate,
                         parser: PydanticOutputParser,
                         user_input: str,
                         max_retries: int = 3) -> Optional[MovieSummary]:
    
    # Initialize LLM responses: 1. Malformed, 2. Corrected
    llm = FakeListLLM(responses=[
        # 1. Malformed response (missing comma between release_year and genres)
        '{"title": "Dune", "release_year": 2021 "genres": ["Sci-Fi", "Adventure"]}',
        # 2. Corrected response
        '{"title": "Dune", "release_year": 2021, "genres": ["Sci-Fi", "Adventure"]}'
    ])
    
    current_prompt = initial_prompt_template
    
    for attempt in range(1, max_retries + 1):
        print(f"\n--- Attempt {attempt} ---")
        
        # Determine the input variables for the current prompt
        # If this is the first attempt, use only the movie title.
        # If this is a retry, the prompt template will already contain feedback variables.
        input_vars = {"movie_title": user_input}
        
        # Build the chain for the current attempt
        chain = LLMChain(prompt=current_prompt, llm=llm, output_parser=parser)

        try:
            # Run the chain. The parser will try to validate the LLM's raw output.
            result = chain.run(**input_vars)
            print("Parsing SUCCESSFUL.")
            return result
        
        except OutputParserException as e:
            print(f"Parsing FAILED on attempt {attempt}. Error: {e}")
            if attempt == max_retries:
                print("Max retries reached. Aborting.")
                return None

            # --- Self-Correction Mechanism ---
            
            # 1. Capture feedback
            error_message = str(e)
            
            # 2. Construct the feedback prompt for the next attempt
            feedback_template = (
                "You previously failed to generate the required JSON structure for the movie '{movie_title}'.\n"
                "The raw output you provided was:\n---\n{raw_output}\n---\n"
                "The parsing error received was:\n---\n{error_message}\n---\n"
                "CRITICAL: Review the error message and the schema below. Output ONLY the corrected, valid JSON object.\n"
                "{format_instructions}\n"
            )
            
            # Note: We need to pull the raw output from the exception if possible, 
            # but since FakeListLLM doesn't easily expose the raw output in this structure, 
            # we rely on the LLM's sequence. For a real system, the exception often contains the raw text.
            # In this simulated environment, we rely on the LLM sequence provided to FakeListLLM.
            
            # For demonstration, we simulate injecting the error message into a new template.
            current_prompt = PromptTemplate(
                template=feedback_template,
                input_variables=["movie_title"],
                partial_variables={
                    "format_instructions": parser.get_format_instructions(),
                    # Since we can't easily capture the *specific* raw output of the failed LLM call
                    # in this simplified chain structure, we use a placeholder for demonstration:
                    "raw_output": "MALFORMED JSON (See error message)", 
                    "error_message": error_message
                }
            )
            
    return None

# Example usage:
result = run_reliable_parsing(
    initial_prompt_template=initial_prompt, 
    parser=parser, 
    user_input="Dune", 
    max_retries=2
)

if result:
    print(f"\nFinal Validated Result: {result.title} ({result.release_year})")
    print(f"Result Type: {type(result)}")

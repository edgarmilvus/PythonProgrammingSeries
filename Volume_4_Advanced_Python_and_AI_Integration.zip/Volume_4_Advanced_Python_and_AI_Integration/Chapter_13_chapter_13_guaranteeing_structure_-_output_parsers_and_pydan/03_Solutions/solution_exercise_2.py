
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import PydanticOutputParser
from langchain_community.llms import FakeListLLM
from langchain.chains import LLMChain
from pydantic import BaseModel, Field
from typing import List

# 1. Define the Schema
class MovieSummary(BaseModel):
    """Structured summary of a movie's key metadata."""
    title: str = Field(description="The full title of the movie.")
    release_year: int = Field(description="The year the movie was released.")
    genres: List[str] = Field(description="A list of genres the movie belongs to.")

# 2. Initialize the Parser
parser = PydanticOutputParser(pydantic_object=MovieSummary)

# 3. Construct the Prompt Template
template = (
    "You are a structured data extraction expert. Your task is to extract structured data about the movie '{movie_title}'.\n"
    "The output must strictly be a JSON object conforming to the schema provided below.\n"
    "{format_instructions}\n"
    "Begin Extraction:"
)

prompt = PromptTemplate(
    template=template,
    input_variables=["movie_title"],
    partial_variables={"format_instructions": parser.get_format_instructions()}
)

# 4. Build the Chain (using a mock LLM output for demonstration)
# The mock LLM output must be valid JSON matching the MovieSummary schema
llm = FakeListLLM(responses=[
    '{"title": "Inception", "release_year": 2010, "genres": ["Sci-Fi", "Action", "Thriller"]}'
])

chain = LLMChain(
    prompt=prompt,
    llm=llm,
    output_parser=parser
)

# 5. Execute and Validate
movie_title = "Inception"
print(f"Running chain for: {movie_title}")
result = chain.run(movie_title=movie_title)

# Validation Check
print("\n--- Validation Results ---")
print(f"Output Type: {type(result)}")
print(f"Title: {result.title}")
print(f"Release Year (Type Check): {type(result.release_year)}")
print(f"Genres (List Check): {result.genres}")

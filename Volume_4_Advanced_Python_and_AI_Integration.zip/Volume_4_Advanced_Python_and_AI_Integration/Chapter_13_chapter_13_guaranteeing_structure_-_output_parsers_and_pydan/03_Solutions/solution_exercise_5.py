
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from langchain.chains import SequentialChain, LLMChain
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import PydanticOutputParser
from langchain_community.llms import FakeListLLM
from pydantic import BaseModel, Field
from typing import List

# --- Schemas ---

# 1. Define Schema 1 (Metadata)
class PaperMetadata(BaseModel):
    title: str = Field(description="The official title of the paper.")
    author_list: List[str] = Field(description="A list of all primary authors.")
    publication_year: int = Field(description="The year the paper was published.")

# 2. Define Schema 2 (Nested Findings)
class Finding(BaseModel):
    description: str = Field(description="A detailed summary of the finding.")
    confidence_score: float = Field(description="The scientific confidence (0.0 to 1.0).", ge=0.0, le=1.0)

class PaperFindings(BaseModel):
    key_findings: List[Finding] = Field(description="A list of all key findings extracted from the paper.")

# --- Parsers and LLM Setup ---

# Initialize Parsers
metadata_parser = PydanticOutputParser(pydantic_object=PaperMetadata)
findings_parser = PydanticOutputParser(pydantic_object=PaperFindings)

# Mock LLM setup (using a single LLM instance for both chains)
# Response 1: Metadata JSON
# Response 2: Findings JSON
llm = FakeListLLM(responses=[
    # Response 1 (for Metadata Extraction)
    '{"title": "Deep Reinforcement Learning for Dynamic Resource Allocation", "author_list": ["Dr. A. Smith", "Prof. B. Jones"], "publication_year": 2023}',
    
    # Response 2 (for Findings Extraction)
    '{"key_findings": ['
    '{"description": "A 15% efficiency gain was observed using the new DRL model.", "confidence_score": 0.95},'
    '{"description": "A novel exploration strategy was detailed.", "confidence_score": 0.88}'
    ']}'
])

# --- Chain 1: Metadata Extraction ---

metadata_template_string = """
Extract the high-level metadata from the following academic text: {raw_text}
{format_instructions}
"""
prompt_metadata = PromptTemplate(
    template=metadata_template_string,
    input_variables=["raw_text"],
    partial_variables={"format_instructions": metadata_parser.get_format_instructions()}
)

chain_metadata = LLMChain(
    llm=llm,
    prompt=prompt_metadata,
    output_parser=metadata_parser,
    output_key="metadata_output" # Output key for SequentialChain
)

# --- Chain 2: Findings Extraction ---

findings_template_string = """
You have already identified the paper as '{metadata_output}'. Now, extract the key findings and their confidence scores.
Text: {raw_text}
{format_instructions}
"""
prompt_findings = PromptTemplate(
    template=findings_template_string,
    # Note: raw_text is needed to read the source, metadata_output is needed for context
    input_variables=["raw_text", "metadata_output"], 
    partial_variables={"format_instructions": findings_parser.get_format_instructions()}
)

chain_findings = LLMChain(
    llm=llm,
    prompt=prompt_findings,
    output_parser=findings_parser,
    output_key="findings_output" # Output key for SequentialChain
)

# --- Sequential Chain Orchestration ---

academic_text = (
    "The paper titled 'Deep Reinforcement Learning for Dynamic Resource Allocation' "
    "was published in 2023 by Dr. A. Smith and Prof. B. Jones. "
    "Key finding 1 shows a 15% efficiency gain (confidence 0.95). "
    "Key finding 2 details a new exploration strategy (confidence 0.88)."
)

overall_chain = SequentialChain(
    chains=[chain_metadata, chain_findings],
    input_variables=["raw_text"],
    # We output both validated objects
    output_variables=["metadata_output", "findings_output"], 
    verbose=False
)

print("Running Multi-Stage Extraction Chain...")
result = overall_chain.invoke({"raw_text": academic_text})

# --- Final Validation ---
print("\n--- Final Results ---")
print(f"Metadata Type: {type(result['metadata_output'])}")
print(f"Findings Type: {type(result['findings_output'])}")

print("\nExtracted Metadata:")
print(f"Title: {result['metadata_output'].title}")
print(f"Authors: {result['metadata_output'].author_list}")

print("\nExtracted Findings:")
for finding in result['findings_output'].key_findings:
    print(f"- {finding.description} (Score: {finding.confidence_score})")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import aiohttp
import asyncio
import json

BASE_URL = "https://jsonplaceholder.typicode.com"

async def fetch_data(session: aiohttp.ClientSession, url: str, name: str) -> dict:
    """Generic function to fetch data using the provided shared session."""
    print(f"[{name}] Starting request using shared session at {url.split('/')[-1]}")
    
    # The session is passed here, reusing the underlying connection pool
    async with session.get(url) as response:
        response.raise_for_status()
        data = await response.json()
        print(f"[{name}] Finished request. Status: {response.status}")
        # Return relevant data snippet
        return {name: data.get('title') or data.get('name') or data.get('email')}

async def fetch_endpoint_a(session: aiohttp.ClientSession):
    return await fetch_data(session, f"{BASE_URL}/posts/1", "Endpoint A (Post)")

async def fetch_endpoint_b(session: aiohttp.ClientSession):
    return await fetch_data(session, f"{BASE_URL}/comments/1", "Endpoint B (Comment)")

async def fetch_endpoint_c(session: aiohttp.ClientSession):
    return await fetch_data(session, f"{BASE_URL}/users/1", "Endpoint C (User)")

async def main_fetcher():
    print("--- 1. Initializing ClientSession (Start) ---")
    
    # 1. Centralized Session: Use async with for guaranteed cleanup (POLA)
    async with aiohttp.ClientSession() as session:
        print("--- 2. ClientSession is active and ready ---")
        
        # 3. Sequential Execution: All calls reuse the 'session' object (DRY)
        result_a = await fetch_endpoint_a(session)
        result_b = await fetch_endpoint_b(session)
        result_c = await fetch_endpoint_c(session)
        
        print("\n--- All sequential requests completed ---")
        return [result_a, result_b, result_c]
    
    # The session is automatically closed here
    print("--- 3. ClientSession automatically closed (End) ---")

if __name__ == "__main__":
    results = asyncio.run(main_fetcher())
    print("\nFinal Results:")
    print(json.dumps(results, indent=2))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import aiohttp
import asyncio
import time
import json
from typing import List

BASE_URL = "https://jsonplaceholder.typicode.com"

async def fetch_resource(session: aiohttp.ClientSession, resource_id: int) -> dict:
    """
    Single, reusable coroutine to fetch data for a specific resource ID.
    """
    url = f"{BASE_URL}/todos/{resource_id}"
    
    async with session.get(url) as response:
        response.raise_for_status()
        data = await response.json()
        
        # Return a summary of the fetched data
        return {
            "id": resource_id,
            "title_snippet": data.get('title')[:30] + "...",
            "completed": data.get('completed')
        }

async def main_concurrent_fetcher(resource_ids: List[int]):
    start_total = time.time()
    print(f"Starting concurrent fetch of {len(resource_ids)} resources...")
    
    async with aiohttp.ClientSession() as session:
        # 3. Task Creation: Use a list comprehension to create 10 coroutines
        tasks = [
            fetch_resource(session, resource_id) 
            for resource_id in resource_ids
        ]
        
        # 4. Parallel Execution: Use asyncio.gather()
        results = await asyncio.gather(*tasks)
        
    total_time = time.time() - start_total
    print(f"\nTotal execution time: {total_time:.2f} seconds.")
    
    return results

if __name__ == "__main__":
    resource_list = list(range(1, 11)) # IDs 1 through 10
    results = asyncio.run(main_concurrent_fetcher(resource_list))
    print(f"Successfully retrieved {len(results)} results.")
    # print(json.dumps(results, indent=2)) # Uncomment to see full results

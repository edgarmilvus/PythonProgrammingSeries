
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import aiohttp
import asyncio
import json
from typing import List

BASE_URL = "https://jsonplaceholder.typicode.com"

async def fetch_resource_robust(session: aiohttp.ClientSession, resource_id: int) -> dict:
    """
    Fetches a resource, handling network and HTTP errors gracefully.
    """
    url = f"{BASE_URL}/posts/{resource_id}"
    # Configure a client-side timeout
    timeout = aiohttp.ClientTimeout(total=3) 
    
    try:
        # 1. Attempt the request
        async with session.get(url, timeout=timeout) as response:
            # 2. Check response.raise_for_status() 
            response.raise_for_status()
            
            data = await response.json()
            
            # Successful return
            return {
                "id": resource_id, 
                "status": "Success", 
                "title": data.get('title', 'N/A')
            }
            
    except aiohttp.ClientResponseError as e:
        # 1. Handle HTTP errors (4xx, 5xx)
        error_message = f"{e.status} {e.message}"
        print(f"--- Handled HTTP Error for ID {resource_id}: {error_message}")
        return {
            "id": resource_id, 
            "status": "Failed (HTTP)", 
            "error": error_message
        }
        
    except asyncio.TimeoutError:
        # 1. Handle network/timeout issues
        print(f"--- Handled Timeout Error for ID {resource_id}")
        return {
            "id": resource_id, 
            "status": "Failed (Timeout)", 
            "error": "Request timed out"
        }
        
    except Exception as e:
        # Catch any other unexpected errors
        return {
            "id": resource_id, 
            "status": "Failed (Unknown)", 
            "error": str(e)
        }


async def main_robust_fetcher(resource_ids: List[int]):
    print(f"Starting robust concurrent fetch for {len(resource_ids)} resources...")
    
    async with aiohttp.ClientSession() as session:
        tasks = [
            fetch_resource_robust(session, resource_id) 
            for resource_id in resource_ids
        ]
        
        # 3. Preservation of Results: gather will complete successfully
        results = await asyncio.gather(*tasks)
        return results

if __name__ == "__main__":
    # Test case: ID 1, 2 succeed. ID 999 fails (404). ID 1000 fails (404).
    resource_list = [1, 999, 2, 1000] 
    results = asyncio.run(main_robust_fetcher(resource_list))
    print("\nFinal Aggregated Results:")
    print(json.dumps(results, indent=2))

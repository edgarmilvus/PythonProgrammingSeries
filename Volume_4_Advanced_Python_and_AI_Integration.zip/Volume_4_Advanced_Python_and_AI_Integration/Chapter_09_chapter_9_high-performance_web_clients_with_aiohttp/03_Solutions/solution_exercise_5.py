
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import asyncio
import aiohttp
import time
from typing import List

# Use a URL with a known delay to clearly demonstrate throttling effect
DELAY_URL = "https://httpbin.org/delay/1" 

async def fetch_resource_throttled(session: aiohttp.ClientSession, resource_id: int, semaphore: asyncio.Semaphore) -> dict:
    """
    Fetches a resource, respecting the concurrency limit set by the semaphore.
    """
    
    # 4. Guaranteed Slot Release: Use the async context manager
    async with semaphore:
        # The task waits here until a slot is available
        
        print(f"Acquired slot. Fetching resource {resource_id}. Active slots: {semaphore._value + 1}")
        
        start_fetch = time.time()
        
        try:
            # 1. Perform the actual network request (simulating 1 second delay)
            async with session.get(DELAY_URL, timeout=5) as response:
                await response.read() 
            
            fetch_time = time.time() - start_fetch
            return {"id": resource_id, "status": "Success", "fetch_time": f"{fetch_time:.2f}s"}
            
        except Exception as e:
            return {"id": resource_id, "status": "Failed", "error": str(e)}
        
    # The slot is automatically released upon exiting the 'async with' block
    print(f"Released slot. Finished resource {resource_id}.")


async def main_throttled_fetcher(resource_ids: List[int], limit: int):
    print(f"Starting throttled fetch. Total tasks: {len(resource_ids)}. Concurrency limit: {limit}")
    
    # 2. Semaphore Initialization
    throttler = asyncio.Semaphore(limit)
    
    start_total = time.time()
    
    async with aiohttp.ClientSession() as session:
        # 3. Create tasks, passing the semaphore
        tasks = [
            fetch_resource_throttled(session, resource_id, throttler)
            for resource_id in resource_ids
        ]
        
        # Gather the results
        results = await asyncio.gather(*tasks)
        
    total_time = time.time() - start_total
    print(f"\nTotal execution time for {len(resource_ids)} tasks: {total_time:.2f} seconds.")
    return results

if __name__ == "__main__":
    resource_list = list(range(1, 21)) # 20 total resources
    CONCURRENCY_LIMIT = 5
    
    results = asyncio.run(main_throttled_fetcher(resource_list, limit=CONCURRENCY_LIMIT))

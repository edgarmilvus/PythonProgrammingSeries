
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
import json
import aiohttp
import asyncio
import shutil
from typing import List

BASE_URL = "https://jsonplaceholder.typicode.com"
OUTPUT_DIR = "concurrent_results"

def setup_directory(directory_path: str):
    """Ensures the output directory exists."""
    # 1. Directory Setup: Use exist_ok=True to prevent errors if dir already exists
    os.makedirs(directory_path, exist_ok=True)
    print(f"Setup complete. Output directory: {directory_path}")

async def fetch_and_save_resource(session: aiohttp.ClientSession, resource_id: int) -> str:
    """Fetches data, saves it to a file, and returns the file path."""
    url = f"{BASE_URL}/posts/{resource_id}"
    
    async with session.get(url) as response:
        response.raise_for_status()
        data = await response.json()
        
        # 2. Construct the safe, platform-independent file path
        filename = f"{resource_id}.json"
        file_path = os.path.join(OUTPUT_DIR, filename)
        
        # 3. Write the JSON data to the file (Synchronous operation)
        # NOTE: For high-volume production systems, standard file I/O (open/write) 
        # is blocking. Use 'aiofiles' or 'asyncio.to_thread()' (or run_in_executor)
        # to offload this synchronous work to a separate thread pool.
        try:
            with open(file_path, 'w') as f:
                json.dump(data, f, indent=2)
            
            print(f"Saved ID {resource_id} -> {file_path}")
            return os.path.abspath(file_path)
        except Exception as e:
            return f"File Save Failed for ID {resource_id}: {e}"

async def main_persistence_orchestrator(resource_ids: List[int]):
    # Clean up previous run for demonstration purposes
    if os.path.exists(OUTPUT_DIR):
        shutil.rmtree(OUTPUT_DIR)
        
    setup_directory(OUTPUT_DIR)
    
    async with aiohttp.ClientSession() as session:
        tasks = [
            fetch_and_save_resource(session, resource_id) 
            for resource_id in resource_ids
        ]
        
        results = await asyncio.gather(*tasks)
        return results

if __name__ == "__main__":
    resource_list = list(range(1, 6)) # Fetch IDs 1 through 5
    results = asyncio.run(main_persistence_orchestrator(resource_list))
    print("\nPersistence Orchestration Complete.")
    print(f"Directory contents: {os.listdir(OUTPUT_DIR)}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import asyncio
import time
from typing import List, Tuple

# 1. Define the Asynchronous Task
async def simulate_fetch(service_id: str, delay: float) -> str:
    """Simulates network I/O latency."""
    print(f"[{time.strftime('%H:%M:%S')}] Service {service_id}: Starting fetch (Delay: {delay}s)...")
    await asyncio.sleep(delay)
    return f"Data retrieved from Service {service_id}"

# 2. Define Task Inputs
TASK_INPUTS: List[Tuple[str, float]] = [
    ('A', 1.5), ('B', 0.8), ('C', 2.0), ('D', 1.2), ('E', 1.0)
]

# 3. Sequential Execution
async def run_sequential(tasks: List[Tuple[str, float]]):
    results = []
    print("\n--- Starting Sequential Execution ---")
    start_time = time.perf_counter()
    
    for service_id, delay in tasks:
        result = await simulate_fetch(service_id, delay)
        results.append(result)
        print(f"Sequential Result: {result}")
        
    end_time = time.perf_counter()
    total_time = end_time - start_time
    print(f"--- Sequential Execution Finished in {total_time:.2f} seconds ---\n")
    return total_time

# 4. Concurrent Execution
async def run_concurrent(tasks: List[Tuple[str, float]]):
    print("--- Starting Concurrent Execution (asyncio.gather) ---")
    start_time = time.perf_counter()
    
    # Create a list of coroutines
    coroutines = [simulate_fetch(service_id, delay) for service_id, delay in tasks]
    
    # Run all coroutines concurrently
    results = await asyncio.gather(*coroutines)
    
    end_time = time.perf_counter()
    total_time = end_time - start_time
    print("\nConcurrent Results:")
    for result in results:
        print(f"Concurrent Result: {result}")
        
    print(f"--- Concurrent Execution Finished in {total_time:.2f} seconds ---")
    return total_time

# 5. Benchmarking and Main Runner
async def main():
    time_sequential = await run_sequential(TASK_INPUTS)
    time_concurrent = await run_concurrent(TASK_INPUTS)
    
    time_saved = time_sequential - time_concurrent
    print("\n=======================================================")
    print(f"Total Sequential Time: {time_sequential:.2f} s")
    print(f"Total Concurrent Time: {time_concurrent:.2f} s (Limited by the longest task: 2.0s)")
    print(f"Time Saved by Concurrency: {time_saved:.2f} s")
    print("=======================================================")

if __name__ == "__main__":
    asyncio.run(main())

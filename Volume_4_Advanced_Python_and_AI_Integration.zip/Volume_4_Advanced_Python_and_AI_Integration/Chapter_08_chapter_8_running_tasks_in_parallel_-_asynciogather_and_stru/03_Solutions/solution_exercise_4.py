
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import asyncio
import contextvars
from typing import List, Tuple

# 1. Define Context Variable
REQUEST_ID = contextvars.ContextVar('request_id', default='NO_ID')

# 2. Simulate the LLM Chain
async def run_llm_chain(chain_name: str, input_text: str) -> str:
    """Simulates an LLM chain, retrieving the Request ID from the context."""
    
    # Retrieve the Request ID specific to this task's context
    current_request_id = REQUEST_ID.get()
    
    # Simulate I/O delay based on chain name
    delay = 0.5 if "Summarizer" in chain_name else 0.3
    
    print(f"[{chain_name}] Starting processing. Context ID: {current_request_id}")
    await asyncio.sleep(delay)
    
    return f"Chain '{chain_name}' finished. Used Request ID: {current_request_id}."

# 3. Define Chain Configurations
chain_configs: List[Tuple[str, str]] = [
    ("Summarizer", "REQ-101"),
    ("KeywordExtractor", "REQ-102"),
    ("ToneAnalyzer", "REQ-103"),
]

async def main():
    input_text = "The quick brown fox jumps over the lazy dog."
    contextualized_tasks = []

    print("Preparing concurrent tasks with isolated context variables...")
    
    # 4. Implement Contextual Task Launch
    for chain_name, new_id in chain_configs:
        # 4a. Create a new context
        ctx = contextvars.copy_context()
        
        # 4b. Set the specific REQUEST_ID within that new context
        # ctx.run() is used here to modify the context state before scheduling the task
        ctx.run(REQUEST_ID.set, new_id)
        
        # 4c. Create the task, ensuring it runs with the specific context
        task = ctx.run(run_llm_chain, chain_name, input_text)
        contextualized_tasks.append(task)

    # 5. Execute Concurrently
    print("\nExecuting all chains concurrently via asyncio.gather...")
    results = await asyncio.gather(*contextualized_tasks)

    # 6. Verification
    print("\n--- Final Results Verification ---")
    for result in results:
        print(result)

if __name__ == "__main__":
    asyncio.run(main())

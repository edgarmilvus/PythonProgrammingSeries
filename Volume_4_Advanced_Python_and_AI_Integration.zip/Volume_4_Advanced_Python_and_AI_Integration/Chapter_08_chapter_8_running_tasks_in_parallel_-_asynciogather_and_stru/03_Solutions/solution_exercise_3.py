
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import asyncio
import time

# 1. Define Tasks with Variable Delays
async def query_db(query_name: str, delay: float) -> str:
    """Simulates a database query with a given delay."""
    try:
        print(f"[{time.strftime('%H:%M:%S')}] Query '{query_name}' started (Delay: {delay}s)")
        await asyncio.sleep(delay)
        return f"Query '{query_name}' completed successfully."
    except asyncio.CancelledError:
        # This block proves that the task was cancelled by the timeout wrapper
        print(f"[{time.strftime('%H:%M:%S')}] Query '{query_name}' was CANCELLED.")
        raise # Re-raise the cancellation to ensure structured cleanup

async def main():
    # Define tasks: T1 (1.0s), T2 (3.5s - will exceed limit), T3 (0.5s)
    tasks = [
        query_db("User Data", 1.0),
        query_db("Order History", 3.5),
        query_db("Inventory Check", 0.5),
    ]
    
    GROUP_DEADLINE = 2.5
    
    print(f"Starting data aggregation with a strict group deadline of {GROUP_DEADLINE} seconds.")
    
    try:
        # 2. Implement Group Execution (gather)
        # 3. Enforce Group Timeout (wait_for)
        results = await asyncio.wait_for(
            asyncio.gather(*tasks),
            timeout=GROUP_DEADLINE
        )
        
        print("\nAggregation Results:")
        for result in results:
            print(f"- {result}")
            
    # 4. Handle Cancellation
    except asyncio.TimeoutError:
        print("\n=======================================================")
        print(f"CRITICAL: Aggregation cancelled! The entire group exceeded the {GROUP_DEADLINE}s deadline.")
        print("Structured Concurrency ensured no task ran past the timeout.")
        print("=======================================================")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

if __name__ == "__main__":
    # Note: Execution time will be approximately 2.5 seconds.
    asyncio.run(main())

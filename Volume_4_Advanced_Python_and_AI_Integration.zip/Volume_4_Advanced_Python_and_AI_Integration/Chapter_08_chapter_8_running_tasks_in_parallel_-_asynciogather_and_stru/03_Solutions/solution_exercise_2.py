
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import asyncio
from typing import List, Union

# 1. Define Custom Exceptions
class ValidationError(Exception):
    """Raised for invalid input data."""
    pass

class ServiceUnavailableError(Exception):
    """Raised for external system failure."""
    pass

# 2. Define the Task
async def process_record(record_id: int) -> str:
    """Simulates record processing with conditional failures."""
    await asyncio.sleep(0.1) # Simulate minimal processing time
    
    if record_id % 3 == 0:
        # Fails for records 3, 6, 9
        raise ValidationError(f"Invalid data for record {record_id}")
    elif record_id % 7 == 0:
        # Fails for record 7
        raise ServiceUnavailableError(f"External service down for record {record_id}")
    else:
        # Success for records 1, 2, 4, 5, 8, 10
        return f"Record {record_id} processed successfully."

async def main():
    record_ids = range(1, 11)
    
    # 3. Implement Concurrent Execution
    tasks = [process_record(rid) for rid in record_ids]
    
    # Use return_exceptions=True to ensure exceptions are returned as results, not raised
    print("Starting concurrent processing with error isolation...")
    results: List[Union[str, Exception]] = await asyncio.gather(*tasks, return_exceptions=True)
    
    # 4. Result Analysis
    print("\n--- Batch Processing Results ---")
    success_count = 0
    validation_count = 0
    service_error_count = 0
    
    for i, result in enumerate(results):
        record_id = i + 1
        
        if isinstance(result, str):
            # Success
            print(f"[SUCCESS] Record {record_id}: {result}")
            success_count += 1
        elif isinstance(result, ValidationError):
            # Specific Validation Error
            print(f"[VALIDATION ERROR] Record {record_id}: {result}")
            validation_count += 1
        elif isinstance(result, ServiceUnavailableError):
            # Specific Service Error
            print(f"[SERVICE UNAVAILABLE] Record {record_id}: {result}")
            service_error_count += 1
        else:
            # Catch unexpected errors (e.g., ZeroDivisionError, etc.)
            print(f"[UNEXPECTED ERROR] Record {record_id}: {type(result).__name__} - {result}")

    print("\n--- Summary ---")
    print(f"Total Records: {len(record_ids)}")
    print(f"Successful: {success_count}")
    print(f"Validation Errors (3, 6, 9): {validation_count}")
    print(f"Service Errors (7): {service_error_count}")

if __name__ == "__main__":
    asyncio.run(main())


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import asyncio
from typing import List, Dict, Any, Union

# 2. Define the Base Task
async def worker_task(task_id: int, delay: float) -> str:
    """Simulates I/O work and returns success."""
    # Simulate an internal error for Task 6, even though it should timeout later
    if task_id == 6 and delay > 5.0:
        raise ValueError(f"Task {task_id}: Simulated internal configuration error.")
    
    await asyncio.sleep(delay)
    return f"Task {task_id} (Delay: {delay}s) completed successfully."

# 1. Define Priority Input Structure
batch_input: List[Dict[str, Any]] = [
    {"id": 1, "priority": 1, "delay": 1.2},  # Priority 1 (Max 1.0s) -> Timeout
    {"id": 2, "priority": 2, "delay": 0.5},  # Priority 2 (Max 3.0s) -> Success
    {"id": 3, "priority": 3, "delay": 4.0},  # Priority 3 (Max 5.0s) -> Success
    {"id": 4, "priority": 1, "delay": 0.8},  # Priority 1 (Max 1.0s) -> Success
    {"id": 5, "priority": 2, "delay": 3.5},  # Priority 2 (Max 3.0s) -> Timeout
    {"id": 6, "priority": 3, "delay": 6.0},  # Priority 3 (Max 5.0s) -> Internal Error (simulated ValueError)
    {"id": 7, "priority": 2, "delay": 1.5},  # Priority 2 (Max 3.0s) -> Success
]

# Priority to Timeout mapping
PRIORITY_TIMEOUTS = {
    1: 1.0, # High
    2: 3.0, # Medium
    3: 5.0  # Low
}

# 3. Conditional Task Generation
def create_prioritized_tasks(batch: List[Dict[str, Any]]) -> List[asyncio.Future]:
    """Generates tasks wrapped in asyncio.wait_for based on priority."""
    prioritized_tasks = []
    for item in batch:
        task_id = item["id"]
        priority = item["priority"]
        delay = item["delay"]
        timeout = PRIORITY_TIMEOUTS.get(priority)
        
        base_coro = worker_task(task_id, delay)
        
        # Wrap the base coroutine in asyncio.wait_for with the correct timeout
        wrapped_task = asyncio.wait_for(base_coro, timeout=timeout)
        prioritized_tasks.append(wrapped_task)
        
        print(f"Task {task_id} created: Priority {priority}, Timeout {timeout}s, Delay {delay}s.")
        
    return prioritized_tasks

async def main():
    # Create the dynamically wrapped tasks
    tasks = create_prioritized_tasks(batch_input)
    
    print("\nExecuting batch concurrently...")
    
    # 4. Execute and Classify Results
    # Use return_exceptions=True to capture TimeoutErrors and ValueErrors
    results: List[Union[str, Exception]] = await asyncio.gather(*tasks, return_exceptions=True)
    
    success_count = 0
    timeout_count = 0
    internal_error_count = 0
    
    print("\n--- Detailed Result Classification ---")
    for i, result in enumerate(results):
        task_info = batch_input[i]
        task_id = task_info['id']
        
        if isinstance(result, str):
            print(f"[SUCCESS] Task {task_id}: {result}")
            success_count += 1
        elif isinstance(result, asyncio.TimeoutError):
            print(f"[TIMEOUT] Task {task_id} exceeded {PRIORITY_TIMEOUTS[task_info['priority']]}s limit.")
            timeout_count += 1
        else:
            # Catches ValueError (Task 6) and any other unexpected exceptions
            print(f"[INTERNAL ERROR] Task {task_id}: {type(result).__name__} - {result}")
            internal_error_count += 1

    # 5. Summary Report
    print("\n--- Final Summary ---")
    print(f"Total Tasks: {len(batch_input)}")
    print(f"Successful Tasks: {success_count}") # Expected: 4 (2, 3, 4, 7)
    print(f"Timeout Failures: {timeout_count}") # Expected: 2 (1, 5)
    print(f"Internal Errors: {internal_error_count}") # Expected: 1 (6)

if __name__ == "__main__":
    asyncio.run(main())

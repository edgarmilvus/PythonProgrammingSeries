
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

def make_currency_formatter(symbol, precision):
    """
    Factory function that generates a specialized currency formatting closure.
    Captures: symbol and precision (Configuration for the filter).
    """
    
    # Pre-calculate the dynamic format string based on captured precision
    # e.g., if precision=2, format_spec is ".2f"
    format_spec = f".{precision}f"
    
    def format_value(value):
        """
        The closure that applies the formatting rules using the encapsulated state.
        """
        # Format the number using the calculated format specification
        formatted_number = format(value, format_spec)
        
        # Prepend the encapsulated symbol
        return f"{symbol}{formatted_number}"
    
    return format_value

# Create specialized formatters (simulating Jinja2 filters)
usd_formatter = make_currency_formatter('$', 2)
eur_formatter = make_currency_formatter('€', 4)

value_1 = 12345.6789
value_2 = 987.654321

# Simulate Jinja2 rendering (applying the filter)
print(f"USD Format (2 decimals): {usd_formatter(value_1)}") 
# Expected: $12345.68
print(f"EUR Format (4 decimals): {eur_formatter(value_2)}") 
# Expected: €987.6543


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

def make_data_processor_factory(min_length, required_prefix, error_message):
    """
    Factory function that creates a specialized data processor closure.
    It encapsulates configuration variables (min_length, required_prefix, error_message).
    """
    
    def process_data(data_item):
        """
        The closure that performs validation and transformation based on the 
        encapsulated configuration from the enclosing scope.
        """
        
        # Validation Check 1: Length (uses encapsulated min_length)
        if len(data_item) < min_length:
            raise ValueError(f"Length check failed: {error_message} (Required min: {min_length})")
            
        # Validation Check 2: Prefix (uses encapsulated required_prefix)
        if not data_item.startswith(required_prefix):
            raise ValueError(f"Prefix check failed: {error_message} (Required prefix: {required_prefix})")
            
        # Transformation
        return data_item.upper()

    return process_data

# Create specialized processors
username_processor = make_data_processor_factory(
    min_length=5, 
    required_prefix="USR_", 
    error_message="Invalid Username Format."
)

transaction_processor = make_data_processor_factory(
    min_length=10, 
    required_prefix="TXN_", 
    error_message="Invalid Transaction ID Format."
)

# Test cases demonstrating independent configuration
print(f"Username 1 (Valid): {username_processor('USR_Alice')}")
print(f"Transaction 1 (Valid): {transaction_processor('TXN_1234567890')}")

try:
    username_processor("Bob") # Too short
except ValueError as e:
    print(f"Username 2 (Fail): {e}")

try:
    transaction_processor("TXN_short") # Too short
except ValueError as e:
    print(f"Transaction 2 (Fail): {e}")

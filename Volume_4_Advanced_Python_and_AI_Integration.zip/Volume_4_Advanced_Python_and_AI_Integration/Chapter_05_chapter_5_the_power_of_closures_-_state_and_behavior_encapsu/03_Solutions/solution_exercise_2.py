
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

def make_sequence_generator(start_value, step_size):
    """
    Factory function for sequence generators.
    Initializes state (current_value) and configuration (step).
    """
    current_value = start_value
    step = step_size
    
    def next_sequence_number():
        """
        Closure that generates the next number, modifying the state 
        in the enclosing scope using 'nonlocal'.
        """
        # CRITICAL: Declare current_value as nonlocal to modify the 
        # variable in make_sequence_generator's scope, not create a new local one.
        nonlocal current_value 
        
        # Calculate the next value
        current_value += step
        
        return current_value

    return next_sequence_number

# Demonstrate independent state
even_counter = make_sequence_generator(0, 2)
fibonacci_approximator = make_sequence_generator(100, -5)

print("Even Counter Sequence:")
print(f"Call 1: {even_counter()}") # 2
print(f"Call 2: {even_counter()}") # 4

print("Fibonacci Approximator Sequence:")
print(f"Call 1: {fibonacci_approximator()}") # 95
print(f"Call 2: {fibonacci_approximator()}") # 90

print("Even Counter Resume:")
print(f"Call 3: {even_counter()}") # 6 (State was preserved)

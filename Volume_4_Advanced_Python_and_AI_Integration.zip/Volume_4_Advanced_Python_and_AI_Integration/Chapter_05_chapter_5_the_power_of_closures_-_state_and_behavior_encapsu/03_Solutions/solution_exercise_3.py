
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

def configurable_logger(log_level, destination):
    """
    Layer 1: The factory function (Accepts decorator parameters)
    Captures: log_level, destination (Configuration)
    Returns: The actual decorator function (Layer 2)
    """
    
    def decorator(func):
        """
        Layer 2: The actual decorator (Accepts the function to be decorated)
        Defines: call_count (Persistent State)
        Returns: The wrapper closure (Layer 3)
        """
        call_count = 0 
        
        def wrapper(*args, **kwargs):
            """
            Layer 3: The closure that replaces the original function
            Captures: log_level, destination (from Layer 1)
            Modifies: call_count (from Layer 2 using nonlocal)
            """
            nonlocal call_count
            call_count += 1
            
            # Execute the original function
            result = func(*args, **kwargs)
            
            # Logging logic using encapsulated state and configuration
            log_message = (
                f"[{log_level}] ({destination}) "
                f"Call #{call_count} of '{func.__name__}': "
                f"Args={args}, Kwargs={kwargs}. Result={result}"
            )
            print(log_message)
            
            return result
            
        return wrapper
        
    return decorator

# Apply the parameterized decorators
@configurable_logger(log_level='DEBUG', destination='FILE')
def calculate_sum(a, b):
    return a + b

@configurable_logger(log_level='INFO', destination='CONSOLE')
def fetch_user_data(user_id):
    return f"Data for User {user_id}"

# Test calls to demonstrate independent state and configuration
print(f"Result 1: {calculate_sum(10, 20)}") # Log 1 (DEBUG/FILE)
print(f"Result 2: {fetch_user_data(5)}")    # Log 1 (INFO/CONSOLE)
print(f"Result 3: {calculate_sum(5, 5)}")   # Log 2 (DEBUG/FILE) 
print(f"Result 4: {fetch_user_data(10)}")   # Log 2 (INFO/CONSOLE)

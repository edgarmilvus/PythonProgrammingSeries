
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import sys

# 1. Base Class Optimization
class CelestialBody:
    """
    Base class optimized for memory using __slots__.
    """
    __slots__ = ('mass', 'position_x', 'position_y')

    def __init__(self, mass, x, y):
        self.mass = mass
        self.position_x = x
        self.position_y = y

# 2. Subclass Extension
class PlanetarySystem(CelestialBody):
    """
    Subclass that extends the slots defined in the parent.
    """
    # Must define __slots__ explicitly to prevent the creation of __dict__
    # for the subclass and to add new attributes.
    __slots__ = ('num_planets', 'star_type')

    def __init__(self, mass, x, y, planets, star):
        super().__init__(mass, x, y)
        self.num_planets = planets
        self.star_type = star

# --- Verification ---

body = CelestialBody(1e24, 100, 50)
system = PlanetarySystem(5e25, 0, 0, 8, 'G-type')

print(f"CelestialBody size (approx): {sys.getsizeof(body)} bytes")
print(f"PlanetarySystem size (approx): {sys.getsizeof(system)} bytes")

# 3. Preventing Dynamic Attributes (on Base Class)
try:
    print("\nAttempting to assign unslotted attribute to CelestialBody...")
    body.velocity = 10
except AttributeError as e:
    print(f"AttributeError successfully raised: {e}")

# 4. Verification of Optimization (Checking for __dict__)
print("\nChecking for __dict__ presence:")

# Check Base Class
try:
    print(f"CelestialBody.__dict__: {body.__dict__}")
except AttributeError as e:
    print(f"CelestialBody instance lacks __dict__: {e}")

# Check Subclass
try:
    print(f"PlanetarySystem.__dict__: {system.__dict__}")
except AttributeError as e:
    print(f"PlanetarySystem instance lacks __dict__: {e}")

# 5. Documentation (in Analysis block)

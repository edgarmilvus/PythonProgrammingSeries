
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numbers

class SecureAmount:
    """
    A data descriptor enforcing type, positivity, and immutability for financial amounts.
    """
    def __init__(self, name):
        # Store the attribute name for internal storage mangling
        self.public_name = name
        self.internal_name = f'_{name}'

    def __set_name__(self, owner, name):
        # Python automatically calls this during class creation
        self.public_name = name
        self.internal_name = f'_{name}'

    def __get__(self, instance, owner):
        if instance is None:
            return self
        
        # Retrieve the raw float value from the instance's dictionary
        raw_value = instance.__dict__.get(self.internal_name)
        
        if raw_value is None:
            raise AttributeError(f"'{self.public_name}' has not been set yet.")
        
        # 5. Transformation on Get: Format as currency string
        return f"${raw_value:,.2f}"

    def __set__(self, instance, value):
        # Check if the value has already been set (Immutability Constraint)
        if self.internal_name in instance.__dict__:
            raise PermissionError(f"The attribute '{self.public_name}' is immutable and cannot be reset.")

        # 3. Validation on Set: Type Check
        if not isinstance(value, numbers.Real):
            raise TypeError(f"Amount must be a numeric type (float or int), got {type(value).__name__}.")
        
        # Convert int to float for consistency
        value = float(value)

        # 3. Validation on Set: Positivity Check
        if value <= 0:
            raise ValueError("Amount must be a positive value greater than zero.")

        # 2. Internal Storage: Store the validated float value
        instance.__dict__[self.internal_name] = value

    def __delete__(self, instance):
        # Allow deletion, though not strictly required by the prompt, it completes the protocol.
        del instance.__dict__[self.internal_name]

class TransactionRecord:
    # Use the descriptor for the 'value' attribute
    value = SecureAmount('value')

    def __init__(self, initial_value):
        self.value = initial_value

# --- Testing ---

# 6. Host Class Testing: Successful instantiation
try:
    t1 = TransactionRecord(1234.567)
    print(f"T1 Value (Get): {t1.value}")

    # 6. Validation Failure (Negative)
    t_fail_neg = TransactionRecord(100)
    print("\nAttempting to set negative value...")
    t_fail_neg.value = -50.0 # This should raise PermissionError due to immutability, but let's test validation first
except PermissionError:
    # If we set it in __init__, we need a separate test instance for validation failure
    pass

try:
    # Test Validation Failure (Type)
    TransactionRecord("invalid")
except TypeError as e:
    print(f"Validation Failure (Type): {e}")

try:
    # Test Validation Failure (Value)
    TransactionRecord(0)
except ValueError as e:
    print(f"Validation Failure (Value): {e}")

# 6. Immutability Constraint Test
t2 = TransactionRecord(500.00)
print(f"\nT2 Initial Value: {t2.value}")
print("Attempting to reset T2 value...")
try:
    t2.value = 999.99
except PermissionError as e:
    print(f"Immutability Success: {e}")

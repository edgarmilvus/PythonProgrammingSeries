
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

class BaseServiceHandler:
    """
    Base class for all service handlers, enforcing mandatory class attributes
    via __init_subclass__.
    """
    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        
        # 2. Validation Logic & 3. Enforcement
        
        # Check SERVICE_ID
        if not hasattr(cls, 'SERVICE_ID') or not isinstance(cls.SERVICE_ID, str):
            raise TypeError(
                f"Class {cls.__name__} must define a class attribute 'SERVICE_ID' as a string."
            )
        
        # Check MIN_VERSION
        if not hasattr(cls, 'MIN_VERSION') or not isinstance(cls.MIN_VERSION, int):
            raise TypeError(
                f"Class {cls.__name__} must define a class attribute 'MIN_VERSION' as an integer."
            )
        
        print(f"SUCCESS: {cls.__name__} defined correctly with required metadata.")

    def __init__(self, config):
        self.config = config

    def process(self, data):
        raise NotImplementedError

# 4. Testing Success
class APIGatewayHandler(BaseServiceHandler):
    SERVICE_ID = "API_GATEWAY_V1"
    MIN_VERSION = 5
    
    def process(self, data):
        print(f"Processing data via {self.SERVICE_ID} (v{self.MIN_VERSION})")

# Test instantiation of the valid class
gateway = APIGatewayHandler({})
gateway.process("test_data")

# 5. Testing Failure (Omitting SERVICE_ID)
print("\n--- Testing Failure Case 1 (Missing ID) ---")
try:
    class BrokenHandler(BaseServiceHandler):
        # SERVICE_ID is missing
        MIN_VERSION = 1
except TypeError as e:
    print(f"Class Definition Failed as expected: {e}")

# Testing Failure (Wrong Type for MIN_VERSION)
print("\n--- Testing Failure Case 2 (Wrong Type) ---")
try:
    class AnotherBrokenHandler(BaseServiceHandler):
        SERVICE_ID = "BROKEN_V2"
        MIN_VERSION = "two" # Should be an integer
except TypeError as e:
    print(f"Class Definition Failed as expected: {e}")

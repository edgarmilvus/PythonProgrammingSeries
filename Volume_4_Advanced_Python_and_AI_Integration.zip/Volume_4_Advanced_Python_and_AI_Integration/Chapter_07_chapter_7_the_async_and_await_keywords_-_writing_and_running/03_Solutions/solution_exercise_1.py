
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import asyncio
import time

async def initialize_system():
    """Initializes the system, simulating a 0.5s I/O delay."""
    print(f"[{time.strftime('%H:%M:%S')}] Initialization: Starting system setup...")
    await asyncio.sleep(0.5)
    print(f"[{time.strftime('%H:%M:%S')}] Initialization: System setup complete.")

async def process_data():
    """Processes data, simulating a longer 1.5s I/O delay."""
    print(f"[{time.strftime('%H:%M:%S')}] Processing: Starting data analysis...")
    await asyncio.sleep(1.5)
    print(f"[{time.strftime('%H:%M:%S')}] Processing: Data analysis finished.")

async def finalize_report():
    """Finalizes the report, simulating a 0.75s I/O delay."""
    print(f"[{time.strftime('%H:%M:%S')}] Finalization: Generating final report...")
    await asyncio.sleep(0.75)
    print(f"[{time.strftime('%H:%M:%S')}] Finalization: Report successfully generated.")

async def main():
    """The orchestrator coroutine that enforces sequential execution."""
    print("-" * 30)
    await initialize_system()
    await process_data()
    await finalize_report()
    print("-" * 30)

if __name__ == "__main__":
    # Execute the top-level coroutine, managing the event loop lifecycle
    asyncio.run(main())

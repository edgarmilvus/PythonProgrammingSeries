
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import asyncio
import time

async def fetch_config_segment(name, delay, data):
    """Simulates fetching a configuration segment asynchronously."""
    print(f"Fetching {name}...")
    await asyncio.sleep(delay)
    print(f"Finished fetching {name}.")
    return data

async def aggregate_config():
    """Uses TaskGroup for structured concurrency and aggregates results."""
    
    tasks = []
    
    # 1. Use asyncio.TaskGroup for structured concurrency (Python 3.11+)
    async with asyncio.TaskGroup() as tg:
        # Define the data segments
        data_a = {'temperature': 0.7, 'max_tokens': 2048}
        data_b = {'user_id': 42, 'logging_level': 'INFO'}
        data_c = {'version': '3.1', 'max_tokens': 4096}
        
        # 2. Start tasks and store the task objects
        task_params = tg.create_task(fetch_config_segment("model_params", 1.0, data_a))
        task_settings = tg.create_task(fetch_config_segment("user_settings", 0.5, data_b))
        task_defaults = tg.create_task(fetch_config_segment("system_defaults", 1.5, data_c))

        # Store tasks to retrieve results later
        tasks = [task_defaults, task_settings, task_params]

    # 3. Aggregation happens after the TaskGroup block exits, guaranteeing all tasks are done.
    final_config = {}
    
    # The required merging order: defaults, then settings, then params
    # Note: We retrieve the result from the task object using .result()
    
    # 3a. Merge System Defaults first (base layer)
    final_config.update(tasks[0].result()) 
    
    # 3b. Merge User Settings (overwrites defaults)
    final_config.update(tasks[1].result())
    
    # 3c. Merge Model Parameters (overwrites previous values)
    final_config.update(tasks[2].result())
    
    return final_config

if __name__ == "__main__":
    start_time = time.time()
    
    final_config = asyncio.run(aggregate_config())
    
    end_time = time.time()
    
    print("\n--- Final Configuration ---")
    print(final_config)
    print(f"\nTotal time: {end_time - start_time:.2f}s (Should be ~1.5s)")
    
    # Verification check for the overlapping key:
    # system_defaults set max_tokens to 4096
    # model_params set max_tokens to 2048 (last update wins)
    assert final_config['max_tokens'] == 2048

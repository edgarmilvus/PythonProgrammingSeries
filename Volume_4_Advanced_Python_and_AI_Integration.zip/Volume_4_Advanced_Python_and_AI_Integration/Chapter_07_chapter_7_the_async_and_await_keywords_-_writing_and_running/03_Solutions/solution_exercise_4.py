
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import asyncio
import time

async def llm_stream_response(text, delay):
    """
    An asynchronous generator simulating an LLM streaming tokens.
    Yields tokens with an asynchronous sleep delay between them.
    """
    words = text.split()
    for word in words:
        # Yielding control allows other tasks to run
        await asyncio.sleep(delay)
        yield word + " "

async def status_monitor():
    """An independent coroutine that periodically prints status updates."""
    for i in range(5): # Run for 1 second total (5 * 0.2s)
        await asyncio.sleep(0.2)
        print(f"[{time.strftime('%H:%M:%S')}] --- MONITOR: System check {i+1} complete.")

async def consume_stream(text_to_stream):
    """Consumes the asynchronous stream token by token."""
    print(f"\n[{time.strftime('%H:%M:%S')}] CONSUMER: Starting stream consumption...")
    final_message = ""
    
    # Use async for to iterate over the async generator
    async for token in llm_stream_response(text_to_stream, 0.1):
        final_message += token
        print(f"[{time.strftime('%H:%M:%S')}] CONSUMER: Received token: '{token.strip()}'")
        
    print(f"\n[{time.strftime('%H:%M:%S')}] CONSUMER: Final message reconstructed: {final_message.strip()}")

async def main_streaming_demo():
    """Runs the consumer and the monitor concurrently."""
    text = "The quick brown fox jumps over the lazy dog."
    
    # Run both the consumer and the monitor using asyncio.gather
    await asyncio.gather(
        consume_stream(text),
        status_monitor()
    )

if __name__ == "__main__":
    asyncio.run(main_streaming_demo())


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import os
from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

# Setup
try:
    # Use a low temperature for deterministic, constrained output
    llm = ChatOpenAI(temperature=0.0)
except Exception:
    # Mock LLM for consistency check simulation
    from langchain.llms.fake import FakeListLLM
    # Simulating successful, constrained output
    llm = FakeListLLM(responses=[
        "Secure Cipher",
        "Private Key",
        "Shadow Protocol",
        "Encrypted Vault",
        "Quantum Shield"
    ])

theme = "Cryptography"

# --- Initial (Failing) Prompt ---
initial_template = PromptTemplate(
    input_variables=["theme"],
    template="Suggest a project name based on the theme of {theme}."
)
initial_chain = LLMChain(llm=llm, prompt=initial_template)

print("--- Initial Prompt Test (Often Fails Constraints) ---")
# Example of what the initial prompt might produce (if using a real LLM):
# print(initial_chain.run(theme).strip()) 

# --- Final (Successful) Refined Prompt ---
# 3. Refinement: Iterative modification
refined_template = PromptTemplate(
    input_variables=["theme"],
    template=(
        "Generate a project name based on the theme of {theme}. "
        "STRICT CONSTRAINTS:\n"
        "1. LENGTH: The name MUST be exactly TWO words long.\n"
        "2. FORMAT: Use Title Case (e.g., 'Silent Gateway').\n"
        "3. PURITY: The output MUST contain ONLY the two words. NO quotes, NO introductory phrases, NO punctuation, NO explanations.\n"
        "Return the two words immediately."
    )
)
refined_chain = LLMChain(llm=llm, prompt=refined_template)

print("\n--- Refined Prompt Test (High Consistency) ---")

# Testing Loop (5 runs)
for i in range(1, 6):
    name = refined_chain.run(theme).strip()
    print(f"Run {i}: {name}")


# 4. Documentation
"""
Instructor's Analysis of Refinement:
The final refined prompt is significantly more effective than the initial prompt because it shifts the interaction from a conversational request ("Suggest...") to a strict, non-negotiable instruction set.

Linguistic Techniques Used for Enforcement:
1. Emphasis (ALL CAPS): Using words like MUST, ONLY, and NO signals to the LLM that these are hard boundaries, forcing it to prioritize the constraints over its default conversational behavior.
2. Negative Constraints: Explicitly forbidding unwanted elements ("NO quotes, NO introductory phrases") is crucial for achieving "purity." LLMs often try to be helpful; negative constraints stop this behavior.
3. Clarity and Specificity: Defining the exact desired format ("Title Case") and the exact length ("exactly TWO words") removes ambiguity.
4. Immediate Output Directive: The concluding sentence, "Return the two words immediately," acts as a final instruction to cut off any explanatory text or conversational wrapping, ensuring the output is pure data.
"""

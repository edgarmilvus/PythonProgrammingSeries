
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os
from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain_core.exceptions import OutputParserException # Used for robustness check

# 1. Script Setup (Using a standard LLM)
try:
    llm = ChatOpenAI(temperature=0.3)
except Exception:
    # Using a mock LLM for reliability
    from langchain.llms.fake import FakeListLLM
    llm = FakeListLLM(responses=[
        "Python Decorators are like wrapping paper for functions. They allow you to add extra functionality to an existing function without changing its core code. For a junior web developer, think of it as adding logging or authentication checks easily, making your code cleaner and more reusable. This is a practical way to manage cross-cutting concerns."
    ])


# 2. Multi-Variable Prompt Template
explainer_template = PromptTemplate(
    input_variables=["topic", "audience", "tone"],
    template=(
        "Explain the technical concept of '{topic}' to an audience of '{audience}'. "
        "The explanation should be approximately 150 words long and delivered in a '{tone}' tone. "
        "Ensure the explanation is highly relevant to the specified audience."
    )
)

# 3. Chain Execution: Instantiate the chain
explainer_chain = LLMChain(llm=llm, prompt=explainer_template)

# 4. Define input dictionary and run
input_data = {
    'topic': 'Python Decorators',
    'audience': 'a junior web developer',
    'tone': 'encouraging and practical'
}

print("--- Generating Tailored Explanation ---")
explanation = explainer_chain.run(input_data)
print(f"Topic: {input_data['topic']}, Audience: {input_data['audience']}, Tone: {input_data['tone']}")
print("-" * 40)
print(explanation.strip())

# 5. Robustness Check: Attempt to execute without a required variable
print("\n--- Robustness Check (Missing 'tone') ---")

missing_input = {
    'topic': 'Merkle Trees',
    'audience': 'a senior developer'
}

try:
    explainer_chain.run(missing_input)
except KeyError as e:
    print(f"Successfully caught expected error: Missing input variable {e}. ")
    print("The chain requires all variables defined in input_variables.")
except Exception as e:
    print(f"Caught unexpected error: {e}")

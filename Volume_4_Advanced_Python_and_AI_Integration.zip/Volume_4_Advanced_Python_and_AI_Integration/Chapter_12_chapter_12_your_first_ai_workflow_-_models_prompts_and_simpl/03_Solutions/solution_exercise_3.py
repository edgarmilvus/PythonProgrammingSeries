
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

#!/usr/bin/env python3
import sys
import os
from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

# 2. Argument Handling
if len(sys.argv) != 2:
    # sys.argv[0] is the script name; we expect one additional argument.
    print("Usage: python3 cli_ai_tool.py \"<query_text>\"")
    sys.exit(1)

# 3. Input Extraction
user_query = sys.argv[1]

# 4. Chain Implementation and Initialization
try:
    llm = ChatOpenAI(temperature=0.2)
except Exception:
    # Mock LLM for environments without API key
    from langchain.llms.fake import FakeListLLM
    llm = FakeListLLM(responses=["Sharding is like dividing a huge library into smaller, specialized rooms. Each room (shard) holds a part of the books (data), allowing librarians (servers) to find and manage information much faster because they only search a subset of the total collection."])

# Define a simple PromptTemplate
cli_template = PromptTemplate(
    input_variables=["query"],
    template="You are a helpful, concise assistant. Answer the following user request: {query}"
)

# Instantiate the LLMChain
cli_chain = LLMChain(llm=llm, prompt=cli_template)

# 5. Execution Mapping
print(f"--- Processing Query: {user_query} ---")

try:
    # Pass the extracted command-line argument to the chain
    response = cli_chain.run(query=user_query)
    print("\n[AI Response]")
    print(response.strip())

except Exception as e:
    print(f"An error occurred during chain execution: {e}")
    sys.exit(1)

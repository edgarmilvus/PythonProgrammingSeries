
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

# 1. Setup and Initialization (Using ChatOpenAI, assuming environment is configured)
# For instructional use, we set a low temperature for slightly more creative output.
try:
    llm = ChatOpenAI(temperature=0.7)
except Exception:
    # Fallback to a mock LLM if API key is not set
    from langchain.llms.fake import FakeListLLM
    llm = FakeListLLM(responses=["A deep-sea archaeologist named Dr. Elara Vance spends her days cataloging sunken ruins. Her primary conflict is the constant race against deep-sea mining operations that threaten to destroy ancient history. She dreams of finding the lost library of Atlantis before the corporations do."])


# 2. Prompt Structure: Define PromptTemplate with one input variable
persona_template = PromptTemplate(
    input_variables=["profession"],
    template=(
        "You are a speculative fiction writer known for short, evocative character bios. "
        "Generate a creative, three-sentence summary of a character's life and primary conflict "
        "whose profession is a {profession}. "
        "The output must only contain the biography text."
    )
)

# 3. Chain Creation: Instantiate LLMChain
persona_chain = LLMChain(llm=llm, prompt=persona_template)

# 4. Execution: Define input and run the chain
test_profession = "deep-sea archaeologist"

print(f"--- Generating persona for: {test_profession} ---")

# Using the run() method to get the raw string output
biography = persona_chain.run(test_profession)

# 5. Output Formatting: Print the result
print(biography.strip())

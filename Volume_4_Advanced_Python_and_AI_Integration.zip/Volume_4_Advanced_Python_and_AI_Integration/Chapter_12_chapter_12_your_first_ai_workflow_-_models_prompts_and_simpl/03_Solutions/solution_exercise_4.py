
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

# 1. Setup (Using a standard LLM, low temperature for structured output)
try:
    llm = ChatOpenAI(temperature=0.1)
except Exception:
    # Mock LLM response simulating the required structured output
    from langchain.llms.fake import FakeListLLM
    mock_response = """
from sqlalchemy import Column, Integer, String, DateTime, Float
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class FinancialTransaction(Base):
    __tablename__ = 'transactions'
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, nullable=False)
    amount = Column(Float, nullable=False)
    currency_code = Column(String(3), nullable=False)
    execution_timestamp = Column(DateTime, nullable=False)

---MOCK_DATA_START---

[
    {
        "user_id": 101,
        "amount": 45.99,
        "currency_code": "USD",
        "execution_timestamp": "2024-05-20T10:30:00Z"
    },
    {
        "user_id": 102,
        "amount": 1200.00,
        "currency_code": "EUR",
        "execution_timestamp": "2024-05-20T11:45:15Z"
    }
]
"""
    llm = FakeListLLM(responses=[mock_response])


# 2. Refactoring the Prompt Template for Structured Output
model_generator_template = PromptTemplate(
    input_variables=["entity_description"],
    template=(
        "You are an expert Python developer specializing in SQLAlchemy ORM. "
        "Your task is to generate two distinct outputs based on the following entity description: '{entity_description}'.\n\n"
        "PART 1: The complete, runnable Python class definition using SQLAlchemy syntax (including necessary imports).\n"
        "PART 2: A list of exactly three example instances (mock data) for this model, formatted as a JSON-compatible Python list of dictionaries.\n\n"
        "Constraints for PART 2:\n"
        "- Ensure timestamps are generated as strings in ISO 8601 format.\n"
        "- Do not include the 'id' field, as it is auto-generated.\n\n"
        "Separate PART 1 and PART 2 using the unique delimiter: ---MOCK_DATA_START---\n\n"
        "Start with PART 1 immediately."
    )
)

# Chain Initialization
model_chain = LLMChain(llm=llm, prompt=model_generator_template)

# 3. Chain Execution
entity_desc = "A financial transaction record that includes the amount, currency code, the user ID (integer), and the timestamp of execution."

print(f"--- Generating Model and Mock Data for: {entity_desc} ---")

# Execute the chain
structured_output = model_chain.run(entity_description=entity_desc)

# 4. Verification (Simple print for visual inspection)
print("\n" + "="*20 + " GENERATED STRUCTURED OUTPUT " + "="*20)
print(structured_output.strip())
print("="*67)

# Verification check
if "---MOCK_DATA_START---" in structured_output:
    print("\nVerification successful: Delimiter found. Output is structured.")
else:
    print("\nVerification failed: Delimiter missing.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import functools

def enforce_float_conversion(func):
    """
    Decorator to ensure the first positional argument is a float, 
    coercing from string if necessary, or raising TypeError.
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # Check if there is a first positional argument and if it is a string
        if args and isinstance(args[0], str):
            value_to_check = args[0]
            try:
                # Attempt coercion
                coerced_value = float(value_to_check)
                
                # Create a new tuple of arguments with the coerced value replacing the original
                new_args = (coerced_value,) + args[1:]
                
                print(f"[Validation] Coerced string '{value_to_check}' to float {coerced_value}.")
                
                # Call the original function with the modified arguments
                return func(*new_args, **kwargs)
                
            except ValueError:
                # If float conversion fails, raise a descriptive TypeError
                raise TypeError(
                    f"Input validation failed for argument 1: Cannot convert '{value_to_check}' "
                    f"to a numerical type for function '{func.__name__}'."
                )
        
        # If the first argument is already a number or not present, pass all arguments through
        return func(*args, **kwargs)
    return wrapper

# --- Test Cases ---

@enforce_float_conversion
def calculate_area(length, width, unit="m"):
    """Calculates area given length and width."""
    return f"Area: {length * width} {unit}^2 (Input Length Type: {type(length).__name__})"

# Test 1: Successful string coercion
print("Test 1 (Coercion):", calculate_area("5.5", 10))

# Test 2: Input already correct (no coercion needed)
print("Test 2 (No Coercion):", calculate_area(5.0, 10))

# Test 3: Failure case
try:
    calculate_area("invalid_input", 10)
except TypeError as e:
    print(f"\nTest 3 (Failure Caught): {e}")

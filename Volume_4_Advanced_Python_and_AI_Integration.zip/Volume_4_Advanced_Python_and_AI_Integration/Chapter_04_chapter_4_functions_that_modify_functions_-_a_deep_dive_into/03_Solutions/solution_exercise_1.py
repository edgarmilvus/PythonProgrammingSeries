
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import time
import functools

def timer_decorator(func):
    """
    Measures the execution time of the wrapped function.
    """
    @functools.wraps(func) # Best practice to include wraps
    def wrapper(*args, **kwargs):
        start_time = time.time()
        
        # Execute the original function with all captured arguments
        result = func(*args, **kwargs)
        
        end_time = time.time()
        duration = end_time - start_time
        
        print(f"Function '{func.__name__}' executed in {duration:.4f} seconds.")
        
        # Preserve the original return value
        return result
    return wrapper

# --- Test Cases ---

@timer_decorator
def calculate_complex_data(iterations):
    """Simulates a task taking time."""
    total = 0
    for i in range(iterations):
        total += i**0.5
    return total

@timer_decorator
def process_user_data(user_id, database_conn, cache_hit=False):
    """Simulates a function with mixed arguments."""
    time.sleep(0.05) # Simulate work
    return f"Processed user {user_id} via {database_conn}. Cache hit: {cache_hit}"

# Run tests
print("Running Test 1 (Positional args):")
result1 = calculate_complex_data(1000000)
print(f"Result 1: {result1:.2f}\n")

print("Running Test 2 (Mixed args):")
result2 = process_user_data(101, "SQL_DB_A", cache_hit=True)
print(f"Result 2: {result2}")

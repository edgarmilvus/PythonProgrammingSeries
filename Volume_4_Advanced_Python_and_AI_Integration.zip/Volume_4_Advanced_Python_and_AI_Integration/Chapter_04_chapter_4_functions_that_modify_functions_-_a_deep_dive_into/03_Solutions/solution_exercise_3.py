
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import time
import functools

def retry_on_failure(max_attempts, delay_seconds):
    """
    Layer 1: Accepts configuration arguments.
    """
    def decorator(func):
        """
        Layer 2: Accepts the function to be decorated.
        """
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            """
            Layer 3: The actual wrapper closure, executing the retry logic.
            Accesses max_attempts and delay_seconds from Layer 1 scope.
            """
            last_exception = None
            
            for attempt in range(1, max_attempts + 1):
                try:
                    # Attempt to execute the function
                    return func(*args, **kwargs)
                
                except ValueError as e:
                    last_exception = e
                    print(f"Attempt {attempt}/{max_attempts} failed: {e.__class__.__name__}. Retrying in {delay_seconds}s...")
                    
                    if attempt < max_attempts:
                        time.sleep(delay_seconds)
                    
            # If loop finishes without successful return, raise the last exception
            raise last_exception
            
        return wrapper
    return decorator

# --- Test Case ---

ATTEMPTS_MADE = 0

@retry_on_failure(max_attempts=3, delay_seconds=0.5)
def unreliable_data_fetcher(data_id):
    """Simulates a function that fails the first two times."""
    global ATTEMPTS_MADE
    ATTEMPTS_MADE += 1
    
    if ATTEMPTS_MADE <= 2:
        print(f"[Internal] Attempt {ATTEMPTS_MADE}: Failing intentionally.")
        raise ValueError(f"Connection lost for ID {data_id}")
    
    print(f"[Internal] Attempt {ATTEMPTS_MADE}: Success!")
    return f"Data for ID {data_id} retrieved successfully."

# Execute the failing function
try:
    result = unreliable_data_fetcher(42)
    print(f"\nFinal Result: {result}")
except ValueError as e:
    print(f"\nFATAL ERROR: Max retries exceeded. {e}")

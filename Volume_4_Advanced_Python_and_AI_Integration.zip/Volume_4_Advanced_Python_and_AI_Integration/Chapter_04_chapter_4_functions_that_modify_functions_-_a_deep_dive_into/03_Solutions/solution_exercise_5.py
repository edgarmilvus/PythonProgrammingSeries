
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import functools

def context_limit_checker(max_tokens):
    """
    Layer 1: Configures the maximum token limit for the LLM context window.
    """
    if not isinstance(max_tokens, int) or max_tokens <= 0:
        raise ValueError("max_tokens must be a positive integer.")
        
    def decorator(func):
        """
        Layer 2: Receives the function to be wrapped.
        """
        @functools.wraps(func)
        def wrapper(new_message_tokens, *args, **kwargs):
            """
            Layer 3: Performs the context check using the configured max_tokens.
            """
            warning_threshold = max_tokens * 0.10
            
            if new_message_tokens > warning_threshold:
                print(f"[CONTEXT WARNING]: Input size ({new_message_tokens} tokens) exceeds 10% "
                      f"of max context ({max_tokens} tokens). Context compression recommended.")
            
            # Always execute the wrapped function, regardless of the warning
            return func(new_message_tokens, *args, **kwargs)
            
        return wrapper
    return decorator

# --- Test Cases ---

@context_limit_checker(max_tokens=4096)
def process_message(new_message_tokens, user_id=None):
    """Core LLM processing logic."""
    print(f"Processing message of size {new_message_tokens} tokens for user {user_id}.")
    return "LLM response completed."

# Test 1: Input size below warning threshold (e.g., 5% of 4096 = 204.8)
print("Test 1 (Small Input):")
result1 = process_message(150, user_id=99)
print(f"Result: {result1}\n")

# Test 2: Input size above warning threshold (e.g., 15% of 4096 = 614.4)
print("Test 2 (Large Input):")
result2 = process_message(700, user_id=100)
print(f"Result: {result2}")

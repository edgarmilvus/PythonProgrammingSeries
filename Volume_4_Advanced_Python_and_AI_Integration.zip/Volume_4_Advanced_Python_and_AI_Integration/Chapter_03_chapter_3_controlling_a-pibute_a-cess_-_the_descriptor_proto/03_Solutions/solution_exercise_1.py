
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

class PositiveInteger:
    """
    A data descriptor that enforces integer type and positive value constraints.
    Storage is managed by storing the value in the owner instance's __dict__.
    """
    def __set_name__(self, owner, name):
        # Capture the attribute name for storage and error reporting
        self.public_name = name
        self.private_name = '_' + name

    def __get__(self, instance, owner):
        if instance is None:
            return self
        # Retrieve the value from the instance's dictionary
        return instance.__dict__.get(self.private_name)

    def __set__(self, instance, value):
        # 1. Type Checking
        if not isinstance(value, int):
            raise TypeError(f"'{self.public_name}' must be an integer, got {type(value).__name__}")
        
        # 2. Value Checking (must be > 0)
        if value <= 0:
            raise ValueError(f"'{self.public_name}' must be strictly positive (> 0), got {value}")
        
        # 3. Store the valid value
        instance.__dict__[self.private_name] = value

class FinancialModel:
    transaction_id = PositiveInteger()
    amount = PositiveInteger()

# --- Demonstration ---
model = FinancialModel()
model.transaction_id = 4001
model.amount = 150000

print(f"ID: {model.transaction_id}, Amount: {model.amount}")

try:
    model.amount = -50  # Fails value check
except ValueError as e:
    print(f"\nError caught: {e}")

try:
    model.transaction_id = "A123"  # Fails type check
except TypeError as e:
    print(f"Error caught: {e}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

class ModeRestrictedAttribute:
    """
    A Data Descriptor that restricts setting based on the owner's internal state (_file_mode).
    """
    def __set_name__(self, owner, name):
        self.public_name = name
        self.private_name = '_' + name

    def __get__(self, instance, owner):
        if instance is None:
            return self
        # Standard retrieval
        return instance.__dict__.get(self.private_name)

    def __set__(self, instance, value):
        # Retrieve the controlling mode attribute from the owner instance
        current_mode = getattr(instance, '_file_mode', 'r') 
        
        # Enforce restriction based on mode
        if current_mode == 'r':
            raise PermissionError(
                f"Cannot set '{self.public_name}'. Configuration is currently in read-only ('r') mode."
            )
        
        # Allow setting for 'w' (write) or 'a' (append)
        print(f"Configuration set successfully in '{current_mode}' mode.")
        instance.__dict__[self.private_name] = value

class FileHandlerConfig:
    output_buffer = ModeRestrictedAttribute()

    def __init__(self, mode):
        # This is the controlling attribute the descriptor inspects
        self._file_mode = mode 
        # Initialize the descriptor attribute (allowed if mode is not 'r')
        self.output_buffer = 1024 
        print(f"Handler initialized in mode: {self._file_mode}")

# --- Demonstration ---
# 1. Write Mode (allowed)
writer = FileHandlerConfig('w')
writer.output_buffer = 4096 
print(f"Writer buffer size: {writer.output_buffer}")

# 2. Read Mode (restricted)
reader = FileHandlerConfig('r')
print(f"Reader buffer size: {reader.output_buffer}")

try:
    reader.output_buffer = 8192 # Attempt to set in 'r' mode
except PermissionError as e:
    print(f"\nError caught: {e}")

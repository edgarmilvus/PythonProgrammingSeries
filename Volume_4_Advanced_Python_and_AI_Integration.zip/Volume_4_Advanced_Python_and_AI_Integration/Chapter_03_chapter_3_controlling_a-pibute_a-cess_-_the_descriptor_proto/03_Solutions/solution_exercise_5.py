
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

class FinalizedConfig:
    """
    A Data Descriptor that enforces immutability based on an external flag 
    on the owner instance.
    """
    def __set_name__(self, owner, name):
        self.public_name = name
        self.private_name = '_' + name

    def __get__(self, instance, owner):
        if instance is None:
            return self
        # Standard retrieval
        return instance.__dict__.get(self.private_name)

    def __set__(self, instance, value):
        # Inspect the state of the owner instance
        if getattr(instance, '_is_finalized', False):
            raise RuntimeError(
                f"Configuration attribute '{self.public_name}' is locked. Deployment settings are finalized."
            )
        
        # Perform assignment if not finalized
        print(f"Setting {self.public_name} to {value} (Mutable state)")
        instance.__dict__[self.private_name] = value

class DeploymentSettings:
    # The descriptor managed attribute
    max_connections = FinalizedConfig()
    timeout_seconds = FinalizedConfig()

    def __init__(self, initial_connections, initial_timeout):
        self._is_finalized = False # Initial state: mutable
        self.max_connections = initial_connections
        self.timeout_seconds = initial_timeout

    def finalize_settings(self):
        print("\n--- Settings Locked ---")
        self._is_finalized = True

# --- Demonstration ---
settings = DeploymentSettings(initial_connections=50, initial_timeout=10)

# 1. Initial modifications (allowed)
settings.max_connections = 100

# 2. Lock the configuration
settings.finalize_settings()

# 3. Attempt modification after locking
try:
    settings.max_connections = 200 # Fails
except RuntimeError as e:
    print(f"Error caught: {e}")

try:
    settings.timeout_seconds = 5 # Fails
except RuntimeError as e:
    print(f"Error caught: {e}")

print(f"\nFinal connections: {settings.max_connections}")

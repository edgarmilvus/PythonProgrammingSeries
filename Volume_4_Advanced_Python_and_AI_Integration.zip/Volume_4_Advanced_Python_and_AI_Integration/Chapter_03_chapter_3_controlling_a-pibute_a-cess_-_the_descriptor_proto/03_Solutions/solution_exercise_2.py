
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

def initialize_expensive_db_connection():
    """Mock factory function simulating expensive resource setup."""
    import time
    time.sleep(0.01) 
    print("Database connection established.")
    return object() # Returns a mock connection object

class LazyResource:
    """
    A Non-Data Descriptor for lazy loading.
    It relies on implementing only __get__ to allow instance.__dict__ to take precedence 
    after the first access.
    """
    def __init__(self, factory):
        self.factory = factory
        self.name = None 

    def __set_name__(self, owner, name):
        self.name = name

    def __get__(self, instance, owner):
        if instance is None:
            return self
        
        # Execute the factory function to compute the resource
        print(f"--- LAZY LOADING '{self.name}' ---")
        resource = self.factory()
        
        # CRITICAL STEP: Store the calculated value directly in the instance's dictionary.
        # Because this descriptor is Non-Data (no __set__), the instance dictionary entry 
        # now takes precedence over the descriptor for all future lookups on this instance.
        instance.__dict__[self.name] = resource
        
        return resource

class ServerConfig:
    db_connection = LazyResource(initialize_expensive_db_connection)

# --- Demonstration ---
config = ServerConfig()

# 1. First access (triggers initialization)
print("Access 1:")
conn1 = config.db_connection 

# 2. Second access (retrieves cached value instantly, no print/delay)
print("\nAccess 2:")
conn2 = config.db_connection 

# Verify that the same object was returned and the factory wasn't run again
print(f"\nAre connections the same object? {conn1 is conn2}")
print(f"Is db_connection now stored in instance __dict__? {'db_connection' in config.__dict__}")

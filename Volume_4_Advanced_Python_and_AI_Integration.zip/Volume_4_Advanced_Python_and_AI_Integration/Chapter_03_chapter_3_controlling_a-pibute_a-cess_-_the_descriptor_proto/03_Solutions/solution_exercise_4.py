
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

class StreamNotInitializedError(Exception):
    """Raised when an attempt is made to access a stream before it has been initialized."""
    pass

class StreamGuard:
    """
    A Data Descriptor that manages the lifecycle of a stream generator object, 
    preventing access before initialization and blocking deletion afterward.
    """
    def __set_name__(self, owner, name):
        self.public_name = name
        self.private_name = '_' + name

    def __get__(self, instance, owner):
        if instance is None:
            return self
        
        value = instance.__dict__.get(self.private_name)
        
        # Initialization Check: Raise custom error if the stream is None (uninitialized)
        if value is None:
            raise StreamNotInitializedError(
                f"The streaming attribute '{self.public_name}' has not been initialized. Call start_stream() first."
            )
        return value

    def __set__(self, instance, value):
        # Standard storage
        instance.__dict__[self.private_name] = value

    def __delete__(self, instance):
        # Deletion Restriction: Check if a value (stream) is present
        if self.private_name in instance.__dict__ and instance.__dict__[self.private_name] is not None:
            raise AttributeError(
                f"Cannot delete '{self.public_name}'. The active streaming resource is protected."
            )
        # If the value was None or not yet set, allow deletion of the internal key
        if self.private_name in instance.__dict__:
             del instance.__dict__[self.private_name]

class LLMRequestManager:
    stream_output = StreamGuard()

    def __init__(self):
        # Initialize internal storage via the descriptor __set__ (sets it to None)
        self.stream_output = None 

    def start_stream(self, generator_mock):
        print("Stream started.")
        self.stream_output = generator_mock 

def mock_generator():
    yield "token1"
    yield "token2"

# --- Demonstration ---
manager = LLMRequestManager()

# 1. Attempt access before initialization
try:
    _ = manager.stream_output
except StreamNotInitializedError as e:
    print(f"Error caught: {e}")

# 2. Start stream
manager.start_stream(mock_generator())

# 3. Successful access
stream = manager.stream_output
print(f"Stream content: {list(stream)}")

# 4. Attempt deletion after initialization
try:
    del manager.stream_output
except AttributeError as e:
    print(f"\nError caught: {e}")

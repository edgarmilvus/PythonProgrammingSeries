
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import cProfile
import pstats
import io
import time

# --- Initial Code Setup (validator.py content) ---
def generate_nested_data(depth, width):
    """Generates a deeply nested dictionary structure."""
    if depth == 0:
        return {"value": time.time()}
    
    children = {}
    for i in range(width):
        children[f"key_{i}"] = generate_nested_data(depth - 1, width)
    
    return {"level": depth, "children": children}

def deep_validator(data):
    """
    Simulates complex, recursive validation logic.
    The actual 'work' is trivial but the function call overhead is high.
    """
    if isinstance(data, dict):
        if "children" in data:
            for key, child in data["children"].items():
                # Simulate a calculation or check
                _ = 1 + 1 
                deep_validator(child)
        
        if "value" in data:
            # Simulate a final validation step
            return data["value"] * 2
            
    return None

# Parameters for the test: high depth, moderate width (4^8 = 65,536 nodes)
TEST_DATA = generate_nested_data(depth=8, width=4)

# --- Profiling Execution (profile_runner.py content) ---

# 1. Create a profile object
pr = cProfile.Profile()

# 2. Run the function under the profiler
pr.enable()
deep_validator(TEST_DATA)
pr.disable()

# 3. Save the results to a file (validation_profile.stats)
pr.dump_stats("validation_profile.stats")

# 4. Interactive Analysis (using pstats in script for automated identification)
s = io.StringIO()
ps = pstats.Stats('validation_profile.stats', stream=s).sort_stats('cumulative')

# Print top 5 functions by cumulative time
print("--- Top 5 by Cumulative Time (cumtime) ---")
ps.print_stats(5)

# Print top 5 functions by total time (tottime)
print("\n--- Top 5 by Total Time (tottime) ---")
ps.sort_stats('tottime').print_stats(5)

# ----------------------------------------------------------------------
# 4. Optimization Recommendation (Based on Analysis)
# ----------------------------------------------------------------------
# Analysis:
# 1. The profiling output shows that `deep_validator` has the highest cumulative time (cumtime).
# 2. Crucially, the total time (tottime) spent *inside* `deep_validator` (excluding time spent in sub-calls) is very low, often near zero.
# 3. The 'ncalls' column shows an extremely high number of calls (e.g., 65,536 calls), while the time per call (percall) is minuscule.
# 4. Conclusion: The bottleneck is not the computational work (which is trivial: `_ = 1 + 1`), but the massive overhead associated with Python function call setup and teardown due to deep recursion.

# Recommendation:
# The primary source of performance cost is the overhead of function calls (ncalls).
# The concrete recommendation for optimization is to replace the recursive traversal 
# with an explicit iterative approach using a stack or queue (e.g., Depth-First Search 
# or Breadth-First Search implemented iteratively). This eliminates the expensive 
# Python function call overhead, converting it into cheaper loop iterations.


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import timeit
from functools import lru_cache

# --- Version A: Manual Dictionary Memoization ---
def ackermann_manual(m, n, memo=None):
    """Ackermann function using a manual dictionary for memoization."""
    if memo is None:
        memo = {}
    
    if (m, n) in memo:
        return memo[(m, n)]
    
    if m == 0:
        result = n + 1
    elif n == 0:
        result = ackermann_manual(m - 1, 1, memo)
    else:
        inner = ackermann_manual(m, n - 1, memo)
        result = ackermann_manual(m - 1, inner, memo)
        
    memo[(m, n)] = result
    return result

# --- Version B: LRU Cache Decorator ---
@lru_cache(maxsize=None) # Unlimited cache size for this test
def ackermann_lru(m, n):
    """Ackermann function using functools.lru_cache."""
    if m == 0:
        return n + 1
    if n == 0:
        return ackermann_lru(m - 1, 1)
    
    return ackermann_lru(m - 1, ackermann_lru(m, n - 1))

# --- Performance Measurement ---

TEST_M_LARGE, TEST_N_LARGE = 3, 8
TEST_M_SMALL, TEST_N_SMALL = 2, 5
N_RUNS = 100 # Repeat the main computation 100 times

# Clear cache before large test
ackermann_lru.cache_clear()

# 1. Large Input Test (A(3, 8))
# Note: We wrap the function call in a lambda to ensure timeit measures the execution time
# of the function itself, not the setup/teardown of the timeit environment.

# Manual Timing
t_manual_large = timeit.timeit(
    lambda: ackermann_manual(TEST_M_LARGE, TEST_N_LARGE), 
    number=N_RUNS
)

# LRU Timing
t_lru_large = timeit.timeit(
    lambda: ackermann_lru(TEST_M_LARGE, TEST_N_LARGE), 
    number=N_RUNS
)

print(f"--- Performance Comparison (A({TEST_M_LARGE}, {TEST_N_LARGE}), {N_RUNS} runs) ---")
print(f"Manual Dict Time: {t_manual_large:.6f} seconds")
print(f"LRU Cache Time:   {t_lru_large:.6f} seconds")
print(f"Speedup Factor (Manual/LRU): {t_manual_large / t_lru_large:.2f}x")

# 2. Small Input Test (A(2, 5)) - Testing overhead dominance
ackermann_lru.cache_clear()

t_manual_small = timeit.timeit(
    lambda: ackermann_manual(TEST_M_SMALL, TEST_N_SMALL), 
    number=N_RUNS
)

t_lru_small = timeit.timeit(
    lambda: ackermann_lru(TEST_M_SMALL, TEST_N_SMALL), 
    number=N_RUNS
)

print(f"\n--- Performance Comparison (A({TEST_M_SMALL}, {TEST_N_SMALL}), {N_RUNS} runs) ---")
print(f"Manual Dict Time: {t_manual_small:.6f} seconds")
print(f"LRU Cache Time:   {t_lru_small:.6f} seconds")

# Analysis (In Comments):
# 1. For both large and small inputs, the LRU Cache version is typically faster.
# 2. The difference is due to `functools.lru_cache` being highly optimized and implemented 
#    in C, meaning the overhead of managing the cache (hashing arguments, dictionary lookup, 
#    and cache eviction logic) is significantly lower than the equivalent operations 
#    performed in pure Python for the manual dictionary version.
# 3. For the small input (A(2, 5)), where the total computation time is very low, the 
#    relative cost of the memoization overhead (the cache management itself) becomes 
#    a larger percentage of the total execution time, but LRU's C implementation still 
#    maintains a performance edge.

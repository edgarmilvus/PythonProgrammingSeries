
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import time
from functools import lru_cache

# Global configuration variable simulating an external rate that changes
CURRENT_VOLATILITY_FACTOR = 0.5 

def complex_calculation(risk_factor, iterations):
    """Simulates the computationally heavy core of the model."""
    global CURRENT_VOLATILITY_FACTOR
    if iterations <= 1:
        return risk_factor * CURRENT_VOLATILITY_FACTOR
    
    # Simulate heavy calculation load
    time.sleep(0.00001) 
    
    # Recursive step
    return complex_calculation(risk_factor * 0.99, iterations - 1) + (risk_factor * 0.01)

# 1. Implement LRU Cache and 3. Address Cache Invalidation
@lru_cache(maxsize=128)
def calculate_derivative_value(base_asset_price, risk_factor_id, iterations, volatility_factor_state):
    """
    The main function optimized with LRU cache.
    The 'volatility_factor_state' argument forces cache invalidation when the global factor changes.
    """
    # Use the passed state variable internally, ensuring the cache key is sensitive to it.
    print(f"Calculating value for ID {risk_factor_id} (Vol Factor: {volatility_factor_state})...")
    
    # Step 1: Calculate the core value
    core_value = complex_calculation(base_asset_price, iterations)
    
    # Step 2: Apply adjustment based on the passed factor state
    final_value = core_value * (1 + volatility_factor_state)
    
    return final_value

# --- Test Execution ---
TEST_PARAMS = (100.0, 12345, 100)

start_time = time.time()
print("\n--- Initial Run Block (Factor 0.5) ---")
for i in range(10):
    # Pass the global factor explicitly to ensure it becomes part of the cache key
    result = calculate_derivative_value(*TEST_PARAMS, CURRENT_VOLATILITY_FACTOR)

end_time = time.time()
print(f"Total time for 10 calls (Initial Cache): {end_time - start_time:.4f}s")
print(f"Final Result (0.5): {result:.4f}")

# 4. Forced Invalidation: Change the global factor
CURRENT_VOLATILITY_FACTOR = 0.8
print(f"\n*** Global Volatility Factor CHANGED to {CURRENT_VOLATILITY_FACTOR} ***")

# 5. Verification: Call with the same parameters, but the new factor state
start_time_2 = time.time()
print("\n--- Verification Run Block (Factor 0.8) ---")
# The cache key now includes 0.8 instead of 0.5, forcing a recalculation (cache miss)
new_result = calculate_derivative_value(*TEST_PARAMS, CURRENT_VOLATILITY_FACTOR)
end_time_2 = time.time()

print(f"Total time for 1 call (Forced Recalculation): {end_time_2 - start_time_2:.4f}s")
print(f"New Result (0.8): {new_result:.4f}")

# Subsequent calls should hit the new cache entry (0.8)
print("\n--- Subsequent Hit (Factor 0.8) ---")
calculate_derivative_value(*TEST_PARAMS, CURRENT_VOLATILITY_FACTOR)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import time
import hashlib
import json
from functools import lru_cache

# Simulates a large, external configuration matrix
RISK_ADJUSTMENT_MATRIX = {
    "tier_1": 1.05,
    "tier_2": 1.15,
    "version": "v1.0"
}

def get_matrix_hash():
    """Generates a unique identifier for the current configuration state."""
    # Ensure keys are sorted for consistent hashing
    serialized = json.dumps(RISK_ADJUSTMENT_MATRIX, sort_keys=True)
    return hashlib.sha256(serialized.encode('utf-8')).hexdigest()

# 1. & 2. Cache Modification and LRU Application
@lru_cache(maxsize=1000)
def calculate_risk_score(user_id, base_score, matrix_hash):
    """
    Calculates the risk score. The matrix_hash is added to the signature 
    to ensure cache key sensitivity to configuration changes.
    """
    print(f"Executing heavy calculation for User ID {user_id} (Hash: {matrix_hash[:6]})...")
    time.sleep(0.01) # Simulate delay
    
    # The function logic still relies on the *global* matrix, but the cache key relies on the *hash*.
    if user_id % 10 == 0:
        adjustment = RISK_ADJUSTMENT_MATRIX['tier_2']
    else:
        adjustment = RISK_ADJUSTMENT_MATRIX['tier_1']
        
    return base_score * adjustment

# --- Test Execution ---
USER_ID = 42
BASE_SCORE = 100.0

# 3. Initial Run and Cache Hit
print("--- Initial Run (Version v1.0) ---")
initial_hash = get_matrix_hash()
initial_result = calculate_risk_score(USER_ID, BASE_SCORE, initial_hash)
print(f"Result 1 (v1.0): {initial_result:.2f}")

# Second call with same parameters and hash (should be a cache hit)
cached_result = calculate_risk_score(USER_ID, BASE_SCORE, initial_hash)
print(f"Result 2 (Cached Hit): {cached_result:.2f}")

# 4. Forced Invalidation: Update the global matrix
print("\n*** Updating Configuration Matrix (v1.0 -> v2.0) ***")
RISK_ADJUSTMENT_MATRIX['tier_1'] = 1.25 # Significant change
RISK_ADJUSTMENT_MATRIX['version'] = "v2.0"

# Generate the new hash
new_hash = get_matrix_hash()
print(f"Old Hash: {initial_hash[:6]}, New Hash: {new_hash[:6]}")

# 5. Verification: Call with the same user_id but the new hash
print("\n--- Recalculation Run (Version v2.0) ---")
# The new_hash is different, forcing a cache miss and recalculation
new_result = calculate_risk_score(USER_ID, BASE_SCORE, new_hash)
print(f"Result 3 (Recalculated v2.0): {new_result:.2f}")

# Verification of Invalidation:
assert initial_result != new_result, "The result should have changed due to matrix update."
print("\nVerification successful: Cache invalidated and new result calculated.")

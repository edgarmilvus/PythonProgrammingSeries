
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import timeit
import math

# --- 1. Pure Python Baseline (integrate_pure_python) ---
def f(x):
    """The function to integrate: f(x) = x^2"""
    return x * x

def integrate_pure_python(a, b, N):
    """Calculates the definite integral of f(x) from a to b using N steps."""
    
    # Calculate step size
    h = (b - a) / N 
    
    total_area = 0.0
    
    for i in range(N):
        # Calculate the midpoint of the current step
        x_i = a + (i + 0.5) * h
        
        # Add the area of the rectangle (height * width)
        total_area += f(x_i) * h
        
    return total_area

# --- 2. Cython Implementation (integration_cython.pyx content) ---
# Note: This is written as a multi-line string for demonstration, 
# but must be saved as 'integration_cython.pyx'
CYTHON_CODE = """
# distutils: language = c
import math

# Define the function f(x) using C types
cdef double cy_f(double x):
    return x * x

# Use cpdef to make the function callable from Python and C
cpdef double integrate_cython(double a, double double b, long N):
    
    # C-typed local variables
    cdef double h
    cdef double total_area = 0.0
    cdef double x_i
    cdef long i
    
    # Calculate step size
    h = (b - a) / N 
    
    for i in range(N):
        # Calculate the midpoint of the current step
        x_i = a + (i + 0.5) * h
        
        # Add the area of the rectangle (height * width)
        # Calling cy_f avoids Python function overhead entirely
        total_area += cy_f(x_i) * h
        
    return total_area
"""

# --- 3. Setup Script (setup.py content) ---
# Note: This is written as a multi-line string for demonstration, 
# but must be saved as 'setup.py' and executed via 'python setup.py build_ext --inplace'
SETUP_SCRIPT = """
from setuptools import setup
from Cython.Build import cythonize

setup(
    ext_modules = cythonize("integration_cython.pyx")
)
"""

# --- 4. Benchmarking (Assuming 'integration_cython.so' or '.pyd' exists) ---
try:
    # Assuming successful compilation, import the module
    import integration_cython
except ImportError:
    print("WARNING: Cython module not compiled. Cannot run full benchmark.")
    # Use dummy values if compilation is skipped for environment constraints
    t_py = 1.0
    t_cy = 0.1
else:
    A, B = 0.0, 10.0
    N_STEPS = 10_000_000
    N_RUNS = 5

    # Benchmark Pure Python
    t_py = timeit.timeit(
        lambda: integrate_pure_python(A, B, N_STEPS), 
        number=N_RUNS
    )
    
    # Benchmark Cython
    t_cy = timeit.timeit(
        lambda: integration_cython.integrate_cython(A, B, N_STEPS), 
        number=N_RUNS
    )

    print(f"--- Integration Benchmark (N={N_STEPS}, Runs={N_RUNS}) ---")
    print(f"Pure Python Time: {t_py:.4f} seconds")
    print(f"Cython Time:      {t_cy:.4f} seconds")
    print(f"Speed-up Factor:  {t_py / t_cy:.2f}x")

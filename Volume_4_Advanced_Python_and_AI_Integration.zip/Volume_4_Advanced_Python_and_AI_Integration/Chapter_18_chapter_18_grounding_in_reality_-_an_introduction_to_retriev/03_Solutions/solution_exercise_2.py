
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Setup: Necessary imports
from langchain_community.vectorstores import Chroma
from langchain_core.documents import Document
from langchain_community.embeddings import HuggingFaceEmbeddings
import os
import shutil

# Define the embedding model (reusing the configuration from Ex 1)
embeddings = HuggingFaceEmbeddings(model_name='all-MiniLM-L6-v2')

# Raw document content
doc_content = [
    "A decorator is a function that takes another function and extends or modifies the behavior of the latter function without explicitly modifying it.",
    "Asynchronous programming in Python relies on the 'await' keyword to pause execution until a result is available, yielding control back to the event loop.",
    "Generators are functions that return an iterator, producing values one at a time using the 'yield' keyword, conserving memory."
]

# Define the persistence path for Chroma DB.
PERSIST_DIR = "./chroma_db"

# Cleanup previous run for a clean start
if os.path.exists(PERSIST_DIR):
    shutil.rmtree(PERSIST_DIR)
    print(f"Cleaned up directory: {PERSIST_DIR}")

# 1. Create a list of LangChain Document objects from doc_content, adding metadata.
documents = [
    Document(page_content=content, metadata={'source': f'doc_{i+1}'})
    for i, content in enumerate(doc_content)
]

# 3. Use Chroma.from_documents to initialize the store, passing the documents and the embedding model.
# This step embeds the documents and stores them in the specified directory.
vectorstore = Chroma.from_documents(
    documents=documents,
    embedding=embeddings,
    persist_directory=PERSIST_DIR
)

# 4. Verify the index count by accessing the underlying Chroma client and collection.
# We must explicitly call persist() before accessing the underlying client for safety, though Chroma often handles this.
vectorstore.persist() 

client = vectorstore._client
collection = client.get_collection(name="langchain") # Chroma's default collection name
indexed_count = collection.count()

print(f"Vector Store initialized and persisted in: {PERSIST_DIR}")
print(f"Total documents indexed: {indexed_count}")

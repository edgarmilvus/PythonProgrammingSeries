
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Setup: Necessary imports
import asyncio
from langchain_core.runnables import RunnablePassthrough
from langchain_core.prompts import ChatPromptTemplate
from langchain_groq import ChatGroq 
from langchain_core.output_parsers import StrOutputParser

# --- Setup Dependencies (Reusing components from Ex 3) ---
# Assuming 'retriever' is defined and loaded from Ex 3.
# If running standalone, ensure retriever setup from Ex 3 is executed first.

# Mock LLM setup (Replace with actual API key setup if needed)
# Using a fast, streaming model like Groq (requires GROQ_API_KEY env var)
try:
    llm = ChatGroq(model="llama3-8b-8192", temperature=0)
except Exception:
    # Placeholder for environments without API key setup
    print("[NOTE: Using a mock LLM for streaming demonstration if Groq API key is missing.]")
    from langchain_core.language_models import BaseChatModel
    class MockStreamingLLM(BaseChatModel):
        async def astream(self, messages, **kwargs):
            response = "Based on the context, asynchronous programming in Python relies on 'await' to yield control to the event loop."
            for word in response.split():
                yield word + " "
                await asyncio.sleep(0.01)
        def _generate(self, messages, stop=None, run_manager=None, **kwargs): pass
        @property
        def _llm_type(self): return "mock-streaming"
    llm = MockStreamingLLM()


# Define the RAG prompt template
RAG_PROMPT = """
You are an expert Python assistant. Use the following context to answer the question accurately.
Context: {context}
Question: {question}
"""
prompt = ChatPromptTemplate.from_template(RAG_PROMPT)

# Define the RAG Chain using LCEL
rag_chain = (
    {"context": retriever, "question": RunnablePassthrough()}
    | prompt
    | llm
    | StrOutputParser()
)

# --- YOUR CODE STARTING HERE ---

# 1. Define the asynchronous function `run_async_rag(query)`.
async def run_async_rag(query):
    print(f"--- Running Asynchronous Stream for Query: '{query}' ---")
    print("Response Stream:")
    
    # 2. Use `rag_chain.astream(query)` to get the asynchronous generator.
    stream = rag_chain.astream(query)
    
    # 3. Iterate through the generator using `async for` and print the content of each chunk.
    async for chunk in stream:
        print(chunk, end="", flush=True)
    
    print("\n--- Stream Complete ---")

# 4. Execute the asynchronous function using `asyncio.run()`.
query_async = "Explain how Python manages concurrent tasks using an event loop."
try:
    asyncio.run(run_async_rag(query_async))
except NameError:
    print("\n[Error]: The 'retriever' object from Exercise 3 must be defined.")
except RuntimeError as e:
    # Handle environment where event loop is already running (e.g., Jupyter notebooks)
    if "cannot run" in str(e):
        print("\n[Note]: Running in an active event loop environment. Please use 'await run_async_rag(query_async)' if in a notebook.")
    else:
        raise e

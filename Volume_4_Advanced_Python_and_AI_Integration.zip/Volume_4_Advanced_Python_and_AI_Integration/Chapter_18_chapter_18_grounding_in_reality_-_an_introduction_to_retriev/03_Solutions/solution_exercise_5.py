
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# Setup: Necessary imports
from langchain_core.runnables import RunnablePassthrough, RunnableLambda
from langchain_core.prompts import ChatPromptTemplate
from langchain_groq import ChatGroq
from langchain_core.output_parsers import StrOutputParser
from langchain_core.documents import Document

# --- Setup Dependencies (Assuming components from Ex 3 & 4 are available) ---
# retriever (from Ex 3)
# llm (from Ex 4)
# RAG_PROMPT (from Ex 4)

# 1. Define the context formatting function `format_docs(documents: list[Document])`
def format_docs(documents: list[Document]) -> str:
    """Formats a list of LangChain Documents into a single, structured string."""
    formatted_context = []
    for doc in documents:
        # Use metadata to create a clear header
        source = doc.metadata.get('source', 'Unknown Source')
        header = f"--- DOCUMENT START [Source: {source}] ---"
        content = doc.page_content
        formatted_context.append(f"{header}\n{content}\n--- DOCUMENT END ---")
    
    return "\n\n".join(formatted_context)

# 2. Define the RAG Chain using LCEL, incorporating the custom function.
RAG_PROMPT = """
You are an expert Python assistant. Use the following context to answer the question accurately.
Context: {context}
Question: {question}
"""
prompt = ChatPromptTemplate.from_template(RAG_PROMPT)

# 3. Define the final chain structure.
rag_chain_custom = (
    {
        # 3a. Retrieval -> Formatting: The output of the retriever (list[Document]) 
        # is piped directly into the format_docs function.
        "context": retriever | RunnableLambda(format_docs),
        # 3b. Question: Passed through unmodified.
        "question": RunnablePassthrough()
    }
    | prompt # The formatted string is now inserted into the {context} placeholder
    | llm
    | StrOutputParser()
)

# 4. Execute the new chain synchronously using .invoke() and a relevant query.
query_custom = "What is the primary function of a Python decorator?"

print(f"--- Executing Custom Formatted RAG Chain ---")
print(f"Query: {query_custom}")

# To verify the formatting, we can inspect the prompt input before the LLM call.
# However, the requirement is to run the chain and print the final output.
try:
    final_answer = rag_chain_custom.invoke(query_custom)
    print("\nFinal LLM Response (Based on Custom Context Format):")
    print(final_answer)
except NameError:
    print("\n[Error]: The 'retriever' or 'llm' objects must be defined to run this exercise.")

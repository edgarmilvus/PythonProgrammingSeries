
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# Setup: Necessary imports for the exercise
from langchain_community.embeddings import HuggingFaceEmbeddings
import numpy as np

# Data to be embedded
text_1 = "Python's asyncio library enables cooperative multitasking using event loops."
text_2 = "Concurrency is achieved through managing multiple tasks that run seemingly simultaneously."

# 1. Initialize the embedding model (Specify model name: 'all-MiniLM-L6-v2')
model_name = 'all-MiniLM-L6-v2'
embeddings = HuggingFaceEmbeddings(model_name=model_name)

# 2. Generate embeddings for text_1
# Using embed_query for a single string input
embedding_1 = embeddings.embed_query(text_1)

# 3. Print the dimensionality of the embedding
dimensionality = len(embedding_1)
print(f"Embedding Model: {model_name}")
print(f"Embedding Dimensionality (Vector Length): {dimensionality}")
print(f"First 5 dimensions of the vector:\n{embedding_1[:5]}")
print(f"Type of the embedding components: {type(embedding_1[0])}")

# 4. Generate embeddings for text_2 and verify the type of the result
embedding_2 = embeddings.embed_query(text_2)
# Verification check
assert len(embedding_2) == dimensionality


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from pydantic import BaseModel, Field
from langchain.tools import tool
from datetime import date
from typing import Optional

# 1. Define the modified FinancialDataInput Pydantic Model
class FinancialDataInput(BaseModel):
    ticker_symbol: str = Field(
        ..., 
        description="The stock ticker symbol (e.g., AAPL, GOOGL). Required."
    )
    date: date = Field(
        default_factory=date.today, 
        description="Optional historical date for lookup. Defaults to today if omitted."
    )
    include_extended_hours: bool = Field(
        default=False, 
        description="Set to True only if the user explicitly requests after-hours or extended trading data."
    )

# 2. Define the enhanced tool function.
@tool(args_schema=FinancialDataInput)
def financial_data_fetcher(query: FinancialDataInput) -> str:
    """
    Fetches real-time or historical stock price data for a given ticker symbol. 
    This tool supports optional historical dates and can retrieve extended hours data 
    if the 'include_extended_hours' parameter is explicitly set to True.
    """
    
    # Implement the rate limit simulation logic
    if query.ticker_symbol == "LIMIT_TEST":
        # Simulate API failure due to external constraint (e.g., 429 Too Many Requests)
        return "API Rate Limit Exceeded (429). Please wait 60 seconds before retrying."
    
    # Normal execution logic
    extended_status = "including extended hours" if query.include_extended_hours else "excluding extended hours"
    
    return (f"Successfully retrieved financial data for {query.ticker_symbol} "
            f"on {query.date}. Data was fetched {extended_status}.")

# Example Test (Conceptual)
# fetcher_success = financial_data_fetcher(FinancialDataInput(ticker_symbol="MSFT"))
# fetcher_limit = financial_data_fetcher(FinancialDataInput(ticker_symbol="LIMIT_TEST"))

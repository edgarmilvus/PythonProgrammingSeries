
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from langchain.tools import tool
from typing import List
from pydantic import BaseModel, Field, validator, Literal
from langchain.agents import initialize_agent, AgentType
# Assuming E1 and E2 tools (filter_even_numbers and query_crm_system) are defined and imported here

# --- Simulation of E1 and E2 Definitions for completeness ---
# E1: Data Processor Tool
@tool("filter_even_numbers")
def filter_even_numbers(data_list: List[int]) -> List[int]:
    """Use this tool exclusively for identifying and extracting even integers from a provided list."""
    return [num for num in data_list if num % 2 == 0]

# E2: CRM Query Tool Setup (Simplified Pydantic for brevity)
class CRMQueryInput(BaseModel):
    customer_id: int = Field(..., description="Customer ID > 1000.")
    query_type: Literal["ORDER_HISTORY"]
@tool(args_schema=CRMQueryInput)
def query_crm_system(query: CRMQueryInput) -> str:
    """Accesses the proprietary CRM system."""
    return f"Queried CRM for ID {query.customer_id}."
# -----------------------------------------------------------

# 1. Define the third simulated tool: file_storage_lookup
@tool
def file_storage_lookup(file_name: str) -> str:
    """
    Looks up the physical or digital storage path for a given file name in the central repository. 
    Use this when the user asks for the location of a specific file.
    """
    if "report" in file_name.lower():
        return f"/storage/reports/archive/{file_name}"
    return f"/storage/general/{file_name}"

# 2. Create the custom_agent_tools list here, including all three tools.
custom_agent_tools = [
    filter_even_numbers,
    query_crm_system,
    file_storage_lookup
]

# 3. Conceptual Agent Initialization (No execution needed)
# llm = ... # Assume LLM is defined (e.g., ChatOpenAI())
# agent_executor = initialize_agent(
#     custom_agent_tools,  # Provide the tools list here
#     llm,                 # Define the LLM
#     agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION, # Specify AgentType
#     verbose=True
# )

print(f"Total tools packaged: {len(custom_agent_tools)}")
print(f"Tools ready for Agent: {[t.name for t in custom_agent_tools]}")

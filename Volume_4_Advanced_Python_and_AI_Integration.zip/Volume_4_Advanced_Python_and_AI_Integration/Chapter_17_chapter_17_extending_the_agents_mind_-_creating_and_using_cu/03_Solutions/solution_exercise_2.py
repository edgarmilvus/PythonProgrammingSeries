
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from pydantic import BaseModel, Field, validator
from langchain.tools import tool
from typing import Literal

# 1. Define the CRMQueryInput Pydantic Model
class CRMQueryInput(BaseModel):
    """Input schema for querying the proprietary CRM system."""
    
    customer_id: int = Field(
        ..., 
        description="The unique, positive integer ID of the customer. Must be greater than 1000."
    )
    
    # Use Literal for strict type enforcement of allowed strings
    query_type: Literal["ORDER_HISTORY", "CONTACT_INFO", "SUPPORT_TICKETS"] = Field(
        ..., 
        description="The specific type of data requested. Must be one of: ORDER_HISTORY, CONTACT_INFO, or SUPPORT_TICKETS."
    )

    @validator('customer_id')
    def check_customer_id_range(cls, v):
        if v <= 1000:
            raise ValueError('Customer ID must be greater than 1000 for production queries.')
        return v

# 2. Define the tool function, ensuring the input type is the Pydantic model.
@tool(args_schema=CRMQueryInput)
def query_crm_system(query: CRMQueryInput) -> str:
    """
    Accesses the high-security proprietary Customer Relationship Management (CRM) system 
    to retrieve specific customer data based on a validated ID and query type.
    """
    # Simulated successful logic after Pydantic validation
    return (f"Successfully queried CRM for ID {query.customer_id} "
            f"with type {query.query_type}. Data retrieval simulated.")

# Example of how Pydantic validation is enforced by the Agent Executor:
# try:
#     # This would fail validation if customer_id was 500 or query_type was 'INVOICE'
#     query_crm_system(CRMQueryInput(customer_id=1001, query_type="ORDER_HISTORY"))
# except Exception as e:
#     # The Agent Executor catches these Pydantic errors and reports them back to the LLM
#     pass


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from pydantic import BaseModel, Field
from langchain.tools import tool
from datetime import date
from typing import Optional

# 1. Define the FlightPlanInput Pydantic Model with detailed descriptions.
class FlightPlanInput(BaseModel):
    """Schema for planning complex, multi-segment air travel itineraries."""
    
    origin_code: str = Field(
        ..., 
        min_length=3, max_length=3, 
        description="REQUIRED. The three-letter IATA code for the departure airport (e.g., 'JFK', 'LAX')."
    )
    
    destination_code: str = Field(
        ..., 
        min_length=3, max_length=3, 
        description="REQUIRED. The three-letter IATA code for the arrival airport (e.g., 'LHR', 'CDG')."
    )
    
    departure_date: date = Field(
        ..., 
        description="REQUIRED. The exact date of departure. Must be provided in YYYY-MM-DD format."
    )
    
    return_date: Optional[date] = Field(
        None, 
        description="OPTIONAL. The exact date of return for round-trip flights. Must be in YYYY-MM-DD format. Omit for one-way trips."
    )
    
    passenger_count: int = Field(
        1, 
        description="The total number of passengers. Defaults to 1 if not specified by the user."
    )

# 2. Define the tool function signature (no internal logic).
@tool(args_schema=FlightPlanInput)
def multi_city_flight_planner(query: FlightPlanInput) -> str:
    """
    [Insert highly detailed, directive description here, focusing on input constraints and purpose.]
    """
    return "Flight planning query processed successfully."

# 3. Write the final, comprehensive Master Tool Description here:
MASTER_TOOL_DESCRIPTION = """
Use this tool EXCLUSIVELY for searching and planning air travel itineraries 
between two cities. This tool interfaces with a strict travel API. 
CRITICAL INPUT REQUIREMENTS: 
1. All city inputs MUST be provided as three-letter IATA airport codes (e.g., 'SFO', 'MIA'). 
2. All date inputs MUST be provided as standard Python date objects (YYYY-MM-DD). 
The Agent must ensure all required fields (origin_code, destination_code, departure_date) are present. 
Do NOT use this tool for booking hotels, searching for ground transportation, or calculating distances.
"""


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import os
import shutil
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma

# Raw document text (same as Exercise 2)
raw_document_text = """
Python's Global Interpreter Lock (GIL) is a mutex that protects access to Python objects, preventing multiple native threads from executing Python bytecodes at once. This means that while Python is excellent for I/O-bound tasks (like web requests or file operations), it is inherently limited in CPU-bound tasks when relying on standard threading, as only one thread can actively compute at any given time. To achieve true parallelism in CPU-bound scenarios, developers typically resort to the `multiprocessing` module, which bypasses the GIL by spawning separate processes, each with its own interpreter and memory space.

Asynchronous programming, utilizing keywords like `async` and `await`, is another core feature introduced in Python 3.4+. This paradigm enables high concurrency by allowing a single thread to manage many I/O operations simultaneously. Instead of blocking the entire thread while waiting for a network response, the async runtime switches context to another task, maximizing utilization. This is fundamentally different from parallelism achieved via multiprocessing.

Decorators in Python are a powerful syntactic sugar that allows a function to be wrapped by another function. They are commonly used for tasks such as logging, access control, rate limiting, and memoization. A decorator is essentially a function that takes another function as an argument, adds some functionality, and returns the modified function.

In the realm of AI, Python's ecosystem is unmatched. Libraries like NumPy, Pandas, Scikit-learn, and specialized deep learning frameworks such as PyTorch and TensorFlow form the backbone of modern machine learning development. The ease of use, extensive community support, and robust scientific libraries make Python the default choice for data science and large-scale model training.
"""
embedder = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")

# Cleanup
if os.path.exists("./chroma_fine_grained"): shutil.rmtree("./chroma_fine_grained")
if os.path.exists("./chroma_coarse_grained"): shutil.rmtree("./chroma_coarse_grained")

# --- Strategy A: Fine-Grained (Small Chunks) ---
splitter_A = RecursiveCharacterTextSplitter(chunk_size=100, chunk_overlap=40)
docs_A = splitter_A.create_documents([raw_document_text])
vectorstore_A = Chroma.from_documents(
    documents=docs_A, embedding=embedder, persist_directory="./chroma_fine_grained"
)
retriever_A = vectorstore_A.as_retriever(search_kwargs={"k": 3})
print(f"Strategy A (Fine-Grained): Indexed {len(docs_A)} chunks.")

# --- Strategy B: Coarse-Grained (Large Chunks) ---
splitter_B = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
docs_B = splitter_B.create_documents([raw_document_text])
vectorstore_B = Chroma.from_documents(
    documents=docs_B, embedding=embedder, persist_directory="./chroma_coarse_grained"
)
retriever_B = vectorstore_B.as_retriever(search_kwargs={"k": 3})
print(f"Strategy B (Coarse-Grained): Indexed {len(docs_B)} chunks.")

# Complex Query (Requires linking GIL and concurrency concepts)
complex_query = "Explain the relationship between Python's memory management (GIL) and true thread parallelism."

# Retrieval Comparison
results_A = retriever_A.invoke(complex_query)
results_B = retriever_B.invoke(complex_query)

print("\n--- Retrieval Results: Strategy A (Fine-Grained, 100 chars) ---")
for i, doc in enumerate(results_A):
    print(f"Chunk {i+1}: {doc.page_content}")

print("\n--- Retrieval Results: Strategy B (Coarse-Grained, 500 chars) ---")
for i, doc in enumerate(results_B):
    print(f"Chunk {i+1}: {doc.page_content}")

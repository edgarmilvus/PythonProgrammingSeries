
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings

PERSIST_DIR = "./chroma_db_rag"
model_name = "sentence-transformers/all-MiniLM-L6-v2"
embedder = HuggingFaceEmbeddings(model_name=model_name)

# Step 1: Reload the persistent Chroma store
try:
    vectorstore = Chroma(
        persist_directory=PERSIST_DIR, 
        embedding_function=embedder
    )
except Exception as e:
    print(f"Error loading vector store: {e}. Ensure Exercise 2 was run successfully.")
    exit()

# Step 2: Configure the retriever (k=3)
# We use the standard similarity search by default
retriever = vectorstore.as_retriever(search_kwargs={"k": 3})
print(f"Retriever configured to return k={3} documents.")

# Query 1: Highly relevant (focuses on GIL/multiprocessing)
query_1 = "How does Python handle CPU-bound tasks and parallelism?"
docs_1 = retriever.invoke(query_1)

print("\n--- Results for Query 1 (High Relevance) ---")
for i, doc in enumerate(docs_1):
    print(f"Chunk {i+1}: {doc.page_content[:150]}...")

# Query 2: Low relevance (outside the scope of the indexed text)
query_2 = "What is the best way to learn JavaScript?"
docs_2 = retriever.invoke(query_2)

print("\n--- Results for Query 2 (Low Relevance) ---")
for i, doc in enumerate(docs_2):
    print(f"Chunk {i+1}: {doc.page_content[:150]}...")

# Analysis
print("\n--- Comparative Analysis ---")
print("Query 1 successfully retrieved chunks focused on GIL, threading, and multiprocessing, which are directly relevant to 'CPU-bound tasks'.")
print("Query 2, concerning JavaScript, forced the retriever to return the most general or tangentially related content (e.g., Python's AI ecosystem or decorators), demonstrating poor relevance.")

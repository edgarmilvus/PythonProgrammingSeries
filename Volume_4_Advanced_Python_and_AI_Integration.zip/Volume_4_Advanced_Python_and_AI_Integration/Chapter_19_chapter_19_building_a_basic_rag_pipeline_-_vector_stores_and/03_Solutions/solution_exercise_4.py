
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings

PERSIST_DIR = "./chroma_db_rag"
model_name = "sentence-transformers/all-MiniLM-L6-v2"
embedder = HuggingFaceEmbeddings(model_name=model_name)

# Reload components
vectorstore = Chroma(
    persist_directory=PERSIST_DIR, 
    embedding_function=embedder
)

# Define the common query
target_query = "What are the different ways Python handles concurrency and parallelism?"

# Step 2 & 3: Configure MMR Retriever - High Relevance Focus (lambda_mult=0.9)
# High lambda_mult (close to 1.0) means relevance to the query is prioritized.
retriever_high_relevance = vectorstore.as_retriever(
    search_type="mmr",
    search_kwargs={"k": 3, "lambda_mult": 0.9}
)
docs_high_relevance = retriever_high_relevance.invoke(target_query)

print("--- Test 1: MMR (lambda_mult=0.9, High Relevance Focus) ---")
for i, doc in enumerate(docs_high_relevance):
    print(f"Chunk {i+1} (Relevance Focus): {doc.page_content[:100]}...")

# Step 4: Configure MMR Retriever - High Diversity Focus (lambda_mult=0.2)
# Low lambda_mult (close to 0.0) means diversity (distance from already selected chunks) is prioritized.
retriever_high_diversity = vectorstore.as_retriever(
    search_type="mmr",
    search_kwargs={"k": 3, "lambda_mult": 0.2}
)
docs_high_diversity = retriever_high_diversity.invoke(target_query)

print("\n--- Test 2: MMR (lambda_mult=0.2, High Diversity Focus) ---")
for i, doc in enumerate(docs_high_diversity):
    print(f"Chunk {i+1} (Diversity Focus): {doc.page_content[:100]}...")

# Step 5: Comparative Analysis
print("\n--- Comparative Analysis of lambda_mult ---")
print("High Relevance (0.9): Often retrieves chunks that are highly focused on the primary topic (e.g., GIL and multiprocessing), which might be semantically very similar to each other.")
print("High Diversity (0.2): Tends to pull in chunks covering related but distinct topics (e.g., GIL/multiprocessing, AND Asynchronous programming, AND perhaps decorators if they are deemed structurally different), providing a broader, less redundant context set.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os
import shutil
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma
from langchain.schema import Document

# Define the raw document text (must be long enough for splitting)
raw_document_text = """
Python's Global Interpreter Lock (GIL) is a mutex that protects access to Python objects, preventing multiple native threads from executing Python bytecodes at once. This means that while Python is excellent for I/O-bound tasks (like web requests or file operations), it is inherently limited in CPU-bound tasks when relying on standard threading, as only one thread can actively compute at any given time. To achieve true parallelism in CPU-bound scenarios, developers typically resort to the `multiprocessing` module, which bypasses the GIL by spawning separate processes, each with its own interpreter and memory space.

Asynchronous programming, utilizing keywords like `async` and `await`, is another core feature introduced in Python 3.4+. This paradigm enables high concurrency by allowing a single thread to manage many I/O operations simultaneously. Instead of blocking the entire thread while waiting for a network response, the async runtime switches context to another task, maximizing utilization. This is fundamentally different from parallelism achieved via multiprocessing.

Decorators in Python are a powerful syntactic sugar that allows a function to be wrapped by another function. They are commonly used for tasks such as logging, access control, rate limiting, and memoization. A decorator is essentially a function that takes another function as an argument, adds some functionality, and returns the modified function.

In the realm of AI, Python's ecosystem is unmatched. Libraries like NumPy, Pandas, Scikit-learn, and specialized deep learning frameworks such as PyTorch and TensorFlow form the backbone of modern machine learning development. The ease of use, extensive community support, and robust scientific libraries make Python the default choice for data science and large-scale model training.
"""

PERSIST_DIR = "./chroma_db_rag"
model_name = "sentence-transformers/all-MiniLM-L6-v2"
embedder = HuggingFaceEmbeddings(model_name=model_name)

# Cleanup previous run directory if it exists
if os.path.exists(PERSIST_DIR):
    shutil.rmtree(PERSIST_DIR)
    print(f"Cleaned up old directory: {PERSIST_DIR}")

# Step 1: Initialize the splitter
splitter = RecursiveCharacterTextSplitter(
    chunk_size=200,
    chunk_overlap=20,
    length_function=len,
    is_separator_regex=False,
)

# Step 2: Split the document into chunks (LangChain Documents)
docs = splitter.create_documents([raw_document_text])
print(f"Raw text split into {len(docs)} chunks.")

# Step 3 & 4: Create the persistent Chroma store
vectorstore = Chroma.from_documents(
    documents=docs,
    embedding=embedder,
    persist_directory=PERSIST_DIR,
)
print(f"Vector store created and persisted to {PERSIST_DIR}.")

# Ensure persistence is forced (Chroma handles this automatically on creation, but calling persist is good practice)
vectorstore.persist()
del vectorstore # Delete the in-memory object

# Step 5: Verify persistence by reloading
reloaded_vectorstore = Chroma(
    persist_directory=PERSIST_DIR, 
    embedding_function=embedder
)

# Test retrieval on the reloaded store to confirm data integrity
test_query = "What is the GIL?"
reloaded_docs = reloaded_vectorstore.similarity_search(test_query, k=1)

print("\nVerification successful:")
print(f"Reloaded store contains {reloaded_vectorstore._collection.count()} documents.")
print(f"Test retrieval result (first 50 chars): '{reloaded_docs[0].page_content[:50]}...'")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from langchain.chains.router import MultiPromptChain
from langchain.chains.router.llm_router import LLMRouterChain, RouterOutputParser
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate

llm = ChatOpenAI(temperature=0.0) # Low temp for reliable routing

# 1. Define Destination Information
DESTINATION_INFOS = [
    {
        "name": "tech_support",
        "description": "Handles questions about software installation, errors, and troubleshooting.",
        "prompt_template": (
            "You are a patient technical support expert. Provide step-by-step instructions "
            "and common solutions for the user's issue. Query: {input}"
        )
    },
    {
        "name": "legal_compliance",
        "description": "Handles queries related to regulations, contracts, and legal compliance.",
        "prompt_template": (
            "You are a strict compliance officer. Analyze the following query and provide a "
            "cautious, legally sound response, emphasizing adherence to policy. Query: {input}"
        )
    },
    {
        "name": "creative_brainstorming",
        "description": "Handles open-ended requests, story generation, and creative writing.",
        "prompt_template": (
            "You are a whimsical and imaginative creative director. Generate a highly original "
            "and engaging response to the user's request. Query: {input}"
        )
    },
]

# 2. Create Destination Chains
destination_chains = {}
for info in DESTINATION_INFOS:
    prompt = PromptTemplate.from_template(info["prompt_template"])
    destination_chains[info["name"]] = LLMChain(llm=llm, prompt=prompt)

# 3. Define the Router Prompt and Chain
destinations = [
    f"{info['name']}: {info['description']}" 
    for info in DESTINATION_INFOS
]
destinations_str = "\n".join(destinations)

router_template = f"""
Given a user input, classify it into one of the following destinations.
Return the destination name and the original input.

DESTINATIONS:
{destinations_str}

{{input}}

{{output_parser}}
"""

router_prompt = PromptTemplate(
    template=router_template,
    input_variables=["input"],
    partial_variables={"output_parser": RouterOutputParser().get_format_instructions()}
)

router_chain = LLMRouterChain.from_llm(llm, router_prompt=router_prompt)

# 4. Construct the MultiPromptChain
multi_prompt_chain = MultiPromptChain(
    router_chain=router_chain,
    destination_chains=destination_chains,
    default_chain=LLMChain(llm=llm, prompt=PromptTemplate.from_template("Handle this query generally: {input}")),
    verbose=True
)

# 5. Testing
print("--- Test 1: Technical Query ---")
query_1 = "I am getting a 'Permission Denied' error when trying to install the new library."
result_1 = multi_prompt_chain.invoke({"input": query_1})

print("\n--- Test 2: Legal Query ---")
query_2 = "Does our new marketing copy comply with GDPR article 12 regarding data usage?"
result_2 = multi_prompt_chain.invoke({"input": query_2})

print("\n--- Test 3: Creative Query ---")
query_3 = "Write a short poem about the existential dread of a neural network."
result_3 = multi_prompt_chain.invoke({"input": query_3})


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from langchain.chains import SequentialChain, LLMChain
from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(temperature=0.2)

# Mock Data for Stage 1 (used in the prompt template)
MOCK_FINANCIAL_DATA = (
    "Revenue: $5.2B (up 15% YoY). Net Income: $350M (down 5% YoY). "
    "Key Risk: Supply chain disruption in Southeast Asia impacting 40% of production. "
    "Major Success: Successful acquisition of 'InnovateTech' increasing market share by 8%."
)

# --- Stage 1: Data Retriever (Simulated) ---
# Inputs: company_ticker, reporting_quarter
# Output: raw_financial_data
template_1 = (
    "You are a data retrieval simulator. Given the ticker {company_ticker} "
    "for Q{reporting_quarter}, return the following mock financial data exactly: "
    f"'{MOCK_FINANCIAL_DATA}'"
)
prompt_1 = PromptTemplate(input_variables=["company_ticker", "reporting_quarter"], template=template_1)
chain_1 = LLMChain(llm=llm, prompt=prompt_1, output_key="raw_financial_data")

# --- Stage 2: Detailed Analysis ---
# Input: raw_financial_data
# Output: detailed_report
template_2 = (
    "Analyze the following raw financial data and generate a comprehensive, detailed report (5-7 sentences). "
    "Focus on trends, successes, and potential concerns.\n\nDATA: {raw_financial_data}"
)
prompt_2 = PromptTemplate(input_variables=["raw_financial_data"], template=template_2)
chain_2 = LLMChain(llm=llm, prompt=prompt_2, output_key="detailed_report")

# --- Stage 3: Reporting Split ---
# Input: detailed_report
# Outputs: executive_summary, risk_assessment
template_3 = (
    "Based on the detailed report below, perform two distinct tasks:\n"
    "1. EXECUTIVE SUMMARY: Write a brief, high-level summary (2 sentences) starting with 'SUMMARY: '.\n"
    "2. RISK ASSESSMENT: Write a structured list of 3 key risks starting with 'RISKS: '.\n\n"
    "Report: {detailed_report}"
)
prompt_3 = PromptTemplate(input_variables=["detailed_report"], template=template_3)
chain_3 = LLMChain(llm=llm, prompt=prompt_3, output_key="combined_report")
# NOTE: To split the output, we rely on the LLM to format the output clearly 
# and then use a custom parser or, simpler for this exercise, rely on the LLM 
# to produce two distinct sections that we will manually extract/verify. 
# For a clean SequentialChain example, we'll keep the output key simple, 
# but the prompt forces the structure.

# For a strict SequentialChain output, we must define a chain that produces 
# the two required outputs. Since LLMChain only produces one output key, 
# we'll create a simple parsing chain structure for verification. 

# Alternative structure for Stage 3 to meet dual output requirement:
# We will create two parallel LLMChains off the detailed_report input 
# and join them, but SequentialChain requires a linear sequence. 
# For the purpose of SequentialChain, we must ensure the final LLM call 
# produces the two required output variables.

# To satisfy the requirement of two final output variables using SequentialChain, 
# we must use a custom approach or, more simply, define two separate final chains 
# that both take `detailed_report` as input, and ensure the `SequentialChain` 
# collects both of their outputs.

# Redefining Stage 3 for clarity in SequentialChain structure:
chain_3_summary = LLMChain(
    llm=llm,
    prompt=PromptTemplate(
        input_variables=["detailed_report"],
        template="Based on this report: {detailed_report}, write a 2-sentence executive summary."
    ),
    output_key="executive_summary"
)

chain_4_risks = LLMChain(
    llm=llm,
    prompt=PromptTemplate(
        input_variables=["detailed_report"],
        template="Based on this report: {detailed_report}, extract and list 3 key risks."
    ),
    output_key="risk_assessment"
)

# --- Construct the SequentialChain ---
# Note: Since chain 3 and chain 4 both require 'detailed_report', 
# SequentialChain handles passing all intermediate results forward.
overall_chain = SequentialChain(
    chains=[chain_1, chain_2, chain_3_summary, chain_4_risks],
    input_variables=["company_ticker", "reporting_quarter"],
    output_variables=["executive_summary", "risk_assessment"],
    verbose=True
)

# --- Execution ---
print("--- Running SequentialChain (Multi-Input, Multi-Output) ---")
input_data = {
    "company_ticker": "QTM",
    "reporting_quarter": "Q3-2024"
}
final_result = overall_chain.invoke(input_data)

print("\n--- Final Result Verification ---")
print(f"Keys in final output: {list(final_result.keys())}")
print("\nExecutive Summary:")
print(final_result['executive_summary'])
print("\nRisk Assessment:")
print(final_result['risk_assessment'])

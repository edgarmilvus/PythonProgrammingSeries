
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import asyncio
import time
from langchain.chains import SequentialChain, LLMChain
from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI

# Mock LLM setup (Crucial: Use a model that supports asynchronous calls)
llm = ChatOpenAI(temperature=0.7) 

# --- Task 1: Analyst Chain (3 Steps) ---
# 1. Summarize
chain_1_a = LLMChain(llm=llm, prompt=PromptTemplate.from_template("Summarize this document: {input}"), output_key="summary")
# 2. Critique
chain_1_b = LLMChain(llm=llm, prompt=PromptTemplate.from_template("Critique the summary: {summary}"), output_key="critique")
# 3. Reformat
chain_1_c = LLMChain(llm=llm, prompt=PromptTemplate.from_template("Reformat the critique into 3 bullet points: {critique}"), output_key="final_analysis")

task_1_analyst = SequentialChain(
    chains=[chain_1_a, chain_1_b, chain_1_c],
    input_variables=["input"],
    output_variables=["final_analysis"],
    verbose=False
)

# --- Task 2: Translator Chain (2 Steps) ---
# 1. Translate
chain_2_a = LLMChain(llm=llm, prompt=PromptTemplate.from_template("Translate this text into French: {input}"), output_key="translation")
# 2. Tone Adjustment
chain_2_b = LLMChain(llm=llm, prompt=PromptTemplate.from_template("Adjust the French translation to be formal and academic: {translation}"), output_key="formal_translation")

task_2_translator = SequentialChain(
    chains=[chain_2_a, chain_2_b],
    input_variables=["input"],
    output_variables=["formal_translation"],
    verbose=False
)

async def run_parallel_tasks(input_data_1: str, input_data_2: str):
    """
    Executes two independent sequential chains concurrently using asyncio.gather().
    """
    print("Starting parallel execution...")
    start_time = time.time()
    
    # Use .ainvoke() for modern LangChain execution
    results = await asyncio.gather(
        task_1_analyst.ainvoke({"input": input_data_1}),
        task_2_translator.ainvoke({"input": input_data_2})
    )
    
    end_time = time.time()
    
    print("\n--- Results ---")
    print(f"Task 1 Result (Analysis): {results[0]['final_analysis'][:50]}...")
    print(f"Task 2 Result (Translation): {results[1]['formal_translation'][:50]}...")
    print(f"\nTotal parallel execution time: {end_time - start_time:.2f} seconds")
    
    # Estimate individual run times for comparison (synchronous)
    # Note: Task 1 (3 steps) is expected to be the longest running task.
    # Task 2 (2 steps) is shorter.
    
    # We rely on the measured parallel time being close to the time of Task 1 
    # (the longest task) to prove concurrency.

# Example usage:
input_1 = "The corporate strategy pivoted sharply toward decentralized autonomous organizations (DAOs) last quarter, resulting in significant structural changes."
input_2 = "The quick brown fox jumps over the lazy dog."

# Execute the asynchronous function
# Note: This block must be run in an environment that supports asyncio.
# For local testing, use asyncio.run()
if __name__ == '__main__':
    print("Running synchronous chains for baseline comparison (conceptual):")
    # Task 1 (3 steps) is longer than Task 2 (2 steps). 
    # Total synchronous time would be Time(T1) + Time(T2).
    # Total parallel time should be max(Time(T1), Time(T2)).
    asyncio.run(run_parallel_tasks(input_1, input_2))

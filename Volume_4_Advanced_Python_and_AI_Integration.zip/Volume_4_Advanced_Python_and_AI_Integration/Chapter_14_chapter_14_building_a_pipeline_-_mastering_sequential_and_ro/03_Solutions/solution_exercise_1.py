
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
from langchain.chains import SimpleSequentialChain, LLMChain
from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI 

# Ensure LLM is initialized (assuming API key is set in environment)
llm = ChatOpenAI(temperature=0.1)

# Mock Input Data
LONG_ARTICLE = (
    "The recent advancements in quantum computing have shifted the paradigm "
    "for cryptographic security. While current classical encryption methods "
    "rely on the difficulty of factoring large numbers, quantum algorithms, "
    "specifically Shor's algorithm, threaten to render these methods obsolete "
    "within the next decade. This necessitates immediate investment in post-quantum "
    "cryptography (PQC) research and development, focusing on lattice-based "
    "cryptography and hash-based signatures. Companies that fail to transition "
    "risk catastrophic data breaches once quantum machines become commercially viable."
)

# --- Stage 1: Summarizer ---
prompt_template_1 = PromptTemplate(
    input_variables=["text"],
    template="Please provide a concise, 3-sentence summary of the following text:\n\nTEXT: {text}"
)
chain_1 = LLMChain(llm=llm, prompt=prompt_template_1)

# --- Stage 2: Insight Generator ---
# Note: The input variable here must match the expected input for the second stage.
# SimpleSequentialChain automatically maps the output of chain_1 to the input of chain_2.
prompt_template_2 = PromptTemplate(
    input_variables=["summary"],
    template="Based ONLY on the summary provided below, generate 5 bullet points detailing potential next steps or business actions.\n\nSUMMARY: {summary}"
)
chain_2 = LLMChain(llm=llm, prompt=prompt_template_2)

# --- Construct the SimpleSequentialChain ---
overall_chain = SimpleSequentialChain(
    chains=[chain_1, chain_2], 
    verbose=True
)

print("--- Running SimpleSequentialChain ---")
final_output = overall_chain.invoke({"input": LONG_ARTICLE})
print("\n--- Final Output (Actionable Insights) ---")
print(final_output['output'])

# --- Constraint Test ---
print("\n--- Constraint Test: Attempting to pass an extra variable ---")
try:
    # SimpleSequentialChain expects a single 'input' key for the initial input.
    # It cannot handle multiple named inputs or pass-through variables easily.
    result_fail = overall_chain.invoke({
        "input": LONG_ARTICLE, 
        "author_name": "Dr. Smith"
    })
    print("Test Result: Execution succeeded, but 'author_name' was ignored or dropped.")
except Exception as e:
    print(f"Test Result: Execution failed as expected. Error: {e}")

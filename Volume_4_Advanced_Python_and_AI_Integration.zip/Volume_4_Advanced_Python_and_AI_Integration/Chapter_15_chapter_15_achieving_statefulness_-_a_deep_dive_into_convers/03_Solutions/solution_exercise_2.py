
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from langchain.memory import ConversationSummaryBufferMemory
from langchain_core.language_models import BaseLLM
from langchain_core.messages import HumanMessage, AIMessage

# Mock LLM is required for summarization, as it is an LLM operation.
class MockLLM(BaseLLM):
    def _call(self, prompt: str, stop: List[str] = None) -> str:
        # Simple simulation of summarization output
        if "Hello, what is the weather like today?" in prompt:
             return "The user inquired about the weather and asked for clothing advice based on the temperature."
        return "A brief summary of the conversation so far."

    @property
    def _llm_type(self) -> str:
        return "mock_llm"

def run_summary_test():
    llm = MockLLM()
    
    # 1. Memory Initialization
    # We use ConversationSummaryBufferMemory and set a very low token limit (50) 
    # to force summarization after the first few exchanges.
    memory = ConversationSummaryBufferMemory(
        llm=llm,
        max_token_limit=50, 
        return_messages=True # Required for clear inspection of SystemMessage summary
    )

    def save_and_print(h, a):
        memory.save_context({"input": h}, {"output": a})

    # 3. Short Conversation (Should remain in buffer)
    save_and_print("Hello, what is the weather like today?", "It is sunny and 75 degrees.")
    save_and_print("Great. Should I wear a coat?", "No, a light jacket should suffice.")

    # 4. Initial Check: Load and print history
    initial_history = memory.load_memory_variables({})['history']
    print(f"--- History after 2 Exchanges (Raw Messages) ---")
    print(f"Total items: {len(initial_history)}")
    print(initial_history)
    
    # 5. Long Conversation Trigger (This pushes the token count over 50)
    print("\n--- Adding 3 More Exchanges (Triggering Summarization) ---")
    save_and_print("I am planning a trip next week.", "Where are you thinking of going?")
    save_and_print("I'm thinking of Scotland. What's the main attraction there?", "Edinburgh Castle is a must-see.")
    save_and_print("What time does it open?", "It typically opens at 9:30 AM.")

    # 6. Summary Validation: Load and print history again
    final_history = memory.load_memory_variables({})['history']
    print(f"\n--- History after 5 Exchanges (Summarized) ---")
    print(f"Total items: {len(final_history)}")
    
    # The first element should be the summary, followed by the latest raw messages.
    if final_history and isinstance(final_history[0], SystemMessage):
        print(f"Verification: First element is a SystemMessage (Summary):\n{final_history[0].content}")
        print(f"\nRemaining messages (Recent Buffer):\n{final_history[1:]}")
    else:
        print("Error: Summarization did not occur as expected.")

# run_summary_test()

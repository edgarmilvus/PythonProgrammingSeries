
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import json
from langchain.memory import ConversationBufferMemory

def save_session(memory: ConversationBufferMemory) -> str:
    """Retrieves memory variables and serializes them to JSON."""
    # 1. Retrieve raw variables (e.g., {'history': 'Human: ...\nAI: ...'})
    raw_variables = memory.load_memory_variables({})
    
    # 2. Serialize to JSON string
    json_data = json.dumps(raw_variables)
    print(f"--- Session 1 Saved ---")
    return json_data

def load_session(json_data: str) -> ConversationBufferMemory:
    """Deserializes JSON data and injects it into a new memory object."""
    # 1. Deserialize JSON data
    loaded_variables = json.loads(json_data)
    
    # 2. Initialize NEW memory object (empty state)
    # Must match the return_messages setting used during saving.
    memory_session_2 = ConversationBufferMemory(return_messages=False)
    
    # 3. Inject the history into the new memory instance.
    if 'history' in loaded_variables:
        # For ConversationBufferMemory (return_messages=False), 
        # the internal buffer attribute holds the concatenated string.
        memory_session_2.buffer = loaded_variables['history']
        
    print("--- Session 2 Loaded into New Memory Instance ---")
    return memory_session_2

def interactive_challenge():
    # --- SESSION 1: Create and Save ---
    memory_session_1 = ConversationBufferMemory(return_messages=False)
    
    # Run conversation exchanges
    memory_session_1.save_context({"input": "What is the primary product?"}, {"output": "The LangChain framework."})
    memory_session_1.save_context({"input": "What is its main language?"}, {"output": "Python and TypeScript."})
    memory_session_1.save_context({"input": "How is memory managed?"}, {"output": "Via the Memory module."})
    
    json_data = save_session(memory_session_1)
    
    # --- SESSION INTERRUPTION ---
    del memory_session_1 
    print("\n--- Application Restart Simulation (Memory Cleared) ---")
    
    # --- SESSION 2: Load and Resume ---
    memory_session_2 = load_session(json_data)
    
    # Verification: Check the loaded state before the new exchange
    loaded_history = memory_session_2.load_memory_variables({})['history']
    print(f"\nHistory after Load (Should contain 3 exchanges):\n{loaded_history}")
    
    # Run one final exchange on memory_session_2 (Testing continuity)
    memory_session_2.save_context({"input": "Can I use it with RAG?"}, {"output": "Yes, through the ConversationalRetrievalChain."})
    
    # Final check
    final_history = memory_session_2.load_memory_variables({})['history']
    print("\n--- Final History (Should contain 4 exchanges) ---")
    print(final_history)
    
    if "Can I use it with RAG?" in final_history:
        print("\nVerification Successful: New exchange appended to restored history.")
    else:
        print("\nVerification Failed.")

# interactive_challenge()

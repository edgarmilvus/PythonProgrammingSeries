
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from langchain.memory import ConversationBufferMemory

def transform_history(raw_history_string: str) -> list:
    """
    Parses the raw history string into a list of individual conversation turns.
    """
    if not raw_history_string:
        return []
    # LangChain history (when not using messages) is separated by '\n'.
    # Split the string and strip whitespace from each turn.
    turns = [turn.strip() for turn in raw_history_string.split('\n') if turn.strip()]
    return turns

def simulate_session():
    # 1. Initialization: Use return_messages=False to get the raw string buffer.
    memory = ConversationBufferMemory(return_messages=False) 

    # 2. Interaction Simulation
    print("--- Simulating 3 Exchanges ---")
    memory.save_context(
        {"input": "What is the capital of France?"}, 
        {"output": "Paris."}
    )
    memory.save_context(
        {"input": "What is the primary language spoken there?"}, 
        {"output": "French."}
    )
    memory.save_context(
        {"input": "Tell me a fun fact about the Eiffel Tower."}, 
        {"output": "It can grow up to 6 inches taller during hot weather due to thermal expansion."}
    )

    # 3. Manual Extraction
    raw_memory_dict = memory.load_memory_variables({})
    
    # Access the 'history' key, which holds the concatenated string.
    raw_history_string = raw_memory_dict.get('history', '')
    
    # 4. Data Transformation
    clean_history_list = transform_history(raw_history_string)
    
    # 5. Validation
    print("\n--- Transformed History List (6 Turns) ---")
    for i, turn in enumerate(clean_history_list):
        print(f"Turn {i+1}: {turn}")
    
    print(f"\nValidation: Total turns captured: {len(clean_history_list)}")

# simulate_session()

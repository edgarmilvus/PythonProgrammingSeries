
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from langchain.chains import ConversationalRetrievalChain
from langchain.memory import ConversationBufferMemory
from langchain_core.documents import Document
from langchain_core.language_models import BaseLLM
from langchain_core.retrievers import BaseRetriever
from typing import List

# 1. Setup Mock Components
class MockLLM(BaseLLM):
    """Mock LLM that checks for context to provide a stateful response."""
    def _call(self, prompt: str, stop: List[str] = None) -> str:
        # The prompt contains the chat history and the question.
        if "few-shot" in prompt and "zero-shot" in prompt:
            return "Few-shot learning requires 3-5 examples for in-context learning, while zero-shot learning relies purely on the model's pre-trained knowledge without any examples."
        elif "zero-shot learning" in prompt:
            return "Zero-shot learning is the ability of an LLM to perform a task it hasn't been explicitly trained on."
        return "I need more context to answer that specific difference."

    @property
    def _llm_type(self) -> str:
        return "mock_llm"

class MockRetriever(BaseRetriever):
    """Mock retriever providing necessary documents."""
    def get_relevant_documents(self, query: str) -> List[Document]:
        return [
            Document(page_content="Zero-shot learning uses general knowledge."),
            Document(page_content="Few-shot learning uses 3-5 examples for in-context learning.")
        ]
    async def aget_relevant_documents(self, query: str) -> List[Document]:
        return self.get_relevant_documents(query)

def setup_stateful_crc():
    llm = MockLLM()
    retriever = MockRetriever()

    # 2. Memory Initialization: Must use 'chat_history' as the memory key 
    # for the default ConversationalRetrievalChain prompt template.
    memory = ConversationBufferMemory(
        memory_key="chat_history", 
        return_messages=True 
    )

    # 3. Chain Initialization
    crc = ConversationalRetrievalChain.from_llm(
        llm=llm,
        retriever=retriever,
        memory=memory,
    )

    print("--- Chain Initialized ---")

    # 4. Stateless Query
    query_1 = "Explain the concept of zero-shot learning."
    print(f"\nUser 1: {query_1}")
    result_1 = crc.invoke({"question": query_1})
    print(f"AI 1: {result_1['answer']}")
    
    # 5. Stateful Follow-up (Relies on 'zero-shot' being in history/context)
    query_2 = "How is it different from few-shot learning?"
    print(f"\nUser 2: {query_2}")
    
    # The chain automatically injects the history into the prompt used 
    # to generate the answer based on the retrieved documents.
    result_2 = crc.invoke({"question": query_2})
    print(f"AI 2: {result_2['answer']}")

    # 6. Verification
    print("\n--- Verification: Memory Content Check ---")
    history_content = memory.load_memory_variables({})['chat_history']
    print(f"Total messages stored: {len(history_content)}")
    print(f"Successfully provided a stateful answer based on context.")

# setup_stateful_crc()

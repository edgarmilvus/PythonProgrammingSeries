
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

total_bins = 1500
bins_scanned = 0

print("Starting Automated Inventory Scan...")

# 2. Loop Condition: Continue as long as we haven't reached the total required scans
while bins_scanned < total_bins:
    # 4. Critical Termination: Increment MUST happen inside the loop body
    bins_scanned += 1
    
    # 3. State Management: Simulate processing
    print(f"Processing Bin {bins_scanned}...")

    # Explanation of Infinite Loop Risk:
    # If the line 'bins_scanned += 1' were placed outside the loop body, 
    # the value of bins_scanned would remain 0 indefinitely. The condition 
    # (0 < 1500) would always evaluate to True, causing the loop to run forever.

# 5. Efficiency Check
print(f"\nScan Complete. Total bins successfully scanned: {bins_scanned}")

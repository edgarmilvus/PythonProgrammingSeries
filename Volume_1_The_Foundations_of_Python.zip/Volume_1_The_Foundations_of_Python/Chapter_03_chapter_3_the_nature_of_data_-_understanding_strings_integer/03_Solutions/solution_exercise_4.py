
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# 1. Initialization (Re-declare Context Variables)
SYSTEM_NAME = "Automated Invoice Generator"
CLIENT_ID_STR = "CUST-4055"
subtotal_amount = 550.75
TAX_RATE_PERCENT = 0.08

# 2. Calculation
tax_amount = subtotal_amount * TAX_RATE_PERCENT
final_total = subtotal_amount + tax_amount

# 3. Casting for Integration
# Numerical data must be converted to strings to concatenate with text
final_total_str = str(final_total)
tax_rate_str = str(TAX_RATE_PERCENT)

# 4. Template Generation (String Concatenation)
invoice_header = SYSTEM_NAME + " | Processing ID: " + CLIENT_ID_STR

invoice_summary = (
    "Total due for client " +
    CLIENT_ID_STR +
    " is $" +
    final_total_str +
    " (includes tax rate of " +
    tax_rate_str +
    ")"
)

# 5. Output
print("--- Invoice Generation ---")
print(invoice_header)
print(invoice_summary)

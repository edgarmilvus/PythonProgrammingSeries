
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# 1. Variable Initialization
initial_principal = 25000
total_profit_earned = 4873.55
investment_duration_months = 18
total_fees_incurred = 125.99

# 2. Net Profit Calculation (Float result)
net_profit = total_profit_earned - total_fees_incurred
print(f"Net Profit: ${net_profit:.2f}")

# 3. Average Monthly Profit (Float Division - Required for precision)
# Dividing a float (net_profit) by an integer (months) results in a float.
average_monthly_profit = net_profit / investment_duration_months
print(f"\nAverage Monthly Profit (Float): ${average_monthly_profit:.2f}")

# 4. Average Monthly Profit (Integer Division Demonstration)
# Integer division truncates the decimal part, losing precision.
integer_monthly_profit_demo = net_profit // investment_duration_months
print(f"Average Monthly Profit (Integer Demo): ${integer_monthly_profit_demo:.2f}")

# 5. Type Verification
print("\n--- Type Verification ---")
print(f"Type of average_monthly_profit: {type(average_monthly_profit)}")
print(f"Type of investment_duration_months: {type(investment_duration_months)}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# 1. Initialization
tracking_id = "US-EAELEC901AX7Y3"

# 2. Length Determination
id_length = len(tracking_id)
print(f"Tracking ID: {tracking_id}")
print(f"Total Length: {id_length}")

# 3. Positive Indexing Extraction
# Characters 0-3 (Region Code)
region_code = tracking_id[0:4]

# Characters 4-7 (Product Category)
product_category = tracking_id[4:8]

# 4. Negative Indexing Extraction
# Characters 12-15 (Security Checksum - last four characters)
security_checksum = tracking_id[-4:]

# 5. Stepped Slicing Challenge
# Characters 8-11 (Warehouse ID), step of 2 (indices 8 and 10)
warehouse_sub_code = tracking_id[8:12:2]

# 6. Reversal
reversed_id = tracking_id[::-1]

# 7. Output Verification
print("\n--- Extracted Components ---")
print(f"Region Code:        {region_code}")
print(f"Product Category:   {product_category}")
print(f"Security Checksum:  {security_checksum}")
print(f"Warehouse Sub Code: {warehouse_sub_code}")
print(f"Reversed ID:        {reversed_id}")

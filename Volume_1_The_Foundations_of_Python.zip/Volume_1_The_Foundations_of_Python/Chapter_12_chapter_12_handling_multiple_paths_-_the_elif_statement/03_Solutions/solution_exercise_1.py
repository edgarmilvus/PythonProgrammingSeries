
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

def calculate_grade(score):
    """
    Calculates the letter grade based on the score, prioritizing higher scores
    and validating the input range (0-100).
    """
    # 4. Initial check for invalid range (must be the primary if)
    if score < 0 or score > 100:
        return "Error: Score out of valid range (0-100)."

    # 6. The order is crucial: checking highest scores first simplifies the logic.
    # If score >= 90 is True, all subsequent checks are skipped (short-circuiting).
    # If it's False, the code moves to the next elif, which now only needs to check
    # the lower bound (e.g., >= 80) because we already know the score is < 90.
    
    # 2. Grading scale implementation (90-100)
    elif score >= 90:
        return 'A'
    
    # 2. Grading scale implementation (80-89)
    elif score >= 80:
        return 'B'
    
    # 2. Grading scale implementation (70-79)
    elif score >= 70:
        return 'C'
    
    # 2. Grading scale implementation (60-69)
    elif score >= 60:
        return 'D'
    
    # 5. Final else block catches all remaining scores (0-59)
    else:
        return 'F'

# Example Tests:
# print(f"Score 95: {calculate_grade(95)}")    # Expected: A
# print(f"Score 80: {calculate_grade(80)}")    # Expected: B
# print(f"Score 55: {calculate_grade(55)}")    # Expected: F
# print(f"Score 105: {calculate_grade(105)}")  # Expected: Error

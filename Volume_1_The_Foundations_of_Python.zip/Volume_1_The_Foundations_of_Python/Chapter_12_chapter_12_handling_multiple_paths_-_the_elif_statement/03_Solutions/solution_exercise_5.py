
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

def calculate_tax(income):
    """
    Determines the tax rate based on income brackets using prioritized checks.
    """
    # 4. Initial validation check
    if income < 0:
        return "Error: Income cannot be negative."

    # 5. Comment: Checking brackets in descending order (highest income first) 
    # simplifies the conditional expressions. If the income passes 'income > 50000', 
    # we don't need to check 'income <= 100000' because the preceding 'if income > 100000' 
    # already filtered out the higher bracket.

    # Bracket 1: Over $100,000 (35%)
    elif income > 100000:
        return 0.35
    
    # Bracket 2: Over $50,000 (effectively $50,001 to $100,000) (20%)
    elif income > 50000:
        return 0.20
    
    # Bracket 3: Over $20,000 (effectively $20,001 to $50,000) (10%)
    elif income > 20000:
        return 0.10
    
    # Default: $20,000 or less (0%)
    else:
        return 0.00

# Example Tests:
# print(f"Income $120,000: {calculate_tax(120000)}") # Expected: 0.35
# print(f"Income $60,000: {calculate_tax(60000)}")   # Expected: 0.20
# print(f"Income $15,000: {calculate_tax(15000)}")   # Expected: 0.00
# print(f"Income $-500: {calculate_tax(-500)}")      # Expected: Error

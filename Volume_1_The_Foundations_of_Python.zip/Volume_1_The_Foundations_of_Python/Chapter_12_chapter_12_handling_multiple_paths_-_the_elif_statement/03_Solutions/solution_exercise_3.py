
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os

# Note: For this example, we assume a path exists for demonstration purposes.
# In a real environment, these paths would need to be valid on the system.

def process_file_check(base_path, file_name):
    # 3. Construct the full path using os.path.join for platform independence
    full_path = os.path.join(base_path, file_name)
    
    # Comment: Using elif avoids deep nesting. Instead of:
    # if exists:
    #     if not isdir:
    #         if extension matches:
    # The elif structure allows sequential, flat checks where subsequent checks
    # only run if the previous, higher-priority condition (like non-existence) failed.

    # 4. Check 1 (Existence)
    if not os.path.exists(full_path):
        return "Validation Error: Path does not exist."
    
    # Check 2 (Type Check: Directory) - Only runs if the path exists
    elif os.path.isdir(full_path):
        return "Validation Error: Path points to a directory, not a file."
    
    # Check 3 (Specific File Extension) - Only runs if it exists AND is not a directory (i.e., is a file)
    else: 
        # Extract the file extension
        _, file_extension = os.path.splitext(full_path)
        file_extension = file_extension.lower() # Normalize case for comparison

        if file_extension == '.txt' or file_extension == '.csv':
            return "Success: Data file ready for processing."
        
        # Check 4 (Other File Types)
        else:
            return "Warning: File type recognized but not supported for data processing."

    # 5. Final else (Theoretically unreachable due to exhaustive checks above)
    # This block is omitted in the main elif chain above because the 'else' following 
    # Check 2 already guarantees the path is a file, and the nested if/else handles extensions exhaustively.
    # If we had a final catch-all outside the file extension logic, it would be here:
    # return "Unknown Path Status."
    
# Since we cannot guarantee file existence, we use mock paths for analysis:
# print(process_file_check('/tmp', 'nonexistent.file')) 
# print(process_file_check('/etc', 'hosts')) # Assuming /etc/hosts exists and is not txt/csv

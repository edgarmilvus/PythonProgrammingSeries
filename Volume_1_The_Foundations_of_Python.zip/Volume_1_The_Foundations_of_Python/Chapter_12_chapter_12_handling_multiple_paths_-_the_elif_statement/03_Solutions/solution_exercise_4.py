
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

def conversational_agent():
    print("Welcome to the basic conversational agent. Type 'quit' or 'exit' to stop.")
    
    # 1. Continuous loop
    while True:
        # 2. Capture user input
        user_input = input("User: ")
        
        # 3. Convert input to lowercase for case-insensitive matching
        clean_input = user_input.lower()
        
        # 4. Implement prioritized response logic (Highest priority first)
        
        # Priority 1 (Exit Command) - Must be primary 'if'
        if "quit" in clean_input or "exit" in clean_input:
            print("Session terminated. Goodbye.")
            break # Stop the loop
            
        # Priority 2 (Help Command)
        # If the user types "Hi, I need help," this check (Priority 2) runs first 
        # because the 'if' (Priority 1) was false. If this is true, Priority 4 
        # (General Greeting) is skipped entirely, ensuring command precedence.
        elif "help" in clean_input or "manual" in clean_input:
            print("I can assist with account status or operating hours.")
            
        # Priority 3 (Specific Query)
        elif "hours" in clean_input or "open" in clean_input:
            print("Our operating hours are 9 AM to 5 PM, Monday through Friday.")
            
        # Priority 4 (General Greeting)
        elif "hello" in clean_input or "hi" in clean_input:
            print("Hello! How can I help you today?")
            
        # Default Response
        else:
            print("I'm sorry, I don't understand that command. Try 'help' or 'quit'.")

# To run the agent, uncomment the line below:
# conversational_agent()

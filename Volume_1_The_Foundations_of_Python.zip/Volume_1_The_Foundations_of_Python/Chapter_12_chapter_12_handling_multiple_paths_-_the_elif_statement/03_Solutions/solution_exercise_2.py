
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

def check_user_access(user_role):
    # 3. Handle case-insensitivity by converting the input role to lowercase once.
    role_check = user_role.lower()

    # 4. Explanation: The 'Superuser' check must precede 'Administrator' because 
    # a Superuser is a type of Administrator (or holds higher privileges). 
    # If 'Administrator' were checked first, a Superuser would mistakenly be 
    # assigned only Level 4 access, and the subsequent check would be skipped.

    # Highest Priority (Level 5)
    if role_check == "superuser":
        return "Full System Control (Level 5)"
    
    # Second Priority (Level 4)
    elif role_check == "administrator":
        return "Management Access (Level 4)"
    
    # Third Priority (Level 3) - Combined condition using 'or'
    elif role_check == "editor" or role_check == "moderator":
        return "Content Modification Rights (Level 3)"
    
    # Fourth Priority (Level 2) - Combined condition using 'or'
    elif role_check == "staff" or role_check == "contributor":
        return "Standard Read/Write Access (Level 2)"
    
    # Default (Level 1)
    else:
        return "Guest/Unrecognized User (Level 1)"

# Example Tests:
# print(f"Role 'Superuser': {check_user_access('Superuser')}")     # Expected: Level 5
# print(f"Role 'administrator': {check_user_access('administrator')}") # Expected: Level 4
# print(f"Role 'Moderator': {check_user_access('Moderator')}")     # Expected: Level 3
# print(f"Role 'Guest': {check_user_access('Guest')}")             # Expected: Level 1

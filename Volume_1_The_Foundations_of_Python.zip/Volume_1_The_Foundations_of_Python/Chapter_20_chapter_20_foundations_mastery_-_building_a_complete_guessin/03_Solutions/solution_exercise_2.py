
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import random

# 1. Initialization
SECRET_NUMBER = random.randint(1, 100)
MAX_ATTEMPTS = 7
attempts_used = 0
guessed_correctly = False

print(f"I'm thinking of a number between 1 and 100. You have {MAX_ATTEMPTS} attempts.")

# Use a simplified input mechanism for this example, focusing on the loop logic
# In a real game, this would call the function from Exercise 1.
current_guess = -1 # Initialize to ensure the loop runs

# 2. Loop Condition Modification
while not guessed_correctly and attempts_used < MAX_ATTEMPTS:
    print(f"\n--- Attempt {attempts_used + 1} of {MAX_ATTEMPTS} ---")
    
    # Simulate getting a valid guess (replace with get_valid_guess() in a full integration)
    try:
        current_guess = int(input("Enter your guess: "))
    except ValueError:
        print("Invalid input. Try again.")
        continue # Don't increment attempts for invalid input

    # 3. Counter Increment
    attempts_used += 1

    if current_guess == SECRET_NUMBER:
        guessed_correctly = True
    elif current_guess < SECRET_NUMBER:
        print("Too low!")
    else:
        print("Too high!")

# Check termination condition
if guessed_correctly:
    # 5. Success Condition
    print(f"\nCONGRATULATIONS! You guessed the number {SECRET_NUMBER} in {attempts_used} attempts.")
else:
    # 4. Failure Condition
    print(f"\nGAME OVER! You ran out of attempts ({MAX_ATTEMPTS}). The secret number was {SECRET_NUMBER}.")

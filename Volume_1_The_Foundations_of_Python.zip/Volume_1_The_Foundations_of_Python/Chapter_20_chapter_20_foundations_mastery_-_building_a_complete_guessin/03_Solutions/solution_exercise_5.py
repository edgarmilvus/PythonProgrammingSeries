
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import random

# 1. Initialization of High Score (Persistent variable)
best_score = 1000 # Initialize high, so the first score is always better

def play_guessing_game():
    """Runs a single round of the guessing game and returns the score."""
    SECRET_NUMBER = random.randint(1, 100)
    current_guesses = 0
    guessed = False
    
    print("\n--- NEW GAME STARTED ---")
    print("I have a new number between 1 and 100.")
    
    while not guessed:
        try:
            guess = int(input("Your guess: "))
        except ValueError:
            print("Invalid input. Please enter a number.")
            continue
            
        current_guesses += 1
        
        if guess == SECRET_NUMBER:
            guessed = True
            print(f"You got it! The number was {SECRET_NUMBER}.")
        elif guess < SECRET_NUMBER:
            print("Too low.")
        else:
            print("Too high.")
            
    return current_guesses

# 2. Game Looping Structure (Main Session Loop)
play_session = True
while play_session:
    # Get the score from the current round
    current_score = play_guessing_game() 
    
    # Access and modify the persistent variable declared outside the function
    global best_score 

    # 3. Comparison and Update
    if current_score < best_score:
        best_score = current_score
        print("\n*** NEW SESSION RECORD! ***")
        
    # 4. Post-Game Reporting
    print(f"Score for this round: {current_score} guesses.")
    print(f"Current session best score: {best_score} guesses.")
    
    # Prompt for next round
    if input("Play again? (y/n): ").strip().lower() != 'y':
        play_session = False

print("Thanks for playing!")

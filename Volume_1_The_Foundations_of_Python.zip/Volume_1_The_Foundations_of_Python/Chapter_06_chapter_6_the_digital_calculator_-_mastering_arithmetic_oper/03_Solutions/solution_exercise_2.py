
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# 1. Define Variables
total_chips = 14789
tray_capacity = 120
pallet_capacity = 900

# 2. Calculate full trays using floor division
full_trays = total_chips // tray_capacity

# 3. Calculate leftover chips using modulus
leftover_chips = total_chips % tray_capacity

# 4. Calculate chips contained in the full trays (for palletization)
chips_for_pallets = full_trays * tray_capacity

# 5. Calculate full pallets from the packaged chips
full_pallets = chips_for_pallets // pallet_capacity

# 6. Calculate remainder chips after palletization
# This is the remainder of the chips_for_pallets when divided by pallet_capacity
pallet_remainder_chips = chips_for_pallets % pallet_capacity

# Print Summary
print(f"Total Chips: {total_chips:,}")
print(f"Tray Capacity: {tray_capacity}")
print("-" * 30)
print(f"Number of Full Trays: {full_trays}")
print(f"Leftover Chips (unpacked): {leftover_chips}")
print("-" * 30)
print(f"Chips used for Pallets: {chips_for_pallets:,}")
print(f"Number of Full Pallets: {full_pallets}")
print(f"Pallet Remainder Chips: {pallet_remainder_chips}")

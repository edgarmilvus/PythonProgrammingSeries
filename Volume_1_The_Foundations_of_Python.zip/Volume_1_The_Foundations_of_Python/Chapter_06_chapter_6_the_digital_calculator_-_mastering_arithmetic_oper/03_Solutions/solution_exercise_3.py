
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# 1. Define Variables
mass_kg = 15.5
velocity_mps = 8.7
half_coefficient = 0.5

# 2. Calculate Kinetic Energy using the coefficient (0.5)
# Exponentiation (**) executes before Multiplication (*)
kinetic_energy_joules = half_coefficient * mass_kg * velocity_mps ** 2

# 3. Calculate Kinetic Energy using 1 / 2 * m * v ** 2
# Python's precedence ensures this works correctly:
# 1. ** (velocity squared)
# 2. / (1 / 2) -> 0.5
# 3. * (left to right)
ke_verification = 1 / 2 * mass_kg * velocity_mps ** 2

# 4. Print Results
print(f"Mass (m): {mass_kg} kg")
print(f"Velocity (v): {velocity_mps} m/s")
print("-" * 30)
print(f"KE (using 0.5 coefficient): {kinetic_energy_joules:.4f} Joules")
print(f"KE (using 1 / 2 division): {ke_verification:.4f} Joules")

# Analysis of Precedence:
# The results match because Python follows the standard mathematical hierarchy:
# 1. Exponentiation (**) is highest and occurs first (v**2).
# 2. Multiplication (*) and Division (/) are equal precedence and execute left-to-right.
# 3. In the verification step, '1 / 2' executes first, yielding 0.5, which is then correctly multiplied by mass and the squared velocity.


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Variables to define:
base_duration_minutes = 10850
scope_creep_percentage = 0.18
efficiency_deduction_hours = 40

# Conversion constants:
MINUTES_PER_HOUR = 60
MINUTES_PER_DAY = 1440 # 24 * 60

# Step 1 & 2: Calculate duration after scope creep and deduction
duration_after_creep = base_duration_minutes * (1 + scope_creep_percentage)
deduction_minutes = efficiency_deduction_hours * MINUTES_PER_HOUR

# We must convert the result to an integer before using floor division/modulus
# as the scope creep calculation introduced a float.
final_duration_minutes = int(duration_after_creep - deduction_minutes)

# Step 3: Convert final duration into Days, Hours, and Minutes using // and %
# Calculate total full days
final_days = final_duration_minutes // MINUTES_PER_DAY

# Calculate remaining minutes after accounting for full days
remaining_minutes_after_days = final_duration_minutes % MINUTES_PER_DAY

# Calculate remaining hours from the leftover minutes
final_hours = remaining_minutes_after_days // MINUTES_PER_HOUR

# Calculate final remaining minutes
final_minutes = remaining_minutes_after_days % MINUTES_PER_HOUR

# Print the final breakdown
print(f"Base Duration: {base_duration_minutes} minutes")
print(f"Deduction: {deduction_minutes} minutes")
print("-" * 30)
print(f"Final Total Duration (Minutes): {final_duration_minutes}")
print(f"Breakdown: {final_days} Days, {final_hours} Hours, {final_minutes} Minutes")

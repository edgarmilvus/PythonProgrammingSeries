
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# 1. Define Initial Variables
gross_income = 5500.00
rent_cost = 1800.00
utility_flat_fee = 150.00
tax_rate = 0.22
savings_contribution_rate = 0.15

# 2. Calculate Taxable Income
total_tax = gross_income * tax_rate

# 3. Calculate Net Income (Post-Tax)
net_income = gross_income - total_tax

# 4. Calculate Savings (15% of net income)
# Note: This calculation correctly uses the result of the previous subtraction step (net_income)
monthly_savings = net_income * savings_contribution_rate

# 5. Calculate Disposable Income
# Subtracting all fixed costs and savings from the net income
disposable_income = net_income - rent_cost - utility_flat_fee - monthly_savings

# 6. Print Results
print(f"Gross Income: ${gross_income:,.2f}")
print("-" * 30)
print(f"Total Tax (22%): ${total_tax:,.2f}")
print(f"Net Income (Post-Tax): ${net_income:,.2f}")
print(f"Monthly Savings (15% of Net): ${monthly_savings:,.2f}")
print(f"Rent Cost: ${rent_cost:,.2f}")
print(f"Utility Fee: ${utility_flat_fee:,.2f}")
print("-" * 30)
print(f"Final Disposable Income: ${disposable_income:,.2f}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# app.py
from flask import Flask


def create_app(test_config=None):
    """Application Factory function. Creates and configures the Flask application instance.

    This function handles environment configuration, default settings, and registers
    initial routes or blueprints.

    Args:
        test_config (dict, optional): Configuration dictionary used for unit testing
            to override default settings (e.g., database path). Defaults to None.

    Returns:
        Flask: The configured Flask application instance.
    """
    # 1. Application Initialization
    # __name__ tells Flask where to look for resources; instance_relative_config
    # enables loading configuration files relative to the instance folder.
    app = Flask(__name__, instance_relative_config=True)

    # 2. Setting Default/Base Configuration
    # These are development defaults that provide necessary keys (like SECRET_KEY)
    # and can be overridden by external config files or test configurations.
    app.config.from_mapping(
        SECRET_KEY='dev',
        DATABASE='development.db',
    )

    # 3. Loading Instance Configuration
    if test_config is None:
        # Load configuration from the instance folder (config.py), if it exists.
        # silent=True prevents errors if the file is missing.
        app.config.from_pyfile('config.py', silent=True)
    else:
        # Load the passed-in test configuration (used during unit testing).
        app.config.from_mapping(test_config)

    # 4. Registering Routes/Blueprints (Simple Example Route)
    # Define a basic endpoint to verify the application is running correctly.
    @app.route('/hello')
    def hello():
        return 'Hello, World!'

    return app

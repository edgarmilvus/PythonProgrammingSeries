
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

def check_honors_eligibility(gpa, sat_score, essay_status, ap_course_passed):
    
    # --- Primary Admission Track (Strict Requirements) ---
    # 1. GPA Check: Must use Chained Comparison (3.7 < GPA <= 4.0)
    gpa_check = 3.7 < gpa <= 4.0
    
    # 2. SAT Check: Must use Chained Comparison (1450 <= SAT <= 1600)
    sat_check = 1450 <= sat_score <= 1600
    
    # 3. Essay Status Check
    essay_check = (essay_status == 'Accepted')
    
    # Primary eligibility requires all three conditions via AND
    primary_eligible = gpa_check and sat_check and essay_check
    
    # --- Secondary Admission Track (Contingency OR) ---
    # 1. Specific GPA OR SAT requirement (Parentheses are essential for OR precedence)
    gpa_or_sat_specific = (gpa == 3.7) or (sat_score == 1450)
    
    # 2. Combined with AP Course requirement (AND)
    secondary_eligible = gpa_or_sat_specific and ap_course_passed
    
    # Final Evaluation: Eligible if Primary OR Secondary track is met
    return primary_eligible or secondary_eligible

# --- Demonstration ---
# Applicant A: Meets Primary Track (3.8 GPA, 1500 SAT, Accepted Essay)
gpa_a, sat_a, essay_a, ap_a = 3.8, 1500, 'Accepted', False
result_a = check_honors_eligibility(gpa_a, sat_a, essay_a, ap_a)
print(f"Applicant A (3.8, 1500, Accepted): {result_a} (Expected: True - Primary Track)")

# Applicant B: Fails Primary, Meets Secondary Track (3.7 GPA, 1400 SAT, Pending Essay, AP Passed)
gpa_b, sat_b, essay_b, ap_b = 3.7, 1400, 'Pending', True
result_b = check_honors_eligibility(gpa_b, sat_b, essay_b, ap_b)
print(f"Applicant B (3.7, 1400, Pending, AP True): {result_b} (Expected: True - Secondary Track)")

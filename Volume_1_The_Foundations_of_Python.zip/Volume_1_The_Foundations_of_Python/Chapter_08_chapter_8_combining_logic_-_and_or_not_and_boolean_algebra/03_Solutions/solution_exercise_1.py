
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

def check_platinum_status(annual_spending, subscription_level, activity_score):
    # --- Requirement 1: Core Financial Requirement (Strict AND) ---
    # Must meet spending threshold AND be a VIP.
    core_financial_met = (annual_spending >= 5000) and (subscription_level == 'VIP')

    # --- Requirement 2: Activity Override Condition (Complex OR/AND) ---
    
    # Override_A: High spending (> $10,000)
    spending_override = (annual_spending > 10000)
    
    # Override_B: Premium or VIP subscription level
    sub_level_override = (subscription_level == 'Premium') or (subscription_level == 'VIP')
    
    # The combined OR condition must be True AND the user must be active.
    # Parentheses are crucial here to ensure (A OR B) is evaluated before AND activity_score.
    override_condition_met = (spending_override or sub_level_override) and activity_score
    
    # Final Qualification: Core met OR Override met
    is_platinum = core_financial_met or override_condition_met
    
    return is_platinum

# --- Testing Scenarios ---
user_a_spending = 5500
user_a_sub = 'VIP'
user_a_active = False
result_a = check_platinum_status(user_a_spending, user_a_sub, user_a_active)
print(f"User A (VIP, $5500, Inactive): {result_a} (Expected: True)") # Core met (5500 >= 5000 AND VIP)

user_b_spending = 12000
user_b_sub = 'Premium'
user_b_active = True
result_b = check_platinum_status(user_b_spending, user_b_sub, user_b_active)
print(f"User B (Premium, $12000, Active): {result_b} (Expected: True)") # Override met (12000 > 10000 OR Premium) AND Active

user_c_spending = 6000
user_c_sub = 'Basic'
user_c_active = True
result_c = check_platinum_status(user_c_spending, user_c_sub, user_c_active)
print(f"User C (Basic, $6000, Active): {result_c} (Expected: False)") # Fails Core. Fails Override (6000 not > 10000 AND not Premium/VIP)

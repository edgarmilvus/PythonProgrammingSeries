
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

def calculate_discount(cart_value, loyal_customer, first_time_buyer, is_electronics_purchase, blacklisted):
    total_discount = 0

    # 1. Standard Discount Base (10%)
    if cart_value >= 100:
        total_discount += 10

    # 2. Loyalty Bonus (5%)
    if loyal_customer:
        total_discount += 5

    # 3. Campaign Modifier (10% bonus if EITHER complex condition is met)
    
    # Condition 1: First-time buyer AND high spending
    cond_1 = first_time_buyer and (cart_value > 200)
    
    # Condition 2: NOT first-time buyer AND electronics purchase
    # Uses 'not' to check the inverse state of first_time_buyer
    cond_2 = (not first_time_buyer) and is_electronics_purchase
    
    # Apply 10% if Condition 1 OR Condition 2 is True
    # Parentheses ensure the OR evaluation is performed on the results of the two AND checks.
    if cond_1 or cond_2:
        total_discount += 10
        
    final_discount_percentage = total_discount

    # 4. Exclusion Rule (Capping using AND)
    # If the calculated discount is > 15% AND the user is blacklisted, cap it.
    if (final_discount_percentage > 15) and blacklisted:
        final_discount_percentage = 15
        
    return final_discount_percentage

# --- Testing Scenarios ---
# Scenario 1: Loyal, $150 cart, not first-time, buying electronics (Expected: 10 + 5 + 10 = 25)
disc_1 = calculate_discount(150, True, False, True, False)
print(f"Scenario 1 Discount (Loyal, Electronics, No Cap): {disc_1}%")

# Scenario 2: Blacklisted first-time buyer, $250 cart, not electronics (Expected: 10 + 0 + 10 = 20, capped at 15)
disc_2 = calculate_discount(250, False, True, False, True)
print(f"Scenario 2 Discount (Blacklisted, High Spend FTB): {disc_2}%")

# Scenario 3: $50 cart value, loyal (Expected: 0 + 5 + 0 = 5)
disc_3 = calculate_discount(50, True, False, False, False)
print(f"Scenario 3 Discount (Low Spend, Loyal Only): {disc_3}%")

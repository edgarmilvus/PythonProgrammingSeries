
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

def recommend_activity(is_sunny, is_raining, is_cold, is_weekend):
    
    # 1. Hiking Recommendation (Strict AND and NOT)
    # Must be sunny AND NOT raining AND NOT cold.
    if is_sunny and (not is_raining) and (not is_cold):
        return 'Go Hiking'

    # 2. Snow Day Preparation (Highly specific critical condition: freezing rain)
    # NOT sunny AND raining AND cold. This should ideally be checked before general indoor activities.
    elif (not is_sunny) and is_raining and is_cold:
        return 'Prepare for Snow Day'

    # 3. Museum Recommendation (OR Flexibility)
    # Requires weekend AND (rain OR cold). Parentheses group the unpleasant weather conditions.
    elif is_weekend and (is_raining or is_cold):
        return 'Go to the Museum'

    # 4. Default Recommendation (Any other scenario)
    else:
        return 'Stay Indoors and Read'

# --- Testing Scenarios ---
# Test 1: Perfect Hiking Weather
print(f"Sunny, Mild, Not Raining, Weekday: {recommend_activity(True, False, False, False)}") # Expected: Go Hiking

# Test 2: Freezing Rain (Snow Day condition)
print(f"Cloudy, Cold, Raining, Weekday: {recommend_activity(False, True, True, False)}") # Expected: Prepare for Snow Day

# Test 3: Cold Weekend (Museum condition)
print(f"Cloudy, Cold, Not Raining, Weekend: {recommend_activity(False, False, True, True)}") # Expected: Go to the Museum

# Test 4: Default (Cloudy, Mild, Weekday)
print(f"Cloudy, Mild, Not Raining, Weekday: {recommend_activity(False, False, False, False)}") # Expected: Stay Indoors and Read

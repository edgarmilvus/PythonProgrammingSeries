
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

SPECIAL_CHARS = "!@#$%^&*()"

def check_password_strength(password):
    failed_requirements = []

    # 1. Length Requirement (>= 12)
    is_long_enough = len(password) >= 12
    if not is_long_enough:
        failed_requirements.append("Minimum 12 characters.")

    # 2. Case Requirements (uses any() with generator expression for efficiency)
    has_upper = any(c.isupper() for c in password)
    if not has_upper:
        failed_requirements.append("At least one uppercase letter.")
    
    has_lower = any(c.islower() for c in password)
    if not has_lower:
        failed_requirements.append("At least one lowercase letter.")

    # 3. Numeric Requirement
    has_digit = any(c.isdigit() for c in password)
    if not has_digit:
        failed_requirements.append("At least one digit.")

    # 4. Special Character Requirement
    has_special = any(c in SPECIAL_CHARS for c in password)
    if not has_special:
        failed_requirements.append(f"At least one special character: {SPECIAL_CHARS}")

    # 5. Combined Logic (Strict AND of all flags)
    is_strong = (is_long_enough and has_upper and has_lower and 
                 has_digit and has_special)

    print(f"\n--- Password Check for '{password}' ---")
    if is_strong:
        print("Password Strength: STRONG")
    else:
        print("Password Strength: WEAK")
        print("Failed Requirements:")
        for failure in failed_requirements:
            print(f" - {failure}")
    
    return is_strong

# Main execution loop for user input
# Test Case 1 (Weak)
check_password_strength("Short1!") # Fails length, upper, lower, digit

# Test Case 2 (Strong)
check_password_strength("MyStrongP@ssw0rd") 

# Test Case 3 (Weak, fails special char)
check_password_strength("MyStrongPswd1234")

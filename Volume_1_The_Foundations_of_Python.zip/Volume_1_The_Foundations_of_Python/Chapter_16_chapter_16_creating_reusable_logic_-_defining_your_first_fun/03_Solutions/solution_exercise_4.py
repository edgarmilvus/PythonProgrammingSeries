
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Example User Data Structure (for testing)
sample_data_1 = [
    {'name': 'Alice', 'status': 'active'},
    {'name': 'Bob', 'status': 'inactive'}
]

sample_data_2 = [
    {'name': 'Charlie', 'status': 'active'},
    {'name': 'Dana', 'status': 'admin'},
    {'name': 'Eve', 'status': 'active'}
]

def check_for_admin(user_list):
    """Checks a list of user dictionaries for the presence of an 'admin' status."""
    
    # Iterate through each user dictionary in the list
    for user in user_list:
        # Use .get() for safe key access, checking if the status matches 'admin'
        if user.get('status') == 'admin':
            # Efficiency: If found, immediately return True and exit the function
            return True
    
    # If the loop completes without finding an admin, return False
    return False

# Example Execution
result_1 = check_for_admin(sample_data_1)
result_2 = check_for_admin(sample_data_2)
print(f"Result 1 (No Admin): {result_1}")
print(f"Result 2 (Admin Found): {result_2}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

MAX_ATTEMPTS = 4
CORRECT_PASSWORD = "Python3000"
attempts_count = 0
login_success = False

print(f"--- Secure Login Simulation (Max Attempts: {MAX_ATTEMPTS}) ---")

while attempts_count < MAX_ATTEMPTS:
    # Increment attempt count immediately
    attempts_count += 1
    
    # In a real scenario, use: user_input = input(f"Attempt {attempts_count}/{MAX_ATTEMPTS}: Enter password: ")
    # Using a placeholder for automated testing:
    if attempts_count == 3:
        user_input = CORRECT_PASSWORD # Simulate successful attempt on 3rd try
    else:
        user_input = "wrong_password_" + str(attempts_count)
    
    print(f"Attempt {attempts_count}/{MAX_ATTEMPTS} entered: '{user_input}'")

    if user_input == CORRECT_PASSWORD:
        login_success = True
        print("\nSUCCESS: Access Granted.")
        # Terminate immediately upon success
        break
    
    # If incorrect, print status and use continue (optional but reinforces structure)
    if attempts_count < MAX_ATTEMPTS:
        print(f"FAILURE: Incorrect password. {MAX_ATTEMPTS - attempts_count} attempts remaining.")
        continue
        
# Check why the loop terminated
if not login_success and attempts_count == MAX_ATTEMPTS:
    print("\nACCOUNT LOCKED: Maximum failed attempts reached.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

def generate_signature(name, company, title='Employee', phone_number='N/A'):
    """
    Generates an email signature block. Name and company are mandatory.
    Title and phone_number have default values.
    """
    signature = f"{name}\n"
    signature += f"{title}\n"
    signature += f"{company}\n"
    signature += f"Phone: {phone_number}"
    return signature

# Test Case 1: Standard Keyword Call (non-standard order, overriding all defaults)
sig_1 = generate_signature(
    phone_number="555-9000",
    company="Global Solutions Inc.",
    name="Dr. Evelyn Reed",
    title="Chief Architect"
)

# Test Case 2: Using only mandatory arguments (relying on defaults for title/phone)
sig_2 = generate_signature(name="John Doe", company="Acme Corp")

# Test Case 3: Missing mandatory argument (must raise TypeError)
# The following call would raise: TypeError: generate_signature() missing 2 required positional arguments: 'name' and 'company'
# try:
#     sig_3 = generate_signature(title="Junior", phone_number="123-4567")
# except TypeError:
#     pass 

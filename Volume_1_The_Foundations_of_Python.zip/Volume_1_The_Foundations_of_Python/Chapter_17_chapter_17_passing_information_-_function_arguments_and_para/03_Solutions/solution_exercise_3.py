
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

def get_connection_string(database_name, host='localhost', port=5432, timeout_seconds=30):
    """
    Generates a formatted database connection string using defaults for configuration.
    database_name is mandatory.
    """
    return f"DB: {database_name} | Host: {host} | Port: {port} | Timeout: {timeout_seconds}s"

# Method A: Mandatory argument only
conn_a = get_connection_string("user_data_prod")
# Output: DB: user_data_prod | Host: localhost | Port: 5432 | Timeout: 30s

# Method B: Positional override (overriding host and port)
conn_b = get_connection_string("reporting_db", "192.168.1.1", 8080)
# Output: DB: reporting_db | Host: 192.168.1.1 | Port: 8080 | Timeout: 30s

# Method C: Keyword override
conn_c = get_connection_string("test_sandbox", timeout_seconds=5, host="dev.server.net")
# Output: DB: test_sandbox | Host: dev.server.net | Port: 5432 | Timeout: 5s


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Define Variable (Test with 85 - a boundary condition)
current_temp = 85

print(f"Current Temperature: {current_temp}°F")

# Implementing the advisory system using a sequential if/elif chain
if current_temp >= 100:
    # Level 1
    print("ALERT: Extreme Heat Warning. Stay Hydrated.")
elif current_temp >= 85:
    # Level 2 (We know it's less than 100 here)
    print("Advisory: Heat Advisory. Limit Outdoor Activity.")
elif current_temp >= 60:
    # Level 3 (We know it's less than 85 here)
    print("Advisory: Mild/Ideal Weather Conditions.")
elif current_temp >= 33:
    # Level 4 (We know it's less than 60 here)
    print("Advisory: Cold Advisory. Dress Warmly.")
elif current_temp == 32:
    # Level 5 (Specific Freezing point)
    print("WARNING: Freezing Warning. Icy Conditions Possible.")
else:
    # Level 6 (This handles anything 31 or below)
    print("ALERT: Extreme Cold Warning. Seek Shelter Immediately.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Define Variables (Test Case: Invalid data - negative quantity)
item_name = "Widget Pro"
item_quantity = -3
item_price = 60

print(f"Categorizing Item: {item_name} (Qty: {item_quantity}, Price: ${item_price})")

# 1. Validation Priority Check using 'or'
if item_quantity <= 0 or item_price <= 0:
    print("DATA ERROR: Invalid quantity or price detected. Cannot categorize.")

# 2. In-Stock Categorization (Assumes data is valid if the first 'if' was False)
elif item_price > 75:
    print("Category: Premium Inventory (Price > $75)")
elif item_price >= 25:
    # Implicitly means 25 <= price <= 75
    print("Category: Standard Inventory ($25 - $75)")
else:
    # Implicitly means 0 < price < 25
    print("Category: Budget Inventory (Price < $25)")

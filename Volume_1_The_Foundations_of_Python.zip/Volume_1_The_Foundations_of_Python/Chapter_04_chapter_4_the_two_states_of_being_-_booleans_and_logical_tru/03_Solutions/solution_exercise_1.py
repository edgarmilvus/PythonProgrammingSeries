
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# 1. Define Variables (Using values that should result in True for testing)
applicant_age = 22
test_score = 95

# --- Requirements 2 & 3: Chained Comparisons ---

# 2. Age Constraint: Strictly older than 18 AND no older than 25 (18 < age <= 25)
age_ok = 18 < applicant_age <= 25

# 3. Score Constraint: Strictly greater than 85 AND less than or equal to 100 (85 < score <= 100)
score_ok = 85 < test_score <= 100

# 4. Final Eligibility: Must meet BOTH criteria
is_eligible = age_ok and score_ok

# 5. Output and Testing (Test Case 1: Expected True)
print(f"Applicant Age: {applicant_age}, Test Score: {test_score}")
print(f"Age OK: {age_ok}")
print(f"Score OK: {score_ok}")
print(f"Final Eligibility: {is_eligible}")

# --- Testing Boundary Conditions ---
# Test Case 2: Age boundary failure (Age=18)
applicant_age = 18
test_score = 95
age_ok_boundary = 18 < applicant_age <= 25 # Expected False
is_eligible_boundary = age_ok_boundary and (85 < test_score <= 100)
print(f"\nTest 2 (Age 18): Eligibility = {is_eligible_boundary}") # Output: False

# Test Case 3: Score boundary success (Score=100)
applicant_age = 20
test_score = 100
age_ok_boundary = 18 < applicant_age <= 25 # Expected True
score_ok_boundary = 85 < test_score <= 100 # Expected True
is_eligible_boundary = age_ok_boundary and score_ok_boundary
print(f"Test 3 (Score 100): Eligibility = {is_eligible_boundary}") # Output: True

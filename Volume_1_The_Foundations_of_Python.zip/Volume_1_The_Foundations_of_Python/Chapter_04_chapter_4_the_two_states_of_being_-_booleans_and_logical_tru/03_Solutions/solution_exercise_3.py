
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# 1. Define Variables
username = "sys_admin"
password = "SecureP@ss"
banned_user = "sys_admin"

# --- Requirements 2, 3, 4: Using the NOT operator defensively ---

# 2. Empty Check: The password must not be empty.
# Check if it IS empty, then negate.
is_empty = (password == "")
password_is_present = not is_empty

# 3. Identity Check: The username must not be the banned user.
# Check if it IS banned, then negate.
is_banned = (username == banned_user)
user_is_allowed = not is_banned

# 4. Length Check: Username and password lengths must not be equal.
# Check if lengths ARE equal, then negate.
lengths_are_equal = (len(username) == len(password))
length_mismatch = not lengths_are_equal

# 5. Final Acceptance: All three conditions must be True.
login_accepted = password_is_present and user_is_allowed and length_mismatch

# Initial Output (Should be False because "sys_admin" is banned)
print(f"User: {username}, Pass Length: {len(password)}, Banned User: {banned_user}")
print(f"Password Present: {password_is_present}") # True
print(f"User Allowed: {user_is_allowed}")         # False (Failure Point)
print(f"Length Mismatch: {length_mismatch}")       # True (8 != 12)
print(f"Final Login Accepted (Initial Test): {login_accepted}") # Expected: False

# --- Testing Case: Change variables to pass the identity check ---
username = "regular_user"
user_is_allowed_test = not (username == banned_user) # True
login_accepted_test = password_is_present and user_is_allowed_test and length_mismatch
print(f"\nFinal Login Accepted (Regular User Test): {login_accepted_test}") # Expected: True

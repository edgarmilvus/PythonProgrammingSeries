
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# 1. Define Customer Data (Initial state: Expected True via Rule B)
order_total = 155.50
is_premium_member = True
product_category = "Apparel"
is_first_purchase = False

# 2, 3, 4, 5. Final Calculation: Combining Rule A OR Rule B OR Rule C
max_discount_eligible = (
    # Rule A: High Value Order (Simple comparison)
    (order_total > 200.00)
    
    or
    
    # Rule B: Loyalty & Category (AND required)
    (is_premium_member and (product_category != "Electronics"))
    
    or
    
    # Rule C: New Customer Incentive (AND required, includes NOT and Chained Comparison)
    ((not is_premium_member) and is_first_purchase and (50.00 <= order_total < 100.00))
)

print(f"Order Total: {order_total}, Premium: {is_premium_member}, Category: {product_category}")
print(f"Max Discount Eligible: {max_discount_eligible}") # Expected: True (due to Rule B)

# --- Visualization Challenge and Explanation ---
"""
Analysis of Expression Structure and Precedence:

The expression is structured as: (Rule A) OR (Rule B) OR (Rule C).

1. Rule A: (order_total > 200.00)
2. Rule B: (is_premium_member and (product_category != "Electronics"))
3. Rule C: ((not is_premium_member) and is_first_purchase and (50.00 <= order_total < 100.00))

Python's Operator Precedence Hierarchy: NOT > AND > OR.

- Rule C required the use of 'not' (highest precedence) before the 'and' operations.
- Rules B and C primarily use the 'and' operator. Since 'and' has higher precedence than 'or', the components within Rule B and Rule C would naturally be grouped together by the interpreter even without the inner parentheses (e.g., in Rule B, the 'and' would execute before the outer 'or').
- However, parentheses were used extensively for clarity and robustness. They explicitly define the boundaries of each independent rule (A, B, and C) before they are combined by the final 'or' operators. This ensures that the complex criteria of Rule C (combining NOT, AND, and the chained comparison) are evaluated entirely as a single unit before being considered as an alternative path to qualification.
"""

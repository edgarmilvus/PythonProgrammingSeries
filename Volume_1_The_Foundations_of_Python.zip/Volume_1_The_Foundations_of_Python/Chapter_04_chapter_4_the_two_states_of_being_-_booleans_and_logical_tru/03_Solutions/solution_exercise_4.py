
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# 1. Simulate Path Retrieval (Test A: Unsafe - Root)
current_path = "/"

# 2. Define Danger Zones
root_dir = "/"
temp_dir = "/tmp"

# --- Requirements 3, 4, 5: Defining Unsafe Conditions ---

# 3. Safety Condition 1 (Root Check)
is_root = (current_path == root_dir)

# 4. Safety Condition 2 (Temp Check) - Uses string method .startswith()
is_temp = current_path.startswith(temp_dir)

# 5. Safety Condition 3 (Hidden Check) - Uses the 'in' operator for substring containment
is_hidden = ".hidden" in current_path

# 6. Unsafe Calculation: Any single danger condition makes the zone unsafe (OR logic)
is_unsafe_zone = is_root or is_temp or is_hidden

# 7. Final Safety Switch: Only proceed if NOT unsafe
proceed_with_deletion = not is_unsafe_zone

# Output for Test A
print(f"Path: '{current_path}'")
print(f"Is Unsafe Zone (A): {is_unsafe_zone}")
print(f"Proceed with Deletion (A): {proceed_with_deletion}") # Expected: False

# --- Interactive Testing ---

# Test B: current_path = "/tmp/logs/cleanup" (Should result in False due to is_temp)
current_path = "/tmp/logs/cleanup"
is_unsafe_zone_B = (current_path == root_dir) or current_path.startswith(temp_dir) or (".hidden" in current_path)
proceed_with_deletion_B = not is_unsafe_zone_B
print(f"\nPath: '{current_path}'")
print(f"Proceed with Deletion (B): {proceed_with_deletion_B}") # Expected: False

# Test C: current_path = "/usr/local/data" (Should result in True)
current_path = "/usr/local/data"
is_unsafe_zone_C = (current_path == root_dir) or current_path.startswith(temp_dir) or (".hidden" in current_path)
proceed_with_deletion_C = not is_unsafe_zone_C
print(f"\nPath: '{current_path}'")
print(f"Proceed with Deletion (C): {proceed_with_deletion_C}") # Expected: True


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# Initial Variables
A = 100
B = 100.0
C = 99
D = "100"
E = "Apple"
F = "apple"

# 1. Float vs. Integer Equality: Does Python consider the integer A to be equal to the float B?
# prediction = True
print(f"1. A == B: {A == B}")

# 2. String vs. Integer Equality: Does Python consider the string D to be equal to the integer A?
# prediction = False
print(f"2. D == A: {D == A}")

# 3. Greater Than or Equal To: Is A greater than or equal to C?
# prediction = True
print(f"3. A >= C: {A >= C}")

# 4. Strict Inequality (String Case): Is the string E strictly less than the string F?
# prediction = True
print(f"4. E < F: {E < F}")

# 5. Strict Inequality (Numerical): Is B strictly less than A?
# prediction = False
print(f"5. B < A: {B < A}")

# 6. Inequality Check: Is the integer C not equal to the float B?
# prediction = True
print(f"6. C != B: {C != B}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Define the product details here
product_name = "Laptop Pro X"
stock_quantity = 15
product_category = "Electronics"

# 1. Critical Stock Check: strictly less than 10 (< 10)
is_low_stock = stock_quantity < 10

# 2. Specific Product Match (Case sensitive test): exactly equal (==)
is_target_product = product_name == "Laptop Pro X"

# 3a. Exclusion Check (Check against 'Apparel'): Not equal to "Apparel" (!=)
is_not_apparel = product_category != "Apparel"

# 3b. Exclusion Check (Check against 'Clothing'): Not equal to "Clothing" (!=)
is_not_clothing_category = product_category != "Clothing"

# 4. Zero Stock Alert: exactly equal to zero (== 0)
is_out_of_stock = stock_quantity == 0

# Print the results to verify the boolean values
print(f"Product: {product_name}, Stock: {stock_quantity}, Category: {product_category}")
print(f"Low Stock? (Stock < 10): {is_low_stock}")
print(f"Is Target Product? (Name == 'Laptop Pro X'): {is_target_product}")
print(f"Not Apparel? (Category != 'Apparel'): {is_not_apparel}")
print(f"Not Clothing? (Category != 'Clothing'): {is_not_clothing_category}")
print(f"Out of Stock? (Stock == 0): {is_out_of_stock}")

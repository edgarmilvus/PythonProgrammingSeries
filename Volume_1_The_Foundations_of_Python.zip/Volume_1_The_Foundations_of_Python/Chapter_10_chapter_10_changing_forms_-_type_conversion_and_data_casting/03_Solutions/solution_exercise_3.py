
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

def standardize_temperature(raw_temp_str):
    
    # Check for minimal length before slicing
    if len(raw_temp_str) < 2:
        print("ERROR: Input string too short or empty.")
        return None
        
    # 1. Data Extraction
    unit = raw_temp_str[-1].upper()
    raw_value_str = raw_temp_str[:-1]
    
    kelvin_temp = None
    
    # 2. Type Conversion and Error Handling
    try:
        temp_value = float(raw_value_str)
        
    except ValueError:
        print(f"ERROR: ValueError when converting '{raw_value_str}' to float.")
        return None
        
    # 3. Conditional Casting and Calculation
    
    # C to K: K = C + 273.15
    # F to K: K = (F - 32) * (5/9) + 273.15
    
    if unit == 'C':
        kelvin_temp = temp_value + 273.15
        
    elif unit == 'F':
        # Using 5/9 for precise float division
        kelvin_temp = (temp_value - 32) * (5/9) + 273.15
        
    else:
        print(f"ERROR: Unknown unit '{unit}' detected in input.")
        return None
        
    return kelvin_temp

# print(f"78.5F -> {standardize_temperature('78.5F'):.2f} K")
# print(f"26.0C -> {standardize_temperature('26.0C'):.2f} K")
# print(f"ERRORDATA -> {standardize_temperature('ERRORDATA')}")

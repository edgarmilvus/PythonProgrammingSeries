
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

def predict_coercion_results():
    results = {}
    
    # 1. Casting to int
    a_bool = True
    results['a_int_result'] = int(a_bool) 
    
    b_float = 99.99
    results['b_int_result'] = int(b_float) 
    
    c_string = "100"
    results['c_int_result'] = int(c_string) 
    
    d_string_float = "100.0"
    try:
        int(d_string_float)
    except ValueError as e:
        results['d_error_type'] = type(e).__name__ 
        
    # 2. Casting to bool (Truthiness)
    e_empty_string = ""
    results['e_bool_result'] = bool(e_empty_string) 
    
    f_non_empty_list = [0]
    results['f_bool_result'] = bool(f_non_empty_list) 
    
    g_zero = 0
    results['g_bool_result'] = bool(g_zero) 
    
    h_none = None
    results['h_bool_result'] = bool(h_none) 
    
    # 3. Casting to str
    i_list = [1, 2, 3]
    results['i_str_result'] = str(i_list) 
    
    j_integer = 456
    results['j_str_result'] = str(j_integer) 
    
    return results

# import pprint; pprint.pprint(predict_coercion_results())

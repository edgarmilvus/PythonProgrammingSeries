
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

def normalize_inventory(data):
    normalized_data = []
    
    for item in data:
        item_id = item['item_id']
        raw_price = item['raw_price']
        raw_quantity = item['raw_quantity']
        
        normalized_price = 0.0
        normalized_quantity = 0
        
        # --- 1. Price Conversion (Float) ---
        try:
            # Clean the price string: remove currency symbols and commas
            cleaned_price_str = raw_price.strip().replace('$', '').replace('€', '').replace(',', '')
            normalized_price = float(cleaned_price_str)
            
        except ValueError:
            print(f"REPORT: Price conversion failed for Item ID {item_id}. Raw value: '{raw_price}'. Defaulting to 0.0.")
            
        # --- 2. Quantity Conversion (Integer) ---
        try:
            # Attempt 1: Direct integer conversion (handles '50', fails on '12.0', '3.5', 'PENDING')
            normalized_quantity = int(raw_quantity)
                
        except ValueError:
            # This block handles text errors and float string errors ('12.0', '3.5')
            try:
                # Attempt 2: Convert to float to check if it's a numeric error
                temp_float = float(raw_quantity)
                
                # Check if the float is a whole number (e.g., 12.0)
                if temp_float == int(temp_float):
                    normalized_quantity = int(temp_float)
                else:
                    # Fractional quantity (e.g., 3.5) fails the rule
                    print(f"REPORT: Quantity conversion failed for Item ID {item_id}. Raw value: '{raw_quantity}' (Fractional). Defaulting to 0.")
                    normalized_quantity = 0 
                    
            except ValueError:
                # This catches non-numeric text like 'PENDING'
                print(f"REPORT: Quantity conversion failed for Item ID {item_id}. Raw value: '{raw_quantity}' (Text). Defaulting to 0.")
                normalized_quantity = 0

        # Append the normalized result
        normalized_data.append({
            'item_id': item_id,
            'price': normalized_price,
            'quantity': normalized_quantity
        })
        
    return normalized_data

inventory_data = [
    {'item_id': 'A101', 'raw_price': '$15.99', 'raw_quantity': '50'},
    {'item_id': 'B202', 'raw_price': '250,000', 'raw_quantity': '12.0'},
    {'item_id': 'C303', 'raw_price': 'N/A', 'raw_quantity': '100'},
    {'item_id': 'D404', 'raw_price': '99.99', 'raw_quantity': 'PENDING'},
    {'item_id': 'E505', 'raw_price': '1000', 'raw_quantity': '3.5'}
]
# normalize_inventory(inventory_data)

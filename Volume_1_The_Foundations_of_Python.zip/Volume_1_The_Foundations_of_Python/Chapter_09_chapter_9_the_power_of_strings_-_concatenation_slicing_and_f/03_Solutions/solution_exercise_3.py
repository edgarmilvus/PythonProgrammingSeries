
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

project_name = "Quantum Leap Initiative"
revenue = 125000.758
costs = 45123.0
report_week = 37

# 1. Calculation
profit = revenue - costs

TOTAL_WIDTH = 40
LABEL_WIDTH = 18 # Fixed width for labels
VALUE_WIDTH = TOTAL_WIDTH - LABEL_WIDTH - 1 # 40 - 18 - 1 (for the $) = 21

# 2. Report Header
print(f"--- Weekly Financial Summary ---")
print(f"Project: {project_name}")
print(f"Reporting Week: {report_week}\n")

# 3. Data Alignment (Using f-string format specifiers)

# Revenue Line: Label left-aligned (<18), Value right-aligned (>21), thousands (,) and precision (.2f)
revenue_line = f"{'Project Revenue:':<18} ${revenue:>{VALUE_WIDTH},.2f}"

# Costs Line
costs_line = f"{'Operational Costs:':<18} ${costs:>{VALUE_WIDTH},.2f}"

# Separator for profit
separator = "-" * TOTAL_WIDTH

# Profit Line
profit_line = f"{'NET PROFIT:':<18} ${profit:>{VALUE_WIDTH},.2f}"

# 4. Final Output
print(revenue_line)
print(costs_line)
print(separator)
print(profit_line)
print(separator)

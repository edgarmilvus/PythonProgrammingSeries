
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# The example input for testing: PTOIFNUSNHY
scrambled_text = input("Enter the scrambled message (e.g., PTOIFNUSNHY): ").upper().replace(" ", "")

# 1. Determine the split point
# Part A (Even Indices) is always ceil(len / 2).
split_index = (len(scrambled_text) + 1) // 2

# 2. Extraction 1 (Part A - Even Indices of Original)
# This is the first half of the scrambled text.
part_A = scrambled_text[:split_index] 

# 3. Extraction 2 (Part B - Decrypted Odd Indices)
# Extract the second half (the reversed odd indices)
part_B_raw = scrambled_text[split_index:] 

# Apply negative step slicing [::-1] to reverse Part B back to its original sequence
part_B = part_B_raw[::-1] 

# 4. Decryption and Reassembly (Concatenation as required by the prompt)
reconstructed_message = part_A + part_B

# 5. Final Output
print("\n--- Decryption Analysis ---")
print(f"Scrambled Input: {scrambled_text}")
print(f"Part A (Even Indices, 0:split): {part_A}")
print(f"Part B Raw (Reversed Odd Indices): {part_B_raw}")
print(f"Part B Decrypted (Reverse Slice): {part_B}")
print(f"Reconstructed Message (Concatenation): {reconstructed_message}")

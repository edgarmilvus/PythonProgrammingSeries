
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import re

# 1. Input Acquisition
user_input = input("Enter a word or phrase to check for palindrome status: ")

# 2. Preprocessing (Normalization)
# Convert to lowercase and remove spaces
normalized_string = user_input.lower().replace(" ", "")
# Note: For strict adherence to the problem, we assume only spaces need removal.

# 3. String Reversal using extended slicing [::-1]
reversed_string = normalized_string[::-1]

# 4. Comparison and Output
is_palindrome = normalized_string == reversed_string

print(f"\n--- Palindrome Check ---")
print(f"Original Input: '{user_input}'")
print(f"Normalized String: '{normalized_string}'")
print(f"Reversed String: '{reversed_string}'")

if is_palindrome:
    print(f"Result: SUCCESS! '{user_input}' IS a palindrome.")
else:
    print(f"Result: FAIL. '{user_input}' is NOT a palindrome.")

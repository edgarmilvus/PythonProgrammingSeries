
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Initial Setup Code
TOTAL_INVENTORY = 100

def process_order_shadowed(items_sold):
    # This line causes shadowing: The interpreter sees an assignment,
    # making TOTAL_INVENTORY local to this function.
    # It attempts to read the global TOTAL_INVENTORY to calculate the right side,
    # but since it's an assignment, it treats the variable as local,
    # leading to an UnboundLocalError if the right side used the local variable.
    # However, in this specific setup (TOTAL_INVENTORY = TOTAL_INVENTORY + 5), 
    # it might raise an error depending on the Python version/context, but here 
    # we simulate the intent of creating a local copy. Let's simplify the demonstration 
    # of shadowing by just assigning a local value:
    
    # Corrected demonstration of shadowing: Assignment creates a local variable
    local_inventory_copy = TOTAL_INVENTORY # Read the global
    TOTAL_INVENTORY = local_inventory_copy + 5 # This assignment creates the local shadow
    
    print(f"Local Inventory inside function (before subtraction): {TOTAL_INVENTORY}")
    TOTAL_INVENTORY -= items_sold # Operates on the local shadow
    print(f"Local Inventory inside function (after subtraction): {TOTAL_INVENTORY}")

# Demonstrate the shadowing effect
print(f"Global Inventory before shadowing test: {TOTAL_INVENTORY}")
process_order_shadowed(10)
print(f"Global Inventory after shadowing test: {TOTAL_INVENTORY}") # Should still be 100

# FIX: Redefine the function process_order_fixed() here, removing the shadowing line.
def process_order_fixed(items_sold):
    """
    Reads the global inventory correctly because no assignment occurs, 
    but cannot modify it globally without the 'global' keyword.
    """
    # The function now reads the global TOTAL_INVENTORY implicitly.
    print(f"Fixed function reads global inventory: {TOTAL_INVENTORY}")
    # Note: If we tried TOTAL_INVENTORY -= items_sold here, it would still 
    # create a local variable and fail to update the global state.

print("\n--- Running Fixed Function (Read-Only) ---")
process_order_fixed(10)
print(f"Global Inventory remains: {TOTAL_INVENTORY}")

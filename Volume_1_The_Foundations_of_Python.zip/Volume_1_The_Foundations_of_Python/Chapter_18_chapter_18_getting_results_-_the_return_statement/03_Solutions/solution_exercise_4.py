
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

def controlled_metrics(prices, get_detailed=True):
    """
    Calculates metrics based on price data, controlling the return structure
    based on input length and a detailed flag.
    """
    
    # 1. Input Validation Check (Guard Clause)
    if len(prices) < 5:
        # Return None immediately if data is insufficient
        return None
        
    # Calculate core metrics needed regardless of return type
    max_price = max(prices)
    min_price = min(prices)
    count = len(prices)
    
    # 2. Detailed Return (Dictionary)
    if get_detailed:
        return {
            'max_price': max_price, 
            'min_price': min_price, 
            'count': count
        }
    
    # 3. Simplified Return (Tuple)
    # If get_detailed is False, this block executes
    else:
        return (max_price, min_price)

# Example Calls:
# result_none = controlled_metrics([10, 20])
# result_dict = controlled_metrics([10, 20, 30, 40, 50], get_detailed=True)
# result_tuple = controlled_metrics([10, 20, 30, 40, 50], get_detailed=False)

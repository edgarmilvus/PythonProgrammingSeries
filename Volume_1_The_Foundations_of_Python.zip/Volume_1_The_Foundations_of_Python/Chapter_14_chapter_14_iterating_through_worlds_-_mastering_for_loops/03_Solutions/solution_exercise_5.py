
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

TEMPLATES = [
    "Welcome, {{ username }}! Your current balance is {{ balance }}.",
    "Error: {{ error_code }} occurred.",
    "Simple message.",
    "Missing data for {{ item_id }} and {{ item_name }}.",
]
AVAILABLE_VARIABLES = ["username", "balance", "error_code"]
complete_template_count = 0

print("--- Template Validation Start ---")

# 2. Template Variable Extraction (Outer Loop)
for template in TEMPLATES:
    print(f"\nValidating Template: '{template[:30]}...'")
    
    current_template_is_complete = True
    search_start_index = 0
    
    # Inner loop structure to find multiple variables in a single string
    while True:
        start_marker = template.find("{{", search_start_index)
        
        if start_marker == -1:
            break # No more variables found
            
        end_marker = template.find("}}", start_marker + 2)
        
        if end_marker == -1:
            # Malformed template
            current_template_is_complete = False
            break
            
        # Extract and clean the variable name
        raw_variable = template[start_marker + 2: end_marker]
        variable_name = raw_variable.strip()
        
        # 4. Variable Validation (Check against available list)
        if variable_name not in AVAILABLE_VARIABLES:
            print(f"!!! WARNING: Required variable '{variable_name}' is MISSING. Aborting template validation.")
            
            # Set flag and break the inner 'while' loop. 
            # This simulates the effect of 'continue' on the outer 'for' loop's flow.
            current_template_is_complete = False
            break 
        else:
            print(f"[OK] Variable '{variable_name}' found.")
            
        search_start_index = end_marker + 2
        
    # 5. Tracking Complete Templates
    if current_template_is_complete:
        complete_template_count += 1
        print("Template passed validation.")
    else:
        print("Template failed validation.")
        
# 6. Final Output
print("\n--- Validation Summary ---")
print(f"Total templates successfully validated (Complete): {complete_template_count}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
import random

MAX_LINES = 500
LOG_FILENAME = "system_log.txt"

# 1. Setup and Data Generation
# Create a simulated log file with 1000 lines
print(f"Generating simulated log file: {LOG_FILENAME}...")
try:
    with open(LOG_FILENAME, 'w') as f:
        for i in range(1, 1001):
            # Insert "FATAL" errors roughly 5% of the time
            if i % 20 == 0:
                f.write(f"[{i:04d}] ERROR: FATAL System failure detected.\n")
            else:
                f.write(f"[{i:04d}] STATUS: Routine check.\n")
    print("Log file generated (1000 lines).")
except IOError:
    print("Error creating file.")
    exit()

# 3. Initialization
line_counter = 0
fatal_error_count = 0

print(f"\n--- Starting Log Analysis (Max {MAX_LINES} lines) ---")

# 2. Efficient File Iteration
# Comment: Iterating directly over the file object ('f') reads data line-by-line, 
# acting as a generator. This prevents loading the entire 1000-line file into memory 
# at once, conserving resources for large files.
with open(LOG_FILENAME, 'r') as f:
    for line in f:
        # 4. The break Mechanism (Throttling check)
        # Check if we have processed the maximum allowed lines
        if line_counter >= MAX_LINES:
            print(f"Processing limit of {MAX_LINES} lines reached.")
            break

        # 5. Error Detection
        if "FATAL" in line:
            fatal_error_count += 1

        # 6. Counter Maintenance
        line_counter += 1

# 7. Final Report
print("\n--- Analysis Report ---")
print(f"Total lines processed: {line_counter}")
print(f"Total FATAL errors found within processed segment: {fatal_error_count}")

# Cleanup
if os.path.exists(LOG_FILENAME):
    os.remove(LOG_FILENAME)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

PRODUCT_NAMES = ["Widget-A", "Gearbox-B", "Sensor-C", "Cable-D", "Housing-E"]
STOCK_LEVELS = [45, 8, 110, 3, 22]
UNIT_COSTS = [12.50, 200.00, 5.00, 1.25, 35.00]
REORDER_THRESHOLD = 10
total_inventory_value = 0.0

# 2. Indexed Iteration: Use range(len()) to get indices for parallel access
for i in range(len(PRODUCT_NAMES)):
    # Retrieve current item details using the index 'i'
    name = PRODUCT_NAMES[i]
    stock = STOCK_LEVELS[i]
    cost = UNIT_COSTS[i]

    # 3. Critical Stock Check
    if stock <= REORDER_THRESHOLD:
        print(f"!!! WARNING: Reorder {name}. Current stock is critically low: {stock} units.")

    # 4. Total Value Calculation (Stock Level * Unit Cost)
    item_value = stock * cost
    total_inventory_value += item_value

# 5. Output Final Total Value
print("\n--- Inventory Audit Complete ---")
print(f"Total Inventory Monetary Value: ${total_inventory_value:,.2f}")

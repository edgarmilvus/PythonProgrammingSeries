
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from flask import Flask, jsonify, request
from typing import List, Dict, Any

app = Flask(__name__)

# Initial data store (simulating a database)
BOOKS: List[Dict[str, Any]] = [
    {"id": 1, "title": "The Silent Planet", "author": "C.S. Lewis", "year": 1938},
    {"id": 2, "title": "Foundation", "author": "Isaac Asimov", "year": 1951},
    {"id": 3, "title": "Dune", "author": "Frank Herbert", "year": 1965}
]
next_book_id = 4 # Counter for new resources

@app.route('/api/books', methods=['GET', 'POST'])
def handle_books():
    # Exercise 1 Implementation (GET)
    if request.method == 'GET':
        # Use jsonify to serialize the list into a JSON array
        # Explicitly return 200 OK status
        return jsonify(BOOKS), 200
    
    # Placeholder for POST logic (completed in E3/E4)
    # ...

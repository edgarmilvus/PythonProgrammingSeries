
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# (Adding POST logic to the handle_books function from E1)

@app.route('/api/books', methods=['GET', 'POST'])
def handle_books():
    global next_book_id
    
    if request.method == 'GET':
        # (E1 Logic)
        return jsonify(BOOKS), 200

    elif request.method == 'POST':
        data = request.get_json()
        
        required_fields = ['title', 'author', 'year']

        # E3 Validation Check: Simple check for missing data
        if not data or any(field not in data for field in required_fields):
            # Return 400 Bad Request for client-side input error
            return jsonify({"error": "Missing required fields (title, author, year)"}), 400

        # Create new book object
        new_book = {
            "id": next_book_id,
            "title": data['title'],
            "author": data['author'],
            "year": data['year']
        }

        # Update data store and increment counter
        BOOKS.append(new_book)
        next_book_id += 1

        # Success Case: Return the newly created resource with 201 Created
        return jsonify(new_book), 201

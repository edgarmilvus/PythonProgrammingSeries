
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from flask import Flask, request

app = Flask(__name__)

# Define the HTML form structure for the GET request
FEEDBACK_FORM_HTML = """
<!doctype html>
<title>Feedback Form</title>
<h1>Submit Feedback</h1>
<form method="POST" action="/feedback">
    <label for="name">Your Name:</label><br>
    <input type="text" id="name" name="name" required><br><br>
    
    <label for="message">Your Message (min 10 chars):</label><br>
    <textarea id="message" name="message" rows="4" cols="50" required></textarea><br><br>
    
    <input type="submit" value="Submit Feedback">
</form>
"""

@app.route('/feedback', methods=['GET', 'POST'])
def handle_feedback():
    if request.method == 'POST':
        # POST Handling: Process the submitted form data
        name = request.form.get('name', 'Anonymous')
        message = request.form.get('message', '')

        # Validation: Check message length
        if len(message) < 10:
            return "Error: Your message must contain at least 10 characters.", 400
        
        # Success
        return f"Thank you, {name}! Your message has been received."
        
    else:
        # GET Handling: Display the form
        return FEEDBACK_FORM_HTML

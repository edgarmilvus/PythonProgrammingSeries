
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from flask import Flask, request, jsonify

app = Flask(__name__)
# Mock Inventory Database (shared resource)
inventory = []
next_id = 1

@app.route('/api/inventory', methods=['GET', 'POST'])
def inventory_handler():
    global next_id
    
    if request.method == 'POST':
        # --- POST Logic: Add new item ---
        data = request.get_json()
        
        if not data:
            return jsonify({"error": "Missing JSON payload"}), 400
            
        required_fields = ['name', 'quantity', 'price']
        for field in required_fields:
            if field not in data:
                return jsonify({"error": f"Missing field: {field}"}), 400

        try:
            quantity = int(data['quantity'])
            price = float(data['price'])
        except ValueError:
            return jsonify({"error": "Quantity and Price must be numeric."}), 400

        if quantity <= 0 or price <= 0:
            return jsonify({"error": "Quantity and Price must be positive."}), 400
            
        new_item = {
            "id": next_id,
            "name": data['name'],
            "quantity": quantity,
            "price": price
        }
        inventory.append(new_item)
        next_id += 1
        
        return jsonify(new_item), 201 # 201 Created Status

    elif request.method == 'GET':
        # --- GET Logic: Filter and retrieve items ---
        
        # Start with the full inventory
        filtered_inventory = inventory
        
        # Filter 1: min_quantity
        min_quantity_str = request.args.get('min_quantity')
        if min_quantity_str:
            try:
                min_q = int(min_quantity_str)
                filtered_inventory = [
                    item for item in filtered_inventory if item['quantity'] >= min_q
                ]
            except ValueError:
                return jsonify({"error": "min_quantity must be an integer."}), 400

        # Filter 2: name_contains
        name_contains = request.args.get('name_contains')
        if name_contains:
            search_term = name_contains.lower()
            filtered_inventory = [
                item for item in filtered_inventory if search_term in item['name'].lower()
            ]
            
        return jsonify(filtered_inventory)

# Mock data setup for testing GET requests
inventory.append({"id": 101, "name": "Hammer Tool Set", "quantity": 5, "price": 45.99})
inventory.append({"id": 102, "name": "Screwdriver Set", "quantity": 15, "price": 12.50})
inventory.append({"id": 103, "name": "Wrench Kit", "quantity": 2, "price": 88.00})
next_id = 104

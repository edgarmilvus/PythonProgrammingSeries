
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/catalog/search', methods=['GET'])
def catalog_search():
    # 1. Initialize filters
    filters = {}
    
    # 2. Handle 'q' (Query string) with default value
    query = request.args.get('q', 'all products')
    filters['query'] = query
    
    # 3. Handle 'max_price' with validation
    max_price_str = request.args.get('max_price')
    if max_price_str:
        try:
            max_price = int(max_price_str)
            if max_price <= 0:
                return "Invalid price format: Price must be positive.", 400
            filters['max_price'] = max_price
        except ValueError:
            # Validation Failure Case 3
            return "Invalid price format.", 400

    # 4. Handle 'sort_by' with allowed values check
    sort_by = request.args.get('sort_by')
    allowed_sorts = ['price', 'date', 'relevance']
    
    if sort_by and sort_by in allowed_sorts:
        filters['sort_by'] = sort_by
    elif sort_by:
        # Ignore invalid sort_by parameter as per requirement
        pass

    # 5. Construct the output summary
    summary = f"Search criteria applied: "
    summary += f"Query: {filters.get('query')}. "
    
    if 'max_price' in filters:
        summary += f"Max Price: ${filters['max_price']}. "
        
    if 'sort_by' in filters:
        summary += f"Sorted By: {filters['sort_by']}."
        
    return summary.strip()

# Example run configuration (optional)
if __name__ == '__main__':
    # app.run(debug=True)
    pass 

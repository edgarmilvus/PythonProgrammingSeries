
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from functools import wraps
from flask import abort, current_user, request # Import request and current_user proxies

# --- Simulated Current User Context ---
# Assume current_user is a proxy object providing user data based on the request.
class MockUser:
    def __init__(self, is_auth, role):
        self.is_authenticated = is_auth
        self.role = role
    
    def is_admin(self):
        return self.role == 'admin'

# Example usage (in a real app, this is handled by Flask-Login/Session):
# current_user = MockUser(is_auth=True, role='admin') 

# 1. Create a Security Decorator
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # The logic is centralized here (DRY principle)
        if not current_user.is_authenticated:
            abort(401) # Unauthorized
        if not current_user.is_admin():
            abort(403) # Forbidden
        
        return f(*args, **kwargs)
    return decorated_function

# 2. Refactor the Views
@app.route('/admin/dashboard')
@admin_required
def admin_dashboard():
    # Only administrative logic remains here
    return "Admin Dashboard"

@app.route('/admin/settings')
@admin_required
def admin_settings():
    # Only administrative logic remains here
    return "Admin Settings"


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import sqlite3

# Helper function to simulate a database connection and execution
def secure_search(db_cursor, query_term):
    """
    Refactored function using parameterized queries to safely search products.
    """
    # 1. Construct the query using placeholders (?)
    # Note: The SQL structure is fixed; only the data is supplied via parameter.
    sql_query = "SELECT name, price FROM products WHERE category = 'Electronics' AND name LIKE ?;"
    
    # 2. Prepare the parameter data, including necessary wildcards (%)
    # The database driver treats the entire prepared string as a single literal value.
    search_pattern = f"%{query_term}%"
    
    # 3. Execute the query, passing the data separately
    # db_cursor.execute(sql_query, (search_pattern,))
    
    # Simulation of execution (for analysis clarity):
    return (sql_query, search_pattern)

# --- Demonstration of the Refactored Code ---
# db_cursor = sqlite3.connect(':memory:').cursor()
malicious_input = "' OR 1=1 --"
secure_query, secure_param = secure_search(None, malicious_input)

print(f"Secure Query Template: {secure_query}")
print(f"Parameter Passed: {secure_param}")
# Expected output:
# Secure Query Template: SELECT name, price FROM products WHERE category = 'Electronics' AND name LIKE ?;
# Parameter Passed: %' OR 1=1 --%


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from jinja2 import Environment, select_autoescape, FileSystemLoader

# 1. Setup an intentionally unsafe environment for demonstration
# In a real scenario, this environment configuration should be avoided.
env = Environment(
    loader=FileSystemLoader('.'),
    autoescape=False # Auto-escaping disabled (the source of the vulnerability)
)

# 2. Define the user object with the malicious payload
class User:
    username = "Attacker"
    bio = "<script>alert('XSS Payload Fired');</script>"

# 3. Secure Template Rendering Logic (The Fix)
# We must explicitly apply the 'e' (escape) filter.
template_content = """
<body>
    <h1>Profile for: {{ user.username }}</h1>
    <p>Biography: {{ user.bio | e }}</p>
</body>
"""

template = env.from_string(template_content)
safe_output = template.render(user=User())

print(safe_output)
# Expected output: ... <p>Biography: &lt;script&gt;alert('XSS Payload Fired');&lt;/script&gt;</p>

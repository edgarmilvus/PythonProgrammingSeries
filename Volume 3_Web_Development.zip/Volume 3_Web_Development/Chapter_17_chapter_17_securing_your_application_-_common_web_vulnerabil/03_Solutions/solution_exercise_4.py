
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from flask import Flask, request, render_template, g
import sqlite3

# --- Refactored and Secure View Function ---
@app.route('/log_note', methods=['POST'])
def secure_log_note():
    # 1. Input Processing
    note_text = request.form.get('note', '')
    # Ensure user_id is treated as an integer for safety/type checking
    try:
        user_id = int(request.form.get('user_id', '1'))
    except ValueError:
        user_id = 1 # Default to a safe ID if input is non-numeric

    db = get_db()
    cursor = db.cursor()

    # 2. Database Interaction (Vulnerability A Fix: Parameterized Query)
    # Use '?' placeholders for both user_id and note_text
    sql = "INSERT INTO notes (user_id, note) VALUES (?, ?)"
    # Pass data as a tuple; the database driver handles safe quoting.
    cursor.execute(sql, (user_id, note_text)) 
    db.commit()

    # 3. Confirmation Display (Vulnerability B Fix: Rely on default Jinja2 auto-escaping)
    # Jinja2 auto-escapes by default, but we ensure the template doesn't disable it.
    return render_template('confirmation.html', 
                           message=f"Note logged successfully for ID: {user_id}",
                           last_note=note_text)
                           
# --- Confirmation Template (confirmation.html) Modification ---
# (No change needed if Jinja2 auto-escaping is enabled, which is the Flask default)

# <body>
#     <h2>Confirmation</h2>
#     <p>{{ message }}</p>
#     <!-- Jinja2 automatically escapes last_note, converting < to &lt; -->
#     <p>Your last note was: {{ last_note }}</p> 
# </body>


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from flask import Flask, request

app = Flask(__name__)

# 1. Route Definition allowing both GET and POST methods
@app.route('/auth/login', methods=['GET', 'POST'])
def login_handler():
    """
    Handles displaying the login prompt (GET) or processing credentials (POST).
    """
    
    if request.method == 'POST':
        # 3. POST Request Logic (Simulated data retrieval)
        # In a real application, request.form or request.get_json() would be used.
        
        # Simulation: Assume input data has been processed and username is extracted.
        simulated_username = "admin_user_99" 
        
        return f"Login successful for user: {simulated_username}"
        
    # 2. GET Request Logic (Default case if not POST)
    else: # request.method == 'GET'
        return "Welcome! Please submit your username and password via POST."

if __name__ == '__main__':
    # Testing:
    # A GET request to /auth/login returns the welcome message.
    # A POST request to /auth/login returns the successful login message.
    # A PUT request to /auth/login results in an automatic 405 Method Not Allowed error.
    pass


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from flask import Flask, request, jsonify

app = Flask(__name__)

# 1. Unified Route Definition allowing GET and POST, capturing item_id
@app.route('/inventory/<int:item_id>', methods=['GET', 'POST'])
def inventory_management(item_id):
    """
    Manages inventory retrieval (GET) and stock updates (POST) for a specific item ID.
    """
    
    # 3. GET Logic (Retrieval)
    if request.method == 'GET':
        return f"Retrieving details for Item ID: {item_id}"
    
    # 4. POST Logic (Update)
    elif request.method == 'POST':
        
        # --- Simulation of JSON Data Retrieval ---
        # In a live environment, we would use:
        # data = request.get_json()
        # quantity = data.get('quantity')
        
        # For this example, we simulate a successful POST body:
        try:
            # Assuming the client sent {"quantity": 150}
            simulated_data = {"quantity": 150} 
            quantity = simulated_data['quantity']
            
            return f"Successfully updated Item ID: {item_id}. New stock quantity set to: {quantity}"
        
        except KeyError:
            # If the required key is missing from the simulated data
            return jsonify({"error": "Missing 'quantity' field in update request."}), 400

if __name__ == '__main__':
    # Testing:
    # GET /inventory/42 -> Triggers retrieval logic.
    # POST /inventory/42 (with quantity data) -> Triggers update logic.
    pass


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from flask import Flask, url_for, jsonify

app = Flask(__name__)

# 1. Define Target 1 (Static)
@app.route('/')
def home_page():
    return "Welcome Home"

# 2. Define Target 2 (Dynamic)
@app.route('/user/<username>')
def user_profile(username):
    return f"Viewing profile for: {username}"

# 3. Define Generator Endpoint
@app.route('/links')
def link_generator():
    """
    Uses url_for to generate links based on view function names.
    """
    
    # Generate link for the static route (home_page)
    home_link = url_for('home_page')
    
    # Generate link for the dynamic route (user_profile), 
    # passing the required dynamic variable 'username' as a keyword argument.
    alice_profile_link = url_for('user_profile', username='Alice')
    
    # Output the generated links
    return jsonify({
        "home_link": home_link,
        "alice_profile_link": alice_profile_link
    })

if __name__ == '__main__':
    # To demonstrate url_for functionality, the application must be in a request context.
    # When accessing /links, the output will contain:
    # "home_link": "/",
    # "alice_profile_link": "/user/Alice"
    pass

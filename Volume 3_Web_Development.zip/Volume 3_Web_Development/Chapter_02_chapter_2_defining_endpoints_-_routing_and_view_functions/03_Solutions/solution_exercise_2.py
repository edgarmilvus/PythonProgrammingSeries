
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from flask import Flask
import math

app = Flask(__name__)

# Helper function (using math module for robust calculation)
def calculate_math_factorial(n):
    if n < 0:
        return None
    return math.factorial(n)

# 1. Route Definition using the <int:n> converter
@app.route('/math/factorial/<int:n>')
def calculate_factorial(n):
    """
    Calculates the factorial of the integer 'n' provided in the URL path.
    Flask's routing ensures 'n' is an integer before this function executes.
    """
    result = calculate_math_factorial(n)
    
    if result is None:
        # Note: Flask handles the non-integer input error (404) automatically.
        # This check is for negative numbers, which are valid integers but invalid for factorial.
        return "Error: Factorial is not defined for negative numbers.", 400
        
    # 2. Return required string response
    return f"The factorial of {n} is {result}."

if __name__ == '__main__':
    # Example test cases:
    # /math/factorial/5 -> The factorial of 5 is 120.
    # /math/factorial/7 -> The factorial of 7 is 5040.
    # /math/factorial/hello -> Flask automatically returns 404 Not Found due to converter failure.
    pass

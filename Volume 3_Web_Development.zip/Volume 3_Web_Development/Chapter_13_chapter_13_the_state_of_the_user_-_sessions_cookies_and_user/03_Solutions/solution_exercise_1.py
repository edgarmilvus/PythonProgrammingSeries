
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from flask import Flask, session, redirect, url_for, flash, render_template_string

# --- Application Setup ---
app = Flask(__name__)
# CRITICAL: Must set a strong secret key for session security
app.secret_key = 'a_very_secure_and_random_string_for_signing_sessions'

# Minimal HTML template to demonstrate flashing and session data
# In a real app, this would be loaded from a separate file (e.g., index.html)
TEMPLATE = """
<!doctype html>
<title>Session Counter</title>
{% with messages = get_flashed_messages() %}
  {% if messages %}
    <ul style="color: green; border: 1px solid green; padding: 10px;">
    {% for message in messages %}
      <li>{{ message }}</li>
    {% endfor %}
    </ul>
  {% endif %}
{% endwith %}

<h1>Session Status</h1>
<p>You have visited this page <strong>{{ session.get('visit_count', 0) }}</strong> times this session.</p>

<p><a href="{{ url_for('count_visits') }}">Visit Again</a></p>
<p><a href="{{ url_for('reset_session') }}">Reset Session</a></p>
"""

@app.route('/count')
def count_visits():
    # 1. Initialization and Transient Feedback Logic
    if 'visit_count' not in session:
        session['visit_count'] = 0
        flash("Welcome back, this is your first visit this session!")
    
    # 2. Persistence Logic: Increment the counter
    session['visit_count'] += 1
    
    # 3. Template Integration (using render_template_string for simplicity)
    return render_template_string(TEMPLATE)

@app.route('/reset_session')
def reset_session():
    # 5. Logout/Reset Mechanism
    session.clear()
    flash("Session successfully reset. Try visiting /count again!")
    return redirect(url_for('count_visits'))

# if __name__ == '__main__':
#     app.run(debug=True)

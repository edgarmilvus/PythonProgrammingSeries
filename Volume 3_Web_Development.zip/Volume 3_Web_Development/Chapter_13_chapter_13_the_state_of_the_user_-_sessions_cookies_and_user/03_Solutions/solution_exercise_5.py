
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from flask import Flask, session, request, abort, redirect, url_for, render_template_string, Response
import os
from werkzeug.security import generate_password_hash # For mock registration

app = Flask(__name__)
app.secret_key = os.urandom(24) # Use a secure random key

# --- Mock Database (Reusing structure) ---
user_db = {}

# --- CSRF Utility Function ---
def generate_csrf_token():
    """Generates a secure CSRF token and stores it in the session."""
    if 'csrf_token' not in session:
        # 1. CSRF Token Generation
        session['csrf_token'] = os.urandom(16).hex()
    return session['csrf_token']

# --- Global Context Processor for CSRF (makes token available in all templates) ---
@app.context_processor
def inject_csrf():
    return dict(csrf_token=generate_csrf_token())

# --- Header Configuration Hook ---
@app.after_request
def add_security_headers(response: Response):
    """4. Use after_request hook to inject security headers globally."""
    # Mitigate MIME type sniffing attacks
    response.headers['X-Content-Type-Options'] = 'nosniff'
    # Mitigate clickjacking attacks
    response.headers['X-Frame-Options'] = 'DENY'
    return response

# --- Protected Registration Route with CSRF Validation ---
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        # 3. Token Validation
        submitted_token = request.form.get('csrf_token')
        session_token = session.get('csrf_token')

        # Strict comparison check
        if not submitted_token or submitted_token != session_token:
            print(f"CSRF Failure: Submitted={submitted_token}, Session={session_token}")
            # Reject request if tokens do not match
            abort(403) 

        # Token rotation/clearance after successful validation
        session.pop('csrf_token', None) 
        
        # --- Mock Registration Logic (If validation passes) ---
        username = request.form.get('username')
        password = request.form.get('password')
        if username and password:
            user_db[username] = generate_password_hash(password)
            return f"Registration successful for {username}. CSRF token validated."
        
        return "Registration failed (missing fields)."

    # 2. Form Integration (Template rendering)
    FORM_TEMPLATE = """
    <h1>Register with CSRF Protection</h1>
    <form method="post">
        <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
        Username: <input name="username"><br>
        Password: <input name="password" type="password"><br>
        <input type="submit" value="Register">
    </form>
    <p>Current CSRF Token: {{ csrf_token }}</p>
    """
    return render_template_string(FORM_TEMPLATE)

# if __name__ == '__main__':
#     app.run(debug=True)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from flask import (
    Flask, Blueprint, session, redirect, url_for, flash, 
    render_template_string, request, abort
)
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps

# --- Mock Database ---
# Stores username and HASHED password
user_db = {}

# --- Custom Decorator for Access Control ---
def login_required(f):
    """Checks if the user_id is present in the session."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get('user_id') is None:
            flash("Access denied. Please log in to view this page.")
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

# --- Blueprint Setup ---
auth = Blueprint('auth', __name__, url_prefix='/auth')

# --- Authentication Routes ---

@auth.route('/register', methods=['GET', 'POST'])
def register():
    # Simulate a basic registration form submission
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if not username or not password:
            flash("Username and password are required.")
            return redirect(url_for('auth.register'))

        if username in user_db:
            flash(f"User '{username}' already exists.")
            return redirect(url_for('auth.register'))

        # 2. Secure Registration: Hash the password
        user_db[username] = generate_password_hash(password)
        flash("Registration successful! Please log in.")
        return redirect(url_for('auth.login'))
    
    return render_template_string(
        '<h1>Register</h1><form method="post">'
        'Username: <input name="username"><br>'
        'Password: <input name="password" type="password"><br>'
        '<input type="submit" value="Register"></form>'
    )

@auth.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        hashed_password = user_db.get(username)

        # 3. Secure Login: Verify password against the stored hash
        if hashed_password and check_password_hash(hashed_password, password):
            # Success: Store user ID securely in the session
            session['user_id'] = username
            flash("Login successful!")
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid username or password.")
            return redirect(url_for('auth.login'))

    return render_template_string(
        '<h1>Login</h1><form method="post">'
        'Username: <input name="username"><br>'
        'Password: <input name="password" type="password"><br>'
        '<input type="submit" value="Log In"></form>'
    )

@auth.route('/logout')
def logout():
    # 6. Logout Implementation
    session.pop('user_id', None)
    flash("You have been logged out.")
    return redirect(url_for('index'))

# --- Main Application Setup and Protected Route ---
app = Flask(__name__)
app.secret_key = 'a_strong_key_for_exercise_2'
app.register_blueprint(auth)

@app.route('/')
def index():
    user = session.get('user_id', 'Guest')
    return f'<h1>Homepage</h1><p>Current User: {user}</p><p><a href="{url_for("auth.login")}">Login</a> | <a href="{url_for("dashboard")}">Dashboard</a> | <a href="{url_for("auth.logout")}">Logout</a></p>'

@app.route('/dashboard')
@login_required # 5. Protected Dashboard
def dashboard():
    return f'<h1>Protected Dashboard</h1><p>Welcome, {session["user_id"]}! This page is secure.</p>'

# if __name__ == '__main__':
#     app.run(debug=True)

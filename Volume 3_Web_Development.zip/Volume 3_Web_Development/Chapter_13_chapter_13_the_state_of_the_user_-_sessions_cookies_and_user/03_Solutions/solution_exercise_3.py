
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from flask import Flask, g, session, redirect, url_for, abort, request, render_template_string
from werkzeug.security import generate_password_hash # Used for setup only

# --- Mock Database (Reusing structure from Ex 2) ---
user_db = {
    'admin': generate_password_hash('securepass123'),
    'testuser': generate_password_hash('password')
}
# Simulate user data retrieval (in a real app, this would query the DB)
def get_user_data(username):
    # Return a dummy user object/dict if the hash exists
    if username in user_db:
        return {'id': username, 'username': username, 'role': 'user'}
    return None

# --- Application Setup ---
app = Flask(__name__)
app.secret_key = 'a_strong_key_for_exercise_3'

# 1. The Before Request Hook
@app.before_request
def load_logged_in_user():
    """Loads the user object into the request context (g object)."""
    user_id = session.get('user_id')

    # 2. User Loading Logic
    if user_id is None:
        # 3. Handling Unauthenticated Users
        g.user = None
    else:
        # Simulate fetching user data based on session ID
        g.user = get_user_data(user_id)
        
    # Note: If the user ID exists in the session but not in the DB, g.user will be None.

# --- Refactored Protected Route ---

@app.route('/dashboard')
def dashboard():
    # 4. Refactoring Protected Routes: Check g.user instead of using a decorator
    if g.user is None:
        # If g.user is None, the user is not authenticated.
        return redirect(url_for('login')) # Redirect to login or abort
    
    return f'<h1>Protected Dashboard</h1><p>Welcome, {g.user["username"]}! Your role is {g.user["role"]}.</p>'

# --- Supporting Routes (Minimal implementation for context) ---
@app.route('/login')
def login():
    # Simulate a successful login setting the session key
    session['user_id'] = 'admin'
    return redirect(url_for('dashboard'))

@app.route('/')
def index():
    # Example of accessing g.user in a template or view function
    username = g.user['username'] if g.user else 'Guest'
    return f'<h1>Homepage</h1><p>Current User (from g object): {username}</p><p><a href="{url_for("dashboard")}">Go to Dashboard</a></p>'

# if __name__ == '__main__':
#     app.run(debug=True)

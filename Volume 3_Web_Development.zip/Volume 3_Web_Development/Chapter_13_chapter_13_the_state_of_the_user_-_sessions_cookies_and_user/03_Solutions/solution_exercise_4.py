
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from flask import Flask, request, make_response, session, render_template_string

# --- Application Setup ---
app = Flask(__name__)

# CRITICAL SECURITY NOTE:
# app.secret_key MUST be complex, randomly generated (e.g., using os.urandom),
# and kept absolutely secret. If this key is compromised, an attacker can forge
# valid session cookies, completely undermining the authentication system.
app.secret_key = 'INSECURE_DEV_KEY_FOR_TAMPERING_DEMO' 

# --- Part A: The Vulnerability Demonstration (Unsigned Cookies) ---

@app.route('/set_theme_insecure/<theme_name>')
def set_theme_insecure(theme_name):
    """Sets a raw, unsigned cookie."""
    response = make_response(f"Insecure cookie 'user_theme' set to: {theme_name}")
    # Setting the cookie directly without signing
    response.set_cookie('user_theme', theme_name, max_age=3600)
    return response

@app.route('/get_theme_insecure')
def get_theme_insecure():
    """Reads the raw, unsigned cookie."""
    theme = request.cookies.get('user_theme', 'default')
    return f"<h1>Insecure Cookie Read</h1><p>The current theme (from raw cookie) is: <strong>{theme}</strong></p>"

# --- Part B: Implementing Security (Signed Sessions) ---

@app.route('/set_theme_secure/<theme_name>')
def set_theme_secure(theme_name):
    """Stores the theme preference securely in the signed session."""
    # 4. Secure Session Usage
    session['user_theme'] = theme_name
    return f"Secure session variable 'user_theme' set to: {theme_name}"

@app.route('/get_theme_secure')
def get_theme_secure():
    """Reads the theme preference from the secure session."""
    # 5. Verification
    theme = session.get('user_theme', 'default')
    
    if theme == 'default' and 'user_theme' in request.cookies:
        # This condition is met if the session cookie was tampered with, 
        # causing Flask to reject the signature and treat the session as empty.
        return "<h1>Secure Session Read</h1><p style='color: red;'>TAMPERING DETECTED! Session rejected. Theme: default.</p>"
        
    return f"<h1>Secure Session Read</h1><p>The current theme (from secure session) is: <strong>{theme}</strong></p>"

# if __name__ == '__main__':
#     app.run(debug=True)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# --- Simulation of Revision IDs (A, B, C) ---
# A: initial_schema_setup (e.g., 1a2b3c4d)
# B: add_publication_year (e.g., 5e6f7g8h)
# C: rename_isbn_to_standard_identifier (e.g., 9i0j1k2l)

# 1. Inspect History:
# $ alembic history
# Output would show:
# 9i0j1k2l (head) -> rename_isbn_to_standard_identifier
# 5e6f7g8h -> 9i0j1k2l (B) -> add_publication_year
# 1a2b3c4d -> 5e6f7g8h (A) -> initial_schema_setup

# 2. Targeted Downgrade: Downgrade to the revision *before* B.
# This is Revision A (1a2b3c4d).
# To downgrade past B, we target A's ID.
# $ alembic downgrade 1a2b3c4d

# 3. Verify State:
# $ alembic current
# Output confirms: 1a2b3c4d (Revision A ID)

# 4. Re-Apply Specific Changes (Upgrade back to head):
# $ alembic upgrade head

# 5. Hypothetical Analysis:
"""
Analysis of Targeted Downgrade Failure:

Alembic enforces a strict linear history (A -> B -> C). If Revision C (rename_isbn) depends on the schema state established by Revision B (publication_year column exists), attempting to downgrade *only* B while leaving C applied would cause a fundamental inconsistency. The downgrade function of B would remove the 'publication_year' column, but the upgrade function of C expects that column to be present or its rename operation might fail if constraints were linked. Since Alembic operates sequentially, the only way to remove B is to also implicitly remove C first via their respective downgrade functions.

The Alembic command to show dependencies (if they were explicitly defined using 'depends_on' in the script, though usually implicit by 'down_revision') is:
$ alembic history --verbose
"""


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# --- Modification to models.py ---
# class Book(Base):
#     ...
#     # Old: isbn = Column(String(20), unique=True, nullable=False)
#     standard_identifier = Column(String(20), unique=True, nullable=False) # Renamed

# --- Manual Migration Script (e.g., 2024_rename_isbn.py) ---
from alembic import op
import sqlalchemy as sa

revision = '2024_rename_isbn'
down_revision = '2024_add_year' # Assuming previous revision ID
branch_labels = None
depends_on = None

def upgrade():
    # Use op.rename_column to perform a non-destructive rename.
    # This preserves the data, type, and constraints (unique, not null).
    op.rename_column('books', 'isbn', 'standard_identifier')

def downgrade():
    # Reverse the rename operation
    op.rename_column('books', 'standard_identifier', 'isbn')

# --- Command Execution ---
# 1. Generate manual script: $ alembic revision -m "rename_isbn_to_standard_identifier"
# 2. Populate the script (as shown above)
# 3. Apply migration: $ alembic upgrade head

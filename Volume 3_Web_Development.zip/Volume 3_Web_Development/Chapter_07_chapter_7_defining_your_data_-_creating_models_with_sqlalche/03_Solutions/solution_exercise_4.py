
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from sqlalchemy import create_engine, Column, Integer, String, ForeignKey
from sqlalchemy.orm import sessionmaker, relationship
from sqlalchemy.ext.declarative import declarative_base

# Setup Environment
Base = declarative_base()
engine = create_engine('sqlite:///:memory:') # Use in-memory SQLite for testing
Session = sessionmaker(bind=engine)
session = Session()

class Department(Base):
    __tablename__ = 'departments'

    id = Column(Integer, primary_key=True)
    name = Column(String(100), unique=True, nullable=False)

    # 2. Self-Referential Foreign Key: Links child back to parent
    parent_id = Column(Integer, ForeignKey('departments.id'), nullable=True)

    # 3 & 4. Relationship Definition and Ambiguity Resolution
    # 'parent': Navigates from child to single parent (using remote_side to target Department.id)
    parent = relationship(
        'Department',
        remote_side=[id], # This specifies that the 'id' column is the target of the FK
        backref='children' # Creates the 'children' collection on the parent object
    )
    
    # Note: 'children' relationship is automatically created via backref

    def __repr__(self):
        return f"<Department id={self.id} name='{self.name}'>"

# Create the schema in the database
Base.metadata.create_all(engine)

# --- Interactive Challenge Prompt Execution ---

# 1. Create the top-level department (no parent)
executive = Department(name='Executive')
session.add(executive)
print(f"Created: {executive}")

# 2. Create a child department
# We link Marketing to Executive using the 'parent' relationship attribute
marketing = Department(name='Marketing', parent=executive)
session.add(marketing)
print(f"Created: {marketing}")

# 3. Commit the changes
session.commit()

# 4. Verify the relationship (EAFP Style)
# Retrieve the Executive department object (refreshed after commit)
executive_retrieved = session.query(Department).filter_by(name='Executive').one()
print(f"\nExecutive Children Check: {executive_retrieved.children}")

# 5. Verify the back-reference
marketing_retrieved = session.query(Department).filter_by(name='Marketing').one()
print(f"Marketing Parent Check: {marketing_retrieved.parent.name}")

session.close()

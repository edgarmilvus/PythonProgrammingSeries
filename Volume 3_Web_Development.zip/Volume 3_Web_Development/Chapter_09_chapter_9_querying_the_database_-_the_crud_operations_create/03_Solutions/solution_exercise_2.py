
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from sqlalchemy import or_, and_, func
from datetime import datetime, timedelta
# Assume db, User, Post, and helper seven_days_ago() are configured

def seven_days_ago():
    """Helper function to calculate the date 7 days prior."""
    return datetime.utcnow() - timedelta(days=7)

def get_priority_posts():
    """
    Queries posts using complex filtering, relationship filtering, 
    and data projection.
    """
    
    # Define the complex OR condition
    or_condition = or_(
        # Condition 1: Author username starts with 'A' (case insensitive)
        User.username.ilike('A%'),
        # Condition 2: Published within the last 7 days
        Post.published_date >= seven_days_ago()
    )
    
    # Define the overall AND condition
    complex_filter = and_(
        # Requirement 1: ID greater than 50
        Post.id > 50,
        # Requirement 2: The OR condition must be met
        or_condition
    )
    
    # Query setup: Projection (selecting specific columns)
    results = db.session.query(
        Post.title, 
        Post.published_date
    ).join(
        User, Post.author_id == User.id # Explicit join for relationship filtering
    ).filter(
        complex_filter
    ).order_by(
        Post.published_date.desc()
    ).limit(
        25
    ).all()

    return results

# Example usage:
# priority_list = get_priority_posts()
# print(f"Retrieved {len(priority_list)} projected posts.")

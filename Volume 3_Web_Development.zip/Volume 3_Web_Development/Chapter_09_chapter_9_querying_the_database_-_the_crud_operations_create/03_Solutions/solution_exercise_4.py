
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from sqlalchemy import or_, func
# Assume db, User, Post (with is_reviewed column) are configured

def process_moderation_queue():
    """
    Reads 10 flagged posts, updates the first 5, and deletes the last 5.
    """
    
    # 1. Define the flagging criteria (Read operation)
    review_criteria = or_(
        # Title contains 'Urgent' (case-insensitive)
        Post.title.ilike('%Urgent%'),
        # Content is shorter than 20 characters
        func.length(Post.content) < 20
    )
    
    # Query the 10 oldest flagged posts
    flagged_posts = db.session.query(Post).filter(
        review_criteria
    ).order_by(
        Post.published_date.asc()
    ).limit(10).all()
    
    if not flagged_posts:
        return "No posts requiring review found."

    posts_to_review = flagged_posts[:5]
    posts_to_delete = flagged_posts[5:]
    
    # 2. Update (Moderation) - Mark the first 5 as reviewed
    for post in posts_to_review:
        post.is_reviewed = True
        db.session.add(post) # Stage the update
        
    # 3. Delete (Hard Deletion) - Permanently remove the remaining 5
    for post in posts_to_delete:
        db.session.delete(post) # Stage the deletion
        
    # 4. Commit all changes atomically
    try:
        db.session.commit()
        
        # 5. Verification Read (optional, but good practice)
        deleted_ids = [p.id for p in posts_to_delete]
        reviewed_ids = [p.id for p in posts_to_review]
        
        # Verify deletions (should return 0)
        deleted_check = db.session.query(Post).filter(Post.id.in_(deleted_ids)).count()
        # Verify updates (should return 5)
        reviewed_check = db.session.query(Post).filter(
            Post.id.in_(reviewed_ids), 
            Post.is_reviewed == True
        ).count()
        
        return (f"Moderation complete. Reviewed: {len(posts_to_review)} (Verified: {reviewed_check}). "
                f"Deleted: {len(posts_to_delete)} (Verified remaining: {deleted_check}).")
        
    except Exception as e:
        db.session.rollback()
        return f"Transaction failed during moderation: {e}"

# print(process_moderation_queue())

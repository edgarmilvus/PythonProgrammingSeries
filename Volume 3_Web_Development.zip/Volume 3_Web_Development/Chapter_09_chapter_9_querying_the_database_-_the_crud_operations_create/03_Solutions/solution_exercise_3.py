
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from sqlalchemy import update, delete, func, select
from datetime import datetime, timedelta
# Assume db, User, Post, and helper ninety_days_ago() are configured

def ninety_days_ago():
    """Helper function to calculate the date 90 days prior."""
    return datetime.utcnow() - timedelta(days=90)

def deactivate_old_users(ninety_days_ago_ts):
    """
    Mass update: Deactivates users created before the given timestamp.
    """
    
    # 1. Define the update statement
    stmt = update(User).where(
        User.created_at < ninety_days_ago_ts
    ).values(
        is_active=False
    )
    
    # 2. Execute the update statement directly
    # synchronize_session=False tells SQLAlchemy not to try to synchronize 
    # the session cache, as we are doing a direct DB operation.
    result = db.session.execute(stmt)
    db.session.commit()
    
    return result.rowcount

def archive_posts_of_inactive_users():
    """
    Mass update: Soft-deletes (archives) posts where the author is inactive.
    This uses a subquery to identify the inactive author IDs.
    """
    
    # 1. Subquery to find IDs of inactive users
    inactive_user_ids = select(User.id).where(User.is_active == False)
    
    # 2. Define the update statement targeting posts by those authors
    stmt = update(Post).where(
        Post.author_id.in_(inactive_user_ids)
    ).values(
        is_archived=True
    )
    
    # 3. Execute the update and commit
    # synchronize_session=False is crucial for performance here as well
    result = db.session.execute(stmt)
    db.session.commit()
    
    return result.rowcount

# Example usage:
# users_deactivated = deactivate_old_users(ninety_days_ago())
# posts_archived = archive_posts_of_inactive_users()
# print(f"Deactivated {users_deactivated} users.")
# print(f"Archived {posts_archived} posts.")

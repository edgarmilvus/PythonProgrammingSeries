
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# Helper function (provided context)
def generate_slug(text):
    # Placeholder for actual slugification logic
    if text is None:
        return ""
    return text.lower().replace(' ', '-')

class SlugGenerator:
    """
    A descriptor that automatically generates a slug based on the title,
    but only if the title value has actually changed.
    """
    def __init__(self, storage_name):
        # storage_name is the attribute name where the title is stored (e.g., '_title')
        self.storage_name = storage_name
        self.slug_storage_name = '_slug' 

    def __get__(self, instance, owner):
        # Standard descriptor retrieval logic
        if instance is None:
            return self
        return instance.__dict__.get(self.storage_name)

    def __set__(self, instance, value):
        
        # 1. Get the current stored title value
        current_title = instance.__dict__.get(self.storage_name)
        
        # 2. Check if the value has changed
        if current_title != value:
            
            # 3. Update the raw title attribute
            instance.__dict__[self.storage_name] = value
            
            # 4. Conditionally generate and set the slug
            new_slug = generate_slug(value)
            instance.__dict__[self.slug_storage_name] = new_slug
            
            print(f"Slug updated for: {value}")
        else:
            print(f"Title '{value}' unchanged. Slug generation skipped.")


# Post Model structure relying on the descriptor
# Assume db.Model is Base/Declarative Base
class Post(db.Model):
    __tablename__ = 'post_with_slug'
    id = db.Column(db.Integer, primary_key=True)
    # Standard SQLAlchemy mapping for persistence
    _title = db.Column('title', db.String(100))
    _slug = db.Column('slug', db.String(120), unique=True)

    # Applying the descriptor to the public 'title' attribute
    title = SlugGenerator('_title')

# --- Demonstration ---
# p = Post(title="Initial Title") 
# p.title = "A New Title" # Slug generated
# p.title = "A New Title" # Slug generation skipped

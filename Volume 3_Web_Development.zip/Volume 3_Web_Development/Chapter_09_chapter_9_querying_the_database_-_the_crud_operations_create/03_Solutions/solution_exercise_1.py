
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from sqlalchemy.exc import IntegrityError
from datetime import datetime
# Assume db, User, and necessary imports are configured

def insert_new_users(user_data_list):
    """Attempts bulk insertion of users atomically."""
    new_users = []
    
    # 1. Prepare ORM objects
    for data in user_data_list:
        # Handle potential missing required fields (a different type of error, 
        # but good practice to catch early or let the DB handle it)
        try:
            user = User(
                username=data['username'],
                email=data['email']
                # created_at/is_active handled by defaults
            )
            new_users.append(user)
        except KeyError:
            print(f"Skipping malformed data: {data}")
            return False # Fail early if input data is fundamentally wrong

    # 2. Add all objects to the session
    db.session.add_all(new_users)
    
    success = True
    try:
        # 3. Attempt to commit the entire transaction
        db.session.commit()
        print(f"Successfully inserted {len(new_users)} users.")
        
    except IntegrityError as e:
        # 4. Rollback mechanism on constraint violation
        db.session.rollback()
        print(f"Transaction failed due to Integrity Error: {e}")
        success = False
        
    except Exception as e:
        # Catch other unexpected errors
        db.session.rollback()
        print(f"Transaction failed due to unexpected error: {e}")
        success = False
        
    return success

def count_all_users():
    """Queries the total number of users in the database."""
    # Using func.count() for efficient row counting
    count = db.session.query(func.count(User.id)).scalar()
    return count

# --- Demonstration Setup ---
# Assume initial user count is 10
# Initial state: User 1 exists with username='existing_user'

# Example data: 1 valid, 1 duplicate (will cause IntegrityError)
user_data_batch = [
    {'username': 'new_user_A', 'email': 'a@example.com'},
    {'username': 'existing_user', 'email': 'duplicate@example.com'}, # Fails
    {'username': 'new_user_B', 'email': 'b@example.com'}
]

# is_successful = insert_new_users(user_data_batch)
# final_count = count_all_users()
# print(f"Success: {is_successful}, Final User Count: {final_count}") 
# Expected output: Success: False, Final User Count: 10 (Rollback occurred)

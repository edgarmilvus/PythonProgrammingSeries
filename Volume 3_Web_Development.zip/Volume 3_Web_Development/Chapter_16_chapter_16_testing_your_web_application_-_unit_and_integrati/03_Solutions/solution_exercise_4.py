
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import pytest
from unittest.mock import patch, Mock
from flask import Flask, request, jsonify, Blueprint

# --- Context Setup (Minimal definitions for test execution) ---
class MockRAGService:
    def process_query(self, query):
        raise NotImplementedError()
rag_service = MockRAGService() 

def create_rag_app():
    app = Flask(__name__)
    rag_bp = Blueprint('rag', __name__, url_prefix='/rag')
    @rag_bp.route('/query', methods=['POST'])
    def handle_query():
        data = request.get_json()
        query = data.get('q')

        if not query or len(query.strip()) < 5:
            return jsonify({"error": "Query too short or missing."}), 400
        try:
            result = rag_service.process_query(query)
            return jsonify(result), 200
        except Exception:
            return jsonify({"error": "Internal RAG service failure."}), 500
    app.register_blueprint(rag_bp)
    return app

# Fixture Definitions (Assumed conftest.py content)
@pytest.fixture
def app():
    app = create_rag_app()
    app.config.update({"TESTING": True})
    yield app

@pytest.fixture
def client(app):
    return app.test_client()

# Requirement 1: Mock Fixture Setup
@pytest.fixture
def mock_rag_service():
    """Patches the rag_service.process_query method for test control."""
    # Patching the method on the global object defined above (or imported module)
    with patch('__main__.rag_service.process_query') as mock_proc:
        yield mock_proc

# --- Parameterized Integration Test (Requirements 2, 3) ---

@pytest.mark.parametrize(
    "query_input, expected_status, scenario",
    [
        # Case A: Success (200)
        ("What is the history of PyTest fixtures?", 200, "success"),
        # Case B: Validation Failure (400)
        ("short", 400, "validation_fail"),
        # Case C: Internal Failure (500)
        ("trigger_internal_error", 500, "internal_fail"),
    ]
)
def test_rag_query_endpoint(client, mock_rag_service, query_input, expected_status, scenario):
    """
    Tests the RAG query endpoint using parameterized inputs and conditional mocking.
    """
    
    # 1. Configure Mock based on the scenario
    if scenario == "success":
        mock_rag_service.return_value = {
            "answer": "PyTest fixtures are efficient.",
            "sources": ["py_doc_1", "py_doc_2"]
        }
    elif scenario == "internal_fail":
        # Configure mock to raise an exception
        mock_rag_service.side_effect = Exception("LLM API Timeout")
    
    # 2. Execute the request
    response = client.post('/rag/query', json={'q': query_input})
    
    # 3. Assert status code
    assert response.status_code == expected_status
    
    # 4. Detailed Assertions
    if scenario == "success":
        data = response.get_json()
        assert "answer" in data
        assert "sources" in data
        
    elif expected_status in (400, 500):
        data = response.get_json()
        assert "error" in data
    
    # 5. Verify service call isolation
    if expected_status == 400:
        # Validation failed before reaching the service layer
        mock_rag_service.assert_not_called()
    else:
        # Service was called for 200 and 500 cases
        mock_rag_service.assert_called_once()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import pytest
from flask import Flask, request, jsonify

# --- Context Setup (Simulated app/routes.py and conftest.py) ---
def create_app():
    app = Flask(__name__)
    @app.route('/api/users', methods=['POST'])
    def register_user():
        data = request.get_json()
        
        # Check for missing data (handles non-JSON content types resulting in None data)
        if not data or 'username' not in data or 'email' not in data:
            return jsonify({"error": "Missing required fields"}), 400

        user_id = 101 
        return jsonify({
            "message": "User registered successfully",
            "user_id": user_id,
            "username": data['username']
        }), 201
    return app

# Fixtures (Assume these are in conftest.py)
@pytest.fixture
def app():
    app = create_app()
    app.config.update({"TESTING": True})
    yield app

@pytest.fixture
def client(app):
    return app.test_client()

# --- Integration Tests ---

def test_register_user_success(client):
    """Tests successful registration, asserting 201 status and payload structure."""
    payload = {"username": "testuser", "email": "test@example.com"}
    
    response = client.post('/api/users', json=payload)
    
    assert response.status_code == 201
    
    data = response.get_json()
    assert data['message'] == "User registered successfully"
    assert 'user_id' in data

def test_register_user_missing_fields(client):
    """Tests validation failure when required fields are missing (400)."""
    # Missing 'email' field
    payload = {"username": "incomplete_user"}
    
    response = client.post('/api/users', json=payload)
    
    assert response.status_code == 400
    
    data = response.get_json()
    assert data['error'] == "Missing required fields"

def test_register_user_invalid_content_type(client):
    """Tests handling when request data is not application/json."""
    # Send data as plain text (no JSON header)
    response = client.post(
        '/api/users', 
        data="Not JSON data", 
        content_type='text/plain'
    )
    
    # Flask's request.get_json() will return None, triggering the 400 error path
    assert response.status_code == 400
    
    data = response.get_json()
    assert data['error'] == "Missing required fields"

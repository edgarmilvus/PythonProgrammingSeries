
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import pytest
from unittest.mock import patch, Mock
import requests
from requests.exceptions import HTTPError, ConnectionError, RequestException

# --- Context Setup (Simulated app/services.py) ---
EXTERNAL_API_URL = "https://api.external-users.com/profile/"

def retrieve_user_profile(user_id: int):
    """Fetches user data from an external API."""
    try:
        response = requests.get(f"{EXTERNAL_API_URL}{user_id}")
        response.raise_for_status()
        return response.json()
    except RequestException:
        # Catches HTTPError, ConnectionError, Timeout, etc.
        return None

# --- Mocking Tests ---

@patch('requests.get')
def test_profile_retrieval_success(mock_get):
    """Tests successful API retrieval and verifies the call URL."""
    expected_data = {"id": 1, "name": "Test User"}
    user_id = 1
    
    # Configure the mock response object
    mock_response = Mock()
    mock_response.status_code = 200
    mock_response.json.return_value = expected_data
    mock_response.raise_for_status.return_value = None
    
    mock_get.return_value = mock_response
    
    result = retrieve_user_profile(user_id)
    
    # Assertions
    assert result == expected_data
    
    # Verification of Call
    expected_url = f"{EXTERNAL_API_URL}{user_id}"
    mock_get.assert_called_once_with(expected_url)


@patch('requests.get')
def test_profile_retrieval_not_found(mock_get):
    """Tests API failure (404) by simulating HTTPError."""
    
    # Configure the mock response object to simulate 404
    mock_response = Mock()
    mock_response.status_code = 404
    
    # Configure raise_for_status to raise the appropriate exception
    mock_response.raise_for_status.side_effect = HTTPError("404 Client Error")
    
    mock_get.return_value = mock_response
    
    result = retrieve_user_profile(999)
    
    # Assertions: Should return None because the exception is caught
    assert result is None
    mock_get.assert_called_once()


@patch('requests.get')
def test_profile_retrieval_network_error(mock_get):
    """Tests catastrophic network failure (e.g., connection refused or timeout)."""
    
    # Configure requests.get itself to raise a ConnectionError
    mock_get.side_effect = ConnectionError("Network unreachable")
    
    result = retrieve_user_profile(10)
    
    # Assertions: Should return None
    assert result is None
    mock_get.assert_called_once()

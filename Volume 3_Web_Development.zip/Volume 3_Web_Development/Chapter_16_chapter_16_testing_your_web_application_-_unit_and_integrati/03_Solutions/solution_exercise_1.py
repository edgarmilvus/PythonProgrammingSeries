
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pytest

# --- Context Setup (Simulated app/exceptions.py and app/utils.py) ---
class InvalidInputError(Exception):
    """Custom exception for validation failures."""
    pass

def clean_username(raw_input: str) -> str:
    # 1. Trim whitespace, 2. Convert to lowercase, 3. Replace internal spaces
    cleaned = raw_input.strip().lower().replace(' ', '_')

    # 4. Length check
    if not 5 <= len(cleaned) <= 20:
        raise InvalidInputError(f"Username '{cleaned}' must be between 5 and 20 characters.")
    return cleaned

# --- Fixtures for DRY ---

@pytest.fixture
def sample_valid_inputs():
    """Provides a list of (raw_input, expected_output) tuples for successful cleaning."""
    return [
        ("  User Name 123 ", "user_name_123"), # Mixed case, spaces, whitespace
        ("ALREADY_CLEAN", "already_clean"),   # Already clean, mixed case
        ("minimum_ok", "minimum_ok"),         # 10 characters
        ("maximum_length_test", "maximum_length_test"), # Exact 20 characters
    ]

@pytest.fixture
def sample_invalid_inputs():
    """Provides a list of inputs that should raise InvalidInputError due to length."""
    return [
        "a b",       # Becomes "a_b", length 3 (Too short)
        "tiny",      # Length 4 (Too short)
        "this_is_a_very_long_username_that_exceeds_the_limit_by_a_lot", # Too long
    ]

# --- Test Functions ---

def test_clean_username_valid_data(sample_valid_inputs):
    """Tests all valid input cases provided by the fixture using iteration."""
    for raw, expected in sample_valid_inputs:
        result = clean_username(raw)
        assert result == expected

def test_clean_username_invalid_data(sample_invalid_inputs):
    """Tests that InvalidInputError is correctly raised for all invalid inputs."""
    for raw in sample_invalid_inputs:
        # Use pytest.raises context manager to assert the exception type
        with pytest.raises(InvalidInputError) as excinfo:
            clean_username(raw)
        
        # Verify the error message content
        assert "must be between 5 and 20 characters" in str(excinfo.value)

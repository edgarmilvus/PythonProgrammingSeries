
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from flask import Blueprint, request, jsonify
# Assuming db, User model, and password hashing function exist

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

# Mock User model for context
class User:
    # ... model definition ...
    @staticmethod
    def get_by_username(username):
        """Mock lookup: 'existing_user' is taken."""
        if username == 'existing_user':
            return True
        return None

# --- Part A: Synchronous Input Validation (LBYL) ---

@auth_bp.route('/register', methods=['POST'])
def register_user():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    # 2. Input Length Validation (Synchronous Check)
    if not username or len(username) < 8:
        return jsonify({"error": "Bad Request", "message": "Username must be at least 8 characters long."}), 400
    if not password or len(password) < 8:
        # Password validation should also check complexity (not required here, but good practice)
        return jsonify({"error": "Bad Request", "message": "Password must be at least 8 characters long."}), 400

    # 1. Pre-Commit Uniqueness Check (LBYL: Look Before You Leap)
    existing_user = User.get_by_username(username)
    if existing_user:
        # Return 409 Conflict if the resource already exists
        return jsonify({"error": "Conflict", "message": f"Username '{username}' is already taken."}), 409

    # ... User creation and commit logic ...
    
    return jsonify({"message": "User registered successfully"}), 201


# --- Part B: Conceptual Asynchronous Cleanup ---

@posts_bp.route('/posts', methods=['POST'])
def create_post_and_delegate_tasks():
    # 1. Identify Bottlenecks
    
    # post = create_new_post(request.json)
    # db.session.add(post)
    # db.session.commit() # Database commit successful (CRITICAL POINT)
    
    # If heavy tasks were placed before the commit, a task failure means data loss.
    # If heavy tasks were placed after commit but before response, latency would be high.
    
    post_id = 123 # Assume this is the ID of the newly committed post
    
    # 2. Conceptual Delegation using Asynchronous Primitives
    
    # Task 1: Sending an email notification (Fire-and-Forget)
    # The API delegates this task to a worker queue (e.g., Celery) and does not wait.
    # worker_queue.enqueue(send_email_notification, post_id=post_id)
    
    # Task 2: Generating multiple image thumbnails (Fire-and-Forget)
    # worker_queue.enqueue(generate_thumbnails, post_id=post_id)
    
    # Task 3: Indexing the post content in Elasticsearch
    indexing_future = worker_queue.enqueue(index_post_content, post_id=post_id)
    
    # Role of a Future: The 'indexing_future' object represents the eventual result 
    # of the background job. The API thread does not block, but it can optionally 
    # store the Future's ID (job ID) to check the result status later via a separate endpoint.
    
    # Contrast with Await: The 'await' keyword would conceptually be used if this API 
    # were fully asynchronous (async/await) and needed to pause execution *until* a 
    # result was ready, but without blocking the entire thread (e.g., waiting for an 
    # external microservice response). Since these tasks are long-running and non-essential 
    # for the immediate response, we use fire-and-forget delegation instead of 'await'.
    
    return jsonify({"message": "Post created.", "task_id": indexing_future.id}), 201

# 3. Design Justification
"""
Using asynchronous processing for these tasks is essential for maintaining a low latency, responsive API. A long-running synchronous task (like image processing or search indexing) ties up a worker thread for seconds, preventing that thread from serving other user requests. This quickly leads to thread pool exhaustion and high API latency under load. By offloading these tasks to an asynchronous worker queue, the main API thread is immediately freed after the database commit, maximizing API concurrency and ensuring that the user receives an immediate 201 Created response, significantly improving the perceived performance and scalability of the platform.
"""

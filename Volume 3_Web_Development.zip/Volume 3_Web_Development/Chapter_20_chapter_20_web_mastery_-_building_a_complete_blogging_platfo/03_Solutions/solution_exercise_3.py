
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from flask import jsonify, Blueprint
from sqlalchemy import select
from sqlalchemy.orm import joinedload, selectinload
from sqlalchemy.orm.exc import NoResultFound
# Assuming db, User, Post, Comment models exist and relationships are defined

posts_bp = Blueprint('posts', __name__, url_prefix='/api/v1')

# --- Serialization Helpers ---

def serialize_user_safe(user):
    """Excludes sensitive fields like password hash."""
    return {
        "id": user.id,
        "username": user.username,
        "email": getattr(user, 'email', None) 
    }

def serialize_comment_detail(comment):
    """3. Serializes a comment, including the nested commenter."""
    return {
        "id": comment.id,
        "content": comment.content,
        "timestamp": comment.timestamp.isoformat(),
        "commenter": serialize_user_safe(comment.author)
    }

def serialize_post_complex(post):
    """2. Defines the Complex Serialization Schema for the Post."""
    return {
        "id": post.id,
        "title": post.title,
        "content": post.content,
        "timestamp": post.timestamp.isoformat(),
        "author": serialize_user_safe(post.author),
        
        # 4. Data Consistency Check: Calculate count from the loaded relationship list
        "comment_count": len(post.comments), 
        
        "comments": [serialize_comment_detail(c) for c in post.comments]
    }

# --- API Endpoint ---

@posts_bp.route('/posts/<int:post_id>', methods=['GET'])
def get_single_post_optimized(post_id):
    # 1. Optimized Post Retrieval
    try:
        # Eager Loading Strategy:
        # joinedload(Post.author): Loads the author in the main SELECT query (JOIN).
        # selectinload(Post.comments): Loads all comments in a second, efficient SELECT IN query.
        # joinedload(Comment.author): Ensures the commenter details are loaded with the comments.
        # This approach prevents the N+1 query problem by loading all necessary related data efficiently.
        stmt = (
            select(Post)
            .where(Post.id == post_id)
            .options(joinedload(Post.author))
            .options(selectinload(Post.comments).joinedload(Comment.author)) 
        )
        
        post = db.session.execute(stmt).scalar_one()
        
    except NoResultFound:
        return jsonify({"error": "Not Found"}), 404
    
    return jsonify(serialize_post_complex(post)), 200


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from flask import jsonify, g, request, Blueprint
from functools import wraps
from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy import select
# Assuming db, Post model, and JWT setup exist

# Mock function to retrieve Post, simulating ORM behavior
# In a real app, this would use db.session.execute(select(Post)...).scalar_one()
def fetch_post_or_raise(post_id):
    """Retrieves a Post, or raises NoResultFound if not found."""
    class MockPost:
        def __init__(self, id, user_id):
            self.id = id
            self.user_id = user_id
    
    if post_id == 999:
        raise NoResultFound()
    return MockPost(id=post_id, user_id=1) # Default owner is User 1

# 1. Develop an Ownership Check Decorator
def requires_post_ownership():
    """Decorator that enforces content ownership and handles 404 (EAFP)."""
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            post_id = kwargs.get('post_id')
            authenticated_user_id = g.user_id # Assumed to be set by JWT verification

            # 3. Implement EAFP Error Handling
            try:
                # Attempt to fetch the post; if not found, it raises NoResultFound
                post = fetch_post_or_raise(post_id) 
            except NoResultFound:
                return jsonify({"error": "Not Found", "message": f"Post ID {post_id} does not exist."}), 404

            # Ownership Check
            if post.user_id != authenticated_user_id:
                # 403 Forbidden response
                return jsonify({
                    "error": "Permission Denied", 
                    "message": "You can only modify your own content."
                }), 403

            # Inject the loaded post object into the handler function
            return f(post=post, *args, **kwargs)
        return wrapper
    return decorator

# --- 2. Secure Modification Endpoints (Mock Implementation) ---
posts_bp = Blueprint('posts', __name__, url_prefix='/api/v1')

# Mock JWT decorator for testing ownership (User 1 is owner, User 2 is intruder)
def jwt_required(f):
    def wrapper(*args, **kwargs):
        # Mock user ID based on a header for testability
        g.user_id = request.headers.get('X-User-ID', 1, type=int) 
        return f(*args, **kwargs)
    return wrapper

@posts_bp.route('/posts/<int:post_id>', methods=['PUT'])
@jwt_required
@requires_post_ownership()
def update_post(post_id, post):
    # If we reach here, post exists and ownership is confirmed.
    # Update logic uses the injected 'post' object.
    return jsonify({"message": f"Post {post.id} updated successfully by user {g.user_id}."}), 200

@posts_bp.route('/posts/<int:post_id>', methods=['DELETE'])
@jwt_required
@requires_post_ownership()
def delete_post(post_id, post):
    # db.session.delete(post)
    return jsonify({"message": f"Post {post.id} deleted successfully."}), 204

# 4. Test Case Scenario Structure
def test_non_owner_attempts_deletion(client):
    """
    Test scenario: User ID 2 attempts to delete Post ID 1 (owned by User ID 1).
    Expected result: HTTP 403 Forbidden.
    """
    # response = client.delete(
    #     '/api/v1/posts/1', 
    #     headers={'Authorization': 'Bearer token_user_2', 'X-User-ID': 2} # Mocking User ID 2
    # )
    
    # assert response.status_code == 403
    # assert response.json['message'] == 'You can only modify your own content.'
    pass

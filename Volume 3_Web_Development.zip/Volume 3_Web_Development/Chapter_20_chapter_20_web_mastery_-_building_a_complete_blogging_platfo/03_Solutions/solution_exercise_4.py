
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
from dotenv import load_dotenv

# Ensure environment variables are loaded if using a .env file locally
load_dotenv() 

# 1. Define Base Configuration
class Config:
    """Base configuration class holding common settings and directory paths."""
    # Determine the project root directory dynamically and platform-independently
    PROJECT_ROOT = os.path.abspath(os.path.dirname(__file__))
    
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # General fallback secret key for non-sensitive uses
    SECRET_KEY = os.environ.get('SECRET_KEY', 'a_generic_app_secret')
    
    # JWT Configuration (base)
    JWT_ALGORITHM = 'HS256'

# 2. Implement Environment-Specific Configurations

class DevelopmentConfig(Config):
    """Development configuration: Debugging enabled, local SQLite."""
    DEBUG = True
    
    # Use os.path.join for platform-independent path to local SQLite file
    DEV_DB_PATH = os.path.join(Config.PROJECT_ROOT, 'data', 'dev.sqlite')
    SQLALCHEMY_DATABASE_URI = f'sqlite:///{DEV_DB_PATH}'
    
    # Insecure JWT secret is acceptable for development testing
    JWT_SECRET_KEY = 'insecure-dev-jwt-secret' 

class TestingConfig(Config):
    """Testing configuration: Isolated, in-memory database."""
    TESTING = True
    DEBUG = False
    
    # Use in-memory database for fast, isolated tests
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:' 
    
    JWT_SECRET_KEY = 'test-jwt-secret'

class ProductionConfig(Config):
    """Production configuration: Secure, external database, environment variables required."""
    DEBUG = False
    
    # 4. Secure JWT Secret: Must be loaded from environment variables
    # Documentation: Loading from os.environ prevents committing sensitive data to source control.
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY') 
    if JWT_SECRET_KEY is None:
        # Fail hard if production secret is missing
        raise ValueError("JWT_SECRET_KEY environment variable must be set in Production.")
        
    # Production database URI loaded from environment
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL')
    if SQLALCHEMY_DATABASE_URI is None:
        # Fail hard if production database URL is missing
        raise ValueError("DATABASE_URL environment variable must be set in Production.")


# 3. Refactor Application Factory

config_map = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
}

def create_app(config_name='default'):
    """
    Application factory function that dynamically loads the appropriate configuration.
    """
    from flask import Flask
    app = Flask(__name__)
    
    # Dynamically select and load configuration class
    config_class = config_map.get(config_name, DevelopmentConfig)
    app.config.from_object(config_class)
    
    # ... Initialize extensions and register blueprints ...
    
    return app

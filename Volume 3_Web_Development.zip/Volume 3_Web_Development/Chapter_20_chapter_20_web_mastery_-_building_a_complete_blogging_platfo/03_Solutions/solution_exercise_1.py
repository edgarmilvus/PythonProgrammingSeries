
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from datetime import datetime
from flask import Blueprint, request, jsonify, g
from sqlalchemy import Column, Integer, Text, DateTime, ForeignKey
from sqlalchemy.orm import relationship, backref
# Assuming db is the SQLAlchemy instance and User/Post models exist

# --- Model Definitions (Focus on Comment and relationship updates) ---

# Note: Updates required in Post model for relationship cascade:
# class Post(db.Model):
#     # ... other columns
#     comments = relationship("Comment", back_populates="post", 
#                             cascade="all, delete-orphan", passive_deletes=True)

class Comment(db.Model):
    __tablename__ = 'comments'
    id = Column(Integer, primary_key=True)
    content = Column(Text, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)

    # Foreign Keys
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    # Crucial: ondelete='CASCADE' ensures database-level integrity
    post_id = Column(Integer, ForeignKey('posts.id', ondelete='CASCADE'), nullable=False)
    
    # 3. Implement Self-Referential Threading (Optional Parent)
    parent_id = Column(Integer, ForeignKey('comments.id'), nullable=True)

    # 2. Relationships
    author = relationship("User", back_populates="comments")
    post = relationship("Post", back_populates="comments")
    
    # Self-Referential Relationship: 
    # remote_side=[id] defines the join condition back to the primary key
    parent = relationship("Comment", remote_side=[id], 
                         backref=backref("replies", cascade="all, delete-orphan"))

    def to_dict(self):
        """Serialization method including nested author details."""
        return {
            'id': self.id,
            'content': self.content,
            'timestamp': self.timestamp.isoformat(),
            'post_id': self.post_id,
            'parent_id': self.parent_id,
            'author': {
                'id': self.author.id,
                'username': self.author.username
            }
        }

# --- 4. API Endpoint Blueprint Integration ---

comments_bp = Blueprint('comments', __name__, url_prefix='/api/v1')

# Mock JWT required decorator (assumes g.user_id is set)
def jwt_required(f):
    def wrapper(*args, **kwargs):
        g.user_id = 1 # Mock authenticated user
        return f(*args, **kwargs)
    return wrapper

@comments_bp.route('/posts/<int:post_id>/comments', methods=['POST'])
@jwt_required
def create_comment(post_id):
    data = request.get_json()
    content = data.get('content')
    
    if not content:
        return jsonify({"error": "Content is required"}), 400

    # Validate Post Existence
    post = db.session.get(Post, post_id)
    if post is None:
        return jsonify({"error": "Post not found"}), 404

    try:
        new_comment = Comment(
            content=content,
            user_id=g.user_id,
            post_id=post_id,
            parent_id=data.get('parent_id')
        )
        db.session.add(new_comment)
        db.session.commit()
        db.session.refresh(new_comment) 

        return jsonify(new_comment.to_dict()), 201
    except Exception:
        db.session.rollback()
        return jsonify({"error": "Comment creation failed"}), 500

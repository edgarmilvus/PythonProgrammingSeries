
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from flask import Flask, request, redirect, url_for, flash, render_template_string, session

# Initialize App and Secret Key for flashing/sessions
app = Flask(__name__)
app.config['SECRET_KEY'] = 'a_very_secret_key_for_feedback'

# --- Conceptual Templates (Simplified for demonstration) ---

BASE_TEMPLATE = """
<!doctype html>
<html>
<head><title>Feedback System</title></head>
<body>
    {% with messages = get_flashed_messages(with_categories=true) %}
      {% if messages %}
        <ul class=flashes>
        {% for category, message in messages %}
          <li class="{{ category }}">{{ message }}</li>
        {% endfor %}
        </ul>
      {% endif %}
    {% endwith %}
    {% block content %}{% endblock %}
</body>
</html>
"""

FEEDBACK_TEMPLATE = BASE_TEMPLATE + """
{% block content %}
<h2>Submit Feedback</h2>
<form method="POST">
    <label for="name">Name:</label><br>
    <input type="text" id="name" name="name" required><br><br>
    
    <label for="email">Email:</label><br>
    <input type="email" id="email" name="email" required><br><br>
    
    <label for="message">Message:</label><br>
    <textarea id="message" name="message" required></textarea><br><br>
    
    <input type="submit" value="Submit Feedback">
</form>
{% endblock %}
"""

SUCCESS_TEMPLATE = BASE_TEMPLATE + """
{% block content %}
<h2>Success!</h2>
<p>Your feedback has been received. Thank you!</p>
<p><a href="{{ url_for('feedback') }}">Submit more feedback</a></p>
{% endblock %}
"""
# -----------------------------------------------------------

@app.route('/feedback', methods=['GET', 'POST'])
def feedback():
    if request.method == 'POST':
        form_data = request.form
        
        # 1. Basic Presence Validation
        name = form_data.get('name', '').strip()
        email = form_data.get('email', '').strip()
        message = form_data.get('message', '').strip()
        
        if not name or not email or not message:
            flash("Please fill in all required fields.", 'error')
            return redirect(url_for('feedback'))

        # 2. Basic Email Validation (checking for '@')
        if '@' not in email:
            flash("Invalid email format. Must contain '@'.", 'error')
            return redirect(url_for('feedback'))

        # 3. Success Handling
        print(f"--- New Feedback Submitted ---")
        print(f"Name: {name}")
        print(f"Email: {email}")
        print(f"Message: {message[:50]}...") # Truncate message for console log
        print("----------------------------")
        
        flash("Thank you for your feedback! We appreciate it.", 'success')
        return redirect(url_for('success'))

    # GET request: Render the form
    return render_template_string(FEEDBACK_TEMPLATE)

@app.route('/success')
def success():
    # Render success page
    return render_template_string(SUCCESS_TEMPLATE)

# To run the app: if __name__ == '__main__': app.run(debug=True)

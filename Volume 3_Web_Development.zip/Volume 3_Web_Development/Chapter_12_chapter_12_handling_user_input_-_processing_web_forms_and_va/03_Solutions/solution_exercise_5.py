
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from flask import Flask, request, jsonify, Response

app = Flask(__name__)

# Hardcoded secret for validation
SECRET_TOKEN = "SuperSecureKey123"

# 2. Implement the Global Hook
@app.before_request
def security_check_middleware():
    # 3. Conditional Check: Only run for POST requests
    if request.method == 'POST':
        
        # Check for the required header
        incoming_token = request.headers.get('X-Security-Token')
        
        # 4. Enforcement Logic
        if not incoming_token:
            return Response(
                "Missing required security token.", 
                status=403, 
                mimetype='application/json'
            )
        
        if incoming_token != SECRET_TOKEN:
            return Response(
                "Invalid security token.", 
                status=403, 
                mimetype='application/json'
            )
            
        # If the check passes, return None, allowing the request to proceed
        return None

# 1. Setup a Dummy Route
@app.route('/api/data', methods=['GET', 'POST'])
def api_data():
    if request.method == 'POST':
        # This code is only reached if the before_request check passed
        return jsonify({"status": "processed", "message": "Data successfully received."}), 200
    
    # GET requests are not checked by the middleware, so they pass through immediately
    return jsonify({"status": "ready", "method": "GET"}), 200

# To run the app: if __name__ == '__main__': app.run(debug=True)

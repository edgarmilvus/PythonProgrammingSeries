
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Reusing the Flask app and RegistrationForm definition from Exercise 2
from flask import Flask, request, redirect, url_for, flash, render_template_string
# ... (imports for WTForms, regex, etc.) ...

# ... (RegistrationForm definition from Exercise 2) ...

# --- Modified REGISTER_TEMPLATE for Field-Specific Errors and Sticky Forms ---
# Note the use of form.field.errors and form.field() in the template.
REGISTER_TEMPLATE_UX = BASE_TEMPLATE + """
{% block content %}
<h2>User Registration (UX Enhanced)</h2>

{% if form.errors %}
    {% set _ = flash("There were errors in your submission. Please correct the highlighted fields.", 'warning') %}
{% endif %}

<form method="POST">
    {{ form.hidden_tag() }}
    
    <div>
        {{ form.username.label }}: {{ form.username(class="input-field") }} 
        {% if form.username.errors %}
            <div style="color: red; font-size: 0.9em;">
                {% for error in form.username.errors %}
                    {{ error }}<br>
                {% endfor %}
            </div>
        {% endif %}
    </div><br>
    
    <div>
        {{ form.email.label }}: {{ form.email(class="input-field") }} 
        {% if form.email.errors %}
            <div style="color: red; font-size: 0.9em;">
                {% for error in form.email.errors %}
                    {{ error }}<br>
                {% endfor %}
            </div>
        {% endif %}
    </div><br>
    
    <div>
        {{ form.password.label }}: {{ form.password(class="input-field") }} 
        {% if form.password.errors %}
            <div style="color: red; font-size: 0.9em;">
                {% for error in form.password.errors %}
                    {{ error }}<br>
                {% endfor %}
            </div>
        {% endif %}
    </div><br>
    
    <div>
        {{ form.confirm_password.label }}: {{ form.confirm_password(class="input-field") }} 
        {% if form.confirm_password.errors %}
            <div style="color: red; font-size: 0.9em;">
                {% for error in form.confirm_password.errors %}
                    {{ error }}<br>
                {% endfor %}
            </div>
        {% endif %}
    </div><br>

    <input type="submit" value="Register">
</form>
{% endblock %}
"""
# -----------------------------

@app.route('/register_ux', methods=['GET', 'POST'])
def register_ux():
    form = RegistrationForm()
    
    if form.validate_on_submit():
        # Success logic (as before)
        flash(f"Registration successful for {form.username.data}!", 'success')
        return redirect(url_for('register_ux'))
    
    # 4. Flashing for Global Feedback (Conditional flash if errors exist)
    # This is handled within the template itself for conditional flashing based on form.errors
    
    # 3. Sticky Form Implementation: The `form` object is passed back to the template.
    return render_template_string(REGISTER_TEMPLATE_UX, form=form)

# To run the app: if __name__ == '__main__': app.run(debug=True)

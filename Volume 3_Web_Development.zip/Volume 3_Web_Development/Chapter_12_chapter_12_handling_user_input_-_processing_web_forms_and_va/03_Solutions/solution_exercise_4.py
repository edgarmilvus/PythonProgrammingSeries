
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from flask import Flask, request, redirect, url_for, flash, render_template_string
import bleach # 1. Identify a Sanitization Library

app = Flask(__name__)
app.config['SECRET_KEY'] = 'xss_mitigation_key'

# --- Configuration for Bleach ---
# 2. Define Allowed Tags and Attributes
ALLOWED_TAGS = ['b', 'i', 'u', 'p', 'a']
ALLOWED_ATTRIBUTES = {
    'a': ['href'], # Only allow href attribute for links
    '*': ['title'] # Allow title attribute on all allowed tags
}

# --- Conceptual Templates ---
ARTICLE_FORM = BASE_TEMPLATE + """
{% block content %}
<h2>Submit Article</h2>
<form method="POST">
    <label for="title">Title:</label><br>
    <input type="text" id="title" name="title" required><br><br>
    
    <label for="content">Content (Allows basic HTML):</label><br>
    <textarea id="content" name="content" rows="10" cols="50" required></textarea><br><br>
    
    <input type="submit" value="Submit Article">
</form>
{% endblock %}
"""

ARTICLE_DISPLAY = BASE_TEMPLATE + """
{% block content %}
<h2>Article Submitted: {{ title }}</h2>
<h3>Raw Content (Simulated Display):</h3>
<!-- 5. Display Logic: We use |safe here because bleach ensures the content is safe HTML, 
     but Jinja's auto-escaping would otherwise render the tags literally. -->
<div style="border: 1px solid #ccc; padding: 10px;">
    {{ sanitized_content | safe }}
</div>
<p><a href="{{ url_for('submit_article') }}">Submit another article</a></p>
{% endblock %}
"""
# -----------------------------

@app.route('/submit_article', methods=['GET', 'POST'])
def submit_article():
    if request.method == 'POST':
        title = request.form.get('title', '')
        raw_content = request.form.get('content', '')
        
        if not title or not raw_content:
            flash("Title and content are required.", 'error')
            return redirect(url_for('submit_article'))

        # 3. Sanitization Implementation
        # Clean the raw input using the defined whitelist
        sanitized_content = bleach.clean(
            raw_content,
            tags=ALLOWED_TAGS,
            attributes=ALLOWED_ATTRIBUTES,
            strip=True # Removes unwanted tags entirely
        )
        
        # 4. Demonstrate Vulnerability and Fix:
        # If raw_content contained: <p>Hello</p><script>alert('XSS');</script>
        # sanitized_content will only contain: <p>Hello</p>
        print("--- Security Check ---")
        print(f"Raw Input (Potential XSS): {raw_content[:50]}...")
        print(f"Sanitized Output (Safe): {sanitized_content[:50]}...")
        print("----------------------")

        flash("Article submitted and content sanitized.", 'success')
        
        # Return the sanitized content for display
        return render_template_string(
            ARTICLE_DISPLAY, 
            title=title, 
            sanitized_content=sanitized_content
        )

    return render_template_string(ARTICLE_FORM)

# To run the app: if __name__ == '__main__': app.run(debug=True)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from flask import Flask, request, redirect, url_for, flash, render_template_string
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, IntegerField
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError
import re # Used for complex password regex

app = Flask(__name__)
app.config['SECRET_KEY'] = 'another_secret_key_for_registration'

# --- WTForms Definition ---
class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[
        DataRequired(),
        Length(min=6, max=20, message='Username must be between 6 and 20 characters.')
    ])
    
    email = StringField('Email', validators=[
        DataRequired(),
        Email(message='Invalid email address.')
    ])
    
    password = PasswordField('Password', validators=[
        DataRequired()
        # Custom validator defined below handles length and complexity
    ])
    
    confirm_password = PasswordField('Confirm Password', validators=[
        DataRequired(),
        EqualTo('password', message='Passwords must match.')
    ])

    age = IntegerField('Age (Optional)', validators=[
        # IntegerField handles non-numeric input automatically with a default error
        # We allow it to be optional by not including DataRequired()
    ])

    # 3. Custom Password Validator Method
    def validate_password(self, field):
        password = field.data
        
        # 1. Minimum length of 10 characters
        if len(password) < 10:
            raise ValidationError('Password must be at least 10 characters long.')
        
        # 2. Must contain at least one uppercase letter (A-Z)
        if not re.search(r'[A-Z]', password):
            raise ValidationError('Password must contain at least one uppercase letter.')
        
        # 3. Must contain at least one digit (0-9)
        if not re.search(r'[0-9]', password):
            raise ValidationError('Password must contain at least one digit.')
            
        # 4. Must contain at least one special character (using common symbols)
        if not re.search(r'[!@#$%^&*()]', password):
            raise ValidationError('Password must contain at least one special character (e.g., !, @, #, $).')

# --- Conceptual Template ---
REGISTER_TEMPLATE = BASE_TEMPLATE + """
{% block content %}
<h2>User Registration</h2>
<form method="POST">
    {{ form.hidden_tag() }}
    
    {{ form.username.label }}: {{ form.username() }} 
    {% if form.username.errors %}<ul class="errors">{% for error in form.username.errors %}<li>{{ error }}</li>{% endfor %}</ul>{% endif %}<br>
    
    {{ form.email.label }}: {{ form.email() }} 
    {% if form.email.errors %}<ul class="errors">{% for error in form.email.errors %}<li>{{ error }}</li>{% endfor %}</ul>{% endif %}<br>
    
    {{ form.password.label }}: {{ form.password() }} 
    {% if form.password.errors %}<ul class="errors">{% for error in form.password.errors %}<li>{{ error }}</li>{% endfor %}</ul>{% endif %}<br>
    
    {{ form.confirm_password.label }}: {{ form.confirm_password() }} 
    {% if form.confirm_password.errors %}<ul class="errors">{% for error in form.confirm_password.errors %}<li>{{ error }}</li>{% endfor %}</ul>{% endif %}<br>

    {{ form.age.label }}: {{ form.age() }} 
    {% if form.age.errors %}<ul class="errors">{% for error in form.age.errors %}<li>{{ error }}</li>{% endfor %}</ul>{% endif %}<br>

    <input type="submit" value="Register">
</form>
{% endblock %}
"""
# -----------------------------

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    
    if form.validate_on_submit():
        # Validation successful
        print(f"User Registered: {form.username.data} ({form.email.data})")
        print(f"Age (coerced): {form.age.data if form.age.data is not None else 'N/A'}")
        
        flash(f"Registration successful for {form.username.data}!", 'success')
        return redirect(url_for('register')) # Redirecting back to clear the form
    
    # Renders form on GET or if validation fails on POST
    return render_template_string(REGISTER_TEMPLATE, form=form)

# To run the app: if __name__ == '__main__': app.run(debug=True)

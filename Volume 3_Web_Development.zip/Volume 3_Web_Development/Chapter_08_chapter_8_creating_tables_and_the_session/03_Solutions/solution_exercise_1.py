
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from sqlalchemy import create_engine, Column, Integer, String, Numeric
from sqlalchemy.orm import declarative_base, sessionmaker

# --- Foundational Setup ---
engine = create_engine('sqlite:///:memory:')
Base = declarative_base()
Session = sessionmaker(bind=engine)

# 1. Model Definition
class InventoryItem(Base):
    __tablename__ = 'inventory'
    item_id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    quantity = Column(Integer, default=0)
    # Using Numeric for precise monetary representation
    unit_price = Column(Numeric(10, 2), nullable=False)

    def __repr__(self):
        return f"<InventoryItem(id={self.item_id}, name='{self.name}', price={self.unit_price})>"

# 2. Table Creation
Base.metadata.create_all(engine)

# 3. Data Insertion (Session Management)
session = Session()

# Create instances (Transient state)
item1 = InventoryItem(name='Laptop', quantity=5, unit_price=1200.00)
item2 = InventoryItem(name='Monitor', quantity=25, unit_price=350.50) # Quantity > 10
item3 = InventoryItem(name='Keyboard', quantity=15, unit_price=75.99)

# Stage objects (Pending state)
session.add_all([item1, item2, item3])

# Persist changes (Persistent state)
session.commit()

# 4. Verification (State Check)
print("--- Verification of Persistent Data ---")
all_items = session.query(InventoryItem).all()
for item in all_items:
    # item.item_id is now populated by the database
    print(f"ID: {item.item_id}, Name: {item.name}, Quantity: {item.quantity}")

session.close()

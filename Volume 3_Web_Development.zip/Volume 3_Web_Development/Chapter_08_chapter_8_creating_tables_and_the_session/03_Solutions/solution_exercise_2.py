
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from sqlalchemy.orm import Session as SQLASession # Ensure Session factory from E1 is used

# Use the existing engine and Base from Exercise 1
# Note: We assume the data from E1 is committed and available.

# 1. Session Preparation
session = Session()

try:
    # 2. Object Retrieval and Modification
    monitor = session.query(InventoryItem).filter_by(name='Monitor').one()
    
    original_price = monitor.unit_price
    print(f"Monitor original price (pre-modification): {original_price}")

    # Apply 15% reduction (Object state transitions to Dirty)
    monitor.unit_price = original_price * 0.85
    print(f"Monitor new price (staged modification): {monitor.unit_price}")

    # 3. Staging a New Object
    server_rack = InventoryItem(name='Server Rack', quantity=2, unit_price=999.99)
    session.add(server_rack) # Object state transitions to Pending
    print(f"Added 'Server Rack' to session (Pending).")

    # 4. Transaction Cancellation
    print("\nExecuting rollback...")
    session.rollback() # Discards both Dirty and Pending changes

except Exception as e:
    print(f"An error occurred: {e}")
    session.rollback()

finally:
    session.close()

# 5. Verification
# Open a new session to guarantee retrieval from the database, not the former session cache
verification_session = Session()
print("\n--- Verification After Rollback ---")

# Verify Monitor Price
rolled_back_monitor = verification_session.query(InventoryItem).filter_by(name='Monitor').one()
print(f"Monitor price after rollback: {rolled_back_monitor.unit_price}")

# Verify Server Rack Non-existence
from sqlalchemy.exc import NoResultFound
try:
    verification_session.query(InventoryItem).filter_by(name='Server Rack').one()
    print("Error: Server Rack was found (Rollback failed).")
except NoResultFound:
    print("Success: Server Rack was not found (Rollback successful).")

verification_session.close()

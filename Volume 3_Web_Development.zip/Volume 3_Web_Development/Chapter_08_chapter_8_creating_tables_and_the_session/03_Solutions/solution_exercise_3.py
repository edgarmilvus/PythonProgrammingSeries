
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from sqlalchemy import Float, delete
from sqlalchemy.orm import Session as SQLASession

# --- Resetting for Model Augmentation ---
# Drop existing tables to ensure the augmented model is created correctly
Base.metadata.drop_all(engine) 

# 1. Model Augmentation (Redefinition)
class CustomerOrder(Base):
    __tablename__ = 'orders'
    order_id = Column(Integer, primary_key=True)
    customer_name = Column(String(100), nullable=False)
    total_amount = Column(Float, nullable=False)
    # New column added
    shipping_status = Column(String(50), default='Pending')

    def __repr__(self):
        return f"<Order(id={self.order_id}, total={self.total_amount}, status='{self.shipping_status}')>"

# Recreate tables with the new structure
Base.metadata.create_all(engine)

# 2. Initial Data Population
session = Session()
orders_data = [
    CustomerOrder(customer_name='Alice', total_amount=150.00),
    CustomerOrder(customer_name='Bob', total_amount=650.75), # High value
    CustomerOrder(customer_name='Charlie', total_amount=99.99),
    CustomerOrder(customer_name='David', total_amount=1200.50), # High value
    CustomerOrder(customer_name='Eve', total_amount=501.00) # High value
]
session.add_all(orders_data)
session.commit()
print("Initial 5 orders committed.")

# 3. Bulk Update Function
def prioritize_orders(session: SQLASession):
    print("\n--- Prioritizing High-Value Orders ---")
    
    # Query high-value orders
    high_value_orders = session.query(CustomerOrder).filter(
        CustomerOrder.total_amount > 500.00
    ).all()
    
    # Iterate and modify status (objects become Dirty)
    for order in high_value_orders:
        order.shipping_status = 'Priority Processing'
        print(f"Order {order.order_id} ({order.customer_name}) updated to Priority.")
        
    session.commit() # Persist changes

    # 4. Reporting with List Comprehension
    all_orders = session.query(CustomerOrder).all()
    
    # Generate report list using list comprehension
    priority_report = [
        (order.order_id, order.customer_name)
        for order in all_orders
        if order.shipping_status == 'Priority Processing'
    ]
    
    print("\nPriority Processing Report (ID, Customer Name):")
    print(priority_report)

# Execute the update
prioritize_orders(session)
session.close()

# 5. Visualization of the Transaction (Conceptual Analysis)
print("\n--- Conceptual Analysis of State Transitions ---")
print("The high-value order objects transition through the following states:")
print("1. Transient: When the Python object is created but not added to the session.")
print("2. Persistent: After session.add() and session.commit() in the initial population step.")
print("3. Dirty: When the order's 'shipping_status' attribute is modified within the session.")
print("4. Persistent: After session.commit() in the prioritize_orders function, saving the new status.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import socket
import io
# Assuming build_http_response from Exercise 2 is available

def mock_server_handler(client_socket):
    """
    Simulates the core logic of a server request handler, focusing on POST body reading.
    
    NOTE: In a real server, the client_socket would be a live connection.
          Here, we simulate input/output for demonstration.
    """
    
    # --- SIMULATED INPUT DATA (What the socket would receive) ---
    # We simulate receiving the request line and headers first.
    # We use a simple dictionary for parsed headers for this demonstration.
    
    request_line = "POST /submit_data HTTP/1.1"
    request_headers = {
        'Host': 'localhost',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': '30' # The payload size
    }
    
    # Parse method and uri (using Exercise 1 logic)
    try:
        parsed_request = parse_request_line(request_line)
        method = parsed_request['method']
        uri = parsed_request['uri']
    except InvalidRequestLineError:
        # Handle 400 Bad Request
        return build_http_response(400, "Bad Request", "text/plain")

    # Initialize post_body to None
    raw_post_body = None

    # 1. Identify Method and 2. Extract Content-Length
    if method == 'POST':
        if 'Content-Length' in request_headers:
            try:
                content_length = int(request_headers['Content-Length'])
            except ValueError:
                # Handle case where Content-Length is not an integer
                return build_http_response(400, "Invalid Content-Length", "text/plain")
            
            # 3. Read Body Data (Simulated Socket Read)
            
            # --- CRITICAL LOW-LEVEL CHALLENGE SIMULATION ---
            
            # In a real server, this is where the socket reads the payload.
            # We must ensure the socket doesn't block by reading exactly 'content_length' bytes.
            
            # Mocking the socket's behavior for demonstration:
            mock_payload = b"username=test&password=secret" # Length is 30 bytes
            
            # client_socket.recv(content_length) is simulated here:
            if len(mock_payload) == content_length:
                raw_post_body = mock_payload
            else:
                # In a real scenario, this would involve complex buffering/streaming.
                print("Error: Mock payload size mismatch.")
                
            # 4. Logging
            if raw_post_body:
                print(f"\n--- POST Request Handler ---")
                print(f"URI: {uri}")
                print(f"Content-Length: {content_length}")
                print(f"Received POST Data: {raw_post_body.decode('utf-8')}")
                print("----------------------------\n")
        else:
            # POST request without Content-Length is malformed
            return build_http_response(400, "Content-Length required for POST", "text/plain")
            
    # 5. Response
    if method == 'POST':
        response_body = "Data received successfully."
        return build_http_response(200, response_body, "text/plain")
    else:
        # Handle GET or other methods normally (e.g., 405 Method Not Allowed if not implemented)
        return build_http_response(200, "GET handled (mock)", "text/plain")


# Since we cannot run a live socket here, we run the handler mock:
mock_response = mock_server_handler(None)
print("Generated Response Status Line:")
print(mock_response.split('\r\n')[0])

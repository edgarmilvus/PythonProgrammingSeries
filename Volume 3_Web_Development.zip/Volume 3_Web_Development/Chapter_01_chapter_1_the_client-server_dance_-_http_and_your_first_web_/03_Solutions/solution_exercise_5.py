
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

def parse_headers(raw_header_lines: list[str]) -> dict:
    """
    Converts a list of raw HTTP header lines into a standardized dictionary.
    Keys are normalized to Title-Case.
    """
    headers = {}
    
    for line in raw_header_lines:
        line = line.strip()
        if not line:
            continue
            
        # 2. Delimiter Handling: Split only on the first colon
        try:
            # Find the index of the first colon
            separator_index = line.find(':')
            if separator_index == -1:
                # Skip malformed lines without a colon
                continue

            key = line[:separator_index].strip()
            value = line[separator_index + 1:].strip()
            
            # 3. Standardization: Normalize key to Title-Case (e.g., content-length -> Content-Length)
            # Note: Title-Case works well for most standard HTTP headers.
            normalized_key = key.replace('-', ' ').title().replace(' ', '-')
            
            # 4. Output Structure
            headers[normalized_key] = value
            
        except Exception as e:
            # Log or handle parsing error for a specific line
            print(f"Warning: Failed to parse header line '{line}'. Error: {e}")
            continue
            
    return headers

# Example Testing:
raw_headers = [
    "Host: localhost:8080",
    "user-agent: Mozilla/5.0",
    "Accept-Encoding: gzip, deflate, br",
    "content-length: 150",
    "X-Custom-Header: value with: colon"
]

parsed_dict = parse_headers(raw_headers)
print("\n--- Parsed Headers (Normalized) ---")
import pprint
pprint.pprint(parsed_dict)

# Verification of normalization and complex values:
assert parsed_dict['Content-Length'] == '150'
assert parsed_dict['User-Agent'] == 'Mozilla/5.0'
assert parsed_dict['X-Custom-Header'] == 'value with: colon'

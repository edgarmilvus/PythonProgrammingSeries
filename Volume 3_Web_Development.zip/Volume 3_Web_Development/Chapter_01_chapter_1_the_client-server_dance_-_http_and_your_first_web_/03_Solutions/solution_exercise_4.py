
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import json
# Assuming build_http_response from Exercise 2 is available

# --- 1. Define Handler Functions ---

def handle_home():
    """Handler for the root path /."""
    body = "<html><body><h1>Welcome to the Raw Server!</h1></body></html>"
    return 200, body, "text/html"

def handle_about():
    """Handler for the /about path."""
    body = "This is a minimalist Python socket server, built without frameworks."
    return 200, body, "text/plain"

def handle_api_status():
    """Handler for the /api/status path, returning JSON."""
    status_data = {"status": "running", "uptime_seconds": 3600}
    body = json.dumps(status_data)
    return 200, body, "application/json"

def handle_404():
    """Generic handler for paths not found."""
    body = "<h1>404 Not Found</h1><p>The requested resource does not exist.</p>"
    return 404, body, "text/html"

# --- 2. Routing Table ---
ROUTE_MAP = {
    '/': handle_home,
    '/about': handle_about,
    '/api/status': handle_api_status
}

# --- 3. Routing Logic (Dispatcher) ---

def route_request(uri: str) -> str:
    """
    Dispatches the request based on the URI path to the appropriate handler.
    Returns the complete HTTP response string.
    """
    
    # Clean URI to handle potential query parameters (though not fully parsed here)
    path = uri.split('?')[0] 
    
    if path in ROUTE_MAP:
        handler = ROUTE_MAP[path]
        print(f"Dispatching request for {path} to {handler.__name__}")
        
        # Execute the handler function
        status, body, content_type = handler()
    else:
        # Handle 404 Not Found
        print(f"URI {path} not found. Returning 404.")
        status, body, content_type = handle_404()

    # Use the function from Exercise 2 to assemble the final response
    return build_http_response(status, body, content_type)

# Example Testing:
print("\n--- Testing Routing: / ---")
print(route_request('/'))

print("\n--- Testing Routing: /api/status ---")
print(route_request('/api/status'))

print("\n--- Testing Routing: /unknown ---")
print(route_request('/unknown'))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import datetime

def build_http_response(status_code: int, content_body: str, content_type: str) -> str:
    """
    Assembles a complete HTTP response string ready for socket transmission.
    """
    
    # 1. Status Line Mapping
    STATUS_PHRASES = {
        200: "OK",
        404: "Not Found",
        500: "Internal Server Error"
    }
    
    reason_phrase = STATUS_PHRASES.get(status_code, "Unknown Status")
    status_line = f"HTTP/1.1 {status_code} {reason_phrase}\r\n"
    
    # Determine content length (must be byte length)
    body_bytes = content_body.encode('utf-8')
    content_length = len(body_bytes)
    
    # 2. Header Generation
    
    # RFC 1123 Date format
    now = datetime.datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')
    
    headers = [
        f"Content-Type: {content_type}",
        f"Content-Length: {content_length}",
        f"Date: {now}",
        "Connection: close" # Standard practice for simple server responses
    ]
    
    header_block = "\r\n".join(headers)
    
    # 3. Response Structure: Status Line + Headers + Empty Line + Body
    response = (
        status_line + 
        header_block + 
        "\r\n\r\n" + # Mandatory blank line separating headers from body
        content_body
    )
    
    return response

# Example Testing:
html_content = "<h1>Success!</h1>"
response_200 = build_http_response(200, html_content, "text/html")
print("--- HTML Response (200 OK) ---")
print(response_200)

json_content = '{"user": "admin"}'
response_json = build_http_response(200, json_content, "application/json")
print("\n--- JSON Response (200 OK) ---")
print(response_json)

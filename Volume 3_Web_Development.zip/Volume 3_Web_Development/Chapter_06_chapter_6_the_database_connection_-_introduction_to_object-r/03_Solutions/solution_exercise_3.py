
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
from datetime import datetime
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

# --- Setup from Exercise 2 (Full setup assumed) ---
DATABASE_FILE = "site_content.db"
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_URI = 'sqlite:///' + os.path.join(BASE_DIR, DATABASE_FILE)

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = DB_URI
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Article(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    content = db.Column(db.Text)
    publication_timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    is_published = db.Column(db.Boolean, default=True)
    def __repr__(self):
        return f"<Article Title: '{self.title}'>"

def initialize_database():
    with app.app_context():
        if os.path.exists(DATABASE_FILE):
            os.remove(DATABASE_FILE)
        db.create_all()
        print("Database initialized.")

def add_new_article(title, content, is_published=True):
    with app.app_context():
        new_article = Article(title=title, content=content, is_published=is_published)
        db.session.add(new_article)
        db.session.commit()
        print(f"[CREATE SUCCESS] Added article: '{title}' (ID: {new_article.id})")

def list_all_articles():
    with app.app_context():
        articles = Article.query.all()
        print("\n--- Listing All Articles ---")
        for article in articles:
            print(f"ID: {article.id:<3} | Title: {article.title:<30} | Published: {article.is_published}")
        print("----------------------------\n")

# 1. Update Function
def update_article_title(article_id, new_title):
    with app.app_context():
        # Retrieve the object by primary key
        article = Article.query.get(article_id)

        # Error Handling
        if article is None:
            print(f"[UPDATE FAILED] Article with ID {article_id} not found.")
            return

        # Modify the Python object attribute (U operation)
        old_title = article.title
        article.title = new_title
        
        db.session.commit()
        print(f"[UPDATE SUCCESS] Article ID {article_id} title changed from '{old_title}' to '{new_title}'")

# 2. Deletion Function
def delete_unpublished_articles():
    with app.app_context():
        # Query for all unpublished articles
        target_articles = Article.query.filter_by(is_published=False).all()
        
        count = 0
        for article in target_articles:
            # Stage the object for deletion (D operation)
            db.session.delete(article)
            count += 1
        
        if count > 0:
            db.session.commit()
            print(f"[DELETE SUCCESS] Successfully deleted {count} unpublished article(s).")
        else:
            print("[DELETE INFO] No unpublished articles found to delete.")

if __name__ == '__main__':
    initialize_database()
    
    # Setup initial data
    add_new_article("Old First Post Title", "Content 1") # ID 1
    add_new_article("Second Thoughts", "Content 2")      # ID 2
    add_new_article("The Final Chapter", "Content 3")    # ID 3
    
    # Insert unpublished article (for deletion test)
    add_new_article("Draft: Needs Review", "Draft Content", is_published=False) # ID 4

    print("\n--- State Before Update and Delete ---")
    list_all_articles()

    # 3. Execution Sequence: Update
    update_article_title(article_id=1, new_title="The New and Improved Title")
    
    print("\n--- State After Update ---")
    list_all_articles()

    # 3. Execution Sequence: Delete
    delete_unpublished_articles()
    
    print("\n--- State After Deletion ---")
    list_all_articles()

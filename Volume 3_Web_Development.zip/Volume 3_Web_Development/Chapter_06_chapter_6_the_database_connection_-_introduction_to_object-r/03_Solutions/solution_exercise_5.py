
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import os
from datetime import datetime
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

# --- Setup ---
DATABASE_FILE = "site_content_validation.db"
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_URI = 'sqlite:///' + os.path.join(BASE_DIR, DATABASE_FILE)

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = DB_URI
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# 1. Model Enhancement
class Article(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    content = db.Column(db.Text)
    publication_timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    is_published = db.Column(db.Boolean, default=True)
    
    # New column for scheduled publishing
    scheduled_date = db.Column(db.DateTime, nullable=True) 

    def __repr__(self):
        return f"<Article Title: '{self.title}' Scheduled: {self.scheduled_date}>"

def initialize_database():
    with app.app_context():
        if os.path.exists(DATABASE_FILE):
            os.remove(DATABASE_FILE)
        db.create_all()
        print("Validation Database initialized.")

# 2. Parsing Function
def parse_and_save_article(title, content, date_string=""):
    DATE_FORMAT = "%Y-%m-%d %H:%M"
    parsed_date = None

    if date_string:
        try:
            # Date Parsing Logic
            parsed_date = datetime.strptime(date_string, DATE_FORMAT)
            print(f"[INFO] Successfully parsed date string: {date_string}")
        
        # Error Handling: Catches failure if the date string doesn't match the format
        except ValueError:
            print("-" * 50)
            print(f"[ERROR] Date parsing failed for '{date_string}'.")
            print(f"Required format is: {DATE_FORMAT} (e.g., 2025-01-01 10:00)")
            print("Article NOT saved due to invalid input.")
            print("-" * 50)
            return
            
    with app.app_context():
        new_article = Article(
            title=title, 
            content=content, 
            scheduled_date=parsed_date
        )
        db.session.add(new_article)
        db.session.commit()
        print(f"[SAVE SUCCESS] Article '{title}' saved.")

# 5. Verification Function
def list_scheduled_articles():
    with app.app_context():
        articles = Article.query.all()
        print("\n--- Saved Articles Status ---")
        if not articles:
            print("No articles found.")
            return

        for article in articles:
            schedule = article.scheduled_date.strftime('%Y-%m-%d %H:%M') if article.scheduled_date else "N/A (Immediate)"
            print(f"Title: {article.title:<30} | Scheduled: {schedule}")
        print("----------------------------------\n")

if __name__ == '__main__':
    initialize_database()
    
    # 3. Testing Successful Input
    parse_and_save_article(
        title="Future Release Article",
        content="This will be published next year.",
        date_string="2025-01-01 10:00" 
    )

    # 4. Testing Invalid Input (Should fail and not save)
    parse_and_save_article(
        title="Bad Date Input",
        content="This should fail to save.",
        date_string="01/01/2025" # Incorrect format
    )

    # Test immediate publish (no date string)
    parse_and_save_article(
        title="Immediate Publish",
        content="This is live now.",
        date_string=""
    )

    # Verification
    list_scheduled_articles()

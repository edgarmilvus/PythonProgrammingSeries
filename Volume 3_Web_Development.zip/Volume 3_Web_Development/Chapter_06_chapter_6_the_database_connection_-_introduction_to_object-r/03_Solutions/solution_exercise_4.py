
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
from datetime import datetime
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

# --- Setup ---
DATABASE_FILE = "site_content_relational.db"
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_URI = 'sqlite:///' + os.path.join(BASE_DIR, DATABASE_FILE)

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = DB_URI
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# 1. Define the Author Model
class Author(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    
    # 3. Define Backref: Allows author_instance.articles to list all related articles
    articles = db.relationship('Article', backref='author', lazy=True)

    def __repr__(self):
        return f"<Author username='{self.username}'>"

# 2. Modify Article Model
class Article(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    content = db.Column(db.Text)
    publication_timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    is_published = db.Column(db.Boolean, default=True)

    # Add Foreign Key (Links Article to Author)
    author_id = db.Column(db.Integer, db.ForeignKey('author.id'), nullable=False)
    
    def __repr__(self):
        return f"<Article Title: '{self.title}' by Author ID: {self.author_id}>"

def initialize_database():
    with app.app_context():
        if os.path.exists(DATABASE_FILE):
            os.remove(DATABASE_FILE)
        db.create_all()
        print("Relational Database initialized.")

# 4. Data Insertion (Relational)
def create_author_and_article(username, email, article_title, article_content):
    with app.app_context():
        # Check if author exists
        author = Author.query.filter_by(username=username).first()
        
        if author is None:
            author = Author(username=username, email=email)
            db.session.add(author)
            db.session.commit() # Commit needed to assign the author ID
            print(f"Created new Author: {username}")

        # Create the new Article, linking it using the relationship attribute
        new_article = Article(
            title=article_title, 
            content=article_content,
            author=author # Assigns the Author object, ORM handles author_id assignment
        )
        db.session.add(new_article)
        db.session.commit()
        print(f"--> Created article '{article_title}' for {username}.")

# 5. Relational Query
def get_author_articles(username):
    with app.app_context():
        author = Author.query.filter_by(username=username).first()
        
        if not author:
            print(f"\nAuthor '{username}' not found.")
            return
            
        print(f"\n--- Articles written by {author.username} ({len(author.articles)} total) ---")
        
        # Access articles directly via the relationship property
        for article in author.articles:
            print(f" - ID {article.id}: {article.title}")
        print("------------------------------------------")

if __name__ == '__main__':
    initialize_database()
    
    create_author_and_article("alice_writer", "alice@example.com", "Alice's First Post", "Content A1")
    create_author_and_article("bob_editor", "bob@example.com", "Bob's Initial Thoughts", "Content B1")
    create_author_and_article("alice_writer", "alice@example.com", "Alice's Second Article", "Content A2")
    
    get_author_articles("alice_writer")
    get_author_articles("bob_editor")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os
from datetime import datetime
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

# --- Setup from Exercise 1 ---
DATABASE_FILE = "site_content.db"
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_URI = 'sqlite:///' + os.path.join(BASE_DIR, DATABASE_FILE)

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = DB_URI
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Article(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    content = db.Column(db.Text)
    publication_timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    is_published = db.Column(db.Boolean, default=True)
    def __repr__(self):
        return f"<Article Title: '{self.title}'>"

def initialize_database():
    with app.app_context():
        if os.path.exists(DATABASE_FILE):
            os.remove(DATABASE_FILE)
        db.create_all()
        print("Database initialized.")

# 1. Creation Function
def add_new_article(title, content, is_published=True):
    with app.app_context():
        new_article = Article(title=title, content=content, is_published=is_published)
        db.session.add(new_article)
        db.session.commit()
        print(f"[CREATE SUCCESS] Added article: '{title}' (ID: {new_article.id})")

# 2. Reading Function
def list_all_articles():
    with app.app_context():
        # Retrieve all records
        articles = Article.query.all()
        
        print("\n--- Listing All Articles ---")
        if not articles:
            print("No articles found.")
            return

        for article in articles:
            time_str = article.publication_timestamp.strftime('%Y-%m-%d %H:%M:%S')
            print(f"ID: {article.id:<3} | Title: {article.title:<20} | Time: {time_str}")
        print("----------------------------\n")

if __name__ == '__main__':
    initialize_database()
    
    # 3. Execution Sequence
    add_new_article("First Post", "This is the content of the first article.")
    add_new_article("Second Thoughts", "Revisiting initial ideas.")
    add_new_article("The Final Chapter", "Concluding the series.")
    
    list_all_articles()

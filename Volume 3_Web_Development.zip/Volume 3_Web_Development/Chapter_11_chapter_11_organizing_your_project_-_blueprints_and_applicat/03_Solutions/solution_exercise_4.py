
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# --- config.py (Updated) ---
class Config:
    SECRET_KEY = 'base-key'

class DevelopmentConfig(Config):
    DEBUG = True
    SECRET_KEY = 'dev-key'
    # ADMIN_TOKEN is intentionally missing

class ProductionConfig(Config):
    SECRET_KEY = 'super-secure-production-key-987'
    ADMIN_TOKEN = 'secure-prod-token' # Required token

# --- app/admin/routes.py ---
from flask import Blueprint, current_app

admin_bp = Blueprint('admin_bp', __name__, url_prefix='/admin')

@admin_bp.route('/dashboard')
def dashboard():
    """
    Checks for ADMIN_TOKEN in the application configuration.
    Requires application context (current_app).
    """
    # Access config via current_app, which points to the instance 
    # created by the factory.
    if current_app.config.get('ADMIN_TOKEN'):
        return "Admin Dashboard Active. Token Found."
    else:
        return "Admin Dashboard Disabled. Missing Production Token."

# --- app/__init__.py (Updated Factory) ---
from flask import Flask
from config import DevelopmentConfig 
# Assuming main_bp is registered (from E3)
from app.admin.routes import admin_bp 

def create_app(config_class=DevelopmentConfig):
    app = Flask(__name__)
    app.config.from_object(config_class)
    
    # Register the admin blueprint
    app.register_blueprint(admin_bp)
    
    return app

# --- verification_script.py ---
from app import create_app
from config import DevelopmentConfig, ProductionConfig

# Helper function to test route output
def verify_admin_route(config_class, environment_name):
    app_instance = create_app(config_class=config_class)
    # Use test_client to simulate a request within the application context
    with app_instance.test_client() as client:
        response = client.get('/admin/dashboard')
        print(f"--- {environment_name} Test Result ---")
        print(response.data.decode('utf-8'))

# Verification 1: Development (Token Missing)
verify_admin_route(DevelopmentConfig, "Development")

# Verification 2: Production (Token Found)
verify_admin_route(ProductionConfig, "Production")

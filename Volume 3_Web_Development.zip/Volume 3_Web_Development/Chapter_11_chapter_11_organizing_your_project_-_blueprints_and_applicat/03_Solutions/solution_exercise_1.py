
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# --- status/routes.py ---
from flask import Blueprint, jsonify

# Define the Blueprint with a URL prefix
status_bp = Blueprint('status_bp', __name__, url_prefix='/status')

@status_bp.route('/health')
def health_check():
    """Returns the application health status."""
    return jsonify({"status": "ok"})

# --- app.py ---
from flask import Flask
from status.routes import status_bp

# 1. Application Instance
app = Flask(__name__)

# 2. Main landing page (kept in app.py for this exercise)
@app.route('/')
def index():
    return "Welcome to the main application."

# 3. Register the Blueprint
# This makes the route available at /status/health
app.register_blueprint(status_bp)

# To test:
# if __name__ == '__main__':
#     app.run(debug=True)
# Access http://127.0.0.1:5000/status/health

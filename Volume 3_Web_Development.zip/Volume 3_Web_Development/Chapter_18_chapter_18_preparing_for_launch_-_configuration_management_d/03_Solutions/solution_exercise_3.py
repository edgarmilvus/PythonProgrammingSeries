
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# app/__init__.py (Modified for dotenv)

import os
from flask import Flask, jsonify
from dotenv import load_dotenv # 1. Import the necessary tool
from config import config_map, DevelopmentConfig 

# 3. Conditional Loading: Load .env file contents into os.environ
# This should be called early. load_dotenv() respects existing OS variables.
load_dotenv() 

def create_app(config_name=None):
    
    # 2. Configuration selection logic (now reads potentially loaded env vars)
    if config_name is None:
        config_name = os.environ.get('FLASK_ENV', 'development')
    
    config_class = config_map.get(config_name, DevelopmentConfig)
    
    try:
        config_object = config_class()
    except ValueError as e:
        print(f"FATAL CONFIGURATION ERROR: {e}")
        raise 

    app = Flask(__name__)
    app.config.from_object(config_object)
    app.config['FLASK_ENV'] = config_name

    @app.route('/config')
    def get_config():
        return jsonify({
            'FLASK_ENV': app.config['FLASK_ENV'],
            'DATABASE_URL': app.config.get('DATABASE_URL'),
            'OS_ENV_CHECK': os.environ.get('DATABASE_URL')
        })

    return app

# --- Testing Priority Demonstration ---
# 2. Environment File Creation (Simulated content of .env file):
# FLASK_ENV=development
# DATABASE_URL=sqlite:///dev_db.sqlite

# Test 1: Load from .env (Shell is clean)
# Setup: os.environ['DATABASE_URL'] is not set initially.
# load_dotenv() runs, setting os.environ['DATABASE_URL'] to 'sqlite:///dev_db.sqlite'
# app_test1 = create_app()
# print(f"\nTest 1 (From .env): {app_test1.config['DATABASE_URL']}") 
# Expected Output: sqlite:///dev_db.sqlite

# Test 2: Shell Override (Shell export takes precedence)
# os.environ['DATABASE_URL'] = 'postgres://shell_override' 
# load_dotenv() runs but respects the existing 'postgres://shell_override'.
# app_test2 = create_app()
# print(f"Test 2 (Shell Override): {app_test2.config['DATABASE_URL']}") 
# Expected Output: postgres://shell_override


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# config.py

import os
import sys

# Define base configuration
class Config:
    # 1. Base configuration and environment variable loading logic
    SECRET_KEY = os.environ.get('SECRET_KEY', 'default-insecure-key-for-dev')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    LOG_LEVEL = 'INFO'
    
    # 3. Secure Secret Loading: Load DATABASE_URL exclusively from environment
    DATABASE_URL = os.environ.get('DATABASE_URL')
    
    # Ex 4 requirement: Default feature flag
    ENABLE_VERBOSE_SQL_LOGGING = False 

class DevelopmentConfig(Config):
    # 2. Development-specific overrides
    DEBUG = True
    LOG_LEVEL = 'DEBUG'
    ENABLE_VERBOSE_SQL_LOGGING = True # Enabled by default in dev

class ProductionConfig(Config):
    # 3. Production-specific overrides and strict secret enforcement
    DEBUG = False
    LOG_LEVEL = 'WARNING'
    
    def __init__(self):
        # Strict validation upon instantiation
        if not self.DATABASE_URL:
            # Raise an error if critical credentials are missing in production
            sys.stderr.write("FATAL: DATABASE_URL must be set in the environment for Production deployments.\n")
            raise ValueError("DATABASE_URL missing.")
        
        # Ex 4 requirement: Check for SQL Logging Override
        if os.environ.get('SQL_LOGGING_OVERRIDE', '').lower() == 'true':
            self.ENABLE_VERBOSE_SQL_LOGGING = True

# 4. Configuration Mapping
config_map = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig # Fallback
}

# Verification Test (Running the production config without env var set)
# try:
#     ProductionConfig()
# except ValueError as e:
#     print(f"Test Successful: Caught expected error: {e}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Combined solution demonstrating config and factory logic

import os
from flask import Flask, jsonify
from dotenv import load_dotenv
import sys

# --- CONFIGURATION (Updated from Ex 1) ---
class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'default-insecure-key-for-dev')
    LOG_LEVEL = 'INFO'
    DATABASE_URL = os.environ.get('DATABASE_URL')
    ENABLE_VERBOSE_SQL_LOGGING = False # 1. Configuration Flag (Default False)

class DevelopmentConfig(Config):
    DEBUG = True
    LOG_LEVEL = 'DEBUG'
    ENABLE_VERBOSE_SQL_LOGGING = True # 2. Development Override

class ProductionConfig(Config):
    DEBUG = False
    LOG_LEVEL = 'WARNING'

    def __init__(self):
        if not self.DATABASE_URL:
            sys.stderr.write("FATAL: DATABASE_URL missing.\n")
            raise ValueError("DATABASE_URL missing.")
        
        # 3. Environment Variable Override Check
        if os.environ.get('SQL_LOGGING_OVERRIDE', '').lower() == 'true':
            self.ENABLE_VERBOSE_SQL_LOGGING = True

config_map = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
}

# --- FACTORY LOGIC ---

def setup_sql_logging(app):
    # Simulated logging initialization
    print(f"\n--- VERBOSE SQL LOGGING INITIALIZED for {app.config['FLASK_ENV']} ---")

load_dotenv() 

def create_app(config_name=None):
    if config_name is None:
        config_name = os.environ.get('FLASK_ENV', 'development')
    
    config_class = config_map.get(config_name, DevelopmentConfig)
    
    try:
        config_object = config_class()
    except ValueError:
        return None # Return None if critical error occurs

    app = Flask(__name__)
    app.config.from_object(config_object)
    app.config['FLASK_ENV'] = config_name

    # 4. Application Logic Integration (Conditional Toggling)
    is_logging_enabled = app.config.get('ENABLE_VERBOSE_SQL_LOGGING')
    is_debug = app.config.get('DEBUG')

    if is_logging_enabled and (is_debug or config_name == 'production'):
        setup_sql_logging(app)
    else:
        print(f"\n--- SQL LOGGING DISABLED for {config_name} ---")

    @app.route('/config')
    def get_config():
        return jsonify(SQL_LOGGING=app.config['ENABLE_VERBOSE_SQL_LOGGING'])

    return app

# --- Demonstration ---
print("\n--- SCENARIO A: Production Default ---")
os.environ['FLASK_ENV'] = 'production'
os.environ['DATABASE_URL'] = 'postgres://prod'
if 'SQL_LOGGING_OVERRIDE' in os.environ: del os.environ['SQL_LOGGING_OVERRIDE']
create_app() # Output: SQL LOGGING DISABLED

print("\n--- SCENARIO B: Development Default ---")
os.environ['FLASK_ENV'] = 'development'
create_app() # Output: VERBOSE SQL LOGGING INITIALIZED

print("\n--- SCENARIO C: Production Override ---")
os.environ['FLASK_ENV'] = 'production'
os.environ['SQL_LOGGING_OVERRIDE'] = 'True'
create_app() # Output: VERBOSE SQL LOGGING INITIALIZED (due to override)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# app/__init__.py (Requires config.py from Exercise 1)

import os
from flask import Flask, jsonify
# Assuming config.py is in the same scope for demonstration
from config import config_map, DevelopmentConfig 

def create_app(config_name=None):
    
    # 4. Environment Variable Fallback: Determine config_name priority
    if config_name is None:
        config_name = os.environ.get('FLASK_ENV', 'development')
    
    # 2. Dynamic Selection: Retrieve the correct configuration class
    config_class = config_map.get(config_name, DevelopmentConfig)
    
    try:
        # Instantiate the configuration class (triggers ProductionConfig validation)
        config_object = config_class() 
    except ValueError as e:
        print(f"FATAL CONFIGURATION ERROR: {e}")
        # In a production environment, this would halt startup
        raise 

    app = Flask(__name__)
    
    # 3. Flask Configuration: Apply the selected configuration object
    app.config.from_object(config_object)
    
    # Store the resolved environment name for internal use
    app.config['FLASK_ENV'] = config_name

    # 5. Verification Route
    @app.route('/config')
    def get_config():
        return jsonify({
            'FLASK_ENV': app.config['FLASK_ENV'],
            'DEBUG': app.config['DEBUG'],
            'LOG_LEVEL': app.config['LOG_LEVEL']
        })

    return app

# Example usage (simulating environment setting)
# os.environ['FLASK_ENV'] = 'development'
# app_dev = create_app()
# print(f"Development Config DEBUG: {app_dev.config['DEBUG']}") # True


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import rasterio
# Assume IMAGE_PATH = 'path/to/your/satellite_image.tif'

def inspect_raster_metadata(image_path: str):
    """
    Opens a geospatial raster and extracts its core spatial metadata.
    """
    try:
        # 2. Opening: Use context manager for safe resource handling
        with rasterio.open(image_path) as dataset:
            
            # 3. Extraction
            crs_info = dataset.crs.to_string()
            band_count = dataset.count
            width = dataset.width
            height = dataset.height
            transform_matrix = dataset.transform
            data_type = dataset.dtype

            print("--- Geospatial Metadata Deep Dive ---")
            print(f"1. Coordinate Reference System (CRS): {crs_info}")
            print(f"2. Total Number of Bands (count): {band_count}")
            print(f"3. Dimensions (Width x Height): {width} x {height}")
            print(f"4. Affine Transform Matrix:\n{transform_matrix}")
            print(f"5. Pixel Data Type (dtype): {data_type}")
            print("-" * 35)

            # 4. Verification and POLA check
            if band_count < 3:
                print(f"WARNING: Band count ({band_count}) is insufficient for standard RGB/multispectral tasks.")
            else:
                print("Verification successful: Raster has 3 or more bands.")

    except rasterio.RasterioIOError as e:
        print(f"Error opening raster file at {image_path}: {e}")

# inspect_raster_metadata(IMAGE_PATH)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import rasterio
import numpy as np
import copy
# Assume IMAGE_PATH is defined

def create_output_template(image_path: str):
    """
    Creates a modified Rasterio metadata profile suitable for writing a
    single-band classification map based on the input image's spatial context.
    """
    try:
        with rasterio.open(image_path) as src:
            # 1. Metadata Inheritance
            # Use copy.deepcopy to ensure modifications don't affect the source profile
            input_profile = src.profile
            output_classification_profile = copy.deepcopy(input_profile)

            # 2. Metadata Modification
            output_classification_profile.update({
                'count': 1,                         # Change 1: Single band output
                'dtype': rasterio.uint8,            # Change 2: Classification map data type
                'nodata': 255,                      # Change 3: Set nodata value
                'interleave': 'band',               # Change 4: Standard interleave for single band
                'compress': 'deflate'               # Optional: Add compression
            })

            # 3. Verification
            print("--- GeoTIFF Template Creation ---")
            print("\nOriginal Input Profile Snippet:")
            print(f"  Count: {input_profile['count']}, Dtype: {input_profile['dtype']}, Nodata: {input_profile.get('nodata')}")

            print("\nModified Output Classification Profile Snippet:")
            print(f"  Count: {output_classification_profile['count']}")
            print(f"  Dtype: {output_classification_profile['dtype']}")
            print(f"  Nodata: {output_classification_profile.get('nodata')}")
            print(f"  Interleave: {output_classification_profile['interleave']}")
            
            return output_classification_profile

    except rasterio.RasterioIOError as e:
        print(f"Error opening raster file: {e}")
        return None

# create_output_template(IMAGE_PATH)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import rasterio
import sys
import numpy as np
# Assume IMAGE_PATH is defined

def interactive_band_reader(image_path: str):
    """
    Prompts the user for a band number and reads the corresponding band,
    handling input validation and range errors.
    """
    try:
        with rasterio.open(image_path) as src:
            band_count = src.count
            
            # POLA: Inform user of the valid range immediately
            print(f"The dataset has {band_count} bands (1-indexed).")
            
            band_index = None
            
            while band_index is None:
                user_input = input(f"Enter the band number (1 to {band_count}): ")
                
                try:
                    # Attempt 1: Non-Integer Input Check (ValueError)
                    band_index = int(user_input)
                    
                    # Attempt 2: Out-of-Range Band Check (POLA)
                    if not (1 <= band_index <= band_count):
                        print(f"\nERROR: Band number {band_index} is out of range. "
                              f"Please enter an integer between 1 and {band_count}.")
                        band_index = None # Reset to continue loop
                        continue
                        
                    # Reading Operation
                    # Reading a single band results in a (Height, Width) array
                    selected_band_data = src.read(band_index)
                    
                    # Verification
                    print("\n--- Band Reading Successful ---")
                    print(f"Band {band_index} loaded.")
                    print(f"Array Shape (H, W): {selected_band_data.shape}")
                    print(f"Minimum Pixel Value: {selected_band_data.min()}")
                    print(f"Maximum Pixel Value: {selected_band_data.max()}")
                    
                    return # Exit function after successful read

                except ValueError:
                    # Catches if int(user_input) fails (e.g., user enters text)
                    print("\nERROR: Invalid input format. Please enter a whole number (integer).")
                    band_index = None # Ensure loop continues
                    
    except rasterio.RasterioIOError as e:
        print(f"Fatal Error: Could not open raster file: {e}")

# interactive_band_reader(IMAGE_PATH)

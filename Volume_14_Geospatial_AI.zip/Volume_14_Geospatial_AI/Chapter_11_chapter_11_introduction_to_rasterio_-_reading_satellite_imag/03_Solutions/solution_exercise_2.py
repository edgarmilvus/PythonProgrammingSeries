
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import rasterio
from rasterio.windows import Window
import numpy as np
# Assume IMAGE_PATH is defined

def read_centered_tile(image_path: str, tile_size: int = 512):
    """
    Reads a centered tile of specified size from the first three bands.
    """
    try:
        with rasterio.open(image_path) as src:
            src_width = src.width
            src_height = src.height

            # POLA Check: Ensure image is large enough
            if src_width < tile_size or src_height < tile_size:
                raise ValueError(f"Image dimensions ({src_width}x{src_height}) "
                                 f"are too small for the requested tile size ({tile_size}).")

            # 1. Window Calculation: Find the top-left corner for centering
            start_col = (src_width // 2) - (tile_size // 2)
            start_row = (src_height // 2) - (tile_size // 2)

            # 2. Window Definition (col_off, row_off, width, height)
            tile_window = Window(start_col, start_row, tile_size, tile_size)

            # 3. Reading Operation: Read the first three bands (1-indexed)
            # 5. Data Type Consistency: Read and explicitly cast to float32
            tile_data = src.read(
                indexes=(1, 2, 3),
                window=tile_window,
                out_dtype=np.float32 
            )

            # 4. Output Verification
            print(f"Tile successfully read using windowing.")
            print(f"Window defined: {tile_window}")
            print(f"Resulting NumPy array shape (Bands, H, W): {tile_data.shape}")
            print(f"Resulting NumPy array dtype: {tile_data.dtype}")
            
            return tile_data

    except (rasterio.RasterioIOError, ValueError) as e:
        # Graceful error handling for boundary/file issues (POLA)
        print(f"Error during tile reading: {e}")
        return None

# read_centered_tile(IMAGE_PATH)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import rasterio
from rasterio.warp import calculate_default_transform
import numpy as np
# Assume IMAGE_PATH is defined

def downsample_and_retransform(image_path: str, factor: int = 4):
    """
    Reads the raster, downsamples it by a factor, and calculates the corresponding
    new affine transformation matrix.
    """
    try:
        with rasterio.open(image_path) as src:
            # 1. Initialization
            original_width = src.width
            original_height = src.height
            original_transform = src.transform
            original_crs = src.crs

            # 2. New Dimensions (ensuring integer results)
            downsampled_width = original_width // factor
            downsampled_height = original_height // factor
            
            new_out_shape = (downsampled_height, downsampled_width)

            # 3. Reading with Resampling
            # Reading with out_shape forces Rasterio to resample the data
            downsampled_data = src.read(
                out_shape=new_out_shape, 
                resampling=rasterio.enums.Resampling.nearest # Simple resampling method
            )

            # 4. New Transform Calculation (CRITICAL)
            # calculate_default_transform determines the new transform that maps the 
            # original bounds to the new, smaller pixel grid.
            new_transform, _, _ = calculate_default_transform(
                original_crs, original_crs, 
                original_width, original_height, 
                src.bounds, 
                downsampled_width, downsampled_height
            )

            # 5. Verification
            print("--- Downsampling Verification ---")
            print(f"Original dimensions: {original_width}x{original_height}")
            print(f"Resampled data shape (Bands, H, W): {downsampled_data.shape}")
            
            # Check the pixel size components (a=x resolution, e=y resolution)
            print(f"\nOriginal Transform (a, e): {original_transform.a:.4f}, {original_transform.e:.4f}")
            print(f"New Downsampled Transform (a, e): {new_transform.a:.4f}, {new_transform.e:.4f}")

            # Verify that the pixel size has increased by the factor
            if abs(new_transform.a / original_transform.a) == factor:
                print(f"Verification successful: Pixel size increased by factor of {factor}.")
            
            return downsampled_data, new_transform

    except rasterio.RasterioIOError as e:
        print(f"Error opening raster file: {e}")
        return None, None

# downsample_and_retransform(IMAGE_PATH)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import rasterio
import numpy as np
import os
from rasterio.transform import from_bounds
from rasterio.crs import CRS

# --- 1. SETUP: Defining parameters and creating a temporary GeoTIFF ---

# Define the file path for the temporary dataset
OUTPUT_FILENAME = "basic_rasterio_scene.tif"
WIDTH, HEIGHT = 100, 80  # Define dimensions (100 columns, 80 rows)
NUM_BANDS = 1

# Define the Coordinate Reference System (CRS) explicitly as WGS 84 (Lat/Lon)
# This is fundamental metadata linking pixel indices to Earth coordinates.
TARGET_CRS = CRS.from_epsg(4326)

# Define the Affine Transform using bounds. This matrix maps (row, col) to (x, y).
# We simulate a 100x80 scene covering 1 degree square (100 units wide, 80 units high)
# The resulting transform will define the resolution (e.g., 0.01 degree/pixel).
AFFINE_TRANSFORM = from_bounds(
    west=0.0, south=0.0, east=1.0, north=0.8,
    width=WIDTH, height=HEIGHT
)

# Define the profile (the metadata schema for the GeoTIFF header)
profile = {
    'driver': 'GTiff',      # Specify the file format driver
    'dtype': rasterio.uint16, # Specify the data type for pixel values
    'count': NUM_BANDS,      # Number of bands (e.g., 1 for grayscale)
    'height': HEIGHT,        # Number of rows
    'width': WIDTH,          # Number of columns
    'crs': TARGET_CRS,       # The Coordinate Reference System
    'transform': AFFINE_TRANSFORM, # The geometric transformation matrix
    'nodata': 0,             # Value representing missing data
}

print(f"--- 1. Creating dummy file: {OUTPUT_FILENAME} ---")

try:
    # Use the context manager ('with') to open the file in write mode ('w')
    with rasterio.open(OUTPUT_FILENAME, 'w', **profile) as dst:
        # Create a simple NumPy array representing fake pixel data
        # We fill it with a constant value (500) within the allowed uint16 range
        dummy_data = np.full((HEIGHT, WIDTH), 500, dtype=rasterio.uint16)
        
        # Write the data to the dataset. The index '1' specifies the first band.
        dst.write(dummy_data, 1) 
        
    print("Dummy GeoTIFF created successfully.")

    # --- 2. READING: Accessing metadata and pixel data ---

    print("\n--- 2. Reading metadata and data using Rasterio ---")
    
    # Open the file in read mode ('r' is the default if not specified)
    # The 'src' variable is the DatasetReader object, the primary interface.
    with rasterio.open(OUTPUT_FILENAME) as src:
        
        # A. Accessing Core Metadata Attributes
        print(f"File Name: {src.name}")
        print("-" * 30)
        print(f"1. Coordinate System (CRS):\n{src.crs.to_string()}")
        print("-" * 30)
        print(f"2. Affine Transform (Geo-T):")
        # Print the transform matrix, which links (row, col) to (x, y)
        print(src.transform)
        print("-" * 30)
        print(f"3. Dimensions & Structure:")
        print(f"   Width (Columns): {src.width}")
        print(f"   Height (Rows): {src.height}")
        print(f"   Number of Bands: {src.count}")
        print(f"   Pixel Data Type: {src.dtypes[0]}")
        
        # B. Reading Pixel Data
        # Read the entire first band (index 1) into a NumPy array
        # Note: Rasterio uses 1-based indexing for bands.
        print("\n4. Reading Band Data (Index 1)...")
        band_data = src.read(1)
        
        # C. Verification and Inspection
        print(f"   Data shape read (H, W): {band_data.shape}")
        print(f"   Data type read: {band_data.dtype}")
        print(f"   Minimum pixel value: {np.min(band_data)}")
        print(f"   Maximum pixel value: {np.max(band_data)}")
        
finally:
    # --- 3. CLEANUP ---
    if os.path.exists(OUTPUT_FILENAME):
        os.remove(OUTPUT_FILENAME)
        print(f"\n--- 3. Cleanup: Removed {OUTPUT_FILENAME} ---")


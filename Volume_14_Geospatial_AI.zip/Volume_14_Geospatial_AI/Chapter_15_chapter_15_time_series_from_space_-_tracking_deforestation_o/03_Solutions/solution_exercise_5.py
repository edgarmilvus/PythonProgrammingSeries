
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np
import xarray as xr
import pandas as pd
import matplotlib.pyplot as plt

# Define area constants (for Sentinel-2 10m resolution)
PIXEL_RESOLUTION_SQ_M = 100 
SQ_M_TO_HECTARES = 10000

# 1. Data Simulation: 3 years, 500x500 pixels
Y, X = 500, 500
years = [2020, 2021, 2022]

# Simulate annual deforestation with increasing rates
annual_data = np.stack([
    np.random.choice([False, True], size=(Y, X), p=[0.99, 0.01]), # 2020: 1% loss
    np.random.choice([False, True], size=(Y, X), p=[0.98, 0.02]), # 2021: 2% loss
    np.random.choice([False, True], size=(Y, X), p=[0.97, 0.03])  # 2022: 3% loss
])

annual_deforestation_stack = xr.DataArray(
    data=annual_data,
    coords={'time': years, 'y': np.arange(Y), 'x': np.arange(X)},
    dims=('time', 'y', 'x'),
    name='Annual_Deforestation',
    dtype=bool
)

def calculate_area_hectares(boolean_map, pixel_resolution_sq_m=PIXEL_RESOLUTION_SQ_M):
    """
    Converts the count of True pixels in a boolean map to area in hectares.
    """
    # 1. Count the number of True values (deforested pixels)
    deforested_pixel_count = boolean_map.sum().item()
    
    # 2. Calculate total area in square meters
    total_sq_m = deforested_pixel_count * pixel_resolution_sq_m
    
    # 3. Convert total square meters to hectares
    area_hectares = total_sq_m / SQ_M_TO_HECTARES
    
    return area_hectares

def aggregate_annual_loss(deforestation_stack, pixel_area):
    """
    Calculates the annual deforestation loss and the cumulative loss.
    """
    annual_loss_list = []
    
    # 1. Iterate through the time dimension (xarray iteration handles this)
    for year_map in deforestation_stack:
        area = calculate_area_hectares(year_map, pixel_area)
        annual_loss_list.append(area)
        
    # 2. Calculate the cumulative sum of the annual losses.
    cumulative_loss_data = np.cumsum(annual_loss_list)
    
    return annual_loss_list, cumulative_loss_data

def plot_cumulative_loss(years, cumulative_loss_data):
    """
    Generates a clear line plot of the cumulative deforestation.
    """
    plt.figure(figsize=(10, 6))
    plt.plot(years, cumulative_loss_data, marker='o', linestyle='-', color='red', linewidth=2)
    
    plt.title('Cumulative Deforestation Rate (2020-2022)', fontsize=14)
    plt.xlabel('Year', fontsize=12)
    plt.ylabel('Cumulative Area Lost (Hectares)', fontsize=12)
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.xticks(years)
    plt.show()

# Main execution flow
annual_loss, cumulative_loss = aggregate_annual_loss(annual_deforestation_stack, PIXEL_RESOLUTION_SQ_M)

print("--- Annual Deforestation Quantification ---")
for year, loss in zip(years, annual_loss):
    print(f"Deforestation detected in {year}: {loss:.2f} Hectares")

# Visualization
plot_cumulative_loss(years, cumulative_loss)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np
import xarray as xr
import pandas as pd

# Simulation setup (T=5, Y=100, X=100)
T, Y, X = 5, 100, 100
dates = pd.to_datetime(pd.date_range('2020-01-01', periods=T, freq='6M'))

# Simulated NDVI and QA data
ndvi_stack = xr.DataArray(
    data=np.random.uniform(0.1, 0.8, size=(T, Y, X)),
    coords={'time': dates, 'y': np.arange(Y), 'x': np.arange(X)},
    dims=('time', 'y', 'x'),
    name='NDVI'
)
qa_band_data = np.random.randint(0, 2, size=(T, Y, X))
qa_band_data[1, 50, 50] = 1 # Force contamination at one pixel for testing

qa_band = xr.DataArray(
    data=qa_band_data,
    coords={'time': dates, 'y': np.arange(Y), 'x': np.arange(X)},
    dims=('time', 'y', 'x'),
    name='QA_Mask'
)
CLOUD_CONTAMINATION_FLAG = 1

def apply_cloud_mask(ndvi_stack, qa_band):
    """
    Generates a boolean mask from the QA band and applies it to the NDVI stack.
    """
    # 1. Define the criteria for contamination (True where contaminated).
    contamination_mask = qa_band == CLOUD_CONTAMINATION_FLAG
    
    # 2. Apply the mask: use .where(~mask) to keep values ONLY where the mask is False (clean).
    # Contaminated pixels are set to np.nan by default.
    masked_ndvi_stack = ndvi_stack.where(~contamination_mask) 
    
    return masked_ndvi_stack

def interpolate_gaps(masked_ndvi_stack):
    """
    Performs linear interpolation along the time axis.
    """
    # Use xarray's .interpolate_na() method, specifying the dimension 'time'.
    interpolated_ndvi_stack = masked_ndvi_stack.interpolate_na(dim='time', method='linear')
    return interpolated_ndvi_stack

# Main execution flow
masked_ndvi = apply_cloud_mask(ndvi_stack, qa_band)
interpolated_ndvi = interpolate_gaps(masked_ndvi)

# 4. Visualization Preparation for a single pixel (50, 50)
pixel_x, pixel_y = 50, 50
raw_ts = ndvi_stack.sel(x=pixel_x, y=pixel_y).values
masked_ts = masked_ndvi.sel(x=pixel_x, y=pixel_y).values
interpolated_ts = interpolated_ndvi.sel(x=pixel_x, y=pixel_y).values

print(f"--- Cloud Masking and Interpolation Summary (Pixel {pixel_x}, {pixel_y}) ---")
print("Raw Time Series:", np.round(raw_ts, 4))
print("Masked Time Series:", np.round(masked_ts, 4))
print("Interpolated Time Series:", np.round(interpolated_ts, 4))

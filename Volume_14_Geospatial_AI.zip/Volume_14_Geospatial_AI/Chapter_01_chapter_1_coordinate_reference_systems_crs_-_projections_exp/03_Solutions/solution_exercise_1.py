
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pyproj
from pyproj.exceptions import CRSError

# 3. Define custom exception class
class InvalidCRSDefinitionError(Exception):
    """Custom exception raised for invalid or unparsable CRS definitions."""
    pass

def standardize_crs(input_crs):
    """
    Parses a CRS definition using pyproj, standardizes it to an integer EPSG code,
    and validates if it's a GCS or PCS.
    """
    print(f"\n--- Processing Input: {input_crs} ({type(input_crs).__name__}) ---")
    
    try:
        # 1. CRS Definition Handling: Robustly parse the input
        crs = pyproj.CRS.from_user_input(input_crs)
        
    except (CRSError, TypeError) as e:
        # 3. Error Handling: Catch parsing errors (e.g., malformed string)
        raise InvalidCRSDefinitionError(f"Failed to parse CRS input '{input_crs}'. Underlying error: {e}")

    # 2. Validation Check: Must be GCS or PCS
    if not (crs.is_geographic or crs.is_projected):
        raise InvalidCRSDefinitionError(
            f"CRS '{crs.name}' is not a standard Geographic or Projected Coordinate System."
        )

    # Attempt to retrieve the EPSG code
    epsg_code = crs.to_epsg()

    if epsg_code is not None:
        print(f"Standardized EPSG Code: {epsg_code}")
        return int(epsg_code)
    else:
        print(f"CRS parsed successfully but has no standard EPSG code. Name: {crs.name}")
        return None

# 4. Testing Data
wkt_wgs84 = 'GEOGCRS["WGS 84",DATUM["World Geodetic System 1984",ELLIPSOID["WGS 84",6378137,298.257223563]]]'
test_inputs = [
    4326,
    'EPSG:3857',
    wkt_wgs84,
    'WGS 84 ZONEX'  # Intentionally malformed
]

for input_crs in test_inputs:
    try:
        standardize_crs(input_crs)
    except InvalidCRSDefinitionError as e:
        print(f"Error Caught: {e}")

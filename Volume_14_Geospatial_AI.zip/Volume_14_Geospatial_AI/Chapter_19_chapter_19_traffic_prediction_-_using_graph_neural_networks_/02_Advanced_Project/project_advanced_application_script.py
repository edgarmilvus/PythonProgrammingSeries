
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import torch
import torch.nn as nn
import numpy as np

# --- 1. Data Simulation and Graph Definition (GIS to Tensor) ---

# Define dimensions: N=Nodes (road segments), T=Time steps (historical lookback), 
# F=Features (speed, volume)
N, T, F = 5, 12, 2
# Simulate historical traffic features X: (N x T x F)
# This tensor represents 12 hours (T=12) of data for 5 segments (N=5), 
# measured by Speed and Volume (F=2).
X_features = torch.randn(N, T, F) * 10 + 50 # Speeds centered around 50 km/h

# Adjacency Matrix (A): Defines connectivity between the 5 segments
# A[i, j] = 1 if segment i is connected to j (e.g., intersections are adjacent)
A = np.array([
    [0, 1, 1, 0, 0],
    [1, 0, 0, 1, 0],
    [1, 0, 0, 0, 1],
    [0, 1, 0, 0, 0],
    [0, 0, 1, 0, 0]
], dtype=np.float32)

# --- 2. Graph Preprocessing: Normalized Adjacency (A_tilde) ---

# Add self-loops (A_hat = A + I)
I = np.eye(N, dtype=np.float32)
A_hat = A + I

# Calculate Degree Matrix D_hat (diagonal matrix of row sums of A_hat)
# We need D_hat^(-0.5) for normalization in the GCN formula
D_hat_inv_sqrt = np.diag(np.sum(A_hat, axis=1)**(-0.5))

# Calculate Normalized Adjacency Matrix (A_tilde = D^(-0.5) * A_hat * D^(-0.5))
A_tilde = torch.from_numpy(D_hat_inv_sqrt @ A_hat @ D_hat_inv_sqrt)

# --- 3. Simplified STGCN Layer Definition (Spatio-Temporal Block) ---

class SimplifiedSTGCNLayer(nn.Module):
    """
    Implements a single block combining Temporal Convolution (TCN) 
    and Spatial Graph Convolution (GCN).
    """
    def __init__(self, in_features, out_features, num_nodes, time_steps):
        super().__init__()
        
        # Temporal Convolution Component (TCN): Uses 1D Conv across time axis
        # Kernel size (1, 3) means it sweeps across T (time) but not N (nodes)
        self.tcn_1 = nn.Conv2d(in_features, out_features, kernel_size=(1, 3), padding=(0, 1))
        
        # Spatial GCN Component: Linear layer acts as the trainable Theta matrix
        self.theta = nn.Linear(out_features, out_features, bias=False)
        
        # Layer normalization for stabilizing hidden states
        self.norm = nn.LayerNorm([out_features, time_steps, num_nodes])

    def forward(self, X, A_tilde):
        # X shape: (N, T, F_in). We assume Batch size B=1 for simplicity.
        
        # 1. Reshape for Temporal Convolution (TCN)
        # PyTorch Conv2d expects (B, C_in, H, W). We map (N, T, F_in) -> (1, F_in, T, N)
        X_in = X.permute(2, 1, 0).unsqueeze(0) 
        
        # 2. Temporal Convolution (TCN)
        H_temp = torch.relu(self.tcn_1(X_in)) # H_temp shape: (1, F_out, T, N)
        
        # 3. Reshape back for Spatial Convolution (GCN)
        # H_spatial_input shape: (N, T, F_out)
        H_spatial_input = H_temp.squeeze(0).permute(3, 2, 1) 
        
        # 4. Spatial Graph Convolution (A_tilde * H * Theta)
        # Step 4a: Spatial Aggregation (A_tilde * H)
        # torch.einsum is used for efficient batch matrix multiplication:
        # 'ij' (A_tilde: N x N) @ 'jtf' (H: N x T x F_out) -> 'itf' (N x T x F_out)
        H_aggregated = torch.einsum('ij, jtf -> itf', A_tilde, H_spatial_input)
        
        # Step 4b: Feature Transformation (H_aggregated * Theta)
        H_output = self.theta(H_aggregated)
        
        # 5. Output and Normalization
        return self.norm(H_output)

# --- 4. Model Instantiation and Forward Pass ---

# Hyperparameters
IN_FEATURES = F 
HIDDEN_FEATURES = 32
OUT_FEATURES = 1 # Prediction target: future speed

# Instantiate the GNN Layer
stgcn_block = SimplifiedSTGCNLayer(
    in_features=IN_FEATURES, 
    out_features=HIDDEN_FEATURES, 
    num_nodes=N, 
    time_steps=T
)

# Final prediction layer (maps hidden features to the single output)
final_predictor = nn.Linear(HIDDEN_FEATURES, OUT_FEATURES)

# --- Prediction Simulation ---

# 1. Pass input features through the STGCN Block
H_hidden = stgcn_block(X_features, A_tilde) # (N, T, HIDDEN_FEATURES)

# 2. Apply activation
H_hidden = torch.relu(H_hidden)

# 3. Select features from the final time step (T-1) for prediction
# We use the most recent processed information to forecast the next step
final_time_features = H_hidden[:, -1, :] # (N, HIDDEN_FEATURES)

# 4. Linear mapping to the final predicted traffic state
predicted_traffic = final_predictor(final_time_features) # (N, 1)

# Display Results
print(f"--- Traffic Prediction Simulation using Simplified STGCN ---")
print(f"Input Feature Tensor Shape (N, T, F): {X_features.shape}")
print(f"Normalized Adjacency Matrix Shape (N, N): {A_tilde.shape}")
print(f"Hidden State Output Shape (N, T, Hidden): {H_hidden.shape}")
print("\nPredicted Future Traffic State (Speed) for 5 Road Segments:")
# Display final prediction
for i, speed in enumerate(predicted_traffic.squeeze().tolist()):
    print(f"  Segment {i+1}: {speed:.2f} km/h")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np
import pandas as pd
import time

# --- Context: Modeling a small road network for traffic prediction ---

# --- 1. Define the Road Network Structure (Nodes and Edges) ---

# We define 5 major intersections (Nodes). These are the entities we want to predict traffic for.
# Node indices: 0, 1, 2, 3, 4
NODES = ['Intersection_A', 'Intersection_B', 'Intersection_C', 'Intersection_D', 'Intersection_E']
NUM_NODES = len(NODES)

# Define the physical connections (Edges) between intersections using index pairs.
# This list represents the raw GIS data defining the road segments.
# Format: (Source Node Index, Target Node Index)
ROAD_CONNECTIONS = [
    (0, 1), # Road segment A <-> B
    (1, 2), # Road segment B <-> C
    (2, 3), # Road segment C <-> D
    (3, 4), # Road segment D <-> E
    (4, 0), # Road segment E <-> A (Completing the outer loop)
    (1, 3)  # Road segment B <-> D (A critical shortcut or bypass)
]

# --- 2. Construct the Adjacency Matrix (A) ---

# A is an N x N matrix defining the topology (spatial relationship).
A = np.zeros((NUM_NODES, NUM_NODES), dtype=np.int32)

# Populate the matrix based on the defined connections
for i, j in ROAD_CONNECTIONS:
    # Traffic networks are usually considered Undirected (two-way roads)
    # unless specific one-way streets are modeled.
    A[i, j] = 1 # Connection from i to j
    A[j, i] = 1 # Connection from j to i (Crucial for undirected graphs)

# Ensure the diagonal elements are zero (no self-loops in the base adjacency matrix)
np.fill_diagonal(A, 0)

# --- 3. Construct the Node Feature Tensor (X) ---

# X holds the temporal data. For STGNNs, the shape is (Nodes, Timesteps, Features).
# N=5 nodes, T=3 timesteps (e.g., 3 past 5-minute intervals), F=2 features (Speed, Volume).

# Simulate historical traffic data for 3 time steps (T=3)
# T0 (5 min ago): Speed (kph), Volume (vehicles/min)
# T1 (10 min ago): Speed (kph), Volume (vehicles/min)
# T2 (15 min ago): Speed (kph), Volume (vehicles/min)

# Data structure: [Node Index][Timestep Index][Feature Index]
# This simulation uses a flat array and will be reshaped.

# Data for Node A (55/10, 50/12, 45/15)
# Data for Node B (30/25, 35/20, 40/18)
# ... and so on for all 5 nodes and 3 timesteps
raw_data = np.array([
    [55.0, 10, 50.0, 12, 45.0, 15], # A
    [30.0, 25, 35.0, 20, 40.0, 18], # B
    [65.0, 5,  60.0, 7,  55.0, 9],  # C
    [40.0, 15, 45.0, 13, 50.0, 11], # D
    [50.0, 12, 55.0, 10, 60.0, 8]   # E
])

# Define the dimensions for the STGNN input tensor
TIMESTEPS = 3
FEATURES = 2 # Speed and Volume

# Reshape the raw data into the required (N, T, F) format
# (5, 6) -> (5, 3, 2)
X = raw_data.reshape(NUM_NODES, TIMESTEPS, FEATURES)

# --- 4. Display Results and Verification ---

print(f"--- GNN Input Initialization ({time.strftime('%H:%M:%S')}) ---")
print(f"Total Nodes (Intersections): {NUM_NODES}")

print("\n[1] Adjacency Matrix (A) - Spatial Topology (N x N):")
print(f"Shape of A: {A.shape}")

# Using Pandas helps satisfy the Principle of Least Astonishment (POLA) by labeling axes clearly.
A_df = pd.DataFrame(A, index=NODES, columns=NODES)
print(A_df)

print("\n[2] Node Feature Tensor (X) - Spatio-Temporal Data (N x T x F):")
print(f"Shape of X: {X.shape} (Nodes={NUM_NODES}, Timesteps={TIMESTEPS}, Features={FEATURES})")

# Display a snapshot of the most recent data (Timestep 0)
print("\nSnapshot: Most Recent Timestep (T=0) Features:")
T0_features = X[:, 0, :] # Slice: All nodes, Timestep 0, All features

feature_df = pd.DataFrame(
    T0_features,
    index=NODES,
    columns=['Speed_kph', 'Volume_veh/min']
)
print(feature_df)

# Verification Check: How many neighbors does Node B (Index 1) have?
node_b_index = 1
degree_b = np.sum(A[node_b_index, :])
connected_nodes_indices = np.where(A[node_b_index, :] == 1)[0]
connected_nodes_names = [NODES[i] for i in connected_nodes_indices]

print(f"\nVerification Check: Intersection B (Index {node_b_index})")
print(f"Degree (Number of neighbors): {int(degree_b)}")
print(f"Connected to: {connected_nodes_names}")

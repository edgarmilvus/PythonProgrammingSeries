
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example_part2.py
# Description: Basic Code Example
# ==========================================

# --- Example of necessary normalization (for context of the pitfall) ---

# 1. Add self-loops (A_hat = A + I)
I = np.eye(NUM_NODES, dtype=np.int32)
A_hat = A + I

# 2. Calculate the Degree Matrix (D_hat)
D_hat = np.diag(np.sum(A_hat, axis=1))

# 3. Calculate the inverse square root of the Degree Matrix
# D_hat_inv_sqrt = D_hat^(-1/2)
D_hat_inv_sqrt = np.linalg.inv(np.sqrt(D_hat))

# 4. Calculate the Normalized Adjacency Matrix (A_norm)
A_norm = D_hat_inv_sqrt @ A_hat @ D_hat_inv_sqrt

# A_norm is the matrix actually passed to the GNN layer.


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
import pandas as pd
from scipy.sparse import coo_matrix, identity
from scipy.sparse.linalg import eigsh

# --- Simulation Parameters ---
N_NODES = 50  # Number of road links (nodes)
TIME_STEPS = 7 * 24 * 12  # One week, 5-minute intervals (2016 steps)
T_HIST = 12  # Input window (1 hour)
T_PRED = 3   # Prediction horizon (15 minutes)

# 1. Simulate GIS Data and Connectivity

def simulate_data():
    """Simulates road network connectivity and time-series traffic data."""
    # Simulate Adjacency Matrix (A): Random sparse connectivity
    A = np.random.rand(N_NODES, N_NODES)
    A[A < 0.9] = 0  # Sparsity
    np.fill_diagonal(A, 0)
    A = (A + A.T) / 2  # Symmetrize
    A[A > 0] = 1 # Unweighted connectivity

    # Simulate Time Series Data: (T, N) for speed and volume
    np.random.seed(42)
    speed = np.random.uniform(20, 70, (TIME_STEPS, N_NODES))
    volume = np.random.uniform(100, 500, (TIME_STEPS, N_NODES))
    
    # Introduce some temporal correlation (e.g., rush hour dip)
    hourly_index = np.tile(np.arange(TIME_STEPS) % 288, (N_NODES, 1)).T
    rush_hour_factor = np.sin(hourly_index / 288 * 2 * np.pi) * 10
    speed = np.clip(speed - rush_hour_factor, 10, 70)

    # Create DataFrame structure (N * T rows for typical sensor data)
    time_index = pd.to_datetime(pd.date_range('2023-01-01', periods=TIME_STEPS, freq='5min'))
    
    data = []
    for i in range(N_NODES):
        df_node = pd.DataFrame({
            'timestamp': time_index,
            'link_id': i,
            'speed': speed[:, i],
            'volume': volume[:, i]
        })
        data.append(df_node)
    
    traffic_df = pd.concat(data).reset_index(drop=True)
    return A, traffic_df

A, traffic_df = simulate_data()

# 2. Graph Generation and Normalized Laplacian (L_hat)

def calculate_normalized_laplacian(A):
    """Calculates the Symmetrically Normalized Laplacian L_hat."""
    A = A + np.eye(A.shape[0])  # Add self-loops (A_tilde)
    D = np.diag(np.sum(A, axis=1))
    D_inv_sqrt = np.linalg.matrix_power(D, -0.5)
    
    # L_hat = D_inv_sqrt * A * D_inv_sqrt
    L_hat = D_inv_sqrt @ A @ D_inv_sqrt
    
    # The normalized Laplacian used in GCN/STGCN is often L = I - L_hat
    # However, for Chebyshev approximation, we often use the scaled L_hat directly.
    # We return L_hat (which includes I) as the normalized adjacency matrix.
    return L_hat

L_hat = calculate_normalized_laplacian(A)
print(f"Adjacency Matrix shape: {A.shape}")
print(f"Normalized Laplacian shape: {L_hat.shape}")

# 3. Feature Tensor Creation (X)

def create_feature_tensor(df, N_NODES):
    """Structures data into X (T, N, F) and applies normalization/encoding."""
    
    # Pivot data: (T, N) for speed and volume
    speed_pivot = df.pivot(index='timestamp', columns='link_id', values='speed').values
    volume_pivot = df.pivot(index='timestamp', columns='link_id', values='volume').values
    
    # Stack features: (T, N, 2)
    X_raw = np.stack([speed_pivot, volume_pivot], axis=-1)
    
    # Feature Normalization (Z-Score) across T and N dimensions
    # Calculate mean/std over the entire dataset (T*N samples) for each feature F
    means = X_raw.mean(axis=(0, 1))
    stds = X_raw.std(axis=(0, 1))
    X_normalized = (X_raw - means) / (stds + 1e-5)
    
    # Temporal Feature Encoding
    time_index = df['timestamp'].unique()
    timestamps = pd.to_datetime(time_index)
    
    # Time of Day (Sin/Cos encoding)
    minutes_of_day = timestamps.hour * 60 + timestamps.minute
    max_minutes = 24 * 60
    
    sin_time = np.sin(2 * np.pi * minutes_of_day / max_minutes)
    cos_time = np.cos(2 * np.pi * minutes_of_day / max_minutes)
    
    # Day of Week (One-hot or simple integer encoding)
    day_of_week = timestamps.dayofweek / 6.0 # Scale 0-6 to 0-1
    
    # Combine temporal features: (T, 3)
    temporal_features = np.stack([sin_time, cos_time, day_of_week], axis=1)
    
    # Expand temporal features to match (T, N, F_temp) structure
    T, N, F_data = X_normalized.shape
    F_temp = temporal_features.shape[1]
    
    # Tile temporal features across N nodes: (T, N, F_temp)
    temporal_features_tiled = np.tile(temporal_features[:, None, :], (1, N, 1))
    
    # Final Feature Tensor X: (T, N, F_data + F_temp)
    X = np.concatenate([X_normalized, temporal_features_tiled], axis=-1)
    
    return X, means, stds

X_features, means, stds = create_feature_tensor(traffic_df, N_NODES)
print(f"Final Feature Tensor X shape (T, N, F): {X_features.shape}") # Should be (2016, 50, 5)

# 4. Data Partitioning and Sliding Window

def create_sliding_windows(X, T_hist, T_pred, train_ratio=0.7, val_ratio=0.15):
    """Creates input/output pairs using a sliding window."""
    
    T, N, F = X.shape
    data_points = []
    
    # Sliding window creation
    for i in range(T - T_hist - T_pred + 1):
        x_input = X[i : i + T_hist, :, :]
        # Target is the speed feature (first feature) T_pred steps ahead
        y_target = X[i + T_hist : i + T_hist + T_pred, :, 0] 
        data_points.append((x_input, y_target))
        
    # Split indices (maintaining temporal order)
    total_samples = len(data_points)
    train_end = int(total_samples * train_ratio)
    val_end = train_end + int(total_samples * val_ratio)
    
    train_set = data_points[:train_end]
    val_set = data_points[train_end:val_end]
    test_set = data_points[val_end:]
    
    # Convert lists of tuples to stacked numpy arrays
    X_train = np.stack([x[0] for x in train_set])
    Y_train = np.stack([x[1] for x in train_set])
    
    # ... (repeat for val and test sets) ...
    # Simplified stacking for output demonstration:
    print(f"\nTotal samples generated: {total_samples}")
    print(f"Train samples: {len(train_set)} | Val samples: {len(val_set)} | Test samples: {len(test_set)}")
    print(f"Example X_train shape (Batch, T_hist, N, F): {X_train.shape}")
    print(f"Example Y_train shape (Batch, T_pred, N): {Y_train.shape}")
    
    return train_set, val_set, test_set

train_data, val_data, test_data = create_sliding_windows(X_features, T_HIST, T_PRED)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np
import tensorflow as tf # Using TF/Keras style for conceptual implementation
from tensorflow.keras.layers import Conv1D, Layer, Activation

# Helper function for Chebyshev Polynomials
def chebyshev_polynomials(L_tilde, K):
    """
    Calculates the first K Chebyshev polynomials T_k(L_tilde).
    L_tilde is the scaled and normalized Laplacian.
    """
    N = L_tilde.shape[0]
    T_k = []
    
    # T_0(L_tilde) = I
    T_k.append(tf.eye(N, dtype=L_tilde.dtype))
    
    if K > 1:
        # T_1(L_tilde) = L_tilde
        T_k.append(L_tilde)
        
    # T_k(L_tilde) = 2 * L_tilde * T_{k-1}(L_tilde) - T_{k-2}(L_tilde)
    for k in range(2, K):
        T_k_minus_1 = T_k[-1]
        T_k_minus_2 = T_k[-2]
        T_k_current = 2 * tf.matmul(L_tilde, T_k_minus_1) - T_k_minus_2
        T_k.append(T_k_current)
        
    return tf.stack(T_k) # Shape: (K, N, N)

class TemporalGatedConv(Layer):
    """Temporal Convolution Layer with Gated Linear Unit (GLU)."""
    def __init__(self, output_channels, kernel_size, **kwargs):
        super().__init__(**kwargs)
        self.output_channels = output_channels
        self.kernel_size = kernel_size
        
        # We need 2 * output_channels for GLU: one for the output, one for the gate
        self.conv = Conv1D(
            filters=2 * output_channels, 
            kernel_size=kernel_size,
            padding='valid', # STGCN uses 'valid' padding
            activation=None
        )

    def call(self, X):
        # Input X shape: (B, T, N, F_in)
        B, T, N, F_in = tf.shape(X)
        
        # Reshape for 1D convolution: (B*N, T, F_in)
        X_reshaped = tf.reshape(X, (B * N, T, F_in))
        
        # Apply 1D convolution
        # Output shape: (B*N, T_out, 2*F_out)
        conv_output = self.conv(X_reshaped)
        
        # Reshape back to (B, N, T_out, 2*F_out)
        conv_output = tf.reshape(conv_output, (B, N, tf.shape(conv_output)[1], 2 * self.output_channels))
        
        # Permute to (B, T_out, N, 2*F_out)
        conv_output = tf.transpose(conv_output, perm=[0, 2, 1, 3])
        
        # Apply GLU: split into result (P) and gate (Q)
        P, Q = tf.split(conv_output, num_or_size_splits=2, axis=-1)
        
        # Output = P * sigmoid(Q)
        return P * tf.sigmoid(Q)
    
class SpatialChebyshevConv(Layer):
    """Spatial Graph Convolution Layer using Chebyshev approximation."""
    def __init__(self, K, output_channels, **kwargs):
        super().__init__(**kwargs)
        self.K = K  # Order of Chebyshev polynomial
        self.output_channels = output_channels
        # Learnable weights Theta_k, shape (K, F_in, F_out)
        self.theta = self.add_weight(
            shape=(K, 1, 1, output_channels), 
            initializer='glorot_uniform', 
            trainable=True,
            name='chebyshev_weights'
        )

    def call(self, X, L_tilde):
        # X shape: (B, T, N, F_in)
        # L_tilde shape: (N, N) - Scaled Laplacian
        B, T, N, F_in = tf.shape(X)
        
        # 1. Calculate Chebyshev Polynomials T_k(L_tilde)
        # T_k_stack shape: (K, N, N)
        T_k_stack = chebyshev_polynomials(L_tilde, self.K)
        
        # 2. Reshape X for matrix multiplication: (B*T, N, F_in)
        X_reshaped = tf.reshape(X, (B * T, N, F_in))
        
        # 3. Graph Convolution Operation
        output_features = []
        for k in range(self.K):
            T_k = T_k_stack[k] # (N, N)
            
            # Apply T_k to X: (B*T, N, F_in) = (N, N) @ (B*T, N, F_in)
            # tf.einsum is ideal here for efficient batch matrix multiplication
            R_k = tf.einsum('ij,bjk->bik', T_k, X_reshaped) # R_k shape: (B*T, N, F_in)
            
            # Apply weights Theta_k: (B*T, N, F_out) = (B*T, N, F_in) @ (F_in, F_out)
            # We use a trick: reshape R_k to (B*T, N, F_in, 1) and Theta_k to (1, 1, F_in, F_out)
            # For simplicity, we use explicit matmul after reshaping the weights.
            
            # Reshape R_k back to (B, T, N, F_in)
            R_k_reshaped = tf.reshape(R_k, (B, T, N, F_in))
            
            # Apply trainable weights theta_k (F_in -> F_out)
            # Theta_k is (1, 1, F_in, F_out). We need to broadcast it.
            # We must define self.theta shape correctly to handle F_in.
            # Let's redefine theta to (K, F_in, F_out) and apply it via einsum/matmul.
            
            # Conceptual Weight application (requires defining F_in in __init__ or build)
            # If we assume F_in is known:
            # We need to map F_in features to F_out features per node.
            
            # Simplified application of theta_k (assuming theta is (K, F_in, F_out))
            # For this solution, we use a dense layer equivalent broadcasted over B, T, N
            
            # We use a simplified dense layer approach for weights, assuming F_in is known
            # and the weights are applied to the F_in dimension.
            
            # Let's use the intended STGCN structure where theta_k is (F_in, F_out) for each k
            
            # Define self.theta correctly: (K, F_in, F_out)
            # Since F_in is dynamic, we must use `build` or pass it. We use `build`.
            
            # R_k_reshaped (B, T, N, F_in). Apply weights: (F_in, F_out)
            # R_k_weighted = R_k_reshaped @ self.theta[k] (This is complex due to shapes)
            
            # Using the intended STGCN formulation:
            # R_k: (B*T, N, F_in). Theta_k: (F_in, F_out).
            
            # We define weights in the call method conceptually:
            # W_k shape (F_in, F_out)
            
            # To simplify the demonstration, we use a placeholder for the weight application
            # assuming the weights have been correctly defined in a build method.
            
            # Placeholder for weight application (assuming theta[k] is (F_in, F_out)):
            # R_k_weighted = tf.einsum('bnf,fo->bno', R_k, self.theta[k])
            
            # Since we cannot define F_in in __init__, we use a simple linear transformation
            # for the output mapping, conceptually replacing the K*F_in -> F_out mapping.
            
            # For correctness, we use the sum formulation:
            # Sum over k: Theta_k * T_k(L_tilde) * X
            
            # R_k_spatial: (B*T, N, F_in)
            
            # We need K sets of weights, each mapping F_in -> F_out
            W_k = self.add_weight(
                shape=(self.K, F_in, self.output_channels), 
                initializer='glorot_uniform', 
                trainable=True,
                name='spatial_weights'
            )
            
            R_k_spatial = tf.einsum('ij,bjk->bik', T_k, X_reshaped) # (B*T, N, F_in)
            
            # Apply weights W_k: (B*T, N, F_out) = (B*T, N, F_in) @ (F_in, F_out)
            R_k_weighted = tf.einsum('bnf,fo->bno', R_k_spatial, W_k[k])
            output_features.append(R_k_weighted)

        # Sum results: (B*T, N, F_out)
        H_spatial = tf.add_n(output_features)
        
        # Reshape back to (B, T, N, F_out)
        H_spatial = tf.reshape(H_spatial, (B, T, N, self.output_channels))
        
        return H_spatial

class STConvBlock(Layer):
    """The full Spatio-Temporal Convolutional Block."""
    def __init__(self, K, Kt, F_in, F_out, **kwargs):
        super().__init__(**kwargs)
        self.F_out = F_out
        self.F_in = F_in
        self.K = K
        self.Kt = Kt
        
        # 1. Temporal Gated Conv (Input -> Hidden)
        self.tconv1 = TemporalGatedConv(output_channels=F_out, kernel_size=Kt)
        
        # 2. Spatial Chebyshev Conv (Hidden -> Hidden)
        self.sconv = SpatialChebyshevConv(K=K, output_channels=F_out)
        
        # 3. Temporal Gated Conv (Hidden -> Output)
        self.tconv2 = TemporalGatedConv(output_channels=F_out, kernel_size=Kt)
        
        # Optional: Residual Connection (1x1 Conv if F_in != F_out or T_in != T_out)
        # Since T_out changes due to 'valid' padding, we need a 1x1 conv on the residual path.
        self.residual_conv = Conv1D(
            filters=F_out, kernel_size=1, activation=None, padding='valid'
        )

    def call(self, X, L_tilde):
        # X shape: (B, T_in, N, F_in)
        T_in = tf.shape(X)[1]
        
        # --- 1. First Temporal Convolution (T_in -> T_mid) ---
        H = self.tconv1(X) # H shape: (B, T_mid, N, F_out)
        
        # --- 2. Spatial Convolution (T_mid, N, F_out -> T_mid, N, F_out) ---
        H = self.sconv(H, L_tilde)
        
        # --- 3. Second Temporal Convolution (T_mid -> T_out) ---
        H = self.tconv2(H) # H shape: (B, T_out, N, F_out)
        T_out = tf.shape(H)[1]
        
        # --- 4. Residual Connection ---
        # Calculate residual: (B, T_in, N, F_in) -> (B*N, T_in, F_in)
        B, N, F_in = tf.shape(X)[0], tf.shape(X)[2], tf.shape(X)[3]
        
        X_res = tf.reshape(X, (B * N, T_in, F_in))
        
        # Apply 1x1 Conv (maps F_in to F_out and ensures T_out length)
        # Since tconv uses 'valid' padding, we must slice X_res to match T_out length
        X_res_conv = self.residual_conv(X_res) # (B*N, T_res, F_out)
        
        # Slice to match H's temporal dimension T_out
        X_res_sliced = X_res_conv[:, :T_out, :] 
        
        # Reshape back: (B, T_out, N, F_out)
        X_res_final = tf.reshape(X_res_sliced, (B, N, T_out, self.F_out))
        X_res_final = tf.transpose(X_res_final, perm=[0, 2, 1, 3])
        
        return Activation('relu')(H + X_res_final)

# Conceptual Demonstration:
# Assume L_hat from Exercise 1 has been scaled to L_tilde [-1, 1]
L_hat_np = calculate_normalized_laplacian(A)
lambda_max = eigsh(L_hat_np, k=1, which='LM', return_eigenvectors=False)[0]
L_tilde_np = (2 / lambda_max) * L_hat_np - np.eye(N_NODES)
L_tilde_tf = tf.constant(L_tilde_np, dtype=tf.float32)

# Simulate Input Batch: (B=32, T=12, N=50, F=5)
X_batch = np.random.rand(32, 12, N_NODES, 5).astype(np.float32)

# Initialize ST-Conv Block
st_conv = STConvBlock(K=3, Kt=3, F_in=5, F_out=64)

# Run forward pass
H_output = st_conv(X_batch, L_tilde_tf)

print(f"\nInput X shape: {X_batch.shape}")
print(f"Output H shape (B, T_out, N, F_out): {H_output.shape}")
# T_out = T_in - 2*(Kt-1) = 12 - 2*(3-1) = 8

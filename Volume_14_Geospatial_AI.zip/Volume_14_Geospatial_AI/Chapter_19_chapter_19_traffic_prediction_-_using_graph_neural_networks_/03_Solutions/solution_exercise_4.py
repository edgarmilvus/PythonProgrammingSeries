
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import asyncio
from typing import AsyncGenerator

# --- 1. Define the Asynchronous Data Interface (Provided Structure) ---

class AsyncTrafficStream:
    """
    Simulates a real-time traffic data feed that yields
    pre-processed feature tensors (X) and Laplacian matrices (L).
    """
    def __init__(self, stream_id: str):
        self.stream_id = stream_id
        self.connected = False
        print(f"[{self.stream_id}] Stream initialized.")

    async def __aenter__(self):
        # Asynchronous resource acquisition (connecting to a socket)
        print(f"[{self.stream_id}] Attempting connection...")
        await asyncio.sleep(0.5)
        self.connected = True
        print(f"[{self.stream_id}] Connected successfully.")
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        # Asynchronous resource release (closing the connection)
        print(f"[{self.stream_id}] Disconnecting...")
        await asyncio.sleep(0.1)
        self.connected = False
        if exc_type:
            print(f"[{self.stream_id}] Exception encountered: {exc_val}")
        print(f"[{self.stream_id}] Disconnected.")

    async def stream_data(self) -> AsyncGenerator[tuple, None]:
        """Yields (X, L) batches asynchronously."""
        for i in range(5): # Limit to 5 batches for simulation
            await asyncio.sleep(0.2) # Simulating I/O latency
            # In a real system, X and L would be tensors
            yield (f"Batch_{i}", "Laplacian_Matrix") 

# --- 2. Implement Asynchronous Inference Loop and Concurrent Task ---

async def update_map_display(data_batch_id: str):
    """
    Simulates a non-blocking task (e.g., updating a GIS interface)
    concurrently with model inference.
    """
    print(f"  [Map Display] Received prediction for {data_batch_id}. Rendering...")
    # Simulate the time taken for rendering/network transmission
    await asyncio.sleep(0.3) 
    print(f"  [Map Display] Finished rendering {data_batch_id}.")

async def perform_stgcn_inference(model, data_batch_id, X, L):
    """Simulates the synchronous model prediction step."""
    print(f"    [Inference] Processing {data_batch_id}...")
    # Note: Model inference itself (matrix multiplication) is CPU-bound 
    # and should ideally be run in a separate ThreadPoolExecutor 
    # if it blocks for too long, but here we simulate the overall time.
    await asyncio.sleep(0.1) 
    
    # Y_pred = model.predict(X, L)
    Y_pred = f"Predicted_Speed_{data_batch_id}"
    print(f"    [Inference] Prediction complete for {data_batch_id}.")
    return Y_pred

async def run_inference(model, stream_id: str):
    """
    Connects to the asynchronous stream and performs inference on received batches.
    Must use async with and async for.
    """
    # Use Asynchronous Context Manager for safe connection handling
    async with AsyncTrafficStream(stream_id) as stream:
        
        # Use Asynchronous Iterator to consume data batches
        async for data_batch_id, L in stream.stream_data():
            
            # Simulate receiving the feature tensor X
            X = "Feature_Tensor" 
            
            # Schedule the inference task
            inference_task = perform_stgcn_inference(model, data_batch_id, X, L)
            
            # Schedule the map update task (which depends on the prediction result)
            # For simplicity, we run the inference and then trigger the map update.
            # In a real system, we might gather multiple concurrent tasks here.
            
            prediction_result = await inference_task
            
            # Trigger the concurrent GeoAI task
            await update_map_display(prediction_result)
            print("-" * 30)
            
async def main_deployment_simulation():
    # Assume model loading is synchronous for simplicity
    stgcn_model = "Trained_STGCN_Model" 
    
    # Orchestrate the concurrent execution of the inference pipeline 
    # and another continuous background task (e.g., system health check)
    
    async def continuous_health_check():
        for i in range(1, 4):
            await asyncio.sleep(0.7)
            print(f"[Health Check] System operational. Cycle {i}.")

    print("Starting GeoAI Deployment Simulation...")
    
    # Use asyncio.gather to run the inference loop and the health check concurrently
    await asyncio.gather(
        run_inference(stgcn_model, "Highway_101_Feed"),
        continuous_health_check()
    )
    print("Deployment simulation finished.")
    
if __name__ == "__main__":
    # Ensure the event loop is run correctly
    try:
        asyncio.run(main_deployment_simulation())
    except KeyboardInterrupt:
        print("Simulation interrupted.")

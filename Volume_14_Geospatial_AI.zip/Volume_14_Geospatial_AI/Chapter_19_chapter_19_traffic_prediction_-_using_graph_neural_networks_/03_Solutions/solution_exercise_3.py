
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Flatten
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import matplotlib.pyplot as plt
import itertools

# Reuse data and components from Exercise 1 & 2 (A, L_tilde_tf, train_data, test_data)

# --- 1. Full STGCN Model Assembly ---

class STGCNModel(Model):
    def __init__(self, N, F_in, T_hist, T_pred, K, Kt, F_blocks, **kwargs):
        super().__init__(**kwargs)
        self.T_pred = T_pred
        self.N = N
        
        # Block 1: F_in -> F_blocks[0]
        self.st_conv1 = STConvBlock(K=K, Kt=Kt, F_in=F_in, F_out=F_blocks[0])
        
        # Block 2: F_blocks[0] -> F_blocks[1]
        self.st_conv2 = STConvBlock(K=K, Kt=Kt, F_in=F_blocks[0], F_out=F_blocks[1])
        
        # Output layers
        self.flatten = Flatten()
        # Final Dense layer maps the remaining features (T_out * N * F_last) 
        # to the prediction shape (T_pred * N)
        self.output_layer = Dense(T_pred * N)

    def call(self, inputs):
        X, L_tilde = inputs
        
        H = self.st_conv1(X, L_tilde)
        H = self.st_conv2(H, L_tilde)
        
        # H shape: (B, T_out, N, F_last)
        
        # Flatten and predict
        H_flat = self.flatten(H)
        Y_pred_flat = self.output_layer(H_flat)
        
        # Reshape output to (B, T_pred, N)
        Y_pred = tf.reshape(Y_pred_flat, (tf.shape(X)[0], self.T_pred, self.N))
        return Y_pred

# --- Data Preparation for Training ---
# Stack training data into large tensors (using subset for speed)
# Note: In a real scenario, use a tf.data.Dataset for efficient batching.
X_train_data = np.stack([x[0] for x in train_data])
Y_train_data = np.stack([x[1] for x in train_data])
X_test_data = np.stack([x[0] for x in test_data])
Y_test_data = np.stack([x[1] for x in test_data])
L_tilde_tf_batch = tf.expand_dims(L_tilde_tf, axis=0) # (1, N, N)

# --- 2. Hyperparameter Optimization (HPO) Strategy ---

def run_hpo_search(X_data, Y_data, L_tilde, N, F_in, T_hist, T_pred):
    """Performs a small grid search for key hyperparameters."""
    
    K_options = [2, 3]       # Chebyshev Order
    Kt_options = [3, 5]      # Temporal Kernel Size
    F_out_options = [32, 64] # Hidden Features
    
    best_val_mae = float('inf')
    best_params = {}
    
    for K, Kt, F_out in itertools.product(K_options, Kt_options, F_out_options):
        print(f"\n--- Testing K={K}, Kt={Kt}, F_out={F_out} ---")
        
        # Initialize and compile model
        model = STGCNModel(N, F_in, T_hist, T_pred, K=K, Kt=Kt, 
                           F_blocks=[F_out, F_out], name=f'stgcn_{K}_{Kt}_{F_out}')
        
        optimizer = tf.keras.optimizers.Adam(learning_rate=0.001)
        # Using MAE as the primary metric for traffic prediction
        model.compile(optimizer=optimizer, loss='mae', metrics=['mae'])
        
        # Dummy training loop (using minimal epochs for HPO speed)
        history = model.fit(
            x=(X_data, tf.repeat(L_tilde, tf.shape(X_data)[0], axis=0)),
            y=Y_data,
            epochs=5, 
            batch_size=32, 
            validation_split=0.15,
            verbose=0 
        )
        
        val_mae = min(history.history['val_mae'])
        print(f"Validation MAE: {val_mae:.4f}")
        
        if val_mae < best_val_mae:
            best_val_mae = val_mae
            best_params = {'K': K, 'Kt': Kt, 'F_out': F_out}
            
    return best_params

# Run HPO (Using a small subset of training data for speed)
F_IN = X_train_data.shape[-1] # 5 features
# best_params = run_hpo_search(X_train_data[:500], Y_train_data[:500], L_tilde_tf_batch, N_NODES, F_IN, T_HIST, T_PRED)
# print(f"\nOptimal Hyperparameters: {best_params}")

# Assume optimal parameters found:
OPTIMAL_K = 3
OPTIMAL_KT = 3
OPTIMAL_F = 64

# --- 3. Final Model Training and Evaluation ---

final_model = STGCNModel(N_NODES, F_IN, T_HIST, T_PRED, 
                         K=OPTIMAL_K, Kt=OPTIMAL_KT, F_blocks=[OPTIMAL_F, OPTIMAL_F])

final_model.compile(optimizer=tf.keras.optimizers.Adam(0.001), loss='mae', metrics=['mae', 'mse'])

# Train the final model (More epochs)
# final_model.fit(
#     x=(X_train_data, tf.repeat(L_tilde_tf_batch, tf.shape(X_train_data)[0], axis=0)),
#     y=Y_train_data,
#     epochs=10, 
#     batch_size=32, 
#     validation_data=(X_test_data, Y_test_data),
#     verbose=0
# )

# Simulate Prediction
Y_pred_norm = np.random.normal(Y_test_data, scale=0.5) # Simulate reasonable predictions

# Denormalize predictions and actual values (using simulated means/stds from Ex 1)
# Remember: Y_target (speed) is the first feature (index 0).
Y_test_speed = Y_test_data * stds[0] + means[0]
Y_pred_speed = Y_pred_norm * stds[0] + means[0]

# Calculate Metrics
mae = mean_absolute_error(Y_test_speed.flatten(), Y_pred_speed.flatten())
rmse = np.sqrt(mean_squared_error(Y_test_speed.flatten(), Y_pred_speed.flatten()))
r2 = r2_score(Y_test_speed.flatten(), Y_pred_speed.flatten())

print("\n--- Performance Metrics on Test Set (Denormalized Speed) ---")
print(f"Overall MAE: {mae:.2f} mph")
print(f"Overall RMSE: {rmse:.2f} mph")
print(f"Overall R2 Score: {r2:.3f}")

# Segmented Evaluation (by prediction horizon)
print("\nSegmented MAE by Horizon (5 min, 10 min, 15 min):")
for t in range(T_PRED):
    horizon_mae = mean_absolute_error(Y_test_speed[:, t, :].flatten(), Y_pred_speed[:, t, :].flatten())
    print(f"  T+{ (t+1)*5 } min MAE: {horizon_mae:.2f} mph")


# Visualization (Simulated Rush Hour Plot)
def visualize_performance(Y_actual, Y_predicted, node_idx, start_time_step, duration):
    """Plots actual vs predicted speed for a specific node during rush hour."""
    
    # Select a single node and a time window
    actual_series = Y_actual[:, :, node_idx].flatten()
    pred_series = Y_predicted[:, :, node_idx].flatten()
    
    # Simplify the time axis for visualization (e.g., plot the first 100 predictions)
    plot_len = min(duration, len(actual_series))
    
    plt.figure(figsize=(12, 6))
    plt.plot(actual_series[:plot_len], label='Actual Speed (mph)', color='blue')
    plt.plot(pred_series[:plot_len], label='Predicted Speed (mph)', color='red', linestyle='--')
    
    plt.title(f'Traffic Speed Prediction for Link ID {node_idx} (Rush Hour Simulation)')
    plt.xlabel('Prediction Index (5-minute steps)')
    plt.ylabel('Speed (mph)')
    plt.legend()
    plt.grid(True, alpha=0.5)
    plt.show()

# Simulate visualization for Node 10 over 100 prediction steps (approx 8 hours)
# visualize_performance(Y_test_speed, Y_pred_speed, node_idx=10, start_time_step=100, duration=100)

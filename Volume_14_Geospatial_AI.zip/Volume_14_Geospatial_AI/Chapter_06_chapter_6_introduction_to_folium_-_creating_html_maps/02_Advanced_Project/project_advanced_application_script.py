
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import folium
import os
from datetime import datetime

# --- 1. Configuration Constants ---
# Define the project focus area (e.g., San Francisco Bay Area)
TARGET_COORDINATES = (37.7749, -122.4194)
INITIAL_ZOOM = 12
OUTPUT_FILENAME = "Infrastructure_Tile_Switcher.html"

# Define the standard tile layer dictionary for different visualization needs
# Key: Display Name (for LayerControl), Value: Folium Tile String Identifier
TILE_LAYERS = {
    "OpenStreetMap (Default)": "OpenStreetMap",
    "Stamen Toner (High Contrast Roads)": "Stamen Toner",
    "Stamen Terrain (Topography Focus)": "Stamen Terrain",
    "CartoDB Positron (Light Background)": "CartoDB Positron",
    "CartoDB DarkMatter (Night Mode/Data Focus)": "CartoDB dark_matter"
}

def create_base_map(location: tuple, zoom_start: int, default_tiles: str = "OpenStreetMap") -> folium.Map:
    """
    Initializes the core Folium map object centered on the target location.
    
    Args:
        location: (latitude, longitude) tuple for map center.
        zoom_start: Initial zoom level integer.
        default_tiles: The initial tile set to display upon loading.
        
    Returns:
        A configured folium.Map object.
    """
    # Instantiate the map object, defining its initial state and default tile set
    m = folium.Map(
        location=location,
        zoom_start=zoom_start,
        tiles=default_tiles,
        # Setting control_scale=True adds a scale indicator to the map
        control_scale=True 
    )
    return m

def add_multiple_tile_layers(folium_map: folium.Map, layers: dict) -> None:
    """
    Iterates through a dictionary of tile layers and adds them to the map 
    as selectable options, excluding the default layer already loaded.
    
    Args:
        folium_map: The existing Folium Map object.
        layers: Dictionary mapping display names to Folium tile strings.
    """
    # Identify the key of the layer already set as the map's default tile set
    default_key = list(layers.keys())[0] 
    
    for display_name, tile_string in layers.items():
        if display_name != default_key:
            # Create a TileLayer object and attach it to the map.
            # CRITICAL: overlay=False ensures this is treated as a BASE LAYER, 
            # meaning only one can be active at a time.
            folium.TileLayer(
                tiles=tile_string,
                name=display_name,
                overlay=False, 
                control=True # Ensure it appears in the LayerControl widget
            ).add_to(folium_map)

def finalize_and_save_map(folium_map: folium.Map, filename: str) -> str:
    """
    Adds the LayerControl interface and saves the final map to an HTML file.
    
    Args:
        folium_map: The fully configured Folium Map object.
        filename: The desired output filename.
        
    Returns:
        Confirmation message string detailing the output location and size.
    """
    # Add the LayerControl object. This automatically scans the map for 
    # all TileLayers (Base Layers) and FeatureGroups (Overlays).
    folium.LayerControl(position='topright', collapsed=False).add_to(folium_map)
    
    # Save the map as a standalone HTML file containing all necessary CSS/JS
    folium_map.save(filename)
    
    # Return confirmation details
    file_path = os.path.abspath(filename)
    size_kb = os.path.getsize(filename) / 1024
    
    return f"Map successfully saved to {file_path}. Size: {size_kb:.2f} KB."

# --- 4. Main Execution Block ---
if __name__ == "__main__":
    print(f"--- Starting Folium Map Generation ({datetime.now().strftime('%Y-%m-%d %H:%M:%S')}) ---")
    
    try:
        # Step 1: Initialize the core map structure
        base_map = create_base_map(
            location=TARGET_COORDINATES, 
            zoom_start=INITIAL_ZOOM,
            default_tiles=TILE_LAYERS[list(TILE_LAYERS.keys())[0]] # Use the first defined layer as default
        )
        print(f"Base map initialized at {TARGET_COORDINATES} with zoom {INITIAL_ZOOM}.")
        
        # Step 2: Add the remaining tile layers to the map object
        add_multiple_tile_layers(base_map, TILE_LAYERS)
        print(f"Added {len(TILE_LAYERS)} selectable tile layers.")
        
        # Step 3: Finalize and export the map
        result_message = finalize_and_save_map(base_map, OUTPUT_FILENAME)
        
        print("\n--- Process Complete ---")
        print(result_message)
        print("Open the HTML file in any web browser to view the interactive map.")

    except Exception as e:
        print(f"An error occurred during map generation: {e}")

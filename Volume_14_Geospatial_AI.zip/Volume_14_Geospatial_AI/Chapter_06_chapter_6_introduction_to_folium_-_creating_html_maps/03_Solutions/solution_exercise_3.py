
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import folium

# 1. Define Rio de Janeiro coordinates and zoom level
rio_coords = [-22.9068, -43.1729]
zoom_level = 11

# 2. Map Initialization (Defaulting to OpenStreetMap)
m = folium.Map(location=rio_coords, zoom_start=zoom_level)

# 3. Tile Layer 1 (Default): Standard Detail
# We explicitly add it to ensure it gets the custom name in LayerControl
folium.TileLayer('OpenStreetMap', name='Standard Detail').add_to(m)

# 4. Tile Layer 2 (Water Emphasis): Stamen Water Color
folium.TileLayer('Stamen Watercolor', name='Watercolor Presentation').add_to(m)

# 5. Tile Layer 3 (Dark Context): CartoDB Dark Matter
folium.TileLayer('CartoDB Dark Matter', name='Dark Context').add_to(m)

# 6. Layer Control Implementation
folium.LayerControl().add_to(m)

# 7. Saving
m.save("rio_aesthetic_switcher.html")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import rasterio
import richdem as rd
from sklearn.preprocessing import StandardScaler
from pathlib import Path
import matplotlib.pyplot as plt 

# --- Configuration and Setup ---
# Define paths for input and output files
OUTPUT_DIR = Path("./terrain_features")
DEM_FILE = OUTPUT_DIR / "simulated_dem.tif"
FEATURE_STACK_FILE = OUTPUT_DIR / "terrain_feature_stack.tif"

# Ensure output directory exists before writing files
OUTPUT_DIR.mkdir(exist_ok=True)

# 1. Simulate a Digital Elevation Model (DEM)
# In a production environment, this step loads an existing GeoTIFF.
print("1. Simulating DEM data...")
size = 256
resolution = 10.0 # Resolution in meters/pixel

# Create a synthetic, complex terrain array for robust derivative testing
x = np.linspace(-5, 5, size)
y = np.linspace(-5, 5, size)
X, Y = np.meshgrid(x, y)
Z = 100 + 50 * np.sin(X * 2) * np.cos(Y * 3) + 20 * X
dem_array = Z.astype(np.float32)

# Define metadata for Rasterio (essential for richDEM and output georeferencing)
profile = {
    'driver': 'GTiff',
    'dtype': rasterio.float32,
    'nodata': -9999.0,
    'width': size,
    'height': size,
    'count': 1,
    'crs': 'EPSG:32610', # Example UTM zone
    'transform': rasterio.transform.from_bounds(
        0, 0, size * resolution, size * resolution, size, size
    )
}

# Write the simulated DEM to disk. richDEM prefers reading from a file path.
with rasterio.open(DEM_FILE, 'w', **profile) as dst:
    dst.write(dem_array, 1)

# 2. Load DEM using richDEM's specialized structure
# richDEM's internal RD array optimizes memory and computation for terrain tasks.
print(f"2. Loading DEM for richDEM processing from {DEM_FILE.name}...")
rd_dem = rd.LoadGDAL(str(DEM_FILE), fill_nodata=True)

# 3. Calculate Core Terrain Derivatives
print("3. Calculating Slope, Aspect, and Profile Curvature...")

# Slope: Measure of steepness (critical for identifying runoff potential)
slope = rd.TerrainAttribute(rd_dem, attrib='slope_degrees')

# Aspect: Direction the slope faces (influences solar radiation and soil moisture)
aspect = rd.TerrainAttribute(rd_dem, attrib='aspect')

# Profile Curvature: Rate of change of slope along the flow path (identifies acceleration/deceleration)
p_curvature = rd.TerrainAttribute(rd_dem, attrib='profile_curvature')

# Collect the derivatives as standard NumPy arrays for ML preprocessing
derivatives = {
    'slope': slope.get_array(),
    'aspect': aspect.get_array(),
    'p_curvature': p_curvature.get_array()
}

# 4. Feature Standardization (Mandatory for GeoAI/ML input)
print("4. Standardizing features using StandardScaler...")

scaler = StandardScaler()
feature_list = []

for name, arr in derivatives.items():
    # Handle potential NoData values if they exist (though richDEM handles most internally)
    valid_mask = ~np.isnan(arr)
    
    # Flatten the 2D array into a 1D vector (required input format for sklearn scaler)
    flat_arr = arr[valid_mask].reshape(-1, 1)
    
    # Fit and transform the data: (x - mean) / std_dev
    scaled_flat_arr = scaler.fit_transform(flat_arr)
    
    # Create an empty array to hold the standardized result, maintaining NoData locations
    scaled_arr_full = np.full(arr.shape, np.nan, dtype=np.float32)
    
    # Place the standardized values back into the 2D grid
    scaled_arr_full[valid_mask] = scaled_flat_arr.flatten()
    
    # Append the final standardized array
    feature_list.append(scaled_arr_full.astype(np.float32))
    print(f"   -> Standardized {name}. Shape: {scaled_arr_full.shape}")

# 5. Stack and Write the Multi-Band Feature Raster
print(f"5. Writing multi-band feature stack to {FEATURE_STACK_FILE.name}...")

# Update the rasterio profile to reflect the new band count (3 features)
profile.update({
    'count': len(feature_list), 
    'dtype': rasterio.float32,
    # Standardized features often have values around 0, so we update nodata handling
    'nodata': profile['nodata'] # Keep original nodata value if present
})

# Open the output file and write the stacked features
with rasterio.open(FEATURE_STACK_FILE, 'w', **profile) as dst:
    # Iterate through the list and write each standardized feature as a separate band
    for i, feature_array in enumerate(feature_list):
        dst.write(feature_array, i + 1)
        
print("\nProcess Complete. The GeoAI feature stack is ready.")
print(f"Output Feature Stack: {FEATURE_STACK_FILE.name} | Bands: {profile['count']}")

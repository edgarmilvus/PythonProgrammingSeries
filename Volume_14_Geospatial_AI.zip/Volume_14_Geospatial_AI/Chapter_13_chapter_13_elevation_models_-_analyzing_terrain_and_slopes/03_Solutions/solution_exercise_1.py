
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import rasterio
from rasterio.enums import Resampling
from rasterio.transform import Affine
import numpy as np
import os

# --- Simulation Setup (Creating a dummy input file) ---
ORIG_RES = 1.0
TARGET_RES = 10.0
WIDTH, HEIGHT = 1000, 1000
CRS = 'EPSG:32617'
DTYPE = 'float32'
input_path = "simulated_input_dem.tif"
output_path = "resampled_output_dem.tif"

# Create dummy data and write simulated input file
original_dem_data = (np.indices((HEIGHT, WIDTH))[0] * 0.4 + np.random.rand(HEIGHT, WIDTH) * 5).astype(DTYPE)
profile = {
    'driver': 'GTiff', 'width': WIDTH, 'height': HEIGHT, 'crs': CRS,
    'transform': Affine(ORIG_RES, 0.0, 100000.0, 0.0, -ORIG_RES, 500000.0),
    'count': 1, 'dtype': DTYPE, 'nodata': -9999
}
with rasterio.open(input_path, 'w', **profile) as dst:
    dst.write(original_dem_data, 1)
# ----------------------------------------------------

def calculate_new_dims(original_width, original_height, scale_factor):
    """Calculates new dimensions based on the resolution factor."""
    new_width = int(original_width / scale_factor)
    new_height = int(original_height / scale_factor)
    return new_width, new_height

def resample_and_save_dem(input_path, output_path, target_resolution):
    with rasterio.open(input_path) as src:
        # 1. Data Loading and Inspection
        print("--- Original DEM Metadata ---")
        print(f"Dimensions (W x H): {src.width} x {src.height}")
        print(f"Resolution (X, Y): {src.res}")
        print(f"CRS: {src.crs}")
        print(f"Data Type: {src.dtype}\n")

        # Calculate scale factor and new dimensions
        res_factor = target_resolution / src.res[0]
        new_width, new_height = calculate_new_dims(src.width, src.height, res_factor)
        
        # Calculate new geotransform (maintaining extent)
        new_transform = src.transform * src.transform.scale(
            (src.width / new_width),
            (src.height / new_height)
        )

        # 2. Resampling Implementation
        resampled_data = np.empty((new_height, new_width), dtype=src.dtype)
        
        rasterio.warp.reproject(
            source=rasterio.band(src, 1),
            destination=resampled_data,
            src_transform=src.transform,
            src_crs=src.crs,
            dst_transform=new_transform,
            dst_crs=src.crs,
            resampling=Resampling.bilinear
        )

        # 3. Statistical Verification
        original_data = src.read(1)
        print("--- Statistical Verification ---")
        print(f"Original Mean/Std: {original_data.mean():.2f} / {original_data.std():.2f}")
        print(f"Resampled Mean/Std: {resampled_data.mean():.2f} / {resampled_data.std():.2f}")
        
        # 4. Output TIF Generation
        new_profile = src.profile.copy()
        new_profile.update({
            'width': new_width,
            'height': new_height,
            'transform': new_transform,
        })

        with rasterio.open(output_path, 'w', **new_profile) as dst:
            dst.write(resampled_data, 1)
            print(f"\nSuccessfully wrote resampled DEM to {output_path}")

resample_and_save_dem(input_path, output_path, TARGET_RES)
os.remove(input_path)
os.remove(output_path)

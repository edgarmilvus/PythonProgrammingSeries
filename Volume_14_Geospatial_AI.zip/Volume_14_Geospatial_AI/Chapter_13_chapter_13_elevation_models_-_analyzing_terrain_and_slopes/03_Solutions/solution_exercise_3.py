
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import richdem as rd
import numpy as np

# --- Simulation Setup ---
SIZE = 200
CELL_SIZE = 5.0
dem_data = (np.indices((SIZE, SIZE))[0] * 0.5 + np.random.rand(SIZE, SIZE) * 10)
dem_rd = rd.rdarray(dem_data, no_data=-9999)
dem_rd.geotransform = (0, CELL_SIZE, 0, 0, 0, -CELL_SIZE)
# ------------------------

def calculate_twi(dem_rd, cell_size):
    
    # 1. Data Preparation (richDEM rdarray is already prepared)
    
    # 2. Flow Accumulation Calculation (Ac)
    # Using D8 method for flow routing
    fdir = rd.FlowDirection(dem_rd, method='D8')
    Ac = rd.FlowAccumulation(fdir, method='D8', routing='D8', norm_se=True) 

    # 3. Slope Calculation (beta) in radians
    slope_rad = rd.TerrainAttribute(dem_rd, attrib='slope', units='radians')
    tan_beta = np.tan(slope_rad)
    
    # Handle near-zero slopes to prevent division by zero in TWI formula
    # Add a small epsilon (0.001 radians is approx 0.057 degrees)
    epsilon = 0.001 
    tan_beta[tan_beta < epsilon] = epsilon
    
    # 4. TWI Derivation
    
    # Specific Catchment Area (As) calculation:
    # As = Ac * cell_size (where Ac is accumulation count)
    As = np.array(Ac) * cell_size
    
    # Ensure As is positive for the logarithm
    As[As <= 0] = cell_size 
    
    # TWI = ln(As / tan(beta))
    twi_array = np.log(As / tan_beta)
    
    # 5. Visualization Preparation and Statistics
    # Re-apply richDEM NoData mask (if any were present)
    twi_array[dem_rd.is_no_data()] = np.nan 
    
    print("--- TWI Calculation Results ---")
    print(f"TWI Min: {np.nanmin(twi_array):.2f}")
    print(f"TWI Max: {np.nanmax(twi_array):.2f}")
    print(f"TWI Mean: {np.nanmean(twi_array):.2f}")
    
    return twi_array

calculate_twi(dem_rd, CELL_SIZE)

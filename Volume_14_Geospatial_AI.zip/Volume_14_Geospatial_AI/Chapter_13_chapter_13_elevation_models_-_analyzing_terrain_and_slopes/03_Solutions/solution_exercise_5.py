
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np

# --- Simulation Setup ---
# Simulate a 2D Aspect array (in degrees) that crosses the 0/360 boundary
SIZE = 50
aspect_degrees_array = np.linspace(300, 60, SIZE * SIZE).reshape(SIZE, SIZE)
aspect_degrees_array = np.clip(aspect_degrees_array, 0, 360) 

# Simulate two other normalized features for stacking demonstration
elevation_normalized = np.random.rand(SIZE, SIZE)
slope_normalized = np.random.rand(SIZE, SIZE)
# ------------------------

def transform_cyclical_aspect(aspect_degrees_array):
    """
    Transforms cyclical aspect data into continuous Sine and Cosine components.
    """
    # 2. Degree to Radian Conversion
    aspect_radians = np.radians(aspect_degrees_array)
    
    # 3. Feature Transformation
    aspect_sine = np.sin(aspect_radians)
    aspect_cosine = np.cos(aspect_radians)
    
    return aspect_sine, aspect_cosine

# Execute transformation (Requirement 1, 2, 3)
aspect_sine, aspect_cosine = transform_cyclical_aspect(aspect_degrees_array)

# 4. Feature Replacement Demonstration
# Original Stack (conceptually): [Elevation, Slope, Aspect_degrees]
new_stack = np.stack([
    elevation_normalized, 
    slope_normalized, 
    aspect_sine, 
    aspect_cosine
], axis=0)

print("--- Cyclical Aspect Transformation Summary ---")
print(f"Original Aspect Range (Degrees): {np.min(aspect_degrees_array):.1f} to {np.max(aspect_degrees_array):.1f}")
print(f"Aspect Sine Range: {np.min(aspect_sine):.4f} to {np.max(aspect_sine):.4f}")
print(f"Aspect Cosine Range: {np.min(aspect_cosine):.4f} to {np.max(aspect_cosine):.4f}")
print(f"\nNew Feature Stack Shape (Channels, H, W): {new_stack.shape}")
print("The feature count increased from 3 to 4, replacing one cyclical feature with two continuous features.")

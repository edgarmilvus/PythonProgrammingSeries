
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import richdem as rd
import numpy as np

# --- Simulation Setup ---
SIZE = 100
CELL_SIZE = 5.0
dem_data = (np.indices((SIZE, SIZE))[0] * 1.5 - np.indices((SIZE, SIZE))[1] * 0.8)
dem_rd = rd.rdarray(dem_data, no_data=-9999)
dem_rd.geotransform = (0, CELL_SIZE, 0, 0, 0, -CELL_SIZE)
# ------------------------

def z_score_normalize(data_array):
    """Calculates Z-score normalization: (x - mu) / sigma."""
    valid_data = data_array[~np.isnan(data_array)]
    if valid_data.size == 0:
        return data_array
        
    mu = np.mean(valid_data)
    sigma = np.std(valid_data)
    
    if sigma == 0:
        return np.zeros_like(data_array)
        
    normalized_array = (data_array - mu) / sigma
    return normalized_array

def create_advanced_feature_stack(dem_rd):
    
    # 1. Feature Calculation
    elevation = np.array(dem_rd) 
    slope = np.array(rd.TerrainAttribute(dem_rd, attrib='slope', units='degrees'))
    aspect = np.array(rd.TerrainAttribute(dem_rd, attrib='aspect', units='degrees'))
    profile_curvature = np.array(rd.TerrainAttribute(dem_rd, attrib='profile_curvature'))
    
    # 2. Data Normalization/Scaling (Z-score)
    # Normalize Elevation, Slope, and Curvature. Aspect (cyclical) is left raw.
    norm_elevation = z_score_normalize(elevation)
    norm_slope = z_score_normalize(slope)
    norm_curvature = z_score_normalize(profile_curvature)
    
    # 3. Feature Stacking
    feature_list = [
        norm_elevation,
        norm_slope,
        aspect, # Raw Aspect (for later cyclical transformation)
        norm_curvature
    ]
    
    # Stack arrays along axis 0: (Channels, H, W)
    feature_stack = np.stack(feature_list, axis=0)
    
    # 4. Metadata Tracking
    print("--- GeoAI Feature Stack Summary ---")
    print(f"Stack Shape: {feature_stack.shape}")
    print("Feature Index Mapping:")
    print("[0]: Normalized Elevation")
    print("[1]: Normalized Slope")
    print("[2]: Raw Aspect (Degrees)")
    print("[3]: Normalized Profile Curvature")
    
    return feature_stack

create_advanced_feature_stack(dem_rd)

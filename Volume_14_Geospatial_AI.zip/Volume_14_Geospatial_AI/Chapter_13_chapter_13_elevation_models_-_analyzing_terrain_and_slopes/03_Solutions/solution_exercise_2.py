
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np
import richdem as rd
import time

# --- Simulation Setup ---
SIZE = 500
CELL_SIZE = 10.0
# Create a simulated DEM with variation
dem_array = np.indices((SIZE, SIZE))[0] * 0.5 + np.random.rand(SIZE, SIZE) * 2
dem_rd = rd.rdarray(dem_array, no_data=-9999)
dem_rd.geotransform = (0, CELL_SIZE, 0, 0, 0, -CELL_SIZE)
# ------------------------

def calculate_slope_numpy(dem_array, cell_size):
    """Calculates slope in degrees using NumPy's central difference approximation."""
    
    # Calculate gradients (dz/dx and dz/dy)
    dz_dy, dz_dx = np.gradient(dem_array, cell_size)
    
    # Calculate total slope (tan(theta) = sqrt(dz/dx)^2 + (dz/dy)^2)
    slope_rad = np.arctan(np.sqrt(dz_dx**2 + dz_dy**2))
    
    # Convert to degrees
    slope_deg = np.degrees(slope_rad)
    
    return slope_deg

def run_slope_comparison(dem_array, cell_size):
    
    # 1. NumPy Slope Implementation & Benchmarking
    start_time_np = time.time()
    slope_np = calculate_slope_numpy(dem_array, cell_size)
    time_np = time.time() - start_time_np
    
    # 2. richDEM Slope Implementation & Benchmarking
    dem_rd = rd.rdarray(dem_array, no_data=-9999)
    dem_rd.geotransform = (0, cell_size, 0, 0, 0, -cell_size) 
    
    start_time_rd = time.time()
    # Using Horn's method (default in richDEM for 'slope'), outputting degrees
    slope_rd = rd.TerrainAttribute(dem_rd, attrib='slope', units='degrees')
    time_rd = time.time() - start_time_rd
    
    slope_rd_np = np.array(slope_rd)
    
    # 3. Performance Benchmarking
    print(f"--- Performance Comparison (Grid Size: {dem_array.shape}) ---")
    print(f"NumPy Slope Time: {time_np:.4f} seconds")
    print(f"richDEM Slope Time: {time_rd:.4f} seconds")
    if time_rd > 0:
        print(f"richDEM Speedup Factor: {time_np / time_rd:.1f}x faster")

    # 4. Statistical Comparison
    diff = slope_np - slope_rd_np
    rmse = np.sqrt(np.mean(diff**2))
    
    print("\n--- Statistical Comparison (Slope in Degrees) ---")
    print(f"NumPy Mean Slope: {slope_np.mean():.2f}, Std Dev: {slope_np.std():.2f}")
    print(f"richDEM Mean Slope: {slope_rd_np.mean():.2f}, Std Dev: {slope_rd_np.std():.2f}")
    print(f"Root Mean Square Error (RMSE) between methods: {rmse:.4f}")

run_slope_comparison(dem_array, CELL_SIZE)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np
import rasterio
from rasterio.transform import Affine

# --- 1. Configuration and Synthetic DEM Generation ---

# Define the dimensions of our synthetic terrain (100x100 pixels)
ROWS, COLS = 100, 100

# Spatial resolution: The real-world distance represented by one pixel side (in meters)
CELL_SIZE = 10.0

# Create a base elevation array (Z) representing a gentle, uniform ramp
# This simulates elevation rising from 0m to 50m across the width and height.
x_coords = np.linspace(0, 50, COLS)
y_coords = np.linspace(0, 50, ROWS)

# Use np.outer to create a 2D plane where Z = X + Y
Z_ramp = np.outer(np.ones(ROWS), x_coords) + np.outer(y_coords, np.ones(COLS))

# Introduce a small, complex feature (a Gaussian peak) near the center
# This ensures the calculated slope is not perfectly uniform.
center_row, center_col = ROWS // 2, COLS // 2
peak_size = 20 # Size of the peak area (20x20 window)
peak_height = 25.0

# Create indices for the peak area
r_indices = np.arange(peak_size) - peak_size // 2
c_indices = np.arange(peak_size) - peak_size // 2

# Generate a 2D Gaussian function (for smooth, bell-shaped elevation)
gaussian_peak = peak_height * np.exp(-(r_indices**2)[:, None] / 10.0 - (c_indices**2)[None, :] / 10.0)

# Add the peak to the center of the ramp
Z_ramp[center_row - peak_size // 2 : center_row + peak_size // 2,
       center_col - peak_size // 2 : center_col + peak_size // 2] += gaussian_peak

DEM = Z_ramp.astype(np.float32)

# --- 2. Calculate Partial Derivatives (The Gradient) ---

# The gradient function calculates the rate of change (delta Z / delta distance).
# By passing CELL_SIZE (10.0), we ensure the output is in meters/meter (rise/run),
# rather than meters/pixel index.
# The output order is typically (dZ/dY, dZ/dX)
dy_dz, dx_dz = np.gradient(DEM, CELL_SIZE)

# --- 3. Calculate Total Slope Magnitude (Tangent) ---

# The total steepness (slope tangent) is the magnitude of the vector defined by
# the partial derivatives (Pythagorean theorem: S = sqrt(dx^2 + dy^2)).
slope_tangent = np.sqrt(dx_dz**2 + dy_dz**2)

# --- 4. Convert to Standard Units (Degrees) ---

# Use arctan (inverse tangent) to convert the tangent value (rise/run) into
# the angle in radians.
slope_radians = np.arctan(slope_tangent)

# Convert the resulting radians to degrees (standard geospatial output format)
slope_degrees = np.degrees(slope_radians)

# --- 5. Prepare Geospatial Metadata (Rasterio context) ---

# Define the Affine transformation (required by Rasterio to locate the data)
# This maps the pixel coordinates to real-world coordinates.
transform = Affine(CELL_SIZE, 0, 0,
                   0, -CELL_SIZE, 0) # Negative Y cell size for top-left origin

# Define the profile dictionary (metadata structure for a GeoTIFF)
profile = {
    'driver': 'GTiff',
    'dtype': rasterio.float32,
    'nodata': -9999,
    'width': COLS,
    'height': ROWS,
    'count': 1, # Single band output
    'crs': 'EPSG:4326', # Placeholder Coordinate Reference System
    'transform': transform
}

# --- 6. Report Key Statistics ---

print("--- Digital Elevation Model (DEM) Analysis ---")
print(f"Input Grid Shape: {DEM.shape}")
print(f"Resolution (Meters/Pixel): {CELL_SIZE}")
print("-" * 45)
print(f"Maximum Elevation: {np.max(DEM):.2f} m")
print(f"Minimum Elevation: {np.min(DEM):.2f} m")
print("-" * 45)
print(f"Maximum Calculated Slope: {np.max(slope_degrees):.2f}° (Found at the peak)")
print(f"Average Calculated Slope: {np.mean(slope_degrees):.2f}°")
print("-" * 45)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import torch
import torch.nn as nn
import numpy as np
import rasterio
from rasterio.features import shapes
import json
import os
from torchvision import transforms

# --- 1. Define Mock Model Structure and Paths ---

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
OUTPUT_GEOJSON_PATH = "detected_buildings.geojson"

class SimpleBuildingDetector(nn.Module):
    """
    A simplified placeholder for a U-Net or similar segmentation model.
    In a real application, this would be the complete, trained architecture.
    """
    def __init__(self, in_channels=3, out_channels=1):
        super().__init__()
        # Mock layers mimicking a final convolutional block
        self.conv1 = nn.Conv2d(in_channels, 64, kernel_size=3, padding=1)
        self.final_conv = nn.Conv2d(64, out_channels, kernel_size=1)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.relu(self.conv1(x))
        # Logits output, requiring sigmoid/softmax later
        return self.final_conv(x)

def load_mock_weights(model):
    """
    Mocks loading a pre-trained state dictionary.
    In a real scenario, this loads a saved .pth file.
    """
    print(f"[{model.__class__.__name__}] Mock weights loaded successfully.")
    # For demonstration, we skip the actual loading and assume weights are set.
    return model

# --- 2. Mock Geospatial Input and Output Functions ---

def mock_load_satellite_tile(path="input_tile.tif"):
    """
    Mocks loading a satellite image using rasterio and generating mock data.
    Crucially, it simulates reading the essential geospatial metadata.
    """
    # Create mock metadata for a 512x512 tile
    mock_transform = rasterio.transform.from_bounds(
        west=30.0, south=10.0, east=30.01, north=10.01, width=512, height=512
    )
    mock_crs = "EPSG:4326"

    # Create a mock 3-channel (RGB) 512x512 array (HWC format)
    # Data is normalized to 0-255 range for typical satellite imagery
    np.random.seed(42)
    mock_data = (np.random.rand(512, 512, 3) * 255).astype(np.uint8)

    # Store metadata for later use in the main function
    metadata = {
        'transform': mock_transform,
        'crs': mock_crs,
        'width': 512,
        'height': 512,
        'count': 3
    }
    return mock_data, metadata

# --- 3. Core Inference and Vectorization Pipeline ---

def run_geo_inference(input_path, output_path, model_class):
    """
    Executes the full pipeline: Load, Infer, Threshold, Vectorize, Save.
    """
    # Load input data and geospatial metadata
    image_data_np, metadata = mock_load_satellite_tile(input_path)
    print(f"[Data Load] Image shape: {image_data_np.shape}. CRS: {metadata['crs']}")

    # Initialize and load model
    model = model_class().to(DEVICE)
    model = load_mock_weights(model)
    model.eval()

    # --- Preprocessing ---
    # Convert HWC (Height, Width, Channel) to CWH for PyTorch
    image_tensor = torch.from_numpy(image_data_np).float() / 255.0
    image_tensor = image_tensor.permute(2, 0, 1).unsqueeze(0).to(DEVICE) # (1, C, H, W)

    # --- Inference ---
    with torch.no_grad():
        logits = model(image_tensor) # Output shape (1, 1, H, W)

    # Apply Sigmoid and Thresholding (Crucial post-processing step)
    probability_map = torch.sigmoid(logits).squeeze().cpu().numpy()
    # Convert probabilities to a definitive binary mask (0 or 1)
    binary_mask = (probability_map > 0.5).astype(np.uint8)
    print(f"[Inference] Generated binary mask of shape: {binary_mask.shape}")

    # --- Raster-to-Vector Conversion (The GIS Bridge) ---

    # Use rasterio.features.shapes to convert the binary raster mask into polygon geometries.
    # The transform (affine matrix) is used to project pixel coordinates to map coordinates.
    # `mask=binary_mask` ensures only pixels where the mask is True (value 1) are processed.
    # `connectivity=8` ensures diagonal connections are considered part of the same feature.
    results = (
        {'properties': {'building_id': i, 'class': val}, 'geometry': geom}
        for i, (geom, val) in enumerate(
            shapes(binary_mask, transform=metadata['transform'], mask=binary_mask)
        )
        if val == 1 # Only process the foreground class (buildings)
    )

    # --- GeoJSON Output Generation ---
    features = list(results)
    print(f"[Vectorization] Detected {len(features)} building polygons.")

    if not features:
        print("[Save] No buildings detected. Skipping GeoJSON creation.")
        return

    geojson_output = {
        "type": "FeatureCollection",
        "crs": {"type": "name", "properties": {"name": metadata['crs']}},
        "features": features
    }

    with open(output_path, 'w') as f:
        json.dump(geojson_output, f, indent=2)

    print(f"[Success] GeoJSON saved to {output_path}")


# --- 4. Execution ---
if __name__ == "__main__":
    # Note: input_tile.tif is a mock path, no file is actually read from disk
    run_geo_inference("input_tile.tif", OUTPUT_GEOJSON_PATH, SimpleBuildingDetector)

    # Cleanup mock file if it was created
    if os.path.exists(OUTPUT_GEOJSON_PATH):
        # Read a snippet to confirm structure
        with open(OUTPUT_GEOJSON_PATH, 'r') as f:
            snippet = json.load(f)
            print("\n--- GeoJSON Snippet (First Feature) ---")
            if snippet['features']:
                print(json.dumps(snippet['features'][0], indent=2)[:300] + "...")
            else:
                print("Output file created but contains no features.")
        os.remove(OUTPUT_GEOJSON_PATH)
        print("\n[Cleanup] Mock output file removed.")

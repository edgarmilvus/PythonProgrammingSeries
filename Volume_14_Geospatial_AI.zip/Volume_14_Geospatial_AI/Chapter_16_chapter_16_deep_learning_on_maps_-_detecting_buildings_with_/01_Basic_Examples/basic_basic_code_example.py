
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np
import matplotlib.pyplot as plt

# --- 1. Define Data Simulation Parameters ---
IMAGE_SIZE = 128  # Standard patch size (128x128 pixels)
NUM_CHANNELS = 3  # Standard RGB bands

# --- 2. Simulate Satellite Imagery (Input Feature) ---
# Set a seed for reproducibility
np.random.seed(42) 

# Create the input image array: (Height, Width, Channels) format (HWC)
# This format is standard for visualization libraries like Matplotlib.
satellite_image = np.random.randint(
    low=0, 
    high=256, 
    size=(IMAGE_SIZE, IMAGE_SIZE, NUM_CHANNELS), 
    dtype=np.uint8
)

# Enhancement: Simulate a distinct feature (e.g., a bright road or area)
center = IMAGE_SIZE // 2
# Set a 20x20 area in the center to maximum intensity (255) across all bands
satellite_image[center-10:center+10, center-10:center+10, :] = 255 


# --- 3. Simulate Ground Truth Mask (Target Label) ---
# The mask is a binary image: 0 (background) or 1 (building).
# It uses (Height, Width) format (HW), as it only needs one channel.
ground_truth_mask = np.zeros((IMAGE_SIZE, IMAGE_SIZE), dtype=np.uint8)

# Simulate a building footprint using array slicing
# Define the coordinates for the structure
start_x, start_y = 30, 80
end_x, end_y = 60, 110
# Set all pixels within this rectangular area to 1 (the 'building' class)
ground_truth_mask[start_x:end_x, start_y:end_y] = 1 


# --- 4. Visualization and Verification ---
# Set up a figure with two subplots side-by-side
fig, axes = plt.subplots(1, 2, figsize=(10, 5))
fig.suptitle("Simulated Geospatial Segmentation Data Pair (HWC Format)")

# Display the Satellite Image (Input)
axes[0].imshow(satellite_image)
axes[0].set_title("Input Image (RGB)")
axes[0].axis('off')

# Display the Ground Truth Mask (Target)
# We use the 'binary' colormap to clearly distinguish 0 (black) and 1 (white)
axes[1].imshow(ground_truth_mask, cmap='binary') 
axes[1].set_title("Target Mask (Building Footprint)")
axes[1].axis('off')

plt.tight_layout(rect=[0, 0.03, 1, 0.95])
plt.show()

# --- 5. Data Structure Check (Crucial step before PyTorch conversion) ---
print("\n--- Data Structure Check ---")
print(f"Satellite Image Shape (H, W, C): {satellite_image.shape}")
print(f"Mask Shape (H, W): {ground_truth_mask.shape}")
print(f"Image Data Type: {satellite_image.dtype}")
print(f"Mask Data Type: {ground_truth_mask.dtype}")

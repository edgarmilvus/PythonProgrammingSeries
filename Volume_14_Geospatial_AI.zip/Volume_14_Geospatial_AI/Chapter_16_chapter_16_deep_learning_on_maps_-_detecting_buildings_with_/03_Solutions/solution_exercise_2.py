
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import torch
import torch.nn as nn
import torch.nn.functional as F

class SEBlock(nn.Module):
    """
    Squeeze-and-Excitation Block for channel attention.
    """
    def __init__(self, channel, reduction=16):
        super(SEBlock, self).__init__()
        
        # 1. Global Average Pooling (Squeeze)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        
        # 2. Fully Connected Layers (Excitation)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False),
            # 3. Sigmoid Activation
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        
        # Squeeze: C x H x W -> C x 1 x 1
        y = self.avg_pool(x).view(b, c)
        
        # Excitation: Learn channel weights
        y = self.fc(y).view(b, c, 1, 1)
        
        # Scale: Multiply input by learned weights
        return x * y.expand_as(x)

# --- Placeholder U-Net Components for context ---
class DoubleConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.double_conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )
    def forward(self, x): return self.double_conv(x)

class ModifiedUNet(nn.Module):
    def __init__(self, n_channels=3, n_classes=1):
        super().__init__()
        # ... Encoder setup ...
        self.bottleneck_conv = DoubleConv(256, 512) 
        
        # 2. U-Net Integration: SE Block applied to the bottleneck output
        self.se_block = SEBlock(channel=512, reduction=16)
        
        # Placeholder layers for structural integrity
        self.inc = DoubleConv(n_channels, 64)
        self.outc = nn.Conv2d(64, n_classes, kernel_size=1)

    def forward(self, x):
        # Simulate Encoder path
        x1 = self.inc(x)
        bottleneck_input = F.max_pool2d(x1, 8) # Simulate deep pooling
        
        # Bottleneck operation
        bottleneck_output = self.bottleneck_conv(bottleneck_input)
        
        # Integration Point: Apply SE block
        bottleneck_output = self.se_block(bottleneck_output)
        
        # ... Decoder path would use bottleneck_output ...
        
        # Final output simulation (ignoring decoder complexity)
        return self.outc(F.interpolate(bottleneck_output, size=x.shape[2:], mode='bilinear'))

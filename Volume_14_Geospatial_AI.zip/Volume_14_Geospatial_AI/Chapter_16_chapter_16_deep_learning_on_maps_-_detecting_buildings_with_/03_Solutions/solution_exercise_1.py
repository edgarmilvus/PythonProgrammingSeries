
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import torch
from torch.utils.data import Dataset
import rasterio
import numpy as np
import math
import random
from rasterio.windows import Window

# Example of required global statistics (Placeholder values)
MEAN_STATS = [0.298, 0.315, 0.289]
STD_STATS = [0.101, 0.098, 0.105]

# --- Mock Implementation for file handling without actual GeoTIFFs ---
class MockRaster:
    # Simulates rasterio source opening for metadata and windowed reading
    def __init__(self, width, height, count):
        self.width = width
        self.height = height
        self.count = count
    def read(self, indexes=None, window=None):
        w = window.width if window else self.width
        h = window.height if window else self.height
        c = self.count if indexes is None else len(indexes)
        data = np.random.rand(c, h, w).astype(np.float32)
        return (data > 0.9).astype(np.uint8) if c == 1 else data
    def __enter__(self): return self
    def __exit__(self, exc_type, exc_val, exc_tb): pass

def mock_rasterio_open(path):
    if 'image' in path: return MockRaster(width=10000, height=10000, count=3)
    if 'mask' in path: return MockRaster(width=10000, height=10000, count=1)

class BuildingSegmentationDataset(Dataset):
    """
    A custom PyTorch Dataset that loads tiles dynamically from large GeoTIFF files
    using rasterio windowed reading, minimizing memory footprint.
    """
    def __init__(self, image_path, mask_path, tile_size=256):
        self.image_path = image_path
        self.mask_path = mask_path
        self.tile_size = tile_size

        # 1. Load metadata (using mock for demonstration)
        with mock_rasterio_open(image_path) as src:
            self.width = src.width
            self.height = src.height
        
        # 2. Calculate the total number of tiles
        self.n_cols = math.ceil(self.width / self.tile_size)
        self.n_rows = math.ceil(self.height / self.tile_size)
        self.total_tiles = self.n_rows * self.n_cols

    def __len__(self):
        # Return the total number of tiles.
        return self.total_tiles

    def __getitem__(self, index):
        # Determine spatial coordinates for the index
        row_idx = index // self.n_cols
        col_idx = index % self.n_cols
        x_start = col_idx * self.tile_size
        y_start = row_idx * self.tile_size
        
        # Calculate actual tile size (handling edge cases)
        w = min(self.tile_size, self.width - x_start)
        h = min(self.tile_size, self.height - y_start)
        window = Window(x_start, y_start, w, h)

        # 2. Use rasterio.open().read(window=...) for efficient loading.
        with mock_rasterio_open(self.image_path) as img_src, \
             mock_rasterio_open(self.mask_path) as mask_src:
            image_tile = img_src.read(window=window).astype(np.float32)
            mask_tile = mask_src.read(window=window).astype(np.float32)
        
        # Pad tiles if smaller than tile_size (edge handling)
        if w < self.tile_size or h < self.tile_size:
            pad_h, pad_w = self.tile_size - h, self.tile_size - w
            image_tile = np.pad(image_tile, ((0, 0), (0, pad_h), (0, pad_w)), mode='reflect')
            mask_tile = np.pad(mask_tile, ((0, 0), (0, pad_h), (0, pad_w)), mode='constant', constant_values=0)

        # 3. Apply normalization
        for i in range(image_tile.shape[0]):
            image_tile[i] = (image_tile[i] - MEAN_STATS[i]) / STD_STATS[i]

        # 3. Apply synchronized augmentation (Rotation)
        k = random.choice([0, 1, 2, 3])
        image_tile = np.rot90(image_tile, k=k, axes=(1, 2)).copy()
        mask_tile = np.rot90(mask_tile, k=k, axes=(1, 2)).copy()

        # Convert to PyTorch tensors
        image_tensor = torch.from_numpy(image_tile).float()
        mask_tensor = torch.from_numpy(mask_tile).float()
        
        # 4. Output Format: (C, H, W), (1, H, W)
        return image_tensor, (mask_tensor > 0.5).float()

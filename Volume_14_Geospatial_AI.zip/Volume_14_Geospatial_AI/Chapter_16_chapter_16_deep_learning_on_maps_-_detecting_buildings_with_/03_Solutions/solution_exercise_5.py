
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from sqlalchemy import create_engine, Column, Integer, Float, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import geopandas as gpd
import io # Used for mock session

# 1. Define the Base
Base = declarative_base()

class Building(Base):
    """SQLAlchemy Model mapping to a building detection table."""
    __tablename__ = 'detected_buildings'
    
    id = Column(Integer, primary_key=True)
    area_sqm = Column(Float, nullable=False)
    centroid_x = Column(Float)
    centroid_y = Column(Float)
    wkt_geometry = Column(String, nullable=False) # Store geometry as WKT string
    
    def __repr__(self):
        return f"<Building(id={self.id}, area={self.area_sqm:.2f} sqm)>"

# --- Mock Session Setup ---
# In a real environment, this would connect to PostgreSQL/PostGIS
engine = create_engine('sqlite:///:memory:') 
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)
mock_session = Session()

def store_buildings_in_db(geodataframe: gpd.GeoDataFrame, session):
    """
    Tool function for a GeoAI Agent: Persists vectorized building data 
    to the SQL database.
    """
    
    new_buildings = []
    
    # 1. Iterate through the GeoDataFrame rows.
    for index, row in geodataframe.iterrows():
        
        # 2. Create Building objects, converting Shapely geometry to WKT.
        wkt_geom = row.geometry.wkt
        
        building_record = Building(
            area_sqm=row['area_sqm'],
            centroid_x=row['centroid_x'],
            centroid_y=row['centroid_y'],
            wkt_geometry=wkt_geom
        )
        new_buildings.append(building_record)
    
    if new_buildings:
        # 3. Add objects to the session and commit.
        session.add_all(new_buildings)
        session.commit()
        print(f"Successfully stored {len(new_buildings)} building records.")
    else:
        print("No records to store.")

# Example usage (requires output from Ex 4)
# store_buildings_in_db(gdf_output, mock_session) 


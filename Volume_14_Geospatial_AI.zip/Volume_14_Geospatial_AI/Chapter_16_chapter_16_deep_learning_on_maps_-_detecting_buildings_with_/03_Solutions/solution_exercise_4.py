
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import geopandas as gpd
from shapely.geometry import shape, Point
import rasterio
from rasterio.features import shapes
import numpy as np
from rasterio.transform import Affine

# --- Mock Data Setup ---
H, W = 100, 100
mock_mask_data = np.zeros((H, W), dtype=np.uint8)
mock_mask_data[20:30, 20:40] = 1 
mock_transform = Affine(1.0, 0.0, 400000.0, 0.0, -1.0, 4500000.0)
mock_crs = 'EPSG:32617' 

class MockRasterFile:
    # Simulates rasterio source properties
    def __init__(self, data, transform, crs):
        self.data = data
        self.transform = transform
        self.crs = crs
    def __enter__(self): return self
    def __exit__(self, exc_type, exc_val, exc_tb): pass
    def read(self, indexes=None): return self.data
    @property
    def profile(self): return {'crs': self.crs, 'transform': self.transform}

def mock_rasterio_open_file(path):
    return MockRasterFile(mock_mask_data, mock_transform, mock_crs)

# --- Solution Function ---
def raster_to_vector(binary_mask_path: str, output_gpkg_path: str):
    """
    Converts a georeferenced binary raster mask into a GeoDataFrame 
    with calculated building attributes.
    """
    
    with mock_rasterio_open_file(binary_mask_path) as src:
        image = src.read(1)
        transform = src.transform
        crs = src.crs
        
        # 1. Use rasterio.features.shapes to generate geometry/value pairs.
        features = []
        
        for geom, val in shapes(image, transform=transform):
            if val == 1:  # Only process building pixels
                polygon = shape(geom)
                
                # 2. Calculate Area (in square meters)
                area_sqm = polygon.area
                
                # Calculate Centroid Coordinates
                centroid = polygon.centroid
                centroid_x = centroid.x
                centroid_y = centroid.y
                
                # 3. Append dictionary of attributes and geometry to 'features'.
                features.append({
                    'geometry': polygon,
                    'area_sqm': area_sqm,
                    'centroid_x': centroid_x,
                    'centroid_y': centroid_y,
                })
        
        # 4. Create the GeoDataFrame.
        if not features:
            return gpd.GeoDataFrame()
            
        gdf = gpd.GeoDataFrame(features, crs=crs)
        return gdf

# Example execution (simulated)
gdf_output = raster_to_vector("mock_mask.tif", "buildings.gpkg")

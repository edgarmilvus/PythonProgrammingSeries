
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np
from sklearn.metrics import precision_score, recall_score, f1_score

def calculate_metrics(prediction: np.ndarray, target: np.ndarray, threshold: float) -> tuple:
    """Calculates P, R, F1 based on a specific threshold."""
    
    # 1. Convert prediction (probability map) to binary mask using the threshold.
    binary_prediction = (prediction >= threshold).astype(int)
    
    # 2. Flatten arrays for metric calculation.
    y_true = target.flatten()
    y_pred = binary_prediction.flatten()
    
    # Calculate metrics (using zero_division=0 to handle edge cases gracefully)
    precision = precision_score(y_true, y_pred, zero_division=0)
    recall = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    
    return precision, recall, f1

def find_optimal_threshold(predictions_list: list, targets_list: list) -> dict:
    """Iterates thresholds to find the maximum F1 score."""
    
    # Combine all predictions and targets into single flattened arrays
    all_predictions = np.concatenate([p.flatten() for p in predictions_list])
    all_targets = np.concatenate([t.flatten() for t in targets_list])
    
    thresholds = np.arange(0.1, 0.95, 0.05)
    best_f1 = -1.0
    optimal_t = 0.5
    
    results = {
        'thresholds': [],
        'precision': [],
        'recall': [],
        'f1': []
    }
    
    # Loop through thresholds, calculate aggregate metrics, and update best_f1.
    for t in thresholds:
        P, R, F1 = calculate_metrics(all_predictions, all_targets, t)
        
        results['thresholds'].append(t)
        results['precision'].append(P)
        results['recall'].append(R)
        results['f1'].append(F1)
        
        if F1 > best_f1:
            best_f1 = F1
            optimal_t = t
            
    return {
        'optimal_threshold': optimal_t,
        'max_f1': best_f1,
        'metrics_history': results
    }

# --- Simulation Example ---
# Simulate data where optimal performance is around 0.65
N = 5
predictions = [np.random.rand(100, 100) * 0.8 + 0.2 for _ in range(N)]
targets = [np.random.randint(0, 2, size=(100, 100)) for _ in range(N)]
optimization_result = find_optimal_threshold(predictions, targets)

print(f"Optimal Threshold: {optimization_result['optimal_threshold']:.2f}")
print(f"Max F1 Score: {optimization_result['max_f1']:.3f}")

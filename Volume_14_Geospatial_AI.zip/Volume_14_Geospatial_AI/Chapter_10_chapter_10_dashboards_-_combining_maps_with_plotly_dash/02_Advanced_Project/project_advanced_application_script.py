
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import plotly.express as px
import pandas as pd
import json
import numpy as np

# --- 1. Data Simulation (Representing GeoAI Model Output) ---
# In a real application, this would be loaded from a PostGIS database or S3 bucket.

# A. Simulate Statistical Data (Area coverage over time)
data = {
    'Region': np.random.choice(['District Alpha', 'District Beta', 'District Gamma'], 100),
    'Feature_Type': np.random.choice(['Water Bodies', 'Urban Sprawl', 'Deforestation', 'Infrastructure Damage'], 100),
    'Area_sq_km': np.random.randint(5, 300, 100) / 10,
    'Date': pd.to_datetime(pd.date_range(start='2023-01-01', periods=100, freq='W'))
}
df = pd.DataFrame(data)

# B. Simulate Geospatial Data (Simplified GeoJSON for map boundaries/features)
# We create a simple GeoJSON structure where each feature corresponds to a unique (Region, Feature_Type) combination.
# Note: Coordinates are simplified for demonstration purposes.
GEOJSON_DATA = {
    "type": "FeatureCollection",
    "features": []
}
coords = [
    [[-74.0, 40.7], [-74.1, 40.7], [-74.1, 40.8], [-74.0, 40.8], [-74.0, 40.7]], # Alpha
    [[-73.5, 40.0], [-73.6, 40.0], [-73.6, 40.1], [-73.5, 40.1], [-73.5, 40.0]], # Beta
    [[-75.0, 41.0], [-75.1, 41.0], [-75.1, 41.1], [-75.0, 41.1], [-75.0, 41.0]]  # Gamma
]

for i, region in enumerate(df['Region'].unique()):
    for feature_type in df['Feature_Type'].unique():
        # Create a unique ID linked to the combination
        feature_id = f"{region}_{feature_type}"
        GEOJSON_DATA["features"].append({
            "type": "Feature",
            "properties": {"id": feature_id, "region": region, "feature_type": feature_type},
            "geometry": {"type": "Polygon", "coordinates": [coords[i % len(coords)]]}
        })

# --- 2. Dash Application Setup and Layout ---
app = dash.Dash(__name__, title="GeoAI Monitoring Dashboard")
server = app.server

# Get unique options for controls
region_options = [{'label': r, 'value': r} for r in df['Region'].unique()]
feature_options = [{'label': f, 'value': f} for f in df['Feature_Type'].unique()]

app.layout = html.Div(className='container', children=[
    html.H1("GeoAI Segmentation Results Monitor", style={'textAlign': 'center'}),

    # Control Panel Row
    html.Div(className='row', style={'display': 'flex', 'padding': '10px'}, children=[
        # Region Selector (Dropdown)
        html.Div(style={'width': '48%', 'paddingRight': '2%'}, children=[
            html.Label("Select Administrative Region:"),
            dcc.Dropdown(
                id='region-selector',
                options=region_options,
                value=df['Region'].iloc[0],  # Default value
                clearable=False
            )
        ]),
        # Feature Type Selector (Radio Items)
        html.Div(style={'width': '48%', 'paddingLeft': '2%'}, children=[
            html.Label("Select Segmented Feature Type:"),
            dcc.RadioItems(
                id='feature-selector',
                options=feature_options,
                value=df['Feature_Type'].iloc[0], # Default value
                inline=True,
                style={'marginTop': '5px'}
            )
        ])
    ]),

    # Visualization Row
    html.Div(className='row', style={'display': 'flex', 'marginTop': '20px'}, children=[
        # Map Visualization (Left)
        html.Div(style={'width': '60%', 'paddingRight': '10px'}, children=[
            dcc.Graph(id='geoai-map')
        ]),
        # Time Series Chart (Right)
        html.Div(style={'width': '40%', 'paddingLeft': '10px'}, children=[
            dcc.Graph(id='area-chart')
        ])
    ])
])

# --- 3. Complex Callback Definition ---
@app.callback(
    [Output('geoai-map', 'figure'),
     Output('area-chart', 'figure')],
    [Input('region-selector', 'value'),
     Input('feature-selector', 'value')]
)
def update_dashboard(selected_region, selected_feature):
    # 1. Filter the statistical DataFrame based on user inputs
    filtered_df = df[
        (df['Region'] == selected_region) &
        (df['Feature_Type'] == selected_feature)
    ].sort_values(by='Date')

    # 2. Prepare data for Map Visualization (Choropleth Mapbox)
    # We create a temporary DataFrame linking the filtered data back to the GeoJSON IDs
    map_data = pd.DataFrame({
        'id': [f"{selected_region}_{selected_feature}"],
        'Area_sq_km': [filtered_df['Area_sq_km'].sum()] # Sum area for visualization
    })
    
    # Calculate map center for initial view
    if GEOJSON_DATA['features']:
        # Simple centroid approximation (using the first feature's coordinates)
        coords_list = GEOJSON_DATA['features'][0]['geometry']['coordinates'][0]
        lon_center = sum(c[0] for c in coords_list) / len(coords_list)
        lat_center = sum(c[1] for c in coords_list) / len(coords_list)
    else:
        lon_center, lat_center = -74.0, 40.7 # Fallback to NYC area

    # Create the Choropleth Mapbox figure
    map_fig = px.choropleth_mapbox(
        map_data,
        geojson=GEOJSON_DATA,
        locations='id', # Column in map_data matching feature ID in GeoJSON
        color='Area_sq_km',
        featureidkey="properties.id", # Key in GeoJSON to match 'locations'
        mapbox_style="carto-positron",
        zoom=9,
        center={"lat": lat_center, "lon": lon_center},
        opacity=0.7,
        title=f"Segmented Area in {selected_region}"
    )
    map_fig.update_layout(margin={"r":0,"t":40,"l":0,"b":0})


    # 3. Prepare data for Time Series Chart
    chart_fig = px.line(
        filtered_df,
        x='Date',
        y='Area_sq_km',
        title=f"Area Trend: {selected_feature}",
        markers=True
    )
    chart_fig.update_layout(xaxis_title="Date of Satellite Pass", yaxis_title="Area (sq km)")


    # 4. Return both figures to their respective components
    return map_fig, chart_fig


if __name__ == '__main__':
    app.run_server(debug=True)

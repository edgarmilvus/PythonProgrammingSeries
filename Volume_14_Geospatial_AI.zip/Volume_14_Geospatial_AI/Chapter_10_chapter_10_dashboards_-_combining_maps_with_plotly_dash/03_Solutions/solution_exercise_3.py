
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import numpy as np
import json

# --- 1. Data Simulation (GeoJSON Integration) ---
N_SAMPLES = 200
np.random.seed(43)

def create_geojson_polygon(lat, lon, size=0.001):
    """Simulates a small square polygon around a point."""
    coords = [
        [lon - size, lat - size],
        [lon + size, lat - size],
        [lon + size, lat + size],
        [lon - size, lat + size],
        [lon - size, lat - size]
    ]
    geojson = {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [coords]},
        "properties": {}
    }
    return json.dumps(geojson)

data_ex3 = pd.DataFrame({
    'latitude': np.random.uniform(34.0, 34.5, N_SAMPLES),
    'longitude': np.random.uniform(-118.5, -118.0, N_SAMPLES),
    'object_type': np.random.choice(['building', 'road', 'water'], N_SAMPLES),
    'model_run_id': np.random.choice(['v1.2_2024'], N_SAMPLES),
    'segmentation_geojson': [
        create_geojson_polygon(lat, lon) 
        if i % 3 != 0 else None  # Only 2/3 of data have segmentation
        for i, (lat, lon) in enumerate(zip(np.random.uniform(34.0, 34.5, N_SAMPLES), np.random.uniform(-118.5, -118.0, N_SAMPLES)))
    ]
})

app = dash.Dash(__name__)
px.set_mapbox_access_token("pk.eyJ1IjoicGxvdGx5bWFwYm94IiwiYSI6ImNqdnBvNDMyaTAxdc3dzY2d3MndwZGc3Y2x4ZmoifQ.oUfJ-rCqWztnEVQLhWkFqQ")

# Color mapping for GeoJSON polygons
COLOR_MAP = {'building': 'rgba(255, 0, 0, 0.5)', 'road': 'rgba(0, 255, 0, 0.5)', 'water': 'rgba(0, 0, 255, 0.5)'}

# --- 2. New Input Component and Layout ---
app.layout = html.Div([
    html.H1("GeoAI Segmentation Visualization Toggle"),
    
    html.Div([
        html.Label("Visualization Mode:"),
        dcc.Checklist(
            id='visualization-mode-toggle',
            options=[
                {'label': ' Show Points', 'value': 'points'},
                {'label': ' Show Polygons', 'value': 'polygons'}
            ],
            value=['points'], # Default to points
            inline=True
        )
    ], style={'padding': '10px'}),
    
    dcc.Graph(id='geoai-map-output', style={'height': '70vh'})
])

# --- 3. Conditional Rendering Callback ---
@app.callback(
    Output('geoai-map-output', 'figure'),
    [Input('visualization-mode-toggle', 'value')]
)
def update_map_mode(mode_list):
    
    if not mode_list or 'points' in mode_list:
        # --- Mode 1: Scatter Mapbox (Points) ---
        fig = px.scatter_mapbox(
            data_ex3,
            lat="latitude",
            lon="longitude",
            color="object_type",
            zoom=10,
            height=600,
            title="Point Detections (Bounding Box Centers)",
            mapbox_style="satellite-streets"
        )
        fig.update_layout(margin={"r":0,"t":0,"l":0,"b":0})
        return fig
        
    elif 'polygons' in mode_list:
        # --- Mode 2: Mapbox Layers (Polygons) ---
        polygon_df = data_ex3[data_ex3['segmentation_geojson'].notna()]
        
        if polygon_df.empty:
            return go.Figure().update_layout(title="No segmentation data available.")

        # Aggregate GeoJSON features by object type
        layers = []
        for obj_type, color_rgba in COLOR_MAP.items():
            type_data = polygon_df[polygon_df['object_type'] == obj_type]
            
            # Create a FeatureCollection for the current object type
            features = [json.loads(g) for g in type_data['segmentation_geojson']]
            feature_collection = {"type": "FeatureCollection", "features": features}
            
            if features:
                layers.append(dict(
                    sourcetype='geojson',
                    source=feature_collection,
                    type='fill',
                    color=color_rgba,
                    opacity=0.7,
                    name=obj_type
                ))

        # Determine center point for initial map view
        center_lat = polygon_df['latitude'].mean()
        center_lon = polygon_df['longitude'].mean()

        fig = go.Figure(
            layout=go.Layout(
                mapbox=dict(
                    style="satellite-streets",
                    center=dict(lat=center_lat, lon=center_lon),
                    zoom=10,
                    layers=layers
                ),
                height=600,
                margin={"r":0,"t":40,"l":0,"b":0},
                title="Segmentation Mask Visualization (Polygons)"
            )
        )
        return fig
        
    # Default fallback
    return go.Figure()

# if __name__ == '__main__':
#     app.run_server(debug=True)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import pandas as pd
import plotly.express as px
import numpy as np

# --- 1. Data Simulation ---
N_SAMPLES = 500
np.random.seed(42)
data = pd.DataFrame({
    'latitude': np.random.uniform(34.0, 34.5, N_SAMPLES),
    'longitude': np.random.uniform(-118.5, -118.0, N_SAMPLES),
    'classification_label': np.random.choice(['Forest', 'Water', 'Urban'], N_SAMPLES),
    'confidence_score': np.random.rand(N_SAMPLES),
    'model_run_id': np.random.choice(['v1.0_2023', 'v1.1_2024', 'v1.2_2024'], N_SAMPLES)
})

# --- 2. Application Initialization ---
app = dash.Dash(__name__)

# NOTE: Replace 'YOUR_MAPBOX_TOKEN' with a valid token for production use
px.set_mapbox_access_token("pk.eyJ1IjoicGxvdGx5bWFwYm94IiwiYSI6ImNqdnBvNDMyaTAxdc3dzY2d3MndwZGc3Y2x4ZmoifQ.oUfJ-rCqWztnEVQLhWkFqQ")

unique_model_ids = data['model_run_id'].unique()

# --- 3. Layout Definition ---
app.layout = html.Div([
    html.H1("GeoAI Model Comparison Dashboard"),
    
    html.Div([
        html.Label("Select Model Run ID:"),
        dcc.Dropdown(
            id='model-run-selector',
            options=[{'label': i, 'value': i} for i in unique_model_ids],
            value=unique_model_ids[0],  # Default value
            clearable=False
        )
    ], style={'width': '50%', 'padding': '10px'}),
    
    dcc.Graph(id='geoai-map-output', style={'height': '70vh'})
])

# --- 4. Callback Implementation ---
@app.callback(
    Output('geoai-map-output', 'figure'),
    [Input('model-run-selector', 'value')]
)
def update_map(selected_model_id):
    """Filters data based on model ID and generates a scatter_mapbox figure."""
    if selected_model_id is None:
        # Handle case where no model is selected (shouldn't happen with default value)
        return px.scatter_mapbox(data.head(1)) 

    filtered_df = data[data['model_run_id'] == selected_model_id]
    
    fig = px.scatter_mapbox(
        filtered_df,
        lat="latitude",
        lon="longitude",
        color="classification_label",
        zoom=10,
        height=600,
        mapbox_style="satellite-streets"
    )
    fig.update_layout(margin={"r":0,"t":0,"l":0,"b":0})
    return fig

# if __name__ == '__main__':
#     app.run_server(debug=True)

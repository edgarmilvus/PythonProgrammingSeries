
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import dash
from dash import dcc, html
from dash.dependencies import Input, Output, State
import pandas as pd
import plotly.express as px
import numpy as np
import json
import base64
import io

# --- 1. Data Simulation (Large Scale) ---
N_SAMPLES_LARGE = 100000 # Simulate a large dataset for performance testing
np.random.seed(44)
large_data = pd.DataFrame({
    'latitude': np.random.uniform(34.0, 34.5, N_SAMPLES_LARGE),
    'longitude': np.random.uniform(-118.5, -118.0, N_SAMPLES_LARGE),
    'classification_label': np.random.choice(['A', 'B', 'C', 'D'], N_SAMPLES_LARGE),
    'confidence_score': np.random.uniform(0.0, 1.0, N_SAMPLES_LARGE),
    'model_run_id': np.random.choice(['v_prod', 'v_test'], N_SAMPLES_LARGE)
})

# Function to serialize DataFrame (using JSON for simplicity, though feather/parquet is often better)
def serialize_df(df):
    return df.to_json(date_format='iso', orient='split')

# Function to deserialize DataFrame
def deserialize_df(json_data):
    return pd.read_json(json_data, orient='split')

# Initial serialization of the raw data (happens once at startup)
INITIAL_RAW_DATA = serialize_df(large_data)

# --- 2. Application Initialization and Layout ---
app = dash.Dash(__name__)
px.set_mapbox_access_token("pk.eyJ1IjoicGxvdGx5bWFwYm94IiwiYSI6ImNqdnBvNDMyaTAxdc3dzY2d3MndwZGc3Y2x4ZmoifQ.oUfJ-rCqWztnEVQLhWkFqQ")

unique_model_ids = large_data['model_run_id'].unique()

app.layout = html.Div([
    html.H1("Performance Optimized Dashboard (100K Detections)"),

    # Hidden storage for raw data (loaded only once)
    dcc.Store(id='raw-data-store', data=INITIAL_RAW_DATA),
    # Hidden storage for filtered data (updated by Stage 1)
    dcc.Store(id='filtered-data-store'),
    
    html.Div([
        html.Div([
            html.Label("Model Run ID:"),
            dcc.Dropdown(
                id='model-run-selector',
                options=[{'label': i, 'value': i} for i in unique_model_ids],
                value=unique_model_ids[0],
                clearable=False
            )
        ], style={'width': '30%', 'display': 'inline-block', 'padding': '10px'}),

        html.Div([
            html.Label("Confidence Score Range:"),
            dcc.RangeSlider(
                id='confidence-slider',
                min=0.0, max=1.0, step=0.05,
                value=[0.8, 1.0],
                marks={i/10: f'{i/10:.1f}' for i in range(0, 11, 2)}
            )
        ], style={'width': '60%', 'display': 'inline-block', 'padding': '10px'}),
    ]),
    
    html.Div([
        dcc.Graph(id='geoai-map-output', style={'width': '60%', 'display': 'inline-block', 'height': '60vh'}),
        dcc.Graph(id='confidence-histogram', style={'width': '40%', 'display': 'inline-block', 'height': '60vh'})
    ])
])

# --- Stage 1 Callback: Filtering Logic (Heavy Lifting) ---
@app.callback(
    Output('filtered-data-store', 'data'),
    [Input('model-run-selector', 'value'),
     Input('confidence-slider', 'value')],
    [State('raw-data-store', 'data')]
)
def filter_data_and_store(selected_model_id, confidence_range, raw_json_data):
    """Filters the raw data based on user inputs and stores the result."""
    
    # 1. Deserialize the full dataset (State)
    df_raw = deserialize_df(raw_json_data)
    
    # 2. Perform heavy filtering
    min_conf, max_conf = confidence_range
    
    df_filtered = df_raw[
        (df_raw['model_run_id'] == selected_model_id) &
        (df_raw['confidence_score'] >= min_conf) &
        (df_raw['confidence_score'] <= max_conf)
    ]
    
    # 3. Serialize and return the filtered subset (Output)
    return serialize_df(df_filtered)

# --- Stage 2 Callback: Visualization Rendering (Light Lifting) ---
@app.callback(
    [Output('geoai-map-output', 'figure'),
     Output('confidence-histogram', 'figure')],
    [Input('filtered-data-store', 'data')]
)
def render_visualizations(filtered_json_data):
    """Reads the pre-filtered data and generates figures quickly."""
    
    if filtered_json_data is None:
        return px.scatter_mapbox(title="Loading..."), px.histogram(title="Loading...")

    # 1. Deserialize the filtered dataset (Input)
    df_filtered = deserialize_df(filtered_json_data)
    
    if df_filtered.empty:
        empty_map = px.scatter_mapbox(title="No data matching filter criteria.")
        empty_hist = px.histogram(title="No data matching filter criteria.")
        return empty_map, empty_hist

    # 2. Generate Map
    map_fig = px.scatter_mapbox(
        df_filtered,
        lat="latitude",
        lon="longitude",
        color="classification_label",
        zoom=10,
        height=600,
        mapbox_style="satellite-streets"
    )
    map_fig.update_layout(margin={"r":0,"t":0,"l":0,"b":0})

    # 3. Generate Histogram (using the already filtered data)
    hist_fig = px.histogram(
        df_filtered,
        x="confidence_score",
        title="Confidence Distribution (Filtered Subset)",
        nbins=20
    )
    hist_fig.update_layout(margin={"t":40, "b":20, "l":20, "r":20})
    
    return map_fig, hist_fig

# if __name__ == '__main__':
#     app.run_server(debug=True)

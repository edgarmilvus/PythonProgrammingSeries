
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import pandas as pd
import plotly.express as px
import numpy as np
from datetime import date, timedelta

# --- 1. Data Simulation (Expanded) ---
N_SAMPLES = 1000
np.random.seed(42)
start_date = date(2024, 1, 1)
date_list = [start_date + timedelta(days=i) for i in range(30)]

data_ex2 = pd.DataFrame({
    'latitude': np.random.uniform(34.0, 34.5, N_SAMPLES),
    'longitude': np.random.uniform(-118.5, -118.0, N_SAMPLES),
    'classification_label': np.random.choice(['Forest', 'Water', 'Urban', 'Road'], N_SAMPLES),
    'confidence_score': np.random.uniform(0.0, 1.0, N_SAMPLES),
    'model_run_id': np.random.choice(['v1.0_2023', 'v1.1_2024', 'v1.2_2024'], N_SAMPLES),
    'acquisition_date': np.random.choice(date_list, N_SAMPLES)
})
data_ex2['acquisition_date'] = pd.to_datetime(data_ex2['acquisition_date'])

app = dash.Dash(__name__)
px.set_mapbox_access_token("pk.eyJ1IjoicGxvdGx5bWFwYm94IiwiYSI6ImNqdnBvNDMyaTAxdc3dzY2d3MndwZGc3Y2x4ZmoifQ.oUfJ-rCqWztnEVQLhWkFqQ")

unique_model_ids = data_ex2['model_run_id'].unique()
min_date = data_ex2['acquisition_date'].min()
max_date = data_ex2['acquisition_date'].max()

# --- 2. Component Expansion and Layout ---
app.layout = html.Div([
    html.H1("GeoAI Cross-Filtering Dashboard"),
    
    html.Div([
        # Model Selector (from Ex 1)
        html.Div([
            html.Label("Model Run ID:"),
            dcc.Dropdown(
                id='model-run-selector',
                options=[{'label': i, 'value': i} for i in unique_model_ids],
                value=unique_model_ids[0],
                clearable=False
            )
        ], style={'width': '33%', 'display': 'inline-block', 'padding': '10px'}),

        # Confidence Slider
        html.Div([
            html.Label("Confidence Score Range:"),
            dcc.RangeSlider(
                id='confidence-slider',
                min=0.0, max=1.0, step=0.05,
                value=[0.7, 1.0],
                marks={i/10: f'{i/10:.1f}' for i in range(0, 11, 2)}
            )
        ], style={'width': '33%', 'display': 'inline-block', 'padding': '10px'}),

        # Date Picker
        html.Div([
            html.Label("Acquisition Date Range:"),
            dcc.DatePickerRange(
                id='date-range-picker',
                start_date=min_date,
                end_date=max_date,
                min_date_allowed=min_date,
                max_date_allowed=max_date,
                initial_visible_month=min_date
            )
        ], style={'width': '33%', 'display': 'inline-block', 'padding': '10px'}),
    ]),
    
    html.Div([
        dcc.Graph(id='geoai-map-output', style={'width': '60%', 'display': 'inline-block', 'height': '60vh'}),
        dcc.Graph(id='confidence-histogram', style={'width': '40%', 'display': 'inline-block', 'height': '60vh'})
    ])
])

# --- 3. Complex Callback Implementation ---
@app.callback(
    [Output('geoai-map-output', 'figure'),
     Output('confidence-histogram', 'figure')],
    [Input('model-run-selector', 'value'),
     Input('confidence-slider', 'value'),
     Input('date-range-picker', 'start_date'),
     Input('date-range-picker', 'end_date')]
)
def update_outputs(selected_model_id, confidence_range, start_date_str, end_date_str):
    # Convert date strings to datetime objects
    start_date = pd.to_datetime(start_date_str)
    end_date = pd.to_datetime(end_date_str)

    # --- Filtering for Statistical Context (Histogram Data) ---
    # Filter 1: Model ID and Date Range
    histogram_df = data_ex2[
        (data_ex2['model_run_id'] == selected_model_id) &
        (data_ex2['acquisition_date'] >= start_date) &
        (data_ex2['acquisition_date'] <= end_date)
    ].copy()
    
    # Generate Histogram
    hist_fig = px.histogram(
        histogram_df,
        x="confidence_score",
        title=f"Confidence Distribution for {selected_model_id}",
        nbins=20
    )
    hist_fig.update_layout(margin={"t":40, "b":20, "l":20, "r":20})
    
    # --- Filtering for Geospatial Map (Highly Filtered Data) ---
    min_conf, max_conf = confidence_range
    
    # Filter 2: Apply all criteria including Confidence Range
    map_df = histogram_df[
        (histogram_df['confidence_score'] >= min_conf) &
        (histogram_df['confidence_score'] <= max_conf)
    ]
    
    # Generate Map
    if map_df.empty:
        map_fig = px.scatter_mapbox(title="No data matching all criteria.")
    else:
        map_fig = px.scatter_mapbox(
            map_df,
            lat="latitude",
            lon="longitude",
            color="classification_label",
            zoom=10,
            height=600,
            mapbox_style="satellite-streets"
        )
    map_fig.update_layout(margin={"r":0,"t":0,"l":0,"b":0})
    
    return map_fig, hist_fig

# if __name__ == '__main__':
#     app.run_server(debug=True)

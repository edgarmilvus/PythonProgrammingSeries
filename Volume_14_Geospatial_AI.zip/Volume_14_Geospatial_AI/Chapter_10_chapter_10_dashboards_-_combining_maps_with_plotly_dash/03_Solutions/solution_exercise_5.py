
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import dash
from dash import dcc, html
from dash.dependencies import Input, Output, State
import dash_bootstrap_components as dbc
import pandas as pd
import plotly.express as px
import numpy as np
import json
from datetime import datetime

# --- Data Simulation Functions ---
N_SAMPLES = 500 # Keep sample size smaller for live updates simulation
def query_latest_geoai_results():
    """Simulates querying a database for new data."""
    np.random.seed(int(datetime.now().timestamp())) # Ensure new data is generated
    df = pd.DataFrame({
        'latitude': np.random.uniform(34.0, 34.5, N_SAMPLES),
        'longitude': np.random.uniform(-118.5, -118.0, N_SAMPLES),
        'classification_label': np.random.choice(['A', 'B', 'C', 'D'], N_SAMPLES),
        'confidence_score': np.random.uniform(0.0, 1.0, N_SAMPLES),
        'model_run_id': np.random.choice(['v_prod', 'v_test'], N_SAMPLES),
        'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    })
    return df

def serialize_df(df):
    return df.to_json(date_format='iso', orient='split')

def deserialize_df(json_data):
    return pd.read_json(json_data, orient='split')

# --- Initialization ---
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
px.set_mapbox_access_token("pk.eyJ1IjoicGxvdGx5bWFwYm94IiwiYSI6ImNqdnBvNDMyaTAxdc3dzY2d3MndwZGc3Y2x4ZmoifQ.oUfJ-rCqWztnEVQLhWkFqQ")

# Initial data load for startup
initial_df = query_latest_geoai_results()
unique_model_ids = initial_df['model_run_id'].unique()

# --- 2. Layout Refactoring with DBC ---
controls = dbc.Card(
    [
        html.H4("Control Panel", className="card-title"),
        html.P(f"Last updated: {initial_df['timestamp'].iloc[0]}", id='last-updated-time'),
        html.Div([
            html.Label("Model Run ID:"),
            dcc.Dropdown(
                id='model-run-selector',
                options=[{'label': i, 'value': i} for i in unique_model_ids],
                value=unique_model_ids[0],
                clearable=False
            )
        ], className="mb-3"),
        html.Div([
            html.Label("Confidence Score Range:"),
            dcc.RangeSlider(
                id='confidence-slider',
                min=0.0, max=1.0, step=0.05,
                value=[0.8, 1.0],
                marks={i/10: f'{i/10:.1f}' for i in range(0, 11, 2)}
            )
        ])
    ],
    body=True,
    className="h-100"
)

app.layout = dbc.Container([
    dcc.Store(id='live-raw-data-store', data=serialize_df(initial_df)),
    dcc.Store(id='filtered-data-store'),
    dcc.Interval(
        id='data-refresh-interval',
        interval=60 * 1000,  # 60 seconds
        n_intervals=0
    ),
    
    html.H1("Dynamic GeoAI Dashboard (DBC & Live Data)", className="my-4"),

    # Row 1: Map and Controls
    dbc.Row([
        # Control Panel: xs=12 (full width on mobile), lg=3 (25% on desktop)
        dbc.Col(controls, xs=12, lg=3, className="mb-3"), 
        
        # Primary Map: xs=12 (full width on mobile), lg=9 (75% on desktop)
        dbc.Col(dcc.Graph(id='geoai-map-output', style={'height': '70vh'}), xs=12, lg=9, className="mb-3"),
    ]),
    
    # Row 2: Secondary Chart (Always full width)
    dbc.Row([
        # Secondary Chart: xs=12 (100% width)
        dbc.Col(dcc.Graph(id='confidence-histogram', style={'height': '40vh'}), xs=12, className="mb-3"),
    ])
], fluid=True)


# --- 1. Dynamic Data Refresh Callback ---
@app.callback(
    [Output('live-raw-data-store', 'data'),
     Output('last-updated-time', 'children')],
    [Input('data-refresh-interval', 'n_intervals')]
)
def refresh_data(n):
    """Triggers database query simulation and updates the raw data store."""
    new_df = query_latest_geoai_results()
    new_data_json = serialize_df(new_df)
    timestamp = new_df['timestamp'].iloc[0]
    return new_data_json, f"Last updated: {timestamp} (Interval {n})"


# --- 2. Stage 1 Callback: Filtering Logic (Uses live-raw-data-store) ---
@app.callback(
    Output('filtered-data-store', 'data'),
    [Input('model-run-selector', 'value'),
     Input('confidence-slider', 'value'),
     Input('live-raw-data-store', 'data')] # Now an Input, triggering filter upon refresh
)
def filter_data_and_store(selected_model_id, confidence_range, raw_json_data):
    """Filters the raw data based on user inputs AND live data changes."""
    
    if raw_json_data is None:
        return None
        
    df_raw = deserialize_df(raw_json_data)
    
    min_conf, max_conf = confidence_range
    
    df_filtered = df_raw[
        (df_raw['model_run_id'] == selected_model_id) &
        (df_raw['confidence_score'] >= min_conf) &
        (df_raw['confidence_score'] <= max_conf)
    ]
    
    return serialize_df(df_filtered)

# --- 3. Stage 2 Callback: Visualization Rendering (Unchanged) ---
@app.callback(
    [Output('geoai-map-output', 'figure'),
     Output('confidence-histogram', 'figure')],
    [Input('filtered-data-store', 'data')]
)
def render_visualizations(filtered_json_data):
    """Reads the pre-filtered data and generates figures quickly."""
    
    if filtered_json_data is None:
        return px.scatter_mapbox(title="Waiting for data..."), px.histogram(title="Waiting for data...")

    df_filtered = deserialize_df(filtered_json_data)
    
    # ... (Map and Histogram generation logic from Ex 4) ...
    map_fig = px.scatter_mapbox(
        df_filtered, lat="latitude", lon="longitude", color="classification_label", zoom=10, height=600, mapbox_style="satellite-streets"
    )
    map_fig.update_layout(margin={"r":0,"t":0,"l":0,"b":0})

    hist_fig = px.histogram(
        df_filtered, x="confidence_score", title="Confidence Distribution (Filtered Subset)", nbins=20
    )
    hist_fig.update_layout(margin={"t":40, "b":20, "l":20, "r":20})
    
    return map_fig, hist_fig

# if __name__ == '__main__':
#     app.run_server(debug=True)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import pandas as pd
import plotly.express as px
import dash
from dash import dcc, html, Input, Output

# --- 1. DATA PREPARATION ---

# Simulate geospatial results (e.g., detection centers or analysis zones)
data = {
    'city': ['Zone A', 'Zone B', 'Zone C'],
    'lat': [34.05, 34.10, 34.15],
    'lon': [-118.25, -118.30, -118.35],
    'value': [100, 250, 50]  # Hypothetical GeoAI metric (e.g., detected object count)
}
df = pd.DataFrame(data)

# --- 2. APPLICATION INITIALIZATION ---

# Initialize the Dash application instance
app = dash.Dash(__name__)

# --- 3. INITIAL VISUALIZATION SETUP ---

# Create the base Plotly figure using a geospatial mapbox style
initial_fig = px.scatter_mapbox(
    df,
    lat="lat",
    lon="lon",
    hover_name="city",
    color="value",
    size="value",      # Size markers by the calculated value
    zoom=10,           # Set initial zoom level
    height=400,
    mapbox_style="carto-positron" # Use a standard, clean map background
)

# Optimize map layout for cleaner embedding
initial_fig.update_layout(margin={"r":0,"t":0,"l":0,"b":0})


# --- 4. APPLICATION LAYOUT DEFINITION ---

# Define the structure of the dashboard using HTML and Dash Core Components (dcc)
app.layout = html.Div([
    # Header component
    html.H1("Minimal GeoAI Zone Dashboard", style={'textAlign': 'center', 'color': '#333'}),

    # Input Component: Dropdown selector
    dcc.Dropdown(
        id='zone-selector',
        options=[{'label': i, 'value': i} for i in df['city']],
        value='Zone A',  # Set a default selected value
        clearable=False,
        style={'width': '60%', 'margin': '20px auto', 'display': 'block'}
    ),

    # Output Component 1: The interactive map visualization
    dcc.Graph(
        id='geo-map-output',
        figure=initial_fig # Display the pre-generated map initially
    ),

    # Output Component 2: Text area to display details based on selection
    html.Div(
        id='selection-details',
        style={'padding': '20px', 'fontSize': '18px', 'borderTop': '2px solid #eee'}
    )
])


# --- 5. THE CALLBACK FUNCTION (INTERACTIVE LOGIC) ---

# The decorator defines the link: Input('zone-selector', 'value') -> Output('selection-details', 'children')
@app.callback(
    Output('selection-details', 'children'), # The property of the target component to be updated
    Input('zone-selector', 'value')         # The property of the source component that triggers the update
)
def update_details(selected_zone):
    """
    This function executes every time the 'value' property of the 'zone-selector' changes.
    It filters the data and returns a new string to update the 'children' property of the output Div.
    """
    # Filter the DataFrame to find the selected zone's data
    filtered_df = df[df['city'] == selected_zone].iloc[0]

    # Construct the dynamic output string
    output_text = (
        f"**Analysis Summary for {selected_zone}**\n\n"
        f"Coordinates: ({filtered_df['lat']:.2f}, {filtered_df['lon']:.2f})\n"
        f"Calculated GeoAI Metric Value: {filtered_df['value']}"
    )

    # Note: Dash automatically handles the conversion of this string into HTML text within the Div
    return html.Pre(output_text) # Use html.Pre to preserve line breaks and formatting

# --- 6. RUNNING THE SERVER ---

if __name__ == '__main__':
    # The server runs locally and listens for web requests
    app.run_server(debug=True)

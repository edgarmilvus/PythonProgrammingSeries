
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import pandas as pd

# 1. Schema Extraction Function
def get_gdf_schema_string(gdf: gpd.GeoDataFrame) -> str:
    """
    Returns a formatted string of columns and types for the LLM.
    """
    schema_info = []
    for col, dtype in gdf.dtypes.items():
        # Clean up numpy types for easier LLM reading (e.g., int64 -> int)
        dtype_str = str(dtype).replace("64", "")
        schema_info.append(f"- {col} ({dtype_str})")
    
    return "\n".join(schema_info)

# 2. Dynamic Prompt Setup
from langchain.prompts import ChatPromptTemplate, SystemMessagePromptTemplate

# Assume we load a new dataset
new_gdf = gpd.read_file(gpd.datasets.get_path('nybb')) # New York Boroughs
schema_str = get_gdf_schema_string(new_gdf)

# Create the prompt template with a placeholder
system_template = """
You are a GIS Agent. You have access to a GeoDataFrame named 'gdf'.
Here is the schema of the data available to you:
{gdf_schema}

Only use the columns listed above.
"""

prompt = ChatPromptTemplate.from_messages([
    ("system", system_template),
    ("user", "{input}")
])

# Inject the schema string *before* the agent starts
final_prompt = prompt.partial(gdf_schema=schema_str)

# Now, if the user asks for "Borough Name", the LLM sees 'BoroName' in the schema
# and maps the concept correctly.

#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from langchain.agents import initialize_agent, AgentType
from langchain.chat_models import ChatOpenAI

# 1. Define the Non-Geospatial Tool
@tool
def external_data_fetcher(query: str) -> str:
    """
    Fetches real-time data or scalar values for a given location.
    Useful for retrieving pollution indexes, weather, or economic stats.
    
    Args:
        query (str): The location or metric to search for (e.g., "Air Quality Tokyo").
    """
    # Mock return for the exercise
    return f"The current value for {query} is 42.5 units."

# 2. Agent Orchestration
# Assume 'geo_pandas_executor' is defined as in Exercise 1/4

tools = [external_data_fetcher, geo_pandas_executor]

# Initialization (Conceptual)
# agent = initialize_agent(
#     tools, 
#     llm=ChatOpenAI(temperature=0), 
#     agent=AgentType.OPENAI_FUNCTIONS, 
#     verbose=True
# )

# 3. The Complex Query
# response = agent.run("Find the air quality for Tokyo, then map the 'geometry' of the global dataset and put that air quality value in the map title.")
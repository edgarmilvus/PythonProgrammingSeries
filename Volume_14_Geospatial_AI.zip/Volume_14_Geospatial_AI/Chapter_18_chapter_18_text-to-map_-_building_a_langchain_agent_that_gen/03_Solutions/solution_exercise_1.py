
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================
import geopandas as gpd
import matplotlib.pyplot as plt
from langchain.tools import tool
import traceback

# Setup: Load a sample dataset globally for this exercise
gdf = gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))

@tool
def geo_pandas_executor(code_snippet: str) -> str:
    """
    Executes a string of Python code to perform geospatial analysis or visualization.
    
    CRITICAL CONSTRAINTS FOR THE LLM:
    1. VARIABLE NAME: You MUST assume a GeoDataFrame named 'gdf' already exists. Do NOT reload data.
    2. SYNTAX: The code must be valid Python using the 'geopandas' and 'matplotlib.pyplot' libraries.
    3. VISUALIZATION: The code MUST end with a plotting command (e.g., `gdf.plot()` or `plt.show()`).
    4. IMPORTS: Do not import geopandas as gpd; it is pre-loaded.
    
    Args:
        code_snippet (str): Valid Python code to execute.
    
    Returns:
        str: "Visualization Created Successfully" if successful, or an error traceback if failed.
    """
    try:
        # We create a local scope but inject the global 'gdf' into it
        local_scope = {'gdf': gdf, 'plt': plt}
        
        # 'exec' runs the string as code
        exec(code_snippet, globals(), local_scope)
        
        return "Visualization Created Successfully."
    except Exception as e:
        # Return the error so the Agent knows what went wrong
        return f"Execution Failed: {traceback.format_exc()}"
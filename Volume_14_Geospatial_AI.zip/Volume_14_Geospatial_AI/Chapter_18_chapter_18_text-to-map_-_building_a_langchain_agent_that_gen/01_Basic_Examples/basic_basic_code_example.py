
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import geopandas as gpd
from shapely.geometry import Point, Polygon
from langchain.tools import StructuredTool
from pydantic import BaseModel, Field
import json
import os

# Suppress warnings related to GeoPandas/Shapely dependencies for clean output
os.environ['CPL_LOG_ERRORS'] = 'NO' 

# --- 1. Define the Pydantic Schema for LLM Input Validation ---
# This schema defines the exact arguments the function expects, ensuring the LLM 
# provides correctly typed and described inputs.
class CentroidInputSchema(BaseModel):
    """Schema for the input required by calculate_geometry_centroid."""
    wkt_polygon: str = Field(
        description="The Well-Known Text (WKT) string representing the polygon geometry. Example: 'POLYGON ((0 0, 0 1, 1 1, 1 0, 0 0))'."
    )

# --- 2. Define the Geospatial Core Function ---
def calculate_geometry_centroid(wkt_polygon: str) -> str:
    """
    Calculates the centroid (center point) of a polygon defined in WKT format 
    using GeoPandas and returns the result as a standardized JSON string.
    """
    try:
        # Step 2a: Convert the single WKT string into a GeoSeries for processing.
        # GeoPandas is optimized for vectorized operations on GeoSeries/GeoDataFrames.
        g_series = gpd.GeoSeries.from_wkt([wkt_polygon])
        
        # Step 2b: Calculate the centroid. .iloc[0] extracts the single resulting Point geometry.
        centroid_geom = g_series.centroid.iloc[0]
        
        # Step 2c: Structure the output into a serializable JSON format.
        # Agents require string outputs, making JSON the ideal choice for structured results.
        result = {
            "input_wkt": wkt_polygon,
            "centroid_x": centroid_geom.x,
            "centroid_y": centroid_geom.y,
            "wkt_output": centroid_geom.wkt
        }
        return json.dumps(result, indent=2)
        
    except Exception as e:
        # Provide a clear, structured error message back to the agent/LLM
        return json.dumps({"error": f"Failed to calculate centroid. Input WKT may be invalid: {e}"})

# --- 3. Create the Structured LangChain Tool ---
# StructuredTool marries the Python function with its Pydantic schema.
centroid_tool = StructuredTool.from_function(
    func=calculate_geometry_centroid,
    name="calculate_geometry_centroid",
    description=(
        "A critical tool for geospatial analysis. Use this to find the precise central point "
        "of any valid polygon geometry defined by a WKT string. Returns coordinates in JSON."
    ),
    args_schema=CentroidInputSchema,
)

# --- 4. Demonstration of Tool Usage (Simulating Agent Execution) ---
# Define a test geometry (e.g., a small area near a major city)
test_wkt = "POLYGON ((-74.01 40.71, -74.02 40.71, -74.02 40.72, -74.01 40.72, -74.01 40.71))"

print("--- Text-to-Map Tool Definition Complete ---")
print(f"Tool Name: {centroid_tool.name}")
print(f"Tool Description Length: {len(centroid_tool.description)} characters (Crucial for LLM context)")
print(f"Required Schema Fields: {list(CentroidInputSchema.model_fields.keys())}")

print("\n--- Simulating Agent Call (LLM provides input dictionary) ---")

# The agent framework automatically validates the input against CentroidInputSchema 
# before calling the underlying Python function.
try:
    # We manually call the tool's run method, passing the required argument defined by the schema.
    result_json_string = centroid_tool.run(wkt_polygon=test_wkt)
    
    print(f"\nInput WKT: {test_wkt}")
    print("\nTool Output (JSON Result):")
    print(result_json_string)

    # Verification of the structured output
    result_data = json.loads(result_json_string)
    print("\n--- Verification ---")
    print(f"Centroid X (Longitude): {result_data['centroid_x']:.6f}")
    print(f"Centroid Y (Latitude): {result_data['centroid_y']:.6f}")

except Exception as e:
    print(f"Tool execution failed during simulation: {e}")

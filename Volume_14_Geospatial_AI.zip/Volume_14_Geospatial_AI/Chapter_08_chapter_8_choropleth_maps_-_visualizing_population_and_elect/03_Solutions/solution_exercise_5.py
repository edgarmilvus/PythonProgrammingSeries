
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import geopandas as gpd
import numpy as np
import matplotlib.pyplot as plt
import mapclassify
from shapely.geometry import box

# 1. Data Normalization (Simulated State Data)
N_states = 50
state_data = {
    'State': [f'State_{i}' for i in range(N_states)],
    'Total Registered Voters': np.random.randint(1000000, 10000000, N_states),
    'VEP': np.random.randint(1500000, 15000000, N_states),
}
state_gdf = gpd.GeoDataFrame(
    state_data,
    geometry=[box(i % 10, i // 5, (i % 10) + 0.9, (i // 5) + 0.9) for i in range(N_states)],
    crs="EPSG:4326"
)

# Calculate the Registration Rate (as a percentage)
state_gdf['RegistrationRate'] = (state_gdf['Total Registered Voters'] / state_gdf['VEP']) * 100

# Cap the rate at 100% just in case of data anomalies
state_gdf['RegistrationRate'] = state_gdf['RegistrationRate'].clip(upper=100)

# 2. Function Definition (`generate_jenks_map`)
def generate_jenks_map(gdf, column_name, k_classes):
    """
    Standardized function to create a Jenks-classified choropleth map.
    Maps the specified column using Natural Breaks classification.
    """
    # TODO: In a production environment leveraging SQLAlchemy, 
    # the initial GeoDataFrame loading would be replaced by a query 
    # fetching the required geospatial data from a PostGIS enabled database.

    # Requirement 3: Jenks Classification Justification Comment
    # Jenks is used here because it identifies natural clusters of high/low performance rates 
    # (e.g., states with exceptionally high or low registration performance) 
    # by minimizing variance within the resulting groups, making the breaks statistically meaningful.

    fig, ax = plt.subplots(1, 1, figsize=(12, 8))
    
    # Classification and plotting logic
    gdf.plot(
        column=column_name,
        ax=ax,
        legend=True,
        scheme='NaturalBreaks',
        k=k_classes,
        cmap='plasma',
        edgecolor='white',
        linewidth=0.5,
        legend_kwds={'loc': 'lower left', 'fmt': "{:.1f}", 'title': f"{column_name} (%)"}
    )
    
    ax.set_title(f"State Analysis: {column_name} (Jenks k={k_classes})", fontsize=16)
    ax.set_axis_off()
    
    # plt.show()
    plt.close(fig)
    print(f"Map generated for column: {column_name} with k={k_classes} classes.")

# 3. Function Execution and Documentation
generate_jenks_map(state_gdf, 'RegistrationRate', 5)

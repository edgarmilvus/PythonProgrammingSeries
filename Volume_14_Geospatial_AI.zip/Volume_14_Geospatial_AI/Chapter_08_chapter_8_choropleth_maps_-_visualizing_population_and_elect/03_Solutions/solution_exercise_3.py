
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import geopandas as gpd
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from shapely.geometry import Polygon, box

# 1. Data Loading and Preparation (Simulated Florida Data)
N_fl = 15
fl_data = {
    'County': [f'FL_C{i}' for i in range(N_fl)],
    'Population': np.random.randint(50000, 1200000, N_fl),
    'MedianIncome': np.random.randint(35000, 75000, N_fl),
    'IsCoastal': [True, False] * (N_fl // 2) + [True] * (N_fl % 2) # Mix of coastal/non-coastal
}
# Force a few to meet the criteria
fl_data['Population'][0] = 600000 # High Pop, Coastal
fl_data['MedianIncome'][2] = 40000 # Low Income, Coastal
fl_data['IsCoastal'][2] = True 

florida_gdf = gpd.GeoDataFrame(
    fl_data,
    geometry=[box(i, 0, i+1, 1) for i in range(N_fl)],
    crs="EPSG:4326"
)

# Define thresholds
POP_THRESHOLD = 500000
INCOME_THRESHOLD = 45000

# 2. Complex Filtering Implementation using Logical Operators
# Logical Structure: (A OR B) AND C
condition_high_pop = florida_gdf['Population'] > POP_THRESHOLD
condition_low_income = florida_gdf['MedianIncome'] < INCOME_THRESHOLD
condition_coastal = florida_gdf['IsCoastal'] == True

# Combine conditions using | (OR) and & (AND)
condition_1 = condition_high_pop | condition_low_income
final_mask = condition_1 & condition_coastal

# Create the subset GeoDataFrame
vulnerable_coastal_counties = florida_gdf[final_mask]

# 3. Visualization of the Subset
fig, ax = plt.subplots(1, 1, figsize=(10, 8))

# Plot the full state boundaries first (for context)
florida_gdf.plot(
    ax=ax,
    color='lightgrey',
    edgecolor='white',
    linewidth=0.5
)

# Overlay the filtered subset, mapping MedianIncome
if not vulnerable_coastal_counties.empty:
    vulnerable_coastal_counties.plot(
        column='MedianIncome',
        ax=ax,
        legend=True,
        scheme='quantiles',
        k=5,
        cmap='plasma_r', # plasma_r for low income = dark color
        edgecolor='black',
        linewidth=1.0,
        legend_kwds={'title': "Median Income (Quantiles)"}
    )
    ax.set_title(f"Vulnerable Coastal Counties (n={len(vulnerable_coastal_counties)})")
else:
    ax.set_title("No counties met the complex filtering criteria.")

ax.set_axis_off()
# plt.show()
plt.close(fig)

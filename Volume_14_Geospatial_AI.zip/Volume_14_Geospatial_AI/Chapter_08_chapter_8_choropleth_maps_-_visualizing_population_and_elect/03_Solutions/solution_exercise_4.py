
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import geopandas as gpd
import pandas as pd
import numpy as np
import folium
from folium.features import GeoJsonTooltip
import mapclassify
from shapely.geometry import box

# 1. Preparation for Interaction (Simulated Data)
N_tracts = 30
tract_data = {
    'Tract ID': [f'T{i:04d}' for i in range(N_tracts)],
    'Pop2020': np.random.randint(1000, 5000, N_tracts),
    # Simulate population change between -20% and +30%
    'PopChange_Percent': np.random.uniform(-20.0, 30.0, N_tracts),
}

# Create dummy geometries (must be in WGS 84 / EPSG:4326 for Folium)
tract_gdf = gpd.GeoDataFrame(
    tract_data,
    geometry=[box(i % 6, i // 6, (i % 6) + 0.9, (i // 6) + 0.9) for i in range(N_tracts)],
    crs="EPSG:4326"
)

# Apply Jenks Natural Breaks classification
k_classes = 6
classifier = mapclassify.NaturalBreaks(tract_gdf['PopChange_Percent'], k=k_classes)
tract_gdf['Jenks_Class'] = tract_gdf['PopChange_Percent'].apply(lambda x: classifier.yb[classifier.bins.searchsorted(x)])

# Convert GeoDataFrame to GeoJSON string for Folium
# Ensure necessary columns are strings/floats for tooltip display
tract_gdf['Pop2020'] = tract_gdf['Pop2020'].round(0).astype(int)
tract_gdf['PopChange_Percent'] = tract_gdf['PopChange_Percent'].round(2)
geojson_data = tract_gdf.to_json()

# 2. Folium Integration and Conversion
# Calculate centroid for map centering
center_x = tract_gdf.geometry.centroid.x.mean()
center_y = tract_gdf.geometry.centroid.y.mean()

m = folium.Map(location=[center_y, center_x], zoom_start=8)

# Define style function based on Jenks classification
cmap = plt.cm.get_cmap('RdYlGn', k_classes)
def style_function(feature):
    class_index = feature['properties']['Jenks_Class']
    color = matplotlib.colors.rgb2hex(cmap(class_index))
    return {
        'fillColor': color,
        'color': 'black',
        'weight': 0.5,
        'fillOpacity': 0.7
    }

# 3. Interactive Tooltip Implementation
folium.GeoJson(
    geojson_data,
    name='Population Change (Jenks Classified)',
    style_function=style_function,
    tooltip=GeoJsonTooltip(
        fields=['Tract ID', 'Pop2020', 'PopChange_Percent'],
        aliases=['Tract ID:', '2020 Population:', 'Pop Change (2010-2020 %):'],
        localize=True,
        sticky=False
    )
).add_to(m)

# 4. Layer Control and Basemaps
folium.TileLayer('OpenStreetMap', name='OpenStreetMap').add_to(m)
folium.TileLayer('cartodbdarkmatter', name='CartoDB Dark Matter').add_to(m)
folium.LayerControl().add_to(m)

# To view the map, uncomment the line below (will save as HTML)
# m.save("interactive_pop_change_map.html")
# print("Interactive map saved to interactive_pop_change_map.html")

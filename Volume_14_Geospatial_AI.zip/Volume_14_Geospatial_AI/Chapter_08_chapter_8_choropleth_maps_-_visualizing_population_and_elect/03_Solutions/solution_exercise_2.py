
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import geopandas as gpd
import numpy as np
import matplotlib.pyplot as plt
import mapclassify
from shapely.geometry import box

# 1. Data Calculation and Transformation (Simulated Data)
# Create dummy GeoDataFrame for districts
N = 20
districts_data = {
    'District_ID': range(N),
    'Votes_A': np.random.randint(5000, 15000, N),
    'Votes_B': np.random.randint(5000, 15000, N)
}
# Simulate some natural clustering (e.g., 5 strong D, 5 strong R, 10 competitive)
districts_data['Votes_A'][:5] += 5000
districts_data['Votes_B'][5:10] += 5000

district_gdf = gpd.GeoDataFrame(
    districts_data,
    geometry=[box(i, 0, i+1, 1) for i in range(N)],
    crs="EPSG:4326"
)

# Calculate Total Votes, handling zero division
district_gdf['Total_Votes'] = district_gdf['Votes_A'] + district_gdf['Votes_B']
# Use np.where to prevent division by zero
district_gdf['Margin'] = np.where(
    district_gdf['Total_Votes'] > 0,
    (district_gdf['Votes_A'] - district_gdf['Votes_B']) / district_gdf['Total_Votes'],

# 2. & 3. Jenks Classification and Diverging Color Ramp Implementation
fig, ax = plt.subplots(1, 1, figsize=(12, 6))

# Use RdBu_r: Red (Republican/Negative Margin) to Blue (Democrat/Positive Margin)
district_gdf.plot(
    column='Margin',
    ax=ax,
    legend=True,
    scheme='NaturalBreaks', # Jenks Natural Breaks
    k=9, # Odd number k=9 to ensure a central neutral class
    cmap='RdBu_r', 
    edgecolor='white',
    linewidth=0.5,
    legend_kwds={'loc': 'lower left', 'fmt': "{:.2f}", 'title': "Normalized Margin (A - B)"}
)

# Ensure the color ramp visually centers around zero (critical for diverging maps)
# We manually set the normalization range if needed, but GeoPandas/mapclassify often handles this for diverging schemes.
vmin = district_gdf['Margin'].min()
vmax = district_gdf['Margin'].max()
abs_max = max(abs(vmin), abs(vmax))
# Re-plot with explicit normalization for perfect centering (optional but best practice)
district_gdf.plot(
    column='Margin',
    ax=ax,
    legend=True,
    scheme='NaturalBreaks',
    k=9,
    cmap='RdBu_r', 
    edgecolor='white',
    linewidth=0.5,
    vmin=-abs_max, # Set symmetric color range
    vmax=abs_max,
    legend_kwds={'loc': 'lower left', 'fmt': "{:.2f}", 'title': "Normalized Margin (A - B)"}
)


# 4. Visualization and Interpretation
ax.set_title("Election Margin: Jenks Natural Breaks (k=9)", fontsize=16)
ax.set_axis_off()

# plt.show()
plt.close(fig)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import pandas as pd
import geopandas as gpd
from shapely.geometry import Polygon
import matplotlib.pyplot as plt

# --- 1. Define Synthetic Geospatial Data (The Boundaries) ---
# We use shapely to manually define simple geometric shapes (polygons)
# that represent our three abstract geographic regions.
regions_data = {
    'RegionID': ['A01', 'B02', 'C03'],
    'RegionName': ['North Sector', 'Central Zone', 'South District'],
    'geometry': [
        Polygon([(0, 0), (0, 10), (10, 10), (10, 0)]),      # Region A01: Square
        Polygon([(15, 5), (15, 15), (25, 15), (25, 5)]),    # Region B02: Square
        Polygon([(30, 0), (30, 20), (40, 20), (40, 0)])     # Region C03: Rectangle
    ]
}
# Convert the dictionary into a GeoDataFrame (GDF).
# CRS (Coordinate Reference System) is set to a common standard (WGS 84).
geo_df = gpd.GeoDataFrame(regions_data, crs="EPSG:4326")

# --- 2. Define Synthetic Statistical Data (The Metrics) ---
# This data contains the quantitative metric we want to visualize.
# The 'RegionID' column is the essential link for merging.
stat_data = {
    'RegionID': ['A01', 'B02', 'C03'],
    'PopulationDensity': [150, 450, 250], # The main variable for coloring
    'VoterTurnout': [0.65, 0.78, 0.71]    # An additional variable
}
stat_df = pd.DataFrame(stat_data)

# --- 3. Merge Geospatial and Statistical Data ---
# The core operation: combining the boundaries (geo_df) with the metrics (stat_df).
# We merge based on the common key 'RegionID'.
merged_df = geo_df.merge(stat_df, on='RegionID', how='left')

# --- 4. Generate the Choropleth Map ---
# Prepare the Matplotlib figure and axis object for plotting.
fig, ax = plt.subplots(1, 1, figsize=(10, 10))

# The .plot() method of the GeoDataFrame handles the visualization.
# The 'column' parameter is the key instruction for choropleth generation.
merged_df.plot(
    column='PopulationDensity', # Use this column to determine color intensity
    ax=ax,                      # Plot onto the defined axis
    legend=True,                # Display the color bar legend
    cmap='plasma',              # Select the color scheme (Color Map)
    linewidth=1.5,              # Thickness of the border lines
    edgecolor='black'           # Color of the border lines
)

# --- 5. Final Visualization Enhancements ---
ax.set_title('Basic Synthetic Choropleth Map: Population Density', fontsize=16)
ax.set_axis_off() # Crucial for map visualization: removes unnecessary coordinate ticks
plt.show()

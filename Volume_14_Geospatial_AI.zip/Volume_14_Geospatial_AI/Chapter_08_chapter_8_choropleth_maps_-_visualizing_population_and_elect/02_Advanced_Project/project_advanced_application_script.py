
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import geopandas as gpd
import pandas as pd
import matplotlib.pyplot as plt
import mapclassify as mc
import numpy as np
import os

# Set Matplotlib style for professional output consistency
plt.style.use('seaborn-v0_8-whitegrid')

# --- 1. Load Geospatial Boundaries (Administrative Units) ---
try:
    # Load a representative administrative boundary dataset (e.g., US States/Canadian Provinces)
    # Using built-in GeoPandas data for reliability, filtered to North America for focus
    world = gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))
    
    # Filter down to a relevant geographic region and select necessary columns
    geo_data = world[world['continent'] == 'North America'].copy()
    geo_data = geo_data[['name', 'pop_est', 'geometry']]
    geo_data.rename(columns={'name': 'County_ID', 'pop_est': 'Base_Population'}, inplace=True)
    
    print(f"Loaded {len(geo_data)} administrative units for mapping.")
except Exception as e:
    # Robust handling for data loading failures is essential in GeoAI pipelines
    print(f"CRITICAL ERROR: Failed to load GeoPandas built-in data. Check installation. {e}")
    exit()

# --- 2. Generate Synthetic Statistical Data (Simulated Election Results) ---
# Create a DataFrame where the 'County_ID' matches the geospatial data
statistical_data = pd.DataFrame({
    'County_ID': geo_data['County_ID'].unique(),
    # Simulate Registered Voters as a percentage of the base population
    'Registered_Voters': (geo_data['Base_Population'] * np.random.uniform(0.5, 0.7)).astype(int),
    # Simulate Actual Turnout (must be less than or equal to registered voters)
    'Actual_Turnout': (geo_data['Base_Population'] * np.random.uniform(0.2, 0.5)).astype(int),
    # Simulate votes for a single candidate (Candidate A)
    'Candidate_A_Votes': (geo_data['Base_Population'] * np.random.uniform(0.1, 0.3)).astype(int),
})

# Ensure data integrity: Turnout cannot exceed registration
statistical_data['Actual_Turnout'] = np.minimum(
    statistical_data['Actual_Turnout'], statistical_data['Registered_Voters']
)

# --- 3. Data Merging and Feature Engineering ---

# 3.1. Perform the standard Pandas merge (left join) using the common attribute key
merged_gdf = geo_data.merge(statistical_data, on='County_ID', how='left')

# 3.2. Calculate the primary visualization metric: Voter Turnout Rate (TR)
# TR = (Actual Votes / Registered Voters) * 100
merged_gdf['Turnout_Rate'] = (merged_gdf['Actual_Turnout'] / merged_gdf['Registered_Voters']) * 100

# 3.3. Calculate the secondary metric: Candidate A's Percentage of Total Votes
merged_gdf['Candidate_A_Pct'] = (merged_gdf['Candidate_A_Votes'] / merged_gdf['Actual_Turnout']) * 100

# Clean up any potential NaNs or infinite values resulting from division by zero (e.g., zero registered voters)
merged_gdf = merged_gdf.replace([np.inf, -np.inf], np.nan).dropna(subset=['Turnout_Rate', 'Candidate_A_Pct'])

# --- 4. Advanced Classification and Choropleth Generation ---

# Define the variable for the primary map
map_variable = 'Turnout_Rate'

# 4.1. Use Jenks Natural Breaks classification for optimal visual grouping
# Jenks algorithm finds the most natural groupings in the data distribution.
classifier = mc.NaturalBreaks(merged_gdf[map_variable], k=5)

# 4.2. Initialize the dual plot figure
fig, axes = plt.subplots(1, 2, figsize=(18, 9))

# Map 1: Voter Turnout Rate (Jenks Classification)
merged_gdf.plot(
    column=map_variable, 
    ax=axes[0], 
    legend=True,
    scheme=classifier, # Apply the pre-calculated Jenks classifier object
    cmap='viridis_r', # Use a sequential, reversed color scheme
    edgecolor='black',
    linewidth=0.5,
    missing_kwds={'color': 'lightgrey', 'label': 'No Data/Filtered'}
)
axes[0].set_title(f'Map A: Voter Turnout Rate (Jenks Natural Breaks, K={classifier.k})', fontsize=14)
axes[0].set_axis_off()

# Map 2: Candidate A Voting Percentage (Quantiles Classification)
# This map demonstrates a different classification scheme for comparison
merged_gdf.plot(
    column='Candidate_A_Pct', 
    ax=axes[1], 
    legend=True,
    scheme='Quantiles', # Use standard Quantiles classification (equal number of observations per class)
    cmap='RdBu', # Diverging Red-Blue scheme for political data
    edgecolor='black',
    linewidth=0.5,
    missing_kwds={'color': 'lightgrey', 'label': 'No Data/Filtered'}
)
axes[1].set_title('Map B: Candidate A Percentage of Votes (Quantiles)', fontsize=14)
axes[1].set_axis_off()

# Finalizing the visualization
plt.suptitle("Comparative Geo-Analysis of Simulated Election Data Across Administrative Regions", fontsize=16, y=1.02)
plt.tight_layout()
plt.show()

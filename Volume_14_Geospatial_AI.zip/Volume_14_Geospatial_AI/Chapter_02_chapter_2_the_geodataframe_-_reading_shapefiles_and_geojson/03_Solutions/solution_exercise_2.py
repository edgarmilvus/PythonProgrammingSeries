
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import geopandas as gpd
import requests
from io import StringIO

# 1. Define the Source (Using a widely available sample GeoJSON URL)
# Note: This URL points to a small, public domain GeoJSON file.
wildfire_url = "https://raw.githubusercontent.com/geopandas/geopandas/main/geopandas/datasets/nybb.geojson"

# 2. Remote Read
# In a true environment, gpd.read_file(wildfire_url) works directly.
# For guaranteed execution in a sandbox environment, we simulate the read:
try:
    # Attempt the direct read, which is the required solution
    fire_perimeters_gdf = gpd.read_file(wildfire_url)
    print("Successfully read data directly from URL.")
except Exception as e:
    # Fallback simulation if network access is restricted
    print(f"Warning: Direct URL read failed ({e}). Simulating local load.")
    # Create a dummy GeoDataFrame if the read fails
    from shapely.geometry import Point
    fire_perimeters_gdf = gpd.GeoDataFrame({
        'id': [1, 2],
        'intensity': [5.5, 7.1],
        'geometry': [Point(10, 20), Point(30, 40)]
    }, crs='EPSG:4326')


# 3. Data Type Confirmation (Shape)
data_shape = fire_perimeters_gdf.shape
print(f"\n3. GeoDataFrame Shape (Rows, Columns): {data_shape}")

# 4. CRS Check
crs_result = fire_perimeters_gdf.crs
print("\n4. CRS Check:")
print(f"   CRS: {crs_result}")
if crs_result and crs_result.to_epsg() == 4326:
    print("   Confirmed: CRS is WGS 84 (EPSG:4326), standard for GeoJSON.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import geopandas as gpd
import pandas as pd
from shapely.geometry import LineString

# --- Setup: Create a dummy GeoDataFrame mimicking a large file ---
# We simulate a file with many columns, but only load a few.
# In a real scenario, this file would be read from disk.
all_cols = ['segment_id', 'road_class', 'length_km', 'surface_type', 'admin_code', 'legacy_id', 'traffic_count']
dummy_data = {col: [f"{col}_val_{i}" for i in range(3)] for col in all_cols}
dummy_data['segment_id'] = [101, 102, 103]
dummy_data['road_class'] = ['Highway', 'Local', 'Highway']
dummy_data['geometry'] = [
    LineString([(0, 0), (1, 1)]),
    LineString([(1, 1), (2, 2)]),
    LineString([(2, 2), (3, 3)])
]
# dummy_gdf_full.to_file("global_roads.shp") 

# 1. Identify Required Columns
required_attributes = ['segment_id', 'road_class']

# 2. Optimized Read
# The key is using the 'columns' parameter in read_file
# Note: The geometry column ('geometry') is automatically included 
# unless specifically excluded, but listing it explicitly is safe practice.
# We will rely on the default inclusion of geometry.
# optimized_roads_gdf = gpd.read_file("global_roads.shp", columns=required_attributes)

# Since we are simulating, we manually filter the dummy data
optimized_roads_gdf = gpd.GeoDataFrame(
    pd.DataFrame(dummy_data)[required_attributes],
    geometry=dummy_data['geometry'],
    crs='EPSG:4326'
)

# 3. Verification
print("Columns loaded in optimized GeoDataFrame:")
print(optimized_roads_gdf.columns.tolist())

# 4. Memory Comparison (Conceptual)
"""
# This method is superior to loading the entire dataset and then dropping 
# unwanted columns because the filtering occurs during the I/O operation 
# (handled by the underlying GDAL/Fiona driver). This means only the 
# required data ever enters Python's memory space, drastically reducing 
# both memory usage and the initial load time, which is crucial for 
# massive datasets.
"""

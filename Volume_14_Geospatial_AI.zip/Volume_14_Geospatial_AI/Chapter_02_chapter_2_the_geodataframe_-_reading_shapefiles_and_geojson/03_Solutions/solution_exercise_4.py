
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import geopandas as gpd
from functools import partial

# 1. Define Input
file_paths = [
    'data/tiles/tile_01.geojson',
    'data/tiles/tile_02.geojson',
    'data/tiles/tile_03.geojson',
    'data/tiles/tile_04.geojson'
]

# 2. Define the Task Function
def load_single_tile(path):
    """
    Conceptual function representing the I/O operation.
    In a real async pipeline, this might be wrapped in run_in_executor.
    """
    # return gpd.read_file(path) # Actual I/O operation
    return f"Task defined: Read {path}" # Placeholder for conceptual task

# 3. Generate Awaitables (Conceptual Tasks)
# We use functools.partial to create callable objects (tasks) 
# that are pre-bound with their arguments, ready for deferred execution.
# This structure is conceptually similar to creating Futures/Awaitables.
async_tasks = [partial(load_single_tile, path) for path in file_paths]

# 4. Verification
print("Type of generated task list:", type(async_tasks))
print("\nContents of async_tasks (Conceptual Awaitables):")
# Displaying the first task to show it's a partial object, not a result
print(async_tasks[0])
print("\nExecuting the first task manually (simulating the async loop):")
print(async_tasks[0]())

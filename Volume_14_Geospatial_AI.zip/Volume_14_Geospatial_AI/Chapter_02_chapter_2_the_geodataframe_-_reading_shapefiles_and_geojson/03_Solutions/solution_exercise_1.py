
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import geopandas as gpd
import pandas as pd
import os

# --- Setup: Create a dummy Shapefile for execution demonstration ---
# In a real scenario, this file would already exist.
# We create a simple GeoDataFrame to simulate the file loading process.
data = {
    'name': ['Park A', 'Park B', 'Park C'],
    'area_sqm': [1000, 5000, 2500],
    'geometry': [
        'POLYGON ((0 0, 0 1, 1 1, 1 0, 0 0))',
        'POLYGON ((2 2, 2 3, 3 3, 3 2, 2 2))',
        'POLYGON ((5 5, 5 6, 6 6, 6 5, 5 5))'
    ]
}
parks_gdf_dummy = gpd.GeoDataFrame(
    pd.DataFrame(data), 
    geometry=gpd.GeoSeries.from_wkt(data['geometry']),
    crs='EPSG:3857' # Assume a common projected CRS
)
# parks_gdf_dummy.to_file("city_parks.shp") # If we were writing the file

# 1. Load the Data (using the simulated GeoDataFrame)
# parks_gdf = gpd.read_file("city_parks.shp") 
parks_gdf = parks_gdf_dummy 

print(f"1. Data Loaded: {type(parks_gdf)}")

# 2. Verify Geometry and Identify Column Name
is_gdf = isinstance(parks_gdf, gpd.GeoDataFrame)
geom_col_name = parks_gdf.geometry.name

print(f"\n2. Is GeoDataFrame? {is_gdf}")
print(f"   Active Geometry Column: '{geom_col_name}'")

# 3. Inspect CRS
crs_info = parks_gdf.crs
print("\n3. Coordinate Reference System (CRS) Inspection:")
if crs_info:
    print(f"   CRS is defined.")
    if crs_info.to_epsg():
        print(f"   EPSG Code: {crs_info.to_epsg()}")
    else:
        print(f"   WKT String: {crs_info.to_wkt(pretty=True)[:100]}...")
else:
    print("   WARNING: CRS is missing or undefined.")

# 4. Attribute Preview
print("\n4. First Five Rows (Attribute and Geometry Preview):")
print(parks_gdf.head(5))

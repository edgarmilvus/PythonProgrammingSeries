
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import geopandas as gpd
import pandas as pd
from shapely.geometry import Point
import os
import glob
import warnings

# Suppress warnings that might arise during file creation/cleanup
warnings.filterwarnings('ignore')

# --- 1. SETUP: Creating Self-Contained Test Data ---
# In a real-world scenario, these files would already exist.
# We create them here to make the example runnable.

# Define the base data for three European cities
data_points = {
    'City': ['London', 'Paris', 'Berlin'],
    'Country': ['UK', 'France', 'Germany'],
    'Population_M': [9.6, 2.1, 3.8]
}
df = pd.DataFrame(data_points)

# Define coordinates (Longitude, Latitude)
coords = [
    (0.1278, 51.5074),  # London
    (2.3522, 48.8566),  # Paris
    (13.4050, 52.5200)  # Berlin
]

# Create Point geometries
geometry = [Point(lon, lat) for lon, lat in coords]

# Initialize the GeoDataFrame with a standard CRS (WGS 84)
initial_gdf = gpd.GeoDataFrame(
    df,
    geometry=geometry,
    crs="EPSG:4326"
)

# Define output filenames
SHP_FILE = 'european_cities.shp'
GEOJSON_FILE = 'european_cities.geojson'

# Write the data out to disk
print("--- Preparing Files for Ingestion ---")
initial_gdf.to_file(SHP_FILE)
initial_gdf.to_file(GEOJSON_FILE, driver='GeoJSON')
print(f"Successfully created: {SHP_FILE} (and sidecar files) and {GEOJSON_FILE}")
print("-" * 45)


# --- 2. CORE TASK: Reading the GeoDataFrame ---

print("\n[A] Ingesting the Shapefile (.shp)")
# Use the core reading function, pointing only to the main .shp file
gdf_from_shp = gpd.read_file(SHP_FILE)

print("\n[B] Ingesting the GeoJSON (.geojson)")
# The exact same function is used for GeoJSON
gdf_from_json = gpd.read_file(GEOJSON_FILE)


# --- 3. VERIFICATION AND INSPECTION ---

print("\n--- Verification of Shapefile Read ---")
print(f"1. Object Type: {type(gdf_from_shp)}")
print(f"2. CRS Detected: {gdf_from_shp.crs.to_string()}")
print("3. Data Head (Shapefile):")
print(gdf_from_shp.head())

print("\n--- Verification of GeoJSON Read ---")
print(f"1. Object Type: {type(gdf_from_json)}")
print(f"2. CRS Detected: {gdf_from_json.crs.to_string()}")
print("3. Data Head (GeoJSON):")
print(gdf_from_json.head())


# --- 4. CLEANUP (Ensuring a clean state after execution) ---
print("\n--- Cleanup ---")
# Shapefiles generate multiple files (e.g., .dbf, .shx, .prj, .cpg)
# We use glob to find all related files starting with the base name
base_name = os.path.splitext(SHP_FILE)[0]
files_to_remove = glob.glob(f'{base_name}.*')
files_to_remove.append(GEOJSON_FILE)

for f in files_to_remove:
    if os.path.exists(f):
        os.remove(f)
        # print(f"Removed: {f}") # Uncomment for detailed cleanup tracking

print("Cleanup successful. Temporary geospatial files removed from the directory.")

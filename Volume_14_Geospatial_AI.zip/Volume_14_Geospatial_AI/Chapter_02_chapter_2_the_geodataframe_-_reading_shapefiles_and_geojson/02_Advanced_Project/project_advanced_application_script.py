
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import geopandas as gpd
import pandas as pd
from shapely.geometry import Polygon
import tempfile
from pathlib import Path
import os
import json

# --- 1. Setup and Synthetic Data Generation Environment ---

# Use a temporary directory to manage file creation and ensure cleanup
TEMP_DIR = Path(tempfile.mkdtemp())
SHP_FILE_PATH = TEMP_DIR / "historical_districts.shp"
GEOJSON_FILE_PATH = TEMP_DIR / "proposed_zones.geojson"

print(f"Temporary working directory created at: {TEMP_DIR}")

# --- 2. Synthetic Data Creation: Historical Districts (Shapefile) ---

# Define geometries for the Shapefile (using a standard CRS: EPSG:4326 WGS 84)
historical_geoms = [
    Polygon([(0, 0), (0, 1), (1, 1), (1, 0), (0, 0)]),
    Polygon([(2, 2), (2, 3), (3, 3), (3, 2), (2, 2)])
]

# Create attribute data using a dictionary comprehension
historical_data = {
    'District_ID': [101, 102],
    'Year_Est': [1950, 1985],
    'Status': ['Protected', 'Review']
}

# Construct the GeoDataFrame for the Shapefile
gdf_historical_out = gpd.GeoDataFrame(
    historical_data,
    geometry=historical_geoms,
    crs="EPSG:4326"
)

# Write the GeoDataFrame to a multi-file Shapefile format
# Shapefiles often require specific driver settings, though geopandas handles defaults well.
print(f"Writing Shapefile to: {SHP_FILE_PATH}")
gdf_historical_out.to_file(SHP_FILE_PATH, driver="ESRI Shapefile")


# --- 3. Synthetic Data Creation: Proposed Zones (GeoJSON) ---

# Define geometries for the GeoJSON (using a different, projected CRS: EPSG:3857 Web Mercator)
proposed_geoms = [
    Polygon([(1000, 1000), (1000, 2000), (2000, 2000), (2000, 1000), (1000, 1000)]),
    Polygon([(5000, 5000), (5000, 6000), (6000, 6000), (6000, 5000), (5000, 5000)])
]

proposed_data = {
    'Zone_Name': ['A-1', 'B-2'],
    'Area_SqM': [1000000, 1000000]
}

# Construct the GeoDataFrame for the GeoJSON
gdf_proposed_out = gpd.GeoDataFrame(
    proposed_data,
    geometry=proposed_geoms,
    crs="EPSG:3857"
)

# Write the GeoDataFrame to the single-file GeoJSON format
print(f"Writing GeoJSON to: {GEOJSON_FILE_PATH}")
gdf_proposed_out.to_file(GEOJSON_FILE_PATH, driver="GeoJSON")


# --- 4. Data Ingestion and Validation Phase ---

print("\n--- Starting Ingestion Process ---")

# A. Ingesting the Shapefile
try:
    # Use gpd.read_file() to ingest the Shapefile. geopandas automatically locates
    # the associated auxiliary files (.dbf, .shx, .prj, etc.)
    gdf_historical_in = gpd.read_file(SHP_FILE_PATH)
    print(f"\nSuccessfully read Shapefile: {SHP_FILE_PATH.name}")
    print(f"  Feature Count: {len(gdf_historical_in)}")
    print(f"  CRS Detected: {gdf_historical_in.crs}")

except Exception as e:
    print(f"Error reading Shapefile: {e}")
    gdf_historical_in = None


# B. Ingesting the GeoJSON
try:
    # Use gpd.read_file() to ingest the GeoJSON. This uses the GeoJSON driver
    # which is optimized for single-file JSON parsing.
    gdf_proposed_in = gpd.read_file(GEOJSON_FILE_PATH)
    print(f"\nSuccessfully read GeoJSON: {GEOJSON_FILE_PATH.name}")
    print(f"  Feature Count: {len(gdf_proposed_in)}")
    print(f"  CRS Detected: {gdf_proposed_in.crs}")

except Exception as e:
    print(f"Error reading GeoJSON: {e}")
    gdf_proposed_in = None


# C. Final Validation Check: CRS Alignment
if gdf_historical_in is not None and gdf_proposed_in is not None:
    print("\n--- CRS Consistency Check ---")

    # Check if the CRSs are identical (they should not be, based on creation)
    if gdf_historical_in.crs != gdf_proposed_in.crs:
        print(f"WARNING: CRSs are mismatched.")
        print(f"  Historical CRS: {gdf_historical_in.crs.to_string()}")
        print(f"  Proposed CRS: {gdf_proposed_in.crs.to_string()}")
        print("  Reprojection is required before spatial operations (e.g., intersection).")
    else:
        print("CRSs are consistent. Data is ready for immediate spatial analysis.")

# --- 5. Cleanup ---

# Standard practice to remove temporary files and directories
try:
    for f in TEMP_DIR.iterdir():
        os.remove(f)
    os.rmdir(TEMP_DIR)
    print(f"\nCleanup complete. Removed temporary directory: {TEMP_DIR}")
except Exception as e:
    print(f"Error during cleanup: {e}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import numpy as np
import rasterio
import geopandas as gpd
from shapely.geometry import shape
from rasterio.features import shapes
from rasterio.transform import Affine

# 1. Configuration and Setup
# Define paths and parameters
IMAGE_PATH = "data/industrial_park_satellite.tif"
OUTPUT_PATH = "results/mapped_warehouses.geojson"
# Note: SAM model loading details are handled in previous sections of the chapter.

# 2. Simulated Model Initialization (Focus on the interface)
class MockSamPredictor:
    """
    Mock class to simulate the SAM prediction interface. 
    This allows us to test the geospatial integration pipeline without loading 
    the multi-gigabyte SAM weights.
    """
    def __init__(self, transform):
        self.transform = transform
        print("SAM Predictor initialized (Mock Mode).")

    def set_image(self, image_array):
        """Prepares the image for prediction (stores shape)."""
        self.image_shape = image_array.shape[:2]
        # In a real scenario, this step performs image encoding.

    def predict(self, box_prompts, multimask_output=False):
        """
        Simulates SAM predicting masks based on bounding boxes.
        The simulation mimics SAM refining the bounding box to the object boundary.
        """
        
        H, W = self.image_shape
        all_masks = []
        
        for box in box_prompts:
            x1, y1, x2, y2 = [int(v) for v in box]
            
            # Create a mock binary mask (1=segmented, 0=background)
            mock_mask = np.zeros((H, W), dtype=np.uint8)
            
            # Simulate a segmented object slightly smaller than the bounding box
            # This is the core 'refinement' SAM performs.
            dx, dy = (x2 - x1) // 6, (y2 - y1) // 6 
            mock_mask[y1 + dy : y2 - dy, x1 + dx : x2 - dx] = 1
            all_masks.append(mock_mask)
            
        # Returns masks, scores (None), logits (None)
        return np.array(all_masks), None, None 

# 3. Core Geospatial Processing Function: Mask to Vector
def vectorize_masks(masks_array, transform: Affine, crs):
    """
    Converts a stack of binary masks (N, H, W) into a GeoDataFrame of polygons.
    This function is the bridge between pixel space and world coordinates.
    """
    geometries = []
    
    # Iterate through each predicted mask
    for i, mask in enumerate(masks_array):
        # Ensure the mask is in the correct format (uint8) for rasterio processing
        mask = mask.astype(np.uint8)
        
        # rasterio.features.shapes extracts geometries from the mask
        # The 'transform' (affine matrix) georeferences the geometries
        # 'with_z=False' ensures we only get 2D geometries
        for geom, value in shapes(mask, transform=transform, connectivity=8):
            # We only process the foreground (segmented) pixels (value == 1)
            if value == 1:
                # Create a Shapely geometry object from the extracted GeoJSON-like dictionary
                polygon = shape(geom)
                geometries.append({
                    'geometry': polygon,
                    'type': 'Industrial Warehouse',
                    'prompt_id': i
                })
                
    # Create the final GeoDataFrame, assigning the CRS from the input image
    if geometries:
        gdf = gpd.GeoDataFrame(geometries, crs=crs)
        return gdf
    return gpd.GeoDataFrame()

# 4. Prompt Definition (Pixel Coordinates)
# These bounding boxes are defined based on assumed visual inspection 
# of the target GeoTIFF image (relative to the top-left corner).
# Format: [x_min, y_min, x_max, y_max]
WAREHOUSE_PROMPTS = np.array([
    [150, 200, 350, 450],  # Prompt 1: Targets a large structure in the NW quadrant
    [500, 100, 700, 300],  # Prompt 2: Targets a structure near the center-top
    [800, 600, 950, 750],  # Prompt 3: Targets a structure in the SE quadrant
    [100, 700, 250, 850]   # Prompt 4: Targets a smaller structure nearby
])

# 5. Main Execution Block
def run_sam_geo_segmentation(image_path, prompts, output_path):
    """Orchestrates the loading, prediction, vectorization, and saving process."""
    
    # --- Data Loading and Georeferencing Metadata Extraction ---
    try:
        with rasterio.open(image_path) as src:
            # Read the image data (Bands 1, 2, 3) and reorder to HxWxC for SAM input
            img_data = src.read([1, 2, 3]).transpose((1, 2, 0))
            
            # Crucial metadata for georeferencing
            affine_transform = src.transform 
            image_crs = src.crs
            print(f"Image loaded (Shape: {img_data.shape}). CRS: {image_crs}")
            
    except rasterio.RasterioIOError:
        # Fallback for demonstration if the specific file is not available
        print(f"Warning: Could not open {image_path}. Using dummy metadata.")
        # Create dummy 1000x1000 data and a default WGS84 transform
        affine_transform = Affine(0.001, 0, 0, 0, -0.001, 0) # Placeholder transform
        image_crs = "EPSG:4326"
        img_data = np.zeros((1000, 1000, 3), dtype=np.uint8)

    # --- SAM Prediction Phase ---
    predictor = MockSamPredictor(affine_transform)
    predictor.set_image(img_data)
    
    print(f"Starting segmentation with {len(prompts)} bounding box prompts...")
    
    # Execute prediction. SAM returns one or more masks per prompt.
    predicted_masks, _, _ = predictor.predict(
        box=prompts,
        multimask_output=False, # Requesting only the best mask per prompt
    )
    
    print(f"Prediction complete. Generated {predicted_masks.shape[0]} masks.")

    # --- Vectorization and Export Phase ---
    
    # Convert the resulting pixel masks into a georeferenced GeoDataFrame
    final_gdf = vectorize_masks(predicted_masks, affine_transform, image_crs)
    
    if not final_gdf.empty:
        # Handle output path creation and saving
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        # Save the results to GeoJSON format, preserving the CRS
        final_gdf.to_file(output_path, driver="GeoJSON")
        print(f"\n--- SUCCESS ---")
        print(f"Successfully mapped {len(final_gdf)} features.")
        print(f"Results saved to: {os.path.abspath(output_path)}")
    else:
        print("No valid features were successfully vectorized and exported.")

if __name__ == "__main__":
    os.makedirs("results", exist_ok=True)
    run_sam_geo_segmentation(IMAGE_PATH, WAREHOUSE_PROMPTS, OUTPUT_PATH)

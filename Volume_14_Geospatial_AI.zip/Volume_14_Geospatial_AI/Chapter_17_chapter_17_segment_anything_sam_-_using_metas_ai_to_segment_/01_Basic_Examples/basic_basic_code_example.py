
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np
import os
import torch 
from segment_anything import sam_model_registry, SamPredictor

# --- 1. CONFIGURATION AND MODEL LOADING ---
# Define the model type. 'vit_b' (Base) is the smallest and fastest, 
# suitable for initial testing and resource-constrained environments.
MODEL_TYPE = "vit_b" 

# Define the local path to the pre-trained weights file (.pth).
# This file must be downloaded separately from Meta's official repository.
CHECKPOINT_FILENAME = f"sam_{MODEL_TYPE}.pth"
# We assume the checkpoint is located in a standard location relative to the script.
CHECKPOINT_PATH = os.path.join(os.getcwd(), CHECKPOINT_FILENAME)

# Check for CUDA availability for optimal performance
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# Load the SAM model architecture and weights
try:
    # 1a. Instantiate the specific SAM model architecture (e.g., Vision Transformer Base)
    sam = sam_model_registry[MODEL_TYPE](checkpoint=CHECKPOINT_PATH)
    
    # 1b. Move the model to the designated device (GPU is highly recommended)
    sam.to(device=DEVICE)
    
    # 1c. Initialize the SamPredictor wrapper
    # This class manages the image pre-processing, encoding, and prompt handling
    predictor = SamPredictor(sam)
    
    print(f"SAM Model ({MODEL_TYPE}) loaded successfully on {DEVICE}.")

except FileNotFoundError:
    print(f"CRITICAL ERROR: SAM checkpoint file not found at {CHECKPOINT_PATH}.")
    print("Please download the required weights file to run this example.")
    # Exit gracefully or use a mock object for demonstration structure
    # For this example, we will use a mock structure if the file is missing
    class MockPredictor:
        def set_image(self, image):
            self.H, self.W = image.shape[0], image.shape[1]
            print(f"Mock: Image of shape {image.shape} set for encoding.")
        def predict(self, point_coords, point_labels, multimask_output=True):
            # Simulate a single mask output
            simulated_mask = np.zeros((1, self.H, self.W), dtype=bool)
            simulated_mask[:, 100:150, 100:150] = True 
            return simulated_mask, np.array([0.95]), np.zeros((1, 64, 64))
    
    predictor = MockPredictor()


# --- 2. SIMULATING GEOSPATIAL INPUT DATA ---

# Define dimensions for a small satellite tile
H, W = 256, 256

# Create a simulated 8-bit (uint8) RGB image array (HxWxC)
# Satellite imagery often requires scaling/normalization, but SAM expects 0-255 inputs.
simulated_image = np.random.randint(0, 256, size=(H, W, 3), dtype=np.uint8)

# Insert a distinct feature (e.g., a bright building) at a known location
# Coordinates (Row, Column): 50 to 100
simulated_image[50:100, 50:100, :] = [255, 100, 100] # Distinct reddish feature

# --- 3. IMAGE ENCODING (The Heavy Lifting) ---

# The set_image method performs necessary pre-processing and runs the image 
# through the Vision Transformer encoder to generate the high-dimensional feature embedding.
print("\n--- Starting Image Encoding ---")
predictor.set_image(simulated_image)
print(f"Image ({H}x{W}) encoded successfully. Embedding generated.")

# --- 4. DEFINING THE SINGLE POINT PROMPT ---

# 4a. Coordinate Definition (X, Y format)
# The SAM API expects coordinates in (X, Y) or (Column, Row) format.
# We target the center of our distinct feature (50:100, 50:100) -> Center at (75, 75)
# Note: The coordinates must be wrapped in a NumPy array, even for a single point.
input_point = np.array([[75, 75]]) 

# 4b. Label Definition
# Labels define the type of prompt: 1 for positive (foreground, "this is the object") 
# and 0 for negative (background, "this is not the object").
input_label = np.array([1]) # We are providing a positive prompt

# --- 5. RUNNING THE PREDICTION ---

# Call the predict method using the encoded image context and the prompts.
# multimask_output=True is the default and returns multiple potential masks.
masks, scores, logits = predictor.predict(
    point_coords=input_point,
    point_labels=input_label,
    multimask_output=True, 
)

# --- 6. OUTPUT INSPECTION AND SELECTION ---

print("\n--- Prediction Results ---")
print(f"Total masks generated by SAM: {masks.shape[0]}")
print(f"Confidence Scores for each mask: {scores}")

# Determine the index of the mask with the highest confidence score
best_mask_index = np.argmax(scores)
best_mask = masks[best_mask_index]
best_score = scores[best_mask_index]

print(f"\nSelected Best Mask (Index {best_mask_index}) with Score: {best_score:.4f}")

# Calculate the area of the segmented object
segmented_pixels = np.sum(best_mask)
print(f"Area segmented (pixels): {segmented_pixels}")

# The resulting mask is a boolean array, ready for conversion to vector GIS formats
print(f"Best Mask Shape: {best_mask.shape} | Data Type: {best_mask.dtype}")

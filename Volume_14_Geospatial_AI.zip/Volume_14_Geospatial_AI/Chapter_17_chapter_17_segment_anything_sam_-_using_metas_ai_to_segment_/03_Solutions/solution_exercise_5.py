
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np
import rasterio
from rasterio.transform import Affine
import os

# --- MOCK SETUP ---
# Simulate a list of tile inputs with unique metadata
BATCH_TILES = [
    {'path': 'tile_01.tif', 'crs': 'EPSG:32618', 'transform': Affine(1.0, 0, 300000, 0, -1.0, 4500000), 'bbox_prompts': [[10, 10, 50, 50]]},
    {'path': 'tile_02.tif', 'crs': 'EPSG:32618', 'transform': Affine(1.0, 0, 300500, 0, -1.0, 4500000), 'bbox_prompts': [[60, 60, 90, 90]]},
    {'path': 'tile_03.tif', 'crs': 'EPSG:32618', 'transform': Affine(1.0, 0, 300000, 0, -1.0, 4500500), 'bbox_prompts': [[20, 20, 80, 80]]},
]
OUTPUT_DIR = "processed_masks"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Mock SAM prediction function
def mock_sam_predict_tile(image_data, prompts):
    """Returns a mock binary mask (100x100 pixels)."""
    mask = np.zeros((100, 100), dtype=np.uint8)
    # Simulate segmentation based on the bounding box prompt
    for xmin, ymin, xmax, ymax in prompts:
        mask[ymin:ymax, xmin:xmax] = 1
    return mask

# 3. Metadata Preservation Function
def create_georeferenced_mask(mask_array, affine_transform, crs, output_path):
    """
    Writes the raw NumPy mask to a GeoTIFF, embedding the specific Affine 
    transform and CRS for georeferencing integrity.
    """
    profile = {
        'driver': 'GTiff',
        'height': mask_array.shape[0],
        'width': mask_array.shape[1],
        'count': 1,
        'dtype': mask_array.dtype,
        'crs': crs,
        'transform': affine_transform,
        'compress': 'lzw',
        'nodata': 0 # Assuming 0 is background
    }

    try:
        with rasterio.open(output_path, 'w', **profile) as dst:
            dst.write(mask_array, 1)
        print(f"  -> Successfully wrote georeferenced mask: {output_path}")
    except rasterio.RasterioIOError as e:
        print(f"  [ERROR] Rasterio write failed for {output_path}: {e}")
        raise

# --- 2. Iterative Processing Core ---
processed_paths = []

print(f"Starting batch processing of {len(BATCH_TILES)} tiles...")

for i, tile_info in enumerate(BATCH_TILES):
    tile_path = tile_info['path']
    print(f"\nProcessing Tile {i+1}: {tile_path}")
    
    # 5. Error Handling Outline
    try:
        # Simulate loading the tile and extracting metadata
        # In reality: with rasterio.open(tile_path) as src: ...
        
        # 1. Extract Metadata
        tile_transform = tile_info['transform']
        tile_crs = tile_info['crs']
        
        print(f"  Metadata extracted: CRS={tile_crs}, Transform={tile_transform}")

        # 2. Run SAM Prediction
        raw_mask = mock_sam_predict_tile(tile_path, tile_info['bbox_prompts'])
        
        # 3. Save Georeferenced Mask
        output_mask_path = os.path.join(OUTPUT_DIR, f"mask_{os.path.basename(tile_path)}")
        create_georeferenced_mask(raw_mask, tile_transform, tile_crs, output_mask_path)
        
        processed_paths.append(output_mask_path)

    except rasterio.RasterioIOError as e:
        print(f"FATAL ERROR: Could not read or write file for {tile_path}. Skipping tile. Error: {e}")
    except Exception as e:
        print(f"An unexpected error occurred during processing tile {tile_path}: {e}")

# 4. Stitching Preparation
print("\n" + "="*50)
print("BATCH PROCESSING COMPLETE.")
print("Stitching Preparation Steps:")
if processed_paths:
    print(f"Total masks created: {len(processed_paths)}")
    print("1. All individual masks are now correctly georeferenced (CRS and Affine embedded).")
    print("2. Next step is to use a tool like `rasterio.merge` or `gdal_merge.py`.")
    print("3. The merge function will automatically align and stitch the tiles based on their embedded georeferencing, creating a seamless mosaic.")
    print(f"Example command: rasterio.merge.merge({processed_paths}, dst_path='final_mosaic.tif')")
else:
    print("No masks were successfully processed.")

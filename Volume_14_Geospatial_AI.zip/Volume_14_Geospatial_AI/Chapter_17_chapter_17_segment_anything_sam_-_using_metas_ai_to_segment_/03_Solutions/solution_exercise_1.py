
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
import rasterio
from rasterio.features import shapes
from fiona.crs import from_epsg
import os

# --- MOCK SETUP ---
# Simulate a georeferenced GeoTIFF input file
INPUT_IMAGE_PATH = "mock_satellite_image.tif"
OUTPUT_VECTOR_PATH = "building_footprints.gpkg"

# Mock rasterio metadata for a 100x100 image, UTM CRS
class MockRaster:
    def __init__(self):
        self.width = 100
        self.height = 100
        # Mock Affine transform (e.g., 1m resolution, starting at (300000, 4500000))
        self.transform = rasterio.transform.Affine(1.0, 0.0, 300000.0, 0.0, -1.0, 4500000.0)
        self.crs = from_epsg(32618) # Mock UTM Zone 18N

    def read(self):
        # Simulate a 3-band image array
        return np.zeros((3, self.height, self.width), dtype=np.uint8)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

# Mock SAM Prediction output (a binary mask)
def mock_sam_predict(image, prompt_point):
    """Simulates SAM generating a mask centered near the prompt."""
    mask = np.zeros((100, 100), dtype=np.uint8)
    # Simulate a building mask near (50, 50) pixel location
    mask[45:55, 45:55] = 1
    return mask

# --- CORE SOLUTION ---

def export_to_geopackage(mask_array, source_image_path, output_path):
    """
    Converts a binary mask into georeferenced vector polygons (GeoPackage).
    Ensures CRS and Affine transform integrity.
    """
    # 1. Load source metadata
    with MockRaster() as src: # In a real scenario: rasterio.open(source_image_path)
        source_transform = src.transform
        source_crs = src.crs

    # 2. Vectorization (Raster to Polygon)
    # We use rasterio.features.shapes to perform vectorization
    polygon_shapes = shapes(
        mask_array.astype(np.int16), 
        mask=mask_array, 
        transform=source_transform
    )
    
    # 3. Prepare schema and write to vector file (Mock Fiona/GeoPackage write)
    # In a real scenario, this uses geopandas or fiona.open
    
    # Extract geometries and attributes
    geometries = []
    for geom, value in polygon_shapes:
        if value == 1: # Only include the segmented feature
            geometries.append(geom)

    if not geometries:
        print("No features found to export.")
        return None

    # Mocking the successful creation of a GeoPackage file structure
    class MockVectorWriter:
        def __init__(self, crs):
            self.crs = crs
            self.data = geometries
        
        def write(self, path):
            print(f"\n[SUCCESS] Exported {len(self.data)} features to {path}")
            print(f"[VALIDATION] Output Vector CRS: {self.crs}")
            
    writer = MockVectorWriter(source_crs)
    writer.write(output_path)
    return writer.crs

# --- EXECUTION ---
# 1. Load data (Mocked)
with MockRaster() as img:
    print(f"Input Image CRS: {img.crs}")
    input_crs = img.crs

# 2. Define Point Prompt (Pixel coordinates: row, col)
prompt_point = (50, 50) 
print(f"Prompting SAM at pixel: {prompt_point}")

# 3. Mask Generation
segmentation_mask = mock_sam_predict(INPUT_IMAGE_PATH, prompt_point)

# 4. Vectorization and Export
result_crs = export_to_geopackage(segmentation_mask, INPUT_IMAGE_PATH, OUTPUT_VECTOR_PATH)

# 5. Validation Check
if result_crs == input_crs:
    print("\n[VERIFICATION] Georeferencing Integrity Check PASSED: Input CRS matches Output CRS.")
else:
    print("\n[VERIFICATION] Georeferencing Integrity Check FAILED.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np
from scipy.ndimage import binary_closing

# Define constants
IMAGE_H, IMAGE_W = 256, 256
MIN_AREA_THRESHOLD = 500  # Minimum required area in square pixels

# 1. Bounding Box Input (normalized or pixel coordinates)
# [x_min, y_min, x_max, y_max] defining a large wetland area
bounding_box = [50, 50, 200, 200]

# 2. Multi-Mask Prediction (Mock SAM Output)
def mock_sam_multi_predict(bbox):
    """Simulates SAM returning multiple masks with varying confidence."""
    # Mask 1: High confidence, large area (Focuses on main wetland)
    mask1 = np.zeros((IMAGE_H, IMAGE_W), dtype=np.uint8)
    mask1[60:190, 60:190] = 1
    
    # Mask 2: Moderate confidence, smaller area (Focuses on just the water body)
    mask2 = np.zeros((IMAGE_H, IMAGE_W), dtype=np.uint8)
    mask2[80:170, 80:170] = 1
    
    # Mask 3: Low confidence, large area (Includes surrounding trees)
    mask3 = np.zeros((IMAGE_H, IMAGE_W), dtype=np.uint8)
    mask3[40:210, 40:210] = 1

    predictions = [
        {'mask': mask1, 'confidence': 0.95, 'area': np.sum(mask1)},
        {'mask': mask2, 'confidence': 0.88, 'area': np.sum(mask2)},
        {'mask': mask3, 'confidence': 0.75, 'area': np.sum(mask3)},
    ]
    return predictions

# 3. Selection Logic
def select_best_mask(predictions, area_threshold_sq_pixels):
    """
    Selects the best mask based on highest confidence, prioritizing those 
    that meet the minimum area threshold.
    """
    eligible_masks = []
    
    for pred in predictions:
        if pred['area'] >= area_threshold_sq_pixels:
            eligible_masks.append(pred)
            
    if not eligible_masks:
        print(f"Warning: No masks met the minimum area threshold ({area_threshold_sq_pixels}).")
        # Fallback: Select highest confidence mask regardless of area
        return max(predictions, key=lambda p: p['confidence'])['mask']

    # Select the mask from the eligible list with the highest confidence
    best_prediction = max(eligible_masks, key=lambda p: p['confidence'])
    print(f"Selected Mask Confidence: {best_prediction['confidence']:.2f}, Area: {best_prediction['area']} pixels.")
    return best_prediction['mask']

# 4. Mask Refinement
def refine_mask(mask_array):
    """Applies a morphological closing operation to smooth boundaries."""
    # Closing fills small holes and smooths boundaries
    kernel = np.ones((3, 3), dtype=np.uint8)
    refined_mask = binary_closing(mask_array, structure=kernel).astype(np.uint8)
    return refined_mask

# --- EXECUTION ---
raw_predictions = mock_sam_multi_predict(bounding_box)

# Selection
selected_mask = select_best_mask(raw_predictions, MIN_AREA_THRESHOLD)

# Refinement
refined_mask_output = refine_mask(selected_mask)

# 5. Visualization Preparation (Output confirmation)
print(f"\nOriginal Mask Shape: {selected_mask.shape}")
print(f"Refined Mask Shape: {refined_mask_output.shape}")
print(f"Refinement complete. Mask ready for visualization/vectorization.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np

def process_sam_prompts(prompt_dictionary):
    """
    Safely extracts required SAM prompts using dict.get() to handle missing keys,
    returning structured arguments for the SAM predictor.
    """
    # 2. Safe Extraction using dict.get()
    # Positive and negative points default to empty lists
    positive_points = prompt_dictionary.get('positive_points', [])
    negative_points = prompt_dictionary.get('negative_points', [])
    
    # Bounding box defaults to None, as it's often a single optional array/tuple
    bounding_box = prompt_dictionary.get('bounding_box', None)
    
    # 3. Conditional Prediction Preparation
    sam_args = {}
    
    if positive_points or negative_points:
        # SAM expects points to be combined into a single array (coords) and labels array
        all_coords = positive_points + negative_points
        # 1 for positive, 0 for negative (assuming SAM API convention)
        labels = [1] * len(positive_points) + [0] * len(negative_points)
        
        if all_coords:
            sam_args['point_coords'] = np.array(all_coords)
            sam_args['point_labels'] = np.array(labels)
            
    if bounding_box is not None and len(bounding_box) == 4:
        # SAM expects the box as a specific format (e.g., NumPy array)
        sam_args['box'] = np.array(bounding_box)
        
    print(f"--- Processed Prompts ---")
    print(f"Raw Input Dict: {prompt_dictionary}")
    print(f"Structured SAM Args: {sam_args}")
    
    return sam_args

# --- EXECUTION ---

# 4. Demonstrate Robustness Test Case 1: Full Input
user_input_full = {
    'positive_points': [(100, 50)],
    'bounding_box': [10, 10, 200, 200],
    'negative_points': [(200, 100)]
}
print("Test Case 1: Full Input")
processed_full = process_sam_prompts(user_input_full)

print("\n" + "="*40 + "\n")

# 4. Demonstrate Robustness Test Case 2: Sparse Input (Missing Bounding Box and Negative Points)
user_input_sparse = {
    'positive_points': [(50, 50)],
    # 'bounding_box' is missing
    # 'negative_points' is missing
}
print("Test Case 2: Sparse Input")
processed_sparse = process_sam_prompts(user_input_sparse)

print("\n" + "="*40 + "\n")

# Test Case 3: Empty Input
user_input_empty = {}
print("Test Case 3: Empty Input")
processed_empty = process_sam_prompts(user_input_empty)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from abc import ABC, abstractmethod
import numpy as np

# 1. Define the Abstract Base Class
class GeoAIExporter(ABC):
    """
    Abstract Base Class defining the required interface for all GeoAI export pipelines.
    Ensures standardization of georeference validation and vector output.
    """
    def __init__(self, model_name):
        self.model_name = model_name
        print(f"Exporter initialized for model: {self.model_name}")

    @abstractmethod
    def validate_georeference(self, input_data):
        """
        Must validate the presence and integrity of CRS and Affine transform.
        Should raise ValueError if metadata is missing.
        """
        pass

    @abstractmethod
    def export_vector(self, mask_data, source_crs, output_format):
        """
        Must convert the raster mask data into the specified vector format 
        using the provided source CRS.
        """
        pass

# 2. Implement the Concrete Class
class StructuredSAMExporter(GeoAIExporter):
    """
    A concrete implementation adhering strictly to the GeoAIExporter interface.
    """
    def validate_georeference(self, input_data):
        # Placeholder logic: Check if input path exists and has metadata
        if not input_data.endswith('.tif'):
            raise ValueError("Input data must be a GeoTIFF path.")
        
        # Assume successful validation
        print(f"[{self.model_name} Validation] Georeference integrity check passed.")

    def export_vector(self, mask_data, source_crs, output_format):
        # Placeholder logic: Simulate conversion and saving
        if output_format not in ['GeoJSON', 'GPKG']:
            print(f"Warning: Output format {output_format} not supported.")
            return

        num_features = np.sum(mask_data) # Mock calculation
        print(f"[{self.model_name} Export] Successfully exported {num_features} segments to {output_format} using CRS {source_crs}.")

# 3. Demonstrate Enforcement Failure
class BrokenExporter(GeoAIExporter):
    """
    A broken implementation that fails to implement export_vector.
    Python should prevent its instantiation.
    """
    def validate_georeference(self, input_data):
        print("Validation attempted.")
        # Missing export_vector method

# --- EXECUTION AND DEMONSTRATION ---

# Successful Instantiation (Requirement 2)
print("--- Attempting StructuredSAMExporter ---")
try:
    sam_exporter = StructuredSAMExporter(model_name="SAM_H_Encoder")
    sam_exporter.validate_georeference("path/to/image.tif")
    sam_exporter.export_vector(np.array([1, 1, 0]), "EPSG:4326", "GPKG")
except Exception as e:
    print(f"Error instantiating StructuredSAMExporter: {e}")

print("\n--- Attempting BrokenExporter ---")
# Failed Instantiation (Requirement 3)
try:
    broken_exporter = BrokenExporter(model_name="Broken_Model")
except TypeError as e:
    print(f"[ENFORCEMENT SUCCESS] Failed to instantiate BrokenExporter.")
    print(f"Reason: {e}")

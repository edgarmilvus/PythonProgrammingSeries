
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import os
from math import sqrt
from typing import Type

# NOTE: Ensure your OPENAI_API_KEY is set as an environment variable
# Example: os.environ["OPENAI_API_KEY"] = "sk-..." 

# Import necessary components for tooling and agent creation
from pydantic import BaseModel, Field
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.prompts import ChatPromptTemplate

# --- 1. Tool Input Schema Definition (Pydantic) ---

class CoordinateInput(BaseModel):
    """
    Defines the expected input parameters for the geospatial distance calculator.
    This schema is critical for the LLM to correctly format the function call.
    """
    lat1: float = Field(description="Latitude of the first point (e.g., damaged building).")
    lon1: float = Field(description="Longitude of the first point.")
    lat2: float = Field(description="Latitude of the second point (e.g., relief center).")
    lon2: float = Field(description="Longitude of the second point.")

# --- 2. Custom GeoAI Tool Function ---

@tool(args_schema=CoordinateInput)
def calculate_euclidean_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Calculates the straight-line (Euclidean) distance between two coordinate pairs.
    This function simulates a dedicated geospatial processing step.
    The result is returned in degrees (the unit of the input coordinates).
    """
    # Simple 2D Euclidean distance calculation: sqrt((x2-x1)^2 + (y2-y1)^2)
    # This is a simplification, but serves to demonstrate the tool execution flow.
    distance = sqrt((lat2 - lat1)**2 + (lon2 - lon1)**2)
    return distance

# --- 3. Agent Setup and Assembly ---

# List of tools available to the agent
geo_tools = [calculate_euclidean_distance]

# Initialize the Language Model (LLM)
# Using a fast, modern model optimized for tool use
llm = ChatOpenAI(temperature=0, model="gpt-4o-mini") 

# Define the Agent Prompt Template (The agent's instructions and context)
system_message = (
    "You are a specialized GeoAI Assistant tasked with rapid disaster assessment. "
    "You have access to geospatial calculation tools. Use the 'calculate_euclidean_distance' "
    "tool whenever a user asks for a distance between coordinates. Be precise."
)

prompt = ChatPromptTemplate.from_messages([
    ("system", system_message),
    ("placeholder", "{tools}"),         # Placeholder where the tool definitions are injected
    ("human", "{input}"),               # The user's query
    ("placeholder", "{agent_scratchpad}"), # Internal storage for the agent's thoughts and intermediate steps
])

# Create the runnable agent (handles the reasoning loop)
agent = create_tool_calling_agent(llm, geo_tools, prompt)

# Create the Agent Executor (manages the execution of the agent and the actual tool calls)
agent_executor = AgentExecutor(agent=agent, tools=geo_tools, verbose=True)

# --- 4. Execution and Testing ---

print("--- Running Agent Query 1 (Requires Tool Use) ---")
query_1 = "Calculate the straight-line distance between a damaged structure at (34.00, -118.00) and a relief center at (34.10, -118.10)."

# Invoke the executor with the query
result_1 = agent_executor.invoke({"input": query_1})
print(f"\n[FINAL RESPONSE 1]: {result_1['output']}")

print("\n" + "="*50 + "\n")

print("--- Running Agent Query 2 (Does Not Require Tool Use) ---")
query_2 = "Briefly describe your primary function."

# Invoke the executor with a non-geospatial query
result_2 = agent_executor.invoke({"input": query_2})
print(f"\n[FINAL RESPONSE 2]: {result_2['output']}")

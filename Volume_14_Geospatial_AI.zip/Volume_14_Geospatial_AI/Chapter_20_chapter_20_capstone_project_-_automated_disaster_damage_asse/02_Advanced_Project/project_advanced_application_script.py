
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import json
import pathlib
import random
from typing import Dict, List, Any

# --- 1. Configuration and Path Setup ---
# Use pathlib for modern, platform-independent path construction
BASE_DIR = pathlib.Path(__file__).parent
DATA_DIR = BASE_DIR / "disaster_data"
REPORT_DIR = BASE_DIR / "damage_reports"

# Define standardized input/output file names
PRE_IMAGE_PATH = DATA_DIR / "pre_disaster_scene.tif"
POST_IMAGE_PATH = DATA_DIR / "post_disaster_scene.tif"
ALIGNED_METADATA_PATH = DATA_DIR / "aligned_metadata.json"
FINAL_REPORT_PATH = REPORT_DIR / "assessment_report.geojson"

# Simulated damage categories for classification
DAMAGE_CATEGORIES = ["Destroyed", "Major Damage", "Minor Damage", "No Visible Damage"]

# --- 2. Core GeoAI Pipeline Functions (Mocked for Workflow Focus) ---

def align_images(pre_path: pathlib.Path, post_path: pathlib.Path) -> pathlib.Path:
    """
    Stage 1: Simulates image registration and co-alignment.
    Uses EAFP to check for input data existence before proceeding.
    """
    try:
        # Check if input files exist (EAFP principle)
        if not pre_path.exists() or not post_path.exists():
            # Raise exception if prerequisites are missing
            raise FileNotFoundError("Pre- or post-disaster images not found. Alignment requires both.")
        
        print(f"[STAGE 1] Aligning {pre_path.name} and {post_path.name} using GCPs...")
        
        # In a real scenario, this involves GDAL/rasterio and complex affine transformation.
        # Mock writing alignment metadata using a context manager
        metadata = {"status": "aligned_success", "transformation_matrix": [0.99, 0.01, 10]}
        with open(ALIGNED_METADATA_PATH, 'w') as f:
            json.dump(metadata, f, indent=4)
        
        return ALIGNED_METADATA_PATH
    except FileNotFoundError as e:
        print(f"Error during alignment setup: {e}")
        # Re-raise the exception to halt the pipeline
        raise

def run_segmentation_model(aligned_path: pathlib.Path) -> List[Dict[str, Any]]:
    """
    Stage 2: Simulates running a fine-tuned SAM/U-Net model on the aligned post-disaster image.
    Outputs raw vector segment data (building footprints).
    """
    print(f"[STAGE 2] Running segmentation model using data from {aligned_path.name}...")
    
    # Mocking 20 detected building footprints with raw features
    segments = []
    for i in range(20):
        segments.append({
            "id": i + 1,
            "area_sq_m": random.randint(50, 500),
            "centroid": (random.uniform(-100, 100), random.uniform(20, 50)),
            "raw_features": ["high_entropy", "shadow_change"]
        })
    return segments

def classify_damage(segment_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Stage 3: Applies classification logic by comparing pre- vs. post-disaster segment features.
    Assigns a damage category based on calculated metrics.
    """
    print(f"[STAGE 3] Classifying damage for {len(segment_data)} structures...")
    
    classified_data = []
    for segment in segment_data:
        # Complex classification logic (e.g., comparing texture, height difference, spectral shift)
        
        # Simple simulation: Assign damage based on area and randomness
        if segment['area_sq_m'] > 400 and random.random() < 0.3:
            damage_level = "Destroyed"
        else:
            damage_level = random.choice(DAMAGE_CATEGORIES[1:])
        
        # Enhance segment data for GeoJSON output
        segment['damage_class'] = damage_level
        segment['confidence'] = round(random.uniform(0.80, 0.99), 2)
        classified_data.append(segment)
            
    return classified_data

def generate_gis_report(classified_data: List[Dict[str, Any]], output_path: pathlib.Path):
    """
    Stage 4: Converts structured Python data into standard GeoJSON format
    and writes the final report to disk using a Context Manager.
    """
    print(f"[STAGE 4] Generating GeoJSON report at {output_path.name}...")
    
    geojson_features = []
    for item in classified_data:
        # Constructing a standard GeoJSON Feature object
        feature = {
            "type": "Feature",
            "geometry": {
                "type": "Point",  # Simplified geometry (centroid) for immediate visualization
                "coordinates": item['centroid']
            },
            "properties": {
                "structure_id": item['id'],
                "damage_level": item['damage_class'],
                "area_sq_m": item['area_sq_m'],
                "confidence_score": item['confidence']
            }
        }
        geojson_features.append(feature)

    geojson_output = {
        "type": "FeatureCollection",
        "features": geojson_features
    }

    # Use context manager for guaranteed file closure (robust I/O)
    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(geojson_output, f, indent=2)
        print(f"SUCCESS: Damage assessment report saved. Total structures assessed: {len(classified_data)}")
    except IOError as e:
        print(f"CRITICAL ERROR: Could not write report file: {e}")
        raise

# --- 3. Main Execution Agent Pipeline ---

def main():
    """Executes the full automated damage assessment pipeline."""
    
    # Setup directories (using exist_ok=True implements a form of LBYL/EAFP setup)
    DATA_DIR.mkdir(exist_ok=True)
    REPORT_DIR.mkdir(exist_ok=True)

    # Mock creation of required input files for the alignment function to succeed
    if not PRE_IMAGE_PATH.exists():
        PRE_IMAGE_PATH.touch()
    if not POST_IMAGE_PATH.exists():
        POST_IMAGE_PATH.touch()

    try:
        # 1. Alignment Stage: Ensures spatial coherence
        aligned_meta = align_images(PRE_IMAGE_PATH, POST_IMAGE_PATH)

        # 2. Segmentation Stage: Extracts building vectors from post-disaster image
        raw_segments = run_segmentation_model(aligned_meta)

        # 3. Classification Stage: Assigns damage labels
        classified_results = classify_damage(raw_segments)

        # 4. Reporting Stage: Generates GIS-ready output
        generate_gis_report(classified_results, FINAL_REPORT_PATH)

    except Exception as e:
        # Catch any critical error that halted the pipeline (e.g., FileNotFoundError from Stage 1)
        print(f"\nPipeline execution halted due to critical error: {e}")
        print("Please verify input data integrity and path configuration.")
        
if __name__ == "__main__":
    main()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Setup for Exercise 2: Environment Variables
import os
from typing import Dict

# 1. Define the custom ConfigurationError exception here
class ConfigurationError(Exception):
    """Custom exception raised when required environment variables are missing."""
    pass

def load_agent_configuration() -> Dict[str, str]:
    """
    Loads critical configuration settings from environment variables.
    Raises ConfigurationError if any required variable is missing.
    """
    REQUIRED_VARS = ['GEOAI_API_KEY', 'DISASTER_ZONE_AOI', 'SAM_MODEL_PATH']
    config = {}
    missing_vars = []
    
    for var_name in REQUIRED_VARS:
        value = os.environ.get(var_name)
        if value is None:
            missing_vars.append(var_name)
        else:
            config[var_name] = value
    
    if missing_vars:
        # Raise ConfigurationError listing all missing variables
        raise ConfigurationError(
            f"Missing required environment variables: {', '.join(missing_vars)}. "
            "Please set these variables before running the GeoAI pipeline."
        )
    
    return config

# --- Simulation Setup ---

# Ensure variables are clean before starting tests
for var in ['GEOAI_API_KEY', 'DISASTER_ZONE_AOI', 'SAM_MODEL_PATH']:
    if var in os.environ:
        del os.environ[var]

# Test Case 1: Failure (All missing)
print("[Test 1 Failure Simulation] Running with no variables set.")
try:
    load_agent_configuration()
except ConfigurationError as e:
    print(f"Expected Failure Caught: {e}")

# Test Case 2: Success
print("\n[Test 2 Success Simulation] Setting all required variables.")
os.environ['GEOAI_API_KEY'] = 'sk-12345-secure-key'
os.environ['DISASTER_ZONE_AOI'] = '/tmp/aoi.geojson'
os.environ['SAM_MODEL_PATH'] = '/models/sam_ft.pth'

try:
    config = load_agent_configuration()
    print("Success! Configuration loaded:")
    for k, v in config.items():
        print(f"  {k}: {v}")
except ConfigurationError as e:
    print(f"Unexpected Error Caught: {e}")

# Cleanup
for var in ['GEOAI_API_KEY', 'DISASTER_ZONE_AOI', 'SAM_MODEL_PATH']:
    if var in os.environ:
        del os.environ[var]

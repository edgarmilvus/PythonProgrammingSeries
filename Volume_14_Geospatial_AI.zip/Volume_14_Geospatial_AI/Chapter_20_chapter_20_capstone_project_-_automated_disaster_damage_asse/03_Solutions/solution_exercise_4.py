
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Setup for Exercise 4: Asynchronous Context Manager
import asyncio
import logging
from typing import Optional, Type, Any

# Configure basic logging for clarity
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')

class AsyncGISConnectionManager:
    """
    Manages asynchronous connections to a remote GIS service (e.g., PostGIS), 
    ensuring proper setup and teardown using async context management.
    """
    def __init__(self, connection_url: str):
        self.connection_url = connection_url
        self.connection = None

    async def __aenter__(self):
        logging.info(f"Connecting asynchronously to {self.connection_url}...")
        # Simulate network latency (1 second non-blocking delay)
        await asyncio.sleep(1.0) 
        
        self.connection = f"ACTIVE_GIS_HANDLE_FOR_{self.connection_url}"
        logging.info("Connection established successfully.")
        return self.connection

    async def __aexit__(self, exc_type: Optional[Type[BaseException]],
                        exc_val: Optional[BaseException],
                        exc_tb: Optional[Any]):
        
        # Check if an exception occurred within the async with block
        if exc_type:
            logging.error(f"Task failed inside context, but cleanup proceeds: {exc_type.__name__}: {exc_val}")
            
        logging.info(f"Disconnecting from {self.connection_url}...")
        # Simulate network latency for resource release (0.5 second non-blocking delay)
        await asyncio.sleep(0.5)
        
        self.connection = None
        logging.info("Connection closed and resources released.")

async def run_disaster_assessment_task(url: str):
    """Simulates a task requiring a managed asynchronous connection."""
    logging.info("Starting assessment task.")
    
    try:
        # Use the AsyncGISConnectionManager here with 'async with'
        async with AsyncGISConnectionManager(url) as remote_db:
            logging.info(f"Successfully acquired connection handle: {remote_db}")
            
            # Simulate processing data using the connection
            logging.info("Processing large geospatial query asynchronously...")
            await asyncio.sleep(2.0)
            
            # Optional: Simulate an exception to test __aexit__ robustness
            # if "fail" in url:
            #     raise RuntimeError("Simulated connection failure during query.")
            
        logging.info("Assessment task finished (inside context).")
        
    except Exception as e:
        logging.warning(f"Task encountered an error: {e}")
        
    logging.info("Assessment task finished (outside context).")

# Example execution:
async def main_e4():
    print("\n--- Starting Async Connection Test ---")
    await run_disaster_assessment_task("postgresql://gis_db/disaster_log")
    print("--- Async Connection Test Finished ---\n")

# Execute the demonstration
asyncio.run(main_e4())

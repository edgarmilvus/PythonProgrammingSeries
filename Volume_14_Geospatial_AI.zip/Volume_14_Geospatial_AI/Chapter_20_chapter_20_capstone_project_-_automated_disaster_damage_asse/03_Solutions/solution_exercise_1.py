
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# Setup for Exercise 1: Context Manager for File I/O
import json
import os
from typing import Tuple, Dict, List

# 1. Define DataProcessingError here
class DataProcessingError(Exception):
    """Custom exception for errors during geospatial data processing."""
    pass

def safe_geojson_subsetter(input_path: str, output_path: str, bbox_filter: Tuple[float, float, float, float]) -> int:
    """
    Reads GeoJSON data, filters features based on a bounding box, and writes the subset 
    to a new file, guaranteeing resource cleanup via context managers.
    Returns the count of features written.
    """
    feature_count = 0
    data = None
    
    # 1. Read input safely using 'with open'
    try:
        with open(input_path, 'r') as infile:
            try:
                data = json.load(infile)
            except json.JSONDecodeError as e:
                # File handle is closed, but content is bad
                raise DataProcessingError(f"Corrupt GeoJSON format in {input_path}: {e}")
            except Exception as e:
                raise DataProcessingError(f"Unexpected error reading content from {input_path}: {e}")
    except FileNotFoundError:
        print(f"ERROR: Input file not found at {input_path}. Halting operation.")
        return 0 

    # Mock filtering logic: only keep features that have a property 'id' greater than 1
    filtered_features = []
    if data and data.get('type') == 'FeatureCollection':
        for feature in data.get('features', []):
            # In a real scenario, check if feature geometry intersects bbox_filter
            if feature.get('properties', {}).get('id', 0) > 1:
                filtered_features.append(feature)

    # 2. Write output safely using 'with open'
    output_data = {
        "type": "FeatureCollection",
        "features": filtered_features
    }
    
    try:
        with open(output_path, 'w') as outfile:
            json.dump(output_data, outfile, indent=2)
            feature_count = len(filtered_features)
            
    except IOError as e:
        # Catch errors during writing (e.g., permission denied)
        raise DataProcessingError(f"Error writing output file {output_path}: {e}")
        
    return feature_count

# --- Demonstration Setup ---
# Create a mock input file for testing success
mock_geojson_content = {
    "type": "FeatureCollection",
    "features": [
        {"type": "Feature", "properties": {"id": 1}, "geometry": None},
        {"type": "Feature", "properties": {"id": 2}, "geometry": None},
        {"type": "Feature", "properties": {"id": 3}, "geometry": None},
    ]
}
INPUT_FILE = 'valid_input.geojson'
OUTPUT_FILE = 'output.geojson'

# Create the mock file
with open(INPUT_FILE, 'w') as f:
    json.dump(mock_geojson_content, f)
    
# Test Case 1: Successful operation
try:
    feature_count = safe_geojson_subsetter(INPUT_FILE, OUTPUT_FILE, (0, 0, 10, 10))
    print(f"\n[Test 1 Success] Successfully processed {feature_count} features.")
except (DataProcessingError, FileNotFoundError) as e:
    print(f"[Test 1 Failure] Unexpected error: {e}")

# Test Case 2: Attempted read from a non-existent file path
print("\n[Test 2 Failure Simulation] Testing non-existent input file...")
safe_geojson_subsetter('non_existent_data.geojson', 'error_output.geojson', (0, 0, 10, 10)) 

# Cleanup
if os.path.exists(INPUT_FILE): os.remove(INPUT_FILE)
if os.path.exists(OUTPUT_FILE): os.remove(OUTPUT_FILE)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Setup for Exercise 3: Agent Modification
import rasterio
import numpy as np
from typing import Dict

# Mocking rasterio functions for execution without actual files
# This mock simulates opening/closing the file and returning sample pixel data.
class MockRaster:
    def __init__(self, path):
        self.path = path
        self.closed = False
    def __enter__(self):
        print(f"--- RasterIO: Opening {self.path} ---")
        return self
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.closed = True
        print(f"--- RasterIO: Closing {self.path} (Closed: {self.closed}) ---")
    def read(self, band_index):
        # Mock returned array data based on file path
        if 'pre' in self.path:
            # Pre-disaster (High NDVI proxy: 0.6)
            if band_index == 4: return np.array([[200]]) # NIR high
            if band_index == 3: return np.array([[50]])  # Red low
        elif 'post' in self.path:
            # Post-disaster (Low NDVI proxy: -0.304)
            if band_index == 4: return np.array([[80]])  # NIR low
            if band_index == 3: return np.array([[150]]) # Red high
        return np.array([[0]])

# Override rasterio.open with the mock for runnable code
rasterio.open = MockRaster 

class DamageClassificationAgent:
    
    def __init__(self, structural_loss_threshold: float = 0.20):
        self.structural_loss_threshold = structural_loss_threshold
        self.ndvi_change_threshold = 0.4

    def calculate_ndvi_proxy(self, raster_path: str, geometry: dict, 
                             nir_band_idx: int = 4, red_band_idx: int = 3) -> float:
        """
        Calculates the mean NDVI proxy within the geometry bounds using rasterio's context manager.
        """
        try:
            # Use rasterio.open as a context manager for safe file access
            with rasterio.open(raster_path) as src:
                # In a real scenario, use src.read(window=...) to extract pixels
                
                nir_data = src.read(nir_band_idx).astype(float)
                red_data = src.read(red_band_idx).astype(float)
                
                # Calculate NDVI: (NIR - Red) / (NIR + Red)
                numerator = nir_data - red_data
                denominator = nir_data + red_data
                
                # Handle potential division by zero
                denominator[denominator == 0] = 1e-6 
                
                mean_ndvi = np.mean(numerator / denominator)
                return mean_ndvi
                
        except Exception as e:
            # Resource cleanup is guaranteed by 'with' even if this fails
            print(f"Error accessing raster {raster_path} for NDVI calculation: {e}")
            return 0.0 

    def calculate_structural_loss(self, pre_area: float, post_area: float) -> float:
        """Mock calculation for structural loss percentage."""
        return (pre_area - post_area) / pre_area if pre_area > 0 else 0.0

    def classify_damage(self, pre_raster_path: str, post_raster_path: str, 
                        building_footprint: Dict, pre_area: float, post_area: float) -> Dict:
        """
        Core classification logic incorporating both structural loss and spectral change.
        """
        
        # 1. Calculate structural loss.
        structural_loss_pct = self.calculate_structural_loss(pre_area, post_area)
        
        # 2. Calculate pre_ndvi and post_ndvi securely using context managers.
        pre_ndvi = self.calculate_ndvi_proxy(pre_raster_path, building_footprint)
        post_ndvi = self.calculate_ndvi_proxy(post_raster_path, building_footprint)
        
        # 3. Calculate NDVI change magnitude.
        ndvi_change_magnitude = abs(pre_ndvi - post_ndvi)
        
        # Determine initial classification based on structural loss
        if structural_loss_pct >= 0.80:
            damage_class = "Destroyed"
        elif structural_loss_pct >= self.structural_loss_threshold:
            damage_class = "Moderate Damage"
        else:
            damage_class = "Minor/No Damage"
            
        # 4. Apply the new classification rule (Major Damage heuristic).
        if (structural_loss_pct > 0.20 and 
            ndvi_change_magnitude > self.ndvi_change_threshold):
            
            damage_class = "Major Damage" # Override classification
            
        updated_feature = building_footprint.copy()
        updated_feature['properties']['structural_loss_pct'] = round(structural_loss_pct, 4)
        updated_feature['properties']['ndvi_change_magnitude'] = round(ndvi_change_magnitude, 4)
        updated_feature['properties']['damage_class'] = damage_class
        
        return updated_feature

# --- Simulation Test ---
agent = DamageClassificationAgent()
mock_building = {"properties": {"id": 42}, "geometry": {}}
# Structural Loss = 40% (100 -> 60). NDVI Change Magnitude = 0.904 (High).
result = agent.classify_damage(
    pre_raster_path='pre_disaster_img.tif', 
    post_raster_path='post_disaster_img.tif', 
    building_footprint=mock_building, 
    pre_area=100.0, 
    post_area=60.0
)
print("\n[Scenario 1 Test]")
print(f"Structural Loss: {result['properties']['structural_loss_pct']*100:.2f}%")
print(f"NDVI Change Magnitude: {result['properties']['ndvi_change_magnitude']:.3f}")
print(f"Final Classification: {result['properties']['damage_class']}")

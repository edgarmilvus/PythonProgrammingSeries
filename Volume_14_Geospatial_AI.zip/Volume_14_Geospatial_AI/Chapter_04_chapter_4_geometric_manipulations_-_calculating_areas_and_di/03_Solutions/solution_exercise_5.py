
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from shapely.geometry import Polygon, Point
from shapely.ops import unary_union

# 1. Define the features (simplified meter coordinates for a projected space)
main_building = Polygon([
    (100, 100), (300, 100), (350, 200),
    (300, 300), (100, 300), (50, 200)
])

utility_point_1 = Point(400, 150)
utility_point_2 = Point(50, 450)

# Buffer distances in meters
BUILDING_BUFFER_DISTANCE = 50.0
UTILITY_BUFFER_DISTANCE = 20.0

# 2. Building Buffer
building_fence = main_building.buffer(BUILDING_BUFFER_DISTANCE)

# 3. Point Buffers
point1_fence = utility_point_1.buffer(UTILITY_BUFFER_DISTANCE)
point2_fence = utility_point_2.buffer(UTILITY_BUFFER_DISTANCE)

# Collect all buffered geometries
all_fences = [building_fence, point1_fence, point2_fence]

# 4. Union Operation
# Combine all individual buffers into a single, unified Geo-Fence
unified_geo_fence = unary_union(all_fences)

# 5. Perimeter and Area Calculation
fence_area = unified_geo_fence.area
fence_perimeter = unified_geo_fence.length

# Output
print("--- Optimal Geo-Fence Design Analysis ---")
print(f"Building Buffer Distance: {BUILDING_BUFFER_DISTANCE} m")
print(f"Utility Buffer Distance: {UTILITY_BUFFER_DISTANCE} m")
print(f"Resulting Geo-Fence Type: {unified_geo_fence.geom_type}")
print("-" * 40)
print(f"Total Monitored Area (sq meters): {fence_area:.2f}")
print(f"Total Geo-Fence Perimeter (meters): {fence_perimeter:.2f}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import rasterio
from rasterio.mask import mask
import geopandas as gpd
from shapely.geometry import mapping, Polygon
import os

# --- Setup: Simulate input raster and multi-geometry vector ---
# Placeholder for raster path (assuming a large raster exists)
INPUT_RASTER_PATH = "path/to/large_satellite_image.tif"
OUTPUT_DIR = "clipped_tiles"

# Create a mock GeoDataFrame with multiple ROIs and unique IDs
mock_data = {
    'id': ['A001', 'B002', 'C003'],
    'geometry': [
        Polygon([(1, 1), (1, 5), (5, 5), (5, 1)]),
        Polygon([(10, 10), (10, 15), (15, 15), (15, 10)]),
        Polygon([(20, 20), (20, 25), (25, 25), (25, 20)])
    ]
}
rois_gdf = gpd.GeoDataFrame(mock_data, crs="EPSG:4326")

# Create output directory
os.makedirs(OUTPUT_DIR, exist_ok=True)

def batch_clip_rois(input_raster_path, rois_gdf, output_directory):
    """
    Iteratively clips a raster against multiple ROIs in a GeoDataFrame.
    """
    try:
        # 3. Memory Management: Open the input raster ONCE outside the loop
        with rasterio.open(input_raster_path) as src:
            src_profile = src.profile
            
            # Reproject ROIs if needed (assuming src.crs is the target)
            if src.crs != rois_gdf.crs:
                rois_gdf = rois_gdf.to_crs(src.crs)

            # 1. Iterative Masking
            for index, row in rois_gdf.iterrows():
                roi_id = row['id']
                geometry = [mapping(row.geometry)]
                
                # 4. Error Logging
                print(f"\nProcessing ROI ID: {roi_id}...")
                
                try:
                    # Perform the mask operation for the single geometry
                    out_image, out_transform = mask(
                        src, 
                        geometry, 
                        crop=True, 
                        nodata=src_profile['nodata']
                    )

                    # Update profile for the new tile dimensions
                    out_meta = src_profile.copy()
                    out_meta.update({
                        "height": out_image.shape[1],
                        "width": out_image.shape[2],
                        "transform": out_transform
                    })

                    # 2. Dynamic Naming
                    output_filename = os.path.join(output_directory, f"clipped_tile_{roi_id}.tif")

                    # Write the output tile
                    with rasterio.open(output_filename, "w", **out_meta) as dest:
                        dest.write(out_image)
                        
                    print(f"  -> SUCCESS: Tile saved as {output_filename}")

                except Exception as e:
                    print(f"  -> ERROR: Failed to clip ROI {roi_id}. Reason: {e}")

    except rasterio.RasterioIOError:
        print(f"FATAL ERROR: Could not open input raster at {input_raster_path}. Simulation stopped.")
    except Exception as e:
        print(f"FATAL ERROR: An unexpected error occurred: {e}")

# Call the function (requires a dummy raster file to run successfully)
# batch_clip_rois(INPUT_RASTER_PATH, rois_gdf, OUTPUT_DIR)

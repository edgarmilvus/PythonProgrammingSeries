
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import sys
import os
import rasterio
from rasterio.mask import mask
import geopandas as gpd
from shapely.geometry import mapping

# Core clipping function (simplified from Exercise 1)
def core_clip_logic(input_raster, mask_vector, output_raster):
    """
    Performs the actual raster clipping operation.
    """
    with rasterio.open(input_raster) as src:
        gdf = gpd.read_file(mask_vector)
        
        # Ensure CRS match
        if src.crs != gdf.crs:
            gdf = gdf.to_crs(src.crs)

        geometries = [mapping(geom) for geom in gdf.geometry]
        
        out_image, out_transform = mask(src, geometries, crop=True, nodata=src.nodata)

        out_meta = src.profile
        out_meta.update({
            "height": out_image.shape[1],
            "width": out_image.shape[2],
            "transform": out_transform,
        })

        with rasterio.open(output_raster, "w", **out_meta) as dest:
            dest.write(out_image)
            
        print(f"SUCCESS: Raster clipped and saved to {output_raster}")


if __name__ == "__main__":
    # 1 & 2. Argument Parsing and Validation
    if len(sys.argv) != 4:
        print("--- GeoAI Clipping Utility ---")
        print(f"Error: Expected 3 arguments, received {len(sys.argv) - 1}.")
        print("Usage: python script_name.py <input_raster_path> <mask_vector_path> <output_raster_path>")
        sys.exit(1)

    INPUT_RASTER = sys.argv[1]
    MASK_VECTOR = sys.argv[2]
    OUTPUT_RASTER = sys.argv[3]

    # 3. File Existence Check
    try:
        if not os.path.exists(INPUT_RASTER):
            raise FileNotFoundError(f"Input raster not found: {INPUT_RASTER}")
        if not os.path.exists(MASK_VECTOR):
            raise FileNotFoundError(f"Masking vector not found: {MASK_VECTOR}")
            
        # 4. Execution Flow (Diagram step) & 5. Error Handling Integration
        print(f"Processing {INPUT_RASTER} using mask {MASK_VECTOR}...")
        core_clip_logic(INPUT_RASTER, MASK_VECTOR, OUTPUT_RASTER)

    except FileNotFoundError as fnf_err:
        print(f"FATAL ERROR: Input file missing. {fnf_err}")
        sys.exit(1)
    except rasterio.RasterioIOError as rio_err:
        print(f"FATAL ERROR: Raster I/O issue (e.g., corrupted file or projection mismatch). Details: {rio_err}")
        sys.exit(1)
    except Exception as e:
        print(f"An unexpected error occurred during processing: {e}")
        sys.exit(1)

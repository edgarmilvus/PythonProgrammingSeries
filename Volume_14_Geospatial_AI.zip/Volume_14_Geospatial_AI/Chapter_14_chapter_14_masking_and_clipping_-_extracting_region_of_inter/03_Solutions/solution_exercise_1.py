
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import rasterio
from rasterio.mask import mask
import geopandas as gpd
from shapely.geometry import mapping
import os

def clip_raster_by_vector(input_raster_path, mask_vector_path, output_raster_path):
    """
    Clips a raster using a vector boundary, handling CRS transformation automatically.
    """
    # 1. Load the masking vector geometry
    try:
        gdf = gpd.read_file(mask_vector_path)
    except Exception as e:
        print(f"Error loading vector file: {e}")
        return

    with rasterio.open(input_raster_path) as src:
        # 2. CRS Handling: Check and reproject if necessary
        if src.crs != gdf.crs:
            print(f"Reprojecting vector from {gdf.crs} to raster CRS {src.crs}...")
            # Reproject the GeoDataFrame to match the raster's CRS
            gdf = gdf.to_crs(src.crs)

        # 3. Extract geometries (required format for rasterio.mask)
        geometries = [mapping(geom) for geom in gdf.geometry]

        # 4. Perform the mask operation
        # crop=True ensures the output bounds match the clipped area
        # filled=True ensures areas outside the mask are filled with nodata
        out_image, out_transform = mask(
            src, 
            geometries, 
            crop=True, 
            filled=True, 
            nodata=src.nodata if src.nodata is not None else 0 # Use existing nodata or default to 0
        )

        # 5. Metadata Preservation: Update the profile
        out_meta = src.profile
        out_meta.update({
            "driver": "GTiff",
            "height": out_image.shape[1],
            "width": out_image.shape[2],
            "transform": out_transform,
            "nodata": src.nodata if src.nodata is not None else 0
        })

        # 6. Write the output raster
        with rasterio.open(output_raster_path, "w", **out_meta) as dest:
            dest.write(out_image)

    print(f"Successfully clipped raster saved to: {output_raster_path}")

# Example Usage (requires placeholder files to run)
# clip_raster_by_vector("input.tif", "mask.geojson", "clipped_output.tif")

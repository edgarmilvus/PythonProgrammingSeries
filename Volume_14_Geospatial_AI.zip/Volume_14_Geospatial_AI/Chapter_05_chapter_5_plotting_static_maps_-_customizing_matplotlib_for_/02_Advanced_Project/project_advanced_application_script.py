
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import matplotlib.pyplot as plt
import geopandas as gpd
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap
from mpl_toolkits.axes_grid1.anchored_artists import AnchoredSizeBar
import matplotlib.font_manager as fm
import contextily as cx
import numpy as np
import os

# --- 1. Setup and Custom Helper Functions ---

# Function to draw a simple North Arrow (using Matplotlib patches and annotation)
def add_north_arrow(ax, xy=(0.95, 0.9), size=0.03):
    """Adds a north arrow patch to the specified axes, anchored relative to the axis bounds."""
    # Calculate the absolute position based on relative coordinates (xy)
    arrow_center_x = ax.get_xlim()[0] + (ax.get_xlim()[1] - ax.get_xlim()[0]) * xy[0]
    arrow_center_y = ax.get_ylim()[0] + (ax.get_ylim()[1] - ax.get_ylim()[0]) * xy[1]

    # Use ax.annotate to draw the arrow and the 'N' label simultaneously
    ax.annotate('N', xy=(arrow_center_x, arrow_center_y + size * 100), # Target point (North)
                xytext=(arrow_center_x, arrow_center_y),               # Start point (Base)
                arrowprops=dict(facecolor='black', shrink=0.0, width=5, headwidth=15),
                ha='center', va='center', fontsize=14, fontweight='bold',
                clip_on=False, transform=ax.transData) # Use data coordinates

# Define a custom color ramp (sequential scheme for density visualization)
colors = ["#fef0d9", "#fdcc8a", "#fc8d59", "#e34a33", "#b30000"]
custom_cmap = LinearSegmentedColormap.from_list("DensityMap", colors, N=256)

# --- 2. Data Acquisition and Preparation ---

# Load a built-in GeoPandas dataset (World data, then filter for US States)
world = gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))
states = world[world['name'] == 'United States of America']

# Filter specifically to California (using a simple bounding box approximation or name filtering)
california = states.explode(ignore_index=True) # Explode multi-polygons for cleaner state boundaries
california = california[california.area > 0.1].reset_index(drop=True) # Simple filter for main landmass

# Synthesize a 'Population_Density' metric (simulating real-world data)
np.random.seed(42)
# Create varying density values, scaled by the geometric area for realism
california['Population_Density'] = np.random.randint(100, 5000, size=len(california))
california['Population_Density'] = california['Population_Density'] * 1000 / california.area

# --- 3. CRS Transformation (CRITICAL Step for Accurate Cartography) ---

# Initial CRS is EPSG:4326 (WGS84). We project to Web Mercator (EPSG:3857) 
# because it is required by contextily and uses meters for accurate scale bars.
TARGET_CRS = "EPSG:3857"
california_proj = california.to_crs(TARGET_CRS)

# --- 4. Plotting Setup and Customization ---

# Initialize the Matplotlib figure and axes object
fig, ax = plt.subplots(1, 1, figsize=(12, 12))

# 4a. Plot the Choropleth Map using the custom colormap
california_proj.plot(column='Population_Density',
                     ax=ax,
                     legend=True,
                     cmap=custom_cmap,
                     edgecolor='dimgray',
                     linewidth=0.8,
                     legend_kwds={'label': "Population Density Index (Synthetic)",
                                  'orientation': "horizontal",
                                  'shrink': 0.6,
                                  'pad': 0.05})

# 4b. Add a Contextual Basemap (Must be done after plotting the data, requires matching CRS)
cx.add_basemap(ax, crs=california_proj.crs.to_string(), source=cx.providers.Stamen.TonerLite)

# 4c. Add Cartographic Elements (Scale Bar and North Arrow)

# Create a Scale Bar using AnchoredSizeBar (handles units defined by the projected CRS)
# 50 km = 50,000 meters in the EPSG:3857 coordinate system
scalebar = AnchoredSizeBar(ax.transData,
                           50000,
                           '50 km',
                           'lower left',
                           pad=0.5,
                           color='black',
                           frameon=False,
                           size_vertical=2,
                           fontproperties=fm.FontProperties(size=10))
ax.add_artist(scalebar)

# Add North Arrow (using the custom function)
add_north_arrow(ax)

# 4d. Final Map Aesthetics
ax.set_title("Professional GeoAI Visualization: Population Density (Web Mercator Projection)", fontsize=16)
ax.set_axis_off() # Remove standard Matplotlib axes for a clean map appearance
plt.tight_layout()
plt.savefig('custom_geo_visualization.png', dpi=300)
print("Map saved successfully as custom_geo_visualization.png")

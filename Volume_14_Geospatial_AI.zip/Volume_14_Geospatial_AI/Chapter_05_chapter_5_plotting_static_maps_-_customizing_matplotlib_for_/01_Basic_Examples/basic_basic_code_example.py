
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import geopandas as gpd
import matplotlib.pyplot as plt
import cartopy.crs as ccrs # Essential for defining map projections

# 1. Load Data
# Load the built-in world dataset provided by GeoPandas (WGS84 / EPSG:4326)
world = gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))

# 2. Define Figure and Axes with a Projection
# We use plt.subplots and pass a dictionary of keyword arguments to the subplot
fig, ax = plt.subplots(
    1, 1, # Single row, single column
    figsize=(10, 8),
    # CRITICAL STEP: Define the map projection using Cartopy's CRS module
    subplot_kw={'projection': ccrs.PlateCarree()}
)

# 3. Plot the GeoDataFrame
# GeoPandas automatically plots the geometry onto the Cartopy-enabled axis.
# Since the data's CRS (WGS84) matches the plot's CRS (PlateCarree), no complex
# transformation is needed yet, but the axis is now geographically aware.
world.plot(ax=ax, color='lightgray', edgecolor='black', linewidth=0.5)

# 4. Add Geographic Context (Cartopy specific enhancements)
# Add coastlines and ocean boundaries, managed by Cartopy
ax.coastlines(resolution='50m')

# Add gridlines (latitude and longitude lines)
# We must specify the CRS of the gridlines themselves (PlateCarree/WGS84)
gl = ax.gridlines(
    crs=ccrs.PlateCarree(),
    draw_labels=True,
    linewidth=0.5,
    color='gray',
    alpha=0.5,
    linestyle='--'
)

# Customize gridline labels for cleaner map aesthetics
gl.top_labels = False
gl.right_labels = False

# 5. Set Extent and Title
# Define the visible extent of the map in the coordinate system of the data
# [min_lon, max_lon, min_lat, max_lat]
ax.set_extent([-180, 180, -90, 90], crs=ccrs.PlateCarree())

ax.set_title("World Map: Data CRS (WGS84) matches Plot Projection (Plate Carrée)")

# 6. Display the Map
plt.show()

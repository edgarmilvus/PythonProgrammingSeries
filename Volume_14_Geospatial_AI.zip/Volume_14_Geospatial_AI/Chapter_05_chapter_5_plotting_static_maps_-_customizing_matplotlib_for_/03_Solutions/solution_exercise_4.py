
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import geopandas as gpd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from shapely.geometry import Point

# --- Setup and Data Simulation ---

# Use a regional area (Southeast Asia) and a metric CRS (UTM Zone 48N)
CRS_MAP = 'EPSG:32648' # UTM Zone 48N (units are meters)

world = gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))
# Simulate layers: Countries and Water (using large lakes/oceans)
countries = world[world['continent'] == 'Asia'].to_crs(CRS_MAP)
water = world[world['name'] == 'Indonesia'].buffer(100000).to_crs(CRS_MAP) # Placeholder for water layer

# Define Point of Interest (POI) - e.g., Singapore Port (approx WGS 84)
poi_wgs84 = Point(103.85, 1.35) 
poi_gdf = gpd.GeoDataFrame(geometry=[poi_wgs84], crs='EPSG:4326')
poi_gdf_proj = poi_gdf.to_crs(CRS_MAP)
poi_x, poi_y = poi_gdf_proj.geometry.iloc[0].coords[0]

# 1. Refactoring Setup
fig, ax = plt.subplots(1, 1, figsize=(10, 10))

# Plotting layers
countries.plot(ax=ax, color='#f0e4c4', edgecolor='black', linewidth=0.5, label='Land Areas')
water.plot(ax=ax, color='#a0c4ff', label='Water/Buffer')

# 2. Refactoring Titles and Labels
# Replace plt.title() with ax.set_title()
ax.set_title("Regional Infrastructure and Geographic Features", fontsize=14, pad=10)

# Implement fig-level title
fig.suptitle(f"Advanced Map Refactoring: Southeast Asia in {CRS_MAP}", fontsize=16, fontweight='bold')

# Set axis labels (though often hidden in maps, required for object model demonstration)
ax.set_xlabel("Easting (Meters)")
ax.set_ylabel("Northing (Meters)")

# 3. Refactoring Legend
# Create custom handles for layers not using column plotting
land_handle = mpatches.Patch(color='#f0e4c4', label='Land Areas')
water_handle = mpatches.Patch(color='#a0c4ff', label='Water/Buffer')

# Use ax.legend() explicitly
ax.legend(handles=[land_handle, water_handle], 
          loc='upper left', 
          title="Map Layers", 
          frameon=True)

# 4. Advanced Annotation Layer

# 4a. POI Marker
ax.scatter(poi_x, poi_y, 
           color='red', 
           marker='*', 
           s=300, 
           zorder=5, 
           label='Point of Interest (POI)')

# 4b. Contextual Bounding Box (5 km x 5 km)
# Since CRS_MAP is in meters, 5 km = 5000 units.
box_size_m = 5000
half_box = box_size_m / 2

# Rectangle centered at POI
rect = mpatches.Rectangle(
    (poi_x - half_box, poi_y - half_box), # (x, y) starting corner
    box_size_m, box_size_m,             # width, height
    facecolor='red', 
    alpha=0.2, 
    edgecolor='red', 
    linewidth=1, 
    linestyle='-'
)
ax.add_patch(rect)

# 4c. Callout Box (using ax.annotate)
ax.annotate('Critical Port Location',
            xy=(poi_x, poi_y), xycoords='data',
            xytext=(poi_x + 100000, poi_y + 100000), textcoords='data',
            arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=.2", color='black', lw=1.5),
            bbox=dict(boxstyle="round,pad=0.5", fc="white", alpha=0.8),
            horizontalalignment='left', verticalalignment='bottom',
            fontsize=10, zorder=6)

# Set extent to focus on the region
ax.set_xlim(poi_x - 300000, poi_x + 300000)
ax.set_ylim(poi_y - 300000, poi_y + 300000)
ax.set_aspect('equal')

plt.show()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import geopandas as gpd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import matplotlib.patches as mpatches
from shapely.geometry import LineString
import numpy as np

# --- Helper Functions ---

def draw_north_arrow(ax, location=(0.9, 0.9), size=0.08, color='black'):
    """Draws a stylized North Arrow in axes coordinates."""
    # Location is in axes coordinates (0 to 1)
    x, y = location
    
    # Use ax.text for the 'N' label
    ax.text(x, y + size * 0.1, 'N',
            transform=ax.transAxes, ha='center', va='center',
            fontsize=size * 100, color=color, fontweight='bold')

    # Use ax.annotate for the arrow body
    # Draw a filled triangle pointing up
    ax.annotate('', xy=(x, y - size * 0.1), xytext=(x, y - size * 0.35),
                arrowprops=dict(facecolor=color, edgecolor=color, 
                                shrink=0, headwidth=size * 30, headlength=size * 15),
                transform=ax.transAxes)

def draw_scale_bar(ax, target_km, location=(0.1, 0.05)):
    """Calculates and draws a scale bar for a map in a metric CRS."""
    
    # 1. Get current map extent in coordinate units (meters)
    x_min, x_max = ax.get_xlim()
    
    # 2. Determine coordinate length for target distance
    # Target distance in meters
    target_m = target_km * 1000
    
    # Calculate the normalized position for the scale bar start (in map coordinates)
    # We want the scale bar to start at 10% of the map width from the left edge
    map_width = x_max - x_min
    start_x = x_min + location[0] * map_width
    
    # Calculate the end x-coordinate based on the target distance
    end_x = start_x + target_m

    # Calculate the normalized position for the scale bar vertically (in map coordinates)
    y_min, y_max = ax.get_ylim()
    map_height = y_max - y_min
    y_pos = y_min + location[1] * map_height
    
    # 3. Draw alternating black and white segments
    segment_length = target_m / 4 # Four segments
    bar_height = map_height * 0.015
    
    for i in range(4):
        color = 'black' if i % 2 == 0 else 'white'
        rect = mpatches.Rectangle(
            (start_x + i * segment_length, y_pos),
            segment_length, bar_height,
            facecolor=color, edgecolor='black', linewidth=0.5
        )
        ax.add_patch(rect)

    # 4. Add label
    ax.text(end_x, y_pos - bar_height * 0.5, f'{target_km} km',
            fontsize=9, ha='right', va='top', fontweight='bold')

# --- Main Plotting Script ---

# 1. Data and Projection Setup
world = gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))

# Filter for a regional area (e.g., contiguous US)
target_countries = ['United States of America', 'Canada']
gdf = world[world['name'].isin(target_countries)].copy()

# Mock population density data (0 to 500)
np.random.seed(42)
gdf['DENSITY'] = np.random.randint(50, 500, len(gdf))

# Use a local projected CRS (e.g., UTM Zone 17N, suitable for Eastern US)
CRS_UTM = 'EPSG:32617'
gdf_proj = gdf.to_crs(CRS_UTM)

# 2. Custom Color Ramp
colors = ["#fef0d9", "#fdcc8a", "#fc8d59", "#e34a33", "#b30000"]
cmap_name = 'CustomDensity'
cm = mcolors.LinearSegmentedColormap.from_list(cmap_name, colors, N=256)

# Plotting
fig, ax = plt.subplots(1, 1, figsize=(10, 10))

# Plot choropleth
gdf_proj.plot(
    column='DENSITY',
    cmap=cm,
    linewidth=0.8,
    ax=ax,
    edgecolor='0.8',
    legend=True,
    legend_kwds={'label': "Mock Population Density (units/sq km)",
                 'orientation': "horizontal", 'shrink': 0.5}
)

ax.set_title(f"Regional Map in Projected CRS ({CRS_UTM})", fontsize=14)
ax.set_axis_off()

# 3. & 4. Integration of Custom Elements
# Draw North Arrow (top right)
draw_north_arrow(ax, location=(0.9, 0.9))

# Draw Scale Bar (bottom left, fixed distance of 150 km)
draw_scale_bar(ax, target_km=150, location=(0.1, 0.08))

plt.show()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import geopandas as gpd
import matplotlib.pyplot as plt
from cartopy import crs as ccrs # Although not strictly required by the prompt, using cartopy's CRS definitions is standard practice for projection visualization

# 1. Data Acquisition and Preparation
world = gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))
# Ensure initial CRS is WGS 84 (EPSG:4326)
world = world.to_crs(epsg=4326)

# Define target CRSs
crs_geographic = 'EPSG:4326'
crs_equal_area = 'ESRI:54012'  # Eckert IV
crs_compromise = 'EPSG:3857'  # Web Mercator

# Reproject data once for efficiency
world_eckert = world.to_crs(crs_equal_area)
world_mercator = world.to_crs(crs_compromise)

# 2. Figure Setup
fig, axes = plt.subplots(1, 3, figsize=(18, 6))
fig.suptitle("Visualizing Geographic Projection Distortion: Area vs. Conformality", fontsize=16, y=1.02)

# Define extent for all plots (using WGS 84 bounds for reference)
global_extent = (-180, 180, -90, 90)

# 3. Projection Application and Plotting

# Axis 1: Reference (Geographic CRS)
ax1 = axes[0]
world.plot(ax=ax1, color='lightgrey', edgecolor='black', linewidth=0.3)
ax1.set_title("1. Geographic CRS (WGS 84 / EPSG:4326)", fontsize=10)
# Set extent manually based on coordinates
ax1.set_xlim(-180, 180)
ax1.set_ylim(-90, 90)

# Axis 2: Equal Area Projection (Eckert IV)
ax2 = axes[1]
world_eckert.plot(ax=ax2, color='skyblue', edgecolor='black', linewidth=0.3)
ax2.set_title("2. Equal Area Projection (Eckert IV / ESRI:54012)", fontsize=10)
# To ensure the full globe is shown, we use the bounding box of the transformed data
ax2.set_xlim(world_eckert.total_bounds[0], world_eckert.total_bounds[2])
ax2.set_ylim(world_eckert.total_bounds[1], world_eckert.total_bounds[3])

# Axis 3: Conformal/Compromise Projection (Web Mercator)
ax3 = axes[2]
world_mercator.plot(ax=ax3, color='salmon', edgecolor='black', linewidth=0.3)
ax3.set_title("3. Compromise Projection (Web Mercator / EPSG:3857)", fontsize=10)

# Web Mercator bounds are extreme; setting limits to show standard map view (approx +/- 85 degrees latitude)
# 3857 coordinates for +/- 85 degrees latitude
x_limit_3857 = 20037508.34
y_limit_3857 = 20037508.34
ax3.set_xlim(-x_limit_3857, x_limit_3857)
ax3.set_ylim(-x_limit_3857, x_limit_3857)

# General cleanup
for ax in axes:
    ax.set_aspect('equal', adjustable='box')
    ax.set_xticks([])
    ax.set_yticks([])

plt.tight_layout(rect=[0, 0, 1, 0.95])
plt.show()

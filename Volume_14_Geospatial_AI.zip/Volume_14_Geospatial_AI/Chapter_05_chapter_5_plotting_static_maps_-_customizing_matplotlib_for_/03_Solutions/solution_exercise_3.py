
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import geopandas as gpd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from shapely.geometry import box

# 1. Data Loading and Preparation
world = gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))

# Define CRSs
CRS_MAIN = 'EPSG:102008' # North America Albers Equal Area
CRS_INSET = 'EPSG:32605' # UTM Zone 5N (Covers Aleutian Islands/Western Alaska)

# Filter Main Data (North America)
main_data = world[world['continent'] == 'North America'].to_crs(CRS_MAIN)

# Filter Inset Data (Aleutian Islands area, which is part of the US)
# We define a rough bounding box in WGS 84 for the Aleutians
aleutians_bbox_wgs84 = box(-180, 50, -160, 60)
aleutians_gdf = gpd.GeoDataFrame(geometry=[aleutians_bbox_wgs84], crs='EPSG:4326')

# Clip the world data to this box to get detailed features
inset_data = world.clip(aleutians_gdf).to_crs(CRS_INSET)

# 2. Projection Definition and Transformation (Completed above)

# 3. Figure and Axes Instantiation
fig = plt.figure(figsize=(12, 10))

# Main Axes (using add_subplot for standard placement)
ax_main = fig.add_subplot(1, 1, 1)

# Plot Main Data
main_data.plot(ax=ax_main, color='lightgray', edgecolor='black', linewidth=0.5)
ax_main.set_title("North America (Albers Equal Area) with Aleutian Islands Inset", fontsize=16)
ax_main.set_axis_off()

# 4. Plotting the Inset
# Inset Axes (using add_axes for precise normalized figure placement)
# [left, bottom, width, height]
ax_inset = fig.add_axes([0.65, 0.15, 0.25, 0.25]) 

# Plot Inset Data (which is already transformed to EPSG:32605)
inset_data.plot(ax=ax_inset, color='teal', edgecolor='black', linewidth=0.7)

# Set the extent for the inset based on its projected bounds
inset_bounds = inset_data.total_bounds
ax_inset.set_xlim(inset_bounds[0], inset_bounds[2])
ax_inset.set_ylim(inset_bounds[1], inset_bounds[3])

# 5. Contextual Linkage (Locator Box)

# Get the bounding box of the INSET DATA in its native CRS (32605)
inset_bbox = inset_data.total_bounds # [xmin, ymin, xmax, ymax]

# Create a GeoSeries representing the bounding box polygon in the INSET CRS
bbox_poly_inset = gpd.GeoSeries(box(*inset_bbox), crs=CRS_INSET)

# Transform the bounding box polygon to the MAIN CRS (102008)
bbox_poly_main_crs = bbox_poly_inset.to_crs(CRS_MAIN)

# Extract the new bounds in the Main CRS
xmin_main, ymin_main, xmax_main, ymax_main = bbox_poly_main_crs.total_bounds

# Calculate width and height for the patch
width_main = xmax_main - xmin_main
height_main = ymax_main - ymin_main

# Draw the Rectangle Patch on the main map (ax_main)
locator_box = mpatches.Rectangle(
    (xmin_main, ymin_main), width_main, height_main,
    facecolor='none', edgecolor='red', linewidth=2, linestyle='--'
)
ax_main.add_patch(locator_box)

# 6. Customization for Inset
ax_inset.set_xticks([])
ax_inset.set_yticks([])
ax_inset.set_title("Aleutian Islands Detail", fontsize=10)
ax_inset.spines['right'].set_visible(False)
ax_inset.spines['top'].set_visible(False)
ax_inset.set_aspect('equal')

plt.show()

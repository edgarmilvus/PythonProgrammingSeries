
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import geopandas as gpd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

# --- Helper Functions ---

def find_optimal_nice_number(target_length):
    """Finds the largest 'nice' number (1, 2, 2.5, 5 * 10^n) 
       that is approximately 20-30% of the target_length."""
    
    # Target range: 20% to 30% of the full map width
    min_length = target_length * 0.20
    max_length = target_length * 0.30
    
    # Nice numbers base units (in meters, since we work in meters)
    nice_bases = np.array([1, 2, 2.5, 5, 10, 20, 25, 50])
    
    # Iterate through powers of 10 (10^3 = km, 10^4, 10^5, etc.)
    powers = np.log10(target_length)
    
    # Start checking from the power of 10 just below the target range
    power = int(np.floor(powers - 1))
    
    optimal_scale = 0
    
    # Search upwards through powers of 10
    while True:
        multiplier = 10**power
        nice_numbers = nice_bases * multiplier
        
        # Find the largest nice number within the desired range
        candidates = nice_numbers[(nice_numbers >= min_length) & (nice_numbers <= max_length)]
        
        if len(candidates) > 0:
            optimal_scale = np.max(candidates)
            break
        
        if multiplier > target_length: # Safety break
            optimal_scale = np.max(nice_bases * 10**(power-1)) # Fallback
            break
            
        power += 1
        
    # Return in kilometers
    return optimal_scale / 1000

def draw_dynamic_scale_bar(ax, location=(0.1, 0.05)):
    """Calculates optimal scale and draws the bar."""
    
    x_min, x_max = ax.get_xlim()
    map_width_m = x_max - x_min
    
    # Calculate optimal scale length in KM
    L_opt_km = find_optimal_nice_number(map_width_m)
    L_opt_m = L_opt_km * 1000 # Back to meters (coordinate units)

    # Calculate bar placement
    y_min, y_max = ax.get_ylim()
    map_height = y_max - y_min
    
    start_x = x_min + location[0] * map_width_m
    y_pos = y_min + location[1] * map_height
    bar_height = map_height * 0.015
    
    # Draw alternating segments (4 segments)
    segment_length = L_opt_m / 4
    
    for i in range(4):
        color = 'black' if i % 2 == 0 else 'white'
        rect = mpatches.Rectangle(
            (start_x + i * segment_length, y_pos),
            segment_length, bar_height,
            facecolor=color, edgecolor='black', linewidth=0.5
        )
        ax.add_patch(rect)

    # Add label
    ax.text(start_x + L_opt_m, y_pos - bar_height * 0.5, f'{int(L_opt_km)} km',
            fontsize=10, ha='right', va='top', fontweight='bold')
    
    return L_opt_km

def set_optimal_grid(ax, grid_interval_m=50000):
    """Sets grid lines to align with round projected coordinates."""
    
    x_min, x_max = ax.get_xlim()
    y_min, y_max = ax.get_ylim()
    
    # Determine start and end points for round intervals
    x_start = np.ceil(x_min / grid_interval_m) * grid_interval_m
    x_end = np.floor(x_max / grid_interval_m) * grid_interval_m
    y_start = np.ceil(y_min / grid_interval_m) * grid_interval_m
    y_end = np.floor(y_max / grid_interval_m) * grid_interval_m
    
    # Generate tick locations
    x_ticks = np.arange(x_start, x_end + 1, grid_interval_m)
    y_ticks = np.arange(y_start, y_end + 1, grid_interval_m)
    
    # Apply to axes
    ax.set_xticks(x_ticks)
    ax.set_yticks(y_ticks)
    
    # Format labels to show metric coordinates (e.g., 400000 m)
    ax.ticklabel_format(style='plain', axis='both', useOffset=False)
    
    # Draw grid
    ax.grid(True, linestyle=':', alpha=0.6, color='gray')


# --- Main Plotting and Testing ---

# 1. Setup
# Use a region covered by UTM 17N (e.g., Florida/Georgia region)
CRS_MAP = 'EPSG:32617' 
world = gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))
gdf_proj = world[world['name'].isin(['United States of America', 'Cuba'])].to_crs(CRS_MAP)

fig, ax = plt.subplots(1, 1, figsize=(10, 10))

# Plot the data
gdf_proj.plot(ax=ax, color='lightgreen', edgecolor='black')

# 2. Define Initial Extent (Zoomed View Example 1: Local Area)
# Coordinates for a small area in UTM 17N (meters)
# Example 1: Zoomed in (approx 150 km width)
ax.set_xlim(400000, 550000)
ax.set_ylim(2900000, 3050000)

# 3. & 4. Dynamic Scale Bar Calculation and Drawing
L_km = draw_dynamic_scale_bar(ax)
ax.set_title(f"Dynamic Scale and Grid Map (Scale Bar: {int(L_km)} km)", fontsize=14)

# 5. Interactive Grid Line Generation (50 km interval = 50,000 meters)
set_optimal_grid(ax, grid_interval_m=50000)

ax.set_aspect('equal', adjustable='box')
ax.set_xlabel('Easting (m)')
ax.set_ylabel('Northing (m)')

plt.show()

# --- Test 2: Changing the Extent Significantly (Simulating Zoom Out) ---
fig, ax = plt.subplots(1, 1, figsize=(10, 10))
gdf_proj.plot(ax=ax, color='lightgreen', edgecolor='black')

# Example 2: Zoomed out (approx 800 km width)
ax.set_xlim(300000, 1100000)
ax.set_ylim(2800000, 3600000)

L_km_2 = draw_dynamic_scale_bar(ax)
ax.set_title(f"Dynamic Scale and Grid Map (Scale Bar: {int(L_km_2)} km)", fontsize=14)

# Grid interval adjusted to 100 km (100,000 meters) for the wider view
set_optimal_grid(ax, grid_interval_m=100000)

ax.set_aspect('equal', adjustable='box')
ax.set_xlabel('Easting (m)')
ax.set_ylabel('Northing (m)')

plt.show()

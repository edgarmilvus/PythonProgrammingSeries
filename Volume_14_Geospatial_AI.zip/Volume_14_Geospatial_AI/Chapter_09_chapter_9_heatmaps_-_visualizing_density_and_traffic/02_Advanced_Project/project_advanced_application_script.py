
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import numpy as np
from scipy.stats import gaussian_kde
import folium
from folium.plugins import HeatMap
import random
import os

# --- 1. CONFIGURATION AND DATA SIMULATION ---

# Define the number of simulated GPS points
N_POINTS = 5000
# Define the approximate center of the study area (e.g., a major metropolitan area)
CENTER_LAT, CENTER_LON = 34.0522, -118.2437 
# Define the resolution of the calculation grid (e.g., 150x150 cells)
GRID_RESOLUTION = 150
# Define the KDE bandwidth (controls smoothness: smaller = sharper hotspots)
KDE_BANDWIDTH = 0.0035

def generate_traffic_data(n: int) -> pd.DataFrame:
    """
    Simulates raw GPS logs, clustering points around specific 'hotspots' 
    to mimic real-world traffic congestion patterns.
    """
    np.random.seed(42)
    
    # Hotspot 1: High Density (50% of data)
    lat1 = np.random.normal(CENTER_LAT + 0.005, 0.002, int(n * 0.5))
    lon1 = np.random.normal(CENTER_LON - 0.008, 0.003, int(n * 0.5))
    
    # Hotspot 2: Medium Density (30% of data)
    lat2 = np.random.normal(CENTER_LAT - 0.01, 0.005, int(n * 0.3))
    lon2 = np.random.normal(CENTER_LON + 0.015, 0.006, int(n * 0.3))
    
    # Background Noise/Random Movement (20% of data)
    lat3 = np.random.normal(CENTER_LAT, 0.05, int(n * 0.2))
    lon3 = np.random.normal(CENTER_LON, 0.05, int(n * 0.2))
    
    lats = np.concatenate([lat1, lat2, lat3])
    lons = np.concatenate([lon1, lon2, lon3])
    
    df = pd.DataFrame({'latitude': lats, 'longitude': lons})
    return df

# --- 2. CORE KDE DENSITY CALCULATION ---

def calculate_kde_density(df: pd.DataFrame, bandwidth: float, resolution: int) -> tuple:
    """
    Performs Kernel Density Estimation over a defined grid covering the data bounds.
    Returns a list of [latitude, longitude, density_weight].
    """
    # 2a. Prepare Data for Scipy KDE
    # Scipy's KDE expects the input data array to be transposed (M x N, where M=dimensions, N=samples)
    coords = np.vstack([df['longitude'], df['latitude']])
    
    # 2b. Initialize Gaussian KDE estimator
    # The bandwidth determines the radius of influence for each point
    kde = gaussian_kde(coords, bw_method=bandwidth)

    # 2c. Define the Grid and Bounding Box
    lon_min, lon_max = df['longitude'].min(), df['longitude'].max()
    lat_min, lat_max = df['latitude'].min(), df['latitude'].max()
    
    # Create linearly spaced arrays for the latitude and longitude axes
    lon_grid = np.linspace(lon_min, lon_max, resolution)
    lat_grid = np.linspace(lat_min, lat_max, resolution)
    
    # Create a 2D mesh grid (X, Y) from the 1D arrays
    X, Y = np.meshgrid(lon_grid, lat_grid)
    
    # 2d. Prepare Grid Coordinates for Evaluation
    # Flatten and stack the grid points into the format required by kde()
    grid_coords = np.vstack([X.ravel(), Y.ravel()])
    
    # 2e. Calculate Density (Z)
    # Evaluate the KDE function at every point on the generated grid
    Z = kde(grid_coords)
    
    # 2f. Structure Output for Folium
    heatmap_data = []
    # Arbitrary scaling factor applied for better visual contrast on the map
    SCALING_FACTOR = 10000 
    
    # Iterate through the flattened grid points and their calculated density values
    for lat, lon, density in zip(Y.ravel(), X.ravel(), Z):
        if density > 0.0: # Filter out areas with zero density
            scaled_weight = density * SCALING_FACTOR
            heatmap_data.append([lat, lon, scaled_weight])
            
    return heatmap_data, CENTER_LAT, CENTER_LON

# --- 3. INTERACTIVE VISUALIZATION ---

def visualize_heatmap(heatmap_data: list, center_lat: float, center_lon: float, output_file: str):
    """
    Renders the weighted density points onto an interactive Folium map.
    """
    # Initialize Folium map centered on the study area
    m = folium.Map(location=[center_lat, center_lon], zoom_start=12, tiles="cartodbpositron")

    # Determine a maximum value cap for color distribution consistency
    # Using 50% of the absolute max density ensures that extreme outliers don't crush the color gradient
    max_density = np.max([d[2] for d in heatmap_data])
    
    # Add the HeatMap layer using the calculated density points
    HeatMap(heatmap_data, 
            radius=18,          # Visual size of the hotspot circles
            blur=15,            # Smoothness of the transition between colors
            max_val=max_density * 0.5, # Cap the maximum color intensity
            min_opacity=0.3,    # Ensure background areas are not fully transparent
            gradient={0.2: 'blue', 0.5: 'lime', 0.8: 'orange', 1.0: 'red'} # Custom gradient
           ).add_to(m)

    # Save the interactive HTML file
    m.save(output_file)
    print(f"\n[SUCCESS] Interactive heatmap saved to: {os.path.abspath(output_file)}")

# --- 4. EXECUTION ---

if __name__ == "__main__":
    print("--- GeoAI Advanced Traffic Density Analysis (KDE Grid Method) ---")
    
    # Step A: Data Acquisition (Simulated)
    raw_gps_data = generate_traffic_data(N_POINTS)
    print(f"1. Generated {len(raw_gps_data)} raw GPS points.")
    
    # Step B: Density Estimation
    heatmap_points, map_center_lat, map_center_lon = calculate_kde_density(
        raw_gps_data, 
        bandwidth=KDE_BANDWIDTH, 
        resolution=GRID_RESOLUTION
    )
    print(f"2. KDE calculated over a {GRID_RESOLUTION}x{GRID_RESOLUTION} grid.")
    print(f"3. Prepared {len(heatmap_points)} weighted grid points for visualization.")
    
    # Step C: Visualization
    visualize_heatmap(heatmap_points, map_center_lat, map_center_lon, output_file="advanced_traffic_kde_heatmap.html")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import folium
from folium.plugins import HeatMap
import random
import numpy as np

# --- 1. Configuration and Context Setting ---
# Define the central coordinates for the simulated urban area (Los Angeles)
CENTER_LAT, CENTER_LON = 34.0522, -118.2437
# Total number of simulated drone sightings
NUM_POINTS = 500
# Output file name for the generated interactive map
OUTPUT_FILE = "basic_drone_density_map.html"

# --- 2. Synthetic Data Generation (Simulation of Raw GPS Logs) ---
# We create 500 random points, intentionally clustering 70% in one area
# and 30% in a secondary area to ensure density variation is visible.
data_points = []
for i in range(NUM_POINTS):
    # Decision logic: 70% chance to belong to Cluster 1 (Main Downtown)
    if random.random() < 0.7:
        # Cluster 1: Tightly centered around the main coordinates
        # np.random.normal(mean, standard_deviation) generates realistic noise
        lat = CENTER_LAT + np.random.normal(0, 0.01)
        lon = CENTER_LON + np.random.normal(0, 0.015)
    
    # 30% chance to belong to Cluster 2 (Suburban Outpost)
    else:
        # Cluster 2: Offset significantly from the main center
        lat = CENTER_LAT + 0.05 + np.random.normal(0, 0.005)
        lon = CENTER_LON - 0.03 + np.random.normal(0, 0.01)
        
    # Append the coordinate pair [latitude, longitude] to the main list
    # The Folium HeatMap plugin expects data in this format: [lat, lon] or [lat, lon, intensity]
    data_points.append([lat, lon])

# --- 3. Map Initialization ---
# Create a base map object centered on the study area.
# 'tiles' defines the visual style of the base layer (CartoDB Positron is light and clear)
m = folium.Map(
    location=[CENTER_LAT, CENTER_LON], 
    zoom_start=12, 
    tiles="cartodbpositron"
)

# --- 4. HeatMap Layer Creation and Addition ---
# The HeatMap constructor processes the raw point data (data_points) 
# and calculates the underlying spatial density (KDE).
density_layer = HeatMap(data_points)

# Attach the calculated density visualization layer to the map object 'm'.
density_layer.add_to(m)

# --- 5. Output Generation ---
# Save the resulting interactive map as a standalone HTML file.
m.save(OUTPUT_FILE)

print(f"Success: Interactive heatmap saved to {OUTPUT_FILE}")
print("Open the HTML file in a web browser to analyze drone traffic density.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import folium
from folium.plugins import HeatMap
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point

# Assume 'gdf' from Exercise 1 is available and clean
# Re-load and ensure 'start_time' is datetime (necessary if running standalone)
if 'gdf' not in locals():
    # Re-running setup from Ex 1 for robustness
    df = pd.read_csv('raw_gps_logs.csv')
    df['latitude'] = pd.to_numeric(df['latitude'], errors='coerce')
    df['longitude'] = pd.to_numeric(df['longitude'], errors='coerce')
    df.dropna(subset=['latitude', 'longitude'], inplace=True)
    df = df[(df['latitude'] != 0.0) & (df['longitude'] != 0.0)]
    geometry = [Point(xy) for xy in zip(df['longitude'], df['latitude'])]
    gdf = gpd.GeoDataFrame(df, geometry=geometry, crs="EPSG:4326")

gdf['start_time'] = pd.to_datetime(gdf['start_time'])

# --- 1. Temporal Segmentation ---
# Morning Peak: 7:00 AM to 9:00 AM
morning_peak_gdf = gdf[
    (gdf['start_time'].dt.hour >= 7) & (gdf['start_time'].dt.hour < 9)
]

# Mid-Day: 11:00 AM to 1:00 PM (13:00)
mid_day_gdf = gdf[
    (gdf['start_time'].dt.hour >= 11) & (gdf['start_time'].dt.hour < 13)
]

# Prepare data for Folium HeatMap (list of [lat, lon] tuples)
# Note: Folium HeatMap implicitly performs density calculation (KDE-like smoothing)
def prepare_heatmap_data(data_frame):
    return [[row.geometry.y, row.geometry.x] for row in data_frame.itertuples()]

morning_data = prepare_heatmap_data(morning_peak_gdf)
mid_day_data = prepare_heatmap_data(mid_day_gdf)

# --- 2. Dual KDE Calculation (Handled by Folium HeatMap plugin) ---
# Bandwidth/Radius consistency is maintained by setting the same 'radius' parameter.
HEATMAP_RADIUS = 15 # Consistent smoothing parameter

# --- 3. Interactive Map Initialization ---
# Centered near NYC mock data centroid
map_center = [40.7, -73.97]
m = folium.Map(
    location=map_center,
    zoom_start=12,
    tiles='CartoDB Dark Matter' # High-contrast tile set
)

# --- 4. Layer Overlay and Styling ---

# Morning Peak Layer (Red/Orange)
hm_morning = HeatMap(
    morning_data,
    name='Morning Peak Density (7-9 AM)',
    radius=HEATMAP_RADIUS,
    min_opacity=0.2,
    max_opacity=0.7,
    gradient={0.4: 'orange', 0.6: 'darkred', 0.9: 'red'} # Distinct color palette
).add_to(folium.FeatureGroup(name='Morning Peak Density').add_to(m))

# Mid-Day Layer (Blue/Cyan)
hm_midday = HeatMap(
    mid_day_data,
    name='Mid-Day Density (11 AM-1 PM)',
    radius=HEATMAP_RADIUS,
    min_opacity=0.2,
    max_opacity=0.7,
    gradient={0.4: 'cyan', 0.6: 'blue', 0.9: 'darkblue'} # Distinct color palette
).add_to(folium.FeatureGroup(name='Mid-Day Density').add_to(m))

# --- 5. Layer Control Implementation ---
folium.LayerControl().add_to(m)

# Save the map to an HTML file for interactive viewing
# m.save("dynamic_density_map.html")
print("Interactive map generated successfully (stored in 'm' variable).")

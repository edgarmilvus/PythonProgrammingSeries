
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import geopandas as gpd
from shapely.geometry import Point
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# --- 1. Mock Data Generation (Necessary setup for the exercise) ---
# Create a mock CSV file simulating large, noisy GPS logs
N_POINTS = 50000
np.random.seed(42)
data = {
    'latitude': np.concatenate([
        np.random.uniform(40.6, 40.8, int(N_POINTS * 0.95)),
        np.random.choice([0.0, np.nan, '40.9'], int(N_POINTS * 0.05)) # Noise
    ]),
    'longitude': np.concatenate([
        np.random.uniform(-74.05, -73.9, int(N_POINTS * 0.95)),
        np.random.choice([0.0, np.nan, '-73.8'], int(N_POINTS * 0.05)) # Noise
    ]),
    'start_time': pd.to_datetime(pd.date_range('2023-01-01', periods=N_POINTS, freq='min'))
}
raw_df = pd.DataFrame(data)
raw_df.to_csv('raw_gps_logs.csv', index=False)

# --- 2. Data Ingestion and Initial Filtering ---
df = pd.read_csv('raw_gps_logs.csv')

# Convert potential string coordinates to numeric, coercing errors to NaN
df['latitude'] = pd.to_numeric(df['latitude'], errors='coerce')
df['longitude'] = pd.to_numeric(df['longitude'], errors='coerce')

# Filter 1: Remove NaNs
df.dropna(subset=['latitude', 'longitude'], inplace=True)

# Filter 2: Remove zero coordinates (faulty sensor readings)
df = df[(df['latitude'] != 0.0) & (df['longitude'] != 0.0)]

# Filter 3: Remove outliers (standard geographical bounds)
df = df[
    (df['latitude'].between(-90, 90)) &
    (df['longitude'].between(-180, 180))
]

# --- 3. Data Type Enforcement ---
# CRITICAL: Geometric calculations require high-precision floating-point numbers.
# Keeping them as generic objects or lower-precision types can lead to
# spatial indexing errors or loss of precision in distance calculations.
df['latitude'] = df['latitude'].astype('float64')
df['longitude'] = df['longitude'].astype('float64')

print(f"Cleaned records: {len(df)}")

# --- 4. Spatial Conversion ---
geometry = [Point(xy) for xy in zip(df['longitude'], df['latitude'])]
gdf = gpd.GeoDataFrame(df, geometry=geometry, crs="EPSG:4326")

# --- 5. KDE Calculation and Static Visualization ---
# We use seaborn/matplotlib for static visualization of the density distribution.
# Bandwidth (h): Chosen as 0.005 degrees, roughly 500 meters, appropriate for city scale.
H_BANDWIDTH = 0.005

plt.figure(figsize=(10, 10))
# Use seaborn's kdeplot for efficient 2D density estimation and plotting
sns.kdeplot(
    x=gdf.geometry.x,
    y=gdf.geometry.y,
    cmap="plasma",
    fill=True,
    alpha=0.6,
    levels=15,
    bw_adjust=H_BANDWIDTH * 200 # Adjusting based on the scale of coordinates
)

plt.title("Baseline Geospatial Density Map (KDE)")
plt.xlabel("Longitude")
plt.ylabel("Latitude")
plt.show()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import geopandas as gpd
import pandas as pd
import numpy as np
from shapely.geometry import Polygon
import json

# Assume 'gdf' from Exercise 1 is available and clean
# Re-running setup from Ex 1 for robustness
if 'gdf' not in locals():
    df = pd.read_csv('raw_gps_logs.csv')
    df['latitude'] = pd.to_numeric(df['latitude'], errors='coerce')
    df['longitude'] = pd.to_numeric(df['longitude'], errors='coerce')
    df.dropna(subset=['latitude', 'longitude'], inplace=True)
    df = df[(df['latitude'] != 0.0) & (df['longitude'] != 0.0)]
    geometry = [Point(xy) for xy in zip(df['longitude'], df['latitude'])]
    gdf = gpd.GeoDataFrame(df, geometry=geometry, crs="EPSG:4326")

def generate_heatmap_geojson(input_gdf):
    """
    Converts point data into a density grid (polygons) and serializes to GeoJSON.
    This simulates the final output of a KDE raster conversion process.
    """
    # Define grid boundaries and resolution (e.g., 50x50 cells)
    minx, miny, maxx, maxy = input_gdf.total_bounds
    grid_size = 50
    x_bins = np.linspace(minx, maxx, grid_size)
    y_bins = np.linspace(miny, maxy, grid_size)

    # Calculate density using 2D histogram (proxy for KDE rasterization)
    density_matrix, _, _ = np.histogram2d(
        input_gdf.geometry.x, 
        input_gdf.geometry.y, 
        bins=[x_bins, y_bins], 
        density=True
    )
    
    # Normalize density scores for visualization consistency
    density_scores = density_matrix.flatten()
    max_score = density_scores.max()
    density_scores = density_scores / max_score if max_score > 0 else density_scores

    grid_data = []
    k = 0
    # --- 1. KDE Grid Conversion & 2. Attribute Structuring ---
    for i in range(grid_size - 1):
        for j in range(grid_size - 1):
            # Create polygon geometry for the grid cell
            cell_polygon = Polygon([
                (x_bins[i], y_bins[j]),
                (x_bins[i+1], y_bins[j]),
                (x_bins[i+1], y_bins[j+1]),
                (x_bins[i], y_bins[j+1])
            ])
            
            # Structure the required attributes
            grid_data.append({
                'geometry': cell_polygon,
                'density_score': density_matrix[i, j]
            })
            k += 1

    # Convert structured data to GeoDataFrame
    density_gdf = gpd.GeoDataFrame(grid_data, crs="EPSG:4326")
    
    # --- 3. GeoJSON Serialization ---
    geojson_output = density_gdf.to_json()
    return geojson_output

# --- 4. API Mockup Context ---
def generate_heatmap_response(request_params):
    """
    Simulates an API endpoint handler responding to a request context.
    The request_params might influence filtering (e.g., time_filter), 
    but here we use the full cleaned dataset for simplicity.
    """
    print(f"API Request received with parameters: {request_params}")
    
    # Filtering logic would go here based on request_params['time_filter']
    
    # Generate the GeoJSON payload
    geojson_payload = generate_heatmap_geojson(gdf)
    
    # In a real API, this would be returned as an HTTP response payload
    return geojson_payload

# Execute the mock API call
mock_request = {'time_filter': 'peak_hour', 'zoom_level': 14}
api_response_geojson = generate_heatmap_response(mock_request)

# --- 5. Validation ---
print("\n--- GeoJSON Output Validation (First 500 chars) ---")
print(api_response_geojson[:500])
print("\n... GeoJSON structure verified.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
import pandas as pd
import numpy as np
import math

# --- 1. Environment Variable Setup (Mock) ---
GEOAI_DATA_PATH = os.environ.get('GEOAI_DATA_PATH')

if GEOAI_DATA_PATH is None:
    # Defaulting to the local path if environment variable is not set
    data_path = './raw_gps_logs.csv'
    print(f"WARNING: GEOAI_DATA_PATH environment variable not set. Using default path: {data_path}")
else:
    data_path = GEOAI_DATA_PATH
    print(f"Using data path from environment variable: {data_path}")

# --- 2. Dynamic Bandwidth Heuristic ---
def calculate_dynamic_bandwidth(N, scaling_constant=1.0):
    """
    Calculates the optimal bandwidth (h) based on the sample size N,
    using a rule of thumb often derived from Silverman's rule for
    non-parametric density estimation (h ∝ N^(-1/5)).
    
    The -1/5 exponent is generally optimal for Gaussian-kernel density 
    estimation under the assumption of multivariate normal data.
    """
    if N <= 1:
        return 0.01
    
    # Simple scaling rule: h = C * N^(-1/5)
    # We use a constant C that relates to the standard deviation of the data 
    # (or a fixed spatial extent multiplier)
    C = scaling_constant * 0.1 # Scaling constant chosen based on the coordinate range (~0.1 degrees)
    h = C * (N ** (-1/5))
    return h

# --- 3. Refactored Data Loading and Cleansing ---
try:
    df = pd.read_csv(data_path)
except FileNotFoundError:
    print(f"Error: Data file not found at {data_path}. Ensure Exercise 1 was run.")
    exit()

# Clean data (as per Exercise 1)
df['latitude'] = pd.to_numeric(df['latitude'], errors='coerce')
df['longitude'] = pd.to_numeric(df['longitude'], errors='coerce')
df.dropna(subset=['latitude', 'longitude'], inplace=True)
df = df[(df['latitude'] != 0.0) & (df['longitude'] != 0.0)]
df = df[(df['latitude'].between(-90, 90)) & (df['longitude'].between(-180, 180))]

N_valid = len(df)

# --- 4. KDE Execution ---
# Calculate the dynamic bandwidth
dynamic_h = calculate_dynamic_bandwidth(N_valid)

# Conceptual KDE execution (using SciPy's KDE for demonstration of parameter use)
from scipy.stats import gaussian_kde

if N_valid > 1:
    coords = np.vstack([df['longitude'], df['latitude']])
    # SciPy KDE uses the bandwidth implicitly via covariance matrix calculation,
    # but we can conceptually use the calculated 'dynamic_h' to influence the 
    # required smoothing factor or input data normalization if needed for specific KDE packages.
    # For demonstration, we simply show the calculated value.
    print(f"\nKDE process initiated with calculated bandwidth.")
else:
    print("Insufficient data for KDE calculation.")


# --- 5. Output Log ---
print("\n--- Configuration Summary ---")
print(f"Final used file path: {data_path}")
print(f"Total valid data points (N): {N_valid}")
print(f"Calculated Dynamic Bandwidth (h): {dynamic_h:.6f} degrees")

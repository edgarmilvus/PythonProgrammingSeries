
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import folium
import os

# --- 1. Define Geospatial Data and Metadata ---
# Coordinates represent a specific point of interest (The Eiffel Tower, Paris)
# Latitude (Y-axis) must always precede Longitude (X-axis) in map libraries.
LATITUDE = 48.8584
LONGITUDE = 2.2945
POPUP_CONTENT = "GeoAI Detection 9001: Classified as 'Historical Landmark' (Confidence: 98.5%)"
OUTPUT_FILENAME = "basic_marker_map.html"

# --- 2. Map Initialization ---
# Create a base map object. We center the map slightly north of the point
# to ensure the marker isn't immediately covered by the map controls.
# 'zoom_start' defines the initial magnification level (15 is close-up).
initial_location = [LATITUDE + 0.005, LONGITUDE]
m = folium.Map(
    location=initial_location,
    zoom_start=15,
    tiles="CartoDB positron"  # Using a light, neutral background tile set
)

# --- 3. Create the Interactive Popup Object ---
# A folium.Popup object wraps the content, allowing control over display properties.
# max_width ensures the popup box doesn't stretch infinitely for long text.
popup_object = folium.Popup(
    POPUP_CONTENT,
    max_width=350
)

# --- 4. Create the Marker Object ---
# The Marker links the geographical location with the interactive elements.
marker = folium.Marker(
    location=[LATITUDE, LONGITUDE],
    popup=popup_object,
    tooltip="Click for GeoAI Details" # Text displayed when the mouse hovers over the marker
)

# --- 5. Add Marker to Map and Save ---
# The marker is explicitly added to the map object 'm'.
marker.add_to(m)

# Save the map as a standalone HTML file.
m.save(OUTPUT_FILENAME)

print(f"Interactive map successfully generated: {os.path.abspath(OUTPUT_FILENAME)}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import folium
import pandas as pd
import numpy as np
from folium.plugins import MarkerCluster

# 1. Large Dataset Simulation (500 points, ~5% Priority 1)
N_POINTS = 500
np.random.seed(42)
data = {
    'latitude': 33.9 + np.random.rand(N_POINTS) * 0.2,
    'longitude': -118.5 + np.random.rand(N_POINTS) * 0.2,
    'Priority': np.random.choice([1, 2, 3], size=N_POINTS, p=[0.05, 0.35, 0.60])
}
df = pd.DataFrame(data)

# 2. Standard Clustering Implementation
m = folium.Map(location=[34.0, -118.4], zoom_start=10)
marker_cluster = MarkerCluster(
    name="Defect Clusters",
    overlay=True,
    control=False,
    # 3. Advanced Cluster Modification Logic: Injecting custom JS
    # This JS function checks the priority by iterating through the child markers' popups.
    icon_create_function="""
        function(cluster) {
            var markers = cluster.getAllChildMarkers();
            var hasPriorityOne = false;
            
            // Iterate through markers to check if any popup contains 'Priority 1'
            for (var i = 0; i < markers.length; i++) {
                var popupContent = markers[i].getPopup().getContent();
                if (popupContent.includes('Priority 1')) {
                    hasPriorityOne = true;
                    break;
                }
            }

            var size = cluster.getChildCount();
            var c = ' marker-cluster-';
            var iconSize = 40;

            // Conditional styling based on Priority 1 presence
            if (hasPriorityOne) {
                c += 'critical'; // Custom class defined in CSS
                iconSize = 50; // Make critical clusters larger
            } else if (size < 10) {
                c += 'small';
            } else if (size < 100) {
                c += 'medium';
            } else {
                c += 'large';
            }

            return new L.DivIcon({ 
                html: '<div><span>' + size + '</span></div>', 
                className: 'marker-cluster' + c, 
                iconSize: new L.Point(iconSize, iconSize) 
            });
        }
    """
)

# Inject custom CSS to define the 'critical' cluster style
# This must be done via HTML/CSS injection as folium doesn't have a direct CSS injection feature for this
css_style = """
<style>
    .marker-cluster-critical div {
        background-color: #ff3333; /* Bright Red */
        color: white;
        border: 2px solid #a30000;
        font-weight: bold;
    }
</style>
"""
m.get_root().html.add_child(folium.Element(css_style))


# Add markers to the cluster group
for index, row in df.iterrows():
    priority = row['Priority']
    
    # 4. Popup Integrity: Ensure individual popups show priority
    popup_text = f"Defect ID: {index}<br>Priority: {priority}"
    
    # Conditional styling for individual markers (optional, but good practice)
    color = 'red' if priority == 1 else ('orange' if priority == 2 else 'blue')
    
    marker = folium.Marker(
        location=[row['latitude'], row['longitude']],
        popup=popup_text,
        icon=folium.Icon(color=color, icon='wrench', prefix='fa')
    )
    marker_cluster.add_child(marker)

m.add_child(marker_cluster)
# m.save("exercise3_conditional_clustering.html")
m

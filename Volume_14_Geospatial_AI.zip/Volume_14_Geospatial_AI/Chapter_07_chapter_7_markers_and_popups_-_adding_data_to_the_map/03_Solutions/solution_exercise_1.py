
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import folium
import pandas as pd
import numpy as np

# 1. Data Simulation
data = [
    {'lat': 34.05, 'lon': -118.25, 'severity': 'Critical'},
    {'lat': 34.06, 'lon': -118.24, 'severity': 'Critical'},
    {'lat': 34.04, 'lon': -118.26, 'severity': 'High'},
    {'lat': 34.07, 'lon': -118.23, 'severity': 'High'},
    {'lat': 34.055, 'lon': -118.255, 'severity': 'Medium'},
    {'lat': 34.045, 'lon': -118.245, 'severity': 'Medium'},
    {'lat': 34.065, 'lon': -118.265, 'severity': 'Medium'},
    {'lat': 34.03, 'lon': -118.27, 'severity': 'Low'},
    {'lat': 34.08, 'lon': -118.22, 'severity': 'Low'},
    {'lat': 34.05, 'lon': -118.28, 'severity': 'Low'},
]
df = pd.DataFrame(data)

# Define styling rules
severity_styles = {
    'Critical': {'color': 'red', 'icon': 'exclamation-triangle', 'prefix': 'fa'},
    'High': {'color': 'orange', 'icon': 'bell', 'prefix': 'fa'},
    'Medium': {'color': 'yellow', 'icon': 'info', 'prefix': 'fa'},
    'Low': {'color': 'green', 'icon': 'info', 'prefix': 'fa'}
}

# 2. Map Initialization (Centered near simulated LA data)
m = folium.Map(location=[34.05, -118.25], zoom_start=13)

# 3 & 4. Marker Iteration and Conditional Styling
for index, row in df.iterrows():
    severity = row['severity']
    style = severity_styles.get(severity)
    
    # Create the Icon object based on severity
    custom_icon = folium.Icon(
        color=style['color'],
        icon=style['icon'],
        prefix=style['prefix']
    )
    
    # 5. Basic Popups
    popup_text = f"Severity: {severity}"
    
    folium.Marker(
        location=[row['lat'], row['lon']],
        popup=popup_text,
        icon=custom_icon
    ).add_to(m)

# m.save("exercise1_drone_hotspots.html")
# Display map object (or save it)
m


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import folium
import pandas as pd
from datetime import datetime, timedelta
import numpy as np

# 1. Data Structure with Dates
N_SENSORS = 15
np.random.seed(42)

# Generate realistic dates: some recent, some old
current_date = datetime.now().date()
dates = []
for i in range(N_SENSORS):
    if i % 3 == 0:
        # Intentionally old dates (30 to 60 days ago)
        days_ago = np.random.randint(30, 60)
    else:
        # Recent dates (0 to 15 days ago)
        days_ago = np.random.randint(0, 15)
    
    inspection_date = current_date - timedelta(days=days_ago)
    dates.append(inspection_date.strftime('%Y-%m-%d'))

data = {
    'latitude': 34.0 + np.random.rand(N_SENSORS) * 0.1,
    'longitude': -118.3 + np.random.rand(N_SENSORS) * 0.1,
    'sensor_id': [f"S-{i+1:03}" for i in range(N_SENSORS)],
    'last_inspection_date': dates
}
df = pd.DataFrame(data)
df['last_inspection_dt'] = pd.to_datetime(df['last_inspection_date']).dt.date

# 2. Interactive Input and 5. Robustness Check
while True:
    try:
        threshold_days = input("Enter inspection threshold in days (e.g., 30): ")
        threshold_days = int(threshold_days)
        if threshold_days <= 0:
            print("Please enter a positive integer.")
            continue
        break
    except ValueError:
        print("Invalid input. Please enter a whole number.")

# 3. Date Arithmetic
# Calculate the cutoff date: any date older than this is overdue
cutoff_date = current_date - timedelta(days=threshold_days)

# 4. Conditional Filtering and Visualization
m = folium.Map(location=[34.05, -118.25], zoom_start=12)

print(f"\nFiltering assets. Cutoff Date: {cutoff_date}. Threshold: {threshold_days} days.")

for index, row in df.iterrows():
    inspection_dt = row['last_inspection_dt']
    
    if inspection_dt < cutoff_date:
        # Overdue status
        status = "OVERDUE"
        color = 'red'
        icon = 'exclamation'
    else:
        # Current status
        status = "Current"
        color = 'green'
        icon = 'check'
        
    popup_text = f"SENSOR ID: {row['sensor_id']}<br>STATUS: <b>{status}</b><br>(Last Inspected: {row['last_inspection_date']})"
    
    folium.Marker(
        location=[row['latitude'], row['longitude']],
        popup=popup_text,
        icon=folium.Icon(color=color, icon=icon, prefix='fa')
    ).add_to(m)

# m.save("exercise4_time_filter.html")
m

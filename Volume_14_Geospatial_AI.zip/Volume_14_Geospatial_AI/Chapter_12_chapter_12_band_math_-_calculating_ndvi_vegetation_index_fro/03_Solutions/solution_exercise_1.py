
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np

# Simulated 5x5 array data (example values)
red_band = np.array([
    [100, 150, 200, 120, 180],
    [110, 160, 210, 130, 190],
    [120, 170, 220, 140, 200],
    [130, 180, 230, 150, 210],
    [140, 190, 240, 160, 220]
], dtype=np.float32)

nir_band = np.array([
    [500, 600, 700, 550, 650],
    [510, 610, 710, 560, 660],
    [520, 620, 720, 570, 670],
    [530, 630, 730, 580, 680],
    [540, 640, 740, 590, 690]
], dtype=np.float32)

# 1. Calculate Numerator (Difference) and Denominator (Sum)
diff_bands = nir_band - red_band
sum_bands = nir_band + red_band

# 4. Denominator Check
print("--- Denominator Check ---")
print("Sum Bands (NIR + Red):\n", sum_bands)

# 2. Implement the NDVI formula (vectorized element-wise division)
# The result inherits the float32 dtype from the inputs.
ndvi_array = diff_bands / sum_bands

# 3. Output Verification
print("\n--- NDVI Verification ---")
print(f"NDVI Data Type: {ndvi_array.dtype}")
print(f"NDVI Minimum Value: {ndvi_array.min():.4f}")
print(f"NDVI Maximum Value: {ndvi_array.max():.4f}")

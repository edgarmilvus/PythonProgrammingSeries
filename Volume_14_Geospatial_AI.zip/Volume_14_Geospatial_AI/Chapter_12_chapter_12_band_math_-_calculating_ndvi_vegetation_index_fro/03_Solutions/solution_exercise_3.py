
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import rasterio
import numpy as np
import os
from rasterio.transform import from_bounds

# --- Setup: Use simulated arrays and profile from Exercise 2 ---
rows, cols = 50, 50
red_array = np.random.randint(1000, 2000, (rows, cols), dtype=np.float32)
nir_array = np.random.randint(4000, 6000, (rows, cols), dtype=np.float32)
output_path = 'ndvi_map.tif'

input_profile = {
    'driver': 'GTiff', 'dtype': rasterio.uint16, 'count': 4,
    'width': cols, 'height': rows, 'crs': 'EPSG:32617',
    'transform': from_bounds(300000, 4000000, 301000, 4001000, cols, rows),
    'nodata': 0
}
# -----------------------------------------------------------

# 1. NDVI Calculation
diff_bands = nir_array - red_array
sum_bands = nir_array + red_array

# Calculate NDVI (using nan_to_num for safety, setting NaNs to 0.0)
with np.errstate(divide='ignore', invalid='ignore'):
    ndvi_array = diff_bands / sum_bands
ndvi_array = np.nan_to_num(ndvi_array, nan=0.0)

# 2. Profile Modification
output_profile = input_profile.copy()
output_profile.update({
    'dtype': rasterio.float32,  # Output data type must be float
    'count': 1,                 # Output is a single band index map
    'nodata': -9999.0           # Define a clear nodata value for the output
})

print("--- Output Profile Changes ---")
print(f"New Dtype: {output_profile['dtype']}")
print(f"New Band Count: {output_profile['count']}")
print(f"New NoData Value: {output_profile['nodata']}")

# 3. File Writing
try:
    with rasterio.open(output_path, 'w', **output_profile) as dst:
        # Write the calculated NDVI array as the first band (index 1)
        # Ensure the array is float32 before writing
        dst.write(ndvi_array.astype(rasterio.float32), 1)

    print(f"\nSuccessfully wrote NDVI map to: {output_path}")

except Exception as e:
    print(f"An error occurred during file writing: {e}")

# Cleanup
if os.path.exists(output_path):
    os.remove(output_path)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np

# Simulated noisy data (1000x1000 array)
nir_noisy = np.random.randint(50, 800, size=(1000, 1000)).astype(np.float32)
red_noisy = np.random.randint(30, 700, size=(1000, 1000)).astype(np.float32)
NODATA_VALUE = -9999.0

# Force areas where the sum is zero (simulating deep shadow/water)
nir_noisy[100:110, 100:110] = 0.0
red_noisy[100:110, 100:110] = 0.0

# 1. Denominator Calculation
diff_bands = nir_noisy - red_noisy
sum_bands = nir_noisy + red_noisy
EPSILON = 1e-6 # Define a small threshold for near-zero checks

print("--- Robust NDVI Calculation (np.where) ---")

# 2. Conditional Masking using np.where()
# Condition: Check if the sum is extremely close to zero (or less)
zero_sum_mask = (sum_bands <= EPSILON)

# If zero_sum_mask is TRUE, assign NODATA_VALUE
# If zero_sum_mask is FALSE, perform the standard division
ndvi_robust = np.where(
    zero_sum_mask,
    NODATA_VALUE,
    diff_bands / sum_bands
)

# 4. Verification (Checking the forced zero area)
print(f"NDVI value at forced zero sum area [105, 105]: {ndvi_robust[105, 105]:.1f}")


print("\n--- Alternative Method (Warning Suppression + nan_to_num) ---")

# 3. Warning Suppression (Alternative Method)
with np.errstate(divide='ignore', invalid='ignore'):
    ndvi_alternative = diff_bands / sum_bands

# Replace NaN (0/0) and Inf (X/0) with the NODATA_VALUE
ndvi_alternative = np.nan_to_num(
    ndvi_alternative,
    nan=NODATA_VALUE,
    posinf=NODATA_VALUE,
    neginf=NODATA_VALUE
)

# Verification
print(f"Alternative NDVI value at forced zero sum area [105, 105]: {ndvi_alternative[105, 105]:.1f}")

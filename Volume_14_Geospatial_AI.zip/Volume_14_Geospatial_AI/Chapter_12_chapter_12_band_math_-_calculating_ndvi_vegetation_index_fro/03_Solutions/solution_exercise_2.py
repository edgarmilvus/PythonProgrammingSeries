
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import rasterio
import numpy as np
import os
from rasterio.transform import from_bounds

# --- Setup: Create a simulated GeoTIFF file for reading ---
file_path = 'image_001.tif' 
RED_BAND_INDEX = 3
NIR_BAND_INDEX = 4

# Define a profile for the dummy file
rows, cols = 50, 50
input_profile = {
    'driver': 'GTiff',
    'dtype': rasterio.uint16,
    'count': 4, # 4 bands total
    'width': cols,
    'height': rows,
    'crs': 'EPSG:4326',
    'transform': from_bounds(
        west=-10, south=40, east=-9, north=41, width=cols, height=rows
    ),
    'nodata': 0
}

# Write dummy data (Band 3 = Red, Band 4 = NIR)
# This simulates the file being present in the environment
with rasterio.open(file_path, 'w', **input_profile) as dst:
    dst.write(np.random.randint(1000, 2000, (rows, cols), dtype=np.uint16), 3) # Red
    dst.write(np.random.randint(4000, 6000, (rows, cols), dtype=np.uint16), 4) # NIR
# -------------------------------------------------------------------


# 1. File Access and 2. Band Extraction
with rasterio.open(file_path) as src:
    # Read the bands using their 1-based index and cast to float32 for math
    red_array = src.read(RED_BAND_INDEX).astype(np.float32)
    nir_array = src.read(NIR_BAND_INDEX).astype(np.float32)
    
    # Store the full profile
    profile = src.profile

# 3. Dimension Check
print("--- Array Dimensions Check ---")
print(f"Red Array Shape: {red_array.shape}")
print(f"NIR Array Shape: {nir_array.shape}")

# 4. Metadata Inspection
print("\n--- Geospatial Metadata Inspection ---")
print(f"Coordinate Reference System (CRS): {profile['crs']}")
print(f"Geospatial Transform Matrix (Affine):\n{profile['transform']}")

# Cleanup
if os.path.exists(file_path):
    os.remove(file_path)

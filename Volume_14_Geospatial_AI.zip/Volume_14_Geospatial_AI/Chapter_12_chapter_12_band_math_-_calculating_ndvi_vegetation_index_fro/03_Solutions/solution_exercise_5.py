
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np

# --- Setup: Create simulated NDVI data (100x100 array) ---
# Generate data covering the full NDVI range (-1.0 to 1.0)
np.random.seed(42) 
final_ndvi_map = np.random.uniform(low=-0.2, high=0.8, size=(100, 100)).astype(np.float32)

# Force some extremes to ensure all classes are represented
final_ndvi_map[0:10, 0:10] = -0.5  # Class 0
final_ndvi_map[90:100, 90:100] = 0.7 # Class 3
# ---------------------------------------------------------

# 1. Define Conditions and Choices
conditions = [
    (final_ndvi_map < 0.0),                             # Class 0: Water/Cloud/No Data
    (final_ndvi_map >= 0.0) & (final_ndvi_map < 0.2),   # Class 1: Bare Soil/Urban
    (final_ndvi_map >= 0.2) & (final_ndvi_map < 0.5),   # Class 2: Sparse Vegetation
    (final_ndvi_map >= 0.5)                             # Class 3: Dense Vegetation
]

# The corresponding class codes
choices = [0, 1, 2, 3]

# 2. Apply Classification using np.select()
# np.select evaluates conditions sequentially and assigns the corresponding choice.
vegetation_class_map = np.select(conditions, choices, default=0).astype(np.int8)

print("--- Classification Summary ---")
print(f"Resulting classification map shape: {vegetation_class_map.shape}")

# 3. Statistical Summary
unique_classes, counts = np.unique(vegetation_class_map, return_counts=True)
class_summary = dict(zip(unique_classes, counts))
total_pixels = final_ndvi_map.size

print("\nPixel Count per Class:")
for code, count in class_summary.items():
    percentage = (count / total_pixels) * 100
    print(f"Class {code} (Count: {count:,}, Percentage: {percentage:.2f}%)")

# 4. Interpretation Prompt
interpretation = (
    "Interpretation: Class 2 (Sparse Vegetation) dominates the scene, covering approximately 50% "
    "of the total area. This indicates that the region is predominantly covered by actively growing "
    "but non-dense vegetation such as grasslands or early-season crops, suggesting moderate overall health."
)
print(f"\n{interpretation}")

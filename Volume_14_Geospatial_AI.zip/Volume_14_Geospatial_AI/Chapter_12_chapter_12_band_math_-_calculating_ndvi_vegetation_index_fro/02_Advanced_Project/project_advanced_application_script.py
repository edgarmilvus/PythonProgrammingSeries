
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import rasterio # Imported to maintain context, though file I/O is simulated
from typing import Dict, Tuple

# --- Configuration and Constants ---
# Standard thresholds for vegetation health classification (NDVI range -1.0 to 1.0)
NDVI_THRESHOLDS = {
    "Poor": (0.0, 0.2),      # Stress or bare soil
    "Moderate": (0.2, 0.5),  # Early growth or moderate stress
    "Healthy": (0.5, 1.0)    # Active, dense vegetation
}

# Simulate a standard satellite image tile size (e.g., 512x512 pixels)
TILE_SIZE = (512, 512)

# --- 1. Data Simulation Utility (Mimicking Geospatial Read Operations) ---
def simulate_band_data(field_name: str, band_type: str, mean_reflectance: float) -> np.ndarray:
    """
    Simulates reading a single band (NIR or Red) array from a file source.
    Satellite data is often stored as scaled integers (e.g., 0-10000).
    """
    print(f"-> Simulating {band_type} band for {field_name}...")
    # Generate a randomized array centered around the specified mean reflectance (scaled by 10000)
    base = np.random.normal(loc=mean_reflectance * 10000, scale=1000, size=TILE_SIZE)
    
    # Clip and convert to unsigned 16-bit integer (standard satellite data format)
    data = np.clip(base, 0, 10000).astype(np.uint16)
    return data

# --- 2. Core Band Math Function: Robust NDVI Calculation ---
def calculate_ndvi(nir_band: np.ndarray, red_band: np.ndarray) -> np.ndarray:
    """
    Calculates the Normalized Difference Vegetation Index: NDVI = (NIR - Red) / (NIR + Red).
    Crucially handles data type conversion and ZeroDivisionError prevention.
    """
    # Convert input bands from integer types (uint16) to float32 for accurate division
    nir_float = nir_band.astype(np.float32)
    red_float = red_band.astype(np.float32)

    # Calculate the denominator (NIR + Red)
    denominator = nir_float + red_float

    # Initialize the output NDVI array with zeros. This handles areas where the denominator is zero.
    ndvi = np.zeros_like(nir_float)

    # Create a boolean mask identifying pixels where the denominator is valid (i.e., > 0)
    # This is the standard NumPy practice for avoiding ZeroDivisionError in vectorized math.
    valid_pixels = denominator > 0

    # Perform the calculation only on the valid pixels using the mask
    numerator = nir_float[valid_pixels] - red_float[valid_pixels]
    
    # Assign the calculated value back into the corresponding locations in the NDVI map
    ndvi[valid_pixels] = numerator / denominator[valid_pixels]

    # Clip the final results to the standard NDVI range [-1.0, 1.0]
    return np.clip(ndvi, -1.0, 1.0)

# --- 3. Analysis and Reporting Function ---
def analyze_ndvi(ndvi_map: np.ndarray, field_name: str) -> Dict:
    """Analyzes the NDVI map, classifies pixels, and generates descriptive statistics."""
    total_pixels = ndvi_map.size
    analysis = {"Field": field_name, "Mean_NDVI": np.mean(ndvi_map)}
    
    print(f"\n--- Analysis for {field_name} ---")
    print(f"Mean NDVI: {analysis['Mean_NDVI']:.4f}")
    
    # Iterate through defined health thresholds to classify the map
    for health_status, (low, high) in NDVI_THRESHOLDS.items():
        # Create a boolean mask for the current classification range
        mask = (ndvi_map >= low) & (ndvi_map < high)
        
        # Use np.sum(mask) to count True values (pixels in this category)
        pixel_count = np.sum(mask)
        
        # Calculate percentage coverage
        percentage = (pixel_count / total_pixels) * 100
        
        analysis[f"Pixels_{health_status}"] = pixel_count
        analysis[f"Percent_{health_status}"] = percentage
        
        print(f"  {health_status}: {pixel_count} pixels ({percentage:.2f}%)")

    return analysis

# --- 4. Main Execution Flow ---
def main_ndvi_workflow():
    """Manages the end-to-end process of data simulation, calculation, and reporting."""
    
    # Define two distinct field scenarios: one healthy, one stressed
    field_data_configs = {
        "Field_A_Healthy_Corn": {"NIR_Mean": 0.55, "Red_Mean": 0.08}, 
        "Field_B_Stressed_Wheat": {"NIR_Mean": 0.25, "Red_Mean": 0.15} 
    }
    
    results = []
    
    for field_name, config in field_data_configs.items():
        print(f"\n[START PROCESSING] {field_name}")
        
        # A. Data Acquisition
        nir_data = simulate_band_data(field_name, "NIR", config["NIR_Mean"])
        red_data = simulate_band_data(field_name, "Red", config["Red_Mean"])
        
        # B. Validation Check (Essential for any Band Math operation)
        if nir_data.shape != red_data.shape:
            raise ValueError("Band Math requires input arrays to have identical dimensions.")
        
        # C. Core Band Math Operation: NDVI Calculation
        ndvi_output_map = calculate_ndvi(nir_data, red_data)
        
        # D. Analysis and Reporting
        field_analysis = analyze_ndvi(ndvi_output_map, field_name)
        results.append(field_analysis)

    # Final Summary Report Generation
    print("\n=============================================")
    print("SERIES SUMMARY REPORT: VEGETATION HEALTH INDEX")
    print("=============================================")
    for res in results:
        print(f"\nField: {res['Field']}")
        print(f"  Overall Mean NDVI: {res['Mean_NDVI']:.4f}")
        print(f"  Healthy Area Coverage: {res['Percent_Healthy']:.2f}%")
        
if __name__ == "__main__":
    main_ndvi_workflow()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np

# --- 1. Define the Spectral Bands (Mock Reflectance Data) ---
# In real-world scenarios, these arrays would be loaded from a raster file (like GeoTIFF)
# using libraries such as rasterio. Here, we simulate a 3x3 pixel area.

# Red Band (R): Reflectance values (0.0 to 1.0).
# Healthy vegetation absorbs Red light, so these values are typically low.
red_band_data = np.array([
    [0.10, 0.15, 0.10], # Healthy vegetation pixel examples
    [0.25, 0.12, 0.35], # Mixed/stressed vegetation or bare soil
    [0.11, 0.14, 0.13]  # Healthy vegetation pixel examples
], dtype=np.float32)

# Near-Infrared Band (NIR): Reflectance values (0.0 to 1.0).
# Healthy vegetation strongly reflects NIR light, so these values are high.
nir_band_data = np.array([
    [0.55, 0.60, 0.50],
    [0.30, 0.65, 0.45],
    [0.52, 0.58, 0.53]
], dtype=np.float32)

print("--- Input Data Summary ---")
print(f"Shape of Arrays: {red_band_data.shape}")
print("-" * 30)


# --- 2. Perform Band Math: The NDVI Calculation ---

# Step A: Calculate the Numerator (NIR - Red)
# The subtraction is performed element-wise across the entire array.
numerator = nir_band_data - red_band_data

# Step B: Calculate the Denominator (NIR + Red)
# The addition is performed element-wise across the entire array.
denominator = nir_band_data + red_band_data

# Step C: Calculate the final NDVI map (Numerator / Denominator)
# NumPy handles the division element-wise.
# NOTE: We intentionally ignore the division-by-zero handling here for simplicity;
# the robust method is covered in the Common Pitfall section.
ndvi_map = numerator / denominator


# --- 3. Output and Interpretation ---

print("--- Intermediate Results (Numerator) ---")
print(numerator)
print("-" * 30)

print("--- Intermediate Results (Denominator) ---")
print(denominator)
print("-" * 30)

print("--- Final NDVI Map (Normalized Difference Vegetation Index) ---")
print(ndvi_map)

# Interpretation: Values closer to +1.0 indicate very dense, healthy vegetation.
# Values near 0.0 or negative indicate bare soil, water, or non-vegetated areas.
print(f"\nMax NDVI recorded: {np.max(ndvi_map):.4f}")
print(f"Min NDVI recorded: {np.min(ndvi_map):.4f}")

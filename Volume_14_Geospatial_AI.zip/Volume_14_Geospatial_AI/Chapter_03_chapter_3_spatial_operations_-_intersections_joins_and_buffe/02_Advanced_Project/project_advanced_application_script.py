
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import geopandas as gpd
import pandas as pd
from shapely.geometry import Point, LineString, Polygon
import warnings

# Suppress common GeoPandas/Shapely warnings for clean output
warnings.filterwarnings('ignore', category=UserWarning)

# --- 1. Data Simulation and Setup ---
# Define a standard Geographic CRS (WGS84) for initial data creation
WGS84_CRS = "EPSG:4326"
# Define a Projected CRS (UTM Zone 15N) for accurate metric calculations (meters)
UTM_CRS = "EPSG:32615" 

print("--- Starting Infrastructure Impact Analysis ---")

# A. Simulate the Proposed Highway Route (LineString)
highway_geom = LineString([(300, 500), (350, 550), (400, 500), (450, 550)])
highway_gdf = gpd.GeoDataFrame(
    {'route_id': [101], 'status': ['Proposed']}, 
    geometry=[highway_geom], 
    crs=WGS84_CRS
)

# B. Simulate Protected Wetlands (Polygons)
wetlands_data = [
    {'name': 'Wetland A', 'area_sqkm': 1.2, 'geometry': Polygon([(320, 520), (320, 540), (340, 540), (340, 520)])},
    {'name': 'Wetland B', 'area_sqkm': 0.8, 'geometry': Polygon([(420, 530), (420, 560), (450, 560), (450, 530)])}
]
wetlands_gdf = gpd.GeoDataFrame(wetlands_data, crs=WGS84_CRS)

# C. Simulate Residential Parcels (Points)
parcel_data = [
    {'pid': 1, 'type': 'Residential', 'geometry': Point(330, 520)}, # Inside Wetland A
    {'pid': 2, 'type': 'Commercial', 'geometry': Point(355, 555)}, # Close to highway
    {'pid': 3, 'type': 'Residential', 'geometry': Point(380, 510)}, # Far from highway
    {'pid': 4, 'type': 'Residential', 'geometry': Point(440, 545)}, # Inside Wetland B
    {'pid': 5, 'type': 'Residential', 'geometry': Point(345, 540)}, # Very close to highway
]
parcels_gdf = gpd.GeoDataFrame(parcel_data, crs=WGS84_CRS)


# --- 2. Spatial Operation 1: Buffering for Proximity Analysis ---

# Reproject to UTM for accurate meter-based buffering (50 meters)
highway_utm = highway_gdf.to_crs(UTM_CRS)
print(f"\n[1/3] Calculating 50-meter buffer (using CRS: {UTM_CRS})...")

# Create the impact zone buffer
impact_zone_gdf = highway_utm.buffer(50) 
# Convert the resulting geometry series back into a GeoDataFrame for joining
impact_zone_gdf = gpd.GeoDataFrame(geometry=impact_zone_gdf, crs=UTM_CRS)


# --- 3. Spatial Operation 2: Spatial Join for Affected Parcels ---

# Ensure parcels are also in the metric CRS for the join operation
parcels_utm = parcels_gdf.to_crs(UTM_CRS)

print(f"[2/3] Performing Spatial Join to identify affected residential parcels...")

# Perform the spatial join: Find all parcels *within* the impact zone.
# We use 'within' predicate here, joining the attributes of the parcels (left)
# to the geometry of the impact zone (right).
affected_parcels_join = gpd.sjoin(
    parcels_utm, 
    impact_zone_gdf, 
    how='inner', 
    predicate='within' 
)

# Filter the results to only include 'Residential' types for the final count
affected_residential_parcels = affected_parcels_join[
    affected_parcels_join['type'] == 'Residential'
]

print(f"   -> Total affected residential parcels identified: {len(affected_residential_parcels)}")


# --- 4. Spatial Operation 3: Intersection for Environmental Conflict ---

# Ensure both layers are in the metric CRS for accurate area calculation
wetlands_utm = wetlands_gdf.to_crs(UTM_CRS)

print(f"[3/3] Calculating geometric intersection with protected wetlands...")

# Use GeoPandas overlay function with 'intersection' op
# This returns a new GeoDataFrame containing only the overlapping geometries.
conflict_area_gdf = gpd.overlay(
    highway_utm, 
    wetlands_utm, 
    how='intersection'
)

# Calculate the length of the intersected line segments (in meters)
conflict_area_gdf['conflict_length_m'] = conflict_area_gdf.geometry.length

# Calculate the total length of the highway intersecting wetlands
total_conflict_length = conflict_area_gdf['conflict_length_m'].sum()

print(f"   -> Total length of highway intersecting wetlands: {total_conflict_length:.2f} meters.")

# --- 5. Reporting and Cleanup ---

print("\n--- Summary of Impact Assessment ---")
print(f"1. Residential Parcels within 50m Buffer: {len(affected_residential_parcels)}")
print(f"2. Total Highway Conflict Length (Wetlands): {total_conflict_length:.2f} m")

# Display the PIDs of the affected parcels
if not affected_residential_parcels.empty:
    print(f"   Affected Parcel IDs: {affected_residential_parcels['pid'].tolist()}")

# Display the names of the affected wetlands
if not conflict_area_gdf.empty:
    print(f"   Wetlands affected: {conflict_area_gdf['name'].unique().tolist()}")

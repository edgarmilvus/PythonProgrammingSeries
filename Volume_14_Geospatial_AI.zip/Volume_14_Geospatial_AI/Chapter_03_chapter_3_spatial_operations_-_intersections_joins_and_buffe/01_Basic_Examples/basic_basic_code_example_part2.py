
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example_part2.py
# Description: Basic Code Example
# ==========================================

# Assume gdf_reserve is currently in EPSG:4326 (degrees)

# Pitfall: Calculating 100 meters in a degree-based CRS
# gdf_reserve.buffer(distance=100) # 100 degrees! Massive error.

# Correct Approach: Reproject to a meter-based CRS (e.g., UTM Zone 10N)
# 1. Define the target projected CRS
target_crs = "EPSG:32610" # UTM Zone 10N (meters)

# 2. Reproject the GDF
gdf_projected = gdf_reserve.to_crs(target_crs)

# 3. Apply the buffer (100 meters)
# This calculation is now accurate because the CRS is meter-based.
gdf_buffer_accurate = gdf_projected.buffer(distance=100)

# Optional: Reproject back to 4326 for web mapping/display if needed
# gdf_buffer_accurate = gdf_buffer_accurate.to_crs("EPSG:4326")

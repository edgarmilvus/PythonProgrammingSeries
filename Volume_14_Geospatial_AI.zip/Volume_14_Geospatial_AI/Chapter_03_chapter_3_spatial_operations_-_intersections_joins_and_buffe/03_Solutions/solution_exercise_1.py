
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import geopandas as gpd
import pandas as pd
from shapely.geometry import LineString, Polygon

# --- Conceptual Setup (Assumes data is already in a metric CRS like UTM) ---
CRS_METRIC = "EPSG:32617" 

# Mock data setup
pipeline_gdf = gpd.GeoDataFrame({
    'pipe_id': [1],
    'geometry': [LineString([(0, 0), (10000, 0)])]
}, crs=CRS_METRIC)

parcels_data = {
    'parcel_id': [101, 102, 103],
    'crop_type': ['Wheat', 'Corn', 'Soy'],
    'total_area_sqm': [3000000.0, 1000000.0, 500000.0],
    'geometry': [
        Polygon([(200, -1000), (200, 1000), (1200, 1000), (1200, -1000)]), 
        Polygon([(5000, -1000), (5000, 1000), (6000, 1000), (6000, -1000)]), 
        Polygon([(20000, 20000), (20000, 20100), (20100, 20100), (20100, 20000)]) # Unaffected
    ]
}
parcels_gdf = gpd.GeoDataFrame(parcels_data, crs=CRS_METRIC)
# --- End Setup ---

# 1. Buffer Generation (500 meters)
impact_zone_geometry = pipeline_gdf.geometry.buffer(500).unary_union
impact_zone_gdf = gpd.GeoDataFrame(
    {'zone_id': [1]}, 
    geometry=[impact_zone_geometry], 
    crs=CRS_METRIC
)

# Prepare original area data for later merging
original_areas = parcels_gdf[['parcel_id', 'total_area_sqm']].copy()

# 2. & 3. Identification of Affected Parcels and Calculate Overlap Area
affected_parcels_gdf = gpd.overlay(
    parcels_gdf, 
    impact_zone_gdf, 
    how='intersection'
)

# Calculate the area of the resulting overlap geometries
affected_parcels_gdf['impacted_area_sqm'] = affected_parcels_gdf.geometry.area

# 4. & 5. Join original area and calculate impact percentage
# Merge the original total area back using parcel_id
final_impact_analysis_gdf = affected_parcels_gdf.merge(
    original_areas,
    on='parcel_id',
    suffixes=('_overlap', '_original')
)

# Calculate Impact Percentage
final_impact_analysis_gdf['impact_percent'] = (
    final_impact_analysis_gdf['impacted_area_sqm'] / 
    final_impact_analysis_gdf['total_area_sqm_original']
) * 100

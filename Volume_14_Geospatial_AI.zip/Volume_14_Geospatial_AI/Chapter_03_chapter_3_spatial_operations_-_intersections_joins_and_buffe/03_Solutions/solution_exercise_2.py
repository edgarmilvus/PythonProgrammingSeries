
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import geopandas as gpd
import pandas as pd
from shapely.geometry import Polygon

# --- Conceptual Setup (Assumes data is in a metric CRS) ---
CRS_METRIC = "EPSG:32617" 
HA_PER_SQM = 10000

# Mock data setup
fire_perimeter_gdf = gpd.GeoDataFrame({
    'fire_name': ['BigBurn'],
    'geometry': [Polygon([(0, 0), (0, 10000), (10000, 10000), (10000, 0)])]
}, crs=CRS_METRIC)

protected_zones_gdf = gpd.GeoDataFrame({
    'zone_id': [201, 202, 203],
    'ecosystem_type': ['Old Growth Forest', 'Wetland Habitat', 'Shrubland'],
    'protection_level': ['High', 'Medium', 'Low'],
    'geometry': [
        Polygon([(1000, 1000), (1000, 4000), (4000, 4000), (4000, 1000)]), # Fully burned (9 sq km)
        Polygon([(5000, 5000), (5000, 12000), (12000, 12000), (12000, 5000)]), # Partially burned
        Polygon([(20000, 20000), (20000, 20100), (20100, 20100), (20100, 20000)]) # Not burned
    ]
}, crs=CRS_METRIC)
# --- End Setup ---

# 1. Overlay Operation (Intersection)
# This results in geometries that represent the overlap (burned area)
burned_areas_gdf = gpd.overlay(
    protected_zones_gdf, 
    fire_perimeter_gdf, 
    how='intersection', 
    keep_geom_type=True
)

# 2. Damage Calculation - Calculate burned area in hectares
burned_areas_gdf['burned_area_hectares'] = burned_areas_gdf.geometry.area / HA_PER_SQM

# 3. Summary Report - Group and Aggregate
ecosystem_damage_summary = burned_areas_gdf.groupby('ecosystem_type').agg(
    total_burned_hectares=('burned_area_hectares', 'sum')
).reset_index()

# Ensure the final result is a standard Pandas DataFrame
ecosystem_damage_summary = pd.DataFrame(ecosystem_damage_summary)

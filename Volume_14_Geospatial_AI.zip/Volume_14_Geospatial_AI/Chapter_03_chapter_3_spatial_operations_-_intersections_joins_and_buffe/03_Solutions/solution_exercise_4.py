
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import geopandas as gpd
import pandas as pd
from shapely.geometry import Point, Polygon

# --- Conceptual Setup (Assumes metric CRS) ---
CRS_METRIC = "EPSG:32617" 

extraction_sites_gdf = gpd.GeoDataFrame({
    'site_id': [1, 2, 3, 4],
    'extraction_type': ['Legal', 'Illegal', 'Legal', 'Illegal'],
    'geometry': [Point(100, 100), Point(5000, 5000), Point(10000, 10000), Point(1000, 1000)]
}, crs=CRS_METRIC).set_index('site_id')

sensitive_areas_gdf = gpd.GeoDataFrame({
    'area_name': ['Park A'],
    'protection_level': ['High'],
    'geometry': [Polygon([(0, 0), (0, 200), (200, 200), (200, 0)])] # Near Site 1
}, crs=CRS_METRIC)

concession_boundaries_gdf = gpd.GeoDataFrame({
    'concession_id': ['C1', 'C2'],
    'geometry': [
        Polygon([(50, 50), (50, 150), (150, 150), (150, 50)]), # Contains Site 1
        Polygon([(9000, 9000), (9000, 11000), (11000, 11000), (11000, 9000)]) # Contains Site 3
    ]
}, crs=CRS_METRIC)
# --- End Setup ---

# Initialize the final GDF based on the original sites (using site_id as index)
enriched_sites_gdf = extraction_sites_gdf.copy()


# --- Feature 1: Binary Proximity Flag (100m Buffer + Join) ---
sensitive_buffer_100m = sensitive_areas_gdf.buffer(100)
sensitive_buffer_gdf = gpd.GeoDataFrame(geometry=sensitive_buffer_100m, crs=CRS_METRIC).assign(is_buffered=True)

# Spatially join sites to the buffer (left join to keep all sites)
proximity_join = gpd.sjoin(
    enriched_sites_gdf, 
    sensitive_buffer_gdf, 
    how='left', 
    predicate='intersects'
)

# Aggregate the join result back to the original index (site_id) and convert to Boolean
enriched_sites_gdf['is_near_sensitive_area'] = proximity_join.groupby(
    enriched_sites_gdf.index
)['is_buffered'].first().fillna(False).astype(bool)


# --- Feature 2: Concession ID Assignment (Join) ---
concession_join = gpd.sjoin(
    enriched_sites_gdf.drop(columns=['is_near_sensitive_area']), 
    concession_boundaries_gdf[['concession_id', 'geometry']], 
    how='left', 
    predicate='within'
)

# Aggregate the join result and fill NaNs
concession_map = concession_join.groupby(
    enriched_sites_gdf.index
)['concession_id'].first().fillna('NONE')

enriched_sites_gdf['concession_id'] = concession_map


# --- Feature 3: Quantified Impact Area (Buffer + Intersection + Aggregation) ---
# 1. Create 50m buffer around each extraction site
site_buffers_gdf = enriched_sites_gdf.buffer(50).reset_index()
site_buffers_gdf = gpd.GeoDataFrame(site_buffers_gdf, geometry=site_buffers_gdf[0], crs=CRS_METRIC)
site_buffers_gdf.rename(columns={0: 'geometry'}, inplace=True)
site_buffers_gdf = site_buffers_gdf.set_index('site_id')

# 2. Perform intersection overlay
impact_overlap_gdf = gpd.overlay(
    site_buffers_gdf, 
    sensitive_areas_gdf, 
    how='intersection'
)

# 3. Calculate overlap area
impact_overlap_gdf['overlap_sqm'] = impact_overlap_gdf.geometry.area

# 4. Aggregate maximum overlap area per site_id
max_overlap_summary = impact_overlap_gdf.groupby('site_id')['overlap_sqm'].max()

# 5. Merge results back and fill NaNs with 0.0
enriched_sites_gdf['max_sensitive_overlap_sqm'] = enriched_sites_gdf.index.map(
    max_overlap_summary
).fillna(0.0)

# Final cleanup: Reset index to restore original structure
enriched_sites_gdf = enriched_sites_gdf.reset_index()

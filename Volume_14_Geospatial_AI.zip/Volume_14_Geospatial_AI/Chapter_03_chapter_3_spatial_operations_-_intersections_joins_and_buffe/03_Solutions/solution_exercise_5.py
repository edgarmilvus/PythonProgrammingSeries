
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import geopandas as gpd
import pandas as pd
from shapely.geometry import Polygon

# --- Conceptual Setup (Assumes metric CRS) ---
CRS_METRIC = "EPSG:32617" 

macro_regions_gdf = gpd.GeoDataFrame({
    'region_id': ['R1', 'R2'],
    'geometry': [
        Polygon([(0, 0), (0, 100), (100, 100), (100, 0)]),
        Polygon([(200, 200), (200, 300), (300, 300), (300, 200)])
    ]
}, crs=CRS_METRIC)

micro_zones_gdf = gpd.GeoDataFrame({
    'micro_zone_id': [1, 2, 3, 4],
    'total_population': [1000, 500, 2000, 1000],
    'average_income': [50000, 60000, 40000, 70000],
    'geometry': [
        Polygon([(0, 0), (0, 50), (50, 50), (50, 0)]), # R1 part 1
        Polygon([(50, 50), (50, 100), (100, 100), (100, 50)]), # R1 part 2
        Polygon([(200, 200), (200, 250), (250, 250), (250, 200)]), # R2 part 1
        Polygon([(250, 250), (250, 300), (300, 300), (300, 250)]) # R2 part 2
    ]
}, crs=CRS_METRIC)
# --- End Setup ---

# 1. Initial Spatial Join: Assign region_id to micro-zones
joined_micro_zones = gpd.sjoin(
    micro_zones_gdf, 
    macro_regions_gdf[['region_id', 'geometry']], 
    how='left', 
    predicate='intersects'
)

# 2. & 3. Dissolve and Attribute Aggregation
# Define the aggregation dictionary for the dissolve operation
agg_funcs = {
    'total_population': 'sum',
    'average_income': 'mean'
}

# Perform the dissolve (implicit union) based on 'region_id'
unified_regions_gdf = joined_micro_zones.dissolve(
    by='region_id', 
    aggfunc=agg_funcs
).reset_index()

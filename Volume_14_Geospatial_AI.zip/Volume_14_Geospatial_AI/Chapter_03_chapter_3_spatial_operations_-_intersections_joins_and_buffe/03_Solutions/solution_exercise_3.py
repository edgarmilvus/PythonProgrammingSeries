
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import geopandas as gpd
from shapely.geometry import Point, Polygon
import pandas as pd

# --- Conceptual Setup ---
CRS_METRIC = "EPSG:32617" 

neighborhoods_gdf = gpd.GeoDataFrame({
    'hood_name': ['Central', 'North'],
    'geometry': [
        Polygon([(0, 0), (0, 1000), (1000, 1000), (1000, 0)]),
        Polygon([(1500, 1500), (1500, 2500), (2500, 2500), (2500, 1500)])
    ]
}, crs=CRS_METRIC)

building_detections_gdf = gpd.GeoDataFrame({
    'detection_id': range(10),
    'building_type': ['Residential', 'Commercial', 'Residential', 'Residential', 'Industrial', 
                      'Residential', 'Commercial', 'Residential', 'Residential', 'Residential'],
    'geometry': [
        Point(100, 100), Point(500, 500), Point(900, 900), # Central (3 Residential)
        Point(100, 10000), # Outside
        Point(1600, 1600), Point(1800, 1800), Point(2000, 2000), # North (2 Residential)
        Point(2200, 2200), Point(2400, 2400), Point(2450, 2450) # North (3 Residential)
    ]
}, crs=CRS_METRIC)
# --- End Setup ---

# 1. Execute the spatial join (sjoin)
# Use 'inner' join to only keep points that fall within a neighborhood.
joined_detections = gpd.sjoin(
    neighborhoods_gdf[['hood_name', 'geometry']], 
    building_detections_gdf[['detection_id', 'building_type', 'geometry']], 
    how='inner', 
    predicate='within'
)

# 2. & 3. Filtering and Aggregation (Memory-Optimized)
# Immediately filter the joined DataFrame based on the attribute column
# and then aggregate using Pandas groupby().
residential_counts_df = joined_detections[
    joined_detections['building_type'] == 'Residential'
].groupby('hood_name').agg(
    residential_building_count=('detection_id', 'count')
).reset_index()

# Note: The resulting DataFrame is a standard Pandas DataFrame

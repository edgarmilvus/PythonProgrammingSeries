
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Install dependencies first (run in terminal):
# pip install google-generativeai wolframalpha pyttsx3 pillow requests

import google.generativeai as genai  # Multimodal LLM for vision-based extraction
from PIL import Image  # Image loading for Gemini input
import wolframalpha  # Symbolic computation engine for exact math solving
import pyttsx3  # Offline text-to-speech for vocal output
import os  # Basic file path handling

# ======================================
# CONFIGURATION: Replace with your API keys
# ======================================
# Get free Gemini key: https://aistudio.google.com/app/apikey
genai.configure(api_key="YOUR_GEMINI_API_KEY_HERE")
# Get free Wolfram AppID: https://developer.wolframalpha.com/ (500 queries/month free)
wolfram_client = wolframalpha.Client("YOUR_WOLFRAM_APPID_HERE")
# Initialize TTS engine (uses system voices, no internet needed)
tts_engine = pyttsx3.init()

# ======================================
# CORE AGENT FUNCTION: Multimodal Math Solver
# ======================================
def multimodal_math_solver(image_path):
    """
    1. Loads and analyzes image with Gemini Vision to extract math problem.
    2. Queries Wolfram Alpha for symbolic solution.
    3. Synthesizes and speaks the answer aloud.
    Achieves near-zero hallucination: Neural extraction + Symbolic compute.
    """
    # Step 1: Validate and load image
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Image not found: {image_path}. Add 'math_problem.jpg' here.")
    img = Image.open(image_path)
    
    # Step 2: Neural Vision Extraction with Gemini Pro Vision
    # Prompt engineered for precision: Extract exact math, ignore noise
    model = genai.GenerativeModel('gemini-pro-vision')
    vision_prompt = """
    Analyze this image of a handwritten or printed math problem.
    Extract ONLY the exact mathematical equation or expression to solve.
    Do not solve it. Do not add explanations. Output just the math string, e.g., '3x^2 + 5x - 2 = 0'.
    Ignore surrounding text, grids, or artifacts.
    """
    response = model.generate_content([vision_prompt, img])
    extracted_problem = response.text.strip()
    print(f"🔍 Extracted math problem: {extracted_problem}")
    
    # Step 3: Symbolic Computation with Wolfram Alpha
    # Query the exact extracted string for reliable, step-by-step solving
    query_result = wolfram_client.query(extracted_problem)
    # Safely extract primary result (Wolfram pods are structured)
    solution = ""
    for pod in query_result.pods:
        if pod.title.lower() in ['result', 'alternate forms', 'solutions']:
            solution = pod.text
            break
    if not solution:
        solution = "No clear solution found. Check the image."
    print(f"✅ Wolfram solution: {solution}")
    
    # Step 4: Voice Output Synthesis
    # Speak the full response: problem + solution for context
    spoken_text = f"The math problem is {extracted_problem}. The solution is {solution}."
    tts_engine.say(spoken_text)
    tts_engine.runAndWait()
    print("🗣️ Answer spoken aloud!")

# ======================================
# HELLO WORLD USAGE: Run the agent
# ======================================
if __name__ == "__main__":
    # Point to your local image (e.g., download a quadratic equation photo)
    image_file = "math_problem.jpg"
    multimodal_math_solver(image_file)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import google.generativeai as genai
import wolframalpha
from ibm_watson import NaturalLanguageUnderstandingV1
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
import re
import os
import contextvars
import io
from PIL import Image
import requests
from gtts import gTTS
import pygame
import time

# Reuse API setups from Exercise 1 (assume same env vars)
genai.configure(api_key=os.getenv('GEMINI_API_KEY'))
wolfram_client = wolframalpha.Client(os.getenv('WOLFRAM_APP_ID'))
authenticator = IAMAuthenticator(os.getenv('WATSON_APIKEY'))
watson_nlu = NaturalLanguageUnderstandingV1(version='2022-04-07', authenticator=authenticator)
watson_nlu.set_service_url(os.getenv('WATSON_URL'))

# ContextVars (reuse from Ex1 + new)
image_path_cv = contextvars.ContextVar('image_path', default='')
data_cv = contextvars.ContextVar('extracted_data', default={})
analysis_cv = contextvars.ContextVar('analysis_summary', default='')

# Reuse analyze_with_gemini, compute_wolfram_metrics, verify_with_watson from Ex1
# (Copy functions here or import; shown abbreviated for brevity)

def load_image(image_path_or_url):  # Same as Ex1
    if image_path_or_url.startswith('http'):
        response = requests.get(image_path_or_url)
        img = Image.open(io.BytesIO(response.content))
    else:
        img = Image.open(image_path_or_url)
    return img

def analyze_with_gemini(image_path_or_url):  # Same as Ex1, but store summary
    # ... (identical to Ex1 implementation)
    summary = f"{chart_type} chart: data {data}, peak {peak}"
    analysis_cv.set(summary)
    return desc, data, chart_type, peak  # Abbrev

def compute_wolfram_metrics(data):  # Same as Ex1
    # ... (identical)
    return total, avg, growth

def verify_with_watson(data):  # Same as Ex1
    # ... (identical)
    return conf

def post_process_summary(data, chart_type, peak, total, avg, growth, conf):
    """Create concise 100-150 word speech script."""
    script = f"This {chart_type} chart illustrates TechNova's sales: peaking at {data[peak]} in relevant quarter, total {total} verified against industry averages via Watson confidence {conf:.2f}, average {avg}, with growth {growth} computed exactly by Wolfram."
    return script

def speak_summary(script, filename='chart_summary.wav'):
    """gTTS synthesis and playback with pygame."""
    print("Speaking summary...")
    print(script)  # Log full speech script
    tts = gTTS(text=script, lang='en-US', slow=False)  # Professional speed
    tts.save(filename)
    pygame.mixer.init()
    pygame.mixer.music.load(filename)
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        time.sleep(0.1)
    print(f"Audio saved to {filename}")

def full_pipeline(image_path_or_url):
    """Build on Ex1 with timing and TTS."""
    start_time = time.perf_counter()
    desc, data, chart_type, peak = analyze_with_gemini(image_path_or_url)
    total, avg, growth = compute_wolfram_metrics(data)
    conf = verify_with_watson(data)
    script = post_process_summary(data, chart_type, peak, total, avg, growth, conf)
    elapsed = time.perf_counter() - start_time
    script_with_time = f"{script} Analysis completed in {elapsed:.2f} seconds."
    speak_summary(script_with_time)
    print(f"Full speech script logged and file path: chart_summary.wav")

# Test with pie chart (e.g., sums to 100%)
full_pipeline('images/b1_c12_s4_diag2.png')  # Replace with pie chart path/URL, Wolfram verifies sum=100

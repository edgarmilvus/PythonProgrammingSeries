
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import google.generativeai as genai
import wolframalpha
import os
import contextvars
import io
from PIL import Image
import requests
from gtts import gTTS
import pygame
import re

genai.configure(api_key=os.getenv('GEMINI_API_KEY'))
wolfram_client = wolframalpha.Client(os.getenv('WOLFRAM_APP_ID'))

# ContextVars
equation_cv = contextvars.ContextVar('equation_str', default='')
solution_cv = contextvars.ContextVar('solution_str', default='')

def load_image(image_path_or_url):
    if image_path_or_url.startswith('http'):
        response = requests.get(image_path_or_url)
        img = Image.open(io.BytesIO(response.content))
    else:
        img = Image.open(image_path_or_url)
    return img

def transcribe_math(image_path_or_url):
    """Gemini Vision transcribes and types math problem."""
    model = genai.GenerativeModel('gemini-pro-vision')
    img = load_image(image_path_or_url)
    prompt = """
    Transcribe this math problem exactly in plain text or LaTeX.
    Identify type: integral, quadratic, equation, etc.
    Ignore background/noise. Output: Type: X. Equation: Y.
    """
    response = model.generate_content([prompt, img])
    text = response.text
    print("Transcribed:", text)
    
    # Parse type and equation
    type_match = re.search(r'Type:\s*(\w+)', text, re.IGNORECASE)
    eq_match = re.search(r'Equation:\s*(.+)', text, re.IGNORECASE)
    ptype = type_match.group(1).lower() if type_match else 'equation'
    equation = eq_match.group(1).strip() if eq_match else text
    
    if not equation or len(equation) < 5:
        print("Unclear transcription. Clarify:")
        equation = input("Enter equation: ")
    
    wolfram_eq = equation.replace('∫', 'integrate ').replace('^2', '**2')  # Adapt for Wolfram
    if ptype == 'integral':
        bounds = re.findall(r'from (\d+) to (\d+)', equation)
        if bounds:
            wolfram_eq += f" from {bounds[0][0]} to {bounds[0][1]}"
    
    equation_cv.set(equation)
    return ptype, wolfram_eq, text

def solve_wolfram(wolfram_eq):
    """Symbolic solve with steps."""
    res = wolfram_client.query(wolfram_eq)
    steps = [r.text for r in res.pods if 'Step' in r.node.text]
    final = next((r.text for r in res.results), "No solution")
    solution_cv.set(final)
    print("Wolfram steps:", steps)
    print("Final:", final)
    return final, steps

def speak_solution(equation, final, image_path_or_url='math_photo.jpg'):
    """TTS for problem and solution."""
    script = f"Problem: {equation}. Solution: {final}. Verified symbolically."
    print("Speaking:", script)
    tts = gTTS(script, lang='en-US')
    tts.save('math_solution.mp3')
    pygame.mixer.init()
    pygame.mixer.music.load('math_solution.mp3')
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        time.sleep(0.1)

# Test pipeline for 3 problems (calculus, algebra, graph)
def run_solver(image_path_or_url):
    ptype, wolfram_eq, trans = transcribe_math(image_path_or_url)
    final, steps = solve_wolfram(wolfram_eq)
    speak_solution(trans, final)

# Tests:
# run_solver('integral_photo.jpg')  # ∫(x^2 + 3x) dx 0 to 5
# run_solver('quadratic.jpg')  # 2x^2 -5x +3=0
run_solver('images/b1_c12_s4_diag3.png')  # Area under curve example

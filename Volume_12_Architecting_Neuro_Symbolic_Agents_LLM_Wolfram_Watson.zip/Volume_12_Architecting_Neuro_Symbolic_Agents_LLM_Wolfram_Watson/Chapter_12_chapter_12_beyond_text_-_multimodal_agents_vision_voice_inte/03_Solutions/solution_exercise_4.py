
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import google.generativeai as genai
import wolframalpha
import speech_recognition as sr
import os
import contextvars
import io
from PIL import Image
import requests
from gtts import gTTS
import pygame
import re

genai.configure(api_key=os.getenv('GEMINI_API_KEY'))
wolfram_client = wolframalpha.Client(os.getenv('WOLFRAM_APP_ID'))

# ContextVars for persistence
current_image_cv = contextvars.ContextVar('current_image', default='')
analysis_cache_cv = contextvars.ContextVar('analysis_cache', default='')

r = sr.Recognizer()
m = sr.Microphone()

def load_image(image_path_or_url):
    # Same as previous
    pass  # Abbrev, reuse

def analyze_image_query(image_path_or_url, query):
    """Dynamic Gemini analysis fused with query."""
    current_image_cv.set(image_path_or_url)
    model = genai.GenerativeModel('gemini-pro-vision')
    img = load_image(image_path_or_url)
    prompt = f"Analyze image for query '{query}': describe relevant facts, numbers, trends exactly."
    response = model.generate_content([prompt, img])
    cache = response.text
    analysis_cache_cv.set(cache)
    print("Analysis:", cache)
    return cache

def route_and_compute(query, analysis):
    """Route: math/compute -> Wolfram, facts -> mock Watson, else Gemini."""
    if re.search(r'(total|average|sum|growth|calculate)', query, re.I):
        # Extract numbers from analysis
        nums = re.findall(r'(\d+(?:\.\d+)?K?)', analysis)
        nums = [int(float(n.rstrip('K'))*1000 if 'K' in n else float(n)) for n in nums]
        q = f"sum {nums}"  # Simplify for demo
        res = wolfram_client.query(q)
        return next(res.results).text
    elif re.search(r'(realistic|verify|industry)', query, re.I):
        return "Verified plausible (Watson conf 0.92)"  # Mock Watson
    else:
        return analysis  # Gemini desc

def get_voice_query():
    """STT with mic fallback to text."""
    try:
        with m as source:
            r.adjust_for_ambient_noise(source)
            audio = r.listen(source, timeout=5)
        return r.recognize_google(audio)
    except:
        print("Mic error, use text.")
        return input("Query (text): ")

def speak_response(response):
    tts = gTTS(response, lang='en-US')
    tts.save('response.mp3')
    pygame.mixer.init()
    pygame.mixer.music.load('response.mp3')
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        time.sleep(0.1)
    print("Response:", response)

# Interactive loop
while True:
    img_path = input("Upload image path/URL (or 'quit'): ").strip()
    if img_path.lower() == 'quit':
        break
    query = get_voice_query() or input("Query (text): ")
    analysis = analyze_image_query(img_path, query)
    result = route_and_compute(query, analysis)
    full_response = f"For '{query}': {result}"
    speak_response(full_response)
    print("Transcript logged above.")

# Test sequence: sales chart "total sales?", math "solve?", voice query


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import google.generativeai as genai
import wolframalpha
import speech_recognition as sr
import os
import contextvars
import io
from PIL import Image
import requests
from gtts import gTTS
import pygame
import json
import re

genai.configure(api_key=os.getenv('GEMINI_API_KEY'))
wolfram_client = wolframalpha.Client(os.getenv('WOLFRAM_APP_ID'))
r = sr.Recognizer()
m = sr.Microphone()

# ContextVars
entities_cv = contextvars.ContextVar('entities_list', default=[])
chain_history_cv = contextvars.ContextVar('chain_history', default=[])

# MODIFICATION START: Original text chain was simple Q&A -> Wolfram/Watson.
# Original (commented): def text_chain(q): wolfram(q) + watson_verify(q)
# Added: Vision entities extraction + voice input fusion.

def extract_entities(image_path_or_url):
    """NEW: Gemini Vision extracts receipt items/prices."""
    model = genai.GenerativeModel('gemini-pro-vision')
    img = Image.open(image_path_or_url)  # Simplified local
    prompt = "Extract entities from receipt: list as [{'item': 'apples', 'price': 2.50}, ...], total if present."
    response = model.generate_content([prompt, img])
    text = response.text
    # Parse JSON-like list
    entities = re.findall(r"'(\w+)':\s*['$]?([\d.]+)", text)
    entities_list = [{'item': item, 'price': float(price)} for item, price in entities]
    total = sum(e['price'] for e in entities_list)
    entities_list.append({'total': total})
    entities_cv.set(entities_list)
    return entities_list

def voice_query():
    """NEW: STT input."""
    try:
        with m as source:
            audio = r.listen(source)
        return r.recognize_google(audio)
    except:
        return input("Voice/text query: ")

def modified_chain(image_path_or_url):
    """MODIFIED: Inject vision + voice into original chain."""
    entities = extract_entities(image_path_or_url)
    q = voice_query()
    # Fuse: vision_entities + query
    fused = f"Entities: {entities}. Query: {q}"
    print("Step 1 (Vision):", entities)
    
    # Wolfram calcs (original + dynamic)
    if 'sum' in q.lower() or 'total' in q.lower():
        prices = [e['price'] for e in entities if 'price' in e]
        res = wolfram_client.query(f"sum {prices}")
        wolfram_res = next(res.results).text
    elif 'max' in q.lower():
        wolfram_res = f"max {prices}"
    else:
        wolfram_res = "Computed"
    print("Step 2 (Wolfram):", wolfram_res)
    
    # Watson verify (original)
    verify = "Realistic US prices (conf 0.91)"  # Mock
    print("Step 3 (Watson):", verify)
    
    full = f"Saw receipt: {entities}. Query: {q}. Computed: {wolfram_res}. Verified: {verify}."
    chain_history_cv.set([full])
    
    # TTS reasoning
    tts = gTTS(full, lang='en-US')
    tts.save('receipt_response.mp3')
    pygame.mixer.music.load('receipt_response.mp3')
    pygame.mixer.music.play()
    
    # Serialize state JSON
    state = {'entities': entities_cv.get(), 'history': chain_history_cv.get()}
    with open('state.json', 'w') as f:
        json.dump(state, f)
    
    # Text-based flow diagram (DOT-like)
    diagram = """
digraph Chain {
    UserVoice -> STT -> FuseVision;
    VisionGemini -> ExtractEntities;
    FuseVision -> WolframCalc;
    WolframCalc -> WatsonVerify;
    WatsonVerify -> TTSOutput;
}
"""
    print("Step-by-step log above. Flow diagram:\n", diagram)
    
    return full

# Test: receipt photo, "sum prices", "budget check" voice
print(modified_chain('receipt.jpg'))
print("Modification: Added Vision (extract_entities), Voice (voice_query), fused into original Wolfram/Watson/TTS chain.")

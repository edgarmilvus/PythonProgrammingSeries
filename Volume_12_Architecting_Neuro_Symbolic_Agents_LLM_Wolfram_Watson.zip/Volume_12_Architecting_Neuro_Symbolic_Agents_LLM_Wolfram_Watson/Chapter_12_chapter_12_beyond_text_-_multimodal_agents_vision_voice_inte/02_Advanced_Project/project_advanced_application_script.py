
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# Multimodal Neuro-Symbolic Math Solver Agent
# Integrates Gemini Vision for image-to-math transcription,
# Wolfram Alpha for hallucination-free solving,
# and pyttsx3 for voice output.
# Usage: python script.py <image_path>
# Requires: pip install google-generativeai wolframalpha pyttsx3 pillow

import sys
import os
import logging
from PIL import Image
import google.generativeai as genai
import wolframalpha.client
import pyttsx3

# Configure logging for debugging and traceability
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# API Keys - Replace with your own (store securely in env vars for production)
GEMINI_API_KEY = "YOUR_GEMINI_API_KEY_HERE"  # From https://aistudio.google.com/app/apikey
WOLFRAM_APP_ID = "YOUR_WOLFRAM_APP_ID_HERE"  # From https://developer.wolframalpha.com/

# Initialize clients for symbiotic integration
genai.configure(api_key=GEMINI_API_KEY)
gemini_model = genai.GenerativeModel('gemini-1.5-flash')  # Multimodal vision model

wolfram_client = wolframalpha.Client(WOLFRAM_APP_ID)
tts_engine = pyttsx3.init()

# Prompt template for Gemini: Grounds vision in symbolic extraction
VISION_PROMPT = """
Analyze this image of a math problem. Extract the exact problem statement as LaTeX or plain text.
Ignore surroundings; focus only on equations, variables, and instructions (e.g., 'Solve for x').
Output ONLY the cleaned math expression in a format ready for Wolfram Alpha, like:
Problem: solve 2x^2 + 5x - 3 = 0
If handwritten, interpret symbols accurately. If no math detected, say "No math problem found."
"""

def extract_math_problem(image_path: str) -> str:
    """
    Use Gemini Vision to transcribe math from image.
    Neuro-step 1: Perceptual grounding to symbolic text.
    """
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Image not found: {image_path}")
    
    logger.info(f"Analyzing image: {image_path}")
    image = Image.open(image_path)
    
    try:
        response = gemini_model.generate_content([VISION_PROMPT, image])
        extracted_problem = response.text.strip()
        logger.info(f"Extracted problem: {extracted_problem}")
        return extracted_problem
    except Exception as e:
        logger.error(f"Gemini extraction failed: {e}")
        raise

def solve_with_wolfram(problem: str) -> str:
    """
    Query Wolfram Alpha for exact computation.
    Neuro-symbolic symbiosis: LLM perception -> Symbolic solver.
    Reduces hallucinations to zero via computational verification.
    """
    logger.info(f"Solving with Wolfram: {problem}")
    
    try:
        res = wolfram_client.query(problem)
        solution_pod = None
        steps_pod = None
        
        for pod in res.pods:
            if 'Solution' in str(pod['@title']) or 'Result' in str(pod['@title']):
                solution_pod = pod
            elif 'Steps' in str(pod['@title']) or 'Derivation' in str(pod['@title']):
                steps_pod = pod
        
        # Parse primary solution
        solution = next((sub[2] for sub in solution_pod.subpods), "No solution found")
        
        # Build step-by-step if available
        steps = ""
        if steps_pod:
            steps = "Steps: " + " | ".join(sub[2] for sub in steps_pod.subpods)
        
        full_solution = f"Solution: {solution}\n{steps}".strip()
        logger.info(f"Wolfram solution: {full_solution}")
        return full_solution
    except Exception as e:
        logger.error(f"Wolfram solve failed: {e}")
        return f"Error solving '{problem}': {str(e)}"

def vocalize_solution(solution_text: str):
    """
    Convert solution to speech using pyttsx3 (offline, free alternative to Watson TTS).
    Multimodal output: Symbolic result -> Auditory delivery.
    """
    logger.info("Vocalizing solution...")
    tts_engine.say(solution_text)
    tts_engine.runAndWait()
    logger.info("Speech complete.")

def main(image_path: str):
    """
    Orchestrate the full multimodal pipeline.
    Handles real-world errors gracefully.
    """
    try:
        # Step 1: Vision integration
        problem = extract_math_problem(image_path)
        if "No math problem" in problem:
            logger.warning("No math detected in image.")
            return
        
        # Step 2: Symbolic computation
        solution = solve_with_wolfram(problem)
        
        # Step 3: Voice integration
        vocalize_solution(solution)
        
        # Log full trace for auditability
        logger.info("Agent pipeline complete: Vision -> Wolfram -> Voice")
        
    except Exception as e:
        logger.error(f"Pipeline failed: {e}")
        vocalize_solution(f"Error processing image: {str(e)}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python math_solver_agent.py <image_path>")
        sys.exit(1)
    
    image_path = sys.argv[1]
    main(image_path)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import asyncio
import json
import random
from datetime import datetime
import builtins
import os

# Stub TCO snippet from Ex1 (simplified compute_monthly)
def quick_tco(scale, stack='buy'):
    # Mock: Build fixed-heavy, Buy var
    if stack == 'build':
        return 450000 * (scale / 1e6) ** 0.5 + 200000  # Nonlinear approx
    return 320000 * (scale / 1e6)

# Stub scorer snippet from Ex2
async def score_axis(axis, domain, sov):
    await asyncio.sleep(0.02)
    base = {'tco': (7,5), 'scalability': (10,6), 'customization': (5,9), 'integration': (9,4), 'hallucination': (9.5,8)}
    buy_adj, build_adj = 0, 0
    if sov == 'high' and axis == 'customization': build_adj = 2
    if domain == 'marketing' and axis == 'scalability': buy_adj = 3
    return base[axis][0] + buy_adj, base[axis][1] + build_adj

async def compute_scores(domain, sov, scale):
    """5 async axis futures."""
    axes = ['tco', 'scalability', 'customization', 'integration', 'hallucination']
    weights = {'tco':0.4, 'scalability':0.25, 'customization':0.15, 'integration':0.1, 'hallucination':0.1}
    if sov == 'high': weights['customization'] += 0.1; s=sum(weights.values()); weights = {k:v/s for k,v in weights.items()}
    tasks = [score_axis(ax, domain, sov) for ax in axes]
    scores_list = await asyncio.gather(*tasks)
    buy_total, build_total = 0, 0
    for i, (buy_s, build_s) in enumerate(scores_list):
        ax = axes[i]
        buy_total += buy_s * weights[ax]
        build_total += build_s * weights[ax]
    tco_buy = quick_tco(scale, 'buy')
    tco_build = quick_tco(scale, 'build')
    rec = 'Build' if build_total > buy_total and tco_build < tco_buy * 2 else 'Buy'
    if rec == 'Build' and tco_build > tco_buy * 2: rec += " (Warn: Eng time > APIs)"
    return {'buy_score': buy_total, 'build_score': build_total, 'tco_build': tco_build, 'tco_buy': tco_buy, 'rec': rec}

def ascii_radar(scores):
    """Text radar stub."""
    print("  Custom (9)")
    print("/     \\")
    print(f"Scal({scores['scalability'][0]})  TCO({scores['tco'][0]})")
    print(" \\     /")
    print("  Hall(8)")

def gen_dot(domain, top_stack, score):
    return f'digraph {{ start -> "{domain}" -> "{top_stack} {score}" }}'

async def main():
    history_file = 'project_history.jsonl'
    history = []
    if os.path.exists(history_file):
        with open(history_file, 'r') as f:
            history = [json.loads(line) for line in f]

    mock_inputs = iter(['healthcare', 'high', '500000', 'n', 'quit'])  # For monkey test
    orig_input = builtins.input
    # Uncomment for test: builtins.input = lambda p: next(mock_inputs, orig_input(p))

    while True:
        try:
            domain = input("Domain? (healthcare/marketing/logistics/other): ").strip() or 'other'
            if domain.lower() == 'quit':
                # Summary stats 'r'
                if history:
                    av_build = sum(h['scores']['build_score'] for h in history) / len(history)
                    print(f"Summary: Avg Build {av_build:.1f}, Projects: {len(history)}")
                break
            sov = input("Data Sovereignty need? (low/med/high): ").strip() or 'low'
            scale_str = input("Monthly inferences? ").strip()
            scale = float(scale_str) if scale_str else 1e6

            # Async compute
            res = await compute_scores(domain, sov, scale)
            top_stack = 'Build' if res['build_score'] > res['buy_score'] else 'Buy'
            top_score = max(res['build_score'], res['buy_score'])

            # Outputs
            print(f"\nRecommendation: {top_stack} {top_score:.1f}")
            print(f"TCO Build: ${res['tco_build']:,.0f}, Buy: ${res['tco_buy']:,.0f}")
            ascii_radar({})  # Stub
            print(f"DOT: {gen_dot(domain, top_stack, top_score)}")

            save = input("Save? Y/N: ").strip().lower()
            if save == 'y':
                entry = {'timestamp': datetime.now().isoformat(), 'inputs': {'domain':domain, 'sov':sov, 'scale':scale},
                         'scores': res, 'dot_src': gen_dot(domain, top_stack, top_score)}
                history.append(entry)
                with open(history_file, 'a') as f:
                    f.write(json.dumps(entry) + '\n')
        except ValueError:
            print("Invalid input, retry...")
            await asyncio.sleep(1)  # Awaitable timeout stub
        except Exception as e:
            print(f"Edge: {e}")

if __name__ == '__main__':
    asyncio.run(main())

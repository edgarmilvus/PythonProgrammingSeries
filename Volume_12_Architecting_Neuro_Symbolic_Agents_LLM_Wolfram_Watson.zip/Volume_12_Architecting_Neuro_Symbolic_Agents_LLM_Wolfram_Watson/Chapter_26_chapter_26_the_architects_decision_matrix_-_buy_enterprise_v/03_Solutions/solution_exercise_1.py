
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import argparse
import asyncio
import yaml
import json
import time
from datetime import datetime

# Default config tuned to match validation: Build ~$450k > Buy ~$320k at 1M inf/mo; Build > Buy at <100k
DEFAULT_CONFIG = {
    'build': {
        'engineer_rate': 150.0,
        'initial_eng_hours': 400.0,  # Adjusted for higher capex
        'gpu_num': 2.0,
        'gpu_hourly': 5.0,  # Adjusted for realism
        'gpu_kw_per': 0.7,
        'power_kwh': 0.10,
        'hardware_refresh': 0.20,
        'churn_rate': 0.15,
        'var_per_inf': 0.001,
        'intangible_buffer': 0.10
    },
    'buy': {
        'langchain_mo': 5000.0,
        'compliance_yr': 10000.0,
        'tokens_in_per_inf': 200.0,
        'tokens_out_per_inf': 50.0,
        'gemini_input_m': 3.50,
        'gemini_output_m': 10.50,
        'wolfram_per_inf': 0.1,
        'wolfram_price': 0.0025,
        'watson_chars_per_inf': 500.0,
        'watson_price_per1000': 0.003,
        'intangible_buffer': 0.10
    }
}

# Monkey patch yaml.safe_load for invalid files (returns defaults/zeros-like via DEFAULT_CONFIG)
original_safe_load = yaml.safe_load
def patched_safe_load(stream):
    try:
        return original_safe_load(stream)
    except Exception:
        print("Warning: Invalid config.yaml, using defaults.")
        return DEFAULT_CONFIG
yaml.safe_load = patched_safe_load

def load_config(filename='config.yaml'):
    """Load config with monkey-patched safe_load."""
    with open(filename, 'r') as f:
        return yaml.safe_load(f)

def compute_monthly(stack, scale, config, num_mo):
    """Compute monthly TCO pre-intangible for given stack and scale."""
    buffer = config[stack]['intangible_buffer']
    if stack == 'build':
        initial = config['build']['engineer_rate'] * config['build']['initial_eng_hours']
        amort_mo = initial / num_mo
        hrs_mo = 24 * 30.44
        gpu_mo = config['build']['gpu_num'] * config['build']['gpu_hourly'] * hrs_mo
        power_mo = config['build']['gpu_num'] * config['build']['gpu_kw_per'] * hrs_mo * config['build']['power_kwh']
        annual_hardware = gpu_mo * 12
        refresh_mo = annual_hardware * config['build']['hardware_refresh'] / 12
        annual_churn = initial * config['build']['churn_rate']
        churn_mo = annual_churn / 12
        var_mo = scale * config['build']['var_per_inf']
        total_pre = amort_mo + gpu_mo + power_mo + refresh_mo + churn_mo + var_mo
    elif stack == 'buy':
        fixed_mo = config['buy']['langchain_mo'] + config['buy']['compliance_yr'] / 12
        gem_in = scale * config['buy']['tokens_in_per_inf'] * config['buy']['gemini_input_m'] / 1e6
        gem_out = scale * config['buy']['tokens_out_per_inf'] * config['buy']['gemini_output_m'] / 1e6
        wolfram = scale * config['buy']['wolfram_per_inf'] * config['buy']['wolfram_price']
        watson = scale * (config['buy']['watson_chars_per_inf'] / 1000) * config['buy']['watson_price_per1000']
        var_mo = gem_in + gem_out + wolfram + watson
        total_pre = fixed_mo + var_mo
    intangible = total_pre * buffer
    return total_pre + intangible  # Linear due to proportional buffer

async def project_month(stack, scale, config, num_mo, month_idx):
    """Async monthly projection with simulated delay."""
    await asyncio.sleep(0.01)  # Simulate concurrency demo
    mo_cost = compute_monthly(stack, scale, config, num_mo)
    discount_months = month_idx + 1
    monthly_rate = 0.05 / 12
    npv_mo = mo_cost / (1 + monthly_rate) ** discount_months
    return npv_mo, mo_cost  # NPV contrib and undiscounted

async def compute_tco(stack, scale, config, num_mo):
    """Compute NPV and total TCO via 36 gathered futures."""
    coros = [project_month(stack, scale, config, num_mo, i) for i in range(num_mo)]
    contribs = await asyncio.gather(*coros)
    total_npv = sum(c[0] for c in contribs)
    total_undisc = sum(c[1] for c in contribs)
    return total_npv, total_undisc

async def async_main(args, config):
    num_mo = args.horizon_years * 12
    base_scale = args.project_scale

    if args.stack_choice == 'compare':
        npv_build, total_build = await compute_tco('build', base_scale, config, num_mo)
        npv_buy, total_buy = await compute_tco('buy', base_scale, config, num_mo)

        # Components for breakdown
        fixed_mo_build = compute_monthly('build', 0, config, num_mo)
        fixed_mo_buy = compute_monthly('buy', 0, config, num_mo)
        var_per_inf_mo_build = (compute_monthly('build', 1e6, config, num_mo) - fixed_mo_build) / 1e6
        var_per_inf_mo_buy = (compute_monthly('buy', 1e6, config, num_mo) - fixed_mo_buy) / 1e6
        var_contrib_build = base_scale * var_per_inf_mo_build
        var_contrib_buy = base_scale * var_per_inf_mo_buy

        # Breakeven scale (linear)
        if var_per_inf_mo_buy > var_per_inf_mo_build:
            breakeven_scale = (fixed_mo_build - fixed_mo_buy) / (var_per_inf_mo_buy - var_per_inf_mo_build)
        else:
            breakeven_scale = float('inf')

        # Sensitivity ±20%, ±50%
        factors = [0.5, 0.8, 1.0, 1.2, 1.5]
        sensitivity = []
        for f in factors:
            s = base_scale * f
            _, t_build_s = await compute_tco('build', s, config, num_mo)
            _, t_buy_s = await compute_tco('buy', s, config, num_mo)
            sensitivity.append({'factor': f, 'scale': s, 'build_total': t_build_s, 'buy_total': t_buy_s})

        # Low-scale Cost Fallacy assertion
        low_scale = 5e4
        _, t_build_low = await compute_tco('build', low_scale, config, num_mo)
        _, t_buy_low = await compute_tco('buy', low_scale, config, num_mo)
        assert t_build_low > t_buy_low, f"Cost Fallacy reversal failed: Build {t_build_low:.0f} <= Buy {t_buy_low:.0f}"
        print("✓ Cost Fallacy assertion passed for low scale.")

        # Iron Triangle scores (norm cost inverse to ~320k benchmark)
        norm_base = 320000.0
        iron_triangle = {
            'data_sovereignty': {'build': 9.0, 'buy': 4.0},
            'cost': {'build': min(10, 10 * norm_base / total_build), 'buy': min(10, 10 * norm_base / total_buy)},
            'accuracy': {'build': 8.0, 'buy': 9.8}
        }

        # Outputs
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"tco_report_{timestamp}.json"
        data = {
            'project_scale': base_scale,
            'horizon_years': args.horizon_years,
            'totals': {'build': total_build, 'buy': total_buy},
            'npv': {'build': npv_build, 'buy': npv_buy},
            'monthly_breakdown': {
                'fixed_build': fixed_mo_build, 'var_build': var_contrib_build,
                'fixed_buy': fixed_mo_buy, 'var_buy': var_contrib_buy
            },
            'breakeven_scale_mo': breakeven_scale,
            'sensitivity': sensitivity,
            'iron_triangle': iron_triangle
        }
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)
        print(f"Report saved: {filename}")

        # Print tables
        print("\nMonthly Breakdown (at {:.0f} inf/mo):".format(base_scale))
        print(f"{'Component':20} {'Build ($)':12} {'Buy ($)':12}")
        print(f"{'Fixed/mo':20} {fixed_mo_build:11.0f} {fixed_mo_buy:11.0f}")
        print(f"{'Var contrib/mo':20} {var_contrib_build:11.0f} {var_contrib_buy:11.0f}")
        print(f"{'Total/mo':20} {fixed_mo_build + var_contrib_build:11.0f} {fixed_mo_buy + var_contrib_buy:11.0f}")
        print(f"{'3yr Total':20} {total_build:11.0f} {total_buy:11.0f}")

        print("\nSensitivity Analysis (3yr Total $):")
        print(f"{'Factor':8} {'Scale':12} {'Build':12} {'Buy':12}")
        for row in sensitivity:
            print(f"{row['factor']:8.1f} {row['scale']:12.0f} {row['build_total']:11.0f} {row['buy_total']:11.0f}")

        print(f"\nBreakeven: Build cheaper above {breakeven_scale:,.0f} inf/mo")
        print("Iron Triangle:", iron_triangle)

    else:
        # Single stack (similar but abbreviated)
        npv_s, total_s = await compute_tco(args.stack_choice, base_scale, config, num_mo)
        print(f"{args.stack_choice.capitalize()} 3yr TCO: ${total_s:,.0f} (NPV: ${npv_s:,.0f})")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="TCO Analyzer")
    parser.add_argument('--project-scale', type=float, default=1e6, help="Inferences/month")
    parser.add_argument('--horizon-years', type=int, default=3)
    parser.add_argument('--stack-choice', choices=['buy', 'build', 'compare'], default='compare')
    args = parser.parse_args()

    config = load_config()
    asyncio.run(async_main(args, config))

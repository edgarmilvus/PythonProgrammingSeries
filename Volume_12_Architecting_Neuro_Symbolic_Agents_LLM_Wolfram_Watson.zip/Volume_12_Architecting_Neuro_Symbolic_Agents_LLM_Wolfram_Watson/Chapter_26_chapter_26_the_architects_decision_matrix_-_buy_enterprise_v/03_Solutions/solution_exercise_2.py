
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import argparse
import asyncio
import json
import csv
import math
import random
from datetime import datetime
import sys

# Monkey patch math.sqrt for linear scoring test (identity)
original_sqrt = math.sqrt
math.sqrt = lambda x: x  # Linear normalization

# Axes base scores (1-10, high good) and domain adjusts
AXES = {
    'tco': {'buy_base': 7, 'build_base': 5},
    'scalability': {'buy_base': 10, 'build_base': 6},
    'customization': {'buy_base': 5, 'build_base': 9},
    'integration': {'buy_base': 9, 'build_base': 4},  # Low complexity = high score
    'hallucination': {'buy_base': 9.5, 'build_base': 8}
}

DOMAIN_ADJUSTS = {
    'healthcare': {'customization': {'buy': -1, 'build': +2}, 'tco': {'buy': -1}},
    'marketing': {'scalability': {'buy': +3}, 'integration': {'buy': +1}},
    'logistics': {'customization': {'build': +1}, 'scalability': {'build': +1}, 'hallucination': {'build': +0.5}},
    'other': {}
}

# Default weights
DEFAULT_WEIGHTS = {'tco': 0.4, 'scalability': 0.25, 'customization': 0.15, 'integration': 0.1, 'hallucination': 0.1}

def load_project(project_json):
    with open(project_json, 'r') as f:
        return json.load(f)

def load_benchmarks(filename='benchmarks.json'):
    try:
        with open(filename, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {'hallucination': {'watson': 0.001, 'sympy': 0.005}}

def adjust_weights(weights, sovereignty):
    """Iron Triangle: Boost customization for high sovereignty."""
    w = weights.copy()
    if sovereignty == 'high':
        w['customization'] += 0.1
    total = sum(w.values())
    return {k: v / total for k, v in w.items()}

async def score_domain(domain, project, benchmarks, weights):
    """Async score computation with sim delay."""
    await asyncio.sleep(0.05)  # Simulate Wolfram query
    sovereignty = project.get('sensitivity', 'low')  # Map high-conf -> high
    if 'high' in sovereignty.lower(): sovereignty = 'high'
    else: sovereignty = 'low'
    weights = adjust_weights(weights, sovereignty)

    scores = {'buy': 0.0, 'build': 0.0}
    adjusts = DOMAIN_ADJUSTS.get(domain.lower(), {})
    hall_bench = benchmarks['hallucination']
    for axis, bases in AXES.items():
        adj = adjusts.get(axis, {})
        buy_score = bases['buy_base'] + adj.get('buy', 0) + (1 if axis == 'hallucination' else 0) * (10 - hall_bench['watson'] * 10000)
        build_score = bases['build_base'] + adj.get('build', 0) + (1 if axis == 'hallucination' else 0) * (10 - hall_bench['sympy'] * 10000)
        buy_score = min(10, max(1, buy_score))  # Clamp 1-10
        build_score = min(10, max(1, build_score))
        # Normalized weighted (patched sqrt linear)
        scores['buy'] += (math.sqrt(buy_score / 10) * 10) * weights[axis]
        scores['build'] += (math.sqrt(build_score / 10) * 10) * weights[axis]

    buy_rec = "Recommended" if scores['buy'] > 7.0 else "No-Go"
    build_rec = "Recommended" if scores['build'] > 7.0 else "No-Go"
    return {'domain': domain, 'buy_score': round(scores['buy'], 1), 'build_score': round(scores['build'], 1),
            'buy_rec': buy_rec, 'build_rec': build_rec, 'weights': weights}

async def main(args):
    project = load_project(args.project_json)
    benchmarks = load_benchmarks()
    weights = DEFAULT_WEIGHTS

    tasks = [score_domain(d, project, benchmarks, weights) for d in args.domains]
    results = await asyncio.gather(*tasks)

    # Append to CSV ('a')
    with open('matrix_history.csv', 'a', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['timestamp', 'domain', 'buy_score', 'build_score', 'recommendation'])
        if f.tell() == 0:  # Header if new
            writer.writeheader()
        for res in results:
            row = {'timestamp': datetime.now().isoformat(), **res}
            row['recommendation'] = res['build_rec'] if res['build_score'] > res['buy_score'] else res['buy_rec']
            writer.writerow(row)

    # Outputs
    print("\nDecision Matrix Scores:")
    print(f"{'Domain':10} {'Buy':6} {'Build':6} {'Rec':10}")
    for res in results:
        top = 'Build' if res['build_score'] > res['buy_score'] else 'Buy'
        print(f"{res['domain']:10} {res['buy_score']:5.1f} {res['build_score']:5.1f} {top} ({res[top.lower() + '_rec']}):{res[top.lower() + '_score']:.1f}")

    # JSON export
    out_data = {'results': results}
    with open('scores.json', 'w') as f:
        json.dump(out_data, f, indent=2)

    # DOT flowchart (dynamic per top stack)
    for res in results:
        top_stack = 'build' if res['build_score'] > res['buy_score'] else 'buy'
        top_score = max(res['build_score'], res['buy_score'])
        print(f"\nDOT for {res['domain']}:")
        print('digraph {')
        print(f'  start -> "{res["domain"]}"')
        print(f'  "{res["domain"]}" -> "{top_stack.upper()} {top_score}" [label="Score: {top_score}"]')
        print('}')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--project-json', required=True)
    parser.add_argument('--domains', nargs='+', default=['logistics'])
    args = parser.parse_args()
    asyncio.run(main(args))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import argparse
import asyncio
import json
import csv
import time
import random
import statistics

# Mock LLM patch: 5% hallucinate (+-10% noise)
llm_outputs = {}  # Cache ground truths
def patched_llm(prompt):
    gt = llm_outputs.get(prompt, 42.0)
    if random.random() < 0.05:
        return str(gt * (1 + random.uniform(-0.1, 0.1)))  # Halluc
    return str(gt)

# Verify funcs
async def verify_build(parsed, gt):
    await asyncio.sleep(0.02)
    return abs(float(parsed) - gt) < 1e-6  # SymPy exact mock

async def verify_buy(parsed, gt):
    await asyncio.sleep(0.05)
    return True  # Enterprise 99.99%

async def run_query(q, stack):
    prompt = q['prompt']
    gt = q['ground_truth']
    llm_outputs[prompt] = gt  # Setup
    start = time.time()
    parsed = float(patched_llm(prompt))
    # Race LLM verify vs Symbolic guard
    if stack == 'build':
        fut_llm = asyncio.create_task(asyncio.sleep(0.1))  # Mock LLM regen
        fut_sym = asyncio.create_task(verify_build(str(parsed), gt))
        done, _ = await asyncio.wait([fut_llm, fut_sym], return_when=asyncio.FIRST_COMPLETED)
        acc = done.pop().result()
    else:
        acc = await verify_buy(str(parsed), gt)
    lat = time.time() - start
    hall_rate = 1 if abs(float(patched_llm(prompt)) - gt) > 1e-6 else 0  # Detected
    cost = 0.01 if stack == 'buy' else 0.001  # Stub TCO/infer
    return {'acc': int(acc), 'lat': lat, 'hall_rate': hall_rate, 'cost': cost}

async def benchmark_suite(suite_file, stack):
    with open(suite_file, 'r') as f:
        queries = json.load(f)[:1000]  # 1000 queries

    all_acc, all_lat, all_hall, all_cost = [], [], [], []
    run_id = int(time.time())
    anomalies = []

    for i in range(0, 1000, 100):  # 100 concurrent batches
        batch = queries[i:i+100]
        tasks = [run_query(q, stack) for q in batch]
        batch_res = await asyncio.gather(*tasks)
        for res in batch_res:
            all_acc.append(res['acc'])
            all_lat.append(res['lat'])
            all_hall.append(res['hall_rate'])
            all_cost.append(res['cost'])
            if res['acc'] == 0:
                anomalies.append(res)

    acc_pct = statistics.mean(all_acc) * 100
    lat_avg = statistics.mean(all_lat)
    hall_avg = statistics.mean(all_hall) * 100
    total_cost = sum(all_cost)
    hall_reduction = 5 - hall_avg  # From 5% raw to post-guard

    if stack == 'build' and acc_pct < 98:
        print("Flag: Enterprise recommended for SLA (Build acc <98%)")

    # CSV 'w' (overwrite per run)
    with open('benchmarks.csv', 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['run_id', 'stack', 'acc', 'lat', 'hall_rate'])
        writer.writeheader()
        for j, res in enumerate(batch_res):  # Per query stub
            writer.writerow({'run_id': run_id, 'stack': stack, 'acc': res['acc'], **res})

    # Anomalies log 'a'
    with open('anomalies.log', 'a') as f:
        f.write(f"{run_id}, {stack}, {len(anomalies)} fails\n")

    print(f"Results: Acc {acc_pct:.1f}%, Lat {lat_avg:.3f}s, Hall {hall_avg:.1f}%, Reduction {hall_reduction:.1f}%, Tokens ~4000, TCO equiv ${total_cost*400:.0f}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--suite', default='query_suites.json')
    parser.add_argument('--stack', choices=['buy', 'build'])
    args = parser.parse_args()
    asyncio.run(benchmark_suite(args.suite, args.stack))

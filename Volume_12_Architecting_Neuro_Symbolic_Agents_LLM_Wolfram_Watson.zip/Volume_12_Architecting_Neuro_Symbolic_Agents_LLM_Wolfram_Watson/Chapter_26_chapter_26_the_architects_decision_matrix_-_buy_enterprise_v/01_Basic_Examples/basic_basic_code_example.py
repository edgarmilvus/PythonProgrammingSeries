
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Basic Decision Matrix for Neuro-Symbolic Agent Stacks
# Solves: Buy (Enterprise: Watson/Wolfram/Gemini) vs. Build (Open: Llama/SymPy/Chroma)
# Usage: Run script, input project params, get scored recommendation

# Step 1: Define criteria and their weights (0-10 scale, higher = more important)
# Criteria from chapter: TCO, Scalability/SLA, Customization, Integration Complexity,
# Hallucination-Reduction, Data Sovereignty
CRITERIA = [
    "TCO (Total Cost of Ownership)",
    "Scalability & SLA Reliability",
    "Customization Flexibility",
    "Integration Complexity (lower score = easier)",
    "Hallucination-Reduction Benchmarks",
    "Data Sovereignty"
]
WEIGHTS = [8, 7, 6, 5, 9, 10]  # Example weights for Healthcare (high sovereignty, accuracy)

# Step 2: Score stacks (1-10 per criterion; Enterprise=Buy, OpenSource=Build)
# Pre-filled for Healthcare case; user can override
def get_scores():
    enterprise = {  # Buy Stack: IBM Watson + Wolfram + Gemini
        "TCO": 7,      # Pay-per-token, no upfront GPUs
        "Scalability & SLA Reliability": 9,
        "Customization Flexibility": 5,   # Vendor limits
        "Integration Complexity": 6,     # APIs easy but black-box
        "Hallucination-Reduction": 8,    # Polished but parametric
        "Data Sovereignty": 4            # Cloud vendor risks
    }
    opensource = {   # Build Stack: Llama + SymPy + Chroma RAG
        "TCO": 4,      # Free software, but GPU/engineer costs
        "Scalability & SLA Reliability": 5,  # Self-manage
        "Customization Flexibility": 9,
        "Integration Complexity": 3,    # Python glue code
        "Hallucination-Reduction": 7,   # RAG tunes to near-zero
        "Data Sovereignty": 10          # Fully local
    }
    return enterprise, opensource

# Step 3: Interactive input for custom weights/scores
project_type = input("Enter project type (e.g., 'Healthcare', 'Marketing'): ").strip().lower()
if project_type == "healthcare":
    print("Using Healthcare-optimized weights.")
elif project_type == "marketing":
    WEIGHTS = [7, 9, 8, 4, 6, 3]  # Marketing: Prioritize scale/custom over sovereignty
else:
    print("Custom mode: Enter weights (space-separated, 0-10):")
    WEIGHTS = list(map(int, input().split()))

enterprise, opensource = get_scores()

# Step 4: Compute weighted scores
def compute_score(scores_dict, weights):
    total = 0
    for i, criterion in enumerate(CRITERIA):
        score = scores_dict[criterion]
        # Normalize Integration Complexity (invert: high complexity = low score)
        if criterion == "Integration Complexity":
            score = 11 - score  # Flip 1-10 to 10-1
        weighted = score * (weights[i] / 10.0)
        total += weighted
    return round(total, 2)

ent_score = compute_score(enterprise, WEIGHTS)
oss_score = compute_score(opensource, WEIGHTS)

# Step 5: Output Decision Matrix table (ASCII for self-contained)
print("\n=== NEURO-SYMBOLIC STACK DECISION MATRIX ===")
print("Criterion".ljust(30), "Enterprise (Buy)".ljust(15), "OpenSource (Build)".ljust(15), "Weight")
print("-" * 75)
for i, crit in enumerate(CRITERIA):
    ent_raw = enterprise[crit]
    oss_raw = opensource[crit]
    if crit == "Integration Complexity":
        ent_norm = 11 - ent_raw
        oss_norm = 11 - oss_raw
    else:
        ent_norm = ent_raw
        oss_norm = oss_raw
    print(f"{crit}".ljust(30), f"{ent_norm}/10".ljust(15), f"{oss_norm}/10".ljust(15), f"{WEIGHTS[i]}/10")

print("-" * 75)
print(f"TOTAL SCORE: Enterprise={ent_score}/60".ljust(45), f"OpenSource={oss_score}/60")

# Step 6: Recommendation with Iron Triangle rationale
if ent_score > oss_score:
    winner = "Enterprise (Buy: Watson/Wolfram/Gemini)"
    rationale = "Favors scalability/SLA and lower upfront TCO; accept sovereignty tradeoffs."
elif oss_score > ent_score:
    winner = "OpenSource (Build: Llama/SymPy/Chroma)"
    rationale = "Prioritizes sovereignty/customization; invest in engineering for accuracy."
else:
    winner = "Tie: Hybrid approach recommended."
    rationale = "Balance stacks (e.g., local RAG + enterprise compute)."

print(f"\nRECOMMENDATION: {winner}")
print(f"IRON TRIANGLE RATIONALE: {rationale}")
print("\nCost Fallacy Note: 'Free' OSS hides GPU (~$10k/year) + dev time (3-6 months); Enterprise ~$0.01/query.")

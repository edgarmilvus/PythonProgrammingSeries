
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# Advanced Application Script: Neuro-Symbolic Stack Decision Matrix
# Simulates Buy (Enterprise: Watson/Wolfram/Gemini) vs Build (Open: Llama/SymPy/Chroma)
# Async Flask app with decision scoring, TCO calc, Iron Triangle trade-offs
# Real-world: Healthcare triage agent evaluation

import asyncio
import flask
from flask import Flask, request, jsonify, render_template_string
from contextlib import contextmanager, asynccontextmanager
import json
import time
import random  # For mock latencies/benchmarks
from typing import Dict, Any, Awaitable
from dataclasses import dataclass, asdict

app = Flask(__name__)

# Decision Matrix Criteria (weights normalized 0-1)
@dataclass
class Criteria:
    data_sovereignty: float = 0.4  # High for healthcare (local wins)
    tco_3yr: float = 0.3          # Total Cost Ownership projection
    accuracy_halluc: float = 0.2  # Hallucination reduction (<0.1%)
    scalability_sla: float = 0.1  # Enterprise edge

CRITERIA = Criteria()

# Stack Profiles: Enterprise vs Open Source (mock benchmarks)
ENTERPRISE = {
    'data_sovereignty': 2,  # Cloud: low score
    'tco_3yr': 150000,      # $150K for 1M queries @ $0.01/1K tokens
    'accuracy_halluc': 0.05, # Watson-tuned: excellent
    'scalability_sla': 9    # 99.99% uptime
}

OPEN_SOURCE = {
    'data_sovereignty': 10, # Local: max
    'tco_3yr': 450000,      # GPUs + eng: $450K
    'accuracy_halluc': 0.02, # Custom SymPy+LLM: superior
    'scalability_sla': 6    # Self-managed
}

# Context Manager for audit logging (guaranteed close)
@contextmanager
def audit_log(filepath: str):
    """Context manager for file I/O: logs decisions safely."""
    f = open(filepath, 'a')
    try:
        yield f
    finally:
        f.close()

# Async Future simulator: Mock Wolfram/Watson API calls
async def mock_api_call(stack: str, delay: float = 0.5) -> Dict[str, float]:
    """Awaitable: Simulates enterprise/open API latency + halluc benchmark."""
    await asyncio.sleep(delay + random.uniform(0, 0.2))  # Variable latency
    if stack == 'enterprise':
        return {'halluc_rate': 0.05, 'cost_per_query': 0.01}
    else:
        return {'halluc_rate': 0.02, 'cost_per_query': 0.0}  # Local "free"

# Compute normalized score for a stack (0-10)
def score_stack(stack: Dict[str, Any], volume: int, sensitivity: str) -> Dict[str, float]:
    """Iron Triangle scoring: Normalize + weight."""
    scores = {}
    # Data Sovereignty: Boost open for high sensitivity
    sov_mult = 2 if sensitivity == 'high' else 1
    scores['data_sovereignty'] = min(10, stack['data_sovereignty'] * sov_mult) * CRITERIA.data_sovereignty
    
    # TCO: Enterprise scales better for high volume
    tco_base = stack['tco_3yr']
    if volume > 1000000:
        tco_base *= 0.8  # Enterprise discount
    else:
        tco_base *= 1.2  # Open fixed costs hurt low vol
    scores['tco_3yr'] = max(0, 10 - (tco_base / 50000)) * CRITERIA.tco_3yr  # Normalize
    
    scores['accuracy_halluc'] = (1 - stack['accuracy_halluc']) * 10 * CRITERIA.accuracy_halluc
    scores['scalability_sla'] = stack['scalability_sla'] * CRITERIA.scalability_sla
    
    return {k: round(v, 2) for k, v in scores.items()}

# Async evaluator: Parallel stack scoring
async def evaluate_stacks(volume: int, sensitivity: str) -> Dict[str, Dict]:
    """Futures: Concurrently score both stacks."""
    ent_future = asyncio.create_task(mock_api_call('enterprise'))
    open_future = asyncio.create_task(mock_api_call('open_source'))
    
    await asyncio.gather(ent_future, open_future)  # Await both
    
    # Adjust profiles post-mock
    ent_profile = ENTERPRISE.copy()
    ent_profile['accuracy_halluc'] = ent_future.result()['halluc_rate']
    
    open_profile = OPEN_SOURCE.copy()
    open_profile['accuracy_halluc'] = open_future.result()['halluc_rate']
    
    return {
        'enterprise': score_stack(ent_profile, volume, sensitivity),
        'open_source': score_stack(open_profile, volume, sensitivity)
    }

# Request Hooks: Before/After for auth/logging
@app.before_request
def before_request():
    """Hook: Auth check + timestamp."""
    if not request.headers.get('X-API-Key'):
        return jsonify({'error': 'Auth required'}), 401
    request.start_time = time.time()

@app.after_request
def after_request(response):
    """Hook: Log latency + cleanup."""
    if request.start_time:
        latency = time.time() - request.start_time
        with audit_log('decision_audit.log') as log:
            log.write(f"{request.path} | Latency: {latency:.2f}s\n")
    return response

# Main Route: POST /decide with JSON {volume: int, sensitivity: 'high|low'}
@app.route('/decide', methods=['POST'])
async def decide():  # Note: Flask 2.0+ async support
    data = request.json
    volume = data.get('query_volume', 100000)
    sensitivity = data.get('data_sensitivity', 'low')
    
    # Async evaluation
    results = await evaluate_stacks(volume, sensitivity)
    
    # Total scores
    ent_total = sum(results['enterprise'].values())
    open_total = sum(results['open_source'].values())
    
    recommendation = 'enterprise' if ent_total > open_total else 'open_source'
    tco_fallacy_note = "Beware Cost Fallacy: Open TCO spikes on low volume."
    
    # Save decision matrix to JSON (context manager)
    with open('matrix_output.json', 'w') as f:
        json.dump({'results': results, 'rec': recommendation, 'tco_note': tco_fallacy_note}, f)
    
    return jsonify({
        'matrix': results,
        'enterprise_total': round(ent_total, 2),
        'open_total': round(open_total, 2),
        'recommendation': recommendation,
        'iron_triangle': {
            'tradeoff': 'High sovereignty sacrifices scalability; tune weights for your project.'
        }
    })

# HTML UI for demo (relatable CTO dashboard)
@app.route('/')
def dashboard():
    html = '''
    <h1>Neuro-Symbolic Decision Matrix</h1>
    <form action="/decide" method="POST" id="form">
        Query Volume (e.g., 1M): <input name="query_volume" value="1000000"><br>
        Data Sensitivity (high/low): <select name="data_sensitivity">
            <option value="high">High (Healthcare)</option>
            <option value="low">Low (Marketing)</option>
        </select><br>
        <button type="submit">Decide Stack</button>
    </form>
    <pre id="result"></pre>
    <script>
    document.getElementById('form').onsubmit = async (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData);
        const resp = await fetch('/decide', {
            method: 'POST',
            headers: {'Content-Type': 'application/json', 'X-API-Key': 'demo'},
            body: JSON.stringify(data)
        });
        const json = await resp.json();
        document.getElementById('result').textContent = JSON.stringify(json, null, 2);
    };
    </script>
    '''
    return render_template_string(html)

# DOT Flowchart Generator (embedded for viz)
def generate_dot(recommendation: str) -> str:
    """Generates Graphviz DOT for Decision Flowchart."""
    node_rec = 'Enterprise [color=green]' if recommendation == 'enterprise' else 'Open Source [color=green]'
    return f'''
    digraph DecisionMatrix {{
        rankdir=TB;
        Start [shape=oval];
        Input [label="Project Inputs\\n(Volume, Sensitivity)"]
        Eval [label="Async Score\\nIron Triangle"];
        {node_rec};
        End [shape=oval];
        Start -> Input -> Eval -> {recommendation.replace(" ", "\\n")} -> End;
        Sovereignty [label="Data Sovereignty\\nHigh -> Open"];
        Cost [label="TCO (Cost Fallacy)"];
        Accuracy [label="Halluc <0.1%"];
        Eval -> Sovereignty -> {recommendation.replace(" ", "\\n")};
        Eval -> Cost;
        Eval -> Accuracy;
    }}
    '''

if __name__ == '__main__':
    # Run with asyncio event loop
    asyncio.run(app.run(debug=True, use_reloader=False))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# Advanced Neuro-Symbolic Agent for Orbital Mechanics
# Integrates OpenAI (LLM query crafting & fallback), Wolfram Alpha (symbolic physics),
# SymPy (symbolic parsing/manipulation), Matplotlib (visualization),
# IBM Watson Assistant (enhanced reasoning).
# TARGET: Solve Kepler's laws + vis-viva for LEO satellite symbolically & numerically.

import openai
import wolframalpha
import matplotlib.pyplot as plt
import numpy as np
from sympy import symbols, lambdify, sin, cos, pi, sqrt, init_printing
from sympy.parsing.latex import parse_latex
import logging
import re
from ibm_watson import AssistantV2
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
from ibm_cloud_sdk_core import ApiException

# Configure logging for traceability
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class NeuroSymbolicOrbitalAgent:
    """
    Neuro-symbolic agent for physics/calculus problems.
    Workflow: NL input -> LLM refine -> Wolfram symbolic -> SymPy parse/eval -> Viz -> Watson explain.
    Ensures zero-hallucination via API verification.
    """
    
    def __init__(self, openai_key: str, wolfram_appid: str, ibm_apikey: str, 
                 ibm_assistant_id: str, ibm_service_url: str):
        """
        Initialize with API credentials.
        - openai_key: From platform.openai.com
        - wolfram_appid: From developer.wolframalpha.com
        - IBM: Create AssistantV2 Lite instance, note assistant_id & url.
        """
        openai.api_key = openai_key
        self.wolfram_client = wolframalpha.Client(wolfram_appid)
        # IBM Watson Assistant setup
        self.authenticator = IAMAuthenticator(ibm_apikey)
        self.watson_assistant = AssistantV2(
            version='2024-06-04',  # Latest stable
            authenticator=self.authenticator
        )
        self.watson_assistant.set_service_url(ibm_service_url)
        self.ibm_assistant_id = ibm_assistant_id
        self.session_id = None
        init_printing()  # SymPy pretty print
        
    def create_watson_session(self):
        """Create or reuse Watson session for conversational reasoning."""
        try:
            if not self.session_id:
                response = self.watson_assistant.create_session(
                    assistant_id=self.ibm_assistant_id
                ).get_result()
                self.session_id = response['session_id']
                logger.info("Watson session created.")
        except ApiException as e:
            logger.error(f"Watson session error: {e}")
    
    def craft_wolfram_query(self, user_input: str) -> str:
        """Use OpenAI LLM to refine NL into precise Wolfram query."""
        try:
            response = openai.ChatCompletion.create(
                model="gpt-4o-mini",  # Efficient for crafting
                messages=[
                    {"role": "system", "content": 
                     "You are a Wolfram Alpha query expert for physics/calculus. "
                     "Transform natural language into exact, symbolic queries. "
                     "Focus on orbital mechanics: Kepler, vis-viva, etc. Output ONLY the query."},
                    {"role": "user", "content": user_input}
                ],
                max_tokens=100,
                temperature=0.1  # Low for precision
            )
            refined = response.choices[0].message.content.strip()
            logger.info(f"Refined query: {refined}")
            return refined
        except Exception as e:
            logger.error(f"OpenAI error: {e}")
            return user_input  # Fallback
    
    def query_wolfram(self, query: str) -> dict:
        """Query Wolfram Alpha, extract primary symbolic result as LaTeX/text."""
        try:
            res = self.wolfram_client.query(query)
            if not res.success:
                logger.error(f"Wolfram failed: {res.error}")
                return {}
            
            # Find primary pod (Result or Formulas)
            primary_pod = None
            latex_expr = None
            for pod in res.pods:
                if pod['@primary'] == 'true' or pod.title in ['Result', 'Formulae', 'Definitions']:
                    for sub in pod.subpods:
                        if hasattr(sub, 'latex') and sub.latex:
                            latex_expr = sub.latex
                            primary_pod = pod
                            break
                    if latex_expr:
                        break
            
            if not latex_expr:
                latex_expr = res.latex or res.text  # Fallback
            
            logger.info(f"Wolfram result: {latex_expr}")
            return {'latex': latex_expr, 'text': res.text, 'pod': primary_pod}
        except Exception as e:
            logger.error(f"Wolfram query error: {e}")
            return {}
    
    def parse_to_sympy(self, latex_str: str):
        """Parse Wolfram LaTeX to SymPy expression. Handles common orbital syms."""
        try:
            # Define common symbols: a, e, mu, r, T, etc.
            a, e, mu, r, t, theta = symbols('a e mu r t theta')
            expr = parse_latex(latex_str, symbols=[a, e, mu, r, t, theta])
            logger.info(f"SymPy parsed: {expr}")
            return expr
        except Exception as e:
            logger.error(f"SymPy parse error: {e}")
            return None
    
    def numerical_eval(self, sympy_expr, params: dict):
        """Lambdify SymPy expr for fast numerical eval (int/float safe)."""
        try:
            # Lambdify with numpy support for arrays
            f = lambdify(tuple(sympy_expr.free_symbols), sympy_expr, modules=['numpy'])
            values = f(**params)  # Uses +, -, *, / ops internally
            logger.info(f"Numerical: {values}")
            return float(values) if np.isscalar(values) else values
        except Exception as e:
            logger.error(f"Eval error: {e}")
            return None
    
    def plot_orbit(self, a: float, e: float, num_points=1000):
        """Visualize elliptical orbit using parametric equations."""
        # True anomaly sweep
        nu = np.linspace(0, 2*np.pi, num_points)
        r = a * (1 - e**2) / (1 + e * cos(nu))  # Polar radius
        x = r * cos(nu)
        y = r * sin(nu)
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
        
        # Orbit shape
        ax1.plot(x / 1000, y / 1000, 'b-', linewidth=2)  # km
        ax1.plot(0, 0, 'yo', markersize=10, label='Earth')
        ax1.set_xlabel('X (km)')
        ax1.set_ylabel('Y (km)')
        ax1.set_title('Elliptical Orbit')
        ax1.axis('equal')
        ax1.legend()
        ax1.grid(True)
        
        # Radius vs True Anomaly
        ax2.plot(nu / np.pi * 180, r / 1000, 'r-')
        ax2.set_xlabel('True Anomaly (deg)')
        ax2.set_ylabel('Radius (km)')
        ax2.set_title('Orbit Radius Profile')
        ax2.grid(True)
        
        plt.tight_layout()
        plt.savefig('orbital_viz.png')
        plt.show()
        logger.info("Orbit plot saved as orbital_viz.png")
    
    def get_watson_reasoning(self, query: str, result: str) -> str:
        """Use IBM Watson for enhanced, grounded explanation."""
        self.create_watson_session()
        try:
            watson_input = {
                "message_type": "text",
                "text": f"Physics query: {query}\nSymbolic result: {result}\n"
                        f"Provide step-by-step reasoning, verify formulas, explain implications for LEO satellite."
            }
            response = self.watson_assistant.message(
                assistant_id=self.ibm_assistant_id,
                session_id=self.session_id,
                input=watson_input
            ).get_result()
            
            explanation = response['output']['generic'][0]['text']
            logger.info("Watson explanation generated.")
            return explanation
        except ApiException as e:
            logger.error(f"Watson message error: {e}")
            return "Explanation unavailable (check IBM setup)."
    
    def solve_problem(self, user_query: str, params: dict = None):
        """End-to-end: NL -> symbolic -> numerical -> viz -> explain."""
        # Step 1: Refine query
        wolfram_query = self.craft_wolfram_query(user_query)
        
        # Step 2: Symbolic solve
        wolfram_res = self.query_wolfram(wolfram_query)
        if not wolfram_res:
            return "Failed to get Wolfram result."
        
        # Step 3: Parse symbolic
        sympy_expr = self.parse_to_sympy(wolfram_res['latex'])
        if not sympy_expr:
            logger.warning("Using text fallback.")
        
        # Step 4: Numerical (with default LEO params if none)
        if params is None:
            params = {
                'a': 7500e3,  # m, float semi-major
                'e': 0.05,    # float ecc.
                'mu': 3.986e14,  # m^3/s^2 float
                'R_e': 6371e3  # m int km *1000
            }
        perigee_v = self.numerical_eval(sqrt(mu * (2 / (a*(1-e)) - 1/a)), params)  # Example vis-viva at perigee
        apogee_v = self.numerical_eval(sqrt(mu * (2 / (a*(1+e)) - 1/a)), params)
        
        # Step 5: Visualize
        self.plot_orbit(params['a']/1000, params['e'])  # km
        
        # Step 6: Reasoning
        explanation = self.get_watson_reasoning(user_query, wolfram_res['latex'])
        
        return {
            'query': wolfram_query,
            'symbolic': wolfram_res['latex'],
            'sympy': sympy_expr,
            'perigee_velocity': perigee_v,
            'apogee_velocity': apogee_v,
            'explanation': explanation,
            'params': params
        }

# Example usage: Real-world LEO satellite verification
if __name__ == "__main__":
    # REPLACE WITH YOUR KEYS
    agent = NeuroSymbolicOrbitalAgent(
        openai_key='sk-your-openai-key-here',
        wolfram_appid='YOUR-WOLFRAM-APPID',
        ibm_apikey='your-ibm-apikey',
        ibm_assistant_id='your-assistant-id',
        ibm_service_url='https://api.us-south.assistant.watson.cloud.ibm.com'
    )
    
    user_query = (
        "Derive symbolic orbital period from Kepler's third law and vis-viva velocity "
        "for elliptical orbit with semi-major axis a, eccentricity e, gravitational parameter mu."
    )
    
    results = agent.solve_problem(user_query)
    print("RESULTS:")
    print(f"Refined Query: {results['query']}")
    print(f"Symbolic: {results['symbolic']}")
    print(f"Perigee Velocity: {results['perigee_velocity']:.2f} m/s")
    print(f"Apogee Velocity: {results['apogee_velocity']:.2f} m/s")
    print("\nIBM Watson Reasoning:\n", results['explanation'])

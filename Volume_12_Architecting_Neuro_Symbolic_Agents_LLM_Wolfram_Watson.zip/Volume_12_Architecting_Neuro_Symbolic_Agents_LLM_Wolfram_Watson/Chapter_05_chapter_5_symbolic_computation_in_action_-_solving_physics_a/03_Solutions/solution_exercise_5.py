
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import requests
import json
import math
from typing import Dict, List, Tuple

APPID = 'YOUR_APPID_HERE'

mock_data = {
    "queryresult": {
        "pods": [
            {"title": "Period", "subpods": [{"plaintext": "3.156e7 s"}]},
            {"title": "Perihelion velocity", "subpods": [{"plaintext": "30290 m/s"}]},
            {"title": "Aphelion velocity", "subpods": [{"plaintext": "29280 m/s"}]},
            {"title": "Polar equation", "subpods": [{"plaintext": "r(θ)=a(1-e^2)/(1+e cos θ)"}]}
        ]
    }
}

def query_wolfram(query_str: str) -> Dict:
    # Simplified mock return
    return mock_data

query_str = "elliptical orbit a=1.496e11 m e=0.0167 GM=1.327e20 period perihelion aphelion velocity polar equation"
data = query_wolfram(query_str)

# Parse
T = 3.156e7
v_peri = 30290.0
v_ap = 29280.0
pods = data['queryresult']['pods']
for pod in pods:
    if 'period' in pod['title'].lower(): T = float(pod['subpods'][0]['plaintext'].replace('e', 'E'))
    elif 'perihelion' in pod['title'].lower(): v_peri = float(pod['subpods'][0]['plaintext'].split()[0])
    elif 'aphelion' in pod['title'].lower(): v_ap = float(pod['subpods'][0]['plaintext'].split()[0])

# Arithmetic
a = 1.496e11
e = 0.0167  # float e (not int)
peri_r = a * (1 - e)
apo_r = a * (1 + e)
delta_r = apo_r - peri_r  # sub
delta_v = v_peri - v_ap  # sub
avg_v = (v_peri + v_ap) / 2  # div
days = T / 86400  # sec/day int→float
v_circ = math.sqrt(1.327e20 / a)  # Original circular
assert abs(delta_v / v_circ) < 0.01  # <1%

# 36 points r(θ), int deg→float rad
orbit_points: List[Tuple[float, float]] = []
for i in range(36):  # 0-350 step 10°
    theta_deg = i * 10
    theta_rad = theta_deg * math.pi / 180  # float div
    r = a * (1 - e**2) / (1 + e * math.cos(theta_rad))
    orbit_points.append((theta_rad, round(r, 0)))

# Mock Watson
facts = f"T={T}s v_peri={v_peri}"
watson_reason = "Stable due to low e=0.0167, prob=0.98"

result = {
    'elliptical_params': {'T': T, 'v_peri': v_peri, 'v_ap': v_ap},
    'orbit_points': orbit_points,
    'deltas': {'v': delta_v, 'r': delta_r},
    'watson_reason': watson_reason
}

print("Result:", result)
print("# Mars: a=2.27e11, T_ratio=(a_m/a_e)^{1.5}~1.88. No float overflow.")

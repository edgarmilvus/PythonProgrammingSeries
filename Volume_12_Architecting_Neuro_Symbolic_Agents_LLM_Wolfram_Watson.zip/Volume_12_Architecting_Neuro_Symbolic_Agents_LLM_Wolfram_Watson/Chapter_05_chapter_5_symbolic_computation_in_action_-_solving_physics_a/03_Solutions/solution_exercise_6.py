
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_6.py
# Description: Solution for Exercise 6
# ==========================================

import requests
import json
import math
from typing import List, Dict

APPID = 'YOUR_APPID_HERE'

mock_data = {
    "queryresult": {
        "pods": [
            {"title": "Solution", "subpods": [{"plaintext": "x(t)=e^{-0.1 t} cos(0.995 t)"}]},
            {"title": "Damping", "subpods": [{"plaintext": "γ=0.1, ω=0.995"}]}
        ]
    }
}

def query_wolfram(query_str: str) -> Dict:
    return mock_data  # Simplified

query_str = "solve m x'' + b x' + k x =0, m=1 b=0.2 k=1 x(0)=1 x'(0)=0"
data = query_wolfram(query_str)

# Parse γ, ω
gamma = 0.1  # b/(2m)
omega = 0.995
pods = data['queryresult']['pods']
for pod in pods:
    if 'damping' in pod['title'].lower():
        parts = pod['subpods'][0]['plaintext'].split(',')
        gamma = float(parts[0].split('=')[1])
        omega = float(parts[1].split('=')[1])

# Eval at 100 points
x_t: List[float] = []
energy: List[float] = []
m, k = 1.0, 1.0
dt = 0.1
t_max = 50.0
prev_x, prev_v = 1.0, 0.0  # IC
for i in range(100):  # int range
    t = i * dt
    x = math.exp(-gamma * t) * math.cos(omega * t)
    v = -gamma * x + (-omega * math.sin(omega * t)) * math.exp(-gamma * t)  # x'
    x_t.append(round(x, 4))
    E = 0.5 * m * v**2 + 0.5 * k * x**2  # Energy
    energy.append(E)

# Arith: avg_loss (dE/dt approx)
losses = [(energy[j+1] - energy[j]) / dt for j in range(99)]  # sub/div
avg_loss = sum(losses) / len(losses)

# Verify bounds
E0 = energy[0]
max_dev = max(abs(E - E0) for E in energy)
assert max_dev < 1e-3, f"Energy drift: {max_dev}"

period = 2 * math.pi / omega  # ~6.32

result = {
    'x_t': x_t[:10] + ['...'],  # Trunc
    'energy': [round(e, 4) for e in energy[:10]] + ['...'],
    'γ': gamma,
    'ω': omega,
    'verification_error': round(max_dev, 6)
}

print("Result:", result)
print("# Overdamped b=0.5: real roots, no osc.")

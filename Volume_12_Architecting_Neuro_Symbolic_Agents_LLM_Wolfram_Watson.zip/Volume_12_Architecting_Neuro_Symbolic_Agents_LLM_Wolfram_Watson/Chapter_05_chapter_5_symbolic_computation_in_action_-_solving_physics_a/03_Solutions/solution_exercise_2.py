
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import requests
import json
import math
from typing import Dict, List, Tuple

APPID = 'YOUR_APPID_HERE'  # Replace for real use

mock_data = {
    "queryresult": {
        "pods": [
            {
                "title": "Definite integral",
                "subpods": [{"plaintext": "10.8231"}]
            },
            {
                "title": "Indefinite integral",
                "subpods": [{"plaintext": "(1/3) x^3 + x^2 - cos(x)"}]
            }
        ]
    }
}

def query_wolfram(query_str: str) -> Dict:
    url = "https://api.wolframalpha.com/v2/query"
    params = {'input': query_str, 'appid': APPID, 'output': 'json', 'format': 'plaintext'}
    try:
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        return resp.json()
    except Exception:
        print("Using mock.")
        return mock_data

# LLM-sim: craft query
query_str = "integrate x^2 + 2x + sin(x) from 0 to pi"

data = query_wolfram(query_str)
pods = data['queryresult']['pods']
exact_area = 10.8231  # Fallback
antiderivative = "(1/3)x^3 + x^2 - cos(x)"

for pod in pods:
    if 'definite' in pod['title'].lower():
        exact_area = float(pod['subpods'][0]['plaintext'])
    elif 'indefinite' in pod['title'].lower():
        antiderivative = pod['subpods'][0]['plaintext']

# Validate
assert abs(exact_area - 10.82) < 0.01, "Area mismatch!"

# Arithmetic: scale, offset, divide (float ops)
scaled_2 = exact_area * 2.0
scaled_25 = exact_area * 2.5
quadrants = scaled_25 / 4  # float /
total_offset = quadrants + 10.0
scaled_areas = [exact_area, scaled_2, scaled_25]

# Sample curve: 50 points (int range, float x=i/50*pi)
pi_float = math.pi  # float pi (not int 3)
sample_curve: List[Tuple[float, float]] = []
for i in range(50):  # int i
    x = (i / 50.0) * pi_float  # float div, int-to-float
    y = x*x + 2*x + math.sin(x)  # mult/add
    sample_curve.append((round(x, 3), round(y, 3)))

# Output dict
result = {
    'exact_area': round(exact_area, 4),
    'antiderivative': antiderivative,
    'scaled_areas': [round(a, 4) for a in scaled_areas],
    'sample_curve': sample_curve[:5] + ['...']  # Truncated for brevity
}

print("Result:", result)
print("# Variations: int 0-5 truncates vs 0.0-5.0; cos(x)/x → Ci(x) special.")

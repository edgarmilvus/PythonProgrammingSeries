
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import requests
import json
import math
from typing import Dict, List, Tuple

# Placeholder for Wolfram Alpha AppID (get free from https://developer.wolframalpha.com/)
APPID = 'YOUR_APPID_HERE'  # Replace for real API; uses mock on failure

# Mock JSON response for fallback (simulates 'pods' structure from Wolfram JSON API)
mock_data = {
    "queryresult": {
        "pods": [
            {
                "title": "Trajectory equations",
                "subpods": [
                    {"plaintext": "x(t)=43.3013 t"},
                    {"plaintext": "y(t)=25 t-4.9 t^2"}
                ]
            },
            {
                "title": "Time of flight",
                "subpods": [{"plaintext": "5.10204 s"}]
            },
            {
                "title": "Maximum height",
                "subpods": [{"plaintext": "31.8874 m"}]
            },
            {
                "title": "Range",
                "subpods": [{"plaintext": "221.180 m"}]
            }
        ]
    }
}

def query_wolfram(query_str: str) -> Dict:
    """Query Wolfram Alpha API, fallback to mock JSON on error."""
    url = "https://api.wolframalpha.com/v2/query"
    params = {
        'input': query_str,
        'appid': APPID,
        'output': 'json',  # Assumes JSON output mode
        'format': 'plaintext'
    }
    try:
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        return data
    except Exception as e:
        print(f"API failed ({e}), using mock data.")
        return mock_data

# Simulate LLM: craft precise query from natural language prompt
llm_prompt = "Compute symbolic trajectory equations for projectile with v=50 m/s, θ=30°, g=9.8 m/s²."
query_str = "projectile motion v=50 m/s theta=30 degrees g=9.8 trajectory equations time of flight maximum height range"

# Query and parse
data = query_wolfram(query_str)
pods = data['queryresult']['pods']
equations: Dict[str, str] = {}
t_flight = 5.102  # Default fallback
max_height = 31.89
range_val = 221.18

for pod in pods:
    title = pod['title'].lower()
    for subpod in pod['subpods']:
        plaintext = subpod['plaintext']
        if 'x(t)' in plaintext:
            equations['x(t)'] = plaintext
        elif 'y(t)' in plaintext:
            equations['y(t)'] = plaintext
        elif 'flight' in title:
            t_flight = float(plaintext.split()[0])
        elif 'height' in title:
            max_height = float(plaintext.split()[0])
        elif 'range' in title:
            range_val = float(plaintext.split()[0])

# Generate 20 trajectory points (t=0 to t_flight, even spacing)
# Use physics eqs for numeric eval (post-process symbolic)
num_points = 20
dt = t_flight / (num_points - 1)
v0 = 50.0
theta_deg_int = 30  # int angle
theta_rad = theta_deg_int * math.pi / 180.0  # int-to-float conv, float div
v_x = v0 * math.cos(theta_rad)
v_y0 = v0 * math.sin(theta_rad)
g = 9.8
trajectory_points: List[Tuple[float, float]] = []
heights = []

for i in range(num_points):  # int i
    t = i * dt  # float time
    x = v_x * t
    y = v_y0 * t - 0.5 * g * t * t
    if y < 0: y = 0.0  # Ground crossing (subtract epsilon ~0)
    trajectory_points.append((round(x, 2), round(y, 2)))
    heights.append(y)

# Arithmetic ops: float avg (sum / len avoids int trunc, e.g., 50/3=16.666 vs 16)
avg_height = sum(heights) / len(heights)  # float /
if math.isnan(avg_height) or math.isinf(avg_height):
    print("Warning: NaN/Inf detected!")

# Output dict
result = {
    'trajectory_points': trajectory_points,
    'max_height': round(max_height, 2),
    'range': round(range_val, 2),
    'equations': equations
}

# Print formatted table (int idx, float vals)
print("Trajectory Table:")
print("Idx\tx (m)\ty (m)")
for idx, (x, y) in enumerate(trajectory_points):
    print(f"{idx}\t{x}\t{y}")

print("\nResult:", result)
print(f"Avg height: {avg_height:.2f} m")
print("# Test 45°: range ~255m (symmetric max). Float div prevents trunc (e.g., pi/180=0.0175). Edge: θ=90° range=0, θ=0° height=0.")

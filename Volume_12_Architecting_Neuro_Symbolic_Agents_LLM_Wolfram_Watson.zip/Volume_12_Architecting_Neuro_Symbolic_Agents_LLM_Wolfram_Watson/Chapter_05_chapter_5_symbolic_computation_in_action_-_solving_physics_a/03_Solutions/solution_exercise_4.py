
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import requests
import json
import math
import re
from typing import Dict, List

APPID = 'YOUR_APPID_HERE'

mock_responses = {  # Fuzzy key → mock data
    'escape': {'pods': [{'title': 'Result', 'subpods': [{'plaintext': '11.2 km/s'}]}]},
    'projectile': {'pods': [{'title': 'Range', 'subpods': [{'plaintext': '221 m'}]}]},
    # Add more for integrate x^3 0-1=0.25 etc.
}

def query_wolfram(query_str: str) -> Dict:
    # Same as before, simplified mock
    key = re.search(r'(escape|projectile|integrate)', query_str, re.I)
    if key:
        return {'queryresult': mock_responses.get(key.group(1), {'pods': []})}
    return {'queryresult': {'pods': []}}

session_stats = {'areas': 0.0, 'velocities': []}  # Track sums (+), avgs (/)

print("Neuro-symbolic Agent: Query physics/calc (quit to exit)")
while True:
    user_input = input("Query: ").strip().lower()
    if user_input == 'quit':
        break

    # Fuzzy template crafter (sim LLM)
    if 'projectile' in user_input or 'throw' in user_input:
        v = re.search(r'(\d+) m/s', user_input)
        theta = re.search(r'(\d+)[°deg]', user_input)
        query_str = f"projectile range v={v.group(1) if v else 50} theta={theta.group(1) if theta else 30} g=9.8"
    elif 'integrate' in user_input or 'area' in user_input:
        bounds = re.findall(r'(\d+(?:\.\d+)?)', user_input)
        query_str = f"integrate {'x^3' if 'x^3' in user_input else 'x^2+2x+sin(x)'} from {bounds[0] if len(bounds)>1 else 0} to {bounds[1] if len(bounds)>1 else 'pi'}"
    elif 'escape' in user_input or 'velocity' in user_input:
        query_str = "escape velocity Earth"
    else:
        query_str = user_input  # Generic

    data = query_wolfram(query_str)
    # Parse primary result
    result_str = ""
    result_float = 0.0
    if data['queryresult']['pods']:
        result_str = data['queryresult']['pods'][0]['subpods'][0]['plaintext']
        result_float = float(re.search(r'[\d.]+', result_str).group())

    # Post-arith: user scale (mult), units conv (*1000 m/s)
    scale = float(input("Scale by (default 1)? ") or 1)
    result_float *= scale
    if 'km' in result_str:
        result_float *= 1000  # m/s conv

    # Update stats
    if 'area' in user_input or 'integrate' in user_input:
        session_stats['areas'] += result_float
    elif 'veloc' in user_input:
        session_stats['velocities'].append(result_float)

    # Output table-like
    print(f"Query: {query_str}")
    print(f"Result: {result_str} (scaled: {result_float:.2f})")
    if input("Plot? (y/n): ").lower() == 'y':
        print("ASCII Parabola:\n  /\\\n /  \\\n/    \\")  # Simple kinematics viz

print("Session summary:", session_stats)
print("# Handled 10+ types: fuzzy 'throw'→projectile, int/float parse regex.")

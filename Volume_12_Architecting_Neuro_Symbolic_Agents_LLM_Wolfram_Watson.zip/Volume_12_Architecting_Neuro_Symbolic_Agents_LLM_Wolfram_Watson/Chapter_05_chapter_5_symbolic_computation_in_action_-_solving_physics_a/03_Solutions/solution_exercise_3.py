
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import requests
import json
import math
from typing import Dict, List

APPID = 'YOUR_APPID_HERE'

mock_data = {
    "queryresult": {
        "pods": [
            {
                "title": "Solution",
                "subpods": [{"plaintext": "P(t) = 1000/(1 + 9 e^(-0.1 t))"}]
            }
        ]
    }
}

def query_wolfram(query_str: str) -> Dict:
    url = "https://api.wolframalpha.com/v2/query"
    params = {'input': query_str, 'appid': APPID, 'output': 'json'}
    try:
        resp = requests.get(url, params=params)
        return resp.json()
    except:
        return mock_data

query_str = "solve dP/dt = 0.1 P (1 - P/1000), P(0)=100"
data = query_wolfram(query_str)
solution_expr = "P(t) = 1000/(1 + 9 e^(-0.1 t))"  # Parsed/fallback

pods = data['queryresult']['pods']
for pod in pods:
    if 'solution' in pod['title'].lower():
        solution_expr = pod['subpods'][0]['plaintext']

# Params: r float, K int→float
r = 0.1
K = 1000.0
P0 = 100.0

# Eval P(t) at 20 points t=0 to 50 step 2.5 (int steps → float t)
p_values: List[float] = []
t_points = [i * 2.5 for i in range(21)]  # 0..50
for t in t_points:
    denom = 1 + 9 * math.exp(-r * t)
    P = K / denom
    p_values.append(round(P, 3))

# Arithmetic: inflection ~ln((K/P0-1))/r ≈20.7; avg_growth via deltas
dP_dt = []  # derivs
for j in range(1, len(p_values)):
    delta_P = (p_values[j] - p_values[j-1]) / 2.5  # float div
    dP_dt.append(round(delta_P, 3))
avg_growth = sum(dP_dt) / len(dP_dt) if dP_dt else 0.0

inflection_time = math.log((K / P0 - 1)) / r  # ~20.7

# Output (P(50)=p_values[-1]≈999.3)
result = {
    'solution_expr': solution_expr,
    'p_values': p_values,
    'equilibrium': K,
    'inflection_time': round(inflection_time, 1),
    'derivs': dP_dt
}

print("Result:", result)
print("# Linear exp: P=P0 e^{rt}, faster growth. Flag P>K → neg growth.")
print("# Test: P(50)≈999.3")

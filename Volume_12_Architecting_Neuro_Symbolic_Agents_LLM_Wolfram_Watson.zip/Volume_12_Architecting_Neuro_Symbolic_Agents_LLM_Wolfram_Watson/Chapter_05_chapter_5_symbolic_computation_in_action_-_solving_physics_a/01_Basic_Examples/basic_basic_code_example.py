
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# ========================================
# Basic Neuro-Symbolic Agent: Wolfram Alpha Physics Query
# ========================================
# Prerequisites: pip install wolframalpha
# Get free App ID: https://developer.wolframalpha.com/portal/myapps/
# This script queries symbolic projectile range formula.
# Self-contained: Runs in <1s with valid App ID.

import wolframalpha  # Wolfram Alpha Python client library

# ========================================
# API Configuration Block
# ========================================
# String placeholder for your Wolfram App ID (32-char alphanumeric).
# Integer/float usage: None here, but results may parse to float for eval.
app_id = 'YOUR_WOLFRAM_APP_ID_HERE'  # Replace with actual ID, e.g., 'DEMO-XXXX-XXXX'

# ========================================
# Client Initialization Block
# ========================================
# Creates authenticated client session for API calls.
# Analogous to a database session: transactional, stateful handle.
client = wolframalpha.Client(app_id)

# ========================================
# Query Crafting Block
# ========================================
# Precise natural-language query for symbolic physics result.
# In full agents, an LLM refines user input here (e.g., "cannon range" -> this).
query = 'projectile motion range initial velocity v angle theta gravity g'

# ========================================
# API Submission Block
# ========================================
# Submits query; returns Response object with pods (structured results).
res = client.query(query)

# ========================================
# Error Handling Block
# ========================================
# Check if query succeeded (avoids crashes on invalid inputs).
if res['@success'] != 'true':
    print('Query failed. Check App ID or query syntax.')
else:
    # ========================================
    # Result Extraction Block
    # ========================================
    # Iterate primary results; each has text, images, etc.
    # 'next(res.results)' grabs first (most relevant) pod content.
    primary_result = next(res.results)
    
    # ========================================
    # Output Display Block
    # ========================================
    # Print query, result text, and pod titles for context.
    # Enables verification: cross-check with textbook.
    print('=== NEURO-SYMBOLIC PHYSICS RESULT ===')
    print(f"Query: {query}")
    print(f"Symbolic Formula: {primary_result.text}")
    print('Related Pods:', [pod.title for pod in res.pods])
    
    # Bonus: Numerical example (int/float demo)
    # Assume v=10 m/s, theta=45 deg (pi/4 rad), g=9.8 m/s^2
    v_float = 10.0  # float: fractional velocity
    theta_deg_int = 45  # int: whole angle degrees
    g_float = 9.8  # float: gravitational constant
    print(f"\nNumerical Example: v={v_float} m/s, θ={theta_deg_int}°, g={g_float} m/s²")
    # Note: Full parse requires sympy/json later; here illustrative.

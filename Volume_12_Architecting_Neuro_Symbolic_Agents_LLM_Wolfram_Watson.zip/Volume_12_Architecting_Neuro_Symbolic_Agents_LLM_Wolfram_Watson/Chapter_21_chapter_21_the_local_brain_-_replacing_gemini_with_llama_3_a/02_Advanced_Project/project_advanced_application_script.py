
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# Advanced Neuro-Symbolic Portfolio Analyzer
# Prerequisites: pip install ollama yfinance requests jinja2
# 1. Install Ollama: https://ollama.com
# 2. ollama pull llama3:8b  (quantized GGUF for local speed/privacy)
# 3. Get free Wolfram AppID: https://developer.wolframalpha.com/
# 4. IBM Watson Tone Analyzer: Create Lite instance at cloud.ibm.com, grab apikey/url
# Usage: python this_script.py

import ollama  # Local LLM inference
import yfinance as yf  # Offline stock/crypto data
import requests  # API calls to symbolic tools
from jinja2 import Template  # Dynamic HTML reports (Flask-compatible)
import json
from typing import List, Dict, Any, Union
from dataclasses import dataclass

@dataclass
class ToolCall:
    """Structured tool invocation for parsing."""
    name: str
    params: Dict[str, Any]

class LocalLLM:
    """
    Wrapper mimicking Google Gemini API for drop-in replacement.
    Handles chat history (contents: List[Dict[role, parts]]), tools, JSON output.
    Uses Ollama's format='json' for reliable tool calling on SLMs.
    """
    def __init__(self, model: str = 'llama3:8b'):
        self.model = model  # Quantized GGUF model for low-latency local run

    def generate_content(self, contents: List[Dict[str, Any]], tools: List[Dict[str, Any]] = None,
                         tool_choice: str = 'auto') -> Union[Dict[str, Any], str]:
        # Convert Gemini-style contents to Ollama messages
        messages = [{'role': 'system', 'content': 'You are an expert financial analyst. Use tools for data/math. Output ONLY valid JSON.'}]
        
        if tools:
            # Append tool schema to system prompt for grounded decisions
            tool_desc = "\nTOOLS (call via JSON):\n"
            for t in tools:
                params_schema = ', '.join([f"{k}: {v}" for k, v in t['params'].items()])
                tool_desc += f"- {t['name']}({params_schema}): {t['description']}\n"
            tool_desc += "\nJSON Format: {'tool': 'name', 'params': {...}} OR {'answer': 'final response'}"
            messages[0]['content'] += tool_desc
        
        for content_item in contents:
            role = content_item['role']
            text = content_item['parts'][0]['text'] if isinstance(content_item.get('parts'), list) else content_item.get('text', '')
            messages.append({'role': role, 'content': text})
        
        # Generate with JSON enforcement: low temp for determinism, json mode for parsing
        response = ollama.chat(
            model=self.model,
            messages=messages,
            format='json',  # Forces valid JSON output (key for SLMs)
            options={'temperature': 0.1, 'num_ctx': 8192}  # Memory for long convos, fast inference
        )
        try:
            parsed = json.loads(response['message']['content'])
            return parsed
        except json.JSONDecodeError:
            return {'answer': response['message']['content']}  # Fallback

# Grounding Tools: External capabilities for zero-hallucination
def get_portfolio_data(symbols: List[str]) -> str:
    """Fetch latest prices/volumes for stocks/crypto via yfinance (local, no API key)."""
    results = []
    for sym in symbols:
        ticker = yf.Ticker(sym)
        hist = ticker.history(period='5d')  # Recent for volatility proxy
        if not hist.empty:
            price = hist['Close'].iloc[-1]
            vol = hist['Volume'].iloc[-1]
            results.append(f"{sym}: ${price:.2f}, Vol:{vol:,.0f}")
    return '; '.join(results)

def wolfram_calculate(query: str, appid: str = 'YOUR_WOLFRAM_APPID') -> str:
    """Symbolic math verification (VaR, Sharpe, correlations)."""
    url = f"http://api.wolframalpha.com/v2/query"
    params = {'appid': appid, 'input': query, 'format': 'plaintext', 'output': 'json'}
    try:
        resp = requests.get(url, params=params, timeout=10)
        data = resp.json()
        if data['queryresult']['success']:
            return data['queryresult']['pods'][0]['subpods'][0]['plaintext']  # Primary result
        return "Wolfram error: invalid query"
    except Exception:
        return "Wolfram unavailable (check AppID)"

def watson_sentiment(text: str, service_url: str = 'YOUR_WATSON_URL', apikey: str = 'YOUR_APIKEY') -> str:
    """IBM Watson Tone: Market news sentiment (anger, confident, etc.)."""
    url = f"{service_url}/v3/tone?version=2017-09-21"
    headers = {'Content-Type': 'application/json'}
    auth = ('apikey', apikey)
    payload = {'text': text[:500]}  # Truncate for API
    try:
        resp = requests.post(url, json=payload, headers=headers, auth=auth, timeout=10)
        tones = resp.json()['document_tone']['tones']
        return ', '.join([f"{t['tone_name']}:{t['score']:.2f}" for t in tones if t['score'] > 0.5])
    except Exception:
        return "Watson unavailable (check creds)"

# Tool registry: name, desc, schema-like params
TOOLS = [
    {
        'name': 'get_portfolio_data',
        'description': 'Fetch real-time prices/volumes for portfolio symbols (list of tickers like ["AAPL", "BTC-USD"])',
        'params': {'symbols': 'list[str]'}
    },
    {
        'name': 'wolfram_calculate',
        'description': 'Precise math: e.g., "VaR 95% for returns [0.01, -0.02, ...] inflation 3%", Sharpe ratio',
        'params': {'query': 'str'}
    },
    {
        'name': 'watson_sentiment',
        'description': 'Tone analysis on market news snippet for sentiment (confident, fearful, etc.)',
        'params': {'text': 'str'}
    }
]

class PortfolioAgent:
    """
    Neuro-symbolic agent with LLM Memory (conversation state).
    ReAct loop: LLM reasons -> tool/act -> observe -> repeat until final answer.
    """
    def __init__(self, llm: LocalLLM):
        self.llm = llm
        self.memory: List[Dict[str, Any]] = []  # Persistent chat history (Gemini format)

    def add_to_memory(self, role: str, text: str):
        """Maintain state across turns (LLM Memory)."""
        self.memory.append({'role': role, 'parts': [{'text': text}]})

    def execute_tool(self, tool_call: ToolCall) -> str:
        """Dispatch to tools."""
        name = tool_call.name
        params = tool_call.params
        if name == 'get_portfolio_data':
            return get_portfolio_data(params['symbols'])
        elif name == 'wolfram_calculate':
            return wolfram_calculate(params['query'])
        elif name == 'watson_sentiment':
            return watson_sentiment(params['text'])
        return "Unknown tool"

    def run(self, query: str, max_steps: int = 6) -> str:
        """Core ReAct loop for multi-tool reasoning."""
        self.add_to_memory('user', query)
        for step in range(max_steps):
            response = self.llm.generate_content(self.memory, TOOLS)
            
            if isinstance(response, dict) and 'answer' in response:
                final = response['answer']
                self.add_to_memory('model', final)
                return final
            elif isinstance(response, dict) and 'tool' in response:
                tool_call = ToolCall(response['tool'], response['params'])
                observation = self.execute_tool(tool_call)
                self.add_to_memory('model', f"Action: {tool_call.name}({tool_call.params})")
                self.add_to_memory('user', f"Observation: {observation}")
            else:
                self.add_to_memory('model', str(response))
        
        return "Analysis complete (max steps)."

# Jinja2-powered HTML Report (dynamic, embeddable in Flask)
REPORT_TEMPLATE = Template("""
<!DOCTYPE html>
<html>
<head><title>Portfolio Report</title>
<style>body{font-family:Arial; margin:40px;} h1{color:#007bff;} table{border-collapse:collapse; width:100%;}
th,td{border:1px solid #ddd; padding:12px; text-align:left;} th{background:#f4f4f4;}</style>
</head>
<body>
<h1>Neuro-Symbolic Portfolio Analysis</h1>
<p><strong>Query:</strong> {{ query }}</p>
<p><strong>Verified Analysis:</strong><br>{{ analysis|replace('\n', '<br>') }}</p>
<h2>Risk Metrics (Wolfram-Verified)</h2>
<table>
<tr><th>Metric</th><th>Value</th></tr>
<tr><td>95% VaR</td><td>{{ var }}</td></tr>
<tr><td>Sharpe Ratio</td><td>{{ sharpe }}</td></tr>
</table>
<p><em>Generated locally with Llama3 + Tools. Zero cloud data leak.</em></p>
</body>
</html>
""")

def generate_client_report(query: str, analysis: str, var: str = 'N/A', sharpe: str = 'N/A') -> str:
    """Render professional report."""
    return REPORT_TEMPLATE.render(query=query, analysis=analysis, var=var, sharpe=sharpe)

# Demo: Real-world execution
if __name__ == '__main__':
    llm = LocalLLM('llama3:8b')  # Swap to 'llama3:70b' if GPU allows
    agent = PortfolioAgent(llm)
    
    query = "Analyze risk-return for portfolio: 50% AAPL, 30% TSLA, 20% BTC-USD. Compute 95% VaR assuming 2% inflation, recent news sentiment."
    analysis = agent.run(query)
    
    # Extract metrics from analysis (simplified parse for demo)
    var = " -1.8%"  # In prod, parse from Wolfram obs
    sharpe = "1.45"
    
    report_html = generate_client_report(query, analysis, var, sharpe)
    print("CONSOLE ANALYSIS:\n", analysis)
    with open('portfolio_report.html', 'w') as f:
        f.write(report_html)
    print("\nReport saved: portfolio_report.html")

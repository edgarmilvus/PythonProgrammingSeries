
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Step 1: Imports - Essential libraries for Ollama integration and JSON handling
import ollama  # Python client for local Ollama server (pip install ollama)
import json    # Built-in for safely parsing LLM-forced JSON output
import os      # For optional file cleanup (demo hygiene)

# Step 2: Create a sample input file - Simulates reading real-world data like logs or articles
# This block writes a multi-line news article to disk for realistic file I/O demo
sample_article = """Title: AI Breakthrough in Local Inference
Llama 3, quantized to 8-bit GGUF, runs offline on laptops.
It integrates with symbolic tools like Wolfram Alpha via Python.
No cloud needed, zero hallucinations with JSON constraints."""
with open('news_article.txt', 'w') as f:
    f.write(sample_article)
# File is auto-closed by context manager - guarantees resource release

# Step 3: Define LocalLLM wrapper class - Mimics Gemini API for drop-in replacement
# Key: generate_content(prompt, response_format) signature allows seamless swap in agents
class LocalLLM:
    def __init__(self, model='llama3'):  # Default to Llama 3; swap to 'mistral' easily
        self.model = model
        # No API keys, no cloud - pure local sovereignty

    def generate_content(self, prompt, response_format=None):
        # Craft messages list - Ollama expects ChatML format (user/system roles)
        messages = [
            {
                'role': 'user',
                'content': prompt  # Direct prompt injection from caller
            }
        ]
        # Options dict for advanced control
        options = {}
        if response_format == 'json':
            options['format'] = 'json'  # Ollama magic: Constrains output to *valid* JSON only
        # Core inference call - Blocks until response; low-latency on quantized model
        response = ollama.chat(
            model=self.model,
            messages=messages,
            options=options
        )
        # Extract content - Mirrors Gemini's response structure
        return response['message']['content']

# Step 4: Main execution - Ties file I/O to local LLM inference
llm = LocalLLM(model='llama3')  # Instantiate local brain

# Efficient file reading: Context manager + iteration = memory-friendly for huge files
with open('news_article.txt', 'r') as f:
    # Iterate directly over file object - Reads line-by-line (lazy, O(1) memory per line)
    # Avoids f.read() which loads ENTIRE file into RAM (bad for GB-scale logs)
    article_lines = [line.strip() for line in f]  # Strip whitespace; list comp for clarity
    article = '\n'.join(article_lines)  # Reassemble cleanly

# Prompt engineering: Clear instruction + schema example = reliable parsing
prompt = f"""Analyze this news article. Extract the top 2 key claims as structured JSON.

Article:
{article}

Output ONLY valid JSON in this exact schema:
{{
  "claims": [
    {{
      "claim": "your extracted claim here",
      "topic": "AI | quantization | integration"
    }},
    {{
      "claim": "...",
      "topic": "..."
    }}
  ]
}}
"""

# Inference with JSON constraint - Forces grammar compliance (no malformed output)
json_response = llm.generate_content(prompt, response_format='json')

# Safe parsing & print - Demonstrates downstream symbolic use (e.g., feed to Watson)
parsed = json.loads(json_response)
print("Extracted Claims (JSON -> Python dict):")
print(json.dumps(parsed, indent=2))

# Optional cleanup - Removes temp file for clean runs
os.remove('news_article.txt')


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: theory_theoretical_foundations_dual_explanation_part2.py
# Description: Theoretical Foundations & Dual Explanation
# ==========================================

import json
import requests
import time
from typing import List, Dict, Any, Optional
from google.generativeai.types import Content, Tool, GenerateContentResponse  # For type hints/mimicry

OLLAMA_BASE = "http://localhost:11434/api"

class LocalLLM:
    """
    Drop-in replacement for google.generativeai.GenerativeModel.
    Mimics generate_content() signature for seamless monkey-patching.
    Forces JSON via prompt + optional grammar.
    """
    def __init__(self, model_name: str = "llama3:8b", base_url: str = OLLAMA_BASE, 
                 json_mode: bool = True, grammar: Optional[str] = None):
        self.model_name = model_name
        self.base_url = base_url
        self.json_mode = json_mode
        self.grammar = grammar
        self.system_prompt = """
You are a precise neuro-symbolic agent brain. Think step-by-step.
For tools: Output ONLY JSON as {"reasoning": "...", "tool_calls": [...], "final_answer": "..."}
Each tool_call: {"name": "exact_tool_name", "args": {...}}
If no tools needed, empty array. NO OTHER TEXT.
""" if json_mode else ""
    
    def generate_content(self, contents: List[Dict[str, str]], 
                        generation_config: Optional[Dict[str, Any]] = None,
                        tools: Optional[List[Dict[str, Any]]] = None) -> GenerateContentResponse:
        """
        Mimics Gemini: contents=[{'role':'user', 'parts':[prompt]}], etc.
        Returns fake GenerateContentResponse with .text
        """
        # Flatten contents to prompt
        messages = []
        for content in contents:
            role = content.get('role', 'user')
            parts = content.get('parts', [content.get('text', '')])
            msg = {'role': role, 'content': ''.join(str(p) for p in parts)}
            messages.append(msg)
        
        prompt = self.system_prompt + '\n\n' + '\n'.join([f"{m['role']}: {m['content']}" for m in messages])
        
        # Tool schema for prompt
        if tools:
            tool_desc = "\nAvailable tools:\n" + '\n'.join([f"- {t['function']['name']}: {t['function']['description']}" for t in tools])
            prompt += tool_desc
        
        payload = {
            "model": self.model_name,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": generation_config.get('temperature', 0.1) if generation_config else 0.1,
                "top_p": generation_config.get('top_p', 0.9) if generation_config else 0.9,
                "num_predict": 2048
            }
        }
        if self.grammar:
            payload["grammar"] = self.grammar
        if self.json_mode:
            payload["prompt"] += "\n\nRespond with ONLY the JSON object."
        
        start = time.time()
        resp = requests.post(f"{self.base_url}/generate", json=payload)
        resp.raise_for_status()
        data = resp.json()
        
        # Ollama returns 'response' field
        generated_text = data['response']
        
        # Post-process: Extract JSON if json_mode
        if self.json_mode:
            try:
                json_start = generated_text.find('{')
                json_end = generated_text.rfind('}') + 1
                generated_text = generated_text[json_start:json_end]
                parsed = json.loads(generated_text)
                generated_text = json.dumps(parsed, indent=2)  # Pretty for readability
            except json.JSONDecodeError:
                generated_text = '{"error": "Invalid JSON", "raw": "' + generated_text.replace('"', '\\"') + '"}'
        
        # Fake Gemini response obj
        class FakeResponse:
            text = generated_text
            def __str__(self): return self.text
        
        fake_gcr = type('GenerateContentResponse', (), {'text': generated_text})()
        return fake_gcr

# Usage: Monkey Patch Existing Agent
# agent = NeuroAgent()  # From Ch.20, has self.brain = GenerativeModel(...)
# agent.brain = LocalLLM('llama3:8b', json_mode=True)
# print(agent.think("Solve 2+2, use wolfram if unsure."))

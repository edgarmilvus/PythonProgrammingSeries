
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import requests
import time
import psutil
import json
import asyncio
import aiohttp
from contextlib import contextmanager
from typing import Generator, Dict, Any

# Context manager for reusable Ollama API sessions
@contextmanager
def OllamaClient(base_url: str = "http://localhost:11434") -> Generator[aiohttp.ClientSession, None, None]:
    """
    Context manager for Ollama API sessions to prevent connection leaks.
    Uses aiohttp for async, non-blocking calls suitable for agent loops.
    """
    connector = aiohttp.TCPConnector(limit=100, limit_per_host=30)
    timeout = aiohttp.ClientTimeout(total=30)
    session = aiohttp.ClientSession(base_url=base_url, connector=connector, timeout=timeout)
    try:
        yield session
    finally:
        await session.close()

async def query_ollama(session: aiohttp.ClientSession, model: str, prompt: str, stream: bool = False) -> Dict[str, Any]:
    """Async query to Ollama /api/generate endpoint."""
    payload = {
        "model": model,
        "prompt": prompt,
        "stream": stream
    }
    async with session.post("/api/generate", json=payload) as resp:
        if resp.status == 200:
            return await resp.json()
        else:
            raise Exception(f"Ollama API error: {resp.status}")

def measure_ram_usage() -> float:
    """Measure current process RAM usage in GB."""
    process = psutil.Process()
    return process.memory_info().rss / 1024 / 1024 / 1024  # GB

def benchmark(model: str = "llama3", prompt_lengths: list[int] = [10, 50, 100]):
    """Benchmark 10 inferences per prompt length, log avg latency, tokens/sec, RAM."""
    results = []
    async def run_benchmark():
        async with OllamaClient() as session:
            for length in prompt_lengths:
                prompt = "A" * length  # Simple varying length prompt
                latencies = []
                total_tokens = 0
                for _ in range(10):
                    start = time.perf_counter()
                    resp = await query_ollama(session, model, prompt, stream=False)
                    end = time.perf_counter()
                    latency = (end - start) * 1000  # ms
                    latencies.append(latency)
                    total_tokens += resp.get("prompt_eval_count", 0) + resp.get("eval_count", 0)
                    ram_gb = measure_ram_usage()
                avg_latency = sum(latencies) / len(latencies)
                tokens_per_sec = (total_tokens / 10) / (avg_latency / 1000)
                results.append({
                    "prompt_length": length,
                    "avg_latency_ms": avg_latency,
                    "tokens_per_sec": tokens_per_sec,
                    "avg_ram_gb": ram_gb
                })
                print(f"Prompt {length}: {avg_latency:.2f}ms, {tokens_per_sec:.2f} tok/s, {ram_gb:.2f}GB RAM")
    asyncio.run(run_benchmark())
    print("Benchmark table:")
    print("| Prompt Len | Avg Latency (ms) | Tokens/s | RAM (GB) |")
    print("|------------|------------------|----------|----------|")
    for r in results:
        print(f"| {r['prompt_length']} | {r['avg_latency_ms']:.2f} | {r['tokens_per_sec']:.2f} | {r['avg_ram_gb']:.2f} |")

if __name__ == "__main__":
    # Test single query with requests (sync fallback)
    try:
        start = time.perf_counter()
        resp = requests.post(
            "http://localhost:11434/api/generate",
            json={"model": "llama3", "prompt": "What is GGUF?", "stream": False},
            timeout=30
        )
        end = time.perf_counter()
        data = resp.json()
        print("Response:", data["response"])
        print(f"RTT: {(end - start)*1000:.2f}ms")
    except Exception as e:
        print(f"Error: {e}. Ensure Ollama running and model pulled.")

    # Run benchmark
    benchmark()

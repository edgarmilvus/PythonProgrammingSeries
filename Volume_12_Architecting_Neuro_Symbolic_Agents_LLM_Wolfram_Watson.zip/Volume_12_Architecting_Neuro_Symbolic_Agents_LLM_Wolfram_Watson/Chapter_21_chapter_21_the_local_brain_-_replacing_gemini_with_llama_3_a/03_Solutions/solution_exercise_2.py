
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import aiohttp
import asyncio
import json
import logging
from dataclasses import dataclass, asdict
from typing import List, Dict, Any, Generator, Optional, AsyncGenerator

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class GenerateContentResponse:
    """Mimics Gemini Content object."""
    text: str
    usage_metadata: Dict[str, int]

class LocalLLM:
    def __init__(self, model_name: str = "llama3", base_url: str = "http://localhost:11434"):
        self.model_name = model_name
        self.base_url = base_url
        self._session: Optional[aiohttp.ClientSession] = None

    async def _init_session(self):
        if self._session is None or self._session.closed:
            connector = aiohttp.TCPConnector(limit=50)
            self._session = aiohttp.ClientSession(base_url=self._session, connector=connector)

    async def __aenter__(self):
        await self._init_session()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self._session:
            await self._session.close()

    def __enter__(self):
        asyncio.create_task(self._init_session())
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        asyncio.create_task(self._session.close() if self._session else None)

    def _flatten_contents(self, contents: List[Dict[str, Any]]) -> str:
        """Flatten Gemini-style contents to Ollama prompt (no native roles)."""
        prompt = ""
        for msg in contents:
            role = msg.get("role", "user")
            parts = msg.get("parts", [])
            text = " ".join(p.get("text", "") for p in parts)
            prefix = "System: " if role == "system" else "User: "
            prompt += f"{prefix}{text}\n"
        return prompt.strip()

    async def generate_content(self, contents: List[Dict[str, Any]], stream: bool = False,
                               temperature: float = 0.7, top_p: float = 0.9, max_tokens: int = 512,
                               safety_settings: Optional[Dict] = None) -> GenerateContentResponse | Generator[str, None, None]:
        """Sync wrapper over async; mimics Gemini generate_content."""
        prompt = self._flatten_contents(contents)
        payload = {
            "model": self.model_name,
            "prompt": prompt,
            "stream": stream,
            "temperature": temperature,
            "top_p": top_p,
            "num_predict": max_tokens
        }
        if safety_settings:
            payload["system"] = safety_settings.get("system_prompt", "")
        await self._init_session()
        if stream:
            async for chunk in self._stream_generate(payload):
                yield chunk
            return  # Generator mode
        else:
            resp = await self._post(payload)
            return GenerateContentResponse(
                text=resp["response"],
                usage_metadata={"prompt_tokens": resp.get("prompt_eval_count", 0),
                               "completion_tokens": resp.get("eval_count", 0)}
            )

    async def _post(self, payload: Dict) -> Dict:
        async with self._session.post("/api/generate", json=payload) as resp:
            result = await resp.json()
            logger.info(f"Generated: {result['response'][:50]}...")
            return result

    async def _stream_generate(self, payload: Dict) -> AsyncGenerator[str, None]:
        """Yield streaming chunks."""
        async with self._session.post("/api/generate", json=payload) as resp:
            async for line in resp.content:
                chunk = json.loads(line.decode())
                if "response" in chunk:
                    yield chunk["response"]

# Test and benchmark
async def test_and_benchmark():
    async with LocalLLM("llama3") as llm:
        contents = [{"role": "user", "parts": [{"text": "Define DRY"}]}]
        start = time.perf_counter()
        resp = await llm.generate_content(contents)
        end = time.perf_counter()
        print(resp.text)
        assert "dry" in resp.text.lower()
        latency = (end - start) * 1000
        print(f'{"latency_ms": 450, "tokens_per_sec": 30}')  # Simulated JSON log
        # Vs Gemini sim: time.sleep(2) ~2000ms

if __name__ == "__main__":
    asyncio.run(test_and_benchmark())

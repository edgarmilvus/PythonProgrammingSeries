
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Basic Global Supply Chain Optimizer: Geo + Logic Integration
# Simulates Watson disruption alert, Wolfram geo-distances, and NetworkX Dijkstra
# for rerouting. PEP 8 compliant: snake_case vars/functions, CamelCase classes (none here),
# inline comments for readability. Achieves symbolic verification vs. LLM hallucination.

import networkx as nx  # Graph logic engine for Dijkstra shortest path
from typing import Dict, Tuple  # Type hints for PEP 8 clarity and IDE support
import sys  # For exit on errors, production robustness

# ======================================
# SIMULATED IBM WATSON: DISRUPTION DETECTION
# ======================================
# In production: Use ibm-watson SDK for NLP on news APIs (e.g., query "port strike").
# Here: Hardcoded sim for self-contained demo; outputs disrupted entity.
def simulate_watson_alert() -> str:
    """
    Mimics Watson's probabilistic risk model.
    Returns alert string with disrupted location for logic routing.
    """
    disruptions = ["Tokyo Port strike detected.", "No disruptions."]
    # Simulate real-time news scan (random for demo; real uses Watson Tone Analyzer + NLU)
    import random  # Standard lib for variability
    alert = random.choice(disruptions)
    print(f"Watson Alert: {alert}")  # Log for feedback loop
    return alert

# ======================================
# SIMULATED WOLFRAM ALPHA: GEO-DISTANCE QUERIES
# ======================================
# In production: wolframalpha.Client(app_id='YOUR_ID').query(f"distance {city1} {city2}")
# Returns km as float. Grounds LLMs in verifiable math.
# Dict fallback ensures no hallucination if query fails.
WOLFRAM_DISTANCES: Dict[Tuple[str, str], float] = {
    ("Shanghai", "Tokyo"): 1700.0,
    ("Shanghai", "Singapore"): 3900.0,
    ("Shanghai", "Hong Kong"): 1200.0,  # Alt route node
    ("Tokyo", "LosAngeles"): 8800.0,
    ("Singapore", "LosAngeles"): 14600.0,
    ("Hong Kong", "LosAngeles"): 11700.0,
}
def simulate_wolfram_distance(city1: str, city2: str) -> float:
    """
    Computes great-circle distance proxy via Wolfram cache.
    Returns inf if unknown (triggers constraint rejection).
    """
    print(f"Wolfram Query: distance between {city1} and {city2}")  # Audit trail
    distance = WOLFRAM_DISTANCES.get((city1, city2), float('inf'))
    if distance == float('inf'):
        print(f"Warning: No geo-data for {city1}-{city2}; path invalid.", file=sys.stderr)
    return distance

# ======================================
# SUPPLY CHAIN GRAPH CONSTRUCTION
# ======================================
# Builds weighted undirected graph (routes bidirectional for simplicity).
# Nodes: Factories/Ports/Warehouses. Edges: Geo-distances as weights (proxy for cost/time).
def build_supply_chain_graph() -> nx.Graph:
    """
    Orchestrates neuro-symbolic fusion:
    - Wolfram for edge weights (geo grounding).
    - NetworkX for symbolic constraint satisfaction.
    Adds extra nodes (Hong Kong) for route diversity.
    """
    G = nx.Graph()
    
    # Core nodes with semantic labels (Factory, Port, Warehouse)
    nodes = [
        "Shanghai_Factory",
        "Tokyo_Port",
        "Singapore_Port",
        "Hong_Kong_Port",
        "LosAngeles_Warehouse"
    ]
    G.add_nodes_from(nodes)
    
    # Edges from Wolfram geo-queries (logic: only feasible if distance < inf)
    edges_data = [
        ("Shanghai_Factory", "Tokyo_Port", simulate_wolfram_distance("Shanghai", "Tokyo")),
        ("Shanghai_Factory", "Singapore_Port", simulate_wolfram_distance("Shanghai", "Singapore")),
        ("Shanghai_Factory", "Hong_Kong_Port", simulate_wolfram_distance("Shanghai", "Hong Kong")),
        ("Tokyo_Port", "LosAngeles_Warehouse", simulate_wolfram_distance("Tokyo", "LosAngeles")),
        ("Singapore_Port", "LosAngeles_Warehouse", simulate_wolfram_distance("Singapore", "LosAngeles")),
        ("Hong_Kong_Port", "LosAngeles_Warehouse", simulate_wolfram_distance("Hong Kong", "LosAngeles")),
    ]
    # Filter invalid edges (symbolic constraint: no inf weights)
    valid_edges = [(u, v, w) for u, v, w in edges_data if w != float('inf')]
    G.add_weighted_edges_from(valid_edges)
    
    print("Graph built: Nodes={}, Edges={}".format(G.number_of_nodes(), G.number_of_edges()))
    return G

# ======================================
# CORE OPTIMIZER: DISRUPTION HANDLING + DIJKSTRA
# ======================================
# Main logic: Alert → Disrupt graph → Re-optimize path.
# Verifiable output: Path + total distance (no hallucination).
def optimize_route(disruption_alert: str, G: nx.Graph) -> Tuple[List[str], float]:
    """
    Applies Dijkstra for min-distance path (cost proxy).
    Handles disruption symbolically (edge removal).
    Returns path and length; raises if no path (constraint violation).
    """
    disrupted_port = None
    if "Tokyo" in disruption_alert:
        disrupted_port = "Tokyo_Port"
        print(f"Disrupting {disrupted_port} edges...")
        # Symbolic disruption: Remove incident edges (real: capacity=0)
        disrupted_edges = list(G.edges(disrupted_port))
        G.remove_edges_from(disrupted_edges)
        print(f"Removed {len(disrupted_edges)} edges.")
    
    source = "Shanghai_Factory"
    target = "LosAngeles_Warehouse"
    
    try:
        # Dijkstra: Symbolic shortest path (greedy, polynomial time)
        optimal_path = nx.shortest_path(G, source, target, weight="weight")
        total_distance = nx.shortest_path_length(G, source, target, weight="weight")
        print(f"Optimal Path: {' -> '.join(optimal_path)}")
        print(f"Total Distance: {total_distance:.0f} km")
        return optimal_path, total_distance
    except nx.NetworkXNoPath:
        print("No feasible route! Escalate to human.", file=sys.stderr)
        sys.exit(1)

# ======================================
# ENTRY POINT: FULL WORKFLOW ORCHESTRATION
# ======================================
# Runs end-to-end: Watson → Wolfram → Logic. Scalable to Flask API.
if __name__ == "__main__":
    # Step 1: Risk monitoring
    alert = simulate_watson_alert()
    
    # Step 2: Geo-grounded graph
    graph = build_supply_chain_graph()
    
    # Step 3: Optimize with constraints
    path, distance = optimize_route(alert, graph)
    
    # Feedback loop: Log for LLM forecasting integration (future chapters)
    print("Optimization complete. Ready for deployment.")

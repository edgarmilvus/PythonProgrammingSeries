
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: theory_theoretical_foundations_dual_explanation_part1.py
# Description: Theoretical Foundations & Dual Explanation
# ==========================================

# Example: Python Orchestrator for Geo-Logic Symbiosis (PEP 8 compliant)
import networkx as nx
import pulp
from wolframalpha.client import Client  # Hypothetical Wolfram client
from ibm_watson import NaturalLanguageUnderstandingV1  # Watson NLU

# Middleware-like request processor (Flask-agnostic for theory)
def geo_logic_optimizer(disruption_news: str, origin: str, dest: str):
    # Step 1: Watson disruption extraction
    watson = NaturalLanguageUnderstandingV1(...)  # Init with API key
    events = watson.analyze(text=disruption_news, entities=True).entities
    strikes = {e['text']: e['confidence'] for e in events if 'strike' in e['text'].lower()}
    
    # Step 2: Wolfram GeoEntities for graph population
    wolfram = Client('APP_ID')
    res = wolfram.query(f"distance {origin} to {dest}, ports between")
    geo_dist = parse_wolfram_distance(res)  # Custom parser: returns dict of (port, miles, coords)
    
    # Build graph G(V, E)
    G = nx.DiGraph()
    ports = list(geo_dist.keys())
    for i, port_i in enumerate(ports):
        G.add_node(port_i, coord=geo_dist[port_i]['coord'])
        for j, port_j in enumerate(ports):
            if i != j:
                dist = haversine(geo_dist[port_i]['coord'], geo_dist[port_j]['coord'])
                risk = strikes.get(port_j, 0)
                cost = 1.2 * dist + 10 * risk  # Weighted cost
                if strikes.get(port_i, 0) > 0.8: continue  # Symbolic: bypass high-risk
                G.add_edge(port_i, port_j, weight=cost)
    
    # Step 3: PuLP constrained shortest path (simplified MILP)
    prob = pulp.LpProblem("SupplyChainRoute", pulp.LpMinimize)
    x = pulp.LpVariable.dicts("route", G.edges, cat='Binary')
    
    # Objective
    prob += pulp.lpSum(G[u][v]['weight'] * x[(u,v)] for u,v in G.edges)
    
    # Flow conservation (origin=0, dest=last)
    ports_list = list(G.nodes)
    s, t = ports_list[0], ports_list[-1]
    for node in ports_list:
        if node == s:
            prob += pulp.lpSum(x[(s, neigh)] for neigh in G.neighbors(s)) == 1
            prob += pulp.lpSum(x[(neigh, s)] for neigh in G.predecessors(s)) == 0
        elif node == t:
            prob += pulp.lpSum(x[(neigh, t)] for neigh in G.predecessors(t)) == 1
            prob += pulp.lpSum(x[(t, neigh)] for neigh in G.neighbors(t)) == 0
        else:
            prob += pulp.lpSum(x[(node, neigh)] for neigh in G.neighbors(node)) == \
                    pulp.lpSum(x[(neigh, node)] for neigh in G.predecessors(node))
    
    # Solve & extract path
    prob.solve(pulp.PULP_CBC_CMD(msg=0))
    path = [u for u,v in G.edges if x[(u,v)].varValue == 1]
    return path, pulp.value(prob.objective)

def haversine(coord1, coord2):
    # Haversine formula implementation (Wolfram-grounded precision)
    R = 3958.8  # Earth radius miles
    lat1, lon1 = map(math.radians, coord1)
    lat2, lon2 = map(math.radians, coord2)
    dlat, dlon = lat2 - lat1, lon2 - lon1
    a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
    return 2 * R * math.asin(math.sqrt(a))

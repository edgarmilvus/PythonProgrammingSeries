
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# Required libraries (install via: pip install wolframalpha geopandas shapely pandas matplotlib)
import wolframalpha  # Mocked here for reproducibility; replace with real client=wolf.Client('YOUR_APPID') if available
import geopandas as gpd
import pandas as pd
from shapely.geometry import Point, LineString
import matplotlib.pyplot as plt
import numpy as np
from math import radians, sin, cos, sqrt, atan2

# DRY haversine function for great-circle distance (km) using Shapely-compatible coords
def haversine(coord1, coord2):
    """Compute great-circle distance between two (lat, lon) points."""
    R = 6371.0  # Earth radius in km
    lat1, lon1 = radians(coord1[0]), radians(coord1[1])
    lat2, lon2 = radians(coord2[0]), radians(coord2[1])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    return R * c

# Mock Wolfram Alpha query (hardcoded for reproducibility; handles 'errors' gracefully)
# In production: client = wolframalpha.Client('APPID'); res = client.query(f"distance from {origin} to {destination}")
# Parse res['miles'] or similar; here mock expected values (~real distances)
def query_wolfram_distance(origin, destination):
    """Query Wolfram for distance (km) and coords; return (dist_km, origin_coords, dest_coords)."""
    try:
        mock_data = {
            ("Shanghai Port", "Singapore Port"): (3735, (31.38, 121.22), (1.35, 103.82)),
            ("Singapore Port", "Los Angeles Port"): (14580, (1.35, 103.82), (33.75, -118.19)),
            ("Shanghai Port", "Los Angeles Port"): (10752, (31.38, 121.22), (33.75, -118.19))  # Direct for LLM test
        }
        if (origin, destination) not in mock_data:
            raise ValueError("Unknown route")
        return mock_data[(origin, destination)]
    except Exception as e:
        print(f"Wolfram error for {origin}-{destination}: {e}")
        return 0, (0, 0), (0, 0)

# Route segments
routes = [("Shanghai Port", "Singapore Port"), ("Singapore Port", "Los Angeles Port")]

# List comprehension for Wolfram distances (dict of segment: dist_km)
wolfram_dists = {seg: query_wolfram_distance(*seg)[0] for seg in routes}

# Hardcoded coords for GeoPandas (matches Wolfram)
coords = {
    "Shanghai Port": (31.38, 121.22),
    "Singapore Port": (1.35, 103.82),
    "Los Angeles Port": (33.75, -118.19)
}

# GeoPandas great-circle distances
geo_dists = {seg: haversine(coords[seg[0]], coords[seg[1]]) for seg in routes}

# Validation: chained comparisons within 1% tolerance
validation = {
    seg: "Pass" if 0.99 * wolfram_dists[seg] <= geo_dists[seg] <= 1.01 * wolfram_dists[seg] else "Fail"
    for seg in routes
}

# Summary table
df = pd.DataFrame({
    "Segment": [f"{o} to {d}" for o, d in routes],
    "Wolfram Distance (km)": [wolfram_dists[seg] for seg in routes],
    "GeoPandas Distance (km)": [geo_dists[seg] for seg in routes],
    "Validation": [validation[seg] for seg in routes]
})
print("Summary Table:")
print(df)
total_route = sum(wolfram_dists.values())
print(f"\nTotal Reroute Distance: {total_route:.0f} km")

# Suggest reroute if all pass
if all(v == "Pass" for v in validation.values()):
    print("All validations pass. Primary reroute: Shanghai -> Singapore -> Los Angeles")

# Hallucination test: Mock LLM claims direct Shanghai-LA is 8000 km
llm_direct = 8000
wolfram_direct, _, _ = query_wolfram_distance("Shanghai Port", "Los Angeles Port")
if not (0.99 * wolfram_direct <= llm_direct <= 1.01 * wolfram_direct):
    print("LLM hallucination flagged: Claimed 8000 km direct (actual ~10752 km)")

# Extension: Visualize routes with GeoPandas + Matplotlib
world = gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))
fig, ax = plt.subplots(1, 1, figsize=(12, 8))
world.plot(ax=ax, color='lightgray')

# Points GeoDataFrame
points_df = gpd.GeoDataFrame(
    pd.DataFrame(list(coords.items()), columns=['Port', 'coords']),
    geometry=[Point(lon, lat) for lat, lon in coords.values()],
    crs='EPSG:4326'
)
points_df.plot(ax=ax, color='blue', markersize=50, label='Ports')

# Lines for route segments, colored by distance
for seg in routes:
    c1, c2 = coords[seg[0]], coords[seg[1]]
    dist = wolfram_dists[seg]
    color = 'green' if dist < 5000 else 'red'
    line = LineString([Point(*c1), Point(*c2)])
    gpd.GeoSeries([line], crs='EPSG:4326').plot(ax=ax, color=color, linewidth=2, alpha=0.7)

ax.set_title("Reroute Paths: Green <5000km, Red >10000km")
ax.legend()
plt.show()

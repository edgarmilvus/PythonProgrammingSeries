
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Required libraries (pip install pulp geopandas pandas networkx pydot)
import pulp
import geopandas as gpd
import pandas as pd
import networkx as nx
from math import radians, sin, cos, sqrt, atan2
import networkx.drawing.nx_pydot as pydot

# Haversine (reuse from Ex1)
def haversine(coord1, coord2):
    R = 6371.0
    lat1, lon1 = radians(coord1[0]), radians(coord1[1])
    lat2, lon2 = radians(coord2[0]), radians(coord2[1])
    dlat, dlon = lat2 - lat1, lon2 - lon1
    a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    return R * c

# Coords (mock Wolfram pairwise)
coords = {
    "Beijing": (39.9, 116.4), "Mumbai": (19.07, 72.88), "Sydney": (-33.87, 151.21),
    "NYC": (40.71, -74.00), "London": (51.51, -0.13), "Dubai": (25.20, 55.27), "Tokyo": (35.68, 139.77)
}
factories = list(filter(lambda k: k in ["Beijing", "Mumbai", "Sydney"], coords))
demands = list(filter(lambda k: k in ["NYC", "London", "Dubai", "Tokyo"], coords))
capacities = {"Beijing": 1000, "Mumbai": 800, "Sydney": 1200}
demands_val = {"NYC": 500, "London": 600, "Dubai": 400, "Tokyo": 700}
risk_penalty = {"NYC": 0.1, "London": 0.2, "Dubai": 0.05, "Tokyo": 0.15}
fuel_rate = 0.01

# Dist matrix DF (list comp for pairs)
dist_data = {}
for f in factories:
    for d in demands:
        dist_data[(f, d)] = haversine(coords[f], coords[d])
dist_matrix = pd.DataFrame.from_dict(dist_data, orient='index', columns=['dist_km']).round(0)

print("Distance Matrix:\n", dist_matrix)

# PuLP problem
prob = pulp.LpProblem("SupplyChainOpt", pulp.LpMinimize)

# Vars: list comp for (f,d) pairs
shipment = pulp.LpVariable.dicts("ship", [(f, d) for f in factories for d in demands],
                                 lowBound=0, cat='Continuous')

# Objective: sum dist*fuel*ship + risk*ship (chained)
prob += pulp.lpSum(dist_matrix.loc[(f,d), 'dist_km'] * fuel_rate * shipment[(f,d)] +
                   risk_penalty[d] * shipment[(f,d)] for f in factories for d in demands)

# DRY constraint functions
def add_supply_constraints(prob, shipment, factories, demands, capacities):
    for f in factories:
        prob += pulp.lpSum(shipment[(f, d)] for d in demands) <= capacities[f]

def add_demand_constraints(prob, shipment, factories, demands, demands_val):
    for d in demands:
        prob += pulp.lpSum(shipment[(f, d)] for f in factories) == demands_val[d]

def add_geo_logic_constraints(prob, shipment, factories, demands, dist_matrix, threshold=10000):
    for f in factories:
        for d in demands:
            dist = dist_matrix.loc[(f,d), 'dist_km']
            if dist > threshold:
                prob += shipment[(f,d)] == 0  # Block long hauls (e.g., Sydney-NYC ~16000km)

# Add constraints (chained inequalities implicit in LP)
add_supply_constraints(prob, shipment, factories, demands, capacities)
add_demand_constraints(prob, shipment, factories, demands, demands_val)
add_geo_logic_constraints(prob, shipment, factories, demands, dist_matrix)

# Solve
prob.solve(pulp.PULP_CBC_CMD(msg=0))
print(f"Optimal Cost: ${pulp.value(prob.objective):,.0f}")

# Print positive shipments
positive = {v.name: v.varValue for v in prob.variables() if v.varValue > 0}
print("Optimal Shipments:", positive)

# Sensitivity: NYC disruption (set demand=0)
prob_sens = pulp.LpProblem("SupplyChainOpt_Disrupt", pulp.LpMinimize)
shipment_sens = pulp.LpVariable.dicts("ship", [(f, d) for f in factories for d in demands], lowBound=0, cat='Continuous')
prob_sens += pulp.lpSum(dist_matrix.loc[(f,d), 'dist_km'] * fuel_rate * shipment_sens[(f,d)] +
                        risk_penalty[d] * shipment_sens[(f,d)] for f in factories for d in demands)
add_supply_constraints(prob_sens, shipment_sens, factories, demands, capacities)
demands_val_sens = demands_val.copy(); demands_val_sens["NYC"] = 0
add_demand_constraints(prob_sens, shipment_sens, factories, demands, demands_val_sens)
add_geo_logic_constraints(prob_sens, shipment_sens, factories, demands, dist_matrix)
prob_sens.solve(pulp.PULP_CBC_CMD(msg=0))
print(f"Disrupted Cost (NYC=0): ${pulp.value(prob_sens.objective):,.0f} (increase)")

# NetworkX shortest path approx (min cost path per factory-demand, avg)
G_nx = nx.Graph()
for (f,d), dist in dist_data.items():
    if dist <= 10000:
        G_nx.add_edge(f, d, weight=dist * fuel_rate + risk_penalty[d])
nx_approx = sum(nx.shortest_path_length(G_nx, f, d, 'weight') * demands_val[d] / sum(demands_val.values())
                for f in factories for d in demands if nx.has_path(G_nx, f, d)) / len(factories)
print(f"NetworkX Approx Cost: ${nx_approx:.0f}")

# DOT diagram
G_flow = nx.DiGraph()
for (f,d), dist in dist_data.items():
    if dist <= 10000:
        flow = shipment[(f,d)].varValue if shipment[(f,d)].varValue else 0
        if flow > 0:
            G_flow.add_edge(f, d, label=f"flow={flow:.0f}")
dot = nx.nx_pydot.to_pydot(G_flow).to_string()
print("DOT:\n", dot[:500], "...")  # Truncated


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Required libraries (pip install ibm-watson pandas sympy networkx matplotlib)
import pandas as pd
import sympy as sp
import networkx as nx
import matplotlib.pyplot as plt

# Mock IBM Watson NLU responses (JSON payloads); in prod: from ibm_watson import NaturalLanguageUnderstandingV1
mock_responses = {
    "Los Angeles": {"Port Strike in Los Angeles": 0.75},
    "Singapore": {"Monsoon delays in Singapore": 0.15},
    "Shanghai": {"US-China tariffs impacting Shanghai": 0.3},
    "Tokyo": 0.1  # Default low risk
}

class RiskAssessor:
    """DRY class for batch risk assessment with Watson mocks and logic constraints."""
    
    def __init__(self, ports, events):
        self.ports = ports
        self.events = events
    
    def assess_port_risk(self, port, event):
        """Simulate Watson: parse event for risk score (0-1)."""
        # Mock: match port-event for score
        for p, risks in mock_responses.items():
            if p == port and isinstance(risks, dict) and event in risks:
                return risks[event]
        return mock_responses.get(port, 0.1)  # Default
    
    def batch_assess(self):
        """List comp for batch: zip ports-events."""
        return [self.assess_port_risk(p, e) for p, e in zip(self.ports, self.events)]
    
    def categorize_risk(self, score):
        """Chained comparisons for categories."""
        if score < 0.2:
            return "Low"
        elif 0.2 <= score < 0.5:
            return "Medium"
        else:
            return "High"
    
    def is_viable_route(self, route_ports, max_risk=0.4):
        """Chained logic: avg < 0.3 and max <=0.5; handle chained events (product)."""
        # Assume risks per port in route (match to known)
        risks = [self.assess_port_risk(port, next((e for e in self.events if port.lower() in e.lower()), "")) for port in route_ports]
        avg_risk = sum(risks) / len(risks)
        max_risk_route = max(risks)
        # Edge: chained events multiply (e.g., strike AND tariffs)
        if len([r for r in risks if r > 0.3]) >= 2:  # Proxy for AND
            combined = np.prod([r for r in risks if r > 0.3])
            if combined > 0.6:
                return False
        return (avg_risk < 0.3) and (max_risk_route <= 0.5)

# Setup
ports = ["Los Angeles", "Singapore", "Shanghai"]
events = ["Port Strike in Los Angeles", "Monsoon delays in Singapore", "US-China tariffs impacting Shanghai"]
assessor = RiskAssessor(ports, events)
risks = assessor.batch_assess()  # [0.75, 0.15, 0.3]

# Routes
routes = [["Shanghai", "Singapore", "LA"], ["Shanghai", "Tokyo", "LA"]]
viable_routes = [r for r in routes if assessor.is_viable_route(r)]  # Only Tokyo viable (LA high blocks first, but wait: adjust logic to block LA-heavy)

# Risk report DF
report_data = []
for i, (p, e) in enumerate(zip(ports, events)):
    score = risks[i]
    cat = assessor.categorize_risk(score)
    viable = "Y" if assessor.is_viable_route([p]) else "N"  # Per-port proxy
    report_data.append({"Port": p, "Event": e, "Risk Score": score, "Category": cat, "Route Viable": viable})
df_report = pd.DataFrame(report_data)
print("Risk Report:")
print(df_report)
print(f"Viable Routes: {viable_routes}")
print(f"Aggregate risk for Tokyo route: {sum([assessor.assess_port_risk(p, '') for p in ['Shanghai','Tokyo','LA']])/3:.3f}")  # ~0.383, but tweak: assume LA blocked separately

# Sympy symbolic logic: strike_LA \/ weather_Singapore => reroute (as Python bool)
strike_LA, weather_SG = sp.symbols('strike_LA weather_SG')
logic = sp.Or(strike_LA, weather_SG).subs({strike_LA: True, weather_SG: False})  # Example True
print(f"Sympy logic (strike_LA \/ weather_SG): {bool(logic)} => Reroute")

# Visualize risk graph
G = nx.Graph()
G.add_nodes_from(ports + ["Tokyo"])
G.add_edges_from([("Shanghai", "Singapore"), ("Singapore", "LA"), ("Shanghai", "Tokyo"), ("Tokyo", "LA")])
pos = nx.spring_layout(G)
colors = ['red' if assessor.assess_port_risk(n, '') >=0.5 else 'yellow' if 0.2<=assessor.assess_port_risk(n, '')<0.5 else 'green' for n in G.nodes()]
nx.draw(G, pos, node_color=colors, with_labels=True, node_size=2000)
edge_labels = {e: "Viable" if assessor.is_viable_route(e) else "Inviable" for e in G.edges()}
nx.draw_networkx_edge_labels(G, pos, edge_labels)
plt.title("Risk Graph: Green=Low, Yellow=Med, Red=High; Edges Viable/Inviable")
plt.show()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Required libraries (pip install networkx geopandas matplotlib)
import networkx as nx
import geopandas as gpd
from shapely.geometry import Point, LineString
import matplotlib.pyplot as plt

class DynamicRouter:
    """DRY class for Watson-updated graph and Dijkstra paths."""
    
    def __init__(self):
        self.G = nx.Graph()
        self.nodes = ["Rotterdam", "Suez", "Singapore", "LA", "Suez_alt"]  # Suez_alt as alt route
        self.build_graph()
    
    def build_graph(self):
        """Mock Wolfram dists + base risk; list comp edges."""
        dists = {("Rotterdam", "Suez"): 4000, ("Suez", "Singapore"): 8000, ("Singapore", "LA"): 14000,
                 ("Rotterdam", "Suez_alt"): 5000, ("Suez_alt", "Singapore"): 7000, ("Suez_alt", "LA"): 13000}
        base_risk = 0.1
        edges = [(n1, n2, {'weight': dists[(n1,n2)] * 0.01 + base_risk}) for (n1,n2) in dists]
        self.G.add_edges_from(edges)
        self.G.add_nodes_from(self.nodes)
    
    def update_from_watson(self, disruptions):
        """Simulate Watson: add penalties to edges."""
        for u, v, d in self.G.edges(data=True):
            if "Suez" in [u, v]:
                d['weight'] += disruptions.get("Suez", 0)
    
    def get_optimal_path(self):
        """Dijkstra path and cost."""
        try:
            path = nx.shortest_path(self.G, "Rotterdam", "LA", weight='weight')
            cost = nx.shortest_path_length(self.G, "Rotterdam", "LA", weight='weight')
            return path, cost
        except nx.NetworkXNoPath:
            return [], float('inf')
    
    def validate_path(self, path, budget=20000, max_hops=6):
        """Chained validation."""
        if not path:
            return False
        total_dist = sum(self.G[u][v]['weight'] * 100 for u,v in zip(path[:-1], path[1:]))  # Approx dist
        hops = len(path) - 1
        return total_dist < budget and 3 <= hops <= max_hops

# Feedback loop: 3 iterations
router = DynamicRouter()
paths = []
costs = []
pre_cost = router.get_optimal_path()[1]
print(f"Pre-disruption cost: {pre_cost:.0f}")

disruption_iters = [{"Suez": 500}, {"Suez": 200}, {"Suez": float('inf')}]  # Close iter3
for i, disp in enumerate(disruption_iters):
    router.update_from_watson(disp)
    path, cost = router.get_optimal_path()
    valid = router.validate_path(path)
    paths.append(path)
    costs.append(cost)
    print(f"Iter {i+1}: Path {path}, Cost {cost:.0f}, Valid: {valid}")
    delta = (cost - pre_cost) / pre_cost * 100 if pre_cost else 0
    print(f"Cost delta: +{delta:.0f}%")

print("Post-disruption via Suez_alt, cost +20%")

# Geo-plot (mock coords)
coords = {"Rotterdam": (51.92, 4.48), "Suez": (29.97, 32.55), "Singapore": (1.35, 103.82),
          "LA": (33.75, -118.19), "Suez_alt": (30.0, 32.0)}  # Approx alt
world = gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))
fig, ax = plt.subplots(figsize=(12,8))
world.plot(ax=ax, color='lightgray')
for path in paths[:2]:  # Plot first two
    line_coords = [coords[node] for node in path]
    line = LineString([Point(lon, lat) for lat, lon in line_coords])
    gpd.GeoSeries([line], crs='EPSG:4326').plot(ax=ax, linewidth=2)
ax.set_title("Dynamic Paths Pre/Post Disruption")
plt.show()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# Advanced Application Script: Neuro-Symbolic Global Supply Chain Optimizer
# Integrates Watson-like disruption detection, Wolfram Alpha geo-queries (proxied via geopy),
# PuLP for symbolic LP optimization, list comprehensions for filtering, logical operators for conditions,
# and contextvars for state management. Solves min-cost flow post-disruption.

from pulp import LpProblem, LpMinimize, LpVariable, lpSum, value, LpStatus
from geopy.distance import geodesic
from contextvars import ContextVar
import math  # For potential extensions

# Geospatial coordinates: In production, query Wolfram Alpha e.g., client.query("coordinates of Singapore")
# Here, pre-loaded for demo (verifiable via Wolfram GeoEntities)
coords = {
    'Singapore': (1.3521, 103.8198),
    'Shanghai': (31.2304, 121.4737),
    'Hong_Kong': (22.3964, 114.1095),
    'Tokyo': (35.6895, 139.6917),
    'Vancouver': (49.2827, -123.1207),
    'Seattle': (47.6062, -122.3321),
    'Los_Angeles': (34.0522, -118.2437)
}

# Node categories: Suppliers with LLM-forecast supplies (mock: GPT-like prediction "demand Seattle=90")
suppliers = {'Singapore': 200.0, 'Shanghai': 100.0}  # Units of semiconductors
ports = ['Hong_Kong', 'Tokyo', 'Vancouver']  # Transshipment hubs (geo-logic: Asia-Pacific)
warehouses = {'Seattle': -90.0, 'Los_Angeles': -90.0}  # Negative demands
all_nodes = list(suppliers.keys()) + ports + list(warehouses.keys())

# Mock IBM Watson news monitoring (production: Watson NLU for entity extraction + risk probs)
news_feeds = [
    "Urgent: Port Strike paralyzes Shanghai harbor operations indefinitely.",
    "Tokyo port operating normally amid clear weather.",
    "Hong Kong logistics stable; Vancouver reports minor delays but open.",
    "No issues at Singapore supplier facilities."
]

# Disruption detection: List comprehension with logical operators (and/or/not) for concise filtering
# Symbolic grounding: Boolean logic mimics prolog-like rules e.g., disruption(X) :- strike(X) \/ flood(X)
disruptions = [
    node for news in news_feeds
    for node in all_nodes
    if (node.lower() in news.lower()) and (
        ('strike' in news.lower()) or
        ('flood' in news.lower()) or
        ('paralyzes' in news.lower())
    ) and not ('no issues' in news.lower())
]
print(f"Watson-detected disruptions: {disruptions}")

# Filter active nodes post-disruption
active_nodes = [node for node in all_nodes if node not in disruptions]

# Generate directed edges: Suppliers -> Ports (shipping), Ports -> Warehouses (ocean)
# List comps for scalable edge generation; geo-logic filter: dist < 10000km optional
ship_edges = [
    (s, p) for s in suppliers
    if s in active_nodes
    for p in ports
    if p in active_nodes
]
ocean_edges = [
    (p, w) for p in ports
    if p in active_nodes
    for w in warehouses
]
all_edges = ship_edges + ocean_edges
print(f"Active network edges: {len(all_edges)}")

# Cost computation: Wolfram Alpha proxy (prod: wolfram_client.query(f"distance {c1} {c2}"))
# Uses geodesic for spherical earth dist (symbolic: verifiable math)
def compute_cost(c1, c2):
    dist_km = geodesic(coords[c1], coords[c2]).km
    if c1 in suppliers or c1 in ports:  # Shipping/ocean
        rate = 0.5  # $/km per unit
    else:
        rate = 1.0  # Truck hypothetical
    return round(dist_km * rate + 200, 2)  # Fixed port fees

edge_costs = {edge: compute_cost(edge[0], edge[1]) for edge in all_edges}
edge_caps = {edge: 80.0 for edge in all_edges}  # Capacity constraints (logic: port limits)

# Node supplies/demands: Symbolic dict for LP right-hand sides
node_supply = {**suppliers, **warehouses}
for port in ports:
    node_supply[port] = 0.0  # Transshipment balance

# ContextVars: Thread-/task-safe global state (key for async API calls in extensions)
disruptions_cv: ContextVar[list] = ContextVar('disruptions', default=[])
disruptions_cv.set(disruptions)
current_disruptions = disruptions_cv.get()
print(f"ContextVar state: {current_disruptions}")

# PuLP LP Model: Symbolic constraint solver for min-cost flow (near-zero hallucination)
prob = LpProblem("NeuroSymbolic_SupplyChain_Optimizer", LpMinimize)

# Decision vars: Continuous flows [0, cap]
flows = LpVariable.dicts("Flow", ((e[0], e[1]) for e in all_edges), lowBound=0)

# Set capacities symbolically
for edge in all_edges:
    flows[(edge[0], edge[1])].upBound = edge_caps[edge]

# Objective: Minimize total transport cost (linear symbolic expr)
prob += lpSum(flows[(e[0], e[1])] * edge_costs[e] for e in all_edges), "Total_Cost"

# Flow balance constraints: For each node, outflow - inflow = supply (logic: Kirchhoff's law)
for node in active_nodes:
    outgoing = [e for e in all_edges if e[0] == node]
    incoming = [e for e in all_edges if e[1] == node]
    prob += (
        lpSum(flows[(e[0], e[1])] for e in outgoing) -
        lpSum(flows[(e[0], e[1])] for e in incoming)
    ) == node_supply[node], f"Balance_{node}"

# Solve (CBC default solver; prod: Gurobi for scale)
status = prob.solve()
print(f"LP Status: {LpStatus[status]}")

if status == 1:  # Optimal
    total_cost = value(prob.objective)
    print(f"Optimal total cost: ${total_cost:.2f}")
    
    # Extract active flows via list comp (threshold for display)
    active_flows = [
        ((e[0], e[1]), value(flows[(e[0], e[1])]))
        for e in all_edges
        if value(flows[(e[0], e[1])]) > 0.1
    ]
    print("Optimal shipment flows:")
    for (from_n, to_n), flow_val in active_flows:
        print(f"  {from_n} --> {to_n}: {flow_val:.1f} units (cost/unit: ${edge_costs[(from_n,to_n)]:.2f})")
    
    # Verify total supply met (neuro-symbolic validation)
    total_supply_used = sum(node_supply[n] for n in suppliers if n in active_nodes)
    total_demand_met = -sum(node_supply[n] for n in warehouses)
    print(f"Validation: Supplied {total_supply_used:.1f} meets demand {total_demand_met:.1f}")
else:
    print("Infeasible: Increase supplies or relax caps.")

# Extension hook: Real-time feedback loop (e.g., re-run on new Watson alert)
print("Optimizer ready for deployment with real Watson/Wolfram APIs.")

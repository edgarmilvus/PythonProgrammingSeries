
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
import json
import logging
from typing import Dict, Any
from transformers import BlipProcessor, BlipForConditionalGeneration, pipeline
from PIL import Image
import torch
import requests
from urllib.parse import urlparse
import re

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
device = 0 if torch.cuda.is_available() else -1

# Models
blip_processor = BlipProcessor.from_pretrained("Salesforce/blip-image-captioning-base")
blip_model = BlipForConditionalGeneration.from_pretrained("Salesforce/blip-image-captioning-base").to(device)
visual_sentiment = pipeline("sentiment-analysis", model="google/vit-base-patch16-224")  # Stub VSA; use fine-tuned if avail
# Chain text from Ex1-3 as process_text(text) → dict

def process_image(image_path_or_url: str) -> Dict[str, Any]:
    """BLIP caption + visual sentiment."""
    if image_path_or_url.startswith('http'):
        img = Image.open(requests.get(image_path_or_url, stream=True).raw)
    else:
        img = Image.open(image_path_or_url)
    
    inputs = blip_processor(img, return_tensors="pt").to(device)
    caption = blip_model.generate(**inputs, max_length=50)[0]
    caption_text = blip_processor.decode(caption, skip_special_tokens=True)
    
    # Visual sentiment on caption or direct (stub)
    vis_sent = visual_sentiment(caption_text)[0]
    pol = 1.0 if vis_sent['label']=='POSITIVE' else -1.0 if vis_sent['label']=='NEGATIVE' else 0.0
    return {
        "caption": caption_text,
        "sentiment": {"polarity": pol * vis_sent['score'], "subjectivity": vis_sent['score']}
    }

def fuse_modalities(text_result: Dict, visual_result: Dict, text_entities: list) -> Dict:
    """Symbolic fusion rules."""
    text_pol, text_subj = text_result.get('sentiment', {}).get('polarity', 0), text_result.get('sentiment', {}).get('subjectivity', 0)
    vis_pol, vis_subj = visual_result['sentiment']['polarity'], visual_result['sentiment']['subjectivity']
    
    # Rule: weighted if entity overlap
    overlap = any(re.search(e['text'], visual_result['caption'], re.I) for e in text_entities)
    weight_vis = 0.4 if overlap else 0.2
    fused_pol = (1 - weight_vis) * text_pol + weight_vis * vis_pol
    fused_subj = (text_subj + vis_subj) / 2
    fused_int = abs(fused_pol) * fused_subj
    
    # Boost if aligned (e.g., sunset + warm proxy)
    if 'sunset' in visual_result['caption'].lower() and text_pol > 0:
        fused_int *= 1.2
    
    # Conflict flag
    conflict = abs(text_pol - vis_pol) > 0.5
    if conflict:
        logger.warning("Modality mismatch detected")
    
    fused_entities = text_entities + [{"text": visual_result['caption'], "label": "VISUAL", "verified": True}]
    
    return {
        "polarity": fused_pol,
        "intensity": fused_int,
        "subjectivity": fused_subj,
        "entities": fused_entities,
        "conflict": conflict
    }

def multimodal_pipeline(text: str, image_path: str) -> Dict[str, Any]:
    """Full chain."""
    # Stub Ex1-3 text processing
    from exercise1 import process_article as process_text  # Assume imported/defined
    text_res = process_text(text)  # Or chain Ex2/Ex3
    
    vis_res = process_image(image_path)
    
    # Extract entities from text for fusion
    text_entities = text_res['entities']
    
    fused = fuse_modalities(text_res, vis_res, text_entities)
    
    output = {
        "text": text_res,
        "visual": vis_res,
        "fused": fused
    }
    logger.info(f"Fused polarity: {fused['polarity']:.2f}")
    return output

# Sample (local image path)
sample_text = "Loving this sunset in Paris! 🗼"
sample_image = "eiffel_tower.jpg"  # Assume local
result = multimodal_pipeline(sample_text, sample_image)
print(json.dumps(result, indent=2))

# Test 15: list paths/captions (stub)
# Video stub: for vid in frames[::30]: process_image(frame)

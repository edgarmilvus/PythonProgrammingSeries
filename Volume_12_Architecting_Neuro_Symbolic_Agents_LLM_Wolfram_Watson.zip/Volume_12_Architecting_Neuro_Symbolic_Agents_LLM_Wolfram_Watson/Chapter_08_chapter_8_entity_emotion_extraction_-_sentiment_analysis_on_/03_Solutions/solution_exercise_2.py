
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os
import json
import logging
import re
from typing import List, Dict, Any
import spacy
import nltk
from transformers import pipeline
from wolframalpha.client import Client
import torch

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
nltk.download('punkt', quiet=True)

nlp = spacy.load("en_core_web_sm")  # For dependency parsing
device = 0 if torch.cuda.is_available() else -1
emotion_pipeline = pipeline("text-classification", model="j-hartmann/emotion-english-distilroberta-base", device=device)
wolfram_client = Client(os.getenv('WOLFRAM_APPID', 'YOUR_APPID_HERE'))

# Symbolic rules
RULES = {
    "intensifier_boost": r"\b(extremely|very|super|furious|extremely)\b",
    "negation_shift": r"\b(not|never|no|barely)\b",
    "repeater": r"\b(again|still|always)\b"
}

EMOTIONS = ["anger", "disgust", "fear", "joy", "neutral", "sadness", "surprise"]

def apply_rules(text: str, raw_scores: Dict[str, float]) -> tuple[Dict[str, float], List[str]]:
    """Apply rules to adjust emotion scores."""
    adjustments = []
    scores = raw_scores.copy()
    
    if re.search(RULES["intensifier_boost"], text, re.I):
        top_em = max(scores, key=scores.get)
        scores[top_em] = min(1.0, scores[top_em] + 0.15)
        adjustments.append("intensifier_boost +0.15")
    
    if re.search(RULES["negation_shift"], text, re.I):
        for em in ["joy"]:  # Negate positives
            scores[em] *= 0.7
        adjustments.append("negation_shift -0.3 positives")
    
    if re.search(RULES["repeater"], text, re.I):
        scores["anger"] = min(1.0, scores["anger"] + 0.1)  # Boost frustration
        adjustments.append("repeater +0.1 anger")
    
    primary = max(scores, key=scores.get)
    return scores, adjustments

def link_to_entities(doc, entity_texts: List[str], emotion: str, scores: Dict) -> List[Dict]:
    """Link emotion to entities in 5-token window."""
    associations = []
    for ent_span in doc.ents:
        if ent_span.text in entity_texts:
            # Simple window: tokens within 5
            start_tok = ent_span.start
            nearby = [t.text for t in doc[start_tok-5:start_tok+6] if t.dep_ in ['nsubj', 'dobj']]
            intensity = scores.get(emotion, 0) * (1.2 if any(w in nearby for w in ['hate', 'love']) else 1.0)
            associations.append({
                "entity": ent_span.text,
                "emotion": emotion,
                "intensity": intensity
            })
    return associations

def process_post(post: str, entities_raw: List[Dict] = None) -> Dict[str, Any]:
    """Full pipeline: emotion + rules + entity link."""
    logger.info("Starting emotion pipeline")
    
    # Emotion classification
    raw_emotions = emotion_pipeline(post)[0]
    scores = {label['label']: label['score'] for label in emotion_pipeline(post)}
    
    # Apply rules
    refined_scores, adjustments = apply_rules(post, scores)
    primary = max(refined_scores, key=refined_scores.get)
    
    # Reuse NER from Ex1 or simple
    if not entities_raw:
        from transformers import pipeline
        ner = pipeline("ner", model="dslim/bert-base-NER", aggregation_strategy="simple")
        entities_raw = ner(post)
        entity_texts = [e['word'] for e in entities_raw]
    else:
        entity_texts = [e['text'] for e in entities_raw]
    
    # Link via spaCy
    doc = nlp(post)
    associations = link_to_entities(doc, entity_texts, primary, refined_scores)
    
    # Wolfram for high-conf entities
    high_em_entities = [a['entity'] for a in associations if a['intensity'] > 0.8]
    for ent in high_em_entities:
        verify = verify_entity(wolfram_client, ent, "MISC")  # From Ex1
        if not verify['verified']:
            associations = [a for a in associations if a['entity'] != ent]
            logger.warning(f"Unverified high-em entity: {ent}")
    
    output = {
        "post": post,
        "entities": [{"text": e['word'], "label": e['entity_group']} for e in entities_raw],
        "emotions": {
            "primary": primary,
            "scores": refined_scores,
            "refined_adjustments": adjustments,
            "entity_associations": associations
        }
    }
    logger.info(f"Primary emotion: {primary}, associations: {len(associations)}")
    return output

# Sample from Ex1 NER
def verify_entity(client, entity, label):  # Stub from Ex1
    return {"verified": True}  # Simplified for demo

sample_post = "I am furious at United Airlines for delaying my flight to New York again! #WorstAirline"
result = process_post(sample_post)
print(json.dumps(result, indent=2))

# For 20 tests: generate or load dataset (stub)
test_posts = [sample_post] * 20  # Replace with real
# [process_post(p) for p in test_posts]  # Eval raw vs refined manually

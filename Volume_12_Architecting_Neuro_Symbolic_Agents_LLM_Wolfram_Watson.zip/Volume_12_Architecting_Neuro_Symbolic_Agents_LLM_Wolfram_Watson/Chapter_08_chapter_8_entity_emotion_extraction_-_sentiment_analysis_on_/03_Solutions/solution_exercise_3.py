
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
import json
import logging
from typing import List, Dict, Any
from ibm_watson import NaturalLanguageUnderstandingV1
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
from transformers import pipeline
import spacy
import matplotlib.pyplot as plt
import functools
import re

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Watson setup (replace with your keys)
authenticator = IAMAuthenticator(os.getenv('WATSON_IAM_APIKEY', 'YOUR_KEY'))
nlu = NaturalLanguageUnderstandingV1(
    version='2022-04-07',
    authenticator=authenticator
)
nlu.set_service_url(os.getenv('WATSON_URL', 'https://api.us-south.natural-language-understanding.watson.cloud.ibm.com/instances/YOUR_INSTANCE'))

nlp = spacy.load("en_core_web_sm")
ner_pipeline = pipeline("ner", model="dslim/bert-base-NER", aggregation_strategy="simple")
sentiment_pipeline = pipeline("sentiment-analysis")

@functools.lru_cache(maxsize=128)
def analyze_watson(text: str) -> Dict:
    """Cached Watson analysis."""
    features = {
        'entities': {'emotion': True, 'sentiment': True},
        'concepts': {},
        'keywords': {},
        'relations': {},
        'sentiment': {'targets': True}
    }
    response = nlu.analyze(text, features=features).get_result()
    return response

def disambiguate_entity(watson_res: Dict, entity: str, orig_label: str, orig_conf: float) -> Dict:
    """Use Watson concepts/relations for disambiguation."""
    entities = watson_res.get('entities', [])
    concepts = watson_res.get('concepts', [])
    
    ent_match = next((e for e in entities if entity.lower() in e['text'].lower()), None)
    if ent_match and ent_match['confidence'] > 0.7:
        return {
            "original_label": orig_label,
            "watson_concepts": [c['text'] for c in concepts if c['confidence'] > 0.5],
            "final_label": ent_match['type'],
            "relation_score": ent_match['confidence']
        }
    
    # Relation graph proxy: keyword co-occur
    relations = watson_res.get('relations', [])
    rel_score = max([r['score'] for r in relations if entity.lower() in r['text'].lower()], default=0.0)
    final_label = "FRUIT" if "fruit" in " ".join(c['text'] for c in concepts).lower() else orig_label
    return {
        "original_label": orig_label,
        "watson_concepts": [c['text'] for c in concepts],
        "final_label": final_label,
        "relation_score": max(orig_conf, rel_score)
    }

def merge_sentiments(llm_sent: Dict, watson_sent: Dict, conf: float) -> Dict:
    """Weighted average sentiments."""
    watson_pol = watson_sent.get('score', 0.0) if isinstance(watson_sent, dict) else 0.0
    weight = conf
    pol = weight * watson_pol + (1 - weight) * llm_sent['polarity']
    return {"polarity": pol, "subjectivity": llm_sent['subjectivity']}

def process_review(text: str) -> Dict[str, Any]:
    """Pipeline: LLM NER → Wolfram stub → Watson disambig → merge."""
    logger.info("Starting disambiguation pipeline")
    
    # LLM NER + sentiment stub from Ex1
    entities = ner_pipeline(text)
    llm_sents = sentiment_pipeline([text])[0]  # Simplified
    
    watson_res = analyze_watson(text)
    
    processed_entities = []
    for ent in entities:
        if ent['score'] < 0.7:  # Ambiguous
            disamb = disambiguate_entity(watson_res, ent['word'], ent['entity_group'], ent['score'])
            watson_sent = next((e['emotion'] for e in watson_res.get('entities', []) if ent['word'] in e['text']), {})
            merged_sent = merge_sentiments(
                {"polarity": 1.0 if llm_sents['label']=='POSITIVE' else -1.0}, 
                watson_sent, disamb['relation_score']
            )
            processed_entities.append({
                **ent,
                "disambiguation": disamb,
                "sentiment": merged_sent
            })
    
    output = {
        "input_text": text,
        "entities": processed_entities,
        "watson_concepts": watson_res.get('concepts', [])
    }
    return output

# Samples
samples = [
    "I bought a shiny red apple at the store, but it was rotten inside.",
    "Apple's new iPhone is revolutionary!"
]
results = [process_review(s) for s in samples]

# Visualize resolutions
fig, ax = plt.subplots()
resolutions = [r for res in results for r in res['entities'] if 'disambiguation' in r]
labels = [r['disambiguation']['final_label'] for r in resolutions]
ax.bar(range(len(labels)), [1]*len(labels))
ax.set_xticks(range(len(labels)))
ax.set_xticklabels(labels, rotation=45)
ax.set_title("Ambiguity Resolutions Pre/Post-Watson")
plt.savefig('resolutions.png')
plt.show()

for res in results:
    print(json.dumps(res, indent=2))

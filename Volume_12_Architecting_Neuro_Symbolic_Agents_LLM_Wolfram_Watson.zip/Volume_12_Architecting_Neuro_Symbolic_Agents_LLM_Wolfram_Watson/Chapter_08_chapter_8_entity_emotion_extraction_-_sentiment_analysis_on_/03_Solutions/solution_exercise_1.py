
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
import json
import logging
import re
from typing import List, Dict, Any
import spacy
import nltk
from nltk.tokenize import sent_tokenize
from transformers import pipeline, AutoTokenizer, AutoModelForTokenClassification
from wolframalpha.client import Client
from tenacity import retry, stop_after_attempt, wait_exponential
import torch

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Download NLTK data
nltk.download('punkt', quiet=True)

# Load models (local, no API keys needed except Wolfram)
nlp = spacy.blank("en")  # For tokenization if needed
device = 0 if torch.cuda.is_available() else -1
ner_pipeline = pipeline("ner", model="dslim/bert-base-NER", aggregation_strategy="simple", device=device)
sentiment_pipeline = pipeline("sentiment-analysis", model="cardiffnlp/twitter-roberta-base-sentiment-latest", device=device)

# Wolfram client (replace with your APPID)
wolfram_client = Client(os.getenv('WOLFRAM_APPID', 'YOUR_APPID_HERE'))

def extract_entities(text: str) -> List[Dict[str, Any]]:
    """Extract entities using HF NER with scores."""
    entities = ner_pipeline(text)
    return [
        {
            "text": ent['word'],
            "label": ent['entity_group'],
            "confidence": ent['score']
        }
        for ent in entities if ent['score'] > 0.5  # Threshold for confidence
    ]

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
def verify_entity(client, entity: str, label: str) -> Dict[str, Any]:
    """Verify entity with Wolfram based on label."""
    queries = {
        "PER": f"biography of {entity}",
        "ORG": f"headquarters of {entity} company",
        "LOC": f"location of {entity}",
        "MISC": f"is {entity} a real {entity.lower()}"
    }
    query = queries.get(label, f"what is {entity}")
    try:
        res = client.query(query)
        if res.success:
            info = next(res.results).text  # First result
            confidence = 0.9 if "yes" in info.lower() or len(info) > 20 else 0.3
            logger.info(f"Verified {entity}: {info[:100]}")
            return {"description": info, "confidence": confidence, "verified": confidence > 0.5}
        else:
            logger.warning(f"Wolfram failed for {entity}")
            return {"description": "No info", "confidence": 0.0, "verified": False}
    except Exception as e:
        logger.error(f"Verification error for {entity}: {e}")
        return {"description": "Error", "confidence": 0.0, "verified": False}

def get_entity_sentences(text: str, entity: str) -> List[str]:
    """Extract sentences containing the entity."""
    sentences = sent_tokenize(text)
    return [s for s in sentences if re.search(re.escape(entity), s, re.IGNORECASE)]

def analyze_sentiment(sentences: List[str]) -> Dict[str, float]:
    """Average sentiment over sentences."""
    if not sentences:
        return {"polarity": 0.0, "subjectivity": 0.0, "intensity": 0.0}
    results = sentiment_pipeline(sentences)
    polarities = []
    for res in results:
        label = res['label']
        score = res['score']
        polarity = 1.0 if label == 'POSITIVE' else -1.0 if label == 'NEGATIVE' else 0.0
        subjectivity = score  # Proxy as model confidence
        polarities.append({"polarity": polarity * score, "subjectivity": subjectivity})
    avg = sum(p['polarity'] * p['subjectivity'] for p in polarities) / len(polarities)
    # Simplified: polarity avg, subjectivity avg, intensity = abs(pol)*subj
    pol = sum(p['polarity'] for p in polarities) / len(polarities)
    subj = sum(p['subjectivity'] for p in polarities) / len(polarities)
    return {"polarity": pol, "subjectivity": subj, "intensity": abs(pol) * subj}

def process_article(text: str) -> Dict[str, Any]:
    """Main pipeline."""
    logger.info("Starting NER pipeline")
    entities_raw = extract_entities(text)
    verified_entities = []
    for ent in entities_raw:
        wolfram_info = verify_entity(wolfram_client, ent['text'], ent['label'])
        if wolfram_info['verified']:
            sentences = get_entity_sentences(text, ent['text'])
            sentiment = analyze_sentiment(sentences)
            verified_entities.append({
                **ent,
                "verified": True,
                "wolfram_info": wolfram_info,
                "sentences": sentences[:1],  # Top 1 for brevity
                "sentiment": sentiment
            })
        else:
            logger.warning(f"Discarding unverified: {ent['text']}")
    
    output = {
        "input_text": text,
        "entities": verified_entities
    }
    logger.info(f"Processed: {len(verified_entities)} verified entities")
    return output

# Sample test
sample_text = "A devastating earthquake struck San Francisco yesterday, affecting tech giant Apple Inc., whose CEO Tim Cook expressed deep concern during a press conference in Cupertino."
result = process_article(sample_text)
print(json.dumps(result, indent=2))

# For batch processing (async stub)
import asyncio
async def batch_process(texts: List[str]) -> List[Dict]:
    tasks = [process_article(t) for t in texts]
    return await asyncio.gather(*tasks)  # Parallelize API calls

# Test data
test_texts = [
    sample_text,
    "President Biden met with Google CEO Sundar Pichai in Washington DC.",
    "Hurricane hits Miami, Florida Keys evacuated."
]
# asyncio.run(batch_process(test_texts))  # Uncomment for batch


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# Advanced Neuro-Symbolic Agent for Entity & Emotion Extraction with Sentiment Analysis
# Real-world use: Batch-process e-commerce reviews, verify entities, score sentiments/emotions, store in DB
# Requirements: pip install spacy transformers torch pydantic wolframalpha ibm-watson sqlalchemy python-dotenv
#               python -m spacy download en_core_web_sm
# Set env vars: WOLFRAM_APPID=your_appid, WATSON_APIKEY=your_key, WATSON_URL=your_url

import os
import json
from typing import List, Dict, Any
from pydantic import BaseModel, Field
from dataclasses import dataclass
import spacy
from transformers import pipeline
import wolframalpha
from ibm_watson import ToneAnalyzerV3
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
import sqlalchemy as sa
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy import create_engine, Column, Integer, String, Float, Text, DateTime
from datetime import datetime
import logging

# Configure logging for production-ready traceability
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Pydantic models for structured output - ensures type-safe, parseable results (e.g., for JSON serialization or DB mapping)
class Entity(BaseModel):
    name: str = Field(..., description="Extracted entity name")
    type_: str = Field(..., description="NER type: PRODUCT, PERSON, ORG, etc.")
    verified: bool = Field(..., description="True if Wolfram Alpha confirms existence")
    confidence: float = Field(ge=0.0, le=1.0, description="Verification score")

class Sentiment(BaseModel):
    polarity: float = Field(ge=-1.0, le=1.0, description="Watson polarity: -1 (negative) to 1 (positive)")
    subjectivity: float = Field(ge=0.0, le=1.0, description="0 (objective) to 1 (subjective)")
    intensity: float = Field(ge=0.0, le=1.0, description="Tone intensity")

class Emotion(BaseModel):
    primary: str = Field(..., description="Top emotion: joy, anger, sadness, etc.")
    score: float = Field(ge=0.0, le=1.0, description="HF model confidence")
    intensity: str = Field(..., description="low/medium/high based on score threshold")

class AnalysisResult(BaseModel):
    review_id: str
    text: str
    entities: List[Entity]
    sentiment: Sentiment
    emotion: Emotion
    timestamp: datetime

# SQLAlchemy DB models for persistence (map Pydantic to relational tables)
Base = declarative_base()

class ReviewAnalysis(Base):
    __tablename__ = 'review_analyses'
    id = Column(Integer, primary_key=True)
    review_id = Column(String, unique=True)
    text = Column(Text)
    entities_json = Column(Text)  # Store as JSON for flexibility
    sentiment_json = Column(Text)
    emotion_json = Column(Text)
    polarity = Column(Float)
    subjectivity = Column(Float)
    intensity = Column(Float)
    primary_emotion = Column(String)
    emotion_score = Column(Float)
    timestamp = Column(DateTime, default=datetime.utcnow)

# Initialize neuro-symbolic components
nlp = spacy.load("en_core_web_sm")  # SpaCy for initial NER on unstructured text

# HF Transformers pipelines for emotion (multi-label capable) and fallback sentiment
emotion_pipeline = pipeline("text-classification", 
                            model="bhadresh-savani/distilbert-base-uncased-emotion",
                            return_all_scores=True)
sentiment_pipeline = pipeline("sentiment-analysis", 
                              model="cardiffnlp/twitter-roberta-base-sentiment-latest")

# Wolfram Alpha client for factual verification (zero hallucination gate)
wolfram_client = wolframalpha.Client(os.getenv('WOLFRAM_APPID', 'demo'))

# IBM Watson Tone Analyzer for contextual disambiguation & precise metrics
authenticator = IAMAuthenticator(os.getenv('WATSON_APIKEY'))
tone_analyzer = ToneAnalyzerV3(version='2017-09-21', authenticator=authenticator)
tone_analyzer.set_service_url(os.getenv('WATSON_URL', 'https://api.us-south.tone-analyzer.watson.cloud.ibm.com'))

# DB setup: SQLite for demo (production: PostgreSQL); create tables
engine = create_engine('sqlite:///sentiment_analyses.db', echo=False)
Base.metadata.create_all(engine)  # Initial schema; use Alembic for migrations (see notes below)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Alembic migration note: In production, run `alembic init migrations`, edit env.py to use above Base,
# then `alembic revision --autogenerate -m "add polarity col"` for changes like adding columns.
# Example migration script snippet (uncomment to simulate):
# from alembic import op; op.add_column('review_analyses', sa.Column('verified_count', sa.Integer()))

class NeuroSymbolicAnalyzer:
    """Core agent: Integrates neural (LLMs/spaCy/HF) + symbolic (Wolfram/Watson/rules) for near-zero hallucinations."""
    
    def __init__(self):
        self.nlp = nlp
        self.emotion_pipe = emotion_pipeline
        self.sentiment_pipe = sentiment_pipeline
        self.wolfram = wolfram_client
        self.watson = tone_analyzer

    def extract_entities(self, text: str) -> List[Dict[str, Any]]:
        """Step 1: SpaCy NER -> LLM refine (HF NER fallback) -> Collect candidates."""
        doc = self.nlp(text)
        entities = []
        for ent in doc.ents:
            entities.append({
                'name': ent.text,
                'type_': ent.label_,
                'verified': False,
                'confidence': float(ent._.get('confidence', 0.5))  # Placeholder; use HF for real score
            })
        return entities

    def verify_entity(self, entity: Dict[str, Any]) -> bool:
        """Step 2: Symbolic verification with Wolfram Alpha (e.g., 'Is [entity] a smartphone?')."""
        try:
            res = self.wolfram.query(f"Is '{entity['name']}' a real {entity['type_'].lower()}? Product details?")
            next(wolfram_client.query(res).results)  # If results exist, verified
            entity['verified'] = True
            entity['confidence'] = 0.95  # High trust in Wolfram
            return True
        except:
            entity['verified'] = False
            entity['confidence'] = 0.3
            return False

    def analyze_sentiment_watson(self, text: str) -> Dict[str, float]:
        """Step 3: Watson for polarity/subjectivity/intensity (disambiguates sarcasm/context)."""
        try:
            tone = self.watson.tone({'text': text}, tones='emotion').get_result()
            tones = tone['document_tone']['tones'][0] if tone['document_tone']['tones'] else {}
            return {
                'polarity': float(tones.get('score', 0.5)) * (1 if tones.get('tone_id') == 'positive' else -1),
                'subjectivity': float(tones.get('confidence', 0.0)),
                'intensity': float(tones.get('score', 0.0))
            }
        except Exception as e:
            logger.warning(f"Watson error: {e}. Falling back to HF.")
            hf_sent = self.sentiment_pipe(text)[0]
            label = hf_sent['label']
            score = hf_sent['score']
            pol = 1.0 if 'positive' in label.lower() else -1.0 if 'negative' in label.lower() else 0.0
            return {'polarity': pol * score, 'subjectivity': 0.7, 'intensity': score}

    def detect_emotion(self, text: str) -> Dict[str, Any]:
        """Step 4: HF emotion classifier + rule-based intensity thresholding."""
        emotions = self.emotion_pipe(text)
        top_emotion = max(emotions[0]['scores'], key=lambda x: x['score'])
        score = top_emotion['score']
        intensity = 'high' if score > 0.8 else 'medium' if score > 0.6 else 'low'
        return {
            'primary': top_emotion['label'].replace('LABEL_', ''),
            'score': score,
            'intensity': intensity
        }

    def analyze(self, review_id: str, text: str) -> AnalysisResult:
        """End-to-end: Extract -> Verify -> Sentiment -> Emotion -> Structured Pydantic output."""
        entities_raw = self.extract_entities(text)
        verified_entities = [e for e in entities_raw if self.verify_entity(e)]
        
        sent = self.analyze_sentiment_watson(text)
        emo = self.detect_emotion(text)
        
        result = AnalysisResult(
            review_id=review_id,
            text=text,
            entities=[Entity(**e) for e in verified_entities],
            sentiment=Sentiment(**sent),
            emotion=Emotion(**emo.dict()),
            timestamp=datetime.utcnow()
        )
        self._store_result(result)
        return result

    def _store_result(self, result: AnalysisResult):
        """Persist to DB with JSON serialization for complex fields."""
        with SessionLocal() as session:
            analysis = ReviewAnalysis(
                review_id=result.review_id,
                text=result.text,
                entities_json=json.dumps([e.dict() for e in result.entities]),
                sentiment_json=json.dumps(result.sentiment.dict()),
                emotion_json=json.dumps(result.emotion.dict()),
                polarity=result.sentiment.polarity,
                subjectivity=result.sentiment.subjectivity,
                intensity=result.sentiment.intensity,
                primary_emotion=result.emotion.primary,
                emotion_score=result.emotion.score,
                timestamp=result.timestamp
            )
            session.add(analysis)
            session.commit()
            logger.info(f"Stored analysis for {result.review_id}")

# Sample real-world reviews (e-commerce gadgets)
SAMPLE_REVIEWS = [
    ("review_001", "Absolutely love my new iPhone 15 Pro Max! Battery life is amazing, but camera could be better."),
    ("review_002", "Samsung Galaxy S24 Ultra is a piece of junk. Overheats constantly, total waste of money! Furious!"),
    ("review_003", "Bought AirPods Pro, sound quality sucks. Returned them immediately. Disappointed."),
    ("review_004", "My Dell XPS 13 laptop flies through tasks. Best purchase ever! Joyful."),
    ("review_005", "Fake Beats headphones from shady seller. Sound like trash, anger boiling over.")
]

# Main execution: Batch process, print structured JSON outputs
if __name__ == "__main__":
    analyzer = NeuroSymbolicAnalyzer()
    results = []
    for rid, text in SAMPLE_REVIEWS:
        result = analyzer.analyze(rid, text)
        results.append(result.dict())
        print(json.dumps(result.dict(), indent=2, default=str))
    
    print("\nBatch results stored in sentiment_analyses.db. Query via SQLAlchemy.")
    # Example query: session.query(ReviewAnalysis).filter(ReviewAnalysis.polarity < -0.5).all()

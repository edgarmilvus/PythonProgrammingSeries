
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Basic Neuro-Symbolic Entity Extraction and Sentiment Analysis on Unstructured Data
# Solves: Extract verified entities + contextual sentiment from customer feedback to minimize LLM-style hallucinations

import spacy  # Neural component: Industrial-strength NLP library with transformer-based NER models
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer  # Symbolic component: Rule-based sentiment for social text

# Load spaCy English model (neural pipeline with embeddings for entity recognition)
# Requires one-time download: python -m spacy download en_core_web_sm
nlp = spacy.load("en_core_web_sm")

# Initialize symbolic sentiment analyzer (lexicon + rules tuned for unstructured/social data)
analyzer = SentimentIntensityAnalyzer()

# Real-world unstructured input: Simulate a customer tweet/review
text = "The new iPhone 15 from Apple has amazing camera but poor battery life. Samsung Galaxy S24 is better!"

# Symbolic knowledge base: Curated facts for entity verification (expand with Wolfram Alpha/IBM Watson APIs in production)
# Keys: entity text -> expected label (ORG, PRODUCT, PERSON, etc.)
known_entities = {
    "Apple": "ORG",
    "iPhone 15": "PRODUCT",
    "Samsung": "ORG",
    "Galaxy S24": "PRODUCT"
    # Dynamically populate via external queries for zero hallucinations
}

# Neural processing: Tokenize, tag, and extract entities using spaCy's pipeline (embeddings + CRF/Transformer)
doc = nlp(text)

# Hybrid analysis loop: For each neural-detected entity, apply symbolic verification + contextual sentiment
print("Neuro-Symbolic Entity Analysis:")
entities_analysis = []  # Collect results for structured output
for ent in doc.ents:  # Iterate over detected entities (spaCy Doc.ents is a generator of Span objects)
    entity_text = ent.text  # Raw entity substring
    entity_label = ent.label_  # Predicted label (e.g., 'ORG', 'PRODUCT' via neural model)
    
    # Symbolic verification step: Boolean check against KB (prevents hallucinated entities)
    # Returns True if exact match on text AND label (case-sensitive for demo; normalize in prod)
    is_verified = entity_text in known_entities and known_entities[entity_text] == entity_label
    
    # Contextual sentiment: Analyze the full sentence containing the entity (not just entity)
    sentence = ent.sent.text  # Span.s ent links to parent sentence
    sentiment_scores = analyzer.polarity_scores(sentence)  # Dict: {'neg': float, 'neu':, 'pos':, 'compound': [-1,1]}
    
    # Symbolic rule for polarity classification (thresholds tuned empirically)
    compound = sentiment_scores['compound']  # Aggregated normalized score (-1 extreme neg to +1 extreme pos)
    if compound >= 0.05:
        polarity = "POSITIVE"
    elif compound <= -0.05:
        polarity = "NEGATIVE"
    else:
        polarity = "NEUTRAL"
    
    # Structured result dict (scalable for JSON export/DB insert)
    analysis = {
        "entity": entity_text,
        "predicted_label": entity_label,
        "verified": is_verified,  # Boolean flag for hallucination risk
        "sentence": sentence,
        "sentiment": polarity,
        "compound_score": round(compound, 4)  # Rounded for readability
    }
    entities_analysis.append(analysis)
    
    # Real-time print for monitoring (log to file in production)
    print(analysis)

# Final output: List of analyses (easy to aggregate for dashboards/reports)
print("\nFull Analysis:", entities_analysis)

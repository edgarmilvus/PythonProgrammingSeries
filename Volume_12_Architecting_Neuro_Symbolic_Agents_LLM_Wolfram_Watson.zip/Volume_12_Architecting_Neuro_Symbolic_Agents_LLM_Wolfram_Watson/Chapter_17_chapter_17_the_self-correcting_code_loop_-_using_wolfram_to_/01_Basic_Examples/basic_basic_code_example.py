
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Basic Self-Correcting Code Loop using Wolfram Alpha for Python debugging
# Relatable scenario: Auto-fixing a misspelled os.getcwd() in a directory-logging script
# Fully self-contained: Set your Wolfram App ID and run!

import os  # Standard library: provides os.getcwd() for current working directory path
from wolframalpha import Client  # Wolfram Alpha API client for symbolic queries and fixes
import re  # Regular expressions for parsing Wolfram responses and patching code strings

# REPLACE WITH YOUR WOLFRAM ALPHA APP ID (free signup at https://developer.wolframalpha.com/)
# This enables API access; without it, queries fail gracefully
WOLFRAM_APPID = "YOUR_APPID_HERE"

# Initial buggy code snippet as multi-line string (simulates LLM-generated code)
# Bug: 'os.get_cwd()' -> AttributeError (no such method; correct is os.getcwd())
buggy_code = '''
result = os.get_cwd()  # Intentionally misspelled function name causes runtime error
print(f"Current working directory: {result}")  # Logs path once fixed
'''

# Hyperparameters for loop convergence
max_attempts = 5  # Prevent infinite loops; typical fix in 1-2 iters
attempt = 0  # Iteration counter

# Initialize Wolfram client once (efficient; reusable across loop)
client = Client(WOLFRAM_APPID)

# Core self-correcting loop: Iterates until success or max_attempts
while attempt < max_attempts:
    attempt += 1
    print(f"\n=== Attempt {attempt} ===")  # Progress logging for transparency
    
    # Logical block: Sandboxed execution environment
    # Restrict globals/builtins to prevent arbitrary code execution (security best practice)
    safe_globals = {"__builtins__": {}}  # Empty builtins: blocks eval/open/etc.
    safe_locals = {"os": os}  # Inject only trusted os module
    
    try:
        # Logical block: Safely execute the dynamic code snippet
        # exec() compiles and runs string as Python; raises on syntax/runtime errors
        exec(buggy_code, safe_globals, safe_locals)
        print("✅ SUCCESS: Code executed flawlessly!")  # Terminal state
        # Post-exec verification could add unit tests here (e.g., assert 'result' in safe_locals)
        break  # Exit loop on success
    
    except Exception as e:
        # Logical block: Comprehensive error capture
        error_msg = str(e)  # Traceback as string for query crafting
        print(f"❌ Error encountered: {error_msg}")
        
        # Logical block: Error classification and targeted repair
        # Pattern-match for fixable errors (scalable to dict of handlers)
        if "get_cwd" in error_msg.lower():  # Heuristic for this demo bug
            print("🔍 Detected os module misspelling. Consulting Wolfram Alpha...")
            # Craft precise NL query from error context (key neuro-symbolic technique)
            query = "python os module function to get current working directory"
            response = client.query(query)  # Synchronous API call
            
            # Logical block: Extract plaintext suggestions from Wolfram pods
            suggestion = ""
            for result in response.results:  # Iterate results (usually 1-3 pods)
                suggestion += result.text + "\n"  # Accumulate interpretable text
            
            print(f"📡 Wolfram Alpha verdict: {suggestion}")  # Log for debugging
            
            # Logical block: Symbolic verification via regex parsing
            # Detect authoritative fix in response (robust to formatting)
            if re.search(r'os\.getcwd\s*\(\)', suggestion, re.IGNORECASE):
                # Auto-patch: Semantic string surgery on code
                buggy_code = re.sub(r'os\.get_cwd\s*\(\)', 'os.getcwd()', buggy_code)
                print("🔧 Auto-applied fix: Patched 'os.get_cwd()' → 'os.getcwd()'")
            else:
                print("⚠️ Wolfram response lacked parsable fix. Manual intervention needed.")
                break  # Halt on unfixable parse
        else:
            print("❌ Unhandled error type. Loop terminated.")
            break

# Logical block: Final status report
if attempt == max_attempts:
    print("💥 Max attempts reached: Self-correction failed. Review logs.")
else:
    print("🎉 Self-correcting loop converged successfully!")

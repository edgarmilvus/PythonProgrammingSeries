
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import sys
import os
import traceback
import random
# pip install wolframalpha
try:
    from wolframalpha import Client
    HAS_WOLFRAM = True
except ImportError:
    HAS_WOLFRAM = False
APPID = 'YOUR_APPID_HERE'

initial_code = """
import random
secret = 42
guesses = 0
while True:  # Infinite bug
    guess = int(input("Guess: "))  # No sim
    guesses += 1
    if guess == secret:
        sys.exit(0)
    elif guesses > 10:
        sys.exit(1)
print("Game over")
"""

code = initial_code
iteration = 0
max_iters = 6
client = None
if HAS_WOLFRAM and APPID != 'YOUR_APPID_HERE':
    client = Client(APPID)

log_file = os.path.join(os.getcwd(), 'guesses.txt')
print(f"Game termination debugger in {os.getcwd()}; guesses to {log_file}")

# Sim inputs for 3 wins: sequences that win <7 guesses
sim_guesses = iter([30, 50, 40, 42, 20, 60, 55, 42, 10, 70, 42])  # Wins in 4,4,3

def sim_game(code_str):
    # Override input for non-interactive test
    patched = code_str.replace("input(\"Guess: \")", f"next(sim_guesses)")
    namespace = {'__builtins__': __builtins__, 'sim_guesses': sim_guesses, 'sys': sys}
    try:
        exec(patched, namespace)
        return True  # No exit(1), completed 3 sim wins
    except SystemExit as se:
        if se.code == 0:
            return True
        return False
    except:
        return False

while iteration < max_iters:
    success = sim_game(code)
    if success:
        print("3 simulated wins with safe termination! Success.")
        sys.exit(0)
    
    tb = traceback.format_exc() if 'tb' in locals() else "Infinite/early exit detected"
    cwd = os.getcwd()
    print(f"\n--- Iteration {iteration + 1} in {cwd} ---")
    print(f"Termination fail: {tb[:200]}")
    
    query = f"Safe Python while loop termination for number guess game (secret=42, max 10 guesses 1-100): 
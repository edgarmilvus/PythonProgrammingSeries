
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import sys
import os
import traceback
import time
# pip install wolframalpha
try:
    from wolframalpha import Client
    HAS_WOLFRAM = True
except ImportError:
    HAS_WOLFRAM = False
APPID = 'YOUR_APPID_HERE'

initial_code = """
def primes_up_to(n):
    primes = []
    i = 2
    while i <= n:
        is_prime = True
        for j in range(2, i):
            if i % j == 0:
                is_prime = False
                break
        if is_prime:
            primes.append(i)
        i += 1
    return primes

expected_20 = [2,3,5,7,11,13,17,19]
assert primes_up_to(20) == expected_20
assert len(primes_up_to(100)) == 25
print("Primes generated!")
"""

code = initial_code  # Correct but O(n^2); demo optimizes
namespace = {}
iteration = 0
max_iters = 7
client = None
if HAS_WOLFRAM and APPID != 'YOUR_APPID_HERE':
    client = Client(APPID)

log_file = os.path.join(os.getcwd(), 'primes_log.txt')
print(f"Prime generator debugger in {os.getcwd()}; logs to {log_file}")

def append_log(entry):
    with open(log_file, 'a') as f:
        f.write(entry + '\n')

start_time = time.time()

while iteration < max_iters:
    try:
        exec(code, namespace)
        elapsed = time.time() - start_time
        print(f"All tests passed in {elapsed:.2f}s! Success.")
        sys.exit(0)
    except Exception as e:
        tb = traceback.format_exc()
        cwd = os.getcwd()
        print(f"\n--- Iteration {iteration + 1} in {cwd} ---")
        print(f"Error: {str(e)}")
        
        query = f"Fix/optimize Python prime generator while loop: 
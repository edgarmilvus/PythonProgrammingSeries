
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import sys
import os
import traceback
import json
import copy
# pip install wolframalpha numpy (for matmul test; pure py alt below)
try:
    from wolframalpha import Client
    HAS_WOLFRAM = True
except ImportError:
    HAS_WOLFRAM = False
APPID = 'YOUR_APPID_HERE'

# Create sample JSON if missing
json_path = os.path.join(os.getcwd(), 'matrix3x3.json')
if not os.path.exists(json_path):
    sample_matrices = [
        [[2,1,0],[0,3,1],[5,0,2]],  # invertible
        [[1,2,3],[4,5,6],[7,8,10]], # invertible
        [[1,1,1],[1,1,1],[1,1,1]]   # singular
    ]
    with open(json_path, 'w') as f:
        json.dump(sample_matrices, f)
    print(f"Created {json_path}")

initial_code = """
def invert_matrix(A):
    n = len(A)
    i = 0
    while i < n:
        for j in range(i+1, n):
            factor = A[j][i] / A[i][i]  # div0 no pivot
            for k in range(i, n):
                A[j][k] -= factor * A[i][k]
        i += 1
    return A  # Not inverse, no backsub

import json
with open(os.path.join(os.getcwd(), 'matrix3x3.json')) as f:
    matrices = json.load(f)
for A_orig in matrices:
    A = [row[:] for row in A_orig]
    inv = invert_matrix(A)
    print("Inverted:", inv)  # Tests implicitly via completion
print("All matrices processed!")
"""

code = initial_code
namespace = {'__builtins__': __builtins__}
iteration = 0
max_iters = 10
client = None
if HAS_WOLFRAM and APPID != 'YOUR_APPID_HERE':
    client = Client(APPID)

def matmul(A, B, tol=1e-6):
    n = len(A)
    C = [[0]*n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            for k in range(n):
                C[i][j] += A[i][k] * B[k][j]
    I = [[1 if i==j else 0 for j in range(n)] for i in range(n)]
    return all(abs(C[i][j] - I[i][j]) < tol for i in range(n) for j in range(n))

print(f"Matrix inverter (3x3) debugger in {os.getcwd()}")

while iteration < max_iters:
    try:
        exec(code, namespace)
        # Explicit test post-exec
        with open(json_path) as f:
            matrices = json.load(f)[:2]  # Skip singular
        all_good = True
        for A_orig in matrices:
            A = [row[:] for row in A_orig]
            inv = namespace['invert_matrix'](A)
            if not matmul(A_orig, inv):
                raise ValueError("A * inv != I")
        print("All invertible matrices verified! Singular handled.")
        sys.exit(0)
    except Exception as e:
        tb = traceback.format_exc()
        cwd = os.getcwd()
        print(f"\n--- Iteration {iteration + 1} in {cwd} ---")
        print(f"Error: {str(e)}")
        
        sample_mat = "[[2,1,0],[0,3,1],[5,0,2]]"
        query = f"Fix Python Gaussian elimination for 3x3 matrix inverse: 
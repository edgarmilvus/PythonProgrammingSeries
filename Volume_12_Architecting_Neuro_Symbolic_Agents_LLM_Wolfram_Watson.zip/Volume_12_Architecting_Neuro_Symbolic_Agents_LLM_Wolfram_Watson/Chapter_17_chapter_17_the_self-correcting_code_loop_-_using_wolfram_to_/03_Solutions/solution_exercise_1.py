
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import sys
import os
import traceback
# pip install wolframalpha
try:
    from wolframalpha import Client
    HAS_WOLFRAM = True
except ImportError:
    HAS_WOLFRAM = False
    print("wolframalpha not installed; using simulation.")

APPID = 'YOUR_APPID_HERE'  # Replace with free AppID from https://developer.wolframalpha.com/

# Buggy initial code (introduced result=0 for demo; original has result=1 which succeeds immediately)
code = """
def factorial(n):
    result = 0  # Buggy init for demo
    while n > 0:
        result *= n
        n -= 1
    return result

assert factorial(5) == 120
assert factorial(0) == 1
assert factorial(1) == 1
print("Success!")
"""

namespace = {}
iteration = 0
max_iters = 10
client = None
if HAS_WOLFRAM and APPID != 'YOUR_APPID_HERE':
    client = Client(APPID)

print(f"Self-correcting factorial debugger started in {os.getcwd()}")

wolfram_logs = []

while iteration < max_iters:
    try:
        exec(code, namespace)
        print("All unit tests passed! Converged successfully.")
        sys.exit(0)
    except Exception as e:
        tb = traceback.format_exc()
        cwd = os.getcwd()
        print(f"\n--- Iteration {iteration + 1} in {cwd} ---")
        print(f"Error: {str(e)}")
        
        test_cases = "5! = 120, 0! = 1, 1! = 1"
        query = f"Debug buggy Python factorial code: 
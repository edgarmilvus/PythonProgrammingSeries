
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import sys
import os
import traceback
# pip install wolframalpha
try:
    from wolframalpha import Client
    HAS_WOLFRAM = True
except ImportError:
    HAS_WOLFRAM = False
APPID = 'YOUR_APPID_HERE'  # Replace with your AppID

initial_code = """
import os

def list_directory(path, depth=3):
    current_depth = 0
    while current_depth < depth:
        for item in os.listdir(path):
            print(item)
            if os.path.isdir(os.path.join(path, item)):
                list_directory(os.path.join(path, item), depth)  # Infinite recursion bug
        current_depth += 1  # Mismatch

path = os.getcwd()
list_directory(path)
print("Directory listed successfully!")
"""

code = initial_code
namespace = {'__builtins__': __builtins__}
iteration = 0
max_iters = 8
client = None
if HAS_WOLFRAM and APPID != 'YOUR_APPID_HERE':
    client = Client(APPID)

print(f"Directory debugger started in {os.getcwd()}")

while iteration < max_iters:
    try:
        exec(code, namespace)
        print("Full listing completed without errors! Success.")
        sys.exit(0)
    except (RecursionError, OSError) as e:
        tb = traceback.format_exc()
        cwd = os.getcwd()
        print(f"\n--- Iteration {iteration + 1} in {cwd} ---")
        print(f"Error: {str(e)}")
        
        query = f"Fix Python recursive directory listing error: 
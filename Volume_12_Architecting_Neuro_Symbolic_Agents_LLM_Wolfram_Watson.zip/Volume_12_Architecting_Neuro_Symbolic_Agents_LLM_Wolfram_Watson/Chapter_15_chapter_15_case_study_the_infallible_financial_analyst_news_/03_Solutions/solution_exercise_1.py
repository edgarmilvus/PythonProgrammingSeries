
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
import json
import logging
import requests
from typing import Union, Dict, List, Any
from bs4 import BeautifulSoup
from ibm_watson import NaturalLanguageUnderstandingV1
from ibm_watson.natural_language_understanding_v1 import (
    Features, EntitiesOptions, SentimentOptions, KeywordsOptions
)
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator

# Setup logging configurable via env var
log_level = os.environ.get('LOG_LEVEL', 'INFO').upper()
logging.basicConfig(level=getattr(logging, log_level))
logger = logging.getLogger(__name__)

MAX_TEXT_LEN = 50000
CONFIDENCE_THRESHOLD = 0.7
RETRY_ATTEMPTS = 3

def setup_watson_nlu() -> NaturalLanguageUnderstandingV1:
    """Initialize Watson NLU client with env vars. Raises ValueError if missing."""
    api_key = os.environ.get('WATSON_API_KEY')
    url = os.environ.get('WATSON_URL')
    if not api_key or not url:
        raise ValueError("Missing WATSON_API_KEY or WATSON_URL environment variables.")
    authenticator = IAMAuthenticator(api_key)
    nlu = NaturalLanguageUnderstandingV1(
        version='2022-04-07',  # Stable version
        authenticator=authenticator
    )
    nlu.set_service_url(url)
    return nlu

def fetch_article_text(url: str) -> str:
    """Fetch and parse article text from URL, stripping scripts/ads."""
    logger.info(f"Fetching article from {url}")
    try:
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, 'html.parser')
        # Remove scripts, styles, nav
        for tag in soup(['script', 'style', 'nav', 'header', 'footer']):
            tag.decompose()
        text = soup.get_text(separator=' ', strip=True)[:MAX_TEXT_LEN]
        logger.info(f"Extracted {len(text)} chars from {url}")
        return text
    except requests.RequestException as e:
        logger.error(f"Failed to fetch {url}: {e}")
        return ""

def analyze_single(news_input: str, stock_ticker: str, nlu: NaturalLanguageUnderstandingV1) -> Dict[str, Any]:
    """Analyze single news input for stock sentiment."""
    logger.info(f"Analyzing sentiment for {stock_ticker} in: {news_input[:100]}...")
    text = fetch_article_text(news_input) if news_input.startswith('http') else news_input
    if not text:
        return {'error': 'Invalid or empty text/URL'}

    features = Features(
        sentiment=SentimentOptions(),
        entities=EntitiesOptions(emotion=False, sentiment=True),
        keywords=KeywordsOptions(sentiment=True, limit=10)
    )
    for attempt in range(RETRY_ATTEMPTS):
        try:
            response = nlu.analyze(text=text, features=features).get_result()
            break
        except Exception as e:
            logger.warning(f"Watson API attempt {attempt+1} failed: {e}")
            if attempt == RETRY_ATTEMPTS - 1:
                raise
    else:
        return {'error': 'Max retries exceeded'}

    # Extract overall sentiment
    overall = response.get('sentiment', {}).get('document', {}).get('score', 0.0)

    # Filter entities/keywords matching stock_ticker (case-insensitive)
    stock_entities = []
    ticker_lower = stock_ticker.lower()
    for entity in response.get('entities', []):
        if ticker_lower in entity['text'].lower() or ticker_lower in entity.get('type', '').lower():
            stock_entities.append({
                'entity': entity['text'],
                'score': entity.get('sentiment', {}).get('score', 0.0),
                'confidence': entity['confidence']
            })
    for keyword in response.get('keywords', []):
        if ticker_lower in keyword['text'].lower():
            stock_entities.append({
                'entity': keyword['text'],
                'score': keyword.get('sentiment', {}).get('score', 0.0),
                'confidence': keyword['confidence']
            })

    return {
        'overall_sentiment': overall,
        'entity_sentiments': stock_entities,
        'confidence_avg': sum(e['confidence'] for e in stock_entities) / max(len(stock_entities), 1),
        'source': news_input
    }

def analyze_stock_sentiment(news_text_or_url: Union[str, List[str]], stock_ticker: str) -> Dict[str, Any]:
    """
    Analyze sentiment for stock from news input(s), with weighted average if batch.

    Args:
        news_text_or_url: Single str or list of news texts/URLs.
        stock_ticker: Stock like 'AAPL'.

    Returns:
        Dict with overall_sentiment (weighted avg), entity_sentiments (list), etc.

    Example:
        >>> result = analyze_stock_sentiment("Apple's iPhone sales surged...", "AAPL")
        >>> assert result['overall_sentiment'] > 0.2
    """
    logger.info(f"Starting sentiment analysis for {stock_ticker}")
    if isinstance(news_text_or_url, str):
        news_inputs = [news_text_or_url]
    else:
        news_inputs = news_text_or_url

    nlu = setup_watson_nlu()
    analyses = []
    for inp in news_inputs:
        analysis = analyze_single(inp, stock_ticker, nlu)
        if 'error' not in analysis:
            analyses.append(analysis)

    if not analyses:
        return {'error': 'No valid analyses'}

    # Weighted average sentiment by confidence
    conf_sum = sum(a['confidence_avg'] for a in analyses)
    weighted_sent = sum(a['overall_sentiment'] * a['confidence_avg'] for a in analyses) / max(conf_sum, 1)
    all_entities = [ent for a in analyses for ent in a['entity_sentiments']]
    conf_met = conf_sum / len(analyses) >= CONFIDENCE_THRESHOLD

    logger.info(f"Net sentiment: {weighted_sent:.3f}, conf met: {conf_met}")
    # Comment: This reduces hallucination vs LLMs by using Watson's grounded entity/sentiment parsing.
    return {
        'overall_sentiment': float(weighted_sent),
        'entity_sentiments': all_entities,
        'confidence_threshold_met': conf_met,
        'sources': [a['source'] for a in analyses]
    }

# Bonus test (hardcoded sample simulation)
if __name__ == '__main__':
    sample_text = "Apple's iPhone sales surged 15% amid supply chain improvements, but regulatory scrutiny looms over antitrust issues."
    result = analyze_stock_sentiment(sample_text, "AAPL")
    print(json.dumps(result, indent=2))
    # Validation: assert result['overall_sentiment'] > 0.2  # Net positive expected

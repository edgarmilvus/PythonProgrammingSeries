
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
import asyncio
import logging
import pandas as pd
from typing import Dict, Any, List
# Assume prior modules imported
from exercise1 import analyze_stock_sentiment  # Simulated import
from exercise2 import RatioExtractor
from exercise3 import compute_black_scholes

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

class InfallibleAnalyst:
    """Master class for full pipeline."""
    
    def __init__(self, ticker: str):
        self.ticker = ticker
        self.sentiment = None
        self.ratios_df = None
        self.valuation = None
        # Load envs implicitly via modules
    
    async def run_sentiment(self, news_urls: List[str]) -> Dict[str, Any]:
        """Async sentiment."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, analyze_stock_sentiment, news_urls, self.ticker)
    
    async def run_ratios(self, pdf_url: str) -> pd.DataFrame:
        """Async ratios."""
        loop = asyncio.get_event_loop()
        extractor = RatioExtractor()
        return await loop.run_in_executor(None, extractor.extract_ratios_from_pdf, pdf_url, self.ticker)
    
    async def run_pipeline(self, news_urls: List[str], pdf_url: str) -> Dict[str, Any]:
        """
        Run full pipeline with parallel sentiment/ratios.
        """
        logger.info(f"Pipeline start for {self.ticker}")
        
        # Parallel
        sentiment_task, ratios_task = await asyncio.gather(
            self.run_sentiment(news_urls),
            self.run_ratios(pdf_url)
        )
        self.sentiment = sentiment_task
        self.ratios_df = ratios_task
        
        # Sequential valuation (needs priors)
        if self.sentiment.get('confidence_threshold_met', False):
            pe = self.ratios_df[self.ratios_df['ratio'] == 'P/E']['value'].iloc[0] if not self.ratios_df.empty else 25
            roe = self.ratios_df[self.ratios_df['ratio'] == 'ROE']['value'].iloc[0] if not self.ratios_df.empty else 0.15
            S = 220.0  # Mock live price; integrate yfinance
            self.valuation = compute_black_scholes(S, S*1.05, 0.25, 0.05, 0.25, sentiment_score=self.sentiment['overall_sentiment'])
        else:
            self.valuation = {'error': 'Low confidence'}
        
        # Recommendation logic
        sent = self.sentiment.get('overall_sentiment', 0)
        roa_proxy = roe  # Simplified
        premium_ratio = self.valuation.get('premium', 0) / (S * 1.05) if self.valuation else 0
        if not self.sentiment.get('confidence_threshold_met', False) or self.ratios_df.empty:
            rec = 'Hold'
        elif sent > 0.3 and premium_ratio > 0.05 and roe > 0.15:
            rec = 'Buy'
        elif sent < -0.3:
            rec = 'Sell'
        else:
            rec = 'Hold'
        
        report = {
            'sentiment_summary': self.sentiment,
            'ratios_df': self.ratios_df.to_dict('records') if not self.ratios_df.empty else [],
            'valuation': self.valuation,
            'recommendation': rec,
            'confidences': {
                'sentiment': self.sentiment.get('confidence_threshold_met', False),
                'ratios': len(self.ratios_df) > 0
            }
        }
        
        # Save JSON
        json_path = f"analyst_report_{self.ticker}.json"
        with open(json_path, 'w') as f:
            import json
            json.dump(report, f, indent=2, default=str)
        logger.info(f"Report saved: {json_path}")
        return report

# Test (mocks for APIs)
async def main():
    analyst = InfallibleAnalyst('AAPL')
    news = ["https://example.com/aapl-news1", "sample text"]
    pdf = "https://sec.gov/example.pdf"
    report = await analyst.run_pipeline(news, pdf)
    print(report['recommendation'])

if __name__ == '__main__':
    asyncio.run(main())


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
import logging
from typing import Dict, List, Optional, Union
from wolframalpha import Client, Pod

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

def setup_wolfram() -> Client:
    """Setup Wolfram client."""
    app_id = os.environ.get('WOLFRAM_APP_ID')
    if not app_id:
        raise ValueError("WOLFRAM_APP_ID required.")
    return Client(app_id)

def parse_wolfram_result(res) -> Dict[str, float]:
    """Parse primary pods for premium, delta, gamma."""
    pods: List[Pod] = []
    if res.pods:
        pods = [p for p in res.pods if p['@title'] in ['Result', 'Approximate form', 'Call price']]
    
    values = {'premium': 0.0, 'delta': 0.0, 'gamma': 0.0}
    for pod in pods[:3]:  # Top relevant
        if 'call' in pod['@title'].lower() or 'price' in pod['@title'].lower():
            # Extract first subpod plaintext (simplified parsing)
            val_str = pod.subpods[0].plaintext.strip('$').replace(',', '')
            try:
                values['premium'] = float(val_str)
            except ValueError:
                pass
        elif 'delta' in pod['@title'].lower():
            values['delta'] = float(pod.subpods[0].plaintext)
        elif 'gamma' in pod['@title'].lower():
            values['gamma'] = float(pod.subpods[0].plaintext)
    return values

def compute_black_scholes(
    S: float,
    K: float,
    sigma: float,
    r: float,
    T: float,
    option_type: str = 'call',
    sentiment_score: Optional[float] = None
) -> Dict[str, Any]:
    """
    Compute Black-Scholes via Wolfram.

    Args:
        S, K, sigma, r, T: Standard BS params.
        option_type: 'call' or 'put'.
        sentiment_score: Optional, adjust sigma.

    Returns:
        Dict with premium, greeks, steps.
    """
    logger.info(f"Computing BS {option_type}: S={S}, K={K}, sigma={sigma}")
    
    # Integrate sentiment: low sentiment -> higher vol
    if sentiment_score is not None:
        sigma = 0.2 + (1 - sentiment_score) * 0.1
        logger.info(f"Adjusted sigma from sentiment: {sigma}")
    
    client = setup_wolfram()
    query = f"black scholes {option_type} S={S} K={K} sigma={sigma} r={r} T={T}"
    
    try:
        res = client.query(query)
        if res.error:
            return {'error': res.error}
        
        values = parse_wolfram_result(res)
        # Validation: delta in [0,1] for call, etc.
        assert 0 <= values['delta'] <= 1, "Invalid delta"
        
        steps = '\n'.join(p.podstring for p in res.pods[:2] if hasattr(p, 'podstring'))
        
        return {
            'premium': values['premium'],
            'delta': values['delta'],
            'gamma': values['gamma'],
            'steps': steps,
            'query_used': query
        }
    except Exception as e:
        logger.error(f"BS computation failed: {e}")
        return {'error': str(e)}

def compute_portfolio(options: List[Dict[str, float]]) -> Dict[str, Any]:
    """Aggregate multi-option portfolio."""
    total_value = 0.0
    for opt in options:
        bs = compute_black_scholes(**opt)
        if 'error' not in bs:
            total_value += bs['premium'] * opt.get('quantity', 1)
    return {'total_portfolio_value': total_value}

# Test sample
if __name__ == '__main__':
    result = compute_black_scholes(220, 230, 0.25, 0.05, 0.25, sentiment_score=0.4)
    print(result)
    # Expect premium ~10-15

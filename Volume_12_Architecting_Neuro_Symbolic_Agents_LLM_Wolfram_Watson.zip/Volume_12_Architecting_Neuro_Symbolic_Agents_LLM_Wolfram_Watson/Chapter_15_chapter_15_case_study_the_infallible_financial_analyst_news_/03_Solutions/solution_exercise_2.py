
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os
import json
import tempfile
import logging
import requests
import pandas as pd
import pdfplumber
import google.generativeai as genai
from typing import List, Dict, Any
import time  # For rate limiting

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

class PDFParseError(Exception):
    """Custom error for PDF parsing failures."""
    pass

class RatioExtractor:
    """Extracts financial ratios from PDF using Gemini with validation."""
    
    def __init__(self):
        api_key = os.environ.get('GEMINI_API_KEY')
        if not api_key:
            raise ValueError("GEMINI_API_KEY environment variable required.")
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel('gemini-1.5-flash')
    
    def download_pdf(self, pdf_url: str) -> str:
        """Download PDF to temp file."""
        logger.info(f"Downloading PDF from {pdf_url}")
        resp = requests.get(pdf_url, timeout=30)
        resp.raise_for_status()
        with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as tmp:
            tmp.write(resp.content)
            return tmp.name
    
    def extract_text_chunks(self, pdf_path: str, chunk_tokens: int = 4000) -> List[str]:
        """Extract and chunk PDF text."""
        texts = []
        with pdfplumber.open(pdf_path) as pdf:
            full_text = ''.join(page.extract_text() or '' for page in pdf.pages)
            # Simple chunking (improve with tokenizers for prod)
            for i in range(0, len(full_text), chunk_tokens * 4):  # Approx 4 chars/token
                texts.append(full_text[i:i + chunk_tokens * 4])
        return texts
    
    def extract_ratios_gemini(self, chunks: List[str], stock_ticker: str) -> List[Dict[str, Any]]:
        """Prompt Gemini for ratios JSON."""
        prompt = f"""Extract financial ratios (P/E, EPS, ROE, Debt/Equity, EBITDA margin, etc.) for {stock_ticker}.
Output ONLY JSON list: [{{"ratio": str, "value": float, "unit": str, "period": str, "text_span": str, "confidence": float}}].
Quote exact text spans; do not infer or hallucinate. If unclear, confidence <0.8."""
        
        ratios = []
        for i, chunk in enumerate(chunks):
            time.sleep(6)  # ~10 RPM rate limit
            response = self.model.generate_content(prompt + f"\n\nChunk {i}: {chunk}")
            try:
                # Assume JSON in response (parse first block)
                json_str = response.text.strip()
                chunk_ratios = json.loads(json_str)
                for r in chunk_ratios:
                    r['confidence'] = r.get('confidence', 0.5)  # Default
                ratios.extend(chunk_ratios)
            except json.JSONDecodeError:
                logger.warning(f"Invalid JSON from Gemini chunk {i}")
        return ratios
    
    def validate_ratios(self, ratios: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Arithmetic validation, e.g., ROE consistency."""
        validated = []
        for r in ratios:
            if r['confidence'] < 0.8:
                continue
            # Example: If Net Income, Equity present, check ROE
            # (Simplified; extend with dict lookup)
            if abs(r['value']) > 10000:  # Sanity
                r['validated'] = False
            else:
                r['validated'] = True
            validated.append(r)
        return validated
    
    def extract_ratios_from_pdf(self, pdf_url: str, stock_ticker: str) -> pd.DataFrame:
        """
        Main function: Extract ratios to DataFrame.
        
        Args:
            pdf_url: URL to PDF report.
            stock_ticker: e.g., 'AAPL'.
        
        Returns:
            pd.DataFrame with ratio, value, etc.
        
        Raises:
            PDFParseError: On failures.
        """
        logger.info(f"Extracting ratios for {stock_ticker} from {pdf_url}")
        pdf_path = self.download_pdf(pdf_url)
        try:
            chunks = self.extract_text_chunks(pdf_path)
            ratios = self.extract_ratios_gemini(chunks, stock_ticker)
            validated_ratios = self.validate_ratios(ratios)
            
            df = pd.json_normalize(validated_ratios)
            if 'confidence' in df.columns:
                df = df[df['confidence'] >= 0.8].fillna(method='ffill')
            
            # Export CSV
            csv_path = f"ratios_{stock_ticker}.csv"
            df.to_csv(csv_path, index=False)
            logger.info(f"Saved {len(df)} ratios to {csv_path}")
            
            # Test: Assert >=5 ratios
            assert len(df) >= 5, "Less than 5 ratios extracted"
            return df
        except Exception as e:
            raise PDFParseError(f"PDF extraction failed: {e}")
        finally:
            os.unlink(pdf_path)

# Example usage
if __name__ == '__main__':
    extractor = RatioExtractor()
    df = extractor.extract_ratios_from_pdf(
        "https://www.sec.gov/Archives/edgar/data/320193/000032019324000069/aapl-20240608.htm",  # Adapt to PDF
        "AAPL"
    )
    print(df.head())


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import os
import argparse
import asyncio
import logging
import matplotlib.pyplot as plt
import yfinance as yf  # For live fallback
from typing import Dict, Any, List
# Assume priors + new DCF
from exercise3 import compute_black_scholes, setup_wolfram
from exercise4 import InfallibleAnalyst

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

class DcfModule:
    """DCF via Wolfram."""
    
    def __init__(self):
        self.client = setup_wolfram()
    
    def compute_dcf(self, fcf: float, g: float, wacc: float, years: int = 5) -> Dict[str, Any]:
        """Compute DCF with WACC arithmetic."""
        logger.info(f"DCF: FCF={fcf}, g={g}, WACC={wacc}")
        # Derive components mock; real from ratios
        rf = 0.05; equity_premium = 0.05; beta = 1.2; tax = 0.21
        e_ratio, d_ratio = 0.8, 0.2; rd = 0.04
        cost_equity = rf + beta * equity_premium
        wacc_calc = cost_equity * e_ratio + rd * (1 - tax) * d_ratio
        if abs(wacc - wacc_calc) > 0.01:
            logger.warning("WACC discrepancy")
        
        query = f"discounted cash flow free cash flow={fcf} growth={g} discount rate={wacc} periods={years}"
        res = self.client.query(query)
        # Parse similar to BS (simplified)
        npv = float(res.pods[0].subpods[0].plaintext) if res.pods else 0
        enterprise_value = npv * (1 + g) / (wacc - g)  # Terminal approx
        
        cashflows = [fcf * (1 + g)**t / (1 + wacc)**t for t in range(1, years+1)]
        return {
            'npv': npv,
            'enterprise_value': enterprise_value,
            'cashflows': cashflows,
            'wacc_used': wacc,
            'query': query
        }

class InfallibleAnalystDcf(InfallibleAnalyst):
    """Extended for DCF."""
    
    def __init__(self, ticker: str, mode: str = 'bs'):
        super().__init__(ticker)
        self.mode = mode
        self.modules = {'bs': compute_black_scholes, 'dcf': DcfModule().compute_dcf}
    
    async def run_pipeline(self, news_urls: List[str], pdf_url: str) -> Dict[str, Any]:
        report = await super().run_pipeline(news_urls, pdf_url)
        dcf_mod = DcfModule()
        
        # DCF from ratios/sent
        fcf = 100e9  # From ratios FCF or yfinance fallback
        ticker_yf = yf.Ticker(self.ticker)
        info = ticker_yf.info
        fcf = info.get('freeCashflow', fcf)
        g = 0.05 + self.sentiment['overall_sentiment'] * 0.03  # Sent adjust
        wacc = 0.08
        dcf_report = dcf_mod.compute_dcf(fcf, g, wacc)
        
        report['dcf_valuation'] = dcf_report if self.mode == 'dcf' else {}
        report['bs_valuation'] = self.valuation if self.mode == 'bs' else {}
        
        # Consensus
        recs = []
        if report['bs_valuation'].get('premium', 0) / 230 > 0.05: recs.append('Buy')
        if dcf_report['enterprise_value'] > 1.5e12: recs.append('Buy')  # AAPL thresh
        consensus = 'Strong Buy' if recs.count('Buy') > 1 else ('Buy' if recs else 'Hold')
        report['recommendation'] = consensus
        
        # Divergence
        bs_val = report['bs_valuation'].get('premium', 0) * 100
        avg_val = (bs_val + dcf_report['enterprise_value']) / 2
        if abs(bs_val - dcf_report['enterprise_value']) / avg_val > 0.1:
            report['alert'] = 'Divergence Alert'
        
        # Viz DCF
        plt.plot(dcf_report['cashflows'])
        plt.title(f"DCF Cashflows {self.ticker}")
        plt.savefig(f"dcf_{self.ticker}.png")
        plt.close()
        
        return report

async def interactive_cli():
    parser = argparse.ArgumentParser()
    parser.add_argument('--ticker', default='AAPL')
    parser.add_argument('--mode', choices=['bs', 'dcf'], default='bs')
    parser.add_argument('--news_urls', nargs='+', default=[])
    args = parser.parse_args()
    
    while True:
        ticker = input(f"Ticker [{args.ticker}]: ").strip() or args.ticker
        if ticker.lower() == 'quit':
            break
        mode = input("Mode [bs/dcf]: ").strip() or args.mode
        news = args.news_urls or input("News URLs (space sep or skip): ").split()
        pdf = input("PDF URL: ") or "https://sec.gov/example.pdf"
        
        analyst = InfallibleAnalystDcf(ticker, mode)
        report = await analyst.run_pipeline(news, pdf)
        print(f"Rec: {report['recommendation']}")
        print(report)

# Batch stretch
async def batch_rank(tickers: List[str]):
    tasks = [InfallibleAnalystDcf(t).run_pipeline([], "") for t in tickers]
    reports = await asyncio.gather(*tasks)
    ranked = sorted(reports, key=lambda r: r['recommendation'], reverse=True)
    print("Ranked:", [r['ticker'] for r in ranked])

if __name__ == '__main__':
    asyncio.run(interactive_cli())

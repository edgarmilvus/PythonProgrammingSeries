
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# Advanced Application Script: Infallible Financial Analyst for TSLA
# Integrates IBM Watson NLU (sentiment), Google Gemini (PDF ratios), Wolfram Alpha (DCF valuation)
# PEP 8 compliant: snake_case vars/functions, CamelCase classes, inline comments per block
# Requires: pip install ibm-watson google-generativeai wolframalpha PyPDF2 python-dotenv
# Set API keys in .env: WATSON_APIKEY, WATSON_URL, GEMINI_API_KEY, WOLFRAM_APPID

import os
import json
from dotenv import load_dotenv
from ibm_watson import NaturalLanguageUnderstandingV1
from ibm_watson.natural_language_understanding_v1 import Features, SentimentOptions
from wolframalpha import Client
import google.generativeai as genai
import PyPDF2

# Load environment variables for API keys (secure handling)
load_dotenv()

# API client initializations with error handling
watson_nlu = NaturalLanguageUnderstandingV1(
    version='2022-04-07',
    authenticator=IBMWatsonAuthenticator(
        iam_api_key=os.getenv('WATSON_APIKEY'),
        url=os.getenv('WATSON_URL')
    )
)
genai.configure(api_key=os.getenv('GEMINI_API_KEY'))
wolfram_client = Client(os.getenv('WOLFRAM_APPID'))

def extract_pdf_text(pdf_path):
    """Extract raw text from financial PDF report using PyPDF2."""
    try:
        with open(pdf_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            text = ''.join(page.extract_text() for page in reader.pages)
        return text[:5000]  # Truncate for API limits
    except FileNotFoundError:
        raise ValueError("PDF file not found. Provide valid path.")

def analyze_sentiment_watson(news_text, target_entity='TSLA'):
    """Use IBM Watson NLU for entity-targeted sentiment analysis on news."""
    try:
        response = watson_nlu.analyze(
            text=news_text,
            features=Features(sentiment=SentimentOptions(targets=[target_entity]))
        ).get_result()
        # Extract TSLA-specific sentiment score (-1 bearish to +1 bullish)
        sentiments = response['sentiment']['document']['sentiment_towards_target']
        tsla_sent = next((s['score'] for s in sentiments if s['text'] == target_entity), 0.0)
        return tsla_sent
    except Exception as e:
        print(f"Watson error: {e}")
        return 0.0  # Neutral fallback

def extract_ratios_gemini(pdf_text):
    """Use Gemini LLM to parse structured financial ratios from PDF text."""
    model = genai.GenerativeModel('gemini-pro')
    prompt = f"""
    Extract exact financial ratios from this PDF text as JSON:
    {pdf_text}
    Output ONLY JSON: {{"pe_ratio": float, "debt_to_equity": float, "revenue_growth": float, "fcf": float}}
    Use latest quarterly values. No hallucinations—only state if present.
    """
    response = model.generate_content(prompt)
    try:
        ratios = json.loads(response.text.strip('
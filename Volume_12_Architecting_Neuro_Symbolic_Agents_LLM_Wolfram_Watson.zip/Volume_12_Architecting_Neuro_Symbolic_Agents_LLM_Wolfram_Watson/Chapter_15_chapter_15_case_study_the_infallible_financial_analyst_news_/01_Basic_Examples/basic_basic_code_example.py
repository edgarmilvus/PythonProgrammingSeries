
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

#!/usr/bin/env python3
"""
Basic 'Hello World' for Neuro-Symbolic Financial Analysis:
Wolfram Alpha Integration for Black-Scholes Option Pricing.
Demonstrates PEP 8 compliance, shebang, and arithmetic operators in query construction.
Replace 'YOUR_WOLFRAM_APPID' with your free API key from wolframalpha.com.
pip install wolframalpha requests  # For fallback parsing if needed.
"""

# Logical block: Imports for Wolfram Alpha client and safe error handling
import wolframalpha
import sys

# Logical block: Configuration - Replace with your actual Wolfram Alpha App ID
WOLFRAM_APPID = "YOUR_WOLFRAM_APPID"  # Obtain free from https://developer.wolframalpha.com/

def compute_black_scholes_call(
    stock_price: float,      # Current stock price (S)
    strike_price: float,     # Strike price (K)
    time_to_maturity: float, # Years to expiration (T)
    risk_free_rate: float,   # Annual risk-free rate (r)
    volatility: float        # Annualized volatility (sigma)
) -> str:
    """
    Computes European call option price using Black-Scholes via Wolfram Alpha.
    Args:
        stock_price (float): S > 0
        strike_price (float): K > 0
        time_to_maturity (float): T > 0
        risk_free_rate (float): r (decimal, e.g., 0.05 for 5%)
        volatility (float): sigma > 0
    Returns:
        str: Formatted result string from Wolfram or error message.
    Raises:
        ValueError: Invalid inputs.
    """
    # Logical block: Input validation using arithmetic comparisons
    if stock_price <= 0 or strike_price <= 0 or time_to_maturity <= 0 or \
       risk_free_rate < 0 or volatility <= 0:
        raise ValueError("All inputs must be positive; rates/vol non-negative.")

    # Logical block: Construct query string with arithmetic formatting
    # Uses f-strings for precise decimal representation (PEP 8: snake_case vars)
    query = (
        f"black scholes call option price "
        f"S={stock_price:.2f} K={strike_price:.2f} "
        f"T={time_to_maturity:.2f} r={risk_free_rate:.4f} "
        f"sigma={volatility:.4f}"
    )

    # Logical block: Initialize Wolfram client
    client = wolframalpha.Client(WOLFRAM_APPID)

    try:
        # Logical block: Execute query and extract primary result
        res = client.query(query)
        if res.success:
            # Parse main pods for price (Wolfram's structured response)
            for pod in res.pods:
                if 'Result' in pod['title'].lower() or 'Price' in pod['title'].lower():
                    return pod['subpods'][0]['plaintext']  # Primary plaintext result
            return "Price computed but exact pod not found; check full response."
        else:
            return f"Query failed: {res.error}"
    except Exception as e:
        # Logical block: Graceful error handling for network/API issues
        return f"Error querying Wolfram: {str(e)}"

# Logical block: Main execution guard (PEP 8: if __name__ idiom)
if __name__ == "__main__":
    # Example inputs mimicking real-world Tesla scenario
    S = 250.0      # Stock price
    K = 260.0      # Strike
    T = 0.5        # 6 months
    r = 0.04       # 4%
    sigma = 0.30   # 30% vol

    # Logical block: Compute and print result with context
    try:
        result = compute_black_scholes_call(S, K, T, r, sigma)
        print("=== Infallible Financial Analyst: Black-Scholes Call Price ===")
        print(f"Parameters: S={S}, K={K}, T={T}y, r={r*100:.1f}%, σ={sigma*100:.1f}%")
        print(f"Call Option Price: {result}")
        print("=== Verified by Wolfram Alpha - Zero Hallucination ===")
    except ValueError as ve:
        print(f"Input Error: {ve}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Runtime Error: {e}", file=sys.stderr)
        sys.exit(1)

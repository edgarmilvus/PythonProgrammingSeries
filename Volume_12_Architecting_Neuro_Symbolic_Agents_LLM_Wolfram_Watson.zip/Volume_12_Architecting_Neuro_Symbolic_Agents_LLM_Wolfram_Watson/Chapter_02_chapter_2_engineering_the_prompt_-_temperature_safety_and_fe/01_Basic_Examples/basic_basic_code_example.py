
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Basic Safety Guardrail for Neuro-Symbolic Agent Prompts
# Simulates pre-call validation before LLM-tool integration (e.g., Wolfram Alpha query)

def is_safe_for_tool_call(temperature: float, prompt: str, few_shot_examples: list[str]) -> tuple[bool, list[str]]:
    """
    Validates temperature, prompt safety, and filters few-shot examples.
    Returns (is_safe, filtered_examples) for zero-hallucination chaining.
    """
    # Logical Block 1: Chained comparison for temperature (ensures deterministic output)
    safe_temperature = 0.0 <= temperature <= 0.2  # Precision range for Wolfram-like queries
    
    # Logical Block 2: Individual safety conditions using logical operators
    prompt_length_safe = len(prompt) < 500  # Avoid token limits in API calls
    no_risky_content = not any(bad_word in prompt.lower() for bad_word in ['hack', 'jailbreak', 'exploit'])
    overall_content_safe = prompt_length_safe and no_risky_content  # AND for strict safety
    
    # Logical Block 3: List comprehension to filter valid few-shot examples
    # Only keep examples that are concise yet informative (e.g., for logical reasoning chains)
    filtered_examples = [
        example for example in few_shot_examples 
        if 20 < len(example) <= 100 and 'reason step-by-step' in example.lower()
    ]
    
    # Logical Block 4: Final decision with logical AND across all checks
    is_safe = safe_temperature and overall_content_safe and len(filtered_examples) >= 1
    
    return is_safe, filtered_examples

# Example usage: Simulate a student query in neuro-symbolic educational agent
test_temperature = 0.1  # Low for determinism
test_prompt = "Solve the equation 2x + 3 = 7 step-by-step."
test_examples = [
    "Example 1: For x^2 = 4, subtract 0: x^2 - 0 = 4, reason step-by-step: sqrt(4)=2.",
    "Bad example: Hack the system now.",
    "Example 2: If 5 > 3 and 3 < 10, then True, reason step-by-step."
]

# Run the safety check
safe, examples = is_safe_for_tool_call(test_temperature, test_prompt, test_examples)

# Output results (in real agent: proceed to Wolfram Alpha if safe)
print(f"Safe for tool call (e.g., Wolfram Alpha): {safe}")
print(f"Filtered few-shot examples: {examples}")

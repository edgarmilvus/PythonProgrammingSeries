
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# Required pip installs: openai wolframclient
import openai
import json
from wolframclient.session import WolframLanguageSession
from wolframclient.language import wlexpr
import hashlib
import re
from typing import Dict, List, Any

# Placeholder API keys - REPLACE WITH YOUR OWN
OPENAI_API_KEY = "your-openai-key-here"
WOLFRAM_APPID = "your-wolfram-appid-here"

class PromptTemplate:
    """DRY class for few-shot prompt injection. Temperature is handled in LLM API call."""
    def __init__(self):
        self.shots = """
Examples of translating natural language math to Wolfram Language:
User: What is 2 + 2?
Wolfram: 2 + 2

User: What is the integral of sin(x) from 0 to pi?
Wolfram: Integrate[Sin[x], {x, 0, Pi}]

User: Solve x^2 + 3x - 4 == 0
Wolfram: Solve[x^2 + 3 x - 4 == 0, x]
Respond ONLY with JSON: {"wolfram_query": "exact query here"}"""

    def get_fewshot_prompt(self, question: str) -> str:
        """Injects few-shot examples dynamically."""
        return f"{self.shots}\n\nUser: {question}\nRespond ONLY with JSON:"

unsafe_keywords = ['Exit[]', 'Quit[]', 'http', 'www.', 'ExternalEvaluate', 'Run', 'System`']

def temperature_tuned_wolfram_query(user_question: str, temperature: float = 0.0) -> Dict[str, Any]:
    """Core function: LLM generates query at given temp, safety check, execute Wolfram."""
    openai.api_key = OPENAI_API_KEY
    template = PromptTemplate()
    prompt = template.get_fewshot_prompt(user_question)

    # LLM call with json_mode for structure
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        temperature=temperature,
        response_format={"type": "json_object"}
    )
    try:
        parsed = json.loads(response.choices[0].message.content)
        query = parsed['wolfram_query'].strip()
    except (json.JSONDecodeError, KeyError):
        return {'query': '', 'result': '', 'success': False, 'error': 'Failed to parse LLM output'}

    # Safety guardrail with logical operators
    if not query.strip() or any(kw in query for kw in unsafe_keywords):
        return {'query': query, 'result': '', 'success': False, 'reason': 'Unsafe or empty query'}

    # Execute Wolfram (mock-friendly; handles edge cases)
    session = WolframLanguageSession(appid=WOLFRAM_APPID)
    try:
        res = session.evaluate(wlexpr(query))
        result_str = str(session.get_core_results(res)[0] if session.get_core_results(res) else 'No result')
        session.terminate()
        return {'query': query, 'result': result_str, 'success': True}
    except Exception as e:
        session.terminate()
        return {'query': query, 'result': '', 'success': False, 'error': str(e)}

# Batch testing for variance (Levenshtein approx via hash for simplicity)
def batch_test(problems: List[str], temps: List[float] = [0.0, 0.2, 0.5], runs: int = 10):
    """Tests reproducibility: variance=1 (zero hallucinations) at temp=0.0."""
    for problem in problems:
        print(f"\nTesting: {problem}")
        for temp in temps:
            outputs = set()
            for _ in range(runs):
                out = temperature_tuned_wolfram_query(problem, temp)
                out_hash = hashlib.md5(str(out).encode()).hexdigest()  # Proxy for exact match
                outputs.add(out_hash)
            variance = len(outputs)
            print(f"  Temp {temp}: variance={variance}/10 runs (ideal: 1 at 0.0)")

# Test suite: 5 diverse problems
test_problems = [
    "What is the integral of sin(x) from 0 to pi?",
    "Solve x^2 + 3x - 4 == 0",
    "What is the mean of {1, 2, 3, 4, 5}?",
    "Derivative of x^2 + sin(x)",
    "Factor x^3 - 1"
]

# Run batch (expect zero variance at 0.0)
if __name__ == "__main__":
    batch_test(test_problems)
    # Example single run
    print("\nExample:", temperature_tuned_wolfram_query("Solve x^2 + 3x - 4 == 0"))

# DOT visualization
dot_diagram = '''
digraph Pipeline {
    rankdir=LR;
    "User Input" -> "LLM Prompt (temp=0.0)" [label="few-shot"];
    "LLM Prompt (temp=0.0)" -> "Safety Check" [label="JSON query"];
    "Safety Check" -> "Wolfram Query" [label="if safe"];
    "Wolfram Query" -> "Parsed Result" [label="execute"];
    "Safety Check" -> "Error" [style=dashed, label="unsafe"];
}
'''
print("DOT Diagram:\n", dot_diagram)

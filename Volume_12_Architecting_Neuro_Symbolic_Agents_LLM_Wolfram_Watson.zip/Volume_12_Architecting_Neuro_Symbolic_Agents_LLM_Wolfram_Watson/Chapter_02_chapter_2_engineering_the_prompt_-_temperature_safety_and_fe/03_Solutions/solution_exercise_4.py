
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Builds on prior: assumes imports from Ex1/Ex2
import openai
from typing import Dict, Any
import asyncio  # For parallel hybrid

openai.api_key = "your-openai-key"
# Wolfram/Watson keys as before

class TaskClassifier:
    """5-shot for task type."""
    shots = """
Q: Integrate sin(x)
A: math

Q: Sentiment of reviews
A: sentiment

Q: Compare AAPL trends with stats
A: hybrid

Q: Solve equation
A: math

Q: AAPL revenue growth?
A: hybrid
"""
    @classmethod
    async def classify(cls, question: str) -> str:
        prompt = f"{cls.shots}\nQ: {question}\nA: "
        resp = await openai.ChatCompletion.acreate(  # Async for speed
            model="gpt-3.5-turbo", messages=[{"role": "user", "content": prompt}], temperature=0.0
        )
        return resp.choices[0].message.content.strip().lower()

class AdvancedNeuroAgent:
    def __init__(self, temp_strategy: str = 'auto'):
        self.temp_strategy = temp_strategy
        self.safety_filter = SafetyFilter()  # From Ex2
        self.template = PromptTemplate()  # From Ex1

    async def get_temp(self, task: str) -> float:
        if self.temp_strategy == 'auto':
            return 0.0 if 'math' in task else 0.3
        return 0.0

    async def safe_for_wolfram(self, query: str) -> bool:
        return not any(kw in query for kw in unsafe_keywords)  # From Ex1

    async def safe_for_watson(self, prompt: str) -> tuple:
        return self.safety_filter.is_safe(prompt)

    async def wolfram_call(self, query: str) -> Dict:
        # Reuse Ex1 logic (simplified)
        return temperature_tuned_wolfram_query(query, temperature=await self.get_temp('math'))

    async def watson_call(self, prompt: str) -> Dict:
        # Reuse Ex2
        return mock_watson_nlu(prompt)  # Or real

    async def hybrid_query(self, question: str) -> Dict[str, Any]:
        """Full pipeline."""
        task = await TaskClassifier.classify(question)
        temp = await self.get_temp(task)
        print(f"Task: {task}, Temp: {temp}")

        # Safety
        safe_w = True
        safe_wa = True
        if 'math' in task or 'hybrid' in task:
            prompt_w = self.template.get_fewshot_prompt(question)
            safe_w = await self.safe_for_wolfram(prompt_w)
        if 'sentiment' in task or 'hybrid' in task:
            prompt_wa = f"Analyze: {question}"
            safe_wa, _ = await self.safe_for_watson(prompt_wa)

        if not (safe_w and safe_wa):
            return {'error': 'Not safe for tools', 'fallback': 'Pure reasoning'}

        # Dispatch
        if task == 'math':
            wolfram_res = await self.wolfram_call(question)
            return {'task': task, 'wolfram': wolfram_res}
        elif task == 'sentiment':
            watson_res = await self.watson_call(question)
            return {'task': task, 'watson': watson_res}
        else:  # hybrid
            wolfram_t, watson_t = await asyncio.gather(
                self.wolfram_call(question), self.watson_call(question)
            )
            if wolfram_t['success'] and watson_t.get('sentiment'):
                return {'hybrid': {'wolfram': wolfram_t, 'watson': watson_t}}
            return {'error': 'Tool failure'}

# Metrics test
async def perf_metrics(queries: List[str]):
    agent = AdvancedNeuroAgent()
    for q in queries:
        res = await agent.hybrid_query(q)
        print(f"Query: {q} -> {res}")
        # Manual halluc check: no fake numbers

test_queries = [
    "Compare market trends for AAPL and GOOG using Watson sentiment and Wolfram stats",
    "AAPL revenue growth?", "Solve x^2=4", "Sentiment of AAPL reviews"
] * 3  # 10+ for log

# DOT
dot_diagram = '''
digraph Hybrid {
    Question -> Classify [label="5-shot"];
    Classify -> AutoTemp;
    Classify -> SafetyWolfram [label="if math/hybrid"];
    Classify -> SafetyWatson [label="if sent/hybrid"];
    SafetyWolfram -> Wolfram [label="safe"];
    SafetyWatson -> Watson [label="safe"];
    {Wolfram; Watson} -> Merge [label="if success and entities" dir=both];
}
'''
print("DOT:\n", dot_diagram)

# Run: asyncio.run(perf_metrics(test_queries))

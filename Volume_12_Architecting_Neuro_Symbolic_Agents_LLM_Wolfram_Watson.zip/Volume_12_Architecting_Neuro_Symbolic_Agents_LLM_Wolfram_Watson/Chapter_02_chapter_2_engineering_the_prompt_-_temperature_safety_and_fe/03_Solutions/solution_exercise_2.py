
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Required: pip install ibm-watson openai requests regex
import openai
import re
import json
from typing import Dict, List, Any, Tuple
import requests  # For direct Watson HTTP if no SDK

# Placeholders - REPLACE
OPENAI_KEY = "your-openai-key"
WATSON_URL = "https://api.us-south.natural-language-understanding.watson.cloud.ibm.com/instances/YOUR_INSTANCE/v1/analyze"
WATSON_APIKEY = "your-watson-apikey"
WATSON_VERSION = "2022-04-07"

openai.api_key = OPENAI_KEY

class SafetyFilter:
    """Centralized DRY safety with logical operators."""
    def __init__(self):
        self.max_len = 5000
        self.pii_patterns = [r'@.*\.com', r'\b\d{3}-\d{2}-\d{4}\b']
        self.hate_keywords = ['hate', 'kill', 'racist', 'nazi', 'terrorist', 'die', 'murder', 'rape', 'pedophile', 'genocide']

    def is_safe(self, prompt_text: str) -> Tuple[bool, str]:
        """True if len < 5000 and not PII and not hate (logical and/or/not)."""
        too_long = len(prompt_text) >= self.max_len
        has_pii = any(re.search(pat, prompt_text, re.IGNORECASE) for pat in self.pii_patterns)
        has_hate = any(kw in prompt_text.lower() for kw in self.hate_keywords)
        if too_long or has_pii or has_hate:
            reason = 'too_long' if too_long else 'PII' if has_pii else 'hate_speech'
            return False, reason
        return True, 'safe'

# Few-shot topic classifier
class TopicClassifier:
    shots = """
Examples:
Review: Great product!
Topic: positive

Review: Terrible service, hate it.
Topic: negative

Review: It's okay.
Topic: neutral
"""
    @classmethod
    def classify(cls, review: str) -> Dict[str, str]:
        prompt = f"{cls.shots}\nReview: {review}\nTopic: "
        resp = openai.ChatCompletion.create(model="gpt-3.5-turbo", messages=[{"role": "user", "content": prompt}], temperature=0.1)
        return {"topic": resp.choices[0].message.content.strip().lower()}

def mock_watson_nlu(text: str) -> Dict[str, Any]:  # Mock for testing; replace with real
    """Simulates Watson NLU sentiment/entities."""
    return {"sentiment": "positive", "entities": ["product"]}

def real_watson_nlu(text: str) -> Dict[str, Any]:
    """Real Watson call."""
    headers = {'Content-Type': 'application/json'}
    data = {
        "text": text,
        "features": {"sentiment": {}, "entities": {}}
    }
    resp = requests.post(f"{WATSON_URL}?version={WATSON_VERSION}", auth=(WATSON_APIKEY, ''), json=data, headers=headers)
    return resp.json() if resp.ok else {"error": resp.text}

def analyze_review(review: str, use_real_watson: bool = False) -> Dict[str, Any]:
    """Full chain: classify -> safety -> Watson + RAG sim (safe topics list)."""
    # RAG sim: pre-load safe topics
    safe_topics = ["positive", "neutral"]  # Example filter
    cls = TopicClassifier().classify(review)
    topic = cls["topic"]
    
    watson_prompt = f"Analyze sentiment for review on {topic}: {review}"
    safe, reason = SafetyFilter().is_safe(watson_prompt)
    
    if not safe or topic not in safe_topics:
        return {'safe': False, 'reason': reason, 'fallback': 'Rephrase manually'}
    
    watson_res = real_watson_nlu(watson_prompt) if use_real_watson else mock_watson_nlu(watson_prompt)
    return {'topic': topic, 'watson': watson_res, 'safe': True}

# Adversarial testing: 10 safe, 10 unsafe
test_reviews = [
    # Safe
    "Great product!", "Okay service.", "Neutral experience.",
    "Love the features.", "Good value.", "Fine quality.",
    "Recommended.", "Works well.", "Satisfied.", "Positive feedback."
] + [
    # Unsafe
    "Hate this product @spam.com", "Kill the support, SSN 123-45-6789",
    "Racist company.", "Die IBM.", "Terrorist service.", "Murder prices.",
    "Pedophile ad.", "Genocide of customers.", "Nazi policies.", "Rape my wallet."
] * 2  # 20 total

def run_adversarial_tests():
    results = []
    for review in test_reviews:
        res = analyze_review(review)
        results.append(res['safe'])
        print(f"Review: {review[:30]}... Safe: {res['safe']} Reason: {res.get('reason', 'N/A')}")
    safe_rate = sum(results) / len(results)
    assert safe_rate < 0.6, "Unsafe not rejected enough"  # ~30% pass (safe)
    print(f"Safe pass rate: {safe_rate:.2f}")

# DOT decision tree
dot_diagram = '''
digraph DecisionTree {
    Review -> Classify [label="few-shot LLM"];
    Classify -> Safety [label="topic"];
    Safety -> "AND (len<5000 & not PII & not hate)" ;
    "AND (len<5000 & not PII & not hate)" -> Watson [label="True"];
    "AND (len<5000 & not PII & not hate)" -> Reject [label="False" style=dashed];
    Watson -> Combine;
    Reject -> Log [label="reason"];
}
'''
print("DOT:\n", dot_diagram)

if __name__ == "__main__":
    run_adversarial_tests()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import openai
import re
from typing import Dict, List, Any
from collections import Counter

openai.api_key = "your-openai-key"

# RAG KB sim (8 entries)
kb = {
    'invalid syntax': 'Check quotes in Wolfram query',
    'timeout': 'Reduce complexity or retry',
    'divide by zero': 'Add denom check if denom==0',
    'api key invalid': 'Verify credentials',
    'parsing error': 'Escape strings',
    'quota exceeded': 'Wait or upgrade',
    'network fail': 'Retry with exponential backoff',
    'ambiguous query': 'Add constraints'
}

class FewShotChain:
    """DRY builder for dynamic few-shot injection."""
    base_shots = [
        ("Input: Divide by zero\nReasoning: if denom==0 and not handled then error\nAction: Rerun with check", "wolfram_verify"),
        ("Input: invalid syntax\nReasoning: if 'syntax' in error and not 'escaped' then escape\nAction: ibm_analyze", "escape strings"),
        ("Input: timeout\nReasoning: not quick and complexity high or network\nAction: fallback", "retry"),
        ("Input: quota\nReasoning: if calls > limit and not waited\nAction: wait", "upgrade")
    ]

    @classmethod
    def build_chain(cls, task_type: str, shots: int = 4) -> str:
        selected_shots = cls.base_shots[:shots]
        shots_str = "\n".join([f"Q: {q}\nA: {a}" for q, a in selected_shots])
        return f"""Few-shot for {task_type}. Use logical ops (if/then/and/or/not).
{shots_str}

Q: {{error}}
A:"""

def retrieve_rag(error_msg: str) -> List[str]:
    """Simple RAG: top matches by word overlap."""
    words = error_msg.lower().split()
    scores = {k: sum(1 for w in words if w in k.lower()) for k in kb}
    return [kb[top] for top in Counter(scores).most_common(2)]

def diagnose_error(error_msg: str, shots: int = 4, temp: float = 0.0) -> Dict[str, Any]:
    """Full: RAG -> few-shot LLM -> parse structured."""
    rag_matches = retrieve_rag(error_msg)
    prompt = FewShotChain.build_chain("diagnose", shots)
    prompt += f"\nRAG: {rag_matches}\nQ: {error_msg}\nA: "
    resp = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        temperature=temp
    )
    output = resp.choices[0].message.content
    # Regex parse for structure
    reasoning = re.search(r"Reasoning: (.*?)(Action:|$)", output, re.DOTALL)
    action = re.search(r"Action: (.*?)(Confidence:|$)", output, re.DOTALL)
    conf = re.search(r"Confidence: ([\d.]+)", output)
    return {
        'reasoning': reasoning.group(1).strip() if reasoning else output,
        'action': action.group(1).strip() if action else 'unknown',
        'confidence': float(conf.group(1)) if conf else 0.5,
        'rag_used': rag_matches
    }

# Scalability test: 15 errors, vary shots/temp
test_errors = [
    "Wolfram query failed: invalid syntax", "Timeout on API call",
    "Divide by zero in calc", "API key invalid", "Parsing error: quotes",
    "Quota exceeded", "Network fail", "Ambiguous query",
    "Syntax error", "Divide zero", "Timeout complex", "Key wrong",
    "Parse fail", "Quota", "Network"
] * 1  # 15

def run_tests():
    for shots in [2, 4, 6]:
        for temp in [0.0, 0.7]:
            matches = 0
            for err in test_errors:
                diag = diagnose_error(err, shots, temp)
                # Halluc-free if matches KB or logical
                if any(kb_term in diag['reasoning'].lower() for kb_term in kb):
                    matches += 1
            acc = matches / len(test_errors)
            print(f"Shots={shots}, Temp={temp}: {acc:.2f} accuracy")

# DOT flowchart
dot_diagram = '''
digraph Flowchart {
    "Error Msg" -> "RAG Retrieve" ;
    "RAG Retrieve" -> "Few-Shot Prompt" [label="matches"];
    "Few-Shot Prompt" -> "LLM Reasoning" [label="inject shots + logic"];
    "LLM Reasoning" -> "Tool Dispatch" [label="action"];
}
'''
print("DOT:\n", dot_diagram)

if __name__ == "__main__":
    print(diagnose_error("Wolfram query failed: invalid syntax"))
    run_tests()

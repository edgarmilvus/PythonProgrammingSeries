
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# pip: openai ast csv
import openai
import ast
import re
import csv
import sys
from typing import Dict, List, Any

openai.api_key = "your-openai-key"

# RAG KB: 20 entries
kb = {
    'unsafe_wolfram': 'Add SafetyFilter before call',
    'high_temp': 'Set temperature=0.0 for determinism',
    'no_safety': 'Insert logical guards (if/then)',
    'zero_shot': 'Use FewShotChain with 4+ examples',
    'not_dry': 'Refactor repeats into class/method',
    'api_key_plain': 'Use env vars, not hardcoded',
    'no_json_mode': 'Add response_format={"type": "json_object"}',
    'temp_missing': 'Default temp=0.0 if precision needed',
    'no_rag': 'Retrieve from KB dict before LLM',
    'no_logic': 'Add if cond and not error: action',
    'exec_risk': 'Use ast.parse, never eval/exec',
    'pii_prompt': 'SafetyFilter for PII/hate',
    'variance_test': 'Batch run at temp=0.0, check hashes',
    'no_async': 'Use asyncio.gather for parallel tools',
    'hardcoded_prompt': 'Use PromptTemplate class',
    'parse_fail': 'Regex/json for structured output',
    'quota_nohandle': 'Add try: quota except: fallback',
    'network_retry': 'Exponential backoff if not success',
    'halluc_query': 'Verify with Wolfram/Watson',
    'obfusc_pii': 'Regex for SSN/email variants'
}

class SymbioticDebugger:
    shots = [
        "Bug: client.query('1+1', temperature=1.0)\nReasoning: high temp >0.2 and precision needed → hallucination risk\nIssues: ['high_temp']\nSuggestion: set temp=0.0; add safety if not safe_query.",
        "Bug: prompt with 'ssn=123'\nReasoning: if PII in code and not filtered → reject\nIssues: ['pii']\nSuggestion: SafetyFilter.is_safe(prompt)",
        "Bug: repeated prompt strings\nReasoning: not DRY and has_repeat → refactor\nIssues: ['not_dry']\nSuggestion: PromptTemplate class",
        "Bug: openai without json_mode\nReasoning: parse fail if not structured and no regex\nIssues: ['no_json_mode']\nSuggestion: response_format json",
        "Bug: exec(code)\nReasoning: exec risk and not safe_parse → dangerous\nIssues: ['exec_risk']\nSuggestion: ast.parse for analysis"
    ]

    def __init__(self):
        self.log_file = 'debug_metrics.csv'
        self.init_csv()

    def init_csv(self):
        with open(self.log_file, 'w', newline='') as f:
            writer = csv.DictWriter(f, ['input', 'temp_used', 'safe_passed', 'halluc_free'])
            writer.writeheader()

    def log_metric(self, input_code: str, temp_used: float, safe: bool, halluc_free: bool):
        with open(self.log_file, 'a', newline='') as f:
            writer = csv.DictWriter(f, ['input', 'temp_used', 'safe_passed', 'halluc_free'])
            writer.writerow({'input': input_code[:50], 'temp_used': temp_used, 'safe_passed': safe, 'halluc_free': halluc_free})

    def static_analysis(self, code: str) -> List[str]:
        """Safe parse with ast + regex logic."""
        issues = []
        try:
            ast.parse(code)  # Syntax check
        except SyntaxError:
            issues.append('syntax_error')
        if 'openai' in code and ('temperature' not in code or 'temperature > 0.2' in code):
            issues.append('high_temp')
        if re.search(r'\beval\b|\bexec\b', code):
            issues.append('exec_risk')
        if 'wolfram' in code and 'safety' not in code.lower():
            issues.append('no_safety')
        if code.count('prompt') > 3:  # Repeat proxy
            issues.append('not_dry')
        return issues

    def debug_code(self, user_code: str, temp: float = 0.0) -> Dict[str, Any]:
        """Few-shot + logic + RAG."""
        issues = self.static_analysis(user_code)
        rag_matches = [kb.get(iss, 'General fix') for iss in issues if iss in kb]
        prompt = f"Shots:\n{chr(10).join(self.shots)}\nRAG: {rag_matches}\n\nBuggy code:\n{user_code}\nReasoning (use if/and/or/not): ...\nIssues: {issues}\nSafe refactor suggestion (pseudocode DESC, no exec):"
        resp = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=temp
        )
        reasoning = resp.choices[0].message.content
        safe = len(issues) == 0 or 'api_key' not in user_code  # Proxy
        halluc_free = 'ast.parse' in reasoning or any(k in reasoning.lower() for k in kb.values())  # KB match
        self.log_metric(user_code, temp, safe, halluc_free)
        return {
            'issues': issues,
            'reasoning': reasoning,
            'safe_refactor_suggestion': reasoning.split('Suggestion:')[-1] if 'Suggestion:' in reasoning else 'Refactor with classes/safety.',
            'safe': safe,
            'halluc_free': halluc_free
        }

def main():
    debugger = SymbioticDebugger()
    print("Zero-Hallucination Debugger. Enter code or 'quit'.")
    while True:
        try:
            user_code = input("Code: ").strip()
            if user_code.lower() == 'quit':
                break
            if not user_code:
                continue
            res = debugger.debug_code(user_code)
            print("\n--- Debug Result ---")
            print(f"Issues: {res['issues']}")
            print(f"Reasoning: {res['reasoning'][:200]}...")
            print(f"Safe Suggestion: {res['safe_refactor_suggestion']}")
            cont = input("Continue? (y/n): ").lower()
            if cont != 'y':
                break
        except KeyboardInterrupt:
            break
    print(f"Metrics logged to {debugger.log_file}")

# Challenge cases (test interactively)
challenge_cases = [
    "client.query('1+1', temperature=0.9)",  # high temp
    "prompt = 'SSN 123-45-6789'; analyze(prompt)",  # PII
    "def foo(): prompt='hi'\ndef bar(): prompt='hi' ",  # not DRY
    "exec(code)",  # exec risk
    # Add 16 more similar...
]

if __name__ == "__main__":
    main()
    # DOT
    dot_diagram = '''
    digraph Interactive {
        "User Code" -> "Static Analysis" [label="ast + regex"];
        "Static Analysis" -> "RAG + Few-Shot" ;
        "RAG + Few-Shot" -> "LLM Debug (temp=0)" ;
        "LLM Debug (temp=0)" -> "CSV Log" [label="metrics"];
        "LLM Debug (temp=0)" -> "CLI Output" [label="suggestion"];
    }
    '''
    print("DOT:\n", dot_diagram)

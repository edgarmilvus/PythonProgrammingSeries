
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# Advanced Neuro-Symbolic Investment Agent
# Integrates OpenAI LLM (prompt engineering), Wolfram Alpha (computation), IBM Watson NLU (sentiment/entities),
# with RAG, safety guardrails, temperature control, and few-shot logic for hallucination-free analysis.
# Real-world use: Parse "Compare AAPL vs TSLA returns over 5 years", compute facts, synthesize grounded advice.

import os
import json
import openai
from wolframalpha import Client
from ibm_watson import NaturalLanguageUnderstandingV1
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
from openai import OpenAI  # For newer client API

# API Key setup (use environment variables for security)
openai.api_key = os.getenv('OPENAI_API_KEY')
wolfram_client = Client(os.getenv('WOLFRAM_APPID'))
authenticator = IAMAuthenticator(os.getenv('IBM_APIKEY'))
nlu = NaturalLanguageUnderstandingV1(
    version='2022-04-07',
    authenticator=authenticator
)
nlu.set_service_url(os.getenv('IBM_SERVICE_URL'))

# Simple RAG knowledge base: Dict of ticker facts for retrieval-augmented generation
RAG_KB = {
    "AAPL": "Apple Inc. (AAPL): Leader in consumer electronics, iPhone revenue ~50% of total, market cap ~$3T, P/E ratio ~30.",
    "TSLA": "Tesla Inc. (TSLA): EV pioneer, Cybertruck production ramping, market cap ~$600B, volatile due to regulatory risks.",
    "MSFT": "Microsoft Corp. (MSFT): Cloud/AI dominance via Azure/OpenAI, market cap ~$3.1T, dividend yield 0.7%."
}

# Few-shot examples for query parsing (instills logical structure extraction)
FEW_SHOT_PARSE = [
    {
        "query": "Should I buy AAPL or TSLA for 5 years with $10k?",
        "structured": json.dumps({
            "tickers": ["AAPL", "TSLA"],
            "horizon_years": 5,
            "amount": 10000,
            "action": "compare_returns"
        })
    },
    {
        "query": "Historical performance of MSFT over 3 years?",
        "structured": json.dumps({
            "tickers": ["MSFT"],
            "horizon_years": 3,
            "amount": None,
            "action": "analyze_returns"
        })
    }
]

# Safety guardrails: Use logical operators, list comp to filter risky phrases pre-tool calls
RISKY_PHRASES = ["guaranteed return", "get rich quick", "double your money", "no risk"]
def safety_check(query: str) -> bool:
    """
    Chapter 2 Safety: Logical check (any risky AND not educational) -> reject.
    List comp filters safe queries; prevents hallucinated advice.
    """
    lower_query = query.lower()
    risky_matches = [phrase for phrase in RISKY_PHRASES if phrase in lower_query]
    # Logical: Reject if ANY risky AND NOT containing educational terms
    is_educational = any(term in lower_query for term in ["historical", "compare", "analyze"])
    return not (risky_matches and not is_educational)

# OpenAI Moderation for additional content filter (zero hallucination safety net)
def openai_moderation_check(query: str) -> bool:
    client = OpenAI()
    response = client.moderations.create(input=query)
    flagged = response.results[0].flagged
    return not flagged

# LLM Query Parser: Few-shot + temp=0.0 for deterministic JSON extraction
def parse_query_llm(query: str, temperature: float = 0.0) -> dict:
    """
    Chapter 2 Prompt Eng: Few-shot chain at temp=0.0 ensures precision, no creativity/hallucinations.
    Outputs structured dict for tool calls.
    """
    examples_str = "\n".join([f"Q: {ex['query']}\nA: {ex['structured']}" for ex in FEW_SHOT_PARSE])
    prompt = f"""Parse investment queries into JSON. Use exactly these examples for logic.

{examples_str}

Q: {query}
A:"""
    client = OpenAI()
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=temperature,  # 0.0 for determinism
        max_tokens=200
    )
    try:
        parsed = json.loads(response.choices[0].message.content.strip())
        return parsed
    except json.JSONDecodeError:
        return {"error": "Parse failed"}

# RAG Retrieval: List comp for relevant facts (grounding, reduces parametric hallucinations)
def retrieve_rag_facts(tickers: list) -> list:
    """
    Simple vector-free RAG: List comp filters KB by ticker keywords.
    """
    facts = []
    keywords = ["aapl", "apple", "tsla", "tesla", "msft", "microsoft"]
    ticker_map = {kw: k for k in RAG_KB for kw in [k.lower(), k[:4].lower()]}
    for ticker in tickers:
        matching_keys = [k for k, v in RAG_KB.items() if ticker.lower() in k.lower()]
        facts.extend([RAG_KB[k] for k in matching_keys])
    return list(set(facts))  # Dedupe

# Wolfram Alpha: Symbolic computation for returns (exact math, no LLM math errors)
def wolfram_returns(tickers: list, years: int) -> str:
    """
    Chapter 2 Tool Integration: Temp=0.0 upstream ensures clean inputs; Wolfram grounds computations.
    """
    results = []
    for ticker in tickers:
        query_str = f"historical average annual return of {ticker} stock last {years} years"
        res = wolfram_client.query(query_str)
        # Extract primary result (simplified parsing)
        if res.results:
            result = next(res.results).text
            results.append(f"{ticker}: {result}")
        else:
            results.append(f"{ticker}: Data unavailable")
    return "; ".join(results)

# IBM Watson NLU: Sentiment & entities on market context (external knowledge)
def watson_sentiment_analysis(tickers: list, mock_news: str = "Tesla beats earnings; Apple launches AI features.") -> dict:
    """
    Safety pre-call: Assumes grounded mock_news; extracts sentiment/entities.
    """
    text = f"{mock_news} Tickers: {', '.join(tickers)}"
    response = nlu.analyze(
        text=text,
        features={
            'sentiment': {},
            'entities': {'emotion': True, 'sentiment': True}
        }
    ).get_result()
    return response

# Few-shot Logic Synthesizer: Chains tools into final reasoning (scalable determinism)
FEW_SHOT_LOGIC = [
    {
        "inputs": {"returns": "AAPL: 15%; TSLA: 60%", "facts": "AAPL stable", "sentiment": "positive"},
        "logic": "Compare volatility: TSLA high returns but risky per facts/sentiment. Recommend diversify for 5y."
    }
]
def synthesize_response(parsed: dict, rag_facts: list, wolfram_res: str, watson_res: dict, temperature: float = 0.1) -> str:
    """
    Chapter 2 Few-Shot Chains: Low temp balances logic/creativity; tools prevent hallucinations.
    """
    examples_str = "\n".join([f"Inputs: {json.dumps(ex['inputs'])}\nLogic: {ex['logic']}" for ex in FEW_SHOT_LOGIC])
    prompt = f"""Synthesize grounded investment analysis. Use facts/tools only, no predictions.

{examples_str}

Inputs: returns="{wolfram_res}", facts={json.dumps(rag_facts)}, sentiment={json.dumps(watson_res)}, parsed={json.dumps(parsed)}
Logic:"""
    client = OpenAI()
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=temperature,  # Slight increase for coherent reasoning
        max_tokens=500
    )
    return response.choices[0].message.content.strip()

# Main Agent Orchestrator: Full symbiotic pipeline
def neuro_investment_agent(query: str) -> str:
    """
    End-to-end: Safety first, then parse/tools/synthesize. Near-zero hallucination via symbiosis.
    """
    # Step 1: Multi-layer safety (logical AND content filter)
    if not safety_check(query) or not openai_moderation_check(query):
        return "Query flagged for safety: Avoid hype phrases. Ask for historical analysis only."
    
    # Step 2: Parse with few-shot low-temp
    parsed = parse_query_llm(query)
    if "error" in parsed:
        return "Failed to parse query."
    
    tickers = parsed.get("tickers", [])
    years = parsed.get("horizon_years", 5)
    
    # Step 3: RAG retrieve
    rag_facts = retrieve_rag_facts(tickers)
    
    # Step 4: Tool calls (Wolfram compute)
    wolfram_res = wolfram_returns(tickers, years)
    
    # Step 5: Watson analysis
    watson_res = watson_sentiment_analysis(tickers)
    
    # Step 6: Few-shot synthesize
    final_response = synthesize_response(parsed, rag_facts, wolfram_res, watson_res)
    
    return f"Grounded Analysis:\n{final_response}\nSources: Wolfram={wolfram_res}\nRAG={rag_facts}\nWatson={json.dumps(watson_res, indent=2)}"

# Demo Usage
if __name__ == "__main__":
    query = "Compare AAPL vs TSLA returns over 5 years with $10k?"  # Relatable example
    print(neuro_investment_agent(query))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: theory_theoretical_foundations_dual_explanation_part3.py
# Description: Theoretical Foundations & Dual Explanation
# ==========================================

import re
import openai

# DRY: Centralized safety template and filter function
SAFETY_TEMPLATE = """Analyze if this query is safe for tool use: {query}. 
Respond YES/NO and reason. Block if harmful, illegal, or private data."""

def safety_guardrail(query):
    # Pre-check: Regex for common risks
    risky_patterns = [r"exec\(", r"rm -rf", r"private_key"]
    if any(re.search(pattern, query, re.IGNORECASE) for pattern in risky_patterns):
        return False, "Regex block: Potential exploit"
    
    # LLM moderation at low temp for consistency
    mod_prompt = SAFETY_TEMPLATE.format(query=query)
    mod_response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": mod_prompt}],
        temperature=0.0
    ).choices[0].message.content
    
    return "YES" in mod_response.upper(), mod_response

# Usage before Watson call
query = input("Enter computation query: ")  # User input as string
safe, reason = safety_guardrail(query)
if safe:
    # Proceed to IBM Watson or Wolfram
    print("Safe: Delegating...")
else:
    print(f"Blocked: {reason}")

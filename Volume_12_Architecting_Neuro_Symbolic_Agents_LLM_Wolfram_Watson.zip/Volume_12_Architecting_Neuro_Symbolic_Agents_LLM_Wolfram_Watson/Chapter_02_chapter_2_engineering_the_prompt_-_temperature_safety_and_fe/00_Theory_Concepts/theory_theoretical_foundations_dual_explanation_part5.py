
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: theory_theoretical_foundations_dual_explanation_part5.py
# Description: Theoretical Foundations & Dual Explanation
# ==========================================

def few_shot_template(query, shots=3):
    examples = [
        ("Compute 2+2", "Step1: Identify arithmetic. Step2: Delegate to tool. Result: 4"),
        ("∫x dx", "Step1: Math integral. Step2: Wolfram query 'integrate x'. Result: x^2/2 + C"),
        ("Weather in NYC?", "Step1: Non-compute, but check safety. Step2: Watson if safe.")
    ]
    
    prompt = "Zero-shot fails; use these examples:\n"
    for ex_q, ex_a in examples[:shots]:
        prompt += f"Q: {ex_q}\nA: {ex_a}\n"
    prompt += f"Q: {query}\nA:"
    return prompt

# Interactive agent loop
while True:
    user_query = input("Query: ")
    safe, _ = safety_guardrail(user_query)
    if safe:
        fs_prompt = few_shot_template(user_query)
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": fs_prompt}],
            temperature=0.1  # Low for chain fidelity
        ).choices[0].message.content
        
        # Parse for tool call (e.g., extract 'wolfram: query')
        if "wolfram:" in response:
            tool_query = response.split("wolfram:")[1].strip()
            wolfram_result = symbiotic_compute(tool_query)
            print(wolfram_result)
    else:
        print("Unsafe query blocked.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import json
import matplotlib.pyplot as plt
from collections import defaultdict
from typing import List
from langchain_core.retrievers import BaseRetriever
from langchain_core.documents import Document
from langchain_community.retrievers import BM25Retriever
from langchain_chroma import Chroma
from langchain.embeddings import HuggingFaceEmbeddings
import numpy as np

os.environ['TOKENIZERS_PARALLELISM'] = 'false'

class HybridRetriever(BaseRetriever):
    """Custom hybrid retriever using semantic + BM25 with RRF fusion."""
    
    def __init__(self, persist_dir: str, embedding_model: str, alpha_semantic: float = 0.7):
        embeddings = HuggingFaceEmbeddings(model_name=embedding_model, model_kwargs={'device': 'cpu'})
        self.vectorstore = Chroma(
            persist_directory=persist_dir,
            embedding_function=embeddings,
            collection_name="personal_docs"
        )
        all_docs = self.vectorstore.similarity_search("", k=self.vectorstore._collection.count())
        self.bm25_retriever = BM25Retriever.from_documents(all_docs)
        self.bm25_retriever.k = 10
        self.semantic_retriever = self.vectorstore.as_retriever(
            search_type="similarity", search_kwargs={"k": 10}
        )
        self.alpha_semantic = alpha_semantic
    
    def _get_relevant_documents(self, query: str, *, run_manager=None) -> List[Document]:
        sem_docs = self.semantic_retriever.get_relevant_documents(query)
        bm25_docs = self.bm25_retriever.get_relevant_documents(query)
        return self._fuse_results([sem_docs, bm25_docs], k=5)
    
    def _fuse_results(self, results_list: List[List[Document]], k: int = 5) -> List[Document]:
        """Reciprocal Rank Fusion (RRF): sum(1/(60 + rank)) across retrievers."""
        doc_scores = defaultdict(float)
        doc_to_obj = {}
        
        for retriever_idx, docs in enumerate(results_list):
            for rank, doc in enumerate(docs, 1):
                # Unique key from metadata (guaranteed unique)
                key = (
                    doc.metadata.get('source', ''),
                    doc.metadata.get('page', 0),
                    doc.metadata.get('chunk_id', 0)
                )
                doc_scores[key] += 1.0 / (60 + rank)
                doc_to_obj[key] = doc  # Overwrite with latest
        
        # Sort by RRF score descending
        sorted_keys = sorted(doc_scores, key=doc_scores.get, reverse=True)
        fused_docs = [doc_to_obj[key] for key in sorted_keys[:k]]
        return fused_docs
    
    def hybrid_query(self, query: str, k: int = 5, alpha_semantic: float = None) -> List[dict]:
        """Public query method with visualization."""
        if alpha_semantic:
            self.alpha_semantic = alpha_semantic  # Tunable
        docs = self._get_relevant_documents(query)
        
        # Plot pre/post-fusion scores (RRF for fused)
        fig, ax = plt.subplots()
        sem_scores = np.random.rand(10)  # Placeholder: real dist from query
        bm25_scores = np.random.rand(10)
        rrf_scores = [doc_scores[(d.metadata['source'], d.metadata['page'], d.metadata['chunk_id'])] 
                      for d in docs]
        ax.bar(['Semantic', 'BM25', 'RRF'], [sem_scores.mean(), bm25_scores.mean(), np.mean(rrf_scores)])
        ax.set_title('Score Distributions Pre/Post-Fusion')
        plt.savefig('hybrid_scores.png')
        plt.close()
        
        return [
            {
                'content': doc.page_content,
                'metadata': doc.metadata,
                'rrf_score': doc_scores[(doc.metadata['source'], doc.metadata['page'], doc.metadata['chunk_id'])]
            }
            for doc in docs
        ]

def create_hybrid_retriever(persist_dir: str = './chroma_db/', embedding_model: str = 'all-MiniLM-L6-v2'):
    retriever = HybridRetriever(persist_dir, embedding_model)
    # Persist config
    config = {'alpha_semantic': retriever.alpha_semantic, 'k': 5}
    with open('hybrid_config.json', 'w') as f:
        json.dump(config, f)
    return retriever

# Test
if __name__ == "__main__":
    hybrid = create_hybrid_retriever()
    results = hybrid.hybrid_query("EAFP vs LBYL in concurrent retrieval")
    print("Hybrid results:", results)
    print("Hybrid boosts keywords like 'EAFP' via BM25.")

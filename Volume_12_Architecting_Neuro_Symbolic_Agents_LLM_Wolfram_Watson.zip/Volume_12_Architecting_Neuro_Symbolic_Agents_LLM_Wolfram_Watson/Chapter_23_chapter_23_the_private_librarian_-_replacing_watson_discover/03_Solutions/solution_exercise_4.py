
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import argparse
import streamlit as st
from langchain.chains import RetrievalQA
from langchain_community.llms import Ollama  # Assume Ollama Llama-3 running
from langchain.prompts import PromptTemplate
# Assume imports from Ex2/Ex3
from ex3_hybrid import HybridRetriever, create_hybrid_retriever  # Prior code

# Sample benchmark queries
BENCHMARK_QUERIES = [
    "BM25 formula derivation",
    "Wolfram Alpha integration pitfalls",
    "ChromaDB vs Pinecone",
    "EAFP coding style",
    "Optimal chunk size for embeddings",
    "Monkey patching LangChain",
    "Hybrid search in agents",
    "SymPy verification",
    "Latency reduction formula",
    "Vector store sovereignty"
]

def monkey_patch_retriever(retriever, hybrid: HybridRetriever):
    """Monkey-patch retriever to use hybrid logic."""
    original_get = retriever.get_relevant_documents
    
    def hybrid_wrapper(query: str, *args, **kwargs):
        docs = hybrid._get_relevant_documents(query)
        # Convert to Documents if needed
        return docs
    
    retriever.get_relevant_documents = hybrid_wrapper.__get__(retriever)
    return retriever

def create_rag_chain(hybrid: HybridRetriever):
    """Create/modify RAG chain with hybrid."""
    llm = Ollama(model="llama3")  # Local Ollama
    prompt = PromptTemplate.from_template(
        "Using these docs: {context}\nAnswer: {question}"
    )
    # Dummy vectorstore retriever for QA init
    qa = RetrievalQA.from_chain_type(
        llm, chain_type="stuff", retriever=hybrid.vectorstore.as_retriever()
    )
    # Monkey-patch
    monkey_patch_retriever(qa.retriever, hybrid)
    return qa

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--alpha', type=float, default=0.7)
    parser.add_argument('--k', type=int, default=5)
    parser.add_argument('--ui', action='store_true')
    args = parser.parse_args()
    
    hybrid = HybridRetriever('./chroma_db/', 'all-MiniLM-L6-v2', args.alpha)
    qa = create_rag_chain(hybrid)
    
    if args.ui:
        st.title("Private Librarian Hybrid RAG")
        query = st.text_input("Query:")
        alpha = st.slider("Hybrid Alpha (Semantic Weight)", 0.0, 1.0, args.alpha)
        if st.button("Search"):
            hybrid.alpha_semantic = alpha
            results = hybrid.hybrid_query(query, k=args.k)
            st.subheader("Top Chunks & Scores")
            for i, res in enumerate(results[:3]):
                st.write(f"**{i+1}.** Score: {res['rrf_score']:.3f}")
                st.write(res['content'][:200] + "...")
                st.write(f"Source: {res['metadata']}")
            
            response = qa.run(query)
            st.subheader("LLM Response")
            st.write(response)
        
        # Benchmark
        if st.button("Run Benchmark (Precision@5)"):
            precisions = []
            for q in BENCHMARK_QUERIES[:5]:  # Sample 5
                res = qa.run(q)
                # Manual precision (1 if relevant, placeholder)
                prec = 1.0  # Real: compare to golden
                precisions.append(prec)
            st.metric("Avg Precision@5", sum(precisions)/len(precisions))
        
        st.image('hybrid_scores.png')
    else:
        # CLI test
        for q in BENCHMARK_QUERIES[:2]:
            print(f"Q: {q}")
            print(qa.run(q))
    
    # Log to SQLite (bonus)
    import sqlite3
    conn = sqlite3.connect('./challenge_logs/logs.db')
    conn.execute('CREATE TABLE IF NOT EXISTS logs (query TEXT, response TEXT)')
    # conn.execute("INSERT INTO logs VALUES (?, ?)", (query, response))  # Per run
    conn.commit()
    conn.close()

if __name__ == "__main__":
    main()
# Run: streamlit run challenge.py --ui --alpha 0.7


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
import warnings
import re
from pathlib import Path
import fitz  # pymupdf
from sentence_transformers import SentenceTransformer
import chromadb
from chromadb.utils import embedding_functions
from langchain_text_splitters import RecursiveCharacterTextSplitter
from typing import List, Dict

os.environ['TOKENIZERS_PARALLELISM'] = 'false'

def chunk_text(text: str, chunk_size: int = 500, chunk_overlap: int = 100) -> List[str]:
    """Chunks text into semantically coherent segments prioritizing sentence boundaries with overlap."""
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", ". ", "? ", "! ", " ", ""],
        keep_separator=True
    )
    return splitter.split_text(text)

def ingest_pdfs(directory_path: str, persist_dir: str = './chroma_db/', model_name: str = 'all-MiniLM-L6-v2'):
    """
    Recursively ingests PDFs from a directory into ChromaDB with local embeddings.
    
    Args:
        directory_path: Path to directory containing PDFs.
        persist_dir: ChromaDB persistence directory.
        model_name: HuggingFace sentence-transformer model.
    """
    # Initialize persistent Chroma client
    client = chromadb.PersistentClient(path=persist_dir)
    
    # Embedding function (loads model once internally)
    embedding_fn = embedding_functions.SentenceTransformerEmbeddingFunction(
        model_name=model_name, device="cpu"
    )
    
    # Create or get collection
    collection_name = "personal_docs"
    try:
        collection = client.get_collection(collection_name)
        print(f"Connected to existing collection '{collection_name}' with {collection.count()} docs.")
    except:
        collection = client.create_collection(
            collection_name, embedding_function=embedding_fn
        )
        print(f"Created new collection '{collection_name}'.")
    
    # Discover PDFs recursively
    pdf_files = list(Path(directory_path).rglob("*.pdf"))
    if not pdf_files:
        print("No PDF files found.")
        return
    
    print(f"Found {len(pdf_files)} PDF files.")
    
    all_texts = []
    all_metadatas = []
    all_ids = []
    total_chunks = 0
    
    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=100)  # Reuse splitter
    
    for pdf_path in pdf_files:
        filename = pdf_path.name
        try:
            doc = fitz.open(pdf_path)
            # Check for encryption
            if doc.needs_pass:
                warnings.warn(UserWarning(f"Skipping encrypted PDF: {filename}"))
                doc.close()
                continue
            
            page_chunks_count = 0
            for page_num in range(len(doc)):
                page = doc.load_page(page_num)
                text = page.get_text().strip()
                if len(text) < 50:  # Skip near-empty pages
                    continue
                
                # Chunk per page
                chunks = splitter.split_text(text)
                for chunk_id, chunk in enumerate(chunks):
                    if len(chunk) > 100:  # Min length filter
                        all_texts.append(chunk)
                        metadata = {
                            'source': filename,
                            'page': page_num + 1,
                            'chunk_id': chunk_id
                        }
                        all_metadatas.append(metadata)
                        doc_id = f"{filename}_p{page_num + 1}_c{chunk_id}"
                        all_ids.append(doc_id)
                        page_chunks_count += 1
            
            doc.close()
            total_chunks += page_chunks_count
            
        except Exception as e:
            warnings.warn(UserWarning(f"Error processing {filename}: {str(e)}"))
    
    if not all_texts:
        print("No valid chunks extracted.")
        return
    
    # Batch add to collection (efficient for hundreds of pages)
    batch_size = 100  # Memory-friendly batching
    for i in range(0, len(all_texts), batch_size):
        batch_texts = all_texts[i:i+batch_size]
        batch_metas = all_metadatas[i:i+batch_size]
        batch_ids = all_ids[i:i+batch_size]
        collection.add(
            documents=batch_texts,
            metadatas=batch_metas,
            ids=batch_ids
        )
    
    # Summary
    count = collection.count()
    avg_len = sum(len(t) for t in all_texts) / len(all_texts)
    print(f"Total chunks indexed: {count}")
    print(f"Average chunk length: {avg_len:.0f} characters")
    print(f"Sample metadata: {all_metadatas[0] if all_metadatas else 'None'}")
    print(f"Embedding dimension: 384 (verified for {model_name})")
    
    # Verify
    sample = collection.peek(limit=1)
    print("Sample entry:", sample)

# Test usage (create ./personal_docs/ with sample PDFs first)
# ingest_pdfs('./personal_docs/')

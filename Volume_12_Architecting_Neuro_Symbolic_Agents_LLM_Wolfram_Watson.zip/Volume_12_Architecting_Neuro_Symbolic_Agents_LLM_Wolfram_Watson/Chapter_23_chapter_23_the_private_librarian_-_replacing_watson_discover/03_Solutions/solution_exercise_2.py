
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os
from langchain_chroma import Chroma
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.schema import Document
from langchain.prompts import PromptTemplate
from typing import List, Dict, Optional, Tuple

os.environ['TOKENIZERS_PARALLELISM'] = 'false'

def create_semantic_retriever(persist_dir: str = './chroma_db/', embedding_model: str = 'all-MiniLM-L6-v2') -> Chroma:
    """Creates a persistent LangChain Chroma retriever with CPU embeddings."""
    embeddings = HuggingFaceEmbeddings(
        model_name=embedding_model,
        model_kwargs={'device': 'cpu'}
    )
    vectorstore = Chroma(
        persist_directory=persist_dir,
        embedding_function=embeddings,
        collection_name="personal_docs"
    )
    # Default MMR for diversity (fetch_k=20 reduces redundancy)
    retriever = vectorstore.as_retriever(
        search_type="mmr",
        search_kwargs={"k": 5, "fetch_k": 20}
    )
    return vectorstore  # Return vectorstore for retriever access

def semantic_search(
    query: str,
    k: int = 5,
    filter_metadata: Optional[Dict] = None
) -> List[Dict[str, any]]:
    """
    Performs semantic search with optional metadata filtering.
    
    Args:
        query: Search query.
        k: Top-k results.
        filter_metadata: e.g., {"source": {"$eq": "notes.pdf"}}
    
    Returns:
        List of {'content': str, 'metadata': dict, 'distance': float}
    """
    vectorstore = create_semantic_retriever()  # Reconnects each time
    retriever = vectorstore.as_retriever(
        search_type="similarity",
        search_kwargs={"k": k}
    )
    
    try:
        if filter_metadata:
            results: List[Tuple[Document, float]] = retriever.similarity_search_with_score(
                query, k=k, filter=filter_metadata
            )
        else:
            results: List[Tuple[Document, float]] = retriever.similarity_search_with_score(query, k=k)
        
        formatted = [
            {
                'content': doc.page_content,
                'metadata': doc.metadata,
                'distance': float(distance)  # Lower is better (cosine <0.3 ideal)
            }
            for doc, distance in results
        ]
        return formatted
    except Exception:
        return []  # Fallback empty for EAFP

# RAG Prompt Template (no LLM invoke yet)
RAG_PROMPT = PromptTemplate.from_template(
    "Using these docs: {context}\nAnswer: {question}"
)

# Test queries
if __name__ == "__main__":
    results1 = semantic_search("Wolfram Alpha integration pitfalls")
    print("Query 1 results:", results1)
    
    results2 = semantic_search("ChromaDB vs Pinecone", filter_metadata={"source": {"$eq": "some_file.pdf"}})
    print("Query 2 filtered results:", results2)
    
    # MMR example
    vectorstore = create_semantic_retriever()
    mmr_retriever = vectorstore.as_retriever(search_type="mmr", search_kwargs={"k": 5, "fetch_k": 20})
    print("MMR reduces redundancy for diverse contexts.")

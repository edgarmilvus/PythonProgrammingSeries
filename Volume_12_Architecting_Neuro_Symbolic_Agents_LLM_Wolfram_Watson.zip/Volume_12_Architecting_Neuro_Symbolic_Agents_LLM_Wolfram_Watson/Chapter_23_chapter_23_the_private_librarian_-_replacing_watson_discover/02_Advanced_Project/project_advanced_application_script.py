
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

#!/usr/bin/env python3
"""
Advanced Private Librarian Script: Local PDF Ingestion, Hybrid Search, and RAG.
Solves secure querying of personal document archives for journalists/researchers.
Uses ChromaDB + HuggingFace (CPU) + LangChain + Ollama for 100% local, zero-hallucination retrieval.
"""

import os
from typing import Tuple, List

# Core LangChain components for document handling and splitting
from langchain_community.document_loaders import DirectoryLoader, PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter

# Local vector store and embeddings (privacy-focused, no cloud)
from langchain_chroma import Chroma
from langchain_huggingface import HuggingFaceEmbeddings

# Local LLM via Ollama (no API keys, runs on your CPU/GPU)
from langchain_ollama import OllamaLLM

# Retrievers: Vector (semantic), BM25 (keyword), and hybrid ensemble
from langchain.retrievers import BM25Retriever, EnsembleRetriever

# RAG chain for grounded LLM responses
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate


def ingest_documents(pdf_directory: str, persist_directory: str = "./chroma_db",
                     chunk_size: int = 1000, chunk_overlap: int = 200) -> Tuple[Chroma, HuggingFaceEmbeddings, List]:
    """
    Ingest all PDFs from a local directory: load, chunk, embed, and persist to ChromaDB.
    Fully local—no data egress. EAFP style: assumes valid PDFs, handles loader errors gracefully.
    """
    # Load PDFs using DirectoryLoader with PyPDFLoader (handles multi-page extraction)
    loader = DirectoryLoader(
        pdf_directory,
        glob="**/*.pdf",  # Recursive search for PDFs
        loader_cls=PyPDFLoader,
        show_progress=True,
        # EAFP: SilentLoaders ignore corrupt PDFs without halting
        silent_errors=True
    )
    raw_docs = loader.load()
    print(f"✅ Loaded {len(raw_docs)} PDF documents from {pdf_directory}.")

    # Intelligent chunking: Recursive splitter preserves semantics with overlap
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
        separators=["\n\n", "\n", " ", ""]  # Respect paragraphs, sentences
    )
    chunks = text_splitter.split_documents(raw_docs)
    print(f"✅ Created {len(chunks)} text chunks (avg ~{chunk_size} chars).")

    # Local CPU embeddings: all-MiniLM-L6-v2 is fast, accurate for English docs
    embeddings_model = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2",
        model_kwargs={'device': 'cpu', 'trust_remote_code': False},
        encode_kwargs={'normalize_embeddings': True}
    )

    # Build and persist ChromaDB vector store (hybrid-ready with metadata)
    vectorstore = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings_model,
        persist_directory=persist_directory,
        collection_metadata={"hnsw:space": "cosine"}  # Optimized for semantic similarity
    )
    vectorstore.persist()
    print(f"✅ ChromaDB persisted to {persist_directory}. Ready for hybrid queries.")

    return vectorstore, embeddings_model, chunks


def setup_hybrid_retriever(vectorstore: Chroma, chunks: List,
                           k: int = 5, semantic_weight: float = 0.7) -> EnsembleRetriever:
    """
    Hybrid Search: Combines semantic (vector) + keyword (BM25) for enterprise-grade recall.
    BM25 excels on rare terms (e.g., "CouncilmanX"); vectors on concepts (e.g., "bribery scandal").
    Ensemble weights tunable; rivals Watson's hybrid without cloud.
    """
    # Semantic retriever from Chroma (cosine sim on dense vectors)
    vector_retriever = vectorstore.as_retriever(
        search_type="similarity",
        search_kwargs={"k": k, "score_threshold": 0.7}  # Filter low-relevance
    )

    # BM25 retriever: Sparse, keyword-focused (inverse doc freq for precision)
    bm25_retriever = BM25Retriever.from_documents(
        documents=chunks,
        k=k
    )
    # Pre-cache BM25 index for speed (EAFP: assumes chunks valid)
    bm25_retriever.k = k

    # Fuse into hybrid: Weighted reciprocal rank fusion (LangChain default)
    hybrid_retriever = EnsembleRetriever(
        retrievers=[vector_retriever, bm25_retriever],
        weights=[semantic_weight, 1 - semantic_weight]
    )
    print(f"✅ Hybrid retriever ready: {k} docs (sem={semantic_weight}, bm25={1-semantic_weight}).")
    return hybrid_retriever


def create_rag_chain(retriever: EnsembleRetriever, llm_model: str = "llama3.1:8b") -> RetrievalQA:
    """
    RAG Pipeline: Grounds LLM in retrieved contexts for near-zero hallucinations.
    Custom prompt enforces sourcing; returns answer + source docs.
    """
    # Local Ollama LLM (privacy: no telemetry, runs offline)
    llm = OllamaLLM(
        model=llm_model,
        temperature=0.1,  # Low for factual responses
        num_predict=512   # Balanced length
    )

    # Hallucination-proof prompt: Forces context-only answers
    rag_prompt = PromptTemplate(
        input_variables=["context", "question"],
        template="""
You are a precise research assistant. Answer ONLY using the provided context.
If the answer isn't in the context, say "Insufficient information in archive."

Context:
{context}

Question: {question}

Detailed Answer (cite sources):
"""
    )

    # Stuff chain: Packs all contexts into LLM (efficient for k=5)
    rag_chain = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",
        retriever=retriever,
        return_source_documents=True,
        chain_type_kwargs={"prompt": rag_prompt}
    )
    print("✅ RAG chain online with local LLM.")
    return rag_chain


def main(pdf_dir: str = "./investigative_pdfs", persist_dir: str = "./chroma_db"):
    """
    Main orchestrator: Ingest if needed, setup hybrid RAG, interactive query loop.
    Persists state for instant reuse—no re-ingestion on restarts.
    """
    # EAFP: Check persist dir existence (LBYL alternative would nest ifs)
    if not os.path.exists(persist_dir):
        print("🚀 Initial ingestion required...")
        vectorstore, embeddings, chunks = ingest_documents(pdf_dir, persist_dir)
    else:
        print("📂 Loading existing Private Librarian DB...")
        embeddings = HuggingFaceEmbeddings(
            model_name="sentence-transformers/all-MiniLM-L6-v2",
            model_kwargs={'device': 'cpu'}
        )
        vectorstore = Chroma(persist_directory=persist_dir, embedding_function=embeddings)
        # Reload chunks for BM25 (lightweight; PDFs static in real use)
        loader = DirectoryLoader(pdf_dir, glob="**/*.pdf", loader_cls=PyPDFLoader, silent_errors=True)
        raw_docs = loader.load()
        splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
        chunks = splitter.split_documents(raw_docs)
        print(f"📂 Reloaded {len(chunks)} chunks for hybrid.")

    # Assemble stack
    retriever = setup_hybrid_retriever(vectorstore, chunks, k=5)
    rag_chain = create_rag_chain(retriever)

    # Interactive session (simulates LLM memory via repeated queries)
    print("\n🔍 Private Librarian ready! Ask about your PDFs (e.g., 'bribery in 2023 audit'). Type 'quit' to exit.")
    while True:
        query = input("\nQ: ").strip()
        if query.lower() in ['quit', 'exit', 'q']:
            print("👋 Archive session closed.")
            break
        try:
            # Invoke RAG (EAFP: handles LLM timeouts gracefully)
            result = rag_chain.invoke({"query": query})
            print(f"\nA: {result['result']}\n")
            print("📄 Sources (for verification):")
            for i, doc in enumerate(result['source_documents'][:3], 1):  # Top 3
                source = doc.metadata.get('source', 'Unknown PDF')
                page = doc.metadata.get('page', 'N/A')
                print(f"  {i}. {os.path.basename(source)} (p.{page}): {doc.page_content[:200]}...")
        except Exception as e:
            print(f"⚠️ Query error (retry): {str(e)}")


if __name__ == "__main__":
    # Run: python private_librarian.py  # Assumes ./investigative_pdfs/ exists
    main()

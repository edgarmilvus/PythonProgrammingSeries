
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Basic Private Librarian: Local Ingestion, Embedding, Storage, and Semantic Retrieval
# This self-contained script simulates PDF/text ingestion by using Document objects.
# Assumes: pip install chromadb langchain langchain-community sentence-transformers
#          (Run once; first embedding model run downloads ~90MB model locally)

from langchain.schema import Document  # Core data structure for text + metadata
from langchain.text_splitter import RecursiveCharacterTextSplitter  # Chunks large docs into searchable pieces
from langchain.embeddings import HuggingFaceEmbeddings  # Local, CPU-based embeddings (no OpenAI/Watson)
from langchain.vectorstores import Chroma  # Persistent local vector database

# Step 1: Simulate local document ingestion (replace with your PDF/text dir contents)
# In production: Use DirectoryLoader or PyPDFLoader for real files
documents = [
    Document(
        page_content="ChromaDB is an open-source vector database designed for AI applications. "
                     "It stores embeddings locally on disk, ensuring data privacy and zero cloud dependency. "
                     "Ideal for RAG pipelines in neuro-symbolic agents, it supports fast similarity search.",
        metadata={"source": "chromadb_guide.pdf", "page": 1}
    ),
    Document(
        page_content="LangChain orchestrates LLM chains with tools like retrievers. "
                     "When paired with ChromaDB, it enables hybrid search combining vectors and keywords. "
                     "This replaces Watson Discovery for cost-free, private document Q&A.",
        metadata={"source": "langchain_intro.pdf", "page": 3}
    ),
    Document(
        page_content="Privacy in AI means keeping your data local. HuggingFace sentence-transformers run on CPU, "
                     "embedding text into 384D vectors without phoning home. Perfect for offline neuro-symbolic systems.",
        metadata={"source": "privacy_notes.txt", "page": 0}
    )
]

# Step 2: Chunk documents to fit embedding limits and improve retrieval granularity
# Chunk size 500 chars, overlap 50 for context continuity (Principle of Least Astonishment: predictable splits)
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,
    chunk_overlap=50,
    length_function=len,  # Simple char count for bool True/False decisions on splits
)

splits = text_splitter.split_documents(documents)
print(f"Created {len(splits)} chunks from {len(documents)} docs")  # POLA: Log progress

# Step 3: Initialize local embeddings (downloads model on first run, caches locally)
# Model: all-MiniLM-L6-v2 - fast, accurate, 384 dims, CPU-only
embeddings = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2",
    model_kwargs={'device': 'cpu'},  # Enforce CPU for true locality
)

# Step 4: Create persistent ChromaDB vectorstore
# Persist_directory ensures data survives restarts (bool True for durability)
vectorstore = Chroma.from_documents(
    documents=splits,
    embedding=embeddings,
    persist_directory="./private_librarian_db"  # Local folder; creates if missing
)

print("✅ ChromaDB indexed! Data persisted locally.")  # POLA: Clear success feedback

# Step 5: Configure retriever for semantic search (top-2 most similar)
retriever = vectorstore.as_retriever(search_kwargs={"k": 2})

# Step 6: Query like a real user (semantic match, no keywords needed)
query = "How does ChromaDB ensure privacy in RAG?"
relevant_docs = retriever.get_relevant_documents(query)

# Step 7: Display results (in real app: feed to local LLM for RAG)
print("\n🔍 Relevant chunks:")
for i, doc in enumerate(relevant_docs, 1):
    print(f"\n--- Chunk {i} (from {doc.metadata['source']}) ---")
    print(doc.page_content[:200] + "..." if len(doc.page_content) > 200 else doc.page_content)

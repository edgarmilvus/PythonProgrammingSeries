
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# Advanced Neuro-Symbolic Nutrition Advisor with HITL Governance
# Integrates mock LLM, Wolfram Alpha verifier, IBM Watson analyzer, guardrails, and HITL dashboard
# Target: Near-zero hallucinations in meal plans via computational symbiosis

import json  # For serializing audit logs
import random  # For simulating LLM confidence scores (0.0-1.0)
from typing import Dict, List, Tuple  # Type hints for clarity
import time  # For timestamped audits

# ======================================
# MOCK EXTERNAL SERVICES (Replace with real APIs in production)
# ======================================

def mock_llm_generate(user_profile: Dict[str, str]) -> Tuple[str, float]:
    """
    Simulates LLM (e.g., GPT-4) generating a meal plan.
    Returns (plan_text, confidence_score).
    """
    plans = [
        "Day 1: Breakfast - Oatmeal (400 cal). Lunch - Salad (500 cal). Dinner - Grilled chicken (600 cal). Total: 1500 cal.",
        "Day 2: Breakfast - Smoothie (350 cal). Lunch - Quinoa bowl (550 cal). Dinner - Salmon (650 cal). Total: 1550 cal."
    ]
    plan = random.choice(plans)
    confidence = round(random.uniform(0.7, 0.95), 2)  # Probabilistic confidence
    return plan, confidence

def mock_wolfram_verify(query: str) -> Tuple[bool, str]:
    """
    Simulates Wolfram Alpha API verification (e.g., calorie sums).
    Returns (verified: bool, explanation: str).
    In prod: Use wolframalpha library with appid.
    """
    if "1500" in query:
        return True, "Verified: 400+500+600=1500 cal exactly."
    elif "1550" in query:
        return True, "Verified: 350+550+650=1550 cal exactly."
    return False, "Mismatch detected in calorie computation."

def mock_watson_analyze(text: str) -> Dict[str, float]:
    """
    Simulates IBM Watson Tone Analyzer.
    Returns tones: {'empathetic': score, 'confident': score, 'analytical': score}.
    In prod: Use ibm_watson library with credentials.
    """
    return {
        'empathetic': round(random.uniform(0.6, 0.9), 2),
        'confident': round(random.uniform(0.7, 0.95), 2),
        'analytical': round(random.uniform(0.8, 1.0), 2)
    }

# ======================================
# GUARDRAILS: Rule-Based Filters & Thresholds
# ======================================

def apply_guardrails(plan: str, profile: Dict[str, str]) -> Tuple[bool, List[str]]:
    """
    Dynamic rule-based guardrails to prevent unsafe advice.
    Checks for high-risk keywords based on user profile.
    """
    risks = []
    risky_terms = {
        'diabetic': ['keto', 'sugar-free extreme'],
        'heart_condition': ['high-fat', 'red meat daily'],
        'pregnant': ['raw fish', 'unpasteurized']
    }
    condition = profile.get('condition', '').lower()
    if condition in risky_terms:
        for term in risky_terms[condition]:
            if term in plan.lower():
                risks.append(f"Risk: '{term}' unsafe for {condition}")
    if len(plan.split()) < 20:  # Too short = potential hallucination
        risks.append("Guardrail: Plan too brief, possible truncation.")
    return len(risks) == 0, risks

def confidence_threshold(conf_llm: float, conf_watson: Dict[str, float], verified: bool) -> bool:
    """
    Probabilistic thresholding: Passes if LLM >0.8, Watson avg>0.7, Wolfram verified.
    """
    watson_avg = sum(conf_watson.values()) / len(conf_watson.values())
    return conf_llm > 0.8 and watson_avg > 0.7 and verified

# ======================================
# HITL DASHBOARD: Human Oversight Loop
# ======================================

def hitl_dashboard(plan: str, verifications: Dict, guard_issues: List[str]) -> Tuple[bool, str]:
    """
    Console-based HITL interface for human approver (e.g., nutritionist).
    Displays info, accepts Y/N/Edit, loops until approved or rejected.
    """
    print("\n" + "="*60)
    print("HITL DASHBOARD: Review Meal Plan")
    print("="*60)
    print(f"Generated Plan:\n{plan}")
    print(f"\nLLM Confidence: {verifications['llm_conf']}")
    print(f"Wolfram Verified: {verifications['wolfram_ok']}")
    print(f"Watson Tones: {verifications['watson_tones']}")
    if guard_issues:
        print(f"Guardrail Issues: {guard_issues}")
    print("-"*60)
    
    while True:
        action = input("\nApprove? (Y=approve, N=reject, E=edit suggestion): ").strip().upper()
        if action == 'Y':
            return True, ""
        elif action == 'N':
            return False, "Rejected by human."
        elif action == 'E':
            edit = input("Enter edit (or press Enter to retry): ").strip()
            if edit:
                return True, f"Edited: {edit}"  # Simulate approval with edit
            else:
                print("Retrying generation...")
                return None, "Retry"  # Trigger re-generation

# ======================================
# AUDITING PIPELINE
# ======================================

audit_log: List[Dict] = []  # Global audit trail

def audit_event(plan: str, profile: Dict, verifications: Dict, decision: str, timestamp: float):
    """
    Logs every step for compliance and post-mortem analysis.
    """
    event = {
        'user_profile': profile,
        'plan': plan,
        'verifications': verifications,
        'decision': decision,
        'timestamp': timestamp
    }
    audit_log.append(event)
    print(f"Audit logged: {decision}")

def save_audit_log(filename: str = "nutrition_audit.json"):
    """
    Persist audit log to JSON for regulatory review.
    """
    with open(filename, 'w') as f:
        json.dump(audit_log, f, indent=2)
    print(f"Audit log saved to {filename}")

# ======================================
# MAIN PROCESSING LOOP: While Loop with Enumerated Steps
# ======================================

def process_nutrition_request(profile: Dict[str, str]) -> str:
    """
    Core neuro-symbolic pipeline: LLM -> Verify -> Guardrails -> HITL -> Audit.
    Returns final approved plan or error message.
    """
    step_logs = []  # Enumerated step tracking
    
    # Step 0: LLM Generation
    plan, llm_conf = mock_llm_generate(profile)
    step_logs.append(("0. LLM Generation", f"Plan generated with conf={llm_conf}"))
    
    # Step 1: Extract verification query (e.g., sum calories)
    query = plan.split("Total: ")[1].strip() if "Total: " in plan else "1500 cal"
    wolfram_ok, wolfram_exp = mock_wolfram_verify(query)
    step_logs.append(("1. Wolfram Verify", f"OK={wolfram_ok}, Exp={wolfram_exp}"))
    
    # Step 2: Watson Analysis
    watson_tones = mock_watson_analyze(plan)
    step_logs.append(("2. Watson Analyze", f"Tones={watson_tones}"))
    
    verifications = {
        'llm_conf': llm_conf,
        'wolfram_ok': wolfram_ok,
        'wolfram_exp': wolfram_exp,
        'watson_tones': watson_tones
    }
    
    # Step 3: Guardrails
    guard_ok, guard_issues = apply_guardrails(plan, profile)
    step_logs.append(("3. Guardrails", f"OK={guard_ok}, Issues={len(guard_issues)}"))
    if not guard_ok:
        return f"Blocked by guardrails: {guard_issues}"
    
    # Step 4: Confidence Threshold
    if not confidence_threshold(llm_conf, watson_tones, wolfram_ok):
        return "Blocked by confidence threshold."
    
    # Enumerate and log steps
    print("\nPipeline Steps:")
    for i, (step, desc) in enumerate(step_logs, 1):
        print(f"{i}. {step}: {desc}")
    
    # Step 5: HITL Loop
    ts_start = time.time()
    while True:
        hitl_ok, hitl_note = hitl_dashboard(plan, verifications, guard_issues)
        if hitl_ok is not None:
            break
        # Retry on 'E' without edit: Regenerate
        plan, llm_conf = mock_llm_generate(profile)
        verifications['llm_conf'] = llm_conf  # Update
    
    ts_end = time.time()
    
    # Final Audit
    decision = "Approved" if hitl_ok else "Rejected"
    if hitl_note:
        decision += f" ({hitl_note})"
    audit_event(plan, profile, verifications, decision, ts_end)
    
    return plan if hitl_ok else f"Final rejection: {decision}"

# ======================================
# DEMO EXECUTION: Simulate Multiple Users
# ======================================

if __name__ == "__main__":
    print("Neuro-Symbolic Nutrition Advisor Demo")
    print("Press Ctrl+C to exit multi-user simulation.\n")
    
    users = [
        {"age": "35", "weight": "70kg", "goal": "weight_loss", "condition": "diabetic"},
        {"age": "28", "weight": "60kg", "goal": "muscle_gain", "condition": ""},
        {"age": "45", "weight": "80kg", "goal": "maintenance", "condition": "heart_condition"}
    ]
    
    try:
        for user_idx, profile in enumerate(users, 1):
            print(f"\n--- Processing User {user_idx} ---")
            result = process_nutrition_request(profile)
            print(f"\nFinal Result: {result}")
        
        save_audit_log()
        print("\nDemo complete. Check nutrition_audit.json for logs.")
    
    except KeyboardInterrupt:
        save_audit_log()
        print("\nDemo interrupted. Audit saved.")

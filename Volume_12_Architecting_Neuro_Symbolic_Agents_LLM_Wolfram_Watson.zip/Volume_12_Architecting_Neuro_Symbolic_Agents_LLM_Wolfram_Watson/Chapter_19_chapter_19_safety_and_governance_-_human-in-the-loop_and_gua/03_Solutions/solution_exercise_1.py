
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import json
import requests
import difflib
from difflib import SequenceMatcher
from datetime import datetime
import time
import os

# Mock Wolfram Alpha API response for demo (replace with real API below for production)
# # Safety: Mock prevents API quota exhaustion during testing; real use mitigates hallucinations via symbolic verification
def mock_wolfram(query):
    """Simulate Wolfram JSON response with pods, interpretations for confidence calc."""
    # Symbolic verification prevents LLM fabrications in agent decisions
    mock_responses = {
        "integral of x^2 from 0 to 1": {"queryresult": {"pods": [{"subpods": [{"plaintext": "1/3"}]}]}, "interpretations": 1},
        "2+2=4": {"queryresult": {"pods": [{"subpods": [{"plaintext": "true"}]}]}, "interpretations": 1},
        "prime number 17": {"queryresult": {"pods": [{"subpods": [{"plaintext": "yes"}]}]}, "interpretations": 1},
        "e=mc^2": {"queryresult": {"pods": [{"subpods": [{"plaintext": "confirmed"}]}]}, "interpretations": 2},
    }
    time.sleep(0.1)  # Simulate API latency
    return mock_responses.get(query.lower(), {"queryresult": {"pods": []}, "interpretations": 5})  # High interps = low conf

# Real Wolfram integration (uncomment and set APP_ID)
# APP_ID = "YOUR_APP_ID"  # Sign up at developer.wolframalpha.com
# def wolfram_query(query):
#     url = f"https://api.wolframalpha.com/v2/query?appid={APP_ID}&input={requests.utils.quote(query)}&format=plaintext&output=json"
#     try:
#         resp = requests.get(url, timeout=5)
#         data = resp.json()
#         # Parse pods for result plaintext
#         pods = data.get("queryresult", {}).get("pods", [])
#         result = pods[0]["subpods"][0]["plaintext"] if pods else ""
#         interps = data.get("queryinterpretations", {}).get("count", 5)
#         return {"queryresult": {"pods": [{"subpods": [{"plaintext": result}]}]}, "interpretations": interps}
#     except Exception as e:
#         print(f"# API error: {e}, retrying...")
#         time.sleep(1)
#         return wolfram_query(query)  # Retry once, thread-safe via single-thread here

results = {
    "total_claims": 0,
    "passes": 0,
    "human_interventions": 0,
    "rejects": 0,
    "avg_confidence": 0.0,
    "log": []
}

# Probabilistic thresholding: conf <0.8 -> HITL mandatory, aligns with governance for uncertain claims
def get_confidence(wolfram_resp):
    interps = wolfram_resp.get("interpretations", 1)
    return max(0.1, 1.0 / (interps + 1))  # Fewer interps = higher conf; bonus impl

# Process file iteratively for memory efficiency (<5s for 100+ lines)
file_path = "llm_outputs.txt"
if not os.path.exists(file_path):
    # Generate sample for testing
    samples = [
        "Claim: The integral of x^2 from 0 to 1 is 1/3.",
        "Claim: 2+2=4",
        "Claim: 17 is a prime number.",
        "Claim: E=mc^2 is a physics equation.",
        "Claim: Integral of x from 0 to 1 is 1/2.",  # Correct
        "Claim: 9 is prime.",  # False
    ] * 2  # 12 claims
    with open(file_path, 'w') as f:
        for s in samples:
            f.write(s + '\n')

confidences = []
with open(file_path, 'r') as f:
    for line_num, line in enumerate(f, 1):
        line = line.strip()
        if not line or not line.startswith("Claim:"):  # Edge: skip empty/non-claim
            continue
        claim = line[6:].strip()  # Parse claim text
        results["total_claims"] += 1
        
        # Construct query: simplify for computable (e.g., remove "is")
        query = claim.replace(" is ", " ").replace("The ", "").lower()
        # # Safety: Query engineering ensures verifiable facts, extensible to Watson
        
        wolfram_resp = mock_wolfram(query)  # Or wolfram_query(query)
        conf = get_confidence(wolfram_resp)
        confidences.append(conf)
        
        # Extract Wolfram result
        pods = wolfram_resp.get("queryresult", {}).get("pods", [])
        wolfram_result = pods[0]["subpods"][0]["plaintext"] if pods else "No result"
        
        # Check match with 99% threshold via difflib
        sim = SequenceMatcher(None, claim.lower(), wolfram_result.lower()).ratio()
        is_match = sim > 0.99
        
        decision = "pending"
        ts = datetime.now().isoformat()
        
        if is_match and conf >= 0.8:
            decision = "pass_auto"  # Green: low risk
        elif conf < 0.8 or not is_match:
            # HITL: pause for human, logs intervention for audit trail
            print(f"\nClaim: {claim}")
            print(f"Wolfram: {wolfram_result} (conf: {conf:.2f}, sim: {sim:.2f})")
            human_resp = input("Approve (y/n)? ").strip().lower()
            results["human_interventions"] += 1
            if human_resp == 'y':
                decision = "human_overridden"
                results["passes"] += 1
            else:
                decision = "reject"
                results["rejects"] += 1
        else:
            decision = "pass_auto"
            results["passes"] += 1
        
        # Log entry for compliance
        log_entry = {"timestamp": ts, "claim": claim, "wolfram": wolfram_result, "confidence": conf, "decision": decision}
        results["log"].append(log_entry)
        print(f"# Processed {line_num}: {decision} (safety: caught potential hallucination)")

# Compute aggregates
results["avg_confidence"] = sum(confidences) / len(confidences) if confidences else 0
results["passes"] += results["human_interventions"] - results["rejects"]  # Adjust if needed, but passes include overrides

# Output JSON report for dashboard integration
with open("validation_report.json", "w") as f:
    json.dump(results, f, indent=2)

print("\n# Audit complete: Check validation_report.json")
print(json.dumps({k: v for k, v in results.items() if k != "log"}, indent=2))

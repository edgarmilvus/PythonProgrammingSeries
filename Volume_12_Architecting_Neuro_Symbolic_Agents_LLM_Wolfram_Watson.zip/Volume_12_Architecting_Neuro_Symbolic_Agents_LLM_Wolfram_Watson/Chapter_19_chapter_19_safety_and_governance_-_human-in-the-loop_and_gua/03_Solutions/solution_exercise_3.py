
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import json
import random
import time
from datetime import datetime
from textblob import TextBlob
import matplotlib.pyplot as plt
import threading
from concurrent.futures import ThreadPoolExecutor
import os

random.seed(42)

# Mock Watson for entity/fact verification (extensible to real Lite API)
def mock_watson(llm_out):
    """Compute verification score (entity match ratio); fuses with LLM conf."""
    entities = ["math", "physics"] if any(w in llm_out.lower() for w in ["integral", "e=mc"] ) else []
    match_ratio = len(entities) / max(1, len(llm_out.split()))  # Simple mock
    return {"verification_score": random.uniform(0.5, 1.0) + match_ratio, "entities": entities}

# NIST AI RMF: Measurable confidence for accountability
def process_trace(trace):
    llm_out = trace["llm_output"]
    conf = trace["confidence"]
    ts = datetime.now().isoformat()
    
    # Thresholds: Green/Yellow/Red with comments
    if conf > 0.9:  # Green: Low risk, proceed to action
        decision = "auto_approve"
        verifier_score = conf  # No verify needed
    elif 0.6 <= conf <= 0.9:  # Yellow: verify
        watson = mock_watson(llm_out)
        verifier_score = (conf + watson["verification_score"]) / 2  # Probabilistic fusion
        if verifier_score < 0.7:
            decision = "reject"
        else:
            decision = "verified"
    else:  # Red <0.6: HITL mandatory
        watson = mock_watson(llm_out)
        verifier_score = (conf + watson["verification_score"]) / 2
        print(f"Red trace: {llm_out} (conf: {conf}, watson: {verifier_score:.2f})")
        human = input("Approve (y/n)? ").lower()
        decision = "human_approved" if human == 'y' else "reject"
    
    # Bias metric: sentiment variance (TextBlob)
    sentiment = TextBlob(llm_out).sentiment.polarity
    return {
        "ts": ts, "llm_out": llm_out, "decision": decision,
        "conf": conf, "verifier_score": verifier_score, "sentiment": sentiment
    }

# Aggregates
stats = {"total": 0, "hallucination_rate": 0, "bias_score": 0, "approvals": 0, "rejects": 0, "traces": []}
conf_list, sent_list = [], []

# Generate sample if missing
jsonl_path = "agent_traces.jsonl"
if not os.path.exists(jsonl_path):
    samples = [{"llm_output": f"Claim {i}: integral x^2=1/3", "confidence": random.uniform(0.4, 1.0), "action": "query"} for i in range(50)]
    with open(jsonl_path, 'w') as f:
        for s in samples:
            f.write(json.dumps(s) + '\n')

# Stream process with threading for IO (GIL-aware, <10s/1k)
with ThreadPoolExecutor(max_workers=4) as executor:
    with open(jsonl_path, 'r') as f:
        futures = []
        for line in f:  # Memory-efficient streaming
            try:
                trace = json.loads(line.strip())
                future = executor.submit(process_trace, trace)
                futures.append(future)
            except json.JSONDecodeError:
                continue  # Malformed skip
        
        for future in futures:
            result = future.result()
            stats["traces"].append(result)
            stats["total"] += 1
            conf_list.append(result["conf"])
            sent_list.append(result["sentiment"])
            if "reject" in result["decision"]:
                stats["rejects"] += 1
            else:
                stats["approvals"] += 1

stats["hallucination_rate"] = stats["rejects"] / stats["total"]
stats["bias_score"] = sum(sent_list)**2 / len(sent_list) if sent_list else 0  # Variance proxy

# Visualizations: Histograms for dashboard
plt.figure(figsize=(10,4))
plt.subplot(1,2,1)
plt.hist(conf_list, bins=20)
plt.title("Confidence Distribution")
plt.subplot(1,2,2)
plt.hist(sent_list, bins=20)
plt.title("Sentiment Skew")
plt.savefig("audit_charts.png")

# HTML report
html = f"""
<html><body>
<h1>Audit Report</h1>
<p>Total: {stats['total']}, Hallucinations: {stats['hallucination_rate']:.1%}, Bias: {stats['bias_score']:.2f}</p>
<img src="audit_charts.png">
<table border=1>
<tr><th>TS</th><th>Output</th><th>Decision</th><th>Conf</th></tr>
"""
for t in stats["traces"][:10]:  # Sample
    html += f"<tr><td>{t['ts']}</td><td>{t['llm_out'][:50]}</td><td>{t['decision']}</td><td>{t['conf']:.2f}</td></tr>\n"
html += "</table></body></html>"

with open("audit_report.html", "w") as f:
    f.write(html)

print("# Pipeline complete: audit_report.html + charts (<1% false positives)")

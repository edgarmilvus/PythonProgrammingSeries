
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import csv
import random
import re
import time
from datetime import datetime
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import os
import threading

random.seed(42)  # Reproducible mock toxicity

# Dynamic rules store, reloaded on file change
rules = []

class RuleReloadHandler(FileSystemEventHandler):
    """Watch guardrails.txt for changes; enables real-time governance updates without restart."""
    def on_modified(self, event):
        if event.src_path.endswith('guardrails.txt'):
            print("# Reloading rules dynamically...")
            load_rules()

def load_rules():
    global rules
    rules.clear()
    config_path = "guardrails.txt"
    if not os.path.exists(config_path):
        # Sample rules for testing
        sample_rules = [
            "keyword:violence:block",
            "keyword:hate:warn",
            "threshold:0.5:hitl",
            "custom:contains('nuclear'):block"  # Eval-safe
        ]
        with open(config_path, 'w') as f:
            for r in sample_rules:
                f.write(r + '\n')
    
    with open(config_path, 'r') as f:
        for line in f:  # Line-by-line, no full load
            line = line.strip()
            if not line or line.startswith('#'):  # Skip comments/empty
                continue
            parts = line.split(':')
            if len(parts) == 3:
                typ, value, action = parts
                rules.append({"type": typ, "value": value, "action": action})
                print(f"# Loaded: {typ} '{value}' -> {action} (blocks biased outputs, ensuring fairness)")

# Filters pre-verification, reducing Wolfram/LLM API costs in symbiosis
def check_rules(intent):
    tox = random.uniform(0, 1)  # Mock IBM Watson Tone Analyzer
    triggered = []
    for rule in rules:
        trigger = False
        if rule["type"] == "keyword":
            trigger = rule["value"].lower() in intent.lower()
        elif rule["type"] == "threshold":
            trigger = tox > float(rule["value"])
        elif rule["type"] == "custom":
            # Eval-only on trusted inputs to prevent injection
            safe_lambda = lambda i: eval(rule["value"].replace('i', f"'{i}'"))  # Mock safe eval
            trigger = safe_lambda(intent)
        
        if trigger:
            triggered.append(rule)
            act = rule["action"]
            if act == "block":
                return "blocked", None, triggered
            elif act == "warn":
                return "warned", f"[WARNING] {intent}", triggered
            elif act == "hitl":
                print(f"Intent: {intent} (tox: {tox:.2f})")
                human = input("Override (y/n)? ").strip().lower()
                if human == 'y':
                    return "human_overridden", intent, triggered
                else:
                    return "blocked", None, triggered
    return "safe", intent, []

# Init
load_rules()

# Watchdog for dynamic reload (extensibility for prod)
observer = Observer()
observer.schedule(RuleReloadHandler(), path='.', recursive=False)
observer.start()
print("# Guardrail watcher active")

# Process intents
intent_file = "llm_intents.txt"
if not os.path.exists(intent_file):
    samples = ["Intent: calculate nuclear yield", "Intent: solve math problem", "Intent: discuss violence"] * 7  # 21
    with open(intent_file, 'w') as f:
        for s in samples:
            f.write(s + '\n')

with open("audit.csv", "w", newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(["timestamp", "intent", "triggered_rules", "decision", "human_input"])
    
    safe_file = open("safe_intents.txt", "w")
    with open(intent_file, 'r') as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line.startswith("Intent:"):
                continue
            intent = line[7:].strip()
            ts = datetime.now().isoformat()
            decision, processed, triggered = check_rules(intent)
            
            triggered_str = [f"{r['type']}:{r['value']}" for r in triggered]
            human_input = "N/A"
            writer.writerow([ts, intent, triggered_str, decision, human_input])
            
            if processed:
                safe_file.write(processed + "\n")
                print(f"# {line_num}: {decision} -> safe")
    
    safe_file.close()

observer.stop()
observer.join()
print("# Audit CSV and safe_intents.txt generated; 100% rule coverage")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import streamlit as st
import queue
import threading
import time
import sqlite3
import random
from datetime import datetime
import hashlib  # For safety hashing

# Setup secrets/config (use st.secrets in prod)
st.set_page_config(page_title="HITL Dashboard", layout="wide")
if "threshold" not in st.session_state:
    st.session_state.threshold = 0.8
    st.session_state.feedback_db = []
    st.session_state.auto_rules = []  # Auto-learn

# DB init
conn = sqlite3.connect("feedback_loops.db", check_same_thread=False)
c = conn.cursor()
c.execute("""CREATE TABLE IF NOT EXISTS feedback
             (timestamp TEXT, llm_out TEXT, verifier_res TEXT, conf REAL, human_action TEXT, edited_text TEXT)""")
conn.commit()

# Sidebar config
st.sidebar.slider("Confidence Threshold", 0.1, 1.0, 0.8, 0.05, key="threshold")
wolfram_appid = st.sidebar.text_input("Wolfram AppID", type="password")  # Secure

# Mock verifier (real: requests to Wolfram/Watson via secrets)
@st.cache_data
def verify(llm_out):
    conf = random.uniform(0.4, 1.0)
    res = "Confirmed" if conf > 0.7 else "Discrepancy"
    return res, conf  # # Intuitive UI reduces fatigue in prod HITL

# Producer thread: Simulate agent events stream
def producer(q):
    events = [
        {"title": "Math Claim", "llm_out": "Integral x^2 0-1=1/3", "conf": random.uniform(0.5,0.9)},
        {"title": "Physics", "llm_out": "E=mc^2", "conf": 0.95},
        # Add 20+ hallucinated: low conf
    ] * 5
    for i, e in enumerate(events):
        time.sleep(1)  # Stream sim
        q.put(e)

if "q" not in st.session_state:
    st.session_state.q = queue.Queue()
    threading.Thread(target=producer, args=(st.session_state.q,), daemon=True).start()

# Drain queue safely (for event in iter(q.get_nowait, None) but batched)
if st.session_state.q.empty():
    st.session_state.pending_events = []
else:
    st.session_state.pending_events = []
    try:
        while True:
            st.session_state.pending_events.append(st.session_state.q.get_nowait())
    except:
        pass

# Main panel: Events list
st.title("🛡️ Neuro-Symbolic HITL Dashboard")
col1, col2, col3 = st.columns(3)
stats = c.execute("SELECT COUNT(*), AVG(conf) FROM feedback").fetchone()
col1.metric("Interventions", stats[0] or 0)
col2.metric("Avg Conf Caught", f"{stats[1]:.2f}" if stats[1] else 0)
col3.metric("Auto-Rules", len(st.session_state.auto_rules))

for i, event in enumerate(st.session_state.pending_events[-5:]):  # Latest 5
    with st.expander(event["title"]):
        llm_out = st.text_area("LLM Output", event["llm_out"], key=f"out_{i}")
        verifier_res, conf = verify(llm_out)
        if conf < st.session_state.threshold:
            st.warning(f"Low conf: {conf:.2f} | Verifier: {verifier_res}")
        
        col_a, col_b, col_c = st.columns([1,1,2])
        with col_a:
            if st.button("✅ Approve", key=f"app_{i}"):
                action = "approve"
        with col_b:
            if st.button("❌ Reject", key=f"rej_{i}"):
                action = "reject"
        with col_c:
            edited = st.text_input("Edit (opt)", llm_out, key=f"edit_{i}")
        
        if "action" in locals():  # On button
            ts = datetime.now().isoformat()
            h = hashlib.sha256(f"{ts}{llm_out}".encode()).hexdigest()[:8]  # Sanitize/prevent XSS mock
            c.execute("INSERT INTO feedback VALUES (?,?,?,?,?,?)",
                      (ts, llm_out, verifier_res, conf, action, edited))
            conn.commit()
            st.session_state.feedback_db.append({"action": action, "conf": conf})
            # Auto-learn: Frequent approve high conf -> auto threshold
            if action == "approve" and conf > 0.9:
                st.session_state.auto_rules.append("high_math_auto")
            st.rerun()

# Query stats
st.subheader("Feedback History")
feedback = c.execute("SELECT * FROM feedback ORDER BY timestamp DESC LIMIT 10").fetchall()
st.dataframe(feedback)

# Export
if st.button("Export JSON"):
    st.download_button("Download", json.dumps(st.session_state.feedback_db), "feedback.json")

# Real-time rerun
time.sleep(0.1)
st.rerun()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import sympy as sp
import pandas as pd
import subprocess
import sys
import io
import re
import traceback
from typing import Dict, Any, List
from contextlib import contextmanager

# Sample coffee shop data: monthly units sold, prices, fixed/variable costs
SAMPLE_DATA_CSV = """units_sold,price_per_unit,fixed_costs,variable_cost_per_unit
100,4.50,1200,2.10
150,4.20,1200,2.20
200,4.00,1200,2.00
120,4.80,1200,2.15
180,4.30,1200,2.05
250,3.90,1200,1.95
90,5.00,1200,2.30
"""

class OpenLogicEngine:
    """
    The Open Logic Engine: Local, self-correcting interpreter replacing Wolfram Alpha.
    Uses SymPy for symbolic math/logic, Pandas for data ops. Executes code in subprocess
    sandbox with error-driven rewriting for near-zero hallucination.
    """
    
    def __init__(self):
        # Load data using context manager for safe StringIO handling
        self.data_df = self._load_data()
    
    @contextmanager
    def _safe_io(self, data_str: str):
        """Context manager for file-like I/O, ensuring cleanup."""
        f = io.StringIO(data_str)
        try:
            yield f
        finally:
            f.close()
    
    def _load_data(self) -> pd.DataFrame:
        """Load sample CSV data into Pandas DataFrame."""
        with self._safe_io(SAMPLE_DATA_CSV) as f:
            return pd.read_csv(f)
    
    def generate_code(self, query: str) -> str:
        """
        Rule-based code generator: Maps query keywords to SymPy/Pandas snippets.
        Generates self-contained code (includes data, imports) for subprocess exec.
        Uses list comps, logical ops, symbolic solving.
        """
        query_lower = query.lower()
        code_template = """
import sympy as sp
import pandas as pd
import io

# Self-contained data load with context manager
data_csv = '''{data}'''
with io.StringIO(data_csv) as f:
    df = pd.read_csv(f)

# Compute profit column using vectorized Pandas ops
df['profit'] = df['price_per_unit'] * df['units_sold'] - df['fixed_costs'] - df['variable_cost_per_unit'] * df['units_sold']
""".format(data=SAMPLE_DATA_CSV)
        
        if 'break-even' in query_lower:
            # Symbolic break-even solve for price p at target units q
            code_template += """
p, q, f, v = sp.symbols('p q f v')
profit_eq = p * q - f - v * q
avg_f = df['fixed_costs'].mean()
avg_v = df['variable_cost_per_unit'].mean()
target_q = 150  # Example target units
breakeven_p = sp.solve(profit_eq, p)[0].subs({{q: target_q, f: avg_f, v: avg_v}})
print(f"Break-even price for {{target_q}} units: ${{breakeven_p.evalf():.2f}}")
print(f"Symbolic formula: p = (f + v*q)/q")
"""
        elif 'profitable' in query_lower or 'logic' in query_lower:
            # Pandas query with logical operators + list comp for months
            code_template += """
# Logical query: profitable AND high volume
high_volume = 150
profitable_high = df.query('profit > 0 and units_sold > @high_volume')

# List comprehension for conditional summary
prof_months = [idx for idx, row in df.iterrows() if row['profit'] > 0 and row['units_sold'] > high_volume]
print("Profitable high-volume months:", prof_months)
print("Filtered data:\\n", profitable_high)
"""
        elif 'optimize price' in query_lower:
            # Symbolic optimization: maximize profit assuming linear demand
            code_template += """
p, q0, b = sp.symbols('p q0 b')  # q = q0 - b*p (demand curve fit)
demand = q0 - b * p
revenue = p * demand
costs = avg_f + avg_v * demand  # avg from data
profit_opt = revenue - costs
opt_price = sp.diff(profit_opt, p).simplify()
print("Optimal price (symbolic deriv=0): solve for p in", opt_price)
# Numeric approx with fitted params
q0_fit, b_fit = 300, 20  # Rough fit from data
opt_p_num = sp.solve(sp.diff((p*(q0_fit - b_fit*p) - avg_f - avg_v*(q0_fit - b_fit*p)), p), p)[0]
print(f"Numerical optimal price: ${{opt_p_num.evalf():.2f}}")
"""
        elif 'theorem' in query_lower or 'prove' in query_lower:
            # SymPy logic: Prove profit >0 implies p > v + f/q
            code_template += """
from sympy.logic.boolalg import And, Implies, Or
from sympy import Symbol, Gt

p, v, f, q = sp.symbols('p v f q', positive=True)
profit_pos = Gt(p*q - f - v*q, 0)
implication = Implies(profit_pos, Gt(p, v + f/q))
print("Is profit >0 => p > v + f/q always true?", implication)
print(sp.satisfiable(~implication))  # False if tautology
"""
        else:
            # Default data summary with logical filters
            code_template += """
print("Data summary:\\n", df.describe())
print("Avg profit:", df['profit'].mean())
"""
        
        # Ensure print for output capture
        code_template += "\nprint('Execution successful.')"
        return code_template
    
    def _analyze_error(self, stderr: str) -> Dict[str, str]:
        """Parse stderr for error type and suggestion using regex."""
        error_info = {'type': 'Unknown', 'fix': 'No fix'}
        if 'SyntaxError' in stderr:
            error_info['type'] = 'SyntaxError'
            error_info['fix'] = 'Check indentation and syntax in generated code.'
        elif 'NameError' in stderr:
            m = re.search(r"name '([^']+)' is not defined", stderr)
            if m:
                error_info['type'] = 'NameError'
                error_info['fix'] = f"Define or import {m.group(1)}."
        elif 'ModuleNotFoundError' in stderr:
            m = re.search(r"No module named '([^']+)'", stderr)
            if m:
                error_info['type'] = 'ImportError'
                error_info['fix'] = f"Add: import {m.group(1)}"
        elif 'IndentationError' in stderr:
            error_info['type'] = 'IndentationError'
            error_info['fix'] = 'Fix code indentation.'
        return error_info
    
    def _correct_code(self, code: str, stderr: str, max_attempts: int = 3) -> str:
        """
        Self-correcting rewriter: Applies fixes based on error analysis.
        Limits mutations to safe patterns (add imports, wrap defs).
        """
        error_info = self._analyze_error(stderr)
        corrected = code
        
        if error_info['type'] == 'ImportError':
            mod = error_info['fix'].split('import ')[1]
            if mod not in code:
                corrected = f"import {mod}\n{code}"
        elif error_info['type'] == 'NameError':
            var = error_info['fix'].split('Define ')[1]
            if var == 'df' and 'df =' not in code:
                # Reinject data load block
                data_block = """
import pandas as pd
import io
data_csv = '''{data}'''
with io.StringIO(data_csv) as f:
    df = pd.read_csv(f)
""".format(data=SAMPLE_DATA_CSV)
                corrected = data_block + code
        elif error_info['type'] == 'SyntaxError':
            # Simple fix: Ensure consistent 4-space indents
            lines = code.split('\n')
            fixed_lines = []
            for line in lines:
                if line.strip() and line.startswith('\t'):
                    fixed_lines.append(re.sub(r'^\t', '    ', line))
                else:
                    fixed_lines.append(line)
            corrected = '\n'.join(fixed_lines)
        
        # Prevent infinite loops: Track changes
        if corrected == code:
            raise ValueError("Cannot auto-correct this error.")
        return corrected
    
    def safe_execute(self, code: str, max_retries: int = 3) -> Dict[str, Any]:
        """
        Local loop: Execute in subprocess sandbox, capture stderr/stdout.
        Retry with corrections on failure. Safer than exec()—no shared globals.
        """
        current_code = code
        for attempt in range(max_retries):
            try:
                # Subprocess sandbox: Isolated Python process
                proc = subprocess.Popen(
                    [sys.executable, '-c', current_code],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    bufsize=0
                )
                stdout, stderr = proc.communicate(timeout=10)  # Timeout for safety
                
                if proc.returncode == 0:
                    return {
                        'success': True,
                        'output': stdout.strip(),
                        'error': None,
                        'attempts': attempt + 1
                    }
                else:
                    print(f"Attempt {attempt+1} failed: {stderr.strip()[:200]}...", file=sys.stderr)
                    if attempt < max_retries - 1:
                        current_code = self._correct_code(current_code, stderr)
            except subprocess.TimeoutExpired:
                return {'success': False, 'output': None, 'error': 'Execution timeout'}
            except Exception as e:
                return {'success': False, 'output': None, 'error': str(e)}
        
        return {'success': False, 'output': None, 'error': stderr.strip()}
    
    def process_query(self, query: str) -> str:
        """Main entry: Generate -> Execute with retries -> Return result."""
        code = self.generate_code(query)
        result = self.safe_execute(code)
        if result['success']:
            return f"SUCCESS after {result['attempts']} attempts:\n{result['output']}"
        else:
            return f"FAILED: {result['error']}"

# Demo usage: Real-world queries
if __name__ == "__main__":
    engine = OpenLogicEngine()
    
    queries = [
        "Calculate break-even price",
        "Find profitable months with logic",
        "Optimize price for max profit",  # Triggers symbolic deriv
        "Prove theorem profit >0 implies higher price",
        # Intentional error-prone: Simulate bad gen (but our gen is robust)
    ]
    
    for q in queries:
        print(f"\n--- Query: {q} ---")
        response = engine.process_query(q)
        print(response)
        print("=" * 50)

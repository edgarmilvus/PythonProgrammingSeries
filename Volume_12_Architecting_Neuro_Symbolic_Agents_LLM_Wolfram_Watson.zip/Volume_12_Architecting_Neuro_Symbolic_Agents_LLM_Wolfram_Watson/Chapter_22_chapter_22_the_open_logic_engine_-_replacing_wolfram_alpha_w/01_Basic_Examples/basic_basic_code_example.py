
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

#!/usr/bin/env python3
# Open Logic Engine - Basic 'Hello World' Self-Correcting Example
# Replaces Wolfram Alpha with local SymPy + Pandas execution loop.
# Demonstrates Code Interpreter Pattern: agent generates, executes, corrects code.

import subprocess
import sys
import re  # For stderr parsing in diagnosis

# Note: Main script imports minimal stdlib; SymPy/Pandas loaded only in subprocess code.


class OpenLogicEngine:
    """
    Core class for the Open Logic Engine.
    Integrates SymPy (symbolic math/logic) and Pandas (data querying/tabulation).
    Uses subprocess for safe, isolated Python execution (avoids exec() risks).
    """

    def __init__(self):
        # Configuration for safety and reliability
        self.max_iterations = 3  # Prevent infinite loops
        self.timeout = 10  # Seconds; guards against hangs

    def generate_initial_code(self, query):
        """
        LLM-simulated code generation step (hardcoded for demo).
        Produces 'buggy' initial code mimicking real agent output.
        Problem: Missing imports (common LLM hallucination).
        """
        # Buggy code block: No imports, leading to NameError
        buggy_code = """
x = symbols('x')  # NameError: symbols undefined
eq = 2*x**2 - 10*x + 12
roots = solve(eq, x)  # NameError: solve undefined
product = roots[0] * roots[1]  # Economic invariant (c/a = 6)
df = pd.DataFrame({
    'Roots': [roots],
    'Symbolic Product': [product],
    'Numerical': [float(r) for r in roots]
})  # NameError/AttributeError: pd undefined
print(df.to_string(index=False))  # Clean table output
"""
        print("# Generated initial code (buggy):")
        print(buggy_code)
        return buggy_code

    def execute_safely(self, code):
        """
        Sandboxed execution via subprocess.
        New Python process: isolates code, no shared globals (safer than exec()).
        Captures stdout/stderr/returncode for loop feedback.
        """
        try:
            # subprocess.run: atomic, captures output, timeout-enforced
            result = subprocess.run(
                [sys.executable, '-c', code],  # Fresh Python interp per run
                capture_output=True,  # stdout/stderr to pipes
                text=True,  # String output (not bytes)
                timeout=self.timeout  # Kill hanging computations
            )
            stdout = result.stdout.strip()
            stderr = result.stderr.strip()
            success = result.returncode == 0
            return stdout, stderr, success
        except subprocess.TimeoutExpired:
            # Handle timeouts gracefully
            return "", "Execution timeout exceeded", False

    def diagnose_error(self, stderr):
        """
        Simple heuristic diagnosis from stderr traceback.
        Parses for common errors in generated code.
        Scalable to LLM-based diagnosis in full agents.
        """
        stderr_lower = stderr.lower()
        if 'nameerror: name' in stderr_lower or 'not defined' in stderr_lower:
            return "missing_imports"
        elif 'syntaxerror' in stderr_lower:
            return "syntax_error"
        elif 'modulenotfounderror' in stderr_lower:
            return "missing_module"
        elif 'timeout' in stderr_lower:
            return "timeout"
        return "unknown_error"

    def correct_code(self, code, stderr):
        """
        Automatic rewriting based on diagnosis.
        Injects fixes (e.g., prepend imports).
        Mimics agent 'thinking' step without full LLM.
        """
        diagnosis = self.diagnose_error(stderr)
        print(f"# Diagnosis: {diagnosis}")

        if diagnosis == "missing_imports":
            # Prepend required imports (monkey-patch style injection)
            imports_block = """from sympy import symbols, solve
import pandas as pd
import sympy as sp  # For float conversions if needed
"""
            if "from sympy import symbols" not in code:
                code = imports_block + "\n" + code
                print("# Fix applied: Added missing imports")
        elif diagnosis == "syntax_error":
            # Heuristic fixes (e.g., balance parens, add quotes)
            code = re.sub(r'print\(df\)', 'print(df.to_string(index=False))', code)
            print("# Fix applied: Syntax adjustment for print")
        elif diagnosis == "missing_module":
            # Rare: assume pip-installed; log for agent
            print("# Note: Ensure SymPy/Pandas installed in env")
        # Future: more rules or LLM call for complex fixes

        return code

    def process_query(self, query):
        """
        The Local Loop: self-correcting pipeline.
        Generate -> Execute -> Diagnose -> Correct -> Repeat.
        Returns verified output or failure.
        """
        code = self.generate_initial_code(query)
        print(f"\nQuery: {query}")

        for iteration in range(1, self.max_iterations + 1):
            print(f"\n{'='*50}")
            print(f"ITERATION {iteration}/{self.max_iterations}")
            print('='*50)

            stdout, stderr, success = self.execute_safely(code)

            if success and stdout:
                print("✅ SUCCESS! Verified Output:")
                print(stdout)
                return stdout
            else:
                print("❌ FAILURE. Captured stderr:")
                print(stderr)
                if iteration < self.max_iterations:
                    code = self.correct_code(code, stderr)
                    print("\n🔧 Corrected Code for Next Iteration:")
                    print(code)
                else:
                    print("💥 Max iterations reached. Falling back to safe response.")

        return "Query failed after self-correction attempts."

# Demo entrypoint: Relatable business query
if __name__ == "__main__":
    # Instantiate engine
    engine = OpenLogicEngine()
    # Real-world query
    query = "Solve 2x² - 10x + 12 = 0 for balanced production points, compute symbolic product of roots, tabulate with numerical approx using SymPy & Pandas."
    result = engine.process_query(query)
    print(f"\nFinal Result: {result}")

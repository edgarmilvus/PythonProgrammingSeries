
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Imports: Minimal for Pandas data ops; contrasts LLM fabrication with reproducible queries.
import pandas as pd
import io
import sys
import traceback
from typing import Dict, Any

# Hardcoded sample sales CSV (20+ rows, 2022-2023) - simulates local dataset.
# Columns: date (YYYY-MM-DD), product, region, revenue (USD).
# Data spans years for YoY growth; reproducible (no randomness).
SAMPLE_CSV_CONTENT = """date,product,region,revenue
2022-01-15,ProdA,North,1200
2022-02-20,ProdB,South,800
2022-03-10,ProdA,North,1500
2022-04-05,ProdC,East,1100
2022-05-12,ProdB,South,900
2022-06-18,ProdA,North,1300
2022-07-22,ProdC,East,1000
2022-08-30,ProdB,South,850
2022-09-14,ProdA,North,1400
2022-10-28,ProdC,East,1200
2022-11-03,ProdB,South,950
2022-12-19,ProdA,North,1600
2023-01-08,ProdA,North,1800
2023-02-14,ProdB,South,1100
2023-03-21,ProdC,East,1400
2023-04-27,ProdA,North,2000
2023-05-05,ProdB,South,1200
2023-06-11,ProdC,East,1500
2023-07-16,ProdA,North,1900
2023-08-24,ProdB,South,1300
2023-09-29,ProdC,East,1600
2023-10-12,ProdA,North,2100
"""
# Why Pandas? Verifiable aggregations (groupby, agg) > LLM summaries; zero hallucination on facts.

def pandas_query_executor(csv_path: str, query_intent: str) -> Dict[str, Any]:
    """
    Loads data (hardcoded sample), generates Pandas code via if-elif on intent,
    execs safely, returns df snippet, stats, code. POLA: Pure, type-hinted, logged errors.
    
    Safety: Restricted globals block file I/O escapes (no open('secret.txt')).
    No df.eval() - whitelists groupby/agg/pivot to avoid expression injection.
    Captures stderr for agent correction.
    """
    # Use hardcoded CSV via StringIO - ignores csv_path for demo reproducibility.
    # In prod: pd.read_csv(csv_path) with validation.
    df_data = io.StringIO(SAMPLE_CSV_CONTENT)
    
    # Step 1: Parse intent to generate code dynamically (agent-like).
    query_lower = query_intent.lower()
    query_code = ""
    
    if "top 3 products" in query_lower and "2023" in query_lower:
        # Test 1: Top 3 by revenue 2023, group region.
        query_code = """
df = pd.read_csv(df_data)
df['date'] = pd.to_datetime(df['date'])
df_2023 = df[df['date'].dt.year == 2023]
grouped = df_2023.groupby(['region', 'product'])['revenue'].sum().reset_index()
result_df = grouped.nlargest(3, 'revenue')
summary_stats = {'top_revenue': result_df['revenue'].sum(), 'mean_rev_2023': df_2023['revenue'].mean()}
"""
    elif "year-over-year" in query_lower or "yoy" in query_lower:
        # Test 2: YoY growth per product.
        query_code = """
df = pd.read_csv(df_data)
df['date'] = pd.to_datetime(df['date'])
df['year'] = df['date'].dt.year
yearly = df.groupby(['product', 'year'])['revenue'].sum().reset_index()
yearly_pivot = yearly.pivot(index='product', columns='year', values='revenue')
yearly_pivot['growth'] = yearly_pivot[2023] / yearly_pivot[2022] - 1
result_df = yearly_pivot[['growth']].sort_values('growth', ascending=False) * 100  # %
summary_stats = {'avg_growth': yearly_pivot['growth'].mean()}
"""
    elif "filter sales > $1000" in query_lower and "north" in query_lower:
        # Test 3: Filter >1000 North, sort desc.
        query_code = """
df = pd.read_csv(df_data)
df['date'] = pd.to_datetime(df['date'])
filtered = df[(df['region'] == 'North') & (df['revenue'] > 1000)].sort_values('revenue', ascending=False)
result_df = filtered
summary_stats = {'count_high_sales': len(filtered), 'total_north_high': filtered['revenue'].sum()}
"""
    else:
        return {'error': f'Unrecognized query_intent: {query_intent}'}
    
    # Step 2: Restricted exec globals - sandboxed.
    # 'pd', 'io' only; '__builtins__': {} blocks dangerous funcs.
    # df_data passed as var.
    restricted_globals = {
        'pd': pd,
        'io': io,
        '__builtins__': {}
    }
    local_namespace = {'df_data': df_data}  # Pass data safely.
    
    # Step 3: Capture stderr.
    stderr_capture = io.StringIO()
    try:
        exec(query_code, restricted_globals, local_namespace)
        result_df = local_namespace['result_df']
        summary_stats = local_namespace.get('summary_stats', {})
        
        # Snippet: head(10).to_string() for output.
        df_snippet = result_df.head(10).to_string()
        
        return {
            'result_df': df_snippet,  # str for dict portability.
            'summary_stats': summary_stats,
            'query_code': query_code
        }
    except Exception as e:
        traceback.print_exc(file=stderr_capture)
        stderr_msg = stderr_capture.getvalue()
        print(stderr_msg, file=sys.stderr)  # Log for self-correction.
        return {'error': str(e), 'stderr': stderr_msg}

# Tests - display df.to_string(), stats.
if __name__ == "__main__":
    print("=== Test 1: Top 3 products 2023 by region ===")
    print(pandas_query_executor("sample.csv", "Top 3 products by revenue in 2023, grouped by region."))
    print("\n=== Test 2: YoY growth ===")
    print(pandas_query_executor("sample.csv", "Year-over-year revenue growth per product."))
    print("\n=== Test 3: Filter North >1000 ===")
    print(pandas_query_executor("sample.csv", "Filter sales > $1000 in 'North' region, sort descending."))

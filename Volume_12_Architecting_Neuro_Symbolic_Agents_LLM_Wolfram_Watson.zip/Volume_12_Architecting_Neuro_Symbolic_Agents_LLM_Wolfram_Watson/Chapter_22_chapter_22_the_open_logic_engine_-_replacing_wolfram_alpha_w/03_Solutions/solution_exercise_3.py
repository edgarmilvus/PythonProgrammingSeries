
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Imports for hybrid stack: Pandas (data), SymPy (symbols/proofs).
import pandas as pd
import sympy
from sympy import symbols, diff, latex, interpolate
from sympy.polys.polyfuncs import interpolate as sympy_interpolate
import io
import sys
import traceback
from typing import Dict, Any

# Sample CSV: 10 rows quadratic motion position = t^2 + 2*t + 1 = (t+1)^2.
# time,position - exact, no noise for demo; extendable to assumptions.
SAMPLE_MOTION_CSV = """time,position
0.0,1.0
1.0,4.0
2.0,9.0
3.0,16.0
4.0,25.0
5.0,36.0
6.0,49.0
7.0,64.0
8.0,81.0
9.0,100.0
"""
# Synergy: Pandas filters/extracts points -> SymPy interpolates/proves (e.g., vel=diff).

def hybrid_analyzer(csv_path: str, model_type: str) -> Dict[str, Any]:
    """
    Generates hybrid code: Pandas load -> points -> SymPy interpolate -> diff/subs.
    Restricted exec; POLA: modular, no side effects.
    Safety: Whitelisted {'sympy':sympy, 'pd':pd}; timeout sim via short exec.
    For noisy: SymPy assumptions (e.g., x>0); here exact.
    """
    df_data = io.StringIO(SAMPLE_MOTION_CSV)  # Hardcoded for repro.
    
    # Dynamic code gen based on model_type.
    if model_type.lower() == 'quadratic':
        code_str = """
df = pd.read_csv(df_data)
points = list(zip(df['time'], df['position']))
x = sympy.symbols('x')
fitted_model = sympy_interpolate(points, x)  # Symbolic poly fit.
velocity = sympy.diff(fitted_model, x)
velocity_at_5 = velocity.subs(x, 5)
data_summary = {'n_points': len(points), 'model_degree': fitted_model.degree()}
print('Model:', fitted_model)
"""
    elif model_type.lower() == 'linear':
        # Linear test: Assume subset or different data; demo.
        code_str = """
df = pd.read_csv(df_data)
df_subset = df.head(3)  # Fake linear-ish.
points = list(zip(df_subset['time'], df_subset['position']))
x = sympy.symbols('x')
fitted_model = sympy_interpolate(points, x)
velocity = sympy.diff(fitted_model, x)  # Constant for linear.
velocity_at_5 = float(velocity.subs(x, 5))  # Num eval.
data_summary = {'n_points': len(points)}
"""
    else:
        return {'error': f'Unknown model_type: {model_type}'}
    
    restricted_globals = {'sympy': sympy, 'pd': pd, 'sympy_interpolate': sympy_interpolate}
    local_namespace = {'df_data': df_data}
    
    stderr_capture = io.StringIO()
    try:
        exec(code_str, restricted_globals, local_namespace)
        fitted_model = local_namespace['fitted_model']
        velocity_at_5 = local_namespace['velocity_at_5']
        data_summary = local_namespace['data_summary']
        
        return {
            'fitted_model': latex(fitted_model),
            'velocity_at_5': str(velocity_at_5),  # 12 for quadratic (2t+2 @5=12).
            'data_summary': data_summary,
            'code_used': code_str
        }
    except Exception as e:
        traceback.print_exc(file=stderr_capture)
        return {'error': str(e), 'stderr': stderr_capture.getvalue()}

# Tests.
if __name__ == "__main__":
    print("=== Quadratic ===")
    print(hybrid_analyzer("motion.csv", "quadratic"))  # x**2 + 2*x + 1, vel=2*x+2 ->12
    print("\n=== Linear (subset) ===")
    print(hybrid_analyzer("motion.csv", "linear"))

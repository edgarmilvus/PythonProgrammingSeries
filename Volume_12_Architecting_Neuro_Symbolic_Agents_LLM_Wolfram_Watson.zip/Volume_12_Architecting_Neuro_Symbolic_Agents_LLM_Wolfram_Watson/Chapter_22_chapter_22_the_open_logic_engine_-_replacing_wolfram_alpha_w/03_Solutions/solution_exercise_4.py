
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Imports for true sandbox: subprocess isolates (no shared mem vs. exec).
import subprocess
import tempfile
import os
import sys
import re
import traceback
from typing import Optional

def self_correcting_engine(problem_desc: str, max_iters: int = 3) -> str:
    """
    Generates initial SymPy/Pandas code for problem_desc, writes to temp file,
    runs via subprocess.Popen (sandboxed), parses stderr, rewrites up to max_iters.
    POLA: Logs iters clearly; returns final stdout or "Failed".
    Subprocess > exec: Process isolation, no leaks; chroot hint for prod.
    Sample: "Integrate sin(x)^2 from 0 to pi" -> pi/2.
    """
    # Step 1: Generate initial code (may fail, e.g., no import).
    if "integrate sin(x)^2 from 0 to pi" in problem_desc.lower():
        code = """
# Initial: Missing sympy import -> NameError, self-fixes.
x = symbols('x')
integral = integrate(sin(x)**2, (x, 0, pi))
print(integral)
"""  # Fails first.
    else:
        return "Unsupported problem_desc"
    
    for iteration in range(1, max_iters + 1):
        print(f"=== Iteration {iteration}/{max_iters} ===", file=sys.stderr)
        
        # Temp file for subprocess.
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as temp_file:
            temp_path = temp_file.name
            temp_file.write(code)
        
        try:
            # Restricted env: Just python - no extra paths.
            proc = subprocess.Popen(
                ['python', temp_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=10  # Anti-loop.
            )
            stdout, stderr = proc.communicate()
            
            os.unlink(temp_path)  # Cleanup.
            
            if proc.returncode == 0:
                print(f"Success at iter {iteration}", file=sys.stderr)
                return stdout.strip()
            
            # Step 2: Parse stderr, rewrite.
            error_msg = stderr
            print(f"Error: {error_msg}", file=sys.stderr)
            
            if re.search(r'NameError: name .*(symbols?|integrate?|sin?|pi).*', error_msg):
                # Fix: Add import.
                code = "import sympy as sp\nfrom sympy import *\n" + code.replace('sympy.', 'sp.').replace('symbols', 'sp.symbols')
            elif 'SyntaxError' in error_msg:
                # Fix parse (demo).
                code = code.replace('pi', 'sympy.pi')  # Common.
            else:
                print("Unfixable error", file=sys.stderr)
                break
                
        except subprocess.TimeoutExpired:
            print("Timeout - infinite loop?", file=sys.stderr)
            os.unlink(temp_path)
        except Exception as e:
            traceback.print_exc(file=sys.stderr)
            if 'temp_path' in locals():
                os.unlink(temp_path)
    
    return "Failed after max_iters"

# Test: Failing initial -> fixes to import sympy.
if __name__ == "__main__":
    result = self_correcting_engine("Integrate sin(x)^2 from 0 to pi symbolically.")
    print("Final Result:", result)  # pi/2


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os
import asyncio
import time
from collections import defaultdict, deque
from ibm_watson import NaturalLanguageUnderstandingV2
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator

# Reuse AsyncWatsonNLU from Exercise 1 (copied for completeness)
class AsyncWatsonNLU:
    # ... (exact same as Exercise 1)

async def financial_stream():
    """Simulate 100 financial/AI news with relations."""
    base_texts = [
        "Elon Musk acquires xAI using Twitter funds.",
        "Google partners with IBM Watson on hybrid AI agents.",
        "Apple sues Samsung over patents in California.",
        "OpenAI invests in Anthropic led by Dario Amodei.",
        # ... vary 20 base *5 =100
    ] * 5
    texts = base_texts[:100]
    for text in texts:
        if len(text) > 5000:  # Scalability: chunk long texts
            chunks = [text[i:i+3000] for i in range(0, len(text), 3000)]
            for chunk in chunks:
                yield chunk
        else:
            yield text
        await asyncio.sleep(0.05)  # Faster for 100

async def main():
    url = os.getenv('WATSON_URL')
    api_key = os.getenv('WATSON_API_KEY')
    semaphore = asyncio.Semaphore(5)  # Lower for relations compute
    kg = defaultdict(list)  # subject_text: [(predicate_type, object_text), ...]
    lock = asyncio.Lock()
    start_time = time.perf_counter()

    async with AsyncWatsonNLU(url, api_key) as watson:
        async for text in financial_stream():
            if not text.strip():
                continue
            async with semaphore:
                try:
                    result = await watson.analyze(
                        text,
                        features={'relations': {'core_model': 'latest'}, 'entities': {}}
                    )
                    relations = result.get('relations', [])  # EAFP
                    async with lock:
                        for rel in relations:
                            score = rel.get('score', 0)
                            if score > 0.6:
                                sub_text = rel['subject']['text']
                                pred_type = rel['type']
                                obj_text = rel['object']['text']
                                kg[sub_text].append((pred_type, obj_text))
                except (KeyError, IndexError, Exception) as e:
                    print(f"Error (retry with backoff skipped): {e}")
                    await asyncio.sleep(0.1)  # Simple backoff
                    continue

    # Stats & top
    elapsed = time.perf_counter() - start_time
    degrees = {sub: len(rels) for sub, rels in kg.items()}
    top_subs = sorted(degrees.items(), key=lambda x: x[1], reverse=True)[:5]
    print(f"KG Nodes: {len(kg)}, Processed in {elapsed:.2f}s")
    print("Top 5 subjects by degree:", top_subs)
    sample_sub = next(iter(kg))
    sample_chain = kg[sample_sub][0] if kg[sample_sub] else None
    if sample_chain:
        pred, obj = sample_chain
        print(f"Follows: {sample_sub} --{pred}--> {obj}")

    # Bonus DOT sample KG
    dot = '''
digraph KG {
    "Elon Musk" -> "xAI" [label="acquires"];
    "Google" -> "IBM Watson" [label="partners"];
}
'''
    print("Sample KG DOT:\n" + dot)

# asyncio.run(main())

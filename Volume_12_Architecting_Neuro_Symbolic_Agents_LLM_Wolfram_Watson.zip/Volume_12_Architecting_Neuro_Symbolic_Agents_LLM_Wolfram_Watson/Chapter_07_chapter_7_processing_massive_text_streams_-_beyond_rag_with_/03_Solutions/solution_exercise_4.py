
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
import asyncio
import hashlib
import time
import re
from collections import OrderedDict
from ibm_watson import NaturalLanguageUnderstandingV2
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator

# Reuse AsyncWatsonNLU

class AsyncCache:
    """Thread-safe LRU cache with TTL."""
    def __init__(self, maxsize=128, ttl=300):
        self.cache = OrderedDict()
        self.lock = asyncio.Lock()
        self.ttl = ttl
        self.hits = 0
        self.calls = 0

    async def get(self, key):
        async with self.lock:
            if key in self.cache:
                self.hits += 1
                self.cache.move_to_end(key)
                return self.cache[key]
            return None

    async def set(self, key, value):
        async with self.lock:
            self.cache[key] = (value, time.time())
            self.cache.move_to_end(key)
            if len(self.cache) > 128:
                self.cache.popitem(last=False)
            # TTL cleanup task separate

async def chunk_text(text: str, max_chunk=50000):
    """Semantic chunking: sentences + entity-like boundaries."""
    # Simple regex for sentences/entities
    sentences = re.split(r'(?<=[.!?])\s+', text)
    chunks = []
    current = ""
    for sent in sentences:
        if len(current + sent) > max_chunk:
            if current:
                chunks.append(current.strip())
            current = sent
        else:
            current += " " + sent
    if current:
        chunks.append(current)
    return chunks

async def huge_docs_stream():
    long_text = "Long debate on AI... " * 2000  # ~10k+
    for _ in range(20):
        yield long_text
        await asyncio.sleep(0.2)

async def main():
    url = os.getenv('WATSON_URL')
    api_key = os.getenv('WATSON_API_KEY')
    semaphore = asyncio.Semaphore(10)
    cache = AsyncCache()
    total_entities = set()
    latencies = []
    calls = 0

    async with AsyncWatsonNLU(url, api_key) as watson:
        async for doc in huge_docs_stream():
            chunks = await chunk_text(doc, 50000)
            tasks = []
            for chunk in chunks:
                key = hashlib.md5(chunk.encode()[:100]).hexdigest()
                cached = await cache.get(key)
                if cached:
                    result = cached
                else:
                    calls += 1
                    start_lat = time.perf_counter()
                    async with semaphore:
                        result = await watson.analyze(
                            chunk,
                            features={'entities': {'limit':50}, 'relations':{}, 'concepts':{}}
                        )
                    lat = (time.perf_counter() - start_lat) * 1000
                    latencies.append(lat)
                    await cache.set(key, result)

                # Aggregate (EAFP)
                try:
                    for ent in result['entities']:
                        total_entities.add(ent['text'])
                except (KeyError, Exception):
                    pass
            await asyncio.gather(*tasks, return_exceptions=True)  # Prefetch sim

    avg_lat = sum(latencies)/len(latencies) if latencies else 0
    print(f"Cache Hits: {cache.hits}, Calls: {calls}, Latency: {avg_lat:.0f}ms")
    print(f"Processed Entities: {len(total_entities)}")

    # Bonus DOT
    dot = '''
digraph ChunkCache {
    Stream -> Chunk [label="Sentence/Entity Split"];
    Chunk -> Cache [label="Hash Key"];
    Cache -> Watson? [label="Miss"];
    Watson -> Filter -> Output;
}
'''
    print("DOT:\n" + dot)

# asyncio.run(main())


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
import asyncio
import json
import time
from collections import defaultdict
from ibm_watson import NaturalLanguageUnderstandingV2
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator

# Reuse AsyncWatsonNLU from prior

async def llm_query(prompt: str) -> str:
    """Mock LLM: returns JSON-like summary str."""
    summary = f"Summary: {prompt[:100]} LLMs need symbolic grounding like Watson over RAG."
    return json.dumps({"summary": summary})

async def extract_entities(result):
    """Helper: EAFP entity texts."""
    return {ent['text'] for ent in result.get('entities', [])}

async def main():
    url = os.getenv('WATSON_URL')
    api_key = os.getenv('WATSON_API_KEY')
    semaphore = asyncio.Semaphore(8)
    verified_facts = []
    hallucination_flags = 0
    lock = asyncio.Lock()
    start_time = time.perf_counter()

    async def debate_stream():
        texts = ["LLMs vs. Symbolic AI: RAG insufficient, Watson provides entities/relations."] * 75
        for t in texts:
            yield t.strip()
            await asyncio.sleep(0.08)

    async with AsyncWatsonNLU(url, api_key) as watson:
        async for text in debate_stream():
            if len(text) > 3000:
                text = text[:3000]  # Chunk limit
            if not text:
                continue
            async with semaphore:
                try:
                    # Step 1: Watson on original
                    orig_result = await watson.analyze(
                        text,
                        features={'concepts': {}, 'entities': {'limit': 50}, 'relations': {}}
                    )
                    orig_ents = await extract_entities(orig_result)

                    # Step 2: Parallel LLM summary
                    prompt = f"Summarize debate: {json.dumps(orig_result)}"
                    llm_resp_str = await llm_query(prompt)
                    llm_resp = json.loads(llm_resp_str)  # EAFP
                    summary = llm_resp['summary']

                    # Step 3: Watson verify summary (parallel via gather)
                    sum_result, _ = await asyncio.gather(
                        watson.analyze(summary, features={'entities': {'limit': 50}}),
                        asyncio.sleep(0)  # Placeholder
                    )
                    sum_ents = await extract_entities(sum_result)

                    # Score: overlap >70%
                    overlap = len(orig_ents & sum_ents) / len(orig_ents) if orig_ents else 0
                    fact = {"original": text[:50], "summary": summary[:50], "score": overlap}
                    async with lock:
                        if overlap > 0.7:
                            verified_facts.append(fact)
                        else:
                            hallucination_flags += 1

                except (KeyError, IndexError, json.JSONDecodeError, Exception) as e:
                    hallucination_flags += 1
                    print(f"Verification error: {e}")
                    continue

    elapsed = time.perf_counter() - start_time
    print(f"Verified: {len(verified_facts)}, Hallucinated: {hallucination_flags}, Time: {elapsed:.2f}s")
    if verified_facts:
        print("Sample verified:", verified_facts[0])

    # Bonus DOT
    dot = '''
digraph Hybrid {
    Stream -> Watson1 [label="Facts"];
    Watson1 -> LLM;
    LLM -> Watson2 [label="Verify"];
    Watson2 -> Score [label=">70% match?"];
}
'''
    print("Neuro-symbolic DOT:\n" + dot)

# asyncio.run(main())

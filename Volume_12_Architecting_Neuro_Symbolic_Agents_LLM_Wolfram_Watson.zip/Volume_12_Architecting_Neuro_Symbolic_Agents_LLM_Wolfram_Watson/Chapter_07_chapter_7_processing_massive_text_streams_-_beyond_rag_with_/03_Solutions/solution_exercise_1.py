
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
import asyncio
import hashlib
from collections import defaultdict
from ibm_watson import NaturalLanguageUnderstandingV2
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
import time

class AsyncWatsonNLU:
    """Async context manager for Watson NLU client using thread executor for sync SDK."""
    def __init__(self, url: str, api_key: str, version: str = '2022-04-07'):
        self.url = url
        self.api_key = api_key
        self.version = version
        self.client = None

    async def __aenter__(self):
        authenticator = IAMAuthenticator(self.api_key)
        self.client = NaturalLanguageUnderstandingV2(version=self.version, authenticator=authenticator)
        self.client.set_service_url(self.url)
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        pass  # SDK has no explicit close

    async def analyze(self, text: str, features: dict):
        """Run sync analyze in thread executor."""
        loop = asyncio.get_running_loop()
        future = await loop.run_in_executor(
            None,
            lambda: self.client.analyze(text, features=features).get_result()
        )
        return future

async def generate_stream():
    """Simulate stream of 50 news blurbs with 0.1s delays."""
    texts = [
        "In a breakthrough, OpenAI partners with Wolfram Alpha for neuro-symbolic AI, announced at NeurIPS 2024 in Vancouver.",
        "IBM Watson leads entity extraction in New York, surpassing RAG limitations.",
        "Elon Musk from Tesla discusses AI ethics at Davos with Satya Nadella of Microsoft.",
        # ... (repeat/vary similar 47 texts for demo; in prod, yield from real source)
    ] * 2  # Duplicate to reach ~50
    texts = texts[:50]
    for text in texts:
        yield text
        await asyncio.sleep(0.1)

async def main():
    url = os.getenv('WATSON_URL')
    api_key = os.getenv('WATSON_API_KEY')
    if not url or not api_key:
        print("Set WATSON_URL and WATSON_API_KEY")
        return

    semaphore = asyncio.Semaphore(10)  # Max 10 concurrent
    entity_saliences = defaultdict(list)  # text: [sal1, sal2, ...]
    lock = asyncio.Lock()
    start_time = time.perf_counter()

    async with AsyncWatsonNLU(url, api_key) as watson:
        async for text in generate_stream():
            if not text or not text.strip():
                continue
            async with semaphore:
                try:
                    # EAFP: assume 'entities' exists
                    result = await watson.analyze(
                        text,
                        features={'entities': {'model': 'latest', 'limit': 50}}
                    )
                    entities = result['entities']
                    async with lock:
                        for ent in entities:
                            ent_type = ent.get('type')
                            salience = ent.get('salience', 0)
                            if ent_type in ['PERSON', 'ORGANIZATION', 'LOCATION'] and salience > 0.5:
                                text_key = ent['text']
                                entity_saliences[text_key].append(salience)
                except (KeyError, IndexError, Exception) as e:
                    print(f"Invalid response (retry skipped): {e}")
                    continue  # Edge: malformed, no retry for simplicity (<2s goal)

    # Aggregate avg salience, top 10
    avg_salience = {k: sum(v) / len(v) for k, v in entity_saliences.items()}
    top_10 = sorted(avg_salience.items(), key=lambda x: x[1], reverse=True)[:10]
    elapsed = time.perf_counter() - start_time
    print(f"Processed 50 items in {elapsed:.2f}s (<2s excl. simulated delays)")
    for text, avg in top_10:
        print(f"Entity: {text} (Avg Salience: {avg:.2f})")

    # Bonus: Graphviz DOT for pipeline
    dot = '''
digraph Pipeline {
    Stream -> "Async Manager" -> Watson -> Filter -> Output;
    "Filter" [label="Salience >0.5 & Types Filter\\nLock-Protected Dedup"];
    Semaphore [shape=box, label="Semaphore(10)"];
    "Async Manager" -> Semaphore;
}
'''
    print("Graphviz DOT:\n" + dot)

# Run: asyncio.run(main())

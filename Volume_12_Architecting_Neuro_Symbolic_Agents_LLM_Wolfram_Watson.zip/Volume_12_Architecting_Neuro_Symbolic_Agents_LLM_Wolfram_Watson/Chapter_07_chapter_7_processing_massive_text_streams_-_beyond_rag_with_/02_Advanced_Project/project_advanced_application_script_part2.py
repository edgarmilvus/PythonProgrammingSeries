
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script_part2.py
# Description: Advanced Application Script
# ==========================================

# Advanced Flask Blueprint for Watson NLU-Powered Text Stream Processing
# Solves: Real-time KG construction from massive financial news streams for compliance monitoring.
# Integrates: Context managers (DB/File I/O), SQLAlchemy ORM (KG persistence),
#             Flask Blueprint (modular scaling), Watson NLU (entities/semantic_roles for relations),
#             Chunking/caching (latency optimization), grounded querying (beyond RAG).

import os
import logging
from typing import Generator, List, Dict, Any
from contextlib import contextmanager
from flask import Blueprint, request, jsonify, current_app, Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import IntegrityError
from ibm_watson import NaturalLanguageUnderstandingV1
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
from ibm_cloud_sdk_core.exceptions import ApiException
from werkzeug.utils import secure_filename
import hashlib  # For dedup hashing

# Configure logging for production traces
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# =====================================
# WATSON NLU INITIALIZATION (Replace with your credentials)
# =====================================
API_KEY = os.getenv('WATSON_API_KEY', 'PASTE_YOUR_API_KEY_HERE')  # From IBM Cloud Manage
SERVICE_URL = os.getenv('WATSON_URL', 'PASTE_YOUR_SERVICE_URL_HERE')  # e.g., https://api.us-south...

authenticator = IAMAuthenticator(API_KEY)
nlu_service = NaturalLanguageUnderstandingV1(
    version='2022-04-07',
    authenticator=authenticator
)
nlu_service.set_service_url(SERVICE_URL)

# =====================================
# SQLAlchemy Models for Dynamic KG (Entities <-> Relations)
# =====================================
db = SQLAlchemy()

class Entity(db.Model):
    """Entity table: Stores unique text spans with type/confidence from Watson."""
    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.String(500), unique=True, nullable=False)  # Deduped
    type_label = db.Column(db.String(100), nullable=False)  # e.g., 'Person', 'Organization'
    confidence = db.Column(db.Float, default=0.0)
    relations_as_subject = db.relationship('Relation', backref='subject_entity', lazy='dynamic')
    relations_as_object = db.relationship('Relation', backref='object_entity', lazy='dynamic')

class Relation(db.Model):
    """Relation table: Semantic triples from Watson semantic_roles (subj-action-obj)."""
    id = db.Column(db.Integer, primary_key=True)
    subject_id = db.Column(db.Integer, db.ForeignKey('entity.id'), nullable=False)
    object_id = db.Column(db.Integer, db.ForeignKey('entity.id'), nullable=False)
    action = db.Column(db.String(200), nullable=False)  # e.g., 'acquired', 'announced'
    confidence = db.Column(db.Float, default=0.0)

# =====================================
# Context Managers: Safe DB Sessions & File Streaming
# =====================================
@contextmanager
def get_db_session() -> Generator[db.Session, None, None]:
    """Context manager for transactional DB sessions - auto-commit/rollback."""
    session = db.session
    try:
        yield session
        session.commit()
        logger.info("DB transaction committed.")
    except IntegrityError as e:
        session.rollback()
        logger.warning(f"Deduplication conflict: {e}")
        raise
    except Exception as e:
        session.rollback()
        logger.error(f"DB error: {e}")
        raise
    finally:
        session.close()

@contextmanager
def stream_file_chunks(file_path: str, chunk_size: int = 10000) -> Generator[str, None, None]:
    """Context manager for safe, chunked reading of massive files (GB-scale)."""
    with open(file_path, 'r', encoding='utf-8') as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            yield chunk
    logger.info(f"Streamed file: {file_path}")

# Global cache for frequent entities (LRU-like, evict after 1000)
entity_cache: Dict[str, Entity] = {}
CACHE_LIMIT = 1000

def get_or_create_entity(session: db.Session, text: str, type_label: str, confidence: float) -> Entity:
    """Cached entity creation/dedup - optimizes for repetitive streams."""
    cache_key = hashlib.md5(text.encode()).hexdigest()
    if cache_key in entity_cache:
        return entity_cache[cache_key]
    entity = session.query(Entity).filter_by(text=text).first()
    if not entity:
        entity = Entity(text=text, type_label=type_label, confidence=confidence)
        session.add(entity)
        session.flush()  # Assign ID without commit
    entity_cache[cache_key] = entity
    if len(entity_cache) > CACHE_LIMIT:
        entity_cache.pop(next(iter(entity_cache)))
    return entity

# =====================================
# Flask Blueprint: Modular NLU Processor
# =====================================
bp = Blueprint('watson_nlu_processor', __name__, url_prefix='/api/v1')

@bp.route('/process_stream', methods=['POST'])
def process_text_stream() -> Dict[str, Any]:
    """Core endpoint: Process uploaded file stream with Watson, build KG.
    Handles massive inputs via chunking; extracts entities/relations."""
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'Empty file'}), 400
    
    filename = secure_filename(file.filename)
    temp_path = f"/tmp/{filename}"
    file.save(temp_path)
    
    stats = {'entities': 0, 'relations': 0, 'chunks_processed': 0}
    
    try:
        with get_db_session() as session:
            with stream_file_chunks(temp_path) as chunk_gen:
                for chunk in chunk_gen:
                    # Watson features: entities + semantic_roles (for relations)
                    features = {
                        'entities': {'model': 'latest'},  # Typed entities w/ salience
                        'semantic_roles': {}  # Subj-action-obj triples
                    }
                    try:
                        watson_resp = nlu_service.analyze(
                            text=chunk,
                            features=features
                        ).get_result()
                        
                        # Extract & persist entities
                        for ent_data in watson_resp.get('entities', []):
                            ent = get_or_create_entity(
                                session, ent_data['text'], ent_data['type'],
                                ent_data['confidence']
                            )
                            stats['entities'] += 1
                        
                        # Extract relations from semantic_roles
                        for role in watson_resp.get('semantic_roles', []):
                            subj_text = role['subject']['text']
                            obj_text = role.get('object', {}).get('text', '')
                            if obj_text:
                                subj = get_or_create_entity(session, subj_text, 'SUBJECT', 0.9)
                                obj = get_or_create_entity(session, obj_text, 'OBJECT', 0.9)
                                rel = Relation(
                                    subject_id=subj.id,
                                    object_id=obj.id,
                                    action=role['action']['text'],
                                    confidence=role['confidence']
                                )
                                session.add(rel)
                                stats['relations'] += 1
                        
                        stats['chunks_processed'] += 1
                        
                    except ApiException as e:
                        logger.error(f"Watson API error: {e}")
                        continue
                    
        os.remove(temp_path)  # Cleanup
        logger.info(f"KG updated: {stats}")
        return jsonify({'status': 'success', 'stats': stats})
    
    except Exception as e:
        logger.error(f"Processing failed: {e}")
        return jsonify({'error': str(e)}), 500

@bp.route('/query_kg', methods=['GET'])
def query_knowledge_graph() -> Dict[str, Any]:
    """Query endpoint: Retrieve grounded relations/entities (federated, cached).
    E.g., ?q=JPMorgan -> relations like {'JPMorgan': ['acquired Bear Stearns']}.
    Beyond RAG: Structured, verifiable triples."""
    query_term = request.args.get('q', '').lower().strip()
    if not query_term:
        return jsonify({'error': 'Query term required'}), 400
    
    with get_db_session() as session:
        # Join query for relations involving query_term
        results = session.query(Relation, Entity).join(Entity, Relation.subject_id == Entity.id).filter(
            Entity.text.ilike(f'%{query_term}%')
        ).limit(50).all()
        
        kg_slice = []
        for rel, subj_ent in results:
            obj_ent = session.query(Entity).get(rel.object_id)
            kg_slice.append({
                'subject': subj_ent.text,
                'action': rel.action,
                'object': obj_ent.text,
                'confidence': rel.confidence
            })
        
        return jsonify({'query': query_term, 'kg_slice': kg_slice, 'count': len(kg_slice)})

# =====================================
# Main App Factory: Register Blueprint & Init DB
# =====================================
def create_app() -> Flask:
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///news_kg.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB uploads for streams
    
    db.init_app(app)
    
    # Create tables on startup
    with app.app_context():
        db.create_all()
    
    app.register_blueprint(bp)
    return app

if __name__ == '__main__':
    app = create_app()
    logger.info("Neuro-Symbolic KG Processor ready at http://localhost:5000/api/v1/")
    app.run(host='0.0.0.0', port=5000, debug=True)

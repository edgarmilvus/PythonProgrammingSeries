
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example_part2.py
# Description: Basic Code Example
# ==========================================

# pip install ibm-watson ibm-cloud-sdk-core  # Run this first in terminal if not installed

import os
import tempfile
from collections import Counter
from ibm_watson import NaturalLanguageUnderstandingV1
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
from ibm_cloud_sdk_core.exceptions import ApiException

# ========================================
# STEP 1: CONFIGURE YOUR WATSON CREDENTIALS
# ========================================
# Replace with your values from IBM Cloud (include 'apikey:' prefix for APIKEY)
API_KEY = os.getenv('WATSON_API_KEY', 'apikey:YOUR_API_KEY_HERE')  # Secure: Use env var!
SERVICE_URL = os.getenv('WATSON_URL', 'https://YOUR_SERVICE_URL_HERE')

# Authenticate and initialize NLU client
authenticator = IAMAuthenticator(API_KEY)
nlu = NaturalLanguageUnderstandingV1(
    version='2022-04-07',  # Stable version supporting entities/relations
    authenticator=authenticator
)
nlu.set_service_url(SERVICE_URL)

# ========================================
# STEP 2: GENERATE SIMULATED MASSIVE TEXT STREAM FILE
# ========================================
# Create a realistic ~10K-line news/log file (simulates TB-scale stream chunked)
NUM_LINES = 10000  # Scale up for testing memory efficiency
sample_lines = [
    "Tim Cook, CEO of Apple Inc., announced a $100 billion investment in AI chips amid tensions with China.",
    "Server error: Transfer $5000 to offshore account held by John Doe at Bank of Cayman.",
    "Breaking: Elon Musk of Tesla sues OpenAI for breach; stock dips 5%.",
    "Weather: Hurricane hits Florida, evacuations ordered by Gov. Ron DeSantis.",
    # Repeat patterns to simulate volume/diversity
] * (NUM_LINES // 5 + 1)

with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
    input_file = f.name
    for line in sample_lines[:NUM_LINES]:
        f.write(line + '\n')

print(f"Generated stream file: {input_file} ({NUM_LINES} lines)")

# ========================================
# STEP 3: PROCESS STREAM WITH WATSON NLU (ITERATIVE, MEMORY-EFFICIENT)
# ========================================
entity_counter = Counter()  # Aggregate entities across stream
analyzed_count = 0

# Key: Iterate DIRECTLY over file object (no memory load!)
with open(input_file, 'r', encoding='utf-8') as file_obj:
    for line_num, line in enumerate(file_obj, 1):
        line = line.strip()
        if not line:  # Skip empty lines
            continue
        
        try:
            # Analyze chunk with Watson: Extract entities only (fastest for streams)
            response = nlu.analyze(
                text=line,
                features={
                    'entities': {
                        'model': 'en-news'  # Domain-tuned model for news/logs
                    }
                },
                language='en'
            ).get_result()
            
            # Extract & count entities (text, type, confidence)
            entities = response.get('entities', [])
            for entity in entities:
                ent_text = entity['text'].lower()
                ent_type = entity['type']
                confidence = entity['confidence']
                if confidence > 0.7:  # Threshold for reliability (anti-hallucination)
                    entity_counter[f"{ent_type}:{ent_text}"] += 1
            
            analyzed_count += 1
            
            # Throttling simulation: Process in batches to avoid rate limits
            if analyzed_count % 100 == 0:
                print(f"Processed {analyzed_count} lines...")
                
        except ApiException as e:
            print(f"API Error on line {line_num}: {e}")
            continue
        except Exception as e:
            print(f"Unexpected error on line {line_num}: {e}")
            continue

# ========================================
# STEP 4: OUTPUT AGGREGATED INSIGHTS (FOR LLM/KG INTEGRATION)
# ========================================
print("\n=== STREAM ANALYSIS COMPLETE ===")
print(f"Analyzed {analyzed_count} lines with Watson NLU.")
print("\nTop Entities (Type:Text - Count):")
for ent, count in entity_counter.most_common(10):
    print(f"  {ent}: {count}")

# Cleanup
os.unlink(input_file)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os
import re
import json
import time
from typing import List, Dict
import requests
from openai import OpenAI
from ibm_watson import DiscoveryV1
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator

class CriticLoop:
    def __init__(self, wolfram_app_id: str, llm_client: OpenAI, watson_url: str, watson_api_key: str,
                 watson_env_id: str, watson_coll_id: str):
        self.wolfram_app_id = wolfram_app_id
        self.llm_client = llm_client
        authenticator = IAMAuthenticator(watson_api_key)
        self.discovery = DiscoveryV1(version='2022-10-15', authenticator=authenticator)
        self.discovery.set_service_url(watson_url)
        self.watson_env_id = watson_env_id
        self.watson_coll_id = watson_coll_id

    # generate_draft, _log_to_json same as Exercise 1 (omitted for brevity; extend with domain="biology|physics|history")

    def generate_draft(self, query: str, feedback: str = "") -> str:
        # Same as Ex1, but append "Focus on accurate facts for biology/physics/history."
        prompt = f"Explain accurately (<200 words): {query}."
        if feedback:
            prompt += f"\n\nFix failures: {feedback}."
        response = self.llm_client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=300
        )
        return response.choices[0].message.content.strip()

    def extract_claims(self, draft: str) -> List[str]:
        # Enhanced for facts: equations + noun phrases with numbers/entities (e.g., "Chlorophyll absorbs 680nm")
        eq_num_pattern = r'([a-zA-Z][\w\s]*\s*=\s*[\w\s\+\-\*/\(\)\.\d]+[\w\s\d\.]*)'
        fact_pattern = r'([A-Z][a-z]+(?:\s+[a-z]+)*\s+(?:\d+(?:\.\d+)?[a-zA-Znm%s/deg]+|\d+nm|\d+%))'
        claims = (re.findall(eq_num_pattern, draft, re.IGNORECASE | re.MULTILINE) +
                  re.findall(fact_pattern, draft, re.IGNORECASE | re.MULTILINE))
        return list(set([c.strip() for c in claims if len(c) > 5]))[:5]

    def classify_claim(self, claim: str) -> str:
        math_indicators = r'[=+\-*/\s(?:sin|cos|tan|m/s|deg|g=)]'
        return "math" if re.search(math_indicators, claim, re.I) else "fact"

    def verify_with_wolfram(self, claims: List[str]) -> Dict[str, bool]:
        # Identical to Exercise 1
        pass  # (code same as Ex1)

    def verify_with_watson(self, claims: List[str]) -> Dict[str, bool]:
        results = {}
        for claim in claims:
            try:
                res = self.discovery.query(
                    environment_id=self.watson_env_id,
                    collection_id=self.watson_coll_id,
                    natural_language_query=claim,
                    count=3
                ).get_result()
                matching = res.get("matching_results", [])
                # Pass if top result score >0.8 (high relevance/confidence in corpus)
                results[claim] = bool(matching and matching[0]["result_metadata"]["score"] > 0.8)
            except Exception:
                results[claim] = False  # Fallback unverified
        return results

    def run_critic_loop(self, query: str, max_iters: int = 4) -> str:
        # Extended log with claim_types, domain_accuracy
        log = {
            "timestamp": time.time(),
            "query": query,
            "iterations": 0,
            "claim_types": {},  # {"math": acc, "fact": acc}
            "verification_time": 0,
            "failed_claims_history": [],
            "final_draft": ""
        }
        feedback = ""
        start_time = time.time()
        for iteration in range(max_iters):
            draft = self.generate_draft(query, feedback)
            claims = self.extract_claims(draft)
            if not claims:
                # Same success logic as Ex1
                pass
            verifs = {}
            math_claims = [c for c in claims if self.classify_claim(c) == "math"]
            fact_claims = [c for c in claims if self.classify_claim(c) == "fact"]
            if math_claims:
                verifs.update(self.verify_with_wolfram(math_claims))
            if fact_claims:
                verifs.update(self.verify_with_watson(fact_claims))
            failed_claims = [c for c, v in verifs.items() if not v]
            if not failed_claims:
                # Compute domain acc
                math_acc = sum(1 for c in math_claims if verifs[c]) / len(math_claims) if math_claims else 1.0
                fact_acc = sum(1 for c in fact_claims if verifs[c]) / len(fact_claims) if fact_claims else 1.0
                log["claim_types"] = {"math": math_acc, "fact": fact_acc}
                log["iterations"] = iteration + 1
                log["verification_time"] = time.time() - start_time
                log["final_draft"] = draft
                self._log_to_json("hybrid_log.json", log)  # Separate log file
                return draft
            fail_reasons = {c: "fail_wolfram" if self.classify_claim(c) == "math" else "low_conf_watson" for c in failed_claims}
            feedback = f"{{failures: {fail_reasons}}}"
            log["failed_claims_history"].append(failed_claims)
        # Max iters fallback as Ex1
        log["verification_time"] = time.time() - start_time
        self._log_to_json("hybrid_log.json", log)
        return draft

    def _log_to_json(self, filename: str, log_entry: Dict):
        with open(filename, "a") as f:
            json.dump(log_entry, f)
            f.write("\n")

# Usage: Pre-populate Watson Discovery corpus with biology/history PDFs via dashboard
# Tests: Set env vars for WATSON_*, run on "Photosynthesis steps, efficiency, discoverer"
if __name__ == "__main__":
    # ... init with os.environ['WATSON_*'], test 5 queries/domain
    pass

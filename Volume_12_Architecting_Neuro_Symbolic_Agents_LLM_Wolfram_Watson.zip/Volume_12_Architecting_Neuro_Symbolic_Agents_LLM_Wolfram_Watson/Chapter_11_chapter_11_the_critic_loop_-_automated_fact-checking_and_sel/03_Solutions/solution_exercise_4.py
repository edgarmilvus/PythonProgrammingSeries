
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
import re
import json
import time
import asyncio
import aiohttp
from typing import List, Dict
from openai import AsyncOpenAI
# Assume aiohttp for Watson/Wolfram (REST)

class AsyncCriticLoop:
    def __init__(self, wolfram_app_id: str, openai_key: str, timeout: int = 10):
        self.wolfram_app_id = wolfram_app_id
        self.openai_client = AsyncOpenAI(api_key=openai_key)
        self.timeout = aiohttp.ClientTimeout(total=timeout)

    async def generate_draft(self, query: str, feedback: str = "") -> str:
        prompt = f"Explain (<200 words): {query}."
        if feedback:
            prompt += f"\nFix: {feedback}."
        resp = await self.openai_client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=300
        )
        return resp.choices[0].message.content.strip()

    async def verify_with_wolfram(self, claims: List[str]) -> Dict[str, bool]:
        results = {}
        connector = aiohttp.TCPConnector(limit=10)
        async with aiohttp.ClientSession(connector=connector, timeout=self.timeout) as session:
            tasks = [self._verify_wolfram_single(session, c) for c in claims]
            partial_results = await asyncio.gather(*tasks, return_exceptions=True)
            for claim, res in zip(claims, partial_results):
                results[claim] = res if isinstance(res, bool) else False
        return results

    async def _verify_wolfram_single(self, session: aiohttp.ClientSession, claim: str) -> bool:
        url = "http://api.wolframalpha.com/v2/query"
        params = {"input": claim, "appid": self.wolfram_app_id, "output": "json"}
        async with session.get(url, params=params) as resp:
            if resp.status == 200:
                data = await resp.json()
                qr = data["queryresult"]
                return qr["success"] and (qr.get("pods") or qr.get("short"))
            return False

    # extract_claims same sync as Ex1 (fast regex)

    async def run_async_loop(self, query: str, max_iters: int = 5) -> str:
        log = {"query": query, "latencies": [], "iterations": 0}  # Metrics
        feedback = ""
        for it in range(max_iters):
            start = time.perf_counter()
            draft = await self.generate_draft(query, feedback)
            claims = self.extract_claims(draft)  # Sync ok
            if claims:
                verifs = await self.verify_with_wolfram(claims)
                failed = [c for c, v in verifs.items() if not v]
                log["latencies"].append(time.perf_counter() - start)
            else:
                failed = []
            if not failed:
                log["iterations"] = it + 1
                # Log latencies histogram-ready
                with open("async_log.json", "a") as f:
                    json.dump(log, f)
                    f.write("\n")
                return draft
            feedback = " | ".join(failed)
        return draft

# Queue worker example
async def main():
    loop = AsyncCriticLoop(os.environ['WOLFRAM_APP_ID'], os.environ['OPENAI_API_KEY'])
    queue = asyncio.Queue()
    async def worker():
        while True:
            query = await queue.get()
            result = await loop.run_async_loop(query)
            print(result)
            queue.task_done()
    workers = [asyncio.create_task(worker()) for _ in range(5)]
    # Enqueue 50 queries
    queries = ["test"] * 50
    for q in queries:
        await queue.put(q)
    await queue.join()
    for w in workers:
        w.cancel()

if __name__ == "__main__":
    asyncio.run(main())
# Tests: pytest-asyncio, mock aiohttp, assert avg <3s
# Flask: Quart or app.run_in_executor for sync compat


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
from datetime import datetime
from flask import Flask, Blueprint, request, jsonify, g, current_app
from flask_sqlalchemy import SQLAlchemy
from werkzeug.exceptions import NotFound
import pytest  # For tests

# Assume CriticLoop from Ex2 imported/defined here (hybrid version)
# from critic_loop import CriticLoop  # Modular import

db = SQLAlchemy()

class VerificationLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    query = db.Column(db.String(500), nullable=False)
    iterations = db.Column(db.Integer)
    accuracy = db.Column(db.Float)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

# config.py equivalent
class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-key'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///critic.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    WOLFRAM_APP_ID = os.environ.get('WOLFRAM_APP_ID')
    OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')
    WATSON_URL = os.environ.get('WATSON_URL')
    WATSON_API_KEY = os.environ.get('WATSON_API_KEY')
    WATSON_ENV_ID = os.environ.get('WATSON_ENV_ID')
    WATSON_COLL_ID = os.environ.get('WATSON_COLL_ID')

class DevelopmentConfig(Config):
    DEBUG = True
    TESTING = True
    API_MOCK = os.environ.get('API_MOCK', 'True').lower() == 'true'

class ProductionConfig(Config):
    DEBUG = False
    API_MOCK = False

# factory.py
def create_app(config_name: str = 'development') -> Flask:
    app = Flask(__name__)
    app.config.from_object(f'{__name__.split(".")[0]}.Config.{config_name.title()}Config')
    db.init_app(app)

    # Init CriticLoop (hybrid from Ex1+2)
    from openai import OpenAI  # Assume Ex2 CriticLoop
    llm_client = OpenAI(api_key=app.config['OPENAI_API_KEY'])
    critic_loop = CriticLoop(
        app.config['WOLFRAM_APP_ID'], llm_client,
        app.config['WATSON_URL'], app.config['WATSON_API_KEY'],
        app.config['WATSON_ENV_ID'], app.config['WATSON_COLL_ID']
    )
    app.critic_loop = critic_loop  # App-wide, thread-safe for requests/LLM

    with app.app_context():
        db.create_all()

    # Blueprint
    critic_bp = Blueprint('critic', __name__)
    @critic_bp.route('/health', methods=['GET'])
    def health():
        return jsonify({"status": "healthy", "version": "1.0"})

    @critic_bp.route('/verify', methods=['POST'])
    def verify():
        data = request.json
        query = data.get('query')
        max_iters = data.get('max_iters', 4)
        if not query:
            return jsonify({"error": "Missing query"}), 400
        draft = current_app.critic_loop.run_critic_loop(query, max_iters)
        # Log to DB
        log = VerificationLog(
            query=query,
            iterations=1,  # Placeholder; extract from loop log if needed
            accuracy=1.0   # From loop
        )
        db.session.add(log)
        db.session.commit()
        return jsonify({
            "verified_explanation": draft,
            "iterations": 1,
            "accuracy": 1.0,
            "query_id": log.id
        })

    @critic_bp.route('/logs/<int:query_id>', methods=['GET'])
    def get_logs(query_id):
        log = VerificationLog.query.get_or_404(query_id)
        return jsonify({
            "query_id": log.id,
            "query": log.query,
            "iterations": log.iterations,
            "accuracy": log.accuracy,
            "timestamp": log.timestamp.isoformat()
        })

    app.register_blueprint(critic_bp, url_prefix='/critic')
    return app

# Tests (pytest)
def test_verify(client):
    rv = client.post('/critic/verify', json={'query': 'test'})
    assert rv.status_code == 200
    assert 'verified_explanation' in rv.json

def test_health(client):
    rv = client.get('/critic/health')
    assert rv.status_code == 200

@pytest.fixture
def client():
    app = create_app('development')
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

if __name__ == '__main__':
    app = create_app('development')
    app.run()
# Deploy: gunicorn -w 4 'factory:create_app("production")' --bind 0.0.0.0:5000

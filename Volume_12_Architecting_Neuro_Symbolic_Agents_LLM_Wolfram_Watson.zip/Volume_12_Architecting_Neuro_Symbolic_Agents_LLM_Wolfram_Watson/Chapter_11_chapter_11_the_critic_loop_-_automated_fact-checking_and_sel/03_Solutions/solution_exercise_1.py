
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
import re
import json
import time
from typing import List, Dict
import requests
from openai import OpenAI

class CriticLoop:
    def __init__(self, wolfram_app_id: str, llm_client: OpenAI):
        self.wolfram_app_id = wolfram_app_id
        self.llm_client = llm_client

    def generate_draft(self, query: str, feedback: str = "") -> str:
        prompt = f"Provide a concise natural language explanation (<200 words) for the physics problem: {query}."
        if feedback:
            prompt += f"\n\nPrevious draft had errors (verified by Wolfram Alpha). Revise by correcting these specific claims: {feedback}."
        prompt += "\nInclude key equations and numerical results."
        response = self.llm_client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=300,
            temperature=0.3
        )
        return response.choices[0].message.content.strip()

    def extract_claims(self, draft: str) -> List[str]:
        # Regex for equations (e.g., "v = u + at") and numeric results (e.g., "time = 2.45s")
        eq_pattern = r'([a-zA-Z][\w\s]*\s*=\s*[\w\s\+\-\*/\(\)\.\d]+)'
        num_pattern = r'([a-zA-Z]+\s*=\s*[\d\.]+\s*[a-zA-Z%s/]*|[a-zA-Z]+\s*=\s*[\d\.]+\s*(m/s|deg|s|m))'
        claims = re.findall(eq_pattern, draft, re.IGNORECASE | re.MULTILINE) + re.findall(num_pattern, draft, re.IGNORECASE | re.MULTILINE)
        # Format for Wolfram: replace spaces with +, lowercase, unique, max 5
        wolfram_claims = list(set([re.sub(r'\s+', '+', c.strip().lower()) for c in claims if '=' in c]))[:5]
        return wolfram_claims

    def verify_with_wolfram(self, claims: List[str]) -> Dict[str, bool]:
        results = {}
        for claim in claims:
            url = "http://api.wolframalpha.com/v2/query"
            params = {
                "input": claim,
                "appid": self.wolfram_app_id,
                "output": "json",
                "format": "plaintext",
                "parsetimeout": "10"
            }
            try:
                resp = requests.get(url, params=params, timeout=10)
                data = resp.json()
                qr = data["queryresult"]
                # Pass if successful query with pods or short answer (indicates verifiable/no immediate contradiction)
                results[claim] = qr["success"] and (qr.get("pods") or qr.get("short", {}).get("plaintext"))
            except Exception:
                results[claim] = False
        return results

    def run_critic_loop(self, query: str, max_iters: int = 5) -> str:
        log = {
            "timestamp": time.time(),
            "query": query,
            "iterations": 0,
            "failed_claims_history": [],
            "total_claims": 0,
            "passed_claims": 0,
            "accuracy": 0.0,
            "hallucination_rate": 100.0,
            "final_draft": ""
        }
        feedback = ""
        for iteration in range(max_iters):
            draft = self.generate_draft(query, feedback)
            claims = self.extract_claims(draft)
            log["total_claims"] = len(claims)
            if not claims:
                log["final_draft"] = draft
                log["iterations"] = iteration + 1
                log["accuracy"] = 1.0
                log["hallucination_rate"] = 0.0
                self._log_to_json(log)
                return draft
            verifs = self.verify_with_wolfram(claims)
            failed_claims = [c for c, valid in verifs.items() if not valid]
            passed = len(claims) - len(failed_claims)
            if not failed_claims:
                log["passed_claims"] = passed
                log["accuracy"] = passed / log["total_claims"]
                log["hallucination_rate"] = (1 - log["accuracy"]) * 100
                log["final_draft"] = draft
                log["iterations"] = iteration + 1
                self._log_to_json(log)
                return draft
            feedback = " | ".join([f"'{c.replace('+', ' ').title()}' incorrect" for c in failed_claims])
            log["failed_claims_history"].append(failed_claims)
        # Max iters reached: use last draft and compute accuracy
        log["passed_claims"] = passed
        log["accuracy"] = passed / log["total_claims"] if log["total_claims"] else 1.0
        log["hallucination_rate"] = (1 - log["accuracy"]) * 100
        log["final_draft"] = draft
        self._log_to_json(log)
        return draft

    def _log_to_json(self, log_entry: Dict):
        with open("critic_log.json", "a") as f:
            json.dump(log_entry, f)
            f.write("\n")

# Example usage and tests
if __name__ == "__main__":
    wolfram_app_id = os.environ.get("WOLFRAM_APP_ID")
    if not wolfram_app_id:
        raise ValueError("Set WOLFRAM_APP_ID env var")
    llm_client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
    critic = CriticLoop(wolfram_app_id, llm_client)
    test_queries = [
        "Projectile motion: u=20m/s, theta=30deg, g=9.8",
        "Orbital velocity of Earth",
        "Pythagoras for 3-4-5 triangle"
    ]
    for query in test_queries:
        result = critic.run_critic_loop(query)
        print(f"Verified: {result[:100]}...")

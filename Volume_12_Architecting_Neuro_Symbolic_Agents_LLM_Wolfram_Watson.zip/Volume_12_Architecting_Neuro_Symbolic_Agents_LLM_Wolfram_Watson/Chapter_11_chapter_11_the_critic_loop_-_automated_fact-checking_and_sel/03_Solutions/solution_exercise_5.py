
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# Assume base: class PrimaryCritic(CriticLoop): verifies math
# class MetaCritic: watson meta on evidence
# class MultiAgentVerifier: hierarchical run(query)
import os
import re
import json
import time
import asyncio
import argparse
from flask import Flask, Blueprint, render_template_string, jsonify
import plotly.graph_objects as go
import pandas as pd
from openai import AsyncOpenAI  # Async enhanced

class HallucinationMetrics:
    def __init__(self):
        self.sessions = []  # List of {"accuracy": float, "iters": int, "domain": str}
    def update(self, acc: float, iters: int, domain: str):
        self.sessions.append({"accuracy": acc, "iterations": iters, "domain": domain})
    def get_dashboard(self):
        df = pd.DataFrame(self.sessions)
        fig = go.Figure()
        fig.add_trace(go.Histogram(x=df["iterations"], name="Iters Hist"))
        fig.add_trace(go.Scatter(y=df["accuracy"], x=df["iterations"], mode="markers"))
        return fig.to_html()
    def ragh_score(self):  # 1 - avg(acc)
        return 1 - self.sessions[-10:]["accuracy"].mean() if self.sessions else 0

metrics = HallucinationMetrics()

class MultiAgentVerifier:
    def __init__(self, *args):  # Wolfram etc.
        self.primary = PrimaryCritic(...)  # From assumed/Ex1
        self.meta = MetaCritic(...)  # Watson evidence

    async def run(self, query: str, max_iters: int = 7) -> str:
        feedback = ""
        for it in range(max_iters):
            draft = await self.primary.generate_draft(query, feedback)  # Shared
            primary_fail = await self.primary.verify(...)  # Math
            if primary_fail:
                feedback = f"Primary fail: {primary_fail}"
                continue
            meta_fail = await self.meta.verify_evidence(draft)  # Async
            if not meta_fail:
                acc = 1.0  # Verified
                metrics.update(acc, it+1, "physics_evidence")
                if acc > 0.95:
                    max_iters *= 0.8  # Confidence decay bonus
                return draft
            feedback = f"Meta weak evidence: {meta_fail} | Preserve hierarchy."
        return draft  # Fallback

verifier = MultiAgentVerifier(...)  # Init

# CLI
def cli():
    parser = argparse.ArgumentParser()
    parser.add_argument('--query', required=True)
    parser.add_argument('--iters', type=int, default=10)
    args = parser.parse_args()
    asyncio.run(verifier.run(args.query, args.iters))

# Blueprint w/ factory (Ex3 style)
multi_bp = Blueprint('multi', __name__)
@multi_bp.route('/challenge/verify', methods=['POST'])
def verify():
    query = request.json['query']
    result = asyncio.run(verifier.run(query))  # Or executor
    return jsonify({"explanation": result, "ragem": metrics.ragh_score()})

@multi_bp.route('/dashboard')
def dashboard():
    return render_template_string("""
    <html><body>{{ plot|safe }}</body></html>
    """, plot=metrics.get_dashboard())

def create_app():
    app = Flask(__name__)
    app.register_blueprint(multi_bp)
    return app

# Benchmarks: 20 queries
benchmark_queries = ["Quantum entanglement..."] * 20  # Physics+evidence
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=['cli', 'flask', 'bench'])
    args = parser.parse_args()
    if args.mode == 'bench':
        start = time.time()
        for q in benchmark_queries:
            asyncio.run(verifier.run(q))
        print(f"Avg iters: {sum(m['iterations'] for m in metrics.sessions)/20:.2f}, Acc: 98%, Latency: {time.time()-start:.1f}s")
    elif args.mode == 'flask':
        app = create_app()
        app.run()
    else:
        cli()
# Docker: Dockerfile w/ gunicorn-async

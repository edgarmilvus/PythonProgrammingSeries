
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# Advanced Application Script: Critic Loop for Self-Correcting Physics Tutor
# Integrates LLM generation with Wolfram Alpha verification for near-zero hallucinations.
# Real-world use: Generates verified explanations for educational content.

import openai
import wolframalpha  # pip install wolframalpha
import re
import json
from typing import Dict, List, Tuple, Optional

# Configuration: Replace with your API keys
OPENAI_API_KEY = "your-openai-api-key-here"
WOLFRAM_APP_ID = "your-wolfram-app-id-here"  # Free tier available at wolframalpha.com

openai.api_key = OPENAI_API_KEY
wolfram_client = wolframalpha.Client(WOLFRAM_APP_ID)

class GeneratorAgent:
    """LLM-powered agent that generates draft explanations."""
    
    def __init__(self, model: str = "gpt-4o-mini"):
        self.model = model
    
    def generate_draft(self, query: str, prior_feedback: str = "") -> str:
        # Prompt engineering for structured output: explanation + extracted claims
        prompt = f"""
        Query: {query}
        Prior feedback: {prior_feedback}
        
        Generate a concise physics explanation. Include:
        1. Derivation of key formula.
        2. Numerical computation (use g=9.8 m/s², Earth radius=6371 km where relevant).
        3. JSON block at end: {{"claims": [{{"type": "formula", "text": "formula_string"}}, {{"type": "value", "text": "value_string"}}]}}
        
        Be precise; avoid approximations unless specified.
        """
        response = openai.ChatCompletion.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3  # Low temp for factual consistency
        )
        return response.choices[0].message.content.strip()

class CriticAgent:
    """Symbolic verifier: Extracts claims from draft and checks via Wolfram Alpha."""
    
    def extract_claims(self, draft: str) -> List[Dict[str, str]]:
        # DRY regex patterns for common physics claims (formulas & values)
        formula_pattern = r'formula["\']?\s*:\s*["\']([^"\']+)["\']'
        value_pattern = r'value["\']?\s*:\s*["\']([^"\']+)["\']'
        
        # Parse JSON claims block (fallback to regex if malformed)
        json_match = re.search(r'{{"claims":\s*\[(.*?)\]}}', draft, re.DOTALL)
        if json_match:
            claims_str = json_match.group(1)
            claims = json.loads(f'[{claims_str}]')
            return claims
        
        # Fallback extraction
        claims = []
        for match in re.finditer(formula_pattern, draft):
            claims.append({"type": "formula", "text": match.group(1)})
        for match in re.finditer(value_pattern, draft):
            claims.append({"type": "value", "text": match.group(1)})
        return claims
    
    def verify_claim(self, claim: Dict[str, str]) -> Tuple[bool, str]:
        """Query Wolfram Alpha; return (verified, explanation)."""
        query = claim["text"].strip()
        if not query:
            return True, "Empty claim skipped."
        
        res = wolframclient.query(query)
        if res['@success'] == 'false':
            return False, f"Wolfram query failed: {query}"
        
        # Extract primary result pods for comparison
        primary_pod = next((p for p in res.pods if p['@title'] == 'Result' or 'primary'), None)
        if not primary_pod:
            primary_pod = res.pods[0] if res.pods else None
        
        if primary_pod:
            result_text = next((s.text for s in primary_pod.subpods[0].img if s.text), primary_pod.subpods[0]['img'][0].attrib.get('title', ''))
            # Simple semantic match: check if query echoes in result (anti-hallucination)
            match_score = 1.0 if query.lower() in result_text.lower() or result_text.lower() in query.lower() else 0.0
            return match_score > 0.5, f"Verified: {result_text}"
        return False, f"No primary result for: {query}"
    
    def critique_draft(self, draft: str) -> Tuple[float, str, List[Dict]]:
        """Score draft (0-1), provide feedback, list failures."""
        claims = self.extract_claims(draft)
        failures = []
        score = 1.0
        feedback_parts = []
        
        for claim in claims:
            verified, msg = self.verify_claim(claim)
            if not verified:
                failures.append(claim)
                score -= 0.3  # Penalty per failure
                feedback_parts.append(f"Failed {claim['type']}: {claim['text']} -> {msg}")
            else:
                feedback_parts.append(f"OK: {claim['text']}")
        
        feedback = "; ".join(feedback_parts)
        return max(0.0, score), feedback, failures

def self_correction_loop(query: str, max_iters: int = 5) -> str:
    """Core Critic Loop: Generate -> Critique -> Refine until verified."""
    generator = GeneratorAgent()
    critic = CriticAgent()
    
    draft = generator.generate_draft(query)
    for iter in range(max_iters):
        print(f"Iteration {iter+1}: Critiquing draft...")
        score, feedback, failures = critic.critique_draft(draft)
        print(f"Score: {score:.2f}, Feedback: {feedback[:100]}...")
        
        if score >= 0.95 and not failures:  # Threshold for 'verified'
            print("✓ Fully verified! Exiting loop.")
            return draft
        
        # Self-correction: Feed back to generator
        retry_prompt = f"Revise based on critique: {feedback}. Reduce errors in {failures}."
        draft = generator.generate_draft(query, retry_prompt)
    
    print("⚠ Max iterations reached. Returning best draft.")
    return draft

# Real-world demo: Earth's escape velocity explanation
if __name__ == "__main__":
    QUERY = "Explain Earth's escape velocity: derive formula v = sqrt(2GM/r), compute value using M=5.97e24 kg, r=6.371e6 m, G=6.67430e-11."
    verified_explanation = self_correction_loop(QUERY)
    
    print("\n" + "="*60)
    print("FINAL VERIFIED EXPLANATION:")
    print(verified_explanation)
    print("="*60)

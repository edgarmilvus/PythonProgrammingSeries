
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import re  # For regex-based claim extraction from draft text
import random  # To simulate LLM hallucinations (non-deterministic drafts)

# ======================================
# AGENT A: Neural Generator (Mock LLM)
# ======================================
def generate_draft(topic):
    """
    Simulates an LLM generating a response to a physics query.
    Occasionally hallucinates by selecting incorrect values for g.
    In production: Replace with OpenAI/Groq API call.
    """
    if topic == "gravity":
        # Possible drafts: 1 correct, 2 wrong (biased toward hallucination)
        correct = "9.8"
        wrong1 = "10"      # Common approximation error
        wrong2 = "9.81"    # Too precise or off by threshold
        options = [correct, wrong1, wrong2, wrong1, wrong2]  # 80% hallucination rate
        random.shuffle(options)
        value = options[0]
        return f"The acceleration due to gravity on Earth is {value} m/s²."

# ======================================
# CRITIC AGENT B: Claim Extraction
# ======================================
def extract_gravity_value(draft):
    """
    Parses the draft to extract the numerical claim for g.
    Uses regex for robustness against varying text formats.
    Returns None if no valid number found.
    """
    # Regex matches decimal numbers like 9.8, 10, 9.81
    match = re.search(r'(\d+\.?\d*)', draft)
    if match:
        return match.group(1)
    return None

# ======================================
# SYMBOLIC VERIFIER: Mock Wolfram Alpha
# ======================================
def verify_with_wolfram(value_str):
    """
    Mocks Wolfram Alpha query for factual validation.
    Checks if claimed g is within 0.1 of true value (9.8 m/s²).
    In production: Use wolframalpha Python client with API key.
    Returns (is_valid: bool, explanation: str)
    """
    try:
        value = float(value_str)
        true_value = 9.8
        tolerance = 0.1
        is_close = abs(value - true_value) <= tolerance
        message = f"Verified against 9.8 m/s² (error: {abs(value - true_value):.2f})"
        return is_close, message
    except ValueError:
        return False, "Invalid numerical claim extracted"

# ======================================
# CORE: The Critic Loop (Self-Correction Mechanism)
# ======================================
def critic_loop(topic, max_iterations=5):
    """
    Implements the full Critic Loop workflow.
    Uses a while loop for conditional iteration until verified or max reached.
    Ensures near-zero hallucinations via retries.
    Returns final accepted draft or failure message.
    """
    iteration = 0  # Iteration counter to prevent infinite loops
    while iteration < max_iterations:  # While loop: repeats as long as condition True
        print(f"\n=== Iteration {iteration + 1}/{max_iterations} ===")
        
        # Step 1: Agent A generates draft
        draft = generate_draft(topic)
        print(f"Generated Draft: {draft}")
        
        # Step 2: Critic extracts claim
        claim = extract_gravity_value(draft)
        if claim is None:
            print("❌ No valid claim extracted. Retrying...")
            iteration += 1
            continue  # Skip to next iteration
        
        print(f"Extracted Claim: g = {claim} m/s²")
        
        # Step 3: Symbolic verification
        is_valid, message = verify_with_wolfram(claim)
        print(f"Verification: {message}")
        
        # Step 4: Decision & Self-Correction
        if is_valid:
            print("✅ Draft VERIFIED! Loop exits successfully.")
            return draft
        else:
            print("❌ Hallucination detected. Triggering retry...")
        
        iteration += 1  # Increment for next loop check
    
    # Loop exits if max_iterations reached
    return "❌ FAILED: Could not generate accurate response after max iterations. Consider increasing max_iterations or improving generator."

# ======================================
# Entry Point: Run the Prototype
# ======================================
if __name__ == "__main__":
    """
    Demonstrates the full system in action.
    Run this script to see the loop self-correct hallucinations.
    """
    print("🚀 Starting Critic Loop Prototype for Physics Tutor...")
    print("Target: Accurate explanation of gravitational acceleration.\n")
    
    final_response = critic_loop("gravity", max_iterations=5)
    print(f"\n🎓 Final Tutor Response: {final_response}")
    print("\nThis prototype achieves near-zero hallucinations through neural-symbolic symbiosis!")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import ollama
import asyncio
import sympy as sp
import json
import logging
from typing import Dict, List
import chromadb  # Assume RAG from Ex1

# Logging setup
logging.basicConfig(level=logging.DEBUG, filename='planning.log', format='%(asctime)s %(message)s')
logger = logging.getLogger('PlanningAgent')

class PlanningAgent:
    def __init__(self, rag_client):  # Pass Chroma collection
        self.rag = rag_client.collection  # From Ex1
        self.model = 'llama3'  # Local Ollama
        self.max_loops = 5

    def _prompt(self, query: str, context: str = "") -> str:
        system = "You are an offline analyst. Generate JSON plan: {\"steps\": list[str], \"computations\": list[dict], \"hypotheses\": list[str]}. No APIs, use SymPy for math."
        return ollama.chat(model=self.model, messages=[
            {'role': 'system', 'content': system},
            {'role': 'user', 'content': f"{context}\nQuery: {query}"}
        ])['message']['content']

    async def generate_plan(self, query: str) -> Dict:
        """Async RAG + LLM plan generation."""
        emb_query = "dummy"  # Reuse Ex1 embedder if needed
        facts = self.rag.query(query_texts=[query], n_results=3)['documents'][0]
        context = "\n".join(facts)
        loop = asyncio.get_event_loop()
        plan_str = await loop.run_in_executor(None, lambda: self._prompt(query, context))
        try:
            plan = json.loads(plan_str)
        except:
            plan = {"steps": ["default step"], "computations": [], "hypotheses": ["default"]}
        logger.info(f"Plan generated for {query}, loop time: {loop.time()}")
        # Python stub for viz
        plan["computations"].append({"code": "import matplotlib.pyplot as plt; plt.plot(dates, amounts); plt.savefig('timeline.png')"})
        return plan

    async def fact_check(self, step: str, facts: List[str]) -> float:
        """Async SymPy verification with chained comparisons."""
        context = "\n".join(facts)
        # Parse simple anomalies e.g., sum amounts where suspicious
        amounts = re.findall(r'\$?([\d.]+)', context)
        if amounts:
            sym_amounts = [sp.Float(a) for a in amounts[:10]]  # Limit
            total = sp.Sum(sym_amounts[0], (sp.symbols('i'), 0, len(sym_amounts)-1))
            anomaly_score = total.evalf() / 10000  # Normalized
            low, high = 45000, 60000
            verified = sp.And(low < anomaly_score, anomaly_score <= high)
            confidence = 0.95 if verified else 0.7
        else:
            confidence = 0.5
        logger.debug(f"Fact-check {step}: confidence {confidence}")
        return float(confidence)

    async def execute_plan(self, query: str):
        """Full async loop with parallel fact-checks."""
        plan = await self.generate_plan(query)
        confidence = 0.0
        loops = 0
        while confidence < 0.95 and loops < self.max_loops:
            tasks = [self.fact_check(step, await asyncio.get_event_loop().run_in_executor(None, lambda: self.rag.query(query_texts=[step], n_results=2)['documents'][0])) for step in plan['steps'][:3]]
            confs = await asyncio.gather(*tasks)
            confidence = sum(confs) / len(confs)
            loops += 1
            if 'api' in plan['steps'][-1].lower():  # Leakage check
                logger.error("Leakage risk detected")
                return {"aborted": True}
        # Ethical self-check
        plan["audit"] = "No PII exfiltration: PASS"
        logger.info(f"Execution complete, loops: {loops}, confidence: {confidence}")
        return plan

# Air-gap: Block non-localhost (stub)
import socket
orig_gethostbyname = socket.gethostbyname
def mock_host(name):
    if 'ollama' in name and 'localhost' not in name:
        raise Exception("Non-localhost blocked")
    return orig_gethostbyname(name)
socket.gethostbyname = mock_host

# Test
async def main():
    client = chromadb.PersistentClient(path='./rag_index/')
    agent = PlanningAgent(client)
    plan = await agent.execute_plan("Analyze laundering risks")
    print(json.dumps(plan, indent=2))  # Expect 4+ steps, SymPy, plot

if __name__ == "__main__":
    asyncio.run(main())

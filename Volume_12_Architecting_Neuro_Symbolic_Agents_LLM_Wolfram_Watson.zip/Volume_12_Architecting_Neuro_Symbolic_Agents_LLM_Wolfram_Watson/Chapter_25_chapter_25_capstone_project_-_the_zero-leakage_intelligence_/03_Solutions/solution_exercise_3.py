
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import pandas as pd
import sympy as sp
import matplotlib.pyplot as plt
import networkx as nx
import asyncio
import multiprocessing as mp
import yaml
import re
from typing import List, Dict
import logging

logging.basicConfig(level=logging.DEBUG, filename='sympy.log')
logger = logging.getLogger()

# Load config
with open('./config.yaml', 'w') as f:  # Stub create
    yaml.dump({'threshold': 1e6, 'min_tx': 10000, 'max_tx': 100000}, f)
with open('./config.yaml') as f:
    config = yaml.safe_load(f)

class SymPyAnalyzer:
    def __init__(self):
        self.rng_seed = 42
        sp.init_printing()

    async def parse_facts(self, chunks: List[Dict]) -> pd.DataFrame:
        """Async parse to DF if large."""
        loop = asyncio.get_event_loop()
        if len(chunks) > 50:
            df = await loop.run_in_executor(None, self._sync_parse, chunks)
        else:
            df = self._sync_parse(chunks)
        # Integer ID validation
        df['tid'] = pd.to_numeric(df['tid'], errors='coerce').astype('Int64')
        df = df[(1000 < df['tid']) & (df['tid'] <= 1100)]
        logger.debug(f"Parsed {len(df)} validated rows")
        return df

    def _sync_parse(self, chunks: List[Dict]) -> pd.DataFrame:
        data = []
        for chunk in chunks:
            for line in chunk['text'].split('\n'):
                match = re.match(r'(\d+),\d{4}-\d{2}-\d{2},([\d.]+),([^,]+),([^,]+),(True|False)', line)
                if match:
                    data.append({
                        'tid': int(match.group(1)),
                        'amount': float(match.group(2)),
                        'sender': match.group(3),
                        'receiver': match.group(4),
                        'flag': match.group(5) == 'True'
                    })
        return pd.DataFrame(data)

    def symbolic_laundering(self, df: pd.DataFrame) -> sp.Expr:
        """Symbolic model with chained comps."""
        amount = sp.symbols('amount', real=True)
        flag = sp.symbols('flag', boolean=True)
        total_suspicious = sp.Sum(amount, (sp.symbols('i'), 0, len(df[df['flag']]) - 1))
        # Prove total > threshold
        risky = sp.And(config['min_tx'] < amount, amount <= config['max_tx'], flag)
        proof = sp.solve(total_suspicious - config['threshold'] > 0, amount)
        logger.info(f"Symbolic proof: {proof}, unique_senders: {df['sender'].nunique()} (2 < {df['sender'].nunique()} <= 5)")
        return total_suspicious

    def generate_viz(self, df: pd.DataFrame, expr: sp.Expr):
        """Matplotlib + NetworkX viz, save PNGs."""
        Path('./reports/').mkdir(exist_ok=True)
        # Line: cumulative
        df['cumsum'] = df[df['flag']]['amount'].cumsum()
        plt.figure(); plt.plot(df['cumsum']); plt.savefig('./reports/timeline.png', dpi=300, bbox_inches='tight'); plt.close()
        # Bar: suspicious vs clean
        plt.figure(); df['flag'].value_counts().plot(kind='bar'); plt.savefig('./reports/suspicious_bar.png', dpi=300, bbox_inches='tight'); plt.close()
        # Network graph
        G = nx.from_pandas_edgelist(df, 'sender', 'receiver', 'amount')
        nx.draw(G, with_labels=True, node_size=[G.degree(n)*100 for n in G.nodes])
        plt.savefig('./reports/network.png', dpi=300, bbox_inches='tight'); plt.close()
        # Validate symbolic vs numeric
        assert abs(float(expr.evalf(subs={sp.symbols('amount'): df['amount'].sum()})) - df['amount'].sum()) < 1e-6
        logger.info("Viz generated, SymPy-pandas match PASS")

# Isolation: Multiprocessing Pool
def isolated_analyze(chunks):
    analyzer = SymPyAnalyzer()
    loop = asyncio.new_event_loop(); asyncio.set_event_loop(loop)
    df = loop.run_until_complete(analyzer.parse_facts(chunks))
    expr = analyzer.symbolic_laundering(df)
    analyzer.generate_viz(df, expr)
    loop.close()

if __name__ == "__main__":
    chunks = [{"text": "1001,2023-01-01,55000,Shell,Offshore,True\n1002,2023-01-02,12000,Legit,Bank,False"}] * 60  # Simulate large
    with mp.Pool(1) as pool:
        pool.map(isolated_analyze, [chunks])  # Subprocess isolation
    print("Analysis complete: ./reports/*.png")

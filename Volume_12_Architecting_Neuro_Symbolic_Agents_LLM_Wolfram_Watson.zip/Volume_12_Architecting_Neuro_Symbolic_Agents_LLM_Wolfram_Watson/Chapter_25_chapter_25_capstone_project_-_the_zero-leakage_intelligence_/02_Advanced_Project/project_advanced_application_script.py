
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

#!/usr/bin/env python3
# Zero-Leakage Intelligence Analyst: Air-Gapped Financial Threat Detector
# Capstone demo - processes "classified" PDF text for laundering patterns.
# All local: no net, no cloud APIs. Neuro-symbolic: LLM-like brain generates SymPy code.

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import sympy as sp
import re
import io
from typing import List, Dict, Any
from datetime import datetime

# Simulated classified PDF text extract (in prod: use pypdf.PdfReader(open('intel.pdf', 'rb')))
SAMPLE_PDF_TEXT = """
Transaction Log - Oceanic Holdings (Classified)
Date | Amount (USD) | From Account | To Account | Description
2023-01-15 | 500000 | ACCT-US001 | SHELL-KY001 | Initial deposit from legit source
2023-02-20 | 1500000 | ACCT-EU002 | SHELL-KY002 | Large wire - layering start?
2023-03-10 | 250000 | ACCT-US001 | SHELL-KY001 | Follow-up small transfer
2023-04-05 | 2000000 | ACCT-ASIA003 | SHELL-KY003 | High-value anomaly - sanctions evaded?
2023-05-18 | 750000 | ACCT-EU002 | SHELL-KY002 | Structuring attempt
2023-06-22 | 100000 | ACCT-US001 | SHELL-KY001 | Low-value mixer
2023-07-14 | 1200000 | ACCT-EU004 | SHELL-KY004 | Rapid succession - red flag
2023-08-09 | 300000 | ACCT-ASIA003 | SHELL-KY003 | Partial unwind
2023-09-27 | 1800000 | ACCT-US005 | SHELL-KY005 | Peak anomaly volume
"""

# Local RAG: Keyword-based retrieval from DataFrame (lightweight, zero ML deps)
def local_rag(query: str, df: pd.DataFrame) -> str:
    """Retrieval-Augmented Generation base: filter rows matching query keywords."""
    words = re.findall(r'\w+', query.lower())
    mask = pd.Series([False] * len(df), index=df.index)
    for col in df.select_dtypes(include=['object', 'datetime64']).columns:
        for word in words:
            mask |= df[col].astype(str).str.contains(word, case=False, na=False)
    relevant_rows = df[mask]
    return relevant_rows.to_string(index=False) if not relevant_rows.empty else "No relevant intel found."

# Local Brain: Simulated Llama 3 (offline mock - monkey-patch for real Ollama in prod)
def local_brain(prompt: str) -> str:
    """Neuro layer: Generates plans or SymPy/Matplotlib code snippets from context.
    In prod: ollama.chat(model='llama3:8b', messages=[{'role': 'user', 'content': prompt}])
    """
    prompt_lower = prompt.lower()
    if 'plan' in prompt_lower:
        return """
1. Parse df for totals/anomalies (>1M USD threshold for laundering flags).
2. Symbolic SymPy: total_vol = sum(amounts), anom_vol = sum(anoms), risk = (anom_vol / total_vol)*100 as Rational.
3. Viz: Monthly bar chart, overlay red anomalies.
4. Report: Risk assessment with evidence."""
    elif 'sympy' in prompt_lower:
        return """
# Generated SymPy code for verifiable calcs (hallucination-proof)
amounts = [sp.Integer(int(row)) for row in df['Amount (USD)'].dropna().tolist()]
total_sym = sum(amounts)
anom_mask = df['Amount (USD)'] > 1000000
anom_amounts = [sp.Integer(int(row)) for row in df[anom_mask]['Amount (USD)'].dropna().tolist()]
anom_sym = sum(anom_amounts)
num_anom = len(anom_amounts)
risk_rational = (anom_sym / total_sym) * 100
print(f"Total Volume (Symbolic): {total_sym}")
print(f"Anomaly Volume: {anom_sym} ({num_anom} txns)")
print(f"Risk Ratio (Exact): {risk_rational} %")
print(f"Risk Float: {float(risk_rational.evalf()):.2f} %")
"""
    elif 'visualization' in prompt_lower:
        return """
# Generated Matplotlib code for threat viz (save PNG offline)
df['Month'] = df['Date'].dt.month_name()
monthly_totals = df.groupby('Month')['Amount (USD)'].sum()
fig, ax = plt.subplots(figsize=(10, 6))
bars = ax.bar(monthly_totals.index, monthly_totals.values, color='blue', alpha=0.7)
anom_mask = df['Amount (USD)'] > 1000000
if anom_mask.any():
    anom_monthly = df[anom_mask].groupby('Month')['Amount (USD)'].sum()
    anom_bars = ax.bar(anom_monthly.index, anom_monthly.values, color='red', alpha=0.8, width=0.4)
ax.set_title('Monthly Transaction Volumes: Laundering Threat Heatmap')
ax.set_ylabel('Total Amount (USD)')
ax.set_xlabel('Month')
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig('zero_leakage_threat_viz.png', dpi=300, bbox_inches='tight')
plt.close()  # No display in air-gapped terminal
print("Viz saved: zero_leakage_threat_viz.png")
"""
    elif 'report' in prompt_lower:
        return """
# AUTO-GENERATED FINAL REPORT (Markdown for audit)
# Zero-Leakage Intelligence Analyst Output
## Executive Summary
High laundering risk detected: {risk_float:.1f}% of volume in {num_anom} anomalous txns.
Total processed: ${total_sym:,}. Recommend escalation.

## Key Findings
- Anomalies (> $1M): {num_anom} instances totaling ${anom_sym:,}.
- Hotspots: {anom_months} (e.g., high-volume shells).
- Evidence: RAG-retrieved contexts confirm layering/smurfing.

## Viz Reference
See attached zero_leakage_threat_viz.png.

## Chain-of-Custody
Generated offline @ {timestamp}. SymPy-verified. No leakage.
"""
    return "Plan executed: Near-zero hallucination achieved via symbolic grounding."

# Main Pipeline: Air-gapped execution
if __name__ == "__main__":
    print("=== Zero-Leakage Intelligence Analyst Activated ===")
    print("Ingesting classified PDF text...")
    
    # Parse PDF text into structured DataFrame
    df = pd.read_csv(io.StringIO(SAMPLE_PDF_TEXT), sep='|', skipinitialspace=True, skiprows=[0], on_bad_lines='skip')
    df.columns = [col.strip() for col in df.columns]
    df['Amount (USD)'] = pd.to_numeric(df['Amount (USD)'], errors='coerce')
    df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
    df = df.dropna(subset=['Amount (USD)', 'Date'])  # Clean intel
    print(f"Parsed {len(df)} transactions. Sample:\n{df.head()}")
    
    # RAG Retrieve: Context for brain
    rag_context = local_rag("shell suspicious high value anomaly", df)
    print("\nRAG Context Retrieved:\n", rag_context[:500] + "...")
    
    # Neuro Planning: Llama3-like plan
    plan_prompt = f"RAG Context: {rag_context}\nFormulate SymPy analysis plan for laundering."
    plan = local_brain(plan_prompt)
    print("\nLLM Brain Plan:\n", plan)
    
    # Symbolic Execution: Brain-generated SymPy code
    sympy_prompt = f"RAG Context: {rag_context}\nGenerate SymPy code for risk metrics."
    sympy_code = local_brain(sympy_prompt)
    print("\nExecuting Generated SymPy Code:\n", sympy_code)
    safe_globals = {'df': df, 'sp': sp, 'pd': pd, 'len': len, 'int': int, 'sum': sum, 'print': print}
    exec(sympy_code, safe_globals)
    
    # Visualization: Brain-generated plot code
    viz_prompt = f"RAG Context: {rag_context}\nGenerate Matplotlib viz code."
    viz_code = local_brain(viz_prompt)
    print("\nExecuting Generated Viz Code:\n", viz_code)
    exec(viz_code, safe_globals)
    
    # Final Report: Synthesize
    total_sym = safe_globals.get('total_sym', 0)
    anom_sym = safe_globals.get('anom_sym', 0)
    num_anom = safe_globals.get('num_anom', 0)
    risk_rational = safe_globals.get('risk_rational', 0)
    risk_float = float(risk_rational.evalf()) if isinstance(risk_rational, sp.Expr) else 0
    anom_months = df[df['Amount (USD)'] > 1000000]['To Account'].value_counts().head().to_dict()
    report_prompt = f"Summarize report. Total: {total_sym}, Anom: {anom_sym}, Risk: {risk_float}%, Months: {anom_months}"
    report_template = local_brain(report_prompt).format(
        risk_float=risk_float, num_anom=num_anom, total_sym=total_sym, anom_sym=anom_sym,
        anom_months=anom_months, timestamp=datetime.now().isoformat()
    )
    with open('zero_leakage_report.md', 'w') as f:
        f.write(report_template)
    print("\n=== MISSION COMPLETE ===")
    print("Report saved: zero_leakage_report.md")
    print("Viz saved: zero_leakage_threat_viz.png")
    print("All outputs air-gapped. Zero leakage confirmed.")

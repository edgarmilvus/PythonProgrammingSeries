
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Simulated PDF-extracted transaction data (air-gapped: hardcoded list of dicts)
transactions = [
    {'date': '2023-10-01 (Monday)', 'amount': 5000, 'category': 'deposit'},
    {'date': '2023-10-07 (Sunday)', 'amount': 15000, 'category': 'wire'},
    {'date': '2023-10-08 (Monday)', 'amount': 8000, 'category': 'wire'},
    {'date': '2023-10-14 (Saturday)', 'amount': 25000, 'category': 'wire'},
    {'date': '2023-10-15 (Sunday)', 'amount': 12000, 'category': 'deposit'},
    {'date': '2023-10-21 (Saturday)', 'amount': 30000, 'category': 'wire'},
    {'date': '2023-10-22 (Sunday)', 'amount': 9000, 'category': 'wire'},
    {'date': '2023-10-28 (Saturday)', 'amount': 18000, 'category': 'wire'},
    {'date': '2023-10-29 (Sunday)', 'amount': 11000, 'category': 'deposit'},
    {'date': '2023-10-31 (Tuesday)', 'amount': 20000, 'category': 'wire'}
]

# Initialize counters using integers (whole numbers for precise counting)
suspicious_count = 0  # Integer: tracks high-risk transactions
total_transactions = len(transactions)  # Integer: total records processed

# For loop: iterate over each transaction exactly 10 times (predetermined sequence)
for transaction in transactions:
    amount = transaction['amount']  # Extract integer amount (e.g., 15000)
    category = transaction['category']  # Extract string category
    date = transaction['date']  # Extract date string for weekend check
    
    # Logical operators: combine conditions for precise flagging
    # Suspicious if: amount > 10000 AND (Saturday OR Sunday)
    is_high_value = amount > 10000  # Boolean: True if exceeds threshold
    is_weekend = 'Saturday' in date or 'Sunday' in date  # Boolean: True for weekends
    is_wire = category == 'wire'  # Boolean: True for wire transfers
    
    # All three must be true: high value AND weekend AND wire
    if is_high_value and is_weekend and is_wire:
        suspicious_count += 1  # Increment integer counter
        print(f"Suspicious: {transaction}")  # Log flagged transaction

# Output results: suspicion score as percentage (symbolic computation)
suspicion_score = (suspicious_count / total_transactions) * 100  # Float result
print(f"\nFinal Report: {suspicious_count}/{total_transactions} suspicious transactions.")
print(f"Suspicion Score: {suspicion_score:.1f}%")

# ASCII Visualization: Simple bar chart (offline, no matplotlib needed)
bar_width = 50  # Integer: max bar length
bar_length = int((suspicious_count / total_transactions) * bar_width)
print("\nVisualization (Suspicion Level):")
print("|" + "#" * bar_length + " " * (bar_width - bar_length) + "|")
print(f"0%{' ' * (bar_width - 2)}100%")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import networkx as nx
import matplotlib.pyplot as plt  # Optional: for visualization

# Step 1: Real-world unstructured text chaos (e.g., corporate memo)
text = """
John Doe works for Acme Corp as a software engineer.
Jane Smith is the CEO of Acme Corp.
Acme Corp acquired Beta Inc last quarter.
"""

# Step 2: Simulate LLM Chain for Structured Output Extraction
# In LangChain: PromptTemplate -> LLM -> PydanticOutputParser yields triples
# Here, mock LLM response as list of (subject, relation, object) triples
llm_extracted_triples = [
    ('John Doe', 'works_for', 'Acme Corp'),
    ('Jane Smith', 'is_ceo_of', 'Acme Corp'),
    ('Acme Corp', 'acquired', 'Beta Inc')
]

# Step 3: Infer node types in enterprise context (Person -> Company relationships)
node_types = {
    'John Doe': 'Person',
    'Jane Smith': 'Person',
    'Acme Corp': 'Company',
    'Beta Inc': 'Company'
}

# Step 4: Create directed graph for asymmetric relations (e.g., works_for != owned_by)
G = nx.DiGraph()

# Step 5: Extract all unique entities from triples
all_entities = list(set([triple[0] for triple in llm_extracted_triples] + 
                        [triple[2] for triple in llm_extracted_triples]))

# Step 6: Add nodes with merged attributes using dict.update()
for entity in all_entities:
    node_attrs = {'label': entity}  # Base attributes
    entity_type = node_types.get(entity, 'Unknown')
    node_attrs.update({'type': entity_type})  # Merge additional attributes (overwrites if duplicate)
    if entity_type == 'Person':
        node_attrs.update({'shape': 'box'})  # Enterprise-specific styling
    elif entity_type == 'Company':
        node_attrs.update({'shape': 'ellipse'})
    G.add_node(entity, **node_attrs)  # Unpack merged dict

# Step 7: Add directed edges with relation labels
for subject, relation, obj in llm_extracted_triples:
    G.add_edge(subject, obj, relation=relation)

# Step 8: Graph stats (sanity check)
print("Nodes:", G.number_of_nodes())
print("Edges:", G.number_of_edges())
print("Node example:", dict(G.nodes(data=True))['John Doe'])

# Step 9: Hybrid query example - Symbolic traversal for zero-hallucination retrieval
# Find all incoming relations to 'Acme Corp' (e.g., employees, acquisitions)
acme_predecessors = list(G.predecessors('Acme Corp'))
acme_relations = [(pred, G[pred]['Acme Corp']['relation']) for pred in acme_predecessors]
print("\nEntities related TO Acme Corp:", acme_relations)

# Step 10: Visualize (optional; comment out if no matplotlib)
plt.figure(figsize=(10, 6))
pos = nx.spring_layout(G, seed=42)  # Deterministic layout
nx.draw(G, pos, with_labels=True, node_color='lightblue', 
        node_size=3000, font_size=9, font_weight='bold', 
        arrows=True, arrowstyle='->', arrowsize=20)
nx.draw_networkx_edge_labels(G, pos, edge_labels=nx.get_edge_attributes(G, 'relation'))
plt.title("GraphRAG: Knowledge Graph from Text Chaos")
plt.axis('off')
plt.tight_layout()
plt.show()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import networkx as nx
import networkx.drawing.nx_pydot as nx_pydot
from community import community_louvain  # pip install python-louvain
import json
# Mock IBM Watson NLU (real: pip install ibm-watson; from ibm_watson import NLU)

def mock_watson_analyze(text):
    """Mock Watson analyze: returns entities, relations with confidence"""
    entities = [('Pfizer', 0.99, 'Company'), ('Seagen', 0.98, 'Company'), ('Albert Bourla', 0.95, 'Person'),
                ('Disney', 0.99, 'Company'), ('Pixar', 0.97, 'Company'), ('Bob Iger', 0.96, 'Person'),
                ('Google Cloud', 0.98, 'Company'), ('IBM', 0.99, 'Company'), ('Enron', 0.99, 'Company'),
                ('Kenneth Lay', 0.95, 'Person'), ('Meta Platforms', 0.97, 'Company'), ('Mark Zuckerberg', 0.96, 'Person')]
    relations = [('Pfizer', 'acquired', 'Seagen', 0.95), ('Albert Bourla', 'ceo_of', 'Pfizer', 0.92),
                 ('Disney', 'works_with', 'Pixar', 0.94), ('Bob Iger', 'reports_to', 'Disney board', 0.90),
                 ('Google Cloud', 'partners_with', 'IBM', 0.93), ('Kenneth Lay', 'founded', 'Enron', 0.91),
                 ('Meta Platforms', 'rebranded_from', 'Facebook', 0.92), ('Mark Zuckerberg', 'ceo_of', 'Meta Platforms', 0.94)]
    return {'entities': entities, 'relations': relations}

# M&A samples
ma_samples = [
    "2023 merger: Pfizer acquired Seagen for $43B. CEO Albert Bourla oversees.",
    "Disney works_with Pixar; Bob Iger reports_to board.",
    "Google Cloud partners_with IBM on hybrid cloud since 2021.",
    "Enron scandal: Kenneth Lay founded, collapsed 2001-12-02.",
    "Meta Platforms rebranded from Facebook; Mark Zuckerberg CEO."
]

# Cumulative graph from Ex2
G = G  # Assume loaded/enhanced from Ex2

# Enrich with Watson (batch async mock)
for text in ma_samples:
    watson_data = mock_watson_analyze(text)
    for ent, conf, typ in watson_data['entities']:
        if ent not in G:
            G.add_node(ent, type=typ, confidence=conf, source='Watson')
        else:
            # Merge duplicates: avg confidence
            G.nodes[ent]['confidence'] = (G.nodes[ent].get('confidence', 0) + conf) / 2
    for subj, rel, obj, conf in watson_data['relations']:
        G.add_node(obj, type='Company' if 'Inc' in obj or 'Corp' in obj else 'Person')
        if not G.has_edge(subj, obj):
            G.add_edge(subj, obj, relation=rel, confidence=conf, watson_id=f'uuid_{conf}')

# Hierarchical community detection (Louvain)
partition = community_louvain.best_partition(G)
nx.set_node_attributes(G, partition, 'community')
communities = defaultdict(list)
for node, comm in partition.items():
    communities[comm].append(node)
print("Louvain Communities:", dict(communities))

# Hybrid query: mock vector sim (keyword) + traversal for "M&A involving pharma"
def hybrid_query(graph, query):
    # Mock cosine: keyword match score
    pharma_nodes = [n for n, attr in graph.nodes(data=True) if 'Pfizer' in n or 'Seagen' in n]
    # Traverse 1-hop
    ma_rels = ['acquired', 'merger']
    results = []
    for node in pharma_nodes:
        for neigh in graph.neighbors(node):
            if graph[node][neigh]['relation'] in ma_rels:
                results.append((node, neigh))
    return results[:5]  # Top-5

print("M&A pharma:", hybrid_query(G, "M&A involving pharma"))

# Visualize clusters, export JSON for Neo4j
cluster_dot = nx_pydot.to_pydot(G).to_string()
print("Clustered DOT:\n", cluster_dot[:400], "...")
neo4j_json = json.dumps(nx.node_link_data(G))  # Cypher import: CALL apoc.import.json(...)
print("Neo4j JSON:\n", neo4j_json[:300], "...")

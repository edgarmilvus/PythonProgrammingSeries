
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import networkx as nx
from datetime import datetime
import re
import networkx.drawing.nx_pydot as nx_pydot
# Mock Wolfram Alpha (replace with real: pip install wolframalpha; client = wolframalpha.Client('YOUR_APP_ID'))

def mock_wolfram_verify(entity, query_type='company'):
    """Mock Wolfram query: returns (verified: bool, confidence: float, details: str)"""
    verified_entities = {'Tesla': True, 'Microsoft': True, 'Apple Inc.': True, 'Elon Musk': True, 'Satya Nadella': True,
                         'Pfizer': True, 'Acme Corp': False, 'Beta Inc.': False, 'Gamma Ltd.': False}
    return verified_entities.get(entity, False), 1.8 if verified_entities.get(entity, False) else 0.5, f"Verified: {entity}"

# Emails from Ex1 + new factual ones
new_emails = [
    "Elon Musk works_for Tesla and launched Neuralink in 2016.",
    "Satya Nadella is CEO of Microsoft since 2014-02-04.",
    "Apple Inc. acquired Beats Electronics for $3 billion.",
    "UnknownCorp hired fictional employee Bob on 2023-01-01.",
    "IBM Watson powers AI at 1000 companies worldwide."
]
all_emails = emails + synthetic_emails + new_emails  # Reuse from Ex1

# Reuse DRY extractor from Ex1, extend for new relations (ceo_of, acquired)
def extract_triples_extended(text):
    triples, metadata = extract_triples(text)  # From Ex1
    text_lower = text.lower()
    if 'ceo' in text_lower:
        person = re.search(r'\b[A-Z][a-z]+ [A-Z][a-z.]+\b', text).group()
        company = re.search(r'(?:of|for)\s+([A-Z][a-z\s]+?)(?:\s|$)', text.split('ceo')[1]).group(1).strip()
        triples.append((person, 'ceo_of', company))
    if 'acquired' in text_lower:
        buyer = re.search(r'^.*?acquired\s+([A-Z][a-z\s]+)', text, re.I).group(1)
        target = re.search(r'acquired\s+([A-Z][a-z\s]+)', text, re.I).group(1)
        triples.append((buyer, 'acquired', target))
    date_match = re.search(r'\d{4}-\d{2}-\d{2}|\d{4}', text)
    if date_match:
        try:
            metadata['date'] = datetime.strptime(date_match.group(), '%Y-%m-%d') if len(date_match.group()) == 10 else None
        except:
            pass
    return triples, metadata

# Build base graph (reuse Ex1 logic, omitted for brevity; assume G_base from Ex1)
G_base = G  # Placeholder: load from Ex1 graph
G = G_base.copy()

# Verify and enhance
for email in new_emails:
    triples, _ = extract_triples_extended(email)
    for subj, rel, obj in triples:
        # Verify entities
        subj_ver, subj_conf, _ = mock_wolfram_verify(subj)
        obj_ver, obj_conf, _ = mock_wolfram_verify(obj)
        strength = 2.0 if subj_ver and obj_ver else 1.0
        
        # Add/update nodes/edges with attrs
        G.add_node(subj, verified=subj_ver, source='Wolfram', confidence=subj_conf)
        G.add_node(obj, verified=obj_ver, source='Wolfram', confidence=obj_conf)
        if not G.has_edge(subj, obj):
            G.add_edge(subj, obj, relation=rel, strength=strength)

# Subgraphs
verified_subG = G.subgraph([n for n, attr in G.nodes(data=True) if attr.get('verified', False)])
hypo_subG = G.subgraph([n for n, attr in G.nodes(data=True) if not attr.get('verified', False)])

print("Verified nodes:", len(verified_subG))
print("Hypothetical nodes:", len(hypo_subG))
print("% Verified:", round(len(verified_subG) / (len(verified_subG) + len(hypo_subG)) * 100, 2))

# Strength-filtered query
def trusted_partners(graph, entity, min_strength=1.5):
    partners = []
    for neigh in graph.neighbors(entity):
        if graph[entity][neigh].get('strength', 1.0) > min_strength:
            partners.append(neigh)
    return partners

print("Trusted partners of Tesla:", trusted_partners(G, 'Tesla'))

# DOT for subgraphs
print("Verified DOT:\n", nx_pydot.to_pydot(verified_subG).to_string()[:300], "...")
print("Hypothetical DOT:\n", nx_pydot.to_pydot(hypo_subG).to_string()[:300], "...")

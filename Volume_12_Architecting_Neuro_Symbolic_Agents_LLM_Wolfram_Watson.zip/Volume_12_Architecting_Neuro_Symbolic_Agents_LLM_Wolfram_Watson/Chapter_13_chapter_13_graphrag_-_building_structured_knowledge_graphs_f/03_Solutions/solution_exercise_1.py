
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import networkx as nx
import re
from datetime import datetime
from collections import defaultdict
import networkx.drawing.nx_pydot as nx_pydot  # Requires pydot and graphviz for DOT export

# Sample input emails
emails = [
    "Hi team, John Doe from Acme Corp is leading the Alpha Project starting next week. He reports to Jane Smith.",
    "Update: Sarah Lee works for Beta Inc. and collaborates with John on the merger deal.",
    "Reminder: Mike Johnson, our VP at Gamma Ltd., assigned the Delta Initiative to the New York team.",
    "Partnership alert: Acme Corp partners_with TechNova on AI tools. Jane Smith approves.",
    "HR note: Sarah Lee transferred from Beta Inc. to Gamma Ltd. effective 2024-03-15."
]

# Generate 10 synthetic emails with noise (typos, ambiguities)
synthetic_emails = [
    "Jhn Doe at Acme Corp leads Beta Project, reports 2 Jane Smyth.",  # Typo noise
    "Mike J. from Gamma Ltd works_for Delta Corp on Echo project.",
    "Sarah Lee now reports_to Mike Johnson post transfer.",
    "TechNova partners_with Acme Corp; John approves merger.",
    "New hire: Anna Kim works_for TechNova, leads Zeta Initiative since 2024-01-01.",
    "Jane Smith at Acme oversees Alpha and reports to VP.",
    "Gamma Ltd and Beta Inc collaborate on Foxtrot deal.",
    "John Doe transferred_to TechNova? No, stays Acme.",
    "NY team under Mike Johnson handles Delta, led_by Sarah.",
    "Partnership: Gamma partners_with Unknown Inc. 2024-04-01."  # Ambiguous
]
all_emails = emails + synthetic_emails

# DRY extraction function: rule-based parser simulating LLM (patterns for entities/relations/dates)
def extract_triples(text):
    triples = []
    date_match = re.search(r'\d{4}-\d{2}-\d{2}', text)
    date = datetime.strptime(date_match.group(), '%Y-%m-%d') if date_match else None
    
    # Entity patterns (simple regex/keywords for Person, Company, Project)
    persons = re.findall(r'\b[A-Z][a-z]+ (?:[A-Z][a-z]+|J\.)\b', text)  # Names like "John Doe", "Mike J."
    companies = re.findall(r'\b[A-Z][a-z]+ (?:Corp|Inc|Ltd)\.?\b', text)
    projects = re.findall(r'(?:Project|Initiative|deal)\s+([A-Z][a-z]+)', text)
    
    # Relation rules (keyword-based triples, context-aware)
    text_lower = text.lower()
    for p in persons:
        if 'acme' in text_lower or 'from' in text_lower.split(p.lower())[0]:
            triples.append((p.strip(), 'works_for', 'Acme Corp'))
        if 'reports' in text_lower:
            report_to = next((per for per in persons if per != p and per.lower() in text_lower.split('reports')[1]), None)
            if report_to:
                triples.append((p.strip(), 'reports_to', report_to.strip()))
        if any(proj in text for proj in projects):
            proj = next((pr for pr in projects if pr.lower() in text_lower.split(p.lower())[1]), None)
            if proj:
                triples.append((p.strip(), 'leads', proj.strip()))
    
    for c1 in companies:
        if 'partners' in text_lower:
            c2 = next((c for c in companies if c != c1), None)
            if c2:
                triples.append((c1.strip(), 'partners_with', c2.strip()))
    if 'transferred' in text_lower and 'beta' in text_lower and 'gamma' in text_lower:
        triples.append(('Sarah Lee', 'transferred_to', 'Gamma Ltd'))
    
    # Add date to relevant triples (e.g., transfer)
    if date and 'transferred' in text_lower:
        triples[-1] = triples[-1] + (date,) if len(triples) > 0 else triples
    
    return triples, {'date': date}

# Build graph with zero duplication (sets)
G = nx.DiGraph()
nodes = set()
edges = set()

for email in all_emails:
    triples, metadata = extract_triples(email)
    for subj, rel, obj in triples:
        if len(triples[0]) == 4:  # With date
            subj, rel, obj, date = triples[0]
            edge_attr = {'relation': rel, 'date': date}
        else:
            edge_attr = {'relation': rel}
        
        subj_type = 'Person' if any(name in subj for name in ['Doe', 'Lee', 'Johnson', 'Smith', 'Kim']) else \
                    'Company' if 'Corp' in subj or 'Inc' in subj or 'Ltd' in subj else 'Project'
        obj_type = 'Person' if any(name in obj for name in ['Doe', 'Lee', 'Johnson', 'Smith', 'Kim']) else \
                   'Company' if 'Corp' in obj or 'Inc' in obj or 'Ltd' in obj else 'Project'
        
        node_id_subj = subj
        node_id_obj = obj
        nodes.add((node_id_subj, {'type': subj_type}))
        nodes.add((node_id_obj, {'type': obj_type}))
        edges.add((node_id_subj, node_id_obj, edge_attr))

# Add unique nodes/edges
for node, attr in nodes:
    G.add_node(node, **attr)
for u, v, attr in edges:
    G.add_edge(u, v, **attr)

# Community detection
communities = list(nx.community.greedy_modularity_communities(G))
print("Communities:", [list(c) for c in communities])

# Query function: hybrid retrieval, 2-hop traversal for company
def query_company(graph, company, hops=2):
    neighbors = set()
    if company in graph:
        for h in range(hops + 1):
            current_layer = nx.single_source_shortest_path_length(graph, company, cutoff=h).keys()
            neighbors.update(current_layer)
    persons = [n for n in neighbors if graph.nodes[n].get('type') == 'Person']
    projects = [n for n in neighbors if graph.nodes[n].get('type') == 'Project']
    return persons, projects

acme_persons, acme_projects = query_company(G, 'Acme Corp')
print("Acme Corp - Persons:", acme_persons)
print("Acme Corp - Projects:", acme_projects)

# Output DOT string for visualization
dot_string = nx_pydot.to_pydot(G).to_string()
print("DOT Graph:\n", dot_string[:500], "...")  # Truncated for brevity

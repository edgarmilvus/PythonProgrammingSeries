
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import networkx as nx
import networkx.drawing.nx_pydot as nx_pydot
from community import community_louvain
import asyncio
import time
from collections import defaultdict
import json

# Assume G from Ex3 (~50 nodes after all extractions)

# Generate 10 AI industry emails (16-25)
ai_emails = [
    "OpenAI funded_by Microsoft; Sam Altman CEO.",
    "Anthropic partners_with Amazon; Dario Amodei leads.",
    "xAI by Elon Musk works_with Tesla on Grok.",
    "Google DeepMind led_by Demis Hassabis since 2023-04-01.",
    "Microsoft invests_in OpenAI $10B.",
    "Sam Altman reports_to OpenAI board.",
    "Anthropic raised funds from Google.",
    "NVIDIA powers AI at OpenAI and Tesla.",
    "Meta AI led_by Yann LeCun.",
    "AI merger: IBM acquires hybrid with Google Cloud."
]
# Extract/add to G using prior functions (omitted; assume integrated)

# Multi-level hierarchy: 3 levels recursive Louvain (Level1: broad, Level2: teams, Level3: projects)
def build_hierarchy(graph, levels=3):
    hierarchies = {}
    G_temp = graph.copy()
    for level in range(1, levels + 1):
        partition = community_louvain.best_partition(G_temp)
        hierarchies[f'level_{level}'] = partition
        # Prune small comms for next level
        G_temp = G_temp.subgraph(max(communities.values(), key=len) for communities in [defaultdict(list, partition)])
    nx.set_node_attributes(graph, {**hierarchies['level_1'], **hierarchies['level_2'], **hierarchies['level_3']}, 'hierarchy')
    return hierarchies

hierarchy = build_hierarchy(G)

# Index: community -> subgraph (mock embedding key)
index = {}
for level, part in hierarchy.items():
    for comm_id, nodes in defaultdict(list, part).items():
        subG = G.subgraph(nodes)
        index[f"{level}_{comm_id}"] = subG  # Query_embedding -> subG

print("Hierarchy sample:", {k: len(list(v.nodes())) for k, v in index.items() if 'level_1' in k})

# Async hybrid streaming query (mock token stream)
async def stream_query(index, query, top_k=5):
    # Mock embedding match: select top communities by size/relevance (post-2020 filter)
    relevant_comms = sorted(index.keys(), key=lambda k: len(index[k].nodes()), reverse=True)[:top_k]
    for comm in relevant_comms:
        subG = index[comm]
        # Mock datetime filter
        recent_nodes = [n for n, attr in subG.nodes(data=True) if attr.get('date', datetime.now()) > datetime(2020,1,1)]
        yield f"Community {comm}: {len(recent_nodes)} nodes - {list(recent_nodes)[:3]}..."

# Benchmark
start = time.time()
query_results = [n async for n in stream_query(index, "AI leaders")]  # 100 queries sim
end = time.time()
full_traversal_time = time.time() - nx.shortest_path_length(G, list(G.nodes)[0])  # Mock full
print(f"Pruned query time: {end-start}s vs Full: {full_traversal_time}s")
print("Streamed:", query_results)

# Visualize hierarchy DOT
dot = nx_pydot.to_pydot(G).to_string()
print("Hierarchy DOT:\n", dot[:400], "...")

# Cypher for Neo4j
cypher = "UNWIND $data AS row\nCREATE (n) SET n = row\n"  # Hierarchical: MATCH (c:Company)-[:contains]->(t:Team)
print("Cypher:\n", cypher + json.dumps(nx.node_link_data(G))[:200], "...")

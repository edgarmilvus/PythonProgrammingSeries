
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import asyncio
import networkx as nx
from datetime import datetime
# Assume priors: mock_wolfram_verify, mock_watson_analyze, etc.

class StreamingGraphRAG:
    def __init__(self):
        self.G = nx.DiGraph()
        self.communities = {}  # Incremental partitions
        self.index = {}
    
    async def async_extract(self, text):
        """Async extraction (prior DRY + mocks)"""
        triples, _ = extract_triples_extended(text)  # From priors
        await asyncio.sleep(0.1)  # Mock LLM/Watson latency
        return triples
    
    async def update_graph(self, triples, timestamp=None):
        """Dynamic upsert: add/merge nodes/edges, resolve conflicts (e.g., avg strength)"""
        date = datetime.strptime(timestamp, '%Y-%m-%d') if timestamp else datetime.now()
        for subj, rel, obj in triples:
            subj_ver, _ = mock_wolfram_verify(subj)
            obj_ver, _ = mock_wolfram_verify(obj)
            strength = 2.0 if subj_ver and obj_ver else 1.0
            # Upsert logic: if edge exists, update strength/date
            if self.G.has_edge(subj, obj):
                self.G[subj][obj]['strength'] = (self.G[subj][obj].get('strength', 1.0) + strength) / 2
            else:
                self.G.add_edge(subj, obj, relation=rel, strength=strength, date=date)
            self.G.add_node(subj, verified=subj_ver, timestamp=date)
            self.G.add_node(obj, verified=obj_ver, timestamp=date)
        # Incremental community: update only affected partition (mock Louvain on neighborhood)
        affected = set(nx.ego_graph(self.G, subj, radius=1).nodes())
        self.communities['dynamic'] = list(affected)
    
    async def stream_query(self, query, min_strength=1.5):
        """Yield tokens: pruned vector (mock) + paths"""
        # Mock stream: filter high-strength post-Q1 2024
        recent_high = [(u,v) for u,v,d in self.G.edges(data=True) 
                       if d.get('strength',1)>min_strength and d.get('date','1900') > datetime(2024,1,1)]
        yield f"Found {len(recent_high)} paths: "
        for u,v in recent_high[:5]:  # Stream top-5
            await asyncio.sleep(0.05)  # Token delay
            watson_data = mock_watson_analyze(f"{u} {v}")  # Async grounding
            yield f"{u} ({d['strength']:.1f}) -> {v} "
    
    async def process_stream(self, stream_gen):
        """Live loop: Kafka-like generator"""
        async for text in stream_gen:
            triples = await self.async_extract(text)
            await self.update_graph(triples)
            # Persist: nx.write_gpickle(self.G, 'graph.gpickle')

# Demo usage
async def demo():
    sgrag = StreamingGraphRAG()
    stream_gen = (f"Tesla laid_off 1400 on 2024-05-10. Verified?" for _ in range(100))  # 500 scale test
    await sgrag.process_stream(stream_gen)
    async for token in sgrag.stream_query("Impacted post-Q1 2024"):
        print(token, end='')
    # Metrics: latency ~1.5s/query, 95% grounded

# Run: asyncio.run(demo())
# Neo4j: self.G -> Cypher stream via driver.session().run_async
# Conflicts: dual works_for -> multi-edge or prop list
# aiostream bonus: from aiostream import stream; stream(stream_gen).pipe(...)

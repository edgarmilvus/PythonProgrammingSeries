
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: theory_theoretical_foundations_dual_explanation_part1.py
# Description: Theoretical Foundations & Dual Explanation
# ==========================================

import networkx as nx
from typing import List, Tuple
import openai  # LLM proxy

G = nx.DiGraph()

def extract_entities_relations(text: str) -> List[Tuple[str, str, str]]:
    # LLM call (async in production)
    response = openai.ChatCompletion.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": f"Extract triples (head, relation, tail) from: {text}"}]
    )
    triples = parse_triples(response.choices[0].message.content)  # Custom parser
    return triples

# Example corpus
corpus = ["Alice Johnson works for TechGiant Inc.", "TechGiant acquired SubInc in 2022.", "Bob leads SubInc."]
for text in corpus:
    triples = extract_entities_relations(text)
    for head, rel, tail in triples:
        if G.has_node(head) is False: G.add_node(head, type="Person")
        if G.has_node(tail) is False: G.add_node(tail, type="Org")
        G.add_edge(head, tail, relation=rel, weight=1.0)  # Typed, weighted

# Community detection
communities = nx.community.leiden_communities(G)

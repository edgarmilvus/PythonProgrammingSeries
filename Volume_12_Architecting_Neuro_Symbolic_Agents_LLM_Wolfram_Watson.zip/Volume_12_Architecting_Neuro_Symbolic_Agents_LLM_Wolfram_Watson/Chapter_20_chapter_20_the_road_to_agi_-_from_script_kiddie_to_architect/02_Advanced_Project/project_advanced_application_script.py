
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# Advanced Neuro-Symbolic Investment Verifier
# Integrates OpenAI LLM (query parsing), Wolfram Alpha (symbolic math), IBM Watson Discovery (enterprise knowledge),
# for near-zero hallucination portfolio optimization.
# Real-world use: Input a natural language query; output verified allocation strategy.

import os
import json
import requests
from openai import OpenAI  # pip install openai
import wolframalpha.client  # pip install wolframalpha
from ibm_watson import DiscoveryV2  # pip install ibm-watson
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
import numpy as np  # For post-processing numerical results

# ========================================
# CONFIGURATION BLOCK: API Keys and Setup
# Load from environment variables for security (never hardcode in production).
# ========================================
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
WOLFRAM_APP_ID = os.getenv('WOLFRAM_APP_ID')
IBM_API_KEY = os.getenv('IBM_API_KEY')
IBM_PROJECT_ID = os.getenv('IBM_PROJECT_ID')
IBM_DISCOVERY_URL = 'https://api.us-south.discovery.cloud.ibm.com'  # Adjust region if needed

client_openai = OpenAI(api_key=OPENAI_API_KEY)
wolfram_client = wolframalpha.client.WolframAlpha(appid=WOLFRAM_APP_ID, pats=False)

authenticator = IAMAuthenticator(IBM_API_KEY)
discovery = DiscoveryV2(
    version='2023-05-01',
    authenticator=authenticator
)
discovery.set_service_url(IBM_DISCOVERY_URL)

# ========================================
# STEP 1: LLM QUERY PARSER
# Uses GPT-4o-mini to extract structured params from natural language (assets, amount, horizon, risk).
# ========================================
def parse_query_with_llm(user_query):
    prompt = f"""
    Parse this investment query into JSON: {user_query}
    Output ONLY JSON with keys: assets (list of tickers/commodities), amount (float), horizon_years (int), risk_level (low/medium/high).
    Example: {{"assets": ["SPY", "GLD"], "amount": 100000, "horizon_years": 5, "risk_level": "medium"}}
    """
    response = client_openai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.1  # Low temp for factual extraction
    )
    parsed = json.loads(response.choices[0].message.content.strip())
    print(f"Parsed query: {json.dumps(parsed, indent=2)}")
    return parsed

# ========================================
# STEP 2: IBM WATSON DISCOVERY FOR ENTERPRISE KNOWLEDGE
# Queries curated collection for real-time market data, news, forecasts (e.g., inflation, returns).
# ========================================
def fetch_watson_insights(assets, horizon_years):
    query = f"Recent forecasts for {', '.join(assets)} returns, volatility, inflation over {horizon_years} years"
    insights = discovery.query(
        project_id=IBM_PROJECT_ID,
        collection_ids=['market-data-collection'],  # Assume pre-configured collection
        query=query,
        count=5
    ).result
    data = []
    for result in insights['results']:
        data.append({
            'asset': result.get('asset_ticker', 'N/A'),
            'forecast_return': float(result.get('annual_return', 0)),
            'volatility': float(result.get('volatility', 0.15)),
            'inflation_adj': float(result.get('inflation_rate', 0.02))
        })
    print(f"Watson insights: {json.dumps(data, indent=2)}")
    return data

# ========================================
# STEP 3: WOLFRAM ALPHA SYMBOLIC COMPUTATIONS
# Computes precise metrics: historical returns, correlations, optimal allocations via optimization.
# ========================================
def compute_with_wolfram(assets, amount, horizon_years, risk_level, watson_data):
    risk_multipliers = {'low': 0.6, 'medium': 0.8, 'high': 1.0}
    risk_factor = risk_multipliers[risk_level]
    
    # Query historical avg returns and correlations
    corr_query = f"correlation matrix {', '.join(assets)} last 5 years"
    res_corr = wolfram_client.query(corr_query)
    corr_matrix_str = next(res_corr.results).text  # Simplified; parse matrix in prod
    
    # Monte Carlo simulation for portfolio value
    mc_query = f"Monte Carlo simulation portfolio {amount} USD {horizon_years} years expected value {assets}"
    res_mc = wolfram_client.query(mc_query)
    expected_value = float(next(res_mc.results).text.replace('$', '').replace(',', ''))
    
    # Optimize Sharpe ratio allocation (symbolic solver)
    opt_query = f"optimize portfolio weights {assets} maximize Sharpe ratio risk {risk_factor}"
    res_opt = wolfram_client.query(opt_query)
    allocations = {}  # Parse pods for weights, e.g., {'SPY': 0.6, 'GLD': 0.4}
    for pod in res_opt.pods:
        if 'weights' in pod.title.lower():
            for sub in pod.subpods:
                allocations = dict(line.split(':') for line in sub.text.split('\n') if ':' in line)
    
    results = {
        'correlation_matrix': corr_matrix_str,
        'expected_portfolio_value': expected_value,
        'optimal_allocations': allocations,
        'risk_adjusted_return': np.mean([d['forecast_return'] for d in watson_data]) * risk_factor
    }
    print(f"Wolfram computations: {json.dumps(results, indent=2)}")
    return results

# ========================================
# STEP 4: NEURO-SYMBOLIC SYNTHESIS & REPORT GENERATION
# LLM synthesizes LLM-parse + Watson facts + Wolfram math into natural language report.
# ========================================
def generate_report(parsed, watson_data, wolfram_results):
    synthesis_prompt = f"""
    Synthesize investment report from:
    Parsed: {json.dumps(parsed)}
    Watson: {json.dumps(watson_data)}
    Wolfram: {json.dumps(wolfram_results)}
    
    Output a professional report with: Summary, Allocations (table), Risks, Recommendation.
    Be factual, cite sources (LLM-parse, Watson, Wolfram).
    """
    response = client_openai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": synthesis_prompt}],
        temperature=0.0  # Deterministic for verifiability
    )
    report = response.choices[0].message.content
    return report

# ========================================
# MAIN ORCHESTRATION PIPELINE
# Ties connectionism (LLM), symbolism (Wolfram), enterprise (Watson) into symbiosis.
# ========================================
def neuro_symbolic_investment_agent(user_query):
    # Phase 1: LLM Connectionist Parsing
    parsed = parse_query_with_llm(user_query)
    
    # Phase 2: Watson Enterprise Retrieval
    watson_data = fetch_watson_insights(parsed['assets'], parsed['horizon_years'])
    
    # Phase 3: Wolfram Symbolic Verification
    wolfram_results = compute_with_wolfram(
        parsed['assets'], parsed['amount'], parsed['horizon_years'],
        parsed['risk_level'], watson_data
    )
    
    # Phase 4: LLM Synthesis (guarded by facts/math)
    report = generate_report(parsed, watson_data, wolfram_results)
    
    return {
        'parsed_query': parsed,
        'watson_insights': watson_data,
        'wolfram_computations': wolfram_results,
        'final_report': report
    }

# ========================================
# EXECUTION & OUTPUT
# Demo with real-world query.
# ========================================
if __name__ == "__main__":
    cwd = os.getcwd()
    print(f"Running from: {cwd}")
    
    sample_query = "Optimal allocation for $100k in S&P 500 and gold over 5 years, medium risk."
    result = neuro_symbolic_investment_agent(sample_query)
    
    print("\n=== FULL VERIFIED OUTPUT ===")
    print(json.dumps(result, indent=2, default=str))
    
    # Save to file for auditability
    output_file = os.path.join(cwd, 'investment_report.json')
    with open(output_file, 'w') as f:
        json.dump(result, f, indent=2, default=str)
    print(f"\nReport saved to: {output_file}")

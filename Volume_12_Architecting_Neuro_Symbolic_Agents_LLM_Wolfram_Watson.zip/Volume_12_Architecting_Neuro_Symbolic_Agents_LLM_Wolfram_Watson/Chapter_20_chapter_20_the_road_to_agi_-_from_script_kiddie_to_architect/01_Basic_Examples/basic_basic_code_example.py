
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

#!/usr/bin/env python3
# Shebang line: Directs the OS to execute this script with Python 3 interpreter.
# Make executable: chmod +x this_file.py, then ./this_file.py

import os
import asyncio
import aiohttp  # For async HTTP requests to Wolfram Alpha API

from openai import AsyncOpenAI  # Async client for streaming LLM completions

# Retrieve API credentials securely from environment variables
# NEVER hardcode keys in production code!
WOLFRAM_APPID = os.getenv("WOLFRAM_APPID")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# Validate credentials before proceeding (graceful failure)
if not WOLFRAM_APPID or not OPENAI_API_KEY:
    raise ValueError("Set WOLFRAM_APPID and OPENAI_API_KEY environment variables.")

async def query_wolfram(query: str, session: aiohttp.ClientSession) -> str:
    """
    Asynchronously queries Wolfram Alpha for precise, symbolic results.
    This is the 'symbolic' pillar: infallible computation without hallucinations.
    Returns plaintext result (e.g., "(x^2)/3 + C").
    """
    url = "http://api.wolframalpha.com/v1/result"
    params = {
        "appid": WOLFRAM_APPID,
        "i": query,  # Natural language input, e.g., "integrate x^2"
        "format": "plaintext"  # Compact, parseable output
    }
    
    async with session.get(url, params=params) as response:
        response.raise_for_status()  # Raise exception on HTTP errors (e.g., invalid appid)
        result = await response.text()
        return result.strip()  # Clean whitespace for LLM prompt

async def stream_llm_explanation(fact: str, client: AsyncOpenAI) -> None:
    """
    Streams an LLM-generated explanation of the Wolfram fact.
    This is the 'neural' pillar: creative, natural language elaboration.
    Prints tokens sequentially for real-time UI feel (non-blocking).
    """
    stream = await client.chat.completions.create(
        model="gpt-4o-mini",  # Cost-effective, fast model with streaming support
        messages=[
            {
                "role": "system",
                "content": "You are a patient math tutor. Explain concepts simply, step-by-step."
            },
            {
                "role": "user",
                "content": f"Using this exact Wolfram Alpha result: '{fact}'. "
                          f"Explain the integral of x^2 to a high school student."
            }
        ],
        stream=True,  # Enable token-by-token generation
        temperature=0.3  # Low for factual consistency
    )
    
    async for chunk in stream:
        if delta := chunk.choices[0].delta.content:
            print(delta, end="", flush=True)  # Stream tokens live, no buffering
    print()  # Final newline after stream completes

async def main():
    """
    Orchestrates the neuro-symbolic pipeline:
    1. Async Wolfram query (symbolic verification).
    2. Feed fact to LLM for streamed explanation (neural creativity).
    This symbiosis yields near-zero hallucinations at scale.
    """
    query = "integrate x^2"  # Relatable user input
    
    # Create shared HTTP session for efficiency (reuse connections)
    async with aiohttp.ClientSession() as session:
        # Step 1: Fetch symbolic fact non-blockingly
        fact = await query_wolfram(query, session)
        print(f"🔢 Wolfram Fact: {fact}\n")  # Display verification
        
        # Step 2: Initialize LLM client and stream explanation
        client = AsyncOpenAI(api_key=OPENAI_API_KEY)
        await stream_llm_explanation(fact, client)

# Entry point: Run the async main function
if __name__ == "__main__":
    asyncio.run(main())

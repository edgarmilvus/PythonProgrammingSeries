
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

#!/usr/bin/env python3
import os
import json
import matplotlib.pyplot as plt
import openai
from NeuroSymAgentV2 import NeuroSymAgentV2  # From Ex3
import time
import os.path as path

BASE_DIR = os.getcwd()
EVO_LOGS_DIR = path.join(BASE_DIR, 'evo_logs')
GOLDEN_QUERIES = [
    "Escape velocity Mars?", "Flu incubation?", "Optimize Mars fuel", "E=mc^2 derivation",
    "Supply chain Mars colony", "Fusion reactor plan", "COVID symptoms", "TB incubation",
    "Newton gravity", "Quantum entanglement"  # 10 benchmarks (req 1)
]
os.makedirs(EVO_LOGS_DIR, exist_ok=True)

client = openai.OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
agent = NeuroSymAgentV2()
few_shots = []  # Evolving few-shot examples

def score_truth(response: str, golden: str) -> float:
    """Benchmark score 0-1."""
    prompt = f"Truth match 0-1: Response '{response}' vs expected '{golden}'."
    resp = client.chat.completions.create(model="gpt-4o-mini", messages=[{"role": "user", "content": prompt}])
    return float(resp.choices[0].message.content.strip() or 0)

def evolve_prompts():
    """Req 3: Append top-5 corrections as few-shot."""
    global few_shots
    failures = []
    for log_file in sorted(os.listdir(EVO_LOGS_DIR))[-10:]:  # Recent
        with open(path.join(EVO_LOGS_DIR, log_file)) as f:
            data = json.load(f)
            if data['status'] == 'failure':
                failures.append(data['diff'])
    top5 = failures[-5:]
    few_shots = [{"role": "user", "content": f}, {"role": "assistant", "content": "Corrected"} for f in top5]

def run_benchmark(query: str, iter_num: int) -> tuple:
    # Inject evolved few-shots into agent prompts (sim: prepend to agent.run)
    response = agent.run(query + "\nFew-shots: " + str(few_shots))
    # Sim golden (real: Wolfram/Watson truth)
    golden = "Verified fact"  # Placeholder; integrate symbiosis scores
    score = score_truth(response, golden)
    
    log_data = {'query': query, 'response': response, 'score': score, 'iter': iter_num}
    if score < 0.9:
        log_data['status'] = 'failure'
        log_data['diff'] = f"Low score: {score} vs expected verified"
    
    log_file = path.join(EVO_LOGS_DIR, f'iter_{iter_num}_{int(time.time())}.json')
    with open(log_file, 'w') as f:
        json.dump(log_data, f)
    
    return score, log_data

def main():
    scores_history = []
    for i in range(1, 101):  # 100 iters (req 6)
        query = GOLDEN_QUERIES[(i-1) % len(GOLDEN_QUERIES)]
        score, _ = run_benchmark(query, i)
        scores_history.append(score)
        
        # Every 10: Evolve
        if i % 10 == 0:
            evolve_prompts()
        
        avg = sum(scores_history[-10:]) / 10
        print(f"Iter {i}: Score {score:.2f}, 10-avg {avg:.2f}")
        
        # Monotonic check (req 7): Warn if drop
        if len(scores_history) > 1 and score < scores_history[-2] * 0.95:
            print("Warning: Non-monotonic; retrying...")
            time.sleep(1)
    
    # Plot improvement (req 6)
    plt.plot(scores_history)
    plt.title('Truth Gain Curve')
    plt.ylabel('Avg Score')
    plt.xlabel('Iterations')
    plt.savefig(path.join(EVO_LOGS_DIR, 'improvement.png'))
    plt.show()
    print("Capstone complete: See evo_logs/ & plot.")

if __name__ == '__main__':
    main()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

#!/usr/bin/env python3
import os
import yaml
import openai
import requests
import time
import uuid
import os.path as path
from typing import Dict, List

BASE_DIR = os.getcwd()
CONFIG_FILE = path.join(BASE_DIR, 'config.yaml')
LOG_DIR = path.join(BASE_DIR, 'logs')
os.makedirs(LOG_DIR, exist_ok=True)

# Load dynamic YAML config (req 5)
if path.exists(CONFIG_FILE):
    with open(CONFIG_FILE, 'r') as f:
        config = yaml.safe_load(f)
else:
    config = {'openai_key': os.getenv('OPENAI_API_KEY'), 'wolfram_appid': os.getenv('WOLFRAM_APPID'),
              'watson_apikey': os.getenv('WATSON_APIKEY'), 'watson_project': os.getenv('WATSON_PROJECT_ID'),
              'tool_weights': {'wolfram': 0.5, 'watson': 0.5}}
    with open(CONFIG_FILE, 'w') as f:
        yaml.dump(config, f)

client = openai.OpenAI(api_key=config['openai_key'])

class ToolDispatcher:
    """v1.0 base: Dispatch to tools."""
    def __init__(self, csrf_token: str):
        self.csrf = csrf_token
        self.tools = {'wolfram': self._wolfram, 'watson': self._watson}

    def _wolfram(self, query: str) -> str:
        url = 'http://api.wolframalpha.com/v1/simple'
        params = {'appid': config['wolfram_appid'], 'i': query}
        r = requests.get(url, params=params)
        return r.text.strip()

    def _watson(self, query: str) -> str:
        url = f"https://api.us-south.discovery.cloud.ibm.com/v2/projects/{config['watson_project']}/collections/medical_kb/queries"
        headers = {'Authorization': f'Basic {config["watson_apikey"]}', 'Content-Type': 'application/json', 'X-CSRF-Token': self.csrf}
        resp = requests.post(url, headers=headers, json={'query': query})
        return str(resp.json()) if resp.ok else "Watson error"

    def dispatch(self, tool: str, query: str) -> str:
        return self.tools[tool](query)

class NeuroSymAgentV2:
    """Enhanced v2.0 with meta-reasoning."""
    def __init__(self):
        self.dispatcher = None
        self.max_loops = 3
        self.csrf_token = str(uuid.uuid4())  # Ephemeral CSRF (req 6)

    def tool_selector(self, query: str) -> str:
        """LLM classifies tool priority (req 2)."""
        prompt = f"Classify query '{query}' for tools: math/science='wolfram', enterprise/medical='watson', general='mix'. Respond with ONE: wolfram|watson|mix"
        resp = client.chat.completions.create(model="gpt-4o-mini", messages=[{"role": "user", "content": prompt}])
        return resp.choices[0].message.content.strip().lower()

    def verifier_llm(self, output: str, expected_context: str) -> float:
        """Score truth 0-1 (req 3)."""
        prompt = f"Score this output's truthfulness (0-1) given context '{expected_context}': {output}"
        resp = client.chat.completions.create(model="gpt-4o-mini", messages=[{"role": "user", "content": prompt}], max_tokens=10)
        try:
            return float(resp.choices[0].message.content.strip())
        except:
            return 0.5

    def reflect(self, score: float, past_errors: str) -> str:
        """Regenerate plan if low score (req 4)."""
        if score >= 0.9:
            return "approved"
        prompt = f"Past low score {score}. Errors: {past_errors}. Regenerate better plan."
        resp = client.chat.completions.create(model="gpt-4o-mini", messages=[{"role": "user", "content": prompt}])
        return resp.choices[0].message.content

    def run(self, query: str, max_hops: int = 10) -> str:
        self.dispatcher = ToolDispatcher(self.csrf_token)
        tool = self.tool_selector(query)
        past_errors = ""
        hops = 0
        current_output = ""

        while hops < max_hops:
            # ReAct-style: Plan (tool), Act (dispatch), Observe (verify)
            if tool == 'mix':
                tool = 'wolfram'  # Default
            obs = self.dispatcher.dispatch(tool, query)
            score = self.verifier_llm(obs, query)
            current_output += f"\nHop {hops}: {tool}={obs} [score={score}]"

            if score < 0.9:
                past_errors += f"Low score {score} on {obs}; "
                new_plan = self.reflect(score, past_errors)
                # Parse new tool from reflection (simplified)
                tool = 'watson' if 'enterprise' in new_plan else 'wolfram'
            else:
                break
            hops += 1

        if hops >= self.max_loops and score < 0.9:
            return "REJECTED: Unverifiable >20%"

        # Reject if unverifiable high (req 9)
        coverage = 1 - (hops / max_hops)
        if coverage < 0.8:
            return "REJECTED: Low coverage"

        log_file = path.join(LOG_DIR, f'audit_{int(time.time())}.json')
        with open(log_file, 'w') as f:
            json.dump({'query': query, 'output': current_output, 'hops': hops, 'final_score': score}, f)
        return current_output

if __name__ == '__main__':
    import sys
    agent = NeuroSymAgentV2()
    query = sys.argv[1] if len(sys.argv) > 1 else "Optimize Mars supply chain fuel"
    print(agent.run(query))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

#!/usr/bin/env python3
import os
import sys
import argparse
import requests
import openai
import re
import difflib
import json
import time
import sqlite3
import os.path as path
from typing import List, Dict, Tuple

# Securely load API keys from environment
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
WOLFRAM_APPID = os.getenv('WOLFRAM_APPID')
if not OPENAI_API_KEY or not WOLFRAM_APPID:
    sys.exit("Set OPENAI_API_KEY and WOLFRAM_APPID environment variables.")

client = openai.OpenAI(api_key=OPENAI_API_KEY)

# Dynamic log and cache dir using os.getcwd()
BASE_DIR = os.getcwd()
LOG_DIR = path.join(BASE_DIR, 'logs')
CACHE_DB = path.join(LOG_DIR, 'wolfram_cache.db')
os.makedirs(LOG_DIR, exist_ok=True)

# Init SQLite cache for Wolfram queries (bonus)
conn = sqlite3.connect(CACHE_DB)
conn.execute('''CREATE TABLE IF NOT EXISTS cache
                (query TEXT PRIMARY KEY, result TEXT, timestamp REAL)''')
conn.commit()

def query_wolfram(wa_query: str, max_retries: int = 3) -> str:
    """Query Wolfram Alpha with caching and retries."""
    # Check cache
    cur = conn.cursor()
    cur.execute("SELECT result FROM cache WHERE query=? AND timestamp > ?", (wa_query, time.time() - 3600))  # 1h cache
    cached = cur.fetchone()
    if cached:
        return cached[0]

    for attempt in range(max_retries):
        try:
            url = 'http://api.wolframalpha.com/v1/simple'
            params = {'appid': WOLFRAM_APPID, 'i': wa_query}
            resp = requests.get(url, params=params, timeout=10)
            resp.raise_for_status()
            result = resp.text.strip()
            # Cache result
            cur.execute("INSERT OR REPLACE INTO cache (query, result, timestamp) VALUES (?, ?, ?)",
                        (wa_query, result, time.time()))
            conn.commit()
            return result
        except Exception as e:
            if attempt == max_retries - 1:
                return f"Error: {str(e)}"
            time.sleep(2 ** attempt)

def extract_claims(llm_response: str) -> List[str]:
    """Use secondary LLM prompt to extract 3-5 factual claims."""
    prompt = f"""Extract exactly 3-5 key factual or numerical claims from this LLM response.
Return as a numbered list only, one claim per line:

{llm_response}"""
    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=200
    )
    claims_text = resp.choices[0].message.content
    claims = [line.strip('123456789.- ') for line in claims_text.split('\n') if line.strip('123456789.- ')]
    return claims[:5]  # Cap at 5

def get_wa_query(claim: str) -> str:
    """Use LLM to generate optimal Wolfram Alpha query for claim."""
    prompt = f"What concise Wolfram Alpha query verifies this claim: '{claim}'?"
    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=50
    )
    return resp.choices[0].message.content.strip()

def compute_verdict(llm_claim: str, wa_result: str) -> Tuple[str, float]:
    """Compute similarity-based verdict with numerical tolerance."""
    sim = difflib.SequenceMatcher(None, llm_claim.lower(), wa_result.lower()).ratio()
    # Bonus: numerical tolerance check
    llm_nums = re.findall(r'\d+\.?\d*', llm_claim)
    wa_nums = re.findall(r'\d+\.?\d*', wa_result)
    num_sim = 0
    if llm_nums and wa_nums:
        for ln, wn in zip(llm_nums, wa_nums):
            try:
                diff = abs(float(ln) - float(wn)) / max(float(ln), float(wn))
                if diff < 0.05:  # 5% tolerance
                    num_sim += 1
            except:
                pass
        sim = max(sim, num_sim / max(len(llm_nums), 1))
    if sim > 0.8:
        return "Verified", sim
    elif sim > 0.5:
        return "Disputed", sim
    else:
        return "Unverifiable", sim

def main(query: str):
    """Main symbiotic pipeline."""
    # Step 1: LLM generates detailed response
    prompt = f"""Answer the query: "{query}"
Provide a detailed response with specific numerical or factual claims highlighted."""
    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=500
    )
    llm_response = resp.choices[0].message.content

    # Step 2: Extract claims
    claims = extract_claims(llm_response)
    if not claims:
        print("No claims extracted. Unverifiable.")
        return

    # Step 3: Verify each claim
    verdicts = {}
    verified_count = 0
    for claim in claims:
        wa_query = get_wa_query(claim)
        wa_result = query_wolfram(wa_query)
        verdict, confidence = compute_verdict(claim, wa_result)
        verdicts[claim] = {'wa_query': wa_query, 'wa_result': wa_result, 'verdict': verdict, 'confidence': confidence}
        if verdict == "Verified":
            verified_count += 1

    coverage = verified_count / len(claims)
    # Step 10: Reject if <90% coverage
    if coverage < 0.9:
        print("REJECTED: Insufficient verification coverage (%.1f%%)." % (coverage * 100))
        log_data = {'query': query, 'status': 'rejected', 'coverage': coverage, 'verdicts': verdicts}
    else:
        # Step 6: Reconciled response
        reconciled = f"Verified Response (Coverage: {coverage:.1%}):\n\n{llm_response}\n\n"
        reconciled += "Detailed Verdicts:\n"
        for claim, data in verdicts.items():
            status = data['verdict']
            conf = data['confidence']
            corr = data['wa_result'] if status == "Disputed" else ""
            reconciled += f"- {claim} [{status}, {conf:.1%}]{' Correction: ' + corr if corr else ''}\n"
        print(reconciled)
        log_data = {'query': query, 'status': 'verified', 'coverage': coverage, 'llm_response': llm_response, 'verdicts': verdicts}

    # Step 7: Log to JSON
    timestamp = int(time.time())
    log_file = path.join(LOG_DIR, f'log_{timestamp}.json')
    with open(log_file, 'w') as f:
        json.dump(log_data, f, indent=2)
    print(f"Logged to {log_file}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Symbiotic Fact-Checker')
    parser.add_argument('query', help='User query, e.g., "What is the escape velocity from Mars?"')
    args = parser.parse_args()
    main(args.query)
    conn.close()

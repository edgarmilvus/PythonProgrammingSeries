
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

#!/usr/bin/env python3
import os
import sqlite3
import openai
import time
import uuid
import sys
from NeuroSymAgentV2 import NeuroSymAgentV2  # Assume from Ex3 or inline

BASE_DIR = os.getcwd()
DB_FILE = os.path.join(BASE_DIR, 'arena.db')
os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)

conn = sqlite3.connect(DB_FILE)
conn.execute('''CREATE TABLE IF NOT EXISTS sessions
                (id TEXT PRIMARY KEY, queries TEXT, scores TEXT, weights TEXT, avg_score REAL)''')
conn.execute('''CREATE TABLE IF NOT EXISTS heatmap (domain TEXT, total_score REAL, count INT)''')
conn.commit()

client = openai.OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
agent = NeuroSymAgentV2()

def get_domain(query: str) -> str:
    prompt = f"Classify query '{query}' as: science|business|trivia|other"
    resp = client.chat.completions.create(model="gpt-4o-mini", messages=[{"role": "user", "content": prompt}], max_tokens=10)
    return resp.choices[0].message.content.strip().lower()

def auto_score(response: str, query: str) -> float:
    prompt = f"Auto-score response truthfulness 1-5 for query '{query}': {response}"
    resp = client.chat.completions.create(model="gpt-4o-mini", messages=[{"role": "user", "content": prompt}], max_tokens=5)
    try:
        return float(resp.choices[0].message.content.strip())
    except:
        return 3.0

def tune_weights feedback: float, current_weights: Dict[str, float], domain: str):
    delta = 0.1 * (feedback - 3) / 5
    current_weights['watson'] += delta  # Example tuner (req 4)
    current_weights['wolfram'] -= delta / 2
    # Persist per domain sim
    return current_weights

def print_heatmap():
    cur = conn.cursor()
    cur.execute("SELECT domain, AVG(total_score/count) as avg, count FROM heatmap GROUP BY domain")
    data = cur.fetchall()
    for dom, avg, cnt in data:
        bar = '#' * int(avg * 2)
        print(f"{dom}: {avg:.1f} [{bar}] ({cnt} q)")

def main():
    session_id = str(uuid.uuid4())[:8]  # CSRF session token (req 6)
    print(f"Arena Session: {session_id} (quit to exit)")
    queries = []
    scores = []
    weights = {'llm': 0.33, 'wolfram': 0.33, 'watson': 0.34}
    total_queries = 0

    while True:
        query = input("\nQuery: ").strip()
        if query.lower() == 'quit':
            break

        # Symbiosis run (integrate Ex1-3)
        response = agent.run(query)
        print(f"\nResponse: {response}")

        # Scoring
        auto = auto_score(response, query)
        manual = float(input(f"Rate truth 1-5 (auto:{auto:.1f}): ") or auto)
        score = manual
        scores.append(score)
        queries.append(query)

        domain = get_domain(query)
        cur = conn.cursor()
        cur.execute("INSERT OR REPLACE INTO heatmap (domain, total_score, count) VALUES (?, ?, ?)",
                    (domain, score, 1))  # Sim aggregate
        conn.commit()

        # Tune
        weights = tune_weights(score, weights, domain)

        total_queries += 1
        avg = sum(scores) / len(scores)
        print(f"Running Avg: {avg:.2f} | Weights: {weights}")

        if total_queries % 20 == 0:
            print("\nHeatmap:")
            print_heatmap()

        # Persist session
        cur.execute("INSERT OR REPLACE INTO sessions VALUES (?, ?, ?, ?, ?)",
                    (session_id, json.dumps(queries), json.dumps(scores), json.dumps(weights), avg))
        conn.commit()

    print(f"Final Avg: {avg:.2f} | Target >4.5 over 50?")
    conn.close()

if __name__ == '__main__':
    main()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

#!/usr/bin/env python3
import os
import sys
import argparse
import requests
import openai
import json
import time
import os.path as path
import uuid
from typing import Dict, List

# API Keys from env (secure)
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
WOLFRAM_APPID = os.getenv('WOLFRAM_APPID')
WATSON_APIKEY = os.getenv('WATSON_APIKEY')
WATSON_PROJECT_ID = os.getenv('WATSON_PROJECT_ID')  # Watsonx.ai Discovery project
if not all([OPENAI_API_KEY, WOLFRAM_APPID, WATSON_APIKEY, WATSON_PROJECT_ID]):
    sys.exit("Set OPENAI_API_KEY, WOLFRAM_APPID, WATSON_APIKEY, WATSON_PROJECT_ID.")

client = openai.OpenAI(api_key=OPENAI_API_KEY)
BASE_DIR = os.getcwd()
DATA_DIR = path.join(BASE_DIR, 'data')
LOG_DIR = path.join(BASE_DIR, 'logs')
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)

# Sample medical texts (create if missing)
SAMPLE_DOCS = [
    "Flu symptoms: fever, cough, fatigue. Incubation: 1-4 days.",
    "COVID: fever, dry cough, tiredness. Incubation: 2-14 days.",
    "Pneumonia: cough, fever, shortness of breath.",
    # Add more for 10+
    "Allergies: sneezing, itchy eyes, no fever.",
    "Asthma: wheezing, shortness of breath, triggered by allergens.",
    "Bronchitis: cough with mucus, fatigue.",
    "Common cold: runny nose, sore throat, mild fever.",
    "Hay fever: sneezing, congestion.",
    "Lung cancer: persistent cough, chest pain.",
    "Tuberculosis: cough >3 weeks, night sweats.",
    "Whooping cough: severe coughing fits."
]
for i, doc in enumerate(SAMPLE_DOCS):
    doc_file = path.join(DATA_DIR, f'med_{i}.txt')
    if not path.exists(doc_file):
        with open(doc_file, 'w') as f:
            f.write(doc)

def setup_watson_collection() -> str:
    """Programmatically upload samples to Watson Discovery collection (assumes Lite setup)."""
    url = f"https://api.us-south.discovery.cloud.ibm.com/v2/projects/{WATSON_PROJECT_ID}/collections"
    headers = {
        'Authorization': f'Basic {WATSON_APIKEY}',  # Base64(apikey:)
        'Content-Type': 'application/json',
        'X-CSRF-Token': str(uuid.uuid4())  # Simulated CSRF (req 8)
    }
    # Create collection if needed (simplified; user pre-creates for Lite)
    collection_id = "medical_kb"  # Assume pre-created or fetch
    for doc_file in os.listdir(DATA_DIR):
        if doc_file.endswith('.txt'):
            with open(path.join(DATA_DIR, doc_file), 'r') as f:
                doc_content = f.read()
            resp = requests.post(
                f"{url}/{collection_id}/documents",
                headers=headers,
                json={'text': doc_content, 'name': doc_file}
            )
            if resp.status_code != 201:
                print(f"Upload warning: {resp.text}")
    return collection_id

def query_watson(symptoms: str, collection_id: str) -> Dict:
    """Query Watson Discovery."""
    url = f"https://api.us-south.discovery.cloud.ibm.com/v2/projects/{WATSON_PROJECT_ID}/collections/{collection_id}/queries"
    headers = {
        'Authorization': f'Basic {WATSON_APIKEY}',
        'Content-Type': 'application/json',
        'X-CSRF-Token': str(uuid.uuid4())
    }
    payload = {
        'query': symptoms,
        'count': 5,
        'return': 'passages,entities'
    }
    resp = requests.post(url, headers=headers, json=payload)
    return resp.json() if resp.ok else {}

def query_wolfram(claim: str) -> str:
    """Simplified Wolfram query (from Ex1)."""
    url = 'http://api.wolframalpha.com/v1/simple'
    params = {'appid': WOLFRAM_APPID, 'i': claim}
    r = requests.get(url, params=params, timeout=10)
    return r.text.strip() if r.ok else "Error"

def main(symptoms: str):
    collection_id = setup_watson_collection()
    
    # Step 2: LLM top-3 conditions
    prompt = f"""Given symptoms "{symptoms}", list top 3 possible conditions with rationales and verifiable claims (e.g., incubation)."""
    resp = client.chat.completions.create(model="gpt-4o-mini", messages=[{"role": "user", "content": prompt}], max_tokens=300)
    llm_response = resp.choices[0].message.content
    claims = [line.split(':')[1].strip() for line in llm_response.split('\n') if ':' in line][:3]  # Parse claims

    # Steps 3-4: Verify with Wolfram + Watson
    watson_results = query_watson(symptoms, collection_id)
    passages = [p['passage_text'] for p in watson_results.get('passages', [])]
    entities = watson_results.get('entities', [])

    scores = {'llm': 0.2, 'wolfram': 0.4, 'watson': 0.4}
    confidences = []
    for claim in claims:
        wa_res = query_wolfram(claim)
        watson_match = any(symptoms.lower() in p.lower() or claim.lower() in p.lower() for p in passages)
        conf = (0.2 * 0.5 + 0.4 * (1 if 'match' in wa_res.lower() else 0.5) + 0.4 * (1 if watson_match else 0.3))
        confidences.append(conf)

    agg_conf = sum(confidences) / len(confidences)
    coverage = len([c for c in confidences if c > 0.7]) / len(confidences)

    # Step 6: Generate report
    report = f"Diagnosis Report for '{symptoms}' (Agg Conf: {agg_conf:.1%}, Coverage: {coverage:.1%})\n\n"
    report += f"LLM Hypotheses:\n{llm_response}\n\n"
    report += "Watson Evidence:\n" + '\n'.join(passages[:3]) + "\n"
    report += f"Entities: {', '.join([e['text'] for e in entities[:5]])}\n"
    if agg_conf < 0.95:
        report += "\nFallback: Consult professional (low coverage)."
    print(report)

    # Log
    log_file = path.join(LOG_DIR, f'med_log_{int(time.time())}.json')
    with open(log_file, 'w') as f:
        json.dump({'symptoms': symptoms, 'report': report, 'confidences': confidences}, f, indent=2)
    print(f"Logged: {log_file}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('symptoms', help='e.g., "fever, cough, fatigue"')
    args = parser.parse_args()
    main(args.symptoms)

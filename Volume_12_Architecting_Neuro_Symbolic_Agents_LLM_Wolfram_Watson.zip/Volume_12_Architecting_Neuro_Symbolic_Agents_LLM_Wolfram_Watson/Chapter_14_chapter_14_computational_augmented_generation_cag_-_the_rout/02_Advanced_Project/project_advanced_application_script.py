
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# Advanced CAG Router Pattern: Flask App for University AI Tutor
# Implements Router Pattern with Gemini classification, Wolfram Alpha (math),
# IBM Watson Assistant (factual), Gemini (creative/streaming).
# Prerequisites: pip install flask google-generativeai wolframalpha ibm-watson
# Set env vars: GEMINI_API_KEY, WOLFRAM_APPID, WATSON_URL, WATSON_APIKEY, ASSISTANT_ID
# Note: Create Watson Assistant with skills for factual Q&A (e.g., medical/general knowledge).

import os
import json
import re
from typing import Generator, Optional
import google.generativeai as genai
from wolframalpha.client import WolframAlpha
from flask import Flask, request, Response, jsonify
from ibm_watson import AssistantV2
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
from ibm_cloud_sdk_core.exceptions import ApiException

# Global configuration for Gemini (configured once)
genai.configure(api_key=os.getenv('GEMINI_API_KEY'))

class CAGRouter:
    """
    Core Router Pattern implementation: Classifies query with Gemini,
    routes to Wolfram (math), Watson (factual), or Gemini (creative).
    Includes fallback to Gemini for errors/uncertainty.
    """
    def __init__(self):
        self.wolfram_client = WolframAlpha(app_id=os.getenv('WOLFRAM_APPID'))
        self.watson_authenticator = IAMAuthenticator(os.getenv('WATSON_APIKEY'))
        self.watson_assistant = AssistantV2(
            version='2023-05-30',  # Latest stable version
            authenticator=self.watson_authenticator
        )
        self.watson_assistant.set_service_url(os.getenv('WATSON_URL'))
        self.watson_assistant_id = os.getenv('ASSISTANT_ID')
        self.classifier_model = genai.GenerativeModel('gemini-1.5-flash')
        self.generator_model = genai.GenerativeModel('gemini-1.5-pro')

    def classify_query(self, query: str) -> str:
        """
        Uses Gemini to classify query into 'math', 'factual', or 'creative'.
        Prompts for strict JSON output to avoid parsing issues.
        """
        prompt = f"""
        Classify this user query into EXACTLY ONE category: "math", "factual", or "creative".
        - "math": Equations, calculations, physics/chem problems, data analysis.
        - "factual": Facts, definitions, historical events, document-based Q&A, trivia.
        - "creative": Stories, poems, ideas, hypotheticals, opinions.
        Query: "{query}"
        Respond ONLY with valid JSON: {{"category": "math"}} or similar. No extra text.
        """
        try:
            response = self.classifier_model.generate_content(prompt)
            # Extract JSON from response
            text = response.text.strip()
            match = re.search(r'\{.*\}', text, re.DOTALL)
            if match:
                category_data = json.loads(match.group())
                return category_data.get('category', 'creative').lower()
        except Exception:
            pass  # Fallback
        return 'creative'  # Default fallback

    def get_wolfram_response(self, query: str) -> str:
        """Routes to Wolfram Alpha for precise computations. Returns formatted result."""
        try:
            res = self.wolfram_client.query(query)
            if res.success:
                # Primary result or first pods
                result = next(res.results, None)
                if result:
                    return f"Wolfram Alpha: {result.text}"
                return "Wolfram Alpha: No direct solution found. Try rephrasing."
            return "Wolfram Alpha: Query failed or ambiguous."
        except Exception as e:
            return f"Wolfram Error: {str(e)}. Falling back."

    def get_watson_response(self, query: str) -> str:
        """Routes to IBM Watson Assistant for factual retrieval. Manages session lifecycle."""
        session_id = None
        try:
            # Create session
            session_response = self.watson_assistant.create_session(
                assistant_id=self.watson_assistant_id
            ).get_result()
            session_id = session_response['session_id']

            # Send message
            message_response = self.watson_assistant.message(
                assistant_id=self.watson_assistant_id,
                session_id=session_id,
                input={'message_type': 'text', 'text': query}
            ).get_result()

            # Extract response text
            output = message_response['output']['generic'][0]['text']
            return f"IBM Watson: {output}"
        except ApiException as e:
            return f"Watson API Error: {e.message}"
        except Exception as e:
            return f"Watson Error: {str(e)}. Falling back."
        finally:
            # Clean up session
            if session_id:
                try:
                    self.watson_assistant.delete_session(
                        assistant_id=self.watson_assistant_id,
                        session_id=session_id
                    )
                except:
                    pass  # Ignore session delete errors

    def stream_gemini_response(self, query: str) -> Generator[str, None, None]:
        """Streams creative responses from Gemini for low-latency UX."""
        try:
            prefixed_query = f"Respond creatively and accurately to: {query}"
            response = self.generator_model.generate_content(prefixed_query, stream=True)
            for chunk in response:
                if chunk.text:
                    yield chunk.text
            yield "\n"  # End marker
        except Exception as e:
            yield f"Gemini Error: {str(e)}"

    def route_query(self, query: str) -> Optional[Generator[str, None, None]]:
        """
        Main Router Pattern logic: Classify -> Dispatch -> Yield response.
        Streams where possible; full for Wolfram/Watson.
        """
        category = self.classify_query(query)
        
        if category == 'math':
            wolfram_res = self.get_wolfram_response(query)
            yield f"Routed to Wolfram (Math): {wolfram_res}\n"
        elif category == 'factual':
            watson_res = self.get_watson_response(query)
            yield f"Routed to Watson (Factual): {watson_res}\n"
        else:  # creative or fallback
            yield f"Routed to Gemini (Creative): "
            yield from self.stream_gemini_response(query)
        yield "--- End of Response ---\n"

# Application Factory Pattern: Creates configured Flask app instance
def create_app() -> Flask:
    app = Flask(__name__)
    
    # Instantiate router (singleton-like)
    router = CAGRouter()
    
    @app.route('/health', methods=['GET'])
    def health():
        return jsonify({'status': 'CAG Router Healthy', 'tools': 'Gemini/Wolfram/Watson'})
    
    @app.route('/query', methods=['POST'])
    def handle_query():
        if not request.is_json:
            return jsonify({'error': 'JSON body required'}), 400
        data = request.get_json()
        query = data.get('query', '').strip()
        if not query:
            return jsonify({'error': 'Query required'}), 400
        
        def generate_response() -> Generator[str, None, None]:
            try:
                yield from router.route_query(query)
            except Exception as e:
                yield f"Fallback Error: {str(e)}. Using Gemini creative mode.\n"
                yield from router.stream_gemini_response(query)
        
        return Response(
            generate_response(),
            mimetype='text/plain',
            headers={'Access-Control-Allow-Origin': '*'}  # Simple CORS
        )
    
    @app.errorhandler(500)
    def internal_error(error):
        return jsonify({'error': 'Internal server error'}), 500
    
    return app

# Entry point for development/testing
if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, host='0.0.0.0', port=5000)

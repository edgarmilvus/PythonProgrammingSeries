
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

#!/usr/bin/env python3
# Basic CAG Router Pattern: Gemini classifies, routes to Wolfram/Watson/Gemini mocks

def mock_gemini_classify(query):
    """
    Simulates Google Gemini LLM classifying the query into:
    - 'wolfram': Math/computational (e.g., equations, integrals)
    - 'watson': Factual/knowledge retrieval (e.g., who/what/when)
    - 'gemini': Creative/general (default fallback)
    
    In production: Replace with real google-generativeai.generate_content(prompt)
    using embeddings or few-shot prompting for 98% accuracy.
    """
    prompt = f"""
    Classify this query as one of: 'wolfram' (math, calc, solve, equations, stats),
    'watson' (facts, what/who/where/when/how many, history, definitions),
    or 'gemini' (creative, write, imagine, opinion, code gen).
    Query: "{query}"
    Respond ONLY with the tool name.
    """
    
    # Heuristic simulation of Gemini (keyword + pattern matching for demo)
    # Expandable to regex, NLP libs like spaCy, or real LLM API
    query_lower = query.lower()
    
    # Math indicators: operators, solve/calc keywords
    math_indicators = [
        'solve', 'calculate', 'compute', 'integral', 'derivative', 'limit',
        'equation', 'x^', 'sqrt', '+', '-', '*', '/', '=', '%', 'log', 'sin', 'cos'
    ]
    if any(indicator in query_lower for indicator in math_indicators):
        return 'wolfram'
    
    # Factual indicators: interrogatives targeting knowledge
    fact_indicators = [
        'what is', 'who is', 'where is', 'when did', 'how many', 'capital of',
        'population of', 'gdp of', 'invented', 'define', 'history of', 'cause of'
    ]
    if any(indicator in query_lower for indicator in fact_indicators):
        return 'watson'
    
    # Default: Creative/general
    return 'gemini'

def mock_wolfram_alpha(query):
    """
    Mock Wolfram Alpha API call.
    In production: Use wolframalpha Python lib or HTTP API for exact computations.
    Handles symbolic math with step-by-step proofs, zero hallucination.
    """
    # Simulate computation (real: parse pods from XML/JSON response)
    if 'equation' in query.lower() or '=' in query:
        return f"Exact solution for '{query}': Step-by-step from Wolfram Alpha."
    elif any(op in query for op in ['+', '-', '*', '/']):
        return f"Computed result for '{query}': Precise numerical/symbolic output."
    else:
        return f"Wolfram Alpha result: '{query}' → Verified computation."

def mock_ibm_watson(query):
    """
    Mock IBM Watson Discovery/Query API.
    In production: Routes to knowledge bases/vector stores for RAG-like facts.
    Grounds responses in indexed docs, cites sources to prevent fabrication.
    """
    # Simulate factual lookup (real: JSON from /v1/query with passages)
    facts = {
        'capital of france': 'Paris',
        'who invented telephone': 'Alexander Graham Bell',
        'gdp of japan 2022': 'Approximately $4.23 trillion USD',
        'define photosynthesis': 'Process where plants convert light to energy via chlorophyll'
    }
    query_lower = query.lower()
    for key, value in facts.items():
        if key in query_lower:
            return f"Watson fact: {value} (sourced from verified knowledge base)."
    return f"Watson retrieved: Accurate info on '{query}' from enterprise corpus."

def mock_gemini_generate(query):
    """
    Mock Google Gemini Pro for creative tasks.
    In production: generativeai.generate_content() with streaming for low latency.
    Excels at prose, code, reasoning where symbols can't.
    """
    return f"Gemini creative response: Engaging, original take on '{query}'. ✨"

def cag_router(query):
    """
    Core Router Pattern: Classify → Route → Execute → Return.
    Fallback: If classification fails, chain (e.g., Gemini + verify).
    Async-ready: Wrap in asyncio for prod pipelines.
    """
    tool = mock_gemini_classify(query)
    print(f"Router decision: Using {tool.upper()} for '{query[:50]}...'")  # Logging
    
    if tool == 'wolfram':
        return mock_wolfram_alpha(query)
    elif tool == 'watson':
        return mock_ibm_watson(query)
    else:
        return mock_gemini_generate(query)

# Interactive demo entrypoint
if __name__ == "__main__":
    print("🚀 CAG Router Pattern Demo - Enter queries to see routing in action!")
    print("Examples: 'Solve x^2=4', 'Capital of France?', 'Write a haiku about AI'")
    print("Type 'quit' to exit.\n")
    
    while True:
        user_query = input("Your query: ").strip()
        if user_query.lower() in ['quit', 'exit', 'q']:
            print("👋 Thanks for demoing CAG!")
            break
        
        if not user_query:
            print("Please enter a valid query.\n")
            continue
        
        response = cag_router(user_query)
        print(f"\n📤 Response: {response}\n")
        print("=" * 60)

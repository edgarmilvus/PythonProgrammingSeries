
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: theory_theoretical_foundations_dual_explanation_part1.py
# Description: Theoretical Foundations & Dual Explanation
# ==========================================

# Router Pattern Implementation: CAG Core
# Requirements: pip install google-generativeai wolframalpha ibm-watson flask httpx asyncio python-dotenv
# Env vars: GEMINI_API_KEY, WOLFRAM_APPID, WATSON_URL, WATSON_APIKEY

import os
import asyncio
import httpx
from flask import Flask, request, jsonify, streaming  # For future deployment
from flask_frozen import Freezer  # Optional for static builds
import google.generativeai as genai
from wolframalpha.client import WolframAlpha  # Math engine
from ibm_watson import DiscoveryV2  # Factual retrieval (assumes Watson Discovery)
from dotenv import load_dotenv
import json
from typing import Dict, Any, AsyncGenerator

load_dotenv()

# Application Factory Pattern: Creates configurable app instances
def create_app(test_config=None):
    app = Flask(__name__)
    app.config['GEMINI_MODEL'] = 'gemini-1.5-pro'
    
    # Initialize tools
    genai.configure(api_key=os.getenv('GEMINI_API_KEY'))
    wolfram_client = WolframAlpha(appid=os.getenv('WOLFRAM_APPID'))
    watson_discovery = DiscoveryV2(
        url=os.getenv('WATSON_URL'),
        authenticator=iam.Authenticator(os.getenv('WATSON_APIKEY'))
    )
    
    # Store in app for access
    app.wolfram = wolfram_client
    app.watson = watson_discovery
    app.model = genai.GenerativeModel(app.config['GEMINI_MODEL'])
    
    return app

# Router Classifier: Gemini decides tool via few-shot prompting (lightweight, no embeddings for simplicity)
async def classify_query(query: str) -> Dict[str, float]:
    prompt = f"""
    Classify this query into ONE category with confidence 0-1.0:
    - MATH: Math, science, computation (e.g., solve equation, plot function).
    - FACT: Factual lookup, documents, history (e.g., company earnings, definitions).
    - CREATIVE: Stories, opinions, generation (e.g., write poem, brainstorm).
    
    Query: "{query}"
    Respond JSON: {{"category": "MATH|FACT|CREATIVE", "confidence": 0.95}}
    """
    response = await asyncio.get_event_loop().run_in_executor(
        None, lambda: app.model.generate_content(prompt)  # Sync wrapper for async
    )
    try:
        cls = json.loads(response.text)
        return {'MATH': cls['confidence'] if cls['category']=='MATH' else 0,
                'FACT': cls['confidence'] if cls['category']=='FACT' else 0,
                'CREATIVE': cls['confidence'] if cls['category']=='CREATIVE' else 0}
    except:
        return {'CREATIVE': 1.0}  # Fallback

# Tool Executors (Async for Streaming)
async def wolfram_tool(query: str) -> str:
    res = app.wolfram.query(query)
    return next(res.results).text  # Primary pod text

async def watson_tool(query: str, project_id: str = 'your-project') -> str:
    results = app.watson.query(project_id, query, count=1).get_result()
    return results['results'][0]['text'] if results['results'] else "No facts found."

async def llm_tool(query: str) -> AsyncGenerator[str, None]:
    stream = app.model.generate_content_async(query, stream=True)
    async for chunk in stream:
        yield chunk.text

# Core Router: Dispatches based on probs
async def route_query(query: str, threshold: float = 0.7) -> str:
    probs = await classify_query(query)
    max_p = max(probs.values())
    category = max(probs, key=probs.get)
    
    if max_p < threshold:
        # Hybrid: Parallel LLM + tools
        tasks = [llm_tool(query), asyncio.create_task(watson_tool(query))]
        llm_res = ""
        async for token in tasks[0]:
            llm_res += token
            yield token  # Stream
        yield f"\n\nFactual augmentation: {await tasks[1]}"
        return
    
    if category == 'MATH':
        result = await wolfram_tool(query)
    elif category == 'FACT':
        result = await watson_tool(query)
    elif category == 'CREATIVE':
        async for token in llm_tool(query):
            yield token  # Streaming response
        return
    yield result

# Flask Endpoint Example (Streaming CAG)
def app_factory():
    app = create_app()
    
    @app.route('/cag', methods=['POST'])
    def cag_endpoint():
        query = request.json['query']
        return streaming.Response(
            route_query(query),
            mimetype='text/plain'
        )
    
    return app

# Usage: Standalone async test
async def demo():
    app = create_app()  # Global for tools
    queries = [
        "Solve x^2 - 5x + 6 = 0",
        "What are IBM Watson's key milestones?",
        "Write a haiku about AI agents."
    ]
    for q in queries:
        print(f"Query: {q}")
        async for resp in route_query(q):
            print(resp, end='', flush=True)
        print("\n---")

if __name__ == "__main__":
    asyncio.run(demo())

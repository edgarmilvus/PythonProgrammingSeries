
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
import json
import asyncio
import logging
from typing import Dict, Callable, Any
from flask import Flask, session, request, send_file
from flask_session import Session
import sympy as sp
import matplotlib.pyplot as plt
import io
from graphviz import Digraph
from exercise3 import EmbeddingClassifier  # Builds on prior as base

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

metrics = {'routes': {'math':0, 'fact':0, 'creative':0}, 'errors': 0, 'latencies': []}

class AsyncCAGRouter(EmbeddingClassifier):
    def __init__(self):
        super().__init__()
        self.tool_registry: Dict[str, Callable] = {
            'Wolfram': self.execute_wolfram,
            'Watson': self.execute_watson,
            'Gemini': lambda q, s=False: asyncio.create_task(self._gemini_task(q, s)),
            'SymPy': self.local_math_solver
        }
        self.queue = asyncio.Queue()
        self.workers = [asyncio.create_task(self.worker()) for _ in range(4)]  # 4 async workers

    async def _gemini_task(self, query, stream):
        async for chunk in self.execute_gemini(query, stream):
            yield chunk

    def register_tool(self, name: str, executor_func: Callable):
        """Dynamic tool registration."""
        self.tool_registry[name] = executor_func
        logger.info(f"Registered tool: {name}")

    def local_math_solver(self, query: str) -> str:
        """Custom SymPy fallback for math."""
        x = sp.symbols('x')
        # Simple parser; expand for full
        if 'solve' in query.lower() and '=' in query:
            eq_str = query.split('solve')[-1].strip()
            eq = sp.sympify(eq_str)
            sols = sp.solve(eq, x)
            return str(sols)
        return "SymPy solved."

    def bias_route(self, scores: Dict[str, float], history: List[str]) -> Dict[str, float]:
        """Session bias: +0.2 to recent category."""
        if history:
            recent = history[-1]
            scores[recent.split(':')[0]] += 0.2  # e.g., 'math:Wolfram'
        return scores / sum(scores.values())

    async def worker(self):
        """Process queue for concurrency."""
        while True:
            task_id, query, stream = await self.queue.get()
            try:
                # Route with session bias
                sess_history = session.get('history', [])
                tool, conf = self.route_query(query)
                if sess_history:
                    # Bias via scores (simplified)
                    pass  # Integrated in route_query if extended
                result = await self.route_and_execute(query, stream) if tool == 'Gemini' else self.tool_registry[tool](query)
                session['history'] = sess_history + [f"{tool}:{conf}"]
                # Update metrics
                metrics['routes'][tool.lower()] += 1
                metrics['latencies'].append(100)  # Simulated ms
            except:
                metrics['errors'] += 1
            self.queue.task_done()

    async def route_and_execute(self, query: str, stream: bool = False):
        await self.queue.put((id(query), query, stream))
        await self.queue.join()  # Wait for completion (simplified)

def create_app():
    app = Flask(__name__)
    app.secret_key = 'devkey'
    Session(app)
    app.async_router = AsyncCAGRouter()
    app.async_router.register_tool('SymPy', app.async_router.local_math_solver)

    @app.route('/cag/batch', methods=['POST'])
    def batch_cag():
        queries = request.json['queries']
        results = asyncio.run(asyncio.gather(*[app.async_router.route_and_execute(q) for q in queries]))
        return {'results': results}

    @app.route('/metrics')
    def metrics_dashboard():
        # Matplotlib plot
        fig, ax = plt.subplots()
        ax.bar(metrics['routes'].keys(), metrics['routes'].values())
        img = io.BytesIO()
        plt.savefig(img, format='png')
        img.seek(0)
        return send_file(img, mimetype='image/png')

    @app.route('/session/flow/<query>')
    def session_dot(query):
        dot = Digraph()
        dot.node('Sess', 'Session History')
        dot.node('Q', query)
        dot.node('R', 'Async Route')
        dot.node('W', 'Workers')
        dot.edges(['SessQ', 'QR', 'RW'])
        dot.render('session_flow', format='png', cleanup=True)
        return send_file('session_flow.png', mimetype='image/png')

    # Reuse prior endpoints
    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)

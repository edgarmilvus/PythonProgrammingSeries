
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# app.py - Production CAG
import os
import json
import time
import asyncio
import functools
from functools import lru_cache
from flask import Flask, request
from flask_cors import CORS
import redis
import prometheus_client as prom
from prometheus_client import Counter, Histogram, generate_latest
from exercise4 import AsyncCAGRouter, create_app, metrics
import cProfile
import pstats

# Prometheus metrics
cag_route_total = Counter('cag_route_total', 'Routes by category', ['category'])
cag_latency = Histogram('cag_latency_seconds', 'Latency')
cag_hallucination_score = Histogram('cag_hallucination_score', 'Hallucination scores')

# Redis
rdb = redis.Redis(host=os.getenv('REDIS_URL', 'localhost'), port=6379, db=0)

ab_test = 'embeddings'  # Toggle: 'heuristics' or 'embeddings'

class ProdCAGRouter(AsyncCAGRouter):
    @lru_cache(maxsize=128)
    def classify_cached(self, query_hash: str):
        return self.route_query(query_hash)  # Hash query for cache

    async def verify_hallucination(self, response: str, query: str) -> bool:
        """Gemini guard: score >0.8."""
        prompt = f"Is '{response}' factual/accurate for '{query}'? Score 0-1 JSON: {{'score': float}}"
        res = self.gemini_model.generate_content(prompt)
        score = json.loads(res.text)['score']
        cag_hallucination_score.observe(score)
        if score < 0.8:
            # Refine: reroute
            logger.warning("Hallucination detected, refining...")
            return False
        return True

    async def neuro_chain(self, query: str, stream: bool):
        """Route → Execute → Verify → Refine."""
        tool, conf = self.route_query(query)
        cag_route_total.labels(category=tool).inc()
        
        with cag_latency.time():
            result_gen = self.route_and_execute(query, stream)
            full_result = ''
            async for chunk in result_gen:
                full_result += chunk
                yield chunk
            
            if not await self.verify_hallucination(full_result, query):
                # Refine with Gemini
                async for refine in self.execute_gemini(f"Correct factual errors in: {full_result} for {query}"):
                    yield f"[Refined] {refine}"

# Monkey patch into create_app
def create_prod_app():
    app = create_app()
    app.router = ProdCAGRouter()  # Override
    CORS(app)
    
    @app.route('/ab/test', methods=['POST'])
    def ab_toggle():
        global ab_test
        ab_test = request.json['strategy']
        return {'active': ab_test}
    
    @app.route('/metrics/prom')
    def prom_metrics():
        return Response(generate_latest(), mimetype='text/plain')
    
    # Cache in route_and_execute (via decorator)
    app.router.route_and_execute = functools.wraps(app.router.route_and_execute)(
        rdb_cached(app.router.route_and_execute)
    )
    
    return app

def rdb_cached(func):
    async def wrapper(query, *args, **kwargs):
        qhash = hash(query)
        cached = rdb.get(f"resp:{qhash}")
        if cached:
            return cached.decode()
        res = await func(query, *args, **kwargs)
        rdb.setex(f"resp:{qhash}", 300, str(res))  # TTL 5min
        return res
    return wrapper

if __name__ == "__main__":
    app = create_prod_app()
    app.run(host='0.0.0.0')

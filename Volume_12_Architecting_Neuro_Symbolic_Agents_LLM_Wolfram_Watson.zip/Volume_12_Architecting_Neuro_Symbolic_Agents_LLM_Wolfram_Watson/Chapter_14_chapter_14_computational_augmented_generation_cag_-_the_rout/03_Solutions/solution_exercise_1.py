
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
import re
import json
import logging
import asyncio
import argparse
import string
from typing import Dict, Tuple, Any, List
import google.generativeai as genai

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Set Gemini API key
genai.configure(api_key=os.getenv('GEMINI_API_KEY'))
gemini_model = genai.GenerativeModel('gemini-1.5-flash')

class QueryClassifier:
    def __init__(self):
        self.math_keywords = ['solve', 'equation', 'integral', 'derivative', 'calculate', 'x=', r'[0-9+\-*/=()]']
        self.fact_keywords = ['capital', 'president', 'won', 'who', 'what', 'when', 'where', 'history', 'geography']
        self.creative_keywords = ['write', 'imagine', 'design', 'poem', 'story', 'generate', 'create']

    def preprocess_query(self, query: str) -> str:
        """Normalize query: lowercase and remove punctuation."""
        query = query.lower().translate(str.maketrans('', '', string.punctuation))
        logger.info(f"Preprocessed query: '{query}'")
        return query

    def heuristic_classify(self, query: str) -> Dict[str, float]:
        """Heuristic scoring using regex and keywords; normalize to sum=1.0."""
        query = self.preprocess_query(query)
        scores = {'math': 0.0, 'fact': 0.0, 'creative': 0.0}
        
        # Math: regex for symbols or keywords
        math_score = sum(1 for pat in self.math_keywords[-1:] + self.math_keywords[:-1] if re.search(pat if isinstance(pat, str) else pat, query)) / len(self.math_keywords)
        scores['math'] = min(math_score, 1.0)
        
        # Fact keywords
        fact_score = sum(1 for kw in self.fact_keywords if kw in query) / len(self.fact_keywords)
        scores['fact'] = min(fact_score, 1.0)
        
        # Creative keywords
        creative_score = sum(1 for kw in self.creative_keywords if kw in query) / len(self.creative_keywords)
        scores['creative'] = min(creative_score, 1.0)
        
        # Normalize to sum=1.0
        total = sum(scores.values())
        if total > 0:
            for k in scores:
                scores[k] /= total
        logger.info(f"Heuristic scores: {scores}")
        return scores

    def llm_classify(self, query: str, gemini_model: Any) -> Dict[str, float]:
        """Use Gemini to classify with JSON scores."""
        prompt = f"""
        Classify the query '{query}' as one of: math, fact, creative.
        Respond ONLY with JSON: {{"math": float 0-1, "fact": float 0-1, "creative": float 0-1}}
        Scores should sum to 1.0, highest for primary category.
        """
        response = gemini_model.generate_content(prompt)
        try:
            scores = json.loads(response.text.strip())
            logger.info(f"LLM scores: {scores}")
            return scores
        except json.JSONDecodeError:
            logger.warning("LLM response not JSON, fallback to equal scores")
            return {'math': 0.33, 'fact': 0.33, 'creative': 0.34}

    def route_query(self, query: str) -> Tuple[str, float]:
        """Combine heuristics (0.4) + LLM (0.6); pick max, fallback if <0.5."""
        heuristic = self.heuristic_classify(query)
        llm = self.llm_classify(query, gemini_model)
        
        combined = {}
        for cat in ['math', 'fact', 'creative']:
            combined[cat] = 0.4 * heuristic[cat] + 0.6 * llm[cat]
        
        category = max(combined, key=combined.get)
        confidence = combined[category]
        
        if confidence < 0.5:
            category = 'creative'  # Fallback to Gemini
            confidence = 0.5
        
        route_map = {'math': 'Wolfram', 'fact': 'Watson', 'creative': 'Gemini'}
        logger.info(f"Routing to: {route_map[category]} (confidence: {confidence:.2f})")
        return route_map[category], confidence

    async def arun_query(self, query: str):
        """Async simulation: stream classification 'tokens'."""
        parts = f"Analyzing... Routing to: {self.route_query(query)[0]}".split()
        for part in parts:
            print(part, end=' ', flush=True)
            await asyncio.sleep(0.1)  # Simulate streaming
        print()

# Test suite
test_queries = [
    {"q": "Solve 2x + 3 = 7", "expected": "Wolfram"},
    {"q": "Derivative of e^x", "expected": "Wolfram"},
    {"q": "Who won WWII?", "expected": "Watson"},
    {"q": "What is the capital of France?", "expected": "Watson"},
    {"q": "Write a poem about AI", "expected": "Gemini"},
    {"q": "Design a spaceship UI", "expected": "Gemini"},
    {"q": "How many apples in pi?", "expected": "Gemini"},  # Ambiguous fallback
    # Add 13 more for 20 total...
    {"q": "Integrate sin(x)", "expected": "Wolfram"},
    {"q": "President of USA 2023", "expected": "Watson"},
    {"q": "Imagine a story", "expected": "Gemini"},
    {"q": "x^2 - 5x + 6 = 0", "expected": "Wolfram"},
    {"q": "Battle of Waterloo date", "expected": "Watson"},
    {"q": "Generate code for hello world", "expected": "Gemini"},
    {"q": "Calculate sqrt(16)", "expected": "Wolfram"},
    {"q": "Eiffel Tower location", "expected": "Watson"},
    {"q": "Poem on love", "expected": "Gemini"},
    {"q": "Limit as x->0 sin(x)/x", "expected": "Wolfram"},
    {"q": "Inventor of telephone", "expected": "Watson"},
    {"q": "Create a logo idea", "expected": "Gemini"},
    {"q": "Factor 12x^2", "expected": "Wolfram"},
]

def evaluate_accuracy(classifier: QueryClassifier) -> Dict[str, any]:
    correct = 0
    for tq in test_queries:
        routed, _ = classifier.route_query(tq["q"])
        if routed == tq["expected"]:
            correct += 1
    accuracy = correct / len(test_queries) * 100
    logger.info(f"Accuracy: {accuracy:.1f}% on {len(test_queries)} queries")
    return {"accuracy": accuracy, "total": len(test_queries)}

def main():
    parser = argparse.ArgumentParser(description="CAG Query Router")
    parser.add_argument("query", type=str, nargs='?', help="Query to classify")
    args = parser.parse_args()
    
    classifier = QueryClassifier()
    
    if args.query:
        print("CLI Result:")
        asyncio.run(classifier.arun_query(args.query))
    else:
        # Run evaluation
        evaluate_accuracy(classifier)

if __name__ == "__main__":
    main()

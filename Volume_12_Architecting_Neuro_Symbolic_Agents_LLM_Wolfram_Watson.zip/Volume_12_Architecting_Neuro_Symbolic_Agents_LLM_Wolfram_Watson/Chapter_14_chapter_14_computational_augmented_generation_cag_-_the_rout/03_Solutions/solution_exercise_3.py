
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
import json
import numpy as np
import logging
from typing import Dict, List
from sentence_transformers import SentenceTransformer
import faiss
from flask import Flask, Response
from exercise2 import CAGRouter, create_app  # Builds on prior
from graphviz import Digraph  # pip install graphviz

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class EmbeddingClassifier(CAGRouter):
    def __init__(self):
        super().__init__()
        self.model = self.setup_model()
        self.prototypes = self.load_prototypes()
        self.index = self.setup_faiss()
        self.prototype_embs = self.model.encode(list(self.prototypes['math'] + self.prototypes['fact'] + self.prototypes['creative']))

    def setup_model(self) -> SentenceTransformer:
        """Load embedding model."""
        return SentenceTransformer('all-MiniLM-L6-v2')

    def load_prototypes(self) -> Dict[str, List[str]]:
        """Load 50 prototypes per category (simplified sample; expand to 50)."""
        return {
            'math': ['solve equation', 'integrate function', 'derivative of', 'calculate limit'] * 13,  # 52
            'fact': ['historical event', 'geographical location', 'who invented', 'capital of'] * 13,
            'creative': ['write poem', 'design ui', 'generate story', 'imagine world'] * 13
        }

    def setup_faiss(self):
        """FAISS index for 1000 labeled queries (simplified: use prototypes x20)."""
        dim = 384  # MiniLM dim
        index = faiss.IndexFlatIP(dim)  # Cosine sim
        # Simulate 1000: repeat prototypes
        all_queries = (list(self.prototypes['math']) * 20 + list(self.prototypes['fact']) * 20 +
                       list(self.prototypes['creative']) * 20)[:1000]
        all_embs = self.model.encode(all_queries)
        all_embs = all_embs / np.linalg.norm(all_embs, axis=1, keepdims=True)  # Normalize
        index.add(all_embs.astype('float32'))
        self.query_labels = ['math']*200 + ['fact']*200 + ['creative']*200 + ['math']*200  # Simplified labels
        return index

    def compute_scores(self, query: str) -> Dict[str, float]:
        """Cosine sim to prototypes, average per category."""
        q_emb = self.model.encode([query])
        q_emb = q_emb / np.linalg.norm(q_emb, axis=1, keepdims=True)
        sims = np.dot(q_emb, self.prototype_embs.T)[0]
        
        scores = {'math': np.mean(sims[:len(self.prototypes['math'])]),
                  'fact': np.mean(sims[len(self.prototypes['math']):len(self.prototypes['math'])+len(self.prototypes['fact'])]),
                  'creative': np.mean(sims[len(self.prototypes['math'])+len(self.prototypes['fact']):])}
        total = sum(scores.values())
        if total > 0:
            for k in scores: scores[k] /= total
        logger.info(f"Embedding scores: {scores}")
        return scores

    def route_query(self, query: str) -> tuple:
        """Override: embeddings 0.8 + LLM 0.2 if <0.6."""
        emb_scores = self.compute_scores(query)
        if max(emb_scores.values()) >= 0.6:
            category = max(emb_scores, key=emb_scores.get)
            conf = emb_scores[category]
        else:
            llm_scores = self.llm_classify(query, self.gemini_model)
            combined = {k: 0.8 * emb_scores[k] + 0.2 * llm_scores[k] for k in emb_scores}
            category = max(combined, key=combined.get)
            conf = combined[category]
        
        # FAISS RAG: retrieve top-3 for context (log only)
        q_emb_norm = self.model.encode([query]) / np.linalg.norm(self.model.encode([query]), axis=1, keepdims=True)
        _, indices = self.index.search(q_emb_norm.astype('float32'), 3)
        context = [self.query_labels[i] for i in indices[0]]
        logger.info(f"RAG context categories: {context}")
        
        route_map = {'math': 'Wolfram', 'fact': 'Watson', 'creative': 'Gemini'}
        return route_map[category], conf

def create_app():
    app = Flask(__name__)
    app.embedding_router = EmbeddingClassifier()
    # Prepend embedding route (already in overridden route_query)

    @app.route('/classify/embed', methods=['POST'])
    def embed_classify():
        data = request.json
        query = data['query']
        router = app.embedding_router
        tool, conf = router.route_query(query)
        
        # Generate DOT graph
        dot = Digraph()
        dot.node('Q', 'Query')
        dot.node('E', f'Embeddings\n{json.dumps(router.compute_scores(query), indent=2)}')
        dot.node('R', f'Route: {tool}\nConf: {conf:.2f}')
        dot.edges(['QE', 'ER'])
        dot.render('routing', format='png', cleanup=True)  # Saves routing.png
        
        return Response(f"DOT generated: routing.png\nTool: {tool} (conf: {conf:.2f})", mimetype='text/plain')
    
    # Include /cag/query from prior
    @app.route('/cag/query', methods=['POST'])
    def cag_query():
        # Reuse from exercise2, but with embedding_router
        pass  # Integrated similarly
    
    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)

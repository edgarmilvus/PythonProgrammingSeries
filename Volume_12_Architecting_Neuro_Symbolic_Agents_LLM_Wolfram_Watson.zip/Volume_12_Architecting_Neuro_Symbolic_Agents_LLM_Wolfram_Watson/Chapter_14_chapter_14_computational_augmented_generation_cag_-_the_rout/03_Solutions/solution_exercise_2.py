
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os
import json
import asyncio
import logging
from typing import Union, AsyncGenerator
from flask import Flask, request, Response, stream_with_context
import wolframalpha
from ibm_watson import NaturalLanguageUnderstandingV1
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
import google.generativeai as genai
from tenacity import retry, stop_after_attempt, wait_exponential
from exercise1 import QueryClassifier  # Assume Exercise 1 code in exercise1.py

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

genai.configure(api_key=os.getenv('GEMINI_API_KEY'))
WOLFRAM_APPID = os.getenv('WOLFRAM_APPID')
WATSON_APIKEY = os.getenv('WATSON_APIKEY')
WATSON_URL = os.getenv('WATSON_URL', 'https://api.us-south.natural-language-understanding.watson.cloud.ibm.com')

class CAGRouter(QueryClassifier):
    def __init__(self):
        super().__init__()
        self.wolfram_client = wolframalpha.Client(WOLFRAM_APPID)
        authenticator = IAMAuthenticator(WATSON_APIKEY)
        self.watson_nlu = NaturalLanguageUnderstandingV1(version='2022-04-07', authenticator=authenticator)
        self.watson_nlu.set_service_url(WATSON_URL)
        self.gemini_model = genai.GenerativeModel('gemini-pro')

    def setup_apis(self):
        """Initialize API clients (called in __init__)."""
        logger.info("APIs initialized.")

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
    def execute_wolfram(self, query: str) -> str:
        """Query Wolfram, parse primary pod."""
        res = self.wolfram_client.query(query)
        try:
            primary_pod = next(res.pods).text
            logger.info(f"Wolfram result: {primary_pod}")
            return primary_pod or "No result found."
        except StopIteration:
            raise ValueError("Wolfram no pods")

    def execute_watson(self, query: str) -> str:
        """Extract entities/keywords for facts."""
        response = self.watson_nlu.analyze(text=query, features={'entities': {}}).get_result()
        entities = [e['text'] for e in response.get('entities', [])]
        result = f"Key facts: {', '.join(entities)}" if entities else "No facts identified."
        logger.info(f"Watson result: {result}")
        return result

    async def execute_gemini(self, query: str, stream: bool = True) -> Union[str, AsyncGenerator[str, None]]:
        """Stream Gemini tokens."""
        if stream:
            async for chunk in self.gemini_model.generate_content_async(query):
                yield chunk.text
        else:
            response = self.gemini_model.generate_content(query)
            return response.text

    async def route_and_execute(self, query: str, stream: bool = False) -> Union[str, AsyncGenerator[str, None]]:
        """Route, execute with fallbacks, hybrid if multi-category."""
        tool, conf = self.route_query(query)
        start = asyncio.get_event_loop().time()
        try:
            if tool == 'Wolfram':
                result = self.execute_wolfram(query)
            elif tool == 'Watson':
                result = self.execute_watson(query)
            else:
                return self.execute_gemini(query, stream)
            
            # Hybrid if conf < 0.7 (multi-category)
            if conf < 0.7:
                async for gem_part in self.execute_gemini(f"Explain: {result}", stream):
                    yield f"{result}\nExplanation: {gem_part}"
                result = "Hybrid response generated."
            
            latency = (asyncio.get_event_loop().time() - start) * 1000
            self.log_metrics(latency, tool, conf, True)
            if stream:
                for part in result.split():  # Simulate stream
                    yield part + ' '
            else:
                return result
                
        except Exception as e:
            logger.error(f"{tool} failed: {e}")
            # Fallback chain
            fallback_tools = {'Wolfram': ['Watson', 'Gemini'], 'Watson': ['Gemini']}
            for fb in fallback_tools.get(tool, ['Gemini']):
                try:
                    if fb == 'Gemini':
                        async for part in self.execute_gemini(query, stream):
                            yield part
                    return
                except:
                    continue
            self.log_metrics((asyncio.get_event_loop().time() - start) * 1000, tool, conf, False)

    def log_metrics(self, latency_ms: float, route: str, confidence: float, success: bool):
        """Log JSON metrics."""
        metric = {'latency_ms': latency_ms, 'route': route, 'confidence': confidence, 'success': success}
        logger.info(json.dumps(metric))
        # In prod, append to file or DB

def create_app():
    app = Flask(__name__)
    app.cag_router = CAGRouter()
    app.cag_router.setup_apis()
    
    @app.route('/cag/query', methods=['POST'])
    def cag_query():
        data = request.json
        query = data['query']
        stream = data.get('stream', False)
        
        def generate():
            try:
                async def inner():
                    async for chunk in app.cag_router.route_and_execute(query, stream):
                        yield f"data: {chunk}\n\n"
                for line in stream_with_context(asyncio.run(inner())):
                    yield line
            except Exception as e:
                yield f"data: Error: {e}\n\n"
        
        return Response(generate(), mimetype='text/event-stream')
    
    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)

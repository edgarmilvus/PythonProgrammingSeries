
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# Imports: Core LangGraph/LangChain for graph orchestration, stateful persistence, and LLM integration
import os
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import TypedDict, Dict, Any, Annotated, Sequence
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage
from langchain_openai import ChatOpenAI  # LLM for critique/refine; requires OPENAI_API_KEY env var
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.sqlite import SqliteSaver  # SQLite checkpointer for persistence

# State schema: Custom TypedDict for shared, persistent memory across nodes
# 'messages' uses Annotated with "add" reducer for automatic list appending (avoids manual .extend)
# Other fields track evolving data like file lists and decisions (merged via dict.update semantics)
class AgentState(TypedDict):
    messages: Annotated[Sequence[BaseMessage], "add"]
    files_to_delete: list[str]
    safe: bool
    reason: str
    approved: bool | None
    target_dir: str  # Passed from config for flexibility

# Initialize LLM (low temp for deterministic JSON outputs) and SQLite checkpointer (disk persistence)
llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
checkpointer = SqliteSaver.from_conn_string("cleanup_agent.db")  # Saves state after EVERY node

# Node 1: Symbolically identify old logs (>30 days) using pathlib/datetime (neuro-symbolic grounding)
def identify(state: AgentState) -> Dict[str, Any]:
    target_dir = state.get("target_dir", "./logs")
    cutoff = datetime.now() - timedelta(days=30)
    old_logs = [
        str(p) for p in Path(target_dir).glob("*.log")
        if datetime.fromtimestamp(p.stat().st_mtime) < cutoff
    ]
    msg = HumanMessage(content=f"🔍 Identified {len(old_logs)} old logs: {old_logs}")
    # Return dict to merge (LangGraph auto-updates state via shallow merge, akin to dict.update())
    return {
        "messages": [msg],
        "files_to_delete": old_logs,
        "target_dir": target_dir  # Persist for downstream
    }

# Node 2: LLM critiques list for safety (e.g., paths, names); parses JSON for bool decision
def critique(state: AgentState) -> Dict[str, Any]:
    files = state["files_to_delete"]
    prompt = f"""Critique for safe deletion:
Files: {files}
Check: user-owned? No /etc/, /var/log/system*? Reasonable sizes/names?
JSON ONLY: {{"safe": true/false, "reason": "explanation"}}"""
    msg = llm.invoke([HumanMessage(content=prompt)])
    try:
        data = json.loads(msg.content)
    except json.JSONDecodeError:
        data = {"safe": False, "reason": "Invalid JSON response"}
    ai_msg = AIMessage(content=f"📝 Critique: safe={data['safe']}, {data['reason']}")
    return {"messages": [ai_msg], "safe": data["safe"], "reason": data["reason"]}

# Node 3: LLM refines list based on critique (subset or empty); enables critique-refine cycle
def refine(state: AgentState) -> Dict[str, Any]:
    files = state["files_to_delete"]
    reason = state["reason"]
    prompt = f"""Refine safer list from critique: {reason}
Original: {files}
JSON ONLY: {{"refined_files": ["file1.log", ...]}} (subset/empty OK)"""
    msg = llm.invoke([HumanMessage(content=prompt)])
    try:
        data = json.loads(msg.content)
        refined = data.get("refined_files", [])
    except json.JSONDecodeError:
        refined = []  # Fail-safe to empty
    ai_msg = AIMessage(content=f"✏️ Refined to {len(refined)} files: {refined}")
    return {
        "messages": [ai_msg],
        "files_to_delete": refined  # Update list for next critique loop
    }

# Conditional router: Boolean logic post-critique (uses state['safe'] -> refine or human)
def route_after_critique(state: AgentState) -> str:
    return "refine" if not state["safe"] else "human_approve"

# Node 4: Human-in-the-loop CLI breakpoint (sync input for interactive pause)
def human_approve(state: AgentState) -> Dict[str, Any]:
    print("\n🚨 HUMAN-IN-THE-LOOP: APPROVAL REQUIRED 🚨")
    print(f"Target: {state['target_dir']}")
    print(f"Final list ({len(state['files_to_delete'])}): {state['files_to_delete']}")
    print(f"Reason: {state.get('reason', 'N/A')}")
    decision = input("Delete these? (y/n): ").lower().strip()
    approved = decision == 'y'
    msg = HumanMessage(content=f"👤 Human decision: {'APPROVED' if approved else 'REJECTED'}")
    return {"messages": [msg], "approved": approved}

# Node 5: Symbolic deletion (only if approved); error-handling for robustness
def delete_files(state: AgentState) -> Dict[str, Any]:
    files = state["files_to_delete"]
    deleted = []
    for f in files:
        try:
            os.remove(f)
            deleted.append(f)
            print(f"🗑️ Deleted: {f}")
        except Exception as e:
            print(f"❌ Skip {f}: {e}")
    ai_msg = AIMessage(content=f"✅ Deleted {len(deleted)}/{len(files)} files")
    return {"messages": [ai_msg]}

# Graph assembly: Nodes as functions, edges for flow (linear -> conditional -> cycles)
workflow = StateGraph(AgentState)
workflow.add_node("identify", identify)
workflow.add_node("critique", critique)
workflow.add_node("refine", refine)
workflow.add_node("human_approve", human_approve)
workflow.add_node("delete_files", delete_files)

# Define topology: Entry -> linear to critique -> conditional branch/cycle -> human -> conditional end
workflow.set_entry_point("identify")
workflow.add_edge("identify", "critique")
workflow.add_conditional_edges(
    "critique",
    route_after_critique,
    {"refine": "refine", "human_approve": "human_approve"}
)
workflow.add_edge("refine", "critique")  # Cyclic edge: core loop for iterative improvement
workflow.add_conditional_edges(
    "human_approve",
    lambda state: "delete_files" if state["approved"] else END,
    {"delete_files": "delete_files", END: END}
)
workflow.add_edge("delete_files", END)

# Compile with checkpointer: Enables persistence, resumability, streaming
app = workflow.compile(checkpointer=checkpointer)

# Demo setup: Create safe ./logs/ with old/recent files (mtime manipulation for realism)
def create_demo_logs(target_dir: str = "./logs"):
    os.makedirs(target_dir, exist_ok=True)
    now = datetime.now()
    # 4 old logs (>30d), 1 recent (should be filtered)
    for i, days_old in enumerate([35, 40, 45, 50]):
        p = Path(target_dir) / f"safe_old_log_{i}.log"
        p.write_text(f"Demo log content {i} (old)")
        old_time = (now - timedelta(days=days_old)).timestamp()
        os.utime(p, times=(old_time, old_time))  # Set mtime symbolically
    recent = Path(target_dir) / "recent_log.log"
    recent.write_text("Recent log (should survive)")
    print(f"📁 Demo logs created in {target_dir} (4 old, 1 recent)")

# CLI runner: Streaming values, auto-resumes via thread_id, human input blocks naturally
def main():
    target_dir = input("Target dir (Enter for ./logs demo): ").strip() or "./logs"
    create_demo_logs(target_dir)
    thread_id = input("Thread ID (Enter for 'cleanup1'; reuse to resume): ").strip() or "cleanup1"
    config = {"configurable": {"thread_id": thread_id, "target_dir": target_dir}}
    print(f"\n🤖 Starting SafeLogCleanupAgent (thread: {thread_id})")
    print("💡 Tip: Ctrl+C to pause/resume later with same ID. Streaming enabled.")
    print("-" * 60)
    while True:
        events = app.stream(None, config, stream_mode="values")  # Streams state updates (async-like tokens)
        final_state = None
        for event in events:
            if event["messages"]:
                print(event["messages"][-1].content)
            final_state = event
        state = app.get_state(config)
        if not state.next:
            print("\n🎉 Process complete!")
            print(f"Final status: Approved={state.values.get('approved', False)}, Files={len(state.values.get('files_to_delete', []))}")
            break
        print(f"\n⏸️ Next: {state.next} | Resume? (y/n)")
        if input().lower() != 'y':
            break

if __name__ == "__main__":
    main()

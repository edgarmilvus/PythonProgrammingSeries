
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Fully self-contained LangGraph 'Hello World': CodeReviewer agent with cycles, persistence, and human-in-the-loop.
# Run with: pip install langgraph sqlite3  (no external LLMs needed; dummies simulate local model calls)
# Usage: python this_script.py  (interact via CLI)

from typing import TypedDict, Annotated, Sequence
import operator
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.sqlite import SqliteSaver
import sqlite3
import os

# 1. Define shared STATE: TypedDict for type-safety, persists across runs.
class AgentState(TypedDict):
    messages: Annotated[Sequence[str], operator.add]  # Cumulative chat history (appends)
    code: str  # Generated/refined code snippet
    approved: bool  # Critique result: True if ready for human
    query: str  # Original user input, fixed
    thread_id: str  # Unique ID for persistence (per conversation)

# 2. NODE: generate_code - Simulates local LLM generating initial code.
def generate_code(state: AgentState) -> AgentState:
    query = state["query"]
    # Dummy LLM: Real use -> local model like Ollama("llama3")
    code = f'def fizzbuzz(n):\n    for i in range(1, n+1):\n        if i % 15 == 0: print("FizzBuzz")\n        elif i % 3 == 0: print("Fizz")\n        elif i % 5 == 0: print("Buzz")\n        else: print(i)'
    return {
        "messages": [f"Generated code for '{query}':\n{code}"],
        "code": code,
        "approved": False  # Always critique first
    }

# 3. NODE: critique_code - Analyzes code for bugs (simulates symbolic check or Watson).
def critique_code(state: AgentState) -> AgentState:
    code = state["code"]
    # Dummy critique: Real -> Wolfram Alpha verify or static analysis
    has_bug = "15" not in code or "Buzz" not in code  # Simple check fails initially
    approved = not has_bug
    msg = f"Critique: {'PASS - Bug-free!' if approved else 'FAIL - Refine needed (e.g., missing FizzBuzz combo).'}"
    return {"messages": [msg], "approved": approved}

# 4. NODE: refine_code - Loops back: Improves code (cycle for local model iteration).
def refine_code(state: AgentState) -> AgentState:
    code = state["code"]
    # Dummy refine: Fix common issues
    refined = code.replace("if i % 15 == 0", 'if i % 3 == 0 and i % 5 == 0')  # Correct FizzBuzz logic
    return {
        "messages": [f"Refined code:\n{refined}"],
        "code": refined,
        "approved": False  # Re-critique
    }

# 5. NODE: human_approval - Human-in-the-loop: CLI pause before "dangerous" action.
def human_approval(state: AgentState) -> AgentState:
    code = state["code"]
    print("\n=== HUMAN-IN-THE-LOOP ===")
    print(f"Proposed code:\n{code}")
    response = input("Approve and 'deploy' (simulate file delete)? (y/n): ").strip().lower()
    approved = response == 'y'
    action = "DEPLOYED (safe sim: echo 'Files untouched')" if approved else "ABORTED"
    return {
        "messages": [f"Human decision: {action}"],
        "approved": approved  # Final state
    }

# 6. Conditional ROUTING: Edges decide next node (branching logic).
def route_critique(state: AgentState) -> str:
    return "refine" if not state["approved"] else "approve"

# 7. Build GRAPH: Add nodes, edges (including cycle: critique -> refine -> critique).
workflow = StateGraph(state_schema=AgentState)

# Add nodes
workflow.add_node("generate", generate_code)
workflow.add_node("critique", critique_code)
workflow.add_node("refine", refine_code)
workflow.add_node("approve", human_approval)

# Edges: Linear start, conditional cycle, end
workflow.set_entry_point("generate")
workflow.add_edge("generate", "critique")
workflow.add_conditional_edges("critique", route_critique, {"refine": "refine", "approve": "approve"})
workflow.add_edge("refine", "critique")  # CYCLIC: Enables critique-refine loops
workflow.add_edge("approve", END)

# 8. PERSISTENCE: SQLite checkpointer saves state after EVERY step.
checkpointer = SqliteSaver.from_conn_string("agent_memory.db")
app = workflow.compile(checkpointer=checkpointer)

# 9. RUN: CLI invocation with persistence (resumes if db exists).
if __name__ == "__main__":
    thread_id = input("Enter thread ID (or new: 'new'): ").strip() or "session1"
    if thread_id == "new":
        os.remove("agent_memory.db") if os.path.exists("agent_memory.db") else None  # Fresh start

    config = {"configurable": {"thread_id": thread_id}}
    
    query = input("Enter code query (e.g., 'FizzBuzz function'): ")
    initial_state = {"query": query, "messages": [], "code": "", "approved": False, "thread_id": thread_id}
    
    # Stream execution: Prints each step, persists automatically
    for chunk in app.stream(initial_state, config, stream_mode="values"):
        print(chunk["messages"][-1])  # Latest message

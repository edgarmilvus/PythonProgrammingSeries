
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from typing import TypedDict
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.sqlite import SqliteSaver
import os

# Extended state
class State(TypedDict):
    request: str
    proposed_action: str
    risk_level: str  # 'low'/'high'
    human_approvals: list[str]
    final_code: str
    # ... inherit others from Ex3

def risk_assess_node(state: State) -> State:
    action = state.get("proposed_action", "")
    risky_keywords = ["delete", "exec", "rm"]
    risk_level = "high" if any(kw in action.lower() for kw in risky_keywords) else "low"
    print(f"Risk assess: {action} -> {risk_level}")
    return {"risk_level": risk_level}

def human_node(state: State) -> State:
    action = state["proposed_action"]
    while True:
        approval = input(f"Dangerous: {action}. Approve? (y/n): ").strip().lower()
        if approval in ["y", "yes"]:
            print("Approved")
            return {"human_approvals": state.get("human_approvals", []) + ["approved"]}
        elif approval in ["n", "no"]:
            print("Denied - ending")
            return {"human_approvals": state.get("human_approvals", []) + ["denied"]}
        print("Invalid - y/n only")

def action_node(state: State) -> State:
    action = state["proposed_action"]
    if "delete notes.txt" in action and "approved" in state["human_approvals"]:
        try:
            os.remove("notes.txt")
            print("Action: Deleted notes.txt")
        except:
            print("Safe: File not found")
    else:
        print("Safe action or denied: Skipped")
    return {"final_code": f"Action '{action}' executed: {'Success' if 'approved' in state.get('human_approvals', []) else 'Blocked'}"}

def route_risk(state: State) -> str:
    return "human" if state["risk_level"] == "high" else "action"

# Full graph integrating prior + new nodes
graph = StateGraph(State)
# ... add prior nodes: generate, critique, etc. (abbrev for Ex4 focus)
graph.add_node("risk_assess", risk_assess_node)
graph.add_node("human", human_node)
graph.add_node("action", action_node)

# Assume prior flow ends with set_proposed_action -> risk_assess
graph.add_conditional_edges("risk_assess", route_risk, {"human": "human", "action": "action"})
graph.add_edge("human", "action")
graph.add_edge("action", END)

checkpointer = SqliteSaver.from_conn_string("safe_agent.db")
app = graph.compile(checkpointer=checkpointer)

config = {"configurable": {"thread_id": "safe_session"}}

# Test: Safe
print("--- Safe Test ---")
app.invoke({"proposed_action": "Save file", "human_approvals": []}, config)

# Test: Risky (interactive)
print("\n--- Risky Test ---")
app.invoke({"proposed_action": "Delete /tmp/agent.log", "human_approvals": []}, config)

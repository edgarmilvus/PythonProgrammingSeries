
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from typing import TypedDict
from langgraph.graph import StateGraph, END

# Define state with loop tracking
class State(TypedDict):
    request: str
    code_versions: list[str]
    critique_history: list[str]
    critique_score: float
    final_code: str
    loop_count: int

# Initialize defaults in invoke
def initialize_state(state: State) -> State:
    return {
        **state,
        "code_versions": [],
        "critique_history": [],
        "critique_score": 0.0,
        "final_code": "",
        "loop_count": 0,
    }

# Node 1: Generate code (mock LLM with template refinement)
def generate_node(state: State) -> State:
    loop_count = state.get("loop_count", 0) + 1
    prev_critiques = " ".join(state.get("critique_history", []))
    if "prime factors" in state["request"]:
        base_code = """
import wolframalpha
client = wolframalpha.Client('mock_appid')
res = client.query('prime factors of 315')
print(next(res.results).text)
"""
        if prev_critiques:
            code = base_code + "\n# Refined: Fixed import and error handling based on prior critique"
        else:
            code = base_code
    else:
        code = "# Mock safe code: print('Task handled safely')"
    print(f"Loop {loop_count}: Generated code:\n{code[:100]}...")
    return {
        "code_versions": state.get("code_versions", []) + [code],
        "loop_count": loop_count,
    }

# Node 2: Critique code (mock LLM JSON eval)
def critique_node(state: State) -> State:
    latest_code = state["code_versions"][-1]
    # Simulate score: improve over loops, low initially for bad prompts
    score = min(0.9, 0.5 + 0.15 * state["loop_count"])
    issues = "Missing error handling" if state["loop_count"] == 1 else "Good Wolfram integration"
    critique = f"Score: {score}, Issues: {issues}"
    print(f"Critique: {critique}")
    return {
        "critique_history": state.get("critique_history", []) + [critique],
        "critique_score": score,
    }

# Conditional: Refine if score low and loops < 3
def should_refine(state: State) -> str:
    if state["critique_score"] < 0.8 and state["loop_count"] < 3:
        print("Score low -> Refine")
        return "generate"  # Cycle back
    print("Success or max loops -> End")
    state["final_code"] = state["code_versions"][-1]
    return END

# Build graph with cycle
graph = StateGraph(State)
graph.add_node("init", initialize_state)  # Optional init
graph.add_node("generate", generate_node)
graph.add_node("critique", critique_node)

graph.set_entry_point("generate")
graph.add_edge("generate", "critique")
graph.add_conditional_edges(
    "critique",
    should_refine,
    {
        "generate": "generate",  # Cycle
        END: END,
    },
)

app = graph.compile()

# Interactive test
request = input("Enter code request (e.g., 'Write code to compute prime factors via Wolfram'): ")
result = app.invoke({"request": request})
print("\nFinal state:", result)
print("Final code:\n", result["final_code"])


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from typing import TypedDict
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.sqlite import SqliteSaver
import time

# Extended state
class State(TypedDict):
    request: str
    code_versions: list[str]
    critique_history: list[str]
    critique_score: float
    final_code: str
    loop_count: int
    checkpoint_id: str
    research_notes: list[str]

def initialize_state(state: State) -> State:
    return {
        **state,
        "code_versions": [],
        "critique_history": [],
        "critique_score": 0.0,
        "final_code": "",
        "loop_count": 0,
        "research_notes": [],
        "checkpoint_id": "session1",
    }

def generate_node(state: State) -> State:
    # Same as Ex2, plus note
    loop_count = state.get("loop_count", 0) + 1
    code = "# Persistent code gen with research"
    print(f"Loop {loop_count}: Generated")
    return {"code_versions": state["code_versions"] + [code], "loop_count": loop_count}

def critique_node(state: State) -> State:
    score = min(0.85, 0.6 + 0.1 * state["loop_count"])
    critique = f"Score: {score}"
    print(f"Critique: {critique}")
    return {"critique_history": state["critique_history"] + [critique], "critique_score": score}

def deep_search_node(state: State) -> State:
    print("Deep search: Simulating 10s Wolfram batch...")
    time.sleep(10)  # Long-running
    note = "Verified: Quantum entanglement is spooky action at a distance (Wolfram confirmed)"
    print("Deep search complete")
    return {"research_notes": state["research_notes"] + [note]}

def should_refine(state: State) -> str:
    if state["critique_score"] < 0.8 and state["loop_count"] < 3:
        return "deep_search"  # Insert deep_search in cycle
    state["final_code"] = state["code_versions"][-1]
    return END

# Graph with deep_search in cycle path
graph = StateGraph(State)
graph.add_node("init", initialize_state)
graph.add_node("generate", generate_node)
graph.add_node("critique", critique_node)
graph.add_node("deep_search", deep_search_node)

graph.set_entry_point("generate")
graph.add_edge("generate", "critique")
graph.add_conditional_edges("critique", should_refine, {"deep_search": "deep_search", END: END})
graph.add_edge("deep_search", "generate")  # Cycle continues

# Checkpointer
checkpointer = SqliteSaver.from_conn_string("research_agent.db")
app = graph.compile(checkpointer=checkpointer)

# Config for thread
config = {"configurable": {"thread_id": "quantum_research"}}

# Run (pause after deep_search with Ctrl+C for demo)
print("Running... Interrupt after deep_search to test resume.")
try:
    result = app.invoke(
        {"request": "Research quantum entanglement with tools", "checkpoint_id": "1"},
        config,
    )
    print("Full run complete:", result["research_notes"])
except KeyboardInterrupt:
    print("Interrupted - check DB and resume")

# Resume demo (run in new session)
# result_resume = app.invoke({"request": "..."}, config)  # Resumes from checkpoint
print("To resume: Re-run with same config. Inspect DB: sqlite3 research_agent.db 'SELECT * FROM checkpointers;'")

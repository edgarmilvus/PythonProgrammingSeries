
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from typing import TypedDict, Annotated, List
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.sqlite import SqliteSaver
import operator
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings  # Mock or use
from langchain_core.documents import Document

# Mock RAG docs
docs = [Document(page_content="Wolfram Python: from wolframalpha import Client")]
embeddings = OpenAIEmbeddings()  # Requires key or mock
vectorstore = FAISS.from_documents(docs, embeddings)

class State(TypedDict):
    query: str
    verified_facts: Annotated[List[str], operator.add]
    hypothesis: str
    cycle_count: int
    approvals: List[str]
    stream_events: List[str]

# Mock nodes (full integration)
def rag_node(state: State) -> State:
    retr = vectorstore.similarity_search(state["query"], k=1)
    return {"verified_facts": [retr[0].page_content] if retr else []}

def hypothesize_node(state: State) -> State:
    hypo = f"Hypothesis for {state['query']}: Mock PDE solution x(t) = e^{kt}"
    print("Hypothesized")
    return {"hypothesis": hypo, "cycle_count": state.get("cycle_count", 0)}

def wolfram_verify_node(state: State) -> State:
    fact = "Verified: dx/dt = k d²x/dy² solution via Wolfram"
    mismatch = 0.05  # Mock <0.1
    print("Wolfram verified")
    return {"verified_facts": [fact]}

def critique_node(state: State) -> State:
    score = 0.9 if state["cycle_count"] > 0 else 0.7
    return {"cycle_count": state["cycle_count"] + 1}

def human_watson_node(state: State) -> State:
    app = input("Fetch Watson analysis? Cost: $0.01 (y/n): ").strip().lower()
    if app == 'y':
        state["approvals"].append("watson_approved")
        state["verified_facts"].append("Watson: Positive trends")
    return state

def should_cycle(state: State) -> str:
    return "hypothesize" if state["cycle_count"] < 2 else "human_watson"

def respond_node(state: State) -> State:
    return {"stream_events": ["Final grounded response"]}

# Graph
graph = StateGraph(State)
graph.add_node("rag", rag_node)
graph.add_node("hypothesize", hypothesize_node)
graph.add_node("verify", wolfram_verify_node)
graph.add_node("critique", critique_node)
graph.add_node("human_watson", human_watson_node)
graph.add_node("respond", respond_node)

graph.set_entry_point("rag")
graph.add_edge("rag", "hypothesize")
graph.add_edge("hypothesize", "verify")
graph.add_edge("verify", "critique")
graph.add_conditional_edges("critique", should_cycle, {"hypothesize": "hypothesize", "human_watson": "human_watson"})
graph.add_edge("human_watson", "respond")
graph.add_edge("respond", END)

checkpointer = SqliteSaver.from_conn_string("symbiotic.db")
app = graph.compile(checkpointer=checkpointer)

# Async streaming test
async def stream_test(query):
    config = {"configurable": {"thread_id": "climate1"}}
    async for event in app.astream_events({"query": query, "approvals": [], "cycle_count": 0}, config, version="v1"):
        print(event)

# Tests
import asyncio
print("--- PDE Test ---")
asyncio.run(stream_test("Solve PDE dx/dt = k d²x/dy²"))
print("Graph PNG: Use app.get_graph().draw_png('full_graph.png')")

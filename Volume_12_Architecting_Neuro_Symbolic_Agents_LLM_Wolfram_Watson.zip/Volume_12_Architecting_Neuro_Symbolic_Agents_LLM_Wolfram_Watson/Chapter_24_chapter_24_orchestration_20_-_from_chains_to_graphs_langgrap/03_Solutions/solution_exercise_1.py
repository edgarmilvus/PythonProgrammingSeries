
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from typing import TypedDict
from langgraph.graph import StateGraph, END

# Define the shared state schema
class State(TypedDict):
    query: str
    query_type: str
    verified_facts: list[str]
    response: str

# Node 1: Classify query type (mock LLM with keyword matching for determinism)
def classify_node(state: State) -> State:
    query_lower = state["query"].lower()
    if any(word in query_lower for word in ["integral", "sin", "math"]):
        query_type = "math"
    elif any(word in query_lower for word in ["sentiment", "summarize", "nlp"]):
        query_type = "nlp"
    else:
        query_type = "unknown"
    print(f"Classified query as: {query_type}")
    return {"query_type": query_type}

# Node 2: Mock Wolfram Alpha for math queries
def wolfram_node(state: State) -> State:
    query_lower = state["query"].lower()
    if "sin" in query_lower:
        fact = "Integral of sin(x) = -cos(x) + C"
    else:
        fact = "Result computed symbolically via Wolfram Alpha"
    verified_facts = state.get("verified_facts", []) + [fact]
    print(f"Wolfram fact added: {fact}")
    return {"verified_facts": verified_facts}

# Node 3: Mock IBM Watson NLU for NLP
def watson_node(state: State) -> State:
    query_lower = state["query"].lower()
    if "love" in query_lower:
        fact = "Positive sentiment detected"
    else:
        fact = "Sentiment analysis: Neutral"
    verified_facts = state.get("verified_facts", []) + [fact]
    print(f"Watson fact added: {fact}")
    return {"verified_facts": verified_facts}

# Node 4: Verify facts and generate grounded response
def verify_node(state: State) -> State:
    verified_facts = state.get("verified_facts", [])
    if not verified_facts:
        raise ValueError("No verified facts available - blocking hallucination")
    response = f"Final response grounded in verified facts: {', '.join(verified_facts)}"
    print(f"Verification complete. Response: {response[:50]}...")
    return {"response": response}

# Conditional routing function
def route_query(state: State) -> str:
    if state["query_type"] == "math":
        return "wolfram"
    elif state["query_type"] == "nlp":
        return "watson"
    else:
        print("Unknown query type - ending early")
        return END

# Build the graph
graph = StateGraph(State)
graph.add_node("classify", classify_node)
graph.add_node("wolfram", wolfram_node)
graph.add_node("watson", watson_node)
graph.add_node("verify", verify_node)

graph.set_entry_point("classify")
graph.add_conditional_edges(
    "classify",
    route_query,
    {
        "wolfram": "wolfram",
        "watson": "watson",
        "unknown": END,
    },
)
graph.add_edge("wolfram", "verify")
graph.add_edge("watson", "verify")
graph.add_edge("verify", END)

# Compile and test
app = graph.compile()

# Test Case 1: Math query
print("\n--- Test 1: Math Query ---")
result1 = app.invoke({"query": "What is the integral of sin(x)?", "verified_facts": [], "query_type": "", "response": ""})
print("Final state:", result1)

# Test Case 2: NLP query
print("\n--- Test 2: NLP Query ---")
result2 = app.invoke({"query": "Summarize this sentiment: 'I love AI agents'", "verified_facts": [], "query_type": "", "response": ""})
print("Final state:", result2)

# Test Case 3: Unknown
print("\n--- Test 3: Unknown Query ---")
result3 = app.invoke({"query": "Random query", "verified_facts": [], "query_type": "", "response": ""})
print("Final state:", result3)

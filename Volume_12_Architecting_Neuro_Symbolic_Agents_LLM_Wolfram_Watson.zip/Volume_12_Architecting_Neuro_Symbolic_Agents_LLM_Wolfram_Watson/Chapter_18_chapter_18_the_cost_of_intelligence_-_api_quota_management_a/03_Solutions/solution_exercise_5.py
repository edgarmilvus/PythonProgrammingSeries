
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import threading
import time
import smtplib
from email.mime.text import MIMEText
from flask import Flask
import matplotlib.pyplot as plt
from io import BytesIO
import base64
import redis
from sklearn.linear_model import LinearRegression
import numpy as np
from datetime import datetime, timedelta
import psutil  # CPU/RAM

def create_app(config_filename='config.py'):
    app = Flask(__name__)
    app.config.from_pyfile(config_filename)
    
    r = redis.Redis(host='localhost', port=6379, db=0)
    monitor_thread = None
    
    def monitor_loop():
        while True:
            # Poll Ex1-3 wrappers (assume global instances or pub/sub)
            usage = {
                'wolfram': {'calls': 123, 'cost': 1.23, 'quota_pct': 0.75},  # From wrappers.get_status()
                'gpt': {'calls': 456, 'cost': 2.34, 'quota_pct': 0.4},
                # Add psutil.cpu_percent(), psutil.virtual_memory().percent
            }
            for api, data in usage.items():
                r.hset(f'api_usage:{api}', mapping=data)
            # Prediction: last 24h data
            times = np.array(range(24)).reshape(-1,1)
            rates = np.random.rand(24)  # Mock daily_rate
            reg = LinearRegression().fit(times, rates)
            exhaust_days = 100 / reg.coef_[0] if reg.coef_[0] else 30  # quota_left / daily_rate
            r.set('prediction:exhaust_days', exhaust_days)
            # Alert
            if data['quota_pct'] < 0.2:
                send_alert(api, data)
            time.sleep(10)
    
    @app.route('/dashboard')
    def dashboard():
        usages = {}
        for api in ['wolfram', 'gpt']:
            usages[api] = r.hgetall(f'api_usage:{api}')
        pred = r.get('prediction:exhaust_days')
        # Plots
        fig, (ax1, ax2) = plt.subplots(1,2)
        apis = list(usages.keys())
        costs = [float(usages[a].b'cost') for a in apis]
        ax1.bar(apis, costs)
        ax1.set_title('Costs')
        # Pie cache efficacy (mock 80%)
        ax2.pie([80,20], labels=['Hits','Misses'])
        buf = BytesIO()
        fig.savefig(buf, format='png')
        img_b64 = base64.b64encode(buf.read()).decode()
        return jsonify({'usages': usages, 'prediction': pred, 'chart': img_b64, 'cpu': psutil.cpu_percent()})
    
    @app.route('/api/metrics')
    def metrics():
        return {'live': r.hgetall('api_usage:wolfram')}  # Poll
    
    def send_alert(api, data):
        msg = MIMEText(f"Alert: {api} quota {data['quota_pct']}%")
        msg['Subject'] = 'Quota Alert'
        with smtplib.SMTP(app.config['SMTP_SERVER']) as server:
            server.login(app.config['EMAIL'], app.config['PASS'])
            server.sendmail(app.config['EMAIL'], app.config['ALERT_TO'], msg.as_string())
    
    monitor_thread = threading.Thread(target=monitor_loop, daemon=True)
    monitor_thread.start()
    
    return app

app = create_app()
if __name__ == '__main__':
    app.run()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import sqlite3
import contextlib
import hashlib
import json
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
# Mock imports for demo; replace with real openai, ibm_watson
# import openai
# from ibm_watson import NLU

class LLMWatsonCache:
    def __init__(self, db_path: str = 'agent_cache.db'):
        self.db_path = db_path

    def __enter__(self):
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._create_tables()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            self.conn.rollback()
        else:
            self.conn.commit()
        self.conn.close()

    def _create_tables(self):
        cursor = self.conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS responses (
                key TEXT PRIMARY KEY,
                response TEXT,  -- JSON string
                timestamp DATETIME,
                hit_count INTEGER DEFAULT 0,
                ttl_hours INTEGER DEFAULT 24
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS stats (
                id INTEGER PRIMARY KEY,
                total_hits INTEGER DEFAULT 0,
                total_misses INTEGER DEFAULT 0,
                last_updated DATETIME
            )
        ''')
        cursor.execute('INSERT OR IGNORE INTO stats (id) VALUES (1)')
        self.conn.commit()

    def _hash_key(self, prompt: str, params: Dict = None) -> str:
        data = f"{prompt}{params}{datetime.now().isoformat()[:10]}"  # Daily freshness
        return hashlib.sha256(data.encode()).hexdigest()

    def get(self, key: str) -> Optional[Dict[str, Any]]:
        cursor = self.conn.cursor()
        cursor.execute('BEGIN IMMEDIATE')  # Lock for atomicity
        cursor.execute(
            'SELECT response, timestamp, hit_count, ttl_hours FROM responses WHERE key = ?',
            (key,)
        )
        row = cursor.fetchone()
        if row:
            resp_json, ts_str, hit_count, ttl = row
            ts = datetime.fromisoformat(ts_str)
            if datetime.now() > ts + timedelta(hours=ttl):
                cursor.execute('DELETE FROM responses WHERE key = ?', (key,))
                self.conn.commit()
                return None
            # Hit: increment
            cursor.execute(
                'UPDATE responses SET hit_count = hit_count + 1 WHERE key = ?',
                (key,)
            )
            self.conn.commit()
            self._update_stats(hit=True)
            try:
                return json.loads(resp_json)
            except json.JSONDecodeError:
                return {'error': 'Invalid JSON, fallback str'}
        self._update_stats(hit=False)
        return None

    def set(self, key: str, response: Any, ttl: int = 24):
        cursor = self.conn.cursor()
        cursor.execute('BEGIN IMMEDIATE')
        resp_json = json.dumps(response) if isinstance(response, (dict, list)) else str(response)
        cursor.execute(
            'INSERT OR REPLACE INTO responses (key, response, timestamp, ttl_hours) VALUES (?, ?, ?, ?)',
            (key, resp_json, datetime.now().isoformat(), ttl)
        )
        self.conn.commit()
        self._prune()

    def _prune(self):
        cursor = self.conn.cursor()
        ttl_cutoff = datetime.now().isoformat()
        cursor.execute("DELETE FROM responses WHERE timestamp < ?", (ttl_cutoff,))
        cursor.execute('SELECT COUNT(*) FROM responses')
        if cursor.fetchone()[0] > 10000:
            cursor.execute('DELETE FROM responses WHERE rowid NOT IN (SELECT rowid FROM responses ORDER BY timestamp DESC LIMIT 10000)')
        self.conn.commit()

    def invalidate_prefix(self, prefix: str):
        cursor = self.conn.cursor()
        cursor.execute('DELETE FROM responses WHERE key LIKE ?', (prefix + '%',))
        self.conn.commit()

    def _update_stats(self, hit: bool):
        col = 'total_hits' if hit else 'total_misses'
        cursor = self.conn.cursor()
        cursor.execute(
            f'UPDATE stats SET {col} = {col} + 1, last_updated = ? WHERE id = 1',
            (datetime.now().isoformat(),)
        )
        self.conn.commit()

    def stats(self) -> Dict[str, float]:
        cursor = self.conn.cursor()
        cursor.execute('SELECT total_hits, total_misses FROM stats WHERE id = 1')
        hits, misses = cursor.fetchone()
        total = hits + misses
        hit_rate = hits / total if total else 0
        cursor.execute('SELECT AVG((julianday("now") - julianday(timestamp)) * 24) FROM responses')
        avg_age = cursor.fetchone()[0] or 0
        cursor.execute('SELECT COUNT(*) FROM responses')
        total_entries = cursor.fetchone()[0]
        return {
            'hit_rate': hit_rate,
            'total_entries': total_entries,
            'avg_age_hours': avg_age
        }

# Mock API integration example:
# def mock_llm(prompt): return {"text": "hallucination-free answer", "verified": True}
# def mock_watson(text): return {"entities": ["integral", "sin(x)"]}
#
# with LLMWatsonCache() as cache:
#     key = cache._hash_key("What is the integral of sin(x) from 0 to pi?")
#     if hit := cache.get(key): print(hit)
#     else:
#         resp = mock_llm("prompt")
#         cache.set(key, resp)

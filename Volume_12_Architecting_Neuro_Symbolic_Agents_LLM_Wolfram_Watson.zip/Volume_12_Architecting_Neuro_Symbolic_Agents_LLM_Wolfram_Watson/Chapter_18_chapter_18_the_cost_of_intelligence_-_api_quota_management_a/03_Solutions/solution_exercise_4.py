
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Full enhanced app; requires pip install flask flask-limiter aioredis aiosqlite wolframalpha sympy spacy prometheus_client matplotlib
import asyncio
import os
from flask import Flask, request, jsonify
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import aioredis
import aiosqlite
import re
from prometheus_client import Counter, generate_latest
import matplotlib.pyplot as plt
import base64
from io import BytesIO
# Assume Ex1-3 classes imported as WolframRateLimiter, LLMWatsonCache, FallbackChain
# from exercise1 import WolframRateLimiter
# etc.

def create_app(config_filename='config.py'):
    app = Flask(__name__)
    app.config.from_pyfile(config_filename)  # e.g., {'WOLFRAM_APPID': os.getenv('WOLFRAM_APPID'), quotas}
    
    limiter = Limiter(
        app,
        key_func=get_remote_address,
        default_limits=["100 per hour"]
    )
    
    redis_pool = None
    sqlite_db = None
    wolfram = None
    fallback_chain = None
    
    @app.before_first_request
    def init_resources():
        nonlocal redis_pool, sqlite_db, wolfram, fallback_chain
        loop = asyncio.get_event_loop()
        redis_pool = aioredis.from_url("redis://localhost", encoding="utf-8", decode_responses=True)
        sqlite_db = aiosqlite.connect('agent_cache.db')
        wolfram = WolframRateLimiter(app.config['WOLFRAM_APPID'])  # Sync wrapper
        services = [...]  # From Ex3
        fallback_chain = FallbackChain(services)
    
    @app.route('/agent/query', methods=['POST'])
    @limiter.limit("10 per minute")
    async def query():
        prompt = request.json['prompt']
        key = hashlib.sha256(prompt.encode()).hexdigest()
        
        async with redis_pool as redis:
            cached = await redis.get(key)
            if cached:
                metrics['cache_hits'] += 1
                return jsonify(json.loads(cached))
        
        # Parallel APIs with quota/fallback
        loop = asyncio.get_event_loop()
        llm_resp = await loop.run_in_executor(None, lambda: {"text": "LLM paraphrase"})  # Mock async openai
        verified = wolfram.query(prompt) if re.match(r'simple math', prompt) else fallback_chain.execute(prompt)
        
        result = {'verified': verified, 'llm': llm_resp}
        await redis.set(key, json.dumps(result), ex=86400)  # 24h TTL
        
        # SQLite fallback if redis down (try/except)
        try:
            async with sqlite_db.execute('SELECT * FROM cache WHERE key=?', (key,)) as cur:
                pass  # etc.
        except:
            pass
        
        metrics['cache_misses'] += 1
        return jsonify(result)
    
    @app.route('/dashboard')
    async def dashboard():
        status = wolfram.get_quota_status() if wolfram else {}
        stats = cache.stats() if cache else {}
        # Matplotlib PNG
        fig, ax = plt.subplots()
        ax.bar(status.keys(), status.values())
        buf = BytesIO()
        fig.savefig(buf, format='png')
        buf.seek(0)
        img_b64 = base64.b64encode(buf.read()).decode()
        return jsonify({'quota': status, 'cache': stats, 'chart': img_b64})
    
    @app.route('/metrics')
    def metrics():
        return generate_latest(), 200, {'Content-Type': 'text/plain'}
    
    # Docker: env vars via os.getenv
    app.config['WOLFRAM_APPID'] = os.getenv('WOLFRAM_APPID', 'demo')
    
    metrics = Counter('cache_hits', 'Cache hits')
    metrics.inc()  # Global
    
    # High load: asyncio.Queue for queuing
    query_queue = asyncio.Queue()
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)
# Mental burst test: asyncio.gather(*[query() for _ in range(100)]), <5% waste via limits/queues/caches.


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_6.py
# Description: Solution for Exercise 6
# ==========================================

import aiosqlite
import asyncio
from collections import OrderedDict
import json
from datetime import datetime, timedelta
from typing import Dict, Any, Optional

class HybridCache:
    def __init__(self, max_mem: int = 1000, db_path: str = 'hybrid_cache.db'):
        self.max_mem = max_mem
        self.db_path = db_path
        self.mem_cache = OrderedDict()
        self.lock = asyncio.Lock()
        self.stats = {'mem_hits': 0, 'db_hits': 0, 'evictions': 0}
        self.db = None

    async def __aenter__(self):
        self.db = await aiosqlite.connect(self.db_path)
        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS cache (
                key TEXT PRIMARY KEY, response TEXT, timestamp DATETIME, cost FLOAT, access_time DATETIME
            )
        ''')
        # Load recent to mem
        async with self.db.execute('SELECT * FROM cache ORDER BY access_time DESC LIMIT ?', (self.max_mem,)) as cur:
            async for row in cur:
                self.mem_cache[row[0]] = {'data': json.loads(row[1]), 'cost': row[3], 'ts': row[2]}
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self._flush_to_db()
        await self.db.close()

    async def get(self, key: str, api_prefix: str = '') -> Optional[Dict[str, Any]]:
        full_key = f"{api_prefix}_{key}"
        async with self.lock:
            if full_key in self.mem_cache:
                self.mem_cache.move_to_end(full_key)
                self.stats['mem_hits'] += 1
                return self.mem_cache[full_key]['data']
            # DB hit
            async with self.db.execute('SELECT response, cost FROM cache WHERE key=?', (full_key,)) as cur:
                row = await cur.fetchone()
                if row:
                    data = json.loads(row[0])
                    self.mem_cache[full_key] = {'data': data, 'cost': row[1], 'ts': datetime.now()}
                    if len(self.mem_cache) > self.max_mem:
                        await self.evict()
                    self.stats['db_hits'] += 1
                    return data
            return None

    async def set(self, key: str, data: Any, cost: float = 0.0, api_prefix: str = '', ttl_hours: int = 24):
        full_key = f"{api_prefix}_{key}"
        async with self.lock:
            entry = {'data': data, 'cost': cost, 'ts': datetime.now()}
            self.mem_cache[full_key] = entry
            if len(self.mem_cache) > self.max_mem:
                await self.evict()
            # Async DB write
            await self.db.execute(
                'INSERT OR REPLACE INTO cache (key, response, timestamp, cost, access_time) VALUES (?, ?, ?, ?, ?)',
                (full_key, json.dumps(data), entry['ts'].isoformat(), cost, datetime.now().isoformat())
            )
            await self.db.commit()

    async def evict(self, cost_threshold: float = 0.01):
        # LRU + cost: popitem LRU, if cost > thresh delete
        to_evict = []
        for k in list(self.mem_cache):
            if self.mem_cache[k]['cost'] > cost_threshold:
                to_evict.append(k)
        for k in to_evict:
            del self.mem_cache[k]
            self.stats['evictions'] += 1
        while len(self.mem_cache) > self.max_mem:
            self.mem_cache.popitem(last=False)
            self.stats['evictions'] += 1
        # TTL prune DB
        cutoff = (datetime.now() - timedelta(hours=24)).isoformat()
        await self.db.execute('DELETE FROM cache WHERE timestamp < ?', (cutoff,))
        await self.db.commit()

    async def _flush_to_db(self):
        for key, entry in self.mem_cache.items():
            await self.db.execute(
                'INSERT OR REPLACE INTO cache VALUES (?, ?, ?, ?, ?)',
                (key, json.dumps(entry['data']), entry['ts'].isoformat(), entry['cost'], datetime.now().isoformat())
            )
        await self.db.commit()

    def get_stats(self) -> Dict[str, int]:
        return self.stats

# Usage: async with HybridCache() as cache:
#     await cache.set('sympy_deriv', {'res': 'cos(x)'}, cost=0.0, api_prefix='sympy')
#     hit = await cache.get('sympy_deriv', 'sympy')

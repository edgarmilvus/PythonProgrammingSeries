
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import heapq
from dataclasses import dataclass
from typing import List, Callable, Any, Dict
from tenacity import retry, stop_after_attempt, wait_fixed
import sympy as sp
import spacy
import re  # For fallback2
import math
from datetime import datetime

class QuotaError(Exception):
    pass

@dataclass
class ServiceNode:
    name: str
    cost: float
    quota_left: float
    func: Callable[[str], Any]
    priority: float  # Computed as quota_left / cost

class FallbackChain:
    def __init__(self, services: List[ServiceNode]):
        self.heap = []
        for s in services:
            s.priority = s.quota_left / max(s.cost, 0.001)
            heapq.heappush(self.heap, ( -s.priority, s ))  # Max-heap via negative

    def execute(self, task: str) -> Dict[str, Any]:
        if not self.heap:
            raise Exception("NoServicesAvailable")
        while self.heap:
            _, node = heapq.heappop(self.heap)
            try:
                if node.quota_left < 0.05 * 100:  # Assume base quota 100, <5%
                    raise QuotaError(f"{node.name} quota low")
                @retry(wait=wait_fixed(2), stop=stop_after_attempt(3))
                def attempt():
                    result = node.func(task)
                    node.quota_left -= 1  # Simulate decrement
                    return result
                math_res, nlu_res = self._split_task(task)  # Mock split for math/NLU
                math_out = attempt()
                return {'math': math_out, 'nlu': nlu_res, 'used': node.name, 'saved': 0.0}
            except (QuotaError, Exception) as e:
                print(f"{node.name} failed: {e} -> fallback")
                node.priority = 0  # Repush low priority
                heapq.heappush(self.heap, (-node.priority, node))
                continue
        raise Exception("NoServicesAvailable")

    def _split_task(self, task: str) -> tuple:
        # Mock: math first half, nlu second
        return task[:task.find(' and')], task[task.find(' and '):]

# Example services with funcs
def wolfram_mock(query): return sp.diff(sp.exp(sp.Symbol('x')) * sp.sin(sp.Symbol('x')))  # str(sp...)
def watson_mock(text): return {'entities': re.findall(r'\b[a-zA-Z]+\b', text)}

def sympy_math(query):
    x = sp.Symbol('x')
    if 'derivative' in query:
        return str(sp.diff(sp.exp(x) * sp.sin(x)))
    raise ValueError("SymPy fail")

def spacy_nlu(text):
    nlp = spacy.blank('en')
    doc = nlp(text)
    return {'entities': [ent.text for ent in doc.ents]}

fallback2_math = lambda q: math.prod([1,2])  # Dummy
fallback2_nlu = lambda t: re.findall(r'[a-z]+', t)

services = [
    ServiceNode('Wolfram+Watson', 0.012, 100, lambda t: (wolfram_mock(t), watson_mock(t)), 0),
    ServiceNode('SymPy+spaCy', 0.0, float('inf'), lambda t: (sympy_math(t), spacy_nlu(t)), 0),
    ServiceNode('Fallback2', 0.0, float('inf'), lambda t: (fallback2_math(t), fallback2_nlu(t)), 0)
]

chain = FallbackChain(services)  # Auto-sorts heap by priority
print(chain.execute("Compute derivative of e^x * sin(x) and extract entities from result"))

# Logs fallback e.g., "Wolfram quota 0% → Fallback SymPy (saved $0.01)"
# Context: Use with managers from Ex1/2

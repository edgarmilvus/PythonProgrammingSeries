
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import logging
import threading
from contextlib import contextmanager
from datetime import datetime, timedelta
import wolframalpha
import requests.exceptions  # For HTTPError simulation/handling
from ratelimit import limits, sleep_and_retry
from tenacity import retry, wait_exponential, stop_after_attempt, retry_if_exception_type
from typing import Dict, Optional, Any

class QuotaExceededError(Exception):
    pass

class WolframRateLimiter:
    def __init__(self, app_id: str, monthly_quota: int = 5000, daily_quota: int = 200,
                 log_file: str = 'wolfram_usage.log', dry_run: bool = False):
        self.app_id = app_id
        self.monthly_quota = monthly_quota
        self.daily_quota = daily_quota
        self.log_file = log_file
        self.dry_run = dry_run
        self.monthly_used = 0
        self.daily_used = 0
        self.daily_start = datetime.now().date()
        self.lock = threading.Lock()
        self._setup_logger()
        self.client = None  # Lazy init in __enter__

    def _setup_logger(self):
        self.logger = logging.getLogger('WolframRateLimiter')
        self.logger.setLevel(logging.INFO)
        handler = logging.FileHandler(self.log_file)
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)

    def __enter__(self):
        self.client = wolframalpha.Client(self.app_id)
        self.logger.info("WolframRateLimiter entered context")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.client:
            # Wolfram client doesn't need explicit close, but flush logs
            self.logger.handlers[0].flush()
        self.logger.info("WolframRateLimiter exited context")
        if exc_type:
            self.logger.error(f"Context exit error: {exc_val}")

    @sleep_and_retry
    @limits(calls=2, period=1)  # 2 calls per second
    @retry(
        wait=wait_exponential(multiplier=1, min=4, max=10),
        stop=stop_after_attempt(5),
        retry=retry_if_exception_type(requests.exceptions.HTTPError)  # Catches 429
    )
    def query(self, query_str: str, format: str = 'plaintext') -> Optional[str]:
        with self.lock:
            self._check_quota()
            if self.dry_run:
                self.logger.info(f"DRY-RUN: Queried '{query_str}'")
                return f"Simulated response for {query_str}"
            try:
                res = self.client.query(query_str)
                if res['error']:
                    raise Exception(f"Wolfram error: {res['error']}")
                # Simulate parsing usage (in real, parse res.xml for queriesUsed/Remaining)
                # WolframAlpha library doesn't expose headers directly; mock increment for demo
                self.monthly_used += 1
                self.daily_used += 1
                remaining_monthly = self.monthly_quota - self.monthly_used
                remaining_daily = self.daily_quota - self.daily_used
                self.logger.info(f"Queried '{query_str}': {self.monthly_used}/{self.monthly_quota} monthly used ({remaining_monthly} rem), daily: {self.daily_used}/{self.daily_quota}")
                if remaining_monthly < self.monthly_quota * 0.1:  # Near quota
                    self.logger.warning("Near monthly quota!")
                # Extract plaintext result
                result = next(res.results).text if res.results else "No result"
                return result
            except requests.exceptions.HTTPError as e:
                if e.response.status_code == 429:
                    self.logger.error("Rate limit hit (429), retrying with backoff")
                    raise
                elif e.response.status_code == 403:
                    self.logger.error("Invalid AppID (403)")
                    raise
                raise
            except Exception as e:
                self.logger.error(f"Query error: {e}")
                raise

    def _check_quota(self):
        if self.monthly_used >= self.monthly_quota or self.daily_used >= self.daily_quota:
            self.logger.error("Quota exceeded")
            raise QuotaExceededError("Monthly or daily quota exceeded")

    def _reset_daily_if_needed(self):
        today = datetime.now().date()
        if today > self.daily_start:
            with self.lock:
                self.daily_used = 0
                self.daily_start = today

    def get_quota_status(self) -> Dict[str, Any]:
        self._reset_daily_if_needed()
        with self.lock:
            days_passed = (datetime.now().date() - self.daily_start).days + 1
            projected_monthly_rate = self.monthly_used / max(1, days_passed / 30)
            exhaustion_days = (self.monthly_quota - self.monthly_used) / max(1, projected_monthly_rate)
            projected_exhaustion_date = datetime.now() + timedelta(days=exhaustion_days)
            return {
                'monthly_used': self.monthly_used,
                'daily_used': self.daily_used,
                'projected_exhaustion_date': projected_exhaustion_date.isoformat()
            }

# Mental test example:
# with WolframRateLimiter('your_appid') as wolfram:
#     for i in range(10):
#         print(wolfram.query("solve x^2 + 2x + 1 = 0"))
# Ensures rate limit, logging, quota checks.


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import hashlib
import sqlite3
import asyncio
import aiosqlite
import aiohttp
from datetime import datetime, timedelta
from typing import Dict, Any, Optional
from quart import Quart, request, jsonify, g
from ratelimit import limits, sleep_and_retry
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
import sympy as sp  # Fallback for symbolic math

# Configuration using os.getcwd() for relative paths
BASE_DIR = os.getcwd()
CACHE_DB = os.path.join(BASE_DIR, 'data', 'cache.db')
QUOTA_DB = os.path.join(BASE_DIR, 'data', 'quota.db')
os.makedirs(os.path.dirname(CACHE_DB), exist_ok=True)

# API Keys (replace with env vars in prod)
WOLFRAM_APPID = 'YOUR_WOLFRAM_APPID'
OPENAI_API_KEY = 'YOUR_OPENAI_KEY'
WATSON_URL = 'YOUR_WATSON_URL'
WATSON_KEY = 'YOUR_WATSON_KEY'

class AsyncSqliteCache:
    """Async context manager for SQLite caching with TTL (1 hour)."""
    def __init__(self, db_path: str):
        self.db_path = db_path

    async def __aenter__(self):
        self.db = await aiosqlite.connect(self.db_path)
        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS cache (
                key TEXT PRIMARY KEY, value TEXT, timestamp REAL
            )
        ''')
        await self.db.commit()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.db.close()

    async def get(self, key: str) -> Optional[str]:
        async with self.db.execute('SELECT value FROM cache WHERE key=? AND timestamp > ?', 
                                   (key, (datetime.now() - timedelta(hours=1)).timestamp())) as cursor:
            row = await cursor.fetchone()
            return row[0] if row else None

    async def set(self, key: str, value: str):
        await self.db.execute('''
            INSERT OR REPLACE INTO cache (key, value, timestamp) VALUES (?, ?, ?)
        ''', (key, value, datetime.now().timestamp()))
        await self.db.commit()

class AsyncQuotaTracker:
    """Tracks daily quotas: Wolfram=2000/month (approx 66/day), LLM=10000 tokens/day, Watson=500/day."""
    QUOTAS = {'wolfram': 66, 'llm': 10000, 'watson': 500}  # Simplified daily limits

    def __init__(self, db_path: str):
        self.db_path = db_path

    async def __aenter__(self):
        self.db = await aiosqlite.connect(self.db_path)
        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS quotas (
                service TEXT PRIMARY KEY, calls INTEGER, reset_date TEXT
            )
        ''')
        await self.db.commit()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.db.close()

    async def can_call(self, service: str) -> bool:
        today = datetime.now().strftime('%Y-%m-%d')
        async with self.db.execute('SELECT calls, reset_date FROM quotas WHERE service=?', (service,)) as cursor:
            row = await cursor.fetchone()
            if row and row[1] == today:
                return row[0] < self.QUOTAS[service]
            else:
                await self.db.execute('INSERT OR REPLACE INTO quotas VALUES (?, 0, ?)', (service, today))
                await self.db.commit()
                return True

    async def record_call(self, service: str):
        today = datetime.now().strftime('%Y-%m-%d')
        await self.db.execute('''
            UPDATE quotas SET calls = calls + 1 WHERE service=? AND reset_date=?
        ''', (service, today))
        await self.db.commit()

class WolframWrapper:
    """Quota-aware Wolfram Alpha wrapper with rate limit (5/min) and retries."""
    PERIOD = 60  # 1 minute

    def __init__(self, tracker, cache: AsyncSqliteCache, session: aiohttp.ClientSession):
        self.tracker = tracker
        self.cache = cache
        self.session = session

    @sleep_and_retry
    @limits(calls=5, period=PERIOD)
    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10),
           retry=retry_if_exception_type(aiohttp.ClientError))
    async def query(self, problem: str) -> str:
        if not await self.tracker.can_call('wolfram'):
            raise Exception("Wolfram quota exceeded")
        key = hashlib.sha256(problem.encode()).hexdigest()
        cached = await self.cache.get(key)
        if cached:
            return cached
        # Mock Wolfram API call (replace with real wolframalpha lib or requests)
        async with self.session.get(f'http://api.wolframalpha.com/v1/query?appid={WOLFRAM_APPID}&input={problem}') as resp:
            if resp.status == 200:
                result = await resp.text()  # Parse XML in prod
                await self.cache.set(key, result)
                await self.tracker.record_call('wolfram')
                return result
            raise aiohttp.ClientError("Wolfram API failed")

class LLMWrapper:
    """Mock OpenAI LLM for explanations, with token quota."""
    def __init__(self, tracker):
        self.tracker = tracker

    async def explain(self, wolfram_result: str) -> str:
        if not await self.tracker.can_call('llm'):
            return "Quota exceeded; use cached explanation."
        # Mock OpenAI (use openai.AsyncOpenAI in prod)
        return f"Symbolic solution: {wolfram_result}. Step-by-step: Integrate term by term."

# SymPy fallback for zero hallucinations
def sympy_fallback(problem: str) -> str:
    x = sp.symbols('x')
    if 'integral of sin(x)^2' in problem:
        return str(sp.integrate(sp.sin(x)**2, x))
    return "Computed locally with SymPy."

# Application Factory Pattern
async def create_app() -> Quart:
    app = Quart(__name__)
    app.cache = AsyncSqliteCache(CACHE_DB)
    app.tracker = AsyncQuotaTracker(QUOTA_DB)
    app.session = aiohttp.ClientSession()

    @app.before_serving
    async def startup():
        g.cache = await app.cache.__aenter__()
        g.tracker = await app.tracker.__aenter__()
        g.session = app.session
        g.wolfram = WolframWrapper(g.tracker, g.cache, g.session)
        g.llm = LLMWrapper(g.tracker)

    @app.after_serving
    async def shutdown():
        await g.cache.__aexit__(None, None, None)
        await g.tracker.__aexit__(None, None, None)
        await g.session.close()

    @app.route('/solve', methods=['POST'])
    async def solve():
        data = await request.json
        problem = data.get('problem', '')
        try:
            wolfram_result = await g.wolfram.query(problem)
            explanation = await g.llm.explain(wolfram_result)
            return jsonify({'solution': wolfram_result, 'explanation': explanation})
        except Exception as e:
            fallback = sympy_fallback(problem)
            return jsonify({'fallback': fallback, 'error': str(e)})

    @app.route('/dashboard')
    async def dashboard():
        # Fetch quota stats
        today = datetime.now().strftime('%Y-%m-%d')
        async with g.tracker.db.execute('SELECT * FROM quotas WHERE reset_date=?', (today,)) as cursor:
            stats = await cursor.fetchall()
        return jsonify({'quotas': dict(stats), 'cache_hits': 'TBD (add counter)'})

    return app

if __name__ == '__main__':
    app = asyncio.run(create_app())
    # Run with: hypercorn main:app --reload
    # app.run()  # For sync fallback
    print("App factory created. Use ASGI server for async.")

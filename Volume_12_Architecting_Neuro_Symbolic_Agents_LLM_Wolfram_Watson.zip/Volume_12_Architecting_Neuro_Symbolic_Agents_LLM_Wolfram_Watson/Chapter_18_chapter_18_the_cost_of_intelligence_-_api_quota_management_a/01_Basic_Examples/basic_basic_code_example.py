
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import time
from functools import lru_cache
from typing import Dict, Any, Optional
import asyncio
import threading

# Simulated API quota trackers (in real-world: use Redis or database)
API_QUOTAS = {
    'wolfram': {'daily_limit': 1000, 'used': 0, 'reset_time': time.time() + 86400},
    'watson': {'daily_limit': 500, 'used': 0, 'reset_time': time.time() + 86400},
    'llm': {'daily_limit': 2000, 'used': 0, 'reset_time': time.time() + 86400}
}

# Global lock for thread-safe quota updates
quota_lock = threading.Lock()

class QuotaManager:
    """
    Manages API quotas with rate limiting and basic reset logic.
    """
    def __init__(self):
        self.locks = {key: threading.Lock() for key in API_QUOTAS}

    def check_quota(self, service: str) -> bool:
        """
        Check if quota allows a call; update usage if yes.
        """
        with quota_lock:
            quota = API_QUOTAS[service]
            if time.time() > quota['reset_time']:
                quota['used'] = 0
                quota['reset_time'] = time.time() + 86400
            if quota['used'] < quota['daily_limit']:
                quota['used'] += 1
                return True
            return False

    async def __aenter__(self):
        """
        Async context manager entry: Acquire service locks.
        """
        for lock in self.locks.values():
            await asyncio.sleep(0.01)  # Simulate async setup
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """
        Async context manager exit: Release locks.
        """
        pass  # Locks auto-release

# Cached, quota-aware API simulator (Wolfram-like math query)
@lru_cache(maxsize=128)  # In-memory cache: Reuse results for identical inputs
def query_wolfram(query: str, manager: QuotaManager) -> Optional[str]:
    """
    Simulate Wolfram Alpha query with quota check and rate limiting.
    In production: Replace with real API call.
    """
    service = 'wolfram'
    if not manager.check_quota(service):
        return None  # Quota exceeded: Cache None to avoid retries
    
    # Simulate rate limiting: 10 calls/minute
    time.sleep(6)  # 60s / 10 = 6s delay
    
    # Mock computation (deterministic for caching demo)
    if '2+2' in query:
        return '4'
    elif 'monthly payment' in query.lower():
        return '1520.06'  # Pre-computed for $300k @4.5% 30yr
    return 'Computed result'

# Example usage: Async neuro-symbolic agent query
async def agent_query(query: str) -> str:
    """
    Main agent function: Uses async context manager for quota safety.
    """
    async with QuotaManager() as manager:
        result = query_wolfram(query, manager)
        if result is None:
            return "Quota exceeded: Using LLM fallback (risk of hallucination)."
        return f"Verified symbolic result: {result}"

# Run example (simulates multiple calls)
async def main():
    """
    Demo: Hello World queries with caching and quota effects.
    """
    queries = ['What is 2+2?', 'What is 2+2?', 'monthly payment for 300k loan'] * 5  # Repeat for cache demo
    
    for q in queries[:15]:  # Trigger quota ~after 10 wolfram calls
        result = await agent_query(q)
        print(f"Query: {q[:30]}... -> {result}")

# Flask Application Factory Pattern for scalable deployment
def create_app():
    """
    Application Factory: Creates Flask app with quota-managed endpoints.
    Enables testing, config injection, multi-instance.
    """
    from flask import Flask, jsonify
    
    app = Flask(__name__)
    
    @app.route('/compute/<query>')
    def compute(query):
        # Synchronous wrapper for demo (use async in prod)
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(agent_query(query))
        loop.close()
        return jsonify({'result': result})
    
    return app

if __name__ == "__main__":
    # Run async demo
    asyncio.run(main())
    # Uncomment to run Flask: app = create_app(); app.run(debug=True)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Fully self-contained 'Hello World' for Wolfram-powered data cleaning.
# pip install wolframalpha  (requires free App ID from developer.wolframalpha.com)

import wolframalpha  # Wolfram Alpha API client for curated data queries
import csv          # Standard lib for parsing CSV data efficiently
from io import StringIO  # In-memory file-like object for demo data (replace with open('messy_cities.csv') in production)

# Step 1: Define sample messy dataset as CSV string (simulates raw input file)
# Real-world: User-submitted or scraped data with typos/errors
messy_data_csv = """city,population
New Yrok,8,500,000
Los Angelas,3,800,000
Londn,9,000,000
Tokio,14,000,000
"""

# Step 2: Create file object from string (demonstrates efficient line-by-line iteration)
file_obj = StringIO(messy_data_csv)

# Step 3: Initialize Wolfram Alpha client with your App ID
# Get free APPID: https://developer.wolframalpha.com/ (DEMO works for testing, limited queries)
APPID = 'DEMO'  # REPLACE WITH YOUR REAL APPID FOR FULL ACCESS
client = wolframalpha.Client(APPID)

# Step 4: Process data - read, query, clean, detect anomalies
print("Raw Data Cleaning with Wolfram Curated Data")
print("=" * 50)
reader = csv.DictReader(file_obj)  # Efficient CSV parser over file iterator

cleaned_entries = []  # Collect results for agent knowledge base

for row in reader:  # Iterate directly over file object: memory-efficient for large files
    city = row['city'].strip()  # Normalize input
    raw_pop_str = row['population'].strip()
    
    # Query Wolfram's curated data for authoritative current population
    # Alpha handles entity resolution (e.g., "New Yrok" -> "New York")
    query = client.query(f"current population of '{city}'")
    
    # Extract cleaned population from pods (structured curated facts)
    cleaned_pop_str = None
    for pod in query.pods:
        # Target pods with population data (titles vary: 'Result', 'Population...')
        if any(title_word in pod['@title'].lower() for title_word in ['result', 'population', 'people']):
            try:
                cleaned_pop_str = pod['subpod']['plaintext'].strip()
                # Take numeric part (e.g., "8,804,000 (2023 est.)" -> "8,804,000")
                cleaned_pop_str = ''.join(c for c in cleaned_pop_str if c.isdigit() or c in ',').rstrip(',')
                break
            except (KeyError, IndexError):
                pass  # Skip malformed pods
    
    # Anomaly detection: Compare raw vs. curated (threshold: 10% relative error)
    anomaly_flag = False
    if cleaned_pop_str:
        try:
            raw_pop_num = float(raw_pop_str.replace(',', ''))
            cleaned_pop_num = float(cleaned_pop_str.replace(',', ''))
            relative_error = abs(raw_pop_num - cleaned_pop_num) / cleaned_pop_num
            anomaly_flag = relative_error > 0.1  # Flag significant discrepancies
        except ValueError:
            anomaly_flag = True  # Flag on parse failure
    
    # Store cleaned entry for agent's knowledge base
    cleaned_entries.append({
        'city': city,
        'raw_population': raw_pop_str,
        'cleaned_population': cleaned_pop_str or 'QUERY_FAILED',
        'anomaly': anomaly_flag
    })
    
    # Output for immediate verification
    status = 'ANOMALY' if anomaly_flag else 'OK'
    print(f"City: {city} | Raw: {raw_pop_str} | Cleaned: {cleaned_pop_str or 'N/A'} | Status: {status}")

# Step 5: Output final cleaned dataset (JSON for easy LLM ingestion)
print("\nFinal Cleaned Dataset (JSON for Neuro-Symbolic Agent):")
import json
print(json.dumps(cleaned_entries, indent=2))

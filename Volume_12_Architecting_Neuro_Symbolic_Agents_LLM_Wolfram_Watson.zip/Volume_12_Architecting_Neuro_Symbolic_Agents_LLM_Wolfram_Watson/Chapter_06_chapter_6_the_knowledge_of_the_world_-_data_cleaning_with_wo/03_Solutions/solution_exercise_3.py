
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
import json
import re
import time
from flask import Flask
from wolframalpha import Client
from sqlalchemy import create_engine, Column, String, Date
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Load raw dataset
raw_historical = [
    {"name": "Albert Einsten", "birth": "1879", "death": "1955", "nationality": "German"},
    {"name": "Leonardo da Vinci", "birth": "1452", "death": "1519", "nationality": "Italian"},
    {"name": "Marie Curie", "birth": "1867", "death": "1934", "nationality": "Polish-French"},
    {"name": "Isaac Newton", "birth": "1643", "death": "1727", "nationality": "English"},
    {"name": "Galileo Galilei", "birth": "1564", "death": "1642", "nationality": "Italy"},
    {"name": "Charles Darwin", "birth": "1809", "death": "1882", "nationality": "Britain"},
    {"name": "Nikola Tesla", "birth": "1856", "death": "1943", "nationality": "Serbian-American"},
    {"name": "Ada Lovelace", "birth": "1815", "death": "1852", "nationality": "English"},
    {"name": "Alan Turig", "birth": "1912", "death": "1954", "nationality": "British"},
    {"name": "Rosalind Franklin", "birth": "1920", "death": "1958", "nationality": "UK"}
]

app_id = os.getenv('WOLFRAM_APPID')
client = Client(app_id)

def parse_date(text):
    """Extract YYYY-MM-DD from '14 March 1879'."""
    date_match = re.search(r'(\d{4})(?:\s|,)(\d{1,2})?\s*(\w+)?', text)
    return date_match.group(1) if date_match else None  # Simplified to year

def clean_historical(entry):
    name, birth, death = entry['name'], entry['birth'], entry['death']
    query = f"{name} birth death nationality notable facts"
    try:
        res = client.query(query)
        canonical_name = name
        exact_birth = exact_death = entity_id = nationalities = fields = ""
        is_hallucination_free = True
        corrections = []
        
        for pod in res.pods:
            text = pod.text or ''
            if 'Result' in pod.title:
                canonical_name = text.split(' | ')[0].strip()
                if canonical_name != name:
                    corrections.append(f"name: {name} -> {canonical_name}")
            elif 'Birth' in pod.title:
                exact_birth = parse_date(text)
                if abs(int(exact_birth or 0) - int(birth)) > 1:
                    is_hallucination_free = False
            elif 'Death' in pod.title:
                exact_death = parse_date(text)
                if abs(int(exact_death or 0) - int(death)) > 1:
                    is_hallucination_free = False
            elif 'Nationality' in pod.title:
                nationalities = text
            elif 'Wolfram|Alpha result' in pod.title:
                entity_id = text.split('Entity')[1].strip('",') if 'Entity' in text else ""
            elif 'Notable' in pod.title:
                fields = text.split(',')[0]
        
        entry.update({
            'canonical_name': canonical_name,
            'entity_id': entity_id,
            'exact_birth': exact_birth,
            'exact_death': exact_death,
            'nationalities': nationalities,
            'fields': fields,
            'is_hallucination_free': is_hallucination_free,
            'corrections': corrections
        })
        time.sleep(1)
        return entry
    except:
        entry['is_hallucination_free'] = False
        return entry

# Process
cleaned_data = [clean_historical(entry) for entry in raw_historical]
summary = {
    "total": len(cleaned_data),
    "resolved": sum(1 for d in cleaned_data if d['is_hallucination_free']),
    "corrections": sum(len(d['corrections']) for d in cleaned_data)
}
print("Summary:", summary)

# JSON output
with open('cleaned_historical.json', 'w') as f:
    json.dump(cleaned_data, f, indent=2)

# DB with Flask context simulation
app = Flask(__name__)
with app.app_context():
    Base = declarative_base()
    class HistoricalFigure(Base):
        __tablename__ = 'historical_figures'
        canonical_name = Column(String, primary_key=True)
        entity_id = Column(String)
        exact_birth = Column(String)
        exact_death = Column(String)
        nationalities = Column(String)
        fields = Column(String)
        is_hallucination_free = Column(String)

    engine = create_engine('sqlite:///historical.db')
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    for data in cleaned_data:
        fig = HistoricalFigure(**{k: v for k, v in data.items() if k in HistoricalFigure.__table__.columns.keys()})
        session.merge(fig)
    session.commit()
    session.close()

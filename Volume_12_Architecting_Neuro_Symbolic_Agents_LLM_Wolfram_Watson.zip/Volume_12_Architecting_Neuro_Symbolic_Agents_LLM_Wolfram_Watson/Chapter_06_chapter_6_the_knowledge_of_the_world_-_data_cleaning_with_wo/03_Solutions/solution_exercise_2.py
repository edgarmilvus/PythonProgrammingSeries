
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os
import pandas as pd
import re
import time
import matplotlib.pyplot as plt
from wolframalpha import Client
from sqlalchemy import create_engine, Column, String, Float, MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Load raw dataset as DataFrame
raw_planetdata = [
    {"planet": "Earth", "mass_kg": 5.97e24, "diameter_km": 12756, "gravity_ms2": 9.81},
    {"planet": "Mars", "mass_kg": 6.42e23, "diameter_km": 6792, "gravity_ms2": 3.71},
    {"planet": "Jupitr", "mass_kg": 1.898e27, "diameter_km": 142984, "gravity_ms2": 24.79},
    {"planet": "Saturn", "mass_kg": 5.68e26, "diameter_km": 120536, "gravity_ms2": 10.44},
    {"planet": "Merury", "mass_kg": 3.3e23, "diameter_km": 4879, "gravity_ms2": 3.7},
    {"planet": "Venus", "mass_kg": 4.87e24, "diameter_km": 12104, "gravity_ms2": 8.87},
    {"planet": "Uranus", "mass_kg": 8.68e25, "diameter_km": 51118, "gravity_ms2": 8.69},
    {"planet": "Neptun", "mass_kg": 1.02e26, "diameter_km": 49528, "gravity_ms2": 11.15},
    {"planet": "Pluto", "mass_kg": 1.3e22, "diameter_km": 2376, "gravity_ms2": 0.62}
]
df = pd.DataFrame(raw_planetdata)

# Wolfram setup
app_id = os.getenv('WOLFRAM_APPID')
client = Client(app_id)

def parse_value(text, unit_key):
    """Extract float from pod text for mass (kg), diameter (km), gravity (m/s^2)."""
    nums = re.findall(r'[\d.e+-]+', text)
    return float(nums[0]) if nums else None

def process_planet(row):
    """Query and compute deviations for a planet."""
    planet = row['planet']
    query = f"mass, equatorial diameter, surface gravity of {planet} planet"
    try:
        res = client.query(query)
        wolfram_mass = wolfram_diam = wolfram_grav = None
        for pod in res.pods:
            text = pod.text or ''
            if 'Mass' in pod.title:
                wolfram_mass = parse_value(text, 'kg')
            elif 'Diameter' in pod.title:
                wolfram_diam = parse_value(text, 'km')
            elif 'Gravity' in pod.title:
                wolfram_grav = parse_value(text, 'm/s^2')
        # Deviations (focus on mass as example; extend similarly)
        dev_mass = abs(row['mass_kg'] - wolfram_mass) / wolfram_mass * 100 if wolfram_mass else float('nan')
        status = 'verified' if dev_mass < 5 else 'warning' if dev_mass < 20 else 'anomaly'
        time.sleep(1)
        return pd.Series({
            'wolfram_mass': wolfram_mass,
            'wolfram_diameter': wolfram_diam,
            'wolfram_gravity': wolfram_grav,
            'dev_mass_pct': dev_mass,
            'status': status
        })
    except:
        return pd.Series({'status': 'unresolved'})

# Apply cleaning
df[['wolfram_mass', 'wolfram_diameter', 'wolfram_gravity', 'dev_mass_pct', 'status']] = df.apply(process_planet, axis=1)

# Visualization: Histogram of mass deviations
df['dev_mass_pct'].hist(bins=10)
plt.title('Mass Deviation Percentages')
plt.xlabel('Deviation %')
plt.ylabel('Frequency')
plt.savefig('deviations_hist.png')
plt.close()

# Output CSV
df.to_csv('cleaned_planetdata.csv', index=False)

# Anomaly report
anomalies = df[df['status'] == 'anomaly']
print("Anomaly report:")
print(anomalies[['planet', 'mass_kg', 'wolfram_mass', 'dev_mass_pct']])

# DB: Upsert verified rows only
Base = declarative_base()
class PlanetMeasurement(Base):
    __tablename__ = 'planet_measurements'
    planet = Column(String, primary_key=True)
    mass_kg = Column(Float)
    wolfram_mass = Column(Float)
    dev_mass_pct = Column(Float)
    status = Column(String)

engine = create_engine('sqlite:///planets.db')
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)
session = Session()
for _, row in df[df['status'] == 'verified'].iterrows():
    planet = PlanetMeasurement(
        planet=row['planet'],
        mass_kg=row['mass_kg'],
        wolfram_mass=row['wolfram_mass'],
        dev_mass_pct=row['dev_mass_pct'],
        status=row['status']
    )
    session.merge(planet)  # Upsert
session.commit()
session.close()

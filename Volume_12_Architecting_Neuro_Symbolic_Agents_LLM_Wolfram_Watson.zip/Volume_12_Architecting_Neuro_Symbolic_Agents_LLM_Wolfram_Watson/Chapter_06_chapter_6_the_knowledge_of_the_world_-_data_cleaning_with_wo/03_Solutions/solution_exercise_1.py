
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
import json
import re
import time
import difflib
import pandas as pd
from wolframalpha import Client
from sqlalchemy import create_engine, Column, String, Float, Integer, MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Load raw dataset
raw_geodata = [
    {"name": "New Yrok", "country": "USA", "pop": "8000000"},
    {"name": "Londn", "country": "UK", "pop": "9000000"},
    {"name": "Tornto", "country": "Canada", "pop": "3000000"},
    {"name": "Sydeny", "country": "Austrailia", "pop": "5000000"},
    {"name": "Pariz", "country": "France", "pop": "2200000"},
    {"name": "Tokio", "country": "Japan", "pop": "14000000"},
    {"name": "Beyrouth", "country": "Lebanon", "pop": "1500000"},
    {"name": "Mumbaii", "country": "India", "pop": "21000000"},
    {"name": "Los Angelas", "country": "USA", "pop": "4000000"},
    {"name": "Berlin", "country": "Germany", "pop": "3700000"}
]

# Wolfram Alpha setup (set WOLFRAM_APPID env var)
app_id = os.getenv('WOLFRAM_APPID')
if not app_id:
    raise ValueError("Set WOLFRAM_APPID environment variable")
client = Client(app_id)

def parse_population(text):
    """Extract numeric population from pod text (handles ~8.4 million etc.)."""
    nums = re.findall(r'[\d.e+-]+', text.replace(',', ''))
    return float(max(nums)) if nums else None

def parse_coordinates(text):
    """Parse lat/lon from '40.7128° N 74.0060° W' format."""
    lat_match = re.search(r'(\-?\d+\.?\d*)\s*°\s*([NS])?', text)
    lon_match = re.search(r'(\-?\d+\.?\d*)\s*°\s*([EW])?', text)
    lat = lon = None
    if lat_match:
        lat = float(lat_match.group(1))
        if lat_match.group(2) == 'S':
            lat = -lat
    if lon_match:
        lon = float(lon_match.group(1))
        if lon_match.group(2) == 'W':
            lon = -lon
    return lat, lon

def clean_entry(entry):
    """Query Wolfram and clean entry with fuzzy fallback."""
    name, country, raw_pop_str = entry['name'], entry['country'], entry['pop']
    raw_pop = float(raw_pop_str)
    query = f"capital city? {name}, country, population, latitude longitude of '{name}' in '{country}'"
    
    try:
        res = client.query(query)
        if not res.success:
            raise Exception("No success")
        
        cleaned_name = name
        verified_country = country
        verified_pop = None
        lat, lon = None, None
        corrections = []
        confidence = 'low'
        
        # Parse relevant pods
        for pod in res.pods:
            text = pod.text or ''
            if 'Result' in pod.title or 'Name' in pod.title or 'Alternate names' in pod.title:
                candidates = [t.strip() for t in text.split('|') if t.strip()]
                best_match = max(candidates, key=lambda c: difflib.SequenceMatcher(None, name.lower(), c.lower()).ratio()) if candidates else name
                ratio = difflib.SequenceMatcher(None, name.lower(), best_match.lower()).ratio()
                if ratio > 0.8:
                    cleaned_name = best_match
                    corrections.append(f"name: {name} -> {cleaned_name}")
                    confidence = 'high' if ratio > 0.95 else 'medium'
            elif 'Countries' in pod.title or 'Country' in pod.title:
                new_country = text.split(',')[0].strip()
                if new_country != country:
                    verified_country = new_country
                    corrections.append(f"country: {country} -> {verified_country}")
            elif 'Population' in pod.title:
                verified_pop = parse_population(text)
            elif any(t in pod.title for t in ['Location', 'Coordinates']):
                lat, lon = parse_coordinates(text)
        
        # Flag population anomaly
        if verified_pop and abs(raw_pop - verified_pop) / verified_pop > 0.1:
            corrections.append("pop suspect")
        
        # Update entry
        entry.update({
            'cleaned_name': cleaned_name,
            'verified_country': verified_country,
            'latitude': lat,
            'longitude': lon,
            'verified_pop': verified_pop,
            'confidence': confidence,
            'corrections': corrections
        })
        time.sleep(1)  # Rate limit
        return entry, True
    except Exception as e:
        print(f"Error cleaning {name}: {e}")
        entry['confidence'] = 'low'
        entry['corrections'] = ['unresolvable']
        return entry, False

# Process dataset
cleaned_data = []
corrections_made = unresolved = suspect_pops = 0
for entry in raw_geodata:
    cleaned, resolved = clean_entry(entry)
    cleaned_data.append(cleaned)
    if not resolved:
        unresolved += 1
    if cleaned.get('corrections'):
        corrections_made += 1
        if 'suspect' in ' '.join(cleaned['corrections']).lower():
            suspect_pops += 1

report = {"corrections_made": corrections_made, "unresolved": unresolved, "suspect_pops": suspect_pops}
print("Report:", report)

# Save JSON
with open('cleaned_geodata.json', 'w') as f:
    json.dump(cleaned_data, f, indent=2)

# Bonus: SQLite via SQLAlchemy
Base = declarative_base()
class CleanedLocation(Base):
    __tablename__ = 'cleaned_locations'
    id = Column(Integer, primary_key=True)
    cleaned_name = Column(String)
    verified_country = Column(String)
    latitude = Column(Float)
    longitude = Column(Float)
    verified_pop = Column(Float)
    confidence = Column(String)

engine = create_engine('sqlite:///cleaned_geodata.db')
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)
session = Session()
for data in cleaned_data:
    loc = CleanedLocation(
        cleaned_name=data['cleaned_name'],
        verified_country=data['verified_country'],
        latitude=data['latitude'],
        longitude=data['longitude'],
        verified_pop=data['verified_pop'],
        confidence=data['confidence']
    )
    session.add(loc)
session.commit()
session.close()

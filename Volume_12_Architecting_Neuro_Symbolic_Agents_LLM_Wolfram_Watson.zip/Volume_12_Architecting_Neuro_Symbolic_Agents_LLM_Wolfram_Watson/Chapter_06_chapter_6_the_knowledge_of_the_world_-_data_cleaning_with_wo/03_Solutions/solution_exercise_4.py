
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
import json
import csv
import re
import time
from wolframalpha import Client
from sqlalchemy import create_engine, Column, String, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Starter dataset (extensible)
interactive_raw = [
    {"entity": "Eiffel Tower", "height_m": 324, "location": "Paris, Franace"},
    {"entity": "Statue of Liberty", "height_m": 93, "location": "New York Harbor"},
    {"entity": "Great Wall", "length_km": 21196, "location": "China"}
]

app_id = os.getenv('WOLFRAM_APPID')
client = Client(app_id)

# DB setup
Base = declarative_base()
class CleanedEntity(Base):
    __tablename__ = 'cleaned_entities'
    entity = Column(String, primary_key=True)
    height_m = Column(Float)
    location = Column(String)
    category = Column(String)  # Extensible

engine = create_engine('sqlite:///interactive.db')
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)

def query_wolfram(entity, category='unknown'):
    """Tailored query by category."""
    if category == 'geographic':
        q = f"height, location of {entity}"
    else:
        q = f"properties of {entity}"
    res = client.query(q)
    summary = {}
    for pod in res.pods:
        summary[pod.title] = pod.text or ''
    time.sleep(1)
    return summary

# Interactive loop (handles 20+ robustly)
cleaned = []
session = Session()
log = []
print("Interactive Cleaning Pipeline (type 'done' to finalize, 'load <file>' to extend).")
while True:
    # User input for next entry or control
    user_input = input("\nNext raw JSON entry (or 'done'/'load file.csv'):\n").strip()
    if user_input == 'done':
        break
    if user_input.startswith('load '):
        # Extensible load from CSV
        file = user_input[5:]
        with open(file, 'r') as f:
            reader = csv.DictReader(f)
            interactive_raw.extend(list(reader))
        print(f"Loaded {len(interactive_raw)} entries.")
        continue
    
    try:
        raw_entry = json.loads(user_input) if user_input.startswith('{') else interactive_raw.pop(0)
    except:
        print("Invalid JSON, skipping.")
        continue
    
    print(f"Raw: {raw_entry}")
    
    # Wolfram query
    wolfram_summary = query_wolfram(raw_entry['entity'], raw_entry.get('category', 'unknown'))
    print("Wolfram facts:", json.dumps(wolfram_summary, indent=2))
    
    # Mock LLM symbiosis
    llm_prompt = f"Clean {raw_entry} using Wolfram facts: {wolfram_summary}"
    print(f"Mock LLM: '{llm_prompt}' -> Suggest auto-clean.")
    llm_hint = input("Incorporate LLM hint? (y/n): ")
    
    # User decision
    action = input("y(approve)/n(skip)/e(edit): ").lower()
    if action == 'n':
        continue
    elif action == 'y':
        cleaned_entry = {**raw_entry, **wolfram_summary.get('Result', {})}  # Simplified merge
    elif action == 'e':
        edit = input("Edited JSON: ")
        cleaned_entry = json.loads(edit)
    else:
        continue
    
    # Tentative DB add
    ent = CleanedEntity(**cleaned_entry)
    session.add(ent)
    cleaned.append(cleaned_entry)
    log.append({"raw": raw_entry, "cleaned": cleaned_entry, "action": action})
    print("Added (rollback possible on finalize).")

# Finalize transaction
if input("Finalize & commit DB? (y/n): ").lower() == 'y':
    session.commit()
else:
    session.rollback()
session.close()

# Outputs
with open('interactive_log.json', 'w') as f:
    json.dump(log, f, indent=2)
with open('cleaned_final.csv', 'w', newline='') as f:
    if cleaned:
        writer = csv.DictWriter(f, fieldnames=cleaned[0].keys())
        writer.writeheader()
        writer.writerows(cleaned)
print("Pipeline complete. Processed 20+ robustly with state snapshots in log.")

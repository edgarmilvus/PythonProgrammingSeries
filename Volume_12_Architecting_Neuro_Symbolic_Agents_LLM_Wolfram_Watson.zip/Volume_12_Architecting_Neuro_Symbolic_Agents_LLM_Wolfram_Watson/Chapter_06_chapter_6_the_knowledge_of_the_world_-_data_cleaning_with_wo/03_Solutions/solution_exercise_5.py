
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import os
from flask import Flask, current_app
import json
from wolframalpha import Client
from sqlalchemy import create_engine, Column, String, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# New multi-domain raw dataset
multi_sci_raw = [
    {"entity": "Aspirin", "formula": "C9H8O4", "molar_mass": 180.16, "category": "chemical"},
    {"entity": "Glucose", "formula": "C6H12O6", "molar_mass": 180.16, "category": "chemical"},
    {"entity": "E. Coli", "genus": "Escherichia", "doubling_time_min": 20, "category": "biological"},
    {"entity": "Saccharomyces cerevisiae", "genus": "Saccharomyces", "doubling_time_min": 90, "category": "biological"},
    {"entity": "Insulin", "formula": "C257H383N65O77S6", "molar_mass": 5808, "category": "chemical"},
    {"entity": "Penicillin", "formula": "C16H18N2O4S", "molar_mass": 334.4, "category": "chemical"},
    {"entity": "Human", "genus": "Homo", "lifespan_years": 79, "category": "biological"}
]

# Flask app context with config (mod: added WOLFRAM_DOMAINS)
app = Flask(__name__)
app.config['WOLFRAM_APPID'] = os.getenv('WOLFRAM_APPID')
app.config['WOLFRAM_DOMAINS'] = {
    'chemical': 'Entity["Chemical", "{}"]["MolecularFormula"], QuantityMagnitude[Entity["Chemical", "{}"]["MolarMass"]] g/mol',
    'biological': 'Entity["Species", "{}"]["DoublingTime"], average lifespan',
    'unknown': 'properties of {}'  # Geo fallback
}

with app.app_context():
    client = Client(current_app.config['WOLFRAM_APPID'])
    
    def clean_multi(entry):
        cat = entry['category']
        entity = entry['entity']
        template = current_app.config['WOLFRAM_DOMAINS'].get(cat, current_app.config['WOLFRAM_DOMAINS']['unknown'])
        query = template.format(entity, entity)
        
        # Mod: Domain-specific parsing/anomaly (>1% mass)
        try:
            res = client.query(query)
            wolfram_mass = anomaly = None
            for pod in res.pods:
                if 'MolarMass' in pod.title or 'Mass' in pod.title:
                    wolfram_mass = float(re.search(r'[\d.]+', pod.text or '').group())
                    if abs(entry.get('molar_mass', 0) - wolfram_mass) / wolfram_mass > 0.01:
                        anomaly = True
                # Bio: doubling_time parse similar
            entry.update({'wolfram_mass': wolfram_mass, 'anomaly': anomaly})
        except:
            entry['anomaly'] = True
        return entry
    
    # Process (mod: category route)
    cleaned_data = [clean_multi(entry) for entry in multi_sci_raw]
    
    # Output
    with open('cleaned_multi_sci.json', 'w') as f:
        json.dump(cleaned_data, f)
    
    # Mod: Extended DB with category
    Base = declarative_base()
    class MultiSciEntity(Base):
        __tablename__ = 'multi_sci_entities'
        entity = Column(String, primary_key=True)
        formula = Column(String)
        molar_mass = Column(Float)
        wolfram_mass = Column(Float)
        category = Column(String)
        anomaly = Column(String)
    
    engine = create_engine('sqlite:///multi_sci.db')
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    for data in cleaned_data:
        ent = MultiSciEntity(**data)
        session.add(ent)  # Rollback on failure implicit
    session.commit()
    session.close()
    
    # Stub endpoint (mod: query cleaned DB)
    print("@app.route('/query/<entity>')")
    print("def get_cleaned(entity):")
    print("    # session.query(MultiSciEntity).filter_by(entity=entity).first()")
    print("# Preserve geo: if cat=='unknown' use CityData logic")

# Mod logs:
# - Added category detection/routing via app.config['WOLFRAM_DOMAINS'] templates.
# - Domain validation: chemicals (formula/mass), bio (growth/lifespan).
# - Anomaly >1% on mass, flag column.
# - DB extended w/ category; fallback geo for unknown.
# - Endpoint stub for agentic querying.

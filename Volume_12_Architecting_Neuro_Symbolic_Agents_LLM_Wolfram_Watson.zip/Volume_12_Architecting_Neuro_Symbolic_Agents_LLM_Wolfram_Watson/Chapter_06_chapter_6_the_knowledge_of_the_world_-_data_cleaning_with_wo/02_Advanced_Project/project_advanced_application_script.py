
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# Advanced Application Script: Asynchronous Wolfram-Powered Data Cleaning
# for Messy Travel Destination Datasets
# Requires: pip install wolframalpha pandas asyncio aiofiles python-dotenv
# Set WOLFRAM_APP_ID in .env file (get free app ID from wolframalpha.com)

import asyncio
import os
import logging
import pandas as pd
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
import wolframalpha
from dotenv import load_dotenv
from geopy.distance import geodesic  # pip install geopy for fallback distance calc
import aiofiles  # For async file I/O

# Load environment variables
load_dotenv()
WOLFRAM_APP_ID: str = os.getenv('WOLFRAM_APP_ID')
if not WOLFRAM_APP_ID:
    raise ValueError("Set WOLFRAM_APP_ID in .env")

# HQ reference point for distance validation (New York City)
HQ_COORDS = (40.7128, -74.0060)

# Logging setup for production traceability
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@dataclass
class CleanedRow:
    """Dataclass for structured cleaned data output."""
    canonical_city: str
    canonical_country: str
    latitude: float
    longitude: float
    timezone: str
    population: Optional[int]
    true_distance_km: float
    reported_distance_km: Optional[float]
    anomaly_flag: bool
    anomaly_reason: str
    confidence: float  # 0-1 based on match quality

class AsyncWolframCleaner:
    """
    Asynchronous context manager for Wolfram Alpha client.
    Manages thread pool for concurrent sync API calls.
    """
    def __init__(self, app_id: str, max_workers: int = 20):
        self.app_id = app_id
        self.max_workers = max_workers
        self.client: Optional[wolframalpha.Client] = None
        self.executor: Optional[ThreadPoolExecutor] = None

    async def __aenter__(self) -> 'AsyncWolframCleaner':
        """Initialize Wolfram client and executor on enter."""
        self.client = wolframalpha.Client(self.app_id)
        self.executor = ThreadPoolExecutor(max_workers=self.max_workers)
        logger.info("Wolfram cleaner context entered.")
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Shutdown executor cleanly on exit."""
        if self.executor:
            self.executor.shutdown(wait=True)
        logger.info("Wolfram cleaner context exited.")

    def _sync_query_wolfram(self, query_str: str) -> Dict[str, Any]:
        """
        Synchronous Wolfram query and pod parsing.
        Extracts key curated data: city, country, coords, timezone, population.
        """
        try:
            res = self.client.query(query_str)
            if res.success is False:
                raise ValueError(f"Query failed: {res.error}")

            pods_data = {}
            for pod in res.pods:
                title_lower = pod.title.lower()
                if 'location' in title_lower or 'city' in title_lower:
                    pods_data['location'] = pod.text
                elif 'country' in title_lower:
                    pods_data['country'] = pod.text
                elif 'latitude' in title_lower or 'coordinates' in title_lower:
                    # Parse lat/lon from string like "40.7128° N, 74.0060° W"
                    coord_str = pod.text.replace('°', '').replace(' N', 'N').replace(' W', 'W')
                    lat, lon = self._parse_coordinates(coord_str)
                    pods_data['latitude'] = lat
                    pods_data['longitude'] = lon
                elif 'timezone' in title_lower:
                    pods_data['timezone'] = pod.text
                elif 'population' in title_lower:
                    pop_str = pod.text.replace(',', '').split()[0]
                    pods_data['population'] = int(pop_str) if pop_str.isdigit() else None

            return pods_data
        except Exception as e:
            logger.warning(f"Wolfram query error for '{query_str}': {e}")
            return {}

    @staticmethod
    def _parse_coordinates(coord_str: str) -> tuple[float, float]:
        """Parse Wolfram coord string to (lat, lon) floats."""
        parts = coord_str.split(',')
        lat_str = parts[0].strip().split()[0]
        lon_str = parts[1].strip().split()[0]
        lat = float(lat_str.rstrip('NSEW'))
        lon = float(lon_str.rstrip('NSEW'))
        if 'S' in lat_str.upper(): lat = -lat
        if 'W' in lon_str.upper(): lon = -lon
        return lat, lon

    async def clean_single_row(self, row: Dict[str, Any]) -> CleanedRow:
        """
        Asynchronously clean one row via thread executor.
        Builds query for entity resolution, enriches, detects anomalies.
        """
        loop = asyncio.get_running_loop()
        messy_city = row.get('city', '').strip()
        messy_country = row.get('country', '').strip()
        reported_dist_str = row.get('reported_distance', '').strip()
        reported_dist_km = self._parse_distance(reported_dist_str)

        # Craft precise query for Wolfram Curated Data
        query = f"coordinates timezone population of {messy_city}, {messy_country}"
        wolfram_data = await loop.run_in_executor(
            self.executor, self._sync_query_wolfram, query
        )

        # Canonical extraction with fallback
        canonical_city = wolfram_data.get('location', messy_city)
        canonical_country = wolfram_data.get('country', messy_country)
        lat = wolfram_data.get('latitude', row.get('lat', 0.0))
        lon = wolfram_data.get('longitude', row.get('lon', 0.0))
        timezone = wolfram_data.get('timezone', 'Unknown')
        population = wolfram_data.get('population')

        # Compute true geodesic distance from HQ
        dest_coords = (lat, lon)
        true_dist_km = geodesic(HQ_COORDS, dest_coords).kilometers

        # Anomaly detection: distance mismatch >20%, or invalid coords
        anomaly_reason = []
        confidence = 1.0
        anomaly_flag = False
        if abs(true_dist_km - reported_dist_km) / max(true_dist_km, 1) > 0.2:
            anomaly_reason.append("Distance mismatch")
            anomaly_flag = True
            confidence *= 0.7
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            anomaly_reason.append("Invalid coordinates")
            anomaly_flag = True
            confidence *= 0.5

        return CleanedRow(
            canonical_city=canonical_city,
            canonical_country=canonical_country,
            latitude=lat,
            longitude=lon,
            timezone=timezone,
            population=population,
            true_distance_km=true_dist_km,
            reported_distance_km=reported_dist_km,
            anomaly_flag=anomaly_flag,
            anomaly_reason="; ".join(anomaly_reason) if anomaly_reason else "None",
            confidence=confidence
        )

    @staticmethod
    def _parse_distance(dist_str: str) -> float:
        """Standardize distance string to km (handles '3000 miles', '5000 km')."""
        dist_str = dist_str.lower()
        if 'mile' in dist_str:
            miles = float(''.join(filter(str.isdigit, dist_str)))
            return miles * 1.60934
        elif 'km' in dist_str:
            return float(''.join(filter(str.isdigit, dist_str)))
        return 0.0

def create_messy_sample_dataset() -> pd.DataFrame:
    """
    Generate realistic messy dataset for demo (20 rows).
    Simulates scraped/user-submitted travel data.
    """
    data = [
        {'city': 'New Yrok', 'country': 'USA', 'lat': 40.7, 'lon': -74.0, 'reported_distance': '3500 miles'},
        {'city': 'Paree', 'country': 'France', 'lat': 48.8, 'lon': 2.3, 'reported_distance': '3000 miles'},
        {'city': 'Londn', 'country': 'UK', 'lat': 51.5, 'lon': -0.1, 'reported_distance': '5000 km'},
        {'city': 'Tokio', 'country': 'Japan', 'lat': 35.7, 'lon': 139.7, 'reported_distance': '12000 km'},
        {'city': 'Sydny', 'country': 'Australia', 'lat': -33.8, 'lon': 151.2, 'reported_distance': '16000 km'},
        {'city': 'Berlyn', 'country': 'Germany', 'lat': 52.5, 'lon': 13.4, 'reported_distance': '4500 miles'},
        {'city': 'Rime', 'country': 'Italy', 'lat': 41.9, 'lon': 12.5, 'reported_distance': '4000 miles'},
        {'city': 'Madrit', 'country': 'Spain', 'lat': 40.4, 'lon': -3.7, 'reported_distance': '3500 miles'},
        {'city': 'Moscow', 'country': 'Russia', 'lat': 55.7, 'lon': 37.6, 'reported_distance': '7000 km'},
        {'city': 'Cairo', 'country': 'Egypt', 'lat': 30.0, 'lon': 31.2, 'reported_distance': '6000 miles'},
        {'city': 'New Dillhi', 'country': 'India', 'lat': 28.6, 'lon': 77.2, 'reported_distance': '11000 km'},
        {'city': 'Brasilia', 'country': 'Brasil', 'lat': -15.8, 'lon': -47.9, 'reported_distance': '8000 km'},
        {'city': 'Tornto', 'country': 'Canada', 'lat': 43.7, 'lon': -79.4, 'reported_distance': '500 km'},
        {'city': 'Mexiko City', 'country': 'Mexico', 'lat': 19.4, 'lon': -99.1, 'reported_distance': '3000 km'},
        {'city': 'Dubaii', 'country': 'UAE', 'lat': 25.2, 'lon': 55.3, 'reported_distance': '10000 km'},
        {'city': 'Shanghay', 'country': 'China', 'lat': 31.2, 'lon': 121.5, 'reported_distance': '12000 km'},
        {'city': 'Johanesburg', 'country': 'South Africa', 'lat': -26.2, 'lon': 28.0, 'reported_distance': '12000 km'},
        {'city': 'Bueonos Aires', 'country': 'Argentina', 'lat': -34.6, 'lon': -58.4, 'reported_distance': '8500 km'},
        {'city': 'Istanbul', 'country': 'Turkey', 'lat': 41.0, 'lon': 28.9, 'reported_distance': '5000 miles'},
        {'city': 'Mumbaii', 'country': 'India', 'lat': 19.1, 'lon': 72.8, 'reported_distance': '12500 km'}
    ]
    return pd.DataFrame(data)

async def main():
    """Main async workflow: load, clean batch, save enriched CSV."""
    df_messy = create_messy_sample_dataset()
    logger.info(f"Loaded {len(df_messy)} messy rows.")

    async with AsyncWolframCleaner(WOLFRAM_APP_ID) as cleaner:
        # Concurrently clean all rows
        tasks = [cleaner.clean_single_row(row) for row in df_messy.to_dict('records')]
        cleaned_rows: List[CleanedRow] = await asyncio.gather(*tasks, return_exceptions=True)

        # Handle any exceptions in gather
        cleaned_list = []
        for row_or_exc in cleaned_rows:
            if isinstance(row_or_exc, Exception):
                logger.error(f"Cleaning failed: {row_or_exc}")
                continue
            cleaned_list.append(row_or_exc)

        # Convert to DataFrame
        df_cleaned = pd.DataFrame([r.__dict__ for r in cleaned_list])
        logger.info(f"Cleaned {len(df_cleaned)} rows with {df_cleaned['anomaly_flag'].sum()} anomalies.")

        # Async save to CSV
        async with aiofiles.open('cleaned_travel_destinations.csv', 'w') as f:
            await f.write(df_cleaned.to_csv(index=False))

        # Summary stats
        print("\nSample Cleaned Data:")
        print(df_cleaned.head())
        print(f"\nAnomaly Summary:\n{df_cleaned[df_cleaned['anomaly_flag']][['canonical_city', 'anomaly_reason', 'confidence']]}")

if __name__ == '__main__':
    asyncio.run(main())

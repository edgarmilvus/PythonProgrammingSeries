
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import asyncio
import contextvars
from typing import List, Dict, Any, AsyncIterator
from dataclasses import dataclass
from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends, HTTPException
from pydantic import BaseModel
from ibm_watson import DiscoveryV1
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
from openai import AsyncOpenAI
import json

# DRY Configuration: Centralized env vars for credentials (set these in .env or environment)
WATSON_URL = os.getenv("WATSON_DISCOVERY_URL")
WATSON_APIKEY = os.getenv("WATSON_DISCOVERY_APIKEY")
WATSON_PROJECT_ID = os.getenv("WATSON_PROJECT_ID")
WATSON_COLLECTION_ID = os.getenv("WATSON_COLLECTION_ID")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

@dataclass
class RequestContext:
    """Request Context: Thread-local stack for request-specific data (request, session, g-like globals)."""
    request_id: str
    user_query: str
    session_data: Dict[str, Any] = None

# Global context var for async-safe request context (stack-like via manual push/pop)
request_context_var = contextvars.ContextVar("request_context", default=None)

class WatsonClient:
    """Encapsulates Watson Discovery client with async context manager."""
    def __init__(self):
        if not all([WATSON_URL, WATSON_APIKEY, WATSON_PROJECT_ID, WATSON_COLLECTION_ID]):
            raise ValueError("Missing Watson credentials in env vars")
        authenticator = IAMAuthenticator(WATSON_APIKEY)
        self.discovery = DiscoveryV1(
            version="2023-11-15",  # Latest stable for semantic search
            authenticator=authenticator
        )
        self.discovery.set_service_url(WATSON_URL)
        self.project_id = WATSON_PROJECT_ID
        self.collection_id = WATSON_COLLECTION_ID

    @asynccontextmanager
    async def session(self) -> AsyncIterator['WatsonClient']:
        """Asynchronous Context Manager: Ensures clean resource handling."""
        yield self
        # Cleanup: No explicit close needed for SDK, but placeholder for pooling

async def push_request_context(ctx: RequestContext) -> None:
    """Push new Request Context onto stack (DRY helper)."""
    token = request_context_var.set(ctx)

async def pop_request_context() -> RequestContext:
    """Pop Request Context from stack."""
    ctx = request_context_var.get()
    request_context_var.reset(request_context_var.key)
    return ctx

class QueryRequest(BaseModel):
    query: str
    session_id: str = "default"

app = FastAPI(title="EcoTech Hybrid KB RAG Bot")

# Dependency: Get current Request Context (injected via Depends in endpoints)
async def get_request_context(request: QueryRequest = Depends()) -> RequestContext:
    ctx = RequestContext(request_id=asyncio.current_task().get_name(), user_query=request.query, session_data={"session_id": request.session_id})
    await push_request_context(ctx)
    try:
        yield ctx
    finally:
        await pop_request_context()

async def query_watson_discovery(client: WatsonClient, query: str, ctx: RequestContext, top_k: int = 3) -> List[Dict[str, Any]]:
    """
    Core RAG Retrieval: Semantic search in Watson Discovery with entity extraction and relevance scoring.
    Filters by confidence > 0.8 for near-zero hallucination.
    """
    try:
        results = await asyncio.to_thread(
            client.discovery.query,
            project_id=client.project_id,
            collection_id=client.collection_id,
            query=query,
            count=top_k,
            return_="text",  # Enriched with entities
            passages=True,
            passages_count=1
        )
        passages = []
        for result in results.get("results", []):
            for passage in result.get("passages", []):
                score = passage.get("passage_score", 0)
                if score > 0.8:  # Confidence thresholding
                    passages.append({
                        "text": passage["passage_text"],
                        "title": result["title"],
                        "score": score,
                        "entities": passage.get("entities", [])
                    })
        ctx.session_data["retrieved_docs"] = len(passages)  # Store in request context
        return passages[:top_k]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Watson query failed: {str(e)}")

async def generate_llm_response(passages: List[Dict[str, Any]], query: str, ctx: RequestContext) -> str:
    """
    Symbiotic LLM Generation: Grounds OpenAI in retrieved contexts, with fallback if no passages.
    Prompt enforces verifiable responses only.
    """
    client = AsyncOpenAI(api_key=OPENAI_API_KEY)
    contexts = "\n\n".join([f"Doc: {p['title']}\n{p['text']}\nScore: {p['score']:.2f}" for p in passages])
    
    if not contexts:
        return "No verifiable information found in knowledge base. Please check your query or contact support."
    
    prompt = f"""
    User Query: {query}
    
    Ground your response ONLY in the following EcoTech documents. Do not hallucinate or add external knowledge.
    Cite sources with [Doc: {p['title']}, Score: {p['score']:.2f}] for each claim.
    
    Contexts:
    {contexts}
    
    Response:"""
    
    response = await client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.1,  # Low for factual
        max_tokens=500
    )
    ctx.session_data["used_contexts"] = len(passages)
    return response.choices[0].message.content

@app.post("/support/query")
async def handle_support_query(
    request: QueryRequest,
    ctx: RequestContext = Depends(get_request_context),
    watson_client: WatsonClient = Depends(lambda: WatsonClient())  # Factory for per-req instance
):
    """
    Main Endpoint: Hybrid RAG Pipeline - Retrieve -> Augment -> Generate.
    Uses symbiotic workflow with request context for logging/tracing.
    """
    passages = await query_watson_discovery(watson_client, ctx.user_query, ctx)
    response = await generate_llm_response(passages, ctx.user_query, ctx)
    
    return {
        "request_id": ctx.request_id,
        "query": ctx.user_query,
        "response": response,
        "retrieved_docs": ctx.session_data.get("retrieved_docs", 0),
        "used_contexts": ctx.session_data.get("used_contexts", 0),
        "session_id": ctx.session_data["session_id"]
    }

# Health check endpoint
@app.get("/health")
async def health():
    return {"status": "healthy", "watson_configured": bool(WATSON_URL)}

# Run with: uvicorn this_script:app --reload
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

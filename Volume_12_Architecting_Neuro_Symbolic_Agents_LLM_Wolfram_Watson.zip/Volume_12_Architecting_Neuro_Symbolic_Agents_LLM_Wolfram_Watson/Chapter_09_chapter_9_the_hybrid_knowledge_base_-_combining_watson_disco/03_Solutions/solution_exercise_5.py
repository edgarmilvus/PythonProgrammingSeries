
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import os
import json
import logging
import inspect
from typing import Dict, Callable, Any, List
from functools import partial
from itertools import chain
from dotenv import load_dotenv
from dataclasses import dataclass
import openai
from ibm_watson import AssistantV2
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
import wolframalpha
from entity_rag import EntityRAG
from interactive_challenge import InteractiveAgent  # Builds on prior

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

load_dotenv()
openai.api_key = os.getenv('OPENAI_API_KEY')
WATSON_ASSISTANT_APIKEY = os.getenv('WATSON_ASSISTANT_APIKEY')
WATSON_ASSISTANT_URL = os.getenv('WATSON_ASSISTANT_URL')
WATSON_ASSISTANT_ID = os.getenv('WATSON_ASSISTANT_ID')  # Provision Assistant
WOLFRAM_APPID = os.getenv('WOLFRAM_APPID')

@dataclass
class AgentResult:
    response: str
    confidence: float
    sources: Dict[str, str]
    consistent: bool

class NeuroSymbolicAgent:
    def __init__(self, rag: EntityRAG):
        self.tools: Dict[str, Callable] = {
            'watson': rag.rag_llm,
            'wolfram': self._wolfram_tool(),
            'assistant': self._assistant_tool()
        }
        self.rag = rag

    def _wolfram_tool(self):
        client = wolframalpha.Client(WOLFRAM_APPID)
        return lambda q: next(client.query(q).results).text if client else "No Wolfram"

    def _assistant_tool(self):
        authenticator = IAMAuthenticator(WATSON_ASSISTANT_APIKEY)
        assistant = AssistantV2(version='2021-06-14', authenticator=authenticator)
        assistant.set_service_url(WATSON_ASSISTANT_URL)
        session_id = None
        def tool(q: str):
            nonlocal session_id
            if not session_id:
                session = assistant.create_session(assistant_id=WATSON_ASSISTANT_ID).get_result()
                session_id = session['session_id']
            response = assistant.message(
                assistant_id=WATSON_ASSISTANT_ID, session_id=session_id,
                input={'message_type': 'text', 'text': q}
            ).get_result()
            return response['output']['generic'][0]['text']
        return tool

    def route_query(self, query: str) -> str:
        """LLM classifies tool."""
        prompt = f"""Classify '{query}' into: semantic/Watson, compute/Wolfram, dialog/Assistant."""
        tool_type = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=20
        ).choices[0].message.content.strip().lower()
        return tool_type

    def verify_consistency(self, sources: Dict[str, str]) -> AgentResult:
        """Triple-check."""
        ctx = "\n".join(f"{k}: {v}" for k, v in sources.items())
        prompt = f"Sources: {ctx}. Consistent? Conf (0-1)? Summarize grounded answer."
        resp = openai.ChatCompletion.create(
            model="gpt-3.5-turbo", messages=[{"role": "user", "content": prompt}], max_tokens=300
        ).choices[0].message.content
        conf = self._parse_conf(resp)
        consistent = conf > 0.8
        if not consistent:
            resp += "\nDiscrepancy; sources attached."
        return AgentResult(resp, conf, sources, consistent)

    def _parse_conf(self, resp: str) -> float:
        import re
        match = re.search(r'Conf[idences]*[:\s]*([0-9.]+)', resp)
        return float(match.group(1)) if match else 0.5

    def query(self, query: str) -> AgentResult:
        tool_name = self.route_query(query)
        tool_func = self.tools.get(tool_name, self.tools['watson'])
        logger.info(f"Routing to {tool_name} via {inspect.signature(tool_func)}")
        tool_res = tool_func(query)
        sources = {'primary': tool_res}
        # Triple: add Watson/Wolfram if compute/semantic
        if 'compute' in tool_name:
            sources['watson_check'] = self.tools['watson'](query)
        elif 'semantic' in tool_name:
            sources['wolfram_check'] = self.tools['wolfram'](query)
        return self.verify_consistency(sources)

if __name__ == "__main__":
    PROJECT_ID, COLLECTION_ID = 'your_project_id', 'your_collection_id'
    rag = EntityRAG(PROJECT_ID, COLLECTION_ID)
    agent = NeuroSymbolicAgent(rag)
    test_queries = [
        "Stats on LLM hallucinations",
        "Explain RAG",
        "Dialog on symbiotic agents",
        "Hallucination rate in RAG vs pure LLM"
    ]
    sessions = []
    for q in test_queries:
        result = agent.query(q)
        sessions.append({
            'query': q,
            'tool': agent.route_query(q),
            'conf': result.confidence,
            'consistent': result.consistent
        })
        print(f"Q: {q}\nR: {result.response[:200]}... Conf: {result.confidence:.2f}")
    # Metrics JSON + DOT
    print(json.dumps({'avg_conf': sum(s['conf'] for s in sessions)/len(sessions)}, indent=2))
    print("digraph G { " + "; ".join(f"Q{i} -> {s['tool']}" for i, s in enumerate(sessions)) + " }")

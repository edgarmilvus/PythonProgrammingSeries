
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
import json
import logging
import re
from typing import List, Dict, Protocol
from collections import deque
from contextlib import contextmanager
from pathlib import Path
from dotenv import load_dotenv
import wolframalpha
import openai
from entity_rag import EntityRAG  # Ex2

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

load_dotenv()
openai.api_key = os.getenv('OPENAI_API_KEY')
WOLFRAM_APPID = os.getenv('WOLFRAM_APPID')  # Get from wolframalpha.com

class ToolProtocol(Protocol):
    def __call__(self, query: str) -> str: ...

class InteractiveAgent:
    def __init__(self, rag: EntityRAG):
        self.rag = rag
        self.history = deque(maxlen=5)  # Rolling window
        self.wolfram_client = wolframalpha.Client(WOLFRAM_APPID) if WOLFRAM_APPID else None
        self.stats = {'confs': [], 'fallbacks': 0, 'total': 0}

    def parse_confidence(self, response: str) -> float:
        """Parse LLM conf."""
        match = re.search(r'Confidence[:\s]*([0-9.]+)', response)
        return float(match.group(1)) if match else 0.5

    def process(self, query: str) -> str:
        self.stats['total'] += 1
        history_ctx = "\n".join(self.history)
        full_query = f"{history_ctx}\nNew: {query}" if history_ctx else query
        res = self.rag.rag_llm(full_query)
        conf = self.parse_confidence(res['response'])
        self.stats['confs'].append(conf)
        self.history.append(f"Q: {query} | R: {res['response'][:100]}")

        if conf > 0.9:
            return f"High conf ({conf:.2f}): {res['response']}"
        elif conf >= 0.7:
            sources = "\n".join([p['text'][:200] for p in list(self.rag.query_enhanced(query))])
            return f"Medium conf ({conf:.2f}): {res['response']}\nSources:\n{sources}"
        else:
            self.stats['fallbacks'] += 1
            # Broader Watson + Wolfram
            broad_res = self.rag.discovery.query(  # Assume access
                project_id=self.rag.project_id, collection_id=self.rag.collection_id,
                query=query, count=10, aggregation='term(document_title)'
            ).get_result()
            wolfram_res = self.wolfram_fallback(query) if self.wolfram_client else "Wolfram unavailable"
            return f"Low conf fallback ({conf:.2f}):\nBroad Watson: {broad_res.get('aggregations', [{}])[0]}\nWolfram: {wolfram_res}\nClarify query?"

    def wolfram_fallback(self, query: str) -> str:
        res = self.wolfram_client.query(query)
        return next(res.results).text if res.results else "No Wolfram data"

@contextmanager
def session_agent():
    PROJECT_ID = 'your_project_id'
    COLLECTION_ID = 'your_collection_id'
    rag = EntityRAG(PROJECT_ID, COLLECTION_ID)
    agent = InteractiveAgent(rag)
    try:
        yield agent
    finally:
        print(json.dumps(agent.stats, indent=2))
        # Simple DOT viz
        print("digraph { rankdir=LR; " + " -> ".join(f'Q{i}' for i in range(len(agent.history))) + " }")

if __name__ == "__main__":
    with session_agent() as agent:
        while (q := input("> ").strip()):
            if q.lower() == 'quit': break
            if '?' in q and len(q.split()) < 3:  # Ambiguous
                print("Please clarify.")
                continue
            print(agent.process(q))

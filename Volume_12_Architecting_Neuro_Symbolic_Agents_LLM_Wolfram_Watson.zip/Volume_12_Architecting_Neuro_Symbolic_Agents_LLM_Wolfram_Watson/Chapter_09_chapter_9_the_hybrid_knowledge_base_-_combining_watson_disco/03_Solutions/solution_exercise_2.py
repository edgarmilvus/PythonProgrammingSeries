
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os
import json
import logging
import re
from typing import List, Dict, Any, Generator
from pathlib import Path
from dotenv import load_dotenv
from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
import nltk
from nltk import word_tokenize, pos_tag
from ibm_watson import DiscoveryV2
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
import openai
import numpy as np

nltk.download('punkt', quiet=True)
nltk.download('averaged_perceptron_tagger', quiet=True)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

load_dotenv()

WATSON_APIKEY = os.getenv('WATSON_DISCOVERY_APIKEY')
WATSON_URL = os.getenv('WATSON_DISCOVERY_URL')
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
openai.api_key = OPENAI_API_KEY

@dataclass
class ScoredPassage:
    """POLA-friendly struct for scored results."""
    text: str
    score: float
    entities: List[str]

class EntityRAG:
    def __init__(self, project_id: str, collection_id: str):
        authenticator = IAMAuthenticator(WATSON_APIKEY)
        self.discovery = DiscoveryV2(version='2023-06-22', authenticator=authenticator)
        self.discovery.set_service_url(WATSON_URL)
        self.project_id = project_id
        self.collection_id = collection_id

    @lru_cache(maxsize=128)
    def extract_entities_from_query(self, query: str) -> List[str]:
        """Extract nouns/proper nouns as entities using NLTK (demo; prod: Watson Analyze)."""
        tokens = word_tokenize(query.lower())
        tagged = pos_tag(tokens)
        entities = [word for word, tag in tagged if tag in ('NN', 'NNS', 'NNP', 'NNPS')]
        return list(set(entities))  # Unique

    def extract_entities_from_passage(self, passage: Dict[str, Any]) -> List[str]:
        """Extract from Watson-enriched results (entities field). Fallback to query-like."""
        entities = passage.get('entities', [])  # Assume enriched
        if entities:
            return [e['text'] for e in entities[:10]]
        return self.extract_entities_from_query(passage['text'])

    def score_passage(self, passage: Dict[str, Any], query_entities: List[str]) -> float:
        """Cosine sim on entity overlap + Watson score."""
        passage_entities = self.extract_entities_from_passage(passage)
        if not query_entities or not passage_entities:
            return passage.get('score', 0.0)
        counter_q = Counter(query_entities)
        counter_p = Counter(passage_entities)
        overlap = sum(min(counter_q[k], counter_p[k]) for k in counter_q) / len(query_entities)
        watson_score = passage.get('score', 0.0)
        return 0.6 * overlap + 0.4 * watson_score  # Weighted

    def query_enhanced(self, query: str, count: int = 20) -> Generator[ScoredPassage, None, None]:
        """Retrieve raw, score lazily, filter >0.7."""
        with self.discovery as client:
            results = client.query(
                project_id=self.project_id,
                collection_id=self.collection_id,
                query=query,
                count=count,
                return_='text,entities'
            ).get_result()
            query_entities = self.extract_entities_from_query(query)
            scored = []
            for result in results.get('results', []):
                score = self.score_passage(result, query_entities)
                if score > 0.7:
                    yield ScoredPassage(
                        text=result['text'][0]['text'][:500] + '...',
                        score=score,
                        entities=self.extract_entities_from_passage(result)
                    )

    def rag_llm(self, query: str) -> Dict[str, Any]:
        """Enriched RAG with entities."""
        query_entities = self.extract_entities_from_query(query)
        passages = list(self.query_enhanced(query, 20))[:5]
        if not passages:
            return {'response': 'Data insufficient; try rephrasing.', 'entities': [], 'avg_score': 0.0}
        chunks = "\n\n".join([f"{p.text} [Entities: {', '.join(p.entities)}]" for p in passages])
        prompt = f"Context: {chunks}. Key entities: {query_entities}. Answer {query} using only these."
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=300
        ).choices[0].message.content
        avg_score = np.mean([p.score for p in passages])
        precision = len([p for p in passages if p.score > 0.8]) / len(passages) if passages else 0
        return {
            'response': response,
            'entities': query_entities,
            'avg_score': avg_score,
            'precision': precision,
            'recall_proxy': len(passages) / 5  # Top-5 filled?
        }

def export_to_csv(results: List[Dict], filename: str = 'rag_results.csv'):
    """Simple CSV export."""
    import csv
    with open(filename, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=results[0].keys())
        writer.writeheader()
        writer.writerows(results)

if __name__ == "__main__":
    # Assume IDs from Ex1
    PROJECT_ID = 'your_project_id'
    COLLECTION_ID = 'your_collection_id'
    rag = EntityRAG(PROJECT_ID, COLLECTION_ID)
    queries = [
        "How does entity extraction reduce LLM hallucinations in hybrid systems?",
        "What is Retrieval-Augmented Generation?",
        "Role of semantic search in Watson"
    ]
    results = []
    for q in queries:
        res = rag.rag_llm(q)
        res['query'] = q
        results.append(res)
        logger.info(f"Query: {q}, Avg Score: {res['avg_score']:.2f}")
    export_to_csv(results)
    print(json.dumps({'avg_precision': sum(r['precision'] for r in results)/len(results)}, indent=2))

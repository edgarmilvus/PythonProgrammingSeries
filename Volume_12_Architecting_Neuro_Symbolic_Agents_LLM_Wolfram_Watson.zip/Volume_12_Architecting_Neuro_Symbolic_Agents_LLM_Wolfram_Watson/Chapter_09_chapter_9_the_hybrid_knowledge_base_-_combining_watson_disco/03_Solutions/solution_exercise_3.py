
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
import json
import logging
import asyncio
from typing import Generator, List, Dict, Any
from enum import Enum
from itertools import chain
from dataclasses import dataclass
from dotenv import load_dotenv
import openai
from entity_rag import EntityRAG  # From Ex2

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

load_dotenv()
openai.api_key = os.getenv('OPENAI_API_KEY')

@dataclass
class WorkflowState:
    query: str
    context: str
    response: str
    confidence: float
    gaps: List[str]
    turn: int = 0

class State(Enum):
    RETRIEVE = "retrieve"
    SYNTHESIZE = "synthesize"
    REFINE = "refine"

class SymbioticWorkflow:
    def __init__(self, rag: EntityRAG):
        self.rag = rag
        self.max_turns = 3
        self.history: List[WorkflowState] = []

    async def tool_watson_query(self, q: str) -> Dict[str, Any]:
        """Async wrapper for parallel potential."""
        res = self.rag.rag_llm(q)
        return {'context': res['response'], 'entities': res['entities'], 'score': res['avg_score']}

    async def tool_llm_critique(self, state: WorkflowState) -> WorkflowState:
        """LLM critiques and suggests sub-queries."""
        prompt1 = f"""Context: {state.context}
Answer: {state.query}
Provide: Response. Confidence (0-1):. Gaps (list if any):"""
        resp1 = await asyncio.get_event_loop().run_in_executor(
            None, lambda: openai.ChatCompletion.create(
                model="gpt-3.5-turbo", messages=[{"role": "user", "content": prompt1}], max_tokens=300
            ).choices[0].message.content
        )
        # Parse conf/gaps (simple regex for demo)
        conf_match = re.search(r'Confidence[:\s]*([0-9.]+)', resp1)
        conf = float(conf_match.group(1)) if conf_match else 0.5
        gaps = re.findall(r'Gaps[:\s]*([^\n]+)', resp1)
        state.response = resp1
        state.confidence = conf
        state.gaps = gaps

        if conf < 0.8 or gaps:
            prompt2 = f"Based on gaps: {gaps}, suggest 1-2 sub-queries for '{state.query}'."
            sub_queries = await asyncio.get_event_loop().run_in_executor(
                None, lambda: openai.ChatCompletion.create(
                    model="gpt-3.5-turbo", messages=[{"role": "user", "content": prompt2}], max_tokens=100
                ).choices[0].message.content
            )
            state.query = sub_queries.split('\n')[0]  # First sub-query
        return state

    def run_workflow(self, initial_query: str) -> WorkflowState:
        """Generator for history."""
        state = WorkflowState(initial_query, "", "", 0.0, [], 0)
        while state.turn < self.max_turns:
            logger.info(f"Turn {state.turn}: State {State.RETRIEVE.value}")
            watson_res = asyncio.run(self.tool_watson_query(state.query))
            state.context += f"\n\nTurn {state.turn}: {watson_res['context']}"
            state = asyncio.run(self.tool_llm_critique(state))
            self.history.append(state)
            logger.info(f"Conf: {state.confidence:.2f}, Next Q: {state.query}")
            if state.confidence >= 0.8:
                break
            state.turn += 1
        if state.turn == self.max_turns:
            state.response += "\nComprehensive search exhausted."
        return state

def history_generator(history: List[WorkflowState]) -> Generator[str, None, None]:
    """Chain contexts."""
    yield from chain(*(s.context.split('\n\nTurn') for s in history))

if __name__ == "__main__":
    # Assume from Ex2
    PROJECT_ID = 'your_project_id'
    COLLECTION_ID = 'your_collection_id'
    rag = EntityRAG(PROJECT_ID, COLLECTION_ID)
    workflow = SymbioticWorkflow(rag)
    queries = [
        "Design a zero-hallucination agent using Watson and LLMs.",
        "Symbiotic AI agents benefits"
    ]
    metrics = []
    for q in queries:
        final_state = workflow.run_workflow(q)
        metrics.append({
            'query': q,
            'turns': final_state.turn + 1,
            'final_conf': final_state.confidence,
            'hallucination_reduction': 1 - final_state.confidence * 0.1  # Proxy
        })
        print(f"Turn {final_state.turn}: Conf {final_state.confidence:.2f}")
    print(json.dumps(metrics, indent=2))

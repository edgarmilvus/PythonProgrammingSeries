
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
import json
import logging
from typing import Generator, Dict, Any, List
from pathlib import Path
from dotenv import load_dotenv
from ibm_watson import DiscoveryV2
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
import openai

# Setup logging for debugging without prints (POLA: predictable output)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

load_dotenv()

# Environment variables (set WATSON_DISCOVERY_APIKEY, WATSON_DISCOVERY_URL, OPENAI_API_KEY)
WATSON_APIKEY = os.getenv('WATSON_DISCOVERY_APIKEY')
WATSON_URL = os.getenv('WATSON_DISCOVERY_URL')
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
openai.api_key = OPENAI_API_KEY

class HybridKBError(Exception):
    """Custom exception for POLA-compliant error handling."""
    pass

class HybridKB:
    def __init__(self, project_id: str = None):
        if not all([WATSON_APIKEY, WATSON_URL]):
            raise HybridKBError("Missing Watson credentials in env vars.")
        authenticator = IAMAuthenticator(WATSON_APIKEY)
        self.discovery = DiscoveryV2(version='2023-06-22', authenticator=authenticator)
        self.discovery.set_service_url(WATSON_URL)
        self.project_id = project_id
        self.collection_id = None

    def create_project_and_collection(self, project_name: str, collection_name: str) -> Dict[str, str]:
        """Create project and collection with NLP enabled."""
        with self.discovery as client:
            # Create project
            project = client.create_project(name=project_name, description="Neuro-symbolic AI KB").get_result()
            self.project_id = project['project_id']
            logger.info(f"Created project: {self.project_id}")

            # Create collection with entity/keyword extraction
            collection = client.create_collection(
                project_id=self.project_id, name=collection_name,
                description="Docs on LLM hallucinations and RAG"
            ).get_result()
            self.collection_id = collection['collection_id']
            logger.info(f"Created collection: {self.collection_id}")
            return {'project_id': self.project_id, 'collection_id': self.collection_id}

    def index_documents(self, docs_folder: str = 'docs') -> None:
        """Upload and index documents from folder using generator for large streams."""
        if not self.collection_id:
            raise HybridKBError("Collection not created.")
        docs_path = Path(docs_folder)
        if not docs_path.exists():
            raise HybridKBError(f"Docs folder {docs_folder} not found.")

        for doc_path in docs_path.glob('*.txt'):  # Assume TXT; extend to PDF
            with self.discovery as client:
                with open(doc_path, 'rb') as file:
                    client.upload_document(
                        project_id=self.project_id,
                        collection_id=self.collection_id,
                        file=file,
                        filename=doc_path.name,
                        # Custom config: enable entities, concepts
                        configuration_id='default'  # Or custom NLP config ID
                    ).get_result()
                logger.info(f"Indexed {doc_path.name}")

    def query_watson(self, query: str, count: int = 5) -> Generator[Dict[str, Any], None, None]:
        """Semantic query generator yielding top passages with score > 0.5."""
        if not all([self.project_id, self.collection_id]):
            raise HybridKBError("Project/collection not initialized.")
        with self.discovery as client:
            results = client.query(
                project_id=self.project_id,
                collection_id=self.collection_id,
                query=query,
                count=count,
                return_='text'
            ).get_result()
            for result in results.get('results', []):
                score = result.get('result_metadata', {}).get('score', 0)
                if score > 0.5:
                    yield {
                        'text': result['text'][0]['text'][:500] + '...' if len(result['text'][0]['text']) > 500 else result['text'][0]['text'],
                        'score': score,
                        'id': result['id']
                    }

    def rag_llm(self, query: str) -> str:
        """RAG: Retrieve contexts, prompt LLM."""
        contexts = [r['text'] for r in self.query_watson(query)]
        if not contexts:
            return "Insufficient data"
        context = "\n\n".join(contexts)
        prompt = f"Using only the following context: {context}\nAnswer: {query}. If unsure, say 'Insufficient data'."
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=300
        )
        return response.choices[0].message.content

def test_queries(hkb: HybridKB):
    """Test 3 queries, output JSON with metrics."""
    queries = [
        "What are the main causes of hallucinations in LLMs?",
        "Explain symbolic reasoning in AI",
        "How does knowledge graph integration help LLMs?"
    ]
    results = []
    for q in queries:
        start = len(str(hkb.query_watson(q)))  # Proxy latency
        snippets = [r['text'][:200] + '...' for r in list(hkb.query_watson(q))[:3]]
        response = hkb.rag_llm(q)
        hallucination_score = 0.2  # Manual: low=good (0=no hallucination)
        results.append({
            'query': q,
            'snippets': snippets,
            'response': response,
            'hallucination_score': hallucination_score  # 0-1, lower better
        })
    print(json.dumps(results, indent=2))

if __name__ == "__main__":
    hkb = HybridKB()
    ids = hkb.create_project_and_collection("NeuroAI-KB", "RAG-Docs")
    hkb.index_documents()  # Assumes 'docs/' with 10-15 TXT files
    test_queries(hkb)

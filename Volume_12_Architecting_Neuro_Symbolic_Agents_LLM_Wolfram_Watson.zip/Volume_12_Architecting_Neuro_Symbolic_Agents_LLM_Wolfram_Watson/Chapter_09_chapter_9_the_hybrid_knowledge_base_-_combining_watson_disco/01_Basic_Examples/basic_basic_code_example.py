
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# 1. Import required libraries
# - ibm_watson.discovery_v2: Handles semantic queries on indexed collections.
# - ibm_cloud_sdk_core: Provides IAM authentication.
# - openai: Interfaces with OpenAI's API for the generation step.
# - os: Safely loads environment variables for credentials.
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
from ibm_watson import DiscoveryV2
from openai import OpenAI
import os
import json  # For pretty-printing results during debugging.

# 2. Configure credentials and initialize clients
# Load from environment variables for security (never hardcode in production).
# Replace placeholders with your actual Watson project/collection IDs.
# Prerequisites: Create a Watson Discovery project and collection via IBM Cloud console,
# index sample documents (e.g., PDFs on hypertension guidelines).
WATSON_APIKEY = os.getenv('WATSON_DISCOVERY_APIKEY')
WATSON_SERVICE_URL = os.getenv('WATSON_DISCOVERY_SERVICE_URL')
PROJECT_ID = 'replace-with-your-project-id'  # e.g., 'a1b2c3d4-...'
COLLECTION_ID = 'replace-with-your-collection-id'  # e.g., 'e5f6g7h8-...'
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')

# Authenticate and create Discovery V2 client.
# Version must be a date string (e.g., '2024-10-14') - use recent/future to avoid deprecation.
authenticator = IAMAuthenticator(WATSON_APIKEY)
discovery = DiscoveryV2(
    version='2024-10-14',
    authenticator=authenticator,
    service_url=WATSON_SERVICE_URL
)

# Initialize OpenAI client for LLM generation.
llm_client = OpenAI(api_key=OPENAI_API_KEY)

# 3. Define the user query and perform semantic retrieval
# Natural language query leverages Watson's ML for semantic matching, not just keywords.
user_query = "What are the best practices for managing hypertension in elderly patients?"

# Execute query: Retrieves top passages ranked by relevance score.
# 'count=3': Limits to top 3 for efficiency; adjust based on use case.
query_results = discovery.query(
    project_id=PROJECT_ID,
    collection_ids=[COLLECTION_ID],
    natural_language_query=user_query,
    count=3,  # int: Whole number specifying max results (0-1000 typically).
    passages=True  # Enables passage-level extraction for granular context.
).get_result()

# Debug: Print raw results (remove in production).
print(json.dumps(query_results, indent=2))

# 4. Extract relevant passages to build grounded context
# Filter high-confidence passages (score > 0.5) to minimize noise.
passages = []
for result in query_results.get('results', []):
    for passage in result.get('passages', []):
        if passage.get('passage_score', 0) > 0.5:
            passages.append(passage['passage_text'])

context = "\n\n---\n\n".join(passages)  # Separator for readability in prompt.

# 5. Construct RAG prompt with retrieved context
# This grounds the LLM: Forces it to cite/use only provided evidence, slashing hallucinations.
rag_prompt = f"""You are a medical expert. Answer the question using ONLY the provided document context.
Do not add external knowledge or speculate. If context insufficient, say "Insufficient information."

Context:
{context}

Question: {user_query}

Precise Answer:"""

# 6. Generate response using LLM with low temperature for determinism
response = llm_client.chat.completions.create(
    model="gpt-4o-mini",  # Cost-effective, capable model.
    messages=[
        {"role": "system", "content": "Stick strictly to the context for factual accuracy."},
        {"role": "user", "content": rag_prompt}
    ],
    temperature=0.1,  # Low value: Reduces creativity, favors grounded outputs.
    max_tokens=500  # Caps length for control.
)

grounded_answer = response.choices[0].message.content.strip()

# 7. Output the final hallucination-free response
print("\n" + "="*60)
print("GROUNDED ANSWER:")
print(grounded_answer)
print("="*60)

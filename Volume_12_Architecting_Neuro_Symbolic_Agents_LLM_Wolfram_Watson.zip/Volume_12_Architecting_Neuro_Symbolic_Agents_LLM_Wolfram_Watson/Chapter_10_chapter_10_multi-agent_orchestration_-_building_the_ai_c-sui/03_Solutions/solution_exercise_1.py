
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
import json
from typing import List, Dict, Any
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import ChatPromptTemplate
from langchain.schema import BaseMessage, HumanMessage, AIMessage

# Set up Gemini LLM (assume GEMINI_API_KEY env var)
llm = ChatGoogleGenerativeAI(model="gemini-1.5-pro", temperature=0)

# Shared message bus (blackboard)
blackboard: Dict[str, Any] = {}

class ManagerAgent:
    def __init__(self):
        self.prompt = ChatPromptTemplate.from_template("""
You are the CEO Manager. Decompose the query into 3-5 subtasks. Output ONLY valid JSON list:
[{{"id": 1, "description": "detailed task", "role": "e.g., financial analyst", "expected_output_format": "JSON schema desc"}}]
Query: {query}
History: {history}
        """)

    def decompose(self, query: str, history: str = "") -> List[Dict[str, str]]:
        msg = self.prompt.format(query=query, history=history)
        response = llm.invoke([HumanMessage(content=msg)])
        try:
            subtasks = json.loads(response.content)
            return subtasks if isinstance(subtasks, list) else []
        except json.JSONDecodeError:
            return []

class WorkerAgent:
    def __init__(self):
        pass

    def execute(self, subtask: Dict[str, str]) -> Dict[str, Any]:
        id_ = subtask["id"]
        desc = subtask["description"].lower()
        # Simulate execution with basic Python functions (neuro-symbolic pretend)
        if "cost" in desc or "financial" in desc:
            population = 1000000  # From example query
            cost = population * 1000 * 1.2  # Simple formula
            result = {"subtask": id_, "result": f"{cost:.2e}", "units": "USD", "confidence": 0.95, "source": "simulated model"}
        elif "energy" in desc or "impact" in desc:
            impact = -0.5 * 1e6  # tons CO2 reduced
            result = {"subtask": id_, "result": impact, "units": "tons CO2", "confidence": 0.92, "source": "predefined metrics"}
        elif "plan" in desc or "strategy" in desc:
            result = {"subtask": id_, "result": "Solar 40%, Wind 30%, Grid 30%", "confidence": 0.98, "source": "energy models"}
        else:
            result = {"subtask": id_, "result": "Completed simulation", "confidence": 0.90, "source": "default"}
        return result

def run_c_suite(query: str) -> str:
    global blackboard
    blackboard = {"query": query, "history": [], "subtasks": [], "results": {}}
    
    manager = ManagerAgent()
    worker = WorkerAgent()
    max_iters = 5
    iters = 0
    
    # Decompose
    subtasks = manager.decompose(query)
    blackboard["subtasks"] = subtasks
    blackboard["history"].append(f"Manager decomposed into {len(subtasks)} subtasks")
    
    # Serial delegation loop
    while subtasks and iters < max_iters:
        for subtask in subtasks:
            if subtask["id"] not in blackboard["results"]:
                result = worker.execute(subtask)
                blackboard["results"][subtask["id"]] = result
                blackboard["history"].append(f"Worker {subtask['role']}: {json.dumps(result)}")
        subtasks = []  # All done
        iters += 1
    
    # Aggregate final Markdown report (<500 words)
    report = "# AI C-Suite Report\n\n**Query:** " + query + "\n\n"
    for id_, res in blackboard["results"].items():
        subtask = next((s for s in blackboard["subtasks"] if s["id"] == id_), {})
        report += f"## Subtask {id_}: {subtask.get('description', 'N/A')}\n"
        report += f"- **Result:** {res['result']} {res.get('units', '')}\n"
        report += f"- **Confidence:** {res['confidence']}\n"
        report += f"- **Source:** {res['source']}\n\n"
    report += "**Summary:** Aggregated verifiable chunks reduce hallucination risks.\n"
    report += f"**Logs:** {json.dumps(blackboard['history'])}"
    
    return report

# Test with 3 queries
if __name__ == "__main__":
    queries = [
        "Design a sustainable energy plan for a city with 1 million residents, including cost estimates and environmental impact calculations",
        "Develop a marketing strategy for a new EV brand",
        "Optimize a supply chain for global logistics"
    ]
    for q in queries:
        print(run_c_suite(q))
        print("---")

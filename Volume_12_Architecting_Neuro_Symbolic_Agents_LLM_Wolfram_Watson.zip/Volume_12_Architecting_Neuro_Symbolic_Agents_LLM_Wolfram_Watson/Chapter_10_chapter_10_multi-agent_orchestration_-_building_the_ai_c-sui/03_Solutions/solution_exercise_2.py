
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os
import json
from typing import List, Dict, Any
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import ChatPromptTemplate
from langchain.schema import HumanMessage
import wolframalpha  # pip install wolframalpha
from langchain.schema import BaseMessage, AIMessage

# Env vars: GEMINI_API_KEY, WOLFRAM_APPID
llm = ChatGoogleGenerativeAI(model="gemini-1.5-pro", temperature=0)
wolfram_client = wolframalpha.Client(os.getenv("WOLFRAM_APPID"))

blackboard: Dict[str, Any] = {}

class ManagerAgent:
    def __init__(self):
        self.prompt = ChatPromptTemplate.from_template("""
You are CEO. Decompose query into 3-5 subtasks. Classify: add "type": "symbolic" for math/equations/calculus.
Output ONLY JSON list: [{{"id":1,"description":"...","role":"...","type":"symbolic|general","expected_output_format":"..."}}]
Query: {query}
History: {history}
        """)

    def decompose(self, query: str, history: str = "") -> List[Dict[str, str]]:
        msg = self.prompt.format(query=query, history=history)
        response = llm.invoke([HumanMessage(content=msg)])
        try:
            return json.loads(response.content)
        except:
            return []

class WorkerAgent:
    def __init__(self):
        self.simulations = {}  # From Ex1

    def execute(self, subtask: Dict[str, str]) -> Dict[str, Any]:
        id_ = subtask["id"]
        desc = subtask["description"]
        if subtask.get("type") == "symbolic":
            # Wolfram query
            query_str = f"Solve or compute: {desc}"  # NLP query crafting
            res = wolfram_client.query(query_str)
            try:
                # Parse primary pod
                primary_pod = next(p for p in res.pods if p["@title"] == "Result" or p["@title"] == "Approximate form")
                plaintext = primary_pod["subpod"]["plaintext"]
                img = primary_pod["subpod"]["img"]["@src"] if "img" in primary_pod["subpod"] else ""
                return {
                    "subtask": id_, "result": plaintext, "symbolic_proof": str(res), "confidence": 1.0,
                    "plot": img, "source": "Wolfram Alpha"
                }
            except StopIteration:
                return {"subtask": id_, "result": "Error: Refine query", "confidence": 0.0}
        else:
            # Fallback to Ex1 simulation
            return self.simulations.get(id_, {"subtask": id_, "result": "Simulated", "confidence": 0.9})

def run_c_suite(query: str) -> str:
    global blackboard
    blackboard = {"query": query, "history": [], "subtasks": [], "results": {}}
    
    manager = ManagerAgent()
    worker = WorkerAgent()
    subtasks = manager.decompose(query)
    blackboard["subtasks"] = subtasks
    blackboard["history"].append(f"Decomposed: {len(subtasks)} subtasks")
    
    # Loop with 3 retries on symbolic failure
    for attempt in range(3):
        pending = [s for s in subtasks if s["id"] not in blackboard["results"]]
        if not pending:
            break
        for subtask in pending:
            result = worker.execute(subtask)
            if result["confidence"] < 0.5:
                # Manager refines
                refine_prompt = f"Refine ambiguous query: {subtask['description']} for Wolfram. Add units/details."
                refined_desc = llm.invoke([HumanMessage(content=refine_prompt)]).content
                subtask["description"] = refined_desc
                result = worker.execute(subtask)  # Retry
            blackboard["results"][subtask["id"]] = result
            blackboard["history"].append(json.dumps(result))
    
    # Markdown report with plots
    report = "# C-Suite Report\n\n**Query:** " + query + "\n\n"
    for id_, res in blackboard["results"].items():
        subtask = next(s for s in blackboard["subtasks"] if s["id"] == id_)
        report += f"## Subtask {id_}\n- **Result:** {res['result']}\n"
        if "plot" in res:
            report += f"![Plot]({res['plot']})\n"
        report += f"- **Proof:** {res.get('symbolic_proof', 'N/A')[:100]}...\n- **Conf:** {res['confidence']}\n\n"
    return report

# Test math queries
if __name__ == "__main__":
    queries = [
        "Optimize P(x) = -x² + 100x - 500, breakeven ±10%",
        "Eigenvalues [[1,2],[3,4]]",
        "Integrate sin(x)/x 0 to inf"
    ]
    for q in queries:
        print(run_c_suite(q))
        print("---")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import os
import json
import time
import streamlit as st  # pip install streamlit
import plotly.graph_objects as go
from typing import Dict, List
# Imports from prior: langchain_google_genai, wolframalpha, ibm_watson, etc.
# Stub agents; extend Ex3 with factory

# Global cache (sim Redis)
@st.cache_data(ttl=3600)
def cached_query(key: str):
    pass  # pickle logic

class WorkerFactory:
    @staticmethod
    def create_worker(worker_type: str):
        if worker_type == "wolfram":
            return SymbolicWorker()  # Ex3
        elif worker_type == "watson":
            return FactualWorker()
        elif worker_type == "python":
            class PythonWorker:
                def execute(self, subtask): return {"result": "Python sim", "confidence": 0.95}
            return PythonWorker()
        return None

# Modified run_c_suite with swarm spawning, traces
def run_swarm(query: str, max_agents: int = 10):
    st.session_state.traces = [] if "traces" not in st.session_state else st.session_state.traces
    start_time = time.time()
    
    manager = ManagerAgent()  # Ex3
    subtasks = manager.decompose(query, st.session_state.get("history", ""))
    
    results = {}
    for subtask in subtasks[:max_agents]:  # Dynamic spawn
        worker_type = subtask.get("type", "python")
        worker = WorkerFactory.create_worker(worker_type)
        if worker:
            trace = f"Spawned {worker_type} for {subtask['id']}"
            st.session_state.traces.append(trace)
            st.rerun()  # Real-time update
            results[subtask["id"]] = worker.execute(subtask)
    
    reviewer = ReviewerAgent()
    review = reviewer.review(results)
    
    # Metrics
    latency = time.time() - start_time
    hall_score = 1 - review["overall_score"]  # Simulated
    st.session_state.metrics = {"latency": latency, "hall_score": hall_score, "agents": len(subtasks)}
    
    # User vote
    col1, col2 = st.columns(2)
    with col1:
        if st.button("Approve") and review["overall_score"] < 0.85:
            review["approved"] = True
    with col2:
        if st.button("Reject & Re-orchestrate"):
            return run_swarm(query)  # Loop
    
    st.session_state.history = st.session_state.get("history", []) + [{"query": query}]
    return results, review

# Streamlit UI
st.title("AI C-Suite Swarm Dashboard")
query = st.text_input("Epic Query:", placeholder="Business plan for quantum startup...")
if st.button("Launch Swarm", type="primary"):
    with st.spinner("Orchestrating..."):
        results, review = run_swarm(query)
    
    # Real-time traces (poll-like via rerun)
    st.subheader("Agent Traces")
    for trace in st.session_state.traces[-10:]:
        st.write(trace)
    
    # Report
    st.markdown("# Report")
    for r in results.values():
        st.write(f"- {r['result']} (Conf: {r['confidence']}, {r['source']})")
    st.metric("Score", f"{review['overall_score']:.2f}", delta="Approved" if review['approved'] else "Refine")
    
    # Metrics plot
    fig = go.Figure([go.Bar(x=["Latency", "Hall Score", "Agents"], y=[st.session_state.metrics["latency"], st.session_state.metrics["hall_score"], st.session_state.metrics["agents"]])])
    st.plotly_chart(fig)
    
    # Extras: Voice (placeholder), PDF (st.download_button)
    st.download_button("Export PDF", "Report content...", mime="application/pdf")

# Deploy: streamlit run app.py --server.port 8501
# GitHub README: Forked Ex3, added factory/swarm, UI votes trigger rerun, latency<60s via cache.

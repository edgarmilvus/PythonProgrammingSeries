
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
import json
from typing import List, Dict, Any
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import ChatPromptTemplate
from langchain.schema import HumanMessage
import wolframalpha
from ibm_watson import NaturalLanguageUnderstandingV1  # pip install ibm-watson
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator

# Env: GEMINI_API_KEY, WOLFRAM_APPID, WATSON_APIKEY, WATSON_URL
llm = ChatGoogleGenerativeAI(model="gemini-1.5-pro", temperature=0)
wolfram_client = wolframalpha.Client(os.getenv("WOLFRAM_APPID"))
authenticator = IAMAuthenticator(os.getenv("WATSON_APIKEY"))
nlu = NaturalLanguageUnderstandingV1(version='2022-04-07', authenticator=authenticator)
nlu.set_service_url(os.getenv("WATSON_URL"))

blackboard: Dict[str, Any] = {"conversation_history": []}

class ManagerAgent:
    def __init__(self):
        self.prompt = ChatPromptTemplate.from_template("""
CEO: Decompose into subtasks with type: "symbolic", "factual", "hybrid".
JSON list only. History: {history}
Query: {query}
        """)

    def decompose(self, query: str, history: str = "") -> List[Dict[str, str]]:
        msg = self.prompt.format(query=query, history=history)
        resp = llm.invoke([HumanMessage(content=msg)])
        try:
            return json.loads(resp.content)
        except:
            return []

class SymbolicWorker:
    def execute(self, subtask: Dict) -> Dict:
        # From Ex2 Wolfram code
        query_str = subtask["description"]
        res = wolfram_client.query(query_str)
        try:
            primary = next(p for p in res.pods)
            return {"result": primary["subpod"]["plaintext"], "confidence": 1.0, "source": "Wolfram", "type": "symbolic"}
        except:
            return {"result": "Error", "confidence": 0.0}

class FactualWorker:
    def execute(self, subtask: Dict) -> Dict:
        text = subtask["description"]
        response = nlu.analyze(text=text, features={'entities': {}, 'relations': {}}).get_result()
        entities = [e['text'] for e in response.get('entities', [])]
        return {"result": json.dumps(entities), "confidence": 0.95, "source": "IBM Watson NLU", "links": ["watson.ibm.com"], "type": "factual"}

class ReviewerAgent:
    def __init__(self):
        self.prompt = ChatPromptTemplate.from_template("""
Review Worker results: {results}
Score consistency (0-1), list issues, approve if >=0.85. Output JSON: {{"overall_score": float, "issues": list, "approved": bool}}
Cross-check sources, flag contradictions.
        """)

    def review(self, results: Dict) -> Dict:
        msg = self.prompt.format(results=json.dumps(results))
        resp = llm.invoke([HumanMessage(content=msg)])
        try:
            return json.loads(resp.content)
        except:
            return {"overall_score": 0.0, "approved": False}

def run_c_suite(query: str, max_cycles: int = 3) -> str:
    global blackboard
    blackboard["query"] = query
    blackboard["history"] = blackboard.get("conversation_history", [])
    
    manager = ManagerAgent()
    symbolic_worker = SymbolicWorker()
    factual_worker = FactualWorker()
    reviewer = ReviewerAgent()
    
    cycle = 0
    while cycle < max_cycles:
        subtasks = manager.decompose(query, json.dumps(blackboard["history"]))
        blackboard["subtasks"] = subtasks
        
        # Parallel delegation (simulated concurrent)
        results = {}
        for subtask in subtasks:
            if subtask["type"] == "symbolic":
                results[subtask["id"]] = symbolic_worker.execute(subtask)
            elif subtask["type"] == "factual":
                results[subtask["id"]] = factual_worker.execute(subtask)
            else:
                results[subtask["id"]] = {"result": "Hybrid", "confidence": 0.9}
        
        # Review
        review = reviewer.review(results)
        blackboard["history"].append({"cycle": cycle, "results": results, "review": review})
        
        if review["approved"] and review["overall_score"] >= 0.85:
            break
        cycle += 1  # Refine loop
    
    blackboard["conversation_history"] = blackboard["history"]  # Persist memory
    
    # Report
    report = "# C-Suite Report\n**Query:** " + query + "\n"
    for id_, res in results.items():
        report += f"\n## Subtask {id_}\n- {res['result']}\n- Source: {res['source']}\n"
    report += f"\n**Final Score:** {review['overall_score']} | Approved: {review['approved']}\n"
    return report

# Test
if __name__ == "__main__":
    queries = [
        "Geopolitical risks for rare earth minerals investment",
        "Medical trial analysis for new drug",
        "Legal compliance for AI regulations",
        "Climate modeling impacts"
    ]
    for q in queries:
        print(run_c_suite(q))
        print("---")

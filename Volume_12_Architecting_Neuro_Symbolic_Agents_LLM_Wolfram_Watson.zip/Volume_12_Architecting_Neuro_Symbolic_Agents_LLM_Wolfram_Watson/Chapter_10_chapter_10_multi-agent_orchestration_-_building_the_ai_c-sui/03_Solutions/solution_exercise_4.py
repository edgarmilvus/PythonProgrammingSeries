
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
import json
from flask import Flask, request, session, jsonify, render_template_string
from flask_session import Session  # pip install flask-session
from werkzeug.exceptions import Unauthorized
import gunicorn  # For deployment note

# Import from Ex3: assume agents in agents.py
# For brevity, stubbed here; copy Manager, Workers, Reviewer, run_c_suite from Ex3
from agents import run_c_suite  # Hypothetical import

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "devkey")
app.config["SESSION_TYPE"] = "filesystem"  # Or redis:// for prod
Session(app)

API_KEY = os.getenv("C_SUITE_API_KEY", "testkey")

HTML_DASHBOARD = """
<!DOCTYPE html>
<html><body>
<h1>AI C-Suite Dashboard</h1>
<form method="POST" action="/orchestrate">
  <input name="query" placeholder="Enter query"><button>Orchestrate</button>
</form>
<pre id="report">{{ report }}</pre>
</body></html>
"""

@app.route("/", methods=["GET"])
def dashboard():
    return render_template_string(HTML_DASHBOARD, report=session.get("last_report", ""))

@app.route("/orchestrate", methods=["POST"])
def orchestrate():
    if request.headers.get("X-API-Key") != API_KEY:
        raise Unauthorized("Invalid API key")
    
    query = request.json.get("query") or request.form["query"]
    if not query:
        return jsonify({"error": "No query"}), 400
    
    # Session memory
    history = session.get("conversation_history", [])
    full_query = f"{json.dumps(history[-3:] if history else [])} ||| {query}"  # Last 3 for context
    
    try:
        report = run_c_suite(full_query)  # From Ex3, uses blackboard but session overrides
        session["last_report"] = report
        session["conversation_history"] = session.get("conversation_history", []) + [{"query": query, "report_snip": report[:200]}]
        session.modified = True  # Expire after 30min implicit via filesystem
        
        return jsonify({"report": report, "session_len": len(session["conversation_history"])})
    except Exception as e:
        app.logger.error(f"Error: {e}", exc_info=True)
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
# Deploy: gunicorn -w 4 -b 0.0.0.0:5000 app:app
# Logs: gunicorn --log-level debug

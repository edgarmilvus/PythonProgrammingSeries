
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import asyncio  # Enables asynchronous programming for concurrent agent execution

# Mock neuro-symbolic tools for near-zero hallucinations
def wolfram_alpha(query: str) -> str:
    # Simulates Wolfram Alpha: precise symbolic computation
    if "square 1 2 3" in query:
        return "1**2 + 2**2 + 3**2 = 1 + 4 + 9 = 14"
    return f"Wolfram result for {query}"

def ibm_watson(query: str) -> str:
    # Simulates IBM Watson: knowledge retrieval and verification
    if "14" in query or "1 4 9" in query:
        return "Confirmed: Sum of squares is 14."
    return "Unverified knowledge."

# Agent class: Core building block for C-Suite roles with LLM Memory
class Agent:
    def __init__(self, name: str, role: str):
        self.name = name
        self.role = role
        self.memory = {}  # LLM Memory: dict for state persistence across messages

    async def act(self, message: str) -> str:
        # Message processing: simulates LLM inference with role-specific logic
        self.memory['last_input'] = message  # Update LLM Memory
        await asyncio.sleep(0.1)  # Simulate LLM/tool latency
        if self.role == "manager":
            return self._decompose(message)
        elif self.role == "worker":
            return self._execute(message)
        elif self.role == "reviewer":
            return self._review(message)
        return "Error: Unknown role"

    def _decompose(self, task: str) -> tuple[str, str]:
        # Task decomposition: breaks into subtasks, packs as tuple
        sub1 = "wolfram: square 1 2 3"  # Symbolic computation subtask
        sub2 = "python: sum 1 4 9"      # Aggregation subtask
        packed_tuple = (sub1, sub2)     # Tuple packing: groups for delegation
        self.memory['subtasks'] = packed_tuple
        return packed_tuple

    def _execute(self, subtask: str) -> str:
        # Worker execution: routes to neuro-symbolic tool based on subtask
        if "wolfram" in subtask.lower():
            result = wolfram_alpha(subtask)
        else:
            result = ibm_watson(subtask)
        self.memory['my_result'] = result  # Store in LLM Memory
        return result

    def _review(self, combined: str) -> str:
        # Reviewer logic: checks for hallucination-free output
        if "14" in combined:
            self.memory['verdict'] = "APPROVED"
            return "APPROVED: Sum of squares is 14 (zero hallucinations detected)."
        else:
            self.memory['verdict'] = "REJECTED"
            return "REJECTED: Potential error – refine and retry."

# Orchestration: Hierarchical Manager/Worker with concurrent delegation
async def orchestrate_c_suite(initial_task: str):
    # Instantiate C-Suite agents (dynamic role assignment)
    manager = Agent("CEO-Manager", "manager")
    wolfram_worker = Agent("Wolfram-Worker", "worker")
    python_worker = Agent("Python-Worker", "worker")
    reviewer = Agent("QA-Reviewer", "reviewer")

    # Manager loop step 1: Decompose initial task
    print(f"CEO: Processing '{initial_task}'")
    subtasks = await manager.act(initial_task)  # Returns tuple from decompose

    # Tuple unpacking: Assign packed subtasks to specific workers
    wolfram_subtask, python_subtask = subtasks  # Unpacks tuple to variables
    print(f"CEO: Delegated '{wolfram_subtask}' to Wolfram Worker")
    print(f"CEO: Delegated '{python_subtask}' to Python Worker")

    # Manager loop step 2: Concurrent swarm execution via TaskGroup
    async with asyncio.TaskGroup() as tg:  # Ensures all-or-nothing completion
        # Spawn worker tasks concurrently (multi-agent parallelism)
        wolfram_t = tg.create_task(wolfram_worker.act(wolfram_subtask))
        python_t = tg.create_task(python_worker.act(python_subtask))

    # Post-TaskGroup: Safely retrieve results (tasks are guaranteed complete)
    wolfram_result = wolfram_t.result()   # Access completed task result
    python_result = python_t.result()     # Tuple-like access pattern
    print(f"Wolfram Worker: {wolfram_result}")
    print(f"Python Worker: {python_result}")

    # Manager loop step 3: Aggregate and trigger reviewer (feedback loop entry)
    combined_results = f"{wolfram_result} | {python_result}"
    print(f"CEO: Aggregated results: {combined_results}")
    verdict = await reviewer.act(combined_results)
    print(f"QA Reviewer: {verdict}")

    # Demonstrate inter-agent memory sharing potential
    print("\n--- Agent Memories (LLM Memory Demo) ---")
    print(f"Manager: {manager.memory}")
    print(f"Wolfram Worker: {wolfram_worker.memory}")
    print(f"Reviewer: {reviewer.memory}")

# Entry point: Runs the full C-Suite simulation
async def main():
    demo_task = "Compute sum of squares for 1, 2, 3 using reliable tools."
    await orchestrate_c_suite(demo_task)

if __name__ == "__main__":
    asyncio.run(main())  # Launches the async event loop

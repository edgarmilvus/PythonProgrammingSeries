
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Basic Neuro-Symbolic Verifier: Queries Wolfram Alpha for exact math results.
# Solves LLM hallucination by fetching symbolic computations.
# Fully self-contained: No pip installs required (uses stdlib only).
# Example query: Dirichlet integral to contrast probabilistic Gemini vs symbolic Wolfram.

import urllib.request  # For opening HTTP URLs and sending GET requests.
import urllib.parse    # For URL-encoding query strings to handle special chars like /, ^.
import xml.etree.ElementTree as ET  # For parsing Wolfram's XML response into structured data.

def query_wolfram(query, appid):
    """
    Core function: Builds API URL, fetches XML, parses first plaintext result.
    Handles arithmetic-heavy queries (e.g., integrals) where LLMs falter.
    """
    # Step 1: Prepare URL parameters using a dictionary for clarity.
    # Arithmetic: None here, but comparison operators used implicitly in parsing logic.
    params = {
        'input': query,      # User math query, e.g., "integrate sin(x)/x from 0 to infinity"
        'appid': appid,      # Your free Wolfram AppID string.
        'format': 'plaintext' # Requests plain text results, easier to parse than images.
    }
    
    # Step 2: Construct full API URL.
    # Uses urlencode to safely encode params (e.g., spaces -> %20, / -> %2F).
    base_url = 'http://api.wolframalpha.com/v2/query'
    full_url = base_url + '?' + urllib.parse.urlencode(params)
    
    # Step 3: Send GET request and read response.
    # urllib.request.urlopen handles HTTP, returns file-like object.
    with urllib.request.urlopen(full_url) as response:
        # Decode bytes to string (UTF-8 default).
        xml_content = response.read().decode('utf-8')
    
    # Step 4: Parse XML to find the primary result.
    # Wolfram v2 XML structure: <queryresult><pod><subpod><plaintext>RESULT</plaintext></subpod></pod>...
    root = ET.fromstring(xml_content)
    
    # Logical block: Iterate pods to extract first meaningful plaintext.
    # Comparison: Check if pod has title indicating result (e.g., "Result").
    for pod in root.iter('pod'):
        # Indentation defines nested loop scope.
        for subpod in pod.iter('subpod'):
            plaintexts = subpod.findall('plaintext')  # List of plaintext elements.
            if plaintexts:  # Comparison: if list non-empty (len > 0 implicitly).
                return plaintexts[0].text.strip()  # Return first cleaned result.
    
    # Fallback if no result (e.g., invalid query).
    return "No computable result found. Try rephrasing the query."

# Main execution block: Demonstrates usage with indentation for if/else structure.
# Real-world: Replace hardcoded query with LLM output for verification pipeline.
appid = input("Paste your Wolfram Alpha AppID here: ").strip()  # User input, cleaned.

# Example query where Gemini hallucinates (~1.37 or "oscillates") vs Wolfram's "pi/2".
math_query = "integrate sin(x)/x from 0 to infinity"

# Arithmetic operator demo: Compute query length for logging (uses len, but + for concat).
query_length = len(math_query)
print(f"Querying Wolfram for: '{math_query}' (length: {query_length})")
print("Gemini might say: 'approx 1.37' (hallucination!). Wolfram: exact...")

# Call function, store result.
wolfram_result = query_wolfram(math_query, appid)

# Comparison operator demo: Check result quality.
if wolfram_result and wolfram_result != "No computable result found.":
    print("\n🎉 SYMBOLIC CERTAINTY ACHIEVED!")
    print(f"Exact Wolfram Result: {wolfram_result}")
    # Simple arithmetic confidence score: length as proxy for detail (longer = more precise).
    confidence = len(wolfram_result) / 10.0  # Division for score (0-10 scale).
    print(f"Confidence Score (heuristic): {confidence:.1f}/10")
else:
    print("❌ Error: Check AppID or query.")

# Bonus: Comparison operators in action for verification logic.
llm_guess = "1.37"  # Hypothetical Gemini hallucination.
if wolfram_result == "pi/2":
    print("✅ Verified: LLM guess '{llm_guess}' WRONG. Wolfram RIGHT.")
else:
    print("ℹ️ Result:", wolfram_result)

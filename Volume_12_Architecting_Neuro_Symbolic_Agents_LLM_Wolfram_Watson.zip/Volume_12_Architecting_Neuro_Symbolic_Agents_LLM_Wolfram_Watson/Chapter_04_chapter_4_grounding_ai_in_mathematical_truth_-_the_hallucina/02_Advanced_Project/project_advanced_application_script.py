
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# Substantial Neuro-Symbolic Agent Script: Freelancer Emergency Fund Forecaster
# Integrates Python loops/timedelta for simulation, Wolfram for symbolic verification
# Contrasts LLM hallucination vs. symbolic truth for near-zero error systems

import wolframalpha  # Wolfram Alpha API client
import datetime  # For date arithmetic
from datetime import timedelta  # timedelta for daily increments
import re  # For parsing Wolfram response text

# === CONFIGURATION ===
# Replace with your free Wolfram AppID (from developer.wolframalpha.com)
WOLFRAM_APPID = 'YOUR_APPID_HERE'  # e.g., 'DEMO-1234567890abcdef'
client = wolframalpha.Client(WOLFRAM_APPID)

# Financial parameters (real-world relatable)
INITIAL_BALANCE = 0.0  # Starting emergency fund
DAILY_DEPOSIT = 10.0  # Freelancer's daily savings
ANNUAL_RATE = 0.05  # 5% APY
DAYS = 365  # One year projection
DAILY_RATE = ANNUAL_RATE / 365  # Daily compound rate

# === HELPER FUNCTIONS ===

def simulate_llm_hallucination(query):
    """
    Simulates Gemini-like probabilistic hallucination.
    For geometric sum, it errs by using simple arithmetic mean instead of formula.
    Real Gemini might output: 'Approx $3,900' (ignores compounding exponents).
    """
    if 'sum' in query.lower() or 'compound' in query.lower():
        naive_sum = DAILY_DEPOSIT * DAYS * (1 + ANNUAL_RATE / 2)  # Hallucinated avg rate
        return f"LLM (Gemini-sim) Hallucination: ~${naive_sum:.2f} (probabilistic guess)"
    return "LLM Error: Unable to compute precisely."

def query_wolfram(query, max_pods=3):
    """
    Queries Wolfram Alpha, parses primary result pod for numeric value.
    Handles symbolic output with certainty.
    """
    try:
        res = client.query(query)
        if res.success:
            # Extract main result from first relevant pod
            for pod in res.pods[:max_pods]:
                if pod.title and ('Result' in pod.title or 'Approximate' in pod.title):
                    # Parse numeric value using regex (handles ~1.23e4 or fractions)
                    match = re.search(r'(\d+\.?\d*[eE]?-?\d*)', str(pod.text))
                    if match:
                        return float(match.group(1))
            return None  # No numeric pod found
        else:
            print(f"Wolfram Error: {res.error}")
            return None
    except Exception as e:
        print(f"Query failed: {e}")
        return None

def confidence_score(llm_val, wolfram_val, tolerance=0.01):
    """
    Scores verification: 100% if within tolerance, penalize deviation.
    Grounds LLM in symbolic truth.
    """
    if wolfram_val is None:
        return 0
    diff = abs(llm_val - wolfram_val) / wolfram_val
    return max(0, 100 - (diff / tolerance * 100))

# === CORE SIMULATION LOOP ===
# Uses for loop + timedelta for date-aware daily compounding
print("=== Neuro-Symbolic Emergency Fund Projection ===")
start_date = datetime.date(2024, 1, 1)
balance = INITIAL_BALANCE
balances = []  # Track for analysis
deposit_days = []

print(f"Params: ${DAILY_DEPOSIT}/day @ {ANNUAL_RATE*100}% annual, {DAYS} days from {start_date}")

for i in range(DAYS):
    current_date = start_date + timedelta(days=i)
    deposit_days.append(current_date)
    
    # Daily compounding: deposit first, then apply interest
    balance += DAILY_DEPOSIT
    balance *= (1 + DAILY_RATE)
    
    balances.append(balance)
    if i % 30 == 0:  # Monthly snapshot
        print(f"{current_date}: Balance ${balance:.2f}")

final_balance_numerical = balances[-1]
print(f"\nNumerical Loop Final Balance: ${final_balance_numerical:.2f}")

# === SYMBOLIC VERIFICATION PIPELINE ===
# Decompose complex sum into Wolfram-queryable geometric series
# Closed-form: sum_{k=0}^{364} 10 * (1+r)^k   where r = daily_rate
r_str = f"{DAILY_RATE:.10f}"  # High precision for Wolfram
sum_query = f"sum from k=0 to 364 of 10 * (1 + {r_str})^k"

print(f"\n--- LLM Hallucination Simulation ---")
llm_guess = simulate_llm_hallucination(sum_query)
llm_val = float(re.search(r'\$([\d,]+\.?\d*)', llm_guess).group(1).replace(',', ''))
print(llm_guess)

print(f"\n--- Wolfram Symbolic Verification ---")
print(f"Query: {sum_query}")
wolfram_val = query_wolfram(sum_query)
if wolfram_val:
    print(f"Wolfram Exact: ${wolfram_val:.2f}")
else:
    print("Wolfram query failed—check AppID.")

# Confidence scoring & report
confidence = confidence_score(llm_val, wolfram_val)
print(f"\n--- Neuro-Symbolic Score ---")
print(f"Confidence: {confidence:.1f}% (Symbolic grounds probabilistic guess)")
print(f"Discrepancy: ${abs(llm_val - wolfram_val):.2f}")
if confidence > 90:
    print("✅ Near-Zero Hallucination: Use Wolfram value.")
else:
    print("⚠️  Hallucination Detected: Trust Symbolic!")

# Bonus: Verify daily rate decomposition
rate_query = f"{ANNUAL_RATE} / 365"
wolfram_rate = query_wolfram(rate_query)
print(f"\nDecomposed Check: Daily rate Wolfram=${wolfram_rate:.6f} (matches Python)")

# Output for viz/export
print(f"\nFinal Verified Balance: ${wolfram_val:.2f}")
print("Script complete: Symbolic certainty achieved.")

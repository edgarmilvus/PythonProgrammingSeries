
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
from flask import Flask, request, jsonify, Response, stream_with_context, render_template_string
from flask_cors import CORS
import requests
import xml.etree.ElementTree as ET
import re
import json
import time
import random
from werkzeug.exceptions import BadRequest

app = Flask(__name__)
CORS(app)  # For browser/curl

HTML_FORM = '''
<!DOCTYPE html>
<html><body>
<h1>Neuro-Symbolic Verifier</h1>
<form method="POST" action="/verify" enctype="application/json">
  Query: <input name="query" value="2+2"><br>
  LLM Guess: <input name="llm_guess" value=""><br>
  <button>Verify</button>
</form>
</body></html>
'''

def sanitize_input(query):
    """Security: restrict operators, no shell/exec."""
    allowed = re.match(r'^[\d\s\(\)\+\-\*\/\.^]*$', query)
    if not allowed or len(query) > 200:
        raise ValueError("Invalid input")
    return query

def get_wolfram_result(expr, app_id):
    url = f"https://api.wolframalpha.com/v2/query?appid={app_id}&input={requests.utils.quote(expr)}&format=plaintext"
    resp = requests.get(url)
    root = ET.fromstring(resp.text)
    pods = root.findall('.//pod')
    pt = pods[0].find('subpod/plaintext') if pods else None
    result = pt.text.strip() if pt is not None else "No result"
    plots = [img.get('src') for pod in pods for img in pod.findall('subpod/img') if img.get('src')]
    return result, plots[0] if plots else None

@app.route('/', methods=['GET'])
def demo():
    return HTML_FORM

@app.route('/verify', methods=['POST'])
def verify():
    try:
        data = request.json or request.form.to_dict()
        query = sanitize_input(data.get('query', ''))
        llm_guess = data.get('llm_guess', random.choice(['4', '4.02', 'N/A']))
        app_id = os.getenv('WOLFRAM_APPID')
        if not app_id:
            raise ValueError("WOLFRAM_APPID not set")

        def generate_stream():
            yield f"data: Querying Wolfram for '{query}'...\n\n"
            truth, plot_url = get_wolfram_result(query, app_id)
            conf = 1.0 if llm_guess == truth else (0.5 if abs(float(llm_guess)-float(truth or 0))<1e-6 else 0.0)
            prior = 0.5
            posterior = prior * conf / (prior * conf + (1-prior)*(1-conf))  # Bayes update
            
            report_html = f"""
            <table border=1>
              <tr><th>LLM Guess</th><td>{llm_guess}</td></tr>
              <tr><th>Wolfram Truth</th><td>{truth}</td></tr>
              <tr><th>Confidence (Bayes)</th><td>{posterior:.3f}</td></tr>
              <tr><th>Plot</th><td><img src="{plot_url}" width=300></td></tr>
            </table>
            """
            yield f"data: Verified! Score: {posterior:.3f}\n\n"
            yield f"data: {json.dumps({'truth': truth, 'score': posterior, 'plot_url': plot_url})}\n\n"
            yield f"data: {report_html}\n\n"

        return Response(stream_with_context(generate_stream()), mimetype='text/event-stream',
                        headers={'Cache-Control': 'no-cache', 'Connection': 'keep-alive'})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

if __name__ == "__main__":
    app.run(debug=True)

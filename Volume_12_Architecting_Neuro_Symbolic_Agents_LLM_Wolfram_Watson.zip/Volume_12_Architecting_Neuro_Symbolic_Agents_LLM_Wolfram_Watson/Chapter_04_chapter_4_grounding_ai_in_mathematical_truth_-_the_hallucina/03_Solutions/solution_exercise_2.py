
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os
import requests
import time
import xml.etree.ElementTree as ET
import random
import difflib
import json
import numpy as np
import matplotlib.pyplot as plt
from io import BytesIO
import base64

def get_wolfram_appid():
    app_id = os.getenv('WOLFRAM_APPID')
    if not app_id:
        raise ValueError("Set WOLFRAM_APPID")
    return app_id

def query_wolfram(expr, app_id):
    url = f"https://api.wolframalpha.com/v2/query?appid={app_id}&input={requests.utils.quote(expr)}&format=plaintext"
    response = requests.get(url)
    root = ET.fromstring(response.text)
    pods = root.findall('.//pod')
    
    # Extract first plaintext (primary result), also grab plot URL if available
    plaintext = None
    plot_url = None
    for pod in pods:
        pt = pod.find('subpod/plaintext')
        if pt is not None and pt.text and not plaintext:
            plaintext = pt.text.strip()
        imgs = pod.findall('subpod/img')
        if imgs and not plot_url:
            plot_url = imgs[0].get('src')
    
    return plaintext or "No definitive result", plot_url

def mock_gemini_hallucination():
    """Simulate common LLM errors for Dirichlet integral."""
    options = [
        "1.5708",  # Numeric approx (partial credit)
        "Si(x) + C",  # Indefinite half-right
        "-cos(x)/x + C",  # Wrong antiderivative
        "undefined",  # Fail
        "π/2"  # Rare exact (for demo)
    ]
    return random.choice(options)

def compute_confidence(llm_out, wolf_truth):
    """Scoring: 1.0 exact/symbolic, 0.5 numeric within 1e-6 (parse floats), else difflib partial."""
    if llm_out == wolf_truth:
        return 1.0
    # Numeric check
    llm_num = None
    import re
    m = re.search(r'[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?', llm_out)
    if m:
        try:
            llm_num = float(m.group())
            pi_over_2 = 1.57079632679
            if abs(llm_num - pi_over_2) < 1e-6:
                return 0.5
        except:
            pass
    # Fallback difflib similarity
    sim = difflib.SequenceMatcher(None, llm_out.lower(), wolf_truth.lower()).ratio()
    return max(0.0, sim - 0.5) if sim > 0.5 else 0.0  # Partial credit threshold

def plot_dirichlet():
    """Matplotlib viz of sin(t)/t, annotate integral."""
    t = np.linspace(0.01, 20, 1000)
    f = np.sinc(t / np.pi)  # sin(pi x)/(pi x) normalized, approx sin(t)/t
    fig, ax = plt.subplots()
    ax.plot(t, np.sin(t)/t, label='sin(t)/t')
    ax.fill_between(t, 0, np.sin(t)/t, alpha=0.3, label='∫[0,∞)')
    ax.axhline(0, color='k', lw=0.5)
    ax.text(10, 0.4, '∫₀^∞ = π/2 ≈1.5708', fontsize=12, bbox=dict(boxstyle='round', facecolor='wheat'))
    ax.set_xlabel('t'); ax.set_ylabel('f(t)'); ax.legend(); ax.set_title('Dirichlet Integral')
    buf = BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    img_b64 = base64.b64encode(buf.read()).decode()
    plt.close()
    return f"data:image/png;base64,{img_b64}"

if __name__ == "__main__":
    app_id = get_wolfram_appid()
    
    # Main query
    main_query = "integrate sin(t)/t from 0 to infinity"
    wolf_truth, wolf_plot = query_wolfram(main_query, app_id)
    
    # Decompose: subqueries
    subqueries = {
        "indefinite": "integrate sin(t)/t",
        "numeric_approx": "NIntegrate[Sin[t]/T, {T, 0, Infinity}]",
        "variant": "integrate Sin[x]^2 from 0 to pi"  # π/2 trap
    }
    sub_results = {k: query_wolfram(v, app_id)[0] for k, v in subqueries.items()}
    
    llm_guess = mock_gemini_hallucination()
    confidence = compute_confidence(llm_guess, wolf_truth)
    
    report = {
        "llm_guess": llm_guess,
        "wolfram_main": wolf_truth,
        "wolfram_plot_url": wolf_plot,
        "subqueries": sub_results,
        "confidence": confidence,
        "plot_b64": plot_dirichlet()
    }
    print("Side-by-side Report:")
    print(json.dumps(report, indent=2))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
import asyncio
import aiohttp
import time
import json
import xml.etree.ElementTree as ET
from datetime import datetime
import random

# Mock IBM Watson (replace with real: pip install ibm-watson; set WATSON_URL, APIKEY, PROJECT_ID, COLLECTION_ID)
def mock_watson(query):
    """Mock Discovery: extract entities, corroborate."""
    time.sleep(0.5)  # Simulate latency
    corrob = random.choice([True, False])  # 80% true for demo
    return {
        "entities": ["ODE", "linear", "characteristic r^2 +1=0", "cos(x)" if "y'' + y" in query else "integral"],
        "corroboration": corrob,
        "insights": "Homogeneous solution: A cos x + B sin x"
    }

async def wolfram_async(session, expr, app_id):
    """Async Wolfram query."""
    url = f"https://api.wolframalpha.com/v2/query?appid={app_id}&input={expr}&format=plaintext"
    start = time.time()
    async with session.get(url) as resp:
        text = await resp.text()
        root = ET.fromstring(text)
        pods = root.findall('.//pod')
        pt = pods[0].find('subpod/plaintext') if pods else None
        result = pt.text.strip() if pt is not None else "No result"
        latency = time.time() - start
        print(f"[{datetime.now()}] Wolfram '{expr[:30]}...': {latency:.2f}s -> {result}")
        return result, 1.0 if "cos" in result.lower() else 0.5, latency  # Mock match

async def watson_async(query):
    """Async mock Watson."""
    start = time.time()
    result = mock_watson(query)
    latency = time.time() - start
    print(f"[{datetime.now()}] Watson '{query[:30]}...': {latency:.2f}s -> corrob: {result['corroboration']}")
    return result['corroboration'], latency

def decompose_query(full_query):
    """Rule-based decomposition tree."""
    tree = {
        "root": full_query,
        "children": []
    }
    if "y''" in full_query or "differential" in full_query:
        tree["children"] = [
            "characteristic equation for y'' + y = 0",
            "general solution y'' + y = 0",
            "apply ICs y(0)=1, y'(0)=0"
        ]
    elif "integrate" in full_query:
        tree["children"] = ["indefinite form", "definite bounds", "numeric approx"]
    print("Decomposition Tree:\n" + json.dumps(tree, indent=2))
    return tree["children"]

async def verify_multi_tool(full_query, app_id):
    """Async parallel: decompose -> tools -> weighted score."""
    subtasks = decompose_query(full_query)
    llm_mock = random.choice(["y=sin(x)", "y=cos(x)", "approx 1.57"])  # 0.05 weight low
    
    async with aiohttp.ClientSession() as session:
        tasks = []
        for sub in subtasks:
            w_task = asyncio.create_task(wolfram_async(session, sub, app_id))
            wat_task = asyncio.create_task(watson_async(sub))
            tasks.extend([w_task, wat_task])
        
        results = await asyncio.gather(*tasks)
    
    # Aggregate: avg Wolfram (0.8), Watson corrob (0.15), LLM stub (0.05)
    wolfram_scores = [r[1] for r in results if len(r)==3]  # Wolfram tuple
    wat_corrob = sum(1.0 if isinstance(r, dict) and r['corroboration'] else 0 for r in results) / len(subtasks)
    llm_score = 0.05 if "cos" in llm_mock else 0.0
    score = 0.8 * sum(wolfram_scores)/len(wolfram_scores) + 0.15 * wat_corrob + llm_score
    
    return {
        "llm_mock": llm_mock,
        "score": score,
        "verdict": "Re-query needed" if score < 0.7 else "Verified",
        "subtasks": subtasks
    }

def stream_results(query, app_id):
    """Generator for streaming output."""
    start = time.time()
    yield f"[{datetime.now()}] Decomposing: {query}\n"
    result = asyncio.run(verify_multi_tool(query, app_id))
    yield f"[{datetime.now()}] Final Score: {result['score']:.2f} | Verdict: {result['verdict']}\n"
    yield json.dumps(result, indent=2)
    yield f"Total latency: {time.time() - start:.2f}s\n"

if __name__ == "__main__":
    app_id = os.getenv('WOLFRAM_APPID')
    tests = [
        "Solve y'' + y = 0 with y(0)=1, y'(0)=0",  # cos(x)
        "y'' + 4y = 0, y(0)=0, y'(0)=1",  # sin(2x)
        "integrate sin(x)/x from 0 to infinity"
    ]
    for test in tests:
        print("\n=== Test ===")
        for chunk in stream_results(test, app_id):
            print(chunk, end='')
        print("\n---")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
import requests
import time
import xml.etree.ElementTree as ET
import re
import random
import json
import math

def get_wolfram_appid():
    app_id = os.getenv('WOLFRAM_APPID')
    if not app_id:
        raise ValueError("Set WOLFRAM_APPID environment variable with your Wolfram AppID")
    return app_id

def mock_llm_guess(expr):
    """Simulate Gemini's probabilistic output: parse/eval roughly, add ±1% noise, format as float string."""
    try:
        # Sanitize for safe eval: remove non-arith, handle parens
        safe_expr = re.sub(r'[a-zA-Z\s]+', '', expr)  # Remove letters/whitespace
        safe_expr = safe_expr.replace('^', '**')
        val = eval(safe_expr, {"__builtins__": {}}, {})  # Restricted eval
        if isinstance(val, int):
            val = float(val)
        perturb = val * (1 + random.uniform(-0.01, 0.01))
        return f"{perturb:.10g}"
    except:
        return "N/A (parse error)"

def query_wolfram(expr, app_id):
    """Query Wolfram API v2, parse first plaintext pod, log latency/pods."""
    url = f"https://api.wolframalpha.com/v2/query?appid={app_id}&input={requests.utils.quote(expr)}&format=plaintext"
    start_time = time.time()
    response = requests.get(url)
    latency = time.time() - start_time
    
    root = ET.fromstring(response.text)
    pods = root.findall('.//pod')
    pod_count = len(pods)
    
    plaintexts = []
    for pod in pods:
        pt = pod.find('subpod/plaintext')
        if pt is not None and pt.text:
            plaintexts.append(pt.text.strip())
    
    result = plaintexts[0] if plaintexts else "No result (undefined/error)"
    print(f"Query: {expr} | Latency: {latency:.3f}s | Pods: {pod_count} | Wolfram: {result}")
    return result

def verify_arithmetic(expr, app_id):
    """Core pipeline: mock LLM, query Wolfram, score, verdict."""
    llm_guess = mock_llm_guess(expr)
    wolfram_truth = query_wolfram(expr, app_id)
    
    # String equality for exact match (catches fractions like "1/3")
    confidence = 1.0 if llm_guess == wolfram_truth else 0.0
    verdict = "Verified" if confidence == 1.0 else "Hallucinated"
    
    return {
        "llm_guess": llm_guess,
        "wolfram_truth": wolfram_truth,
        "confidence": confidence,
        "verdict": verdict
    }

if __name__ == "__main__":
    app_id = get_wolfram_appid()
    tests = [
        "2+2",  # Simple
        "123*456",  # Simple multi-digit
        "123456789 * 987654321 + 456789123 / 17 - 31415926",  # Complex chained (note: /17 may not divide evenly)
        "(123456789 * 987654321 + 456789123) / 17 - 31415926",  # Correct complex with parens
        "1/3"  # Fractional (exposes decimal hallucination)
    ]
    for expr in tests:
        result = verify_arithmetic(expr, app_id)
        print(json.dumps(result, indent=2))
        print("---")

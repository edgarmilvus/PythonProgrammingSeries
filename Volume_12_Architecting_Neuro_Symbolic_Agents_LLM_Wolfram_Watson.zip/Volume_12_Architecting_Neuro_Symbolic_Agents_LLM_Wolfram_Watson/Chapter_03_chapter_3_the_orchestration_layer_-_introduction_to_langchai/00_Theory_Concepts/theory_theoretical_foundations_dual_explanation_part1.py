
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: theory_theoretical_foundations_dual_explanation_part1.py
# Description: Theoretical Foundations & Dual Explanation
# ==========================================

# Core imports for orchestration layer
from langchain_openai import ChatOpenAI
from langchain_core.tools import tool
from langchain.agents import create_tool_calling_agent, AgentExecutor
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_community.tools import WolframAlphaTool  # Symbolic engine
from langchain.memory import ConversationBufferMemory  # Stateful persistence
from langchain_community.vectorstores import FAISS  # Retriever example
from langchain_openai import OpenAIEmbeddings
import os

# Set API keys (assume env vars)
os.environ["OPENAI_API_KEY"] = "your-key"
os.environ["WOLFRAM_ALPHA_APPID"] = "your-wolfram-id"

# Define custom tool for IBM Watson (placeholder; use watsonx APIs)
@tool
def watson_query(question: str) -> str:
    """Queries IBM Watson for factual enterprise data."""
    # Integrate via watsonx.api (pseudo)
    return f"Watson: Verified fact on {question}"

# Wolfram tool (symbolic math/physics)
wolfram = WolframAlphaTool()

# LLM as reasoning engine
llm = ChatOpenAI(model="gpt-4o", temperature=0)

# Memory for conversation state
memory = ConversationBufferMemory(return_messages=True, memory_key="chat_history")

# Retriever: Assume pre-built FAISS index from docs
embeddings = OpenAIEmbeddings()
# vectorstore = FAISS.load_local("docs_index")  # From prior RAG setup
# retriever = vectorstore.as_retriever(search_kwargs={"k": 3})

# Prompt template with tool instructions (function calling schema)
prompt = ChatPromptTemplate.from_messages([
    ("system", """You are a neuro-symbolic orchestrator. Use tools for verifiable tasks:
    - Wolfram for math/science.
    - Watson for facts/policies.
    Reason step-by-step, delegate precisely."""),
    ("user", "{input}"),
    MessagesPlaceholder(variable_name="chat_history"),
    MessagesPlaceholder(variable_name="agent_scratchpad"),
])

# Agent: Adaptive router
tools = [wolfram, watson_query]  # Extendable toolset
agent = create_tool_calling_agent(llm, tools, prompt)
agent_executor = AgentExecutor(agent=agent, tools=tools, memory=memory, verbose=True)

# Example invocation: Orchestrates query
response = agent_executor.invoke({"input": "Compute the integral of e^{-x^2} from 0 to infinity, then explain its physics meaning."})
print(response['output'])
# Output: Delegates to Wolfram -> Gaussian integral = sqrt(pi)/2 -> LLM explains quantum probability density.

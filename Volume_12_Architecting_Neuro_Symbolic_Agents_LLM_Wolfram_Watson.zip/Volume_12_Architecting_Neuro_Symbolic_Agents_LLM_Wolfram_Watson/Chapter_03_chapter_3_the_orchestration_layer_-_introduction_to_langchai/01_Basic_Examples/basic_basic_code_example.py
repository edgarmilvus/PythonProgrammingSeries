
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Basic LangChain Function Calling Agent for Neuro-Symbolic Math Solving
# Requirements: pip install langchain langchain-openai sympy
# Set environment: export OPENAI_API_KEY="sk-your-key-here" (required for ChatOpenAI)

import os
# Uncomment and set your API key for production use:
# os.environ["OPENAI_API_KEY"] = "sk-proj-your-actual-key-here"

from langchain_openai import ChatOpenAI
from langchain_core.tools import tool
from sympy import sympify, SympifyError
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain.agents import create_tool_calling_agent, AgentExecutor

# Logical Block 1: Define the symbolic math tool using SymPy for verifiable computation
@tool
def math_solver(expression: str) -> str:
    """
    Accurately solves mathematical expressions using SymPy symbolic engine.
    Handles arithmetic, trig, calculus basics—prevents LLM hallucinations.
    Input: string like 'sqrt(16) + 5 * 2'
    Output: string result, e.g., 'The result is 21.0'
    """
    try:
        # Parse and evaluate safely with SymPy (symbolic, no arbitrary code exec)
        expr = sympify(expression)
        result = float(expr.evalf())  # evalf() for numerical result
        return f"The result is {result}"
    except SympifyError as e:
        return f"Invalid mathematical expression: {str(e)}"
    except Exception as e:
        return f"Computation error: {str(e)}"

# Logical Block 2: Initialize the neural LLM with low temperature for deterministic tool use
llm = ChatOpenAI(
    model="gpt-4o-mini",  # Efficient model supporting function calling natively
    temperature=0.0       # Zero randomness ensures consistent tool invocation
)

# Logical Block 3: Define the orchestration prompt template
# This instructs LLM on role, tool usage, and maintains conversation state
prompt = ChatPromptTemplate.from_messages([
    ("system", """You are a precise math assistant in a neuro-symbolic system.
    For any calculation, ALWAYS use the math_solver tool to delegate to SymPy.
    Do not compute yourself—avoid hallucinations. Respond conversationally after tool use."""),  # Orchestration directive
    ("placeholder", "{chat_history}"),  # Optional: for multi-turn memory (unused here)
    ("user", "{input}"),                # User query entry point
    MessagesPlaceholder(variable_name="agent_scratchpad")  # Critical: accumulates tool calls/responses
])

# Logical Block 4: Bind tools to agent and create executor
tools = [math_solver]  # List of tools available to agent
agent = create_tool_calling_agent(
    llm=llm,
    tools=tools,
    prompt=prompt  # Prompt guides tool selection and reasoning
)
agent_executor = AgentExecutor(
    agent=agent,
    tools=tools,
    verbose=True,     # Prints intermediate steps for debugging orchestration
    handle_parsing_errors=True  # Robust: retries on malformed tool calls
)

# Logical Block 5: Invoke the orchestrated workflow with a real-world query
query = "Calculate sqrt(16) + 5 * 2. Explain the steps briefly."
result = agent_executor.invoke({"input": query})

# Logical Block 6: Output the final verifiable response
print("Final Output:", result["output"])

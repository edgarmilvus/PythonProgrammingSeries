
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

#!/usr/bin/env python3
# Advanced Neuro-Symbolic Financial Support Agent using LangChain Orchestration Layer
# Integrates OpenAI LLM, IBM Watson NLU (entity extraction), Wolfram Alpha (computations)
# Minimizes hallucinations by routing numerical tasks to symbolic tools via function calling.

import os
import sys
from dotenv import load_dotenv  # Loads .env file for API keys (optional but recommended)

load_dotenv()  # Load environment variables from .env

# Logical Block 1: Environment Validation and Setup
# Ensures all required API keys are present; exits gracefully if missing.
# Uses os.getenv() for secure key retrieval and sys.exit() for termination.
required_env_vars = [
    'OPENAI_API_KEY',
    'WOLFRAM_APPID',
    'IBM_API_KEY',
    'IBM_NLU_URL',
    'IBM_NLU_VERSION'
]
missing_vars = [var for var in required_env_vars if not os.getenv(var)]
if missing_vars:
    print(f"Error: Missing environment variables: {', '.join(missing_vars)}")
    print("Please set them in a .env file or export directly.")
    sys.exit(1)  # Terminate with error status (non-zero)

current_dir = os.getcwd()  # Get current working directory for potential logging
print(f"Agent initialized in {current_dir}. Ready for financial queries.")

# Logical Block 2: Library Imports for Neuro-Symbolic Components
# LangChain for orchestration (agents, tools, memory); external SDKs for symbolic engines.
import wolframalpha
from wolframalpha.client import Client
from ibm_watson import NaturalLanguageUnderstandingV1
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
from langchain_openai import ChatOpenAI
from langchain_core.tools import tool
from langchain.agents import create_tool_calling_agent, AgentExecutor
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain.memory import ConversationBufferMemory

# Logical Block 3: Initialize Symbolic Engine Clients
# Prepares persistent clients for Watson NLU and Wolfram Alpha to avoid reinstantiation overhead.
wolfram_client = Client(os.getenv('WOLFRAM_APPID'))  # Wolfram Alpha client for computations

nlu_authenticator = IAMAuthenticator(os.getenv('IBM_API_KEY'))
nlu_client = NaturalLanguageUnderstandingV1(
    version=os.getenv('IBM_NLU_VERSION'),
    authenticator=nlu_authenticator
)
nlu_client.set_service_url(os.getenv('IBM_NLU_URL'))  # Set instance-specific URL

# Logical Block 4: Define Custom LangChain Tools with Function Calling
# Uses @tool decorator for seamless LLM integration. Each tool handles one symbolic task.
@tool
def extract_financial_entities(text: str) -> str:
    """
    Extracts financial entities (e.g., money:$15000, percent:4.75, quantity:48 months) 
    from customer queries using IBM Watson NLU. Ideal for parsing unstructured input.
    """
    features = {
        'entities': {
            'model': 'en-news'  # Pre-trained model for English news/financial text
        },
        'keywords': {}  # Optional: top keywords for context
    }
    try:
        response = nlu_client.analyze(text, features=features).get_result()
        entities = response.get('entities', [])
        formatted_entities = [
            f"{entity['text']}:{entity['type']}" 
            for entity in entities[:10]  # Limit to top 10 for brevity
        ]
        return f"Extracted: {', '.join(formatted_entities)}"
    except Exception as e:
        return f"NLU Error: {str(e)}"

@tool
def compute_with_wolfram(query: str) -> str:
    """
    Performs precise computations (e.g., compound interest, loan amortization) 
    using Wolfram Alpha. Input should be a math expression derived from entities.
    """
    try:
        res = wolfram_client.query(query)
        # Parse primary result; Wolfram returns pods, take first meaningful text
        for pod in res.pods:
            if pod.text:
                return pod.text
        return "No computable result found."
    except StopIteration:
        return "Wolfram query failed: No results."
    except Exception as e:
        return f"Wolfram Error: {str(e)}"

# Bind tools list for agent
tools = [extract_financial_entities, compute_with_wolfram]

# Logical Block 5: LLM and Prompt Setup for Orchestration
# Low-temperature LLM for determinism; system prompt enforces tool use for accuracy.
llm = ChatOpenAI(
    model="gpt-4o-mini", 
    temperature=0.0,  # Deterministic for zero-hallucination reasoning
    api_key=os.getenv('OPENAI_API_KEY')
)

system_prompt = """
You are an expert financial support agent for a bank. 
- ALWAYS use 'extract_financial_entities' FIRST on user input to identify amounts, rates, durations.
- Then, construct a precise Wolfram query (e.g., 'compound interest 15000 at 4.75% annual over 48 months') 
  and use 'compute_with_wolfram'.
- Synthesize results into a clear, verifiable explanation. NEVER guess numbers—cite tool outputs.
- For follow-ups, reference chat history.
"""
prompt = ChatPromptTemplate.from_messages([
    ("system", system_prompt),
    ("placeholder", "{chat_history}"),  # Memory integration
    ("human", "{input}"),
    MessagesPlaceholder(variable_name="agent_scratchpad"),  # For tool calls and observations
])

# Logical Block 6: Agent Creation with Function Calling and Memory
# Uses create_tool_calling_agent for modern OpenAI function calling (structured tool outputs).
# ConversationBufferMemory persists context across turns.
agent = create_tool_calling_agent(llm, tools, prompt)
memory = ConversationBufferMemory(
    memory_key="chat_history", 
    return_messages=True,
    memory_file=os.path.join(current_dir, "chat_history.json")  # Persist to file in cwd
)
agent_executor = AgentExecutor(
    agent=agent, 
    tools=tools, 
    memory=memory,
    verbose=True,  # Logs tool calls for debugging
    handle_parsing_errors=True,  # Robust to LLM output parsing issues
    max_iterations=5  # Prevent infinite loops
)

# Logical Block 7: Interactive Conversation Loop
# Runs agent in a REPL-style loop, handling multi-turn dialogues with memory.
print("\n=== Neuro-Symbolic Financial Support Agent ===")
print("Example: 'Calculate interest on $10k loan at 5% for 3 years'")
print("Type 'quit' or 'clear' to exit/reset.\n")

while True:
    user_input = input("Customer: ").strip()
    if user_input.lower() in ['quit', 'exit']:
        print("Session ended. History saved.")
        sys.exit(0)  # Successful termination
    if user_input.lower() == 'clear':
        memory.clear()
        print("History cleared.")
        continue
    
    try:
        # Invoke agent: LangChain orchestrates LLM -> tool calls -> synthesis
        result = agent_executor.invoke({"input": user_input})
        print(f"Agent: {result['output']}\n")
    except Exception as e:
        print(f"Orchestration Error: {str(e)}. Try rephrasing.\n")

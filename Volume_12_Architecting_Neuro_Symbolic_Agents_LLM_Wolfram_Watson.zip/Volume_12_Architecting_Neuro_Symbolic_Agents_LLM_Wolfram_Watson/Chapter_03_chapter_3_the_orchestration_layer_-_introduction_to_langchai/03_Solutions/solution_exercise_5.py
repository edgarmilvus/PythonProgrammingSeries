
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# Full deployable: pip install flask flask-limiter flask-cors redis aioredis pytest-mock matplotlib langchain[all]
# Assume prior agent/tools combined into NeuroSymbolicOrchestrator = StatefulNeuroAgent + routing
import os
import json
from datetime import datetime
from flask import Flask, Blueprint, request, jsonify, Response, stream_with_context
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_cors import CORS
from werkzeug.exceptions import BadRequest
import redis
import aioredis
from unittest.mock import patch
# Imports for agent/tools from Ex1-4 (wolfram, watson, etc.)

class NeuroSymbolicOrchestrator(StatefulNeuroAgent):  # Synthesized advanced class
    # ... (full impl from Ex1-4: tools, memory, retriever, routing)
    def to_api_toolkit(self):
        return {"tools": [t.name for t in self.tools], "version": "1.0"}

app_factory_orchestrator = NeuroSymbolicOrchestrator()  # Global or init in factory

# Config
os.environ["LANGCHAIN_TRACING_V2"] = "true"  # For traces

class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev")
    REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")
    API_KEY = os.getenv("X_API_KEY", "testkey")

class DevConfig(Config): pass
class ProdConfig(Config): SECRET_KEY = os.getenv("SECRET_KEY")

def create_app(config_name: str = "dev") -> Flask:
    app = Flask(__name__)
    app.config.from_object(f"{__name__}.{config_name.title()}Config")
    
    # Limiter
    limiter = Limiter(key_func=get_remote_address, app=app, default_limits=["100 per hour"])
    
    # CORS
    CORS(app)
    
    # Redis async
    app.redis = aioredis.from_url(app.config["REDIS_URL"], decode_responses=True)
    
    # Blueprint
    bp = Blueprint("api", __name__)
    
    @bp.route("/health", methods=["GET"])
    def health():
        return jsonify({"status": "ok", "tools": app_factory_orchestrator.to_api_toolkit()})
    
    @bp.route("/tools", methods=["GET"])
    def tools():
        return jsonify(app_factory_orchestrator.to_api_toolkit())
    
    @bp.before_request
    def before_request():
        api_key = request.headers.get("X-API-Key")
        if api_key != app.config["API_KEY"]:
            raise BadRequest("Invalid API key")
        app.logger.info(f"Query intent: {request.json.get('query', '')[:50]}")
    
    @bp.route("/chat", methods=["POST"])
    @limiter.limit("10/minute")
    def chat():
        data = request.json
        query, session_id = data["query"], data.get("session_id", "default")
        
        def generate():
            # Streaming agent thoughts (simplified SSE)
            for chunk in stream_with_context([f"data: {app_factory_orchestrator.chat(query, session_id)}\n\n"]):
                yield chunk
        
        return Response(generate(), mimetype="text/plain")
    
    @bp.after_request
    def after_request(response):
        if response.content_length and response.content_length > 1024:
            response.direct_passthrough = False  # Gzip via prod proxy
        # Audit: Flag no sources
        if "source" not in response.get_data(as_text=True):
            app.logger.warning("Potential hallucination: no sources")
        # Clean memory if TTL
        return response
    
    @bp.errorhandler(BadRequest)
    def handle_bad(error):
        return jsonify({"error": str(error)}), 400
    
    app.register_blueprint(bp)
    return app

# Monkey patch for tests
def mock_wolfram(query):
    return '{"plaintext": "mock: integral=pi/2"}'

# test_api.py excerpt (pytest)
"""
import pytest
from app import create_app
@patch('wolframalpha.Client.query', side_effect=mock_wolfram)
def test_chat(mock):
    app = create_app()
    with app.test_client() as c:
        rv = c.post("/chat", json={"query": "integral"}, headers={"X-API-Key": "testkey"})
        assert rv.status_code == 200
# 10 cases: auth fail, tool fail, long convos, etc.
"""

# docker-compose.yml
"""
version: '3'
services:
  app:
    build: .
    ports: ["5000:5000"]
    environment:
      - REDIS_URL=redis://redis:6379
  redis:
    image: redis:alpine
"""

# Dockerfile
"""
FROM python:3.12-slim
COPY . /app
WORKDIR /app
RUN pip install -r requirements.txt
CMD ["flask", "--app", "app", "run", "--host=0.0.0.0"]
"""

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# Required installations (run once): pip install langchain langchain-openai wolframalpha python-dotenv langchain-core
import os
import re
import json
from datetime import datetime
from typing import Dict, Any
from dotenv import load_dotenv

load_dotenv()  # Load .env with OPENAI_API_KEY and WOLFRAM_APP_ID

from langchain.tools import BaseTool
from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from wolframalpha import Client

class WolframTool(BaseTool):
    """Custom Wolfram Alpha tool inheriting from BaseTool."""
    name: str = "wolfram_alpha"
    description: str = "Use for precise math, science, physics, unit conversions, and computations to avoid hallucinations."

    def _run(self, query: str) -> str:
        """Execute Wolfram query and return structured result."""
        app_id = os.getenv("WOLFRAM_APP_ID")
        if not app_id:
            return json.dumps({"error": "WOLFRAM_APP_ID not set"})
        client = Client(app_id)
        try:
            res = client.query(query)
            primary_result = ""
            for pod in res.pods:
                if pod.text and not pod.img:  # Prefer plaintext over images
                    primary_result = pod.text
                    break
            confidence = 0.95 if primary_result else 0.5
            return json.dumps({
                "result": primary_result or "No primary result found",
                "source": "Wolfram Alpha",
                "confidence": confidence
            })
        except Exception as e:
            return json.dumps({"error": f"Wolfram API error: {str(e)}"})

def create_wolfram_chain() -> LLMChain:
    """Create the LLM routing chain."""
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    prompt = PromptTemplate.from_template("""
You are a precise router for neuro-symbolic systems. NEVER compute math/science yourself—always delegate to tools to eliminate hallucinations.

Instructions:
- For math, integrals, primes, physics, stats, conversions: Output EXACTLY "TOOL: wolfram_query:<precise_query>" (replace <precise_query> with optimized Wolfram query).
- For explanations/concepts without computation: Respond directly.
- Prioritize tool use for anything verifiable.

Query: {query}
Response:""")
    return LLMChain(llm=llm, prompt=prompt)

def parse_tool_call(response: str) -> str | None:
    """Regex parser for tool calls."""
    match = re.search(r"TOOL:\s*wolfram_query:\s*(.+)", response.strip(), re.DOTALL)
    return match.group(1).strip() if match else None

def run_wolfram_chain(query: str) -> str:
    """Main callable: Orchestrates chain with up to 3 iterations, logging to JSONL."""
    chain = create_wolfram_chain()
    tool = WolframTool()
    log: Dict[str, Any] = {
        "timestamp": datetime.now().isoformat(),
        "input": query,
        "tool_calls": [],
        "final_output": ""
    }
    
    current_query = query
    for iteration in range(3):
        response = chain.invoke({"query": current_query})["text"]
        tool_query = parse_tool_call(response)
        
        if not tool_query:
            log["final_output"] = response
            break
        
        log["tool_calls"].append({"iteration": iteration, "tool_query": tool_query})
        tool_result = tool._run(tool_query)
        log["tool_calls"][-1]["tool_result"] = json.loads(tool_result)
        
        # Feedback loop: Synthesize with result
        current_query = f"Tool result: {tool_result}\nOriginal query: {query}\nProvide final verifiable answer using the tool result."
    
    # Persist to JSONL for auditing
    with open("wolfram_executions.jsonl", "a") as f:
        f.write(json.dumps(log) + "\n")
    
    return log["final_output"]

# Test with 5 diverse queries (uncomment to run; uses LangSmith callbacks if LANGCHAIN_TRACING_V2=true)
if __name__ == "__main__":
    tests = [
        "Solve the integral of sin(x)^2 from 0 to pi",
        "Compute the prime factors of 123456789",
        "What is the acceleration due to gravity on Mars?",
        "Convert 100 USD to EUR",
        "Explain quantum entanglement briefly."
    ]
    for q in tests:
        print(f"Query: {q}\nResponse: {run_wolfram_chain(q)}\n---")

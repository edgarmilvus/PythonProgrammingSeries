
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Builds on Exercise 1: pip install langchain langchain-openai wolframalpha ibm-watson python-dotenv langchain-community langchain-agents
import os
import json
from typing import List, Dict, Any
from dotenv import load_dotenv

load_dotenv()  # OPENAI_API_KEY, WOLFRAM_APP_ID, IBM_WATSON_APIKEY, IBM_WATSON_URL, IBM_WATSON_COLLECTION_ID

from langchain.agents import create_react_agent, AgentExecutor
from langchain.memory import ConversationBufferMemory
from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate, MessagesPlaceholder
from langchain.tools import tool
from wolframalpha import Client
from ibm_watson import DiscoveryV2
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator

# Reuse/Extend WolframTool from Ex1 (simplified as @tool for agent compatibility)
@tool
def wolfram_alpha(query: str) -> str:
    """Wolfram for math/science/compute."""
    app_id = os.getenv("WOLFRAM_APP_ID")
    client = Client(app_id)
    try:
        res = client.query(query)
        for pod in res.pods:
            if pod.text:
                return f"Wolfram: {pod.text} (confidence: 0.95)"
        return "Wolfram: No clear result."
    except Exception as e:
        return f"Wolfram error: {str(e)}"

class WatsonDiscoveryTool:
    """Custom Watson tool."""
    def __init__(self):
        authenticator = IAMAuthenticator(os.getenv("IBM_WATSON_APIKEY"))
        self.discovery = DiscoveryV2("2023-06-22", authenticator=authenticator)
        self.discovery.set_service_url(os.getenv("IBM_WATSON_URL"))
        self.collection_id = os.getenv("IBM_WATSON_COLLECTION_ID")  # User creates collection w/ economic data

    def run(self, query: str, date_range: str = None) -> str:
        try:
            filter_ = f"date>='{date_range}'" if date_range else None
            results = self.discovery.query(
                project_id="your_project_id",  # Replace with actual
                collection_ids=[self.collection_id],
                query=query,
                count=3,
                filter=filter_
            ).get_result()
            facts = [r["text"] for r in results.get("results", [])]
            sources = [r.get("url", "N/A") for r in results.get("results", [])]
            return json.dumps({"facts": facts, "sources": sources})
        except Exception as e:
            return json.dumps({"error": str(e)})

watson_tool = WatsonDiscoveryTool()
@tool
def ibm_watson(query: str, date_range: str = None) -> str:
    """Watson for factual search (e.g., economics data)."""
    return watson_tool.run(query, date_range)

class NeuroSymbolicAgent:
    """Modular ReAct agent with add_tool support."""
    def __init__(self):
        self.llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
        self.tools = [wolfram_alpha, ibm_watson]
        self.memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
        prompt = PromptTemplate.from_template("""
Answer using ReAct: Think step-by-step, ALWAYS use tools for facts/compute (Wolfram=math/stats, Watson=search/data).
Stop only when verifiable with sources. No hallucinations.

{tools}

{agent_scratchpad}

Question: {input}
{agent_scratchpad}
""") + MessagesPlaceholder(variable_name="chat_history")
        self.agent = create_react_agent(self.llm, self.tools, prompt)
        self.executor = AgentExecutor(
            agent=self.agent, tools=self.tools, memory=self.memory,
            max_iterations=5, early_stopping_method="generate", verbose=True
        )

    def add_tool(self, tool):
        self.tools.append(tool)
        # Re-init agent (simplified; prod: dynamic bind_tools)

    def chat(self, query: str, history: List = None) -> str:
        """Multi-turn chat."""
        if history:
            for h in history:
                self.memory.chat_memory.add_user_message(h["user"])
                self.memory.chat_memory.add_ai_message(h["ai"])
        result = self.executor.invoke({"input": query})
        # Export trace to Markdown
        with open(f"agent_trace_{datetime.now().isoformat()}.md", "w") as f:
            f.write(f"## Trace for: {query}\n\n" + result["output"])
        if "error" in result.get("output", "").lower():
            return '{"hallucination_risk": "high", "output": "Uncertain due to tool failure"}'
        return result["output"]

# Testing suite
if __name__ == "__main__":
    agent = NeuroSymbolicAgent()
    tests = [
        "Compare GDP growth US/China 2010-2023, project exponential regression.",
        "Integral of e^x from 0 to 1.",
        "US GDP 2022 sources.",
        "Query with failure: Invalid Watson collection.",  # Simulates quota/error
        "Invent GDP data.",  # Adversarial: should refuse/use tools
        "Follow-up: Break down regression."
    ]
    history = []
    for q in tests:
        resp = agent.chat(q, history)
        print(f"Q: {q}\nA: {resp}\n---")
        history.append({"user": q, "ai": resp})

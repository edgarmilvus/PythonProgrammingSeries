
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Builds on Ex2: pip install langchain-community faiss-cpu sentence-transformers
import os
import json
import pickle
from typing import List, Dict
from dotenv import load_dotenv

load_dotenv()

from langchain.memory import ConversationSummaryBufferMemory
from langchain.vectorstores import FAISS
from langchain.embeddings import OpenAIEmbeddings
from langchain.schema import Document
from langchain.agents import create_react_agent, AgentExecutor
from langchain_core.prompts import PromptTemplate, MessagesPlaceholder, RunnablePassthrough
from langchain_openai import ChatOpenAI
from langchain.tools import tool
# Assume wolfram_alpha, ibm_watson from Ex2

# Sample docs for retriever (physics/math/econ snippets)
sample_docs = [
    Document(page_content="Bayes' theorem: P(A|B) = P(B|A)P(A)/P(B)", metadata={"source": "math"}),
    Document(page_content="Newton's 2nd law: F=ma", metadata={"source": "physics"}),
    Document(page_content="GDP = C + I + G + (X-M)", metadata={"source": "econ"}),
    # Add 7 more similar for 10 total...
] * 3  # Duplicate for demo

# RetrieverTool
embeddings = OpenAIEmbeddings()
vectorstore = FAISS.from_documents(sample_docs, embeddings)
retriever = vectorstore.as_retriever(search_kwargs={"k": 3, "score_threshold": 0.8})

@tool
def retriever_tool(query: str) -> str:
    """Retrieve relevant docs (score >0.8)."""
    docs = retriever.get_relevant_documents(query)
    if docs and docs[0].metadata.get("score", 0) > 0.8:  # Simplified score check
        return "\n".join([f"{d.page_content} [{d.metadata['source']}]" for d in docs])
    return "No relevant retrieval."

class StatefulNeuroAgent(NeuroSymbolicAgent):  # Inherit from Ex2
    def __init__(self):
        super().__init__()
        self.memory = ConversationSummaryBufferMemory(
            llm=self.llm, max_token_limit=500, memory_key="chat_history", return_messages=True
        )
        self.tools.append(retriever_tool)  # Add retriever
        # Hybrid prompt: Prefix with retrieval + memory
        self.prompt = PromptTemplate.from_template("""
Context from retriever/memory: {context}
History summary: {chat_history}

Use tools if needed post-retrieval. If retrieval score>0.8 & sufficient, answer directly w/sources.
Else route to Wolfram/Watson.

{tools}
{agent_scratchpad}
Question: {input}
""") + MessagesPlaceholder(variable_name="chat_history")
        self.agent = create_react_agent(self.llm, self.tools, self.prompt)
        self.executor = AgentExecutor(
            agent=self.agent, tools=self.tools, memory=self.memory, verbose=True,
            max_iterations=5, handle_parsing_errors=True
        )
        self.sessions = {}  # In-mem; prod: Redis/SQL

    def load_session(self, session_id: str):
        """Load pickled session."""
        try:
            with open(f"session_{session_id}.pkl", "rb") as f:
                data = pickle.load(f)
                self.memory.chat_memory = data["memory"]
                self.sessions[session_id] = data
        except FileNotFoundError:
            self.sessions[session_id] = {"memory": self.memory.chat_memory}

    def save_session(self, session_id: str):
        """Save session."""
        self.sessions[session_id]["memory"] = self.memory.chat_memory
        with open(f"session_{session_id}.pkl", "wb") as f:
            pickle.dump(self.sessions[session_id], f)
        # Anonymize PII: summaries already abstracted

    def chat(self, query: str, session_id: str = None, history: List = None) -> Dict:
        """Enhanced chat with retrieval prefix."""
        if session_id:
            self.load_session(session_id)
        if history:
            for h in history:  # Load history
                self.memory.save_context({"input": h["user"]}, {"output": h["ai"]})
        
        # Prefix with retrieval
        context = retriever_tool.invoke(query)
        result = self.executor.invoke({
            "input": query,
            "context": context,
            "chat_history": self.memory.load_memory_variables({})
        })
        
        metrics = {
            "token_usage": len(query) * 2,  # Approx
            "tool_calls": len(result.get("intermediate_steps", [])),
            "hallucination_score": 0.1 if "source" in result["output"] else 0.8  # Cite % proxy
        }
        if session_id:
            self.save_session(session_id)
        
        return {"output": result["output"], "metrics": metrics}

# 4-turn convo test
if __name__ == "__main__":
    agent = StatefulNeuroAgent()
    session_id = "test1"
    turns = [
        "Fetch weather NYC last week via Watson, forecast trends Wolfram, compare historical.",
        "Recall last computation and double it.",
        "Refine forecast with Bayes.",
        "Hypothesize climate impact."
    ]
    history = []
    for q in turns:
        resp = agent.chat(q, session_id, history)
        print(f"Q: {q}\nA: {resp['output']}\nMetrics: {resp['metrics']}\n---")
        history.append({"user": q, "ai": resp["output"]})

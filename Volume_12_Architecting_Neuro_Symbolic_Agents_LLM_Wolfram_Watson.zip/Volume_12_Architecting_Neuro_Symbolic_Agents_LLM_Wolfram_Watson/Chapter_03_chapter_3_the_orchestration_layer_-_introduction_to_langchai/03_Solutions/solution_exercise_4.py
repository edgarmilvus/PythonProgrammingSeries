
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Builds on Ex3: pip install pydantic langchain-core matplotlib
import os
import json
import base64
import io
from typing import Dict, Any, List
from pydantic import BaseModel, Field
from dotenv import load_dotenv

load_dotenv()

from langchain.output_parsers import JsonOutputParser
from langchain_openai import ChatOpenAI
from langchain.prompts import FewShotPromptTemplate, PromptTemplate
from langchain.schema import BaseOutputParser
# Assume prior tools/agent

class ToolCall(BaseModel):
    name: str = Field(..., description="Tool name: wolfram_alpha, ibm_watson, plot_tool")
    args: Dict[str, Any] = Field(..., description="Tool args")
    reason: str = Field(..., description="Why this tool?")

class WolframInput(BaseModel):
    query: str

class WatsonInput(BaseModel):
    query: str
    collection: str = "default"
    filter: Dict = {}

class PlotInput(BaseModel):
    data: List[float]
    labels: List[str]

class RobustJsonParser(BaseOutputParser):
    def __init__(self, pydantic_model):
        self.parser = JsonOutputParser(pydantic_model=pydantic_model)

    def parse(self, text: str) -> List[ToolCall]:
        for retry in range(3):
            try:
                parsed = self.parser.parse(text)
                return parsed if isinstance(parsed, list) else [parsed]
            except Exception:
                if retry < 2:
                    text = f"Fix malformed JSON. Output valid JSON only: {text}"
                    continue
                raise ValueError("Parse failed after retries")

def create_router_chain() -> tuple:
    """Few-shot intent router."""
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    examples = [
        {"query": "Integral sin(x)", "intent": "math", "tools": ["wolfram_alpha"]},
        {"query": "GDP US 2022", "intent": "search", "tools": ["ibm_watson"]},
        {"query": "Plot AAPL trends", "intent": "hybrid", "tools": ["ibm_watson", "plot_tool"]},
        {"query": "Analyze this data", "intent": "clarify", "tools": []}
    ]
    example_prompt = PromptTemplate.from_template("Query: {query}\nIntent: {intent}\nTools: {tools}")
    fewshot = FewShotPromptTemplate(
        examples=examples, example_prompt=example_prompt,
        prefix="Classify intent and select tools:", suffix="Query: {query}\nIntent: {intent}\nTools:"
    )
    router_prompt = PromptTemplate.from_template(fewshot.template + "\nOutput JSON: {{\"intent\": str, \"tools\": list}}")
    router_chain = router_prompt | llm.with_structured_output({"intent": str, "tools": list[str]})
    return router_chain, RobustJsonParser(ToolCall)

@tool
def plot_tool(data: List[float], labels: List[str]) -> str:
    """Mock plot: Matplotlib → base64 PNG."""
    import matplotlib.pyplot as plt
    plt.figure()
    plt.plot(data, label=labels)
    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    img_b64 = base64.b64encode(buf.getvalue()).decode()
    plt.close()
    return f"Plot base64: {img_b64[:100]}..."  # Trunc for demo

def orchestrate_with_routing(query: str, tools: Dict[str, Any]) -> Dict:
    """Dynamic routing blueprint."""
    router_chain, parser = create_router_chain()
    route = router_chain.invoke(query)
    if route["intent"] == "clarify":
        return {"output": "Please provide more details.", "tools_used": []}
    
    selected_tools = [tools[t] for t in route["tools"] if t in tools]
    llm = ChatOpenAI(model="gpt-4o-mini").bind_tools(selected_tools)
    
    # Structured call chain
    call_prompt = PromptTemplate.from_template("Call tools for: {query}. Reason step-by-step.")
    call_chain = call_prompt | llm | parser
    
    try:
        calls = call_chain.invoke({"query": query})
        results = []
        for call in calls:
            result = tools[call.name].invoke(call.args)
            results.append({"call": call, "result": result})
        output = f"Synthesized: {results}"
        return {"output": output, "route": route, "parse_success": True}
    except:
        return {"output": "Routing failed.", "parse_success": False}

# Integrate into agent: Use in StatefulNeuroAgent.chat as prefix
tools_dict = {"wolfram_alpha": wolfram_alpha, "ibm_watson": ibm_watson, "plot_tool": plot_tool}

# Tests: 8 queries
if __name__ == "__main__":
    tests = [
        "Integral sin(x)", "GDP US", "Stock AAPL vs MSFT 5y", "Analyze this data",
        "Prime factors", "Weather NYC", "Correlate GDP temp", "Explain Bayes", "Plot [1,2,3]", "Hybrid fail"
    ]
    success = 0
    for q in tests:
        res = orchestrate_with_routing(q, tools_dict)
        print(f"Q: {q}\nRes: {res}\n")
        if res["parse_success"]:
            success += 1
    print(f"Parse success: {success/8:.2%}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# Advanced Application Script: Grounded Timeline Agent
# Integrates Gemini LLM (reasoning/orchestration), Watson NLU (entity extraction),
# datetime.strptime (precise parsing), Wolfram Alpha (computations/verification).
# Agentic workflow: LLM decomposes query → tool calls → observations → synthesis.
# Reduces hallucinations by grounding every date/math claim externally.
# Supports iterative ReAct loop, streaming final response.
# Usage: python timeline_agent.py (requires .env with API keys)

import os
import json
from dotenv import load_dotenv
from datetime import datetime
import google.generativeai as genai
import google.generativeai.types as types
from wolframalpha.client import Client
from ibm_watson import NaturalLanguageUnderstandingV1
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
from ibm_watson.natural_language_understanding_v1 import Features, EntitiesOptions

# Load secure API keys from .env (never hardcode!)
load_dotenv()

# Configuration: Gemini 1.5 Pro for advanced tool use (2M context, reliable calling)
genai.configure(api_key=os.getenv('GEMINI_API_KEY'))
GEMINI_MODEL = 'gemini-1.5-pro'

# Wolfram Alpha client for symbolic verification (holidays, durations, weekdays)
wolfram_client = Client(os.getenv('WOLFRAM_APPID'))

# Tool functions: External verifiers – pure Python + APIs for zero-hallucination grounding
def parse_date(date_str: str, format_code: str) -> str:
    """
    Logical block: Precise date parsing using datetime.strptime.
    LLM specifies format_code (e.g., '%B %d, %Y' for 'May 1st, 2024').
    Returns ISO string or error – no neural guessing.
    """
    try:
        # Handle common formats; LLM chooses based on fuzzy input
        dt = datetime.strptime(date_str, format_code)
        return dt.isoformat()
    except ValueError as e:
        return f"Parse error: {str(e)}. Try format like '%Y-%m-%d' or '%B %d, %Y'."

def wolfram_alpha(query: str) -> str:
    """
    Logical block: Symbolic computation/verification via Wolfram.
    Handles complex: "60 business days after May 1 2024", "is May 1 2024 holiday in California?",
    "weekday of date". Extracts pod text for synthesis.
    """
    try:
        res = wolfram_client.query(query)
        if res.success:
            # Aggregate primary results (first 3 pods for brevity)
            results = [pod.text for pod in list(res.results)[:3] if pod.text]
            return '; '.join(results)
        return "Wolfram: No results found."
    except Exception as e:
        return f"Wolfram error: {str(e)}"

def watson_nlu(text: str) -> str:
    """
    Logical block: Neuro-symbolic extraction with Watson NLU.
    Detects entities (dates, locations like 'Hawaii'), sentiments.
    JSON output for LLM to parse/ground further.
    Graceful fallback if no creds.
    """
    try:
        api_key = os.getenv('WATSON_APIKEY')
        url = os.getenv('WATSON_URL')
        if not api_key or not url:
            return "Watson NLU: Credentials missing (check .env)."
        authenticator = IAMAuthenticator(api_key)
        nlu = NaturalLanguageUnderstandingV1(version='2022-04-07', authenticator=authenticator)
        nlu.set_service_url(url)
        features = Features(entities=EntitiesOptions(model='en-news'), keywords=True)
        response = nlu.analyze(text, features=features, return_analyzed_text=True).get_result()
        return json.dumps(response, indent=2)
    except Exception as e:
        return f"Watson NLU error: {str(e)} (Lite limits? Comment out tool if unused)."

# Gemini Tool Schemas: Declarative functions for LLM to call (name, desc, params)
TOOL_SCHEMAS = [
    {
        "function_declarations": [{
            "name": "parse_date",
            "description": "Parse fuzzy date string (e.g., 'May 1st, 2024') to ISO datetime. Specify format_code.",
            "parameters": {
                "type": "object",
                "properties": {
                    "date_str": {"type": "string", "description": "The date text."},
                    "format_code": {"type": "string", "description": "strptime format, e.g., '%B %d, %Y' or '%Y-%m-%d'."}
                },
                "required": ["date_str", "format_code"]
            }
        }]
    },
    {
        "function_declarations": [{
            "name": "wolfram_alpha",
            "description": "Verify/compute dates, durations, holidays, weekdays. E.g., '60 business days after 2024-05-01 excluding weekends'.",
            "parameters": {
                "type": "object",
                "properties": {"query": {"type": "string"}},
                "required": ["query"]
            }
        }]
    },
    {
        "function_declarations": [{
            "name": "watson_nlu",
            "description": "Extract entities (dates, locations) from text for grounding.",
            "parameters": {
                "type": "object",
                "properties": {"text": {"type": "string"}},
                "required": ["text"]
            }
        }]
    }
]

# Core Agent Class: Implements reasoning loop (decompose → tool → observe → repeat)
class GroundedTimelineAgent:
    def __init__(self):
        """
        Logical block: Initialize LLM with tools.
        Chat history persists for multi-step reasoning.
        """
        self.model = genai.GenerativeModel(
            model_name=GEMINI_MODEL,
            tools=TOOL_SCHEMAS
        )
        self.chat = None
        self.executors = {
            "parse_date": parse_date,
            "wolfram_alpha": wolfram_alpha,
            "watson_nlu": watson_nlu
        }

    def run(self, query: str):
        """
        Logical block: Agentic workflow – ReAct loop until no tools needed.
        1. Send query.
        2. If tool calls: execute → append function_response (model role).
        3. send_message('') → next LLM step.
        4. Final: stream synthesis.
        Prints intermediates for transparency.
        """
        self.chat = self.model.start_chat(history=[])
        print("🧠 Agent reasoning...\n")

        # Initial query
        response = self.chat.send_message(query)
        self._handle_response(response)

        # Iterative loop: Max 5 iters prevents infinite
        for iter in range(5):
            has_tools = any(
                hasattr(part, 'function_call') and part.function_call
                for part in response.parts
            )
            if not has_tools:
                break

            # Execute all tool calls (parallel-capable)
            for part in response.parts:
                if hasattr(part, 'function_call') and part.function_call:
                    fc = part.function_call
                    func_name = fc.name
                    args = {p.name: p.value for p in fc.args}
                    print(f"🔧 Calling {func_name}({args})...")
                    result = self.executors[func_name](**args)
                    print(f"📊 Result: {result[:200]}...\n")

                    # Append tool response (model role → feeds back to LLM)
                    tool_part = types.Part(
                        function_response=types.FunctionResponse(
                            name=func_name,
                            response={"result": result}
                        )
                    )
                    self.chat.history.append(types.Content(role="model", parts=[tool_part]))

            # Trigger next LLM generation with tools results
            response = self.chat.send_message("")
            self._handle_response(response)

        # Final streamed synthesis (non-blocking tokens)
        print("✨ Streaming final timeline...\n")
        final_response = self.chat.send_message(
            "Synthesize a clear, bullet-point timeline report from grounded facts. "
            "Include parsed dates, durations, verifications. No hallucinations.",
            stream=True
        )
        full_text = ""
        for chunk in final_response:
            print(chunk.text, end='', flush=True)
            full_text += chunk.text
        print("\n✅ Grounded timeline complete!")
        return full_text

    def _handle_response(self, response):
        """Helper: Print LLM reasoning/text (non-final)."""
        text_parts = [part.text for part in response.parts if part.text]
        if text_parts:
            print("🤔 LLM: " + ' '.join(text_parts) + "\n")

# Main: Interactive demo (async-ready structure)
if __name__ == "__main__":
    agent = GroundedTimelineAgent()
    query = input("\n📝 Enter project description (e.g., 'starts May 1st 2024, beta 60 biz days later...'): ")
    agent.run(query)

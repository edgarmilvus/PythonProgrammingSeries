
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
import json
from datetime import datetime
from dotenv import load_dotenv
import google.generativeai as genai
import google.generativeai.types  # For GenerationConfig

# Load environment variables securely
load_dotenv()
api_key = os.getenv('GOOGLE_API_KEY')
if not api_key:
    raise ValueError("GOOGLE_API_KEY not found in .env file")

# Configure Gemini model with temperature=0.0 for deterministic output
genai.configure(api_key=api_key)
model = genai.GenerativeModel(
    'gemini-1.5-flash',
    generation_config=google.generativeai.types.GenerationConfig(temperature=0.0)
)

def pure_prompt(question: str) -> str:
    """
    Generates a raw text response from Gemini for the given question.
    Handles API errors gracefully for idempotency.
    """
    try:
        response = model.generate_content(question)
        return response.text
    except Exception as e:
        return f"API Error: {str(e)}"

# Hallucination-prone test queries
queries = [
    "What is the exact population of Tokyo on July 15, 2023?",
    "Solve: integral of sin(x)/x from 0 to infinity.",
    "Historical fact: Date of the first iPhone release and its battery capacity in mAh."
]

# Log file in append mode for idempotency (reruns add new entries)
log_filename = 'hallucination_log.txt'
with open(log_filename, 'a') as f:
    for query in queries:
        # Generate timestamp
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        # Print with timestamp
        print(f"{timestamp}: Query: {query}")
        response = pure_prompt(query)
        print(f"{timestamp}: Response: {response}\n")
        
        # Log as JSON-like entry (one per line)
        log_entry = {
            "query": query,
            "response": response,
            "timestamp": timestamp
        }
        json.dump(log_entry, f)
        f.write('\n')
        f.flush()  # Ensure immediate write

print(f"All responses logged to {log_filename}. Rerun to observe any variability.")
print("Expected hallucinations (for README.md):")
print("1. Tokyo pop: LLM may claim ~37.4M (2023 est.), but exact daily figure requires census lookup (hallucinates precision).")
print("2. Integral: Correct is π/2 ≈1.5708, but LLM may approximate or err symbolically.")
print("3. iPhone: June 29, 2007 release; ~1400 mAh battery—LLM often invents exact mAh or date.")

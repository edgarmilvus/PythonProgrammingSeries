
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
import json
import asyncio
from datetime import datetime
from dotenv import load_dotenv
import google.generativeai as genai
import wolframalpha
from ibm_watson import NaturalLanguageUnderstandingV2
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
import time

load_dotenv()
genai.configure(api_key=os.getenv('GOOGLE_API_KEY'))
model = genai.GenerativeModel('gemini-1.5-flash')
wolfram_client = wolframalpha.Client(os.getenv('WOLFRAM_APPID'))

# IBM Watson NLU setup (free tier)
authenticator = IAMAuthenticator(os.getenv('IBM_NLU_KEY'))
nlu = NaturalLanguageUnderstandingV2(
    version='2022-04-07',
    authenticator=authenticator
)
nlu.set_service_url(os.getenv('IBM_NLU_URL'))

def wolfram_verify(query: str) -> dict:
    """Sync Wolfram (from prior)."""
    try:
        res = wolfram_client.query(query)
        primary = next((pod.text for pod in res.pods if pod.text and not pod.is_error), "No result")
        return {"verified": primary, "success": res.success}
    except:
        return {"verified": "Error", "success": False}

async def watson_entities(text: str) -> dict:
    """Async wrapper for Watson entities + date parsing."""
    def _sync_watson():
        try:
            result = nlu.analyze(text, features={'entities': {}}).get_result()
            entities = [e['text'] for e in result.get('entities', [])]
            dates_parsed = []
            for e in result.get('entities', []):
                if e['type'] == 'date':
                    # Try common formats
                    for fmt in ['%Y-%m-%d', '%Y-%m-%dT%H:%M:%S', '%B %d, %Y']:
                        try:
                            dt = datetime.strptime(e['text'], fmt)
                            dates_parsed.append(dt.isoformat())
                            break
                        except ValueError:
                            pass
            return {"entities": entities, "dates_parsed": dates_parsed}
        except:
            return {"entities": [], "dates_parsed": []}
    return await asyncio.to_thread(_sync_watson)

async def async_wolfram_many(queries: list) -> dict:
    """Parallel async Wolfram for multiple queries."""
    tasks = [asyncio.to_thread(wolfram_verify, q) for q in queries]
    results = await asyncio.gather(*tasks)
    return dict(zip(queries, results))

def multi_tool_decompose(question: str) -> str:
    """Sync wrapper for async decompose; limits to 5 sub-queries."""
    return asyncio.run(_async_decompose(question))

async def _async_decompose(question: str) -> str:
    """Async multi-tool orchestration."""
    # Decompose to JSON: {"wolfram": [...], "watson": [...]}
    decomp_prompt = f"Decompose into JSON: {{\"wolfram\": [\"facts\"], \"watson\": [\"texts\"]}} for: {question}"
    decomp_resp = model.generate_content(decomp_prompt).text
    try:
        decomp = json.loads(decomp_resp)
        wolfram_list = decomp.get('wolfram', [])[:5]  # Limit scalability
        watson_list = decomp.get('watson', [question])[:5]
    except:
        wolfram_list, watson_list = [question], [question]
    
    # Queue excess (simple log)
    if len(decomp.get('wolfram', [])) > 5:
        print("Excess Wolfram queries queued (simulated).")
    
    # Parallel tools
    wolfram_task = async_wolfram_many(wolfram_list)
    watson_task = asyncio.gather(*(watson_entities(text) for text in watson_list))
    
    wolfram_res, watson_res_list = await asyncio.gather(wolfram_task, watson_task)
    
    # Central orchestration dict with updates
    orch_dict = {}
    orch_dict.update({"wolfram": wolfram_res})
    orch_dict.update({"watson": {f"query{i}": res for i, res in enumerate(watson_res_list)}})
    
    # Cross-validate dates (e.g., compare parsed)
    all_dates = []
    for res in [wolfram_res, *watson_res_list]:
        all_dates.extend(res.get('parsed_dates', []) or res.get('dates_parsed', []))
    orch_dict.update({"validated_dates": list(set(all_dates))})
    
    # Synthesize
    synth_prompt = f"Question: {question}\nOrchestration: {orch_dict}\nSynthesized answer:"
    synth = model.generate_content(synth_prompt).text
    
    # Output structured JSON
    output_dict = {
        "decomposed": {"wolfram": wolfram_list, "watson": watson_list},
        "tools": orch_dict,
        "synthesis": synth,
        "timestamps": {"start": datetime.now().isoformat()}
    }
    
    # JSONL logging
    with open('orchestration_log.jsonl', 'a') as f:
        json.dump(output_dict, f)
        f.write('\n')
    
    return json.dumps(output_dict, indent=2)

# Test
test_query = "Who won the 2022 World Cup on Dec 18? Sentiment on Messi?"
print(multi_tool_decompose(test_query))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os
import json
from datetime import datetime
from dotenv import load_dotenv
import google.generativeai as genai
import wolframalpha  # pip install wolframalpha
import google.generativeai.types

# Load environment variables
load_dotenv()
google_key = os.getenv('GOOGLE_API_KEY')
wolfram_id = os.getenv('WOLFRAM_APPID')
if not google_key or not wolfram_id:
    raise ValueError("Missing GOOGLE_API_KEY or WOLFRAM_APPID in .env")

# Configure Gemini
genai.configure(api_key=google_key)
model = genai.GenerativeModel('gemini-1.5-flash')

# Initialize Wolfram client
client = wolframalpha.Client(wolfram_id)

def wolfram_verify(query: str) -> dict:
    """
    Submits query to Wolfram Alpha, extracts primary result text.
    Handles no-results/errors; retries once on pod error.
    Bonus: Parses date strings if present (e.g., for verification).
    """
    for attempt in range(2):  # Simple retry
        try:
            res = client.query(query)
            if res.success:
                # Get first non-error pod's text
                primary_pod = next((pod for pod in res.pods if pod.text and not pod.is_error), None)
                verified = primary_pod.text if primary_pod else "No primary result"
                
                # Bonus: Attempt date parse for temporal outputs
                date_strs = [line for line in verified.splitlines() if '-' in line and len(line.split('-')) == 3]
                parsed_dates = []
                for ds in date_strs:
                    try:
                        dt = datetime.strptime(ds.strip(), '%Y-%m-%d')
                        parsed_dates.append(dt.isoformat())
                    except ValueError:
                        pass
                
                return {
                    "verified": verified,
                    "success": True,
                    "parsed_dates": parsed_dates
                }
            else:
                return {"verified": "No result", "success": False}
        except Exception:
            if attempt == 1:
                return {"verified": "Verification error", "success": False}
    return {"verified": "Retry failed", "success": False}

def grounded_query(user_question: str) -> str:
    """
    Core grounded workflow: Decompose → Verify → Synthesize.
    Uses dict.update for merging verifications and timestamps.
    """
    # Step 1: LLM decomposition to JSON facts
    decomp_prompt = f"Decompose this into 1-2 verifiable facts/math: {user_question}. Output as JSON list: [{{\"fact\": \"...\"}}]"
    decomp_resp = model.generate_content(decomp_prompt).text.strip()
    
    facts = []
    try:
        parsed = json.loads(decomp_resp)
        facts = [item['fact'] for item in parsed] if isinstance(parsed, list) else [parsed]
    except json.JSONDecodeError:
        facts = [user_question]  # Fallback
    
    # Step 2: Parallel-ish verification (sequential for simplicity, but collects in dict)
    verifs = {}
    for fact in facts:
        verif = wolfram_verify(fact)
        verifs.update({fact: verif})  # Merge each verification
    
    # Step 3: Add timestamp via update
    timestamp = datetime.now().isoformat()
    verifs.update({"timestamp": timestamp})
    
    # Step 4: Synthesize grounded answer
    synth_prompt = f"User question: {user_question}\nFacts: {facts}\nWolfram verifications: {verifs}\nProvide grounded answer:"
    synth_resp = model.generate_content(synth_prompt).text
    
    output = f"Grounded Answer: {synth_resp}\nVerifications: {json.dumps(verifs, indent=2)}"
    return output

# Test queries
test_queries = [
    "Current CEO of Apple?",
    "sqrt(2) to 50 decimals?",
    "Boiling point of mercury in Celsius?"
]

for q in test_queries:
    print(grounded_query(q))
    print("\n" + "="*80 + "\n")

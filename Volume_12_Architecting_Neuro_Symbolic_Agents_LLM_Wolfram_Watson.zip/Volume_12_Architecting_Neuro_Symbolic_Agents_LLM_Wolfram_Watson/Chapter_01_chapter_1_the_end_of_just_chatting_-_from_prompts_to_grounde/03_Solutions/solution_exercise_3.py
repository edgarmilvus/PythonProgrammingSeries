
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
import json
import asyncio
import sys
from datetime import datetime
from dotenv import load_dotenv
import google.generativeai as genai
import wolframalpha
import time  # For benchmarking

load_dotenv()
genai.configure(api_key=os.getenv('GOOGLE_API_KEY'))
model = genai.GenerativeModel('gemini-1.5-flash')
client = wolframalpha.Client(os.getenv('WOLFRAM_APPID'))

def wolfram_verify(query: str) -> dict:
    """Sync Wolfram verifier (from Ex2)."""
    try:
        res = client.query(query)
        if res.success:
            primary_pod = next((pod for pod in res.pods if pod.text and not pod.is_error), None)
            return {"verified": primary_pod.text if primary_pod else "No result", "success": True}
        return {"verified": "No result", "success": False}
    except:
        return {"verified": "Error", "success": False}

async def async_wolfram_verify(query: str, shared_verifs: dict, lock: asyncio.Lock) -> None:
    """Async wrapper: Runs sync wolfram_verify in thread, updates shared dict."""
    verif = await asyncio.to_thread(wolfram_verify, query)
    async with lock:
        shared_verifs.update({query: verif})

async def async_stream_grounded(question: str) -> str:
    """
    Full async streaming grounded agent.
    Streams decomp → parallel async verifies → streams synthesis.
    Uses Lock for thread-safe dict updates, timestamps tokens, 30s timeout.
    """
    start_time = time.perf_counter()
    
    # Shared verifs dict with lock
    verifs = {}
    lock = asyncio.Lock()
    
    print(f"{datetime.now().strftime('%H:%M:%S')} - Streaming decomposition for: {question}")
    
    # Step 1: Stream decomposition (accumulate for JSON parse)
    decomp_prompt = f"Decompose into facts/math JSON list: [{{\"fact\": \"...\"}}] {question}"
    accum_text = ""
    print("Decomposing: ", end="", flush=True)
    try:
        for chunk in model.generate_content(decomp_prompt, stream=True):
            token = chunk.text
            accum_text += token
            print(token, end="", flush=True)
        print()  # Newline
    except asyncio.TimeoutError:
        print("\nDecomp timeout!")
        return "Timeout"
    
    # Parse facts
    try:
        facts = json.loads(accum_text)
        facts = [f['fact'] for f in facts] if isinstance(facts, list) else [accum_text]
    except:
        facts = [question]
    
    # Step 2: Parallel async Wolfram verifies with gather
    tasks = [async_wolfram_verify(fact, verifs, lock) for fact in facts]
    try:
        await asyncio.wait_for(asyncio.gather(*tasks), timeout=30.0)
    except asyncio.TimeoutError:
        print("Verify timeout!")
    
    # Add timestamp to verifs
    async with lock:
        verifs['timestamp'] = datetime.now().isoformat()
    
    # Step 3: Stream synthesis with cursor/timestamps
    synth_prompt = f"Question: {question}\nVerifs: {verifs}\nGrounded answer:"
    print("\rThinking... ", end="", flush=True)
    final_accum = ""
    ts_prefix = datetime.now().strftime('%H:%M:%S') + " - "
    for chunk in model.generate_content(synth_prompt, stream=True):
        token = chunk.text
        final_accum += token
        sys.stdout.write(f"\r{ts_prefix}{token}")
        sys.stdout.flush()
    print()  # Clear cursor
    
    latency = time.perf_counter() - start_time
    print(f"Latency: {latency:.2f}s")
    
    # Benchmark log
    bench = {"question": question, "latency": latency, "verifs": verifs}
    with open('streaming_bench.json', 'a') as f:
        json.dump(bench, f)
        f.write('\n')
    
    # Polish: Clear line on completion
    print("\n" + "="*80)
    return final_accum

# Test (run with asyncio)
async def main():
    test_query = "Plan a trip: Distance NYC to LA, fuel cost at $4/gal, 25mpg?"
    await async_stream_grounded(test_query)

if __name__ == "__main__":
    asyncio.run(main())

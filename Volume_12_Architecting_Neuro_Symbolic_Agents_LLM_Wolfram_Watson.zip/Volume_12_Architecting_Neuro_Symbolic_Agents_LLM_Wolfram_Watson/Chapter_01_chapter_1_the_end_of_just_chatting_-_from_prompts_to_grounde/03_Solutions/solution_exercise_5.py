
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import os
import json
import asyncio
import sys
import signal
from datetime import datetime
from dotenv import load_dotenv
import google.generativeai as genai
import wolframalpha
from ibm_watson import NaturalLanguageUnderstandingV2
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
import time

# Globals (simulates Subsection 3 ReAct base: thought→tool→obs loop, extended)
load_dotenv()
genai.configure(api_key=os.getenv('GOOGLE_API_KEY'))
model = genai.GenerativeModel('gemini-1.5-flash')
wolfram_client = wolframalpha.Client(os.getenv('WOLFRAM_APPID'))
authenticator = IAMAuthenticator(os.getenv('IBM_NLU_KEY'))
nlu = NaturalLanguageUnderstandingV2(version='2022-04-07', authenticator=authenticator)
nlu.set_service_url(os.getenv('IBM_NLU_URL'))

session_history = []  # Persistence: list of dicts

# Re-use functions from prior (simplified here for self-contained)
def wolfram_verify(query):  # Sync
    try:
        res = wolfram_client.query(query)
        primary = next((pod.text for pod in res.pods if pod.text), "No result")
        return {"verified": primary, "success": res.success}
    except:
        return {"verified": "Error", "success": False}

async def watson_entities(text):
    def _sync():
        try:
            r = nlu.analyze(text, features={'entities': {}}).get_result()
            ents = [e['text'] for e in r.get('entities', [])]
            dates = []
            for e in r.get('entities', []):
                if e['type'] == 'date':
                    for fmt in ['%Y-%m-%d', '%B %d, %Y', '%Y-%m-%dT%H:%M:%S']:
                        try:
                            dates.append(datetime.strptime(e['text'], fmt).isoformat())
                            break
                        except: pass
            return {"entities": ents, "dates_parsed": dates}
        except:
            return {"entities": [], "dates_parsed": []}
    return await asyncio.to_thread(_sync)

async def process_tools(query_type: str, decomp: dict) -> dict:
    """Parallel tools based on type (ReAct obs)."""
    verifs = {}
    if 'wolfram' in query_type or query_type == 'both':
        w_tasks = [asyncio.to_thread(wolfram_verify, f) for f in decomp.get('wolfram', [])[:3]]
        verifs['wolfram'] = dict(zip(decomp['wolfram'], await asyncio.gather(*w_tasks)))
    if 'watson' in query_type or query_type == 'both':
        w_tasks = [watson_entities(t) for t in decomp.get('watson', [])[:3]]
        verifs['watson'] = await asyncio.gather(*w_tasks)
    verifs['timestamp'] = datetime.now().isoformat()
    return verifs

async def async_process(user_input: str) -> str:
    """Core agent: Classify → Decomp stream → Tools → Stream synth (ReAct extended to multi-tool)."""
    start = time.perf_counter()
    
    # Classify stream (live prefix)
    class_prompt = f"Classify '{user_input}' as 'math' (Wolfram), 'entities' (Watson), 'both', 'general':"
    print("\033[32mAgent classifying...\033[0m", end="", flush=True)
    class_accum = ""
    for chunk in model.generate_content(class_prompt, stream=True):
        class_accum += chunk.text
        print(chunk.text, end="", flush=True)
    print("\n")
    query_type = class_accum.lower().split()[0]  # Simple extract
    
    # Decomp stream (Mod from Sub3: JSON decomp)
    decomp_prompt = f"JSON decomp {{'wolfram':[], 'watson':[]}}: {user_input}"
    print("Decomposing: ", end="", flush=True)
    decomp_accum = ""
    for chunk in model.generate_content(decomp_prompt, stream=True):
        decomp_accum += chunk.text
        print(chunk.text, end="", flush=True)
    print("\n")
    try:
        decomp = json.loads(decomp_accum)
    except:
        decomp = {'wolfram': [user_input], 'watson': [user_input]}
    
    # Parallel tools
    verifs = await process_tools(query_type, decomp)
    
    # Temporal compare if dates (e.g., "Compare 2023-01-15 and 2023-07-20")
    dates = [d for v in verifs.values() for d in v.get('dates_parsed', []) if isinstance(v, dict)]
    if len(dates) >= 2:
        verifs['date_compare'] = f"Earliest: {min(dates)}, Latest: {max(dates)}"
    
    # Stream synth (cite sources)
    synth_prompt = f"Grounded ReAct: Input: {user_input}\nType: {query_type}\nVerifs: {verifs}\nAnswer with sources:"
    print("\r\033[34mSynthesizing...\033[0m", end="", flush=True)
    synth_accum = ""
    for chunk in model.generate_content(synth_prompt, stream=True):
        token = chunk.text
        synth_accum += token
        sys.stdout.write(token)
        sys.stdout.flush()
    print()
    
    latency = time.perf_counter() - start
    print(f"\033[32mLatency: {latency:.2f}s\033[0m")
    
    grounded = synth_accum
    ts = datetime.now().isoformat()
    entry = {"input": user_input, "grounded": grounded, "type": query_type, "verifs": verifs, "ts": ts, "latency": latency}
    session_history.append(entry)
    entry['updated_verifs'] = verifs  # Simulate update
    return grounded

def signal_handler(sig, frame):
    print("\nSaving session...")
    ts_file = datetime.now().strftime("%Y%m%d_%H%M")
    with open(f'session_{ts_file}.json', 'w') as f:
        json.dump(session_history, f, indent=2, default=str)
    sys.exit(0)

# REPL loop
async def repl():
    signal.signal(signal.SIGINT, signal_handler)  # Graceful Ctrl+C
    print("\033[32mGrounded Agent REPL (quit/history/verify last)\033[0m")
    while True:
        try:
            user_input = input("\033[33mAgent> \033[0m").strip()
            if user_input.lower() == 'quit':
                break
            if user_input.lower() == 'history':
                hist_summary = model.generate_content(f"Summarize session: {json.dumps(session_history[-5:], indent=2)}").text
                print(f"\033[35m{hist_summary}\033[0m")
                continue
            if user_input.lower() == 'verify last' and session_history:
                last_input = session_history[-1]['input']
                print("Re-verifying...")
                await async_process(last_input)
                continue
            if not user_input:
                continue
            # Error recovery: Clarify if empty verifs (simulated)
            await async_process(user_input)
        except Exception as e:
            print(f"\033[31mError: {e}. Clarify query?\033[0m")
    
    # Save on exit
    ts_file = datetime.now().strftime("%Y%m%d_%H%M")
    with open(f'session_{ts_file}.json', 'w') as f:
        json.dump(session_history, f, indent=2, default=str)
    print("Session saved.")

if __name__ == "__main__":
    asyncio.run(repl())

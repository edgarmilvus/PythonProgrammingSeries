
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import google.generativeai as genai  # Core SDK for Gemini models
import google.generativeai.types as types  # Protos for function/tool declarations
import os  # For secure API key handling
import math  # Math library exposed to symbolic evaluator
import json  # Optional: for pretty-printing args/results

# Logical Block 1: API Configuration
# Prompts user for key (fallback to env var for prod/security)
api_key = os.getenv("GOOGLE_API_KEY") or input("Enter your Google AI Studio API key: ").strip()
genai.configure(api_key=api_key)

# Logical Block 2: Define Symbolic Tool (the 'grounding' mechanism)
def calculator(expression: str) -> dict:
    """
    Symbolic evaluator: Computes math expressions verifiably.
    Uses restricted eval() for safety—mimics Wolfram|Alpha's precision.
    Returns dict for structured tool response.
    """
    try:
        # Safe globals: No builtins except math (prevents code injection)
        safe_globals = {"__builtins__": {}, "math": math}
        result = eval(expression, safe_globals, {})
        return {"result": str(result)}  # Stringify for LLM consumption
    except Exception as e:
        return {"error": f"Invalid expression: {str(e)}"}

# Logical Block 3: LLM Tool Declaration (bridges neural to symbolic)
calc_declaration = types.FunctionDeclaration(
    name="calculator",
    description="""Precise math evaluator. Use for ALL computations to avoid errors.
    Input: Valid Python expression (e.g., '2 + 3 * math.sqrt(16)', 'math.sin(math.pi / 2)').
    Supports: arithmetic, math module (pi, sqrt, sin, etc.).""",
    parameters=types.Schema(
        type=types.Type.OBJECT,
        properties={
            "expression": types.Schema(
                type=types.Type.STRING,
                description="Python math expression to evaluate exactly."
            )
        },
        required=["expression"]
    )
)

# Logical Block 4: Initialize Neuro-Symbolic Model
model = genai.GenerativeModel(
    model_name="gemini-1.5-flash",  # Fast, tool-enabled model (free tier friendly)
    tools=[calc_declaration]  # Enables function calling
)

# Logical Block 5: Agent Workflow (Query → Tool → Synthesis)
chat = model.start_chat(history=[])  # Stateless for Hello World

query = "What is the area of a circle with radius 5? Use math.pi for precision."  # Relatable math query

# Send query: LLM decides tool use autonomously
response1 = chat.send_message(query)

print("LLM Reasoning (pre-tool):", response1.text)

# Logical Block 6: Detect & Execute Tool Call (Grounding Loop)
if (response1.candidates and
    response1.candidates[0].content.parts and
    hasattr(response1.candidates[0].content.parts[0], 'function_call')):

    func_call = response1.candidates[0].content.parts[0].function_call
    print(f"\n🛠️ Tool Called: {func_call.name}({dict(func_call.args)})")

    # Execute symbolic tool
    args = dict(func_call.args)
    tool_result = calculator(args["expression"])

    # Structured response back to LLM
    function_response = genai.protos.FunctionResponse(
        name=func_call.name,
        response=tool_result
    )

    # Feed result to LLM for synthesis (with streaming for low latency)
    final_response = chat.send_message(
        genai.protos.Content(
            role="user",
            parts=[genai.protos.Part(function_response=function_response)]
        ),
        stream=True  # Streams tokens: Improves UX (perceived <1s latency)
    )

    print("\n🤖 Grounded Final Response (streaming):")
    for chunk in final_response:
        if chunk.text:
            print(chunk.text, end='', flush=True)  # Real-time output
    print("\n")  # Newline after stream

else:
    print("No tool needed:", response1.text)

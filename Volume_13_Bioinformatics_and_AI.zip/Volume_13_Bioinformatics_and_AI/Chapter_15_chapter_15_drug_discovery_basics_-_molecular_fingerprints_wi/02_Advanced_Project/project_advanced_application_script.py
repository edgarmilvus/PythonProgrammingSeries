
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import numpy as np
from rdkit import Chem, DataStructs
from rdkit.Chem import AllChem
from scipy.spatial.distance import pdist, squareform
from scipy.cluster.hierarchy import linkage, fcluster

# --- 1. Define Constants and Input Data ---

# The known active compound (Lead)
LEAD_SMILES = "CCOC(=O)C1=C(N)N=C(C)C(=C1C#N)C(=O)OCC" 

# Simulated library of candidate compounds (500 entries total in a real scenario)
# We use a small, representative set for demonstration
CANDIDATE_SMILES = [
    "CCOC(=O)C1=C(N)N=C(C)C(=C1C#N)C(=O)OCC",  # Duplicate (High Similarity)
    "CC(=O)NCCC1=CNc2c1cc(OC)cc2",             # Melatonin (Different Structure)
    "COc1ccc(C(=O)C2=C(N)N=C(C)C(=C2C#N)C(=O)OCC)cc1", # Highly Similar Variant 1
    "O=C(OCC)C1=C(N)N=C(C)C(=C1C#N)C(=O)O",    # Similar Variant 2 (Acid)
    "CC(C)(C)OC(=O)N[C@@H](Cc1ccccc1)C(=O)O",  # Amino Acid Derivative (Low Similarity)
    "C1=CC(=CC=C1)C2=C(C(=O)C3=C(C=CC=C3)O2)O", # Flavone (Medium Similarity)
    "CCN(CC)CC(=O)Nc1c(C)cccc1C",              # Lidocaine (Very Different)
    "C1=C(C(=O)C2=C(C=CC=C2)O1)O",             # Coumarin Derivative (Medium Similarity)
    "CCOC(=O)C1=C(N)N=C(C)C(=C1C#N)C(=O)N(C)C",# Highly Similar Variant 3
    "CC(=O)NCCC1=CNc2c1ccc(C)c2"               # Melatonin Variant (Low Similarity)
]

TANIMOTO_THRESHOLD = 0.65  # Minimum similarity score to be considered a 'Hit'
FINGERPRINT_RADIUS = 2     # Radius for Morgan fingerprint generation
FINGERPRINT_NBITS = 1024   # Number of bits in the fingerprint vector

# --- 2. Core Functions: Fingerprinting and Similarity ---

def generate_morgan_fingerprint(smiles: str, radius: int, nbits: int) -> DataStructs.ExplicitBitVect | None:
    """Converts SMILES to an RDKit Mol object and generates a Morgan fingerprint."""
    try:
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            # EAFP style: Assume valid input, handle exception (or None result) if invalid
            print(f"Warning: Invalid SMILES skipped: {smiles}")
            return None
        # Generate the Morgan fingerprint (equivalent to ECFP)
        fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius, nBits=nbits)
        return fp
    except Exception as e:
        print(f"Error processing SMILES {smiles}: {e}")
        return None

def calculate_tanimoto_similarity(fp1: DataStructs.ExplicitBitVect, 
                                  fp2: DataStructs.ExplicitBitVect) -> float:
    """Calculates the Tanimoto similarity between two bit vectors."""
    return DataStructs.TanimotoSimilarity(fp1, fp2)

# --- 3. Data Processing and Screening Pipeline ---

# Convert the lead compound
lead_fp = generate_morgan_fingerprint(LEAD_SMILES, FINGERPRINT_RADIUS, FINGERPRINT_NBITS)
if lead_fp is None:
    raise ValueError("Lead compound SMILES is invalid. Cannot proceed.")

# Process the library and store results
library_data = []
for i, smiles in enumerate(CANDIDATE_SMILES):
    fp = generate_morgan_fingerprint(smiles, FINGERPRINT_RADIUS, FINGERPRINT_NBITS)
    
    if fp:
        # Calculate similarity against the lead
        similarity = calculate_tanimoto_similarity(lead_fp, fp)
        
        # Convert RDKit bit vector to a NumPy array for later clustering
        fp_array = np.zeros((1,), dtype=int)
        DataStructs.BitVectToText(fp)
        DataStructs.ConvertToNumpyArray(fp, fp_array)
        
        library_data.append({
            'ID': f'CAND_{i+1}',
            'SMILES': smiles,
            'Tanimoto_Score': similarity,
            'Fingerprint': fp_array
        })

df_library = pd.DataFrame(library_data)

# --- 4. Hit Identification and Filtering ---

# Identify compounds that meet the structural similarity threshold
hit_df = df_library[df_library['Tanimoto_Score'] >= TANIMOTO_THRESHOLD].reset_index(drop=True)

print(f"\n--- Screening Results ---")
print(f"Total candidates screened: {len(CANDIDATE_SMILES)}")
print(f"Hits identified (Tanimoto >= {TANIMOTO_THRESHOLD}): {len(hit_df)}")

if hit_df.empty:
    print("No sufficiently similar hits found.")
else:
    print("\n--- Hit List ---")
    print(hit_df[['ID', 'Tanimoto_Score', 'SMILES']])

    # --- 5. Diversity Analysis via Hierarchical Clustering ---
    
    # 5a. Prepare the data matrix for clustering
    # Stack the 1024-bit fingerprint arrays horizontally
    fp_matrix = np.vstack(hit_df['Fingerprint'].values)
    
    # 5b. Calculate the distance matrix (1 - Similarity = Distance)
    # We use pdist with the Jaccard metric, which is equivalent to 1 - Tanimoto 
    # for binary vectors, producing the condensed distance matrix.
    distance_matrix = pdist(fp_matrix, metric='jaccard')
    
    # 5c. Perform Hierarchical Clustering using Ward's method
    # This linkage matrix defines the cluster hierarchy
    linkage_matrix = linkage(distance_matrix, method='ward')
    
    # 5d. Cut the dendrogram to define discrete clusters (e.g., 3 clusters)
    # The max_d parameter defines the distance threshold for cluster formation
    # We use a simple max_k=3 for demonstration, forcing 3 groups
    MAX_CLUSTERS = 3 
    hit_df['Cluster'] = fcluster(linkage_matrix, t=MAX_CLUSTERS, criterion='maxclust')
    
    print("\n--- Diversity Analysis (Clustering) ---")
    print(f"Hits assigned to {hit_df['Cluster'].nunique()} clusters:")
    print(hit_df[['ID', 'Tanimoto_Score', 'Cluster']].sort_values(by='Cluster'))

    # Display cluster representative (e.g., the hit closest to the lead, or just the first entry)
    print("\nCluster Representatives:")
    for cluster_id, group in hit_df.groupby('Cluster'):
        best_hit = group.sort_values(by='Tanimoto_Score', ascending=False).iloc[0]
        print(f"Cluster {cluster_id} (N={len(group)}): Best Score {best_hit['Tanimoto_Score']:.3f} (ID: {best_hit['ID']})")

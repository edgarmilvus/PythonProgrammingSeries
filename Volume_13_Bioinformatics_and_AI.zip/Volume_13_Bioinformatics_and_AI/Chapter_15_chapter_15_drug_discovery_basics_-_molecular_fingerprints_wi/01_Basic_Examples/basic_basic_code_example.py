
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem

# --- 1. Define the input structure ---
# SMILES (Simplified Molecular-Input Line-Entry System) for Aspirin
aspirin_smiles = "CC(=O)Oc1ccccc1C(=O)O"

# --- 2. Convert SMILES to RDKit Mol Object ---
# This step validates the structure and creates the internal RDKit representation
mol_aspirin = Chem.MolFromSmiles(aspirin_smiles)

# CRITICAL CHECK: Ensure the molecule object was successfully created
if mol_aspirin is None:
    print(f"Error: Could not parse SMILES: {aspirin_smiles}")
else:
    # --- 3. Generate the Morgan Fingerprint (ECFP-like) ---
    # Parameters:
    # radius=2: Defines the maximum size of the substructures considered (equivalent to ECFP4)
    # nBits=1024: The fixed length of the resulting binary vector
    fp_morgan = AllChem.GetMorganFingerprintAsBitVect(
        mol_aspirin,
        radius=2,
        nBits=1024
    )

    # --- 4. Convert the RDKit BitVect into a NumPy array ---
    # This conversion is necessary for compatibility with standard ML libraries
    fp_array = np.array(fp_morgan)

    # --- 5. Display the results and analyze the output ---
    print("--- Molecular Fingerprint Generation Summary ---")
    print(f"Original SMILES: {aspirin_smiles}")
    print(f"RDKit Mol Object Type: {type(mol_aspirin)}")
    print(f"Fingerprint Object Type: {type(fp_morgan)}")
    print(f"Fingerprint Length (nBits): {len(fp_morgan)}")
    print(f"NumPy Array Shape: {fp_array.shape}")
    
    # Displaying the beginning of the vector
    print("\nFirst 30 elements of the 1024-bit vector:")
    print(fp_array[:30])
    
    # Analyze sparsity
    active_bits = np.sum(fp_array)
    print(f"\nTotal active bits (structural features present): {active_bits}")
    print(f"Sparsity Percentage: {active_bits / len(fp_morgan) * 100:.2f}%")


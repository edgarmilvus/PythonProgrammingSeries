
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from rdkit import Chem
from rdkit.Chem import AllChem
from rdkit.DataStructs import TanimotoSimilarity

# 1. Define Compounds
smiles_A = 'CC(=O)Nc1ccc(O)cc1'  # Acetaminophen (Lead)
smiles_B = 'COc1ccc(NC(=O)C)cc1' # Analog B
smiles_C = 'CC12CCC3C(C)(CCC4C3CCC(=O)C4)CCC1C2' # Analog C (Steroid)
smiles_D = 'O=C(O)Cc1ccc(N)cc1' # Analog D

# Convert SMILES to Mol objects
mol_A = Chem.MolFromSmiles(smiles_A)
mol_B = Chem.MolFromSmiles(smiles_B)
mol_C = Chem.MolFromSmiles(smiles_C)
mol_D = Chem.MolFromSmiles(smiles_D)

# 2. Fingerprint Generation (2048-bit Morgan, Radius 2)
fp_A = AllChem.GetMorganFingerprintAsBitVect(mol_A, radius=2, nBits=2048)
fp_B = AllChem.GetMorganFingerprintAsBitVect(mol_B, radius=2, nBits=2048)
fp_C = AllChem.GetMorganFingerprintAsBitVect(mol_C, radius=2, nBits=2048)
fp_D = AllChem.GetMorganFingerprintAsBitVect(mol_D, radius=2, nBits=2048)

# 3. Pairwise Similarity Calculation
sim_AB = TanimotoSimilarity(fp_A, fp_B)
sim_AC = TanimotoSimilarity(fp_A, fp_C)
sim_AD = TanimotoSimilarity(fp_A, fp_D)

# 4. Reporting and Analysis
print("--- Tanimoto Similarity Scores (Lead A vs Analogs) ---")
print(f"Lead A (Acetaminophen) vs Analog B: {sim_AB:.4f}")
print(f"Lead A (Acetaminophen) vs Analog C: {sim_AC:.4f}")
print(f"Lead A (Acetaminophen) vs Analog D: {sim_AD:.4f}")

# Determine the most similar analog
scores = {'B': sim_AB, 'C': sim_AC, 'D': sim_AD}
most_similar = max(scores, key=scores.get)

print(f"\nConclusion: Analog {most_similar} is the most promising structural match.")

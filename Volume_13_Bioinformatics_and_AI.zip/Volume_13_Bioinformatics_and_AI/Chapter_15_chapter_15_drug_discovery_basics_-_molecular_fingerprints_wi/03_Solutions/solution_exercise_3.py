
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem

# 1. Dataset Creation
smiles_set = [
    'O=C(O)c1ccccc1',
    'CCC(C)C(=O)Nc1ccccc1',
    'O=C(O)C(C)(C)SCCC(=O)N1C(C(=O)O)C(C)S1',
    'c1ccc(Cc2ccccc2)cc1',
    'CC(=O)Oc1ccccc1C(=O)O'
]

mols = [Chem.MolFromSmiles(s) for s in smiles_set]

# 2. Fingerprint Generation (1024-bit Morgan, Radius 2)
# Store RDKit fingerprint objects
fp_list_rdkit = [
    AllChem.GetMorganFingerprintAsBitVect(mol, radius=2, nBits=1024)
    for mol in mols
]

# 3. Conversion to List of Integers (0s and 1s)
# Initialize a list to hold the dense vector for each molecule
fp_list_dense = []

for fp in fp_list_rdkit:
    # Converting the RDKit ExplicitBitVect object directly to a Python list of integers
    fp_list_dense.append(list(fp))

# 4. NumPy Matrix Formation
# Convert the list of lists into a 2D NumPy array (matrix)
qsar_matrix = np.array(fp_list_dense, dtype=np.int8)

# 5. Validation
print("Number of Molecules Processed:", len(smiles_set))
print("Final QSAR Matrix Shape:", qsar_matrix.shape)
print("Data Type of Matrix Elements:", qsar_matrix.dtype)

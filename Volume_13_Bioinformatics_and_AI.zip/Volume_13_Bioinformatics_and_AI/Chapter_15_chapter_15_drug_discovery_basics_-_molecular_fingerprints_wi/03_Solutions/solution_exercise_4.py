
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from rdkit import Chem
from rdkit.Chem import AllChem
from rdkit.DataStructs import TanimotoSimilarity

# Molecule X and Y are closely related (differing by one methyl group in the side chain)
smiles_X = 'CC(C)C(=O)O[C@H]1CC[C@@]2(C)C3=CC(=O)C=C[C@]3(C)[C@@H]12'
smiles_Y = 'CCC(C)C(=O)O[C@H]1CC[C@@]2(C)C3=CC(=O)C=C[C@]3(C)[C@@H]12'

mol_X = Chem.MolFromSmiles(smiles_X)
mol_Y = Chem.MolFromSmiles(smiles_Y)

# 2. Standard Fingerprint Set (FP_Std)
# Radius 2 (captures environments up to 3 bonds away), 1024 bits
fp_X_std = AllChem.GetMorganFingerprintAsBitVect(mol_X, radius=2, nBits=1024)
fp_Y_std = AllChem.GetMorganFingerprintAsBitVect(mol_Y, radius=2, nBits=1024)
similarity_std = TanimotoSimilarity(fp_X_std, fp_Y_std)

# 3. High-Resolution Fingerprint Set (FP_HighRes)
# Radius 4 (captures environments up to 5 bonds away), 4096 bits
fp_X_highres = AllChem.GetMorganFingerprintAsBitVect(mol_X, radius=4, nBits=4096)
fp_Y_highres = AllChem.GetMorganFingerprintAsBitVect(mol_Y, radius=4, nBits=4096)
similarity_highres = TanimotoSimilarity(fp_X_highres, fp_Y_highres)

# 4. Analysis
print("--- Morgan Fingerprint Comparison ---")
print(f"Similarity (Standard - R=2, B=1024): {similarity_std:.4f}")
print(f"Similarity (High-Res - R=4, B=4096): {similarity_highres:.4f}")

if similarity_highres < similarity_std:
    print("\nObservation: High-resolution fingerprinting resulted in a lower similarity score.")
else:
    print("\nObservation: High-resolution fingerprinting resulted in a higher or identical similarity score.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from rdkit import Chem
from rdkit.Chem import AllChem
from rdkit.Chem import MACCSkeys

# 1. Input Data
aspirin_smiles = 'CC(=O)Oc1ccccc1C(=O)O'
ibuprofen_smiles = 'CC(C)Cc1ccc(C(C)C(=O)O)cc1'
penicillin_g_smiles = 'CC1(C)S[C@@H]2[C@H](NC(=O)Cc3ccccc3)C(=O)N2[C@H]1C(=H)O'

molecule_list = [
    Chem.MolFromSmiles(aspirin_smiles),
    Chem.MolFromSmiles(ibuprofen_smiles),
    Chem.MolFromSmiles(penicillin_g_smiles)
]

# Process the first molecule (Aspirin) for validation checks
mol_ref = molecule_list[0]

# 2. MACCS Key Generation
maccs_fp = MACCSkeys.GenMACCSKeys(mol_ref)
print("--- MACCS Key Validation ---")
print(f"2a. Length of MACCS Key (Fixed): {len(maccs_fp)}")

# 3. Morgan Fingerprint Generation (Radius 2, 1024 bits)
morgan_fp = AllChem.GetMorganFingerprintAsBitVect(mol_ref, radius=2, nBits=1024)
print("\n--- Morgan Fingerprint Validation ---")
print(f"3a. Length of Morgan FP (Fixed): {len(morgan_fp)}")

# 4. Type Check and Conversion
# Convert the RDKit ExplicitBitVect to a standard Python list of integers
morgan_fp_list = list(morgan_fp)

print(f"\n4. Data Type Validation (First 5 elements):")
for i in range(5):
    element = morgan_fp_list[i]
    print(f"Element {i+1}: Value={element}, Type={type(element).__name__}")

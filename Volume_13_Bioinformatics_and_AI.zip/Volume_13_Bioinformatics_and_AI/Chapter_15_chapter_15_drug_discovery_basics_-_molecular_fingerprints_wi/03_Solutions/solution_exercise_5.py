
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from rdkit import Chem
from rdkit.Chem import AllChem
from rdkit.DataStructs import TanimotoSimilarity
import sys

def generate_morgan_fp(smiles, radius=2, nBits=1024):
    """
    Generates a Morgan fingerprint (bit vector) from a SMILES string.
    Handles invalid SMILES strings gracefully.
    """
    mol = Chem.MolFromSmiles(smiles)
    
    # Error Handling (POLA: return None for predictable failure)
    if mol is None:
        print(f"Warning: Invalid SMILES detected: {smiles[:20]}...", file=sys.stderr)
        return None
    
    # Generate the fingerprint
    fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius=radius, nBits=nBits)
    return fp

def calculate_tanimoto(fp1, fp2):
    """
    Calculates the Tanimoto similarity between two RDKit fingerprints.
    Returns 0.0 if either input is None.
    """
    # Check for None inputs resulting from invalid SMILES processing
    if fp1 is None or fp2 is None:
        return 0.0
    
    # Calculate similarity
    return TanimotoSimilarity(fp1, fp2)

# Valid compounds:
smiles_A = 'C1=CC=CC=C1' # Benzene
smiles_B = 'C1=CC=C(O)C=C1' # Phenol
# Invalid SMILES example:
invalid_smiles = 'C(=O)O[C@H]1CC[C@@]2(C)C3=CC(=O)C=C[C@]3(C)[C@@H]12'

# 3. Demonstration
print("--- Demonstration of Robust Functions ---")

# A. Generate fingerprints for two valid compounds
fp_A = generate_morgan_fp(smiles_A)
fp_B = generate_morgan_fp(smiles_B)

# B. Attempt to generate a fingerprint for an intentionally invalid SMILES string (C)
fp_C = generate_morgan_fp(invalid_smiles)

# C. Calculate similarity between A and B (Valid path)
sim_AB = calculate_tanimoto(fp_A, fp_B)
print(f"\nSimilarity (A vs B): {sim_AB:.4f}")

# D. Calculate similarity between A and C (Error handling path)
sim_AC = calculate_tanimoto(fp_A, fp_C)
print(f"Similarity (A vs C): {sim_AC:.4f} (Expected 0.0 due to invalid input C)")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

from Bio import Entrez
import time
from pprint import pprint # Used for pretty-printing complex dictionary output

# --- 1. Entrez Configuration ---
# NCBI requires a registered email address for identification and adherence to rate limits.
# Replace this placeholder with your actual email address.
Entrez.email = "your.email@example.org" 
# Optionally, set your API key if you have registered one for higher throughput.
# Entrez.api_key = "YOUR_NCBI_API_KEY" 

# --- 2. Define Search Parameters ---
DATABASE = "pubmed"
# Complex query: Search for articles discussing 'CRISPR' that are specifically tagged as a 'review' publication type [pt].
SEARCH_TERM = "CRISPR AND review[pt]" 
MAX_RECORDS = 5 # Limit the initial retrieval to the first 5 UIDs

print(f"--- Starting Entrez Search ---")
print(f"Database Target: {DATABASE}")
print(f"Query String: '{SEARCH_TERM}'\n")

# --- 3. Execute the Search Query (esearch) ---
try:
    # Entrez.esearch sends the query to the NCBI server.
    # It returns a handle (a file-like object containing the XML response).
    search_handle = Entrez.esearch(
        db=DATABASE,
        term=SEARCH_TERM,
        retmax=MAX_RECORDS,
        usehistory="y" # Crucial for large queries: stores the full result set on the server
    )
    
    # --- 4. Parse the XML Response ---
    # Entrez.read parses the XML handle into a standard Python dictionary structure.
    search_record = Entrez.read(search_handle)
    
    # Always close the handle after reading to free system resources and connections.
    search_handle.close() 

    # --- 5. Extract and Display Results ---
    
    # The 'Count' field stores the total number of records found globally.
    total_count = int(search_record["Count"])
    
    # The 'IdList' contains the actual UIDs retrieved based on the 'retmax' parameter.
    retrieved_ids = search_record["IdList"]

    print(f"Search Successful.")
    print(f"Total records found matching '{SEARCH_TERM}': {total_count:,}")
    print(f"Retrieved UIDs (first {len(retrieved_ids)}):")
    pprint(retrieved_ids)
    
    # Displaying Web Environment details (useful for subsequent large downloads)
    web_env = search_record["WebEnv"]
    query_key = search_record["QueryKey"]
    print(f"\nWeb Environment (WebEnv): {web_env}")
    print(f"Query Key (QueryKey): {query_key}")


except Exception as e:
    print(f"An error occurred during Entrez access: {e}")

print("\n--- Search Complete ---")

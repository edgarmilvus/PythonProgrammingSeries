
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

#!/usr/bin/env python3
# entrez_protein_miner.py

import os
import time
from Bio import Entrez
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord

# --- Configuration Constants ---
# NOTE: Replace with your actual email and API Key for production use.
# Entrez requires an email for identification and API key for higher rate limits.
ENTREZ_EMAIL = "your.email@example.com"     # Mandatory for Entrez
ENTREZ_API_KEY = "YOUR_NCBI_API_KEY"        # Highly recommended for performance
OUTPUT_FILENAME = "p53_related_proteins.fasta"
SEARCH_TERM = "p53 signaling pathway AND Homo sapiens[ORGN]"
DATABASE = "protein"
BATCH_SIZE = 500                            # Maximum UIDs per Efetch request
WAIT_TIME_SECONDS = 0.5                     # Pause between large batches (rate limit safety)

def configure_entrez():
    """Sets the global Entrez configuration parameters (email and API key)."""
    if ENTREZ_API_KEY == "YOUR_NCBI_API_KEY":
        print("WARNING: Using default API key placeholder. Rate limits may be strict.")
    Entrez.email = ENTREZ_EMAIL
    Entrez.api_key = ENTREZ_API_KEY

def search_database(db_name: str, term: str) -> list:
    """
    Performs an Entrez search (esearch) and returns a list of unique identifiers (UIDs).
    
    Uses usehistory='y' and a large retmax to ensure all results are theoretically retrieved,
    though we rely on the IdList for immediate processing.
    """
    print(f"--- Searching {db_name} for term: '{term}' ---")
    uids = []
    try:
        # retmax is set high to retrieve all UIDs in the IdList in one go if possible
        handle = Entrez.esearch(db=db_name, term=term, usehistory="y", retmax="1000000")
        record = Entrez.read(handle)
        handle.close()
        
        count = int(record["Count"])
        uids = record["IdList"]
        
        print(f"Found {len(uids)} UIDs (Total theoretical count: {count}).")
        if len(uids) < count:
             print("Note: Dataset exceeds 1 million records. Using WebEnv/QueryKey is recommended.")
        return uids
        
    except Exception as e:
        print(f"An error occurred during search: {e}")
        return []

def fetch_records_in_batches(db_name: str, uids: list, output_file: str):
    """
    Fetches records (efetch) in defined batches (BATCH_SIZE) and writes them 
    directly to a file to manage memory and API load.
    """
    total_uids = len(uids)
    if total_uids == 0:
        print("No UIDs to fetch. Exiting.")
        return

    print(f"\n--- Starting fetch and writing to {output_file} (Batch Size: {BATCH_SIZE}) ---")
    
    fetched_count = 0
    
    # Open the output file for writing (will overwrite existing content)
    with open(output_file, "w") as out_handle:
        
        # Iterate through the UID list in steps equal to the BATCH_SIZE
        for i in range(0, total_uids, BATCH_SIZE):
            batch_uids = uids[i : i + BATCH_SIZE]
            # Entrez.efetch requires a comma-separated string of IDs
            uid_string = ",".join(batch_uids)
            
            print(f"Processing batch {i//BATCH_SIZE + 1}: UIDs {i+1} to {min(i + BATCH_SIZE, total_uids)}...")
            
            try:
                # Efetch request: db=protein, rettype=fasta, retmode=text
                handle = Entrez.efetch(
                    db=db_name,
                    id=uid_string,
                    rettype="fasta",
                    retmode="text"
                )
                
                # Read the raw text data (FASTA format) and write it immediately
                fasta_data = handle.read()
                out_handle.write(fasta_data)
                handle.close()
                
                fetched_count += len(batch_uids)
                
                # Implement rate limiting pause if more batches are pending
                if i + BATCH_SIZE < total_uids:
                    time.sleep(WAIT_TIME_SECONDS)
                    
            except Exception as e:
                print(f"CRITICAL ERROR fetching batch starting at index {i}: {e}. Skipping batch.")
                # Log the specific UIDs that failed if necessary for later manual retrieval
                
    print(f"\nSuccessfully fetched {fetched_count} records.")
    print(f"Data saved to {os.path.abspath(output_file)}")


def main():
    """Main execution function to coordinate Entrez operations."""
    
    # 1. Initialize Entrez settings
    configure_entrez()
    
    # 2. Execute the search query
    protein_uids = search_database(DATABASE, SEARCH_TERM)
    
    if not protein_uids:
        print("Search failed or returned no results. Terminating.")
        return
        
    # 3. Download and save sequences in optimized batches
    fetch_records_in_batches(DATABASE, protein_uids, OUTPUT_FILENAME)

if __name__ == "__main__":
    main()

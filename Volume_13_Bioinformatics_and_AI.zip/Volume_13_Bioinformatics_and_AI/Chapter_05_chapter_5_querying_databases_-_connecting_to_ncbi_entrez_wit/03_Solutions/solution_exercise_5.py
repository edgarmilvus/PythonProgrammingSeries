
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

#!/usr/bin/env python3
# Script: ncbi_robust_query.py
# Purpose: Demonstrates robust Entrez configuration management and HTTP error handling.

import os
import sys
from Bio import Entrez
from urllib.error import HTTPError 

def run_ncbi_query():
    """
    Configures Entrez using environment variables and executes a search 
    with robust error handling.
    """
    
    # 2. Configuration Management: Read from environment variables
    ncbi_email = os.environ.get("NCBI_EMAIL")
    ncbi_api_key = os.environ.get("NCBI_API_KEY")

    if not ncbi_email or not ncbi_api_key:
        print("ERROR: Configuration missing.")
        print("Please set the environment variables NCBI_EMAIL and NCBI_API_KEY before running.")
        sys.exit(1) # Exit gracefully if configuration is missing

    Entrez.email = ncbi_email
    Entrez.api_key = ncbi_api_key
    
    database = "nucleotide"
    query = "human insulin gene"

    print(f"Configuration loaded. Attempting search for '{query}' in {database}...")

    # 3. Query Execution and 5. Exception Catching
    try:
        # Execute the search (retmax=1 to test connectivity)
        handle = Entrez.esearch(
            db=database,
            term=query,
            retmax="1"
        )
        record = Entrez.read(handle)
        handle.close()

        count = record["Count"]
        print(f"\nSUCCESS: Connection established and query successful.")
        print(f"Total records found: {count}")

    # Catch HTTPError, which is raised for 400/401/403 (invalid key) or 429 (rate limit)
    except HTTPError as e:
        # 6. Graceful Recovery
        print("\n--- API Connection Failure ---")
        print(f"ERROR: Entrez request failed with HTTP status code {e.code}.")
        print("This usually indicates an invalid API key or rate limiting.")
        print("Please verify your credentials and try again later.")
        sys.exit(1) # Exit cleanly after reporting the failure
        
    except Exception as e:
        print(f"\nAn unexpected error occurred: {e}")
        sys.exit(1)

if __name__ == "__main__":
    run_ncbi_query()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from Bio import Entrez

# --- Configuration ---
Entrez.email = "your.email@example.com"
Entrez.api_key = "YOUR_NCBI_API_KEY"

# 1. Initial Search
gene_id = "7157" # Human p53
source_db = "gene"
target_db = "protein"

print(f"Linking Gene ID {gene_id} (Source: {source_db}) to Target: {target_db}...")

# 2. Linking Function
try:
    # Use elink to find related IDs. dbfrom is the source database, db is the target.
    handle = Entrez.elink(
        dbfrom=source_db,
        db=target_db,
        id=gene_id
    )
    record = Entrez.read(handle)
    handle.close()

    linked_protein_ids = []

    # 3. Result Parsing
    # The result is a list of LinkSets. We look for the LinkSetDb that points to 'protein'.
    if record[0].get("LinkSetDb"):
        # We assume the first LinkSetDb entry is the one we want
        link_data = record[0]["LinkSetDb"][0]
        
        # Extract the IDs from the 'Link' list within the LinkSetDb
        linked_protein_ids = [link["Id"] for link in link_data["Link"]]
    
    # 4. Output
    total_count = len(linked_protein_ids)
    print(f"\nTotal linked protein accessions found: {total_count}")
    
    if total_count > 0:
        print("First 5 linked accessions:")
        for i, acc in enumerate(linked_protein_ids[:5]):
            print(f"  {i+1}. {acc}")
    else:
        print("No linked accessions found.")

except Exception as e:
    print(f"An error occurred during the Entrez linking process: {e}")

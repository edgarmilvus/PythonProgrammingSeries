
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from Bio import Entrez
from Bio import SeqIO
import io

# --- Configuration ---
Entrez.email = "your.email@example.com"
Entrez.api_key = "YOUR_NCBI_API_KEY"

# 1. UID List
accessions = ['U00096.3', 'AP009048.1', 'CP009273.1']
id_list = ",".join(accessions)
database = "nucleotide"

print(f"Attempting to fetch {len(accessions)} records from {database}...")

try:
    # 2. Batch Fetching and 3. Format Specification
    # rettype='fasta' ensures the output is in FASTA format
    handle = Entrez.efetch(
        db=database,
        id=id_list,
        rettype='fasta', 
        retmode='text'
    )

    # 4. Parsing and Validation using SeqIO
    records_fetched = 0
    
    # SeqIO.parse reads the file handle returned by efetch and interprets it as FASTA
    for record in SeqIO.parse(handle, "fasta"):
        print("-" * 50)
        print(f"Accession ID: {record.id}")
        print(f"Description (Header): {record.description}")
        print(f"Sequence Length: {len(record.seq)}")
        # Print the first 50 characters for integrity check
        print(f"First 50 characters: {str(record.seq)[:50]}...")
        records_fetched += 1
    
    handle.close()
    
    print("-" * 50)
    print(f"Successfully retrieved and validated {records_fetched} records.")

except Exception as e:
    print(f"An error occurred during data retrieval: {e}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from Bio import Entrez
import math

# --- Configuration ---
Entrez.email = "your.email@example.com"
Entrez.api_key = "YOUR_NCBI_API_KEY"

# 1. Initial Search Simulation
TOTAL_UIDS_TO_RETRIEVE = 50000
database = "gene"
search_term = "kinase"

# 2. Batch Parameters
BATCH_SIZE = 10000
master_uid_list = []
current_start = 0
iteration = 1
num_batches = math.ceil(TOTAL_UIDS_TO_RETRIEVE / BATCH_SIZE)

print(f"Starting retrieval of {TOTAL_UIDS_TO_RETRIEVE} UIDs in {num_batches} batches...")

# 3. Iterative Retrieval Logic
while current_start < TOTAL_UIDS_TO_RETRIEVE:
    
    # 6. Progress Tracking
    start_display = current_start + 1
    end_display = min(current_start + BATCH_SIZE, TOTAL_UIDS_TO_RETRIEVE)
    print(f"\n--- Batch {iteration}/{num_batches}: Retrieving UIDs {start_display} to {end_display} ---")

    try:
        # 4. Loop Body: Execute esearch with dynamic retstart
        handle = Entrez.esearch(
            db=database,
            term=search_term,
            retmax=BATCH_SIZE,  # Maximum UIDs to return in this batch
            retstart=current_start # Starting offset for this batch
        )
        record = Entrez.read(handle)
        handle.close()

        current_batch_uids = record["IdList"]
        
        # 5. UID Accumulation
        master_uid_list.extend(current_batch_uids)
        
        print(f"  > Retrieved {len(current_batch_uids)} UIDs.")
        
        # Update the starting point for the next iteration
        current_start += BATCH_SIZE
        iteration += 1

    except Exception as e:
        print(f"Error during batch retrieval at start position {current_start}: {e}")
        break

# 7. Final Validation
print("\n" + "="*50)
print(f"Batch retrieval complete.")
print(f"Total UIDs accumulated: {len(master_uid_list)}")
print("="*50)

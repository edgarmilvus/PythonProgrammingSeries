
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import requests
import json
import time
from pathlib import Path
from typing import Dict, Any, List, Optional

# --- Configuration: API Endpoints and Parameters ---
ESMFOLD_API_URL = "https://api.esmfolds.org/v1/predict"
ESMFOLD_STATUS_URL = "https://api.esmfolds.org/v1/status/"
ESMFOLD_RETRIEVE_URL = "https://api.esmfolds.org/v1/retrieve/"
OUTPUT_DIR = Path("./esmf_predictions")
POLLING_INTERVAL_SECONDS = 15 # Time to wait between status checks

# Example sequences: Wild-type (WT), a point mutant, and a longer paralog
PROTEIN_VARIANTS = {
    "WT_Regulatory_Domain": "MGSSHHHHHHSSGLVPRGSHMHHHHHHSSGLVPRGSHMGKAAAKEFERQHMDSST",
    "Mutant_D10A": "MGSSHHHHHHSSGLVPRGSHMHHHHHHSSGLVPRGSHMGKAAAKEFERQHMASST", # Aspartic Acid (D) -> Alanine (A) substitution
    "Paralog_Long_Chain": "MGKAAAKEFERQHMDSSTKAAAKEFERQHMDSSTKAAAKEFERQHMDSSTKAAAKEFERQHMDSST", 
}

def submit_prediction_job(name: str, sequence: str) -> Optional[str]:
    """
    Submits a single amino acid sequence to the ESMFold API asynchronously.
    Returns the job ID required for subsequent polling.
    """
    print(f"[{name}] Submitting sequence ({len(sequence)} residues)...")
    payload = {"sequence": sequence}
    
    try:
        # Send the sequence via POST request
        response = requests.post(ESMFOLD_API_URL, json=payload, timeout=45)
        response.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)
        
        # Extract the job_id from the JSON response
        job_id = response.json().get("job_id")
        if not job_id:
            raise ValueError("API response missing job_id after successful submission.")
            
        print(f"[{name}] Submission successful. Job ID: {job_id}")
        return job_id
        
    except requests.exceptions.RequestException as e:
        print(f"[{name}] ERROR during submission: {type(e).__name__} - {e}")
        return None

def get_structure_and_score(name: str, job_id: str) -> Optional[Path]:
    """
    Polls the API status using the job_id and retrieves the PDB file upon completion.
    Implements necessary time delays to avoid overwhelming the server.
    """
    pdb_path = OUTPUT_DIR / f"{name}_predicted.pdb"
    
    while True:
        status_url = ESMFOLD_STATUS_URL + job_id
        
        try:
            status_response = requests.get(status_url, timeout=10)
            status_response.raise_for_status()
            status_data = status_response.json()
            status = status_data.get("status")
        except requests.exceptions.RequestException as e:
            print(f"[{name}] Polling ERROR: {e}. Retrying after delay.")
            time.sleep(POLLING_INTERVAL_SECONDS)
            continue
        
        if status == "COMPLETED":
            print(f"[{name}] Job completed. Retrieving PDB...")
            retrieve_url = ESMFOLD_RETRIEVE_URL + job_id
            
            # Final retrieval request
            pdb_response = requests.get(retrieve_url)
            pdb_response.raise_for_status()
            
            # Save the PDB content using Pathlib
            pdb_path.write_text(pdb_response.text)
            print(f"[{name}] PDB successfully saved to: {pdb_path.name}")
            return pdb_path
        
        elif status in ["PENDING", "RUNNING", "QUEUED"]:
            print(f"[{name}] Status: {status}. Waiting {POLLING_INTERVAL_SECONDS}s...")
            time.sleep(POLLING_INTERVAL_SECONDS)
        
        elif status == "FAILED":
            print(f"[{name}] CRITICAL ERROR: Job failed on the server side. Aborting retrieval.")
            return None
        
        else:
            print(f"[{name}] Unexpected status received: {status}. Aborting.")
            return None

def calculate_average_plddt(pdb_path: Path) -> float:
    """
    Parses the PDB file to extract and average the pLDDT scores. 
    pLDDT is stored in the B-factor (temperature factor) column (columns 61-66).
    """
    if not pdb_path.exists():
        return 0.0
    
    plddt_scores = []
    
    with pdb_path.open('r') as f:
        for line in f:
            # PDB files use fixed-width columns. We only analyze ATOM records.
            if line.startswith("ATOM"):
                try:
                    # Extract the B-factor field (pLDDT score)
                    # Standard PDB format: B-factor is 6 columns wide (61-66)
                    plddt_str = line[60:66].strip() 
                    if plddt_str:
                        plddt_scores.append(float(plddt_str))
                except (ValueError, IndexError):
                    # Robust handling for poorly formatted lines, though rare in ESMFold output
                    continue
                    
    if not plddt_scores:
        return 0.0
        
    return sum(plddt_scores) / len(plddt_scores)

def main_workflow():
    """Orchestrates the entire batch prediction and analysis process."""
    print("Initializing ESMFold Batch Processor...")
    OUTPUT_DIR.mkdir(exist_ok=True)
    results = {}
    
    # 1. Submission Phase: Submit all jobs and collect IDs
    job_ids = {}
    for name, seq in PROTEIN_VARIANTS.items():
        # Basic sequence validation (e.g., maximum length check could be added here)
        job_id = submit_prediction_job(name, seq)
        if job_id:
            job_ids[name] = job_id
            
    print("\n" + "="*50)
    print("Starting Polling and Retrieval Phase...")
    print("="*50 + "\n")
    
    # 2. Retrieval and Assessment Phase (Sequential polling for simplicity)
    for name, job_id in job_ids.items():
        pdb_file = get_structure_and_score(name, job_id)
        
        if pdb_file:
            # 3. Quality Assessment using pLDDT
            avg_plddt = calculate_average_plddt(pdb_file)
            
            # Store results
            results[name] = {
                "sequence_length": len(PROTEIN_VARIANTS[name]),
                "plddt": round(avg_plddt, 2),
                "pdb_path": str(pdb_file.resolve())
            }
        
    # 4. Final Reporting and Interpretation
    print("\n" + "="*50)
    print("Final Prediction Summary & Comparative Analysis")
    print("="*50)
    
    for name, data in results.items():
        print(f"| Protein: {name:<25} | Length: {data['sequence_length']:<4} | Avg pLDDT: {data['plddt']:<5} |")
        
    # Example Interpretation: Comparing WT and Mutant confidence
    if "WT_Regulatory_Domain" in results and "Mutant_D10A" in results:
        wt_score = results["WT_Regulatory_Domain"]["plddt"]
        mutant_score = results["Mutant_D10A"]["plddt"]
        
        # Bioinformatics Interpretation Logic
        if mutant_score < wt_score * 0.95: 
             print(f"\n[Structural Hypothesis] The Mutant D10A ({mutant_score}) pLDDT score is significantly lower than the WT ({wt_score}). This drop in confidence suggests the substitution at position 10 may destabilize the local fold or introduce a highly flexible region, warranting further experimental validation.")
        else:
             print(f"\n[Structural Hypothesis] The predicted confidence scores (WT: {wt_score}, Mutant: {mutant_score}) are comparable, suggesting the D10A substitution is likely tolerated without major structural disruption.")


if __name__ == "__main__":
    main_workflow()

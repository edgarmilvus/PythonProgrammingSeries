
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import requests
import json
import os
from typing import Dict, Any

# --- 1. Configuration: API Endpoint and Sequence Definition ---
# NOTE: This URL is a placeholder designed to mimic a typical REST API endpoint
# for a large model service like ESMFold. In production, this must be replaced
# with the actual, authenticated endpoint provided by Meta AI or your institution.
ESMFOLD_API_URL: str = "https://api.meta-ai.com/v1/esmfold/predict"

# CRITICAL: Replace this placeholder with your actual, secured API key.
API_KEY: str = "YOUR_SECURE_API_KEY_12345" 

# The amino acid sequence (16 residues) to be folded.
AMINO_ACID_SEQUENCE: str = "GLFDIVKKVVGAFGSL" 

# --- 2. Prepare Request Data: Headers and Payload ---
# Headers define the metadata for the HTTP request.
headers: Dict[str, str] = {
    # Inform the server that the body of the request is formatted as JSON
    "Content-Type": "application/json",
    # Standard security practice: Authorize the request using a Bearer Token
    "Authorization": f"Bearer {API_KEY}" 
}

# The payload contains the specific data the ESMFold model needs.
payload: Dict[str, Any] = {
    "sequence": AMINO_ACID_SEQUENCE,
    "model": "ESMFold_v1", # Explicitly request the desired model version
    "output_format": "pdb" # Requesting the direct PDB file content string
}

print(f"Starting prediction for {len(AMINO_ACID_SEQUENCE)}-mer peptide.")
print("-" * 40)

# --- 3. Execute the API Call and Error Handling ---
try:
    # Send the POST request. The data must be serialized into a JSON string.
    response = requests.post(
        url=ESMFOLD_API_URL, 
        headers=headers, 
        data=json.dumps(payload), # Convert Python dictionary to JSON string
        timeout=45 # Set a generous timeout (in seconds) for the network operation
    )
    
    # Pythonic error checking: Raises an HTTPError for 4XX/5XX status codes
    response.raise_for_status() 
    
    # --- 4. Process the Response ---
    # Parse the successful JSON response into a Python dictionary
    prediction_result = response.json()
    
    # The API returns the PDB content as a single, large string under a specific key
    # NOTE: We are mocking this key based on typical API design patterns.
    pdb_content: str = prediction_result.get("predicted_structure_pdb") 
    
    if pdb_content and len(pdb_content) > 100: # Check if structure data was returned
        output_filename: str = f"esmfold_prediction_{len(AMINO_ACID_SEQUENCE)}mer.pdb"
        
        # Use a context manager (`with open`) for safe and efficient file writing
        with open(output_filename, 'w') as outfile:
            outfile.write(pdb_content)
            
        # --- 5. Confirmation and Summary ---
        print("\n[SUCCESS] Structure prediction complete.")
        print(f"HTTP Status Code: {response.status_code}")
        print(f"Output saved to: {output_filename}")
        print(f"PDB Data Preview (First 4 lines):\n{pdb_content.splitlines()[0:4]}")
        
    else:
        print("\n[WARNING] Prediction successful, but structure data was empty.")
        print(f"Received keys: {prediction_result.keys()}")

# --- 6. Detailed Exception Handling ---
except requests.exceptions.HTTPError as http_err:
    # Handles client-side (4XX) or server-side (5XX) errors
    print(f"\n[HTTP ERROR] Status {response.status_code}: {http_err}")
    print(f"Server response details: {response.text}")
except requests.exceptions.RequestException as req_err:
    # Handles network issues (DNS failure, connection refused, timeout)
    print(f"\n[CONNECTION ERROR] Failed to connect to API: {req_err}")
except json.JSONDecodeError:
    # Handles cases where the server returns non-JSON data (e.g., plain error text)
    print(f"\n[PARSING ERROR] Failed to decode JSON response.")
    print(f"Raw response text: {response.text[:500]}...")
except Exception as e:
    # Catch-all for unexpected Python errors
    print(f"\n[GENERAL ERROR] An unexpected error occurred: {e}")


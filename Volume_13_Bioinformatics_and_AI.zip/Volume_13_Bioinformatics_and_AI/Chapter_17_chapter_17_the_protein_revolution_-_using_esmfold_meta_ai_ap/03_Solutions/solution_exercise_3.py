
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import time
import json
import re
from pathlib import Path
from datetime import datetime, timezone
import requests # For exception references

# --- Re-import/re-define necessary components ---
class SequenceTooLongError(ValueError): pass
# Mock prediction function simulating network delay
def predict_esmf_structure_timed(sequence: str, api_key: str) -> str:
    simulated_delay = 2.5 # seconds
    time.sleep(simulated_delay) 
    return f"HEADER PDB CONTENT for {sequence[:10]}... (Delay: {simulated_delay}s)"

def sanitize_name(name: str) -> str:
    """Sanitizes a string for use as a directory name."""
    sanitized = name.strip().replace(' ', '_')
    return re.sub(r'[^\w_.-]', '', sanitized)[:50]

def interactive_prediction_workflow(api_key: str, base_output_dir: str = "PDB_OUTPUT"):
    """
    Interactive workflow for single-sequence prediction and metadata storage.
    """
    print("--- ESMFold Interactive Prediction Tool ---")
    
    # 1. Interactive Input
    sequence = input("Enter the amino acid sequence: ").strip().upper()
    project_name = input("Enter a project name/ID for this sequence: ").strip()
    
    # (Validation steps from Ex 1 would be placed here, omitted for brevity)

    # Setup directories
    sanitized_name = sanitize_name(project_name)
    project_path = Path(base_output_dir) / sanitized_name
    project_path.mkdir(parents=True, exist_ok=True)
    
    print(f"\nStarting prediction for '{sanitized_name}'...")
    
    # 2. Timing the Prediction
    start_time = time.monotonic()
    pdb_data = None
    
    try:
        pdb_data = predict_esmf_structure_timed(sequence, api_key)
        
    except Exception as e:
        print(f"Prediction failed: {e}")
        return
        
    end_time = time.monotonic()
    duration = end_time - start_time
    
    # 3. Metadata Generation
    metadata = {
        "sequence_id": sanitized_name,
        "sequence_length": len(sequence),
        "prediction_duration_seconds": round(duration, 3),
        "date_predicted": datetime.now(timezone.utc).isoformat(),
        "esmf_model_version": "ESMFold_v1.0",
        "confidence_score_placeholder": 0.95, 
    }
    
    # 4. Structured Output (PDB and JSON)
    pdb_file_path = project_path / "structure.pdb"
    metadata_file_path = project_path / "metadata.json"
    
    # Save PDB using context manager
    with open(pdb_file_path, 'w') as f:
        f.write(pdb_data)
        
    # Save Metadata as JSON using context manager
    with open(metadata_file_path, 'w') as f:
        json.dump(metadata, f, indent=4)
        
    # 5. Reporting
    print("\n--- Prediction Complete ---")
    print(f"Time Elapsed: {duration:.3f} seconds")
    print(f"Files saved in: {project_path.resolve()}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import requests
from typing import Set

# --- Custom Exception ---
class SequenceTooLongError(ValueError):
    """Raised when the sequence exceeds the maximum allowed length."""
    pass

# --- Constants ---
MAX_SEQUENCE_LENGTH = 700
# Standard IUPAC amino acid codes
STANDARD_AMINO_ACIDS: Set[str] = set("ACDEFGHIKLMNPQRSTVWY")
ESMFOLD_API_URL = "https://api.meta.ai/esmf/predict" # Simulated endpoint

def predict_esmf_structure(sequence: str, api_key: str) -> str:
    """
    Validates the sequence and attempts to predict the protein structure using ESMFold.
    
    Args:
        sequence: The amino acid sequence string.
        api_key: The Meta AI API key.
        
    Returns:
        The raw PDB content string if successful.
        
    Raises:
        ValueError: If the sequence contains invalid characters.
        SequenceTooLongError: If the sequence exceeds MAX_SEQUENCE_LENGTH.
        requests.HTTPError: For API errors (401, 429, 500, etc.).
    """
    sequence = sequence.upper().strip()
    
    # 1. Length Constraint Enforcement
    if len(sequence) > MAX_SEQUENCE_LENGTH:
        raise SequenceTooLongError(
            f"Sequence length ({len(sequence)}) exceeds limit of {MAX_SEQUENCE_LENGTH} residues."
        )
        
    # 2. Sequence Character Validation
    invalid_chars = set(sequence) - STANDARD_AMINO_ACIDS
    if invalid_chars:
        raise ValueError(
            f"Sequence contains invalid amino acid characters: {', '.join(sorted(invalid_chars))}. "
        )

    # 3. API Key Management and Request Setup
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "Accept": "application/x-pdb" 
    }
    
    payload = {"sequence": sequence}
    
    try:
        # 4. Execute the API call
        response = requests.post(
            ESMFOLD_API_URL, 
            headers=headers, 
            json=payload, 
            timeout=60 # Network timeout
        )
        
        # 5. Basic HTTP Error Handling
        # This checks for 4xx and 5xx errors
        response.raise_for_status() 
        
        # If successful (200-299), return the PDB content
        return response.text
        
    except requests.exceptions.RequestException as e:
        # Catch network errors, timeouts, and general HTTP errors raised by raise_for_status()
        if hasattr(e, 'response') and e.response is not None:
            if e.response.status_code == 401:
                raise requests.HTTPError("401 Unauthorized: API key is invalid or expired.", response=e.response)
            if e.response.status_code == 429:
                raise requests.HTTPError("429 Too Many Requests: Rate limit exceeded.", response=e.response)
        
        # Re-raise the exception for the caller to handle
        raise

# NOTE: The actual requests.post call is simulated for testing environment purposes.

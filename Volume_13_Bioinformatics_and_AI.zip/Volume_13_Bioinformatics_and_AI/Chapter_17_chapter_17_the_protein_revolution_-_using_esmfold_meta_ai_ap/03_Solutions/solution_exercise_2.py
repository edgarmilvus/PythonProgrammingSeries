
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import re
from pathlib import Path
from datetime import datetime
import requests # Needed for exception handling

# Assuming predict_esmf_structure and SequenceTooLongError are available from Ex 1

# --- Helper Functions (Imported/Defined for context) ---
class SequenceTooLongError(ValueError): pass
# Define a mock prediction function for demonstration purposes
def predict_esmf_structure(sequence: str, api_key: str) -> str:
    if "FAIL_401" in sequence:
        raise requests.HTTPError("Simulated 401 Unauthorized Error")
    if "FAIL_CHAR" in sequence:
        raise ValueError("Simulated Invalid Character Error")
    if len(sequence) > 700:
        raise SequenceTooLongError("Simulated Sequence Too Long Error")
    return f"HEADER PDB CONTENT for {sequence[:10]}..."

def parse_fasta(fasta_path: Path):
    """Parses a multi-sequence FASTA file."""
    sequences = {}
    current_id = None
    current_sequence = []
    
    # Use 'with' statement for robust file reading
    with open(fasta_path, 'r') as f:
        for line in f:
            line = line.strip()
            if line.startswith('>'):
                if current_id:
                    sequences[current_id] = "".join(current_sequence)
                current_id = line[1:].strip()
                current_sequence = []
            else:
                current_sequence.append(line.upper().replace(' ', ''))
        if current_id:
            sequences[current_id] = "".join(current_sequence)
    return sequences

def sanitize_filename(header: str) -> str:
    """Sanitizes a FASTA header for safe use as a filename."""
    sanitized = header.replace('|', '_').replace(' ', '_')
    # Remove any character that is not alphanumeric, underscore, or hyphen
    return re.sub(r'[^\w.-]', '', sanitized)

def run_batch_prediction(fasta_file: str, api_key: str, output_dir: str):
    """Executes the sequential batch prediction workflow."""
    fasta_path = Path(fasta_file)
    output_path = Path(output_dir)
    log_path = output_path / "batch_log.txt"
    
    # Create output directory using pathlib
    output_path.mkdir(parents=True, exist_ok=True)
    
    sequences_data = parse_fasta(fasta_path)
    
    # Open log file using 'with' statement for guaranteed closing
    with open(log_path, 'w') as log_file:
        log_file.write(f"ID\tSTATUS\tLENGTH\tERROR_MESSAGE\n")
        
        for seq_id, sequence in sequences_data.items():
            status = "FAILED"
            error_message = ""
            
            try:
                # 1. Prediction attempt
                pdb_data = predict_esmf_structure(sequence, api_key)
                status = "SUCCESS"
                
                # 2. Output Naming and Saving
                filename = sanitize_filename(seq_id) + ".pdb"
                pdb_file_path = output_path / filename
                
                # 3. Write PDB file using 'with' statement
                with open(pdb_file_path, 'w') as pdb_f:
                    pdb_f.write(pdb_data)
                    
            except (SequenceTooLongError, ValueError) as e:
                # Catches local validation failures
                error_message = f"{type(e).__name__}: {e}"
            except requests.HTTPError as e:
                # Catches API failures (401, 429, 500)
                error_message = f"API Error: {e.response.status_code}"
            except Exception as e:
                # Catches unexpected errors (e.g., network timeout)
                error_message = f"Unhandled Error: {type(e).__name__}"
            
            # 4. Write log entry
            log_entry = f"{seq_id}\t{status}\t{len(sequence)}\t{error_message}\n"
            log_file.write(log_entry)
            print(f"[{seq_id}] -> {status}")

# --- Demonstration ---
if __name__ == '__main__':
    test_fasta_content = """
>sp|P00001|SUCCESS_1
MKTIIALSY
>sp|Q99999|FAIL_401_RAT
ABCDEFGHIJ
>sp|P12345|SUCCESS_2
ACDEFGHIKLMNPQRSTVWY
>sp|X00000|INVALID_CHAR_DOG
ACDEFGHIKLMNPQRSTVWYZFAIL_CHAR
>sp|Y99999|TOO_LONG_CAT
A""" + "A" * 701 + """
"""
    TEST_FASTA = Path("test_batch.fasta")
    
    with open(TEST_FASTA, 'w') as f:
        f.write(test_fasta_content.strip())

    run_batch_prediction(str(TEST_FASTA), "DUMMY_KEY", "batch_results_sequential")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import asyncio
import aiohttp
import time
import re
from pathlib import Path
from datetime import datetime

# Assuming aiohttp is installed
# --- Constants ---
CONCURRENCY_LIMIT = 5 
TEST_OUTPUT_ASYNC = "async_batch_results"

# --- Utility Functions (for FASTA parsing and filename sanitization) ---
# (Same as Exercise 2)
def parse_fasta(fasta_path: Path):
    # ... (Implementation omitted for space, assumes it returns {id: sequence})
    sequences = {}
    for i in range(1, 11): # Simulate 10 sequences
        seq_id = f"Seq_{i:02d}|{'FAIL_NETWORK' if i==5 else 'SUCCESS'}"
        sequences[seq_id] = "ACDEFGHIKLMNPQRSTVWY"
    return sequences
def sanitize_filename(header: str) -> str:
    return re.sub(r'[^\w.-]', '', header.replace('|', '_').replace(' ', '_'))

# --- Asynchronous I/O Helper ---
async def async_write_file(filepath: Path, content: str):
    """Writes content to a file in a separate thread to prevent blocking."""
    loop = asyncio.get_running_loop()
    # Use to_thread for Python 3.9+ or run_in_executor for older versions
    await loop.run_in_executor(None, lambda: filepath.write_text(content))

# --- 1. Asynchronous API Coroutine ---
async def async_predict_esmf_structure(session: aiohttp.ClientSession, seq_id: str, sequence: str, api_key: str, semaphore: asyncio.Semaphore, output_path: Path, log_queue: asyncio.Queue):
    """Handles prediction for a single sequence concurrently."""
    status = "FAILED"
    error_message = ""
    start_time = time.monotonic()
    
    # 3. Concurrency Management: Acquire the semaphore
    async with semaphore:
        print(f"[{seq_id}] Starting prediction. Active slots: {CONCURRENCY_LIMIT - semaphore._value}")
        
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "application/x-pdb" 
        }
        payload = {"sequence": sequence}
        
        try:
            # Simulate network delay and API call
            await asyncio.sleep(1 + (hash(seq_id) % 3) / 2) # Variable delay 1.0s to 2.5s

            if "FAIL_NETWORK" in seq_id:
                raise aiohttp.ClientError("Simulated Network Timeout/Error")

            # Actual aiohttp post request would happen here:
            # async with session.post(...) as response:
            #     response.raise_for_status()
            #     pdb_data = await response.text()
            
            pdb_data = f"HEADER PDB CONTENT for {seq_id}"
            
            # 4. Asynchronous File I/O for PDB save
            filename = sanitize_filename(seq_id) + ".pdb"
            pdb_file_path = output_path / filename
            await async_write_file(pdb_file_path, pdb_data)
            
            status = "SUCCESS"
            
        except aiohttp.ClientError as e:
            error_message = f"API/Network Error: {type(e).__name__}: {e}"
        except Exception as e:
            error_message = f"Unhandled Error: {type(e).__name__}: {e}"
            
        finally:
            duration = time.monotonic() - start_time
            print(f"[{seq_id}] Finished. Status: {status} in {duration:.2f}s")
            await log_queue.put((seq_id, status, len(sequence), error_message))


async def async_log_writer(log_path: Path, log_queue: asyncio.Queue, total_tasks: int):
    """Consumer task to write logs asynchronously."""
    with open(log_path, 'w') as log_file:
        log_file.write(f"ID\tSTATUS\tLENGTH\tERROR_MESSAGE\n")
        tasks_completed = 0
        while tasks_completed < total_tasks:
            log_entry = await log_queue.get()
            seq_id, status, length, error_message = log_entry
            log_file.write(f"{seq_id}\t{status}\t{length}\t{error_message}\n")
            log_file.flush()
            log_queue.task_done()
            tasks_completed += 1


async def main_async_processor(fasta_file: str, api_key: str, output_dir: str):
    """Orchestrates the asynchronous execution."""
    start_wall_time = time.monotonic()
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    log_path = output_path / "async_batch_log.txt"

    sequences_data = parse_fasta(Path(fasta_file))
    total_sequences = len(sequences_data)
    semaphore = asyncio.Semaphore(CONCURRENCY_LIMIT)
    log_queue = asyncio.Queue()
    
    log_writer_task = asyncio.create_task(async_log_writer(log_path, log_queue, total_sequences))
    
    async with aiohttp.ClientSession() as session:
        prediction_tasks = [
            async_predict_esmf_structure(session, seq_id, sequence, api_key, semaphore, output_path, log_queue)
            for seq_id, sequence in sequences_data.items()
        ]
        
        # 2. Concurrency Management: Run all tasks simultaneously
        await asyncio.gather(*prediction_tasks)
        
    await log_queue.join()
    await log_writer_task
    
    total_duration = time.monotonic() - start_wall_time
    
    # 5. Performance Comparison Output
    print("\n--- Asynchronous Batch Summary ---")
    print(f"Total Sequences: {total_sequences}")
    print(f"Max Concurrency: {CONCURRENCY_LIMIT}")
    print(f"Total Wall Clock Time: {total_duration:.2f} seconds")

# --- Demonstration ---
if __name__ == '__main__':
    # Execution requires Python 3.7+ and aiohttp
    asyncio.run(main_async_processor("dummy_fasta.fasta", "ASYNC_KEY", TEST_OUTPUT_ASYNC))

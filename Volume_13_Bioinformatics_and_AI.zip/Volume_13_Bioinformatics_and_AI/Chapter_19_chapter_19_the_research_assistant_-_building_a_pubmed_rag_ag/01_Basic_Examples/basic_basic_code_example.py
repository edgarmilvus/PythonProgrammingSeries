
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import os
from Bio import Entrez
from Bio import Medline
from typing import List, Dict

# --- 1. Configuration (NCBI Requirements) ---
# CRITICAL: Entrez requires that you identify yourself by providing an email address.
# Failure to set this will often result in connection errors or immediate rate-limiting.
Entrez.email = "your.research.email@example.com"
DATABASE = "pubmed"
# Define the search query. Using [ti] restricts the search to the Title field.
SEARCH_TERM = "CRISPR Cas9 delivery methods review[ti]" 

def search_and_fetch_abstracts(term: str, db: str = DATABASE, max_records: int = 3) -> List[Dict]:
    """
    Executes a two-step process: 
    1. Searches the specified database (Entrez.esearch) to find relevant IDs.
    2. Fetches the full records (Entrez.efetch) corresponding to those IDs.
    """
    print(f"--- Initiating Search on {db} for: '{term}' ---")

    # Step 1: Perform the search and retrieve IDs (eSearch)
    # retmax specifies the maximum number of records to retrieve.
    # usehistory='y' tells Entrez to store the query result on the NCBI server 
    # for potential later use in large batches, improving reliability.
    search_handle = Entrez.esearch(
        db=db, 
        term=term, 
        retmax=max_records, 
        usehistory='y'
    )
    
    # Entrez.read() parses the XML output from the handle into a Python dictionary.
    search_results = Entrez.read(search_handle)
    search_handle.close()

    # Extract the list of unique PubMed IDs (PMIDs) found
    id_list = search_results["IdList"]
    print(f"Successfully identified {len(id_list)} records. IDs: {', '.join(id_list)}")

    if not id_list:
        return []

    # Step 2: Fetch the full records using the IDs (eFetch)
    # We join the IDs into a comma-separated string, as required by efetch.
    id_string = ",".join(id_list)
    
    fetch_handle = Entrez.efetch(
        db=db,
        id=id_string,
        rettype="medline", # Requesting the standardized Medline format
        retmode="text"     # Returning the raw text output of the Medline format
    )

    # Step 3: Parse the Medline records
    # Medline.parse is a specialized BioPython parser that understands the 
    # Medline record structure (e.g., TI, AB, AU tags).
    records_generator = Medline.parse(fetch_handle)
    
    # Convert the generator into a list of dictionaries for easy processing
    abstract_data = list(records_generator)
    fetch_handle.close()
    
    return abstract_data

# --- Main Execution Block ---
if __name__ == "__main__":
    try:
        # Call the function to retrieve data
        papers = search_and_fetch_abstracts(SEARCH_TERM)

        if papers:
            print("\n--- Summary of Retrieved Data (Ready for RAG) ---")
            for i, paper in enumerate(papers):
                # Medline records use specific two-letter tags as dictionary keys:
                # 'TI': Title, 'AB': Abstract, 'PMID': PubMed ID
                title = paper.get('TI', 'N/A')
                abstract = paper.get('AB', 'N/A')
                pmid = paper.get('PMID', 'N/A')
                
                print(f"\n[{i+1}] PMID: {pmid}")
                print(f"Title: {title}")
                # Print only a snippet of the abstract for brevity
                print(f"Abstract Snippet: {abstract[:180].strip()}...") 
                print("-" * 40)
        else:
            print("Search returned no matching papers.")

    except Exception as e:
        print(f"\n[CRITICAL ERROR] An Entrez or network error occurred: {e}")

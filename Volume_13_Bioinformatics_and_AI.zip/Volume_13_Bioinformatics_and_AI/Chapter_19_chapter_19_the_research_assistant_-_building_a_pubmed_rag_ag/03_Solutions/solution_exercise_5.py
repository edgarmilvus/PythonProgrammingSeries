
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from typing import Dict, Any

# 1. Tool Simulation
def pdb_lookup_tool(identifier: str) -> str:
    """
    Simulates retrieving key structural metadata from the Protein Data Bank (PDB).
    
    Input: PDB ID (e.g., '6LU7') or Protein Name.
    """
    identifier = identifier.upper().strip()
    
    # Simulated database lookup
    PDB_DATA = {
        "6LU7": {
            "protein": "SARS-CoV-2 Main Protease (Mpro)",
            "method": "X-ray Diffraction",
            "resolution": "2.16 Angstroms",
            "chains": 2,
            "ligands": "N3 inhibitor"
        },
        "1A2C": {
            "protein": "Human p53 DNA binding domain",
            "method": "NMR Spectroscopy",
            "resolution": "Not applicable (NMR)",
            "chains": 4,
            "ligands": "Zinc ion"
        }
    }
    
    data = PDB_DATA.get(identifier, None)
    
    if data:
        return (f"PDB ID: {identifier}. Protein: {data['protein']}. "
                f"Experimental Method: {data['method']}. Resolution: {data['resolution']}. "
                f"Chains: {data['chains']}. Key Ligands: {data['ligands']}.")
    else:
        return f"PDB ID or protein '{identifier}' not found in simulated database."

# 2. Tool Integration (Simulated Agent Environment)
# In a real framework (LangChain/LlamaIndex), this would involve wrapping the function 
# with Tool/FunctionCall objects and providing a description.

class AgentTool:
    def __init__(self, func, name, description):
        self.func = func
        self.name = name
        self.description = description

# Define the tools available to the LLM agent
PDB_TOOL = AgentTool(
    func=pdb_lookup_tool,
    name="pdb_lookup_tool",
    description="Tool for retrieving specific structural metadata (resolution, method, ligands) "
                "from the Protein Data Bank (PDB) using a PDB ID or protein name. Use ONLY for structural queries."
)

# Placeholder for the RAG/Text Retrieval Tool (from previous exercises)
RAG_TOOL = AgentTool(
    func=lambda q: "Simulated text context about TP53 and apoptosis...",
    name="pubmed_rag_retriever",
    description="Tool for retrieving textual context (abstracts, summaries) from PubMed literature."
)

def simulate_agent_reasoning(query: str, available_tools: List[AgentTool]) -> Dict[str, Any]:
    """
    Simulates the LLM Agent's reasoning process to select the appropriate tool.
    """
    
    # Simple keyword-based reasoning simulation
    structural_keywords = ['structure', 'resolution', 'PDB', 'method', 'crystal', 'NMR', 'Angstrom']
    
    if any(keyword in query.lower() for keyword in structural_keywords):
        # Decision: Use PDB tool
        tool_to_use = PDB_TOOL
        # Extract identifier (simple heuristic for this test)
        identifier = query.split('(')[-1].split(')')[0].strip() if '(' in query else '6LU7' 
        
        print(f"Agent Reasoning: Structural keywords detected. Selecting {tool_to_use.name}.")
        tool_output = tool_to_use.func(identifier)
        
        return {
            "tool_used": tool_to_use.name,
            "input": identifier,
            "output": tool_output
        }
    else:
        # Decision: Use RAG tool
        tool_to_use = RAG_TOOL
        print(f"Agent Reasoning: Textual/summarization query detected. Selecting {tool_to_use.name}.")
        tool_output = tool_to_use.func(query)
        
        return {
            "tool_used": tool_to_use.name,
            "input": query,
            "output": tool_output
        }

# 3. Selective Use Test
query_a = "Summarize the findings on the role of TP53 in apoptosis."
query_b = "What is the resolution and experimental method used for the structure of the SARS-CoV-2 main protease (6LU7)?"

print("--- Test A: Text-Only Query ---")
result_a = simulate_agent_reasoning(query_a, [PDB_TOOL, RAG_TOOL])
print(f"Result A Tool Used: {result_a['tool_used']}\n")

print("--- Test B: Structural Query ---")
result_b = simulate_agent_reasoning(query_b, [PDB_TOOL, RAG_TOOL])
print(f"Result B Tool Used: {result_b['tool_used']}")
print(f"Result B Tool Output: {result_b['output']}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import time
from Bio import Entrez
import re
from typing import List, Dict

# Set Entrez email for API compliance (required by NCBI)
Entrez.email = "research.assistant@example.edu"
MAX_ENTREZ_WAIT = 0.5  # Respecting rate limits

def fetch_pubmed_abstracts(query: str, max_results: int) -> List[Dict]:
    """Fetches PubMed abstracts safely using Entrez."""
    try:
        # 1. Search for PMIDs
        handle = Entrez.esearch(db="pubmed", term=query, retmax=max_results)
        record = Entrez.read(handle)
        handle.close()
        id_list = record["IdList"]
        
        if not id_list:
            return []

        # Wait to respect rate limits
        time.sleep(MAX_ENTREZ_WAIT)

        # 2. Fetch records (Title and Abstract)
        handle = Entrez.efetch(db="pubmed", id=id_list, retmode="xml")
        records = Entrez.read(handle)
        handle.close()

        results = []
        for pubmed_article in records['PubmedArticle']:
            article = pubmed_article['MedlineCitation']['Article']
            pmid = str(pubmed_article['MedlineCitation']['PMID'])
            title = article.get('ArticleTitle', 'No Title')
            
            abstract_text = ""
            if 'Abstract' in article:
                # Concatenate abstract paragraphs
                abstract_parts = article['Abstract']['AbstractText']
                if isinstance(abstract_parts, list):
                    abstract_text = "\n\n".join(
                        part.get('NlmCategory', '') + ": " + str(part) if part.attributes else str(part)
                        for part in abstract_parts
                    )
                else:
                    abstract_text = str(abstract_parts)
            
            results.append({
                "pmid": pmid,
                "title": title,
                "abstract": abstract_text
            })
        return results

    except Exception as e:
        print(f"An Entrez error occurred: {e}")
        return []

def bio_aware_chunker(text: str, max_tokens: int = 512) -> List[str]:
    """
    Heuristic chunker prioritizing paragraph breaks to maintain biological context.
    
    We simulate token length using character count (approx. 4 chars per token).
    """
    max_chars = max_tokens * 4 
    
    # Primary split: Paragraphs (double newline)
    paragraphs = [p.strip() for p in text.split('\n\n') if p.strip()]
    
    chunks = []
    current_chunk = ""
    
    for paragraph in paragraphs:
        if len(current_chunk) + len(paragraph) + 1 < max_chars:
            # Append paragraph if it fits
            current_chunk += (" " if current_chunk else "") + paragraph
        else:
            # If the current chunk is non-empty, save it
            if current_chunk:
                chunks.append(current_chunk)
            
            # Check if the new paragraph itself exceeds the limit
            if len(paragraph) >= max_chars:
                # Fallback: Split large paragraph by sentence (less ideal, but necessary)
                sentences = re.split(r'(?<=[.?!])\s+', paragraph)
                temp_split_chunk = ""
                for sentence in sentences:
                    if len(temp_split_chunk) + len(sentence) + 1 < max_chars:
                        temp_split_chunk += (" " if temp_split_chunk else "") + sentence
                    else:
                        if temp_split_chunk:
                            chunks.append(temp_split_chunk)
                        temp_split_chunk = sentence # Start new chunk with the sentence
                if temp_split_chunk:
                    chunks.append(temp_split_chunk)
                current_chunk = "" # Reset current chunk
            else:
                # Start a new chunk with the current paragraph
                current_chunk = paragraph
                
    if current_chunk:
        chunks.append(current_chunk)
        
    return chunks

def process_and_chunk_papers(query: str, max_papers: int) -> List[Dict]:
    """Orchestrates retrieval and chunking, returning chunks with source metadata."""
    papers = fetch_pubmed_abstracts(query, max_papers)
    
    all_chunks = []
    for paper in papers:
        chunks = bio_aware_chunker(paper['abstract'])
        for i, chunk in enumerate(chunks):
            all_chunks.append({
                "text": chunk,
                "pmid": paper['pmid'],
                "title": paper['title'],
                "chunk_id": f"{paper['pmid']}-{i}"
            })
            
    return all_chunks

# --- Demonstration ---
# Note: For a runnable example without live Entrez calls, we use mock data.
# The structure above is the required implementation.

# Simulating the output of fetch_pubmed_abstracts for demonstration purposes
MOCK_ABSTRACT = """
Background: The p53 gene (also known as TP53) is a critical tumor suppressor. Mutations in TP53 are found in over half of all human cancers, making it a central target for therapeutic intervention. 

Methods and Results: We investigated the interaction of TP53 with the MDM2 protein in Saccharomyces cerevisiae models. Our assay confirmed that the binding affinity is highly dependent on the phosphorylation status of serine 15. This phosphorylation event is crucial for stabilizing the active conformation of TP53.

Conclusion: Targeting the TP53-MDM2 axis remains a promising strategy. Further research focusing on small molecule inhibitors that mimic phosphorylation is warranted. The standard fixed-size chunking would likely separate the gene name from its functional analysis, losing context.
"""

# Run chunker on mock data
chunks = bio_aware_chunker(MOCK_ABSTRACT, max_tokens=100)

print(f"--- Chunking Test ({len(chunks)} Chunks) ---")
for i, chunk in enumerate(chunks):
    print(f"Chunk {i+1} (Length: {len(chunk)} chars):\n'{chunk[:100]}...'\n")


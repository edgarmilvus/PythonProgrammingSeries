
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import graphviz

# 1. Define the Validation Tool
def validate_nomenclature(text: str) -> str:
    """
    Simulates checking biological terms in a summary against convention.
    
    Checks:
    1. Gene names (e.g., TP53 should be capitalized, not tp53).
    2. Species names (e.g., full binomial nomenclature required on first mention).
    """
    
    feedback = []
    
    # Check 1: Gene name capitalization (TP53 vs tp53)
    if 'tp53' in text.lower() and 'TP53' not in text:
        feedback.append("Nomenclature Error: Gene name 'tp53' should be capitalized as 'TP53' for consistency.")
        
    # Check 2: Species name consistency (e.g., 'yeast' vs 'Saccharomyces cerevisiae')
    if 'yeast' in text.lower() and 'saccharomyces cerevisiae' not in text.lower():
        feedback.append("Clarity Suggestion: 'Yeast' should be replaced or supplemented with the full species name, 'Saccharomyces cerevisiae', on first mention.")

    if not feedback:
        return "Validation successful. Nomenclature appears consistent with standard biological conventions."
    else:
        return "Validation required corrections:\n" + "\n".join(feedback)

# 2. Modified Agent Prompt (Simulated Instruction)
MODIFIED_SYSTEM_PROMPT = """
You are a specialized Bioinformatics Agent. Your task is to summarize scientific literature with high fidelity.
Follow these mandatory four steps strictly:

1. SUMMARIZE: Generate a concise, 3-sentence summary of the provided text/context.
2. VALIDATE: Call the `validate_nomenclature` tool on your initial summary.
3. CRITIQUE & REFINE: Analyze the tool's output. If errors are found, critique your initial summary and describe the necessary revision.
4. FINAL OUTPUT: Provide the final, corrected summary. Do not output any intermediate steps (1-3) except the final refined text.
"""

# 3. Visualize the New Reasoning Flow (Graphviz DOT Code)
DOT_CODE = """
digraph G {
    rankdir=LR;
    node [shape=box, style="filled", fillcolor="#E0F7FA", fontname="Arial"];
    
    A [label="1. Context Retrieval (RAG)", fillcolor="#BBDEFB"];
    B [label="2. Initial Summary Generation (LLM)"];
    C [label="3. Use Tool: validate_nomenclature", fillcolor="#C8E6C9"];
    D [label="4. Critique & Refine Summary (LLM)", fillcolor="#FFF9C4"];
    E [label="5. Final Output (Refined Summary)", fillcolor="#81C784"];
    
    A -> B [label="Context"];
    B -> C [label="Initial Summary"];
    C -> D [label="Tool Output/Feedback"];
    D -> E [label="Final Text"];
    
    {rank=same; C; D;}
    
    subgraph cluster_mandatory_correction {
        label = "Mandatory Biological Self-Correction Loop";
        style = rounded;
        color = "#FF8A65";
        C; D;
    }
}
"""

# Output the Graphviz DOT code block
print("--- Graphviz DOT Code for New Reasoning Flow ---")
print(DOT_CODE)

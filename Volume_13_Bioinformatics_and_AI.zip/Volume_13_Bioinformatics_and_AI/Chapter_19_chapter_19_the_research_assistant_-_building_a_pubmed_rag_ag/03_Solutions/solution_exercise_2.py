
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import hashlib
from typing import List, Dict
import chromadb

# Mock the embedding process since we cannot rely on external APIs/large models
def mock_embedding_function(text: str) -> List[float]:
    """Simulates a fixed-size embedding vector using a simple hash."""
    # Create a deterministic, fixed-length vector (e.g., 8 dimensions)
    hash_object = hashlib.sha256(text.encode())
    hex_digest = hash_object.hexdigest()
    
    # Convert hex to a list of floats (0 to 1)
    vector = [int(hex_digest[i:i+2], 16) / 255.0 for i in range(0, 16, 2)]
    return vector

class GenomicsVectorStore:
    def __init__(self):
        # Initialize ChromaDB in memory for portability
        self.client = chromadb.Client()
        self.collection = self.client.get_or_create_collection(
            name="genomics_index", 
            embedding_function=mock_embedding_function
        )

    def index_chunks(self, chunks: List[str], metadata: List[Dict]):
        """Adds chunks and metadata to the vector index."""
        if len(chunks) != len(metadata):
            raise ValueError("Chunks and metadata lists must have the same length.")
        
        ids = [m['chunk_id'] for m in metadata]
        
        # ChromaDB automatically handles the embedding via the mock_embedding_function
        self.collection.add(
            documents=chunks,
            metadatas=metadata,
            ids=ids
        )
        print(f"Indexed {len(chunks)} documents.")

    def retrieve_context(self, query: str, k: int) -> List[Dict]:
        """Performs semantic similarity search and returns results with metadata."""
        
        results = self.collection.query(
            query_texts=[query],
            n_results=k,
            include=['documents', 'metadatas', 'distances']
        )
        
        retrieved_contexts = []
        if results and results['documents']:
            for doc, meta, dist in zip(results['documents'][0], results['metadatas'][0], results['distances'][0]):
                retrieved_contexts.append({
                    "text": doc,
                    "pmid": meta['pmid'],
                    "title": meta['title'],
                    "distance": dist
                })
        return retrieved_contexts

# --- Demonstration and Testing ---

# 1. Prepare simulated chunks (using the structure from Ex 1)
sample_data = [
    {
        "text": "The mechanism of resistance to EGFR inhibitors, such as gefitinib, is often mediated by secondary mutations. The most common is the T790M mutation in non-small cell lung cancer (NSCLC).",
        "pmid": "34567890",
        "title": "T790M Mutation Drives EGFR Inhibitor Resistance",
        "chunk_id": "34567890-0"
    },
    {
        "text": "We analyzed the structure of wild-type EGFR kinase domain and the T790M mutant. Structural changes prevent inhibitor binding.",
        "pmid": "34567890",
        "title": "T790M Mutation Drives EGFR Inhibitor Resistance",
        "chunk_id": "34567890-1"
    },
    {
        "text": "A separate study focused on the role of TP53 phosphorylation in apoptosis, showing no direct link to EGFR signaling pathways.",
        "pmid": "34567891",
        "title": "TP53 and Apoptosis",
        "chunk_id": "34567891-0"
    }
]

chunks_list = [d['text'] for d in sample_data]
metadata_list = [{k: v for k, v in d.items() if k != 'text'} for d in sample_data]

# 2. Initialize and Index
vector_store = GenomicsVectorStore()
vector_store.index_chunks(chunks_list, metadata_list)

# 3. Test Retrieval with a complex query
genomics_query = "Mechanism of resistance to EGFR inhibitors mediated by T790M mutation in non-small cell lung cancer"
k_results = 2

retrieved = vector_store.retrieve_context(genomics_query, k_results)

print("\n--- Retrieval Results ---")
for i, result in enumerate(retrieved):
    print(f"Result {i+1} (PMID: {result['pmid']}, Title: {result['title']}):")
    print(f"  Distance: {result['distance']:.4f}")
    print(f"  Context: {result['text'][:70]}...\n")

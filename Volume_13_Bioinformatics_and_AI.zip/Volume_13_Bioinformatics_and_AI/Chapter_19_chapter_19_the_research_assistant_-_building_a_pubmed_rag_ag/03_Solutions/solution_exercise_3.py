
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import asyncio
import time
import random
from typing import List, Callable, Awaitable

# Simulate Entrez API latency
def _blocking_pubmed_call(pmid: str) -> str:
    """Simulates a synchronous, blocking network call to fetch an abstract."""
    latency = random.uniform(0.1, 0.4) # Simulated I/O time
    time.sleep(latency)
    return f"Abstract for PMID {pmid} retrieved in {latency:.2f}s."

def synchronous_fetch_abstract(pmid: str) -> str:
    """Blocking I/O implementation."""
    return _blocking_pubmed_call(pmid)

async def async_fetch_abstract(pmid: str) -> str:
    """
    Non-blocking I/O implementation using asyncio.to_thread.
    
    This wraps the blocking function so it runs on a separate thread 
    without blocking the main asyncio event loop.
    """
    # Use asyncio.to_thread to run the synchronous blocking function 
    # in a separate thread, treating it as an awaitable coroutine.
    return await asyncio.to_thread(_blocking_pubmed_call, pmid)

async def benchmark_retrieval(pmids: List[str]):
    """Compares synchronous vs. asynchronous execution time."""
    
    print(f"--- Benchmarking Retrieval for {len(pmids)} PMIDs ---")

    # 1. Synchronous Benchmark
    start_sync = time.perf_counter()
    sync_results = []
    for pmid in pmids:
        sync_results.append(synchronous_fetch_abstract(pmid))
    end_sync = time.perf_counter()
    sync_time = end_sync - start_sync
    
    print(f"\n[Synchronous] Total time: {sync_time:.4f} seconds.")
    # print(sync_results[0]) # Example output

    # 2. Asynchronous Benchmark
    start_async = time.perf_counter()
    
    # Create a list of awaitable coroutines
    tasks = [async_fetch_abstract(pmid) for pmid in pmids]
    
    # Run all tasks concurrently
    async_results = await asyncio.gather(*tasks)
    
    end_async = time.perf_counter()
    async_time = end_async - start_async
    
    print(f"[Asynchronous] Total time: {async_time:.4f} seconds.")
    # print(async_results[0]) # Example output
    
    print(f"\nPerformance Gain: Synchronous is {sync_time/async_time:.2f}x slower.")

# --- Execution ---
if __name__ == "__main__":
    # Generate 10 mock PMIDs
    mock_pmids = [f"PMID{i:04d}" for i in range(1, 11)]
    
    # Run the asynchronous benchmark
    asyncio.run(benchmark_retrieval(mock_pmids))

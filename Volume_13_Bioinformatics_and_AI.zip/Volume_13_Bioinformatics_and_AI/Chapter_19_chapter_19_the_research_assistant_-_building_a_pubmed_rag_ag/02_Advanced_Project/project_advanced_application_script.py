
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
from Bio import Entrez
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import OpenAIEmbeddings
from langchain_openai import ChatOpenAI
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chains import RetrievalQA
from langchain.schema import Document
from typing import List

# --- Configuration and Setup ---
# NOTE: Replace with your actual email for Entrez
Entrez.email = "your.researcher.email@example.com"
# Ensure your OpenAI API key is set in environment variables
# os.environ["OPENAI_API_KEY"] = "sk-..." 

# 1. PubMed Data Retrieval Function
def fetch_pubmed_data(query: str, max_results: int = 10) -> List[Document]:
    """
    Queries PubMed using Entrez and converts the results (abstracts) 
    into LangChain Document objects.
    """
    print(f"--- 1. Searching PubMed for: '{query}' ---")
    handle = Entrez.esearch(db="pubmed", term=query, retmax=max_results)
    record = Entrez.read(handle)
    id_list = record["IdList"]
    handle.close()

    if not id_list:
        print("No results found.")
        return []

    # Fetch details for the retrieved IDs
    handle = Entrez.efetch(db="pubmed", id=id_list, retmode="xml")
    records = Entrez.read(handle)
    handle.close()

    documents = []
    for pubmed_article in records['PubmedArticle']:
        try:
            article = pubmed_article['MedlineCitation']['Article']
            abstract_text = article['Abstract']['AbstractText'][0]
            title = article['ArticleTitle']
            pmid = pubmed_article['MedlineCitation']['PMID']
            
            # Create metadata dictionary
            metadata = {
                "source": f"PubMed ID: {pmid}",
                "title": title,
                "authors": ", ".join([a['LastName'] for a in article['AuthorList']])
            }
            
            # Create LangChain Document
            doc = Document(page_content=abstract_text, metadata=metadata)
            documents.append(doc)
            
        except (KeyError, IndexError):
            # Skip articles missing abstracts or required fields
            continue
            
    print(f"--- Successfully retrieved and parsed {len(documents)} abstracts. ---")
    return documents

# 2. RAG Pipeline Setup and Execution
def run_pubmed_rag_agent(search_query: str, synthesis_question: str):
    """
    Main function to execute the RAG pipeline: retrieve, index, and query.
    """
    # A. Data Retrieval (Tooling 1: BioPython/Entrez)
    documents = fetch_pubmed_data(search_query, max_results=15)
    if not documents:
        return "RAG Agent failed: No relevant literature found."

    # B. Document Processing and Chunking
    print("--- 2. Processing and Chunking Documents ---")
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=150,
        length_function=len,
        separators=["\n\n", "\n", " ", ""]
    )
    chunks = text_splitter.split_documents(documents)
    print(f"Total chunks created: {len(chunks)}")

    # C. Vector Store Creation (External Memory)
    print("--- 3. Creating Vector Embeddings and Indexing (Chroma) ---")
    embedding_model = OpenAIEmbeddings(model="text-embedding-3-small")
    vectorstore = Chroma.from_documents(
        documents=chunks, 
        embedding=embedding_model, 
        collection_name="pubmed_bioinfo_rag"
    )
    retriever = vectorstore.as_retriever(search_kwargs={"k": 5}) # Retrieve top 5 relevant chunks

    # D. LLM and RAG Chain Initialization (Tooling 2: Synthesis)
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.1)
    
    # Use RetrievalQA chain to integrate retrieval and generation
    qa_chain = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff", # Stuffing all retrieved chunks into the prompt
        retriever=retriever,
        return_source_documents=True
    )

    # E. Agent Execution (Querying the RAG Chain)
    print(f"\n--- 4. Running Synthesis Query: '{synthesis_question}' ---")
    result = qa_chain.invoke({"query": synthesis_question})

    print("\n=======================================================")
    print("               RAG AGENT SYNTHESIS RESULT              ")
    print("=======================================================")
    print(result['result'])
    print("\n--- Sources Used (Top 5 Relevant Abstracts) ---")
    
    # Display unique sources
    unique_sources = set()
    for doc in result['source_documents']:
        unique_sources.add(f"{doc.metadata.get('title', 'N/A')} (ID: {doc.metadata.get('source', 'N/A')})")
        
    for source in unique_sources:
        print(f"- {source}")
    print("=======================================================")
    
# --- Main Execution Block ---
if __name__ == "__main__":
    # Define the specific biological problem
    LITERATURE_SEARCH_TERM = "TP53 pathway Glioblastoma resistance AND immunotherapy"
    
    # Define the complex synthesis question the RAG agent must answer
    SYNTHESIS_QUESTION = (
        "Based *only* on the retrieved abstracts, synthesize the primary mechanisms "
        "by which TP53 mutations influence immunotherapy resistance in Glioblastoma, "
        "citing specific molecular pathways mentioned."
    )
    
    run_pubmed_rag_agent(LITERATURE_SEARCH_TERM, SYNTHESIS_QUESTION)



#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import tensorflow as tf
from tensorflow.keras.layers import Input, Conv3D, Dense, Flatten, Dropout
from tensorflow.keras.models import Model
from tensorflow.keras import regularizers

# Simulated Data setup
input_shape = (10, 10, 10, 1) # Example 3D grid input
X_train = tf.random.normal((100, 10, 10, 10, 1))
y_train = tf.random.uniform((100, 1), minval=4, maxval=10)

def create_enhanced_model(input_shape, l2_reg_strength=0.01, dropout_rate=0.3):
    """Creates the modified model using L2 regularization and Dropout."""
    
    # Define the L2 regularizer
    l2_reg = regularizers.l2(l2_reg_strength)
    
    input_layer = Input(shape=input_shape)
    
    # Feature Extraction Block
    x = Conv3D(32, kernel_size=(3, 3, 3), activation='relu')(input_layer)
    x = Conv3D(64, kernel_size=(3, 3, 3), activation='relu')(x)
    x = Flatten()(x)
    
    # Regularization 1: Dropout after feature extraction
    x = Dropout(dropout_rate)(x)
    
    # Dense Layers with L2 Regularization
    x = Dense(128, activation='relu', kernel_regularizer=l2_reg)(x)
    
    # Regularization 2: Additional Dropout
    x = Dropout(dropout_rate)(x) 
    
    # Output Layer (L2 regularization applied here as well)
    output_layer = Dense(1, activation='linear', kernel_regularizer=l2_reg)(x)
    
    model = Model(inputs=input_layer, outputs=output_layer)
    return model

def compile_and_train_simulation(model, X_train, y_train):
    """Simulates compilation and training with enhanced parameters."""
    
    # 1. Define the customized loss function (Huber Loss)
    # Justification: Huber Loss is superior to MSE for noisy data because it 
    # transitions from a squared loss for small errors to a linear loss for 
    # large errors, making it less sensitive to affinity outliers.
    huber_loss = tf.keras.losses.Huber(delta=1.0)
    
    # 2. Define the dynamic learning rate schedule
    initial_learning_rate = 0.001
    lr_schedule = tf.keras.optimizers.schedules.ExponentialDecay(
        initial_learning_rate,
        decay_steps=10 * (len(X_train) // 32), # Decay after every 10 epochs
        decay_rate=0.1, # Step down factor
        staircase=True
    )
    
    optimizer = tf.keras.optimizers.Adam(learning_rate=lr_schedule)
    
    # 3. Compile the model
    model.compile(optimizer=optimizer, loss=huber_loss, metrics=['mae'])
    
    print("--- Model Enhancement Summary ---")
    print(f"Loss Function: {huber_loss.name}")
    print(f"Regularization: L2 (0.01) and Dropout (0.3) implemented.")
    print(f"Learning Rate Scheduler: Exponential Decay implemented.")
    
    # 4. Simulate the training loop (model object ready for training)
    return model

# Execution
enhanced_model = create_enhanced_model(input_shape)
compiled_model = compile_and_train_simulation(enhanced_model, X_train, y_train)

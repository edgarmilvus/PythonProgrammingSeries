
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import math

# Simulated PDB content snippet for parsing
pdb_content = """
REMARK Simulated AlphaFold Output
ATOM      1  N   MET A   1      50.120  34.690  12.980  1.00 92.50           N
ATOM      2  CA  MET A   1      49.520  33.580  12.180  1.00 95.10           C
ATOM      3  C   MET A   1      48.060  33.740  12.500  1.00 88.00           C
ATOM     10  CA  GLY A   2      45.000  30.000  15.000  1.00 70.00           C
ATOM     20  CA  LEU A   3      35.210  25.010  10.150  1.00 75.20           C
ATOM     21  O   LEU A   3      36.000  24.500  10.900  1.00 65.00           O
ATOM     30  CA  VAL A   4      30.000  20.000   5.000  1.00 90.00           C
ATOM     40  CA  SER A   5      28.000  18.000   4.000  1.00 85.00           C
"""

# Define a simplified hydrophobicity scale
HYDROPHOBICITY_SCALE = {
    'LEU': 5.0, 'VAL': 4.0, 'MET': 3.0, 'GLY': 0.0,
    'SER': -2.0, 'THR': -1.0, 'ASP': -3.5, 'GLU': -3.5
}
CONFIDENCE_THRESHOLD = 80.0

def calculate_distance(p1, p2):
    """Calculates Euclidean distance between two 3D points."""
    return math.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2 + (p1[2] - p2[2])**2)

def analyze_alphafold_structure(pdb_data):
    """Parses PDB data to extract druggability features."""
    
    c_alpha_coords = []
    residue_scores = []
    high_confidence_atoms = 0
    total_atoms = 0
    
    for line in pdb_data.strip().split('\n'):
        if line.startswith("ATOM"):
            total_atoms += 1
            
            # PDB format parsing (fixed width columns)
            atom_name = line[12:16].strip()
            res_name = line[17:20].strip()
            
            try:
                x = float(line[30:38])
                y = float(line[38:46])
                z = float(line[46:54])
                b_factor = float(line[60:66])
            except ValueError:
                continue

            if atom_name == 'CA':
                c_alpha_coords.append((x, y, z))

            if res_name in HYDROPHOBICITY_SCALE:
                residue_scores.append(HYDROPHOBICITY_SCALE[res_name])

            if b_factor >= CONFIDENCE_THRESHOLD:
                high_confidence_atoms += 1

    # 2. Hydrophobicity Scoring
    avg_hydrophobicity = sum(residue_scores) / len(residue_scores) if residue_scores else 0

    # 3. Radius of Gyration Proxy (Max C-alpha distance)
    max_distance = 0.0
    if len(c_alpha_coords) > 1:
        for i in range(len(c_alpha_coords)):
            for j in range(i + 1, len(c_alpha_coords)):
                dist = calculate_distance(c_alpha_coords[i], c_alpha_coords[j])
                max_distance = max(max_distance, dist)
    
    # 4. Confidence Filtering
    confidence_percentage = (high_confidence_atoms / total_atoms) * 100 if total_atoms > 0 else 0

    features = {
        "Avg_Hydrophobicity": round(avg_hydrophobicity, 2),
        "Max_CA_Distance_Proxy": round(max_distance, 2),
        "High_Confidence_Percent": round(confidence_percentage, 2)
    }
    return features

# Execution
structural_features = analyze_alphafold_structure(pdb_content)
print("--- AlphaFold Structural Features ---")
print(f"Average Residue Hydrophobicity Score: {structural_features['Avg_Hydrophobicity']}")
print(f"Max C-alpha Distance (Size Proxy): {structural_features['Max_CA_Distance_Proxy']} Å")
print(f"Percentage of High Confidence Atoms (> {CONFIDENCE_THRESHOLD}): {structural_features['High_Confidence_Percent']}%")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np
from scipy.spatial.distance import cosine

# Constants
EMBEDDING_DIM = 512
NUM_COMPOUNDS = 100
TOP_K = 5

def generate_compound_library(num_compounds, embedding_dim=512):
    """Generates simulated compound IDs and embeddings."""
    compound_data = {}
    for i in range(1, num_compounds + 1):
        compound_id = f"CHEM_{i:04d}"
        # Generate random embeddings and normalize them
        embedding = np.random.rand(embedding_dim)
        embedding = embedding / np.linalg.norm(embedding) 
        compound_data[compound_id] = embedding
    return compound_data

def retrieve_top_k_candidates(query_vector, compound_embeddings, k=5):
    """Calculates cosine similarity and retrieves the top K matching IDs."""
    
    similarity_scores = {}
    
    # 1. Vector Store Retrieval Simulation
    for compound_id, embedding in compound_embeddings.items():
        # Cosine distance is 1 - similarity. We calculate similarity (1=most similar)
        cosine_dist = cosine(query_vector, embedding)
        similarity = 1 - cosine_dist
        similarity_scores[compound_id] = similarity
        
    # 2. Sorting and Top K Selection
    # Sort the items based on the similarity score in descending order
    sorted_scores = sorted(
        similarity_scores.items(), 
        key=lambda item: item[1], 
        reverse=True
    )
    
    top_candidates = sorted_scores[:k]
    
    return top_candidates

# Execution
# 1. Data Structure Simulation & Indexing
compound_library = generate_compound_library(NUM_COMPOUNDS, EMBEDDING_DIM)

# 3. Query Vector Generation (making it similar to the first compound)
query_vector = compound_library["CHEM_0001"] * 0.9 + np.random.rand(EMBEDDING_DIM) * 0.1
query_vector = query_vector / np.linalg.norm(query_vector)

# 4. Retrieval Mechanism
top_candidates = retrieve_top_k_candidates(query_vector, compound_library, TOP_K)

print(f"--- LLM-Guided Compound Retrieval (Top {TOP_K}) ---")
print(f"Total compounds indexed: {NUM_COMPOUNDS}")
print("\nTop Candidates Retrieved:")
for rank, (cid, score) in enumerate(top_candidates):
    print(f"Rank {rank+1}: ID {cid} | Similarity Score: {score:.4f}")

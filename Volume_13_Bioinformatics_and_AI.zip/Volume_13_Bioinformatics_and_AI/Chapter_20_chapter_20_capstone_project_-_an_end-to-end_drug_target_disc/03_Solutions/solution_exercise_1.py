
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import random

# Simulated Input Data (Extended for robust testing)
gwas_results = {
    f"ENSG{i:03d}": {"p_value": random.uniform(1e-10, 1e-6)}
    for i in range(1, 15)
}
gwas_results.update({
    f"ENSG{i:03d}": {"p_value": random.uniform(1e-6, 1e-4)}
    for i in range(15, 30)
})
gwas_results["ENSG001"]["p_value"] = 1e-9 
gwas_results["ENSG005"]["p_value"] = 4e-8 
gwas_results["ENSG010"]["p_value"] = 6e-8 

rnaseq_results = {
    f"ENSG{i:03d}": {"logFC": random.uniform(1.6, 5.0)}
    for i in range(1, 10)
}
rnaseq_results.update({
    f"ENSG{i:03d}": {"logFC": random.uniform(-5.0, -1.6)}
    for i in range(10, 20)
})
rnaseq_results["ENSG001"]["logFC"] = 3.0
rnaseq_results["ENSG005"]["logFC"] = -2.5

def prioritize_targets(gwas_results, rnaseq_results):
    """Filters and intersects gene lists based on strict criteria."""
    
    P_VALUE_THRESHOLD = 5e-8
    LOGFC_THRESHOLD = 1.5

    # 1. Filter GWAS results using Set Comprehension
    gwas_targets = {
        gene_id for gene_id, data in gwas_results.items()
        if data.get('p_value', 1.0) < P_VALUE_THRESHOLD
    }

    # 2. Filter RNA-seq results using Set Comprehension
    rnaseq_targets = {
        gene_id for gene_id, data in rnaseq_results.items()
        if abs(data.get('logFC', 0.0)) > LOGFC_THRESHOLD
    }

    # 3. Intersect the two sets to find high-confidence targets
    prioritized_targets = gwas_targets & rnaseq_targets
    
    return prioritized_targets

# Execution
final_targets = prioritize_targets(gwas_results, rnaseq_results)

print(f"Prioritized Target IDs (Intersection): {final_targets}")
print(f"Total number of unique, prioritized targets: {len(final_targets)}")
print(f"Output structure type validation: {type(final_targets)}")

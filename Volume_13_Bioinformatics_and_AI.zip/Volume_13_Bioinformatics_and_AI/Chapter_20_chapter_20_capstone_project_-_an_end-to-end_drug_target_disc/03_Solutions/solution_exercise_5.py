
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np

# Constants for the simulation
TOTAL_COMPOUNDS = 50000
BATCH_SIZE = 5000
CHECKPOINT_INTERVAL = 3  # Save every 3 batches

def run_batch_screening_campaign(total_compounds, batch_size, checkpoint_interval):
    """Simulates high-throughput virtual screening with checkpointing."""
    
    # Calculate the number of batches required
    num_batches = (total_compounds + batch_size - 1) // batch_size
    print(f"Starting screening campaign: {total_compounds} compounds in {num_batches} batches.")
    
    # Placeholder for accumulated results (simulating persistence)
    all_results = []
    
    # 2. Iterative Screening (For Loop)
    for batch_num in range(num_batches):
        
        # Calculate the start and end indices for the current batch
        start_index = batch_num * batch_size
        end_index = min((batch_num + 1) * batch_size, total_compounds)
        
        current_batch_size = end_index - start_index
        
        # 3. Model Application Simulation
        # Simulate generating predicted affinity scores (e.g., pIC50)
        predicted_scores = np.random.uniform(5.0, 10.0, current_batch_size)
        
        # Accumulate results
        all_results.extend(list(predicted_scores))
        
        # Calculate progress
        compounds_processed = end_index
        percent_complete = (compounds_processed / total_compounds) * 100
        
        # 4. Dynamic Checkpointing: Trigger save on the 3rd batch, 6th batch, etc.
        if (batch_num + 1) % checkpoint_interval == 0:
            print(f"\n[CHECKPOINT] Batch {batch_num + 1}/{num_batches} reached.")
            print(f"    Saving {len(all_results)} total results to persistent storage...")
        
        # 5. Progress Tracking
        print(f"Batch {batch_num + 1}/{num_batches}: Processing compounds {start_index + 1} to {end_index}. ", end="")
        print(f"Completion: {percent_complete:.2f}%")

    print("\nScreening campaign completed successfully.")
    return len(all_results)

# Execution
total_screened = run_batch_screening_campaign(TOTAL_COMPOUNDS, BATCH_SIZE, CHECKPOINT_INTERVAL)
print(f"Total final results collected: {total_screened}")

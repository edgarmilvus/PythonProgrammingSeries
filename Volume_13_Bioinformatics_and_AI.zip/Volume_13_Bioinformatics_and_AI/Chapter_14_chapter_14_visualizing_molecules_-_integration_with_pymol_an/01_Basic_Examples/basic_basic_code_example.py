
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import nglview as nv
from IPython.display import display
import sys
import os

# --- Configuration ---
# 1. Define the target PDB ID (Myoglobin, a classic test structure)
PDB_IDENTIFIER = "1A2C"
# Define the maximum size for the widget display (optional, but good for layout)
WIDGET_HEIGHT = "400px" 

# --- Visualization Logic ---
print(f"--- Starting NGLView Visualization for PDB ID: {PDB_IDENTIFIER} ---")

# 2. Attempt to load the structure directly from the RCSB PDB database
# nv.PDBID acts as a streamlined utility, handling network communication and parsing.
try:
    # Instantiate the NGLView widget object
    view = nv.PDBID(PDB_IDENTIFIER)
    print(f"Successfully fetched structure {PDB_IDENTIFIER}.")

except Exception as e:
    # Robust error handling for network or parsing failures
    print(f"FATAL ERROR: Could not load PDB ID {PDB_IDENTIFIER}.")
    print(f"Details: {e}")
    # Exit gracefully if the core resource cannot be obtained
    sys.exit(1)

# 3. Configure the visualization style
# The NGL viewer uses a powerful command-based API for defining representations.

# Set the widget size and enable auto-rotation for initial viewing pleasure
view.layout.height = WIDGET_HEIGHT
view.layout.width = '100%'
view.spin(True) # Start auto-rotation

# Clear any default representations that nglview might apply automatically
view.clear_representations()
print("Cleared default representations.")

# A. Add the primary representation: Cartoon for the protein backbone
# 's_struc' (Secondary Structure) is a standard coloring scheme for proteins.
view.add_cartoon(
    color='s_struc', 
    name='Protein_Backbone_Cartoon',
    opacity=0.8
)
print("Added cartoon representation (colored by secondary structure).")


# B. Add the secondary representation: Ball and Stick for non-protein parts
# 'hetero' is the standard NGL selection keyword for non-standard residues (ligands, ions, water).
view.add_ball_and_stick(
    selection='hetero',
    name='Ligand_Details',
    color='element' # Standard coloring by atomic element (C, N, O, S, etc.)
)
print("Added ball-and-stick representation for heteroatoms.")

# 4. Final step: Display the interactive widget in the Jupyter output cell
# The 'display' function is crucial for rendering the underlying JavaScript component.
print("Rendering interactive NGLView widget...")
display(view)

print("--- Visualization setup complete. Scroll up to interact with the model. ---")

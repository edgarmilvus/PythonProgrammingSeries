
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import requests
import subprocess
import os
from pathlib import Path

# --- Configuration ---
PDB_DOWNLOAD_URL = "https://files.rcsb.org/download/{}.pdb"

def render_pdb_structure(pdb_id: str, output_filename: str):
    """
    Downloads a PDB file, generates a PyMOL script (.pml), executes PyMOL 
    to render the structure with standardized settings, and cleans up temporary files.
    """
    pdb_id = pdb_id.upper()
    temp_pdb_file = Path(f"{pdb_id}.pdb")
    temp_pml_file = Path(f"{pdb_id}_render.pml")
    
    print(f"Starting rendering process for {pdb_id}...")

    # 1. PDB Acquisition
    try:
        response = requests.get(PDB_DOWNLOAD_URL.format(pdb_id), stream=True)
        response.raise_for_status()
        with open(temp_pdb_file, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        print(f"Downloaded {temp_pdb_file}")
    except requests.exceptions.RequestException as e:
        print(f"Error downloading PDB {pdb_id}: {e}")
        return

    # 2. PyMOL Command Script Generation
    pymol_commands = [
        f"load {temp_pdb_file}, {pdb_id}",
        "hide all",
        "show cartoon",
        "bg_color white",
        # Color by secondary structure (using spectrum command on residue index)
        "spectrum resi, rainbow, selection=all", 
        "set antialias, 1",
        "set ray_trace_mode, 1", # High quality ray tracing
        "zoom all",
        "ray 2000, 2000", # Render at 2000x2000 pixels
        f"png {output_filename}, dpi=300",
        "quit"
    ]
    
    with open(temp_pml_file, 'w') as f:
        f.write("\n".join(pymol_commands))
    print(f"Generated PyMOL script: {temp_pml_file}")

    # 3. Execution Strategy (Requires PyMOL executable in PATH)
    try:
        # Execute PyMOL in headless mode (-c) using the generated script
        result = subprocess.run(
            ['pymol', '-c', str(temp_pml_file)],
            check=True,
            capture_output=True,
            text=True
        )
        print(f"Successfully rendered image to {output_filename}")
        # Optional: print PyMOL output for debugging
        # print("PyMOL Output:\n", result.stdout)
        
    except FileNotFoundError:
        print("ERROR: PyMOL executable not found. Ensure 'pymol' is in your system PATH.")
    except subprocess.CalledProcessError as e:
        print(f"ERROR: PyMOL execution failed.")
        print("PyMOL Error Output:\n", e.stderr)
    
    # 4. Clean-up
    finally:
        if temp_pdb_file.exists():
            os.remove(temp_pdb_file)
        if temp_pml_file.exists():
            os.remove(temp_pml_file)
        print("Clean-up complete.")

# Example Usage (Requires PyMOL to be installed and accessible via command line)
# render_pdb_structure("1A2C", "1A2C_publication_figure.png")

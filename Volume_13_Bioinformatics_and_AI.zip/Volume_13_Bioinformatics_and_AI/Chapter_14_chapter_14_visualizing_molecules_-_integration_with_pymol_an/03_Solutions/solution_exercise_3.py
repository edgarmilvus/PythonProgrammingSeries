
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import nglview
import MDAnalysis as mda
import numpy as np
import os
from pathlib import Path

# --- Setup Mock Trajectory Files ---
# In a real scenario, these files would already exist. 
# We mock them to demonstrate the MDAnalysis setup.
def create_mock_trajectory_files():
    """Creates minimal, valid PDB and DCD files for MDAnalysis testing."""
    # Minimal PDB topology (10 residues, 1 chain)
    pdb_content = """
ATOM      1  N   ALA A   1      -0.000   0.000   0.000  1.00 50.00           N  
ATOM      2  CA  ALA A   1       1.000   0.000   0.000  1.00 50.00           C  
... (8 more residues for a total of 10)
ATOM     29  CA  ALA A  10      10.000   0.000   0.000  1.00 50.00           C  
ATOM     30  C   ALA A  10      11.000   0.000   0.000  1.00 50.00           C  
END
"""
    # Note: Creating a valid DCD file is complex. We rely on MDAnalysis 
    # being able to handle the topology and assume a DCD exists for the visualization logic.
    # For this exercise, we focus on the MDAnalysis/nglview integration logic.

    # Create placeholder files
    Path("protein.pdb").write_text(pdb_content)
    # Mock DCD file creation (requires specific library, skipped here, but assumed present)
    # os.system("touch trajectory.dcd") 
    print("Mock PDB topology file created.")
    # Assume 'trajectory.dcd' exists for the MDAnalysis Universe creation step.

# create_mock_trajectory_files() # Run this line if testing locally

# --- MD Analysis and nglview Integration ---

# 1. Load Trajectory Data using MDAnalysis
try:
    # Assuming 'protein.pdb' and 'trajectory.dcd' exist
    # Note: In a real run, trajectory.dcd must be a valid file.
    # We use a single PDB frame loaded as a Universe for demonstration consistency.
    # A true trajectory would look like: mda.Universe('protein.pdb', 'trajectory.dcd')
    
    # Using a single PDB for robustness in a non-MD environment, but the code structure 
    # is exactly what is needed for trajectory loading.
    universe = mda.Universe('protein.pdb') 
    print(f"MDAnalysis Universe loaded with {universe.trajectory.n_frames} frames.")

    # 2. nglview Initialization (enables playback controls automatically)
    view = nglview.show_mdanalysis(universe)

    # 3. Visualization Aesthetics and Color Mapping
    # Clear defaults to apply specific coloring
    view.clear_representations()
    
    # 4. RMSF Simulation Coloring
    # Apply cartoon representation and color by residue index (scalar property)
    view.add_representation(
        'cartoon', 
        selection='protein', 
        # Crucial step: instruct NGL to use a scalar property for coloring
        color_scheme='residueindex', 
        name='Residue Index Coloring (Simulated RMSF)'
    )
    
    # Set background for better contrast
    view.background = 'white'

    # 5. Verification (Display the widget)
    display(view)

except FileNotFoundError:
    print("Error: Mock PDB or DCD file not found. Ensure mock files are created or use real files.")
except Exception as e:
    print(f"An error occurred during MDAnalysis/nglview setup: {e}")

# Clean up mock files (if they were created)
# os.remove('protein.pdb')
# os.remove('trajectory.dcd') 

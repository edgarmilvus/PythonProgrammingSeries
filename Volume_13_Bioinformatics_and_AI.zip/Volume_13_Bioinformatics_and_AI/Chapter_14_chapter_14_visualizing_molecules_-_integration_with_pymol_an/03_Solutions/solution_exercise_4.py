
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import pymol
from pymol import cmd
import os
from pathlib import Path

# --- Mock Data Setup ---
# PyMOL needs PDB files to operate. We create placeholders.
def create_mock_pdb_files():
    """Creates mock PDB files with varying B-factors to simulate pLDDT."""
    # Cluster A (Primary AF Model) - B-factors simulate pLDDT scores (0-100)
    # Residues 1-5: Low confidence (~40)
    # Residues 6-10: High confidence (~95)
    pdb_a_content = ""
    for i in range(1, 11):
        # Assign B-factor based on residue index to create a gradient
        b_factor = 40 + (i * 6) # Range from 46 to 100
        pdb_a_content += f"ATOM  {i:5d}  CA  ALA A {i:4d}    10.000 10.000 10.000  1.00{b_factor:6.2f}           C\n"
    Path("cluster_A.pdb").write_text(pdb_a_content + "END\n")

    # Cluster B (Comparison Model) - Simple coordinates, uniform B-factors
    pdb_b_content = ""
    for i in range(1, 11):
        # Shift coordinates slightly for alignment demonstration
        pdb_b_content += f"ATOM  {i:5d}  CA  ALA B {i:4d}    11.000 10.000 10.000  1.00 50.00           C\n"
    Path("cluster_B.pdb").write_text(pdb_b_content + "END\n")

    print("Mock PDB files created: cluster_A.pdb (pLDDT mapped) and cluster_B.pdb.")

create_mock_pdb_files()

def visualize_alphafold_confidence_and_cluster_comparison():
    """
    Executes PyMOL commands via the embedded API to visualize pLDDT 
    and structural alignment.
    """
    cmd.reinitialize()
    
    # 1. Structure Loading and Preparation
    cmd.load("cluster_A.pdb", "cluster_A")
    cmd.hide("all")
    cmd.show("cartoon", "cluster_A")
    
    # 2. Confidence Gradient Definition and Application (on cluster_A)
    # Define the color gradient mapping B-factor (pLDDT) to colors:
    # 0-50 (Red), 50-70 (Yellow), 70-90 (Cyan), 90-100 (Blue)
    
    # PyMOL's spectrum command requires colors to be listed from minimum to maximum value.
    # The selection is set to cluster_A.
    cmd.spectrum(
        'b', 
        'red_orange_yellow_cyan_blue', # Predefined gradient name OR list individual colors
        'cluster_A', 
        minimum=0, 
        maximum=100
    )
    
    # 3. Load and Align Second Structure
    cmd.load("cluster_B.pdb", "cluster_B")
    
    # Align cluster_B onto cluster_A using only CA atoms for structural comparison
    alignment_result = cmd.align("cluster_B and name CA", "cluster_A and name CA")
    print(f"Alignment RMSD: {alignment_result[0]:.3f} Å")
    
    # 4. Color the second structure for contrast
    cmd.show("cartoon", "cluster_B")
    cmd.color("gray70", "cluster_B") # Uniform gray for contrast
    
    # Zoom and center the view
    cmd.zoom("all", 1.0)
    
    # 5. Visualization Output (Ray trace and save)
    # Note: Requires PyMOL to be running in an environment capable of ray tracing
    output_image = "confidence_comparison_figure.png"
    cmd.ray(2000, 2000)
    cmd.png(output_image, width=2000, height=2000, dpi=300, quiet=1)
    
    print(f"High-resolution image saved: {output_image}")

    # Clean-up
    cmd.delete("all")
    os.remove("cluster_A.pdb")
    os.remove("cluster_B.pdb")

# Execute the visualization function
visualize_alphafold_confidence_and_cluster_comparison()

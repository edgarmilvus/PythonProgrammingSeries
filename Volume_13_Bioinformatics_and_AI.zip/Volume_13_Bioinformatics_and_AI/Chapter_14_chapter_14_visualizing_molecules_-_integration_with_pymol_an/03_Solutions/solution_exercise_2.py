
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import nglview
from IPython.display import display

# PDB ID for Adenylate Kinase bound to ATP and Mg2+
PDB_ID = "4AKE"

# 1. Structure Loading
view = nglview.show_pdbid(PDB_ID)

# 2. Clear default representations (optional, but ensures a clean slate)
view.clear_representations()

# 3. Protein Representation (Polymer)
# Selection: 'polymer'
view.add_representation(
    'cartoon', 
    selection='polymer', 
    color='lightgray', 
    name='Protein Backbone'
)

# 4. Ligand Isolation and Representation (ATP)
# Selection: 'resname ATP' (or 'hetero' which includes ligands and ions)
view.add_representation(
    'ball+stick', 
    selection='resname ATP', 
    color='magenta', 
    radius=0.3,
    name='ATP Ligand'
)

# 5. Cofactor/Ion Handling (Magnesium)
# Selection: 'element MG'
view.add_representation(
    'spacefill', 
    selection='element MG', 
    color='green', 
    radius=0.5,
    name='Magnesium Ion'
)

# Optional: Zoom to the binding site for better initial view
# view.center('resname ATP or element MG')

# 6. Interactive Control (The view object itself is the interactive widget)
display(view) 

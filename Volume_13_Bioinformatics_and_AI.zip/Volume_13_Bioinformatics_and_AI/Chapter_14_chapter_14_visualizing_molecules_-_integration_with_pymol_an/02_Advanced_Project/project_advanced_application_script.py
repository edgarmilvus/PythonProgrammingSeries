
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import nglview as nv
import pymol2
import MDAnalysis as mda
import numpy as np
import os
from tempfile import NamedTemporaryFile

# --- 1. Simulation Setup: Define representatives from a hypothetical MD clustering ---
# Note: PDB IDs (4JR2, 4JR3, 4JR4) are used here as stand-ins for actual cluster centers.
# These represent three distinct structural states identified by clustering.

def fetch_pdb_data(pdb_id):
    """
    Fetches PDB structure using MDAnalysis. This function ensures the data
    is available, simulating the retrieval of cluster representative files.
    """
    try:
        # MDAnalysis handles fetching the file from the PDB database
        path = mda.fetch_pdb(pdb_id)
        return path
    except Exception:
        # Placeholder for environments where fetching is impossible
        print(f"Warning: Could not fetch {pdb_id}. Using a placeholder path.")
        return f"{pdb_id}.pdb" 

# Define the cluster representatives (PDB IDs mapped to descriptive names)
CLUSTER_REPRESENTATIVES = {
    "Cluster_A_Open": "4JR2",
    "Cluster_B_Closed": "4JR3",
    "Cluster_C_Intermediate": "4JR4"
}

# --- 2. Interactive Visualization (nglview) ---

def visualize_clusters_interactive(cluster_dict):
    """
    Loads all cluster representatives into a single nglview widget for interactive comparison.
    Each structure is added as a separate component to the view.
    """
    print("--- Starting NGLView Interactive Visualization ---")
    
    # Load first structure (Cluster A) to initialize the view and set the reference frame
    first_id = list(cluster_dict.keys())[0]
    first_path = fetch_pdb_data(cluster_dict[first_id])
    
    u = mda.Universe(first_path)
    view = nv.show_mdanalysis(u)
    view.add_representation('cartoon', selection='protein', name='Protein Backbone')
    
    # Load subsequent structures as additional components
    # nglview automatically attempts to align components visually
    for name, pdb_id in list(cluster_dict.items())[1:]:
        path = fetch_pdb_data(pdb_id)
        u_comp = mda.Universe(path)
        # Adding a new component allows structures to be overlaid
        view.add_component(u_comp)
    
    # Apply distinct styling and naming for clarity
    color_schemes = ['red', 'blue', 'green']
    for i, name in enumerate(cluster_dict.keys()):
        # Update styling for each component using its index (i)
        view.update_component(i, representation='cartoon', selection='protein', 
                              colorScheme=color_schemes[i], opacity=0.8, name=f'{name} Cartoon')
        
        # Highlight the ligand (HET) in the structure
        view.add_representation('licorice', selection='resname HET', component=i, 
                                color=color_schemes[i], name=f'{name} Ligand')
        
        view.set_name(f"Cluster Visualization ({len(cluster_dict)} States)")
        
    print(f"NGLView loaded {len(cluster_dict)} structures for comparison.")
    return view

# --- 3. High-Quality Static Rendering (PyMOL) ---

def render_cluster_comparison_pymol(cluster_dict, output_filename="cluster_comparison.png"):
    """
    Uses pymol2 API to load, align, style, and render high-resolution comparison image.
    This ensures publication-quality output with consistent styling.
    """
    print("\n--- Starting PyMOL Static Rendering ---")
    
    # Initialize PyMOL session using the context manager
    with pymol2.PyMOL() as p:
        cmd = p.cmd
        
        # 1. Load structures and assign unique object names
        object_names = []
        for i, (name, pdb_id) in enumerate(cluster_dict.items()):
            path = fetch_pdb_data(pdb_id)
            obj_name = f"C{i}_{name}"
            cmd.load(path, obj_name)
            object_names.append(obj_name)
            
        # 2. Crucial Step: Align all structures to the first one (reference)
        reference_obj = object_names[0]
        for target_obj in object_names[1:]:
            # Align based on the C-alpha atoms of the entire protein backbone
            cmd.align(target_obj, reference_obj, mobile_selection='name CA and polymer.protein', 
                      target_selection='name CA and polymer.protein')
            
        # 3. Apply consistent visualization style and color scheme
        cmd.hide("all")
        
        pymol_colors = ["0xEE4B2B", "0x0000FF", "0x3CB371"] # Custom hex colors
        for obj, color in zip(object_names, pymol_colors):
            # Show backbone cartoon for the cluster representative
            cmd.show("cartoon", obj)
            cmd.color(color, obj)
            
            # Highlight the binding site/ligand in sticks representation
            cmd.show("sticks", f"{obj} and resn HET")
            cmd.util.cbag(f"{obj} and resn HET") # Color ligand by atom type (C, O, N)
            
        # 4. Set viewing and rendering parameters for high quality
        cmd.zoom("all", 5) # Zoom slightly out from the default
        cmd.set("ray_trace_mode", 1) # Use high-quality ray tracing
        cmd.set("ray_shadows", 0) # Disable shadows for cleaner look (optional)
        cmd.set("cartoon_fancy_helices", 1) # Enhance helix rendering
        cmd.set("bg_color", "white")
        
        # 5. Generate and save high-quality image
        cmd.ray(2560, 1440) # Ray trace at 2K resolution
        cmd.png(output_filename, width=2560, height=1440, dpi=600, ray=1)
        
        print(f"Successfully rendered high-resolution image: {output_filename}")
        
    return output_filename

# --- 4. Execution Flow ---

if __name__ == "__main__":
    # A. Interactive Exploration: Generates the nglview widget
    ngl_view_widget = visualize_clusters_interactive(CLUSTER_REPRESENTATIVES)
    # The user would now interact with ngl_view_widget in the notebook.

    # B. Static Output: Generates the publication-ready image
    output_file = render_cluster_comparison_pymol(CLUSTER_REPRESENTATIVES)
    print(f"\nFinal script execution complete. Output image: {output_file}")

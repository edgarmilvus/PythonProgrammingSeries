
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd 

# --- 1. Configuration and Simulated Data Loading ---
RESIDUE_COUNT = 200
PAE_THRESHOLD = 5.0  # Ångstroms: Threshold for reliable domain interaction (low PAE = rigid)
pLDDT_CONFIDENCE_CUTOFF = 70.0 # Score (0-100): Threshold for high local confidence

# Define the two domains of interest (0-indexed for Python slicing)
DOMAIN_A = (0, 49)      # Residues 1 to 50
DOMAIN_B = (100, 149)   # Residues 101 to 150

# Simulate pLDDT scores (0-100). 
# We introduce low confidence in the linker region (residues 51-100).
np.random.seed(42)
pLDDT_scores = np.concatenate([
    np.random.uniform(90, 95, 50), # Domain A: High Confidence
    np.random.uniform(50, 65, 50), # Linker Region: Low Confidence (Flexible)
    np.random.uniform(85, 90, 50), # Domain B: High Confidence
    np.random.uniform(60, 75, 50)  # C-terminus: Medium Confidence
])

# Simulate PAE Matrix (Predicted Aligned Error in Angstroms)
PAE_matrix = np.zeros((RESIDUE_COUNT, RESIDUE_COUNT))
for i in range(RESIDUE_COUNT):
    for j in range(RESIDUE_COUNT):
        # Intra-domain (low error)
        if (i < 50 and j < 50) or (i >= 100 and i < 150 and j >= 100 and j < 150):
            PAE_matrix[i, j] = np.random.uniform(0.5, 3.0)
        # Inter-domain (A vs B): High error due to predicted flexibility
        elif (i < 50 and j >= 100 and j < 150) or (j < 50 and i >= 100 and i < 150):
            PAE_matrix[i, j] = np.random.uniform(7.0, 12.0)
        # Other regions (Linkers, etc.): Medium error
        else:
            PAE_matrix[i, j] = np.random.uniform(3.0, 7.0)
PAE_matrix = (PAE_matrix + PAE_matrix.T) / 2 # Ensure the matrix is symmetric

# --- 2. Core Analysis Functions ---

def analyze_plddt(scores, domain_range, cutoff):
    """Calculates mean pLDDT and identifies low-confidence residues within a range."""
    start, end = domain_range
    domain_scores = scores[start:end+1]
    mean_plddt = np.mean(domain_scores)
    # Count how many residues fall below the acceptable local confidence threshold
    low_confidence_count = np.sum(domain_scores < cutoff)
    return mean_plddt, low_confidence_count

def analyze_pae_orientation(pae_matrix, domain_a, domain_b):
    """Extracts and analyzes the PAE sub-matrix between two domains (A vs B)."""
    # Slice the inter-domain block (A rows, B columns)
    a_start, a_end = domain_a
    b_start, b_end = domain_b
    inter_pae_block = pae_matrix[a_start:a_end+1, b_start:b_end+1]

    mean_inter_pae = np.mean(inter_pae_block)
    max_inter_pae = np.max(inter_pae_block)
    
    # Orientation is reliable if the average predicted error is below the threshold
    is_reliable = mean_inter_pae < PAE_THRESHOLD
    
    return mean_inter_pae, max_inter_pae, is_reliable

# --- 3. Execution and Reporting ---

print("--- AlphaFold Confidence Inspector Report ---")
print(f"Total Residues Analyzed: {RESIDUE_COUNT}")
print(f"pLDDT Local Confidence Cutoff: >{pLDDT_CONFIDENCE_CUTOFF:.1f}")
print(f"PAE Orientation Reliability Threshold: <{PAE_THRESHOLD:.1f} Å")
print("-" * 40)

# A. Domain A Analysis
mean_a, low_a = analyze_plddt(pLDDT_scores, DOMAIN_A, pLDDT_CONFIDENCE_CUTOFF)
print(f"Domain A (Res {DOMAIN_A[0]+1}-{DOMAIN_A[1]+1}): Mean pLDDT = {mean_a:.2f}")
print(f"  -> Low Confidence Residues: {low_a}")

# B. Domain B Analysis
mean_b, low_b = analyze_plddt(pLDDT_scores, DOMAIN_B, pLDDT_CONFIDENCE_CUTOFF)
print(f"Domain B (Res {DOMAIN_B[0]+1}-{DOMAIN_B[1]+1}): Mean pLDDT = {mean_b:.2f}")
print(f"  -> Low Confidence Residues: {low_b}")

# C. Inter-Domain Orientation Analysis (A vs B)
mean_pae, max_pae, reliable = analyze_pae_orientation(PAE_matrix, DOMAIN_A, DOMAIN_B)
reliability_status = "RELIABLE" if reliable else "UNRELIABLE (High Flexibility)"

print("-" * 40)
print(f"Inter-Domain Orientation (A vs B):")
print(f"  -> Mean PAE: {mean_pae:.2f} Å")
print(f"  -> Max PAE: {max_pae:.2f} Å")
print(f"  -> Status: {reliability_status}")

# --- 4. Visualization of Confidence Metrics ---

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))

# Plot 1: pLDDT Score Distribution
ax1.plot(range(1, RESIDUE_COUNT + 1), pLDDT_scores, color='darkblue')
ax1.axhline(pLDDT_CONFIDENCE_CUTOFF, color='red', linestyle='--', label='Cutoff')
ax1.fill_between(range(1, RESIDUE_COUNT + 1), pLDDT_scores, pLDDT_CONFIDENCE_CUTOFF,
                 where=(pLDDT_scores < pLDDT_CONFIDENCE_CUTOFF), color='salmon', alpha=0.3)
ax1.set_title('Predicted Local Distance Difference Test (pLDDT)')
ax1.set_xlabel('Residue Index')
ax1.set_ylabel('pLDDT Score (0-100)')
ax1.legend()

# Plot 2: PAE Matrix Visualization
im = ax2.imshow(PAE_matrix, cmap='viridis_r', origin='lower', vmin=0, vmax=15)

# Highlight the inter-domain region (A vs B) for visual inspection
rect_A_B = plt.Rectangle((DOMAIN_B[0], DOMAIN_A[0]), 
                         DOMAIN_B[1] - DOMAIN_B[0] + 1, 
                         DOMAIN_A[1] - DOMAIN_A[0] + 1, 
                         fill=False, edgecolor='red', linewidth=2, linestyle='--')
ax2.add_patch(rect_A_B)

ax2.set_title('Predicted Aligned Error (PAE) Matrix')
ax2.set_xlabel('Residue Index B')
ax2.set_ylabel('Residue Index A')
plt.colorbar(im, ax=ax2, label='PAE (Å)')

plt.tight_layout()
# plt.show()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# File: alphafold_confidence_parser.py

# --- 1. Simulated AlphaFold pLDDT Output Data ---
# In a real scenario, this data would be loaded from a JSON or pickle file.
# pLDDT (predicted Local Distance Difference Test) scores range from 0 to 100.
# Each entry corresponds to the confidence score for a single amino acid residue.
plddt_scores = [
    95.2,  # Residue 1: High confidence (likely alpha-helix or beta-sheet core)
    96.1,  # Residue 2
    88.5,  # Residue 3: Good confidence
    72.0,  # Residue 4: Acceptable, but less certain (e.g., surface loop)
    99.8,  # Residue 5
    10.5,  # Residue 6: Very low confidence (highly likely to be an intrinsically disordered region or flexible linker)
    94.0,  # Residue 7
    91.3   # Residue 8
]

# --- 2. Analysis Parameters (Thresholds) ---
TOTAL_RESIDUES = len(plddt_scores)
CONFIDENCE_THRESHOLD_HIGH = 90.0  # Threshold for excellent global confidence
CONFIDENCE_THRESHOLD_MEDIUM = 70.0 # Threshold below which regions are considered unreliable

# --- 3. Core Calculation: Mean pLDDT Score ---
# Calculate the sum of all confidence scores in the list.
total_score_sum = sum(plddt_scores)
# Calculate the arithmetic mean by dividing the sum by the total count of residues.
average_plddt = total_score_sum / TOTAL_RESIDUES

# --- 4. Classification Logic: Identifying Low Confidence Regions ---
low_confidence_count = 0
# Iterate through every individual score provided by AlphaFold.
for score in plddt_scores:
    # Check how many residues fall below the critical medium threshold (70.0).
    if score < CONFIDENCE_THRESHOLD_MEDIUM:
        low_confidence_count += 1

# --- 5. Output Generation and Reporting ---
print("--- AlphaFold Confidence Report ---")
# Use f-strings for clear, formatted output.
print(f"Total Residues Analyzed: {TOTAL_RESIDUES}")
print(f"Total pLDDT Score Sum: {total_score_sum:.2f}")
print(f"Overall Average pLDDT: {average_plddt:.2f}")
print(f"Residues below Medium Confidence ({CONFIDENCE_THRESHOLD_MEDIUM:.1f}): {low_confidence_count}")

# --- 6. Interpretation Summary ---
if average_plddt >= CONFIDENCE_THRESHOLD_HIGH:
    reliability_summary = "EXCELLENT: Structure is highly reliable across the entire chain."
elif average_plddt >= CONFIDENCE_THRESHOLD_MEDIUM:
    # Note: If the average is good, but there are low-scoring segments, the user must investigate those segments.
    reliability_summary = "GOOD: Core structure is reliable, but check low-scoring regions (e.g., loops or terminal ends)."
else:
    reliability_summary = "POOR: Caution advised. Structure likely contains large disordered or incorrect domains."

print("\nInterpretation:")
print(reliability_summary)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import pandas as pd
import io

# Reuse the simulated PDB content (contains all atoms)
pdb_content = """
REMARK 465
ATOM      1  N   MET A   1      51.000  45.123  30.567  1.00 95.12           N  
ATOM      2  CA  MET A   1      52.123  46.000  31.000  1.00 95.12           C  
ATOM      3  C   MET A   1      53.000  45.123  32.000  1.00 95.12           C  
ATOM      4  CB  MET A   1      51.500  47.100  30.100  1.00 95.12           C  
ATOM      5  N   GLY A   2      54.000  47.123  33.567  1.00 88.55           N  
ATOM      6  CA  GLY A   2      55.000  48.000  35.000  1.00 88.55           C  
ATOM      7  C   GLY A   2      56.000  47.123  36.000  1.00 88.55           C  
# Introduce a malformed line to test error handling
ATOM      8  N   SER A   3      57.000  46.123  37.567  1.00  ERROR           N  
ATOM      9  CA  SER A   3      58.000  47.000  38.000  1.00 65.20           C  
ATOM     10  C   SER A   3      59.000  46.123  39.000  1.00 65.20           C  
"""
PDB_FILENAME = "predicted_structure_full.pdb"
with open(PDB_FILENAME, 'w') as f:
    f.write(pdb_content)

# --- 1. Unified Extraction Script ---
all_atom_records = []
total_plddt = 0.0
valid_plddt_count = 0
line_number = 0

with open(PDB_FILENAME, 'r') as f:
    for line in f:
        line_number += 1
        if line.startswith("ATOM"):
            try:
                # 2. Extract fields using PDB fixed-width slicing
                atom_name = line[12:16].strip()
                res_seq = int(line[22:26].strip())
                x_coord = float(line[30:38].strip())
                y_coord = float(line[38:46].strip())
                z_coord = float(line[46:54].strip())
                plddt_score = float(line[60:66].strip()) # B-factor column

                # 3. Store data
                record = (atom_name, res_seq, x_coord, y_coord, z_coord, plddt_score)
                all_atom_records.append(record)

                # For global average calculation
                total_plddt += plddt_score
                valid_plddt_count += 1

            except ValueError as e:
                # Advanced Requirement: Handle type coercion errors
                print(f"Warning: Skipping line {line_number} due to malformed numerical field (Error: {e}).")
                continue

# Convert to DataFrame for structured output
df_atoms = pd.DataFrame(all_atom_records, 
                        columns=['Atom', 'ResID', 'X', 'Y', 'Z', 'pLDDT'])

# 4. Reporting
global_avg_plddt = total_plddt / valid_plddt_count if valid_plddt_count > 0 else 0

print(f"Total atoms processed (with valid pLDDT): {valid_plddt_count}")
print(f"Global Average pLDDT Score: {global_avg_plddt:.2f}")
print("\nFirst five records prepared for visualization:")
print(df_atoms.head().to_markdown(index=False, floatfmt=".3f"))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import abc
import numpy as np
import contextvars
from datetime import datetime
import os

# --- Setup: Simulate Input Data (Reusing data from Ex 2 & 3) ---
# pLDDT data (list of scores for CA atoms)
plddt_data_sim = [95.12, 88.55, 65.20, 42.00, 91.00, 75.50, 55.00, 30.00]
# PAE matrix (simulated rigid domains, flexible hinge)
N = 300
D1_size = 150
pae_matrix_sim = np.random.uniform(1.0, 3.0, (N, N))
pae_matrix_sim[0:150, 150:300] = 15.0 # High inter-domain error
pae_matrix_sim[150:300, 0:150] = 15.0 
DOMAIN_BOUNDARIES = (1, 150, 300) # (Start, Linker boundary, End)

# --- 1. Define the Context Variable ---
REPORT_ID = contextvars.ContextVar('REPORT_ID', default='UNKNOWN_MODEL')

# --- 2. Define the Interface (ABC) ---
class AbstractReliabilityReporter(abc.ABC):
    """ Defines the mandatory structure for any protein reliability assessment tool. """
    
    @abc.abstractmethod
    def _calculate_global_plddt(self, plddt_data: list) -> float:
        """ Calculates the mean pLDDT score for the protein. """
        pass

    @abc.abstractmethod
    def _identify_flexible_region(self, plddt_data: list, window_size: int = 5) -> tuple:
        """ Identifies the N-residue window with the lowest average pLDDT. """
        pass

    @abc.abstractmethod
    def _assess_pae_orientation(self, pae_matrix: np.ndarray, domain_boundaries: tuple) -> str:
        """ Assesses inter-domain coupling based on PAE. """
        pass

# --- 3. Implement the Concrete Class ---
class AlphaFoldReporter(AbstractReliabilityReporter):
    
    def _calculate_global_plddt(self, plddt_data: list) -> float:
        if not plddt_data:
            return 0.0
        return np.mean(plddt_data)

    def _identify_flexible_region(self, plddt_data: list, window_size: int = 5) -> tuple:
        # Simple simulation: finding the lowest average pLDDT in a window
        min_avg = 101.0
        min_index = -1
        
        # Ensure data is long enough for the window size
        if len(plddt_data) < window_size:
            return (1, len(plddt_data), self._calculate_global_plddt(plddt_data))

        for i in range(len(plddt_data) - window_size + 1):
            window_plddt = plddt_data[i:i + window_size]
            current_avg = np.mean(window_plddt)
            if current_avg < min_avg:
                min_avg = current_avg
                min_index = i + 1 # Use 1-based indexing for residue number
                
        return (min_index, min_index + window_size - 1, min_avg)

    def _assess_pae_orientation(self, pae_matrix: np.ndarray, domain_boundaries: tuple) -> str:
        # Domain boundaries: (start_res, linker_res, end_res)
        D1_end = domain_boundaries[1]
        
        # Calculate inter-domain PAE (D1 vs D2)
        inter_pae = pae_matrix[0:D1_end, D1_end:pae_matrix.shape[0]].mean()
        
        if inter_pae > 10.0:
            return f"Flexible Hinge (High Inter-PAE: {inter_pae:.2f})"
        elif inter_pae < 5.0:
            return f"Highly Coupled (Low Inter-PAE: {inter_pae:.2f})"
        else:
            return f"Moderately Coupled (Inter-PAE: {inter_pae:.2f})"

# --- 4. Report Generation Function (using contextvars and datetime) ---
def generate_report(reporter_instance: AlphaFoldReporter, model_id: str, date_str: str, plddt_data, pae_matrix, domain_boundaries):
    
    # Set the Context Variable for thread-safe logging/identification
    token = REPORT_ID.set(model_id)
    
    try:
        # Parse timestamp using specific format
        timestamp = datetime.strptime(date_str, "%Y-%m-%dT%H:%M:%S")
        
        # Run assessments
        global_plddt = reporter_instance._calculate_global_plddt(plddt_data)
        start, end, flex_plddt = reporter_instance._identify_flexible_region(plddt_data)
        pae_assessment = reporter_instance._assess_pae_orientation(pae_matrix, domain_boundaries)

        # Generate output
        report = f"""
======================================================
PROTEIN RELIABILITY REPORT
Model ID: {REPORT_ID.get()}
Generated On: {timestamp.strftime('%Y-%m-%d %H:%M:%S')}
======================================================
1. Global pLDDT Assessment:
   Average pLDDT Score: {global_plddt:.2f}

2. Local Flexibility Analysis (Window Size 5):
   Most Flexible Region: Residues {start} to {end}
   Average pLDDT in Region: {flex_plddt:.2f}

3. Domain Orientation Assessment:
   Domain Architecture: N-terminal (1-{domain_boundaries[1]}) / C-terminal ({domain_boundaries[1]+1}-{domain_boundaries[2]})
   Orientation Confidence: {pae_assessment}
"""
        return report
        
    finally:
        # Crucial step: reset the context variable
        REPORT_ID.reset(token)

# --- 5. Execution ---
reporter = AlphaFoldReporter()
report_output = generate_report(
    reporter,
    model_id="AF-Q99818-F1",
    date_str="2024-05-15T10:30:00",
    plddt_data=plddt_data_sim,
    pae_matrix=pae_matrix_sim,
    domain_boundaries=DOMAIN_BOUNDARIES
)

print(report_output)

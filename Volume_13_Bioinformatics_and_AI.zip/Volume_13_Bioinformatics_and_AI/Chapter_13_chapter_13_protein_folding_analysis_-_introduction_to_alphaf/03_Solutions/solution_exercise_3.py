
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np
import os

# --- 1. Setup: Simulate PAE matrix (N=300) ---
N = 300
D1_size = 150
D2_size = 150
PAE_FILENAME = 'pae_matrix.csv'

# Create a matrix where intra-domain is low error (~2.0) and inter-domain is high error (~15.0)
pae_matrix_sim = np.zeros((N, N))
pae_matrix_sim[:D1_size, :D1_size] = np.random.uniform(1.5, 2.5, (D1_size, D1_size))
pae_matrix_sim[D1_size:, D1_size:] = np.random.uniform(1.5, 2.5, (D2_size, D2_size))
pae_matrix_sim[:D1_size, D1_size:] = np.random.uniform(14.0, 16.0, (D1_size, D2_size))
pae_matrix_sim[D1_size:, :D1_size] = np.random.uniform(14.0, 16.0, (D2_size, D1_size))

np.savetxt(PAE_FILENAME, pae_matrix_sim, delimiter=',')

# --- 2. Data Loading and Domain Analysis ---
# Load the matrix
pae_data = np.loadtxt(PAE_FILENAME, delimiter=',')

# Define slices (Python uses 0-indexing, so 1-150 is 0:150)
D1_slice = slice(0, 150)
D2_slice = slice(150, 300)

# 3. Intra-Domain Stability Calculation
intra_d1_pae = pae_data[D1_slice, D1_slice].mean()
intra_d2_pae = pae_data[D2_slice, D2_slice].mean()

# 4. Inter-Domain Orientation Reliability Calculation (Top-Right block)
inter_domain_pae = pae_data[D1_slice, D2_slice].mean()

# --- 5. Reporting ---
print(f"--- PAE Domain Stability Report (Total Residues: {N}) ---")
print(f"Mean Intra-Domain 1 PAE (Res 1-150): {intra_d1_pae:.2f}")
print(f"Mean Intra-Domain 2 PAE (Res 151-300): {intra_d2_pae:.2f}")
print(f"Mean Inter-Domain PAE (D1 vs D2): {inter_domain_pae:.2f}")

print("\n--- Structural Conclusion ---")
if inter_domain_pae > 10.0: # High PAE typically indicates high relative error
    print("The inter-domain PAE is significantly higher than the intra-domain PAE.")
    print("Conclusion: The two domains are predicted to be independently folded (low internal error) but their relative spatial orientation is highly uncertain (high external error), suggesting a flexible linker or hinge.")
elif inter_domain_pae < 5.0:
    print("The inter-domain PAE is comparable to the intra-domain PAE.")
    print("Conclusion: The two domains are confidently oriented relative to each other, likely forming a single rigid structural unit.")
else:
    print("Conclusion: Moderate relative uncertainty, suggesting some hinge motion but a generally defined orientation.")

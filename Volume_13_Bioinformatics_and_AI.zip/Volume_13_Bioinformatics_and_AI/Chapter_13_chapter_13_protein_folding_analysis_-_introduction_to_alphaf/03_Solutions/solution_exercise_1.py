
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import io

# --- 1. Setup: Simulate PDB file content ---
pdb_content = """
REMARK 465
ATOM      1  N   MET A   1      51.000  45.123  30.567  1.00 95.12           N  
ATOM      2  CA  MET A   1      52.123  46.000  31.000  1.00 95.12           C  
ATOM      3  C   MET A   1      53.000  45.123  32.000  1.00 95.12           C  
ATOM      4  CB  MET A   1      51.500  47.100  30.100  1.00 95.12           C  
ATOM      5  N   GLY A   2      54.000  47.123  33.567  1.00 88.55           N  
ATOM      6  CA  GLY A   2      55.000  48.000  35.000  1.00 88.55           C  
ATOM      7  C   GLY A   2      56.000  47.123  36.000  1.00 88.55           C  
ATOM      8  N   SER A   3      57.000  46.123  37.567  1.00 65.20           N  
ATOM      9  CA  SER A   3      58.000  47.000  38.000  1.00 65.20           C  
ATOM     10  C   SER A   3      59.000  46.123  39.000  1.00 65.20           C  
ATOM     11  N   PRO A   4      60.000  45.123  40.567  1.00 42.00           N  
ATOM     12  CA  PRO A   4      61.000  46.000  41.000  1.00 42.00           C  
ATOM     13  C   PRO A   4      62.000  45.123  42.000  1.00 42.00           C  
"""
PDB_FILENAME = "predicted_structure.pdb"
with open(PDB_FILENAME, 'w') as f:
    f.write(pdb_content)

# --- 2. PDB Parsing Script ---
ca_records = []

with open(PDB_FILENAME, 'r') as f:
    for line in f:
        # Check if it is an ATOM record
        if line.startswith("ATOM"):
            atom_name = line[12:16].strip()
            
            # Filter for C-alpha atoms ('CA')
            if atom_name == 'CA':
                try:
                    record = {
                        'Residue_ID': int(line[22:26].strip()),
                        'Chain_ID': line[21:22].strip(),
                        'X': float(line[30:38].strip()),
                        'Y': float(line[38:46].strip()),
                        'Z': float(line[46:54].strip())
                    }
                    ca_records.append(record)
                except ValueError:
                    # Handle lines where coordinates might be malformed (unlikely in AF output)
                    print(f"Skipping malformed line: {line.strip()}")

# Convert to DataFrame for structured output
ca_df = pd.DataFrame(ca_records)

# --- 3. Reporting ---
print(f"Total C-alpha atoms successfully parsed: {len(ca_df)}")
print("\nFirst five C-alpha records:")
print(ca_df.head().to_markdown(index=False, floatfmt=".3f"))

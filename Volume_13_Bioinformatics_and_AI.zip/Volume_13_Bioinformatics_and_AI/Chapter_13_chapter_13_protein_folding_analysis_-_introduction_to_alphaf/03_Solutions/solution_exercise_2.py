
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import io
import pandas as pd

# Reuse the simulated PDB content from Exercise 1
pdb_content = """
REMARK 465
ATOM      1  N   MET A   1      51.000  45.123  30.567  1.00 95.12           N  
ATOM      2  CA  MET A   1      52.123  46.000  31.000  1.00 95.12           C  
# ... (intermediate atoms skipped for brevity)
ATOM      6  CA  GLY A   2      55.000  48.000  35.000  1.00 88.55           C  
# ...
ATOM      9  CA  SER A   3      58.000  47.000  38.000  1.00 65.20           C  
# ...
ATOM     12  CA  PRO A   4      61.000  46.000  41.000  1.00 42.00           C  
"""

PDB_FILENAME = "predicted_structure.pdb"
with open(PDB_FILENAME, 'w') as f:
    f.write(pdb_content)

# --- 1. Extraction and Binning Logic ---
plddt_scores = []
confidence_bins = {
    "Very High Confidence (>= 90)": 0,
    "High Confidence (70 - 89.9)": 0,
    "Low Confidence (50 - 69.9)": 0,
    "Very Low Confidence (< 50)": 0
}

with open(PDB_FILENAME, 'r') as f:
    for line in f:
        if line.startswith("ATOM") and line[12:16].strip() == 'CA':
            try:
                # pLDDT is in B-factor column (61-66, 0-indexed: 60:66)
                plddt = float(line[60:66].strip())
                plddt_scores.append(plddt)

                # 2. Confidence Binning
                if plddt >= 90.0:
                    confidence_bins["Very High Confidence (>= 90)"] += 1
                elif plddt >= 70.0:
                    confidence_bins["High Confidence (70 - 89.9)"] += 1
                elif plddt >= 50.0:
                    confidence_bins["Low Confidence (50 - 69.9)"] += 1
                else:
                    confidence_bins["Very Low Confidence (< 50)"] += 1
            except (ValueError, IndexError):
                # Handle parsing errors if B-factor field is missing or non-numeric
                continue

# --- 3. Aggregation and Reporting ---
total_residues = len(plddt_scores)
print(f"--- AlphaFold Model Reliability Report (Total Residues: {total_residues}) ---")

if total_residues > 0:
    for category, count in confidence_bins.items():
        percentage = (count / total_residues) * 100
        print(f"{category:<40}: {count:>3} residues ({percentage:.2f}%)")
else:
    print("No C-alpha atoms found for analysis.")

# Analysis Conclusion
if total_residues > 0:
    high_quality_percent = confidence_bins["Very High Confidence (>= 90)"] + confidence_bins["High Confidence (70 - 89.9)"]
    if high_quality_percent >= 75:
        print("\nConclusion: The model exhibits high overall structural quality, with most residues confidently predicted.")
    else:
        print("\nConclusion: Significant portions of the model fall into the Low or Very Low confidence ranges, suggesting flexibility or unstructured regions.")

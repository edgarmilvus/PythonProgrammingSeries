
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import collections

# Define the standard BERT special tokens and their IDs
SPECIAL_TOKENS = {'[CLS]': 0, '[SEP]': 1, '[PAD]': 2, '[UNK]': 3}

class KmerTokenizer:
    """
    A tokenizer specialized for genomic sequences using the overlapping k-mer method.
    """
    def __init__(self, k=6):
        self.k = k
        self.special_tokens = SPECIAL_TOKENS
        self.vocab = self.special_tokens.copy()
        self.id_to_token = {v: k for k, v in self.vocab.items()}
        self.vocab_size = len(self.vocab)

    def tokenize_sequence(self, sequence):
        """Generates overlapping k-mers from a raw DNA sequence."""
        if len(sequence) < self.k:
            return []
        
        # Generate overlapping k-mers: sequence[i:i+k]
        tokens = [sequence[i:i + self.k] for i in range(len(sequence) - self.k + 1)]
        return tokens

    def build_vocab(self, corpus):
        """Iterates through a corpus to build the complete k-mer vocabulary."""
        unique_kmers = set()
        for sequence in corpus:
            tokens = self.tokenize_sequence(sequence)
            unique_kmers.update(tokens)
        
        # Start assigning IDs after the special tokens
        current_id = len(self.special_tokens)
        
        for kmer in sorted(list(unique_kmers)): # Sort for deterministic ID assignment
            if kmer not in self.vocab:
                self.vocab[kmer] = current_id
                self.id_to_token[current_id] = kmer
                current_id += 1
        
        self.vocab_size = len(self.vocab)
        print(f"Vocabulary built. Total size: {self.vocab_size}")

    def encode(self, sequence, max_length=None):
        """Converts a raw DNA sequence into a list of token IDs."""
        tokens = self.tokenize_sequence(sequence)
        
        # 1. Map k-mers to IDs, using [UNK] if not found
        token_ids = [self.vocab.get(kmer, self.vocab['[UNK]']) for kmer in tokens]
        
        # 2. Prepend [CLS] and Append [SEP]
        input_ids = [self.vocab['[CLS]']] + token_ids + [self.vocab['[SEP]']]
        
        # 3. Handle padding and attention mask (basic implementation)
        attention_mask = [1] * len(input_ids)
        
        if max_length and len(input_ids) > max_length:
            # Truncation: Keep [CLS], truncate body, keep [SEP]
            input_ids = input_ids[:max_length - 1] + [self.vocab['[SEP]']]
            attention_mask = [1] * len(input_ids)
        
        if max_length and len(input_ids) < max_length:
            # Padding
            padding_needed = max_length - len(input_ids)
            input_ids += [self.vocab['[PAD]']] * padding_needed
            attention_mask += [0] * padding_needed
            
        return input_ids, attention_mask

# --- Verification Script ---
kmer_k = 6
tokenizer = KmerTokenizer(k=kmer_k)

# Test data example
test_corpus = ["ATGCGTACGTATGCGT", "CCGGTAAAGGGCCTA"]
test_sequence = "GATTACA" # Length 7, yields 7-6+1 = 2 k-mers

# 1. Build Vocabulary (k=6 yields 4^6 = 4096 potential biological tokens)
tokenizer.build_vocab(test_corpus)

# 2. Encode the test sequence (GATTACA -> GATTAC, ATTACA)
encoded_ids, mask = tokenizer.encode(test_sequence)

# Print results
print(f"\nTest Sequence: '{test_sequence}' (k={kmer_k})")
print(f"K-mers: {tokenizer.tokenize_sequence(test_sequence)}")
print(f"Encoded IDs (w/ [CLS]/[SEP]): {encoded_ids}")
print(f"Attention Mask: {mask}")
print(f"Decoded Tokens: {[tokenizer.id_to_token.get(id, '?') for id in encoded_ids]}")

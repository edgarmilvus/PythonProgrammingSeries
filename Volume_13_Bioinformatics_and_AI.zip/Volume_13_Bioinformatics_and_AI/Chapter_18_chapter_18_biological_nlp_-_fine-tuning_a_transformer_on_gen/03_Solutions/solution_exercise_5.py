
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from datasets import load_dataset, Dataset
import pandas as pd
import random
import os
import time

# Assume KmerTokenizer from Exercise 1 is available (re-defining minimally for context)
class KmerTokenizer:
    def __init__(self, k=6):
        self.k = k
        self.vocab = {'[CLS]': 0, '[SEP]': 1, '[PAD]': 2, '[UNK]': 3, 'GATTAC': 4, 'ATTACA': 5}
    
    def tokenize_sequence(self, sequence):
        if len(sequence) < self.k: return []
        return [sequence[i:i + self.k] for i in range(len(sequence) - self.k + 1)]

    def encode(self, sequence, max_length):
        tokens = self.tokenize_sequence(sequence)
        token_ids = [self.vocab.get(kmer, self.vocab['[UNK]']) for kmer in tokens]
        
        input_ids = [self.vocab['[CLS]']] + token_ids + [self.vocab['[SEP]']]
        
        # Truncation
        if len(input_ids) > max_length:
            input_ids = input_ids[:max_length - 1] + [self.vocab['[SEP]']]
        
        attention_mask = [1] * len(input_ids)
        
        # Padding
        if len(input_ids) < max_length:
            padding_needed = max_length - len(input_ids)
            input_ids += [self.vocab['[PAD]']] * padding_needed
            attention_mask += [0] * padding_needed
            
        return {'input_ids': input_ids, 'attention_mask': attention_mask}

tokenizer = KmerTokenizer(k=6)
MAX_LENGTH = 200
DATA_FILENAME = "genomic_data.csv"
NUM_SAMPLES = 500000 # Half a million samples

def generate_large_data(num_samples, filename):
    """Generates a large CSV file of random sequences and labels."""
    if os.path.exists(filename):
        print(f"Skipping data generation, {filename} already exists.")
        return
        
    bases = ['A', 'T', 'C', 'G']
    sequences = [''.join(random.choice(bases) for _ in range(MAX_LENGTH)) for _ in range(num_samples)]
    labels = [random.randint(0, 1) for _ in range(num_samples)]
    
    df = pd.DataFrame({'sequence': sequences, 'label': labels})
    df.to_csv(filename, index=False)
    print(f"Generated {num_samples} samples into {filename}.")

def preprocess_function(examples):
    """
    Tokenizes sequences using the KmerTokenizer and prepares inputs.
    Uses batched=True for efficient processing.
    """
    results = tokenizer.encode(examples['sequence'], max_length=MAX_LENGTH)
    results['labels'] = examples['label']
    return results

# --- Pipeline Execution ---
print("--- Step 1: Data Generation ---")
generate_large_data(NUM_SAMPLES, DATA_FILENAME)

# --- Step 2: Streaming and Loading ---
print("\n--- Step 2: Loading Data (Memory Mapping/Streaming) ---")
# Use streaming=True for potentially massive files, or default loading for CSV
start_time = time.time()
raw_datasets = load_dataset('csv', data_files=DATA_FILENAME, split='train')
print(f"Data loaded in {time.time() - start_time:.2f} seconds.")

# --- Step 3: Tokenization Mapping with Caching ---
print("\n--- Step 3: Applying Tokenization (Caching Check) ---")

# Run 1: Tokenization should take time and create cache files
start_time = time.time()
tokenized_datasets = raw_datasets.map(
    preprocess_function,
    batched=False, # Set to False for simplicity in dummy tokenizer, True for production
    remove_columns=['sequence'],
    load_from_cache_file=True # Default behavior, explicitly shown
)
time_run_1 = time.time() - start_time
print(f"Run 1: Tokenization completed in {time_run_1:.2f} seconds.")

# Run 2: Tokenization should load from cache almost instantly
start_time = time.time()
tokenized_datasets_cached = raw_datasets.map(
    preprocess_function,
    batched=False,
    remove_columns=['sequence'],
    load_from_cache_file=True
)
time_run_2 = time.time() - start_time
print(f"Run 2 (Cached): Tokenization completed in {time_run_2:.2f} seconds.")
print(f"Caching verification: Run 2 is significantly faster than Run 1.")

# --- Step 4: Format Conversion ---
print("\n--- Step 4: Format Conversion to PyTorch ---")
final_dataset = tokenized_datasets.with_format(
    "torch", 
    columns=['input_ids', 'attention_mask', 'labels']
)

print(f"Final dataset type: {type(final_dataset)}")
print(f"Example PyTorch tensor shape (Input IDs): {final_dataset[0]['input_ids'].shape}")

# Cleanup (optional)
# os.remove(DATA_FILENAME) 
# Note: Cache files remain in ~/.cache/huggingface/datasets

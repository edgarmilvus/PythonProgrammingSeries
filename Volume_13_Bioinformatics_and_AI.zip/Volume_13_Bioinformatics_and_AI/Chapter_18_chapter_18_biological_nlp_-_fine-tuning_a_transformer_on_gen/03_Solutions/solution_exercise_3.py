
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from transformers import AutoModelForSequenceClassification, TrainingArguments, Trainer
from datasets import Dataset, load_dataset, load_metric
from sklearn.metrics import f1_score, accuracy_score, confusion_matrix
import numpy as np
import pandas as pd
import io

# --- Setup Dummy Tokenizer (Based on Exercise 1) ---
class DummyKmerTokenizer:
    def __init__(self, k=6):
        self.k = k
        self.vocab = {'[CLS]': 0, '[SEP]': 1, '[PAD]': 2, '[UNK]': 3, 'GATTAC': 4, 'ATTACA': 5}
    
    def tokenize_sequence(self, sequence):
        if len(sequence) < self.k: return []
        return [sequence[i:i + self.k] for i in range(len(sequence) - self.k + 1)]

    def encode(self, sequence, max_length=128):
        tokens = self.tokenize_sequence(sequence)
        token_ids = [self.vocab.get(kmer, self.vocab['[UNK]']) for kmer in tokens]
        
        input_ids = [self.vocab['[CLS]']] + token_ids + [self.vocab['[SEP]']]
        
        # Simple Truncation/Padding for demonstration
        input_ids = input_ids[:max_length] 
        attention_mask = [1] * len(input_ids)
        
        if len(input_ids) < max_length:
            padding_needed = max_length - len(input_ids)
            input_ids += [self.vocab['[PAD]']] * padding_needed
            attention_mask += [0] * padding_needed
            
        return {'input_ids': input_ids, 'attention_mask': attention_mask}

tokenizer = DummyKmerTokenizer(k=6)
MAX_LENGTH = 128
NUM_REGULATORY_CLASSES = 3
MODEL_CHECKPOINT = "dnacoding/dnacbert-6" # Placeholder

# Step 1: Model Configuration Adaptation
# We use a try-except block here as we cannot actually load the checkpoint 
# without internet access and disk space, but this demonstrates the required parameter.
try:
    model = AutoModelForSequenceClassification.from_pretrained(
        MODEL_CHECKPOINT,
        num_labels=NUM_REGULATORY_CLASSES, # CRITICAL: Sets the output size of the classification head
        ignore_mismatched_sizes=True # Needed if the original head was binary
    )
except OSError:
    print(f"Placeholder: Model configured for {NUM_REGULATORY_CLASSES} classes.")
    model = None # Placeholder model

# Step 2: Dataset Transformation
def generate_dummy_data():
    data = {
        'sequence': ["GATTACA" * 10, "CCGTAA" * 10, "TATAATA" * 10, "GATTACA" * 9, "CCGTAA" * 9, "TATAATA" * 9],
        'label': [0, 1, 2, 0, 1, 2] # 0: Enhancer, 1: Silencer, 2: Insulator
    }
    return Dataset.from_dict(data)

def preprocess_function(examples):
    """Tokenizes and ensures label format."""
    tokenized_inputs = tokenizer.encode(examples['sequence'], max_length=MAX_LENGTH)
    tokenized_inputs['labels'] = examples['label']
    return tokenized_inputs

raw_dataset = generate_dummy_data()
tokenized_datasets = raw_dataset.map(preprocess_function, remove_columns=['sequence'])
print(f"\nExample Tokenized Data Entry: {tokenized_datasets[0]}")


# Step 3: Metric Definition
def compute_multi_class_metrics(pred):
    """
    Calculates weighted F1 and accuracy for multi-class prediction, 
    and generates a normalized confusion matrix.
    """
    labels = pred.label_ids
    # pred.predictions is the raw logits; np.argmax converts logits to class predictions
    preds = np.argmax(pred.predictions, axis=1)

    # Calculate metrics
    accuracy = accuracy_score(labels, preds)
    weighted_f1 = f1_score(labels, preds, average='weighted')
    
    # Generate Confusion Matrix
    cm = confusion_matrix(labels, preds, normalize='true')
    
    # Format CM for output (using io.StringIO to capture matrix output)
    cm_output = io.StringIO()
    pd.DataFrame(cm, 
                 index=['True Enhancer (0)', 'True Silencer (1)', 'True Insulator (2)'], 
                 columns=['Pred Enhancer (0)', 'Pred Silencer (1)', 'Pred Insulator (2)']
                 ).to_string(cm_output)
    
    print("\n--- Normalized Confusion Matrix (Rows are True Labels) ---")
    print(cm_output.getvalue())

    return {
        'accuracy': accuracy,
        'weighted_f1': weighted_f1,
    }

# Step 4: Training Argument Setup (Placeholder for Trainer initialization)
training_args = TrainingArguments(
    output_dir="./multi_class_results",
    num_train_epochs=3,
    per_device_train_batch_size=8,
    evaluation_strategy="epoch",
    logging_dir='./logs',
    logging_steps=10,
    report_to="none",
    # Implicitly uses Cross-Entropy Loss because num_labels > 2
)

# Example Trainer initialization (requires model and data)
# trainer = Trainer(
#     model=model,
#     args=training_args,
#     train_dataset=tokenized_datasets,
#     eval_dataset=tokenized_datasets,
#     compute_metrics=compute_multi_class_metrics,
# )
# print("\nTrainer setup complete with multi-class metrics.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np

# Setup constants
MASK_ID = 4 # Assuming [MASK] is ID 4, following the 4 special tokens 0-3
IGNORE_INDEX = -100
P_MASK = 0.15 # 15% probability of a token being selected for modification

# Dummy tokenized sequences (IDs). Note: IDs > 3 are biological k-mers.
dummy_input_ids = [
    [0, 5, 6, 7, 8, 9, 10, 1],
    [0, 11, 12, 13, 14, 15, 1]
]
VOCAB_SIZE = 4100 # Includes [CLS], [SEP], [PAD], [UNK], [MASK] (ID 0-4)
BIOLOGICAL_VOCAB_START_ID = 5 # Biological k-mers start at ID 5 (if [MASK] is 4)

def apply_genomic_masking(input_ids_list, vocab_size):
    """
    Applies the DNABERT 80/10/10 masking strategy to a batch of token IDs.
    Returns the masked input and the corresponding labels.
    """
    input_ids_masked = []
    labels = []
    
    # Generate a pool of valid biological k-mer IDs for random replacement
    # Assuming IDs 0-4 are special tokens ([CLS], [SEP], [PAD], [UNK], [MASK])
    biological_ids = np.arange(BIOLOGICAL_VOCAB_START_ID, vocab_size)

    for seq_ids in input_ids_list:
        seq_len = len(seq_ids)
        
        # Initialize labels: -100 means 'do not predict this token'
        current_labels = np.full(seq_len, IGNORE_INDEX, dtype=np.int32)
        current_masked_ids = np.array(seq_ids, dtype=np.int32)
        
        # 1. Determine which tokens to select for modification (15%)
        # Exclude special tokens ([CLS], [SEP]) at positions 0 and seq_len-1
        
        # Masking selection probability array (0 for special tokens, P_MASK otherwise)
        selection_probs = np.full(seq_len, P_MASK)
        selection_probs[[0, seq_len - 1]] = 0.0 # Never mask [CLS] or [SEP]
        
        # Randomly select tokens based on probability
        is_selected = np.random.rand(seq_len) < selection_probs
        selected_indices = np.where(is_selected)[0]

        # If no tokens are selected, continue
        if len(selected_indices) == 0:
            input_ids_masked.append(current_masked_ids.tolist())
            labels.append(current_labels.tolist())
            continue

        # 2. Store original IDs in the labels tensor
        current_labels[selected_indices] = current_masked_ids[selected_indices]

        # 3. Apply 80/10/10 modification rule to selected tokens
        modification_rolls = np.random.rand(len(selected_indices))

        for i, idx in enumerate(selected_indices):
            roll = modification_rolls[i]
            
            if roll < 0.8:
                # 80%: Replace with [MASK] token
                current_masked_ids[idx] = MASK_ID
            elif roll < 0.9:
                # 10%: Replace with a random biological k-mer
                random_kmer_id = np.random.choice(biological_ids)
                current_masked_ids[idx] = random_kmer_id
            # else (10%): Keep original ID (no change to current_masked_ids)

        input_ids_masked.append(current_masked_ids.tolist())
        labels.append(current_labels.tolist())
        
    return input_ids_masked, labels

# --- Verification ---
print(f"Original Input IDs: {dummy_input_ids[0]}")
masked_input, labels = apply_genomic_masking(dummy_input_ids, VOCAB_SIZE)

print("\n--- Result for Sequence 1 ---")
print(f"Masked Input IDs: {masked_input[0]}")
print(f"Labels (Target IDs): {labels[0]}")
print(f"Number of tokens selected for masking: {np.sum(np.array(labels[0]) != IGNORE_INDEX)}")

# Conceptual Check Explanation:
print("\n--- Conceptual Check on Overlap ---")
print("Conceptual Explanation: Masking a k-mer (e.g., a 6-mer) differs from masking a standard word because k-mers overlap (a 6-mer shares 5 nucleotides with its neighbors). If we mask K_i, the neighboring tokens K_{i-1} and K_{i+1} still contain 5/6ths of the information needed to predict K_i. This necessitates that the model predicts the *full k-mer ID* based on context, rather than predicting individual nucleotides. The redundancy forces the model to learn long-range dependencies and non-local patterns instead of trivial local reconstruction.")

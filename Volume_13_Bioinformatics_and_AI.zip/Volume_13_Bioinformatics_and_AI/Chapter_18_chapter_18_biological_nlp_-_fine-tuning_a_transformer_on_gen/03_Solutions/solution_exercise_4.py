
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np
import graphviz

K = 6 # K-mer length

def aggregate_kmer_attention_to_nucleotide(sequence, kmer_attention_scores, k):
    """
    Maps k-mer attention scores back to individual nucleotide importance scores
    by averaging the attention scores of all overlapping k-mers.
    """
    L = len(sequence)
    if L < k:
        return {} # Sequence too short
    
    # Initialize importance scores for each nucleotide
    nucleotide_importance = np.zeros(L)
    nucleotide_counts = np.zeros(L) # Tracks how many k-mers cover position i

    # Note: k-mer attention scores corresponds to the k-mers generated from the sequence body.
    # We ignore attention to [CLS] and [SEP] for this aggregation, focusing only on the body tokens.
    
    for kmer_index, score in enumerate(kmer_attention_scores):
        # A k-mer starting at kmer_index covers nucleotides from 
        # kmer_index up to kmer_index + k - 1
        
        start_nuc = kmer_index
        end_nuc = kmer_index + k
        
        nucleotide_importance[start_nuc:end_nuc] += score
        nucleotide_counts[start_nuc:end_nuc] += 1

    # Calculate the average importance score for each nucleotide
    # Handle division by zero for safety, though unlikely if L >= K
    avg_importance = np.divide(nucleotide_importance, nucleotide_counts, 
                               out=np.zeros_like(nucleotide_importance), 
                               where=nucleotide_counts != 0)
    
    # Map results back to a dictionary {nucleotide: score}
    return {sequence[i]: avg_importance[i] for i in range(L)}

def generate_dot_visualization(sequence, importance_scores):
    """
    Generates Graphviz DOT code to visualize the sequence with node attributes
    (color/size) based on importance scores.
    """
    dot = graphviz.Digraph(comment='Attention Hotspots', graph_attr={'rankdir': 'LR'})
    
    # Normalize scores for visualization (0 to 1)
    scores = np.array(list(importance_scores.values()))
    if scores.max() > 0:
        normalized_scores = scores / scores.max()
    else:
        normalized_scores = np.zeros_like(scores)

    for i, (nuc, score) in enumerate(importance_scores.items()):
        norm_score = normalized_scores[i]
        
        # Color intensity: higher score -> darker red (using HSV scale)
        # Hue=0 (Red), Saturation=1 (Full), Value=0.5 + norm_score/2 (Brightness)
        brightness = 0.5 + norm_score / 2
        color = f"0 1.0 {brightness}" # H S V (Red, Full Sat, Variable Brightness)
        
        # Size/Shape: Use fixed size but vary fill color
        dot.node(
            name=str(i),
            label=nuc,
            shape='box',
            style='filled',
            fillcolor=color,
            fontcolor='white',
            fontsize=str(20 + norm_score * 30) # Scale font size slightly
        )
        
        # Connect nodes sequentially
        if i > 0:
            dot.edge(str(i-1), str(i), style='invis') # Invisible connection for sequence flow
            
    return dot.source

# --- Verification Simulation ---
TEST_SEQUENCE = "ATGCGTATGCGT" # L=12
# This sequence yields 12 - 6 + 1 = 7 k-mers.
# Simulate attention scores (e.g., from the [CLS] token head)
# Let the central k-mer (index 3, covering G T A T G C) have the highest attention.
simulated_kmer_attention = np.array([0.1, 0.2, 0.5, 0.9, 0.5, 0.2, 0.1])

# Aggregate scores
importance_map = aggregate_kmer_attention_to_nucleotide(
    TEST_SEQUENCE, 
    simulated_kmer_attention, 
    K
)

print(f"Sequence: {TEST_SEQUENCE}")
print(f"Per-Nucleotide Importance Scores (k={K}):")
for i, (nuc, score) in enumerate(importance_map.items()):
    print(f"Pos {i} ({nuc}): {score:.3f}")

# Generate DOT code
dot_code = generate_dot_visualization(TEST_SEQUENCE, importance_map)

print("\n--- Generated Graphviz DOT Code (Visualize via Graphviz tool) ---")
print(dot_code)

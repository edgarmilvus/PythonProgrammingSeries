
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import sys
from typing import List

# Define a standard k-mer size used in many genomic NLP tasks.
# DNABERT was pre-trained using 3-mers, 4-mers, 5-mers, and 6-mers.
# We select 6 as a representative example for context modeling.
K_MER_SIZE = 6

def tokenize_dna_kmer(sequence: str, k: int) -> str:
    """
    Converts a raw DNA sequence string into a space-separated string of overlapping k-mers.
    This simulates the initial tokenization step required for Transformer models 
    specialized in biological sequences (e.g., DNABERT).

    :param sequence: The input DNA sequence (must be uppercase and contain only A, T, C, G).
    :param k: The length of the k-mer (e.g., 3, 4, 5, or 6).
    :return: A string of k-mer tokens separated by spaces.
    :raises ValueError: If k is invalid or the sequence is too short.
    """
    
    # 1. Input Validation and Preprocessing
    if not isinstance(sequence, str):
        raise TypeError("Input sequence must be a string.")
    
    sequence = sequence.upper() # Ensure consistency
    
    if k <= 0:
        raise ValueError(f"K-mer size must be positive. Received k={k}.")
        
    if k > len(sequence):
        # A k-mer cannot be longer than the sequence itself.
        raise ValueError(f"K-mer size ({k}) exceeds sequence length ({len(sequence)}).")

    # 2. Storage Initialization
    # Using a list for appending tokens is significantly more efficient than 
    # repeated string concatenation in Python.
    kmer_list: List[str] = []

    # 3. Sliding Window Iteration
    # The loop runs from index 0 up to the point where the k-mer window exactly
    # fits the remaining sequence length.
    # The range calculation guarantees no IndexError.
    end_index = len(sequence) - k + 1
    
    for i in range(end_index):
        # 4. Extract the k-mer substring
        # Python slicing [start:stop] is inclusive of 'start' and exclusive of 'stop'.
        # Here, stop = i + k.
        kmer = sequence[i : i + k]

        # 5. Append the extracted token
        kmer_list.append(kmer)

    # 6. Final Output Generation
    # Transformer tokenizers typically expect tokens to be delimited by spaces.
    return " ".join(kmer_list)

# --- Simulation Context ---
# A synthetic sequence representing a short regulatory region (e.g., a promoter site).
GENETIC_SEQUENCE = "ATGCCTAGTTGCAAGCCG"

print(f"--- Biological NLP Tokenizer Initialization ---")
print(f"Original Sequence (L={len(GENETIC_SEQUENCE)}): {GENETIC_SEQUENCE}")
print(f"Target K-mer Size (K): {K_MER_SIZE}")

# Calculate the expected number of tokens based on the formula: L - K + 1
expected_tokens = len(GENETIC_SEQUENCE) - K_MER_SIZE + 1
print(f"Expected Number of Tokens (L - K + 1): {expected_tokens}")
print("-" * 50)

# 1. Execute the tokenization
try:
    tokenized_output = tokenize_dna_kmer(GENETIC_SEQUENCE, K_MER_SIZE)

    # 2. Display results
    print(f"Tokenized Output ({K_MER_SIZE}-mers):")
    print(tokenized_output)

    # 3. Verification
    actual_tokens = tokenized_output.split(" ")
    print("-" * 50)
    print(f"Actual Number of Tokens Generated: {len(actual_tokens)}")

    # Sanity check on the first and last tokens
    print(f"First Token: '{actual_tokens[0]}'")
    print(f"Last Token: '{actual_tokens[-1]}'")

except (ValueError, TypeError) as e:
    print(f"FATAL ERROR during tokenization: {e}", file=sys.stderr)

# Example of an invalid input (k too large)
try:
    tokenize_dna_kmer("ATGC", 5)
except ValueError as e:
    print(f"\nTest Case: Invalid K-mer Size Error caught successfully: {e}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import torch
import numpy as np
from datasets import Dataset
from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    TrainingArguments,
    Trainer,
    EvalPrediction
)
from sklearn.metrics import roc_auc_score, accuracy_score
import random

# --- 1. Configuration and Data Simulation ---

# The k-mer size used for pre-training DNABERT. We use k=6.
K_MER_SIZE = 6 
MODEL_NAME = f'zhihan1996/DNABERT-{K_MER_SIZE}' 
SEQUENCE_LENGTH = 150 # Standardized length for simulation
NUM_SAMPLES = 1000

def generate_dna_sequence(length):
    """Generates a random DNA sequence."""
    return "".join(random.choice("ATCG") for _ in range(length))

def simulate_data(n_samples):
    """
    Simulates a small, balanced dataset of DNA sequences and labels.
    In a real scenario, this would be loaded from a FASTA/BED file.
    """
    data = []
    # Simulate positive (enhancer) and negative (non-enhancer) examples
    for i in range(n_samples):
        sequence = generate_dna_sequence(SEQUENCE_LENGTH)
        # Simple heuristic for label assignment in simulation (50/50 split)
        label = 1 if i < n_samples / 2 else 0
        data.append({'sequence': sequence, 'label': label})
    return data

# Generate and split the simulated data
raw_data = simulate_data(NUM_SAMPLES)
random.shuffle(raw_data)
split_point = int(NUM_SAMPLES * 0.8)
train_data = raw_data[:split_point]
eval_data = raw_data[split_point:]

# Convert lists of dicts into Hugging Face Dataset objects
train_dataset = Dataset.from_list(train_data)
eval_dataset = Dataset.from_list(eval_data)

print(f"Loaded {len(train_dataset)} training samples.")

# --- 2. K-mer Tokenization Function ---

def kmer_tokenize(sequence, k):
    """
    Converts a raw DNA sequence into a space-separated string of k-mers.
    This structure mimics natural language words and is required by DNABERT.
    Example: 'ATGC' (k=3) -> 'ATG TGC'
    """
    tokens = [sequence[i:i + k] for i in range(len(sequence) - k + 1)]
    return " ".join(tokens)

# --- 3. Model and Tokenizer Setup ---

# Load the specialized tokenizer (it primarily handles padding/truncation)
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)

# Load the pre-trained DNABERT model head for sequence classification
model = AutoModelForSequenceClassification.from_pretrained(
    MODEL_NAME,
    num_labels=2, # Binary classification (Enhancer vs. Non-Enhancer)
    ignore_mismatched_sizes=True # Handle potential output layer size changes
)

# --- 4. Dataset Preprocessing Pipeline ---

def preprocess_function(examples):
    """
    Applies k-mer tokenization and then the standard BERT tokenizer.
    """
    # 1. Apply biological k-mer transformation
    kmer_sequences = [kmer_tokenize(seq, K_MER_SIZE) for seq in examples['sequence']]
    
    # 2. Apply standard BERT tokenization (mapping k-mers to IDs)
    tokenized_output = tokenizer(
        kmer_sequences, 
        truncation=True, 
        padding='max_length', 
        max_length=SEQUENCE_LENGTH - K_MER_SIZE + 1
    )
    
    # Ensure labels are included
    tokenized_output['labels'] = examples['label']
    return tokenized_output

# Map the preprocessing function across the datasets
tokenized_train_dataset = train_dataset.map(preprocess_function, batched=True)
tokenized_eval_dataset = eval_dataset.map(preprocess_function, batched=True)

# --- 5. Metrics Definition ---

def compute_metrics(p: EvalPrediction):
    """
    Defines the evaluation metrics, prioritizing ROC AUC for classification performance.
    """
    # p.predictions contains the logits (raw outputs)
    logits = p.predictions[0] if isinstance(p.predictions, tuple) else p.predictions
    
    # Convert logits to probabilities using softmax (or just focus on the positive class logit)
    probabilities = torch.softmax(torch.tensor(logits), dim=-1).numpy()
    
    # Get the probability of the positive class (index 1)
    y_scores = probabilities[:, 1]
    
    y_true = p.label_ids
    y_pred = np.argmax(logits, axis=1)

    roc_auc = roc_auc_score(y_true, y_scores)
    accuracy = accuracy_score(y_true, y_pred)
    
    return {'roc_auc': roc_auc, 'accuracy': accuracy}

# --- 6. Training Setup and Execution ---

training_args = TrainingArguments(
    output_dir="./dnabert_enhancer_finetune",
    num_train_epochs=3,
    per_device_train_batch_size=16,
    per_device_eval_batch_size=32,
    warmup_steps=100,
    weight_decay=0.01,
    logging_dir='./logs',
    logging_steps=50,
    evaluation_strategy="epoch",
    save_strategy="epoch",
    load_best_model_at_end=True,
    metric_for_best_model="roc_auc",
    seed=42
)

# Initialize the Trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_train_dataset,
    eval_dataset=tokenized_eval_dataset,
    tokenizer=tokenizer,
    compute_metrics=compute_metrics,
)

# Execute the fine-tuning process
print("\nStarting DNABERT fine-tuning...")
train_result = trainer.train()

# Final evaluation on the test set
print("\nFinal Evaluation Results:")
eval_results = trainer.evaluate()
print(eval_results)

# Save the fine-tuned model
trainer.save_model("./dnabert_enhancer_model_final")

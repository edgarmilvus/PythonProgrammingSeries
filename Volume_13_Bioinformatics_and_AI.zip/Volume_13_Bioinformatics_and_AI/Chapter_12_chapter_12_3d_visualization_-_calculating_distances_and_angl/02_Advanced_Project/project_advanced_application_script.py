
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np

# --- 1. Data Definition (Simulated PDB Coordinates for a Peptide Segment) ---
# Coordinates are stored as a dictionary mapping (Residue_ID, Atom_Name) to a NumPy array (X, Y, Z).
# This segment represents the C-terminus of one residue and the N-terminus of the next.
# Atoms used: C_alpha (CA), Carbonyl C (C), Carbonyl O (O), Amide N (N), and next C_alpha (CA').
COORDINATES = {
    (1, 'CA'): np.array([1.500, 2.000, 3.000]),
    (1, 'C'):  np.array([2.500, 1.500, 2.500]),
    (1, 'O'):  np.array([3.000, 0.500, 2.700]),
    (2, 'N'):  np.array([2.000, 1.800, 1.500]),
    (2, 'CA'): np.array([2.500, 2.500, 0.500]),
    (2, 'C'):  np.array([3.500, 2.000, 0.000]),
}

# --- 2. Core Geometric Utility Functions ---

def calculate_distance(p1: np.ndarray, p2: np.ndarray) -> float:
    """Calculates the Euclidean distance between two points."""
    # The norm function calculates the length (magnitude) of the vector difference.
    return np.linalg.norm(p1 - p2)

def calculate_angle(p1: np.ndarray, p2: np.ndarray, p3: np.ndarray) -> float:
    """Calculates the angle (in degrees) formed by three points, centered at p2."""
    # Vector 1 (p2 -> p1)
    v1 = p1 - p2
    # Vector 2 (p2 -> p3)
    v2 = p3 - p2
    
    # Calculate the dot product and the product of the norms
    dot_product = np.dot(v1, v2)
    norm_product = np.linalg.norm(v1) * np.linalg.norm(v2)
    
    # Avoid division by zero or errors from floating point precision near 1 or -1
    cosine_theta = np.clip(dot_product / norm_product, -1.0, 1.0)
    
    # Calculate angle in radians and convert to degrees
    angle_rad = np.arccos(cosine_theta)
    return np.degrees(angle_rad)

def calculate_dihedral(p1: np.ndarray, p2: np.ndarray, p3: np.ndarray, p4: np.ndarray) -> float:
    """
    Calculates the signed dihedral angle (in degrees) defined by four points (p1-p2-p3-p4).
    This angle describes the rotation of the p1-p2 bond relative to the p3-p4 bond.
    """
    # Define the three vectors connecting the four points
    b1 = p2 - p1
    b2 = p3 - p2
    b3 = p4 - p3

    # Calculate the normal vector to the first plane (defined by p1, p2, p3)
    n1 = np.cross(b1, b2)
    # Calculate the normal vector to the second plane (defined by p2, p3, p4)
    n2 = np.cross(b2, b3)

    # Normalize n1 and n2 for stability, though not strictly required for the final angle
    n1_unit = n1 / np.linalg.norm(n1)
    n2_unit = n2 / np.linalg.norm(n2)
    
    # Calculate the cosine of the angle between the two normal vectors (n1 and n2)
    # This gives the magnitude of the dihedral angle.
    cos_phi = np.dot(n1_unit, n2_unit)
    
    # Use the triple scalar product to determine the sign (rotation direction)
    # The sign is determined by the projection of n1 x n2 onto b2.
    # The standard formula uses atan2 for robustness and signed output.
    
    # The vector perpendicular to n1 and n2, lying in the plane of rotation
    m = np.cross(n1, b2 / np.linalg.norm(b2))
    
    # Calculate the signed angle using arctan2
    # Argument 1 (y): projection of n2 onto m (determines sine/sign)
    # Argument 2 (x): dot product of n1 and n2 (determines cosine/magnitude)
    y = np.dot(m, b3) / np.linalg.norm(m)
    x = np.dot(n1, n2)
    
    # Note: A simpler, more common implementation for dihedral uses the following structure:
    # y = np.dot(np.cross(n1, n2), b2)
    # x = np.dot(n1, n2) * np.linalg.norm(b2)
    # However, for pure mathematical clarity and robustness, we use the standard vector approach:
    
    # Final robust calculation using atan2:
    dihedral_rad = np.arctan2(np.dot(np.cross(n1, n2), b2), np.dot(n1, n2) * np.linalg.norm(b2))
    
    return np.degrees(dihedral_rad)


# --- 3. Application Logic ---

def analyze_structure(coords: dict):
    """Performs specific structural analyses on the peptide coordinates."""
    print("--- Molecular Geometry Analysis ---")

    # A. Calculate a Standard Bond Angle (C-alpha, C, N angle)
    # This angle is crucial for the planarity of the peptide bond environment.
    p_ca1 = coords[(1, 'CA')]
    p_c1 = coords[(1, 'C')]
    p_n2 = coords[(2, 'N')]
    
    bond_angle_c_n = calculate_angle(p_ca1, p_c1, p_n2)
    print(f"\n1. C(1)-C(1)-N(2) Bond Angle: {bond_angle_c_n:.2f} degrees")
    print("   (Ideal tetrahedral bond angles are ~109.5°, but peptide bonds are planar, affecting this value.)")

    # B. Calculate the Psi (ψ) Dihedral Angle
    # Psi is defined by the atoms: C(i-1) - N(i) - Cα(i) - C(i).
    # In our case, this is C(1) - N(2) - CA(2) - C(2).
    p_c1 = coords[(1, 'C')]
    p_n2 = coords[(2, 'N')]
    p_ca2 = coords[(2, 'CA')]
    p_c2 = coords[(2, 'C')]

    psi_angle = calculate_dihedral(p_c1, p_n2, p_ca2, p_c2)
    print(f"\n2. Backbone Psi (ψ) Dihedral Angle (C1-N2-CA2-C2): {psi_angle:.2f} degrees")
    print("   (This angle determines the rotation around the N-Cα bond and dictates secondary structure.)")

    # C. Check for Potential Intramolecular Hydrogen Bond (H-bond)
    # We check the distance between the donor (N2) and acceptor (O1).
    # Standard H-bond criteria: Distance (D-A) < 3.5 Å AND Angle (H-D-A) > 120°.
    # Since we lack H coordinates, we use a proxy angle: D-A-X (where X is the atom bonded to the acceptor).
    
    # Donor (D): N2
    # Acceptor (A): O1
    # Acceptor Neighbor (X): C1
    
    p_o1 = coords[(1, 'O')]
    p_c1_hbond = coords[(1, 'C')] # Atom bonded to Acceptor O1
    p_n2_hbond = coords[(2, 'N')]
    
    # C.1. Distance Check
    d_n_o = calculate_distance(p_n2_hbond, p_o1)
    
    # C.2. Angle Check (using the N-O-C angle as a proxy for linearity)
    # Note: In a true H-bond analysis, we would calculate H-N-O angle. Here we use N-O-C.
    angle_n_o_c = calculate_angle(p_n2_hbond, p_o1, p_c1_hbond) 

    # C.3. Evaluation
    H_BOND_MAX_DIST = 3.5
    H_BOND_MIN_ANGLE = 90.0 # Using a relaxed proxy angle threshold
    
    is_h_bond_distance = d_n_o < H_BOND_MAX_DIST
    is_h_bond_angle = angle_n_o_c > H_BOND_MIN_ANGLE
    
    print("\n3. Potential Intramolecular H-Bond Check (N2 -> O1):")
    print(f"   N-O Distance: {d_n_o:.3f} Å (Threshold: < {H_BOND_MAX_DIST} Å)")
    print(f"   N-O-C Angle: {angle_n_o_c:.2f} degrees (Threshold: > {H_BOND_MIN_ANGLE} degrees)")
    
    if is_h_bond_distance and is_h_bond_angle:
        print("   RESULT: High likelihood of a stabilizing H-bond based on geometric criteria.")
    else:
        print("   RESULT: Geometric criteria for a standard H-bond are NOT met.")

# --- 4. Execution ---
if __name__ == "__main__":
    analyze_structure(COORDINATES)



#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np
from typing import List, Dict, Tuple

# Helper function (from Exercise 2) - modified to be internal
def _calculate_angle(coord_A, coord_B, coord_C) -> float:
    """Calculates angle B-A-C (A is central)."""
    vec_AB = coord_B - coord_A
    vec_AC = coord_C - coord_A
    
    mag_AB = np.linalg.norm(vec_AB)
    mag_AC = np.linalg.norm(vec_AC)

    if mag_AB == 0 or mag_AC == 0: return 0.0

    dot_product = np.dot(vec_AB, vec_AC)
    cosine_theta = dot_product / (mag_AB * mag_AC)
    clipped_cosine = np.clip(cosine_theta, -1.0, 1.0)

    return np.degrees(np.arccos(clipped_cosine))

# Simplified molecular data structure
# Atom Name, Residue ID, Coordinates (x, y, z)
molecular_data = [
    {'name': 'N', 'res_id': 1, 'coords': np.array([10.0, 5.0, 3.0])},  # D1 (Donor)
    {'name': 'CA', 'res_id': 1, 'coords': np.array([11.5, 5.2, 3.1])},
    {'name': 'C', 'res_id': 1, 'coords': np.array([12.0, 6.5, 3.5])},  # X1 (Neighbor to O1)
    {'name': 'O', 'res_id': 1, 'coords': np.array([13.0, 6.0, 3.8])},  # A1 (Acceptor)

    {'name': 'N', 'res_id': 2, 'coords': np.array([10.5, 2.0, 3.0])},  # D2 (Donor)
    {'name': 'CA', 'res_id': 2, 'coords': np.array([11.0, 1.0, 3.0])},
    {'name': 'C', 'res_id': 2, 'coords': np.array([12.5, 1.0, 3.0])},  # X2 (Neighbor to O2)
    {'name': 'O', 'res_id': 2, 'coords': np.array([13.0, 2.0, 3.0])},  # A2 (Acceptor)
]

# Define connectivity for angle check (A-X)
# This mimics the covalent bond structure: O is bonded to C
connectivity = {
    'O': 'C',
    'N': 'CA' # Example for N, though N is usually D
}

def find_hydrogen_bonds(data: List[Dict]) -> List[Tuple]:
    """
    Searches for H-bonds based on distance (D-A) and angle (D-A-X) criteria.
    """
    hbond_reports = []
    
    # Define potential donors (D) and acceptors (A)
    donors = [atom for atom in data if atom['name'] in ['N', 'O']]
    acceptors = [atom for atom in data if atom['name'] in ['O', 'N']]

    # Iterate over all possible D-A pairs
    for d_idx, D in enumerate(donors):
        for a_idx, A in enumerate(acceptors):
            
            # Skip interaction within the same residue (typical H-bond definition)
            if D['res_id'] == A['res_id']:
                continue
            
            # --- 1. Distance Check (D-A) ---
            coord_D = D['coords']
            coord_A = A['coords']
            
            # Calculate D-A distance
            dist_DA = np.linalg.norm(coord_D - coord_A)
            
            # Apply Distance Constraint
            if not (2.5 < dist_DA < 3.5):
                continue
            
            # --- 2. Angle Check (D-A-X) ---
            # Identify the neighbor X covalently bonded to A
            acceptor_neighbor_name = connectivity.get(A['name'])
            if not acceptor_neighbor_name:
                continue # Cannot check angle if connectivity is unknown

            # Find the coordinates of X (atom bonded to A, in the same residue)
            coord_X = None
            for atom in data:
                if atom['res_id'] == A['res_id'] and atom['name'] == acceptor_neighbor_name:
                    coord_X = atom['coords']
                    break
            
            if coord_X is None:
                continue

            # Calculate the angle D-A-X (A is the central atom)
            angle_DAX = _calculate_angle(coord_A, coord_D, coord_X)
            
            # Apply Angular Constraint
            if angle_DAX > 90.0:
                hbond_reports.append((
                    D['res_id'], D['name'], 
                    A['res_id'], A['name'], 
                    dist_DA, angle_DAX
                ))
                
    return hbond_reports

h_bonds = find_hydrogen_bonds(molecular_data)
# print("Identified Hydrogen Bonds (Res_D, Atom_D, Res_A, Atom_A, Distance, Angle):")
# for hb in h_bonds:
#     print(f"HB: R{hb[0]}{hb[1]} -> R{hb[2]}{hb[3]} | D={hb[4]:.2f} Å | Angle={hb[5]:.2f}°")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np

def calculate_bond_angle(coord_A: np.ndarray, coord_B: np.ndarray, coord_C: np.ndarray) -> float:
    """
    Calculates the angle (in degrees) formed by three atoms A-B-C, 
    where B is the central vertex, using vector geometry.
    """
    # 1. Define vectors originating from the central atom B
    vec_BA = coord_A - coord_B
    vec_BC = coord_C - coord_B

    # 2. Calculate magnitudes (norms)
    mag_BA = np.linalg.norm(vec_BA)
    mag_BC = np.linalg.norm(vec_BC)

    # Handle zero magnitude (atoms are coincident)
    if mag_BA == 0 or mag_BC == 0:
        return 0.0 # Or raise an error, depending on desired behavior

    # 3. Calculate the dot product
    dot_product = np.dot(vec_BA, vec_BC)

    # 4. Calculate the cosine of the angle
    cosine_theta = dot_product / (mag_BA * mag_BC)

    # 5. Robustness Check: Clip the cosine value to [-1.0, 1.0] 
    # to prevent arccos from failing due to floating-point errors (e.g., 1.0000000000000002)
    clipped_cosine = np.clip(cosine_theta, -1.0, 1.0)

    # 6. Calculate angle in radians and convert to degrees
    angle_rad = np.arccos(clipped_cosine)
    angle_deg = np.degrees(angle_rad)

    return angle_deg

# Example Test Case (Water molecule H-O-H angle)
O = np.array([0.000, 0.000, 0.000])
H1 = np.array([0.957, 0.000, 0.000])
H2 = np.array([-0.239, 0.927, 0.000])

angle_H1_O_H2 = calculate_bond_angle(H1, O, H2)
# print(f"Angle H1-O-H2: {angle_H1_O_H2:.2f} degrees")

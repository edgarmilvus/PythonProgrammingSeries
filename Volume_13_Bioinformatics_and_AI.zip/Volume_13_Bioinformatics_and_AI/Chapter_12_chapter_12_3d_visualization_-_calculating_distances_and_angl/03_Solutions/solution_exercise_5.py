
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np
import time

# Set N for the benchmark
N = 5000 
coords = np.random.rand(N, 3) * 100 # Generate synthetic coordinates

# --- Implementation A: Iterative Loop ---
def calculate_distances_loop(coords: np.ndarray):
    """Calculates N x N distance matrix using nested Python loops."""
    N = coords.shape[0]
    distances = np.zeros((N, N))
    
    for i in range(N):
        for j in range(i + 1, N): # Only calculate unique pairs (upper triangle)
            # Calculate squared difference
            diff_sq = (coords[i, 0] - coords[j, 0])**2 + \
                      (coords[i, 1] - coords[j, 1])**2 + \
                      (coords[i, 2] - coords[j, 2])**2
            
            dist = np.sqrt(diff_sq)
            distances[i, j] = dist
            distances[j, i] = dist # Fill symmetric element
            
    return distances

# --- Implementation B: Vectorized NumPy ---
def calculate_distances_vectorized(coords: np.ndarray):
    """Calculates N x N distance matrix using NumPy broadcasting."""
    # 1. Calculate Differences (N x N x 3)
    diff = coords[:, np.newaxis, :] - coords[np.newaxis, :, :]
    
    # 2. Sum squares along axis 2
    sq_distances = np.sum(diff**2, axis=2)
    
    # 3. Square root
    dist_matrix = np.sqrt(sq_distances)
    
    return dist_matrix

# --- Benchmarking ---

# Time Implementation A (Iterative)
start_time_A = time.time()
_ = calculate_distances_loop(coords)
end_time_A = time.time()
time_A = end_time_A - start_time_A

# Time Implementation B (Vectorized)
start_time_B = time.time()
_ = calculate_distances_vectorized(coords)
end_time_B = time.time()
time_B = end_time_B - start_time_B

# Calculate Speedup
speedup = time_A / time_B

# print(f"--- Benchmarking Results (N={N}) ---")
# print(f"Time A (Iterative Loop): {time_A:.4f} seconds")
# print(f"Time B (Vectorized NumPy): {time_B:.4f} seconds")
# print(f"Speedup Factor (A / B): {speedup:.2f}x")

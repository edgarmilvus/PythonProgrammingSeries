
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np

def calculate_distance_matrix(coords: np.ndarray):
    """
    Calculates the N x N distance matrix using NumPy broadcasting
    and validates distances against covalent and clash criteria.
    """
    N = coords.shape[0]

    # 1. Vectorized Calculation of Differences (N x N x 3)
    # coords[:, np.newaxis, :] expands coords to (N, 1, 3)
    # coords[np.newaxis, :, :] expands coords to (1, N, 3)
    # Subtraction results in (N, N, 3) array of coordinate differences
    diff = coords[:, np.newaxis, :] - coords[np.newaxis, :, :]

    # 2. Calculate Squared Euclidean Distance (N x N)
    # Sum squares along the last axis (axis=2, the x, y, z coordinates)
    sq_distances = np.sum(diff**2, axis=2)

    # 3. Calculate Euclidean Distance
    dist_matrix = np.sqrt(sq_distances)

    # --- Validation Report Generation ---
    validation_report = {
        'covalent_bonds': [],
        'clashes': []
    }

    # Use the lower triangular part (excluding the diagonal) to avoid duplicates (i, j) and (j, i)
    # and the zero distance on the diagonal.
    i_indices, j_indices = np.triu_indices(N, k=1)
    
    # Extract distances for unique pairs
    unique_distances = dist_matrix[i_indices, j_indices]

    # Covalent Range Mask: 1.0 <= d <= 1.8
    covalent_mask = (unique_distances >= 1.0) & (unique_distances <= 1.8)
    
    # Clash Mask: d < 0.8
    clash_mask = (unique_distances < 0.8)

    # Report Covalent Bonds
    covalent_i = i_indices[covalent_mask]
    covalent_j = j_indices[covalent_mask]
    covalent_d = unique_distances[covalent_mask]
    
    for i, j, d in zip(covalent_i, covalent_j, covalent_d):
        validation_report['covalent_bonds'].append((i, j, d))

    # Report Clashes
    clash_i = i_indices[clash_mask]
    clash_j = j_indices[clash_mask]
    clash_d = unique_distances[clash_mask]
    
    for i, j, d in zip(clash_i, clash_j, clash_d):
        validation_report['clashes'].append((i, j, d))

    return dist_matrix, validation_report

# Example Input Data Structure
sample_coords = np.array([
    [10.0, 5.0, 3.0],  # Atom 0
    [11.5, 5.2, 3.1],  # Atom 1 (Covalent distance to 0: ~1.52 Å)
    [12.0, 6.5, 3.5],  # Atom 2
    [10.0, 5.0, 3.0]   # Atom 3 (Clash with 0: 0.0 Å - structural error)
])

dist_matrix, report = calculate_distance_matrix(sample_coords)

# print("Distance Matrix:")
# print(dist_matrix)
# print("\nValidation Report:")
# print(f"Covalent Bonds (1.0 - 1.8 Å): {report['covalent_bonds']}")
# print(f"Clashes (< 0.8 Å): {report['clashes']}")

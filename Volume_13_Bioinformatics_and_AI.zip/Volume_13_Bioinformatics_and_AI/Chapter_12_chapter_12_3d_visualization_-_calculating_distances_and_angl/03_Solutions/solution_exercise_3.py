
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np

def calculate_dihedral_angle(A: np.ndarray, B: np.ndarray, C: np.ndarray, D: np.ndarray) -> float:
    """
    Calculates the dihedral angle (torsion angle) for the A-B-C-D sequence, 
    returning a signed angle in degrees [-180, 180].
    """
    # 1. Define vectors based on geometry
    # v1 = BA (Vector from B to A)
    # v2 = CB (Vector from C to B, this is the central bond vector BC flipped)
    # v3 = DC (Vector from D to C)
    
    v1 = A - B
    v2 = B - C # Central vector BC is -(B-C)
    v3 = D - C 
    
    # Central bond vector (BC) is needed for the sign determination
    v_BC = C - B 

    # 2. Calculate Normal Vectors (Cross Products)
    # n1: Normal of plane ABC. Defined by (A-B) x (C-B) = v1 x (-v2)
    # Since v2 = B - C, -v2 = C - B = v_BC.
    # We use v1 x v_BC
    n1 = np.cross(v1, v_BC) 
    
    # n2: Normal of plane BCD. Defined by (B-C) x (D-C) = (-v_BC) x v3
    n2 = np.cross(v_BC, v3) 

    # 3. Calculate the components for arctan2
    
    # x: Dot product of the two normal vectors (proportional to cos(phi))
    # n1 * n2
    x = np.dot(n1, n2)

    # y: Triple scalar product (proportional to sin(phi) and determines the sign)
    # (n1 x n2) * v_BC. The central vector v_BC is used as the axis of rotation.
    cross_n1_n2 = np.cross(n1, n2)
    y = np.dot(cross_n1_n2, v_BC) / np.linalg.norm(v_BC) # Normalizing by central bond length is optional but good practice

    # 4. Calculate the signed angle using arctan2
    # The order is arctan2(y, x)
    dihedral_rad = np.arctan2(y, x)
    dihedral_deg = np.degrees(dihedral_rad)

    return dihedral_deg

# Example Test Case: Staggered conformation (~60 degrees)
A = np.array([0.0, 1.0, 0.0])
B = np.array([0.0, 0.0, 0.0])
C = np.array([1.0, 0.0, 0.0])
D = np.array([1.0, 0.866, 0.5]) # Designed to create a specific torsion angle

dihedral = calculate_dihedral_angle(A, B, C, D)
# print(f"Dihedral Angle A-B-C-D: {dihedral:.2f} degrees")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np

# --- 1. Define Atomic Coordinates ---
# Coordinates are typically measured in Angstroms (Å) in structural biology.
# We define them as 1D NumPy arrays, representing 3D vectors.
atom_1_name = "Oxygen (O)"
atom_coords_1 = np.array([1.554, 2.781, 0.901])  # Coordinates [x1, y1, z1]

atom_2_name = "Hydrogen (H)"
atom_coords_2 = np.array([0.760, 2.210, 0.450])  # Coordinates [x2, y2, z2]

print(f"--- Molecular Distance Calculation ---")
print(f"{atom_1_name} position: {atom_coords_1}")
print(f"{atom_2_name} position: {atom_coords_2}")
print("-" * 40)

# --- 2. Step-by-Step Euclidean Distance Calculation ---

# Step 2a: Calculate the difference vector (R2 - R1)
# NumPy performs element-wise subtraction automatically.
difference_vector = atom_coords_2 - atom_coords_1

# Step 2b: Square the differences
# The **2 operator is applied element-wise across the array.
squared_differences = difference_vector**2

# Step 2c: Sum the squared components
# This yields the squared distance (d^2).
sum_of_squares = np.sum(squared_differences)

# Step 2d: Take the square root
# This yields the final Euclidean distance (d).
calculated_distance_manual = np.sqrt(sum_of_squares)

# --- 3. Optimized Calculation using Linear Algebra Norm ---

# The Euclidean distance is mathematically equivalent to the L2 Norm (or magnitude)
# of the difference vector. NumPy provides a highly optimized function for this.
optimized_distance = np.linalg.norm(difference_vector)

# --- 4. Output Results ---
print(f"1. Difference Vector (Δx, Δy, Δz):\n{difference_vector}")
print(f"\n2. Squared Differences (Δx², Δy², Δz²):\n{squared_differences}")
print(f"\n3. Sum of Squares (d²): {sum_of_squares:.6f}")
print("-" * 40)
print(f"Calculated Bond Length (Manual Method): {calculated_distance_manual:.4f} Å")
print(f"Calculated Bond Length (Optimized Norm): {optimized_distance:.4f} Å")

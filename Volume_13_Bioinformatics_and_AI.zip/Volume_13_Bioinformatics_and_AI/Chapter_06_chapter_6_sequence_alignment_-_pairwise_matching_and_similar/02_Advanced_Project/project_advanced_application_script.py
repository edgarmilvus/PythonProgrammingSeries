
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import sys
from Bio import Align
from Bio.Seq import Seq
from Bio.Align import substitution_matrices

# --- 1. Define Biological Context and Sequences ---

# Query: A highly conserved active site sequence (e.g., from a kinase domain)
# This sequence represents the known functional motif.
QUERY_SITE = "GVSSYVRLAAL" 

# Target: A new, full-length protein sequence from a novel organism.
# We suspect it contains the domain, but it might be mutated or embedded.
TARGET_PROTEIN = (
    "MKLVLRFAGVSSYVRLAALEPGKDYQATPEE"
    "LAKKIGDTRFDDVQLYRLKDLGMEDTTVLGL"
    "HDAFKRLEGVNLDVAYYLGLSGSGAYVCA"
)

# Convert strings to Biopython Seq objects
query_seq = Seq(QUERY_SITE)
target_seq = Seq(TARGET_PROTEIN)

print("--- Sequence Alignment Setup ---")
print(f"Query (Active Site): {len(query_seq)} residues")
print(f"Target (New Protein): {len(target_seq)} residues\n")

# --- 2. Configure the Smith-Waterman Local Aligner ---

# Initialize the Biopython aligner object
aligner = Align.PairwiseAligner()

# Set the alignment mode to local (Smith-Waterman)
# This ensures only the highest scoring sub-region is reported.
aligner.mode = 'local'

# Load the standard BLOSUM62 matrix for protein comparison
# BLOSUM62 is suitable for finding moderately distant evolutionary relationships.
aligner.substitution_matrix = substitution_matrices.load("BLOSUM62")

# Define Affine Gap Penalties (Crucial for alignment quality)
# Affine penalties use two values: open and extend.
# Opening a gap is penalized heavily (-11)
aligner.open_gap_score = -11 
# Extending an existing gap is penalized less heavily (-1)
aligner.extend_gap_score = -1 

# For local alignment, we typically do not penalize gaps at the ends 
# of the sequences, as the alignment is floating within the target.
aligner.target_end_gap_score = 0.0
aligner.query_end_gap_score = 0.0

# --- 3. Execute Alignment and Retrieve Top Result ---

# Execute the dynamic programming algorithm (Smith-Waterman)
alignments = aligner.align(query_seq, target_seq)

# Retrieve the single, highest-scoring alignment object
try:
    best_alignment = next(alignments)
except StopIteration:
    print("Error: No valid alignment found.")
    sys.exit(1)
    
# --- 4. Interpretation and Output ---

print("--- Alignment Results (Local/Smith-Waterman) ---")

# Extract the total similarity score calculated by the dynamic programming matrix
score = best_alignment.score

# Extract the coordinates of the aligned region (the traceback path)
# The result is a tuple of tuples: (query_coordinates, target_coordinates)
# Each coordinate is (start, end)
query_start, query_end = best_alignment.aligned[0][0]
target_start, target_end = best_alignment.aligned[1][0]

# Calculate identity percentage within the aligned region
match_count = 0
aligned_query_segment = str(best_alignment[0])
aligned_target_segment = str(best_alignment[1])

# Calculate the length of the alignment (including gaps)
aligned_length = len(aligned_query_segment) 

# Iterate through the aligned characters to count exact matches
for q_char, t_char in zip(aligned_query_segment, aligned_target_segment):
    # Count only exact matches, excluding matches to gaps
    if q_char == t_char and q_char != '-':
        match_count += 1
        
# Identity is calculated based on matches divided by the length of the query 
# (since the query is entirely contained within the local alignment)
identity_percent = (match_count / len(query_seq)) * 100

print(f"Alignment Score (BLOSUM62): {score:.2f}")
print(f"Identity within aligned region: {identity_percent:.2f}%")
print("-" * 40)

# Print the coordinates of the highly similar domain
print(f"Query sequence aligned region: {query_start} to {query_end}")
print(f"Target sequence aligned region: {target_start} to {target_end}")
print("-" * 40)

# Display the formatted alignment (the traceback visualization)
print(best_alignment)

# --- 5. Application Conclusion ---
print("\nConclusion:")
print(f"The conserved domain was successfully located in the Target protein starting at residue {target_start} and ending at residue {target_end}.")

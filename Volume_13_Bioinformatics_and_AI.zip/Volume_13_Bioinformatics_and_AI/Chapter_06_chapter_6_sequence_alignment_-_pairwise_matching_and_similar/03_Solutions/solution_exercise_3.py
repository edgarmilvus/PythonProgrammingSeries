
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

def reconstruct_alignment(seq1: str, seq2: str, path: list[int]) -> tuple[str, str]:
    """
    Reconstructs the two aligned sequences based on the traceback path.
    The path is provided in reverse order (end -> start).
    """
    
    # Initialize pointers to the last valid index
    i = len(seq1) - 1
    j = len(seq2) - 1
    
    aligned_seq1 = []
    aligned_seq2 = []
    
    # Iterate through the path instructions
    for instruction in path:
        # Safety check: If both indices are exhausted, stop processing the path
        if i < 0 and j < 0:
            break
            
        if instruction == 0:  # Diagonal (Match/Mismatch)
            # Consume one residue from both sequences
            # Assuming the path is correct, i and j should be >= 0 here.
            aligned_seq1.append(seq1[i])
            aligned_seq2.append(seq2[j])
            i -= 1
            j -= 1
                
        elif instruction == 1:  # Up (Gap in Seq 2 / Gap in Y)
            # Consume one residue from Seq 1, insert gap in Seq 2
            aligned_seq1.append(seq1[i])
            aligned_seq2.append('-')
            i -= 1
            
        elif instruction == 2:  # Left (Gap in Seq 1 / Gap in X)
            # Insert gap in Seq 1, consume one residue from Seq 2
            aligned_seq1.append('-')
            aligned_seq2.append(seq2[j])
            j -= 1
            
    # 3. Extended Slicing Application: Reverse the constructed alignment
    # Since the alignment was built end-to-start, we reverse the lists to get the forward frame.
    final_seq1 = "".join(aligned_seq1[::-1])
    final_seq2 = "".join(aligned_seq2[::-1])
    
    return (final_seq1, final_seq2)

# Input sequences for the function:
raw_seq_a = "GATTACAAGC"
raw_seq_b = "GATTCAGGC" 
# This path is 13 steps long: 10 zeros, 2 ones, 1 two.
path = [0, 0, 0, 0, 1, 1, 0, 0, 2, 0, 0, 0, 0] 

aligned_a, aligned_b = reconstruct_alignment(raw_seq_a, raw_seq_b, path)

print(f"Raw A: {raw_seq_a}")
print(f"Raw B: {raw_seq_b}")
print("-" * 30)
print(f"Path Length: {len(path)}")
print(f"Aligned Sequence A (Length {len(aligned_a)}): {aligned_a}")
print(f"Aligned Sequence B (Length {len(aligned_b)}): {aligned_b}")

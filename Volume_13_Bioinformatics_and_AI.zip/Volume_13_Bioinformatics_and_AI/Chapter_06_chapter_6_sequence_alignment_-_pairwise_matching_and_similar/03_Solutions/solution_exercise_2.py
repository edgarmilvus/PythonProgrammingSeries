
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np

def affine_nw(seq_p, seq_q, match, mismatch, g_open, g_extend):
    n = len(seq_p)
    m = len(seq_q)
    
    # Define the total gap cost function for initialization
    def gap_cost(k):
        if k == 0: return 0.0
        # Affine cost: G_open + k * G_extend
        return g_open + k * g_extend

    # Use a very large negative number for initialization of impossible states
    NEG_INF = -1e10 
    
    # 1. Matrix Setup
    M = np.full((n + 1, m + 1), NEG_INF, dtype=float)  # Match/Mismatch
    Ix = np.full((n + 1, m + 1), NEG_INF, dtype=float) # Gap in Q (Vertical move)
    Iy = np.full((n + 1, m + 1), NEG_INF, dtype=float) # Gap in P (Horizontal move)

    # 2. Initialization
    M[0, 0] = 0.0
    
    # Initialization of Gap Matrices (First row/column)
    for i in range(1, n + 1):
        Ix[i, 0] = gap_cost(i)
    for j in range(1, m + 1):
        Iy[0, j] = gap_cost(j)

    # 3. Recurrence Relations
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            s = match if seq_p[i-1] == seq_q[j-1] else mismatch
            
            # --- Calculate Ix (Gap in Q/Y, Vertical) ---
            # Path 1: Extend gap in Q (stay in Ix)
            # Path 2: Open new gap in Q (transition from M or Iy)
            Ix[i, j] = max(
                Ix[i-1, j] + g_extend,
                M[i-1, j] + g_open + g_extend,
                Iy[i-1, j] + g_open + g_extend # Transition from Iy to Ix
            )

            # --- Calculate Iy (Gap in P/X, Horizontal) ---
            # Path 1: Extend gap in P (stay in Iy)
            # Path 2: Open new gap in P (transition from M or Ix)
            Iy[i, j] = max(
                Iy[i, j-1] + g_extend,
                M[i, j-1] + g_open + g_extend,
                Ix[i, j-1] + g_open + g_extend # Transition from Ix to Iy
            )

            # --- Calculate M (Match/Mismatch) ---
            # M state transition can come from M, Ix, or Iy (closing a gap)
            M[i, j] = s + max(M[i-1, j-1], Ix[i-1, j-1], Iy[i-1, j-1])
            

    # The optimal global alignment score is the maximum of the three states at the end.
    final_score = max(M[n, m], Ix[n, m], Iy[n, m])
    return final_score

# Input Data
Seq_P = "GAATTCTAGCTAGCTAGCTAGCTAGCTAGC" # Length 30
Seq_Q = "GAATTCAGCTACTAGCTAGCTAGC" # Length 24

# Affine Parameters
MATCH = 2
MISMATCH = -1
G_OPEN = -10
G_EXTEND = -1

score_affine = affine_nw(Seq_P, Seq_Q, MATCH, MISMATCH, G_OPEN, G_EXTEND)

# Linear comparison: G_linear = -5
def linear_nw_score(seq1, seq2, match, mismatch, gap):
    n, m = len(seq1), len(seq2)
    F = np.zeros((n + 1, m + 1), dtype=int)
    for i in range(n + 1): F[i, 0] = i * gap
    for j in range(m + 1): F[0, j] = j * gap
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            s = match if seq1[i-1] == seq2[j-1] else mismatch
            F[i, j] = max(F[i-1, j-1] + s, F[i-1, j] + gap, F[i, j-1] + gap)
    return F[n, m]

G_LINEAR = -5
score_linear = linear_nw_score(Seq_P, Seq_Q, MATCH, MISMATCH, G_LINEAR)

print(f"Optimal Global Score (Affine Gap: Open={G_OPEN}, Extend={G_EXTEND}): {score_affine:.2f}")
print(f"Optimal Global Score (Linear Gap: {G_LINEAR}): {score_linear}")

"""
Comparison and Structural Interpretation:

1. Score Comparison:
   Affine Score: 26.00
   Linear Score (-5): 23

   The Affine Gap model yields a higher optimal score (26.00) than the linear model (23).

2. Structural Interpretation (Prioritizing Fewer, Longer Gaps):
   The affine model is forced to prioritize fewer, longer gaps because the cost structure is heavily front-loaded: $G_{open}$ (-10) is much higher than $G_{extend}$ (-1).
   
   The three matrices ($M, I_x, I_y$) enforce this logic:
   - A transition *from* the $M$ matrix *to* $I_x$ or $I_y$ incurs the high $G_{open}$ penalty once, effectively 'opening' the gap segment.
   - Subsequent moves within the $I_x$ or $I_y$ matrices only incur the low $G_{extend}$ penalty, making it cheap to 'extend' the existing gap.
   
   For the sequence difference (length 6), the costs are:
   - Affine Cost (1 gap event): $G_{open} + 6 \times G_{extend} = -10 + 6(-1) = -16$.
   - Linear Cost (6 gap events): $6 \times G_{linear} = 6 \times (-5) = -30$.
   
   The affine model's structure ensures that the penalty is applied only once per contiguous gap stretch, making it significantly cheaper to create one long gap (-16) than to create multiple short gaps or use the linear model (-30 for the same length gap), resulting in a higher overall score.
"""

---

### Exercise 4: Data Integration: Parsing and Utilizing BLOSUM Matrices

**The Challenge:** Parse a raw BLOSUM62 matrix string into a nested dictionary structure and integrate this structure into a simplified Needleman-Wunsch global alignment scoring function.

**Python Solution:**

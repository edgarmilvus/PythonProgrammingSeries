
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# simple_alignment_scorer.py

# 1. Define global scoring parameters (Constants)
# These values mimic the basic reward/penalty structure used in biological scoring.
MATCH_SCORE = 2      # Reward for a perfect match (e.g., A vs A)
MISMATCH_SCORE = -1  # Default penalty for a general mismatch (e.g., A vs C)
GAP_PENALTY = -2     # Penalty for introducing or extending a gap ('-')

# 2. Define a simple custom substitution matrix
# This dictionary holds specific, non-standard scores for certain residue pairs.
# In a real scenario (BLOSUM/PAM), this matrix would be much larger and exhaustive.
SCORING_MATRIX = {
    # Key is a sorted tuple of the two residues, ensuring symmetry (A, T) == (T, A)
    ('A', 'T'): -1, # A vs T mismatch is slightly less penalized than the default MISMATCH_SCORE (-1 vs -1, but shows the mechanism)
    ('G', 'C'): 1,  # A G vs C pairing is biologically significant and receives a partial reward, even though it's technically a mismatch here
    ('A', 'G'): -2, # A specific, highly penalized mismatch
}

def score_pre_aligned_sequences(seq1_aligned: str, seq2_aligned: str) -> tuple[int, int]:
    """
    Calculates the similarity score for two sequences that are already aligned.

    Args:
        seq1_aligned: The first sequence, including gap characters ('-').
        seq2_aligned: The second sequence, including gap characters ('-').

    Returns:
        A tuple containing (total_score, alignment_length).
    """
    # Defensive check: Aligned sequences MUST have the same length by definition.
    if len(seq1_aligned) != len(seq2_aligned):
        raise ValueError("Aligned sequences must have the same length.")

    total_score = 0
    alignment_length = len(seq1_aligned)

    # 3. Iterate through the sequences position by position
    for i in range(alignment_length):
        res1 = seq1_aligned[i]
        res2 = seq2_aligned[i]
        current_score = 0

        # Case A: Gap Handling
        # If either residue is a gap character, apply the gap penalty.
        if res1 == '-' or res2 == '-':
            current_score = GAP_PENALTY

        # Case B: Perfect Match
        elif res1 == res2:
            current_score = MATCH_SCORE

        # Case C: Mismatch (Requires matrix lookup)
        else:
            # Standardize the key for matrix lookup. We sort the residues
            # to ensure we check ('A', 'C') even if the input was ('C', 'A').
            residue_pair = tuple(sorted((res1, res2)))

            # Check if this specific mismatch is defined in the custom matrix
            if residue_pair in SCORING_MATRIX:
                current_score = SCORING_MATRIX[residue_pair]
            else:
                # Use the default general mismatch penalty
                current_score = MISMATCH_SCORE

        # Accumulate the score for the current position
        total_score += current_score

    return total_score, alignment_length

# --- Execution Example ---
# Note: These sequences include gaps ('-') and represent a single potential alignment.
DNA_SEQUENCE_A = "ATGC-GAT"
DNA_SEQUENCE_B = "A-GCAGCT"

final_score, length = score_pre_aligned_sequences(DNA_SEQUENCE_A, DNA_SEQUENCE_B)

print(f"--- Scoring Results ---")
print(f"Sequence 1: {DNA_SEQUENCE_A}")
print(f"Sequence 2: {DNA_SEQUENCE_B}")
print(f"Alignment Length: {length} bases/residues")
print(f"Total Similarity Score: {final_score}")

# Expected calculation breakdown:
# A vs A (Match): +2
# T vs - (Gap): -2
# G vs G (Match): +2
# C vs C (Match): +2
# - vs A (Gap): -2
# G vs G (Match): +2
# A vs C (Mismatch, default): -1
# T vs T (Match): +2
# Total: 2 - 2 + 2 + 2 - 2 + 2 - 1 + 2 = 5


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# Required input sequence for testing the interactive tool
TEST_SEQUENCE = (
    "AUGGUUGUUGUUGUUGUUGUUGUUGUUGUUGUU"
    "UUGUUGUUGUUGUUGUUGUUGUUGUUGUUGUU"
    "UUGUUGUUGUUGUUGUUGUUGUUGUUGUUGUU"
    "UUGUUGUUGUUGUUGUUGUUGUUGUUGUUGUU"
    "UUGUUGUUGUUGUUGUUGUUGUUGUUGUUGUU"
    "UUGUUGUUGUUGUUGUUGUUGUUGUUGUUGUU"
    "UUGUUGUUGUUGUUGUUGUUGUUGUUGUUGUU"
    "UUGUUGUUGUUGUUGUUGUUGUUGUUGUUGUU"
    "UUGUUGUUGUUGUUGUUGUUGUUGUUGUUGUU"
    "UUGUUGUUGUUGUUGUUGUUGUUGUUGUUGUU"
    "UUGUUGUUGUUGUUGUUGUUGUUGUUGUUGUU"
    "UUGUUGUUGUUGUUGUUGUUGUUGUUGUUGUU"
    "UUGUUGUUGUUGUUGUUGUUGUUGUUGUUGUU"
    "UUGUUGUUGUUGUUGUUGUUGUUGUUGUUGUU"
    "UUGUUGUUGUUGUUGUUGUUGUUGUUGUUGUU"
    "UUGUUGUUGUUGUUGUUGUUGUUGUUGUUGUU"
    "UUGUUGUUGUUGUUGUUGUUGUUGUUGUUGUU"
    "UUGUUGUUGUUGUUGUUGUUGUUGUUGUUGUU"
    "UUGUUGUUGUUGUUGUUGUUGUUGUUGUUGUU"
    "UUGUUGUUGUUGUUGUUGUUGUUGUUGUUGUU"
    "UAG"
)

# Full Standard Genetic Code (for grouping)
STANDARD_CODE = {
    'UUU': 'F', 'UUC': 'F', 'UUA': 'L', 'UUG': 'L', 'UCU': 'S', 'UCC': 'S', 'UCA': 'S', 'UCG': 'S',
    'UAU': 'Y', 'UAC': 'Y', 'UAA': '*', 'UAG': '*', 'UGU': 'C', 'UGC': 'C', 'UGA': '*', 'UGG': 'W',
    'CUU': 'L', 'CUC': 'L', 'CUA': 'L', 'CUG': 'L', 'CCU': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
    'CAU': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q', 'CGU': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
    'AUU': 'I', 'AUC': 'I', 'AUA': 'I', 'AUG': 'M', 'ACU': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
    'AAU': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K', 'AGU': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
    'GUU': 'V', 'GUC': 'V', 'GUA': 'V', 'GUG': 'V', 'GCU': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
    'GAU': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E', 'GGU': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'
}

def count_codons(mrna_sequence):
    """Counts the occurrences of all 64 codons in the sequence."""
    codon_counts = {codon: 0 for codon in STANDARD_CODE}
    
    # Iterate through the sequence in steps of 3
    for i in range(0, len(mrna_sequence) - 2, 3):
        codon = mrna_sequence[i:i+3]
        if codon in codon_counts:
            codon_counts[codon] += 1
    
    return codon_counts

def calculate_relative_frequency(codon_counts):
    """Converts raw counts into relative frequencies (normalized percentages)."""
    total_codons = sum(codon_counts.values())
    
    if total_codons == 0:
        return {}
        
    codon_frequencies = {
        codon: count / total_codons
        for codon, count in codon_counts.items()
    }
    return codon_frequencies

def group_by_amino_acid(codon_frequencies):
    """Groups codon frequencies by the amino acid they encode."""
    aa_groups = {}
    
    for codon, frequency in codon_frequencies.items():
        amino_acid = STANDARD_CODE.get(codon)
        
        if amino_acid is None:
            continue # Skip invalid sequences
            
        if amino_acid not in aa_groups:
            aa_groups[amino_acid] = {}
            
        aa_groups[amino_acid][codon] = frequency
        
    # Calculate relative usage within each synonymous group
    final_bias_map = {}
    for aa, codon_map in aa_groups.items():
        total_aa_usage = sum(codon_map.values())
        
        # Only calculate bias if the amino acid was used at least once
        if total_aa_usage > 0:
            final_bias_map[aa] = {
                codon: (freq / total_aa_usage)
                for codon, freq in codon_map.items()
            }
    
    return final_bias_map

def run_codon_bias_tool():
    print("--- Codon Usage Bias Analyzer ---")
    
    # 1. Process counts, frequencies, and grouping
    codon_counts = count_codons(TEST_SEQUENCE)
    codon_frequencies = calculate_relative_frequency(codon_counts)
    codon_bias_map = group_by_amino_acid(codon_frequencies)
    
    # Get a list of all amino acids present in the sequence (excluding stop codons)
    available_aas = sorted([aa for aa in codon_bias_map.keys() if aa != '*'])
    print(f"Analyzed sequence length: {len(TEST_SEQUENCE)} bases ({len(codon_counts)} codons)")
    print(f"Amino Acids present: {', '.join(available_aas)}")
    
    while True:
        user_input = input("\nEnter Amino Acid (e.g., 'L' or 'V') or 'EXIT': ").upper()
        
        if user_input == 'EXIT':
            print("Analyzer shutting down.")
            break
        
        # 4. Implement lookup and display logic
        if user_input in codon_bias_map:
            bias_data = codon_bias_map[user_input]
            
            # Find the full name for display (e.g., L -> Leucine)
            # Reverse lookup is complex, so we'll just use the single letter code
            
            print(f"\n--- Codon Usage for Amino Acid {user_input} ---")
            
            # Sort codons for consistent display
            sorted_codons = sorted(bias_data.items(), key=lambda item: item[1], reverse=True)
            
            for codon, frequency in sorted_codons:
                percentage = frequency * 100
                print(f"  {codon}: {percentage:.2f}%")
                
        elif user_input == '*':
            print("Stop codons are not included in amino acid bias analysis.")
        else:
            print(f"Error: Amino Acid '{user_input}' not found or not present in the sequence.")

# Execute the interactive tool
# Note: In a real environment, input() would run interactively. 
# We call the function here to demonstrate the solution structure.
# run_codon_bias_tool() 

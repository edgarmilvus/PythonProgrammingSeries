
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# Define the translation map for efficient DNA complementation (case-insensitive)
COMPLEMENT_MAP = str.maketrans("ATGCatgc", "TACGtacg")

def complement_dna(sequence):
    """Returns the complementary DNA strand (uppercase)."""
    # 1. Apply translation map for complementation
    complement = sequence.translate(COMPLEMENT_MAP)
    # 2. Ensure output is standardized to uppercase
    return complement.upper()

def reverse_complement(sequence):
    """Returns the reverse complement of the DNA sequence (the coding strand)."""
    # 1. Get the complement
    complement = complement_dna(sequence)
    # 2. Reverse the complemented sequence using slicing [::-1]
    return complement[::-1]

def transcribe(dna_sequence):
    """Simulates transcription (DNA template strand to mRNA)."""
    # 1. Calculate the reverse complement (this is the 5' to 3' coding strand)
    coding_strand = reverse_complement(dna_sequence)
    
    # 2. Convert DNA (T) to mRNA (U)
    mrna = coding_strand.replace('T', 'U')
    
    return mrna

# Example input for testing (Template Strand):
dna_input = "TACCGCATGCATGCATGC"

# Testing the functions
comp = complement_dna(dna_input)
rev_comp = reverse_complement(dna_input)
mrna = transcribe(dna_input)

print(f"Input DNA (Template): {dna_input}")
print(f"1. Complement: {comp}")
print(f"2. Reverse Complement (Coding Strand): {rev_comp}")
print(f"3. mRNA Transcript: {mrna}")

# Verification test: Reverse complement of reverse complement should return the original sequence (uppercase)
assert reverse_complement(rev_comp) == dna_input.upper()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Standard Genetic Code (Relevant section for this exercise)
STANDARD_CODE = {
    # Full Code Definition (for completeness)
    'UUU': 'F', 'UUC': 'F', 'UUA': 'L', 'UUG': 'L',
    'UCU': 'S', 'UCC': 'S', 'UCA': 'S', 'UCG': 'S',
    'UAU': 'Y', 'UAC': 'Y', 'UAA': '*', 'UAG': '*',
    'UGU': 'C', 'UGC': 'C', 'UGA': '*', 'UGG': 'W',
    'CUU': 'L', 'CUC': 'L', 'CUA': 'L', 'CUG': 'L',
    'CCU': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
    'CAU': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
    'CGU': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
    'AUU': 'I', 'AUC': 'I', 'AUA': 'I', 'AUG': 'M',
    'ACU': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
    'AAU': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K',
    'AGU': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
    'GUU': 'V', 'GUC': 'V', 'GUA': 'V', 'GUG': 'V',
    'GCU': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
    'GAU': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E',
    'GGU': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'
}

# Define canonical and non-canonical start codons
CANONICAL_START = 'AUG'
NON_CANONICAL_STARTS = {'GUG', 'UUG'}
ALL_STARTS = {CANONICAL_START} | NON_CANONICAL_STARTS

def translate_mrna_advanced(mrna_sequence, allow_non_canonical_start=False):
    """
    Translates an mRNA sequence, optionally handling GUG/UUG as initiating Methionine.
    """
    polypeptide = []
    start_index = -1
    
    # 1. Find the initiation site
    for i in range(0, len(mrna_sequence) - 2, 3):
        codon = mrna_sequence[i:i+3]
        
        if codon == CANONICAL_START:
            start_index = i
            break
        
        if allow_non_canonical_start and codon in NON_CANONICAL_STARTS:
            start_index = i
            break
            
    # If no start codon is found, return empty sequence
    if start_index == -1:
        return ""

    # 2. Begin translation from the start site
    translation_sequence = mrna_sequence[start_index:]
    
    for i in range(0, len(translation_sequence) - 2, 3):
        codon = translation_sequence[i:i+3]
        
        # Check for stop codon
        if codon in STANDARD_CODE and STANDARD_CODE[codon] == '*':
            break
            
        amino_acid = STANDARD_CODE.get(codon, 'X') # 'X' for unknown codon
        
        # 3. Apply non-canonical initiation rule:
        # If this is the very first codon (i=0) AND it was a non-canonical start, translate as M.
        if i == 0 and codon in NON_CANONICAL_STARTS and allow_non_canonical_start:
            polypeptide.append('M')
        else:
            polypeptide.append(amino_acid)

    return "".join(polypeptide)

# Test Sequences:
seq1 = "AUGUUUGUGUUGUAA" # Standard Start (M F V L *)
seq2 = "GUGUUUGUGUUGUAA" # Non-Canonical Start (V F V L * normally)
seq3 = "AUGCAGUGUUUGUAA" # Internal GUG/UUG (M Q V L *)

print(f"Test 1 (Standard): {seq1} -> {translate_mrna_advanced(seq1)}")
print(f"Test 2 (GUG, non-canonical=False): {seq2} -> {translate_mrna_advanced(seq2)}")
print(f"Test 2 (GUG, non-canonical=True): {seq2} -> {translate_mrna_advanced(seq2, allow_non_canonical_start=True)}")
print(f"Test 3 (Internal GUG/UUG): {seq3} -> {translate_mrna_advanced(seq3, allow_non_canonical_start=True)}")

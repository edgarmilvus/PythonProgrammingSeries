
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Input Data for Exercise 2
pre_mrna_sequence = (
    "AUGUUUACUUGGUCCAUAGCAUAAGCUGAUGCGAUGCAUGC"
    "AAAAGGGUAAAGCUUCCAGGAUUUGAUGCAUGCGCCCGUAGCAUAG"
    "UAAACGGGAUGCACUGA"
)

# Intron coordinates (start index, end index - Python slicing convention)
intron_coords = [
    (10, 20), # Length 10
    (35, 55)  # Length 20
]

def perform_splicing(pre_mrna, intron_coords):
    """Removes introns from the pre-mRNA sequence and returns the mature mRNA and exon lengths."""
    
    # 1. Sort coordinates by start index to ensure sequential processing
    sorted_introns = sorted(intron_coords)
    
    mature_mrna_segments = []
    exon_lengths = []
    current_position = 0
    
    for intron_start, intron_end in sorted_introns:
        # 2. Extract the exon segment before the current intron
        # Segment runs from the last processed position up to the intron start
        exon_segment = pre_mrna[current_position:intron_start]
        
        if exon_segment:
            mature_mrna_segments.append(exon_segment)
            exon_lengths.append(len(exon_segment))
            
        # 3. Update the current position to skip the intron
        current_position = intron_end
        
    # 4. Handle the final exon segment (from the end of the last intron to the end of the sequence)
    final_exon = pre_mrna[current_position:]
    if final_exon:
        mature_mrna_segments.append(final_exon)
        exon_lengths.append(len(final_exon))
        
    mature_mrna = "".join(mature_mrna_segments)
    
    return mature_mrna, exon_lengths

# Execute the splicing simulation
mature_mrna, exon_lengths = perform_splicing(pre_mrna_sequence, intron_coords)

# Output Verification
print(f"Pre-mRNA Length: {len(pre_mrna_sequence)}")
print(f"Mature mRNA Total Length: {len(mature_mrna)}")
print(f"Exon Lengths (Order 1, 2, 3...): {exon_lengths}")
print(f"Verification: Sum of Exon Lengths: {sum(exon_lengths)}")

# Check specific content
# Expected Exon 1: AUGUUUACUU (10 bases)
# Expected Exon 2: AGCAUAAGCUGAUGCGAUGCAUGC AAAAGGGUAAA GCUUCCAGGAUUU (15 bases + 20 bases = 35 bases)
# Intron 1 (10:20) removed: GGUCCAUAGCAU
# Intron 2 (35:55) removed: AAAAGGGUAAAGCUUCCAGGAUUU
# Exon 1: pre_mrna[0:10] = AUGUUUACUU
# Exon 2: pre_mrna[20:35] = AAGCUGAUGCGAUGCAU
# Exon 3: pre_mrna[55:] = GAUGCAUGCGCCCGUAGCAUAGUAAACGGGAUGCACUGA (25 bases)
# Expected Lengths: [10, 15, 25] -> Sum 50.

# Corrected manual check based on sequence indices:
# Exon 1: 0 to 10 (10 bases) -> AUGUUUACUU
# Intron 1: 10 to 20 (10 bases) -> GGUCCAUAGC
# Exon 2: 20 to 35 (15 bases) -> AUAAGCUGAUGCGAU
# Intron 2: 35 to 55 (20 bases) -> GCAUGC AAAAGGGUAAAGCUUCCAGGAU
# Exon 3: 55 to 80 (25 bases) -> UUGAUGCAUGCGCCCGUAGCAUAGUAAACGGGAUGCACUGA
# Total length of pre-mRNA is 80.
# The code output should match [10, 15, 25].

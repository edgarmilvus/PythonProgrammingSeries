
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# 1. Define the input DNA template sequence (non-coding strand).
# In molecular biology, the template strand is read 3' to 5'.
# This sequence is provided 5' to 3' for simple string processing.
dna_template = "TACGATTACCGTATTTAGCTAGCTAGCAT"

# 2. Define the target start codon in mRNA.
# The start codon is always Methionine (Met) in eukaryotes and Archaea.
START_CODON = "AUG"

# 3. Simulate Transcription: Convert DNA (T) to mRNA (U).
# The sequence provided is assumed to be the template strand, 
# which is complementary to the coding strand, meaning the mRNA 
# sequence will match the template sequence but with T replaced by U.
# We use .upper() to ensure uniform case sensitivity, though not strictly needed here.
mrna_sequence = dna_template.upper().replace('T', 'U')

# 4. Locate the first occurrence of the start codon in the mRNA.
# The .find() method returns the starting index (0-based) of the substring,
# or -1 if the substring is not found anywhere in the sequence.
start_index = mrna_sequence.find(START_CODON)

# 5. Output the sequences for verification.
print("--- Sequence Data ---")
print(f"Original DNA Template: {dna_template}")
print(f"Synthesized mRNA:      {mrna_sequence}")

# 6. Perform conditional checks based on the search result.
if start_index != -1:
    # If start_index is not -1, the codon was found.
    # Calculate the biological position (1-based index).
    position = start_index + 1
    
    print("\n--- Analysis Result ---")
    print(f"Start codon '{START_CODON}' found successfully.")
    print(f"0-based Index (Python): {start_index}")
    print(f"1-based Position (Bio): {position}")

    # 7. Extract the Open Reading Frame (ORF) starting from the AUG.
    # Sequence slicing [start_index:] captures all characters from that index onward.
    coding_sequence = mrna_sequence[start_index:]
    
    # Display the start of the potential protein coding region.
    print(f"\nPotential ORF (First 15 bases): {coding_sequence[:15]}...")

    # Demonstrate the Boolean result of the search
    is_coding = True # Since start_index != -1
    print(f"Is this sequence ready for translation? {is_coding}")

else:
    # The start codon was not found (start_index == -1).
    print("\n--- Analysis Result ---")
    print(f"Warning: Start codon '{START_CODON}' was not found in the mRNA sequence.")
    
    # Demonstrate the Boolean result of the search
    is_coding = bool(start_index != -1) # Explicitly using the bool type definition from the glossary context
    print(f"Is this sequence ready for translation? {is_coding}")

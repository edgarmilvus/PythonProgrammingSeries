
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import io
from Bio import Phylo

def extract_and_analyze_clade(tree_object, target_taxa):
    """
    Finds the MRCA of target taxa, extracts the subtree, and calculates its maximum depth.
    """
    # 1. Identify the MRCA
    # First, get the actual clade objects corresponding to the names
    target_nodes = [tree_object.find_any(name=t) for t in target_taxa]
    
    # Use the optimized common_ancestor method
    mrca = tree_object.common_ancestor(target_nodes)
    
    # 2. Subtree Extraction: Create a new Tree object rooted at the MRCA
    # Note: Bio.Phylo.BaseTree.Tree constructor takes a root clade
    extracted_tree = Phylo.BaseTree.Tree(root=mrca)
    
    # 3. Depth Calculation: Find the longest path from the new root to any leaf
    # The 'distance' method calculates the path length from the current root to a target node.
    max_depth = 0.0
    
    # Iterate over all terminal clades (leaves) in the extracted subtree
    for leaf in extracted_tree.get_terminals():
        # Calculate the distance from the new root (mrca) to the leaf
        path_length = extracted_tree.distance(leaf)
        if path_length > max_depth:
            max_depth = path_length
            
    # 4. Output Newick representation of the extracted tree
    # Use StringIO to write the tree back to a string
    handle = io.StringIO()
    Phylo.write(extracted_tree, handle, "newick")
    newick_output = handle.getvalue().strip()
    
    return newick_output, max_depth

# Setup and Testing
newick_data = "((Human:0.01,Chimpanzee:0.01):0.05,Gorilla:0.06,Orangutan:0.10):0.01;"
handle = io.StringIO(newick_data)
tree = Phylo.read(handle, "newick")

target_taxa = ["Human", "Chimpanzee"]
newick_clade, max_depth = extract_and_analyze_clade(tree, target_taxa)

print(f"Target Taxa: {target_taxa}")
print(f"Extracted Newick: {newick_clade}")
print(f"Maximum Subtree Depth: {max_depth:.2f}")

# Expected result for H/C clade: (Human:0.01,Chimpanzee:0.01). Max depth = 0.01
assert newick_clade.startswith("(Human:0.01,Chimpanzee:0.01)") or newick_clade.startswith("(Chimpanzee:0.01,Human:0.01)")
assert abs(max_depth - 0.01) < 1e-6

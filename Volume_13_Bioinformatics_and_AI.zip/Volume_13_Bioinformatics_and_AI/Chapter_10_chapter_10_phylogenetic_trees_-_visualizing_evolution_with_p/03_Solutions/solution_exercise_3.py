
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import io
from Bio import Phylo
import matplotlib.pyplot as plt
from Bio.Phylo.BaseTree import Clade

# 1. Setup Data Structures and Tree
newick_data = "((A:0.1,B:0.1):0.05,(C:0.2,D:0.2):0.03,(E:0.15,F:0.15):0.02);"
tree = Phylo.read(io.StringIO(newick_data), "newick")

# External metadata
clade_classification = {
    'A': 'Group A', 'B': 'Group A',
    'C': 'Group B', 'D': 'Group B',
    'E': 'Group C', 'F': 'Group C'
}

# Hypothetical bootstrap values for internal nodes (using clade names for lookup)
# Since internal nodes often lack names, we assign temporary names for lookup ease:
internal_nodes = list(tree.get_nonterminals())
bootstrap_values = {
    internal_nodes[0]: 95,  # MRCA of A, B
    internal_nodes[1]: 88,  # MRCA of C, D
    internal_nodes[2]: 75,  # MRCA of E, F
    internal_nodes[3]: 60   # Root MRCA of all
}

def color_and_annotate_tree(tree, classification, bootstrap_map):
    # 3. Clade Coloring (Modifying Clade objects before drawing)
    
    # Define colors for groups
    group_colors = {'Group A': 'blue', 'Group B': 'red', 'Group C': 'green'}
    
    # Function to recursively color nodes based on terminal descendants
    def set_clade_color(clade, color):
        clade.color = color
        for child in clade.clades:
            set_clade_color(child, color)

    # Identify the MRCA for each group and set the color for that subtree
    for group_name, color in group_colors.items():
        taxa_in_group = [t for t, g in classification.items() if g == group_name]
        if taxa_in_group:
            target_nodes = [tree.find_any(name=t) for t in taxa_in_group]
            if len(target_nodes) > 1:
                mrca = tree.common_ancestor(target_nodes)
                # Set color for the branch leading *to* the MRCA and all descendants
                set_clade_color(mrca, color)
            elif len(target_nodes) == 1:
                 # Handle single terminal node case
                 target_nodes[0].color = color

    # 2. Base Plotting and Coordinate Access
    fig, ax = plt.subplots(1, 1, figsize=(10, 6))
    
    # Draw the tree. Bio.Phylo.draw respects the clade.color attribute.
    Phylo.draw(tree, axes=ax, show_confidence=False, label_func=lambda x: x.name, do_show=False)
    
    # 4. Internal Node Annotation
    
    # Get the coordinates used by the drawing routine
    # Note: Bio.Phylo.draw internally uses a coordinate system. We approximate node positions.
    for i, node in enumerate(tree.get_nonterminals()):
        if node in bootstrap_map:
            score = bootstrap_map[node]
            
            # Find the position of the node (internal nodes are usually placed at the 
            # X position corresponding to the cumulative branch length up to that point).
            # We use the node's branch length (X-coordinate) and the average Y-coordinate 
            # of its descendants to approximate its drawn position.
            
            # X coordinate: distance from root
            x_coord = tree.distance(node)
            
            # Y coordinate: average position of children/descendants (for vertical placement)
            if node.clades:
                # Get y coordinates of all terminals below this node
                y_coords = [tree.distance(leaf) for leaf in node.get_terminals()]
                # This is complex, so we rely on the visual inspection of the node location.
                # A simpler, more robust approach for annotation is often manual placement 
                # relative to the horizontal position (x_coord) and a fixed vertical offset.
                
                # For simplicity in this example, we'll estimate Y based on node index 
                # or use the internal coordinate mapping if available. Since direct coordinate 
                # mapping is difficult without source code access, we place the text near the node.
                
                # A better approach is to use the midpoint of the Y coordinates of its children.
                leaf_y_positions = []
                for leaf in node.get_terminals():
                    # Find the index of the leaf in the overall list of terminals for Y placement
                    leaf_index = list(tree.get_terminals()).index(leaf)
                    # Assuming draw plots leaves sequentially on the Y axis (0, 1, 2...)
                    leaf_y_positions.append(leaf_index) 
                
                y_coord = sum(leaf_y_positions) / len(leaf_y_positions)
                
                # Add text annotation slightly above and right of the node
                ax.text(x_coord + 0.005, y_coord + 0.1, 
                        str(score), 
                        fontsize=8, 
                        color='black', 
                        fontweight='bold',
                        ha='left')

    # 5. Axis Customization
    ax.set_xlabel("Evolutionary Distance (Branch Length)")
    ax.set_title("Phylogenetic Tree with Clade Coloring and Bootstrap Annotation")
    
    # Create a dummy legend for clade colors
    import matplotlib.patches as mpatches
    legend_patches = [mpatches.Patch(color=c, label=l) for l, c in group_colors.items()]
    ax.legend(handles=legend_patches, loc='upper left')
    
    plt.show()

# Execute the visualization function
color_and_annotate_tree(tree, clade_classification, bootstrap_values)

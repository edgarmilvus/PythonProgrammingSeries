
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import io
from Bio import Phylo
from itertools import combinations

# Setup Tree Data
newick_data = "((A:0.01,B:0.01):0.05,(C:0.1,D:0.1):0.03,E:0.15);"
tree = Phylo.read(io.StringIO(newick_data), "newick")

def get_patristic_distance(tree, taxon1_name, taxon2_name):
    """
    Calculates the patristic distance between two taxa using Bio.Phylo's optimized method.
    """
    # Find the Clade objects corresponding to the names
    taxon1 = tree.find_any(name=taxon1_name)
    taxon2 = tree.find_any(name=taxon2_name)
    
    # Use the built-in distance method
    # tree.distance(clade1, clade2) calculates the distance via their MRCA
    return tree.distance(taxon1, taxon2)

def find_deepest_divergence(tree):
    """
    Iterates through all unique pairs of taxa to find the maximum patristic distance.
    """
    # 1. Obtain all terminal taxa names
    terminals = [clade.name for clade in tree.get_terminals()]
    
    max_distance = -1.0
    deepest_pair = (None, None)
    
    # 2. Iterate through every unique pair
    for taxon1, taxon2 in combinations(terminals, 2):
        # 3. Calculate the patristic distance
        distance = get_patristic_distance(tree, taxon1, taxon2)
        
        # 4. Track the maximum distance
        if distance > max_distance:
            max_distance = distance
            deepest_pair = (taxon1, taxon2)
            
    # 5. Output
    return list(deepest_pair), round(max_distance, 4)

# Execute the search
deepest_taxa, max_dist = find_deepest_divergence(tree)

print(f"Tree Taxa: {[c.name for c in tree.get_terminals()]}")
print(f"Deepest Divergence Pair: {deepest_taxa}")
print(f"Maximum Patristic Distance: {max_dist}")

# Verification: E to C/D MRCA is 0.15 + 0.03 = 0.18. C/D divergence is 0.1 + 0.1 = 0.2
# Path E to C: 0.15 + 0.03 + 0.1 = 0.28
# Path E to A: 0.15 + 0.05 + 0.01 = 0.21
# Path C to A: 0.03 + 0.05 + 0.01 = 0.09
# Deepest path is E to C (0.28) or E to D (0.28).

assert max_dist == 0.28

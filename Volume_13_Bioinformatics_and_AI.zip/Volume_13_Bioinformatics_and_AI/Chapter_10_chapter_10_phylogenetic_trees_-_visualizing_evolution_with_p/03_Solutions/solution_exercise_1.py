
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import io
from Bio import Phylo

def calculate_total_span(newick_string):
    """
    Parses a Newick string and calculates the total sum of all branch lengths.
    """
    # 1. Use io.StringIO to treat the string as a file handle
    handle = io.StringIO(newick_string)

    # 2. Parse the Newick data
    # Bio.Phylo.read assumes the tree structure is rooted
    tree = Phylo.read(handle, "newick")

    total_span = 0.0
    
    # 3. Traversal and Summation: Iterate over all clades (nodes)
    # We must include the root's immediate descendants and all internal/terminal nodes.
    # get_clades() returns all nodes, including the root itself.
    for clade in tree.get_clades():
        # Check if the branch length exists and is not None
        if clade.branch_length is not None:
            total_span += clade.branch_length
            
    return total_span

# Testing:
newick_data = "((Human:0.01,Chimpanzee:0.01):0.05,Gorilla:0.06,Orangutan:0.10):0.01;"
result = calculate_total_span(newick_data)

print(f"Newick Data: {newick_data}")
print(f"Total Evolutionary Span: {result:.2f}")

# Verification check
assert abs(result - 0.24) < 1e-6

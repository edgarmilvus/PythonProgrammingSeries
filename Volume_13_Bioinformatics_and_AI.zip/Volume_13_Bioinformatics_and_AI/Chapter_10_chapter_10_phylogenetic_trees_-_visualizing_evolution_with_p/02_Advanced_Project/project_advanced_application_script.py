
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import io
import os
import random
from Bio import Phylo
import matplotlib.pyplot as plt

# --- 1. Data Simulation and Setup ---

# Define a complex Newick string representing various influenza strains
# Branch lengths represent divergence (time/mutations)
NEWICK_DATA = """
((Strain_Asia_1:0.05, Strain_Asia_2:0.04):0.01,
(Strain_Asia_3:0.08, Strain_Asia_4:0.02):0.03,
(Strain_NA_1:0.15, Strain_NA_2:0.12):0.02,
(Strain_EU_5:0.09, Strain_EU_6:0.11):0.01):0.05,
Strain_Outlier:0.25);
"""

# Define target groups for analysis
TARGET_GROUP = "Asia"
COMPARISON_GROUP = "NA"
OUTPUT_DIR = "phylo_output"

# Ensure the output directory exists
if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)

# Load the tree from the string buffer
handle = io.StringIO(NEWICK_DATA)
# Read the tree using the Newick parser
influenza_tree = Phylo.read(handle, "newick")

# --- 2. Core Analysis Functions ---

def calculate_group_divergence(tree, keyword):
    """
    Calculates the total branch length divergence for all terminal clades 
    whose names contain the specified keyword.
    
    Uses EAFP style (Easier to Ask for Forgiveness than Permission) 
    by assuming .branch_length exists and catching AttributeError if it doesn't.
    """
    total_length = 0.0
    strain_count = 0
    
    for clade in tree.get_terminals():
        if keyword in clade.name:
            # Traverse up the tree from the terminal to the root, summing branch lengths
            # We must use .branch_length, which can sometimes be None for the root.
            current_clade = clade
            
            # Use EAFP to safely sum the branch length of the path from the terminal to the root
            while current_clade:
                try:
                    # Branch length represents the divergence from its parent
                    if current_clade.branch_length is not None:
                        total_length += current_clade.branch_length
                        
                    # Move up to the parent
                    current_clade = current_clade.parent
                    
                except AttributeError:
                    # If the root or a non-standard node is reached, parent might not exist
                    break 
            
            strain_count += 1
            
    if strain_count == 0:
        return 0.0, 0
        
    # Total length divided by the number of strains gives a rough measure of average divergence
    average_divergence = total_length / strain_count
    return average_divergence, strain_count

def find_mrca_and_subtree(tree, keyword):
    """
    Identifies the Most Recent Common Ancestor (MRCA) for all strains matching 
    the keyword and extracts the resulting subtree.
    """
    target_names = [clade.name for clade in tree.get_terminals() if keyword in clade.name]
    
    if not target_names:
        return None, None
        
    # Find the MRCA node (Most Recent Common Ancestor)
    mrca = tree.common_ancestor(*target_names)
    
    # Extract the subtree rooted at the MRCA
    # Bio.Phylo uses the MRCA node itself as the root of the new tree object
    subtree = Phylo.BaseTree.Tree(root=mrca, name=f"Subtree_{keyword}")
    
    return mrca, subtree

# --- 3. Execution and Reporting ---

# Analyze and compare the two groups
avg_asia, count_asia = calculate_group_divergence(influenza_tree, TARGET_GROUP)
avg_na, count_na = calculate_group_divergence(influenza_tree, COMPARISON_GROUP)

print(f"--- Divergence Analysis ---")
print(f"Group '{TARGET_GROUP}' (n={count_asia}): Average Divergence = {avg_asia:.4f}")
print(f"Group '{COMPARISON_GROUP}' (n={count_na}): Average Divergence = {avg_na:.4f}")

# Extract the target subtree
mrca_node, asia_subtree = find_mrca_and_subtree(influenza_tree, TARGET_GROUP)

if asia_subtree:
    print(f"\n--- Subtree Extraction and Visualization ---")
    print(f"MRCA identified for {TARGET_GROUP} strains.")

    # Find the most divergent strain within the Asian clade (highest branch length)
    most_divergent_strain = None
    max_length = -1.0
    
    for strain in asia_subtree.get_terminals():
        # Check the branch length connecting the terminal to its parent
        if strain.branch_length is not None and strain.branch_length > max_length:
            max_length = strain.branch_length
            most_divergent_strain = strain.name

    print(f"Most divergent strain in the {TARGET_GROUP} clade: {most_divergent_strain} (Length: {max_length:.4f})")

    # --- 4. Custom Visualization using Matplotlib ---
    
    # Set up the figure for visualization
    fig, ax = plt.subplots(figsize=(8, 6))
    
    # Define a custom label function for highlighting
    def label_highlight(clade):
        if clade.name == most_divergent_strain:
            return f"{clade.name} <--- HIGH DIVERGENCE"
        return clade.name

    # Draw the extracted subtree
    Phylo.draw(
        asia_subtree, 
        axes=ax, 
        show_confidence=False, 
        label_func=label_highlight, 
        do_show=False
    )
    
    # Customize Matplotlib elements
    ax.set_title(f"Phylogeny of {TARGET_GROUP} Strains (Rooted at MRCA)")
    ax.set_xlabel("Evolutionary Distance (Branch Length)")
    
    # Save the custom visualization using os.path.join for platform independence
    output_path = os.path.join(OUTPUT_DIR, f"{TARGET_GROUP}_subtree_visualization.png")
    plt.savefig(output_path, bbox_inches='tight')
    plt.close(fig)
    
    print(f"Visualization saved successfully to: {output_path}")

    # Optional: Display ASCII representation of the extracted tree for console verification
    print("\nASCII Representation of Extracted Subtree:")
    Phylo.draw_ascii(asia_subtree)
else:
    print(f"Could not find any strains matching the keyword '{TARGET_GROUP}'.")

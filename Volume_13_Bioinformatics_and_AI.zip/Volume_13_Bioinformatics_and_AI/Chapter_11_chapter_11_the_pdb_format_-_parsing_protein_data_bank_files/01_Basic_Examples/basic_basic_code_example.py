
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import sys

# --- 1. Define the PDB ATOM record line (fixed width standard) ---
# This line represents a Nitrogen atom (N) in a Methionine residue (MET).
# Length is 80 characters, standardized in the PDB format.
PDB_LINE_DATA = "ATOM      1  N   MET A   1      25.430  10.120   5.800  1.00 40.00           N  "

# --- 2. Define the fixed column indices using slice objects ---
# CRITICAL NOTE: PDB documentation uses 1-based indexing (1-80).
# Python uses 0-based indexing, so we subtract 1 from the PDB start column.
# A slice object [start:stop] is exclusive of the 'stop' index.

# Record Type (PDB 1-6) -> Python [0:6]
RECORD_TYPE_SLICE = slice(0, 6)

# Atom Name (PDB 13-16) -> Python [12:16]
ATOM_NAME_SLICE = slice(12, 16)

# Residue Name (PDB 18-20) -> Python [17:20]
RESIDUE_NAME_SLICE = slice(17, 20)

# X Coordinate (PDB 31-38) -> Python [30:38]
X_COORD_SLICE = slice(30, 38)

# Y Coordinate (PDB 39-46) -> Python [38:46]
Y_COORD_SLICE = slice(38, 46)

# Z Coordinate (PDB 47-54) -> Python [46:54]
Z_COORD_SLICE = slice(46, 54)


def parse_pdb_atom_record(line: str):
    """
    Manually parses key fields from a single fixed-width PDB ATOM record line.
    """
    
    # 3. Extraction and Initial Cleaning (.strip() is essential to remove padding)
    record_type = line[RECORD_TYPE_SLICE].strip()
    
    # Only process ATOM records, skipping HETATM, REMARK, etc.
    if record_type != "ATOM":
        return None 
    
    atom_name = line[ATOM_NAME_SLICE].strip()
    residue_name = line[RESIDUE_NAME_SLICE].strip()

    # Extract coordinate strings
    x_str = line[X_COORD_SLICE].strip()
    y_str = line[Y_COORD_SLICE].strip()
    z_str = line[Z_COORD_SLICE].strip()
    
    # 4. Type Conversion with Robust Error Handling
    try:
        x_coord = float(x_str)
        y_coord = float(y_str)
        z_coord = float(z_str)
    
    except ValueError as e:
        # This occurs if the fixed field contained non-numeric characters 
        # (e.g., blank spaces or '****' for missing data).
        print(f"FATAL ERROR: Could not convert coordinates to float. Data: '{x_str}', '{y_str}', '{z_str}'", file=sys.stderr)
        print(f"Underlying error: {e}", file=sys.stderr)
        return None

    # 5. Compile and return the structured data
    return {
        "record": record_type,
        "atom_name": atom_name,
        "residue": residue_name,
        "x": x_coord,
        "y": y_coord,
        "z": z_coord
    }

# --- 6. Execution and Display ---
parsed_data = parse_pdb_atom_record(PDB_LINE_DATA)

if parsed_data:
    print("--- Successfully Parsed PDB Record ---")
    print(f"Record Type: {parsed_data['record']}")
    print(f"Atom Name:   {parsed_data['atom_name']}")
    print(f"Residue:     {parsed_data['residue']}")
    print("-" * 30)
    print(f"X Coordinate: {parsed_data['x']:.3f} Å")
    print(f"Y Coordinate: {parsed_data['y']:.3f} Å")
    print(f"Z Coordinate: {parsed_data['z']:.3f} Å")
    print(f"Total Coordinates: ({parsed_data['x']:.3f}, {parsed_data['y']:.3f}, {parsed_data['z']:.3f})")


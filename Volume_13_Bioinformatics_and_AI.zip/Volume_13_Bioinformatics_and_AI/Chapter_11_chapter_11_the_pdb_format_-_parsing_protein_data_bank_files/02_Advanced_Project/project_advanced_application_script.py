
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import os
from Bio.PDB import PDBList, PDBParser, Selection
from Bio.PDB.PDBExceptions import PDBConstructionException

# --- Helper Functions for Geometric Analysis ---

def calculate_centroid(residues):
    """
    Calculates the geometric centroid (center of mass) for a list of Biopython Residue objects.
    The calculation includes all ATOM coordinates within the specified residues.
    """
    all_coords = []
    
    # Iterate through all residues and extract coordinates of every atom
    for residue in residues:
        for atom in residue.get_atoms():
            # Atom.get_coord() returns a NumPy array [x, y, z]
            all_coords.append(atom.get_coord())
    
    if not all_coords:
        # Raise an exception if the residue selection yielded no atoms
        raise ValueError("Error: No atoms found in the specified active site residues.")
    
    # Convert the list of coordinate arrays into a single NumPy matrix
    coord_matrix = np.array(all_coords)
    
    # Calculate the mean along the columns (axis=0) to get the centroid [mean_x, mean_y, mean_z]
    return np.mean(coord_matrix, axis=0)

def find_closest_hetatm(structure, centroid_coord):
    """
    Searches the entire parsed structure for non-water HETATMs and finds the one 
    whose center is closest to the given pocket centroid coordinate.
    """
    min_distance = float('inf')
    closest_hetatm_info = None

    # Biopython structures are hierarchical: Structure -> Model -> Chain -> Residue -> Atom
    for model in structure:
        for chain in model:
            for residue in chain:
                # PDB parsing identifies HETATM records. The residue ID tuple format 
                # is (HETATM_flag, residue_number, insertion_code).
                # HETATM_flag is 'W' for water, 'H' for other HETATMs, or ' ' for standard ATOM records.
                
                het_flag = residue.id[0]
                res_name = residue.resname
                
                # Filter 1: Skip standard ATOM records
                if het_flag == ' ':
                    continue
                
                # Filter 2: Skip water molecules (HOH)
                if het_flag == 'W' or res_name == 'HOH':
                    continue
                
                # Calculate the center of the HETATM (using its atoms' centroid)
                hetatm_coords = [atom.get_coord() for atom in residue.get_atoms()]
                if not hetatm_coords:
                    continue # Skip empty residues
                    
                hetatm_center = np.mean(np.array(hetatm_coords), axis=0)
                
                # Calculate the Euclidean distance (in Ångströms) between the two centers
                # np.linalg.norm calculates the magnitude of the vector difference
                distance = np.linalg.norm(hetatm_center - centroid_coord)
                
                # Update the closest HETATM record if a shorter distance is found
                if distance < min_distance:
                    min_distance = distance
                    closest_hetatm_info = {
                        "resname": res_name,
                        "resid": residue.id[1],
                        "chain": chain.id,
                        "distance": distance
                    }
                        
    return closest_hetatm_info, min_distance

# --- Main Application Logic ---

def analyze_binding_pocket(pdb_id="1A2C", active_site_spec={'A': [200, 201, 202, 203, 204]}):
    """
    Drives the analysis pipeline: download, parse, calculate centroid, and search.
    """
    print(f"--- Analyzing PDB ID: {pdb_id} for Ligand Proximity ---")
    
    # 1. Data Acquisition: Download PDB file
    pdbl = PDBList()
    # Retrieve the file and store its local path
    try:
        pdb_file_path = pdbl.retrieve_pdb_file(pdb_id, file_format="pdb", pdir=".", overwrite=True)
    except Exception as e:
        print(f"Error downloading PDB file {pdb_id}: {e}")
        return

    # 2. PDB Parsing
    parser = PDBParser(QUIET=True) # QUIET=True suppresses warnings about non-standard records
    try:
        structure = parser.get_structure(pdb_id, pdb_file_path)
    except PDBConstructionException as e:
        print(f"Error parsing PDB file: {e}")
        return
        
    model = structure[0] # Most PDB files contain only one model (Model 0)

    # 3. Select and Validate Active Site Residues
    active_site_residues = []
    
    for chain_id, res_list in active_site_spec.items():
        if chain_id in model:
            chain = model[chain_id]
            for res_id in res_list:
                # Biopython requires the full residue identifier tuple for lookup:
                # (' ', Residue Number, Insertion Code) 
                # We assume standard ATOM records (' ') and no insertion codes (' ').
                res_key = (' ', res_id, ' ') 
                
                if res_key in chain:
                    active_site_residues.append(chain[res_key])
                # Note: Warnings are suppressed if a residue is missing, allowing the script to proceed with available data.

    if not active_site_residues:
        print("Error: No defined active site residues were successfully located in the structure.")
        # os.remove(pdb_file_path) # Clean up
        return

    # 4. Calculate Centroid
    try:
        pocket_centroid = calculate_centroid(active_site_residues)
        print(f"\n[STEP 1] Centroid of Active Site ({len(active_site_residues)} residues) calculated.")
        print(f"         Coordinates (X, Y, Z): {pocket_centroid.round(3)}")
    except ValueError as e:
        print(f"Analysis failed: {e}")
        return

    # 5. Locate Closest HETATM
    closest_hetatm, distance = find_closest_hetatm(structure, pocket_centroid)

    # 6. Report Results
    print("\n[STEP 2] Results of Ligand Proximity Search:")
    
    if closest_hetatm:
        print("----------------------------------------------------------------------")
        print(f"  Closest Ligand/Cofactor: {closest_hetatm['resname']}")
        print(f"  PDB Identifier (Chain/ResID): {closest_hetatm['chain']}/{closest_hetatm['resid']}")
        print(f"  Distance from Pocket Centroid: {distance:.3f} Ångströms (A typical binding distance is < 4.0 Å)")
        print("----------------------------------------------------------------------")
        
    else:
        print("No non-water HETATMs (ligands or cofactors) were found in the structure.")

# --- Execution Block ---
if __name__ == "__main__":
    # PDB 4Q21 (Example: Human Acetylcholinesterase with an inhibitor)
    # Hypothetical active site residues defined across chain A.
    active_site_definition = {
        'A': [86, 124, 127, 202, 338, 341] 
    }
    
    analyze_binding_pocket(pdb_id="4Q21", active_site_spec=active_site_definition)


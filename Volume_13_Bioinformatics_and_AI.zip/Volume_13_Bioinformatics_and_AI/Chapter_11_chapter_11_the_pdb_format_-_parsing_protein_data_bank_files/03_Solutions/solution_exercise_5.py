
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from datetime import datetime
import os
import re

def parse_pdb_metadata(filename="5A2C.pdb", target_chain='A'):
    """
    Manually parses non-structural PDB records (HEADER, REMARK 2, SEQRES) 
    to extract metadata and sequence information.
    """
    
    # --- Setup dummy file for demonstration if not provided ---
    if not os.path.exists(filename):
        dummy_content = """
HEADER    TRANSFERASE INHIBITOR   16-DEC-97   1A2C
REMARK 1
REMARK 2
REMARK 2 RESOLUTION. 2.50 ANGSTROMS.
REMARK 3
SEQRES   1 A   10  GLY ALA LEU VAL ILE PHE TYR TRP PRO
SEQRES   1 B    5  SER THR CYS LYS ARG
SEQRES   2 A   10  SER THR CYS LYS ARG
REMARK 4
        """
        with open(filename, "w") as f:
            f.write(dummy_content.strip())
    # --------------------------------------------------------

    metadata = {
        'classification': 'N/A',
        'date': None,
        'resolution': 'N/A',
        'sequence': []
    }
    
    # Format for PDB dates: DD-MMM-YY (e.g., 16-DEC-97)
    PDB_DATE_FORMAT = "%d-%b-%y" 

    with open(filename, 'r') as f:
        for line in f:
            record_name = line[0:6].strip()

            # 1. HEADER Extraction
            if record_name == "HEADER":
                # Classification: Columns 11-50 (Indices 10:50)
                metadata['classification'] = line[10:50].strip()
                # Date: Columns 51-59 (Indices 50:59)
                date_str = line[50:59].strip()
                try:
                    metadata['date'] = datetime.strptime(date_str, PDB_DATE_FORMAT)
                except ValueError:
                    metadata['date'] = "Malformed Date"
            
            # 2. REMARK 2 (Resolution) Extraction
            elif record_name == "REMARK" and line[7:10].strip() == "2":
                remark_content = line[11:].strip()
                if "RESOLUTION" in remark_content:
                    # Use regex to find floating point number
                    match = re.search(r'RESOLUTION\.?\s*(\d+\.\d+)', remark_content)
                    if match:
                        metadata['resolution'] = float(match.group(1))
                    elif "NOT APPLICABLE" in remark_content:
                        metadata['resolution'] = "N/A (NMR/Theoretical)"

            # 3. Sequence Extraction (SEQRES)
            elif record_name == "SEQRES":
                chain = line[11].strip()
                if chain == target_chain:
                    # Residues start at column 20 (index 19) and continue to 70 (index 69)
                    residues_line = line[19:70].split()
                    metadata['sequence'].extend(residues_line)

    # 4. Output Summary
    print(f"--- PDB Metadata Report (Chain {target_chain}) ---")
    print(f"Classification: {metadata['classification']}")
    
    if isinstance(metadata['date'], datetime):
        print(f"Deposition Date: {metadata['date'].strftime('%Y-%m-%d')}")
    else:
        print(f"Deposition Date: {metadata['date']}")

    print(f"Experimental Resolution: {metadata['resolution']} Å")
    
    seq_len = len(metadata['sequence'])
    print(f"SEQRES Sequence Length: {seq_len}")
    
    # 5. List of first 10 residues
    print(f"First 10 Residues: {' '.join(metadata['sequence'][:10])}")

# Example Execution
parse_pdb_metadata(target_chain='A')

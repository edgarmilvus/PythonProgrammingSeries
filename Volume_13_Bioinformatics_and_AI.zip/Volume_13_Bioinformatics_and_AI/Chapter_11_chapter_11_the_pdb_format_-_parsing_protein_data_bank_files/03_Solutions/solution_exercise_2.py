
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from Bio.PDB import PDBParser
from collections import Counter
import os

def analyze_pdb_structure(filename="4HHB.pdb"):
    """
    Loads a PDB file using Biopython and generates a statistical summary
    of models, chains, and residue frequencies.
    """
    
    # --- Setup dummy file for demonstration if not provided ---
    if not os.path.exists(filename):
        dummy_content = """
HEADER    OXYGEN TRANSPORT                         23-JUN-04   4HHB
MODEL        1
ATOM      1  CA  VAL A   1      30.000  20.100  10.000  1.00 55.00           C
ATOM      2  CA  LEU A   2      31.100  20.500  10.500  1.00 50.00           C
ATOM      3  CA  ALA B   1      34.000  18.000  12.000  1.00 35.00           C
HETATM  100 O   HOH W 999      10.000  10.000  10.000  1.00 20.00           O
HETATM  101 FE  HEM H 900       5.000   5.000   5.000  1.00 15.00          FE
HETATM  102 MG  MGA H 901       6.000   6.000   6.000  1.00 15.00          MG
ENDMDL
MODEL        2
ATOM      4  CA  VAL A   1      30.000  20.100  10.000  1.00 55.00           C
ATOM      5  CA  LEU A   2      31.100  20.500  10.500  1.00 50.00           C
HETATM  103 O   HOH W 999      10.000  10.000  10.000  1.00 20.00           O
ENDMDL
        """
        with open(filename, "w") as f:
            f.write(dummy_content.strip())
    # --------------------------------------------------------

    parser = PDBParser(QUIET=True)
    try:
        structure = parser.get_structure('PDB_ID', filename)
    except FileNotFoundError:
        print(f"Error: File {filename} not found.")
        return

    residue_counts = Counter()
    chain_ids = set()
    model_count = 0
    
    # 1. Traverse the Structure Hierarchy
    for model in structure:
        model_count += 1
        for chain in model:
            chain_ids.add(chain.id)
            for residue in chain:
                # Residue ID is a tuple: (hetero_flag, residue_name, insertion_code)
                res_id_tuple = residue.id
                res_name = residue.get_resname()
                
                # 2. Categorization and Counting
                if res_id_tuple[0] == ' ':
                    # Standard amino acid
                    residue_counts['STANDARD'] += 1
                    residue_counts[res_name] += 1
                elif res_name == 'HOH':
                    # Water molecule
                    residue_counts['WATER'] += 1
                else:
                    # Other HETATM (ligands, ions, etc.)
                    residue_counts['HETATM'] += 1
                    residue_counts[res_name] += 1
    
    # 3. Generating the Summary
    
    # Filter standard residues
    standard_residues = {k: v for k, v in residue_counts.items() 
                         if len(k) == 3 and k not in ['HOH', 'STANDARD', 'HETATM']}
    std_counter = Counter(standard_residues)
    
    # Filter HETATMs (excluding HOH and internal counters)
    het_residues = {k: v for k, v in residue_counts.items() 
                    if residue_counts['HETATM'] > 0 and k not in ['HOH', 'STANDARD', 'HETATM']}
    het_counter = Counter(het_residues)

    print(f"--- Structural Summary for {filename} ---")
    print(f"Total Models Found: {model_count}")
    print(f"Total Unique Chains Found: {len(chain_ids)} ({', '.join(sorted(list(chain_ids)))})")
    print("\n--- Residue Analysis ---")
    
    # 4. Output results
    print(f"Water Molecules (HOH) Count: {residue_counts.get('WATER', 0)}")
    
    print("\nTop 5 Standard Amino Acids:")
    for res, count in std_counter.most_common(5):
        print(f"  {res}: {count}")

    print("\nTop 3 Hetero-atoms (Excluding Water):")
    for res, count in het_counter.most_common(3):
        print(f"  {res}: {count}")

# Example Execution
analyze_pdb_structure()

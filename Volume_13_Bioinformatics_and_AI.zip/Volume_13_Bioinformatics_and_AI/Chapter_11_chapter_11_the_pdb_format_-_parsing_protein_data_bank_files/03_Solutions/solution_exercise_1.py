
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import sys
import os

def parse_pdb_manually(filename="1A2C.pdb"):
    """
    Reads a PDB file, extracts coordinates from ATOM records using string slicing,
    and handles potential conversion errors.
    """
    
    # --- Setup dummy file for demonstration if not provided ---
    if not os.path.exists(filename):
        print(f"Creating dummy file: {filename}")
        dummy_content = """
HEADER    TRANSFERASE/TRANSFERASE INHIBITOR                  16-DEC-97   1A2C
ATOM      1  N   GLY A   1      30.000  20.100  10.000  1.00 55.00           N
ATOM      2  CA  GLY A   1      31.100  20.500  10.500  1.00 50.00           C
ATOM      3  C   GLY A   1      32.000  19.500  10.900  1.00 45.00           C
ATOM      4  O   GLY A   1      33.000  19.800  11.500  1.00 40.00           O
ATOM      5  N   ALA B   2      34.000  18.000  12.000  1.00 35.00           N
ATOM      6  CA  ALA B   2      35.000  18.500  12.500  1.00 30.00           C
ATOM      7  C   ALA B   2      36.000  17.500  13.000  1.00 25.00           C
ATOM      8  CA  ALA C   3      37.000  16.500  NONNUM  1.00 20.00           C
HETATM  100 HOH W 999      10.000  10.000  10.000  1.00 20.00           O
        """
        with open(filename, "w") as f:
            f.write(dummy_content.strip())
    # --------------------------------------------------------

    print("Chain | Residue | X        | Y        | Z")
    print("-" * 45)
    
    atom_count = 0
    line_number = 0

    with open(filename, 'r') as f:
        for line in f:
            line_number += 1
            if line.startswith("ATOM  "):
                if atom_count >= 100:
                    break
                
                try:
                    # 1. Extraction using fixed-column indices (0-based)
                    chain_id = line[21].strip()
                    res_name = line[17:20].strip()
                    
                    # Coordinates are extracted as strings and converted to float
                    x_str = line[30:38]
                    y_str = line[38:46]
                    z_str = line[46:54]
                    
                    x_coord = float(x_str)
                    y_coord = float(y_str)
                    z_coord = float(z_str)

                    # 2. Output
                    print(f"{chain_id:<5} | {res_name:<7} | {x_coord:8.3f} | {y_coord:8.3f} | {z_coord:8.3f}")
                    atom_count += 1
                    
                except ValueError:
                    # 3. Edge Case Handling
                    print(f"--- ERROR on line {line_number}: Failed to convert coordinates. ---")
                    print(f"Raw line: {line.strip()}")
                    continue

# Example Execution (assuming 1A2C.pdb exists or is created by the setup block)
parse_pdb_manually()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np
from Bio.PDB import PDBParser, PDBList
import os
import sys

# --- Mock PDB Download/Setup for execution environment ---
def setup_pdb_file(pdb_id, chain_id):
    filename = f"{pdb_id}.pdb"
    # Example structure: 1 model, Chain A and B. 
    # Chain A atoms: (10,10,10), (11,10,10), (12,10,10). CM = (11, 10, 10)
    content = f"""
HEADER    TEST STRUCTURE
MODEL        1
ATOM      1  CA  GLY A   1      10.000  10.000  10.000  1.00 20.00           C
ATOM      2  CA  ALA A   2      11.000  10.000  10.000  1.00 20.00           C
ATOM      3  CA  GLY A   3      12.000  10.000  10.000  1.00 20.00           C
ATOM      4  CA  GLY B   1      20.000  20.000  20.000  1.00 20.00           C
HETATM  100 O   HOH A 999       0.000   0.000   0.000  1.00 20.00           O
ENDMDL
"""
    with open(filename, "w") as f:
        f.write(content.strip())
    return filename
# --------------------------------------------------------

def calculate_radius_of_gyration():
    """Calculates Rg for a user-specified chain in a PDB structure."""
    
    # 1. User Input and Validation
    pdb_id = input("Enter PDB ID (e.g., 1A2C): ").upper()
    chain_id = input("Enter Chain ID (single character, e.g., A): ").upper()
    
    if len(chain_id) != 1 or not chain_id.isalpha():
        print("Error: Chain ID must be a single character.")
        return

    # In a real environment, use PDBList().retrieve(pdb_id)
    # For this exercise, we rely on the setup function to create the file locally.
    filename = setup_pdb_file(pdb_id, chain_id)
    
    parser = PDBParser(QUIET=True)
    try:
        structure = parser.get_structure(pdb_id, filename)
    except Exception as e:
        print(f"Error loading structure: {e}")
        return

    target_chain = None
    
    # Find the target chain in the first model
    for model in structure:
        if chain_id in model:
            target_chain = model[chain_id]
            break
            
    if target_chain is None:
        print(f"Chain {chain_id} not found in PDB {pdb_id}.")
        return

    coordinates = []
    
    # 2. Target Selection: Collect coordinates, excluding HETATMs
    for residue in target_chain:
        # Check if it is a standard residue (hetero_flag is ' ')
        if residue.id[0] == ' ':
            for atom in residue:
                coordinates.append(atom.get_coord())

    if not coordinates:
        print(f"No standard atoms found in Chain {chain_id}.")
        return

    coords_array = np.array(coordinates)
    N = len(coords_array)

    # 3. Center of Mass (CM) Calculation (assuming equal mass)
    cm = np.mean(coords_array, axis=0)
    
    # 4. Distance Calculation: Vectorized approach
    # Subtract CM from all coordinates
    diff = coords_array - cm
    
    # Calculate squared distance (r_i^2)
    squared_distances = np.sum(diff**2, axis=1)
    
    # 5. Rg Calculation
    mean_squared_distance = np.mean(squared_distances)
    rg = np.sqrt(mean_squared_distance)

    # 6. Output
    print("\n--- Radius of Gyration Calculation ---")
    print(f"PDB ID: {pdb_id}, Chain ID: {chain_id}")
    print(f"Total atoms analyzed: {N}")
    print(f"Center of Mass (X, Y, Z): ({cm[0]:.3f}, {cm[1]:.3f}, {cm[2]:.3f})")
    print(f"Radius of Gyration (Rg): {rg:.3f} Å")

# Example Execution
# Note: This requires interactive input. We simulate the call.
# calculate_radius_of_gyration() 
# Assuming user inputs '1A2C' and 'A'
# Expected CM: (11.000, 10.000, 10.000)
# Expected squared distances: (10-11)^2 + 0 + 0 = 1; (11-11)^2 + 0 + 0 = 0; (12-11)^2 + 0 + 0 = 1
# Mean squared distance = (1 + 0 + 1) / 3 = 0.6666...
# Rg = sqrt(0.6666...) = 0.816 Å
print("Running interactive Rg calculation...")
# Mocking input for testing purposes if running non-interactively
if 'calculate_radius_of_gyration' in locals():
    # Simulate user input if necessary for testing environment
    if os.environ.get('TEST_ENV'):
        sys.stdin = iter(['1A2C', 'A'])
    calculate_radius_of_gyration()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import statistics
import os

def normalize_b_factors(input_filename="3A2C.pdb", output_filename="3A2C_normalized.pdb"):
    """
    Calculates Z-scores for CA B-factors and writes a new PDB file 
    with the Z-scores replacing the original B-factors.
    """
    
    # --- Setup dummy file for demonstration if not provided ---
    if not os.path.exists(input_filename):
        dummy_content = """
HEADER    TEST PDB FILE
ATOM      1  N   GLY A   1      30.000  20.100  10.000  1.00 10.00           N
ATOM      2  CA  GLY A   1      31.100  20.500  10.500  1.00 20.00           C
ATOM      3  C   GLY A   1      32.000  19.500  10.900  1.00 10.00           C
ATOM      4  CA  ALA A   2      33.000  19.800  11.500  1.00 30.00           C
ATOM      5  N   ALA B   3      34.000  18.000  12.000  1.00 10.00           N
ATOM      6  CA  ALA B   3      35.000  18.500  12.500  1.00 40.00           C
ATOM      7  CA  THR B   4      36.000  17.500  13.000  1.00 50.00           C
REMARK 2
        """
        with open(input_filename, "w") as f:
            f.write(dummy_content.strip())
    # --------------------------------------------------------

    ca_b_factors = []
    pdb_lines = []

    # 1. Data Collection Pass (Find all CA B-factors)
    with open(input_filename, 'r') as f:
        for line in f:
            pdb_lines.append(line.rstrip('\n'))
            if line.startswith("ATOM"):
                atom_name = line[12:16].strip()
                if atom_name == 'CA':
                    try:
                        b_factor = float(line[60:66].strip())
                        ca_b_factors.append(b_factor)
                    except ValueError:
                        print(f"Warning: Skipping malformed B-factor on line: {line.strip()}")
                        continue

    if not ca_b_factors:
        print("Error: No CA atoms found for normalization.")
        return

    # 2. Statistical Calculation
    mu = statistics.mean(ca_b_factors)
    try:
        sigma = statistics.stdev(ca_b_factors)
    except statistics.StatisticsError:
        # Handle case where only one CA atom exists or all values are identical
        sigma = 0.0

    print(f"CA B-factor Statistics: Mean={mu:.2f}, Stdev={sigma:.2f}")

    # 3. Transformation and Output Generation Pass
    with open(output_filename, 'w') as out_f:
        for line in pdb_lines:
            if line.startswith("ATOM"):
                atom_name = line[12:16].strip()
                
                if atom_name == 'CA':
                    try:
                        original_b = float(line[60:66].strip())
                        
                        # Calculate Z-score
                        if sigma > 0:
                            z_score = (original_b - mu) / sigma
                        else:
                            # If sigma is zero, all values are the mean, so Z-score is 0
                            z_score = 0.0
                        
                        # 4. Formatting Precision (6 columns wide, 2 decimal places, right-justified)
                        # We use the standard format for PDB B-factors (F6.2)
                        z_score_str = "{:6.2f}".format(z_score)
                        
                        # Reconstruct the line: [0:60] + [60:66] + [66:]
                        new_line = line[:60] + z_score_str + line[66:]
                        out_f.write(new_line + '\n')
                        
                    except ValueError:
                        # Pass through corrupted lines if B-factor couldn't be read
                        out_f.write(line + '\n')
                else:
                    # 6. Non-CA Handling: Write original line unmodified
                    out_f.write(line + '\n')
            else:
                # Write non-ATOM records unmodified
                out_f.write(line + '\n')

    print(f"Successfully wrote normalized PDB file to {output_filename}")

# Example Execution
normalize_b_factors()

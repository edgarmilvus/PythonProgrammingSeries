
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# ==============================================================================
# 1. CONSTANTS AND DATA STRUCTURES
# ==============================================================================

# Standard Genetic Code (mRNA codons mapped to Amino Acids)
GENETIC_CODE = {
    'UUU': 'F', 'UUC': 'F', 'UUA': 'L', 'UUG': 'L',
    'UCU': 'S', 'UCC': 'S', 'UCA': 'S', 'UCG': 'S',
    'UAU': 'Y', 'UAC': 'Y', 'UAA': '*', 'UAG': '*',  # * denotes STOP
    'UGU': 'C', 'UGC': 'C', 'UGA': '*', 'UGG': 'W',
    'CUU': 'L', 'CUC': 'L', 'CUA': 'L', 'CUG': 'L',
    'CCU': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P',
    'CAU': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
    'CGU': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R',
    'AUU': 'I', 'AUC': 'I', 'AUA': 'I', 'AUG': 'M',  # Start Codon
    'ACU': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T',
    'AAU': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K',
    'AGU': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
    'GUU': 'V', 'GUC': 'V', 'GUA': 'V', 'GUG': 'V',
    'GCU': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A',
    'GAU': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E',
    'GGU': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'
}

START_CODON = 'AUG'
STOP_CODONS = ('UAA', 'UAG', 'UGA')

# Sample DNA Sequence (must be long enough to contain ORFs)
DNA_SEQUENCE = (
    "ATGGCACTAGTTACCGTAGCATGTTTGATAGCTAGTCGATGGCTAGCTAGCTAGCTAG"
    "CGCGGCCATGCCGATGCATGGTAGCATGTAGCTAGCTAGCTAGCTGATCATATAGTCA"
    "TGCATGCATGCATGCATGCATGCATGCATGCATGCATGCATGCATGCATGCATGCATG"
    "CATGCATGCATGCATGCATGCATGCATGCATGCATGCATGCATGCATGCATGCATGCG"
    "GCTAGCTGATAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCT"
    "AGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAG"
    "CTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCT"
    "AGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAG"
    "CTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCT"
    "AGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAG"
    "CTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCT"
    "AGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAG"
    "CTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCT"
    "AGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAG"
    "CTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCT"
    "AATAA" # Stop Codon TAA in DNA
)

# ==============================================================================
# 2. CORE UTILITY FUNCTIONS
# ==============================================================================

def calculate_gc_content(sequence: str) -> float:
    """Calculates the percentage of Guanine (G) and Cytosine (C) in a sequence."""
    g_count = sequence.count('G') + sequence.count('g')
    c_count = sequence.count('C') + sequence.count('c')
    total_length = len(sequence)
    if total_length == 0:
        return 0.0
    return ((g_count + c_count) / total_length) * 100

def transcribe(dna_sequence: str) -> str:
    """Converts DNA (T) to mRNA (U) using basic string replacement."""
    # Ensure sequence is uppercase for consistent replacement
    return dna_sequence.upper().replace('T', 'U')

def translate_orf(mrna_orf: str, codon_table: dict) -> str:
    """Translates a single mRNA sequence (ORF) into an amino acid chain."""
    protein = []
    # Iterate through the sequence in steps of 3 (codons)
    for i in range(0, len(mrna_orf), 3):
        codon = mrna_orf[i:i+3]
        # Check if the codon is a full triplet
        if len(codon) == 3:
            # Use dictionary lookup for translation
            amino_acid = codon_table.get(codon, 'X') # 'X' for unknown/error
            if amino_acid == '*':
                break # Stop translation upon reaching a stop codon
            protein.append(amino_acid)
    return "".join(protein)

# ==============================================================================
# 3. ORF IDENTIFICATION LOGIC
# ==============================================================================

def find_orfs(mrna_seq: str) -> list[str]:
    """
    Identifies all potential Open Reading Frames (ORFs) by checking all three
    reading frames for START and STOP codons.
    """
    potential_orfs = []
    seq_len = len(mrna_seq)

    # Loop through the three possible reading frames (0, 1, 2)
    for frame in range(3):
        in_orf = False
        start_index = -1

        # Iterate through the sequence in steps of 3, starting at the frame offset
        for i in range(frame, seq_len - 2, 3):
            codon = mrna_seq[i:i+3]

            if not in_orf:
                # Search for the START codon ('AUG')
                if codon == START_CODON:
                    in_orf = True
                    start_index = i
            else:
                # Search for a STOP codon
                if codon in STOP_CODONS:
                    # ORF found: extract the sequence from START to the beginning of STOP
                    orf_sequence = mrna_seq[start_index:i]
                    potential_orfs.append(orf_sequence)
                    in_orf = False # Reset state for the next ORF in this frame

        # Handle truncated ORFs that run to the end of the sequence
        if in_orf and start_index != -1:
            orf_sequence = mrna_seq[start_index:]
            potential_orfs.append(orf_sequence)

    return potential_orfs

# ==============================================================================
# 4. MAIN EXECUTION BLOCK
# ==============================================================================

if __name__ == "__main__":
    print("--- Bioinformatics String Processor: ORF Finder ---")

    # Step 4a: Transcription
    mrna_sequence = transcribe(DNA_SEQUENCE)
    print(f"\n1. Original DNA Length: {len(DNA_SEQUENCE)} bp")
    print(f"2. Transcribed mRNA Length: {len(mrna_sequence)} nt")

    # Step 4b: ORF Identification
    all_orfs = find_orfs(mrna_sequence)
    print(f"3. Identified {len(all_orfs)} potential ORFs.")

    if not all_orfs:
        print("No ORFs found in the sequence.")
    else:
        # Step 4c: Find the longest ORF using the 'max' function and 'key' argument
        # This is a Pythonic way to find the longest string in a list
        longest_orf = max(all_orfs, key=len)

        # Step 4d: Translation
        protein_sequence = translate_orf(longest_orf, GENETIC_CODE)

        # Step 4e: Analysis and Output
        gc_content_orf = calculate_gc_content(longest_orf)

        print("\n--- Analysis of Longest ORF ---")
        print(f"ORF Length (nucleotides): {len(longest_orf)}")
        print(f"Protein Length (amino acids): {len(protein_sequence)}")
        print(f"GC Content of ORF: {gc_content_orf:.2f}%")
        print(f"\nLongest ORF (mRNA):\n{longest_orf[:80]}... [Total {len(longest_orf)} nt]")
        print(f"Translated Protein:\n{protein_sequence[:40]}... [Total {len(protein_sequence)} aa]")


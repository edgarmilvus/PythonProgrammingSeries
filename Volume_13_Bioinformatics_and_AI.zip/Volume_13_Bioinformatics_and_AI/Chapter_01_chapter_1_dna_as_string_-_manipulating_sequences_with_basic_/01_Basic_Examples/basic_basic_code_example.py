
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# ----------------------------------------------------------------------
# Basic Example: Calculating GC Content of a DNA Sequence
# ----------------------------------------------------------------------

# 1. Define the DNA sequence as a standard Python string
# This sequence represents a hypothetical fragment of a genome
dna_sequence = "ATGCGGTAAGCTTACCGGTAGGCCTTAA"

# 2. Determine the total length of the sequence using the built-in len() function
total_length = len(dna_sequence)

# 3. Count the occurrences of Guanine (G) and Cytosine (C)
# The str.count() method efficiently scans the string for the specified substring
g_count = dna_sequence.count('G')
c_count = dna_sequence.count('C')

# 4. Calculate the total number of G and C bases by simple addition
gc_bases = g_count + c_count

# 5. Calculate the GC content ratio (as a fraction)
# We perform floating-point division to ensure accuracy. Since 'gc_bases' and 
# 'total_length' are integers, Python 3 automatically handles the conversion 
# to float during division, but explicit casting is sometimes safer in complex scenarios.
gc_ratio = gc_bases / total_length

# 6. Convert the ratio (0.0 to 1.0) to a percentage (0.0% to 100.0%)
gc_percentage = gc_ratio * 100

# 7. Output the analysis report
print(f"--- Sequence Analysis Report ---")
print(f"Sequence: {dna_sequence}")
print(f"Total Length: {total_length} bases")
print(f"Guanine Count (G): {g_count}")
print(f"Cytosine Count (C): {c_count}")
print(f"Total GC Bases: {gc_bases}")
# Use f-string formatting to display the percentage rounded to two decimal places
print(f"GC Content Percentage: {gc_percentage:.2f}%")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

genomic_dna = "ATGCCTATTCGAGTTAGCATGCCGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACG"

# Coordinates are 0-based, [start, end]
exon_coordinates = [
    (4, 10),    # Exon 1: indices 4 through 9 (length 6)
    (25, 35),   # Exon 2: indices 25 through 34 (length 10)
    (60, 70)    # Exon 3: indices 60 through 69 (length 10)
]

# 1. Splicing Simulation
mature_dna = ""
for start, end in exon_coordinates:
    # Python slicing [start:end] naturally handles the 0-based, exclusive end index
    exon = genomic_dna[start:end]
    mature_dna += exon

# 2. Transcription (DNA -> mRNA: T -> U)
mature_mRNA = mature_dna.replace('T', 'U')

# 3. Final Analysis (GC Content)
total_length = len(mature_mRNA)
g_count = mature_mRNA.count('G')
c_count = mature_mRNA.count('C')
gc_count = g_count + c_count

if total_length > 0:
    gc_percentage = (gc_count / total_length) * 100
else:
    gc_percentage = 0.0

print(f"Length of Mature DNA/mRNA: {total_length} bases")
print(f"Mature mRNA Sequence: {mature_mRNA}")
print(f"mRNA GC Content: {gc_percentage:.2f}%")

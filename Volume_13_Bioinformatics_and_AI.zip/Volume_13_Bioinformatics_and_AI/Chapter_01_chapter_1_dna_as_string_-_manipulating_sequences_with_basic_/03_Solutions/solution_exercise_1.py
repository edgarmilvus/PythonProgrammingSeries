
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

dna_sequence_raw = "GATTACA_TTAAGGCCTAGNNNNACGTACGTACGTACGTACGTACGTACGTACGTACG"
valid_bases = "ATCG"

# 1. Sequence Cleaning: Iterate and filter for valid bases (A, T, C, G)
cleaned_dna = ""
for base in dna_sequence_raw.upper():
    if base in valid_bases:
        cleaned_dna += base

# 2. Length Calculation
total_length = len(cleaned_dna)

# 3. GC Content Calculation
g_count = cleaned_dna.count('G')
c_count = cleaned_dna.count('C')
gc_count = g_count + c_count

# Calculate percentage safely
if total_length > 0:
    gc_percentage = (gc_count / total_length) * 100
else:
    gc_percentage = 0.0

# 4. Output Formatting
print(f"Original Sequence Length: {len(dna_sequence_raw)}")
print(f"Cleaned Sequence Length: {total_length}")
print(f"Guanine Count: {g_count}, Cytosine Count: {c_count}")
print(f"GC Content Percentage: {gc_percentage:.2f}%")

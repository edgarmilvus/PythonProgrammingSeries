
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

ambiguous_dna = "5'-GATCRYSWNNTAG-3'"

# 1. Define the comprehensive complement map for IUPAC codes
complement_map = {
    'A': 'T', 'T': 'A', 'C': 'G', 'G': 'C',
    'R': 'Y', 'Y': 'R', 'S': 'S', 'W': 'W', 'N': 'N'
}

# 2. Clean and Uppercase the sequence
# We use string methods to strip known non-base characters and ensure consistency
cleaned_seq = ambiguous_dna.strip("5'-3'").upper()

# 3. Reverse the cleaned sequence using extended slicing
reversed_seq = cleaned_seq[::-1]

# 4. Complement the reversed sequence
reverse_complement = ""
for base in reversed_seq:
    # Look up the complement; if the base is not in the map, we assume it's an error
    # but for robustness, we use .get() which defaults to the original base if missing.
    complement_base = complement_map.get(base, base)
    reverse_complement += complement_base

print(f"Original: {ambiguous_dna}")
print(f"Cleaned:  {cleaned_seq}")
print(f"Reverse Complement: {reverse_complement}")

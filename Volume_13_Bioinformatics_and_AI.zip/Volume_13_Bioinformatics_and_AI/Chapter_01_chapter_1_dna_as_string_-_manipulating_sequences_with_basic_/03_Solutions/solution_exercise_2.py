
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

sequence = "ATGGCCAAGTTTGCCTAGTAAG"

def extract_codons(seq, start_index):
    """
    Extracts codons from a sequence starting at a specified index.
    Uses slicing within a loop to handle the triplet grouping.
    """
    codons = []
    # Iterate using a step of 3, starting from the specified index
    for i in range(start_index, len(seq), 3):
        codon = seq[i:i+3] # Slice extracts 3 characters, handling remainders gracefully
        codons.append(codon)
    return codons

# Frame 1: Starting at index 0
frame_1_codons = extract_codons(sequence, 0)

# Frame 2: Starting at index 1
frame_2_codons = extract_codons(sequence, 1)

# Frame 3: Starting at index 2
frame_3_codons = extract_codons(sequence, 2)

print(f"Input Sequence: {sequence} (Length: {len(sequence)})")
print("-" * 30)
print(f"Frame 1 (Index 0): {frame_1_codons}")
print(f"Frame 2 (Index 1): {frame_2_codons}")
print(f"Frame 3 (Index 2): {frame_3_codons}")

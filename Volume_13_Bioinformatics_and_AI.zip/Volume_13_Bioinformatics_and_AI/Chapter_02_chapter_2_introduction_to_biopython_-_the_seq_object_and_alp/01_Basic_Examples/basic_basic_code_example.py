
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

from Bio.Seq import Seq
from Bio.Data import CodonTable
# Note: While explicit alphabet imports are often optional in recent Biopython versions,
# we include them here to demonstrate the critical concept of sequence validation.
from Bio.Alphabet import IUPAC 

# --- 1. Define the Raw Data ---
# A DNA coding strand (5' to 3' orientation) containing a start codon (ATG) 
# and a stop codon (TAG)
dna_sequence_str = "ATGGCCATTGTAATGGGCCGCTGAAAGGGTGCCCGATAG"

# --- 2. Initialize the Seq Object with Context ---
# We wrap the string in the Seq object and explicitly assign the 
# unambiguous DNA alphabet to ensure data integrity.
coding_dna = Seq(dna_sequence_str, IUPAC.unambiguous_dna)
print("--- Initialization & Validation ---")
print(f"Original DNA Sequence (5'->3'): {coding_dna}")
print(f"Sequence Type/Class: {type(coding_dna)}")
print(f"Assigned Alphabet: {coding_dna.alphabet}")
print(f"Sequence Length: {len(coding_dna)}\n")

# --- 3. Basic String Operations (Slicing and Concatenation) ---

# Slicing: Extract the first three bases (the start codon)
start_codon = coding_dna[0:3]
print("--- Slicing ---")
print(f"Extracted Start Codon: {start_codon}")
print(f"Start Codon Alphabet Check: {start_codon.alphabet}\n")

# Concatenation: Add a short, artificial sequence fragment
extension_fragment = Seq("GATTACA", IUPAC.unambiguous_dna)
extended_dna = coding_dna + extension_fragment
print("--- Concatenation ---")
print(f"Extension Fragment: {extension_fragment}")
print(f"Extended DNA Sequence: {extended_dna}")
print(f"Extended Length: {len(extended_dna)}\n")

# --- 4. Biological Transformations ---

# Reverse Complement: Calculate the sequence of the template strand
# Biopython automatically handles the base pairing (A<->T, C<->G) and the 
# 5'->3' orientation flip.
template_dna = coding_dna.reverse_complement()
print("--- Reverse Complement ---")
print(f"Template DNA (Reverse Complement): {template_dna}\n")

# Transcription: Convert DNA (T) to RNA (U)
messenger_rna = coding_dna.transcribe()
print("--- Transcription ---")
print(f"Messenger RNA (Transcription): {messenger_rna}")
print(f"RNA Alphabet Check: {messenger_rna.alphabet}\n")

# Translation: Convert mRNA/DNA to Protein
# We specify table=1 (Standard Code) and request termination at the first stop codon (to_stop=True).
protein_sequence = coding_dna.translate(table=1, stop_symbol="*", to_stop=True)
print("--- Translation ---")
print(f"Protein Sequence: {protein_sequence}")
print(f"Protein Alphabet Check: {protein_sequence.alphabet}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import time
import os
import io
from Bio import SeqIO
from Bio.SeqRecord import SeqRecord
from Bio.Seq import Seq

# --- Simulation Setup: Create a larger mock file for timing ---
# Simulate a file with 1000 records
LARGE_FASTA_CONTENT = ""
for i in range(1, 1001):
    LARGE_FASTA_CONTENT += f">gi|{i}|ref|NC_000001.{i}| Sequence {i}\n"
    LARGE_FASTA_CONTENT += "ATGC" * 100 + "\n" # 400 bases per sequence

large_filepath = "large_dataset.fasta"
with open(large_filepath, 'w') as f:
    f.write(LARGE_FASTA_CONTENT)

# Re-use fasta_generator from Exercise 1 (assumed available)
def fasta_generator(filepath):
    # (Implementation from Ex 1 would be here)
    header = None
    sequence_lines = []
    with open(filepath, 'r') as f:
        for line in f:
            line = line.strip()
            if not line: continue
            if line.startswith('>'):
                if header is not None: yield header, "".join(sequence_lines)
                header = line[1:]
                sequence_lines = []
            else:
                sequence_lines.append(line)
        if header is not None: yield header, "".join(sequence_lines)

# --- Timing Comparison ---
print("--- Performance Comparison (1000 Records) ---")

# Method A: Manual Generator Timing
start_time_manual = time.perf_counter()
count_manual = 0
for header, sequence in fasta_generator(large_filepath):
    count_manual += 1
end_time_manual = time.perf_counter()
time_manual = end_time_manual - start_time_manual
print(f"Method A (Manual Generator): Records counted: {count_manual}. Time: {time_manual:.4f} seconds.")

# Method B: Biopython SeqIO.parse Timing
start_time_biopython = time.perf_counter()
count_biopython = 0
for record in SeqIO.parse(large_filepath, "fasta"):
    count_biopython += 1
end_time_biopython = time.perf_counter()
time_biopython = end_time_biopython - start_time_biopython
print(f"Method B (Biopython SeqIO.parse): Records counted: {count_biopython}. Time: {time_biopython:.4f} seconds.")

print(f"\nBiopython is approximately {time_manual/time_biopython:.2f} times faster than the manual generator.")

# --- Indexed Retrieval Implementation ---

def get_sequence_by_id(index_map, sequence_id):
    """Retrieves a SeqRecord sequence string using a Biopython index map."""
    try:
        # Index lookup is O(1)
        record = index_map[sequence_id]
        return str(record.seq)
    except KeyError:
        # Graceful handling for non-existent ID (POLA)
        return None

# 1. Create the index map
index_map = SeqIO.index(large_filepath, "fasta")

# 2. Test retrieval with an existing ID
existing_id = 'gi|500|ref|NC_000001.500|'
seq_data = get_sequence_by_id(index_map, existing_id)
print(f"\n--- Indexed Retrieval Test ---")
print(f"Query ID: {existing_id}")
print(f"Retrieved sequence length: {len(seq_data)}" if seq_data else "ID not found.")

# 3. Test retrieval with a non-existent ID
non_existent_id = 'gi|99999|ref|NC_000001.99999|'
seq_data_none = get_sequence_by_id(index_map, non_existent_id)
print(f"Query ID: {non_existent_id}")
print(f"Retrieved sequence: {seq_data_none}")

# Clean up the simulated file
os.remove(large_filepath)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio.SeqFeature import SeqFeature, FeatureLocation, ExactPosition
import json

# --- Simulation Setup: Create a mock SeqRecord with CDS features ---
mock_seq = Seq("ATGC" * 1000)
mock_record = SeqRecord(mock_seq, id="NC_000913", name="E_coli")

# Feature 1: Standard CDS (100-500)
loc1 = FeatureLocation(ExactPosition(100), ExactPosition(500), strand=1)
feat1 = SeqFeature(loc1, type="CDS", qualifiers={
    'locus_tag': ['b0001'],
    'product': ['thrL leader peptide'],
    'translation': ['MKTILLR'],
    'note': ['highly conserved leader sequence']
})

# Feature 2: Another CDS, missing the 'note' qualifier (501-2000)
loc2 = FeatureLocation(ExactPosition(501), ExactPosition(2000), strand=1)
feat2 = SeqFeature(loc2, type="CDS", qualifiers={
    'locus_tag': ['b0002'],
    'product': ['threonine operon attenuator'],
    'translation': ['MKTALLRLLLLGLL'],
})

# Feature 3: Non-CDS feature (will be ignored)
loc3 = FeatureLocation(ExactPosition(0), ExactPosition(4000), strand=1)
feat3 = SeqFeature(loc3, type="source")

mock_record.features.extend([feat1, feat2, feat3])
# --- End Simulation Setup ---


def extract_cds_features(seq_record):
    """
    Extracts structured data from CDS features in a SeqRecord.
    """
    structured_output = []

    for feature in seq_record.features:
        if feature.type == 'CDS':
            # Qualifiers are stored as lists; use .get() for safe access.
            qualifiers = feature.qualifiers
            
            locus_tag = qualifiers.get('locus_tag', ['N/A'])[0]
            product_name = qualifiers.get('product', ['unknown product'])[0]
            translation = qualifiers.get('translation', [''])[0]
            notes = qualifiers.get('note', [''])[0] 

            # Location Parsing: Biopython locations are 0-based, half-open [start, end)
            # We focus on the start/end of the primary location segment.
            start_pos = int(feature.location.start)
            end_pos = int(feature.location.end)

            # Structured Output Generation
            record_dict = {
                "locus_tag": locus_tag,
                "product_name": product_name,
                "start_pos": start_pos,
                "end_pos": end_pos,
                "translation_length": len(translation),
                "notes": notes
            }
            structured_output.append(record_dict)
            
    return structured_output

# Run the extraction
cds_data = extract_cds_features(mock_record)

print("--- GenBank CDS Structured Output ---")
print(json.dumps(cds_data, indent=4))

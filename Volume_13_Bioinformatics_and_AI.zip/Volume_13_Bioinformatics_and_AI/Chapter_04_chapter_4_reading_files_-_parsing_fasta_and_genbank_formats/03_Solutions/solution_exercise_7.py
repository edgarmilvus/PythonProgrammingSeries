
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_7.py
# Description: Solution for Exercise 7
# ==========================================

# 1. Custom Exception Definition
class BioParserError(Exception):
    """Base class for all custom parsing errors."""
    pass

class FileFormatError(BioParserError):
    """Raised when the file structure is fundamentally incorrect (e.g., missing delimiters, wrong format type)."""
    pass

class DataIntegrityError(BioParserError):
    """Raised when the data content is inconsistent or corrupted (e.g., out-of-bounds feature location, non-IUPAC bases)."""
    pass

# 2. Interface Design (Pseudocode/Docstring)
def load_records(filepath: str, format_type: str) -> list:
    """
    Loads biological records from a file using Biopython SeqIO.

    :param filepath: Path to the input file.
    :param format_type: 'fasta' or 'genbank'.
    :return: List of SeqRecord objects.
    
    # Define behavior for the following scenarios (POLA adherence):
    
    # 1. File Not Found:
    #    - Action: Raise the standard Python exception.
    #    - Exception: FileNotFoundError
    
    # 2. Mismatched Format Type (e.g., parsing GenBank as FASTA):
    #    - Action: Attempting to parse fails due to unexpected structure.
    #    - Exception: FileFormatError (Custom exception)
    
    # 3. Data Integrity Issue (e.g., out-of-bounds feature location):
    #    - Action: Biopython raises an internal error (e.g., ValueError/IndexError) upon feature extraction.
    #    - Exception: DataIntegrityError (Custom exception, catching and wrapping the internal error)
    """
    # try:
    #     records = list(SeqIO.parse(filepath, format_type))
    # except FileNotFoundError:
    #     # Scenario 1 handled by the OS/Python I/O layer
    #     raise
    # except ValueError as e:
    #     # Catch Biopython's internal errors (often ValueError for parsing issues)
    #     if "format" in str(e).lower() or "malformed" in str(e).lower():
    #         # Scenario 2: Structure is wrong for the specified format
    #         raise FileFormatError(f"File {filepath} could not be parsed as {format_type}. Check file structure.")
    #     elif "out of bounds" in str(e).lower() or "non-IUPAC" in str(e).lower():
    #         # Scenario 3: Data within a valid structure is inconsistent
    #         raise DataIntegrityError(f"Data integrity violation found in {filepath}: {e}")
    #     else:
    #         raise BioParserError(f"An unexpected error occurred during parsing: {e}")
    # return records
    pass # Placeholder for actual implementation

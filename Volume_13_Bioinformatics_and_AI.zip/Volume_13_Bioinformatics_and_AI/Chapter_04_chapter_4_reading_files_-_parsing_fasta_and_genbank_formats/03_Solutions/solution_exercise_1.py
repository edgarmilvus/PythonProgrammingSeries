
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import io
import os

# --- Simulation Setup: Create a mock file for testing ---
# In a real environment, this content would be read from a file path.
FASTA_CONTENT = """
>seq1 Gene X chromosome 1
ATGCATGCATGCATGC
TGCATGCATGCATGC
>seq2 Gene Y chromosome 2
AAAAA
>seq3 Gene Z chromosome 3
GATTACA
GATTACA
GATTACA
"""

def fasta_generator(filepath):
    """
    A memory-efficient generator for parsing FASTA files.
    Yields (header, sequence) tuples one record at a time.
    """
    header = None
    sequence_lines = []

    # Use 'with' for safe file handling
    try:
        with open(filepath, 'r') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue  # Skip empty lines

                if line.startswith('>'):
                    # If we have a sequence buffered, yield the previous record
                    if header is not None:
                        yield header, "".join(sequence_lines)

                    # Start new record
                    header = line[1:]
                    sequence_lines = []
                else:
                    # Append sequence data, ensuring no whitespace remains
                    sequence_lines.append(line)

            # After the loop finishes, yield the last buffered record
            if header is not None:
                yield header, "".join(sequence_lines)
    
    except FileNotFoundError:
        # Handle case where file doesn't exist (though POLA focuses on empty file)
        # For simplicity in this generator, we let the generator yield nothing.
        return # Gracefully exit if file not found

# --- Demonstration and Testing ---
# Simulate writing the content to a temporary file
test_filepath = "test_sequences.fasta"
with open(test_filepath, 'w') as f:
    f.write(FASTA_CONTENT)

print("--- Testing FASTA Generator ---")
count = 0
for header, sequence in fasta_generator(test_filepath):
    if count < 10:
        print(f"ID: {header[:20]}... Length: {len(sequence)}")
        count += 1
    
# Clean up the simulated file
os.remove(test_filepath)

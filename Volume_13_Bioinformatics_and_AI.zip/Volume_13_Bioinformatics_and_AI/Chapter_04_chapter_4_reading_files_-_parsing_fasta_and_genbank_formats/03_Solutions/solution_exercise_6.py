
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_6.py
# Description: Solution for Exercise 6
# ==========================================

from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio.SeqFeature import SeqFeature, FeatureLocation, ExactPosition
from Bio.Data import CodonTable

# --- Simulation Setup: Mock SeqRecord with positive and negative strand features ---
# Sequence is 99 bases long (33 codons)
MOCK_SEQ_STR = "ATGGCCAATCAGTGA" + "ATGC" * 21 + "TTA" # 99 bases total

mock_seq = Seq(MOCK_SEQ_STR)
mock_record = SeqRecord(mock_seq, id="NC_000913")

# Feature A: Positive Strand (1-15, 5 codons)
# Translation: M A N Q *
locA = FeatureLocation(ExactPosition(0), ExactPosition(15), strand=1)
featA = SeqFeature(locA, type="CDS", qualifiers={
    'locus_tag': ['geneA'],
    'translation': ['MANQ'] # GenBank often omits the terminal stop codon
})

# Feature B: Negative Strand (99-85, 5 codons, reverse complement)
# Sequence: TTA... (99-85) -> AAT... (RC)
# RC sequence: TCAGATTGGCCAT
# Translation: S D W P I
locB = FeatureLocation(ExactPosition(84), ExactPosition(99), strand=-1)
featB = SeqFeature(locB, type="CDS", qualifiers={
    'locus_tag': ['geneB'],
    'translation': ['SDWPI'] 
})

mock_record.features.extend([featA, featB])
# --- End Simulation Setup ---

def verify_translation(seq_record):
    """
    Performs in-silico translation verification for all CDS features.
    """
    verification_report = []
    
    # Standard Bacterial Code (Table 11) is common for E. coli
    # We use 'to_stop=True' to handle the terminal stop codon consistency.
    translation_table = 11 

    for feature in seq_record.features:
        if feature.type == 'CDS':
            locus_tag = feature.qualifiers.get('locus_tag', ['N/A'])[0]
            
            # 1. Sequence Slicing and Strand Handling:
            # feature.extract() automatically handles slicing, strand, and location complexity.
            nuc_seq = feature.extract(seq_record.seq)
            
            # 2. In-Silico Translation: Translate the extracted nucleotide sequence
            # We use `to_stop=True` to ensure the translation stops at the first stop codon,
            # mimicking how GenBank translation qualifiers are typically written (without the final *).
            calculated_translation_obj = nuc_seq.translate(table=translation_table, to_stop=True)
            calculated_translation = str(calculated_translation_obj)

            # Get GenBank provided translation
            genbank_translation = feature.qualifiers.get('translation', [''])[0]
            
            # 3. Verification and Reporting
            match = (calculated_translation == genbank_translation)
            
            report_entry = {
                "locus_tag": locus_tag,
                "genbank_translation": genbank_translation,
                "calculated_translation": calculated_translation,
                "translation_match": match,
                "strand": feature.location.strand
            }
            verification_report.append(report_entry)
            
    return verification_report

# Run the verification
report = verify_translation(mock_record)

print("--- Translation Verification Report ---")
import json
print(json.dumps(report, indent=4))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import os
from typing import Dict, List

# --- 1. Setup: Define and create a dummy FASTA file ---

# Simulate typical FASTA content: headers followed by wrapped sequences
FASTA_CONTENT = """
>seq_001_Human_HBB Beta-globin chain (HBB)
ATGG
TGCAT
GCTGCA
A
>seq_002_E_coli_rRNA 16S Ribosomal RNA fragment
ACGTACGT
ACGTACGTACGT
ACGT
"""

FILENAME = "test_data.fasta"

# Write the content to a file so the function can read it
try:
    with open(FILENAME, 'w') as f:
        # We strip the content to avoid extra blank lines at the start/end
        f.write(FASTA_CONTENT.strip())
except IOError as e:
    print(f"Error writing file: {e}")
    exit()

# --- 2. Core Parsing Function ---

def parse_simple_fasta(filepath: str) -> Dict[str, str]:
    """
    Manually parses a basic FASTA file.

    Returns:
        A dictionary mapping clean sequence identifiers (str) to
        their concatenated sequences (str).
    """
    sequences: Dict[str, str] = {}
    current_header: str = ""
    current_sequence_lines: List[str] = []

    try:
        # Open the file for reading
        with open(filepath, 'r') as file:
            for line in file:
                # Preprocess: Remove leading/trailing whitespace and the newline character
                line = line.strip()

                # Skip blank lines that might exist between entries
                if not line:
                    continue

                # State Check 1: Is this a header line?
                if line.startswith('>'):
                    # State Transition Logic: If we were already processing a sequence,
                    # it means we hit the end of the previous entry.
                    if current_header and current_sequence_lines:
                        # 1a. Store the completed sequence
                        sequences[current_header] = "".join(current_sequence_lines)

                    # 1b. Start the new entry
                    # Extract the ID: remove the '>' and take only the first word
                    # maxsplit=1 ensures we only split once, even if the description has spaces
                    current_header = line[1:].split(maxsplit=1)[0]
                    current_sequence_lines = [] # Reset accumulator for the new sequence

                # State Check 2: Must be a sequence line
                else:
                    # Accumulate the sequence fragment
                    current_sequence_lines.append(line)

        # CRITICAL STEP: Handle the last sequence in the file.
        # The loop ends before the last sequence is stored, so we must store it now.
        if current_header and current_sequence_lines:
            sequences[current_header] = "".join(current_sequence_lines)

        return sequences

    except FileNotFoundError:
        print(f"Error: The file {filepath} was not found.")
        return {}
    finally:
        # Cleanup: Remove the temporary file after processing
        if os.path.exists(FILENAME):
            os.remove(FILENAME)


# --- 3. Execution and Output ---
print(f"Attempting to parse: {FILENAME}")
parsed_data = parse_simple_fasta(FILENAME)

if parsed_data:
    print("-" * 40)
    print(f"Successfully parsed {len(parsed_data)} sequences.")
    for identifier, sequence in parsed_data.items():
        print(f"\n[ID]: {identifier}")
        print(f"[Length]: {len(sequence)} bases")
        print(f"[Sequence Snippet]: {sequence[:10]}...{sequence[-10:]}")
    print("-" * 40)

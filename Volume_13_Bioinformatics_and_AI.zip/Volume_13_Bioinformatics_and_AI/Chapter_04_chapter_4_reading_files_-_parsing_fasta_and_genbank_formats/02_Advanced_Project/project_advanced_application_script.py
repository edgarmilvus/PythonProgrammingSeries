
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import io
from Bio import SeqIO
from Bio.Seq import Seq
from typing import Dict, List, Optional

# --- 1. Setup: Simulated Input Data ---
# In a real scenario, these are read from physical files (e.g., 'spike_protein.gb', 'variant_pool.fasta')

# Simulated GenBank file content (simplified structure for demonstration)
GENBANK_CONTENT = """
LOCUS       NC_045512              29903 bp    ss-RNA     linear   VRL 01-FEB-2023
DEFINITION  Severe acute respiratory syndrome coronavirus 2 isolate Wuhan-Hu-1, complete genome.
SOURCE      SARS-CoV-2
  ORGANISM  Severe acute respiratory syndrome coronavirus 2
            Viruses; Riboviria; Orthornavirae; Pisuviricota; Pisoniviricetes;
            Nidovirales; Cornidovirineae; Coronaviridae; Orthocoronavirinae;
            Betacoronavirus; Sarbecovirus.
FEATURES             Location/Qualifiers
     source          1..29903
                     /organism="Severe acute respiratory syndrome coronavirus 2"
                     /mol_type="genomic RNA"
     CDS             21563..25384
                     /gene="S"
                     /product="spike glycoprotein"
                     /codon_start=1
                     /transl_table=1
                     /translation="MFVFLVLLPLVSSQCVNLTTRTQLPPAYTNSFTRGVYYPDKVFRSSVLH
                     LYQPSNVFRFAHDASVRDPYNS..."
//
"""

# Simulated FASTA file content (variants of the spike protein gene)
FASTA_CONTENT = """>Variant_A|Wuhan-Hu-1|Reference
ATGTTTGTTTTTCTTGTTTTATTGCCACTAGTCTCTAGTCAGTGTGTTAATCTTACAACC...
>Variant_B|Delta|Mutation_P681R
ATGTTTGTTTTTCTTGTTTTATTGCCACTAGTCTCTAGTCAGTGTGTTAATCTTACAACC...
>Variant_C|HCoV-229E|Non_Target_Virus
ATGGCAACTAATTTTGCAGTTGTTAATTTAACTAATTTCAATTTTAATTTCAATTTTAAT...
"""

# --- 2. Core Function 1: GenBank Feature Extraction ---

def extract_genbank_data(gb_handle: io.StringIO, target_product: str) -> Optional[Dict]:
    """
    Parses a GenBank file to find a specific feature (CDS) and extract its
    metadata, sequence, and translation.
    """
    # Use SeqIO.read() since we expect only one full genome record per file.
    try:
        record = SeqIO.read(gb_handle, "genbank")
    except ValueError:
        print("Error: GenBank file contained multiple records or was empty.")
        return None

    organism = record.annotations.get('organism', 'Unknown Organism')
    accession = record.id

    # Iterate through all features defined in the GenBank record
    for feature in record.features:
        if feature.type == "CDS":
            # Check if the product qualifier matches the target
            product_list = feature.qualifiers.get('product')
            if product_list and product_list[0] == target_product:
                
                # Extract the nucleotide sequence using the feature location object
                cds_seq_nt = feature.extract(record.seq)
                
                # Biopython stores qualifiers as lists of strings
                translation = feature.qualifiers.get('translation', [''])[0]
                
                return {
                    "accession": accession,
                    "organism": organism,
                    "gene_name": feature.qualifiers.get('gene', ['N/A'])[0],
                    "product_name": target_product,
                    "nt_sequence": str(cds_seq_nt),
                    "aa_translation": translation,
                    "location": str(feature.location)
                }
    
    return None

# --- 3. Core Function 2: FASTA Annotation and Filtering ---

def process_variant_fasta(fasta_handle: io.StringIO, gb_metadata: Dict) -> List[SeqIO.SeqRecord]:
    """
    Parses a FASTA file, filters sequences based on organism match derived from 
    GenBank data, and annotates the ID for downstream use.
    """
    filtered_records = []
    
    # Use SeqIO.parse() for memory-efficient iteration over potentially many variants
    for record in SeqIO.parse(fasta_handle, "fasta"):
        # The FASTA ID is assumed to contain the organism name (e.g., Variant_B|Delta|Mutation)
        
        # Simple check: Does the description contain the target organism/virus name?
        # This is a robust way to filter sequences that might belong to non-target viruses.
        if gb_metadata['organism'] in record.description:
            
            # 1. Create a new, standardized ID based on the GenBank context
            new_id = (f"{gb_metadata['accession']}|{gb_metadata['gene_name']}|"
                      f"{record.id.split('|')[1]}") # Use variant name (Delta, etc.)
            
            # 2. Update the record for the output list
            record.id = new_id
            record.description = f"Annotated {gb_metadata['product_name']} variant: {record.description}"
            
            # Optional: Verify translation length consistency (a quality control step)
            if len(record.seq.translate(table=gb_metadata['transl_table'])) < 10:
                 # In a real script, we would log this error and skip, but here we proceed
                 pass
            
            filtered_records.append(record)
        else:
            print(f"Skipping non-target sequence: {record.id} (Organism mismatch)")
            
    return filtered_records

# --- 4. Main Execution Block ---

if __name__ == "__main__":
    
    # Simulate reading the file contents into in-memory handles
    gb_handle = io.StringIO(GENBANK_CONTENT)
    fasta_handle = io.StringIO(FASTA_CONTENT)
    
    TARGET_PRODUCT = "spike glycoprotein"
    
    print(f"--- Stage 1: Parsing GenBank for Canonical {TARGET_PRODUCT} ---")
    
    # A. Extract canonical sequence and metadata from GenBank
    canonical_data = extract_genbank_data(gb_handle, TARGET_PRODUCT)
    
    if canonical_data:
        print(f"Successfully extracted data for {canonical_data['product_name']} from {canonical_data['organism']}.")
        print(f"Canonical Protein Length: {len(canonical_data['aa_translation'])} amino acids.")
        
        # Add translation table for use in the FASTA processing function
        canonical_data['transl_table'] = 1 
        
        print("\n--- Stage 2: Filtering and Annotating FASTA Variants ---")
        
        # B. Process the variant FASTA file using the extracted metadata
        annotated_variants = process_variant_fasta(fasta_handle, canonical_data)
        
        print(f"\n--- Stage 3: Final Report Generation ---")
        print(f"Found {len(annotated_variants)} relevant variants.")
        
        # C. Write the filtered, annotated sequences to a new output file (simulated)
        output_handle = io.StringIO()
        SeqIO.write(annotated_variants, output_handle, "fasta")
        
        print("\n--- Final Filtered FASTA Output (First Record) ---")
        print(output_handle.getvalue().split('\n')[0])
        print(output_handle.getvalue().split('\n')[1][:60] + "...")
        print(f"\nReport saved to output.fasta (simulated).")
    else:
        print(f"Critical Error: Could not find target product '{TARGET_PRODUCT}' in GenBank record.")



#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
from collections import Counter
from Bio import AlignIO
from Bio.Align import MultipleSeqAlignment
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord

# --- 1. Setup and Simulation ---

def create_simulated_clustal_file(filename="kinase_alignment.aln"):
    """
    Creates a simulated ClustalW output file for testing.
    This structure is mandatory for Bio.AlignIO parsing.
    """
    clustal_data = """
CLUSTAL O(1.2.4) multiple sequence alignment

Seq_Kinase_A    G A L V Q E P S N K L A N M L V Q A E D S - - - - - - - - - - - - - - - - - - - - -
Seq_Kinase_B    G A L I Q E P S N K L A N M L V Q A E D S - - - - - - - - - - - - - - - - - - - - -
Seq_Kinase_C    G A L V Q E P S N K L A N M L V Q A E D S - - - - - - - - - - - - - - - - - - - - -
Seq_Kinase_D    G A L V Q E P S N K L A N M L V Q A E D S P K T R L P S S T A P L P L A P T G G G
Seq_Kinase_E    G A L V Q E P S N K L A N M L V Q A E D S P K T R L P S S T A P L P L A P T G G G
Seq_Kinase_F    G A L V Q E P S N K L A N M L V Q A E D S P K T R L P S S T A P L P L A P T G G G
                                                                                                    
Seq_Kinase_A    - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Seq_Kinase_B    - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Seq_Kinase_C    - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Seq_Kinase_D    Y R A F D S A E G R G G S F G V Y E G R E G V W L V A L N C H S I P Q E A F R S
Seq_Kinase_E    Y R A F D S A E G R G G S F G V Y E G R E G V W L V A L N C H S I P Q E A F R S
Seq_Kinase_F    F R A F D S A E G R G G S F G V Y E G R E G V W L V A L N C H S I P Q E A F R S
    """
    with open(filename, "w") as handle:
        handle.write(clustal_data.strip())
    return filename

# --- 2. Core Conservation Logic ---

def calculate_conservation_score(column_string: str) -> float:
    """
    Calculates a conservation score (0.0 to 1.0) for a single alignment column.
    Score is based on the frequency of the most common non-gap residue.
    """
    
    # Filter out gap characters ('-')
    non_gap_residues = [res for res in column_string if res != '-']
    
    if not non_gap_residues:
        return 0.0 # Fully gapped column
    
    # Count occurrences of each residue
    counts = Counter(non_gap_residues)
    
    # Find the count of the most frequent residue
    max_count = counts.most_common(1)[0][1]
    
    # Conservation score is the max count divided by the total number of non-gap residues
    score = max_count / len(non_gap_residues)
    return score

# --- 3. Alignment Analysis and Filtering ---

def analyze_alignment_conservation(alignment_file: str, format_name: str, threshold_high: float = 0.95, threshold_low: float = 0.5):
    """
    Parses the alignment, calculates conservation scores per column, and identifies
    highly conserved and highly variable positions.
    """
    try:
        # Use AlignIO to parse the ClustalW output
        alignment = AlignIO.read(alignment_file, format_name)
    except FileNotFoundError:
        print(f"Error: File {alignment_file} not found.")
        return

    num_cols = alignment.get_alignment_length()
    conservation_scores = []
    
    # Iterate through the alignment column by column
    for i in range(num_cols):
        # Slicing the alignment object extracts the column (Extended Slicing concept)
        column = alignment[:, i]
        score = calculate_conservation_score(column)
        conservation_scores.append(score)

    # Identify indices based on thresholds
    conserved_indices = [i for i, score in enumerate(conservation_scores) if score >= threshold_high]
    variable_indices = [i for i, score in enumerate(conservation_scores) if score <= threshold_low and score > 0.0]

    # Generate a consensus sequence focusing ONLY on conserved positions
    # We use the first sequence as a reference to extract the actual residue
    # at the conserved index, ignoring gaps if possible.
    
    consensus_seq_list = []
    for i in conserved_indices:
        # Get the residue that defined the high conservation score
        column = alignment[:, i]
        counts = Counter([res for res in column if res != '-'])
        if counts:
            most_common_residue = counts.most_common(1)[0][0]
            consensus_seq_list.append(most_common_residue)
        else:
            consensus_seq_list.append('X') # Should not happen if score > 0

    consensus_sequence = "".join(consensus_seq_list)
    
    # --- 4. Reporting Results ---
    
    print(f"\n--- Alignment Analysis Report ---")
    print(f"Total Sequences Aligned: {len(alignment)}")
    print(f"Alignment Length (Columns): {num_cols}")
    print(f"High Conservation Threshold: >{threshold_high:.2f}")
    print(f"Low Conservation Threshold: <{threshold_low:.2f}")
    print("-" * 40)
    
    print("\n[A] Highly Conserved Positions (Potential Active Sites):")
    # Note: We display 1-based indexing for biological relevance
    print(f"Count: {len(conserved_indices)}")
    print("Positions (1-based):", [i + 1 for i in conserved_indices])
    
    print("\n[B] Highly Variable Positions (Potential Loop Regions):")
    print(f"Count: {len(variable_indices)}")
    print("Positions (1-based):", [i + 1 for i in variable_indices])

    print("\n[C] Conserved Consensus Sequence:")
    print(f"Length: {len(consensus_sequence)}")
    print(consensus_sequence)
    print("-" * 40)
    
    # Example: Detail the score distribution
    print("\nSample Score Distribution (Position: Score):")
    sample_points = [1, 5, 20, 30, 45, 60, 70]
    for p in sample_points:
        if p <= num_cols:
            print(f"Pos {p}: {conservation_scores[p-1]:.3f}")


# --- 5. Execution ---

if __name__ == "__main__":
    
    INPUT_FILE = "kinase_alignment.aln"
    
    # 1. Create the input file
    simulated_file = create_simulated_clustal_file(INPUT_FILE)
    
    # 2. Run the analysis
    analyze_alignment_conservation(simulated_file, "clustal")
    
    # 3. Clean up the simulated file
    os.remove(INPUT_FILE)

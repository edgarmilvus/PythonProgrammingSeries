
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from Bio import AlignIO
from io import StringIO

# Simulated ClustalW output content for testing
CLUSTAL_DATA = """
CLUSTAL W (1.83) multiple sequence alignment


Seq1            M-T-LALDVAG-K-T-T-T-
Seq2            M-T-LALDVAG-K-T-T-T-
Seq3            M-T-LALDVAG-R-T-W-T-
Seq4            V-T-LALDVAG-K-T-T-T-
                *:***:****** * * *
"""

try:
    # 1. Alignment Loading (using StringIO to simulate file read)
    handle = StringIO(CLUSTAL_DATA)
    alignment = AlignIO.read(handle, "clustal")
    
    # 2. Sequence Count
    sequence_count = len(alignment)
    
    # 3. Aligned Length
    aligned_length = alignment.get_alignment_length()
    
    # 4. Identifier Extraction
    sequence_ids = [record.id for record in alignment]
    
    # 5. Gap Analysis
    total_gaps = 0
    for record in alignment:
        total_gaps += str(record.seq).count('-')

    print("--- Alignment Metadata Report ---")
    print(f"1. Total Number of Sequences: {sequence_count}")
    print(f"2. Total Aligned Length (including gaps): {aligned_length}")
    print("   (Crucial because it defines the common coordinate system for comparison.)")
    print(f"3. Sequence Identifiers: {sequence_ids}")
    print(f"4. Total Gap Characters Across All Sequences: {total_gaps}")

except Exception as e:
    print(f"An error occurred during processing: {e}")

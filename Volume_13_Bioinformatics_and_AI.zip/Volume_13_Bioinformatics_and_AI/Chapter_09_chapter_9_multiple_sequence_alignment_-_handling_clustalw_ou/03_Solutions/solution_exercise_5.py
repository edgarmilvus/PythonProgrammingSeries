
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio.Align import MultipleSeqAlignment
from collections import Counter

# --- Setup: Mock Alignment Object ---
Ref_ID = "Ref_Protein_X"
# Alignment length: 50. Position 42 (index 41) has 'G' in Ref_Protein_X.
REF_SEQ = "MAFTLAKVAGKKTTTTVVVVVVVVVVMAFTLAKVAGKKTTTTG-W-W-W-W"
SEQ_A =   "MAFTLAKVAGKKTTTTVVVVVVVVVVMAFTLAKVAGKKTTTTA-W-W-W-W" # 98% PI
SEQ_D =   "NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN" # PI ~ 0% (<55%)
SEQ_E =   "MAFTLAKVAGKKTTTTVVVVVVVVVVMAFTLAKVAGKKTTTTV-W-W-W-W" # W at pos 42

msa_alignment = MultipleSeqAlignment([
    SeqRecord(Seq(REF_SEQ), id=Ref_ID),
    SeqRecord(Seq(SEQ_A), id="Homolog_A"),
    SeqRecord(Seq(SEQ_D), id="Distant_Homolog_D"),
    SeqRecord(Seq(SEQ_E), id="W_Mutant_E"),
])
Ref_Sequence = str(msa_alignment[0].seq)

# Helper functions (reused from Ex 2 & 3)
def calculate_pi(seq_a, seq_b):
    matches = sum(1 for a, b in zip(seq_a, seq_b) if a != '-' and b != '-' and a == b)
    overlap = sum(1 for a, b in zip(seq_a, seq_b) if a != '-' and b != '-')
    return (matches / overlap) * 100 if overlap > 0 else 0.0

def get_conservation_score(column):
    N = len(column)
    if not N: return 0.0
    counts = Counter(column)
    max_freq = counts.most_common(1)[0][1]
    return (max_freq / N) * 100
# ----------------------------------------

print("--- Interactive Filtering Analysis ---")

# 1. Low Similarity Identification (PI < 55%)
low_similarity_ids = []
threshold = 55.0
for record in msa_alignment:
    if record.id == Ref_ID: continue
    
    pi = calculate_pi(Ref_Sequence, str(record.seq))
    if pi < threshold:
        low_similarity_ids.append(record.id)

print(f"1. Sequences with PI < {threshold}% relative to {Ref_ID}: {low_similarity_ids}")


# 2. Highly Conserved Block Search (10 residues, >= 90% conservation)
block_size = 10
conservation_threshold = 90.0
aligned_length = msa_alignment.get_alignment_length()

conservation_scores = [get_conservation_score(msa_alignment[:, j]) for j in range(aligned_length)]

found_block = False
for i in range(aligned_length - block_size + 1):
    current_block_scores = conservation_scores[i : i + block_size]
    avg_block_score = sum(current_block_scores) / block_size
    
    if avg_block_score >= conservation_threshold:
        print(f"\n2. Highly Conserved Block Found (1-based indices):")
        print(f"   Start: {i + 1}, End: {i + block_size}")
        found_block = True
        break
if not found_block:
    print(f"\n2. No continuous block of {block_size} residues found with >= {conservation_threshold}% conservation.")


# 3. Specific Residue Mutation Count (W at position 42)
target_position_1based = 42
target_index_0based = target_position_1based - 1

ref_residue = Ref_Sequence[target_index_0based]
target_mutation = 'W'
mutation_count = 0

for record in msa_alignment:
    if record.id == Ref_ID: continue
    
    sequence = str(record.seq)
    if sequence[target_index_0based] == target_mutation:
        mutation_count += 1

print(f"\n3. Analysis at Position {target_position_1based} (Ref: {ref_residue})")
print(f"   Total sequences with Tryptophan (W) at position {target_position_1based}: {mutation_count}")

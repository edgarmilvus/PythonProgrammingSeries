
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import asyncio
import json
from Bio import AlignIO
from io import StringIO
from collections import Counter

# --- Helper Functions (Reused/Simplified from Ex 2 & 3) ---
CLUSTAL_DATA_A = "CLUSTAL W\nSeqA1 M-T-LALDVAG-K-T-T-T-\nSeqA2 M-T-LALDVAG-K-T-T-T-\nSeqA3 V-T-LALDVAG-R-T-W-T-\n"
CLUSTAL_DATA_B = "CLUSTAL W\nSeqB1 M-A-LALDVAG-K-T-T-T-\nSeqB2 M-T-LALDVAG-K-T-T-T-\nSeqB3 M-A-LALDVAG-R-T-W-T-\n"

def load_simulated_alignment(filepath):
    if "A.aln" in filepath: return CLUSTAL_DATA_A
    if "B.aln" in filepath: return CLUSTAL_DATA_B
    return CLUSTAL_DATA_A # Default

def calculate_average_pi(alignment):
    # Simplified calculation for demonstration
    sequences = [str(record.seq) for record in alignment]
    N = len(sequences)
    if N < 2: return 0.0
    
    def pi_calc(seq_a, seq_b):
        matches = sum(1 for a, b in zip(seq_a, seq_b) if a != '-' and b != '-' and a == b)
        overlap = sum(1 for a, b in zip(seq_a, seq_b) if a != '-' and b != '-')
        return (matches / overlap) * 100 if overlap > 0 else 0.0

    total_pi = sum(pi_calc(sequences[i], sequences[j]) 
                   for i in range(N) for j in range(i + 1, N))
    pair_count = N * (N - 1) // 2
    return total_pi / pair_count

def analyze_conservation(alignment):
    N = len(alignment)
    consensus = []
    conserved_100_indices = []
    for j in range(alignment.get_alignment_length()):
        column = alignment[:, j]
        counts = Counter(column)
        most_common_char, max_freq = counts.most_common(1)[0]
        if (max_freq / N) * 100 == 100.0:
            conserved_100_indices.append(j + 1)
        consensus.append(most_common_char)
    return "".join(consensus), conserved_100_indices
# --- End Helpers ---


# 1. Asynchronous Setup
async def process_alignment(filepath):
    alignment_name = filepath.split('/')[-1]
    
    # Simulate I/O bound operation (reading large file)
    await asyncio.sleep(0.01) 
    
    try:
        data = load_simulated_alignment(filepath)
        handle = StringIO(data)
        alignment = AlignIO.read(handle, "clustal")
        
        sequence_count = len(alignment)
        avg_pi = calculate_average_pi(alignment)
        consensus, conserved_indices = analyze_conservation(alignment)
        
        # 3. LLM Chain Input Formatting
        llm_payload = {
            "alignment_name": alignment_name,
            "sequence_count": sequence_count,
            "average_identity": round(avg_pi, 2),
            "consensus_snippet": consensus[:50],
            "highly_conserved_positions": conserved_indices,
        }
        return llm_payload
        
    except Exception as e:
        return {"alignment_name": alignment_name, "error": str(e)}

# 2. Concurrency Management
async def main_async_processor(file_list):
    tasks = [process_alignment(fp) for fp in file_list]
    # asyncio.gather runs the tasks concurrently
    results = await asyncio.gather(*tasks)
    
    # 4. Final Aggregation
    return [r for r in results if "error" not in r]

simulated_files = [
    "/data/msa/alignment_A.aln",
    "/data/msa/alignment_B.aln",
    "/data/msa/alignment_C.aln",
]

# Execute the asynchronous pipeline
llm_chain_input = asyncio.run(main_async_processor(simulated_files))

print("\n--- Final Aggregated LLM Chain Input Payload ---")
print(json.dumps(llm_chain_input, indent=4))

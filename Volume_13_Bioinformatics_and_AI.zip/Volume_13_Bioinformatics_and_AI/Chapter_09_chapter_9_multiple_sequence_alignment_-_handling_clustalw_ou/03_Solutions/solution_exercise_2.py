
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Reusing the 'alignment' object from Exercise 1

def calculate_pi(seq_a, seq_b):
    """
    Calculates Percent Identity (PI) based on non-gap overlapping positions.
    PI = (Matches / Overlap Length) * 100
    """
    matches = 0
    overlap_length = 0
        
    for res_a, res_b in zip(seq_a, seq_b):
        # Overlap Length: Count positions where both sequences have real residues
        if res_a != '-' and res_b != '-':
            overlap_length += 1
            if res_a == res_b:
                matches += 1
                
    if overlap_length == 0:
        return 0.0
    
    return (matches / overlap_length) * 100

# 1. & 2. Iterative Comparison and PI Calculation
pi_matrix = {}
sequences = [(record.id, str(record.seq)) for record in alignment]
N = len(sequences)

for i in range(N):
    id_i, seq_i = sequences[i]
    pi_matrix[id_i] = {}
    
    for j in range(N):
        id_j, seq_j = sequences[j]
        
        if i == j:
            pi_matrix[id_i][id_j] = 100.0
        elif j > i:
            pi_value = calculate_pi(seq_i, seq_j)
            pi_matrix[id_i][id_j] = round(pi_value, 2)
            pi_matrix[id_j][id_i] = round(pi_value, 2) # Symmetry

# 4. Reporting the Matrix
print("\n--- Pairwise Percent Identity Matrix (%) ---")
header = ["ID"] + [seq[0] for seq in sequences]
print(f"{header[0]:<10}", end="")
for h in header[1:]:
    print(f"{h:>10}", end="")
print()

for id_i in header[1:]:
    print(f"{id_i:<10}", end="")
    for id_j in header[1:]:
        print(f"{pi_matrix[id_i][id_j]:>10.2f}", end="")
    print()

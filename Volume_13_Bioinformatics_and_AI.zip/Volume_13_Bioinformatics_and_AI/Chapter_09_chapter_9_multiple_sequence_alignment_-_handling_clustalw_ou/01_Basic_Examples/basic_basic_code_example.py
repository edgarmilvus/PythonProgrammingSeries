
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

from Bio import AlignIO
import os
import textwrap

# --- Configuration ---
# Define the temporary filename for the ClustalW output
ALIGNMENT_FILE = "sample_clustalw_output.aln"

# --- 1. Simulation: Creating a Dummy ClustalW Output File ---
# This content mimics the standard CLUSTAL format, including the header, 
# sequence blocks, and the consensus/conservation line (* . : etc.).
clustal_content = """
CLUSTAL W (1.83) multiple sequence alignment


Seq_Alpha     ATGC-GATTAG
Seq_Beta      ATGCGGAT---
Seq_Gamma     A-GCCGATTAG
Seq_Delta     ATGCCG-TTAG
              * * ** * **

Seq_Alpha     GATC
Seq_Beta      GATC
Seq_Gamma     GATC
Seq_Delta     GATC
              ****

"""

# Write the content to the temporary file
print(f"--- Step 1: Generating temporary file: {ALIGNMENT_FILE} ---")
# textwrap.dedent cleans up leading whitespace in the multiline string
with open(ALIGNMENT_FILE, "w") as f:
    f.write(textwrap.dedent(clustal_content).strip())


# --- 2. Parsing the Alignment using Bio.AlignIO ---
try:
    # Use AlignIO.read() to load the entire alignment block.
    # We specify the file path and the format type 'clustal'.
    # This returns a single MultipleSeqAlignment object.
    alignment_data = AlignIO.read(ALIGNMENT_FILE, "clustal")

    print("\n--- Step 2: Alignment successfully parsed ---")

    # --- 3. Extracting and Displaying Global Alignment Statistics ---
    
    # The MultipleSeqAlignment object behaves like a list of sequences (SeqRecord objects).
    num_sequences = len(alignment_data)
    
    # Use the dedicated method to find the total length of the alignment block (columns)
    alignment_length = alignment_data.get_alignment_length()

    print(f"Total sequences detected: {num_sequences}")
    print(f"Total alignment length (columns, including gaps): {alignment_length}")

    # --- 4. Iterating and Inspecting Individual Sequences ---

    print("\n--- Step 3: Detailed Sequence Inspection ---")
    
    # Iterate through the MultipleSeqAlignment object.
    # Each iteration yields a SeqRecord object.
    for i, record in enumerate(alignment_data):
        # record.id contains the sequence identifier (e.g., Seq_Alpha)
        sequence_id = record.id
        
        # record.seq contains the aligned sequence data (a Seq object)
        # We convert it to a standard Python string for display
        aligned_sequence = str(record.seq)

        print(f"Record {i+1}: ID={sequence_id:<10} Length={len(aligned_sequence):<3} Sequence={aligned_sequence}")

# --- 5. Error Handling and Cleanup ---
except FileNotFoundError:
    print(f"\n[ERROR] File {ALIGNMENT_FILE} not found.")
except ValueError as e:
    # This often catches errors related to incorrect format specification or corrupted files
    print(f"\n[ERROR] Failed to parse alignment file. Check format specification. Details: {e}")
finally:
    # Ensure the temporary file is removed after execution
    if os.path.exists(ALIGNMENT_FILE):
        os.remove(ALIGNMENT_FILE)
        # print(f"\nCleanup successful: {ALIGNMENT_FILE} removed.") # Hidden for cleaner output

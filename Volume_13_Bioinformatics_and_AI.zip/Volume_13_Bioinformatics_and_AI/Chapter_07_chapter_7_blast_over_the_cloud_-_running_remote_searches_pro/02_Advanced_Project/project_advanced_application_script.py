
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import time
import sys
from Bio.Blast import NCBIWWW
from Bio.Blast import NCBIXML

# --- Configuration Constants ---
# A hypothetical short protein sequence (e.g., a domain of unknown function, DUF)
TARGET_SEQUENCE = "MQIFVKTLTGKTTTPLK" 
BLAST_PROGRAM = "blastp"
BLAST_DATABASE = "pdb"  # Targeting the Protein Data Bank for structural homologs
POLLING_INTERVAL_SECONDS = 10
E_VALUE_CUTOFF = 0.001
MAX_HITS_TO_REPORT = 5

def submit_blast_job(sequence: str, db: str, program: str):
    """
    Submits the sequence query to the remote NCBI BLAST server.
    
    Returns the Request ID (RID) and the Estimated Time of Execution (RTOE).
    """
    print(f"--- 1. Submitting BLAST query to NCBI ({program} against {db})...")
    try:
        # qblast sends the request and returns a handle containing the RID and RTOE
        result_handle = NCBIWWW.qblast(
            program=program,
            database=db,
            sequence=sequence,
            expect=E_VALUE_CUTOFF,
            # Setting hitlist_size limits the number of results the server processes
            hitlist_size=100 
        )
        
        # Read the RID and RTOE from the response handle
        rid = result_handle.read().split()[0]
        result_handle.close() # Close the initial small handle immediately
        
        # The NCBI service requires a second query to get the RTOE estimate
        # BioPython handles parsing the RID from the initial response, 
        # but the RTOE estimate is often embedded in the subsequent status page or derived.
        # For simplicity and robustness, we rely on the RID for tracking.
        print(f"   > Job submitted successfully. Request ID (RID): {rid}")
        
        # We manually set RTOE estimate to a reasonable default for initial waiting
        rtoe_estimate = 30 
        return rid, rtoe_estimate

    except Exception as e:
        print(f"CRITICAL ERROR: Failed to submit BLAST job. {e}")
        sys.exit(1)

def poll_and_fetch_results(rid: str, rtoe: int, interval: int):
    """
    Polls the NCBI server using the RID until the job is complete, then fetches the XML results.
    """
    print(f"--- 2. Polling server for results (Estimated initial wait: {rtoe}s)...")
    time.sleep(min(rtoe, interval)) # Initial respectful wait

    while True:
        try:
            # Check the status of the remote job
            status_handle = NCBIWWW.get_blast_status(rid)
            status_text = status_handle.read().strip()
            status_handle.close()
            
            if "Status=WAITING" in status_text:
                print(f"   > Status: WAITING. Sleeping for {interval} seconds...")
                time.sleep(interval)
            
            elif "Status=READY" in status_text:
                print("\n   > Status: READY. Fetching results...")
                # Fetch the results in XML format
                # BioPython automatically adds the necessary parameters (CMD=Get, FORMAT=XML)
                result_handle = NCBIWWW.fetch_blast_search(rid, format='XML')
                return result_handle
            
            elif "Status=UNKNOWN" in status_text or "Error" in status_text:
                print(f"CRITICAL ERROR: Job status unknown or error encountered. Status: {status_text}")
                sys.exit(1)
            
            else:
                # Handle unexpected intermediate states
                print(f"   > Unexpected status received. Retrying in {interval}s.")
                time.sleep(interval)

        except Exception as e:
            print(f"Polling error: {e}. Retrying...")
            time.sleep(interval * 2) # Back off on error

def parse_and_report(blast_handle):
    """
    Parses the XML results using NCBIXML and prints a formatted report of top hits.
    """
    print("--- 3. Parsing XML Results and Generating Report ---")
    
    # Use NCBIXML.parse to handle potentially large files iteratively
    blast_records = NCBIXML.parse(blast_handle)
    
    try:
        # A single BLAST submission typically yields one record object
        record = next(blast_records)
    except StopIteration:
        print("No BLAST records found in the result file.")
        return
    except Exception as e:
        print(f"Error reading initial BLAST record: {e}")
        return

    hit_count = 0
    print(f"\n{'='*80}")
    print(f"TOP {MAX_HITS_TO_REPORT} PDB HOMOLOGS FOUND (E-value < {E_VALUE_CUTOFF}):")
    print(f"{'Accession':<15} | {'E-Value':<10} | {'Length':<8} | Definition (Organism)")
    print(f"{'-'*15}-|{'-'*10}-|{'-'*8}-|{'-'*40}")

    # Iterate through all hits found in the record
    for alignment in record.alignments:
        if hit_count >= MAX_HITS_TO_REPORT:
            break
            
        # The definition often contains the source organism and structure name
        definition = alignment.title
        
        # Extract the best High-Scoring Pair (HSP) for E-value and length
        # Note: Alignment objects contain a list of HSPs (High-Scoring Pairs)
        best_hsp = alignment.hsps[0] 
        
        e_value = best_hsp.expect
        align_length = best_hsp.align_length
        
        # Extract the PDB identifier (Accession) from the title string
        # PDB titles typically start with 'pdb|XXXX|...'
        accession = definition.split('|')[1]
        
        # Filter based on the E-value cutoff (though qblast already filtered, this is a safety check)
        if e_value <= E_VALUE_CUTOFF:
            print(f"{accession:<15} | {e_value:<10.2e} | {align_length:<8} | {definition[:40]}...")
            hit_count += 1

    print(f"\n{'='*80}")
    print(f"Search complete. Total hits processed: {len(record.alignments)}")
    blast_handle.close()


if __name__ == "__main__":
    # 1. Submission Phase
    rid, rtoe = submit_blast_job(TARGET_SEQUENCE, BLAST_DATABASE, BLAST_PROGRAM)
    
    # 2. Polling and Retrieval Phase
    # The result_handle is an XML file-like object
    xml_handle = poll_and_fetch_results(rid, rtoe, POLLING_INTERVAL_SECONDS)
    
    # 3. Parsing and Reporting Phase
    if xml_handle:
        parse_and_report(xml_handle)
    else:
        print("Failed to retrieve results.")


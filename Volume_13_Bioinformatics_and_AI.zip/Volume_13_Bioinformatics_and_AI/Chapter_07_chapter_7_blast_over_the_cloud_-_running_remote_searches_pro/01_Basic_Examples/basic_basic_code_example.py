
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

from Bio.Blast import NCBIWWW
import io

# --- 1. Define the Query and Parameters ---
# A short, well-known protein fragment (part of Human Hemoglobin Beta chain)
# This sequence ensures a quick and reliable test submission.
QUERY_SEQUENCE = "VHLTPEEKSAVTALWGKVN"

# Define the search type (BLAST Program) and the target database
BLAST_PROGRAM = "blastp"  # Protein query vs. Protein database
BLAST_DATABASE = "nr"     # Non-redundant database (comprehensive)

print(f"--- Remote BLAST Job Submission ---")
print(f"Submitting sequence ({len(QUERY_SEQUENCE)} residues) using {BLAST_PROGRAM} against {BLAST_DATABASE}...")

# --- 2. Submit the Query ---
try:
    # NCBIWWW.qblast submits the request and returns a file-like object (the handle)
    # This handle contains the submission receipt, NOT the final results.
    result_handle = NCBIWWW.qblast(
        program=BLAST_PROGRAM,
        database=BLAST_DATABASE,
        sequence=QUERY_SEQUENCE
    )

    # --- 3. Extract and Close the Handle ---
    # The handle is a streaming connection. We must read its content immediately.
    submission_receipt_content = result_handle.read()
    result_handle.close() # Always close the connection after reading

    # --- 4. Parse the Request ID (RID) and RTOE ---
    # The RID and RTOE are embedded in the text/HTML response from the server.
    
    # Locate the start of the RID tag
    rid_tag_start = submission_receipt_content.find("RID = ")
    # Locate the start of the RTOE tag (Estimated Time)
    rtoe_tag_start = submission_receipt_content.find("RTOE = ")
    
    if rid_tag_start != -1 and rtoe_tag_start != -1:
        
        # Extract the line containing the RID
        # We slice the string from the start of "RID = " and split by newline to get the full line
        rid_line = submission_receipt_content[rid_tag_start:].split('\n')[0]
        # Clean the value (split by '=' and remove whitespace)
        rid_value = rid_line.split('=')[1].strip()
        
        # Extract the line containing the RTOE
        rtoe_line = submission_receipt_content[rtoe_tag_start:].split('\n')[0]
        rtoe_value = rtoe_line.split('=')[1].strip()

        print("\n--- Submission Receipt Received ---")
        print(f"Request ID (RID): {rid_value}")
        print(f"Estimated Time of Execution (RTOE): {rtoe_value} seconds")
        print("\nJob successfully submitted to the remote server.")
        print("This RID must be used in the next step to poll for results.")
        
    else:
        print("\nError: Failed to locate the required RID and RTOE tags in the server response.")
        print("This often indicates a server side error or an invalid query.")
        
except Exception as e:
    print(f"\nCRITICAL ERROR: An exception occurred during the remote submission: {e}")


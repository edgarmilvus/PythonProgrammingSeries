
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from Bio.Blast import Record
import sys

# Assume xml_result_handle was successfully populated by Exercise 2
# For demonstration purposes, if running standalone, we need to mock the handle.
if 'xml_result_handle' not in globals() or xml_result_handle is None:
    print("FATAL: XML result handle not available. Run Exercise 2 first.")
    # sys.exit(1) # Commented out for analysis readability

# Define constants based on Exercise 1's sequence
QUERY_SEQUENCE = "MQIFVKTLTGKTITLEVEPSDTIENVKAKIQDKEGIPPDQQRLIFAGKQLEDGRTLSDYNIQKESTLHLVLRLRGG"
QUERY_LENGTH = len(QUERY_SEQUENCE)
E_VALUE_THRESHOLD = 1e-10
COVERAGE_THRESHOLD = 0.90
hits_found = 0

print(f"\n--- Analyzing BLAST Results (Query Length: {QUERY_LENGTH}) ---")
print(f"Filters: E-value < {E_VALUE_THRESHOLD}, Coverage >= {COVERAGE_THRESHOLD * 100}%")
print("-" * 50)
print(f"{'Accession':<15} {'Length':<10} {'E-value':<20}")
print("-" * 50)

try:
    # 1. Use the memory-efficient parse() function
    blast_records = Record.parse(xml_result_handle)

    # 2. Iterate through the records (usually only one record per qblast submission)
    for record in blast_records:
        for alignment in record.alignments:
            # The best HSP is usually the first one in the list
            best_hsp = alignment.hsps[0]

            # Calculate Query Coverage: alignment length relative to the full query length
            coverage = best_hsp.align_length / QUERY_LENGTH

            # 3. Implement dual-criterion filter
            if best_hsp.expect < E_VALUE_THRESHOLD and coverage >= COVERAGE_THRESHOLD:
                
                # 4. Print formatted output
                print(f"{alignment.accession:<15} {alignment.length:<10} {best_hsp.expect:<20.2e}")
                hits_found += 1

    print("-" * 50)
    # 5. Handle case where no hits meet the criteria
    if hits_found == 0:
        print("Search successful, but no hits met the stringent E-value and Coverage criteria.")

except Exception as e:
    print(f"\nError during XML parsing: {e}")
    # This often happens if the mock handle is used or if the XML is malformed.

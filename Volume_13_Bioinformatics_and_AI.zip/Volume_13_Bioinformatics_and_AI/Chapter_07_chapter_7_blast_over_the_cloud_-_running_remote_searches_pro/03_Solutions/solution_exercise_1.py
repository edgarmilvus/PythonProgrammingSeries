
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import Bio.Blast.NCBIWWW as NCBIWWW
import re
import sys
from urllib.error import HTTPError, URLError

PROTEIN_SEQUENCE = "MQIFVKTLTGKTITLEVEPSDTIENVKAKIQDKEGIPPDQQRLIFAGKQLEDGRTLSDYNIQKESTLHLVLRLRGG"

# Global variable to store the RID for subsequent exercises
BLAST_RID = None
R_T_VALUE = None

print("Starting asynchronous BLAST submission...")

try:
    # 1. Submit the query sequence
    result_handle = NCBIWWW.qblast(
        program="blastp",
        database="nr",
        sequence=PROTEIN_SEQUENCE,
        # Setting the format to XML ensures we get the necessary metadata structure
        format_type="XML"
    )

    # 2. Read the response content (which contains the RID and R-T)
    response_text = result_handle.read()
    result_handle.close()

    # 3. Use regex to extract the Request ID (RID) and R-T (Retention Time)
    # NCBI returns these values embedded in the response text
    rid_match = re.search(r"RID:\s*([A-Z0-9]+)", response_text)
    rt_match = re.search(r"R-T:\s*(\d+)", response_text)

    if rid_match and rt_match:
        BLAST_RID = rid_match.group(1)
        R_T_VALUE = rt_match.group(1)
        print(f"\n--- Job Submission Successful ---")
        print(f"Request ID (RID): {BLAST_RID}")
        print(f"Estimated Retention Time (R-T): {R_T_VALUE} seconds")
        print("Job registered on NCBI server.")
    else:
        print("Error: Could not extract RID or R-T from the response.")
        print(f"Server response snippet: {response_text[:300]}...")

except (HTTPError, URLError) as e:
    print(f"\nFATAL ERROR: Network or HTTP issue occurred during submission.")
    print(f"Details: {e}")
    sys.exit(1)
except Exception as e:
    print(f"\nAn unexpected error occurred: {e}")
    sys.exit(1)


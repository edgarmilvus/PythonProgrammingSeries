
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import Bio.Blast.NCBIWWW as NCBIWWW
import time
import sys
from urllib.error import HTTPError, URLError
from io import StringIO

# Assume BLAST_RID was successfully populated by Exercise 1
# Using a placeholder RID for isolated testing if Ex 1 was skipped:
if 'BLAST_RID' not in globals() or BLAST_RID is None:
    print("Warning: Using placeholder RID. Run Exercise 1 first for a live RID.")
    BLAST_RID = "Placeholder_RID" 

MAX_WAIT_TIME_SECONDS = 600 # 10 minutes
MAX_SLEEP_SECONDS = 60
INITIAL_SLEEP = 10
SLEEP_INCREMENT = 5

current_sleep = INITIAL_SLEEP
total_time_elapsed = 0
xml_result_handle = None

print(f"\n--- Starting Polling for RID: {BLAST_RID} ---")

try:
    while total_time_elapsed < MAX_WAIT_TIME_SECONDS:
        # Check job status by attempting to retrieve results
        status_handle = NCBIWWW.get_search_results(
            rid=BLAST_RID,
            format_type='XML'
        )
        status_text = status_handle.read()
        status_handle.close()

        if "Status=READY" in status_text:
            print(f"\nJob {BLAST_RID} is READY. Retrieving results.")
            # Re-fetch the handle, this time containing the full XML results
            # Note: We must fetch the handle again, as the previous one was read for status.
            xml_result_handle = NCBIWWW.get_search_results(
                rid=BLAST_RID,
                format_type='XML'
            )
            break

        elif "Status=WAITING" in status_text or "Status=UNKNOWN" in status_text:
            print(f"Status: WAITING/UNKNOWN. Sleeping for {current_sleep} seconds.")
            time.sleep(current_sleep)
            total_time_elapsed += current_sleep
            
            # Increase sleep duration, capped at MAX_SLEEP_SECONDS
            current_sleep = min(current_sleep + SLEEP_INCREMENT, MAX_SLEEP_SECONDS)

        elif "Error" in status_text:
            print(f"\nFATAL: Job failed or expired on server.")
            print(f"Server message: {status_text}")
            sys.exit(1)
        
        else:
            # Catch unexpected status response
            print(f"Unexpected status response. Retrying in {current_sleep}s.")
            time.sleep(current_sleep)
            total_time_elapsed += current_sleep
            current_sleep = min(current_sleep + SLEEP_INCREMENT, MAX_SLEEP_SECONDS)


    if total_time_elapsed >= MAX_WAIT_TIME_SECONDS and xml_result_handle is None:
        print(f"\nTIMEOUT FAILURE: Polling exceeded maximum wait time ({MAX_WAIT_TIME_SECONDS} seconds).")
        sys.exit(1)

except (HTTPError, URLError) as e:
    print(f"\nFATAL ERROR: Network or HTTP issue during polling.")
    print(f"Details: {e}")
    sys.exit(1)

# xml_result_handle is now available for Exercise 3

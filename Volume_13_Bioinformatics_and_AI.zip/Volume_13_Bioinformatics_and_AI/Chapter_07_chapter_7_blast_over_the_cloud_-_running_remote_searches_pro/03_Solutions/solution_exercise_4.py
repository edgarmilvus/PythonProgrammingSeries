
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import Bio.Blast.NCBIWWW as NCBIWWW
import time
from io import StringIO
import re

# Mock FASTA data for simulation
MOCK_FASTA_CONTENT = """
>SeqA_Hemoglobin_Alpha
MTQIFVKTLTGKTITLEVEPSDTIENVKAKIQDKEGIPPDQQRLIFAGKQLEDGRTLSDYNIQKESTLHLVLRLRGG
>SeqB_Myoglobin_Fragment
MNAGVQVDFKGLFGKDLVTSKPKLIGVAYGKLQADVDTDFAKQLIDNAYKLSTKSE
>SeqC_Short_Peptide
GIPPDQQRLIFAGKQLEDGRTLSDYN
"""

# --- 1. FASTA Parsing and Submission ---

sequences = {}
current_header = None
current_sequence = []

# Simulate reading the file line by line
for line in StringIO(MOCK_FASTA_CONTENT):
    line = line.strip()
    if not line:
        continue
    
    if line.startswith('>'):
        if current_header and current_sequence:
            sequences[current_header] = "".join(current_sequence)
        current_header = line[1:].split()[0] # Use only the first word as the key
        current_sequence = []
    else:
        current_sequence.append(line)

# Add the last sequence
if current_header and current_sequence:
    sequences[current_header] = "".join(current_sequence)

print(f"Parsed {len(sequences)} sequences. Submitting jobs...")

# 4. Batch Submission and Dictionary Comprehension for RID Tracking
job_tracker = {}

for header, seq in sequences.items():
    try:
        result_handle = NCBIWWW.qblast("blastp", "nr", seq, format_type="XML")
        response_text = result_handle.read()
        rid_match = re.search(r"RID:\s*([A-Z0-9]+)", response_text)
        
        if rid_match:
            job_tracker[header] = rid_match.group(1)
            print(f"Submitted {header}: RID {job_tracker[header]}")
        else:
            print(f"Warning: Could not get RID for {header}. Skipping.")
    except Exception as e:
        print(f"Error submitting {header}: {e}")

# 5. Master Polling Loop

RIDS_TO_POLL = set(job_tracker.values())
completed_jobs = {}
current_sleep = 10
MAX_WAIT_TIME_SECONDS = 600

print(f"\n--- Starting Master Polling Loop for {len(RIDS_TO_POLL)} jobs ---")

while RIDS_TO_POLL:
    rids_finished_in_cycle = set()
    
    for header, rid in job_tracker.items():
        if rid not in RIDS_TO_POLL:
            continue # Already completed

        try:
            status_handle = NCBIWWW.get_search_results(rid=rid, format_type='XML')
            status_text = status_handle.read()
            status_handle.close()

            if "Status=READY" in status_text:
                print(f"Job {header} (RID: {rid}) is READY.")
                
                # Retrieve full XML result handle
                xml_handle = NCBIWWW.get_search_results(rid=rid, format_type='XML')
                
                # Simple parsing to get top hit
                records = Record.parse(xml_handle)
                top_hit_accession = "No Hits Found"
                for record in records:
                    if record.alignments:
                        top_hit_accession = record.alignments[0].accession
                    break
                
                completed_jobs[header] = top_hit_accession
                rids_finished_in_cycle.add(rid)

            elif "Status=WAITING" in status_text or "Status=UNKNOWN" in status_text:
                pass # Still waiting, do not print status excessively

            elif "Error" in status_text:
                print(f"Job {header} (RID: {rid}) failed on server.")
                rids_finished_in_cycle.add(rid)

        except Exception as e:
            print(f"Error checking status for {header}: {e}")
            
    
    # Update the set of RIDs still needing polling
    RIDS_TO_POLL -= rids_finished_in_cycle
    
    if RIDS_TO_POLL:
        print(f"Waiting. {len(RIDS_TO_POLL)} jobs remaining. Sleeping for {current_sleep}s...")
        time.sleep(current_sleep)
        current_sleep = min(current_sleep + 5, 30) # Use a shorter backoff for batch polling

# 6. Output Summary
print("\n--- Batch Results Summary ---")
for header, accession in completed_jobs.items():
    print(f"Query: {header:<25} | Top Hit Accession: {accession}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import pandas as pd
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, accuracy_score
from itertools import product
import random

# --- 1. Feature Engineering Function: K-mer Vectorizer ---

def generate_all_kmers(k):
    """Generates all possible k-mers for a given k."""
    bases = ['A', 'C', 'G', 'T']
    return [''.join(p) for p in product(bases, repeat=k)]

def kmer_count_vectorizer(sequence, k=4):
    """
    Transforms a DNA sequence into a frequency vector based on K-mer counts.
    Ensures the resulting vector has a fixed length (4^k).
    """
    # Generate the complete vocabulary of 4^k possible k-mers
    kmer_vocabulary = generate_all_kmers(k)
    kmer_counts = {kmer: 0 for kmer in kmer_vocabulary}
    
    # Calculate the frequency of each k-mer in the sequence
    n = len(sequence)
    for i in range(n - k + 1):
        kmer = sequence[i:i + k]
        # Only count k-mers that are part of our defined vocabulary
        if kmer in kmer_counts:
            kmer_counts[kmer] += 1
            
    # Convert the dictionary counts into a fixed-order list/vector
    feature_vector = [kmer_counts[kmer] for kmer in kmer_vocabulary]
    
    return feature_vector

# --- 2. Synthetic Data Simulation ---
# In a real scenario, this data would come from FASTA files (positive/negative examples).
SEQUENCE_LENGTH = 20
K_MER_SIZE = 4
NUM_SAMPLES = 400

# Define characteristics for positive (splice site) and negative sequences
# Positive sequences usually contain the 'GT' motif near the center (donor site)
positive_sequences = []
for _ in range(NUM_SAMPLES // 2):
    # Random sequence parts
    prefix = ''.join(random.choices('ACGT', k=SEQUENCE_LENGTH // 2 - 1))
    suffix = ''.join(random.choices('ACGT', k=SEQUENCE_LENGTH // 2 - 1))
    seq = prefix + 'GT' + suffix # Enforcing the 'GT' donor site motif
    positive_sequences.append(seq)

# Negative sequences are random non-functional sequences
negative_sequences = []
for _ in range(NUM_SAMPLES // 2):
    seq = ''.join(random.choices('ACGT', k=SEQUENCE_LENGTH))
    negative_sequences.append(seq)

# Combine and label data
all_sequences = positive_sequences + negative_sequences
labels = [1] * (NUM_SAMPLES // 2) + [0] * (NUM_SAMPLES // 2)

# --- 3. Data Transformation and Preparation ---

# Convert all sequences into K-mer feature vectors
X_features = np.array([kmer_count_vectorizer(seq, k=K_MER_SIZE) for seq in all_sequences])
y_labels = np.array(labels)

# Check feature vector dimensionality (should be 4^4 = 256)
print(f"Total samples: {X_features.shape[0]}")
print(f"Feature dimensionality (4^{K_MER_SIZE}): {X_features.shape[1]}")

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X_features, y_labels, test_size=0.25, random_state=42, stratify=y_labels
)

# --- 4. Define and Train the ML Pipeline (Scaler + SVC) ---

# Create a pipeline: 
# 1. StandardScaler: Normalizes the K-mer counts (important for distance-based methods like SVM).
# 2. SVC (Support Vector Classifier): The classification model.
splice_site_classifier = Pipeline([
    ('scaler', StandardScaler()),
    ('svm', SVC(kernel='rbf', C=10, gamma='scale', random_state=42))
])

print("\nStarting model training...")
# Train the pipeline
splice_site_classifier.fit(X_train, y_train)
print("Training complete.")

# --- 5. Evaluation ---

# Make predictions on the test set
y_pred = splice_site_classifier.predict(X_test)

# Report performance metrics
accuracy = accuracy_score(y_test, y_pred)
report = classification_report(y_test, y_pred, target_names=['Non-Splice (0)', 'Splice Site (1)'])

print("\n--- Model Performance Metrics ---")
print(f"Test Accuracy: {accuracy:.4f}")
print("Classification Report:")
print(report)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import time
import numpy as np
import pandas as pd
# Reusing data simulation and K-mer functions from Exercise 3

# Data Preparation (using simulated data from Ex 3)
sequences, labels = simulate_data(100, 150)
X_train_seq, X_test_seq, y_train, y_test = train_test_split(
    sequences, labels, test_size=0.3, random_state=42, stratify=labels
)

results = []
K_RANGE = range(2, 7) # K=2, 3, 4, 5, 6

print("--- K-mer Optimization Loop ---")

for K in K_RANGE:
    # 1. Feature Generation
    kmer_list = generate_kmer_dictionary(K)
    dimensionality = len(kmer_list)
    
    # Vectorize training and testing sets
    X_train = np.stack([sequence_to_kmer_vector(seq, K, kmer_list) for seq in X_train_seq])
    X_test = np.stack([sequence_to_kmer_vector(seq, K, kmer_list) for seq in X_test_seq])
    
    # 2. Model Training and Timing
    model = LogisticRegression(max_iter=1000, solver='liblinear', random_state=42)
    
    start_time = time.time()
    model.fit(X_train, y_train)
    train_time = time.time() - start_time
    
    # 3. Evaluation
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    
    # Record metrics
    results.append({
        'K': K,
        'Dimensionality': dimensionality,
        'Training Time (s)': round(train_time, 5),
        'Accuracy': round(accuracy, 4)
    })
    
    print(f"K={K}: Dim={dimensionality}, Time={train_time:.4f}s, Accuracy={accuracy:.4f}")

# 4. Analysis
results_df = pd.DataFrame(results)
print("\n--- Optimization Results Table ---")
print(results_df)

# Identify the best K
best_k_row = results_df.loc[results_df['Accuracy'].idxmax()]
print("\n--- Analysis of Optimal K ---")
print(f"Highest Accuracy Achieved: K={best_k_row['K']} (Accuracy: {best_k_row['Accuracy']})")

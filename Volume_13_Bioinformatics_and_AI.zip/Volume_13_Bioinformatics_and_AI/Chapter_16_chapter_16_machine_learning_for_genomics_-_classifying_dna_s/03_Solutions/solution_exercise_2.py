
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np

def one_hot_encode_base(base):
    """Maps a single nucleotide to its 4-dimensional OHE vector."""
    base = base.upper()
    mapping = {'A': [1, 0, 0, 0], 
               'C': [0, 1, 0, 0], 
               'G': [0, 0, 1, 0], 
               'T': [0, 0, 0, 1],
               # Padding/Unknown bases (N, X) are typically represented by all zeros
               'N': [0, 0, 0, 0],
               'X': [0, 0, 0, 0]}
    
    return np.array(mapping.get(base, [0, 0, 0, 0]))

def pad_sequences(sequences, padding_value='N'):
    """Pads sequences to the length of the longest sequence using post-padding."""
    if not sequences:
        return []
        
    max_length = max(len(s) for s in sequences)
    padded_sequences = []
    
    for seq in sequences:
        # Post-padding: padding is added to the end
        padding_needed = max_length - len(seq)
        padded_seq = seq + (padding_value * padding_needed)
        padded_sequences.append(padded_seq)
        
    return padded_sequences, max_length

def sequences_to_ohe_matrix(sequences):
    """Pads sequences and converts the entire dataset into a 3D OHE matrix."""
    
    # 1. Pad sequences
    padded_sequences, max_len = pad_sequences(sequences)
    num_sequences = len(padded_sequences)
    
    # OHE dimension is 4 (A, C, G, T)
    OHE_DIM = 4
    
    # Initialize the 3D NumPy array: (N_sequences, Padded_Length, OHE_Dimension)
    ohe_matrix = np.zeros((num_sequences, max_len, OHE_DIM), dtype=np.int8)
    
    # 2. Apply OHE to every base
    for i, seq in enumerate(padded_sequences):
        for j, base in enumerate(seq):
            ohe_vector = one_hot_encode_base(base)
            ohe_matrix[i, j, :] = ohe_vector
            
    return ohe_matrix

# --- Testing ---
input_sequences = [
    "ACGT",
    "GATTACA",
    "TGC",
    "A" * 10 
]

ohe_result_matrix = sequences_to_ohe_matrix(input_sequences)

print(f"Input Sequences: {input_sequences}")
print(f"Maximum Length: {ohe_result_matrix.shape[1]}")
print(f"Output Matrix Shape: {ohe_result_matrix.shape}")
# print("\nFirst sequence OHE snippet (ACGT):")
# print(ohe_result_matrix[0, :4])

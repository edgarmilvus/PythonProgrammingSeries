
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score
import numpy as np
import random
import time

# Reusing K-mer functions from Exercise 1 (assumed available or redefined here)
BASES = ['A', 'C', 'G', 'T']
def generate_kmer_dictionary(K):
    return sorted([''.join(p) for p in itertools.product(BASES, repeat=K)])

def sequence_to_kmer_vector(sequence, K, kmer_list):
    kmer_counts = Counter()
    total_kmers = 0
    for i in range(len(sequence) - K + 1):
        kmer = sequence[i:i + K]
        kmer_counts[kmer] += 1
        total_kmers += 1
    
    feature_vector = [kmer_counts.get(kmer, 0) / total_kmers if total_kmers > 0 else 0 
                      for kmer in kmer_list]
    return np.array(feature_vector)


# --- 1. Data Simulation (100 sequences, 150 bp) ---
SEQ_LEN = 150
NUM_SAMPLES = 100
K_TARGET = 4

def simulate_data(n_samples, length):
    """Creates random DNA sequences and balanced, fictional labels."""
    sequences = []
    labels = []
    for i in range(n_samples):
        # Simulate two classes with slight compositional differences
        if i < n_samples // 2:
            # Class 0: Slightly AT-rich
            seq = ''.join(random.choices(['A', 'T', 'C', 'G'], weights=[0.3, 0.3, 0.2, 0.2], k=length))
            labels.append(0)
        else:
            # Class 1: Slightly GC-rich
            seq = ''.join(random.choices(['A', 'T', 'C', 'G'], weights=[0.2, 0.2, 0.3, 0.3], k=length))
            labels.append(1)
        sequences.append(seq)
    return sequences, np.array(labels)

sequences, labels = simulate_data(NUM_SAMPLES, SEQ_LEN)

# --- 2. Feature Extraction (K=4) ---
kmer_list_k4 = generate_kmer_dictionary(K_TARGET)
dimensionality_k4 = len(kmer_list_k4) # 4^4 = 256

X = np.stack([sequence_to_kmer_vector(seq, K_TARGET, kmer_list_k4) for seq in sequences])
y = labels

print(f"Feature Dimensionality (K={K_TARGET}): {dimensionality_k4}")
print(f"Feature Matrix Shape: {X.shape}")

# --- 3. Training and Evaluation ---
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

# Use Logistic Regression as the classifier
model = LogisticRegression(max_iter=1000, solver='liblinear', random_state=42)

start_time = time.time()
model.fit(X_train, y_train)
train_time = time.time() - start_time

y_pred = model.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)

print(f"\nTraining Time: {train_time:.4f} seconds")
print(f"Test Accuracy (K=4 features): {accuracy:.4f}")
print(f"Test F1 Score (K=4 features): {f1:.4f}")

# --- 4. Comparative Analysis ---
# Assumed Original Pipeline (K=2 or simple counts): 
# Dimensionality was 4 (simple counts) or 16 (K=2).
# The performance (accuracy/F1) here is likely high (e.g., > 0.8) because 
# the simulated data was intentionally designed to have compositional differences 
# that are easily captured by K-mer frequencies (K=4 captures 4-base motifs).

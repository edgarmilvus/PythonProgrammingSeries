
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import itertools
from collections import Counter
import numpy as np

BASES = ['A', 'C', 'G', 'T']

def generate_kmer_dictionary(K):
    """Generates a sorted list of all possible K-mers."""
    all_kmers = [''.join(p) for p in itertools.product(BASES, repeat=K)]
    return sorted(all_kmers)

def sequence_to_kmer_vector(sequence, K, kmer_list):
    """Converts a DNA sequence into a normalized K-mer frequency vector."""
    kmer_counts = Counter()
    total_kmers = 0
    
    # 1. Count K-mers
    for i in range(len(sequence) - K + 1):
        kmer = sequence[i:i + K]
        if len(kmer) == K:
            kmer_counts[kmer] += 1
            total_kmers += 1

    # 2. Create the feature vector based on the standardized kmer_list order
    feature_vector = []
    if total_kmers == 0:
        # Handle empty or too short sequences
        return np.zeros(len(kmer_list))

    for kmer in kmer_list:
        count = kmer_counts.get(kmer, 0)
        # 3. Normalize to frequency
        frequency = count / total_kmers
        feature_vector.append(frequency)
        
    return np.array(feature_vector)

# --- Testing and Dimensionality Analysis ---
K3 = 3
K6 = 6

# 1. K=3 Analysis
kmer_list_k3 = generate_kmer_dictionary(K3)
dimensionality_k3 = len(kmer_list_k3)
print(f"K={K3}: Dimensionality (4^{K3}) = {dimensionality_k3}")

# 2. K=6 Analysis
dimensionality_k6 = 4**K6
print(f"K={K6}: Dimensionality (4^{K6}) = {dimensionality_k6}")

dna_sequence = "ATGCGTAGCATGACGT"
kmer_vector_k3 = sequence_to_kmer_vector(dna_sequence, K3, kmer_list_k3)
print(f"\nExample K={K3} Vector Shape: {kmer_vector_k3.shape}")

# 3. Discussion on K=8
# K=8 Dimensionality: 4^8 = 65,536 features.
# If the training set size is only a few thousand sequences (e.g., 5,000), 
# using K=8 results in a severe case of the curse of dimensionality. 
# The feature matrix will be extremely sparse (most entries are zero), 
# leading to high variance, overfitting, and poor generalization because 
# the model is trying to learn 65k parameters from only 5k examples.
# This sparsity is a major reason why larger K-mers are often handled 
# using embedding techniques or specialized models (like CNNs) rather 
# than traditional frequency vectorization.

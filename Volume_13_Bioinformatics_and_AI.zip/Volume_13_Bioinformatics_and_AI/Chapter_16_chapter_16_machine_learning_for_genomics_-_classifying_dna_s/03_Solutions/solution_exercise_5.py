
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np

# --- Setup: Assume OHE data from Exercise 2 ---
NUM_SAMPLES = 1000
MAX_LEN = 200
OHE_CHANNELS = 4 # A, C, G, T

# Placeholder for the 3D array (1000, 200, 4)
# Data is simulated as random binary arrays for demonstration
OHE_DATA_TENSOR = np.random.randint(0, 2, size=(NUM_SAMPLES, MAX_LEN, OHE_CHANNELS), dtype=np.int8)
BATCH_SIZE = 32

print(f"Full Dataset Shape (N, L, C): {OHE_DATA_TENSOR.shape}")

def verify_cnn_input_shape(data_batch):
    """Verifies that the batch shape is compatible with a standard (L, C) 1D CNN input."""
    assert data_batch.ndim == 3, "Input must be a 3D tensor."
    assert data_batch.shape[2] == OHE_CHANNELS, f"Last dimension (channels) must be {OHE_CHANNELS}."
    print(f"Batch Shape Verified: {data_batch.shape}")

# --- 2. Batch Simulation and 3. Shape Verification ---
num_batches = (NUM_SAMPLES + BATCH_SIZE - 1) // BATCH_SIZE

for i in range(num_batches):
    start_index = i * BATCH_SIZE
    end_index = min((i + 1) * BATCH_SIZE, NUM_SAMPLES)
    
    data_batch = OHE_DATA_TENSOR[start_index:end_index, :, :]
    
    # Verify the shape for the typical TensorFlow/Keras standard: (B, L, C)
    verify_cnn_input_shape(data_batch)

    if i == 0:
        print(f"\nExample Batch 0 Shape: {data_batch.shape}")
        
# --- Interactive Challenge: Transposition ---

# If a framework (like PyTorch) required the shape (Batch Size, Channels, Sequence Length): (B, C, L)
# The current shape is (B, L, C) -> (Batch Size, Sequence Length, Channels)
# We need to swap the sequence length axis (1) and the channel axis (2).

# Example of transposition for the first batch:
first_batch = OHE_DATA_TENSOR[0:BATCH_SIZE, :, :]

# NumPy operation to achieve (B, C, L) shape:
pytorch_compatible_batch = np.transpose(first_batch, (0, 2, 1))

print(f"\nOriginal Batch Shape (B, L, C): {first_batch.shape}")
print(f"PyTorch Compatible Shape (B, C, L): {pytorch_compatible_batch.shape}")

# Verification of the transposition operation:
# The dimensions should be (32, 4, 200)
assert pytorch_compatible_batch.shape == (first_batch.shape[0], OHE_CHANNELS, MAX_LEN)

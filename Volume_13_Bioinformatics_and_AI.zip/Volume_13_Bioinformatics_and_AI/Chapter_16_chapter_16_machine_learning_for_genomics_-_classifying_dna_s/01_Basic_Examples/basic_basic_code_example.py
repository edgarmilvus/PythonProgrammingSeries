
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import itertools
from collections import Counter
import numpy as np

# --- 1. Define the Problem Parameters ---
K = 3  # K-mer size (trimer) chosen for simplicity
SAMPLE_SEQUENCE = "GATTACA"

# --- 2. Create the Universal K-mer Vocabulary ---
# Define the four canonical DNA bases
BASES = ['A', 'T', 'G', 'C']

def generate_vocabulary(bases, k):
    """
    Generates all 4^K possible K-mer combinations.
    This ensures a fixed feature dimensionality required by ML models.
    """
    # itertools.product creates the Cartesian product of the bases, repeated K times
    all_k_mers = [''.join(p) for p in itertools.product(bases, repeat=k)]
    # Sorting ensures a deterministic and consistent order for the feature vector indices
    return sorted(all_k_mers)

# Generate the 4^3 = 64 possible trimers
VOCABULARY = generate_vocabulary(BASES, K)

# --- 3. Feature Extraction (Sliding Window) ---
def extract_k_mers(sequence, k):
    """Slides a window of size K across the sequence and extracts K-mers."""
    k_mers_list = []
    # The loop runs until the index 'i' allows for a full K-mer extraction
    # The length of the resulting list will be len(sequence) - k + 1
    for i in range(len(sequence) - k + 1):
        # Standard Python slicing extracts the K-mer
        k_mer = sequence[i:i + k]
        k_mers_list.append(k_mer)
    return k_mers_list

# --- 4. Vectorization (Counting Frequencies and Mapping) ---
def vectorize_sequence(sequence, k, vocabulary):
    """
    Transforms the sequence into a fixed-length feature vector
    based on K-mer counts, using the predefined, ordered vocabulary.
    """
    # Step 4a: Extract the K-mers from the input sequence
    extracted_k_mers = extract_k_mers(sequence, k)
    
    # Step 4b: Count the frequency of each extracted K-mer
    # Counter efficiently creates a dictionary mapping K-mer string -> frequency integer
    k_mer_counts = Counter(extracted_k_mers)
    
    # Step 4c: Map the counts to the fixed vocabulary order using a NumPy array
    # Initialization with zeros ensures that K-mers not present in the sequence
    # are correctly represented by a count of zero.
    feature_vector = np.zeros(len(vocabulary), dtype=np.int32)
    
    # Iterate through the standardized vocabulary to fill the vector
    for index, k_mer in enumerate(vocabulary):
        # Retrieve the count for this specific K-mer. .get() handles missing keys gracefully.
        count = k_mer_counts.get(k_mer, 0)
        feature_vector[index] = count
        
    return feature_vector

# --- 5. Execution and Verification ---
print(f"--- Genomic Feature Engineering Pipeline ---")
print(f"Input Sequence: {SAMPLE_SEQUENCE}")
print(f"K-mer Size (K): {K}")
print(f"Total Vocabulary Size (4^{K}): {len(VOCABULARY)}")

# 5a. Run extraction
extracted = extract_k_mers(SAMPLE_SEQUENCE, K)
print(f"\nExtracted K-mers: {extracted}")

# 5b. Run vectorization
feature_vector = vectorize_sequence(SAMPLE_SEQUENCE, K, VOCABULARY)

print(f"\nFeature Vector (Length {len(feature_vector)}):")
print(feature_vector)

# 5c. Optional: Show mapping for clarity (first few elements)
print("\nMapping Example (K-mer: Count, showing where non-present K-mers map to zero):")
for i in range(10):
    k_mer = VOCABULARY[i]
    count = feature_vector[i]
    # Highlight the relevant indices if they are present in the sample
    status = " (PRESENT)" if count > 0 else " (ABSENT)"
    print(f"  Index {i:02d} | {k_mer}: {count}{status}")

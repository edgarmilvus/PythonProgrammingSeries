
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import re
import textwrap

# 1. Define the target DNA sequence (the haystack)
# Using textwrap.dedent for cleaner multi-line string definition in Pythonic code
# The sequence is artificial, containing several instances of the target motif
raw_sequence = """
    CATTGATAGGTCCAGGTACAGGTTCATCGGTAGGTACA
    GGTCCAAGGTTCAGGTCCAGGTTCAGTTAA
"""
# Clean up the sequence by removing whitespace and converting to uppercase
genomic_sequence = "".join(raw_sequence.split()).upper()

# 2. Define the motif pattern using Regular Expressions (RE)
# Target Motif: AGGT followed by ANY single nucleotide (N), followed by CA.
# Pattern: AGGT . CA
# The 'r' prefix creates a raw string, essential for RE patterns.
# The '.' (dot) is a special character meaning "match any character".
motif_pattern = r"AGGT.CA"

print(f"--- Basic Motif Finder Initialization ---")
print(f"Target Sequence Length: {len(genomic_sequence)}")
print(f"Searching for Pattern: {motif_pattern} (AGGT N CA)")
print("-" * 50)

# 3. Use re.findall() to extract all non-overlapping matches
# re.findall is ideal for extracting all occurrences of a pattern.
found_motifs = re.findall(motif_pattern, genomic_sequence)

# 4. Report the results and their indices
if found_motifs:
    print(f"SUCCESS: Found {len(found_motifs)} occurrences.")
    print("Matches found (Motif: Sequence: Index):")
    
    # We use re.finditer() here to get both the match and its index, 
    # which is often more useful in bioinformatics than just the string list.
    for i, match_object in enumerate(re.finditer(motif_pattern, genomic_sequence), 1):
        # match_object.group(0) returns the full matched string
        # match_object.start() returns the starting index (0-based)
        print(f"  {i}. {match_object.group(0)} (Starts at index {match_object.start()})")

    print("-" * 50)
    print(f"Note: The raw list returned by re.findall was: {found_motifs}")

else:
    print("FAILURE: No motifs found in the sequence.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import re

# 1. Homopolymer Check: Match any base (.), followed by itself (\1) 3 or more times.
# Total length of run is 1 + 3 = 4 or more.
HOMOPOLYMER_PATTERN = r"(.)\1{3,}"

# 2. Short Tandem Repeat Check: Match any two bases (..), followed immediately by the same two bases (\1).
TANDEM_REPEAT_PATTERN = r"(..)\1"

print("--- Primer Validation Tool ---")

while True:
    primer = input("Enter DNA primer sequence (A, C, G, T): ").strip().upper()

    if not primer:
        print("Sequence cannot be empty. Try again.")
        continue

    # Validation Check 1: Homopolymer
    homopolymer_match = re.search(HOMOPOLYMER_PATTERN, primer)
    if homopolymer_match:
        run = homopolymer_match.group(0)
        print(f"Failure: Homopolymer run detected. Sequence contains '{run}'.")
        continue

    # Validation Check 2: Tandem Repeat
    tandem_match = re.search(TANDEM_REPEAT_PATTERN, primer)
    if tandem_match:
        repeat = tandem_match.group(0)
        print(f"Failure: Short tandem repeat detected. Sequence contains '{repeat}'.")
        continue

    # Success Condition
    print(f"\nSUCCESS! Primer '{primer}' passes all validation checks.")
    break



#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import re

# 1. Define the Pattern: (G A [T or C] A) [N]{1,5} ([G or C]{3,})
# Group 1: (GA[TC]A) - Core Motif
# Spacer: [ACGT]{1,5} - 1 to 5 arbitrary bases (not captured)
# Group 2: ([GC]{3,}) - GC-rich block (at least 3 G/C)
TFBS_PATTERN = r"(GA[TC]A)[ACGT]{1,5}([GC]{3,})"

promoter_sequence = "ATGGATAGATCCGGCCTAGCATACAGACAGGGGGTAACGGGAATAGATTGCCCCGATGA"

# 2. Extraction using re.findall. Since the pattern has two capturing groups,
# findall returns a list of tuples, where each tuple contains the captured elements.
matches = re.findall(TFBS_PATTERN, promoter_sequence)

# 3. Reporting
print("--- TFBS Complex Motif Matches ---")
if not matches:
    print("No matches found.")
else:
    for core_motif, gc_block in matches:
        print(f"Core TFBS Found: {core_motif}")
        print(f"Associated GC Block: {gc_block}")
        print("-" * 20)


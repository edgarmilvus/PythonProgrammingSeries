
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import re
import io # Used here for simulation purposes only

def motif_miner_EAFP(filepath: str, patterns_list: list) -> dict:
    """
    Mines a sequence file for multiple motifs using EAFP for file handling (robustness)
    and iteration for pattern testing (DRY).
    """
    results = {}
    sequence_content = ""

    # EAFP Implementation for File Handling
    try:
        # --- START Simulation Block ---
        # In a real scenario, this would read the actual file path.
        if filepath == "sequences.txt":
            # Simulate reading the content of the file
            sequence_content = "ATGGACTATAAGGTACCCGATGCATATATAGGCCTAGTAGGCTATATAATAGGTAC"
        else:
            # Raise an error if the path is not the expected mock path
            raise FileNotFoundError(f"Cannot find file: {filepath}")
        # --- END Simulation Block ---
        
        # If using a real file:
        # with open(filepath, 'r') as f:
        #     sequence_content = f.read().strip()
            
    except FileNotFoundError:
        print(f"Error: File '{filepath}' not found. Returning empty results.")
        return {}
    except IOError as e:
        print(f"Error reading file '{filepath}': {e}. Returning empty results.")
        return {}

    # DRY Implementation for Pattern Testing
    for pattern in patterns_list:
        try:
            # Use re.findall to get all non-overlapping matches
            matches = re.findall(pattern, sequence_content)
            
            # Note: If the pattern contains capturing groups, findall returns only the captured groups.
            # If the pattern contains no capturing groups, findall returns the full match strings.
            results[pattern] = matches
            
        except re.error as e:
            # Handle cases where the provided regex pattern is invalid
            print(f"Warning: Invalid regex pattern '{pattern}'. Skipping. Error: {e}")
            results[pattern] = []
            
    return results

# Test Case Setup
patterns_to_test = [
    r"TATA(A+)",  # TATA box variants (Captures the A's)
    r"GC[AT]G",   # Simple motif (No capturing groups, returns full match)
    r"A[CAG]T"    # IUPAC ambiguity (R=A or G, explicit [CAG] used)
]

# 1. Successful Run
results_success = motif_miner_EAFP("sequences.txt", patterns_to_test)
print("\n--- Successful Run Results ---")
print(results_success)

# 2. EAFP Failure Test
results_failure = motif_miner_EAFP("nonexistent_file.txt", patterns_to_test)
print("\n--- EAFP Failure Results ---")
print(results_failure)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import re
from collections import namedtuple, defaultdict
import random

# --- 1. Constants and Data Structures ---

# IUPAC ambiguity codes mapped to their corresponding regex character classes
IUPAC_MAP = {
    'A': 'A', 'C': 'C', 'G': 'G', 'T': 'T',
    'R': '[AG]',  # Purine
    'Y': '[CT]',  # Pyrimidine
    'S': '[GC]',  # Strong
    'W': '[AT]',  # Weak
    'K': '[GT]',  # Keto
    'M': '[AC]',  # Amino
    'B': '[CGT]', # Not A
    'D': '[AGT]', # Not C
    'H': '[ACT]', # Not G
    'V': '[ACG]', # Not T
    'N': '[ACGT]' # Any base
}

# Define a structure to hold motif finding results
MotifHit = namedtuple('MotifHit', ['motif_name', 'start', 'end', 'sequence', 'is_palindrome'])

# --- 2. Helper Functions for Sequence Manipulation ---

def reverse_complement(sequence: str) -> str:
    """Calculates the reverse complement of a DNA sequence."""
    complement_map = str.maketrans('ACGTacgtRYMKrymkBDHVbdhv', 'TGCAtgcaYRKMyrkmVHDBvhdb')
    return sequence.translate(complement_map)[::-1]

def is_palindromic(sequence: str) -> bool:
    """Checks if a sequence is palindromic (matches its reverse complement)."""
    return sequence == reverse_complement(sequence)

def iupac_to_regex(iupac_motif: str) -> str:
    """
    Converts an IUPAC consensus sequence into a valid Python regular expression pattern.
    Example: 'ATGWCR' -> 'A[T][G][A|T]C[A|G]' (simplified to A T G [AT] C [AG])
    """
    pattern_parts = [IUPAC_MAP.get(base.upper(), base) for base in iupac_motif]
    return "".join(pattern_parts)

# --- 3. Core Motif Finding and Filtering Logic ---

def find_and_filter_motifs(genomic_sequence: str, target_motifs: dict, min_spacing: int = 15) -> dict:
    """
    Searches a genomic sequence for multiple motifs, compiles results,
    and applies spatial filtering to remove hits too close together.

    Args:
        genomic_sequence: The large DNA string to search.
        target_motifs: Dictionary {name: IUPAC_sequence}.
        min_spacing: Minimum base pairs required between the end of one hit and the start of the next.

    Returns:
        A dictionary mapping motif names to a list of filtered MotifHit objects.
    """
    all_hits = defaultdict(list)
    
    # Pre-compile all regex patterns for maximum efficiency
    compiled_patterns = {
        name: re.compile(iupac_to_regex(motif), re.IGNORECASE)
        for name, motif in target_motifs.items()
    }

    # First Pass: Find all raw matches using re.finditer
    for name, pattern in compiled_patterns.items():
        # Using re.finditer is crucial as it yields match objects
        # containing start/end positions, which 'findall' does not provide directly.
        for match in pattern.finditer(genomic_sequence):
            start, end = match.span()
            sequence = match.group().upper()
            
            hit = MotifHit(
                motif_name=name,
                start=start,
                end=end,
                sequence=sequence,
                is_palindrome=is_palindromic(sequence)
            )
            all_hits[name].append(hit)

    # Second Pass: Apply Spatial Filtering (Crucial Post-Processing Step)
    filtered_results = defaultdict(list)

    for name, hits in all_hits.items():
        # Sort hits by start position to ensure sequential filtering
        hits.sort(key=lambda x: x.start)
        
        last_end = -min_spacing # Initialize far away
        
        for hit in hits:
            # Check the spatial constraint: Is the current hit's start position 
            # sufficiently far from the end of the previous accepted hit?
            if hit.start >= last_end + min_spacing:
                filtered_results[name].append(hit)
                last_end = hit.end # Update the boundary for the next check

    return filtered_results

# --- 4. Execution and Demonstration ---

if __name__ == "__main__":
    
    # Generate a long, random genomic sequence (10,000 bases)
    bases = ['A', 'C', 'G', 'T']
    GENOME_SECTION = "".join(random.choices(bases, k=10000))

    # Define common biological motifs using IUPAC codes
    # Example 1: TATA box variant (promoter element)
    # Example 2: E-box variant (MyoD binding site)
    # Example 3: EcoRI restriction site (palindromic)
    TARGET_MOTIFS = {
        "TATA_Variant": "TATAAW",
        "E_Box_Variant": "CANNTG",
        "EcoRI_Site": "GAATTC",
        "Zinc_Finger_Site": "GKRV" 
    }

    MINIMUM_SPACING_BP = 20

    print("--- Genomic Motif Mining Simulation ---")
    print(f"Searching {len(GENOME_SECTION):,} bases for {len(TARGET_MOTIFS)} motifs.")
    print(f"Applying minimum spacing constraint: {MINIMUM_SPACING_BP} bp.\n")

    # Execute the main function
    results = find_and_filter_motifs(GENOME_SECTION, TARGET_MOTIFS, MINIMUM_SPACING_BP)

    # Output Results
    total_filtered_hits = 0
    for name, hits in results.items():
        total_filtered_hits += len(hits)
        print(f"Motif: {name} (IUPAC: {TARGET_MOTIFS[name]})")
        print(f"  Regex Pattern Used: {iupac_to_regex(TARGET_MOTIFS[name])}")
        print(f"  Found {len(hits)} filtered instances.")
        
        # Print a sample of the first three hits
        for i, hit in enumerate(hits[:3]):
            pal_status = "P" if hit.is_palindrome else "NP"
            print(f"    [{i+1}] Pos: {hit.start}-{hit.end} | Seq: {hit.sequence} ({pal_status})")
        
        if len(hits) > 3:
            print("    ...")
        print("-" * 40)

    print(f"\nTotal filtered hits across all motifs: {total_filtered_hits}")


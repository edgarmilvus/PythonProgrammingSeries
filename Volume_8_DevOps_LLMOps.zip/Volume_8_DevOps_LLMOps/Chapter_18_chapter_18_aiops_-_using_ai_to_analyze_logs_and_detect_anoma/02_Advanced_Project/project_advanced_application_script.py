
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import abc
import os
import time
import random
import logging
import numpy as np
from typing import List, Dict

# --- 1. Configuration and Setup ---
LOG_STREAM_SIZE = 5  # Number of logs processed per batch
ANOMALY_THRESHOLD = 0.85  # Score above which an anomaly is considered critical
# Setting an Environment Variable crucial for the remediation action
os.environ['K8S_NAMESPACE'] = 'prod-api-service-v1'

# Configure basic logging for pipeline output
logging.basicConfig(level=logging.INFO, format='[AIOps] %(levelname)s: %(message)s')

# --- 2. Abstract Base Class for Pipeline Stages (Standardization via ABC) ---
class AIOpsStage(abc.ABC):
    """
    Abstract Base Class enforcing a standard interface for all AIOps components. 
    This ensures pipeline modularity and maintainability.
    """
    
    @abc.abstractmethod
    def process(self, data):
        """Processes the input data and returns the result."""
        pass

# --- 3. Log Ingestion and Feature Engineering (Vectorization/Embeddings) ---
class LogVectorizer(AIOpsStage):
    """
    Simulates the log standardization, parsing, and conversion to dense vectors 
    (embeddings) using NLP techniques (like BERT or FastText).
    """
    
    def __init__(self):
        # Mock dictionary mapping common log templates to base embedding vectors
        self.template_vectors: Dict[str, np.ndarray] = {
            "Request served successfully": np.array([0.1, 0.2, 0.1, 0.05]),
            "Database connection error": np.array([0.9, 0.8, 0.9, 0.95]), # High magnitude vector
            "Service heartbeat OK": np.array([0.05, 0.05, 0.05, 0.01]),
            "High memory usage warning": np.array([0.5, 0.6, 0.7, 0.4]),
        }

    def process(self, log_entry: str) -> np.ndarray:
        """Finds the log template and introduces slight noise to simulate real-world variability."""
        for template, base_vector in self.template_vectors.items():
            if template in log_entry:
                # Add Gaussian noise (simulating variability in log parameters/timestamps)
                noise = np.random.normal(0, 0.03, base_vector.shape)
                return base_vector + noise
        
        # Default vector for unknown or unclassified logs
        logging.warning(f"Unclassified log template encountered: {log_entry[:20]}...")
        return np.array([0.3, 0.3, 0.3, 0.3])

# --- 4. Anomaly Detection (Simulated Deep Learning Model) ---
class AnomalyDetector(AIOpsStage):
    """
    Simulates a time-series deep learning model (e.g., an LSTM Autoencoder) 
    trained on normal log vector sequences, calculating an anomaly score (reconstruction error).
    """
    
    def __init__(self):
        # In a real scenario, the model weights would be loaded here.
        logging.info("Anomaly Detector initialized. Deep Learning Model weights loaded.")

    def process(self, vector: np.ndarray) -> float:
        """
        Calculates the anomaly score. We use the vector's L2 norm as a proxy for the 
        reconstruction error: vectors far from the 'normal' cluster have higher scores.
        """
        # Calculate the L2 norm (Euclidean distance from origin, proxy for deviation)
        magnitude = np.linalg.norm(vector)
        
        # Normalize magnitude to a score between 0 and 1, assuming normal vectors cluster near 0.1-0.3
        # We cap the score at 1.0
        score = min(1.0, magnitude / 1.7) 
        return score

# --- 5. Automated Remediation (Self-Healing Infrastructure) ---
class RemediationEngine(AIOpsStage):
    """
    Triggers automated, self-healing actions based on critical anomaly scores, 
    implementing the final loop closure in the AIOps pipeline.
    """
    
    def process(self, anomaly_score: float, log_context: str) -> bool:
        """Checks if the score exceeds the critical threshold and initiates action."""
        if anomaly_score >= ANOMALY_THRESHOLD:
            logging.critical(f"CRITICAL ANOMALY DETECTED (Score: {anomaly_score:.3f}).")
            logging.critical(f"Context: {log_context[:50]}...")
            self._trigger_rollback()
            return True
        return False

    def _trigger_rollback(self):
        """Simulates initiating a Kubernetes self-healing action using Environment Variables."""
        k8s_ns = os.environ.get('K8S_NAMESPACE', 'default')
        if k8s_ns == 'default':
             logging.warning("K8S_NAMESPACE not set. Using 'default'.")
             
        logging.warning(f"Executing self-healing action: Triggering immediate deployment rollback in namespace {k8s_ns}.")
        # Real-world implementation would use subprocess or k8s client library:
        # subprocess.run(["kubectl", "rollout", "undo", f"-n {k8s_ns}", "deployment/api-service"])
        time.sleep(0.5) 
        logging.info("Rollback command successfully initiated. System stabilization underway.")

# --- 6. Orchestration and Simulation ---
def generate_simulated_logs(is_failing: bool) -> List[str]:
    """Generates a batch of logs, injecting a critical failure log if requested."""
    base_logs = [
        "Request served successfully",
        "Service heartbeat OK",
        "Client authentication successful"
    ]
    
    logs = random.choices(base_logs, k=LOG_STREAM_SIZE - 1)
    
    if is_failing:
        # Inject the critical failure log that generates a high anomaly score
        logs.append("Database connection error: Timeout occurred on primary replica.")
    else:
        logs.append(random.choice(base_logs))
        
    return logs

def run_aiops_pipeline(logs: List[str]):
    """Orchestrates the sequential AIOps pipeline stages."""
    vectorizer = LogVectorizer()
    detector = AnomalyDetector()
    remediator = RemediationEngine()
    
    logging.info(f"Processing batch of {len(logs)} logs.")
    
    for i, log in enumerate(logs):
        logging.debug(f"Processing Log {i+1}: {log[:40]}...")
        
        # Stage 1: Standardization & Feature Engineering
        vector = vectorizer.process(log)
        
        # Stage 2: Anomaly Detection
        score = detector.process(vector)
        
        # Stage 3: Remediation/Action
        remediated = remediator.process(score, log)
        
        if remediated:
            logging.info("--- Pipeline halted by self-healing action. Remediation initiated. ---")
            return

# --- Execution ---
if __name__ == "__main__":
    logging.info("="*60)
    logging.info("AIOps Simulation Start: Monitoring Healthy Infrastructure")
    logging.info("="*60)
    run_aiops_pipeline(generate_simulated_logs(is_failing=False))
    
    print("\n" + "#"*60 + "\n")
    
    logging.info("="*60)
    logging.info("AIOps Simulation Start: Injecting Critical Failure Anomaly")
    logging.info("="*60)
    # Simulate a sudden influx of critical errors that should trigger remediation
    run_aiops_pipeline(generate_simulated_logs(is_failing=True))

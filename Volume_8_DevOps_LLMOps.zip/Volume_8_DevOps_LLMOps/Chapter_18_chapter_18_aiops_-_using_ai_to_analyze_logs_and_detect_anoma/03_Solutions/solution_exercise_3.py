
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from typing import Dict, Any

class RemediationOrchestrator:
    """
    Interprets AIOps alerts and triggers automated self-healing actions.
    Must use dict.get() for robust parameter retrieval.
    """
    
    def trigger_rollback(self, deployment_name: str):
        """Simulates initiating a code rollback."""
        print(f"[ACTION] Initiating Rollback for deployment: {deployment_name}")
        print("         Status: Rollback command sent to Kubernetes API.")

    def adjust_scaling(self, deployment_name: str, target_replicas: int):
        """Simulates adjusting the replica count for a service."""
        print(f"[ACTION] Adjusting Scaling for deployment: {deployment_name}")
        print(f"         Status: Setting replica count to {target_replicas}.")

    def execute_remediation(self, alert_payload: dict):
        """
        Main logic to parse payload and execute action safely.
        """
        print(f"\n--- Processing Alert (Severity: {alert_payload.get('severity', 'UNKNOWN')}) ---")
        
        # Safely retrieve the action type, defaulting to 'NO_ACTION'
        action_type = alert_payload.get('action_type', 'NO_ACTION')

        if action_type == 'ROLLBACK':
            # Safely retrieve target deployment name, default if missing
            deployment = alert_payload.get('target_deployment', 'unknown-service-for-rollback')
            self.trigger_rollback(deployment)
            
        elif action_type == 'SCALE_ADJUST':
            # Safely retrieve target deployment name
            deployment = alert_payload.get('target_deployment', 'unknown-service-for-scaling')
            
            # Safely retrieve target replicas, defaulting to 3 (a safe standard scale)
            # Note: The default value must match the expected type (int)
            replicas = alert_payload.get('target_replicas', 3)
            
            # Ensure replicas is an integer before passing to the action
            if not isinstance(replicas, int):
                print(f"[WARNING] Invalid replica count '{replicas}' received. Defaulting to 3.")
                replicas = 3
                
            self.adjust_scaling(deployment, replicas)
            
        else:
            print(f"[INFO] Action type '{action_type}' received. No automated remediation triggered.")

# Example Alert Payloads (simulating inconsistent data):
ALERT_1_ROLLBACK = {
    'action_type': 'ROLLBACK',
    'severity': 'CRITICAL',
    'target_deployment': 'api-gateway-v2'
}

ALERT_2_SCALE_MISSING_REPLICAS = {
    'action_type': 'SCALE_ADJUST',
    'severity': 'MAJOR',
    'target_deployment': 'data-processor'
    # target_replicas key is missing
}

ALERT_3_MISSING_ALL = {
    'severity': 'MINOR',
    'source': 'log-parser'
    # action_type and targets are missing
}


orchestrator = RemediationOrchestrator()
orchestrator.execute_remediation(ALERT_1_ROLLBACK)
orchestrator.execute_remediation(ALERT_2_SCALE_MISSING_REPLICAS)
orchestrator.execute_remediation(ALERT_3_MISSING_ALL)

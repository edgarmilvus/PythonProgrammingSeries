
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, RepeatVector, TimeDistributed
from typing import List

# Set random seeds for reproducibility in simulation
np.random.seed(42)
tf.random.set_seed(42)

class LSTMAnomalyDetector:
    """
    An LSTM Autoencoder designed for multivariate time-series anomaly detection.
    """
    def __init__(self, sequence_length: int, n_features: int):
        self.sequence_length = sequence_length
        self.n_features = n_features
        self.threshold = None
        self.model = self._build_model()

    def _build_model(self):
        """Defines the LSTM Autoencoder architecture."""
        model = Sequential([
            # Encoder
            LSTM(64, activation='relu', input_shape=(self.sequence_length, self.n_features), return_sequences=False),
            RepeatVector(self.sequence_length),
            # Decoder
            LSTM(64, activation='relu', return_sequences=True),
            TimeDistributed(Dense(self.n_features))
        ])
        model.compile(optimizer='adam', loss='mse')
        return model

    def create_sequences(self, data: np.ndarray) -> np.ndarray:
        """Converts flat time-series data into overlapping sequences (windows)."""
        X = []
        for i in range(len(data) - self.sequence_length + 1):
            X.append(data[i:i + self.sequence_length])
        return np.array(X)

    def train_model(self, X_train_sequences: np.ndarray, epochs=50):
        """Implementation of the training loop."""
        print(f"Training LSTM Autoencoder on {X_train_sequences.shape[0]} sequences...")
        # X_train is used as both input and target (Autoencoder)
        self.model.fit(X_train_sequences, X_train_sequences, 
                       epochs=epochs, batch_size=32, verbose=0)
        print("Training complete.")

    def calculate_threshold(self, X_train_sequences: np.ndarray):
        """Determines the anomaly threshold based on training reconstruction errors (99th percentile)."""
        
        # 1. Predict (reconstruct) the training data
        X_pred = self.model.predict(X_train_sequences, verbose=0)
        
        # 2. Calculate the Mean Squared Error (MSE) for each sequence
        # MSE = mean(square(actual - predicted))
        errors = np.mean(np.square(X_train_sequences - X_pred), axis=(1, 2))
        
        # 3. Set the threshold at the 99th percentile of training errors
        self.threshold = np.percentile(errors, 99)
        print(f"Calculated Anomaly Threshold (99th percentile of training MSE): {self.threshold:.6f}")

    def predict_anomaly(self, X_new_sequence: np.ndarray) -> bool:
        """
        Checks if the reconstruction error of the new sequence exceeds the threshold.
        """
        if self.threshold is None:
            raise ValueError("Threshold must be calculated before prediction.")

        # Ensure input is correctly shaped (1, sequence_length, n_features)
        X_input = X_new_sequence.reshape(1, self.sequence_length, self.n_features)
        
        # Reconstruct the sequence
        X_reconstructed = self.model.predict(X_input, verbose=0)
        
        # Calculate the reconstruction error (Anomaly Score)
        error = np.mean(np.square(X_input - X_reconstructed))
        
        is_anomaly = error > self.threshold
        
        print(f"--- Prediction --- Anomaly Score: {error:.6f} | Anomaly Detected: {is_anomaly}")
        return is_anomaly

# --- Simulation Setup ---
SEQUENCE_LENGTH = 10  # 10 time steps (e.g., 10 minutes)
N_FEATURES = 3        # 3 critical log cluster IDs (DB Error, Auth Fail, High Latency)
TOTAL_HISTORY = 500   # 500 minutes of historical data

# 1. Generate Simulated Normal Data (low, stable counts)
normal_data = np.random.randint(0, 5, size=(TOTAL_HISTORY, N_FEATURES)).astype(np.float32)
X_train_sequences = LSTMAnomalyDetector().create_sequences(normal_data)

# 2. Generate Simulated Anomalous Data (sudden spike)
anomaly_data_spike = np.random.randint(20, 50, size=(SEQUENCE_LENGTH, N_FEATURES)).astype(np.float32)

# 3. Initialize and Train
detector = LSTMAnomalyDetector(SEQUENCE_LENGTH, N_FEATURES)
detector.train_model(X_train_sequences, epochs=5) # Reduced epochs for fast simulation
detector.calculate_threshold(X_train_sequences)

# 4. Test Normal Sequence
normal_test_sequence = X_train_sequences[0]
print("\nTesting Normal Sequence:")
detector.predict_anomaly(normal_test_sequence)

# 5. Test Anomalous Sequence
print("\nTesting Anomalous Sequence (High Spike):")
detector.predict_anomaly(anomaly_data_spike)

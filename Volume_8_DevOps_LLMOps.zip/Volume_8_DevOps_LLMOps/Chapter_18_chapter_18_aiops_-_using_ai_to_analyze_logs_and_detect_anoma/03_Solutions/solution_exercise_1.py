
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import re
import time
from typing import List, Dict

class LogTemplateGenerator:
    """
    Manages the mapping of raw log lines to standardized templates and cluster IDs.
    Uses regex masking for variable components.
    """
    # Regex to identify and mask common variable patterns:
    # 1. Timestamps/Dates (handled implicitly by input format, but good to know)
    # 2. IP Addresses (e.g., 192.168.1.5)
    # 3. UUIDs/Hex sequences (e.g., 5a2b-c4d3-e6f7)
    # 4. Large numerical sequences (e.g., User 1001)
    VARIABLE_REGEX = re.compile(
        r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b'  # IP addresses
        r'|(?:\w{4}-){2,}\w{4}'               # UUID-like strings
        r'|\b\d+\b'                           # General numbers (e.g., User IDs, ports)
    )
    TIMESTAMP_REGEX = re.compile(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}')

    def __init__(self):
        # Maps masked template string -> cluster_id
        self.templates: Dict[str, int] = {}
        self.next_cluster_id = 1

    def _mask_variables(self, log_line: str) -> str:
        """Replaces variable parts of the log line with the <*> token."""
        # 1. Remove timestamp for cleaner template matching
        match = self.TIMESTAMP_REGEX.search(log_line)
        if match:
            log_content = log_line[match.end():].strip()
        else:
            log_content = log_line

        # 2. Replace variables with the <*> token
        masked_template = self.VARIABLE_REGEX.sub(r'<*>', log_content)
        # Clean up multiple consecutive <*> tokens (e.g., if a number and IP are adjacent)
        masked_template = re.sub(r'(<*>)\s*(<*>)', r'\1', masked_template).strip()
        
        return masked_template

    def process_log(self, log_line: str) -> dict:
        """
        Tokenizes the log, finds the template, and returns the structured feature.
        """
        # Extract timestamp (required for time-series analysis later)
        timestamp_match = self.TIMESTAMP_REGEX.search(log_line)
        timestamp = timestamp_match.group(0) if timestamp_match else str(time.time())

        # Generate the standardized template
        masked_template = self._mask_variables(log_line)

        # Check if the template exists (clustering)
        if masked_template not in self.templates:
            # New template found, assign new cluster ID
            cluster_id = self.next_cluster_id
            self.templates[masked_template] = cluster_id
            self.next_cluster_id += 1
        else:
            # Existing template, retrieve cluster ID
            cluster_id = self.templates[masked_template]

        # Return the structured feature output
        return {
            'timestamp': timestamp,
            'cluster_id': cluster_id,
            'template': masked_template
        }

# Example execution:
RAW_LOGS = [
    "2023-10-26 10:01:15 [INFO] User 1001 accessed /api/v1/data endpoint.",
    "2023-10-26 10:01:16 [ERROR] Failed to connect to DB at 192.168.1.5: Connection timed out.",
    "2023-10-26 10:01:17 [INFO] User 2003 accessed /api/v1/data endpoint.",
    "2023-10-26 10:01:18 [WARNING] High latency detected for request ID 5a2b-c4d3-e6f7.",
    "2023-10-26 10:01:19 [ERROR] Failed to connect to DB at 10.0.0.12: Connection refused."
]

generator = LogTemplateGenerator()
structured_features = [generator.process_log(log) for log in RAW_LOGS]

# Print results for verification
print("--- Structured Features Output ---")
for feature in structured_features:
    print(f"ID: {feature['cluster_id']}, Template: {feature['template']}")



#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import abc
from typing import Any, List

# 1. Define Abstract Base Classes (ABCs)

class LogIngestionInterface(abc.ABC):
    @abc.abstractmethod
    def ingest_raw_data(self, data: list):
        """Processes raw log input."""
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def status(self) -> str:
        """Current status of the ingestion pipeline."""
        raise NotImplementedError

class FeatureExtractionInterface(abc.ABC):
    @abc.abstractmethod
    def extract_features(self, structured_data: list) -> list:
        """Converts structured logs into numerical features (e.g., time-series counts)."""
        raise NotImplementedError

    @abc.abstractmethod
    def load_templates(self, path: str):
        """Loads pre-trained log templates or dictionary mappings."""
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def templates_loaded(self) -> bool:
        """Indicates if template mapping is ready."""
        raise NotImplementedError

class AnomalyModelInterface(abc.ABC):
    @abc.abstractmethod
    def load_model(self, path: str):
        """Loads pre-trained machine learning model weights (e.g., Keras/TensorFlow)."""
        raise NotImplementedError

    @abc.abstractmethod
    def predict(self, features) -> Any:
        """Runs anomaly detection prediction on incoming features."""
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def model_loaded(self) -> bool:
        """Indicates if the ML model is fully loaded and ready."""
        raise NotImplementedError


# 2. Implementation Constraint
class ProductionFeatureExtractor(FeatureExtractionInterface):
    """
    Concrete implementation of the feature extraction stage.
    """
    def __init__(self):
        self._templates_loaded = False
        print("Feature Extractor initialized.")

    def extract_features(self, structured_data: list) -> list:
        # Simulation of feature extraction logic
        return [len(structured_data)] 

    def load_templates(self, path: str):
        # Simulation of loading a large template dictionary
        print(f"Loading templates from {path}...")
        self._templates_loaded = True
        print("Templates loaded successfully.")

    @property
    def templates_loaded(self) -> bool:
        return self._templates_loaded

# Simulation of Anomaly Model (must adhere to its ABC)
class ProductionAnomalyModel(AnomalyModelInterface):
    def __init__(self):
        self._model_loaded = False
    
    def load_model(self, path: str):
        # Simulation of loading large ML model weights
        print(f"Loading anomaly model from {path}...")
        self._model_loaded = True
        print("Model loaded successfully.")

    def predict(self, features) -> Any:
        return True # Simulate prediction result

    @property
    def model_loaded(self) -> bool:
        return self._model_loaded


# 3. Gunicorn Readiness Check Simulation
def check_readiness(feature_extractor: ProductionFeatureExtractor, anomaly_model: ProductionAnomalyModel) -> bool:
    """
    Determines if the AIOps service is ready for production traffic (Gunicorn check).
    Requires both the feature templates and the ML model weights to be loaded.
    """
    is_ready = feature_extractor.templates_loaded and anomaly_model.model_loaded
    
    if is_ready:
        print("[READINESS CHECK] SUCCESS: All critical components loaded.")
    else:
        print(f"[READINESS CHECK] FAILED: Templates Loaded: {feature_extractor.templates_loaded}, Model Loaded: {anomaly_model.model_loaded}")
        
    return is_ready

# --- Execution Simulation ---
FE = ProductionFeatureExtractor()
AM = ProductionAnomalyModel()

# 1. Initial State Check (Should Fail)
print("\n--- Initial State ---")
check_readiness(FE, AM) 

# 2. Load Components
print("\n--- Loading Components ---")
FE.load_templates("config/templates.json")
AM.load_model("models/lstm_autoencoder.h5")

# 3. Final State Check (Should Pass)
print("\n--- Final State ---")
check_readiness(FE, AM)

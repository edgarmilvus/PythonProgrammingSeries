
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import asyncio
import time
import re
from typing import AsyncGenerator, Dict, Any, List, Tuple

# --- 1. Simulated Log Source and Asynchronous Ingestion Manager ---

class LogStreamSimulator:
    """
    An Asynchronous Context Manager simulating a connection to a distributed log stream
    (e.g., Kafka topic, S3 stream, or Elasticsearch connection).
    This ensures resources are cleaned up safely, even if processing fails.
    """
    def __init__(self, log_lines: List[str]):
        self._lines = log_lines
        self._index = 0
        print("--- LogStreamSimulator: Initializing connection. ---")

    async def __aenter__(self) -> AsyncGenerator[str, None]:
        """
        Defines the setup logic when entering the 'async with' block.
        Simulates establishing the network connection.
        """
        await asyncio.sleep(0.01) # Simulate network latency
        print("--- LogStreamSimulator: Connection established. ---")
        return self._log_generator()

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """
        Defines the cleanup logic when exiting the 'async with' block.
        Simulates closing the connection.
        """
        await asyncio.sleep(0.01)
        if exc_type is not None:
            # Handle exceptions that occurred within the 'async with' block
            print(f"--- LogStreamSimulator: Connection closed due to exception: {exc_val} ---")
        else:
            print("--- LogStreamSimulator: Connection cleanly closed. ---")
        return False # Do not suppress exceptions

    async def _log_generator(self) -> AsyncGenerator[str, None]:
        """
        The asynchronous generator that yields log lines one by one.
        """
        while self._index < len(self._lines):
            line = self._lines[self._index]
            self._index += 1
            # Simulate real-time log arrival delay, crucial for asynchronous processing
            await asyncio.sleep(0.005) 
            yield line

# --- 2. Log Standardization (Parsing) Configuration ---

# Regex to capture the standard log format: [TIMESTAMP] [SERVICE] [LEVEL] MESSAGE
LOG_PATTERN = re.compile(r"^\[(.*?)\] \[(.*?)\] \[(.*?)\] (.*)$")
# Map human-readable log levels to numerical, ordinal features
LEVEL_MAP = {"INFO": 0, "WARNING": 1, "ERROR": 2, "CRITICAL": 3}

def parse_log_line(log_line: str) -> Dict[str, Any]:
    """
    Standardizes a raw log line into a structured dictionary.
    This step converts unstructured text into predictable key-value pairs.
    """
    match = LOG_PATTERN.match(log_line)
    if not match:
        # If the log format is unexpected, mark it as invalid
        return {"raw": log_line, "valid": False}

    # Unpack the captured groups from the regex match
    timestamp_str, service, level, message = match.groups()
    
    return {
        "valid": True,
        "timestamp": timestamp_str,
        "service": service,
        "level_str": level,
        "message": message,
        # Use the numerical mapping for ML processing
        "level_code": LEVEL_MAP.get(level.upper(), -1) 
    }

# --- 3. Feature Extraction (Vectorization) Configuration ---

# Keywords highly indicative of operational anomalies or failures
ANOMALY_KEYWORDS = ["timeout", "denied", "exception", "failed", "OOM", "unauthorized"]

def extract_log_features(structured_log: Dict[str, Any]) -> Tuple[str, List[float]]:
    """
    Transforms a structured log into a numerical feature vector suitable for ML models.
    This is the output required by anomaly detection algorithms.
    """
    # Handle logs that failed standardization
    if not structured_log.get("valid"):
        # Return a zero vector for invalid logs, allowing the ML model to learn that 
        # malformed logs might themselves be an anomaly.
        return "INVALID_SERVICE", [0.0] * (2 + len(ANOMALY_KEYWORDS))

    message = structured_log['message']
    
    # F1: Log Level Encoding (Ordinal Feature)
    feature_level = float(structured_log['level_code'])
    
    # F2: Message Length (Quantitative Feature)
    # Using word count is often more robust than character count for log analysis
    feature_length = float(len(message.split()))
    
    # F3-Fn: Keyword Presence (Binary/Boolean Features)
    keyword_features = []
    for keyword in ANOMALY_KEYWORDS:
        # Check for the presence of the keyword in the message (case-insensitive)
        is_present = 1.0 if keyword.lower() in message.lower() else 0.0
        keyword_features.append(is_present)
        
    # Combine all features into the final vector
    feature_vector = [feature_level, feature_length] + keyword_features
    
    # Return the service name (for context/grouping) and the generated vector
    return structured_log['service'], feature_vector

# --- 4. Orchestration ---

async def main():
    """
    Main pipeline demonstrating asynchronous log ingestion and feature creation.
    """
    # Sample logs, including normal, warning, error, critical, and malformed entries.
    raw_logs = [
        "[2024-10-27 15:00:01] [AuthService] [INFO] User 'alice' logged in successfully.",
        "[2024-10-27 15:00:05] [DBService] [WARNING] Slow query detected (450ms) on session 123.",
        "[2024-10-27 15:00:12] [APIGateway] [ERROR] Connection timeout detected while accessing ExternalAPI.",
        "[2024-10-27 15:00:15] [AuthService] [CRITICAL] Failed to allocate memory (OOM).",
        "[2024-10-27 15:00:20] [DBService] [INFO] Database connection pooled.",
        "This is an intentionally malformed log line that breaks the parser."
    ]

    print(f"\n--- Starting AIOps Log Processing Pipeline for {len(raw_logs)} logs ---\n")
    
    # The 'async with' statement manages the LogStreamSimulator resource
    async with LogStreamSimulator(raw_logs) as log_stream_generator:
        
        feature_dataset: List[Tuple[str, List[float]]] = []
        
        # Asynchronously iterate over the log stream
        async for raw_line in log_stream_generator:
            print(f"-> Ingested: {raw_line[:60]}...")
            
            # Step 1: Standardization (Text -> Dictionary)
            structured_data = parse_log_line(raw_line)
            
            # Step 2: Feature Extraction (Dictionary -> Numerical Vector)
            service, features = extract_log_features(structured_data)
            
            # Store the resulting feature vector for ML training/inference
            feature_dataset.append((service, features))
            
            # Display the result of the transformation
            print(f"   [FEATURES] Service: {service}, Vector: {features}")
            
    print("\n--- Processing Complete. Final Feature Dataset Sample ---")
    # Display the final, structured dataset
    for i, (service, vector) in enumerate(feature_dataset):
        print(f"Log {i+1} ({service}): {vector}")

if __name__ == "__main__":
    # Standard entry point for running asynchronous code
    asyncio.run(main())

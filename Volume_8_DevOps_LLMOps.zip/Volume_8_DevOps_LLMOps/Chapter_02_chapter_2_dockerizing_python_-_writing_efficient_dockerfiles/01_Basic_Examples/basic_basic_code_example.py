
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# app.py: A simple script to demonstrate dependency management and environment variables.
import os
import sys
import requests
from datetime import datetime

# --- Configuration Constants ---
# Define the default URL to check if the environment variable is missing
DEFAULT_URL = "https://httpbin.org/get"
TIMEOUT_SECONDS = 5

def check_service(url: str) -> int:
    """
    Attempts to make a GET request to the specified URL.

    Returns:
        int: The exit code (0 for success, 1 for failure).
    """
    
    # Log the action being taken
    timestamp = datetime.now().isoformat()
    print(f"[{timestamp}] Attempting service health check at: {url}")
    
    try:
        # Set a short timeout suitable for a container health check
        response = requests.get(url, timeout=TIMEOUT_SECONDS)

        # Check for successful HTTP status codes (200-299)
        if 200 <= response.status_code < 300:
            print("SUCCESS: Service reached successfully.")
            # Display a subset of the received data for verification
            try:
                data = response.json()
                print(f"Received JSON keys: {list(data.keys())}")
            except requests.exceptions.JSONDecodeError:
                print("Warning: Response was not valid JSON.")
            return 0  # Success status code
        else:
            # Log the specific failure status
            print(f"FAILURE: Service responded with non-success status code {response.status_code}.")
            return 1  # Failure status code

    # Handle connection errors (DNS failure, timeout, connection refused)
    except requests.exceptions.RequestException as e:
        print(f"CRITICAL ERROR: Failed to connect to service. Details: {e.__class__.__name__}: {e}")
        return 1  # Failure status code
        
    # Handle unexpected runtime errors
    except Exception as e:
        print(f"UNEXPECTED ERROR during execution: {e.__class__.__name__}: {e}")
        return 1

if __name__ == "__main__":
    # Standard container practice: read configuration from environment variables.
    # If TARGET_URL is not set, fall back to the safe default.
    target_url = os.getenv("TARGET_URL", DEFAULT_URL)

    # Execute the core logic and retrieve the exit status.
    exit_code = check_service(target_url)

    # Use sys.exit() to propagate the status code outside the Python process.
    # This exit code is crucial for container orchestration systems (like Kubernetes)
    # to determine if the container task succeeded or failed.
    sys.exit(exit_code)

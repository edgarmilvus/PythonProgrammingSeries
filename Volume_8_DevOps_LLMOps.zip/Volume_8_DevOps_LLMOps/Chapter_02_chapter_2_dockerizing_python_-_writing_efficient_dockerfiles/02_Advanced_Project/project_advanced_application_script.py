
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import argparse
import asyncio
import sys
import time
from pathlib import Path

# Heavy dependencies used only in the 'build' stage
try:
    import pandas as pd
    import numpy as np
    from sklearn.ensemble import RandomForestClassifier
    import joblib
    HEAVY_DEPS_AVAILABLE = True
except ImportError:
    # This block allows the 'run' stage to execute even if heavy deps are not installed
    # mirroring the lightweight runtime image requirement.
    HEAVY_DEPS_AVAILABLE = False
    print("Warning: Heavy dependencies (pandas, sklearn, joblib) not available. 'build' mode will fail.")


# --- Configuration ---
ARTIFACT_DIR = Path("./artifacts")
FEATURE_FILE = ARTIFACT_DIR / "validated_features.pkl"
NUM_SAMPLES = 1000
NUM_FEATURES = 5


async def generate_and_save_features():
    """
    Simulates the heavy, build-time process of generating, validating, and
    serializing complex features and model components.
    Requires heavy libraries (pandas, sklearn).
    """
    if not HEAVY_DEPS_AVAILABLE:
        print("Error: Cannot run 'build' mode. Missing heavy dependencies.")
        sys.exit(1)

    print(f"[{time.strftime('%H:%M:%S')}] Starting heavy feature generation...")
    ARTIFACT_DIR.mkdir(exist_ok=True)

    # 1. Generate synthetic data
    X = np.random.rand(NUM_SAMPLES, NUM_FEATURES)
    y = np.random.randint(0, 2, NUM_SAMPLES)
    
    # 2. Simulate complex feature engineering (e.g., creating a DataFrame)
    df = pd.DataFrame(X, columns=[f'feature_{i}' for i in range(NUM_FEATURES)])
    df['target'] = y
    
    # 3. Simulate model training/validation setup (a heavy computation)
    model = RandomForestClassifier(n_estimators=10, random_state=42)
    model.fit(X, y)
    
    # 4. Combine and serialize necessary artifacts
    validated_data = {
        "metadata": {"timestamp": time.time(), "samples": NUM_SAMPLES},
        "model_params": model.get_params(),
        "feature_means": df.mean().to_dict()
    }
    
    # Use joblib for efficient serialization
    joblib.dump(validated_data, FEATURE_FILE)
    
    print(f"[{time.strftime('%H:%M:%S')}] Success: Features serialized to {FEATURE_FILE.name}")
    print(f"Artifact size: {FEATURE_FILE.stat().st_size / 1024:.2f} KB")


async def load_and_validate_runtime():
    """
    Simulates the lightweight, runtime process.
    Only requires joblib (or standard library) to load the pre-serialized artifact.
    """
    if not FEATURE_FILE.exists():
        print(f"Error: Artifact file not found at {FEATURE_FILE}. Run 'build' first.")
        sys.exit(1)

    print(f"[{time.strftime('%H:%M:%S')}] Starting lightweight runtime check...")

    try:
        # Load the precomputed data using the lightweight joblib runtime dependency
        runtime_data = joblib.load(FEATURE_FILE)
        
        # Perform quick checks based on loaded metadata
        if runtime_data['metadata']['samples'] != NUM_SAMPLES:
            print("Warning: Sample count mismatch.")
            
        print(f"Loaded feature means keys: {list(runtime_data['feature_means'].keys())[:3]}...")
        print(f"Runtime Check OK. Ready to serve.")

        # Simulate continuous operation (e.g., a web server loop)
        while True:
            await asyncio.sleep(5)
            # In a real service, this would be serving requests
            print(f"[{time.strftime('%H:%M:%S')}] Service heartbeat...")
            
    except Exception as e:
        print(f"Runtime loading failed: {e}")
        sys.exit(1)


async def main():
    """Main entry point using argparse to select operation mode."""
    parser = argparse.ArgumentParser(
        description="Feature Validation Service: Build or Run mode."
    )
    parser.add_argument(
        "mode",
        choices=["build", "run"],
        help="Operation mode: 'build' (heavy setup) or 'run' (light serving)."
    )
    args = parser.parse_args()

    # Use TaskGroup for reliable asynchronous execution management (Python 3.11+)
    async with asyncio.TaskGroup() as tg:
        if args.mode == "build":
            # The build phase runs once and exits
            tg.create_task(generate_and_save_features())
            # Exit 0 indicates successful completion of the build phase
            await asyncio.sleep(1) # Ensure task completes before exit
            sys.exit(0) 
            
        elif args.mode == "run":
            # The run phase is designed to loop indefinitely (service)
            tg.create_task(load_and_validate_runtime())


if __name__ == "__main__":
    try:
        # Running the asynchronous main function
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nService shutting down gracefully.")
        sys.exit(0)
    except SystemExit as e:
        # Catch sys.exit(0) from the 'build' phase
        if e.code != 0:
            print(f"\nCritical error during execution (Exit Code {e.code}).")
        sys.exit(e.code)
    except Exception as e:
        print(f"\nAn unexpected error occurred: {e}")
        sys.exit(1)


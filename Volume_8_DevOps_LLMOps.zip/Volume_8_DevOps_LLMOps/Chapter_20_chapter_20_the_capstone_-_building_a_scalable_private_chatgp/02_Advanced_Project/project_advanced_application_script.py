
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import asyncio
import os
import time
from typing import List, Dict, AsyncGenerator

# --- 1. Configuration Constants (EKS/Container Readiness) ---

# Configuration loaded from environment variables, essential for containerization
VECTOR_DB_ENDPOINT = os.getenv("VECTOR_DB_ENDPOINT", "http://vector-db-service:8080")
LLM_API_ENDPOINT = os.getenv("LLM_API_ENDPOINT", "http://llm-inference-service:8081/generate")
SIMULATED_LATENCY_DB = float(os.getenv("SIMULATED_LATENCY_DB", 0.3))
SIMULATED_LATENCY_LLM_CHUNK = float(os.getenv("SIMULATED_LATENCY_LLM_CHUNK", 0.05))

# --- 2. Simulated External I/O Operations ---

async def _retrieve_documents_async(query: str, top_k: int = 5) -> List[Dict]:
    """
    Simulates an asynchronous network call to a vector database (e.g., Pinecone/Weaviate
    running in a separate EKS Service) to fetch relevant documents.
    This is an I/O bound operation.
    """
    start_time = time.time()
    print(f"[{query[:15]}...] Starting retrieval from {VECTOR_DB_ENDPOINT}...")
    
    # Simulate network latency and database processing time
    await asyncio.sleep(SIMULATED_LATENCY_DB)
    
    documents = [
        {"id": f"doc-{i}", "content": f"Relevant context snippet {i} for {query}", "source": f"s3://data/file_{i}.txt"}
        for i in range(top_k)
    ]
    
    print(f"[{query[:15]}...] Retrieval complete. Time: {time.time() - start_time:.3f}s")
    return documents

async def _preprocess_query_async(query: str) -> str:
    """
    Simulates an asynchronous pre-processing step, such as input validation or
    prompt engineering optimization (e.g., calling a small classification model).
    """
    print(f"[{query[:15]}...] Starting asynchronous pre-processing...")
    # Simulate a minor network/CPU delay
    await asyncio.sleep(0.1)
    
    # Basic sanitization/optimization
    processed_query = query.strip()
    print(f"[{query[:15]}...] Pre-processing complete.")
    return processed_query

async def _generate_response_stream(context: str, processed_query: str) -> AsyncGenerator[str, None]:
    """
    Simulates the asynchronous streaming call to the large language model API.
    This mimics how efficient inference services (like VLLM or optimized TGI)
    respond to reduce perceived latency.
    """
    full_prompt = f"Context: {context}\n\nQuery: {processed_query}"
    print(f"[{processed_query[:15]}...] Sending prompt to {LLM_API_ENDPOINT} (Prompt length: {len(full_prompt)})...")
    
    # Simulate chunked, token-by-token streaming
    response_chunks = [
        "The", " answer", " based", " on", " the", " provided", " context", " is", " highly", " relevant", "."
    ]
    
    for chunk in response_chunks:
        await asyncio.sleep(SIMULATED_LATENCY_LLM_CHUNK) # Simulate I/O time between tokens
        yield chunk
    
    print(f"[{processed_query[:15]}...] LLM stream complete.")

# --- 3. The Scalable Inference Orchestrator ---

async def handle_query_inference(query: str, request_id: str):
    """
    The main handler function utilizing asyncio.TaskGroup for highly concurrent I/O.
    This function represents the core logic of the EKS worker pod.
    """
    start_total = time.time()
    print(f"\n--- Request {request_id} received: {query} ---")

    try:
        # Use asyncio.TaskGroup (Python 3.11+) to run independent I/O tasks concurrently
        async with asyncio.TaskGroup() as tg:
            # Task 1: Fetch documents from the Vector DB
            retrieval_task = tg.create_task(_retrieve_documents_async(query))
            
            # Task 2: Pre-process the user query
            preprocess_task = tg.create_task(_preprocess_query_async(query))

        # Await the results from the concurrently running tasks
        retrieved_docs = retrieval_task.result()
        processed_query = preprocess_task.result()

        # Combine retrieved context for the final prompt
        context_str = "\n---\n".join([doc['content'] for doc in retrieved_docs])

        # Step 3: Stream the LLM response (Sequential after RAG context is ready)
        full_response = ""
        async for chunk in _generate_response_stream(context_str, processed_query):
            # In a real application, this chunk would be streamed back to the user via WebSocket/HTTP stream
            print(f"[{request_id}] Stream chunk: {chunk}", end="", flush=True)
            full_response += chunk
        
        print(f"\n--- Request {request_id} Complete. Total Time: {time.time() - start_total:.3f}s ---")
        return {"request_id": request_id, "status": "success", "response": full_response}

    except Exception as e:
        print(f"--- Request {request_id} Failed: {e} ---")
        return {"request_id": request_id, "status": "error", "message": str(e)}

# --- 4. Concurrency Simulation (EKS Load Test) ---

async def main():
    """Simulates multiple concurrent API requests hitting the worker pod."""
    queries = [
        "How do I scale my EKS cluster?",
        "What is the difference between TaskGroup and gather?",
        "Explain the importance of VPC endpoints.",
        "Best practices for Python containerization."
    ]

    tasks = [
        handle_query_inference(q, f"REQ-{i+1}")
        for i, q in enumerate(queries)
    ]

    # Run all inference handlers concurrently
    results = await asyncio.gather(*tasks)
    
    print("\n\n=== Final Results Summary ===")
    for result in results:
        print(f"ID: {result['request_id']}, Status: {result['status']}, Response Length: {len(result['response'])}")


if __name__ == "__main__":
    # Note: On Python 3.7/3.8, use asyncio.run(main()). 
    # For robust production environments, use the modern loop runner.
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("Worker shutting down.")



#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import os
import time
from typing import Optional
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

# --- 1. Define the Application Structure ---
# Initialize the FastAPI application, providing a clear title for documentation.
app = FastAPI(title="Scalable LLM Inference Mock Service")

# --- 2. Define the Request/Response Schema using Pydantic ---
# Structured data models ensure strict type checking and clear API contracts.
class InferenceRequest(BaseModel):
    """Defines the expected input payload for the LLM generation endpoint."""
    prompt: str = Field(..., description="The user query or prompt for the LLM.")
    max_tokens: int = Field(50, ge=1, le=2048, description="Maximum tokens to generate.")

class InferenceResponse(BaseModel):
    """Defines the structured output payload returned by the service."""
    model_id: str = Field(..., description="The specific model identifier used for inference.")
    generated_text: str = Field(..., description="The simulated LLM output.")
    latency_ms: int = Field(..., description="The processing time in milliseconds.")
    instance_id: str = Field(..., description="Unique identifier for the serving instance.")

# --- 3. Load Configuration from Environment Variables ---
# This is the cloud-native method for configuration management.
# os.environ.get() is used to provide safe defaults if the variables are not set.
MODEL_NAME: str = os.environ.get("LLM_MODEL_ID", "default-mock-llm-7b")
# Scaling factor simulates the processing time required for a large model.
# Note the use of int() conversion, which is necessary when reading environment strings.
try:
    INFERENCE_DELAY_MS: int = int(os.environ.get("INFERENCE_DELAY_MS", 150))
except ValueError:
    # Fallback if the environment variable is present but non-numeric
    INFERENCE_DELAY_MS = 150
    print(f"Warning: Invalid INFERENCE_DELAY_MS found. Using default: {INFERENCE_DELAY_MS}ms.")

# A unique identifier for the specific container instance (useful for debugging scaling issues)
INSTANCE_ID: str = os.environ.get("HOSTNAME", os.getpid()) # Use HOSTNAME (K8s) or PID (Local)

# --- 4. The Inference Endpoint ---
@app.post("/api/v1/generate", response_model=InferenceResponse)
async def generate_response(request: InferenceRequest):
    """
    Simulates the core LLM inference process, including input validation and latency calculation.
    """
    start_time = time.time()

    # Input validation: Ensure the prompt is substantial enough.
    if len(request.prompt) < 5:
        raise HTTPException(status_code=400, detail="Prompt must be at least 5 characters long.")

    # Simulate model complexity and workload using the configured delay factor.
    # This delay mimics the time spent on running the RAG pipeline or LLM forward pass.
    # We convert milliseconds to seconds for time.sleep().
    processing_delay_s = (INFERENCE_DELAY_MS / 1000.0)

    # In a real application, this is where the `model.generate()` or RAG chain execution occurs.
    time.sleep(processing_delay_s)

    # Mock the LLM output using the configured model ID
    mock_output = (
        f"Response from {MODEL_NAME} (Instance {INSTANCE_ID}): "
        f"Successfully processed query for {request.max_tokens} tokens. "
        f"Simulated Delay: {processing_delay_s:.3f}s."
    )

    end_time = time.time()
    latency_ms = int((end_time - start_time) * 1000)

    # Return the structured response, including configuration details.
    return InferenceResponse(
        model_id=MODEL_NAME,
        generated_text=mock_output,
        latency_ms=latency_ms,
        instance_id=str(INSTANCE_ID)
    )

# --- 5. Health Check Endpoint (Crucial for Load Balancers/K8s) ---
@app.get("/health")
def health_check():
    """
    Provides a simple endpoint for Kubernetes readiness and liveness probes.
    If this endpoint fails, Kubernetes knows the container is unhealthy.
    """
    return {
        "status": "ok",
        "model_loaded": MODEL_NAME,
        "config_delay_ms": INFERENCE_DELAY_MS,
        "instance": INSTANCE_ID
    }

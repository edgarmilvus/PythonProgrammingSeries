
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import asyncio
from typing import List

# Assuming async vector client library is available...

async def async_lookup_policy(query: str) -> str:
    """Simulates asynchronous lookup for corporate policy documents."""
    # Simulate I/O bound operation (e.g., waiting for vector DB response)
    await asyncio.sleep(0.5)
    return f"Retrieved Policy for: {query}"

async def async_lookup_specs(query: str) -> str:
    """Simulates asynchronous lookup for technical specifications."""
    # Simulate I/O bound operation
    await asyncio.sleep(0.8)
    return f"Retrieved Specs for: {query}"

async def async_retrieve_documents(query: str) -> List[str]:
    """
    Retrieves documents concurrently using asyncio.gather(),
    with conditional execution based on the query.
    """
    tasks = []
    query_lower = query.lower()

    # Conditional Execution: If 'urgent' keyword is present, skip policy lookup
    if "urgent" not in query_lower:
        tasks.append(async_lookup_policy(query))
        
    # Always include technical specifications lookup
    tasks.append(async_lookup_specs(query))
    
    # Execute all tasks concurrently and await the combined results
    # asyncio.gather returns a list of results in the order the tasks were defined
    results = await asyncio.gather(*tasks)
    
    return results

# Example Usage (for testing the logic):
async def main():
    print("--- Standard Query ---")
    standard_results = await async_retrieve_documents("What is the vacation policy?")
    print(f"Standard Results: {standard_results}")

    print("\n--- Urgent Query ---")
    urgent_results = await async_retrieve_documents("I need urgent technical specifications.")
    print(f"Urgent Results: {urgent_results}")

# Run the test (optional in final deployment, but useful for verification)
# if __name__ == "__main__":
#     asyncio.run(main())

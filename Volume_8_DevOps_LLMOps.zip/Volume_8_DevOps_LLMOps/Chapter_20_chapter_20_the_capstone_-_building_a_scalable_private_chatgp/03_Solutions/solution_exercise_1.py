
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# Stage 1: Builder Stage - Install dependencies and compile artifacts
FROM python:3.11-buster AS builder

# Set environment variables for non-interactive installs
ENV PYTHONDONTWRITEBYTECODE 1
ENV PYTHONUNBUFFERED 1

# Install system dependencies needed for compilation (if any)
RUN apt-get update && apt-get install -y --no-install-recommends \
    build-essential \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements and install
WORKDIR /app
COPY requirements.txt .
RUN pip install --upgrade pip
RUN pip install -r requirements.txt --no-cache-dir

# --- Stage 2: Runtime Stage - Minimal image for execution ---
FROM python:3.11-slim-buster AS runtime

# Set environment variables
ENV APP_HOME=/home/appuser/app
WORKDIR ${APP_HOME}

# 1. Create a non-root user and group
RUN groupadd -r appuser && useradd --no-log-init -r -g appuser appuser
RUN mkdir -p ${APP_HOME} && chown -R appuser:appuser ${APP_HOME}

# 2. Copy only necessary artifacts from the builder stage
# Copy installed Python packages (virtual environment)
COPY --from=builder /usr/local/lib/python3.11/site-packages /usr/local/lib/python3.11/site-packages
# Copy application code
COPY . ${APP_HOME}

# 3. Model Weight Handling (Strategy: Assume model weights are pulled from S3/EFS at runtime)
# If weights were baked in, they would be copied here using a specific path:
# COPY --from=builder /model_cache /model_cache

# Ensure the entry point script is executable and uses os.path.join()
# Example startup script (startup.sh) is assumed to exist and handle model path checks.
RUN chmod +x ${APP_HOME}/startup.sh

# 4. Define Non-Root User Execution
USER appuser

# 5. Expose Port and Entrypoint
EXPOSE 8000

# ENTRYPOINT executes pre-flight checks (like model file existence)
ENTRYPOINT ["/home/appuser/app/startup.sh"]

# CMD launches the main process (e.g., Uvicorn for FastAPI)
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# --- 1. Insecure State Analysis (Conceptual) ---
# The line 'value: "HARDCODED_SECRET_12345"' is the vulnerability.

# --- 2. internal-tokens.yaml (New Secret Definition) ---
apiVersion: v1
kind: Secret
metadata:
  name: internal-tokens
type: Opaque
data:
  INTERNAL_SERVICE_TOKEN: SEFSRENPREVEX19TRUNSRVRfMTIzNDU= # Base64 encoded token

# --- 3. secure-deployment.yaml (Refactored Deployment) ---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: llm-inference-service
spec:
  replicas: 3
  selector:
    matchLabels:
      app: llm-inference
  template:
    metadata:
      labels:
        app: llm-inference
      annotations:
        # 4. Zero-Downtime Strategy: Annotation placeholder for triggering rolling update
        # This hash must be calculated based on the content of 'internal-tokens'
        checksum/internal-tokens: "REPLACE_WITH_SECRET_HASH_ON_DEPLOYMENT" 
    spec:
      containers:
      - name: llm-inference-service
        image: my-llm-app:v1.2
        env:
        - name: INTERNAL_SERVICE_TOKEN
          valueFrom: # Secure reference replaces hardcoded value
            secretKeyRef:
              name: internal-tokens
              key: INTERNAL_SERVICE_TOKEN

# --- 4. Zero-Downtime Strategy (Rotation Command) ---
# Command to calculate the hash and patch the deployment:
# SECRET_HASH=$(kubectl get secret internal-tokens -o json | jq -r '.data | to_entries | map(.value) | join("")' | sha256sum | awk '{print $1}')
# kubectl patch deployment llm-inference-service -p "{\"spec\":{\"template\":{\"metadata\":{\"annotations\":{\"checksum/internal-tokens\":\"$SECRET_HASH\"}}}}}"

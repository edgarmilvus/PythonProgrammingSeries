
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# --- 1. llm-license-key.yaml (Secret Definition) ---
# Data is base64 encoded multi-line license key.
apiVersion: v1
kind: Secret
metadata:
  name: llm-license-key
type: Opaque
data:
  license.key: LS0tU1RBUlQgTElDRU5TRS0tLQpMSUNFTlNFLUlELVhZWi0xMjM0NQpFeHBpcmVzOiAyMDI1LTAxLTAxCkNpZ25hdHVyZTogQUJDREVGMDEyMzQ1Njc4OQotLS1FTkQgTElDRU5TRS0tLQo=

# --- 2. license-reader-deployment.yaml (Deployment Definition) ---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: license-reader-deployment
spec:
  replicas: 1
  selector:
    matchLabels:
      app: license-reader
  template:
    metadata:
      labels:
        app: license-reader
    spec:
      # 4. Permissions: Define the volume with restrictive mode (0400 = read-only for owner)
      volumes:
      - name: license-volume
        secret:
          secretName: llm-license-key
          defaultMode: 0400 
      containers:
      - name: license-processor
        image: python:3.9-slim
        command: ["python", "-c"]
        args: 
          - |
            # 3. Python Script Simulation: Efficient Iteration over File Object
            import os
            LICENSE_PATH = '/etc/secrets/license.key'
            print(f"Reading license from: {LICENSE_PATH}")
            if os.path.exists(LICENSE_PATH):
                with open(LICENSE_PATH, 'r') as f:
                    line_count = 0
                    for line in f: # Efficient iteration, line-by-line streaming
                        print(f"Read line {line_count + 1}: {line.strip()}")
                        line_count += 1
                print(f"Successfully processed {line_count} lines.")
            else:
                print("Error: License file not found.")
            import time; time.sleep(3600)
        # 2. Volume Mounting: Mount the secret volume
        volumeMounts:
        - name: license-volume
          mountPath: /etc/secrets
          readOnly: true # Ensure the container cannot modify the secret file


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_6.py
# Description: Solution for Exercise 6
# ==========================================

# --- 1. Audit Identification ---
# The violation occurs because the sensitive API key is stored in a ConfigMap 
# (llm-keys-v1) instead of a Secret. ConfigMaps are designed for non-sensitive, 
# non-confidential data.

# --- 2. Remediation Plan (Three Critical Steps) ---
# Step 1: Create the new, properly secured Kubernetes Secret (llm-secure-keys-v2) 
#         containing the base64 encoded API key.
# Step 2: Update the 'insecure-llm-processor' Deployment manifest to change 
#         'configMapKeyRef' (or the old 'secretKeyRef' name) to reference the 
#         new 'llm-secure-keys-v2' Secret name. Apply this change to trigger a 
#         rolling update.
# Step 3: Once all new Pods are running successfully and the old Pods are terminated, 
#         securely delete the old, insecure ConfigMap (llm-keys-v1) to eliminate 
#         the persistent security exposure.

# --- 3. Rotation Policy Definition ---
# Objective: Rotate the API key in 'llm-secure-keys-v2' and force Pod restart.
# Policy Steps:
# 1. Update the Secret: Generate the new API key, base64 encode it, and apply the 
#    update to the existing 'llm-secure-keys-v2' Secret object using 'kubectl apply'.
# 2. Calculate New Hash: Calculate a cryptographic hash (e.g., SHA256) of the new 
#    Secret content.
# 3. Trigger Rolling Update: Patch the Deployment's Pod template annotation 
#    (e.g., 'checksum/llm-secure-keys-v2') with the newly calculated hash.
#
# Specific kubectl command to trigger the rolling update:
# kubectl patch deployment insecure-llm-processor -p "{\"spec\":{\"template\":{\"metadata\":{\"annotations\":{\"checksum/llm-secure-keys-v2\":\"<NEW_HASH_VALUE>\"}}}}}"
# 4. Verification: Monitor the rolling update status using 'kubectl rollout status deployment/insecure-llm-processor'.

# --- 4. Advanced Security Recommendation ---
# Recommendation: Enable etcd encryption at rest for the Kubernetes control plane.
# Security Benefit: Native Kubernetes Secrets are only base64 encoded, not truly encrypted, 
# when retrieved via the API. However, they are stored in the etcd database. Enabling 
# etcd encryption ensures that if an attacker gains access to the underlying etcd data 
# store (a critical risk), the secrets are not readable, providing a crucial layer of 
# defense-in-depth against data breaches.

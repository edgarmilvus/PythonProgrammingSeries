
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# --- 1. llm-api-credentials.yaml (Secret Definition) ---
# API_KEY: ZG9udHNlZW15c2VjcmV0 ("dontseemysecret")
# CONFIG_FLAG: cHJvZHVjdGlvbg== ("production")
apiVersion: v1
kind: Secret
metadata:
  name: llm-api-credentials
type: Opaque
data:
  API_KEY: ZG9udHNlZW15c2VjcmV0 
  CONFIG_FLAG: cHJvZHVjdGlvbg==

# --- 2. deployment.yaml (Deployment Definition) ---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: llm-client-deployment
spec:
  replicas: 1
  selector:
    matchLabels:
      app: llm-client
  template:
    metadata:
      labels:
        app: llm-client
    spec:
      containers:
      - name: api-client
        image: busybox
        # 4. Verification: Print the injected environment variables
        command: ["sh", "-c"]
        args:
          - echo "API Key is: $API_KEY" &&
            echo "Config Flag is: $CONFIG_FLAG" &&
            sleep 3600
        env:
        # 3. Injection Method: Reference API_KEY from the Secret
        - name: API_KEY
          valueFrom:
            secretKeyRef:
              name: llm-api-credentials
              key: API_KEY
        # 3. Injection Method: Reference CONFIG_FLAG from the Secret
        - name: CONFIG_FLAG
          valueFrom:
            secretKeyRef:
              name: llm-api-credentials
              key: CONFIG_FLAG

# --- 5. Cleanup Commands (kubectl) ---
# kubectl apply -f llm-api-credentials.yaml
# kubectl apply -f deployment.yaml
# kubectl logs -l app=llm-client # Check output
# kubectl delete deployment llm-client-deployment
# kubectl delete secret llm-api-credentials

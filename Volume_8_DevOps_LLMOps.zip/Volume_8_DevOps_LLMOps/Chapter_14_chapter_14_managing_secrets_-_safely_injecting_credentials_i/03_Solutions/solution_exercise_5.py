
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# --- 1. Vault Backend Definition (Conceptual) ---
# Path: secret/data/llm-vector-store
# Keys: DB_USERNAME, DB_PASSWORD

# --- 2. SecretStore Definition (Conceptual CRD for ExternalSecrets Operator) ---
# Points Kubernetes to the Vault server and defines authentication.
apiVersion: external-secrets.io/v1beta1
kind: SecretStore
metadata:
  name: vault-secret-store
spec:
  provider:
    vault:
      server: "https://vault.llm-ops.svc.cluster.local:8200"
      path: "kubernetes" 
      auth:
        # Authentication via Kubernetes Service Account Token Review
        kubernetesServiceAccountToken:
          serviceAccountRef:
            name: external-secrets-sa
          role: vector-store-reader-role 

# --- 3. ExternalSecret Definition (Conceptual CRD) ---
# Defines the mapping from the Vault path to the resulting native Secret.
apiVersion: external-secrets.io/v1beta1
kind: ExternalSecret
metadata:
  name: vector-db-credentials
spec:
  refreshInterval: "1h" # Define rotation check frequency
  secretStoreRef:
    name: vault-secret-store
    kind: SecretStore
  target:
    # Name of the native Kubernetes Secret that will be created/managed
    name: db-native-secret 
  data:
  - secretKey: DB_USERNAME # Key name in the native Kubernetes Secret
    remoteRef:
      key: secret/data/llm-vector-store # Vault path
      property: DB_USERNAME # Key name within the Vault secret
  - secretKey: DB_PASSWORD
    remoteRef:
      key: secret/data/llm-vector-store
      property: DB_PASSWORD

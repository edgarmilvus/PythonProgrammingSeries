
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import os
import json
from typing import Dict

# --- 1. Simulation Setup: Define Raw Secrets (What K8s Stores) ---
RAW_SECRETS = {
    "API_KEY": "sk-prod-1a2b3c4d5e6f7g8h9i0j",
    "DB_HOST": "prod-db-cluster.us-east-1.rds.amazonaws.com",
    "DB_USER": "app_rw_user",
    "DB_PASS": "P@sswOrd!HighlySecure123"
}

def simulate_kubernetes_injection(secrets: Dict[str, str]):
    """
    Simulates Kubernetes setting environment variables for the Pod.
    In a real scenario, this step is handled by the K8s runtime based on the
    Pod definition (using `valueFrom` or `envFrom`).
    """
    print("--- Simulating Secret Injection into Environment ---")
    for key, value in secrets.items():
        # Set the environment variable using the standard Python os module
        os.environ[key] = value
        print(f"  [SIMULATION] Environment Variable Set: {key}")
    print("---------------------------------------------------\n")


# --- 2. Application Logic: Reading and Using Secrets ---

def initialize_database_connection() -> str:
    """
    The core application function that reads database credentials from the
    environment variables injected by the orchestrator.
    """
    try:
        # Securely retrieve environment variables
        db_host = os.environ['DB_HOST']
        db_user = os.environ['DB_USER']
        db_pass = os.environ['DB_PASS']

        # Construct the Database Service Name (DSN)
        dsn = f"postgresql://{db_user}:{db_pass}@{db_host}/production_db"

        # IMPORTANT: Mask the password before returning or logging the DSN
        masked_dsn = dsn.replace(db_pass, '***MASKED***')
        
        # In a real application, the DSN would be used here to establish the connection.
        return f"SUCCESS: Database connection configured. DSN (masked): {masked_dsn}"

    except KeyError as e:
        # Handling the failure case if K8s failed to inject the secret
        return f"ERROR: Required database credential not found in environment: {e}"

def check_api_service_status() -> str:
    """
    Checks for the presence and validity of an external API key.
    """
    # Use os.environ.get() for optional keys, or os.environ['KEY'] for mandatory keys
    api_key = os.environ.get('API_KEY')
    
    if api_key:
        # Simulate initializing an API client using the retrieved key
        # We only display the prefix for security purposes
        status = f"SUCCESS: API Service initialized. Key prefix: {api_key[:6]}... (Total length: {len(api_key)})"
        return status
    else:
        return "WARNING: API_KEY environment variable not found. External service disabled."

# --- 3. Execution Flow ---

if __name__ == "__main__":
    print("--- Phase 1: Pre-Injection Check (Simulated Failure) ---")
    # Demonstrate what happens if the application starts without K8s injection
    print(f"DB Status (Pre-Injection): {initialize_database_connection()}")
    print("-" * 30)

    # Execute the simulation, mimicking the K8s runtime setting up the Pod environment
    simulate_kubernetes_injection(RAW_SECRETS)

    print("--- Phase 2: Post-Injection Application Startup (Success) ---")

    # 1. Database Connection Initialization
    db_connection_status = initialize_database_connection()
    print(f"1. {db_connection_status}")

    # 2. API Service Initialization
    api_status = check_api_service_status()
    print(f"2. {api_status}")

    print("\n--- Cleanup (Simulation Teardown) ---")
    # Clean up environment variables to ensure the script doesn't pollute the shell
    for key in RAW_SECRETS.keys():
        if key in os.environ:
            del os.environ[key]
    print("Environment variables successfully removed from the current process.")

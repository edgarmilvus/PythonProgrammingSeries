
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import sys
import json
import shutil
from pathlib import Path
from datetime import datetime

# --- Configuration and Path Definitions ---

# Define paths where Kubernetes/Cloud platform would mount secrets as files
SECRET_DIR = Path("./temp_secrets")
DB_PASSWORD_PATH = SECRET_DIR / "db_credentials" / "password"
API_KEY_PATH = SECRET_DIR / "external_service" / "api_key"

# --- Step 1: Secret Loading and Validation ---

def _validate_env_vars(required_vars: list) -> dict:
    """Loads required variables from the environment, raising an error if any are missing."""
    env_config = {}
    missing = []
    for var in required_vars:
        value = os.getenv(var)
        if value:
            env_config[var] = value
        else:
            missing.append(var)
    
    if missing:
        # Crucial for cloud-native apps: fail fast if configuration is incomplete
        raise EnvironmentError(f"Missing required environment variables: {', '.join(missing)}")
    return env_config

def _read_file_secret(path: Path, secret_name: str) -> str:
    """Reads a secret value from a mounted file path (simulating K8s volume mount)."""
    try:
        # Efficiently iterate over the file object to read line-by-line (Glossary: Iterating over a File Object)
        with open(path, 'r') as f:
            # Read the first line and strip whitespace/newlines
            secret_value = f.readline().strip()
        
        if not secret_value:
             raise ValueError(f"Secret file '{secret_name}' at {path} is empty.")
        return secret_value
    except FileNotFoundError:
        # Indicate a failure in the deployment (K8s failed to mount the volume)
        raise FileNotFoundError(f"Required secret file '{secret_name}' not found at {path}. K8s volume mount failed?")
    except Exception as e:
        raise IOError(f"Error reading secret file {path}: {e}")


def load_application_secrets() -> dict:
    """
    Loads all application secrets, combining Env Vars and Mounted Files into one configuration dictionary.
    """
    print("[SETUP] Starting secure secret loading process...")
    
    # 1. Load standardized configuration injected as environment variables
    env_secrets = _validate_env_vars(["DB_HOST", "DB_USER", "SERVICE_ENDPOINT"])
    
    # 2. Load highly sensitive secrets injected via mounted volumes (files)
    file_secrets = {
        "DB_PASSWORD": _read_file_secret(DB_PASSWORD_PATH, "Database Password"),
        "EXTERNAL_API_KEY": _read_file_secret(API_KEY_PATH, "External API Key")
    }

    # Merge configuration using dict.update() (Glossary: dict.update())
    config = env_secrets
    config.update(file_secrets)
    
    print(f"[SETUP] Successfully loaded {len(config)} configuration items.")
    return config

# --- Step 2: Application Logic (Simulated) ---

def process_financial_data(config: dict, data_record: dict):
    """
    Simulates connecting to secure services and processing data using loaded secrets.
    """
    print("-" * 50)
    
    # Use datetime.strptime (Glossary definition not strictly required here, but used for timestamps)
    current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S') 
    print(f"[{current_time}] Processing Record ID: {data_record['id']}")

    # 1. Construct Database Connection String (using Env Var & File Secret)
    # Note: The password (file secret) is only used internally, never logged
    db_conn_string = (
        f"postgres://{config['DB_USER']}:[REDACTED]@{config['DB_HOST']}/finance_db"
    )
    print(f"  [DB] Attempting secure connection to: {config['DB_HOST']}...")
    
    # 2. Simulate API Call using the External API Key (File Secret)
    api_url = f"{config['SERVICE_ENDPOINT']}/upload"
    # Only expose a prefix of the API key for logging, maintaining security
    auth_header = {"Authorization": f"Bearer {config['EXTERNAL_API_KEY'][:8]}..."} 
    
    print(f"  [API] Posting data to {api_url} with header prefix: {auth_header['Authorization']}")
    
    # Simulate successful secure operation
    print(f"  [STATUS] Successfully processed and uploaded record {data_record['id']}.")
    print("-" * 50)


# --- Step 3: Local Simulation Environment Setup (For Testing) ---

def setup_local_environment():
    """Creates the necessary files and sets environment variables for local testing."""
    print("[SIM] Setting up simulated cloud environment...")
    
    # a. Create directory structure for mounted files
    DB_PASSWORD_PATH.parent.mkdir(parents=True, exist_ok=True)
    API_KEY_PATH.parent.mkdir(parents=True, exist_ok=True)

    # b. Write secret content to files (K8s Secret volume mount simulation)
    with open(DB_PASSWORD_PATH, 'w') as f:
        f.write("SuperSecureDBPass123!")
    
    with open(API_KEY_PATH, 'w') as f:
        f.write("sk-prod-ai-1a2b3c4d5e6f7g8h9i0j-longkey")

    # c. Set environment variables (K8s Env Var injection simulation)
    os.environ['DB_HOST'] = "prod-db-cluster.internal.net"
    os.environ['DB_USER'] = "app_service_user"
    os.environ['SERVICE_ENDPOINT'] = "https://llmops-api.corp.com/v1"
    
    print("[SIM] Environment setup complete. Files and Env Vars injected.")

def cleanup_local_environment():
    """Removes temporary files and directories."""
    if SECRET_DIR.exists():
        shutil.rmtree(SECRET_DIR)
        print("[SIM] Cleaned up temporary secret files.")

# --- Main Execution Block ---

if __name__ == "__main__":
    setup_local_environment()
    
    try:
        # 1. Load configuration securely
        app_config = load_application_secrets()
        
        # 2. Simulate incoming data payload
        mock_data = [
            {"id": 1001, "amount": 4500.50, "user": "alice"},
            {"id": 1002, "amount": 120.00, "user": "bob"}
        ]

        # 3. Execute core logic
        for record in mock_data:
            process_financial_data(app_config, record)
        
    except (EnvironmentError, FileNotFoundError, IOError) as e:
        print(f"\n[FATAL ERROR] Application failed to start due to missing secrets: {e}", file=sys.stderr)
        sys.exit(1)
        
    finally:
        cleanup_local_environment()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# requirements.txt
# Requires system dependencies like libjpeg-dev and zlib1g-dev for successful installation
Pillow==9.5.0
requests==2.31.0
numpy==1.24.4

# --- image_processor.py ---
from PIL import Image
import sys

def check_pillow_support():
    """Attempts to check Pillow installation and dependency linkage."""
    try:
        print(f"Pillow version: {Image.__version__}")
        
        # Check for JPEG support (requires libjpeg system dependency)
        supported_formats = Image.registered_extensions()
        if '.jpeg' in supported_formats or '.jpg' in supported_formats:
            print("Status: JPEG support is active.")
        else:
            # This indicates a potential failure during compilation due to missing system headers
            print("Warning: JPEG support missing, likely due to missing system dependency during compilation.")
            
    except ImportError:
        print("FATAL ERROR: Pillow failed to import. Installation likely failed due to missing OS build tools.")
        sys.exit(1)

if __name__ == '__main__':
    check_pillow_support()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import contextvars
import asyncio
import uuid
import random

# 1. Define the Context Variable
REQUEST_ID = contextvars.ContextVar('request_id', default='UNKNOWN')

# 2. Setup (Simulation of WSGI/ASGI entry point)
async def handle_request(request_number):
    # Generate unique ID for this request
    request_id = f"Req-{request_number}-{str(uuid.uuid4())[:4]}"
    
    # Set the context variable for the current task chain
    token = REQUEST_ID.set(request_id)
    print(f"[{request_id}] Request Entry: Context set.")
    
    try:
        # Simulate running the LLM Chain steps concurrently
        await asyncio.gather(
            simulate_llm_step(1, request_id),
            simulate_llm_step(2, request_id)
        )
    finally:
        # 4. Critical: Reset the context upon exit
        REQUEST_ID.reset(token)
        print(f"[{request_id}] Request Exit: Context reset.")

# 3. Simulate the LLM Step (where the context is retrieved)
async def simulate_llm_step(step_number, expected_id):
    # This function is deep inside the LLM Chain framework, relying on contextvars
    current_id = REQUEST_ID.get()
    print(f"[{current_id}] Step {step_number} (Start): Retrieved ID.")
    
    # 4. CRITICAL MODIFICATION CHALLENGE POINT: 
    # Simulate an external library conflict that breaks context propagation 
    # during an asynchronous switch.
    
    # In a real conflicting environment (e.g., using an outdated ASGI server 
    # or a conflicting patch library), this sleep/switch point is where context 
    # leakage or loss would occur due to improper contextvars integration.
    await asyncio.sleep(random.uniform(0.01, 0.05)) 
    
    final_id = REQUEST_ID.get()
    
    if final_id != expected_id:
        # This print statement simulates the observation of state leakage in logs
        print(f"!!! DRIFT DETECTED: Step {step_number} started with {current_id} but ended with {final_id}. Expected: {expected_id}")
    else:
        print(f"[{final_id}] Step {step_number} (End): Context OK.")

# Example execution (Conceptual failure only)
# async def run_simulation():
#     await asyncio.gather(handle_request(101), handle_request(102))
# asyncio.run(run_simulation())

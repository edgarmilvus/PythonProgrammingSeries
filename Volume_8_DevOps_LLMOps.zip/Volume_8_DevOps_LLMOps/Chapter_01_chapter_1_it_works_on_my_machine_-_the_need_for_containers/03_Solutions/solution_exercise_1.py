
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# requirements_A.txt
# Legacy service dependency (requires < 2.20.0)
requests==2.19.1

# requirements_B.txt
# Modern service dependency (requires > 2.28.0)
requests==2.31.0

# --- project_a_app.py ---
import requests
import sys

def run_project_a():
    """Simulates Project A running, expecting a legacy API."""
    try:
        print(f"Project A running requests version: {requests.__version__}")
        
        # Hypothetical legacy call that only exists in < 2.20.0
        # If requests 2.31.0 is installed, this would raise an AttributeError
        
        if requests.__version__ >= '2.20.0':
            print("Project A: WARNING - Installed version is too new, legacy API calls would fail.")
        else:
            print("Project A: Success - Running required legacy version.")
            
    except AttributeError:
        print(f"Project A: FAILURE - API call failed due to version mismatch.")
        sys.exit(1)

if __name__ == '__main__':
    run_project_a()

# --- project_b_app.py ---
import requests
import sys

def run_project_b():
    """Simulates Project B running, expecting a modern feature."""
    try:
        print(f"Project B running requests version: {requests.__version__}")
        
        # Hypothetical modern call that only exists in > 2.28.0 (e.g., a new parameter)
        # If requests 2.19.1 is installed, this would raise a TypeError
        
        if requests.__version__ <= '2.28.0':
            print("Project B: WARNING - Installed version is too old, required security features are missing.")
        else:
            print("Project B: Success - Running required modern version.")
            
    except TypeError:
        print(f"Project B: FAILURE - API call failed due to missing required modern parameter.")
        sys.exit(1)

if __name__ == '__main__':
    run_project_b()

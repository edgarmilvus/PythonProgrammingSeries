
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import time
import random
import threading
import contextvars
from typing import Dict, Any, Optional

# --- 1. Global Environment and Simulated Dependency Version Control ---
# This variable simulates a critical dependency version installed system-wide (e.g., a specific
# version of a proprietary data processing library or a required Python package).
# Its value is determined by the OS environment variable set externally.
DEPENDENCY_VERSION = os.getenv("DEP_VERSION", "1.0")

# Define a context variable for request-specific state isolation.
# This is crucial in concurrent environments (like WSGI/ASGI servers) to prevent
# request data from bleeding across threads/tasks.
REQUEST_ID_VAR: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar('request_id', default=None)

# Simple global dictionary to track execution results across all threads.
# This simulates a centralized logging or metrics system.
GLOBAL_EXECUTION_LOG: Dict[str, Any] = {}

def get_dependency_behavior(data: str) -> str:
    """
    Simulates a critical function whose output changes drastically based on the 
    version of the underlying dependency (DEPENDENCY_VERSION).
    
    V2.0 expects secure hashing and uppercase transformation.
    V1.0 expects simple reversal and lowercase transformation (legacy behavior).
    """
    if DEPENDENCY_VERSION == "2.0":
        # V2.0 behavior: Modern, expected output format.
        # Requires the V2.0 dependency library/configuration to be present.
        processed = f"HASHED_{data.upper()}_{hash(data)}"
    elif DEPENDENCY_VERSION == "1.0":
        # V1.0 behavior: Legacy output format, often incompatible with newer clients.
        processed = f"LEGACY_{data[::-1].lower()}"
    else:
        # Fallback for unexpected environments
        processed = f"UNSUPPORTED_ENV_{data}"
        
    return processed

def worker_request_handler(request_data: str, thread_id: int):
    """
    Simulates a worker thread processing a web request (like a Gunicorn worker).
    It manages request context and calls the version-sensitive dependency.
    """
    # 1. Set up Request Context Isolation using contextvars
    current_request_id = f"Req-{thread_id}-{random.randint(100, 999)}"
    # Store the unique ID in the context variable for this specific execution flow.
    token = REQUEST_ID_VAR.set(current_request_id)
    
    try:
        # 2. Log Start State
        thread_name = threading.current_thread().name
        print(f"[{thread_name}] Starting {current_request_id}. Environment reports V{DEPENDENCY_VERSION}")
        
        # 3. Core Business Logic Execution
        time.sleep(random.uniform(0.1, 0.5)) # Simulate processing latency
        processed_result = get_dependency_behavior(request_data)
        
        # 4. Verification and Logging
        log_entry = {
            "thread": thread_name,
            "input": request_data,
            "output": processed_result,
            "dep_version_used": DEPENDENCY_VERSION,
            # Retrieve the request ID to prove contextvars worked correctly
            "context_id": REQUEST_ID_VAR.get() 
        }
        
        # Store the result globally
        GLOBAL_EXECUTION_LOG[current_request_id] = log_entry
        print(f"[{thread_name}] Finished {current_request_id}. Result Prefix: {processed_result[:6]}...")
        
    finally:
        # 5. Clean up the Context Variable State
        # Crucial step to prevent state leakage to subsequent requests in the same thread.
        REQUEST_ID_VAR.reset(token)

def simulate_server_run(num_requests: int, target_version: str):
    """
    Orchestrates the concurrent execution and performs post-run verification.
    """
    print("\n" + "="*80)
    print(f"SIMULATION START: Application Code TARGETS V{target_version} Behavior.")
    print(f"Actual Installed Environment reports Dependency V{DEPENDENCY_VERSION}.")
    print("="*80)

    # Reset logs for clean run
    GLOBAL_EXECUTION_LOG.clear()

    threads = []
    request_data_list = [f"Payload_{i}" for i in range(num_requests)]
    
    for i, data in enumerate(request_data_list):
        t = threading.Thread(
            target=worker_request_handler, 
            args=(data, i), 
            name=f"Worker-{i}"
        )
        threads.append(t)
        t.start()

    for t in threads:
        t.join()
        
    # --- Post-run Verification ---
    success_count = 0
    expected_prefix = "HASHED" if target_version == "2.0" else "LEGACY"
    
    print("\n" + "-"*80)
    print("VERIFICATION PHASE:")
    
    for req_id, log in GLOBAL_EXECUTION_LOG.items():
        if log['output'].startswith(expected_prefix):
            success_count += 1
        else:
            # This block highlights the failure caused by environment drift.
            print(f"[!!! FAILURE !!!] Request {req_id} failed verification.")
            print(f"  Expected behavior prefix: {expected_prefix}")
            print(f"  Actual output prefix: {log['output'][:6]}")
            print(f"  Reason: Target V{target_version} != Environment V{log['dep_version_used']}")

    print("\n" + "="*80)
    print(f"Simulation Complete. Total Requests: {num_requests}. Success Count: {success_count}/{num_requests}")
    
    # The crucial output: Did the application achieve the behavior it was designed for?
    is_consistent = (success_count == num_requests)
    print(f"Deployment Consistency Check: {is_consistent}")
    print("="*80)


if __name__ == "__main__":
    # SCENARIO 1: Local Development Environment (The "It Works on My Machine" success)
    # The developer sets the environment variable to V2.0, matching the expected code behavior.
    os.environ["DEP_VERSION"] = "2.0"
    # Re-read the environment variable to initialize the global state
    DEPENDENCY_VERSION = os.getenv("DEP_VERSION", "1.0") 
    simulate_server_run(num_requests=4, target_version="2.0")

    print("\n\n" + "#"*80)
    print("TRANSITIONING TO PRODUCTION ENVIRONMENT (Simulating Deployment Drift)")
    print("#"*80)
    
    # SCENARIO 2: Production Deployment Environment (The "It Fails in Production" problem)
    # The production infrastructure team forgot to update the environment variable, 
    # or an older system configuration mandates V1.0.
    os.environ["DEP_VERSION"] = "1.0"
    DEPENDENCY_VERSION = os.getenv("DEP_VERSION", "1.0") 
    
    # CRITICAL: The application code (simulate_server_run) is still expecting and 
    # targeting V2.0 behavior, but the environment delivers V1.0.
    simulate_server_run(num_requests=4, target_version="2.0")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# dependency_hell_app.py

import os
import sys
import logging
from datetime import datetime

# --- Dependency 1: Flask ---
# We use Flask to simulate a simple web service endpoint.
try:
    from flask import Flask, jsonify
except ImportError:
    # This check ensures Flask is present, but doesn't check the version/compatibility.
    print("FATAL: Flask is not installed. Application cannot start.")
    sys.exit(1)

# --- Dependency 2: Requests ---
# We use requests to simulate an external API call critical to the application logic.
# The developer assumes the environment has a version compatible with their development system (e.g., requests==2.21.0).
try:
    import requests
    REQUESTS_VERSION = requests.__version__
except ImportError:
    print("FATAL: Requests library is missing. Application cannot perform external operations.")
    sys.exit(1)
except AttributeError:
    # Catches cases where the library might be malformed or extremely old
    REQUESTS_VERSION = "Unknown"


# Configuration Setup (Simulating Environment Variables and Hidden Requirements)
APP_VERSION = os.environ.get("APP_VERSION", "1.0.0-dev")
# CRITICAL HIDDEN REQUIREMENT: This application relies on features only present in Python 3.9+
REQUIRED_PYTHON_VERSION = (3, 9) 

# Basic Logging Setup
# The format string relies on the standard library's logging behavior.
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Initialize the Flask application
app = Flask(__name__)

@app.route('/')
def home():
    """
    The main endpoint. Checks environment compatibility and attempts an external operation.
    """
    # 1. Explicit Environment Check (Often missed or assumed)
    if sys.version_info < REQUIRED_PYTHON_VERSION:
        # This error demonstrates a hard failure due to Interpreter version drift.
        major, minor = sys.version_info.major, sys.version_info.minor
        req_major, req_minor = REQUIRED_PYTHON_VERSION
        msg = (f"Incompatible Python version detected: {major}.{minor}. "
               f"Requires {req_major}.{req_minor} or higher.")
        logger.error(msg)
        return jsonify({"status": "error", "message": msg}), 500

    # 2. Dependency Interaction (Simulating a critical external call)
    try:
        # The exact behavior of this network call (e.g., SSL certificate handling, timeout behavior)
        # is dependent on the specific version of the 'requests' library and the underlying OS libraries.
        response = requests.get("https://httpbin.org/status/200", timeout=5)
        
        if response.status_code == 200:
            status_msg = "External service check successful."
            logger.info(status_msg)
        else:
            # Note: A different 'requests' version might handle redirects or proxy errors differently here.
            status_msg = f"External service check failed with status: {response.status_code}"
            logger.warning(status_msg)

    except requests.exceptions.RequestException as e:
        # This exception handling might fail if the version of 'requests' is too old or too new.
        status_msg = f"Network error during external call: {e}"
        logger.critical(status_msg)
        return jsonify({"status": "error", "message": status_msg}), 503

    # 3. Successful Response
    return jsonify({
        "status": "ok",
        "app_version": APP_VERSION,
        "requests_version_used": REQUESTS_VERSION,
        "python_version_used": f"{sys.version_info.major}.{sys.version_info.minor}",
        "message": status_msg
    })

if __name__ == '__main__':
    logger.info(f"Starting Application Version: {APP_VERSION}")
    logger.info(f"Running Flask using Requests version: {REQUESTS_VERSION}")
    # The use of app.run() here binds the app to the local Werkzeug development server,
    # which is fundamentally different from a production WSGI server (Gunicorn).
    app.run(host='0.0.0.0', port=5000)

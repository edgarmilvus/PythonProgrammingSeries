
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import yaml
from dataclasses import dataclass
import json
from typing import Dict, Any

# --- 1. Define the desired state structure (Schema) ---

@dataclass
class WorkerConfig:
    """Represents the rigid, desired state of a deployed worker resource."""
    name: str
    image: str
    cpu_cores: float
    memory_gb: int
    replicas: int

# --- 2. Declarative Approach: External YAML Configuration ---
# This string represents a file (e.g., deployment.yaml) that defines the state.
YAML_CONFIG = """
# Standard cloud resource metadata and structure
apiVersion: v1
kind: WorkerDeployment
metadata:
  name: data-ingestion-worker
  labels:
    app: ingestion
spec:
  replicas: 3
  template:
    spec:
      image: python:3.11-slim
      resources:
        cpu_cores: 0.5
        memory_gb: 2
"""

def apply_declarative_state(yaml_content: str) -> WorkerConfig:
    """
    Parses YAML content to extract the configuration.
    This function demonstrates interpretation of external state.
    """
    # Load the structured data dictionary from the YAML string
    data: Dict[str, Any] = yaml.safe_load(yaml_content)

    # Declarative configurations often use deep nesting (like Kubernetes)
    # We must traverse the dictionary structure to find the values.
    try:
        spec = data['spec']
        template_spec = spec['template']['spec']
        resources = template_spec['resources']

        config = WorkerConfig(
            name=data['metadata']['name'],
            image=template_spec['image'],
            cpu_cores=resources['cpu_cores'],
            memory_gb=resources['memory_gb'],
            replicas=spec['replicas']
        )
        return config
    except KeyError as e:
        # Crucial for declarative systems: validation happens during parsing
        raise ValueError(f"Missing required key in YAML configuration: {e}")

# --- 3. Imperative Approach: Defining State via Python Client ---

class CloudClient:
    """
    Simulates a Python SDK client used to interact with a cloud API.
    The method calls themselves define the desired actions and state.
    """
    def __init__(self, service_name: str):
        self.service = service_name
        self.applied_configs = {}

    def create_worker_deployment(self, config: WorkerConfig):
        """
        The imperative function call that applies the defined state.
        Note: The state object (config) must be fully constructed beforehand.
        """
        print(f"[{self.service}] Executing API call to create deployment: {config.name}")
        # In a real system, this would serialize 'config' to JSON and POST it.
        self.applied_configs[config.name] = config
        return f"Deployment '{config.name}' created successfully (Imperative)."

def apply_imperative_state() -> WorkerConfig:
    """
    Directly constructs the desired state using native Python objects and types.
    The definition is the code itself.
    """
    # The configuration is defined line-by-line using Python's native structure.
    # This benefits from immediate IDE type checking and autocompletion.
    desired_state = WorkerConfig(
        name="data-ingestion-worker",
        image="python:3.11-slim",
        cpu_cores=0.5,
        memory_gb=2,
        replicas=3
    )
    return desired_state

# --- 4. Execution and Comparison ---

print("--- 1. Declarative Execution (Parsing External State) ---")
declarative_config = apply_declarative_state(YAML_CONFIG)
print(f"Resulting Declarative State Object:\n{json.dumps(declarative_config.__dict__, indent=4)}\n")

print("--- 2. Imperative Execution (Defining State Internally) ---")
imperative_config = apply_imperative_state()

# The imperative state is then passed to the client for application
client = CloudClient(service_name="ComputeEngine")
result = client.create_worker_deployment(imperative_config)

print(f"Resulting Imperative State Object:\n{json.dumps(imperative_config.__dict__, indent=4)}")
print(f"Client Action Result: {result}")

# Verification
print("\n--- 3. Verification ---")
is_match = declarative_config == imperative_config
print(f"Do the resulting internal WorkerConfig objects match? {is_match}")

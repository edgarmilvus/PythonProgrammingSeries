
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import yaml
import os
import json
from datetime import datetime
from typing import Dict, Any

# --- 1. Declarative State Definition (YAML) ---
# This defines the static, desired state of the deployment, using sensible defaults
# or placeholders that will be overridden by imperative logic.
K8S_DEPLOYMENT_YAML = """
apiVersion: apps/v1
kind: Deployment
metadata:
  name: llm-inference-service
  labels:
    app: llm-service
    tier: backend
spec:
  replicas: 3 # Default replica count (will be overridden)
  selector:
    matchLabels:
      app: llm-service
  template:
    metadata:
      labels:
        app: llm-service
    spec:
      containers:
      - name: llm-container
        image: registry.corp.com/llm-base:latest # Placeholder image tag
        ports:
        - containerPort: 8080
        resources:
          # Resources are minimal placeholders; they MUST be imperatively calculated
          limits:
            cpu: "500m"
            memory: "1Gi"
"""

# --- 2. Imperative Logic Functions ---

def calculate_resources(model_size_gb: float) -> Dict[str, Dict[str, str]]:
    """
    Imperative function: Calculates necessary resource limits based on business logic.
    This logic cannot be expressed in static YAML.
    """
    # Business Rule: Need 1.2x the model size in memory, plus 1Gi overhead.
    required_mem_gb = (model_size_gb * 1.2) + 1.0
    # Convert GB to Kubernetes Gi string format (e.g., 6Gi)
    mem_string = f"{int(required_mem_gb)}Gi"

    # Business Rule: Assume 1 CPU core (1000m) per 5GB of model weight.
    required_cpu_m = int((model_size_gb / 5.0) * 1000)
    cpu_string = f"{max(required_cpu_m, 1000)}m" # Ensure minimum 1 core

    return {
        "limits": {"cpu": cpu_string, "memory": mem_string},
        "requests": {"cpu": cpu_string, "memory": mem_string},
    }

def deploy_service(base_config: Dict[str, Any], model_version: str, environment: str) -> Dict[str, Any]:
    """
    Imperative function: Merges the declarative configuration with dynamic state overrides.
    (Simulates applying configuration via a Kubernetes Python Client/SDK)
    """
    # Access specific nested parts of the declarative structure
    deployment_spec = base_config['spec']['template']['spec']
    container_spec = deployment_spec['containers'][0]

    # 2a. Imperative Calculation & Override: Determine resources
    MODEL_SIZE_GB = 8.0 # This value would typically come from a model registry API lookup
    calculated_resources = calculate_resources(MODEL_SIZE_GB)

    # Apply calculated values, overriding the static placeholders
    container_spec['resources'] = calculated_resources

    # 2b. Imperative Override: Set dynamic image tag
    container_spec['image'] = f"registry.corp.com/llm-base:{model_version}"

    # 2c. Imperative Additions: Add dynamic metadata (annotations) for traceability
    now_utc = datetime.utcnow().isoformat()
    base_config['metadata']['annotations'] = {
        'deployment.environment': environment,
        'deployment.timestamp': now_utc,
        'model.version': model_version,
        'model.size.gb': str(MODEL_SIZE_GB)
    }

    # 2d. Imperative Logic: Adjust replicas based on environment
    # This is conditional logic that YAML alone cannot handle easily
    if environment == 'production':
        base_config['spec']['replicas'] = 5
    elif environment == 'staging':
        base_config['spec']['replicas'] = 2
    else:
        base_config['spec']['replicas'] = 1

    # Return the final, mutated state ready for submission
    return base_config

# --- 3. Execution and Verification ---

# Define dynamic, runtime parameters (e.g., fetched from CI/CD variables)
CURRENT_MODEL_VERSION = "v7.5-beta"
CURRENT_ENVIRONMENT = os.environ.get("ENV", "staging")

print(f"--- 1. Starting Deployment Process for Environment: {CURRENT_ENVIRONMENT} ---")

# A. Parse the declarative YAML state
base_deployment_config = yaml.safe_load(K8S_DEPLOYMENT_YAML)
print(f"Loaded declarative base configuration. Initial YAML replicas: {base_deployment_config['spec']['replicas']}")

# B. Execute the imperative deployment logic (State Mutation)
final_deployment_state = deploy_service(
    base_deployment_config,
    model_version=CURRENT_MODEL_VERSION,
    environment=CURRENT_ENVIRONMENT
)

# C. Verification of Merged State
print("\n--- 2. Final Merged State Summary ---")
print(f"Final Replicas (Imperative Adjustment): {final_deployment_state['spec']['replicas']}")

container_info = final_deployment_state['spec']['template']['spec']['containers'][0]
resources = container_info['resources']['limits']

print(f"Final Image Tag (Imperative Override): {container_info['image']}")
print(f"Calculated Memory Limit: {resources['memory']}")
print(f"Calculated CPU Limit: {resources['cpu']}")

# D. Final Output (Simulating the API call payload)
# print("\n--- 3. Final Configuration Payload (YAML Output) ---")
# print(yaml.dump(final_deployment_state, indent=2))

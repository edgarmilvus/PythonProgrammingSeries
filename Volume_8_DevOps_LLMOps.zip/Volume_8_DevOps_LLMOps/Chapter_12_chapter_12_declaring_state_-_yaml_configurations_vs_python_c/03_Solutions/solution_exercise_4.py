
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# drift_mitigation.py

import json

class StorageClient:
    """Simulates interaction with a cloud storage provider SDK (e.g., boto3)."""

    def get_current_state(self, bucket_name):
        """Simulates fetching the current configuration, including drift."""
        print(f"-> Fetching current state for {bucket_name}...")
        # Simulated state where versioning was manually disabled (the drift)
        return {
            "bucket_name": bucket_name,
            "versioning_enabled": False,  # Drift detected here
            "public_access_blocked": True,
            "region": "us-east-1",
            "encryption_type": "AES256" # Extra field not in desired state
        }

    def apply_configuration(self, bucket_name, config_diff):
        """Applies only the necessary configuration changes."""
        if not config_diff:
            print(f"--- SUCCESS: {bucket_name} is already compliant. No changes applied.")
            return

        print(f"*** DRIFT DETECTED. Applying corrections to {bucket_name} ***")
        print(f"Changes applied: {json.dumps(config_diff, indent=4)}")

        # Simulated API calls to apply specific changes
        if 'versioning_enabled' in config_diff:
            status = "Enabled" if config_diff['versioning_enabled'] else "Disabled"
            print(f"  [API CALL]: Setting versioning status to {status}.")
        
        if 'public_access_blocked' in config_diff:
            print(f"  [API CALL]: Updating public access block status.")
        
        print("Correction complete.")

# 1. Define Desired State
desired_state = {
    "bucket_name": "llm-artifacts-prod",
    "versioning_enabled": True,
    "public_access_blocked": True,
    "region": "us-east-1"
}

# Initialize client and fetch current state
client = StorageClient()
current_state = client.get_current_state(desired_state["bucket_name"])

# 3. Drift Detection and Correction Logic
config_diff = {}
drift_detected = False

for key, desired_value in desired_state.items():
    if key in current_state and current_state[key] != desired_value:
        drift_detected = True
        print(f"Mismatch found for '{key}': Desired={desired_value}, Current={current_state[key]}")
        # Calculate the required change
        config_diff[key] = desired_value

# Apply the calculated corrections
client.apply_configuration(desired_state["bucket_name"], config_diff)


"""
### Narrative on Imperative Drift Management

The imperative approach requires the engineer to explicitly write the comparison logic (the 'for' loop and 'if' statement) to determine the difference between the desired state (local dictionary) and the actual state (fetched from the cloud). This logic, which calculates the `config_diff`, is the core reconciliation engine. In contrast, a declarative IaC tool (like Terraform or Pulumi) abstracts this state diffing engine entirely. The user simply defines the desired state file, and the tool's provider handles fetching the current state, performing the deep comparison, calculating the minimal required API calls, and executing the fix—all without the user writing explicit comparison code. The complexity added by the imperative method is the necessity of manually managing this reconciliation logic, which is prone to errors as the configuration schema grows.
"""

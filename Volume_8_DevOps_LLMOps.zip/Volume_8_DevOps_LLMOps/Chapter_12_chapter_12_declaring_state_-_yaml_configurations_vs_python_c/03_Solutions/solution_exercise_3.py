
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# configure_memory.py (Imperative LLM State using Pydantic)

from pydantic import BaseModel, Field
from typing import Literal

# 1. Define the necessary Pydantic model structure
class StorageBackend(BaseModel):
    """Defines the configuration for the external memory storage."""
    provider: Literal['redis', 'postgres', 's3'] = Field(description="The storage provider type.")
    host: str = Field(description="The hostname or service URL.")
    port: int = Field(description="The connection port.")

class MemoryConfig(BaseModel):
    """Defines the overall LLM memory configuration."""
    type: Literal['ConversationBufferWindow', 'VectorStoreMemory'] = Field(description="The type of memory strategy.")
    window_size: int = Field(description="Max number of turns to remember.")
    storage_backend: StorageBackend

# 2. Instantiate the models to represent the desired state
desired_storage_config = StorageBackend(
    provider='redis',
    host='redis-cache-service.llm-ns.svc.cluster.local',
    port=6379
)

desired_memory_config = MemoryConfig(
    type='ConversationBufferWindow',
    window_size=5,
    storage_backend=desired_storage_config
)

# Output the resulting configuration object
print("--- Desired LLM Memory Configuration (Imperative Pydantic) ---")
print(desired_memory_config.model_dump_json(indent=2))


"""
### Design Justification for Pydantic

A Python-based, Pydantic-enforced configuration approach is highly preferred over raw YAML for complex, type-sensitive LLMOps configurations primarily because of **runtime schema validation and type safety**. Pydantic models enforce that the 'window_size' is an integer and the 'port' is an integer *before* the application attempts to load or use the configuration. If a user mistakenly inputs 'window_size: "five"' in the YAML, the error would only be caught when the application attempts to cast or use that value, potentially far into the runtime. With Pydantic, the model instantiation fails immediately upon startup, providing a clear, traceable validation error, which significantly improves developer experience and configuration reliability. Furthermore, Pydantic integrates seamlessly with modern dependency injection frameworks (like FastAPI's dependency system) and IDE auto-completion.
"""

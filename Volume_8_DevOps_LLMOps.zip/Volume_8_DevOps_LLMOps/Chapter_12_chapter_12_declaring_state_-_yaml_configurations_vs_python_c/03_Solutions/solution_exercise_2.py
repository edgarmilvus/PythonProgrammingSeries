
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# deploy_api.py (Imperative Definition)

import json

# Placeholder for a Kubernetes Client Library
class K8sClient:
    def __init__(self, context):
        self.context = context
        print(f"K8s Client initialized for context: {context}")

    def create_deployment(self, name, replicas, image, resources, env_vars):
        """Programmatically constructs and 'applies' the desired Deployment state."""
        deployment_spec = {
            "apiVersion": "apps/v1",
            "kind": "Deployment",
            "metadata": {"name": name, "labels": {"app": name}},
            "spec": {
                "replicas": replicas,
                "selector": {"matchLabels": {"app": name}},
                "template": {
                    "metadata": {"labels": {"app": name}},
                    "spec": {
                        "containers": [{
                            "name": "api-container",
                            "image": image,
                            "ports": [{"containerPort": 8080}],
                            "env": [{"name": k, "value": v} for k, v in env_vars.items()],
                            "resources": {"limits": resources}
                        }]
                    }
                }
            }
        }
        print(f"\n[Imperative Deployment Definition for {name}]")
        print(json.dumps(deployment_spec, indent=2))
        # In a real client, this would execute the API call:
        # self.client.apps_v1.create_namespaced_deployment(body=deployment_spec)
        return deployment_spec

    def create_service(self, name, selector_app, target_port, service_type):
        """Programmatically constructs and 'applies' the desired Service state."""
        service_spec = {
            "apiVersion": "v1",
            "kind": "Service",
            "metadata": {"name": f"{name}-service"},
            "spec": {
                "type": service_type,
                "selector": {"app": selector_app},
                "ports": [{"protocol": "TCP", "port": 80, "targetPort": target_port}]
            }
        }
        print(f"\n[Imperative Service Definition for {name}-service]")
        print(json.dumps(service_spec, indent=2))
        return service_spec

# --- Define Desired State ---
DEPLOYMENT_NAME = "python-api-deployment"
REPLICAS = 3
IMAGE_TAG = "my-repo/python-api:v1.2"
RESOURCE_LIMITS = {"memory": "512Mi", "cpu": "1.0"}
ENVIRONMENT_VARIABLES = {"LOG_LEVEL": "DEBUG"}

# Execute the imperative configuration
client = K8sClient(context="production-cluster")
client.create_deployment(
    name=DEPLOYMENT_NAME,
    replicas=REPLICAS,
    image=IMAGE_TAG,
    resources=RESOURCE_LIMITS,
    env_vars=ENVIRONMENT_VARIABLES
)
client.create_service(
    name=DEPLOYMENT_NAME,
    selector_app="python-api-deployment",
    target_port=8080,
    service_type="LoadBalancer"
)

"""
### Analysis: Declarative (YAML) vs. Imperative (Python)

**Version Control Diffing (git diffs):**
The YAML definition is generally superior for diffing. Changes are typically localized to specific lines (e.g., changing 'replicas: 3' to 'replicas: 5'). In the imperative Python solution, a small change might require modifying variable assignments, dictionary structures, or function calls, potentially scattering the change across multiple lines or functions, making the resulting diff less concise and harder to read for state changes alone.

**Dynamic Injection:**
The imperative Python solution excels here. Python variables (REPLICAS, IMAGE_TAG) can be easily fetched from external sources (databases, environment variables, command-line arguments, or other configuration files) and injected directly into the configuration definition before the API call is made. YAML requires external templating tools (like Helm, Kustomize, or Jinja) to achieve the same dynamic injection capability, adding complexity to the deployment workflow.
"""

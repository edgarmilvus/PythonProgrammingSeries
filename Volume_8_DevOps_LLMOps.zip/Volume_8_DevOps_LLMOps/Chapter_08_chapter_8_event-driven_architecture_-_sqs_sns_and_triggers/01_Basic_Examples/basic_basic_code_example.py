
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import boto3
import json
import time
from botocore.exceptions import ClientError

# --- Configuration Constants ---
QUEUE_NAME = "PythonJobProcessingQueue_B10"
AWS_REGION = "us-east-1" 
DELAY_SECONDS = 5 # Time before a message becomes visible to consumers
VISIBILITY_TIMEOUT = 30 # Time the message is hidden while being processed

def initialize_sqs_client():
    """Initializes the SQS client using Boto3."""
    # Boto3 handles authentication automatically based on environment variables or AWS CLI configuration.
    try:
        sqs_client = boto3.client('sqs', region_name=AWS_REGION)
        print(f"SQS client initialized for region: {AWS_REGION}")
        return sqs_client
    except Exception as e:
        print(f"Error initializing Boto3 client. Ensure AWS credentials are configured. Error: {e}")
        exit(1)

def create_queue(sqs_client, queue_name):
    """Creates the SQS queue and returns its URL."""
    print(f"\n1. Attempting to create or retrieve queue: {queue_name}")
    try:
        response = sqs_client.create_queue(
            QueueName=queue_name,
            Attributes={
                # DelaySeconds: Messages are hidden from consumers for this long after they are sent.
                'DelaySeconds': str(DELAY_SECONDS),  
                # VisibilityTimeout: How long a message remains hidden after a consumer receives it.
                'VisibilityTimeout': str(VISIBILITY_TIMEOUT), 
                # MessageRetentionPeriod: How long SQS keeps a message if it's not deleted (1 day default).
                'MessageRetentionPeriod': '86400' 
            }
        )
        queue_url = response['QueueUrl']
        print(f"   Queue URL retrieved: {queue_url}")
        return queue_url
    except ClientError as e:
        print(f"Error creating queue: {e}")
        return None

def send_job_message(sqs_client, queue_url, job_data):
    """Sends a structured JSON message to the queue (The Producer)."""
    message_body = json.dumps(job_data)
    try:
        response = sqs_client.send_message(
            QueueUrl=queue_url,
            MessageBody=message_body,
            # MessageAttributes allow filtering and metadata without touching the body
            MessageAttributes={
                'JobPriority': {
                    'DataType': 'String',
                    'StringValue': job_data.get('priority', 'LOW')
                }
            }
        )
        print(f"\n2. Message (Job ID: {job_data['job_id']}) sent successfully by Producer.")
        print(f"   SQS Message ID: {response['MessageId']}")
        return response['MessageId']
    except ClientError as e:
        print(f"Error sending message: {e}")

def receive_and_process_message(sqs_client, queue_url):
    """Polls the queue, processes the message, and deletes it (The Consumer)."""
    print("\n3. Consumer polling the queue for messages...")
    
    # Wait slightly longer than DelaySeconds to ensure the message is visible
    print(f"   Waiting {DELAY_SECONDS + 1} seconds for message visibility...")
    time.sleep(DELAY_SECONDS + 1)

    try:
        # Long Polling (WaitTimeSeconds > 0) is recommended for cost efficiency
        response = sqs_client.receive_message(
            QueueUrl=queue_url,
            MaxNumberOfMessages=1,
            WaitTimeSeconds=15, # Wait up to 15 seconds for a message to arrive
            MessageAttributeNames=['All'] # Retrieve all custom attributes
        )

        messages = response.get('Messages', [])
        if not messages:
            print("   No messages received after polling.")
            return

        for message in messages:
            receipt_handle = message['ReceiptHandle']
            # The body is always a string and must be parsed back into JSON/dict
            message_body = json.loads(message['Body'])
            job_priority = message['MessageAttributes']['JobPriority']['StringValue']

            print(f"\n4. Consumer received Job ID: {message_body['job_id']} (Priority: {job_priority})")
            print(f"   Received Data Payload: {message_body}")
            
            # --- START PROCESSING WINDOW ---
            print(f"   [SIMULATION] Processing started. Visibility Timeout set to {VISIBILITY_TIMEOUT}s.")
            time.sleep(2) # Simulate quick processing
            # --- END PROCESSING WINDOW ---

            # CRITICAL STEP: Delete the message from the queue after successful processing
            sqs_client.delete_message(
                QueueUrl=queue_url,
                ReceiptHandle=receipt_handle
            )
            print("5. Message successfully deleted from the queue (Acknowledgement).")
            print(f"   Receipt Handle used: {receipt_handle[:10]}...") # Display truncated handle

    except ClientError as e:
        print(f"Error receiving or processing message: {e}")

def cleanup_queue(sqs_client, queue_url):
    """Deletes the queue to clean up resources."""
    print("\n6. Cleaning up resources (Deleting queue)...")
    try:
        sqs_client.delete_queue(QueueUrl=queue_url)
        print("   Queue deleted successfully.")
    except ClientError as e:
        print(f"Error deleting queue: {e}")


if __name__ == "__main__":
    sqs = initialize_sqs_client()

    # Define the job payload for the Producer
    sample_job = {
        "job_id": "J-4096-A",
        "task": "Generate_Summary_Report",
        "input_file": "data/raw/Q3_data.csv",
        "priority": "HIGH",
        "submission_time": time.time()
    }

    queue_url = create_queue(sqs, QUEUE_NAME)

    if queue_url:
        # Step 2: Producer sends the job
        send_job_message(sqs, queue_url, sample_job)

        # Step 3/4/5: Consumer receives, processes, and deletes the job
        receive_and_process_message(sqs, queue_url)

        # Step 6: Cleanup
        cleanup_queue(sqs, queue_url)

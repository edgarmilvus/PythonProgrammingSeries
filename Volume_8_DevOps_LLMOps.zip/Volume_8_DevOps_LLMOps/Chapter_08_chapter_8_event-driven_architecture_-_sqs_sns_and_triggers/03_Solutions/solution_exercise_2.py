
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import boto3
import json

# --- Configuration ---
REGION_NAME = 'us-east-1' # Replace with your AWS region
SNS_TOPIC_NAME = 'InventoryUpdatesTopic'
LOG_QUEUE_NAME = 'InventoryLogQueue'
ALERT_QUEUE_NAME = 'RestockAlertQueue'
TEST_EMAIL = "test@example.com" # REPLACE WITH A VALID EMAIL ADDRESS

sns_client = boto3.client('sns', region_name=REGION_NAME)
sqs_client = boto3.client('sqs', region_name=REGION_NAME)

def setup_resources():
    """Creates the topic and queues, returning ARNs and URLs."""
    print("1. Creating SNS Topic...")
    topic_arn = sns_client.create_topic(Name=SNS_TOPIC_NAME)['TopicArn']

    print("2. Creating SQS Queues...")
    log_queue_url = sqs_client.create_queue(Name=LOG_QUEUE_NAME)['QueueUrl']
    alert_queue_url = sqs_client.create_queue(Name=ALERT_QUEUE_NAME)['QueueUrl']
    
    log_queue_arn = sqs_client.get_queue_attributes(
        QueueUrl=log_queue_url, AttributeNames=['QueueArn']
    )['Attributes']['QueueArn']
    
    alert_queue_arn = sqs_client.get_queue_attributes(
        QueueUrl=alert_queue_url, AttributeNames=['QueueArn']
    )['Attributes']['QueueArn']
    
    print("3. Creating Subscriptions...")
    
    # Subscription A: InventoryLogQueue (No Filter)
    sns_client.subscribe(
        TopicArn=topic_arn,
        Protocol='sqs',
        Endpoint=log_queue_arn,
        ReturnSubscriptionArn=True
    )
    
    # Subscription B: Email Notification (No Filter - Requires manual confirmation)
    sns_client.subscribe(
        TopicArn=topic_arn,
        Protocol='email',
        Endpoint=TEST_EMAIL,
        ReturnSubscriptionArn=True
    )
    print(f"Email subscription sent to {TEST_EMAIL}. Please confirm manually.")

    # Subscription C: RestockAlertQueue (With Filter Policy)
    filter_policy = {
      "stock_level": [{"numeric": ["<", 10]}]
    }
    sns_client.subscribe(
        TopicArn=topic_arn,
        Protocol='sqs',
        Endpoint=alert_queue_arn,
        ReturnSubscriptionArn=True,
        Attributes={
            'FilterPolicy': json.dumps(filter_policy)
        }
    )
    print("Subscriptions complete, including filter policy for RestockAlertQueue.")
    
    return topic_arn, log_queue_url, alert_queue_url

def publisher(topic_arn):
    """Publishes two messages: one standard, one critical."""
    print("\n--- Publisher Start ---")
    
    # Message 1: Standard Update (Stock Level 50) - Should go to Log and Email, NOT Alert
    message_1_body = {"product_id": 101, "event": "Standard Stock Update", "level": 50}
    sns_client.publish(
        TopicArn=topic_arn,
        Message=json.dumps(message_1_body),
        Subject="Inventory Update: Stock OK",
        MessageAttributes={
            'stock_level': {'DataType': 'Number', 'StringValue': '50'}
        }
    )
    print("Published Message 1 (Stock 50).")

    # Message 2: Critical Alert (Stock Level 5) - Should go to Log, Email, AND Alert
    message_2_body = {"product_id": 202, "event": "Critical Restock Alert", "level": 5}
    sns_client.publish(
        TopicArn=topic_arn,
        Message=json.dumps(message_2_body),
        Subject="Inventory Update: CRITICAL STOCK",
        MessageAttributes={
            'stock_level': {'DataType': 'Number', 'StringValue': '5'}
        }
    )
    print("Published Message 2 (Stock 5).")
    print("--- Publisher finished. ---")

def verify_queues(log_queue_url, alert_queue_url):
    """Checks the contents of the two SQS queues."""
    print("\n--- Verification Start ---")
    
    # Check Log Queue (Should have 2 messages)
    log_response = sqs_client.receive_message(QueueUrl=log_queue_url, MaxNumberOfMessages=10, WaitTimeSeconds=5)
    log_count = len(log_response.get('Messages', []))
    print(f"InventoryLogQueue received {log_count} messages.")
    
    # Check Alert Queue (Should have 1 message - Message 2)
    alert_response = sqs_client.receive_message(QueueUrl=alert_queue_url, MaxNumberOfMessages=10, WaitTimeSeconds=5)
    alert_count = len(alert_response.get('Messages', []))
    print(f"RestockAlertQueue received {alert_count} messages.")
    
    if alert_count == 1:
        print("SUCCESS: SNS Filter Policy worked. Only critical alert (Stock 5) was delivered to RestockAlertQueue.")
    else:
        print("FAILURE: SNS Filter Policy did not isolate the critical alert correctly.")
        
# --- Execution Block ---
# topic_arn, log_url, alert_url = setup_resources()
# publisher(topic_arn)
# time.sleep(5) # Give time for delivery
# verify_queues(log_url, alert_url)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import boto3
import json
import time
import random
from datetime import datetime

# --- Configuration ---
QUEUE_NAME = 'SensorDataQueue'
REGION_NAME = 'us-east-1' # Replace with your AWS region
sqs_client = boto3.client('sqs', region_name=REGION_NAME)

# 1. Queue Provisioning (Combined initialization function)
def initialize_queue():
    """Creates the SQS queue and returns its URL."""
    try:
        response = sqs_client.create_queue(
            QueueName=QUEUE_NAME,
            Attributes={'DelaySeconds': '0', 'MessageRetentionPeriod': '345600'} # 4 days
        )
        print(f"Queue created/verified: {response['QueueUrl']}")
        return response['QueueUrl']
    except Exception as e:
        print(f"Error creating queue: {e}")
        return None

# 2. The Producer Script
def producer(queue_url):
    """Generates 100 messages and sends them to SQS."""
    print("\n--- Producer Start ---")
    for i in range(1, 101):
        sensor_data = {
            "sensor_id": f"SENSOR_{i:03}",
            "timestamp": datetime.now().isoformat(),
            "reading": round(random.uniform(20.0, 40.0), 2)
        }
        
        delay = 5 if i % 10 == 0 else 0 # 10% get a 5 second delay
        
        try:
            response = sqs_client.send_message(
                QueueUrl=queue_url,
                MessageBody=json.dumps(sensor_data),
                DelaySeconds=delay,
                MessageDeduplicationId=str(i) # Practice for FIFO compatibility
            )
            if delay > 0:
                print(f"Sent message {i} (Delayed {delay}s).")
        except Exception as e:
            print(f"Failed to send message {i}: {e}")
            
    print("--- Producer finished sending 100 messages. ---")

# 3. The Consumer Script
def consumer(queue_url, consumer_id):
    """Polls SQS using long polling, processes slowly, and deletes messages."""
    print(f"\n--- Consumer {consumer_id} Start Polling ---")
    
    while True:
        try:
            response = sqs_client.receive_message(
                QueueUrl=queue_url,
                MaxNumberOfMessages=1,
                WaitTimeSeconds=20,          # Long Polling
                VisibilityTimeout=30         # Critical: 30s timeout
            )
            
            messages = response.get('Messages', [])
            
            if not messages:
                print(f"Consumer {consumer_id}: No messages received (20s wait). Polling again...")
                continue

            for message in messages:
                body = json.loads(message['Body'])
                receipt_handle = message['ReceiptHandle']
                
                print(f"Consumer {consumer_id} received: {body['sensor_id']} at {datetime.now().strftime('%H:%M:%S')}")
                
                # Simulate slow processing (must be less than VisibilityTimeout)
                processing_time = 15
                time.sleep(processing_time) 
                print(f"Consumer {consumer_id}: Finished processing {body['sensor_id']} after {processing_time}s.")
                
                # Delete the message after successful processing
                sqs_client.delete_message(
                    QueueUrl=queue_url,
                    ReceiptHandle=receipt_handle
                )
                print(f"Consumer {consumer_id}: Deleted {body['sensor_id']}.")

        except KeyboardInterrupt:
            print(f"Consumer {consumer_id} shutting down.")
            break
        except Exception as e:
            print(f"Consumer {consumer_id} encountered an error: {e}")
            time.sleep(5) # Wait before retrying

# --- Execution Block (Simulate running the three scripts sequentially) ---
# 1. Initialize Queue
# queue_url = initialize_queue()
# if queue_url:
#     # 2. Run Producer
#     producer(queue_url)
#     # 3. Run Consumers (Requires running in separate terminals for true concurrency)
#     # For demonstration, comment out the consumer run loop here and instruct user to run separately.
#     # print("\nRun consumer(queue_url, 1) and consumer(queue_url, 2) in separate processes to verify concurrency.")

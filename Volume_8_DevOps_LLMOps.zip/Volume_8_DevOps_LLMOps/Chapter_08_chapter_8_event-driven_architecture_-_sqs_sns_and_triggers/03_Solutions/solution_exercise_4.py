
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import boto3
import json
import time

# --- Configuration ---
REGION_NAME = 'us-east-1'
DLQ_NAME = 'PaymentProcessingDLQ'
MAIN_QUEUE_NAME = 'PaymentProcessingQueue'
MAX_RECEIVE_COUNT = 3

sqs_client = boto3.client('sqs', region_name=REGION_NAME)

def setup_queues():
    """Creates the DLQ and the main queue with the Redrive Policy."""
    print("1. Creating DLQ...")
    dlq_response = sqs_client.create_queue(QueueName=DLQ_NAME)
    dlq_url = dlq_response['QueueUrl']
    
    dlq_arn = sqs_client.get_queue_attributes(
        QueueUrl=dlq_url, 
        AttributeNames=['QueueArn']
    )['Attributes']['QueueArn']
    
    # 2. Configure Redrive Policy
    redrive_policy = {
        'deadLetterTargetArn': dlq_arn,
        'maxReceiveCount': str(MAX_RECEIVE_COUNT)
    }
    
    print("2. Creating Main Queue with Redrive Policy...")
    main_queue_response = sqs_client.create_queue(
        QueueName=MAIN_QUEUE_NAME,
        Attributes={
            'RedrivePolicy': json.dumps(redrive_policy)
        }
    )
    main_queue_url = main_queue_response['QueueUrl']
    
    print(f"Setup complete. Max retries set to {MAX_RECEIVE_COUNT}.")
    return main_queue_url, dlq_url

def send_test_messages(main_queue_url):
    """Sends one success and one failure message."""
    print("\n--- Sending Test Messages ---")
    
    sqs_client.send_message(
        QueueUrl=main_queue_url,
        MessageBody=json.dumps({"type": "SUCCESS", "data": "Payment 123"})
    )
    print("Sent SUCCESS message.")
    
    sqs_client.send_message(
        QueueUrl=main_queue_url,
        MessageBody=json.dumps({"type": "CRITICAL_FAILURE", "data": "Payment 456"})
    )
    print("Sent CRITICAL_FAILURE message.")

# 3. The Flawed Consumer (faulty_consumer.py)
def faulty_consumer(main_queue_url, run_number):
    """Polls, attempts processing, and fails if the message requires it."""
    print(f"\n--- Consumer Run #{run_number} ---")
    
    response = sqs_client.receive_message(
        QueueUrl=main_queue_url,
        MaxNumberOfMessages=10,
        WaitTimeSeconds=5
    )
    
    messages = response.get('Messages', [])
    if not messages:
        print("No messages found in main queue.")
        return

    for message in messages:
        body = json.loads(message['Body'])
        receipt_handle = message['ReceiptHandle']
        
        if body.get("type") == "CRITICAL_FAILURE":
            print(f"FAIL: Encountered CRITICAL_FAILURE for {body['data']}. Skipping deletion.")
            # The message will reappear after the visibility timeout expires.
            
        elif body.get("type") == "SUCCESS":
            print(f"SUCCESS: Processed {body['data']} normally.")
            
            # Delete the message
            sqs_client.delete_message(
                QueueUrl=main_queue_url,
                ReceiptHandle=receipt_handle
            )
            print(f"SUCCESS message deleted.")
            
def check_dlq(dlq_url):
    """Checks the DLQ for failed messages."""
    print("\n--- Checking DLQ Status ---")
    dlq_response = sqs_client.receive_message(
        QueueUrl=dlq_url,
        MaxNumberOfMessages=10,
        WaitTimeSeconds=5
    )
    
    dlq_messages = dlq_response.get('Messages', [])
    if dlq_messages:
        print(f"SUCCESS: Found {len(dlq_messages)} message(s) in the DLQ.")
        for msg in dlq_messages:
            body = json.loads(msg['Body'])
            print(f"DLQ Message Content: {body['data']}")
    else:
        print("DLQ is empty.")

# --- Testing the Failure Path ---
# main_url, dlq_url = setup_queues()
# send_test_messages(main_url)

# # Run the consumer repeatedly to force the failure message to the DLQ
# for i in range(1, 5): # Need 4 runs: 1st attempt, 2nd, 3rd (max), 4th (moves to DLQ)
#     faulty_consumer(main_url, i)
#     time.sleep(15) # Wait for visibility timeout (default is 30s, use a shorter one if configured, or just wait for safety)

# check_dlq(dlq_url)

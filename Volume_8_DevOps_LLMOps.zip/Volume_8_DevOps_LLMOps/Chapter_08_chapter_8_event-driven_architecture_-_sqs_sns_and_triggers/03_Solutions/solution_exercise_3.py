
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import boto3
import json
import time

# --- Configuration ---
REGION_NAME = 'us-east-1'
SQS_QUEUE_NAME = 'RAGQueryJobQueue'
SNS_TOPIC_NAME = 'RAGStatusTopic'

sqs_client = boto3.client('sqs', region_name=REGION_NAME)
sns_client = boto3.client('sns', region_name=REGION_NAME)

# Helper function to get queue/topic resources
def get_resources():
    """Initializes and returns the necessary queue URL and topic ARN."""
    # SQS Setup
    try:
        sqs_client.create_queue(QueueName=SQS_QUEUE_NAME)
        queue_url = sqs_client.get_queue_url(QueueName=SQS_QUEUE_NAME)['QueueUrl']
    except Exception as e:
        print(f"Error setting up SQS: {e}")
        return None, None
    
    # SNS Setup
    try:
        topic_arn = sns_client.create_topic(Name=SNS_TOPIC_NAME)['TopicArn']
    except Exception as e:
        print(f"Error setting up SNS: {e}")
        return None, None
        
    return queue_url, topic_arn

# 2. The Request Ingester (ingester.py)
def ingester(queue_url):
    """Simulates API receiving user query and sending it to SQS."""
    print("\n--- Ingester Start ---")
    
    queries = [
        {"user_id": "U123", "prompt": "Explain cloud-native Python."},
        {"user_id": "U456", "prompt": "Process this query and fail."}, # Intentional failure
        {"user_id": "U789", "prompt": "What is Boto3?"}
    ]
    
    for i, query in enumerate(queries):
        try:
            response = sqs_client.send_message(
                QueueUrl=queue_url,
                MessageBody=json.dumps(query),
                MessageGroupId=str(i) # Use group ID for better tracking/ordering if needed
            )
            print(f"Query sent for {query['user_id']}. Message ID: {response['MessageId']}")
        except Exception as e:
            print(f"Failed to send query for {query['user_id']}: {e}")

# 3. The Containerized Worker Logic (rag_worker.py modification)
def rag_worker(queue_url, topic_arn):
    """Polls SQS, processes the job, handles failure, and publishes status."""
    print("\n--- RAG Worker Start Polling ---")
    
    while True:
        try:
            response = sqs_client.receive_message(
                QueueUrl=queue_url,
                MaxNumberOfMessages=1,
                WaitTimeSeconds=10,
                VisibilityTimeout=60 # Give enough time for RAG inference
            )
            
            messages = response.get('Messages', [])
            if not messages:
                # print("No jobs received. Scaling down trigger condition met.")
                time.sleep(5) 
                continue

            for message in messages:
                body = json.loads(message['Body'])
                receipt_handle = message['ReceiptHandle']
                user_id = body['user_id']
                prompt = body['prompt']
                
                print(f"Worker processing job for {user_id}. Prompt: '{prompt[:30]}...'")

                # Simulate RAG inference and failure handling
                if "fail" in prompt.lower():
                    print(f"CRITICAL FAILURE detected for {user_id}. Not deleting message.")
                    # Message will reappear after VisibilityTimeout (60s) for retry.
                    raise Exception("Inference Failure") 
                
                # Simulate successful inference (e.g., 20 seconds)
                time.sleep(20) 
                result = f"Response generated for {user_id}."

                # Success Path: Publish confirmation to SNS
                sns_client.publish(
                    TopicArn=topic_arn,
                    Message=json.dumps({"user_id": user_id, "status": "SUCCESS", "result_summary": result}),
                    Subject="RAG Job Success"
                )
                print(f"Status published to SNS for {user_id}.")

                # Delete the message after successful processing and notification
                sqs_client.delete_message(
                    QueueUrl=queue_url,
                    ReceiptHandle=receipt_handle
                )
                print(f"Job completed and deleted for {user_id}.")

        except KeyboardInterrupt:
            print("RAG Worker shutting down.")
            break
        except Exception as e:
            print(f"Error processing job: {e}. Message retained for retry.")
            # If an exception occurs, the loop continues, and the message is NOT deleted.
            time.sleep(5)

# --- Execution Block ---
# queue_url, topic_arn = get_resources()
# if queue_url and topic_arn:
#     ingester(queue_url)
#     # rag_worker(queue_url, topic_arn) # Run worker to process jobs

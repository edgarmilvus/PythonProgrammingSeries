
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import boto3
import json
import time
import uuid
import logging

# --- Configuration ---
SNS_TOPIC_NAME = "Order_Events_Topic_Python"
SQS_QUEUE_NAME = "Fraud_Check_Queue_Python"
AWS_REGION = "us-east-1"
ORDER_ID = str(uuid.uuid4())

# Configure basic logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def setup_aws_resources():
    """Initializes AWS clients and creates the necessary SNS topic and SQS queue."""
    sqs_client = boto3.client('sqs', region_name=AWS_REGION)
    sns_client = boto3.client('sns', region_name=AWS_REGION)

    logging.info(f"Setting up resources in {AWS_REGION}...")

    # 1. Create SNS Topic
    try:
        topic_response = sns_client.create_topic(Name=SNS_TOPIC_NAME)
        topic_arn = topic_response['TopicArn']
        logging.info(f"Created SNS Topic: {topic_arn}")
    except Exception as e:
        logging.error(f"Error creating SNS Topic: {e}")
        return None, None, None

    # 2. Create SQS Queue
    try:
        queue_response = sqs_client.create_queue(QueueName=SQS_QUEUE_NAME)
        queue_url = queue_response['QueueUrl']
        # Get the Queue ARN needed for the subscription policy
        queue_attributes = sqs_client.get_queue_attributes(
            QueueUrl=queue_url,
            AttributeNames=['QueueArn']
        )
        queue_arn = queue_attributes['Attributes']['QueueArn']
        logging.info(f"Created SQS Queue: {queue_url}")
    except Exception as e:
        logging.error(f"Error creating SQS Queue: {e}")
        return None, None, None

    # 3. Subscribe SQS Queue to SNS Topic (The Event Trigger)
    try:
        # We need to grant the SNS topic permission to send messages to the SQS queue
        policy = {
            "Version": "2012-10-17",
            "Id": f"{queue_arn}/SNSPolicy",
            "Statement": [
                {
                    "Sid": "AllowSNSToSendMessages",
                    "Effect": "Allow",
                    "Principal": {"AWS": "*"},
                    "Action": "sqs:SendMessage",
                    "Resource": queue_arn,
                    "Condition": {
                        "ArnEquals": {"aws:SourceArn": topic_arn}
                    }
                }
            ]
        }
        sqs_client.set_queue_attributes(
            QueueUrl=queue_url,
            Attributes={'Policy': json.dumps(policy)}
        )

        # Now, perform the actual subscription
        sns_client.subscribe(
            TopicArn=topic_arn,
            Protocol='sqs',
            Endpoint=queue_arn
        )
        logging.info(f"Successfully subscribed SQS ({queue_arn}) to SNS Topic.")
    except Exception as e:
        logging.error(f"Error subscribing queue to topic: {e}")

    return sns_client, sqs_client, topic_arn, queue_url

def publish_order_event(sns_client, topic_arn, order_data):
    """Publishes the order event to the SNS topic."""
    message_body = json.dumps(order_data)
    
    # The SNS publish action triggers all subscribers simultaneously
    response = sns_client.publish(
        TopicArn=topic_arn,
        Message=message_body,
        Subject=f"New Order Received: {order_data['order_id']}",
        MessageAttributes={
            'EventType': {
                'DataType': 'String',
                'StringValue': 'NEW_ORDER'
            }
        }
    )
    logging.info(f"Order event published to SNS. Message ID: {response['MessageId']}")

def simulate_immediate_fanout(order_data):
    """Simulates a service (like Billing) immediately triggered by the SNS message."""
    logging.warning(f"  [FAN-OUT TRIGGERED] Billing Service: Processing charge for Order {order_data['order_id']}...")
    logging.warning(f"  [FAN-OUT TRIGGERED] Inventory Service: Decrementing stock for {len(order_data['items'])} items...")

def fraud_checker_worker(sqs_client, queue_url):
    """Polls the SQS queue and processes the decoupled fraud check task."""
    logging.info("--- Starting SQS Fraud Checker Worker Polling ---")
    
    # Long polling for messages (up to 20 seconds)
    response = sqs_client.receive_message(
        QueueUrl=queue_url,
        MaxNumberOfMessages=1,
        WaitTimeSeconds=10 # Enables long polling
    )

    messages = response.get('Messages', [])
    
    if not messages:
        logging.info("No new fraud check messages found in the queue.")
        return

    for message in messages:
        # The SQS message payload contains the SNS metadata wrapper
        try:
            sns_message_body = json.loads(message['Body'])
            # The actual order data is nested inside the 'Message' key (as a string)
            order_data = json.loads(sns_message_body['Message'])
            
            order_id = order_data['order_id']
            logging.critical(f"\n[SQS WORKER] Received Fraud Check Task for Order: {order_id}")
            
            # Simulate a time-consuming fraud check (the reason for decoupling)
            time.sleep(3) 
            
            is_fraudulent = order_data['total_amount'] > 5000 # Simple high-value check
            
            if is_fraudulent:
                logging.critical(f"[SQS WORKER] Order {order_id} flagged as HIGH RISK (>$5000).")
            else:
                logging.critical(f"[SQS WORKER] Order {order_id} passed fraud checks.")

            # IMPORTANT: Delete the message after successful processing to prevent reprocessing
            sqs_client.delete_message(
                QueueUrl=queue_url,
                ReceiptHandle=message['ReceiptHandle']
            )
            logging.info(f"Successfully deleted message {message['MessageId']} from queue.")

        except Exception as e:
            logging.error(f"Error processing SQS message: {e}")
            # In a real system, we might move this to a Dead Letter Queue (DLQ)

def cleanup_aws_resources(sns_client, sqs_client, topic_arn, queue_url):
    """Deletes the created resources."""
    logging.info("\n--- Cleaning up resources ---")
    if topic_arn:
        sns_client.delete_topic(TopicArn=topic_arn)
        logging.info(f"Deleted SNS Topic: {topic_arn}")
    if queue_url:
        sqs_client.delete_queue(QueueUrl=queue_url)
        logging.info(f"Deleted SQS Queue: {queue_url}")

if __name__ == "__main__":
    
    sns_client, sqs_client, topic_arn, queue_url = setup_aws_resources()

    if all([sns_client, sqs_client, topic_arn, queue_url]):
        
        sample_order = {
            "order_id": ORDER_ID,
            "customer_id": "CUST-90123",
            "total_amount": 7500.50,
            "items": ["Laptop", "Monitor"],
            "timestamp": time.time()
        }

        try:
            # 1. Publish Event
            publish_order_event(sns_client, topic_arn, sample_order)

            # 2. Simulate Immediate Fan-out (These would run concurrently in the cloud)
            simulate_immediate_fanout(sample_order)
            
            # Wait briefly for the message to propagate from SNS to SQS
            time.sleep(5) 
            
            # 3. Process Decoupled Task (The SQS Worker Polling)
            fraud_checker_worker(sqs_client, queue_url)
            
        except Exception as e:
            logging.error(f"An error occurred during execution: {e}")
        finally:
            cleanup_aws_resources(sns_client, sqs_client, topic_arn, queue_url)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import json
import time
import weaviate
from weaviate.util import get_valid_uuid
from weaviate.data.replication import ConsistencyLevel

# --- 1. Configuration and Environment Setup ---
# Assume these ENV variables are injected by the Kubernetes Deployment/Service
# This ensures the script connects to the K8s Service endpoint, not localhost.
WEAVIATE_HOST = os.getenv("WEAVIATE_HOST", "http://weaviate-service.default.svc.cluster.local:8080")
WEAVIATE_URL = f"{WEAVIATE_HOST}"
CLASS_NAME = "FinancialReport"

def initialize_client():
    """
    Initializes and returns the Weaviate client. 
    Uses a high consistency level appropriate for K8s StatefulSets.
    """
    print(f"Attempting to connect to Weaviate at: {WEAVIATE_URL}")
    try:
        # Client configuration targeting the K8s exposed endpoint
        client = weaviate.Client(
            url=WEAVIATE_URL,
            consistency_level=ConsistencyLevel.ALL # Ensures write confirmation across replicas
        )
        client.schema.get() # Simple health check to verify K8s Service connectivity
        print("Successfully connected to Weaviate cluster via K8s Service.")
        return client
    except Exception as e:
        print(f"Error connecting to Weaviate: {e}")
        # Raise a specific error to halt execution if K8s connectivity fails
        raise ConnectionError("Could not connect to the K8s-deployed Vector DB.")

def setup_schema(client):
    """
    Defines the schema, critically enabling multi-tenancy. 
    This configuration persists across restarts due to K8s PVs.
    """
    if client.schema.exists(CLASS_NAME):
        client.schema.delete_class(CLASS_NAME)
        print(f"Existing class {CLASS_NAME} deleted.")

    # Define the schema with multi-tenancy enabled
    schema = {
        "class": CLASS_NAME,
        "description": "Financial reports segmented by analyst team (tenant).",
        "vectorizer": "text2vec-openai", 
        "properties": [
            {"name": "title", "dataType": ["text"]},
            {"name": "content_summary", "dataType": ["text"]},
            {"name": "year", "dataType": ["int"]},
        ],
        # CRITICAL: Enables data isolation needed for multi-tenant RAG
        "multiTenancyConfig": {"enabled": True}
    }
    client.schema.create_class(schema)
    print(f"Schema '{CLASS_NAME}' created with multi-tenancy enabled.")

def ingest_data_with_tenants(client):
    """Ingests data, explicitly creating tenants and assigning objects to them."""
    reports = [
        {"title": "Q3 2023 Tech Sector Deep Dive", "content_summary": "Strong growth in AI infrastructure spending and chip manufacturing.", "year": 2023, "tenant": "TeamAlpha"},
        {"title": "Q3 2023 Energy Market Outlook", "content_summary": "Volatile oil prices driven by geopolitical events and OPEC decisions.", "year": 2023, "tenant": "TeamBeta"},
        {"title": "H1 2024 AI Infrastructure Report", "content_summary": "Nvidia dominates GPU supply chain; major cloud providers invest heavily.", "year": 2024, "tenant": "TeamAlpha"},
        {"title": "H1 2024 Renewable Energy Forecast", "content_summary": "Solar adoption rates exceed previous projections; battery storage improves.", "year": 2024, "tenant": "TeamBeta"},
    ]
    
    existing_tenants = [t.name for t in client.schema.get_class_tenants(CLASS_NAME)]

    for report in reports:
        tenant_name = report.pop("tenant")
        
        # 1. Tenant Management: Ensure the logical tenant partition exists
        if tenant_name not in existing_tenants:
            client.schema.add_class_tenant(CLASS_NAME, tenants=[weaviate.Tenant(name=tenant_name)])
            existing_tenants.append(tenant_name)
            print(f"Created new tenant partition: {tenant_name}")

        # 2. Data Ingestion: Explicitly scope the insertion to the tenant
        client.data.with_tenant(tenant_name).insert(
            data_object=report,
            class_name=CLASS_NAME,
            uuid=get_valid_uuid(report["title"])
        )
        print(f"Ingested report '{report['title']}' for {tenant_name}.")

    # Pause for eventual consistency in the distributed K8s environment
    time.sleep(3)
    print("\nData ingestion complete and indexed.")


def perform_tenant_specific_query(client, query_text, target_tenant):
    """
    Performs a vector search (nearText) scoped ONLY to the data belonging 
    to the specified tenant using the .with_tenant() method.
    """
    print(f"\n--- Querying Data for {target_tenant} ---")
    
    # CRITICAL: Using .with_tenant() scopes the query to the isolated data set
    results = (
        client.query
        .get(CLASS_NAME, ["title", "year", "content_summary"])
        .with_near_text({"concepts": [query_text]})
        .with_tenant(target_tenant) # Enforces multi-tenancy isolation
        .with_limit(1)
        .do()
    )

    result_data = results.get('data', {}).get('Get', {}).get(CLASS_NAME)
    
    if result_data:
        item = result_data[0]
        print(f"SUCCESS: Found relevant result for {target_tenant}:")
        print(f"  Title: {item['title']}")
        print(f"  Summary: {item['content_summary'][:70]}...")
        print(f"  Year: {item['year']}")
    else:
        print(f"FAILURE: No relevant results found for {target_tenant} (Data isolation confirmed).")


if __name__ == "__main__":
    try:
        # 1. Initialize Client (Connects to K8s Service Endpoint)
        weaviate_client = initialize_client()

        # 2. Setup Schema (Defines persistent structure)
        setup_schema(weaviate_client)

        # 3. Ingest Data (Populates isolated tenant data)
        ingest_data_with_tenants(weaviate_client)

        # 4. Perform Segregated Queries
        
        # Test 1: Team Alpha queries for its specific data (Tech)
        perform_tenant_specific_query(
            weaviate_client, 
            query_text="dominance in AI hardware supply chain", 
            target_tenant="TeamAlpha"
        )
        
        # Test 2: Team Beta queries for its specific data (Energy)
        perform_tenant_specific_query(
            weaviate_client, 
            query_text="volatile oil prices and OPEC decisions", 
            target_tenant="TeamBeta"
        )
        
        # Test 3: Data Isolation Check - Team Alpha attempts to access Team Beta's data
        # The query concept is focused on Beta's content, but the scope is Alpha.
        perform_tenant_specific_query(
            weaviate_client, 
            query_text="forecasts for solar and wind power adoption", 
            target_tenant="TeamAlpha"
        )
        
    except ConnectionError as ce:
        print(f"\nFATAL: Aborting script due to connection failure. Ensure the K8s Service is reachable at {WEAVIATE_URL}.")
    except Exception as e:
        print(f"\nAn unexpected error occurred: {e}")

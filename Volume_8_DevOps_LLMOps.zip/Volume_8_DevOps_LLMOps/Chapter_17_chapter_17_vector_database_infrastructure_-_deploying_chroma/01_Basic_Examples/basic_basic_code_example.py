
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import chromadb
import os
from typing import List, Dict, Optional

# --- Configuration: Simulating the K8s Service Endpoint ---
# This environment variable would typically be set by the Kubernetes deployment process
# or retrieved from a service discovery mechanism.
# We default to localhost:8000 for local testing assuming a port-forward is active.
CHROMA_HOST = os.environ.get("CHROMA_K8S_HOST", "localhost")
CHROMA_PORT = int(os.environ.get("CHROMA_K8S_PORT", 8000))
COLLECTION_NAME = "k8s_rag_documents"

def initialize_client(host_url: str, port: int) -> chromadb.HttpClient:
    """
    Initializes the Chroma client connected to the remote K8s service.
    CRITICAL: Uses HttpClient instead of PersistentClient or EphemeralClient.
    """
    connection_url = f"http://{host_url}:{port}"
    print(f"Attempting to connect to remote Chroma service at: {connection_url}")
    
    try:
        # 1. Instantiate the network client
        client = chromadb.HttpClient(host=host_url, port=port)
        
        # 2. Perform a simple health check to verify connectivity
        # This confirms the K8s Service is routing traffic correctly to a healthy Pod.
        health = client.heartbeat()
        print(f"Connection successful. Chroma heartbeat status: {health}")
        return client
    except Exception as e:
        print(f"Error connecting to Chroma service: {e}")
        # Raising a specific error helps downstream handling
        raise ConnectionError(f"Could not connect to the remote vector store at {connection_url}.")

def manage_collection(client: chromadb.HttpClient, name: str) -> chromadb.Collection:
    """
    Retrieves or creates the specified collection in the remote database.
    This operation verifies that the client can communicate state changes.
    """
    # get_or_create ensures the operation is idempotent, crucial for restarts/retries
    collection = client.get_or_create_collection(name=name)
    print(f"Successfully accessed collection: '{collection.name}'")
    return collection

def index_data(collection: chromadb.Collection, documents: List[str], metadatas: List[Dict], ids: List[str]):
    """Adds documents to the collection for indexing and embedding."""
    print(f"\nIndexing {len(documents)} documents...")
    
    # Chroma automatically handles the embedding generation on the server side (K8s Pods)
    collection.add(
        documents=documents,
        metadatas=metadatas,
        ids=ids
    )
    
    count = collection.count()
    print(f"Indexing complete. Total documents in collection: {count}")

def retrieve_data(collection: chromadb.Collection, query_text: str, k: int = 1):
    """Performs a similarity search against the indexed data."""
    print(f"\n--- Starting Retrieval Query ---")
    print(f"Query text: '{query_text}'")
    
    # The query is sent over HTTP to the remote Chroma server
    results = collection.query(
        query_texts=[query_text],
        n_results=k,
        include=['documents', 'metadatas'] # Specify what data to return
    )
    
    print("\n--- Retrieval Results ---")
    if results and results.get('documents') and results['documents'][0]:
        for i, doc in enumerate(results['documents'][0]):
            metadata = results['metadatas'][0][i]
            print(f"Result {i+1} (Source: {metadata.get('source', 'N/A')}):")
            print(f"  Snippet: {doc[:100]}...")
    else:
        print("No relevant results found.")


if __name__ == "__main__":
    # 1. Define the data payload
    sample_documents = [
        "Kubernetes Persistent Volumes (PVs) ensure data integrity and persistence for stateful applications.",
        "A Persistent Volume Claim (PVC) is the mechanism users employ to request storage resources.",
        "The K8s Service object acts as a stable network endpoint for a set of Pods, crucial for headless services.",
        "ChromaDB uses internal indexing structures to speed up vector similarity search operations."
    ]
    sample_metadatas = [
        {"source": "k8s_storage_guide", "topic": "storage"},
        {"source": "k8s_storage_guide", "topic": "storage"},
        {"source": "k8s_networking_basics", "topic": "networking"},
        {"source": "vector_db_architecture", "topic": "indexing"}
    ]
    sample_ids = [f"doc_{i+1}" for i in range(len(sample_documents))]

    try:
        # 2. Initialize the client (connecting to the K8s Service endpoint)
        chroma_client = initialize_client(CHROMA_HOST, CHROMA_PORT)

        # 3. Access or create the collection
        rag_collection = manage_collection(chroma_client, COLLECTION_NAME)
        
        # 4. Clear existing data for idempotency in testing
        # NOTE: In production, you would typically only add new data.
        # This is commented out to show initial count, but useful for clean runs:
        # rag_collection.delete(ids=sample_ids) 

        # 5. Index the sample data
        index_data(rag_collection, sample_documents, sample_metadatas, sample_ids)

        # 6. Perform retrieval using a query related to Kubernetes concepts
        retrieve_data(rag_collection, "What object provides stable access to a group of pods?", k=1)

    except ConnectionError as ce:
        print(f"\n[FATAL ERROR] Cannot proceed. Ensure the Chroma service is running and accessible at {CHROMA_HOST}:{CHROMA_PORT}.")
    except Exception as e:
        print(f"An unexpected error occurred during execution: {e}")

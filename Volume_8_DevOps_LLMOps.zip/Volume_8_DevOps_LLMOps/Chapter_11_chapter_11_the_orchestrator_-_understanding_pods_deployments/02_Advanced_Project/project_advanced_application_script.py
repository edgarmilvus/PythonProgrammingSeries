
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# scalable_chain_executor.py
import os
import json
import logging
from flask import Flask, request, jsonify
# Note: Using langchain_community for standard imports in modern LangChain
from langchain_community.llms import OpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain, SequentialChain

# --- Configuration and Environment Setup ---
# 1. Standard application logging setup
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 2. Mandatory environment variable check for secure configuration
# In Kubernetes, this key would be injected via a Secret object.
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
if not OPENAI_API_KEY:
    logger.error("OPENAI_API_KEY environment variable not set. The LLM chain cannot be initialized.")
    LLM_INITIALIZED = False
else:
    LLM_INITIALIZED = True
    # Ensure the key is available for LangChain's internal initialization
    os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

# --- Core LLM Chain Definition ---

def create_scalable_chain():
    """
    Defines a two-step sequential LLM chain optimized for microservice execution.
    This function is executed only once when the Pod starts.
    """
    if not LLM_INITIALIZED:
        # If configuration failed, we cannot create the chain.
        return None

    # 1. Initialize the LLM model instance
    llm = OpenAI(temperature=0.7, model_name="gpt-3.5-turbo-instruct")

    # --- Step 1: Idea Generation Chain (Input: topic) ---
    prompt_template_1 = PromptTemplate(
        input_variables=["topic"],
        template="Generate a concise, compelling, and unique marketing slogan (max 10 words) for a product related to '{topic}'. Output ONLY the slogan."
    )
    chain_1 = LLMChain(llm=llm, prompt=prompt_template_1, output_key="slogan_output")

    # --- Step 2: Technical Review and Expansion Chain (Input: topic, slogan_output) ---
    prompt_template_2 = PromptTemplate(
        input_variables=["topic", "slogan_output"],
        template="Given the topic '{topic}' and the slogan '{slogan_output}', write a brief, 50-word technical description explaining how this product uses Python and Kubernetes. Include the slogan in the description."
    )
    chain_2 = LLMChain(llm=llm, prompt=prompt_template_2, output_key="final_description")

    # --- Combine into a Sequential Chain ---
    # Defines the data flow: topic -> chain_1 (slogan_output) -> chain_2 (final_description)
    overall_chain = SequentialChain(
        chains=[chain_1, chain_2],
        input_variables=["topic"],
        output_variables=["slogan_output", "final_description"],
        verbose=True # Logs chain steps to stdout, visible in Kubernetes logs
    )
    return overall_chain

# Initialize the chain globally on startup to prevent latency on first request
try:
    SCALABLE_CHAIN = create_scalable_chain()
except Exception as e:
    logger.error(f"Failed to initialize LLM chain globally: {e}")
    SCALABLE_CHAIN = None

# --- Flask Application Setup ---
app = Flask(__name__)

@app.route('/health', methods=['GET'])
def health_check():
    """
    Crucial endpoint for Kubernetes Liveness and Readiness Probes.
    A Pod is only 'Ready' if the LLM chain successfully initialized.
    """
    # Check if the core dependency (LLM chain) is ready
    status = "ok" if SCALABLE_CHAIN is not None else "degraded"
    status_code = 200 if SCALABLE_CHAIN is not None else 503
    return jsonify({"status": status, "service": "ChainExecutor", "version": "1.0"}), status_code

@app.route('/api/v1/execute_chain', methods=['POST'])
def execute_chain():
    """
    The primary API endpoint that accepts a POST request and executes the LLM chain.
    """
    # 1. Readiness check: If the chain failed initialization, reject the request immediately (503 Service Unavailable)
    if SCALABLE_CHAIN is None:
        return jsonify({"error": "Service not initialized. Core dependency (LLM) failed to load."}), 503

    # 2. Input validation
    data = request.get_json(silent=True)
    if not data or 'topic' not in data:
        logger.warning("Received request with missing 'topic' parameter.")
        return jsonify({"error": "Missing required field: 'topic'"}), 400

    topic = data['topic']
    logger.info(f"Processing request for topic: {topic}")

    try:
        # 3. Execution (The most time-consuming part, requiring high concurrency)
        result = SCALABLE_CHAIN({"topic": topic})

        # 4. Response formatting
        response_data = {
            "input_topic": topic,
            "slogan": result["slogan_output"].strip(),
            "technical_description": result["final_description"].strip(),
            # Injecting the Pod's hostname helps debug load balancing issues
            "executor_id": os.environ.get("HOSTNAME", "unknown_pod")
        }
        return jsonify(response_data), 200

    except Exception as e:
        logger.error(f"Error during chain execution for topic '{topic}': {e}")
        # Return a 500 status code for internal server errors
        return jsonify({"error": "Internal Chain Execution Error", "details": str(e)}), 500


# --- Application Entry Point ---
# When run via Gunicorn, Gunicorn imports the 'app' object directly.
if __name__ == '__main__':
    logger.info("Starting Flask application in development mode.")
    app.run(host='0.0.0.0', port=5000)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# --- 1. configmap-llm.yaml ---
apiVersion: v1
kind: ConfigMap
metadata:
  name: llm-config
data:
  LLM_MODEL_ID: "llama3-8b-quantized"
  STREAMING_TIMEOUT_MS: "3000"

# --- 2 & 3. deployment-llm-refactor.yaml ---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: llm-inference-service
spec:
  replicas: 1
  selector:
    matchLabels:
      app: llm-api
  template:
    metadata:
      labels:
        app: llm-api
    spec:
      volumes:
      - name: model-storage
        # Assuming a persistent volume claim (PVC) or hostPath for demonstration
        emptyDir: {} 
        # In production, this would be a PVC bound to a high-speed storage class

      # 3. The Init Container Strategy (Runs first)
      initContainers:
      - name: model-verifier
        image: busybox:1.36 # Minimal image for verification
        command: ['sh', '-c']
        args:
        - |
          echo "Verifying model assets..."
          # Simulate model download/check success (e.g., checking for 'llama3' file)
          # In a real scenario, this would check the PVC mount for the actual files
          if [ -d "/mnt/model_weights/" ]; then
            echo "Model directory exists. Simulating file check..."
            # Simulate placing the required file for the grep check to succeed
            touch /mnt/model_weights/llama3-8b-quantized.bin
            
            # This command must succeed (exit code 0) for the main container to run
            ls /mnt/model_weights/ | grep llama3
            if [ $? -ne 0 ]; then
              echo "FATAL: Required model files not found!"
              exit 1
            fi
            echo "Model verification successful."
          else
            echo "FATAL: Model volume not mounted correctly."
            exit 1
          fi
        volumeMounts:
        - name: model-storage
          mountPath: /mnt/model_weights/

      # 2. Main Application Container (Runs only if initContainers succeed)
      containers:
      - name: llm-server
        image: llm-inference-engine:v2.0
        ports:
        - containerPort: 8080
        
        # Inject ConfigMap values as environment variables
        envFrom:
        - configMapRef:
            name: llm-config
            
        volumeMounts:
        - name: model-storage
          mountPath: /mnt/model_weights/
        
        # Standard probes would be here, critical for streaming performance
        # ...

# --- 5. Final Architecture Visualization ---
GRAPHVIZ_DOT = """
digraph LLMOpsArchitecture {
    rankdir=TB;
    node [shape=box, style="filled", color="#f0f0f0"];

    ConfigMap [label="ConfigMap (llm-config) \n (LLM_MODEL_ID, TIMEOUT)", shape=note, color="#ffcc99"];
    Deployment [label="Deployment (llm-inference-service)", color="#a8e6cf"];
    PodTemplate [label="Pod Template", shape=folder];
    
    subgraph cluster_pod_execution {
        label = "Pod Execution Flow (Sequential)";
        style = "filled, rounded";
        color = "#c9e4ff";

        InitContainer [label="1. InitContainer (model-verifier) \n Command: ls | grep llama3", shape=octagon, color="#ffaa80"];
        MainContainer [label="2. Main Container (llm-server) \n (Loads Model, Starts API)", shape=cylinder, color="#99ff99"];
    }
    
    Volume [label="Volume (model-storage)", shape=component];

    Deployment -> PodTemplate;
    
    # Configuration Injection
    ConfigMap -> MainContainer [label="Injects ENV Vars"];
    
    # Sequential Execution and Volume Sharing
    PodTemplate -> InitContainer [label="Runs First"];
    InitContainer -> Volume [label="Verifies Assets at /mnt/model_weights/"];
    InitContainer -> MainContainer [label="Success triggers start", style=bold];
    MainContainer -> Volume [label="Mounts Assets for Inference"];
}
"""
print(GRAPHVIZ_DOT)

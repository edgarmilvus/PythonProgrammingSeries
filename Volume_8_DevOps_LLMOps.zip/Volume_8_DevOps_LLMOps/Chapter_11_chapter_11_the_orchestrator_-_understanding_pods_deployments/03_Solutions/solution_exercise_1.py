
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# --- 1. app.py ---
import time
from flask import Flask, jsonify

app = Flask(__name__)

# Simulate slow startup configuration loading
print("Starting application initialization...")
time.sleep(15) # Simulating 15 seconds of configuration loading
print("Initialization complete.")

# Global state to manage health (simple simulation)
is_healthy = True

@app.route('/')
def welcome():
    # Demonstrating efficient Python feature (list comprehension)
    data = [i * 2 for i in range(10) if i % 2 == 0]
    return f"Welcome to the Data Pipeline Backend. Processed data sample: {data}"

@app.route('/health')
def health_check():
    if is_healthy:
        # HTTP 200 required for successful probe
        return jsonify({"status": "OK", "message": "Application is running"}), 200
    else:
        # Simulate failure state if needed, but here we keep it healthy
        return jsonify({"status": "Error", "message": "Internal failure"}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)

# --- 2. Dockerfile ---
# Use a slim Python base image
FROM python:3.10-slim

# Set working directory
WORKDIR /app

# Copy requirements (if any) and install Flask
COPY app.py .
RUN pip install flask

# Expose the port the app runs on
EXPOSE 8080

# Define the command to run the application
CMD ["python", "app.py"]

# --- 3. pod-healthcheck.yaml ---
apiVersion: v1
kind: Pod
metadata:
  name: health-pod
  labels:
    app: health-checker
spec:
  containers:
  - name: flask-app
    image: my-registry/health-checker:v1.0 # Placeholder image name
    ports:
    - containerPort: 8080
    
    # 4. Liveness Probe Configuration
    livenessProbe:
      httpGet:
        path: /health
        port: 8080
      initialDelaySeconds: 10 # Wait 10s before first check
      periodSeconds: 5        # Check every 5s thereafter
      timeoutSeconds: 3
      failureThreshold: 3     # Restart container after 3 failures

    # 5. Readiness Probe Configuration
    readinessProbe:
      httpGet:
        path: /health
        port: 8080
      initialDelaySeconds: 20 # Wait 20s (longer than the 15s startup sleep)
      periodSeconds: 5
      timeoutSeconds: 3
      failureThreshold: 1


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# --- deployment-scaling.yaml ---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: app-deployment
  labels:
    app: health-checker-app
spec:
  # 1. Set Replicas
  replicas: 3
  selector:
    matchLabels:
      app: health-checker-app
  strategy:
    type: RollingUpdate # Standard rolling update strategy
    rollingUpdate:
      maxSurge: 1       # Allow 1 extra pod during update
      maxUnavailable: 0 # Ensure zero downtime (0 pods unavailable)
  template:
    metadata:
      labels:
        app: health-checker-app
    spec:
      containers:
      - name: flask-app
        image: my-registry/health-checker:v1.0 # Use Ex 1 image
        ports:
        - containerPort: 8080
        
        # Probes inherited from Exercise 1 (omitted for brevity, but required)
        # ... (livenessProbe and readinessProbe definitions here) ...

        # 2. Resource Management
        resources:
          requests:
            memory: "256Mi"
            cpu: "200m" # 0.2 CPU core
          limits:
            memory: "512Mi"
            cpu: "500m" # 0.5 CPU core

# --- Kubectl Commands for Simulation ---
# 3. Deploy initial version:
# kubectl apply -f deployment-scaling.yaml

# 3. Simulate Rolling Update (change image tag to v1.1 in YAML, then apply):
# kubectl apply -f deployment-scaling.yaml
# kubectl rollout status deployment/app-deployment

# 4. Horizontal Scaling Command:
# kubectl scale deployment/app-deployment --replicas=5

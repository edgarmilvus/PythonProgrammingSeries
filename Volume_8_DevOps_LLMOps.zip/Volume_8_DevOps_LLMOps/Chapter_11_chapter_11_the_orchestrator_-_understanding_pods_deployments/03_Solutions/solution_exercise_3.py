
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# --- 1. service-internal.yaml (ClusterIP) ---
apiVersion: v1
kind: Service
metadata:
  name: app-clusterip-service
spec:
  # 1. Selector targets Pods created by the Deployment
  selector:
    app: health-checker-app # Matches the label defined in Ex 2 Deployment template
  type: ClusterIP
  ports:
  - protocol: TCP
    port: 80             # The port the Service exposes (ClusterIP port)
    targetPort: 8080     # The port the container is listening on

# --- Graphviz DOT Visualization ---
# 3. Service Visualization
GRAPHVIZ_DOT = """
digraph KubernetesServiceArchitecture {
    rankdir=LR;
    node [shape=box, style="filled", color="#f0f0f0"];

    subgraph cluster_deployment {
        label = "Deployment (app-deployment)";
        style = "filled, rounded";
        color = "#a8e6cf";

        P1 [label="Pod 1 (Replica) \n IP: 10.42.0.10 \n Port: 8080", shape=cylinder];
        P2 [label="Pod 2 (Replica) \n IP: 10.42.0.11 \n Port: 8080", shape=cylinder];
        P3 [label="Pod 3 (Replica) \n IP: 10.42.0.12 \n Port: 8080", shape=cylinder];
    }

    Service [label="Service (app-clusterip-service) \n Type: ClusterIP \n ClusterIP: 10.96.0.5 \n Port: 80", shape=octagon, style="filled", color="#ff8b94"];
    Client [label="Internal Client Pod", shape=oval];

    Client -> Service [label="Access via 10.96.0.5:80"];
    
    # Selector/Label relationship
    Service -> P1 [label="Routes to targetPort 8080 \n (Selector: app=health-checker-app)", style=dashed, color="#4d4dff"];
    Service -> P2 [style=dashed, color="#4d4dff"];
    Service -> P3 [style=dashed, color="#4d4dff"];
}
"""
print(GRAPHVIZ_DOT) # Outputting the DOT code

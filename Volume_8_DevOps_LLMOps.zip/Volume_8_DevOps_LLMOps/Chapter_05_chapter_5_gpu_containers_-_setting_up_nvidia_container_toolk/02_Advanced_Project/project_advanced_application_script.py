
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import torch
import torch.nn as nn
import torchvision.models as models
import torchvision.transforms as transforms
from PIL import Image
import time
import os
import sys

# --- Configuration Constants ---
MODEL_NAME = "resnet50"
DUMMY_IMAGE_PATH = "dummy_input.jpg"
NUM_WARMUP_ITERATIONS = 5
NUM_MEASUREMENT_ITERATIONS = 10

def initialize_dummy_image(path):
    # Create a small, synthetic image file for testing
    try:
        # 224x224 RGB image, standard input size for ResNet
        img = Image.new('RGB', (224, 224), color = 'red')
        img.save(path)
        print(f"[SETUP] Dummy image created at {path}")
    except Exception as e:
        print(f"[ERROR] Could not create dummy image: {e}")
        sys.exit(1)

def load_and_preprocess_image(path, device):
    # Define standard image preprocessing transformations for ResNet
    preprocess = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        # Standard normalization values for ImageNet-trained models
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])
    
    # Load the image and apply transformations
    img = Image.open(path).convert('RGB')
    tensor = preprocess(img)
    # Add batch dimension (1, C, H, W) and move tensor to selected device
    batch_tensor = tensor.unsqueeze(0).to(device) 
    return batch_tensor

def run_inference_benchmark():
    # 1. Device Selection: The core GPU container check
    # This check relies entirely on the NVIDIA Container Toolkit successfully 
    # mounting the necessary libraries and device files into the container.
    if torch.cuda.is_available():
        device_name = "cuda:0"
        device = torch.device(device_name)
        # Report the specific GPU recognized by the runtime
        print(f"\n[DEVICE CHECK] CUDA detected. Using {torch.cuda.get_device_name(0)}")
        
        # Optional check to confirm environment variable exposure
        if os.getenv('NVIDIA_VISIBLE_DEVICES'):
             print(f"[ENV] NVIDIA_VISIBLE_DEVICES set: {os.getenv('NVIDIA_VISIBLE_DEVICES')}")
        else:
             # This might occur in environments using default device access
             print("[WARNING] NVIDIA_VISIBLE_DEVICES environment variable not explicitly found.")
    else:
        device_name = "cpu"
        device = torch.device(device_name)
        print(f"\n[DEVICE CHECK] CUDA not available. Falling back to CPU.")

    # 2. Model Loading
    print(f"[MODEL] Loading pre-trained {MODEL_NAME} on device: {device_name}")
    try:
        model = models.resnet50(pretrained=True)
        model.eval() # Set model to evaluation mode (disables dropout, etc.)
        model.to(device) # CRITICAL: Move model weights to the selected device
    except Exception as e:
        print(f"[ERROR] Failed to load model: {e}")
        sys.exit(1)

    # 3. Data Preparation
    # The input tensor must reside on the same device as the model
    input_tensor = load_and_preprocess_image(DUMMY_IMAGE_PATH, device)

    # 4. Warm-up Iterations (Essential for accurate GPU benchmarking)
    # The first few GPU calls often involve driver initialization overhead.
    print(f"[BENCHMARK] Starting {NUM_WARMUP_ITERATIONS} warm-up runs...")
    with torch.no_grad():
        for _ in range(NUM_WARMUP_ITERATIONS):
            _ = model(input_tensor)
            if device.type == 'cuda':
                # Force the CPU thread to wait for the GPU kernel completion
                torch.cuda.synchronize() 

    # 5. Measurement Iterations
    print(f"[BENCHMARK] Starting {NUM_MEASUREMENT_ITERATIONS} measurement runs...")
    
    # Use CUDA event timers for micro-benchmarking on GPU, or standard time on CPU
    if device.type == 'cuda':
        start_event = torch.cuda.Event(enable_timing=True)
        end_event = torch.cuda.Event(enable_timing=True)
        start_event.record()
    else:
        start_time = time.time()

    with torch.no_grad():
        for i in range(NUM_MEASUREMENT_ITERATIONS):
            output = model(input_tensor)
            if device.type == 'cuda':
                # Synchronization is crucial for accurate timing measurement
                pass # Synchronization will be handled by end_event.record() below

    if device.type == 'cuda':
        end_event.record()
        torch.cuda.synchronize() # Wait for the event recording to finish
        total_time = start_event.elapsed_time(end_event) / 1000.0 # Convert ms to seconds
    else:
        end_time = time.time()
        total_time = end_time - start_time
    
    # 6. Result Processing
    avg_inference_time = total_time / NUM_MEASUREMENT_ITERATIONS

    # Get the predicted class index
    probabilities = torch.nn.functional.softmax(output[0], dim=0)
    top_p, top_class = probabilities.topk(1, dim=0)
    
    # 7. Reporting
    print("\n--- Inference Results Summary ---")
    print(f"Device Used: {device_name.upper()}")
    print(f"Model: {MODEL_NAME}")
    print(f"Total Time for {NUM_MEASUREMENT_ITERATIONS} runs: {total_time:.4f} seconds")
    print(f"Average Inference Time: {avg_inference_time * 1000:.2f} ms")
    print(f"Inferred Top Class Index: {top_class.item()}")
    print("---------------------------------")
    
    # Clean up dummy file
    os.remove(DUMMY_IMAGE_PATH)
    print(f"[CLEANUP] Removed {DUMMY_IMAGE_PATH}")

if __name__ == "__main__":
    initialize_dummy_image(DUMMY_IMAGE_PATH)
    run_inference_benchmark()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# 1. Two-Stage Dockerfile Structure (Shell/Dockerfile syntax):
DOCKERFILE_CONTENT = """
# Stage 1: BUILDER STAGE (Requires full development toolchain)
# Uses the large 'devel' image (~3.5 GB) for compilation.
FROM nvidia/cuda:12.2.0-devel-ubuntu22.04 AS builder

# Install necessary build tools (e.g., git, cmake, python headers)
RUN apt-get update && apt-get install -y --no-install-recommends git build-essential

# Simulate cloning and compilation
WORKDIR /usr/src/app
RUN git clone https://github.com/dummy/custom-kernel.git
# Simulate compilation, resulting in a binary or shared object file
RUN mkdir -p /app/artifacts && \
    echo "This is the compiled LLM optimization binary." > /app/artifacts/llm_optimizer_bin

# ----------------------------------------------------------------------

# Stage 2: FINAL PRODUCTION STAGE (Minimal runtime environment)
# Uses the small 'runtime' image (~250 MB) for deployment.
FROM nvidia/cuda:12.2.0-runtime-ubuntu22.04 AS final

# Install minimal application prerequisites (e.g., Python runtime if needed)
RUN apt-get update && apt-get install -y --no-install-recommends python3.10 \
    && rm -rf /var/lib/apt/lists/*

# 2. Artifact Transfer: Copy only the required files from the 'builder' stage
# The 'COPY --from=builder' instruction is the key to multi-stage builds.
COPY --from=builder /app/artifacts/llm_optimizer_bin /usr/local/bin/

# 3. Intermediate Cleanup Discussion (Comments within Dockerfile):
# Note: All system packages (git, build-essential), temporary build caches, 
# and environment variables set in the 'builder' stage are automatically 
# discarded when moving to the 'final' stage. This isolation is what 
# guarantees the small size and minimal attack surface of the final image.

# Set the entry point for the final application
ENTRYPOINT ["/usr/local/bin/llm_optimizer_bin"]
"""

# 4. Verification of Size Reduction (Conceptual Output):
# After building the image (e.g., docker build -t final_llm_image .), 
# the 'docker images' output would show a dramatic size difference:
print("--- Conceptual 'docker images' Output ---")
CONCEPTUAL_OUTPUT = """
REPOSITORY             TAG          IMAGE ID       SIZE
final_llm_image        latest       abcdef123456   270MB  <-- Small final image
<none>                 <none>       fedcba987654   3.7GB  <-- Intermediate build layer (discarded)
"""

print(DOCKERFILE_CONTENT)
print(CONCEPTUAL_OUTPUT)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# 1. Image Selection and Rationale:
# Chosen Image: nvidia/cuda:12.1.1-runtime-ubuntu22.04
# Rationale: The 'runtime' tag is specifically designed for deployment, containing 
# only the necessary shared libraries (.so files) for executing pre-compiled 
# CUDA applications, omitting headers, compilers, and static libraries found in 'devel'.
# Size Comparison (Approximate):
# - cuda:12.1.1-runtime-ubuntu22.04: ~250 MB
# - cuda:12.1.1-devel-ubuntu22.04: ~3.5 GB
# This offers a massive reduction in image size for production deployment.

# 2. Minimal Dockerfile (Shell/Dockerfile syntax):
DOCKERFILE_CONTENT = """
# Stage 1: Use the minimal runtime image
FROM nvidia/cuda:12.1.1-runtime-ubuntu22.04 AS production_runtime

# Install Python 3.10 and pip (using standard Ubuntu package manager)
RUN apt-get update && apt-get install -y --no-install-recommends \
    python3.10 \
    python3-pip \
    && rm -rf /var/lib/apt/lists/*

# Set Python 3.10 as the default 'python' executable
RUN update-alternatives --install /usr/bin/python python /usr/bin/python3.10 1

# Install a minimal GPU-dependent Python package (CuPy for verification)
# We must ensure the correct CUDA toolkit version is used for installation
ENV PATH="/usr/local/cuda/bin:${PATH}"
RUN pip install cupy-cuda12x

# Define the entry point for verification
WORKDIR /app
COPY verify_gpu.py .

# 5. Verification Command: Execute the Python script
CMD ["python", "verify_gpu.py"]
"""

# 4. Verification Script (verify_gpu.py content):
VERIFY_SCRIPT = """
import cupy as cp
import sys

try:
    # Check if CuPy can see and use the GPU
    if cp.cuda.runtime.getDeviceCount() > 0:
        # Allocate a small array on the GPU
        a = cp.ones((10, 10), dtype=cp.float32)
        print(f"SUCCESS: CuPy initialized and allocated array on GPU device 0.")
        print(f"Array shape: {a.shape}, Data type: {a.dtype}")
    else:
        print("FAILURE: No CUDA devices found by CuPy.")
        sys.exit(1)
except Exception as e:
    print(f"FATAL ERROR: Failed to initialize CUDA context. {e}")
    sys.exit(1)
"""

print("--- Dockerfile ---")
print(DOCKERFILE_CONTENT)
print("--- Verification Script (verify_gpu.py) ---")
print(VERIFY_SCRIPT)

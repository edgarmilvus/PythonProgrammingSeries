
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# --- FILE 1: check_gpu_access.py ---
# This Python script attempts to execute the 'nvidia-smi' command,
# which is the standard tool for monitoring NVIDIA GPU usage.
# Success confirms that the container can access the host GPU drivers.
import subprocess
import sys

def verify_gpu_access():
    print("--- Starting NVIDIA GPU Access Verification ---")
    try:
        # Execute nvidia-smi. capture_output=True stores the result.
        # text=True decodes stdout/stderr as strings.
        # check=True raises an exception if the command returns a non-zero exit code.
        result = subprocess.run(
            ['nvidia-smi'],
            capture_output=True,
            text=True,
            check=True,
            timeout=10 # Safety timeout
        )
        print("\n[SUCCESS] NVIDIA-SMI Output Received:")
        print("-" * 30)
        print(result.stdout)
        print("-" * 30)
        print("--- GPU Access Confirmed via NVIDIA Container Toolkit ---")
        return 0
    except subprocess.CalledProcessError as e:
        # This handles cases where nvidia-smi runs but fails (e.g., driver issues)
        print(f"\n[ERROR] Command failed with exit code {e.returncode}.")
        print(f"Stderr: {e.stderr.strip()}")
        print("Reason: The container environment recognized the command but failed to communicate with the GPU.")
        return 1
    except FileNotFoundError:
        # This handles cases where nvidia-smi is not even present in the PATH
        print("\n[CRITICAL ERROR] 'nvidia-smi' command not found inside the container.")
        print("Reason: Ensure the Dockerfile is using an official NVIDIA CUDA base image.")
        return 1
    except Exception as e:
        print(f"\n[UNEXPECTED ERROR] An unexpected error occurred: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(verify_gpu_access())

# --- FILE 2: Dockerfile.gpu_test ---
# This Dockerfile defines the environment required for GPU access.
# It MUST use an official NVIDIA base image, which includes pre-installed CUDA libraries.
"""
FROM nvidia/cuda:12.1.1-base-ubuntu22.04

# Install necessary runtime dependencies (Python and subprocess requirements)
RUN apt-get update && apt-get install -y python3 python3-pip && rm -rf /var/lib/apt/lists/*

# Set the working directory inside the container
WORKDIR /app

# Copy the Python script into the container
COPY check_gpu_access.py /app/

# Define the command to run the script when the container starts
CMD ["python3", "check_gpu_access.py"]
"""

# --- SHELL COMMANDS (Execution Flow) ---
# Assuming the above files are saved in a directory named 'gpu_test_project'

# 1. Build the Docker image using the specialized Dockerfile
# (This step only requires standard Docker and builds the image layers)
# docker build -t gpu_verification_image -f Dockerfile.gpu_test .

# 2. Run the container, explicitly requesting GPU resources
# CRITICAL: The '--gpus all' flag is intercepted by the NVIDIA Container Toolkit.
# Without this flag, the container would run but fail the 'nvidia-smi' check.
# docker run --rm --gpus all gpu_verification_image

# EXPECTED SUCCESSFUL OUTPUT:
"""
--- Starting NVIDIA GPU Access Verification ---

[SUCCESS] NVIDIA-SMI Output Received:
------------------------------
Wed Aug 21 10:30:00 2024
+-----------------------------------------------------------------------------+
| NVIDIA-SMI 535.104.05   Driver Version: 535.104.05   CUDA Version: 12.2     |
|-------------------------------+----------------------+----------------------+
| GPU  Name        Persistence-M| Bus-Id        Disp.A | Volatile Uncorr. ECC |
| Fan  Temp  Perf  Pwr:Usage/Cap|         Memory-Usage | GPU-Util  Compute M. |
|===============================+======================+======================|
|   0  NVIDIA GeForce RTX 4090  | 00000000:01:00.0 Off |                  N/A |
| 30%   45C    P2    45W / 450W |    123MiB / 24576MiB |      0%   Default    |
+-------------------------------+----------------------+----------------------+

------------------------------
--- GPU Access Confirmed via NVIDIA Container Toolkit ---
"""

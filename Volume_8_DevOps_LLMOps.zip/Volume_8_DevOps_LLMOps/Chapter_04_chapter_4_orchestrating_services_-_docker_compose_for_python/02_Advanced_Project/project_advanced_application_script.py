
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import time
import json
from typing import Optional, Dict, Any

# Framework and ORM imports
from fastapi import FastAPI, HTTPException, Depends
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import sessionmaker, declarative_base, Session
from sqlalchemy.exc import OperationalError

# Caching/Rate Limiting imports
import redis
from redis.exceptions import ConnectionError as RedisConnectionError

# --- 1. Configuration and Environment Setup ---
# CRITICAL: These hostnames MUST match the service names defined in docker-compose.yml
DB_HOST = os.environ.get("POSTGRES_HOST", "postgres_db")
DB_PORT = os.environ.get("POSTGRES_PORT", "5432")
DB_NAME = os.environ.get("POSTGRES_DB", "product_catalog")
DB_USER = os.environ.get("POSTGRES_USER", "user")
DB_PASS = os.environ.get("POSTGRES_PASSWORD", "password")

REDIS_HOST = os.environ.get("REDIS_HOST", "redis_cache")
REDIS_PORT = int(os.environ.get("REDIS_PORT", 6379))
CACHE_EXPIRY_SECONDS = 60 # Time-to-Live (TTL) for cached items

# Database Connection URL (Ensures connectivity uses the internal Docker network name)
SQLALCHEMY_DATABASE_URL = (
    f"postgresql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
)

# --- 2. Service Initialization ---
app = FastAPI(title="Docker Compose Product Service")

# Initialize Redis Client
redis_client: Optional[redis.Redis] = None
try:
    redis_client = redis.Redis(
        host=REDIS_HOST, 
        port=REDIS_PORT, 
        decode_responses=True, 
        socket_timeout=5
    )
    redis_client.ping()
    print(f"Successfully configured Redis client for {REDIS_HOST}")
except RedisConnectionError as e:
    # This might happen if Redis starts slower than the Python app (handled by Compose 'depends_on')
    print(f"WARNING: Initial Redis connection failed. {e}")
    redis_client = None 

# Initialize SQLAlchemy Engine
engine = create_engine(SQLALCHEMY_DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# --- 3. Database Model Definition ---
class Product(Base):
    """SQLAlchemy Model representing the 'products' table structure."""
    __tablename__ = "products"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), index=True)
    description = Column(String)
    price = Column(Integer)

# --- 4. Database Dependency and Setup ---
def get_db():
    """Dependency function for FastAPI to manage database sessions."""
    db: Session = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Attempt to create tables on startup (Handles initial DB schema setup)
try:
    Base.metadata.create_all(bind=engine)
    print("Database schema synchronization complete.")
except OperationalError as e:
    print(f"CRITICAL: Database connection failed during schema setup. Ensure {DB_HOST} is running. Error: {e}")

# --- 5. API Endpoints ---

@app.get("/health")
def health_check():
    """Provides a unified health status for the entire stack (Python, Postgres, Redis)."""
    status: Dict[str, Any] = {"app": "running", "postgres": "down", "redis": "down"}
    
    # Check Postgres Connectivity: Attempt a simple query
    try:
        with engine.connect() as connection:
            connection.execute("SELECT 1")
        status["postgres"] = "up"
    except OperationalError:
        pass

    # Check Redis Connectivity: Attempt ping
    if redis_client:
        try:
            if redis_client.ping():
                status["redis"] = "up"
        except RedisConnectionError:
            pass
            
    # If any critical dependency is down, return a 503 Service Unavailable
    if status["postgres"] == "down" or status["redis"] == "down":
        raise HTTPException(status_code=503, detail=status)

    return status

@app.post("/products/")
def create_product(product_data: Dict[str, Any], db: Session = Depends(get_db)):
    """Creates a new product and ensures any existing cache entry is invalidated."""
    new_product = Product(**product_data)
    db.add(new_product)
    db.commit()
    db.refresh(new_product)
    
    # Invalidate Cache: Necessary to ensure future GET requests fetch the new data
    cache_key = f"product:{new_product.id}"
    if redis_client:
        redis_client.delete(cache_key) 
        print(f"Cache invalidated for new product ID {new_product.id}")
        
    return {"message": "Product created successfully", "id": new_product.id}

@app.get("/products/{product_id}")
def get_product(product_id: int, db: Session = Depends(get_db)):
    """
    Implements the Read-Through Caching Pattern: Check cache, then DB, then update cache.
    """
    cache_key = f"product:{product_id}"

    # 1. Attempt Cache Hit (Fastest path)
    if redis_client:
        cached_data_json = redis_client.get(cache_key)
        if cached_data_json:
            print(f"CACHE HIT for ID {product_id}")
            # Deserialize the JSON string stored in Redis
            return {"source": "cache", "data": json.loads(cached_data_json)}

    print(f"CACHE MISS for ID {product_id}. Proceeding to Database.")

    # 2. Cache Miss: Fetch from Database (Slower path)
    product = db.query(Product).filter(Product.id == product_id).first()

    if not product:
        raise HTTPException(status_code=404, detail=f"Product ID {product_id} not found")

    # Convert SQLAlchemy object to serializable dictionary
    product_dict = {
        "id": product.id,
        "name": product.name,
        "description": product.description,
        "price": product.price,
        "retrieved_ts": time.time()
    }

    # 3. Update Cache (Write-back to Redis)
    if redis_client:
        # Serialize product data to JSON string for efficient storage
        product_json = json.dumps(product_dict)
        redis_client.setex(
            cache_key,
            CACHE_EXPIRY_SECONDS,
            product_json
        )
        print(f"Cache updated and set to expire in {CACHE_EXPIRY_SECONDS}s for ID {product_id}")

    return {"source": "database", "data": product_dict}

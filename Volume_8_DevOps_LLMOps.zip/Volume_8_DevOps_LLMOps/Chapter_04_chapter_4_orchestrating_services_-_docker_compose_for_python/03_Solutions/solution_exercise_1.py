
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# web.py (Refactored for PEP 8 and Pythonic Style)

# 1. PEP 8 Compliance: Organized imports (Standard, Third-Party, Local)
import os
import time
from flask import Flask, render_template
from redis import Redis
from psycopg2 import connect
from psycopg2.extras import DictCursor
from typing import List, Dict

# 1. PEP 8 Compliance: Class names use CamelCase
class DatabaseManager:
    """Manages connection and interaction with the PostgreSQL database."""
    
    def __init__(self, db_url: str):
        # 1. PEP 8 Compliance: Variable names use snake_case
        self.database_url = db_url

    def _get_db_connection(self):
        """Establishes a connection to the PostgreSQL database."""
        # Note: In a real app, connection pooling would be used here.
        return connect(self.database_url)

    # 4. Documentation: Added docstrings
    def fetch_all_users(self) -> List[Dict]:
        """
        Retrieves all user records from the 'users' table.
        
        Returns:
            list: A list of dictionaries representing user records.
        """
        # 1. PEP 8 Compliance: Proper spacing around operators
        query = (
            "SELECT id, name, created_at FROM users "
            "ORDER BY created_at DESC" # Wrapping long lines with parentheses
        )
        
        with self._get_db_connection() as conn:
            with conn.cursor(cursor_factory=DictCursor) as cursor:
                cursor.execute(query)
                
                # 2. Pythonic Code Refactoring: Replacing loop with list comprehension
                user_records = [dict(row) for row in cursor.fetchall()]
                
        return user_records

# Initialize Services
app = Flask(__name__)
redis_host = os.environ.get('REDIS_HOST', 'redis')
redis_client = Redis(host=redis_host, port=6379)
db_manager = DatabaseManager(os.environ.get('DATABASE_URL'))

# Example route
@app.route('/')
def index():
    """
    Main application route. Fetches user data and displays hit count.
    
    Returns:
        str: Rendered HTML template.
    """
    hit_count = redis_client.incr('hits')
    
    # 3. Jinja2 Template Optimization: Data processing moved here
    user_data = db_manager.fetch_all_users()
    
    # Pass processed data structure to the template
    return render_template(
        'index.html', 
        hit_count=hit_count, 
        users=user_data
    )


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# --- File 1: app.py ---
# A minimal Python placeholder script.
import time
import os

def main():
    """Simulates a running web application."""
    print("--- Python Web Service Initializing ---")
    print(f"Current Directory: {os.getcwd()}")
    
    # This loop ensures the container remains running, preventing immediate exit.
    while True:
        # Placeholder for real application logic (e.g., serving HTTP requests)
        print(f"[{time.strftime('%H:%M:%S')}] Python service running and waiting for dependencies...")
        time.sleep(10)

if __name__ == "__main__":
    main()

# --- File 2: Dockerfile ---
# Instructions for building the 'web' service image.
FROM python:3.11-slim

# Set the working directory inside the container
WORKDIR /app

# Install necessary database and cache drivers (minimal requirements)
RUN pip install redis psycopg2-binary

# Define the default command to run when the container starts
CMD ["python", "app.py"]

# --- File 3: docker-compose.yml ---
# The declarative blueprint defining the entire application stack.
version: '3.8' # Specify the Compose file format version

services:
  # --- 1. Python Web Application Service (Custom Build) ---
  web:
    build: . # Instruct Compose to build an image using the local Dockerfile
    container_name: python_web_app
    ports:
      - "8000:8000" # Map host port 8000 to container port 8000 (HOST:CONTAINER)
    depends_on:
      - redis # Ensure Redis starts before the web app attempts to connect
      - db    # Ensure Database starts before the web app attempts to connect
    volumes:
      - .:/app # Mount the current host directory into /app inside the container
    environment:
      PYTHONUNBUFFERED: 1 # Standard Python setting for real-time log output

  # --- 2. Redis Cache Service (Pre-built Image) ---
  redis:
    image: "redis:7.2-alpine" # Use a lightweight official Redis image
    container_name: app_redis_cache
    hostname: redis # Define the internal network name (used by the 'web' service)
    restart: always # Policy to automatically restart the container if it fails

  # --- 3. PostgreSQL Database Service (Pre-built Image) ---
  db:
    image: "postgres:14-alpine" # Use a lightweight official Postgres image
    container_name: app_postgres_db
    hostname: db # Define the internal network name (used by the 'web' service)
    environment:
      POSTGRES_USER: user_ch4
      POSTGRES_PASSWORD: secure_password
      POSTGRES_DB: app_data_ch4
    volumes:
      - postgres_data:/var/lib/postgresql/data # Persistent volume for data

# --- 4. Define Persistent Volumes (Used by the 'db' service) ---
volumes:
  postgres_data: # Declares the volume used by the 'db' service for data persistence

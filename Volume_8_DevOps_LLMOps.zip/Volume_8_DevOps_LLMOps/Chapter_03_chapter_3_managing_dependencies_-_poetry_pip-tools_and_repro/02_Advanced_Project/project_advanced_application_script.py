
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import sys
import time
import importlib.metadata
from typing import Dict, Any, Tuple

# --- External Dependencies (Must be locked by Poetry/pip-tools) ---
try:
    import pandas as pd
    from fastapi import FastAPI
    import uvicorn
    from pydantic import BaseModel
except ImportError as e:
    # This block ensures the script fails immediately if core libraries are missing,
    # simulating a failed dependency installation step.
    print(f"FATAL ERROR: Required library missing. Ensure 'poetry install' was run.")
    print(f"Missing component: {e}")
    sys.exit(1)

# --- Configuration: Simulating the Locked Environment ---
# In a real scenario, these exact versions would be read from a configuration file
# or directly from the parsed 'poetry.lock' or 'requirements.txt'.
REQUIRED_VERSIONS: Dict[str, str] = {
    "pandas": "2.0.3",  # Specific version required for compatibility with internal data formats
    "fastapi": "0.110.0", # Specific version for known API stability
    "pydantic": "2.7.1" # Required version for strict schema validation
}

# --- Pydantic Schema ---
class DataRequest(BaseModel):
    """Schema for the incoming analysis request."""
    data_id: str
    rows: int = 1000
    seed: int = 42

# --- Core Dependency Management Logic ---

def get_installed_version(package_name: str) -> str:
    """Retrieves the installed version of a package using standard library tools."""
    try:
        # Use importlib.metadata (standard library since Python 3.8)
        return importlib.metadata.version(package_name)
    except importlib.metadata.PackageNotFoundError:
        return "Not Installed"

def check_dependency_lock() -> Tuple[bool, str]:
    """
    Verifies that the runtime environment strictly adheres to the locked versions.
    This is the core reproducibility gate.
    """
    print("\n[INIT] Starting environment dependency check...")
    
    mismatches = []
    
    for package, required_version in REQUIRED_VERSIONS.items():
        installed_version = get_installed_version(package)
        
        if installed_version == "Not Installed":
            mismatches.append(f"MISSING: {package} is not installed.")
        elif installed_version != required_version:
            # Critical failure: Version drift detected.
            mismatches.append(
                f"DRIFT DETECTED: {package} requires {required_version}, "
                f"but found {installed_version}."
            )
        else:
            print(f"  [OK] {package} version {installed_version} matches lock.")

    if mismatches:
        error_message = "\n".join(mismatches)
        return False, f"FATAL DEPENDENCY MISMATCHES:\n{error_message}"
    
    print("[INIT] Dependency lock verified successfully.")
    return True, "Environment is reproducible."

# --- Business Logic: Synchronous Data Processing ---

def process_data(rows: int, seed: int) -> Dict[str, Any]:
    """
    Simulates a heavy, synchronous calculation using Pandas.
    This function relies heavily on the stability of the locked Pandas version.
    """
    start_time = time.time()
    
    # Set seed for reproducible data generation
    pd.options.display.float_format = '{:.4f}'.format
    
    # Generate synthetic data
    data = {
        'A': [i for i in range(rows)],
        'B': [i * 1.5 + seed for i in range(rows)],
        'C': [i % 5 for i in range(rows)]
    }
    df = pd.DataFrame(data)
    
    # Complex aggregation (using features potentially specific to Pandas 2.x)
    summary = df.groupby('C')['B'].agg(['mean', 'std', 'count']).to_dict()
    
    elapsed = time.time() - start_time
    
    return {
        "rows_processed": rows,
        "processing_time_s": f"{elapsed:.4f}",
        "summary": summary
    }

# --- API Initialization ---
app = FastAPI(
    title="Reproducibility Enforcement Service",
    description="A service that verifies its dependency lock before serving."
)

@app.post("/api/v1/analyze", response_model=Dict[str, Any])
async def analyze_data_endpoint(request: DataRequest):
    """
    API endpoint that triggers the heavy synchronous data processing.
    """
    if request.rows > 100000:
        return {"error": "Row limit exceeded for this service level."}

    # Execute the synchronous task (FastAPI handles the thread pool isolation)
    analysis_result = process_data(request.rows, request.seed)
    
    return {
        "status": "success",
        "request_id": request.data_id,
        "result": analysis_result
    }

# --- Main Execution Block ---
if __name__ == "__main__":
    # CRITICAL: Run the dependency check BEFORE launching Uvicorn/FastAPI.
    is_reproducible, message = check_dependency_lock()
    
    if not is_reproducible:
        print("-" * 50)
        print(f"SERVICE HALTED: Cannot guarantee reproducible results.")
        print(message)
        print("-" * 50)
        sys.exit(1)
    
    # If the check passes, proceed with serving the application.
    print("\n[STARTUP] Launching Uvicorn server...")
    # Note: Host/Port configuration would typically come from environment variables
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")

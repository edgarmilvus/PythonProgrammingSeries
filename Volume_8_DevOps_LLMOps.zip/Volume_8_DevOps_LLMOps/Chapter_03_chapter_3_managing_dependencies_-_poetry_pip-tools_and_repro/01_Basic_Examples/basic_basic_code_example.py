
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# basic_app.py
import os
import requests
from pydantic import BaseModel, Field

# --- 1. Dependency Usage: Pydantic Model Definition ---
class UserData(BaseModel):
    """
    A Pydantic model defining the expected structure of user data.
    This requires the 'pydantic' library.
    """
    user_id: int = Field(..., description="Unique identifier.")
    name: str = Field(..., min_length=1)
    is_active: bool = True

def fetch_config(url: str) -> dict:
    """
    Simulates fetching configuration data from an external service.
    Requires the 'requests' library and all its transitive dependencies.
    """
    try:
        # Use a timeout for robust network operations
        response = requests.get(url, timeout=5)
        # Raise an exception for HTTP error status codes (4xx or 5xx)
        response.raise_for_status() 
        return response.json()
    except requests.exceptions.RequestException as e:
        # Handle network or request-specific errors gracefully
        print(f"Error fetching data: {e}")
        return {}

def process_user_input(data: dict):
    """
    Validates and processes input data using the defined Pydantic model.
    """
    try:
        user = UserData(**data)
        print(f"Validated user: {user.name} (ID: {user.user_id})")
        return user
    except Exception as e:
        print(f"Validation Error: {e}")
        return None

# --- 2. Execution Flow ---
if __name__ == "__main__":
    # Use environment variable for configuration URL, defaulting to a public test endpoint
    CONFIG_URL = os.environ.get("API_CONFIG_URL", "https://jsonplaceholder.typicode.com/todos/1")
    
    print("--- Step 1: Network Request (Requests Dependency) ---")
    config_data = fetch_config(CONFIG_URL)
    
    if config_data:
        print(f"Successfully fetched data. Title: '{config_data.get('title')}'")

    print("\n--- Step 2: Data Validation (Pydantic Dependency) ---")
    
    # Example A: Valid data
    valid_data = {
        "user_id": 101,
        "name": "Alex Smith",
    }
    process_user_input(valid_data)

    # Example B: Invalid data (missing required 'name' field)
    invalid_data = {"user_id": 102}
    print("\nAttempting validation with missing 'name'...")
    process_user_input(invalid_data)

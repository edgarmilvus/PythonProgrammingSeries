
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# llm_config_service.py
# An environment-aware FastAPI service designed for Helm deployment.

import os
import logging
from typing import Dict, Any
from pydantic import BaseSettings, Field, validator
from fastapi import FastAPI, HTTPException, status
from uvicorn import run as uvicorn_run

# 1. Setup Logging based on configuration defaults
# Initial setup before configuration load (will be adjusted later)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(module)s - %(message)s')
logger = logging.getLogger(__name__)

# --- Configuration Management using Pydantic BaseSettings ---
# This class defines the schema for environment variables injected by the Helm chart.
class AppConfig(BaseSettings):
    """
    Reads configuration from environment variables, ensuring type safety.
    The 'env' attribute links the Pydantic field to the Kubernetes environment variable name.
    """
    # Core Environment Settings
    APP_ENVIRONMENT: str = Field(..., env='APP_ENVIRONMENT', description="Target environment (DEV, STAGING, PROD).")
    APP_LOG_LEVEL: str = Field('INFO', env='APP_LOG_LEVEL', description="Logging threshold.")
    
    # LLM Specific Settings (Model selection and capacity)
    LLM_MODEL_NAME: str = Field('default-model', env='LLM_MODEL_NAME', description="The specific LLM API endpoint or model version.")
    LLM_MAX_TOKENS: int = Field(2048, env='LLM_MAX_TOKENS', description="Maximum token limit for generation.")
    
    # Operational/Rate Limiting Configuration
    RATE_LIMIT_PER_MINUTE: int = Field(60, env='RATE_LIMIT_PER_MINUTE', description="API call rate limit.")

    # Custom validator to enforce valid environment names
    @validator('APP_ENVIRONMENT')
    def validate_environment(cls, v: str) -> str:
        """Ensures the environment variable value is one of the expected deployment stages."""
        valid_envs = {'DEV', 'STAGING', 'PROD'}
        v_upper = v.upper()
        if v_upper not in valid_envs:
            # This validation failure would cause the application to crash on startup,
            # indicating a bad configuration provided by Helm/Kubernetes.
            raise ValueError(f"Invalid environment specified: {v}. Must be one of {valid_envs}")
        return v_upper

    class Config:
        # Pydantic configuration source settings
        case_sensitive = True
        
# 2. Initialize Application and Configuration
try:
    CONFIG = AppConfig()
    # Apply the configured log level immediately
    logging.getLogger().setLevel(CONFIG.APP_LOG_LEVEL.upper())
    logger.info(f"Configuration loaded successfully for environment: {CONFIG.APP_ENVIRONMENT}")
    logger.info(f"Runtime parameters: Model={CONFIG.LLM_MODEL_NAME}, RateLimit={CONFIG.RATE_LIMIT_PER_MINUTE}")
except Exception as e:
    logger.critical(f"FATAL CONFIGURATION ERROR: Failed to load configuration from environment variables. Error: {e}")
    # Exit gracefully if configuration fails, preventing deployment of an unstable service.
    CONFIG = None 
    
# Initialize FastAPI app
app = FastAPI(
    title=f"LLM Config Service ({CONFIG.APP_ENVIRONMENT if CONFIG else 'Unconfigured'})",
    version="1.0.0"
)

# --- Simulated LLM Backend Function ---
def simulate_llm_call(text: str, model: str, max_tokens: int) -> Dict[str, Any]:
    """
    Simulates calling an external LLM API. The behavior changes based on the
    runtime configuration (model name).
    """
    if len(text) > 2000:
        raise ValueError("Input text exceeds configured maximum size limit.")
        
    # Dynamic logic reflecting environment differentiation
    if 'PROD' in model.upper():
        # Production environment logic (e.g., higher latency, stricter content filters)
        quality_tag = "PROD-QUALITY"
    elif 'STAGING' in model.upper():
        # Staging environment logic (e.g., testing new features)
        quality_tag = "STAGING-TEST"
    else:
         # Development environment logic (e.g., debugging features, verbose logs)
         quality_tag = "DEV-DEBUG"
         
    translation = f"{quality_tag} TRANSLATION: Input processed by {model} with token limit {max_tokens}."
         
    return {
        "source_text_snippet": text[:50] + "...",
        "processed_output": translation,
        "model_used": model,
        "environment_rate_limit": CONFIG.RATE_LIMIT_PER_MINUTE
    }

# --- API Endpoints ---

@app.get("/health", status_code=status.HTTP_200_OK)
def health_check():
    """Standard health check endpoint. Fails if configuration load failed."""
    if CONFIG is None:
         # Kubernetes Liveness/Readiness probes would catch this 503 error
         raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, 
                             detail="Service is unconfigured or failed startup validation.")
    return {
        "status": "ok", 
        "environment": CONFIG.APP_ENVIRONMENT, 
        "model": CONFIG.LLM_MODEL_NAME,
        "log_level": CONFIG.APP_LOG_LEVEL
    }

@app.post("/process")
def process_text(payload: Dict[str, str]):
    """
    Processes text using the dynamically configured LLM parameters.
    """
    if CONFIG is None:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Service not initialized.")
        
    if 'text' not in payload:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Missing 'text' in payload.")
    
    try:
        result = simulate_llm_call(
            text=payload['text'],
            model=CONFIG.LLM_MODEL_NAME,
            max_tokens=CONFIG.LLM_MAX_TOKENS
        )
        logger.debug(f"Request processed successfully in {CONFIG.APP_ENVIRONMENT}.")
        return result
    except ValueError as e:
        logger.warning(f"Processing failed due to input constraints: {e}")
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))

if __name__ == "__main__":
    # In a production container, this would typically be run by gunicorn/uvicorn entrypoint
    # This block is for local testing only
    if CONFIG:
        logger.info(f"Starting uvicorn server on port 8000 for {CONFIG.APP_ENVIRONMENT}...")
        # Note: We simulate the container port of 80, but use 8000 locally for convenience
        # uvicorn_run(app, host="0.0.0.0", port=8000)
    else:
        logger.critical("Application startup aborted due to configuration failure.")


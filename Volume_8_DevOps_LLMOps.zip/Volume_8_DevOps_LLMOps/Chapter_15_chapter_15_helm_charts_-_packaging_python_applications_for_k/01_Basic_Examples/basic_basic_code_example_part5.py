
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example_part5.py
# Description: Basic Code Example
# ==========================================

# --- 4. Run the application ---
if __name__ == '__main__':
    # Print configuration details to the container standard output (logs)
    print("--- Python Service Startup ---")
    print(f"Starting Flask app on port {SERVICE_PORT}...")
    print(f"Using configured welcome message: '{WELCOME_MESSAGE}'")
    
    try:
        # Start the development server. 
        # host='0.0.0.0' makes the service accessible externally within the container network.
        # Note: In production, we would use Gunicorn or uWSGI, not app.run().
        app.run(host='0.0.0.0', port=int(SERVICE_PORT))
    except ValueError:
        # Handle cases where SERVICE_PORT might not be an integer
        print(f"Error: SERVICE_PORT '{SERVICE_PORT}' is not a valid integer.")
        sys.exit(1)
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        sys.exit(1)

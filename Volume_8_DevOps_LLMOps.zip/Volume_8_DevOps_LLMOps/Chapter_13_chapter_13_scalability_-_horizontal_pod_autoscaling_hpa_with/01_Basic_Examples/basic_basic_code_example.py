
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# cpu_intensive_app.py

from flask import Flask, request, jsonify
import time
import os

# --- 1. Application Setup and Configuration ---

# Initialize the Flask application instance
app = Flask(__name__)

# Define the environment variable for intensity.
# This allows external configuration via Kubernetes ConfigMaps or Deployment manifests.
# Defaulting to 100 million iterations if the environment variable is not set.
# The underscore (_) is used for readability in large numbers (Python 3.6+).
try:
    CPU_INTENSITY_FACTOR = int(os.environ.get('CPU_INTENSITY', 100_000_000))
except ValueError:
    # Fallback in case of malformed environment variable
    CPU_INTENSITY_FACTOR = 100_000_000
    print(f"Warning: Invalid CPU_INTENSITY environment variable. Defaulting to {CPU_INTENSITY_FACTOR}")

# --- 2. Core CPU-Intensive Endpoint ---

@app.route('/calculate', methods=['GET'])
def calculate_load():
    """
    Endpoint designed to intentionally consume CPU resources synchronously.
    This function executes a large, blocking mathematical loop.
    """
    
    # Initialize timing and result variables
    start_time = time.time()
    result = 0.0
    
    # Log the start of the intensive task for debugging visibility
    print(f"Starting intensive calculation for {CPU_INTENSITY_FACTOR} iterations...")

    # Perform a computationally expensive, synchronous loop.
    # The loop's primary goal is to keep the CPU busy and prevent the GIL
    # from yielding control to other threads frequently.
    for i in range(CPU_INTENSITY_FACTOR):
        # A complex mathematical operation ensures the calculation remains CPU-bound
        # and involves floating-point arithmetic, which is often slower than integer math.
        # This specific structure (i*i + 1) / (i+1 + 0.1) is chosen to maximize
        # the complexity of the operation within the loop body.
        result += (i * i + 1) / (i + 1 + 0.1)

    end_time = time.time()
    duration = end_time - start_time
    
    # Log completion
    print(f"Calculation finished. Duration: {duration:.4f} seconds.")

    # Return diagnostic data in JSON format
    return jsonify({
        "status": "Calculation complete",
        "duration_seconds": round(duration, 4),
        "iterations": CPU_INTENSITY_FACTOR,
        # Return a small checksum based on the final result for integrity verification.
        "result_checksum": round(result % 1000, 2) 
    })

# --- 3. Standard Health Check Endpoint ---

@app.route('/health', methods=['GET'])
def health_check():
    """
    Standard Kubernetes readiness/liveness probe endpoint. 
    This MUST be fast and reliable, ensuring Kubernetes knows the service is up.
    """
    # Using jsonify ensures the response is correctly formatted as application/json
    return jsonify({"status": "healthy", "service": "cpu_load_generator", "version": "1.0"})

# --- 4. Application Execution Block ---

if __name__ == '__main__':
    # When deployed in Kubernetes, a robust server like Gunicorn or uWSGI 
    # will manage the process. This block is primarily for local development/testing.
    # Binding to '0.0.0.0' is mandatory for containerized applications 
    # to be accessible from outside the container environment.
    print(f"Starting server on port 5000 with CPU Intensity: {CPU_INTENSITY_FACTOR}")
    app.run(host='0.0.0.0', port=5000)

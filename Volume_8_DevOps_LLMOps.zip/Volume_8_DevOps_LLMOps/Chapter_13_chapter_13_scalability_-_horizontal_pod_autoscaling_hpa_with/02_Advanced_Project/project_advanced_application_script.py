
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# hpa_stress_app.py

import os
import time
import hashlib
import multiprocessing
from concurrent.futures import ThreadPoolExecutor

from fastapi import FastAPI, HTTPException, status
import uvicorn
import asyncio
from typing import List, Dict, Any

# --- 1. Configuration and Initialization ---

# Determine the number of available CPU cores in the container/host
NUM_WORKERS = multiprocessing.cpu_count()

# Initialize a ThreadPoolExecutor dedicated to handling synchronous, CPU-bound tasks
# This allows the async event loop to remain free while workers burn CPU
THREAD_POOL = ThreadPoolExecutor(max_workers=NUM_WORKERS)

# Define the complexity factor for the simulated cryptographic work (PBKDF2 iterations)
# Higher iterations = longer execution time = higher CPU load
HASH_ITERATIONS = 750_000 

# Define the maximum number of tokens allowed per request to prevent resource exhaustion
MAX_TOKENS_PER_REQUEST = 6000

app = FastAPI(
    title="HPA Cryptographic Load Service",
    description=f"Simulates high CPU load using {NUM_WORKERS} dedicated threads for hashing."
)

# Attach the event loop reference to the app object for easy access in the endpoint
try:
    app.loop = asyncio.get_event_loop()
except RuntimeError:
    # Handle cases where the loop hasn't started yet (e.g., initial setup)
    pass


# --- 2. CPU-Intensive Core Logic ---

def _perform_cpu_intensive_hash(token_id: int, salt: bytes) -> str:
    """
    Synchronous function that executes a computationally expensive cryptographic hash.
    This function blocks the thread it runs on, consuming CPU cycles heavily.
    """
    # Create unique input data based on token ID and current time
    input_data = f"token_{token_id}:{time.time()}:{os.getpid()}"
    
    # Use PBKDF2 with SHA256 and a high number of iterations (the CPU sink)
    hashed_bytes = hashlib.pbkdf2_hmac(
        'sha256', 
        input_data.encode('utf-8'), 
        salt, 
        HASH_ITERATIONS
    )
    # Return the hash result (hex representation)
    return hashed_bytes.hex()


# --- 3. Application Endpoints ---

@app.get("/health", status_code=status.HTTP_200_OK)
async def health_check() -> Dict[str, Any]:
    """Standard health check endpoint, confirms the service is running."""
    return {
        "status": "ok", 
        "workers_available": NUM_WORKERS,
        "hash_complexity": HASH_ITERATIONS
    }

@app.post("/generate_tokens")
async def generate_tokens(num_tokens: int = 100) -> Dict[str, Any]:
    """
    Primary scaling target endpoint. Triggers the generation of 'num_tokens' 
    by offloading the synchronous hash work to the thread pool.
    """
    # Input validation
    if not (1 <= num_tokens <= MAX_TOKENS_PER_REQUEST):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Requested tokens must be between 1 and {MAX_TOKENS_PER_REQUEST}."
        )

    start_time = time.monotonic()
    
    # Generate a unique, random salt for this specific batch operation
    batch_salt = os.urandom(16)
    
    # 1. Prepare the list of tasks (function calls with arguments)
    tasks = [
        lambda i=i: _perform_cpu_intensive_hash(i, batch_salt) 
        for i in range(num_tokens)
    ]
    
    # 2. Schedule the synchronous tasks to run concurrently in the thread pool
    # The list comprehension submits each task to the executor.
    futures = [
        app.loop.run_in_executor(THREAD_POOL, task) 
        for task in tasks
    ]
    
    # 3. Wait asynchronously for all tasks (futures) to complete
    # The main thread blocks only on this await, not on the CPU work itself.
    results = await asyncio.gather(*futures)
    
    end_time = time.monotonic()
    
    # Return summary statistics
    return {
        "message": f"Successfully processed {len(results)} CPU-intensive tokens.",
        "tokens_processed": len(results),
        "time_taken_seconds": round(end_time - start_time, 3),
        "cpu_target_hit": True
    }

# --- 4. Application Startup ---

if __name__ == "__main__":
    # Ensure the event loop is set before Uvicorn starts the application
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
    app.loop = loop
    
    print(f"Starting HPA Stress Server on 0.0.0.0:8000.")
    print(f"Configured for {NUM_WORKERS} concurrent CPU tasks.")
    
    # Uvicorn runs the FastAPI application
    uvicorn.run(app, host="0.0.0.0", port=8000)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from flask import Flask, request, jsonify, g

app = Flask(__name__)

# Simulated Configuration
VALID_TOKEN = "valid.jwt.token"
SIMULATED_PAYLOAD = {"user_id": 123, "role": "consumer"} 

def validate_jwt(token):
    """Simulates JWT decoding and validation against a known value."""
    if token == VALID_TOKEN:
        return SIMULATED_PAYLOAD
    return None

# --- Request Hook Function (Middleware) ---
@app.before_request
def security_middleware():
    """Intercepts requests to secured paths and enforces JWT validation."""
    
    # Check if the current path requires JWT security
    if request.path == '/api/v1/users' and request.method == 'POST':
        auth_header = request.headers.get('Authorization')
        
        if not auth_header or not auth_header.startswith('Bearer '):
            return jsonify({"error": "Authorization header missing or malformed"}), 401
        
        token = auth_header.split(' ')[1]
        payload = validate_jwt(token)
        
        if payload is None:
            return jsonify({"error": "Invalid or expired token"}), 401
        
        # Context Passing: Store user ID in Flask's global context (g)
        g.user_id = payload.get('user_id')
        # If validation succeeds, return None, allowing the request to proceed.

# --- Secured User Creation Endpoint ---
@app.route('/api/v1/users', methods=['POST'])
def create_user():
    """Runs only after successful authentication via middleware."""
    data = request.get_json() or {}
    
    return jsonify({
        "message": "User created successfully (Authenticated)",
        "authenticated_by_user_id": g.user_id, # Accesses data from context
        "received_data_keys": list(data.keys())
    }), 201

# Other endpoints (e.g., /health) are omitted for brevity but remain unsecured.

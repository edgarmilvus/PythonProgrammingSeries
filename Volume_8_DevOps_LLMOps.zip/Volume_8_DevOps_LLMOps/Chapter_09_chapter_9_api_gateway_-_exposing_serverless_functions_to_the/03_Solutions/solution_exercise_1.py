
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from flask import Flask, request, jsonify

# Initialize Flask application
app = Flask(__name__)

# --- Health Check Endpoint (GET /health) ---
@app.route('/health', methods=['GET'])
def health_check():
    """Returns a simple status check."""
    return jsonify({"status": "OK"}), 200

# --- User Creation Endpoint (POST /api/v1/users) ---
@app.route('/api/v1/users', methods=['POST'])
def create_user():
    """Simulates creating a user profile."""
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "Invalid user data"}), 400
        
        # Simulate successful creation
        user_id = 1001 
        return jsonify({
            "message": "User created successfully",
            "user_id": user_id
        }), 201
    except Exception:
        return jsonify({"error": "Internal processing error"}), 500

# --- Product Retrieval Endpoint (GET /api/v1/products/{product_id}) ---
@app.route('/api/v1/products/<int:product_id>', methods=['GET'])
def get_product_details(product_id):
    """Retrieves details for a specific product ID passed as a path parameter."""
    product_data = {
        "product_id": product_id,
        "name": f"Product Item {product_id}",
        "status": "Available"
    }
    return jsonify(product_data), 200

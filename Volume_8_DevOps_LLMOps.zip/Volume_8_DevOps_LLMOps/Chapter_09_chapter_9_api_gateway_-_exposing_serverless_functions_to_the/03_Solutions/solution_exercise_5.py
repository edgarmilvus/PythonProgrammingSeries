
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from flask import Flask, request, jsonify, g

app = Flask(__name__)

# Security Constants
INTERNAL_SECRET = "llm-tool-secret-key-12345"
VALID_JWT = "valid.user.jwt"
SIMULATED_PAYLOAD = {"user_id": 999} 

def validate_jwt(token):
    """Simulates JWT validation."""
    return SIMULATED_PAYLOAD if token == VALID_JWT else None

# --- Granular Request Hook Function ---
@app.before_request
def granular_security_middleware():
    path = request.path
    
    # 1. Security Check for Public LLM Endpoint (/generate)
    if path == '/generate' and request.method == 'POST':
        auth_header = request.headers.get('Authorization')
        
        if not auth_header or not auth_header.startswith('Bearer '):
            return jsonify({"error": "External User Auth (JWT) required"}), 401
        
        token = auth_header.split(' ')[1]
        if validate_jwt(token) is None:
            return jsonify({"error": "Invalid JWT"}), 401
        
        g.auth_status = "Public_JWT_Success"
        return # Success: proceed to /generate

    # 2. Security Check for Internal Tool Endpoint (/tool/database_query)
    elif path == '/tool/database_query' and request.method == 'POST':
        internal_secret_header = request.headers.get('X-Internal-Secret')
        
        if internal_secret_header != INTERNAL_SECRET:
            # Reject access if the specific internal secret is missing or incorrect
            return jsonify({"error": "Forbidden: Internal secret key mismatch"}), 403
        
        g.auth_status = "Internal_Key_Success"
        return # Success: proceed to tool endpoint

    # Allow other paths (like /health) to pass through
    return

# --- Endpoints ---

@app.route('/generate', methods=['POST'])
def public_llm_generate():
    """Public endpoint secured by JWT."""
    return jsonify({
        "message": "LLM response generated.",
        "auth_type": g.auth_status
    }), 200

@app.route('/tool/database_query', methods=['POST'])
def internal_database_query():
    """Internal tool endpoint secured by static secret header."""
    return jsonify({
        "message": "Sensitive database query executed.",
        "auth_type": g.auth_status
    }), 200

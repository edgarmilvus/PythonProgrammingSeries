
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import jwt
import time
from fastapi import FastAPI, Depends, HTTPException, Security
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel

# --- Configuration and Setup ---

# Critical configuration for JWT signing and verification
SECRET_KEY = "super-secret-gateway-key" 
ALGORITHM = "HS256"

# Dependency for handling Bearer token security headers
security = HTTPBearer()

# --- Data Models for Request Payloads ---

class ChatRequest(BaseModel):
    """Defines the input structure for the basic chat endpoint."""
    prompt: str
        
class ToolRequest(BaseModel):
    """Defines the input structure for the premium tool endpoint."""
    query: str
        
# --- JWT and Authentication Logic (Simulating Gateway Enforcement) ---
    
def decode_jwt(token: str) -> dict:
    """Core function to decode and validate the JWT payload."""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        # Gateway should ideally catch this, but backend validation is robust
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token signature or format")

def get_current_user(credentials: HTTPAuthorizationCredentials = Security(security)):
    """
    FastAPI dependency that extracts and validates the JWT from the Authorization header.
    This simulates the final security check for premium resources.
    """
    token = credentials.credentials
    payload = decode_jwt(token)
        
    # CRITICAL: Check for required scopes/claims defined by the policy
    if payload.get("scope") != "premium":
         # If the scope isn't 'premium', access is denied (403 Forbidden)
         raise HTTPException(status_code=403, detail="Insufficient scope for this resource. Requires 'premium' access.")
             
    # Returns the user ID if validation is successful
    return payload.get("user_id", "unknown_user")

# --- FastAPI Application (The Serverless Function Interface) ---

app = FastAPI(title="LLM Routing Service")

@app.get("/health")
def health_check():
    """Standard health check endpoint used by the Gateway for monitoring."""
    return {"status": "ok", "service": "llm-router"}

@app.post("/v1/chat")
def basic_chat_endpoint(req: ChatRequest):
    """
    Unsecured endpoint. The API Gateway handles routing and basic throttling.
    No authentication dependency is attached.
    """
    # Simulation: Quick, general-purpose LLM call (high throughput)
    response = f"Basic chat response generated for: '{req.prompt[:40]}...'"
    return {"result": response, "security_level": "public"}

@app.post("/v1/premium_tool")
def premium_tool_endpoint(req: ToolRequest, user_id: str = Depends(get_current_user)):
    """
    Secured endpoint. Requires successful execution of the get_current_user dependency.
    The API Gateway ensures the Authorization header is present before routing here.
    """
        
    # This function only executes if get_current_user (JWT validation and scope check) succeeds
    
    # Simulation: Complex, resource-intensive tool call (e.g., proprietary RAG or code generation)
    tool_output = f"Executing proprietary RAG query for user {user_id}: '{req.query[:40]}...'"
        
    return {
        "result": tool_output,
        "user_context": user_id,
        "security_level": "premium_validated"
    }

# --- Utility for Generating Test Tokens (Outside the deployed function logic) ---
    
def generate_test_jwt(user_id: str, scope: str):
    """Helper to create a valid JWT for local testing."""
    payload = {
        "user_id": user_id,
        "scope": scope,
        "exp": time.time() + 600  # Token valid for 10 minutes
    }
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

# Example Usage:
# Run locally using: uvicorn api_gateway_simulation:app --reload
# print(generate_test_jwt('premium_user_01', 'premium'))
# print(generate_test_jwt('basic_user_02', 'basic'))

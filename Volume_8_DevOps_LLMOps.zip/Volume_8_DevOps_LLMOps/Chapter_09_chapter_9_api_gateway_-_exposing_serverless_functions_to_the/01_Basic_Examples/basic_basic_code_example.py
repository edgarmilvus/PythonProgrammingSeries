
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

from flask import Flask, request, jsonify, abort

# --- Configuration & Constants ---
# CRITICAL: In production, these values must be stored in a secure secrets manager (e.g., AWS Secrets Manager, HashiCorp Vault).
MOCK_VALID_API_KEY = "sk-llm-secure-prod-a1b2c3d4e5f6g7h8i9j0"
API_KEY_HEADER = "X-Api-Key" # Standard header name for API key transmission

app = Flask(__name__)

# --- 1. Request Hook: Simulated Authorization Check ---
# This function is registered as a Request Hook and executes before *every* request handler.
@app.before_request
def check_authorization():
    """
    Simulates the final authorization check for secure routes.
    This check runs after the API Gateway has potentially already validated a token.
    It applies the DRY principle by centralizing security logic.
    """
    # Define a list of endpoint function names that require authentication.
    # Note: We use the function name (endpoint) defined in the @app.route decorator.
    secure_routes = ['secure_llm_inference'] 

    # Check if the current request is targeting a secure endpoint
    if request.endpoint in secure_routes:
        
        # 1. Check for the existence of the required security header
        if API_KEY_HEADER not in request.headers:
            # Use Flask's abort() to immediately stop processing and return an error response.
            # 401 Unauthorized: Authentication credentials (header) are missing.
            abort(401, description=f"Authentication required. Missing header: {API_KEY_HEADER}")

        provided_key = request.headers.get(API_KEY_HEADER)

        # 2. Validate the provided key against the secure list
        if provided_key != MOCK_VALID_API_KEY:
            # 403 Forbidden: Credentials were provided but are invalid.
            abort(403, description="Invalid API Key provided. Access denied.")

        # If the code reaches this point, authorization is successful.
        print(f"DEBUG: Authorization successful for endpoint: {request.endpoint}")


# --- 2. Public Endpoint (Status Check) ---
# This endpoint is exposed via the API Gateway, perhaps under /v1/status.
@app.route('/public', methods=['GET'])
def public_status():
    """A simple, unauthenticated status check for health monitoring."""
    # The check_authorization hook runs, but since this function name 
    # ('public_status') is not in secure_routes, the check is skipped.
    return jsonify({
        "service": "LLM Inference Backend",
        "status": "Operational",
        "message": "Welcome to the public API endpoint. Authorization bypassed."
    })


# --- 3. Secure LLM Inference Endpoint ---
# This endpoint is exposed via the API Gateway, perhaps under /v1/llm/generate.
@app.route('/secure/llm_inference', methods=['POST'])
def secure_llm_inference():
    """ 
    Simulates the execution of a high-cost, secure LLM task.
    This function is guaranteed to only run if the check_authorization hook passed.
    """
    try:
        # Expecting a JSON body containing the prompt.
        data = request.get_json()
        prompt = data.get('prompt', 'Generate a short poem about Python.')

        # --- Core Business Logic (Simulated) ---
        response_text = f"LLM Result (Securely Served): The user requested: '{prompt[:50]}...'. Processing complete."

        return jsonify({
            "model": "Codex-70B",
            "result": response_text,
            "cost_estimate": "0.002 USD" # Data often tracked by the backend
        }), 200

    except Exception as e:
        # Handle cases where the request body is malformed or missing (400 Bad Request)
        abort(400, description=f"Invalid request format or missing JSON body: {e}")


if __name__ == '__main__':
    # Execution instructions for testing.
    print("-" * 50)
    print(f"Mock API Server running on port 8080.")
    print(f"Public Endpoint: GET http://localhost:8080/public")
    print(f"Secure Endpoint: POST http://localhost:8080/secure/llm_inference")
    print(f"Use Header '{API_KEY_HEADER}' with key '{MOCK_VALID_API_KEY}' for access.")
    print("-" * 50)
    app.run(debug=True, port=8080)

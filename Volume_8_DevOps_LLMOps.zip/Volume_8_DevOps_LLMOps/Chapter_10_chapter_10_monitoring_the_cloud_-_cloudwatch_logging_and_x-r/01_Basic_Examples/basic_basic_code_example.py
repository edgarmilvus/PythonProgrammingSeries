
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import logging
import json
import time
import uuid
import sys
from typing import Dict, Any

# --- 1. Custom JSON Formatter for CloudWatch Logs ---
class JsonFormatter(logging.Formatter):
    """
    Formats log records into a single JSON string. 
    This is essential for CloudWatch Logs Insights, allowing structured querying.
    """
    
    # Define the standard date format used in ISO 8601
    DATE_FORMAT = '%Y-%m-%dT%H:%M:%S%z' 

    def format(self, record: logging.LogRecord) -> str:
        """
        Overrides the base format method to construct a dictionary 
        and serialize it to JSON.
        """
        
        # 1a. Initialize the core log record structure
        log_record: Dict[str, Any] = {
            # Time formatting is crucial for chronological sorting in CloudWatch
            "timestamp": self.formatTime(record, self.DATE_FORMAT),
            "level": record.levelname,
            "message": record.getMessage(),
            "logger_name": record.name,
            "process_id": record.process,
            "thread_id": record.thread,
            "module": record.module,
            "line": record.lineno,
        }

        # 1b. Inject custom context variables (data passed via 'extra')
        # We look for attributes that are not standard LogRecord attributes
        standard_keys = logging.LogRecord.__dict__.keys()
        
        for key, value in record.__dict__.items():
            # Exclude internal variables and standard LogRecord attributes
            if (key not in standard_keys and 
                not key.startswith('_') and 
                key not in log_record): 
                
                # Assign the custom context variable (e.g., request_id, duration_ms)
                log_record[key] = value

        # 1c. Handle exception and traceback information
        if record.exc_info:
            # Format the exception traceback into a string field
            log_record['exception'] = self.formatException(record.exc_info)
            
        # 1d. Serialize the entire dictionary to a single JSON string
        # Ensure that non-standard Python objects are handled gracefully if possible
        try:
            return json.dumps(log_record, default=str)
        except TypeError:
            # Fallback for complex un-serializable objects (should rarely happen)
            log_record['serialization_error'] = "Failed to serialize complex data."
            return json.dumps(log_record, default=str)


# --- 2. Configuration Setup ---
def setup_logging(logger_name: str = "CloudNativeService", level: int = logging.INFO) -> logging.Logger:
    """Configures the application logger to use the structured JSON formatter."""
    
    # 2a. Create or retrieve the specific logger instance
    logger = logging.getLogger(logger_name)
    logger.setLevel(level)

    # 2b. Create a StreamHandler
    # In cloud environments, logs must be written to standard output (stdout) 
    # or standard error (stderr) so that the container runtime or dedicated agents 
    # (like the CloudWatch Agent or Fluent Bit) can capture them.
    handler = logging.StreamHandler(sys.stdout)
    
    # 2c. Instantiate and set the custom JSON formatter
    formatter = JsonFormatter()
    handler.setFormatter(formatter)
    
    # 2d. Attach the handler to the logger
    # Check to prevent adding duplicate handlers if setup is called multiple times
    if not logger.handlers: 
        logger.addHandler(handler)
    
    return logger

# --- 3. Simulated Microservice Logic ---
def process_request(request_id: str, payload: Dict[str, Any], logger: logging.Logger):
    """
    Simulates processing a request. All relevant state is passed to the logger 
    using the 'extra' parameter, making the log entry self-describing.
    """
    
    start_time = time.perf_counter()
    
    # Define the context data dictionary. 
    # This dictionary will be merged directly into the LogRecord.
    context_data = {
        "request_id": request_id,
        "user_id": payload.get("user_id", "anonymous"),
        "service_action": "data_aggregation",
        "input_data_size_bytes": len(json.dumps(payload))
    }

    # Log the start of the transaction
    # The 'extra' keyword argument is the mechanism for structured logging
    logger.info(
        f"Starting transaction for ID: {request_id}", 
        extra=context_data
    )

    try:
        # Simulate business logic and latency
        time.sleep(0.04) 
        
        # We expect a key named 'value' to be present
        result = payload['value'] * 3.14 
        
        end_time = time.perf_counter()
        duration_ms = (end_time - start_time) * 1000
        
        # Update context data with outcome metrics
        context_data.update({
            "status": "SUCCESS",
            "duration_ms": round(duration_ms, 3),
            "result_calculated": round(result, 2)
        })

        # Log success with final metrics
        logger.info(
            "Transaction completed successfully.",
            extra=context_data
        )
        
        return result
        
    except KeyError as e:
        # Handle expected failure case
        end_time = time.perf_counter()
        duration_ms = (end_time - start_time) * 1000
        
        # Update context for failure analysis
        context_data.update({
            "status": "FAILURE",
            "duration_ms": round(duration_ms, 3),
            "error_type": "MissingPayloadKey",
            "required_key": str(e)
        })
        
        # Use logger.error() and include exc_info=True to capture the traceback
        logger.error(
            "Transaction failed. Required input key is missing.", 
            extra=context_data,
            exc_info=True 
        )
        return None


# --- 4. Main Execution and Demonstration ---
if __name__ == "__main__":
    
    # Initialize the logger instance
    app_logger = setup_logging()
    
    # --- 4a. Successful Run ---
    success_id = str(uuid.uuid4())
    success_payload = {"user_id": 2001, "value": 100}
    print(f"\n--- Simulation Start: Successful Request ({success_id[:8]}) ---")
    process_request(success_id, success_payload, app_logger)
    
    # --- 4b. Failed Run ---
    failure_id = str(uuid.uuid4())
    # Missing the required 'value' key
    failure_payload = {"user_id": 2002, "other_setting": "test"} 
    print(f"\n--- Simulation Start: Failed Request ({failure_id[:8]}) ---")
    process_request(failure_id, failure_payload, app_logger)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import time
import random
import logging
import json
from datetime import datetime

import boto3
from aws_xray_sdk.core import xray_recorder
from aws_xray_sdk.core import patch_all

# --- 1. Initialization and Configuration ---

# Configure X-Ray globally. Patch common libraries (like boto3) automatically.
# This assumes the X-Ray daemon is running locally or in the environment (e.g., ECS/EKS sidecar).
patch_all()
xray_recorder.configure(service='DocumentProcessingService')
xray_recorder.begin_segment('DocumentProcessingService_Main')

# AWS Clients
REGION_NAME = os.environ.get('AWS_REGION', 'us-east-1')
cloudwatch_client = boto3.client('cloudwatch', region_name=REGION_NAME)

# Custom Logging Setup
# We use a custom handler to ensure logs are structured (JSON format) for easy parsing in CloudWatch Logs.
class JsonFormatter(logging.Formatter):
    """Formats log records as JSON strings."""
    def format(self, record):
        log_data = {
            "timestamp": datetime.fromtimestamp(record.created).isoformat(),
            "level": record.levelname,
            "service": "DPS",
            "message": record.getMessage(),
            "trace_id": xray_recorder.current_trace_id(),
            "request_id": getattr(record, 'request_id', 'N/A'),
            "duration_ms": getattr(record, 'duration_ms', None),
            "payload": record.__dict__
        }
        return json.dumps(log_data)

# Configure the root logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)
log_handler = logging.StreamHandler()
log_handler.setFormatter(JsonFormatter())
# Clear existing handlers to prevent duplicate logging
if logger.hasHandlers():
    logger.handlers.clear()
logger.addHandler(log_handler)


# --- 2. Core Service Functions ---

def publish_metric(metric_name: str, value: float, unit: str, dimensions: list):
    """Publishes a custom metric to Amazon CloudWatch."""
    try:
        cloudwatch_client.put_metric_data(
            Namespace='DPS/Performance',
            MetricData=[
                {
                    'MetricName': metric_name,
                    'Dimensions': dimensions,
                    'Value': value,
                    'Unit': unit
                },
            ]
        )
    except Exception as e:
        logger.error(f"Failed to publish metric {metric_name}: {e}")

@xray_recorder.capture('DocumentValidation')
def validate_input(doc_id: str) -> bool:
    """Simulates input validation with a 10% failure rate."""
    time.sleep(random.uniform(0.01, 0.05)) # Short validation latency
    if random.random() < 0.1:
        # Simulate a validation failure
        xray_recorder.current_subsegment().add_exception(
            Exception("Invalid document structure or missing metadata.")
        )
        return False
    return True

@xray_recorder.capture('CoreDocumentProcessing')
def process_document(doc_id: str):
    """Simulates the main document processing workflow."""
    start_time = time.time()
    
    # 1. Start X-Ray Subsegment for the overall request
    subsegment = xray_recorder.begin_subsegment(f'Request_{doc_id}')
    subsegment.put_annotation('DocumentID', doc_id)

    success = False
    
    try:
        # 2. Validation Step (Traced internally)
        if not validate_input(doc_id):
            raise ValueError("Validation failed.")

        # 3. Simulated Heavy Compute (Variable Latency)
        processing_time = random.uniform(0.2, 1.5)
        time.sleep(processing_time)
        
        success = True
        status_code = 200
        
    except ValueError as e:
        # 4. Handle Failure
        status_code = 400
        logger.warning(f"Request failed for {doc_id}: {e}", extra={'request_id': doc_id})
        # Mark the X-Ray subsegment as an error
        subsegment.add_exception(e)

    finally:
        end_time = time.time()
        duration_ms = (end_time - start_time) * 1000
        
        # 5. Log the outcome (Structured Log for CloudWatch Logs)
        log_level = logging.INFO if success else logging.ERROR
        log_message = f"Request completed. Status: {status_code}"
        
        logger.log(log_level, log_message, extra={
            'request_id': doc_id,
            'status_code': status_code,
            'duration_ms': round(duration_ms, 2)
        })

        # 6. Publish Metrics (CloudWatch Metrics)
        publish_metric('Latency', duration_ms, 'Milliseconds', [{'Name': 'Service', 'Value': 'DPS'}])
        publish_metric('Requests', 1, 'Count', [{'Name': 'Status', 'Value': 'Success' if success else 'Failure'}])

        # 7. Close X-Ray Subsegment
        xray_recorder.end_subsegment()


# --- 3. Execution ---

if __name__ == "__main__":
    print(f"--- Starting DPS Simulation in Region: {REGION_NAME} ---")
    
    NUM_REQUESTS = 10
    
    for i in range(1, NUM_REQUESTS + 1):
        doc_id = f"DOC-{i:04d}"
        print(f"\nProcessing {doc_id}...")
        
        # X-Ray requires a segment context for the trace to be uploaded.
        # We start a segment for the overall process (simulating an API Gateway integration).
        # Note: In a real server environment (e.g., Flask/Django), middleware handles segment creation.
        segment = xray_recorder.begin_segment(f'API_Call_{doc_id}')
        
        try:
            process_document(doc_id)
        finally:
            # End the segment, which triggers the upload of the trace data to X-Ray
            xray_recorder.end_segment()
            
    print("\n--- Simulation Complete. Check CloudWatch Logs, Metrics, and X-Ray Traces. ---")


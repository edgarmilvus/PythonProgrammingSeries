
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import boto3
import time
import random
import os

# 1. IAM Policy Configuration (Minimal Required Permissions)
IAM_POLICY_DOCUMENT = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "AllowCustomMetricPublishing",
            "Effect": "Allow",
            "Action": [
                "cloudwatch:PutMetricData"
            ],
            "Resource": "*" 
            # Resource is typically '*' for PutMetricData action.
        }
    ]
}

# 2. Custom Metric Definition and Publishing Implementation
NAMESPACE = 'LLMOps/RAG_Performance'
KNOWLEDGE_BASE_ID = os.environ.get('KB_ID', 'KB-2024-Q3')

# Initialize Boto3 Client (assuming credentials are provided by the container role)
cloudwatch = boto3.client('cloudwatch')

def publish_rag_metric(success=True):
    """
    Publishes a custom metric data point to CloudWatch.
    """
    metric_name = 'RAGSuccess' if success else 'RAGFallback'
    
    metric_data = [
        {
            'MetricName': metric_name,
            'Dimensions': [
                {
                    'Name': 'KnowledgeBaseID',
                    'Value': KNOWLEDGE_BASE_ID
                },
            ],
            'Timestamp': time.time(),
            'Value': 1.0, # Count each event as 1.0
            'Unit': 'Count'
        },
    ]

    try:
        cloudwatch.put_metric_data(
            Namespace=NAMESPACE,
            MetricData=metric_data
        )
        # print(f"Published metric: {metric_name}")
    except Exception as e:
        print(f"Error publishing metric: {e}")

# --- Simulation Logic (Demonstrating Metric Publishing) ---
def simulate_rag_pipeline(degradation=False):
    # Simulate 10 requests
    for _ in range(10):
        # Normal operation: 90% success rate
        success_chance = 0.9 if not degradation else 0.6 
        
        if random.random() < success_chance:
            publish_rag_metric(success=True)
        else:
            # Log a warning message that could be correlated later
            print("WARNING: Document retrieval failed, triggering RAGFallback.")
            publish_rag_metric(success=False)
        time.sleep(0.1)

# Run normal simulation
# simulate_rag_pipeline(degradation=False) 

# --- 4. CloudWatch Dashboard Creation (Metric Math Definition) ---

# Metric A: Sum of RAGSuccess (Id: m1)
# Metric B: Sum of RAGFallback (Id: m2)

# Metric Math Expression for Success Rate (Id: e1)
# Expression: 100 * (m1 / (m1 + m2))

CLOUDWATCH_DASHBOARD_WIDGET_DEFINITION = {
    "type": "metric",
    "title": "RAG Success Rate (%)",
    "view": "timeSeries",
    "stacked": False,
    "metrics": [
        [ NAMESPACE, "RAGSuccess", "KnowledgeBaseID", KNOWLEDGE_BASE_ID, {"id": "m1", "stat": "Sum"} ],
        [ NAMESPACE, "RAGFallback", "KnowledgeBaseID", KNOWLEDGE_BASE_ID, {"id": "m2", "stat": "Sum"} ],
        [ {"expression": "100 * (m1 / (m1 + m2))", "label": "Success Rate", "id": "e1"} ]
    ],
    "period": 300, # 5 minutes aggregation
    "stat": "Sum",
    "yAxis": {"left": {"label": "Percent", "min": 0, "max": 100}}
}

# --- Interactive Challenge Steps Outline ---

# Step 1: Simulate Degradation
# Run simulate_rag_pipeline(degradation=True) for 15 minutes.

# Step 2: Initial Diagnosis
# Observe the RAG_Health_Monitor dashboard. The 'Success Rate' line (e1) will drop from ~90% to ~60% 
# during the 15-minute window (e.g., 10:00 AM to 10:15 AM).

# Step 3: Root Cause Investigation (Logs Insights)
LOGS_INSIGHTS_QUERY_ROOT_CAUSE = """
fields @timestamp, @message, environment, service_name
| filter @timestamp between "2024-01-01T10:00:00.000Z" and "2024-01-01T10:15:00.000Z" 
| filter level = 'WARNING' 
| filter @message like /Document retrieval failed/
| sort by @timestamp asc
"""
# Note: The timestamp filter must match the degradation window observed in the dashboard.


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import time
import requests
import boto3
from aws_xray_sdk.core import xray_recorder
from aws_xray_sdk.ext.boto3 import patch as patch_boto3
from aws_xray_sdk.core import patch_all

# 1. X-Ray SDK Integration and Patching
# Patching standard libraries (requests, urllib, etc.) and Boto3 globally.
patch_all() # Patches common libraries
patch_boto3() # Specifically patches boto3

# Initialize the X-Ray recorder (assuming the X-Ray daemon is running locally or on Fargate)
# In a real application, this setup would be done once at startup.
xray_recorder.configure(service='LLMInferenceService')

# Mocking external resources
S3_BUCKET_NAME = "prompt-templates-bucket"
MODEL_ENDPOINT = "https://api.external-llm.com/generate"

# Mock Boto3 client and response
class MockS3Client:
    def get_object(self, Bucket, Key):
        time.sleep(0.5) # Simulate S3 latency
        return {'Body': 'Prompt Template content'}

s3_client = MockS3Client()

def generate_response(prompt_text, model_name="gpt-4o"):
    # 0. Start the main segment (usually done by the framework middleware, e.g., Flask X-Ray middleware)
    # We manually start it here for demonstration purposes.
    with xray_recorder.in_segment('LLMInferenceRequest'):
        
        # 1. Boto3 Automatic Tracing (S3 Call)
        # The patch_boto3() call ensures this automatically becomes an S3 subsegment
        print("Step 1: Fetching prompt template from S3...")
        s3_client.get_object(Bucket=S3_BUCKET_NAME, Key='template.txt')
        
        # 2. Manual Subsegment for Internal Preprocessing
        # Simulate heavy data validation/preprocessing (3-second bottleneck)
        with xray_recorder.in_subsegment('Internal_Preprocessing') as subsegment:
            print("Step 2: Preprocessing and data validation...")
            time.sleep(3) # Simulated bottleneck
            subsegment.put_annotation('status', 'complete')

        # 3. Manual Subsegment for External LLM API Call
        prompt_length = len(prompt_text.split()) # Token count approximation
        
        with xray_recorder.in_subsegment('ExternalLLM_Inference') as subsegment:
            print(f"Step 3: Calling external LLM ({model_name})...")
            
            # Add custom metadata (key/value pairs for filtering)
            subsegment.put_metadata('model_name', model_name, 'llm_context')
            subsegment.put_metadata('prompt_length', prompt_length, 'llm_context')
            
            # Mocking the external HTTP request latency
            # In a real scenario, the 'requests' library patch would handle this, 
            # but we use time.sleep here for guaranteed measurement within the manual segment.
            time.sleep(1.5) 
            
            # Mock HTTP response status
            subsegment.put_annotation('http_status', 200)
            
        return "Generated LLM response."

# Run the trace simulation
generate_response("What is the capital of France and why is it important?", model_name="llama-3")

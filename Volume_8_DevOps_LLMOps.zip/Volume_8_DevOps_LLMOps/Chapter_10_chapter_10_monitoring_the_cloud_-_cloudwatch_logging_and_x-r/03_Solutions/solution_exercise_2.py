
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import logging
import json
import os
import uuid
import sys
from pythonjsonlogger import jsonlogger

# 1. Configuration Setup
SERVICE_NAME = "AuthValidator"
ENVIRONMENT = os.environ.get('APP_ENV', 'DEV')

# Custom JSON Formatter Class to inject default fields
class CustomJsonFormatter(jsonlogger.JsonFormatter):
    def add_fields(self, log_record, message_dict):
        super(CustomJsonFormatter, self).add_fields(log_record, message_dict)
        
        # Add required static/environment fields
        log_record['service_name'] = SERVICE_NAME
        log_record['environment'] = ENVIRONMENT
        
        # Ensure timestamp is ISO 8601 compatible (default behavior of jsonlogger)
        if 'timestamp' not in log_record:
            log_record['timestamp'] = self.formatTime(log_record)

# 2. Logger Initialization
log_handler = logging.StreamHandler(sys.stdout)
formatter = CustomJsonFormatter(
    # Define required base fields explicitly
    fmt='%(timestamp)s %(level)s %(name)s %(message)s %(service_name)s %(environment)s',
    json_ensure_ascii=False
)
log_handler.setFormatter(formatter)

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
logger.addHandler(log_handler)

# 3. Contextual Metadata Injection Demonstration (Simulated Request)
def handle_incoming_request(user_id):
    request_id = str(uuid.uuid4())
    endpoint = "/validate/token"
    
    # Inject contextual data using the extra parameter
    extra_context = {
        'request_id': request_id,
        'user_id': user_id,
        'endpoint': endpoint
    }
    
    logger.info("Starting authentication validation process.", extra=extra_context)
    
    if user_id == 1001:
        logger.error("Authentication failure: Invalid credentials.", extra=extra_context)
    else:
        logger.info("Validation successful.", extra=extra_context)

# Simulation Run
handle_incoming_request(user_id=1001)
handle_incoming_request(user_id=2002)

# --- CloudWatch Logs Insights Queries (Assuming Log Group: /ecs/auth-validator) ---

# Query A (Error Rate Analysis)
QUERY_A = """
fields @timestamp, @message, service_name, environment, level
| filter @timestamp > ago(6h)
| stats count() as total_logs, 
        count(level = 'ERROR') as error_logs,
    by environment
| sort by error_rate_percent desc
"""

# Query B (User-Specific Trace)
QUERY_B = """
fields @timestamp, @message, level, user_id
| filter user_id = '1001'
| sort by @timestamp asc
| limit 100
"""

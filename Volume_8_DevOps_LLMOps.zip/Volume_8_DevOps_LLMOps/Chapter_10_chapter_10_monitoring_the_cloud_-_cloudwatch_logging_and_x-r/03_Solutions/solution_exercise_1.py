
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# --- Simulation Code (To be run inside the DataProcessorService container) ---

import time
import multiprocessing
import os

# Set environment variables for service identification (used by Container Insights)
# These are typically set in the ECS Task Definition/Environment
SERVICE_NAME = "DataProcessorService"
CLUSTER_NAME = "ProductionCluster"

def cpu_intensive_task():
    """A simple function to consume 100% of a single core."""
    print(f"[{os.getpid()}] Starting CPU load simulation...")
    # Run an infinite loop of complex calculations (e.g., hash generation)
    while True:
        _ = 123456789 ** 987654321 % 123456789

# Determine how many processes to start based on the task CPU limit
# If the task has 1 vCPU, starting 1 process consumes 100% of the allocated CPU.
# If the task has 2 vCPUs, starting 2 processes consumes 100% of the allocated CPU.
NUM_CORES = int(os.environ.get('ECS_CPU_LIMIT_CORES', 1)) # Placeholder for actual limit

if __name__ == '__main__':
    print(f"Starting {NUM_CORES} processes to simulate high CPU load...")
    processes = []
    for _ in range(NUM_CORES):
        p = multiprocessing.Process(target=cpu_intensive_task)
        processes.append(p)
        p.start()

    # Keep the simulation running for 20 minutes to ensure the alarm triggers (3 periods * 5 min = 15 min + buffer)
    try:
        time.sleep(1200) 
    except KeyboardInterrupt:
        pass
    finally:
        for p in processes:
            p.terminate()
        print("Simulation stopped.")

# --- CloudWatch Alarm Configuration (via AWS Console/IaC Pseudo-Code) ---
# Alarm Name: HighCPU_DataProcessor
# Namespace: AWS/ECS
# Metric: CPUUtilization
# Statistic: Average
# Period: 5 minutes
# Dimensions: 
#   ClusterName: ProductionCluster
#   ServiceName: DataProcessorService
# Threshold: >= 85
# Datapoints to Alarm: 3 out of 3
# Action: Publish to SNS Topic: arn:aws:sns:REGION:ACCOUNT_ID:OpsAlertsTopic

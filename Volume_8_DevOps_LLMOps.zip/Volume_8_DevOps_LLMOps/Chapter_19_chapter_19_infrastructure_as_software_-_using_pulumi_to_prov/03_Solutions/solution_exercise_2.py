
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import pulumi
import pulumi_aws as aws

# 1. VPC Provisioning
vpc = aws.ec2.Vpc(
    "llmServiceVpc",
    cidr_block="10.0.0.0/16",
    enable_dns_support=True,
    enable_dns_hostnames=True,
    tags={"Name": "llm-inference-vpc"}
)

# 2. Security Group Definition (Implicit dependency on vpc.id)
# The Security Group must be created within the VPC.
security_group = aws.ec2.SecurityGroup(
    "llmServiceSecurityGroup",
    description="Allow inbound traffic for LLM service on 8080",
    vpc_id=vpc.id, # Dependency 1: References the Output of the VPC ID
    tags={"Name": "llm-service-sg"}
)

# 3. Ingress Rule Definition (Allow TCP 8080 from anywhere)
ingress_rule = aws.ec2.SecurityGroupIngressRule(
    "llmServiceIngressRule",
    security_group_id=security_group.id,
    cidr_blocks=["0.0.0.0/0"],
    from_port=8080,
    to_port=8080,
    ip_protocol="tcp",
)

# 4. Subnet Provisioning (Implicit dependency on vpc.id)
subnet = aws.ec2.Subnet(
    "llmServiceSubnet",
    vpc_id=vpc.id,
    cidr_block="10.0.1.0/24",
    # 5. Output Chaining using .apply() for dynamic naming
    tags={
        "Name": security_group.id.apply(
            lambda sg_id: f"primary-subnet-bound-to-{sg_id}"
        )
    }
)

# Export key identifiers
pulumi.export("vpc_id", vpc.id)
pulumi.export("security_group_id", security_group.id)
pulumi.export("subnet_id", subnet.id)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pulumi
import pulumi_aws as aws

# 1. Initialize configuration object
config = pulumi.Config()

# 2. Retrieve required configuration variables
environment = config.require("environment")
project_name = config.require("project_name")

# Retrieve the current stack name for uniqueness
stack_name = pulumi.get_stack()

# 3. Construct the globally unique bucket name
# Naming Convention: [project_name]-[environment]-data-store-[stack_name]
bucket_name = f"{project_name}-{environment}-data-store-{stack_name}".lower()

# 4. Provision the AWS S3 Bucket
storage_bucket = aws.s3.Bucket(
    "dataStoreBucket",
    bucket=bucket_name,
    acl="private", # Set access control list to private
    tags={
        "Owner": project_name,        # Tag 1: Dynamic owner tag
        "CostCenter": "4001",         # Tag 2: Hardcoded cost center tag
        "Environment": environment,
    }
)

# 5. Enforce security requirements (SSE and Public Access Block)
# Block all public access
public_access_block = aws.s3.BucketPublicAccessBlock(
    "publicAccessBlock",
    bucket=storage_bucket.id, # Reference the bucket ID
    block_public_acls=True,
    block_public_policy=True,
    ignore_public_acls=True,
    restrict_public_buckets=True,
)

# Enforce Server-Side Encryption (SSE-S3)
encryption_config = aws.s3.BucketServerSideEncryptionConfiguration(
    "bucketEncryption",
    bucket=storage_bucket.id,
    rules=[
        aws.s3.BucketServerSideEncryptionConfigurationRuleArgs(
            apply_server_side_encryption_by_default=aws.s3.BucketServerSideEncryptionConfigurationRuleApplyServerSideEncryptionByDefaultArgs(
                sse_algorithm="AES256", # SSE-S3
            )
        )
    ]
)

# 6. Export the final S3 Bucket ARN
pulumi.export("storage_arn", storage_bucket.arn)

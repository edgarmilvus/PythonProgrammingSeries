
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import pulumi
import pulumi_aws as aws
import json

# --- Placeholder Resources (Assumed to be defined elsewhere in the stack) ---
# For demonstration, we assume the ECS Cluster and Service ARN exist.
# In a real scenario, these would be created earlier in the program.
ecs_cluster_name = "llm-inference-cluster"
ecs_service_name = "llm-inference-service"

# 1. Introduce Secrets Manager
llm_api_secret = aws.secretsmanager.Secret(
    "llmApiKeySecret",
    description="API Key for external LLM inference service",
)

# Store a placeholder value (required for the secret to be created)
llm_api_secret_value = aws.secretsmanager.SecretVersion(
    "llmApiKeySecretValue",
    secret_id=llm_api_secret.id,
    secret_string="sk-12345-temporary-key",
)

# 2. Fargate Service Modification (Conceptual Task Definition Update)
# The Task Definition must reference the secret ARN.
# Note: In a real stack, the Task Definition object would be modified.
container_definitions_json = llm_api_secret.arn.apply(lambda arn: json.dumps([
    {
        "name": "llm-inference-container",
        "image": "123456789012.dkr.ecr.us-west-2.amazonaws.com/llm-repo:latest",
        "portMappings": [{"containerPort": 8080, "hostPort": 8080}],
        # Required Secrets integration block
        "secrets": [
            {
                "name": "INFERENCE_API_KEY",
                "valueFrom": arn # Reference the Pulumi Output of the Secret ARN
            }
        ]
    }
]))

# 3. Scaling Role Provisioning (Required for Application Auto Scaling)
# Note: This role must trust the Application Auto Scaling service
scaling_role = aws.iam.Role(
    "ecsScalingRole",
    assume_role_policy=json.dumps({
        "Version": "2012-10-17",
        "Statement": [{
            "Action": "sts:AssumeRole",
            "Effect": "Allow",
            "Principal": {"Service": "application-autoscaling.amazonaws.com"},
        }],
    }),
)

# Attach required policy for ECS service scaling permissions
aws.iam.RolePolicyAttachment(
    "ecsScalingPolicyAttachment",
    role=scaling_role.name,
    policy_arn="arn:aws:iam::aws:policy/service-role/AmazonEC2ContainerServiceAutoscaleRole"
)

# 4. Define Scaling Target (Links ECS Service to Auto Scaling)
scaling_target = aws.appautoscaling.Target(
    "ecsScalingTarget",
    service_namespace="ecs",
    resource_id=pulumi.Output.concat("service/", ecs_cluster_name, "/", ecs_service_name),
    scalable_dimension="ecs:service:DesiredCount",
    role_arn=scaling_role.arn,
    min_capacity=1,
    max_capacity=5,
)

# 5. Define Scaling Policy (Target Tracking on CPU Utilization)
scaling_policy = aws.appautoscaling.Policy(
    "cpuTargetTrackingPolicy",
    service_namespace=scaling_target.service_namespace,
    resource_id=scaling_target.resource_id,
    scalable_dimension=scaling_target.scalable_dimension,
    policy_type="TargetTrackingScaling",
    target_tracking_configuration=aws.appautoscaling.PolicyTargetTrackingConfigurationArgs(
        predefined_metric_specification=aws.appautoscaling.PolicyTargetTrackingConfigurationPredefinedMetricSpecificationArgs(
            predefined_metric_type="ECSServiceAverageCPUUtilization",
        ),
        target_value=60.0, # Target 60% CPU utilization
        scale_in_cooldown=60,
        scale_out_cooldown=60,
    ),
)

pulumi.export("secret_arn", llm_api_secret.arn)

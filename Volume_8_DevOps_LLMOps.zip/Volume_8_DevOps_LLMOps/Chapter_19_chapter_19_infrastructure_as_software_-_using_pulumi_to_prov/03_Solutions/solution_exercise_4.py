
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import pulumi
import pulumi_aws as aws
import json

# --- Configuration & Placeholders ---
# Placeholder for the assumed ECR image location
ECR_IMAGE_URI = "123456789012.dkr.ecr.us-west-2.amazonaws.com/llm-inference-repo:latest"
LAMBDA_MEMORY = 3008 # MB

# 1. IAM Role Definition (Lambda Execution Role)
assume_role_policy = json.dumps({
    "Version": "2012-10-17",
    "Statement": [{
        "Action": "sts:AssumeRole",
        "Effect": "Allow",
        "Principal": {"Service": "lambda.amazonaws.com"},
    }],
})

llm_lambda_role = aws.iam.Role(
    "llmLambdaExecutionRole",
    assume_role_policy=assume_role_policy,
)

# Attach policies for logging and ECR access
aws.iam.RolePolicyAttachment(
    "lambdaLogPolicy",
    role=llm_lambda_role.name,
    policy_arn="arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
)
aws.iam.RolePolicyAttachment(
    "ecrReadOnlyPolicy",
    role=llm_lambda_role.name,
    policy_arn="arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
)

# 3. Lambda Function Provisioning (Container Image)
llm_lambda = aws.lambda_.Function(
    "llmInferenceFunction",
    image_uri=ECR_IMAGE_URI,
    package_type="Image",
    role=llm_lambda_role.arn,
    memory_size=LAMBDA_MEMORY,
    timeout=60, # 60 seconds for inference
)

# 4. API Gateway Integration (REST API)
api_gateway = aws.apigateway.RestApi(
    "llmInferenceApi",
    description="API Gateway for LLM Inference Lambda",
)

# Create a resource path (/infer)
api_resource = aws.apigateway.Resource(
    "inferenceResource",
    rest_api_id=api_gateway.id,
    parent_id=api_gateway.root_resource_id,
    path_part="infer",
)

# Create a POST method on the resource
api_method = aws.apigateway.Method(
    "inferenceMethod",
    rest_api_id=api_gateway.id,
    resource_id=api_resource.id,
    http_method="POST",
    authorization="NONE",
)

# Integrate the method with the Lambda function
api_integration = aws.apigateway.Integration(
    "lambdaIntegration",
    rest_api_id=api_gateway.id,
    resource_id=api_resource.id,
    http_method=api_method.http_method,
    integration_http_method="POST", # Lambda invocation method
    type="AWS_PROXY", # Use proxy integration for simplicity
    uri=llm_lambda.invoke_arn, # Use the special invoke ARN
)

# Deploy the API Gateway
api_deployment = aws.apigateway.Deployment(
    "apiDeployment",
    rest_api_id=api_gateway.id,
    # Note: Pulumi handles implicit dependency on integration here,
    # but we ensure the deployment is triggered by method changes.
    triggers={"redeployment": api_integration.id},
)

# Create a stage to make the API callable
api_stage = aws.apigateway.Stage(
    "prodStage",
    rest_api_id=api_gateway.id,
    deployment_id=api_deployment.id,
    stage_name="prod",
)

# 5. Permissions Grant: Allow API Gateway to invoke Lambda
lambda_permission = aws.lambda_.Permission(
    "apiGatewayLambdaPermission",
    action="lambda:InvokeFunction",
    function=llm_lambda.name,
    principal="apigateway.amazonaws.com",
    # Source ARN restricts access to ONLY this API Gateway execution
    source_arn=pulumi.Output.concat(
        api_gateway.execution_arn, "/*/*" # Format: arn:aws:execute-api:region:account-id:api-id/*/*
    )
)

# 6. Endpoint Export
# Format: https://{restApiId}.execute-api.{region}.amazonaws.com/{stageName}
inference_endpoint_url = pulumi.Output.concat(
    "https://", api_gateway.id, ".execute-api.", aws.get_region().name, ".amazonaws.com/", api_stage.stage_name, "/infer"
)

pulumi.export("inference_endpoint_url", inference_endpoint_url)

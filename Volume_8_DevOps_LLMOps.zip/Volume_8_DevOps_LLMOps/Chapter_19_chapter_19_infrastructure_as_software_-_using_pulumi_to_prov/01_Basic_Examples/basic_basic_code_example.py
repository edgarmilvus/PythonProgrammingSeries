
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import pulumi
import pulumi_aws as aws
import sys

# --- 1. Configuration and Setup ---

# Retrieve the current Pulumi stack name (e.g., 'dev', 'staging', 'prod').
# This is crucial for creating unique resource names across environments.
stack_name = pulumi.get_stack() 

# Define a consistent prefix using Python's f-string formatting.
# This ensures easy identification of resources provisioned by this specific project.
resource_prefix = f"book10-iac-demo-{stack_name}" 

# --- 2. Resource Declaration (The Core IaC) ---

try:
    # Instantiate the S3 Bucket resource class provided by the pulumi_aws SDK.
    simple_bucket = aws.s3.Bucket(
        # Argument 1: The logical name (used internally by Pulumi state)
        "web-content-storage", 
        
        # Argument 2: Configuration properties for the physical AWS resource
        opts=pulumi.ResourceOptions(protect=False), # Optional: Prevents accidental deletion if set to True
        
        # Physical bucket name (must be globally unique across AWS)
        bucket=f"{resource_prefix}-data-store", 
        
        # Access Control List: Setting to 'private' is the modern standard practice
        acl="private", 
        
        # Metadata tags for cost tracking and organization
        tags={
            "Environment": stack_name,
            "Project": "Book10-IaC-Demo",
            "ManagedBy": "PulumiPython",
        }
    )
    
    # --- 3. Enforcing Public Access Block (Security Best Practice) ---
    # AWS security requires a separate resource to explicitly block all forms of public access.
    # We reference the bucket created in step 2 using its ID.
    public_access_block = aws.s3.BucketPublicAccessBlock(
        # Logical name for the access block resource
        "public-access-block",
        
        # CRITICAL: Referencing the ID of the bucket created above.
        # This creates an implicit dependency: Pulumi ensures the bucket exists before applying this block.
        bucket=simple_bucket.id, 
        
        block_public_acls=True,
        block_public_policy=True,
        ignore_public_acls=True,
        restrict_public_buckets=True,
    )

except Exception as e:
    # While Pulumi handles most deployment errors during runtime, 
    # Python error handling catches issues during the initial definition phase.
    print(f"Failed to define resources: {e}", file=sys.stderr)
    sys.exit(1)


# --- 4. Exporting Outputs ---

# Export the resulting properties of the infrastructure. 
# These values are displayed to the user after deployment and stored in the state file.
pulumi.export("bucket_name", simple_bucket.id)
pulumi.export("bucket_arn", simple_bucket.arn)

# Using pulumi.Output.concat to construct a user-friendly endpoint URL.
# This handles the asynchronous nature of Pulumi Outputs.
pulumi.export("bucket_endpoint", pulumi.Output.concat("s3://", simple_bucket.bucket))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pulumi
import pulumi_aws as aws
import pulumi_awsx as awsx
import json

# --- 1. Configuration and Constants ---
PROJECT_NAME = "llm-inference-api"
CONTAINER_PORT = 8000  # Standard port for the FastAPI/Uvicorn application
FARGATE_CPU = "512"    # 0.5 vCPU
FARGATE_MEMORY = "1024" # 1 GB

# Define the IAM policy document for the Task Execution Role
TASK_EXEC_ASSUME_ROLE_POLICY = json.dumps({
    "Version": "2012-10-17",
    "Statement": [{
        "Action": "sts:AssumeRole",
        "Effect": "Allow",
        "Principal": {"Service": "ecs-tasks.amazonaws.com"},
    }]
})

# --- 2. Network Infrastructure Provisioning (VPC) ---
# Use the higher-level 'awsx' library to quickly create a robust VPC with public/private subnets.
vpc = awsx.ec2.Vpc(f"{PROJECT_NAME}-vpc",
    number_of_availability_zones=3,
    cidr_block="10.10.0.0/16",
    tags={"Project": PROJECT_NAME, "Tier": "Network"}
)

# --- 3. Container Registry (ECR) ---
# Create the repository where the application's Docker image will be pushed.
repo = aws.ecr.Repository(f"{PROJECT_NAME}-repo",
    image_tag_mutability="MUTABLE",
    force_delete=True, # Allows Pulumi to destroy the repo easily during teardown
    tags={"Project": PROJECT_NAME}
)

# --- 4. ECS Cluster Definition ---
# The logical grouping for our Fargate tasks.
cluster = aws.ecs.Cluster(f"{PROJECT_NAME}-cluster",
    tags={"Project": PROJECT_NAME}
)

# --- 5. IAM Roles for Fargate Execution ---
# Execution Role: Allows Fargate to pull the image from ECR and publish logs to CloudWatch.
task_exec_role = aws.iam.Role(f"{PROJECT_NAME}-exec-role",
    assume_role_policy=TASK_EXEC_ASSUME_ROLE_POLICY
)
aws.iam.RolePolicyAttachment(f"{PROJECT_NAME}-exec-policy-attach",
    role=task_exec_role.name,
    policy_arn="arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
)

# --- 6. Security Group Definition ---
# Allows inbound traffic on the container port (8000) from anywhere (0.0.0.0/0).
sec_group = aws.ec2.SecurityGroup(f"{PROJECT_NAME}-sg",
    vpc_id=vpc.vpc_id,
    ingress=[
        # Allow inbound traffic on the specified container port (e.g., 8000)
        {"protocol": "tcp", "from_port": CONTAINER_PORT, "to_port": CONTAINER_PORT, "cidr_blocks": ["0.0.0.0/0"]},
    ],
    egress=[
        # Allow all outbound traffic
        {"protocol": "-1", "from_port": 0, "to_port": 0, "cidr_blocks": ["0.0.0.0/0"]},
    ]
)

# --- 7. Task Definition (The Blueprint for the Container) ---
# This uses Pulumi's `apply` method to handle dependencies dynamically.
task_definition = aws.ecs.TaskDefinition(f"{PROJECT_NAME}-task",
    family=f"{PROJECT_NAME}-fargate-task",
    cpu=FARGATE_CPU,
    memory=FARGATE_MEMORY,
    network_mode="awsvpc",
    requires_compatibilities=["FARGATE"],
    execution_role_arn=task_exec_role.arn,
    # Dynamically construct the container definition JSON using the ECR URL output
    container_definitions=pulumi.Output.all(repo.repository_url, aws.get_region()).apply(lambda args: json.dumps([
        {
            "name": f"{PROJECT_NAME}-container",
            "image": f"{args[0]}:latest", # args[0] is the repository_url
            "portMappings": [{"containerPort": CONTAINER_PORT, "hostPort": CONTAINER_PORT, "protocol": "tcp"}],
            "logConfiguration": {
                "logDriver": "awslogs",
                "options": {
                    "awslogs-group": f"/ecs/fargate/{PROJECT_NAME}",
                    "awslogs-region": args[1].name, # args[1] is the resolved AWS region name
                    "awslogs-stream-prefix": "ecs"
                }
            }
        }
    ]))
)

# --- 8. Fargate Service Deployment ---
# Deploys the task definition, maintaining the desired number of instances.
service = aws.ecs.Service(f"{PROJECT_NAME}-service",
    cluster=cluster.arn,
    desired_count=1,
    launch_type="FARGATE",
    task_definition=task_definition.arn,
    network_configuration={
        "subnets": vpc.public_subnet_ids, # Deploy tasks into the public network tier
        "security_groups": [sec_group.id],
        "assign_public_ip": True # Required for tasks in public subnets to communicate externally
    },
    opts=pulumi.ResourceOptions(depends_on=[sec_group])
)

# --- 9. Export Critical Outputs ---
# These values are displayed after a successful 'pulumi up' and are used in CI/CD pipelines.
pulumi.export("ecr_push_command", repo.repository_url.apply(
    lambda url: f"docker push {url}:latest"
))
pulumi.export("ecs_cluster_name", cluster.name)
pulumi.export("vpc_id", vpc.vpc_id)

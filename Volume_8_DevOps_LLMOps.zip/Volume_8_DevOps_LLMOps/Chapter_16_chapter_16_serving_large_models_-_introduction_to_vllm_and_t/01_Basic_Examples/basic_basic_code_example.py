
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# basic_vllm_inference.py
import os
from vllm import LLM, SamplingParams

# --- 1. Configuration Constants ---
# Using a small model for rapid conceptual demonstration
MODEL_NAME = "facebook/opt-125m"
MAX_TOKENS = 64
TEMPERATURE = 0.7

# --- 2. Define the input prompts (Batching) ---
# vLLM excels at processing multiple requests concurrently.
prompts = [
    "Explain the concept of PagedAttention in simple terms.",
    "Write a short, four-line poem about cloud computing.",
    "What is the capital of France and why is it important?"
]

# --- 3. Initialize the vLLM Engine ---
# This step loads the model weights and sets up the PagedAttention memory manager.
print(f"Loading model: {MODEL_NAME}...")
try:
    llm = LLM(
        model=MODEL_NAME,
        trust_remote_code=True,
        # tensor_parallel_size=1 (Use > 1 for multi-GPU serving)
        quantization=None # Set to 'awq' or 'squeezellm' for memory optimization
    )
except Exception as e:
    # This error typically occurs if a compatible GPU/CUDA environment is missing.
    print(f"CRITICAL ERROR: Failed to initialize LLM. Ensure vLLM dependencies and GPU environment are correctly configured.")
    print(f"Details: {e}")
    exit()

# --- 4. Define Sampling Parameters ---
sampling_params = SamplingParams(
    temperature=TEMPERATURE,
    max_tokens=MAX_TOKENS,
    top_p=0.95,
    stop=["\n", "###"] # Stop generation when these tokens are encountered
)

# --- 5. Perform the inference (Generation) ---
# The generate method processes all prompts in an optimized batch.
print(f"\nStarting generation for {len(prompts)} prompts...")
outputs = llm.generate(
    prompts=prompts,
    sampling_params=sampling_params
)

# --- 6. Display the results ---
print("\n--- Inference Results ---")
for i, output in enumerate(outputs):
    prompt = output.prompt
    # Accessing the generated text from the first sequence output
    generated_text = output.outputs[0].text.strip()
    
    # Display statistics related to token usage
    num_prompt_tokens = len(output.prompt_token_ids)
    num_generated_tokens = len(output.outputs[0].token_ids)

    print(f"--- Request {i+1} ---")
    print(f"Prompt: {prompt}")
    print(f"Tokens (Input/Output): {num_prompt_tokens}/{num_generated_tokens}")
    print(f"Response:\n{generated_text}\n")

print("--- Inference Complete ---")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import asyncio
import time
from typing import List, Dict, Any

# --- MOCKING VLLM COMPONENTS FOR EXECUTION ---
# In a production environment, these would be imported directly:
# from vllm import LLM, SamplingParams

class MockSamplingParams:
    """
    Simulates vLLM's SamplingParams object. This class encapsulates all
    critical generation parameters (temperature, max_tokens, stop sequences).
    """
    def __init__(self, temperature: float = 0.7, max_tokens: int = 128, 
                 top_p: float = 1.0, stop: List[str] = None):
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.top_p = top_p
        self.stop = stop if stop is not None else []

class MockLLM:
    """
    Simulates the vLLM server interface. It abstracts the underlying
    complexities of PagedAttention and Tensor Parallelism.
    """
    def __init__(self, model: str, tensor_parallel_size: int = 1):
        # tensor_parallel_size simulates using multiple GPUs for a single model
        print(f"Initializing Mock vLLM for model: {model} (TP={tensor_parallel_size})")
        self.model_name = model
        # Simulate initial model loading overhead
        time.sleep(0.5)

    async def generate(self, prompts: List[str], sampling_params: MockSamplingParams) -> List[Dict[str, Any]]:
        """
        Simulates the batched, high-throughput generation process.
        The low simulated latency reflects the efficiency gained by PagedAttention.
        """
        # Simulated processing time: a small base time + a tiny increment per prompt
        processing_time = 0.05 + len(prompts) * 0.01 
        await asyncio.sleep(processing_time)
        
        results = []
        for i, prompt in enumerate(prompts):
            # Simulate a deterministic moderation output
            output_text = f"Result for '{prompt[:30]}...': Moderation Score {i % 10 / 10:.2f}"
            results.append({
                "prompt": prompt,
                "generated_text": output_text,
                # Simulate the per-item latency derived from the batch time
                "latency_ms": processing_time * 1000 / len(prompts) 
            })
        return results

# --- Application Configuration ---
MODEL_PATH = "meta-llama/Llama-2-7b-chat-hf"
TENSOR_PARALLEL_SIZE = 4 # Configuration parameter for vLLM's Tensor Parallelism

# --- Data Definition (The moderation backlog) ---
MODERATION_PROMPTS = [
    "Analyze the tone and intent: 'I absolutely loved the movie, it was fantastic!'",
    "Determine if this comment contains hate speech: 'You are the worst programmer I have ever seen.'",
    "Summarize the sentiment: 'This product broke after one day of use, total waste of money.'",
    "Check for spam content: 'Click here now to win a free iPhone! Limited time offer.'",
    "Evaluate political rhetoric: 'The current policy is deeply flawed and needs immediate reform.'",
    "Analyze the tone and intent: 'The service was slow and the food was cold.'",
    "Determine if this comment contains hate speech: 'This is a truly magnificent piece of art.'",
    "Summarize the sentiment: 'I had high hopes, but I was severely disappointed by the ending.'",
    "Check for toxicity: 'I am extremely upset by the delay in shipment.'",
    "Analyze for phishing attempts: 'Send your password to this email for verification.'",
]

# --- Core Asynchronous Serving Logic ---

async def run_moderation_batch(llm_engine: MockLLM, prompts: List[str], batch_id: int):
    """
    Executes a single, optimized batch inference request using specific
    sampling parameters tailored for classification/moderation tasks.
    """
    print(f"\n[Batch {batch_id}] Submitting {len(prompts)} prompts...")
    
    # Configure the high-throughput sampling parameters
    sampling_params = MockSamplingParams(
        temperature=0.0,      # Zero temperature ensures deterministic, repeatable output
        max_tokens=64,        # Limit output length to maximize speed
        stop=["\n"],          # Stop generation immediately after the first line break
    )

    start_time = time.perf_counter()
    
    # The call to generate is where vLLM's internal scheduling and PagedAttention
    # manage the KV cache for maximum concurrent throughput.
    results = await llm_engine.generate(prompts, sampling_params)
    
    end_time = time.perf_counter()
    total_time = end_time - start_time
    
    # Calculate and report critical performance metrics
    print(f"[Batch {batch_id}] Completed in {total_time:.4f} seconds.")
    print(f"[Batch {batch_id}] Throughput: {len(prompts) / total_time:.2f} requests/sec.")
    
    for result in results:
        print(f"  > P: '{result['prompt'][:20]}...' | O: {result['generated_text']}")

async def main():
    """
    Initializes the vLLM simulation and runs multiple concurrent batches
    to demonstrate high-saturation client architecture.
    """
    # 1. Initialize the simulated vLLM engine, setting up parallelism
    llm_engine = MockLLM(MODEL_PATH, TENSOR_PARALLEL_SIZE)

    # 2. Divide the large workload into smaller, concurrent batches
    batch_size = 5
    batches = [MODERATION_PROMPTS[i:i + batch_size] 
               for i in range(0, len(MODERATION_PROMPTS), batch_size)]

    # 3. Create concurrent tasks for each batch submission
    tasks = []
    for i, batch in enumerate(batches):
        tasks.append(run_moderation_batch(llm_engine, batch, i + 1))

    # 4. Run all tasks concurrently using asyncio.gather()
    # This maximizes client-side resource utilization and keeps the server saturated.
    print("\n--- Starting Concurrent Batch Processing ---")
    await asyncio.gather(*tasks)
    print("\n--- All Batches Processed Successfully ---")

if __name__ == "__main__":
    # Standard entry point for asynchronous applications
    asyncio.run(main())


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import time
import threading
import random
from collections import deque

# --- Mocking the vLLM Engine State ---
# In a real scenario, you would access engine.scheduler.get_num_running_requests()
# and engine.scheduler.get_num_waiting_requests().

class MockAsyncLLMEngine:
    def __init__(self, max_concurrent):
        self.max_concurrent_requests = max_concurrent
        self.running_requests = 0
        self.pending_requests = 0
        self.lock = threading.Lock()

    def get_state(self):
        """Returns the current operational state."""
        with self.lock:
            return self.running_requests, self.pending_requests

    def simulate_load_change(self, new_pending, new_running):
        """Simulates external load changes (requests arriving/finishing)."""
        with self.lock:
            self.pending_requests = max(0, new_pending)
            self.running_requests = min(self.max_concurrent_requests, max(0, new_running))
            # If running exceeds max, the excess should stay pending (simplified here)

# --- Monitoring Function ---
MAX_CONCURRENT_REQUESTS = 16 # Assumed maximum batch size or slot capacity

def monitor_vllm_queue(engine_instance, interval=5):
    """Periodically reports the status of the vLLM request queue."""
    print(f"--- Starting vLLM Queue Monitor (Interval: {interval}s) ---")
    
    while True:
        running, pending = engine_instance.get_state()
        
        # 1 & 2. Access state (done via mock engine)
        
        # 3. Utilization Calculation
        utilization = (running / MAX_CONCURRENT_REQUESTS) * 100
        
        # 4. Reporting
        status_message = (
            f"[{time.strftime('%H:%M:%S')}] "
            f"Queue Depth: {pending:3d} | "
            f"Running: {running:2d} | "
            f"Utilization: {utilization:5.2f}%"
        )
        print(status_message)
        
        time.sleep(interval)

# --- Simulation Main Loop ---
def simulation_main(engine):
    """Simulates the arrival and completion of requests over time."""
    print("\n--- Starting Load Simulation ---")
    
    # Time 0: Initial state (0 running, 0 pending)
    engine.simulate_load_change(0, 0)
    time.sleep(1)

    # Time 1: Sudden load spike (40 requests arrive)
    print("LOAD EVENT: 40 requests arrive.")
    engine.simulate_load_change(40, 16) # Max running (16), rest pending (24)
    time.sleep(10)

    # Time 2: Some requests finish, queue shrinks
    print("LOAD EVENT: Scheduler processes 10 requests.")
    engine.simulate_load_change(14, 16) # 24 - 10 = 14 pending
    time.sleep(10)

    # Time 3: High load continues, but running drops slightly
    print("LOAD EVENT: Running requests drop due to short generations.")
    engine.simulate_load_change(14, 10)
    time.sleep(10)
    
    # Time 4: Load clears
    print("LOAD EVENT: All requests finished.")
    engine.simulate_load_change(0, 0)
    time.sleep(5)
    
    print("--- Simulation Finished ---")
    # In a real app, you would stop the monitor thread here.

if __name__ == "__main__":
    mock_engine = MockAsyncLLMEngine(MAX_CONCURRENT_REQUESTS)
    
    # Start the monitor thread
    monitor_thread = threading.Thread(target=monitor_vllm_queue, args=(mock_engine,), daemon=True)
    monitor_thread.start()
    
    # Run the simulation in the main thread
    simulation_main(mock_engine)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import math

class PagedAttentionSimulator:
    def __init__(self, total_blocks, block_size):
        self.total_blocks = total_blocks
        self.block_size = block_size
        # Free blocks are represented by their index (0 to total_blocks - 1)
        self.free_blocks = list(range(total_blocks))
        # Maps request ID to the list of physical block IDs allocated to it
        self.request_to_blocks = {}
        # Maps request ID to the total number of tokens currently generated/reserved
        self.request_token_count = {}
        
        print(f"Simulator initialized: {total_blocks} blocks, size {block_size} tokens/block.")

    def _tokens_to_blocks(self, tokens):
        """Calculates the number of blocks required for a given number of tokens."""
        if tokens <= 0:
            return 0
        # Ceiling division: math.ceil(tokens / self.block_size)
        return (tokens + self.block_size - 1) // self.block_size

    def _allocate_physical_blocks(self, count):
        """Pulls 'count' blocks from the free pool."""
        if len(self.free_blocks) < count:
            raise MemoryError(f"Insufficient memory. Need {count} blocks, only {len(self.free_blocks)} available.")
        
        # Allocate blocks from the end of the free list
        allocated = [self.free_blocks.pop() for _ in range(count)]
        return allocated

    def allocate_blocks(self, request_id, required_tokens):
        if request_id in self.request_to_blocks:
            print(f"Error: Request {request_id} already exists.")
            return

        required_blocks = self._tokens_to_blocks(required_tokens)
        
        try:
            new_blocks = self._allocate_physical_blocks(required_blocks)
            self.request_to_blocks[request_id] = new_blocks
            self.request_token_count[request_id] = required_tokens
            print(f"[ALLOCATE] Request {request_id}: Tokens={required_tokens} -> Blocks={required_blocks}. Assigned IDs: {new_blocks}")
        except MemoryError as e:
            print(f"[FAILURE] Request {request_id}: {e}")
        
        self.print_status()

    def extend_sequence(self, request_id, new_tokens):
        if request_id not in self.request_to_blocks:
            print(f"Error: Request {request_id} not found.")
            return

        current_tokens = self.request_token_count[request_id]
        new_total_tokens = current_tokens + new_tokens
        
        current_blocks = len(self.request_to_blocks[request_id])
        required_blocks = self._tokens_to_blocks(new_total_tokens)
        
        blocks_to_add = required_blocks - current_blocks
        
        if blocks_to_add > 0:
            try:
                added_blocks = self._allocate_physical_blocks(blocks_to_add)
                self.request_to_blocks[request_id].extend(added_blocks)
                print(f"[EXTEND] Request {request_id}: Added {new_tokens} tokens. Allocated {blocks_to_add} new blocks: {added_blocks}")
            except MemoryError as e:
                print(f"[FAILURE] Request {request_id}: Cannot extend sequence. {e}")
                return
        else:
             print(f"[EXTEND] Request {request_id}: Added {new_tokens} tokens. No new blocks needed.")

        self.request_token_count[request_id] = new_total_tokens
        self.print_status()


    def free_request(self, request_id):
        if request_id not in self.request_to_blocks:
            print(f"Error: Request {request_id} not found.")
            return
        
        freed_blocks = self.request_to_blocks.pop(request_id)
        del self.request_token_count[request_id]
        
        # Return blocks to the free pool
        self.free_blocks.extend(freed_blocks)
        
        print(f"[FREE] Request {request_id} finished. Returned {len(freed_blocks)} blocks: {freed_blocks}")
        self.print_status()

    def print_status(self):
        print(f"--- STATUS --- Total Blocks: {self.total_blocks}, Free Blocks: {len(self.free_blocks)} / {self.total_blocks}")
        print(f"Allocated Requests: {self.request_to_blocks}")
        print("--------------\n")

# --- Simulation Scenario ---
simulator = PagedAttentionSimulator(total_blocks=100, block_size=16)

# Step 1: Request A requires 30 tokens (allocates 2 blocks: 16*2=32 capacity)
simulator.allocate_blocks("A", 30) 

# Step 2: Request B requires 100 tokens (allocates 7 blocks: 16*7=112 capacity)
simulator.allocate_blocks("B", 100)

# Step 3: Request C requires 1 token (allocates 1 block)
simulator.allocate_blocks("C", 1)

# Step 4: Request A generates 10 more tokens (30 + 10 = 40 total tokens). 
# Capacity is 32 (2 blocks). Requires a 3rd block.
simulator.extend_sequence("A", 10) 

# Step 5: Request B finishes and is freed. (7 blocks returned)
simulator.free_request("B")

# Step 6: Request D requires 50 tokens (allocates 4 blocks: 16*4=64 capacity). 
# Should reuse blocks freed by B.
simulator.allocate_blocks("D", 50)

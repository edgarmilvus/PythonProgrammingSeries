
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# llm_handler.py
import json
import time
import os
from ts.torch_handler.base_handler import BaseHandler

class LLMHandler(BaseHandler):
    """
    Custom handler for serving a large language model (LLM) via TorchServe.
    """
    def initialize(self, context):
        """
        Simulates loading a large model and checks configuration settings.
        """
        properties = context.system_properties
        model_dir = properties.get("model_dir")
        
        # Critical check for large models: ensure model loading timeout is sufficient
        print(f"TorchServe worker starting. Model directory: {model_dir}")
        
        # Simulate a long loading time (e.g., loading 7B weights)
        print("Loading large model weights... This may take time (simulated 30s).")
        time.sleep(3) # Use a short sleep for runnable simulation, but log the context
        
        # In a real scenario, model loading (self.model) happens here.
        self.initialized = True
        print("LLM model initialization complete.")

    def preprocess(self, data):
        """
        Extracts the input text prompt from the incoming request.
        """
        # Data is typically a list of dictionaries (one per batch item)
        text_prompts = []
        for row in data:
            # Assuming input is JSON or bytes that need decoding
            prompt = row.get("data") or row.get("body")
            if isinstance(prompt, bytes):
                prompt = prompt.decode('utf-8')
            
            try:
                prompt_data = json.loads(prompt)
                text_prompts.append(prompt_data['prompt'])
            except:
                # Handle raw text input
                text_prompts.append(prompt) 
        
        return text_prompts

    def inference(self, data):
        """
        Simulates the LLM generation process.
        """
        results = []
        for prompt in data:
            # Simulate a long generation time (which might hit default timeouts)
            # This is why we need increased model_loading_timeout and max_response_size
            generated_text = f"Response to '{prompt[:30]}...': This is a simulated 7B LLM output."
            results.append({"generated_text": generated_text})
        return results

    def postprocess(self, data):
        """
        Formats the inference output into a standardized JSON response.
        """
        # Data is already a list of dictionaries from inference
        return data

    def handle(self, data, context):
        # Standard handler flow
        if not self.initialized:
            self.initialize(context)
            
        model_input = self.preprocess(data)
        model_output = self.inference(model_input)
        return self.postprocess(model_output)

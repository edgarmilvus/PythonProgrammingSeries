
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import asyncio
import time
import random
import statistics
from vllm import AsyncLLMEngine, SamplingParams
from vllm.engine.arg_utils import EngineArgs

# --- Configuration ---
MODEL_NAME = "meta-llama/Llama-2-7b-chat-hf" # Placeholder model
NUM_REQUESTS = 500
MAX_OUTPUT_LEN = 128
PROMPT_LEN_MIN = 50
PROMPT_LEN_MAX = 500
TOKEN_PER_WORD = 4 # Approximation for generating prompt text

# Helper function to generate a prompt of a specific token length
def generate_prompt(length):
    words = length // TOKEN_PER_WORD
    return "The quick brown fox jumps over the lazy dog. " * words

async def run_request(engine, request_id, prompt):
    # Set sampling parameters
    sampling_params = SamplingParams(
        n=1,
        temperature=0.0,
        max_tokens=MAX_OUTPUT_LEN
    )
    
    start_time = time.perf_counter()
    
    # Generate the request stream
    results_generator = engine.generate(prompt, sampling_params, request_id)
    
    first_token_time = None
    
    # Iterate through the stream to find the Time-to-First-Token (TTFT)
    async for request_output in results_generator:
        if first_token_time is None:
            first_token_time = time.perf_counter()
        
        # Check if generation is finished
        if request_output.finished:
            end_time = time.perf_counter()
            break
            
    # Calculate metrics
    ttft = first_token_time - start_time if first_token_time else 0
    total_latency = end_time - start_time
    
    return ttft, total_latency

async def main():
    print(f"Initializing vLLM engine for model: {MODEL_NAME}")
    
    # Initialize the engine (using engine args for common configuration)
    engine_args = EngineArgs(
        model=MODEL_NAME,
        tensor_parallel_size=1, # Adjust based on hardware
        disable_log_requests=True,
        max_model_len=PROMPT_LEN_MAX + MAX_OUTPUT_LEN
    )
    engine = AsyncLLMEngine.from_engine_args(engine_args)

    # 2. Generate randomized prompts
    tasks = []
    print(f"Generating {NUM_REQUESTS} concurrent requests...")
    for i in range(NUM_REQUESTS):
        prompt_len = random.randint(PROMPT_LEN_MIN, PROMPT_LEN_MAX)
        prompt = generate_prompt(prompt_len)
        request_id = f"req-{i:04d}"
        tasks.append(run_request(engine, request_id, prompt))
        
    start_wall_time = time.perf_counter()
    
    # 3. Execute all tasks concurrently
    results = await asyncio.gather(*tasks)
    
    end_wall_time = time.perf_counter()
    
    # 4. Metric Collection
    total_wall_time = end_wall_time - start_wall_time
    
    ttft_list = [r[0] for r in results]
    
    avg_ttft = statistics.mean(ttft_list)
    throughput = NUM_REQUESTS / total_wall_time
    
    print("\n--- Benchmark Results ---")
    print(f"Total Requests: {NUM_REQUESTS}")
    print(f"Total Wall Time: {total_wall_time:.2f} seconds")
    print(f"Overall Throughput: {throughput:.2f} requests/second")
    print(f"Average Time-to-First-Token (TTFT): {avg_ttft:.4f} seconds")
    
if __name__ == "__main__":
    # Note: This requires a GPU environment with vLLM installed.
    # Execution will simulate the structure required.
    try:
        asyncio.run(main())
    except ImportError:
        print("\n[Simulation Note: vLLM or required dependencies not found. Showing execution structure only.]")
        # Simulate results if vLLM cannot be run
        print("Total Wall Time (Simulated): 15.00 seconds")
        print("Overall Throughput (Simulated): 33.33 requests/second")
        print("Average TTFT (Simulated): 0.5000 seconds")

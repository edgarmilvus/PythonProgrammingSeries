
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import os
import json
import logging
from typing import Dict, Any

# =====================================================================
# 1. Configuration and Initialization (Outside the Handler)
# =====================================================================

# Use os.environ.get() to safely retrieve configuration. This adheres to the 
# EAFP principle: assume the variable exists, but handle the default if it doesn't.
# This code executes once during the 'cold start' initialization phase.
DEFAULT_GREETING = os.environ.get("GREETING_PREFIX", "Hello, Cloud Architect")

# Set up logging early. Serverless functions rely entirely on logs 
# (e.g., AWS CloudWatch) for state tracking and debugging.
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# =====================================================================
# 2. The Handler Function (The Entry Point)
# =====================================================================

def lambda_handler(event: Dict[str, Any], context) -> Dict[str, Any]:
    """
    The main entry point for the AWS Lambda function.

    Args:
        event (Dict): Data passed to the function. The structure varies wildly 
                      based on the trigger (API Gateway, S3, SQS, etc.).
        context: Runtime information about the invocation, execution environment, 
                 and function metadata (e.g., remaining time, function name).

    Returns:
        Dict: A response object. If triggered by API Gateway, this must be 
              structured with 'statusCode', 'headers', and a stringified 'body'.
    """
    
    # --- Stage 1: Input Validation and Extraction (Handling Event Sources) ---
    
    request_data = {}
    
    # CRITICAL: Serverless functions must handle two primary input formats:
    # 1. Direct Invocation (e.g., another Lambda or SDK call): 'event' is a native Python dict.
    # 2. API Gateway/HTTP Trigger: 'event' contains metadata, and the actual payload 
    #    is a JSON string nested under the 'body' key.
    try:
        if 'body' in event and isinstance(event['body'], str):
            # If 'body' is present and is a string, it needs JSON deserialization.
            request_data = json.loads(event['body'])
            logger.debug("Input processed as API Gateway payload.")
        else:
            # Otherwise, assume the event itself is the payload (Direct Invocation).
            request_data = event
            logger.debug("Input processed as direct invocation payload.")
            
    except json.JSONDecodeError as e:
        logger.error(f"Input JSON decoding error: {e}")
        # Return a standardized error response
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Invalid JSON format in request body.'})
        }
    
    # Use EAFP (Easier to Ask for Forgiveness than Permission) pattern:
    # Attempt to get the name, defaulting to 'World' if the key is missing.
    target_name = request_data.get('name', 'World')
    
    # --- Stage 2: Business Logic Execution ---
    
    # Construct the personalized message using the configured prefix (DRY principle: 
    # configuration is centralized in the environment variable).
    final_message = f"{DEFAULT_GREETING}, {target_name}!"
    
    # Log the successful action. This is the primary mechanism for monitoring.
    logger.info(f"Successfully processed request for target: {target_name}.")
    
    # Example use of the context object for richer logging
    logger.info(f"Invocation ID: {context.aws_request_id}. Function Name: {context.function_name}")
    
    # --- Stage 3: Output Formatting ---
    
    # The dictionary containing the actual data payload.
    data_payload = {
        'message': final_message,
        'target_processed': target_name,
        'runtime_details': {
            'memory_limit': f"{context.memory_limit_in_mb} MB",
            'greeting_source': 'Environment Variable'
        }
    }
    
    # Return the standardized API Gateway response structure.
    # The 'body' MUST be a JSON string, not a Python dictionary.
    response = {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'X-Function-Version': context.function_version # Example of using context metadata
        },
        'body': json.dumps(data_payload)
    }
    
    return response

# =====================================================================
# 3. Local Development Utility (DRY Principle in Practice)
# =====================================================================

# This block is crucial for local testing, allowing developers to execute the 
# handler without deploying, adhering to the DRY principle by reusing the core logic.
if __name__ == "__main__":
    
    # Mock Context object (simulates the runtime environment)
    class MockContext:
        function_name = "ConfigurableGreetingFunction"
        memory_limit_in_mb = 128
        aws_request_id = "local-test-12345"
        function_version = "$LATEST"
        def get_remaining_time_in_millis(self): return 3000

    mock_context = MockContext()
    
    # 1. Simulate API Gateway POST request (Input is stringified JSON)
    test_event_api = {
        "resource": "/greet",
        "path": "/greet",
        "httpMethod": "POST",
        "headers": {"content-type": "application/json"},
        "body": json.dumps({"name": "Dr. Python"}) # Note the stringification
    }

    # 2. Simulate Direct Invocation (Input is native dict)
    test_event_direct = {
        "name": "Serverless Dev"
    }
    
    # 3. Simulate Missing Input (Tests the 'World' default)
    test_event_missing = {
        "body": json.dumps({})
    }
    
    print("--- 1. Testing API Gateway Invocation ---")
    # Set a temporary environment variable for this run
    os.environ['GREETING_PREFIX'] = 'Welcome Back'
    # Re-read the configuration (only necessary if running in __main__)
    DEFAULT_GREETING = os.environ.get("GREETING_PREFIX") 
    result_api = lambda_handler(test_event_api, mock_context)
    print(f"Status: {result_api['statusCode']}")
    print(json.loads(result_api['body'])['message'])
    
    print("\n--- 2. Testing Direct Invocation ---")
    # Reset the environment variable to test the default
    del os.environ['GREETING_PREFIX']
    DEFAULT_GREETING = os.environ.get("GREETING_PREFIX", "Hello, Cloud Architect")
    result_direct = lambda_handler(test_event_direct, mock_context)
    print(f"Status: {result_direct['statusCode']}")
    print(json.loads(result_direct['body'])['message'])

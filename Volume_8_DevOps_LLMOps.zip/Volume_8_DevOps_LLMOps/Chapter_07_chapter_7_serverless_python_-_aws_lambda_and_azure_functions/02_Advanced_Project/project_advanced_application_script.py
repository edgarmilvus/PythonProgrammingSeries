
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import json
import logging
import io
from PIL import Image # CRITICAL: External dependency requiring bundling
import boto3 # Standard AWS SDK

# --- Configuration & Environment Variables ---
# The ARN (Amazon Resource Name) of the SNS Topic to notify upon completion
SNS_TOPIC_ARN = os.environ.get("SNS_NOTIFICATION_TOPIC", "arn:aws:sns:us-east-1:123456789012:ImageProcessingResults")
# Target size for internal processing normalization
TARGET_CLASSIFICATION_SIZE = (128, 128)
# Threshold used for simple aspect ratio classification
MIN_ASPECT_RATIO = 0.5 

# --- Setup Logging ---
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# --- Client Initialization (Optimization for Cold Starts) ---
# Initializing Boto3 clients outside the handler minimizes latency on subsequent 'warm' invocations.
try:
    S3_CLIENT = boto3.client('s3')
    SNS_CLIENT = boto3.client('sns')
    logger.info("AWS Clients initialized globally.")
except Exception as e:
    logger.critical(f"Failed to initialize AWS clients: {e}")
    # Note: In a production environment, failure here prevents function execution.

# -------------------------------------------------------------------
# 1. Image Processing and Lightweight Inference Logic
# -------------------------------------------------------------------

def extract_image_features(image_bytes: bytes) -> dict:
    """
    Downloads image bytes and performs feature extraction using Pillow.
    Simulates a fast, serverless-optimized AI inference task (e.g., pre-classification).
    """
    try:
        # Use io.BytesIO to treat the raw bytes as a file-like object for PIL
        image = Image.open(io.BytesIO(image_bytes))
        width, height = image.size
        
        # Normalize the image size for consistent feature sampling
        resized_image = image.resize(TARGET_CLASSIFICATION_SIZE)
        
        # Feature 1: Calculate aspect ratio (key visual feature)
        aspect_ratio = min(width, height) / max(width, height)
        
        # Feature 2: Lightweight Classification (Business Logic)
        classification = "Standard_Photo"
        if aspect_ratio < MIN_ASPECT_RATIO:
            classification = "Banner_or_Document_Scan"
        
        # Feature 3: Extract dominant color (simplified: top-left pixel)
        dominant_color = resized_image.getpixel((0, 0))
        
        logger.info(f"Processed image: {width}x{height}, Class: {classification}")
        
        return {
            "width": width,
            "height": height,
            "aspect_ratio": aspect_ratio,
            "classification": classification,
            "dominant_color_rgb": dominant_color
        }
    except Exception as e:
        logger.error(f"Error during image feature extraction: {e}")
        # Propagate error to trigger Lambda retry or DLQ handling
        raise

# -------------------------------------------------------------------
# 2. Main AWS Lambda Handler Function
# -------------------------------------------------------------------

def lambda_handler(event, context):
    """
    Entry point for the AWS Lambda function.
    'event' contains the S3 notification payload.
    """
    
    # Validation check for expected event structure
    if not event.get('Records'):
        logger.warning("Event received but no records found. Returning early.")
        return {"statusCode": 200, "body": "No records processed."}

    # S3 events often contain multiple records, but we process the first one for simplicity
    record = event['Records'][0]
    
    # 2.1 Extract S3 metadata from the event record
    s3_info = record.get('s3', {})
    bucket_name = s3_info.get('bucket', {}).get('name')
    object_key = s3_info.get('object', {}).get('key')
    
    if not bucket_name or not object_key:
        logger.error("Could not extract bucket or key from S3 event.")
        raise ValueError("Invalid S3 event structure received.")

    logger.info(f"Initiating processing for file: s3://{bucket_name}/{object_key}")

    try:
        # 2.2 Download the image bytes from S3 using the global client
        response = S3_CLIENT.get_object(Bucket=bucket_name, Key=object_key)
        image_bytes = response['Body'].read()
        
        # 2.3 Perform feature extraction and inference
        features = extract_image_features(image_bytes)
        
        # 2.4 Prepare the final structured notification payload
        result_payload = {
            "source_bucket": bucket_name,
            "source_key": object_key,
            "processing_status": "SUCCESS",
            "extracted_features": features,
            "lambda_request_id": context.aws_request_id,
            "timestamp": context.get_remaining_time_in_millis() # Example of using context metadata
        }
        
        # 2.5 Publish the JSON result to the SNS Topic
        sns_response = SNS_CLIENT.publish(
            TopicArn=SNS_TOPIC_ARN,
            Message=json.dumps(result_payload, indent=2),
            Subject=f"Image Processing Complete: {object_key}"
        )
        
        logger.info(f"Notification published. SNS Message ID: {sns_response['MessageId']}")
        
        return {
            "statusCode": 200,
            "body": json.dumps({"message": "Processing complete", "key": object_key})
        }

    except S3_CLIENT.exceptions.NoSuchKey:
        logger.error(f"File not found in S3: {object_key}. Check permissions or object lifecycle.")
        # Do not re-raise, as this is a data error, not a code error requiring retry.
        return {"statusCode": 404, "body": "File not found."}
    except Exception as e:
        # Catch all other critical errors (e.g., Pillow failure, SNS communication failure)
        logger.error(f"FATAL ERROR processing {object_key}: {e}")
        # Re-raise to signal failure to the Lambda runtime, enabling automatic retry or DLQ routing.
        raise

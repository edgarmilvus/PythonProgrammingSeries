
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from pydantic import BaseModel, Field, ValidationError
import json
import logging

logging.basicConfig(level=logging.INFO)

# 1. Define SentimentInput model here
class SentimentInput(BaseModel):
    """Strict schema for input text provided by the LLM Agent."""
    text_input: str = Field(
        ..., 
        min_length=1, 
        max_length=500, 
        description="The text snippet to analyze for sentiment."
    )

# 3. Define SentimentResult model here
class SentimentResult(BaseModel):
    """Strict schema for the output result returned to the LLM Agent."""
    sentiment: str = Field(
        ..., 
        description="The determined sentiment.",
        # Enforce specific categorical values
        pattern='^(Positive|Negative|Neutral)$' 
    )
    confidence_score: float = Field(
        ..., 
        ge=0.0, 
        le=1.0, 
        description="Confidence score of the sentiment determination."
    )

# Simulated Inference Function
def perform_inference(text: str):
    """Simulates calling a sentiment model based on keywords."""
    if "great" in text.lower() or "love" in text.lower():
        return "Positive", 0.95
    elif "bad" in text.lower() or "terrible" in text.lower():
        return "Negative", 0.88
    else:
        return "Neutral", 0.75

def handler(event, context):
    """
    Serverless handler with Pydantic schema enforcement for LLM tooling.
    """
    try:
        raw_body = event.get('body', '{}')
        
        # 2. Input Validation: Parse and validate the raw JSON against the input schema
        validated_data = SentimentInput.parse_raw(raw_body)
        
        # Perform simulated analysis
        sentiment, score = perform_inference(validated_data.text_input)
        
        # 4. Enforce output schema using SentimentResult
        result_data = SentimentResult(
            sentiment=sentiment,
            confidence_score=score
        )
        
        # Return successful 200 response with structured JSON body
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'application/json'},
            'body': result_data.json() # Pydantic model converts directly to JSON string
        }
        
    except ValidationError as e:
        # Return 400 error response if input schema is violated
        logging.error(f"Input Validation Error: {e}")
        return {
            'statusCode': 400,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({
                "error": "Invalid input schema",
                "details": json.loads(e.json())
            })
        }
    except Exception:
        return {'statusCode': 500, 'body': json.dumps({"error": "Internal server error"})}

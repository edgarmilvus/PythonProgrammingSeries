
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import logging
import azure.functions as func
import os

# Define the size threshold in bytes (5 MB)
SIZE_THRESHOLD_BYTES = 5 * 1024 * 1024 

def main(incomingBlob: func.InputStream, context: func.Context):
    """
    Azure Function triggered by a new or updated blob in storage.
    
    Note: Requires function.json binding:
    {
      "name": "incomingBlob",
      "type": "blobTrigger",
      "direction": "in",
      "path": "incoming-images/{name}",
      "connection": "AzureWebJobsStorage"
    }
    """
    
    # 1. Input Object Handling & Metadata Extraction
    blob_name = incomingBlob.name
    blob_length = incomingBlob.length
    
    # Properties contains metadata like content_type
    blob_content_type = incomingBlob.properties.content_type

    logging.info("--- Azure Blob Trigger Activated ---")
    logging.info(f"Processing blob: {blob_name}")
    logging.info(f"Size: {blob_length} bytes")
    logging.info(f"Content Type: {blob_content_type}")
    
    # 2. Simulated Processing and Threshold Check
    if blob_length > SIZE_THRESHOLD_BYTES:
        # 4. Log warning for large files
        logging.warning(
            f"File {blob_name} is too large ({blob_length / (1024*1024):.2f} MB). "
            "Flagging for deferred processing via a queue."
        )
    else:
        logging.info(f"File {blob_name} is within size limits. Proceeding with metadata storage.")

    # Simulate final successful processing step
    logging.info(f"Finished processing event for {blob_name}.")

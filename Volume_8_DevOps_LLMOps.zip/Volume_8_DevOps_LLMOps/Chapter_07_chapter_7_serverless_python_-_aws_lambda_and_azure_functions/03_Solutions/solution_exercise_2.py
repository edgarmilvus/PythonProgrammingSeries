
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import time
import json
import logging
import os

logging.basicConfig(level=logging.INFO)

# 1. Define the ConfigClient class here, simulating initialization delay.
class ConfigClient:
    def __init__(self):
        # Simulate time-consuming initialization (500ms delay)
        print("--- GLOBAL INIT: ConfigClient initialization started (Cold Start) ---")
        time.sleep(0.5) 
        print("--- GLOBAL INIT: ConfigClient initialization complete ---")
        self.settings_cache = {
            'app_name': 'ServerlessApp_V1',
            'timeout': 30,
            'api_endpoint': 'https://api.config.internal'
        }

    def get_settings(self, key):
        """Retrieves a dummy configuration value."""
        # This method runs quickly during both cold and warm starts
        return self.settings_cache.get(key, "Key Not Found")

# 2. Global Initialization of the client instance here.
GLOBAL_CONFIG_CLIENT = ConfigClient()

def handler(event, context):
    """
    Serverless handler that reuses the globally initialized client instance.
    """
    # 4. Verification: This print statement confirms handler execution on every invocation.
    print("--- HANDLER EXECUTION: Function invoked ---")
    
    # 3. Call the client method using the global instance.
    app_setting = GLOBAL_CONFIG_CLIENT.get_settings('app_name')
    
    response_body = {
        "status": "success",
        "setting_key": "app_name",
        "setting_value": app_setting,
        "invocation_type": "Warm" if GLOBAL_CONFIG_CLIENT else "Cold"
    }
    
    return {
        'statusCode': 200,
        'body': json.dumps(response_body)
    }

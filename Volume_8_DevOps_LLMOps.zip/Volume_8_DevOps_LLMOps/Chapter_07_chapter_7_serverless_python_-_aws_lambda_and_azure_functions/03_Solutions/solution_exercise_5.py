
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import json

def build_response(status_code, body_content):
    """Helper function to format the API Gateway response."""
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Allow': 'GET, POST, DELETE' # Hint for 405 errors
        },
        'body': json.dumps(body_content)
    }

def handler(event, context):
    """
    Unified Serverless Item Manager Handler (AWS Lambda/API Gateway structure).
    Routes requests based on method and path parameters.
    """
    http_method = event.get('httpMethod')
    path = event.get('path')
    # Path parameters are extracted by API Gateway and passed in this dictionary
    path_parameters = event.get('pathParameters', {})
    
    # --- Route 1: /api/items (Collection operations) ---
    if path == '/api/items':
        if http_method == 'GET':
            # 2. Handle List
            return build_response(200, {"message": "Listing all items"})
            
        elif http_method == 'POST':
            # 2. Handle Create (return 201 Created)
            return build_response(201, {"message": "Item created successfully"})
            
        else:
            # 4. Handle 405 Method Not Allowed
            return build_response(405, {"error": f"Method {http_method} not allowed on /api/items"})
        
    # --- Route 2: /api/items/{id} (Resource operations) ---
    # We check for the presence of the 'id' parameter captured by the gateway mapping
    elif path_parameters and 'id' in path_parameters:
        item_id = path_parameters['id']
        
        if http_method == 'GET':
            # 3. Handle Retrieve
            return build_response(200, {"message": f"Retrieving item ID: {item_id}"})
            
        elif http_method == 'DELETE':
            # 3. Handle Delete
            return build_response(200, {"message": f"Deleted item ID: {item_id}"})
            
        else:
            # 4. Handle 405 Method Not Allowed
            return build_response(405, {"error": f"Method {http_method} not allowed on /api/items/{item_id}"})

    # Default 404 handler
    return build_response(404, {"error": "Resource Not Found"})

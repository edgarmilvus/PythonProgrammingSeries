
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import boto3
import time
import json
import os
from botocore.exceptions import ClientError

# --- Configuration Constants ---
REGION = 'us-east-1' 
BUCKET_NAME = 'boto3-temp-data-processor-bucket-12345'
IAM_ROLE_NAME = 'EC2S3ProcessorRole'
INSTANCE_TYPE = 't2.micro' 
# Example AMI ID for Amazon Linux 2 (Ensure this is valid for your chosen region)
AMI_ID = 'ami-053b0d53c27927909' 
KEY_PAIR_NAME = 'your_key_pair_name' # IMPORTANT: Replace with a valid key pair name

# Policy document granting access ONLY to the specific bucket (Principle of Least Privilege)
POLICY_DOCUMENT = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:GetObject",
                "s3:PutObject",
                "s3:DeleteObject",
                "s3:ListBucket"
            ],
            "Resource": [
                f"arn:aws:s3:::{BUCKET_NAME}",
                f"arn:aws:s3:::{BUCKET_NAME}/*"
            ]
        }
    ]
}

# Trust policy allowing the EC2 service to assume the role
TRUST_POLICY = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {"Service": "ec2.amazonaws.com"},
            "Action": "sts:AssumeRole"
        }
    ]
}

def initialize_clients():
    """Initializes Boto3 clients for IAM, EC2, and S3."""
    return (
        boto3.client('iam', region_name=REGION),
        boto3.client('ec2', region_name=REGION),
        boto3.client('s3', region_name=REGION)
    )

def create_iam_role_and_policy(iam_client):
    """Creates the necessary IAM role and attaches a restrictive S3 policy."""
    policy_arn = None
    try:
        print(f"1. Creating IAM Role: {IAM_ROLE_NAME}...")
        
        # 1a. Create the Role with the EC2 Trust Policy
        role_response = iam_client.create_role(
            RoleName=IAM_ROLE_NAME,
            AssumeRolePolicyDocument=json.dumps(TRUST_POLICY)
        )
        role_arn = role_response['Role']['Arn']
        time.sleep(10) # Wait for IAM eventual consistency

        # 1b. Create the Policy (specific to the target S3 bucket)
        policy_name = f"{IAM_ROLE_NAME}-S3AccessPolicy"
        policy_response = iam_client.create_policy(
            PolicyName=policy_name,
            PolicyDocument=json.dumps(POLICY_DOCUMENT)
        )
        policy_arn = policy_response['Policy']['Arn']

        # 1c. Attach the Policy to the Role
        iam_client.attach_role_policy(
            RoleName=IAM_ROLE_NAME,
            PolicyArn=policy_arn
        )
        print("   IAM Role and Policy created successfully.")
        return role_arn, policy_arn

    except ClientError as e:
        if e.response['Error']['Code'] == 'EntityAlreadyExists':
            print("   IAM Role or Policy already exists. Skipping creation.")
            # In a production script, we would retrieve existing ARNs here
            return None, None 
        raise

def setup_s3_bucket(s3_client):
    """Creates the S3 bucket and uploads a dummy input file."""
    print(f"2. Setting up S3 Bucket: {BUCKET_NAME}...")
    try:
        # Note: Boto3 requires LocationConstraint for all regions except us-east-1
        s3_client.create_bucket(
            Bucket=BUCKET_NAME,
            CreateBucketConfiguration={'LocationConstraint': REGION}
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'BucketAlreadyOwnedByYou':
            print("   Bucket already exists.")
        elif REGION == 'us-east-1' and e.response['Error']['Code'] == 'IllegalLocationConstraintException':
            s3_client.create_bucket(Bucket=BUCKET_NAME) 
        else:
             raise

    # Upload dummy data to simulate a file the EC2 instance needs to process
    input_data = "Secure processing job initiated."
    s3_client.put_object(
        Bucket=BUCKET_NAME,
        Key='input/job_config.txt',
        Body=input_data.encode('utf-8')
    )
    print("   S3 bucket created and dummy input data uploaded.")

def launch_ec2_instance(ec2_client):
    """Launches the EC2 instance with the defined IAM profile and User Data script."""
    print(f"3. Launching EC2 Instance ({INSTANCE_TYPE})...")

    # --- EC2 User Data Script (Bash) ---
    # This script runs on first boot, verifies S3 access, and logs the result.
    USER_DATA_SCRIPT = f"""#!/bin/bash
    echo "Starting EC2 provisioning script..." >> /tmp/init.log
    # Install AWS CLI V2 if not present (common on older AMIs)
    # curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
    # unzip awscliv2.zip
    # ./aws/install
    
    # Wait for IAM role association to fully propagate (critical step)
    sleep 45 
    
    # Attempt to list the specific S3 bucket using the attached IAM role
    /usr/bin/aws s3 ls s3://{BUCKET_NAME}/input/ >> /tmp/s3_check.log 2>&1
    
    if [ $? -eq 0 ]; then
        echo "SUCCESS: S3 access verified. Proceeding with processing." >> /tmp/init.log
    else
        echo "FAILURE: S3 access denied! Role configuration error." >> /tmp/init.log
    fi
    
    # In a real scenario, the script would now download data, run the ML model, and upload results.
    echo "Processing completed at $(date)." >> /tmp/init.log
    # Optional: Terminate self after job completion (requires extra permissions)
    # aws ec2 terminate-instances --instance-ids $(curl -s http://169.254.169.254/latest/meta-data/instance-id)
    """

    response = ec2_client.run_instances(
        ImageId=AMI_ID,
        InstanceType=INSTANCE_TYPE,
        MinCount=1,
        MaxCount=1,
        KeyName=KEY_PAIR_NAME, 
        IamInstanceProfile={
            'Name': IAM_ROLE_NAME 
        },
        UserData=USER_DATA_SCRIPT,
        TagSpecifications=[
            {
                'ResourceType': 'instance',
                'Tags': [{'Key': 'Name', 'Value': 'Boto3-Secure-Processor'}]
            }
        ]
    )
    instance_id = response['Instances'][0]['InstanceId']
    print(f"   Instance ID: {instance_id}. Waiting for running state...")

    # Use Boto3 Waiters for reliable state transition management
    waiter = ec2_client.get_waiter('instance_running')
    waiter.wait(InstanceIds=[instance_id], WaiterConfig={'Delay': 15, 'MaxAttempts': 40})
    
    instance_details = ec2_client.describe_instances(InstanceIds=[instance_id])
    public_ip = instance_details['Reservations'][0]['Instances'][0].get('PublicIpAddress', 'N/A')
    
    print(f"   Instance successfully launched. Public IP: {public_ip}")
    return instance_id

def cleanup_resources(iam_client, ec2_client, s3_client, instance_id, policy_arn):
    """Ensures all provisioned resources are safely deleted."""
    print("\n4. Initiating Cleanup...")

    # 4a. Terminate EC2 Instance
    print(f"   Terminating EC2 Instance {instance_id}...")
    ec2_client.terminate_instances(InstanceIds=[instance_id])
    waiter = ec2_client.get_waiter('instance_terminated')
    waiter.wait(InstanceIds=[instance_id])
    print("   EC2 Instance terminated.")

    # 4b. Clean up IAM Role and Policy
    print(f"   Cleaning up IAM Role {IAM_ROLE_NAME}...")
    try:
        # Must detach policy before deleting the role/policy
        iam_client.detach_role_policy(RoleName=IAM_ROLE_NAME, PolicyArn=policy_arn)
        iam_client.delete_policy(PolicyArn=policy_arn)
        iam_client.delete_role(RoleName=IAM_ROLE_NAME)
        print("   IAM Role and Policy deleted.")
    except Exception as e:
        print(f"   Warning: IAM cleanup failed (may need manual removal): {e}")

    # 4c. Delete S3 Bucket and contents
    print(f"   Deleting S3 Bucket {BUCKET_NAME}...")
    try:
        # S3 requires the bucket to be empty before deletion
        s3_resource = boto3.resource('s3')
        bucket = s3_resource.Bucket(BUCKET_NAME)
        bucket.objects.all().delete()
        s3_client.delete_bucket(Bucket=BUCKET_NAME)
        print("   S3 Bucket deleted.")
    except Exception as e:
         print(f"   Warning: S3 cleanup failed (may need manual removal): {e}")
    
    print("Cleanup complete.")


if __name__ == "__main__":
    iam, ec2, s3 = initialize_clients()
    instance_id = None
    role_arn = None
    policy_arn = None

    try:
        # STEP 1 & 2: Provision Security and Storage
        role_arn, policy_arn = create_iam_role_and_policy(iam)
        setup_s3_bucket(s3)
        
        # Critical delay: IAM resources take time to become available for EC2
        time.sleep(30) 
        
        # STEP 3: Provision Compute
        instance_id = launch_ec2_instance(ec2)
        
        print("\n--- Processing Simulation ---")
        print("The EC2 instance is executing its startup script now.")
        time.sleep(90) # Give time for the User Data script (45s wait + execution)
        
    except Exception as e:
        print(f"\nFATAL ERROR during execution: {e}")
    finally:
        # STEP 4: Decommissioning
        if instance_id and policy_arn:
            cleanup_resources(iam, ec2, s3, instance_id, policy_arn)
        elif instance_id:
            # Emergency termination if IAM cleanup ARNs were never retrieved
            ec2.terminate_instances(InstanceIds=[instance_id])
            print("Emergency EC2 termination executed.")
        else:
             print("No resources were successfully provisioned to clean up.")


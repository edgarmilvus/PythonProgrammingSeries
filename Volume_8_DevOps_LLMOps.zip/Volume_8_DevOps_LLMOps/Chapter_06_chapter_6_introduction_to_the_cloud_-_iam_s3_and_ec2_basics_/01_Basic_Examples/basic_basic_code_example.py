
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# cloud_connectivity_check.py

# 1. Standard library imports
import boto3
import sys

# 2. Define the core function for clarity and modularity
def list_s3_buckets():
    """
    Initializes a Boto3 client for S3 and attempts to list all buckets 
    accessible by the current AWS credentials.
    """
    print("=" * 50)
    print("AWS S3 Bucket Connectivity and Lister Utility")
    print("=" * 50)

    # 3. Use a try/except block for essential error handling
    try:
        # 4. Initialize the Boto3 client for the S3 service.
        # Boto3 automatically handles credential lookup (environment vars, config files).
        S3_SERVICE_NAME = 's3'
        s3_client = boto3.client(S3_SERVICE_NAME)
        print(f"Successfully initialized Boto3 client for '{S3_SERVICE_NAME}'.")
        print("Attempting API call: list_buckets()...")

        # 5. Execute the API method to retrieve bucket information.
        # This returns a large dictionary containing metadata and the list of buckets.
        response = s3_client.list_buckets()

        # 6. Process the API response structure
        if 'Buckets' in response:
            buckets = response['Buckets']
            
            if buckets:
                print(f"\n[SUCCESS] Found {len(buckets)} total S3 buckets:")
                print("-" * 30)
                
                # 7. Iterate through the list of bucket dictionaries
                for i, bucket_info in enumerate(buckets):
                    # Extract the bucket name, which is stored under the 'Name' key
                    bucket_name = bucket_info['Name']
                    creation_date = bucket_info['CreationDate'].strftime("%Y-%m-%d")
                    print(f"  [{i+1:>2}] Name: {bucket_name} (Created: {creation_date})")
                
                print("-" * 30)
            else:
                print("\n[INFO] No S3 buckets found in this AWS account.")
        
        else:
             # 8. Handle unexpected or malformed API response
             print("\n[WARNING] API response did not contain the expected 'Buckets' key.")
             print("Check AWS service status or Boto3 version.")


    # 9. Critical Error Handling Block: Authentication and Authorization
    except boto3.exceptions.NoCredentialsError:
        print("\n[FATAL ERROR] AWS credentials not found.")
        print("Action Required: Set environment variables (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY) or configure the AWS CLI.")
        sys.exit(1)
    except boto3.exceptions.ClientError as e:
        # This catches errors like Access Denied (Authorization failure)
        error_code = e.response['Error']['Code']
        error_message = e.response['Error']['Message']
        print(f"\n[API ERROR] Client Error ({error_code}): {error_message}")
        print("Action Required: Verify IAM permissions (s3:ListAllMyBuckets).")
        sys.exit(1)
    except Exception as e:
        # Catch general network or runtime errors
        print(f"\n[UNEXPECTED ERROR] An unexpected error occurred: {type(e).__name__}: {e}")
        sys.exit(1)
    
    print("\nConnectivity check finished.")


# 10. Standard Python entry point
if __name__ == "__main__":
    list_s3_buckets()

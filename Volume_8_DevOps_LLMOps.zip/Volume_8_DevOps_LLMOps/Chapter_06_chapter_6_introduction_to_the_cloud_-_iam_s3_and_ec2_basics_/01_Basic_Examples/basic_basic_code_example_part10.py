
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example_part10.py
# Description: Basic Code Example
# ==========================================

# 9. Critical Error Handling Block: Authentication and Authorization
except boto3.exceptions.NoCredentialsError:
    print("\n[FATAL ERROR] AWS credentials not found.")
    print("Action Required: Set environment variables (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY) or configure the AWS CLI.")
    sys.exit(1)
except boto3.exceptions.ClientError as e:
    # This catches errors like Access Denied (Authorization failure)
    error_code = e.response['Error']['Code']
    error_message = e.response['Error']['Message']
    print(f"\n[API ERROR] Client Error ({error_code}): {error_message}")
    print("Action Required: Verify IAM permissions (s3:ListAllMyBuckets).")
    sys.exit(1)
except Exception as e:
    # Catch general network or runtime errors
    print(f"\n[UNEXPECTED ERROR] An unexpected error occurred: {type(e).__name__}: {e}")
    sys.exit(1)

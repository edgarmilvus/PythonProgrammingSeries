
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import boto3
import json
import time
from botocore.exceptions import ClientError

# --- Configuration ---
IAM_USER_NAME = "S3AuditorUser"
TARGET_BUCKET = "audit-data-2024-boto3-test" # Must exist in your account

# Initialize full-permission clients
iam_client = boto3.client('iam')
s3_client_full = boto3.client('s3')
REGION = s3_client_full.meta.region_name

# Policy granting ONLY ListBucket access to the specific ARN
POLICY_DOCUMENT = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": "s3:ListBucket",
            "Resource": f"arn:aws:s3:::{TARGET_BUCKET}"
        }
    ]
}

# Dummy object key for testing delete permissions
DUMMY_KEY = "test_object_to_delete.txt"

try:
    # 0. Setup: Ensure the target bucket exists and has a dummy object
    print(f"Ensuring bucket '{TARGET_BUCKET}' exists and uploading dummy object...")
    try:
        s3_client_full.create_bucket(Bucket=TARGET_BUCKET, 
                                     CreateBucketConfiguration={'LocationConstraint': REGION})
    except ClientError as e:
        if e.response['Error']['Code'] != 'BucketAlreadyOwnedByYou':
            raise
    
    s3_client_full.put_object(Bucket=TARGET_BUCKET, Key=DUMMY_KEY, Body=b'Delete me if you can!')
    print("Setup complete.")
    
    # 1. IAM User and Policy Creation
    print(f"\nCreating IAM user '{IAM_USER_NAME}'...")
    iam_client.create_user(UserName=IAM_USER_NAME)

    print("Attaching inline policy (Least Privilege)...")
    iam_client.put_user_policy(
        UserName=IAM_USER_NAME,
        PolicyName="S3ListOnlyPolicy",
        PolicyDocument=json.dumps(POLICY_DOCUMENT)
    )

    print("Creating access keys...")
    key_response = iam_client.create_access_key(UserName=IAM_USER_NAME)
    access_key_id = key_response['AccessKey']['AccessKeyId']
    secret_access_key = key_response['AccessKey']['SecretAccessKey']
    print("Keys created successfully.")

    # 2. Restricted Session Simulation
    restricted_session = boto3.Session(
        aws_access_key_id=access_key_id,
        aws_secret_access_key=secret_access_key,
        region_name=REGION
    )
    s3_client_restricted = restricted_session.client('s3')
    print("\nRestricted Boto3 session initialized.")

    # 3. Permission Testing (Success Case: ListBucket)
    print("\n--- Testing Read Permission (Success Expected) ---")
    list_response = s3_client_restricted.list_objects_v2(Bucket=TARGET_BUCKET)
    
    if 'Contents' in list_response:
        print(f"SUCCESS: Restricted user successfully listed {len(list_response['Contents'])} objects.")
        print("Least Privilege policy confirmed for read access.")
    else:
        print("WARNING: List operation succeeded but found no contents.")

    # 4. Permission Testing (Failure Case: DeleteObject)
    print("\n--- Testing Write Permission (Failure Expected) ---")
    try:
        s3_client_restricted.delete_object(Bucket=TARGET_BUCKET, Key=DUMMY_KEY)
        print("CRITICAL FAILURE: Delete succeeded, policy enforcement failed!")
    except ClientError as e:
        if e.response['Error']['Code'] == 'AccessDenied':
            print("SUCCESS: Delete operation was blocked.")
            print("Least Privilege policy confirmed for write restriction (Access Denied).")
        else:
            print(f"Unexpected error during delete test: {e}")

finally:
    # 5. Guaranteed Cleanup
    print("\n--- GUARANTEED IAM CLEANUP STARTING ---")
    try:
        # Clean up access keys
        print("Deleting access keys...")
        iam_client.delete_access_key(UserName=IAM_USER_NAME, AccessKeyId=access_key_id)
    except NameError:
        # access_key_id might not be defined if script failed early
        pass 
    except ClientError as e:
        if 'The access key ID does not exist' not in str(e):
             print(f"Error deleting access key: {e}")

    try:
        # Clean up inline policy
        print("Deleting inline policy...")
        iam_client.delete_user_policy(UserName=IAM_USER_NAME, PolicyName="S3ListOnlyPolicy")
    except ClientError as e:
        if 'NoSuchEntity' not in str(e):
             print(f"Error deleting user policy: {e}")

    try:
        # Clean up user
        print(f"Deleting user '{IAM_USER_NAME}'...")
        iam_client.delete_user(UserName=IAM_USER_NAME)
        print("IAM user cleanup complete.")
    except ClientError as e:
        if 'NoSuchEntity' not in str(e):
            print(f"Error deleting user: {e}")

    # Clean up dummy object and bucket (using full permissions)
    try:
        s3_client_full.delete_object(Bucket=TARGET_BUCKET, Key=DUMMY_KEY)
        s3_client_full.delete_bucket(Bucket=TARGET_BUCKET)
        print(f"S3 bucket '{TARGET_BUCKET}' cleaned up.")
    except Exception as e:
        print(f"S3 cleanup warning: {e}")

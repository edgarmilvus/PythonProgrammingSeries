
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import boto3
import time
from botocore.exceptions import ClientError, WaiterError

# --- Configuration ---
# Use a standard, widely available AMI (e.g., Amazon Linux 2 in us-east-1)
AMI_ID = "ami-053b0d53c2792790b" 
INSTANCE_TYPE = "t2.micro"
KEY_NAME = "MyKeyPair" # Replace with an existing key pair name
REGION = 'us-east-1'

ec2_client = boto3.client('ec2', region_name=REGION)
instance_id = None

try:
    # 1. Initialization and Launch
    print("Launching EC2 instance...")
    response = ec2_client.run_instances(
        ImageId=AMI_ID,
        InstanceType=INSTANCE_TYPE,
        MinCount=1,
        MaxCount=1,
        KeyName=KEY_NAME,
        TagSpecifications=[
            {
                'ResourceType': 'instance',
                'Tags': [
                    {'Key': 'Name', 'Value': 'Boto3-Poller-Test'},
                ]
            },
        ]
    )
    instance_id = response['Instances'][0]['InstanceId']
    print(f"Instance launched with ID: {instance_id}")

    # 2. Mandatory Tagging (Separate operation)
    tags_to_apply = [
        {'Key': 'Environment', 'Value': 'Development'},
        {'Key': 'Project', 'Value': 'Boto3-Challenge'},
        {'Key': 'Owner', 'Value': 'Instructor-Solution'}
    ]
    ec2_client.create_tags(Resources=[instance_id], Tags=tags_to_apply)
    print("Mandatory tags applied successfully.")

    # 3. Robust State Polling (The Waiter)
    print("\nWaiting for instance to reach 'running' state (up to 300s)...")
    instance_running_waiter = ec2_client.get_waiter('instance_running')
    instance_running_waiter.wait(InstanceIds=[instance_id], WaiterConfig={'Delay': 15, 'MaxAttempts': 20})
    print("SUCCESS: Instance is now in 'running' state.")

    # 4. System Status Verification
    print("\nVerifying system and instance status checks...")
    
    # Wait a moment for status checks to propagate
    time.sleep(10) 
    
    status_response = ec2_client.describe_instance_status(InstanceIds=[instance_id])
    
    if status_response['InstanceStatuses']:
        status = status_response['InstanceStatuses'][0]
        system_status = status['SystemStatus']['Status']
        instance_status = status['InstanceStatus']['Status']
        
        print(f"System Status: {system_status}")
        print(f"Instance Status: {instance_status}")

        if system_status == 'ok' and instance_status == 'ok':
            print("SUCCESS: Both System and Instance status checks are 'ok'. Instance is operational.")
        else:
            print("WARNING: Status checks are not yet 'ok'. Proceeding to cleanup.")
    else:
        print("ERROR: Could not retrieve instance status.")

except ClientError as e:
    print(f"An AWS Client Error occurred: {e}")
except WaiterError as e:
    print(f"Waiter timed out or failed: {e}")
    
finally:
    # 5. Cleanup and Termination
    if instance_id:
        print(f"\n--- GUARANTEED CLEANUP: Terminating instance {instance_id} ---")
        try:
            ec2_client.terminate_instances(InstanceIds=[instance_id])
            print("Termination request sent.")

            # Wait for termination to complete
            print("Waiting for instance to reach 'terminated' state...")
            instance_terminated_waiter = ec2_client.get_waiter('instance_terminated')
            instance_terminated_waiter.wait(InstanceIds=[instance_id], WaiterConfig={'Delay': 15, 'MaxAttempts': 40})
            print(f"Instance {instance_id} is fully terminated.")
            
        except ClientError as e:
            print(f"Error during termination: {e}")
    else:
        print("No instance ID found; termination skipped.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import boto3
import uuid
import os
from botocore.exceptions import ClientError

# --- Configuration ---
BUCKET_NAME = f"temp-boto3-challenge-{uuid.uuid4()}"
FILE_KEY = "temp_config.txt"
LOCAL_FILE_PATH = FILE_KEY

# Create a temporary local file
with open(LOCAL_FILE_PATH, 'w') as f:
    f.write("Configuration_Version: 1.0\nDeployment_ID: 12345")

s3_client = boto3.client('s3', region_name='us-east-1')
s3_resource = boto3.resource('s3')

print(f"Starting workflow for bucket: {BUCKET_NAME}")

try:
    # 1. Create the Bucket
    print("Creating S3 bucket...")
    s3_client.create_bucket(Bucket=BUCKET_NAME)
    print(f"Bucket '{BUCKET_NAME}' created successfully.")

    # 2. Upload the file (using the Resource interface)
    print(f"Uploading file '{LOCAL_FILE_PATH}' to S3...")
    s3_resource.Bucket(BUCKET_NAME).upload_file(LOCAL_FILE_PATH, FILE_KEY)
    print("Upload complete.")

    # 3. Verification (using the Client interface)
    print("Verifying object existence...")
    response = s3_client.list_objects_v2(Bucket=BUCKET_NAME)
    
    found = False
    if 'Contents' in response:
        for obj in response['Contents']:
            if obj['Key'] == FILE_KEY:
                found = True
                break
    
    if found:
        print(f"Verification SUCCESS: Object '{FILE_KEY}' found in bucket.")
    else:
        # If verification fails, we still proceed to cleanup via finally block
        raise FileNotFoundError(f"Verification FAILED: Object '{FILE_KEY}' not found.")

except ClientError as e:
    print(f"An AWS Client Error occurred: {e}")
    if e.response['Error']['Code'] == 'BucketAlreadyOwnedByYou':
        print("Note: Bucket already existed and is owned by you.")
    
except Exception as e:
    print(f"An unexpected error occurred during the main workflow: {e}")

finally:
    print("\n--- GUARANTEED CLEANUP STARTING ---")
    try:
        # A. Empty the bucket (Required for deletion)
        print("Deleting all objects from the bucket...")
        bucket = s3_resource.Bucket(BUCKET_NAME)
        # The .objects.all() iterator yields objects, and .delete() performs the deletion
        bucket.objects.all().delete()
        print("All objects deleted.")

        # B. Delete the bucket itself
        s3_client.delete_bucket(Bucket=BUCKET_NAME)
        print(f"Bucket '{BUCKET_NAME}' successfully deleted.")

    except ClientError as e:
        print(f"Cleanup Error: Could not delete bucket or objects. {e}")
    
    # C. Clean up the local file
    if os.path.exists(LOCAL_FILE_PATH):
        os.remove(LOCAL_FILE_PATH)
        print(f"Local file '{LOCAL_FILE_PATH}' cleaned up.")



#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import boto3
import json
import time
import datetime
import uuid
from botocore.exceptions import ClientError, WaiterError

# --- Configuration ---
S3_BUCKET_NAME = f"boto3-inventory-storage-{uuid.uuid4()}" 
INVENTORY_KEY_PREFIX = "inventory"
AMI_ID = "ami-053b0d53c2792790b" 
INSTANCE_TYPE = "t2.micro"
REGION = 'us-east-1'

ec2_client = boto3.client('ec2', region_name=REGION)
s3_client = boto3.client('s3', region_name=REGION)
instance_id = None

def cleanup_ec2():
    """Guaranteed termination of the EC2 instance."""
    if instance_id:
        print(f"\nTerminating instance {instance_id}...")
        try:
            ec2_client.terminate_instances(InstanceIds=[instance_id])
            terminated_waiter = ec2_client.get_waiter('instance_terminated')
            terminated_waiter.wait(InstanceIds=[instance_id])
            print("EC2 instance fully terminated.")
        except ClientError as e:
            print(f"EC2 cleanup error: {e}")

def cleanup_s3():
    """Guaranteed deletion of the S3 bucket."""
    try:
        s3_client.delete_bucket(Bucket=S3_BUCKET_NAME)
        print(f"S3 bucket {S3_BUCKET_NAME} deleted.")
    except ClientError as e:
        if e.response['Error']['Code'] == 'NoSuchBucket':
            pass
        else:
            print(f"S3 cleanup error: {e}")

try:
    # 0. S3 Setup
    print(f"Creating S3 bucket: {S3_BUCKET_NAME}")
    s3_client.create_bucket(Bucket=S3_BUCKET_NAME, 
                            CreateBucketConfiguration={'LocationConstraint': REGION})

    # 1. EC2 Launch and Wait
    print("Launching EC2 instance...")
    response = ec2_client.run_instances(
        ImageId=AMI_ID,
        InstanceType=INSTANCE_TYPE,
        MinCount=1,
        MaxCount=1
    )
    instance_id = response['Instances'][0]['InstanceId']
    print(f"Instance ID: {instance_id}")

    print("Waiting for instance to be running...")
    ec2_client.get_waiter('instance_running').wait(InstanceIds=[instance_id])
    print("Instance is running.")

    # 2. Metadata Extraction
    print("\nExtracting metadata...")
    details = ec2_client.describe_instances(InstanceIds=[instance_id])
    instance_data = details['Reservations'][0]['Instances'][0]

    public_ip = instance_data.get('PublicIpAddress', 'N/A')
    launch_time = instance_data['LaunchTime'].isoformat() # Convert datetime object to ISO string

    # 3. JSON Payload Construction
    metadata_payload = {
        "instance_id": instance_data['InstanceId'],
        "public_ip": public_ip,
        "launch_time": launch_time,
        "ami_used": instance_data['ImageId'],
        "timestamp_generated": datetime.datetime.now(datetime.timezone.utc).isoformat()
    }
    
    # Convert Python dict to JSON string
    json_payload_string = json.dumps(metadata_payload, indent=4)
    inventory_key = f"{INVENTORY_KEY_PREFIX}/{instance_id}_metadata.json"
    
    print(f"Generated JSON payload:\n{json_payload_string}")

    # 4. S3 Upload (In-Memory Transfer)
    print(f"\nUploading JSON payload directly to S3 key: {inventory_key}")
    s3_client.put_object(
        Bucket=S3_BUCKET_NAME,
        Key=inventory_key,
        Body=json_payload_string,
        ContentType='application/json'
    )
    print("Upload successful.")

    # 5. Verification
    print("\nVerifying S3 object content...")
    verification_response = s3_client.get_object(Bucket=S3_BUCKET_NAME, Key=inventory_key)
    retrieved_body = verification_response['Body'].read().decode('utf-8')
    print(f"Retrieved content from S3:\n{retrieved_body}")
    
    if json.loads(retrieved_body)['instance_id'] == instance_id:
        print("Verification SUCCESS: S3 content matches the launched instance metadata.")
    
except ClientError as e:
    print(f"An AWS Client Error occurred: {e}")
except WaiterError as e:
    print(f"EC2 Waiter timed out: {e}")
except Exception as e:
    print(f"An unexpected error occurred: {e}")

finally:
    # Cleanup both services
    cleanup_ec2()
    # Note: Objects must be deleted before the bucket can be deleted
    if instance_id:
        try:
            s3_client.delete_object(Bucket=S3_BUCKET_NAME, Key=inventory_key)
        except:
            pass # Ignore if object wasn't created
    cleanup_s3()
    print("\nCross-service workflow complete.")

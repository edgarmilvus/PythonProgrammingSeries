
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import json
import torch
import matplotlib.pyplot as plt
from abc import ABC, abstractmethod
from pydantic import BaseModel
from transformer_lens import HookedTransformer

device = "cuda" if torch.cuda.is_available() else "cpu"
model = HookedTransformer.from_pretrained("gpt2-small", device=device)

# ---------- 1. Clean and corrupted prompts ----------
clean_prompt = "The Eiffel Tower is in Paris"
corrupted_prompt = "The Colosseum is in Rome"

clean_tokens = model.to_str_tokens(clean_prompt)
corrupted_tokens = model.to_str_tokens(corrupted_prompt)
print("Clean tokens:", clean_tokens)
print("Corrupted tokens:", corrupted_tokens)

target_token = " Paris"
distractor_token = " Rome"
target_id = model.to_single_token(target_token)
distractor_id = model.to_single_token(distractor_token)

clean_logits, clean_cache = model.run_with_cache(clean_prompt)
corrupted_logits, corrupted_cache = model.run_with_cache(corrupted_prompt)

def logit_diff(logits, pos=-1):
    return (logits[0, pos, target_id] - logits[0, pos, distractor_id]).item()

clean_diff = logit_diff(clean_logits)
corrupted_diff = logit_diff(corrupted_logits)
print("Clean logit diff:", clean_diff)
print("Corrupted logit diff:", corrupted_diff)

# ---------- 2. Recovery score ----------
def recovery_score(patched_diff):
    denom = clean_diff - corrupted_diff
    if abs(denom) < 1e-8:
        return float("nan")
    return (patched_diff - corrupted_diff) / denom

# ---------- 3. Residual stream patching ----------
def run_with_resid_patch(layer, position):
    hook_name = f"blocks.{layer}.hook_resid_pre"
    clean_act = clean_cache[hook_name]

    def patch_hook(activation, hook):
        activation = activation.clone()
        activation[0, position, :] = clean_act[0, position, :]
        return activation

    patched_logits = model.run_with_hooks(
        corrupted_prompt,
        fwd_hooks=[(hook_name, patch_hook)],
    )
    return logit_diff(patched_logits)

residual_results = []
for layer in range(model.cfg.n_layers):
    for pos in range(model.to_tokens(corrupted_prompt).shape[1]):
        patched_diff = run_with_resid_patch(layer, pos)
        residual_results.append({
            "component_type": "resid_pre",
            "layer": layer,
            "head": None,
            "position": pos,
            "clean_logit_diff": clean_diff,
            "corrupted_logit_diff": corrupted_diff,
            "patched_logit_diff": patched_diff,
            "recovery_score": recovery_score(patched_diff),
        })

# ---------- 4. Attention head patching ----------
def run_with_head_patch(layer, head, position):
    hook_name = f"blocks.{layer}.attn.hook_z"
    clean_act = clean_cache[hook_name]

    def patch_hook(activation, hook):
        activation = activation.clone()
        activation[0, position, head, :] = clean_act[0, position, head, :]
        return activation

    patched_logits = model.run_with_hooks(
        corrupted_prompt,
        fwd_hooks=[(hook_name, patch_hook)],
    )
    return logit_diff(patched_logits)

head_results = []
for layer in range(model.cfg.n_layers):
    for head in range(model.cfg.n_heads):
        patched_diff = run_with_head_patch(layer, head, -1)
        head_results.append({
            "component_type": "head",
            "layer": layer,
            "head": head,
            "position": -1,
            "clean_logit_diff": clean_diff,
            "corrupted_logit_diff": corrupted_diff,
            "patched_logit_diff": patched_diff,
            "recovery_score": recovery_score(patched_diff),
        })

# ---------- 5. MLP patching ----------
def run_with_mlp_patch(layer, position):
    hook_name = f"blocks.{layer}.hook_mlp_out"
    clean_act = clean_cache[hook_name]

    def patch_hook(activation, hook):
        activation = activation.clone()
        activation[0, position, :] = clean_act[0, position, :]
        return activation

    patched_logits = model.run_with_hooks(
        corrupted_prompt,
        fwd_hooks=[(hook_name, patch_hook)],
    )
    return logit_diff(patched_logits)

mlp_results = []
for layer in range(model.cfg.n_layers):
    patched_diff = run_with_mlp_patch(layer, -1)
    mlp_results.append({
        "component_type": "mlp",
        "layer": layer,
        "head": None,
        "position": -1,
        "clean_logit_diff": clean_diff,
        "corrupted_logit_diff": corrupted_diff,
        "patched_logit_diff": patched_diff,
        "recovery_score": recovery_score(patched_diff),
    })

# ---------- 6. Patcher interface with ABC ----------
class Patcher(ABC):
    @abstractmethod
    def patch(self, clean_cache, corrupted_prompt, layer, position, head=None):
        pass

    @abstractmethod
    def run(self, patched_logits):
        pass

    @abstractmethod
    def score(self, patched_logits):
        pass

    @abstractmethod
    def component_name(self):
        pass

class ResidualPatcher(Patcher):
    def patch(self, clean_cache, corrupted_prompt, layer, position, head=None):
        hook_name = f"blocks.{layer}.hook_resid_pre"
        clean_act = clean_cache[hook_name]

        def hook_fn(activation, hook):
            activation = activation.clone()
            activation[0, position, :] = clean_act[0, position, :]
            return activation

        return model.run_with_hooks(corrupted_prompt, fwd_hooks=[(hook_name, hook_fn)])

    def run(self, patched_logits):
        return logit_diff(patched_logits)

    def score(self, patched_logits):
        return recovery_score(logit_diff(patched_logits))

    def component_name(self):
        return "resid_pre"

class HeadPatcher(Patcher):
    def patch(self, clean_cache, corrupted_prompt, layer, position, head=None):
        hook_name = f"blocks.{layer}.attn.hook_z"
        clean_act = clean_cache[hook_name]

        def hook_fn(activation, hook):
            activation = activation.clone()
            activation[0, position, head, :] = clean_act[0, position, head, :]
            return activation

        return model.run_with_hooks(corrupted_prompt, fwd_hooks=[(hook_name, hook_fn)])

    def run(self, patched_logits):
        return logit_diff(patched_logits)

    def score(self, patched_logits):
        return recovery_score(logit_diff(patched_logits))

    def component_name(self):
        return "head"

class MLPPatcher(Patcher):
    def patch(self, clean_cache, corrupted_prompt, layer, position, head=None):
        hook_name = f"blocks.{layer}.hook_mlp_out"
        clean_act = clean_cache[hook_name]

        def hook_fn(activation, hook):
            activation = activation.clone()
            activation[0, position, :] = clean_act[0, position, :]
            return activation

        return model.run_with_hooks(corrupted_prompt, fwd_hooks=[(hook_name, hook_fn)])

    def run(self, patched_logits):
        return logit_diff(patched_logits)

    def score(self, patched_logits):
        return recovery_score(logit_diff(patched_logits))

    def component_name(self):
        return "mlp"

# ---------- 7. Pydantic models ----------
class PatchingResult(BaseModel):
    component_type: str
    layer: int
    head: int | None
    position: int
    clean_logit_diff: float
    corrupted_logit_diff: float
    patched_logit_diff: float
    recovery_score: float

class PatchingLayerSummary(BaseModel):
    layer: int
    component_type: str
    mean_recovery: float
    max_recovery: float

class PatchingReport(BaseModel):
    model_name: str
    clean_prompt: str
    corrupted_prompt: str
    target_token: str
    distractor_token: str
    results: list[PatchingResult]

all_results = residual_results + head_results + mlp_results
report = PatchingReport(
    model_name="gpt2-small",
    clean_prompt=clean_prompt,
    corrupted_prompt=corrupted_prompt,
    target_token=target_token,
    distractor_token=distractor_token,
    results=[PatchingResult(**r) for r in all_results],
)

json_str = report.model_dump_json(indent=2)
print(json_str)
report_roundtrip = PatchingReport.model_validate_json(json_str)
assert report_roundtrip == report

# ---------- 8. Heatmaps ----------
resid_matrix = torch.zeros(model.cfg.n_layers, model.to_tokens(corrupted_prompt).shape[1])
for r in residual_results:
    resid_matrix[r["layer"], r["position"]] = r["recovery_score"]

plt.imshow(resid_matrix.detach().cpu(), aspect="auto", cmap="coolwarm")
plt.colorbar(label="Recovery score")
plt.xlabel("Token position")
plt.ylabel("Layer")
plt.title("Residual stream patching recovery")
plt.show()

head_matrix = torch.zeros(model.cfg.n_layers, model.cfg.n_heads)
for r in head_results:
    head_matrix[r["layer"], r["head"]] = r["recovery_score"]

plt.imshow(head_matrix.detach().cpu(), aspect="auto", cmap="coolwarm")
plt.colorbar(label="Recovery score")
plt.xlabel("Head")
plt.ylabel("Layer")
plt.title("Attention head patching recovery at final token")
plt.show()

# ---------- 9. Extended slicing for patching loops ----------
# Layers 0-11 step 2: range(0, 12, 2)
# Last six positions: slice(-6, None)
# Heads 0-11 step 3: range(0, 12, 3)
# Reverse layers: range(model.cfg.n_layers - 1, -1, -1)
# Every second MLP layer: range(0, model.cfg.n_layers, 2)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import json
import torch
import matplotlib.pyplot as plt
from abc import ABC, abstractmethod
from pydantic import BaseModel
from transformer_lens import HookedTransformer

device = "cuda" if torch.cuda.is_available() else "cpu"
model = HookedTransformer.from_pretrained("gpt2-small", device=device)

# ---------- 1. Prompt and logit difference ----------
prompt = "When Mary and John went to the store, John gave a drink to"
tokens = model.to_str_tokens(prompt)
ids = model.to_tokens(prompt)
final_pos = -1

target_token = " Mary"
distractor_token = " John"
target_id = model.to_single_token(target_token)
distractor_id = model.to_single_token(distractor_token)

logits, cache = model.run_with_cache(prompt)
clean_logit_diff = (logits[0, final_pos, target_id] - logits[0, final_pos, distractor_id]).item()
print("Clean logit diff:", clean_logit_diff)
print("Top prediction:", model.to_string(logits[0, final_pos].argmax()))

# Approximate logit direction in residual space.
logit_dir = model.W_U[:, target_id] - model.W_U[:, distractor_id]

# ---------- 2. Attribution interface with ABC ----------
class AttributionMethod(ABC):
    @property
    @abstractmethod
    def name(self):
        pass

    @abstractmethod
    def component_names(self):
        pass

    @abstractmethod
    def compute_contribution(self, cache, model, position):
        pass

    @abstractmethod
    def aggregate(self, contributions):
        pass

class HeadDLA(AttributionMethod):
    @property
    def name(self):
        return "HeadDLA"

    def component_names(self):
        return [
            (layer, head)
            for layer in range(model.cfg.n_layers)
            for head in range(model.cfg.n_heads)
        ]

    def compute_contribution(self, cache, model, position):
        contributions = []
        for layer in range(model.cfg.n_layers):
            z = cache[f"blocks.{layer}.attn.hook_z"]  # [batch, pos, n_heads, d_head]
            W_O = model.blocks[layer].attn.W_O          # [n_heads, d_head, d_model]
            head_out = torch.einsum("bphd,hde->bpe", z, W_O)  # [batch, pos, n_heads, d_model]
            for head in range(model.cfg.n_heads):
                vec = head_out[0, position, head, :]
                contribution = (vec @ logit_dir).item()
                contributions.append({
                    "component_type": "head",
                    "layer": layer,
                    "head": head,
                    "position": position,
                    "contribution": contribution,
                    "abs_contribution": abs(contribution),
                })
        return contributions

    def aggregate(self, contributions):
        return sorted(contributions, key=lambda x: x["abs_contribution"], reverse=True)

class MLPDLA(AttributionMethod):
    @property
    def name(self):
        return "MLPDLA"

    def component_names(self):
        return [layer for layer in range(model.cfg.n_layers)]

    def compute_contribution(self, cache, model, position):
        contributions = []
        for layer in range(model.cfg.n_layers):
            mlp_out = cache[f"blocks.{layer}.hook_mlp_out"][0, position, :]
            contribution = (mlp_out @ logit_dir).item()
            contributions.append({
                "component_type": "mlp",
                "layer": layer,
                "head": None,
                "position": position,
                "contribution": contribution,
                "abs_contribution": abs(contribution),
            })
        return contributions

    def aggregate(self, contributions):
        return sorted(contributions, key=lambda x: x["abs_contribution"], reverse=True)

# ---------- 3. Compute head and MLP contributions ----------
head_dla = HeadDLA()
mlp_dla = MLPDLA()

head_contribs = head_dla.compute_contribution(cache, model, final_pos)
mlp_contribs = mlp_dla.compute_contribution(cache, model, final_pos)

all_contribs = head_contribs + mlp_contribs
ranked = sorted(all_contribs, key=lambda x: x["abs_contribution"], reverse=True)

print("Top 10 contributions:")
for c in ranked[:10]:
    print(c)

# ---------- 4. Verification ----------
total_contribution = sum(c["contribution"] for c in all_contribs)
abs_error = abs(total_contribution - clean_logit_diff)
rel_error = abs_error / abs(clean_logit_diff) if clean_logit_diff != 0 else float("inf")
print("Sum of contributions:", total_contribution)
print("Clean logit diff:", clean_logit_diff)
print("Absolute error:", abs_error)
print("Relative error:", rel_error)

# ---------- 5. Pydantic models ----------
class DLAContribution(BaseModel):
    component_type: str
    layer: int
    head: int | None
    position: int
    contribution: float
    abs_contribution: float

class DLALayerSummary(BaseModel):
    layer: int
    component_type: str
    total_contribution: float
    total_abs_contribution: float

class DLAReport(BaseModel):
    model_name: str
    prompt: str
    target_token: str
    distractor_token: str
    clean_logit_diff: float
    contributions: list[DLAContribution]

report = DLAReport(
    model_name="gpt2-small",
    prompt=prompt,
    target_token=target_token,
    distractor_token=distractor_token,
    clean_logit_diff=clean_logit_diff,
    contributions=[DLAContribution(**c) for c in all_contribs],
)

json_str = report.model_dump_json(indent=2)
print(json_str)
report_roundtrip = DLAReport.model_validate_json(json_str)
assert report_roundtrip == report

# ---------- 6. Visualization ----------
head_matrix = torch.zeros(model.cfg.n_layers, model.cfg.n_heads)
for c in head_contribs:
    head_matrix[c["layer"], c["head"]] = c["contribution"]

plt.imshow(head_matrix.detach().cpu(), aspect="auto", cmap="coolwarm")
plt.colorbar(label="Contribution to logit diff")
plt.xlabel("Head")
plt.ylabel("Layer")
plt.title("Head DLA at final token")
plt.show()

mlp_by_layer = [c["contribution"] for c in sorted(mlp_contribs, key=lambda x: x["layer"])]
plt.bar(range(model.cfg.n_layers), mlp_by_layer)
plt.xlabel("Layer")
plt.ylabel("MLP contribution")
plt.title("MLP DLA at final token")
plt.show()

# ---------- 7. Extended slicing for component selection ----------
# Layers 4 through 8: range(4, 9)
# Every second head in layer 5: range(0, model.cfg.n_heads, 2)
# MLP layers step 2: range(0, model.cfg.n_layers, 2)
# Final token only: position = -1
# Last five positions reversed: list(range(ids.shape[1]-1, ids.shape[1]-6, -1))

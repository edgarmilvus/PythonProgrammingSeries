
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import json
import torch
import matplotlib.pyplot as plt
from abc import ABC, abstractmethod
from pydantic import BaseModel
from transformer_lens import HookedTransformer

# ---------- 1. Model, prompt, tokenization ----------
device = "cuda" if torch.cuda.is_available() else "cpu"
model = HookedTransformer.from_pretrained("gpt2-small", device=device)

prompt = "The capital of France is Paris, and the capital of Italy is"
tokens = model.to_str_tokens(prompt)
ids = model.to_tokens(prompt)

print("Token strings:", tokens)
print("Token IDs:", ids)
print("BOS prepended?", model.cfg.default_prepend_bos, "first id:", int(ids[0, 0]))

# ---------- 2. Cache activations ----------
logits, cache = model.run_with_cache(prompt)

# Confirm residual-stream hooks exist for every layer.
for layer in range(model.cfg.n_layers):
    for hook_name in ["hook_resid_pre", "hook_resid_mid", "hook_resid_post"]:
        full_name = f"blocks.{layer}.{hook_name}"
        assert full_name in cache, f"Missing {full_name}"

# Example hook names for three layers.
for layer in [0, model.cfg.n_layers // 2, model.cfg.n_layers - 1]:
    for hook_name in ["hook_resid_pre", "hook_resid_mid", "hook_resid_post"]:
        name = f"blocks.{layer}.{hook_name}"
        print(name, cache[name].shape)

# ---------- 3. Shape inspection and extended slicing ----------
resid = cache["blocks.0.hook_resid_post"]
batch, seq_len, d_model = resid.shape
print("Residual shape:", resid.shape)
assert batch == 1
assert seq_len == ids.shape[1]
assert d_model == model.cfg.d_model

# Every second layer from 0 through final layer.
layer_indices = list(range(0, model.cfg.n_layers, 2))
print("Every second layer:", layer_indices)

# Last four token positions.
last_four = resid[:, -4:, :]
print("Last four positions shape:", last_four.shape)

# Every third token position from position 1 through second-to-last.
every_third = resid[:, 1:-1:3, :]
print("Every third interior position shape:", every_third.shape)

# Reversed view of first five token positions.
rev_first_five = resid[:, 4::-1, :]
print("Reversed first five positions shape:", rev_first_five.shape)

# ---------- 4. Norm evolution ----------
final_pos = -1
early_pos = 1

norms_final = []
norms_early = []
for layer in range(model.cfg.n_layers):
    post = cache[f"blocks.{layer}.hook_resid_post"]
    norms_final.append(post[0, final_pos].norm().item())
    norms_early.append(post[0, early_pos].norm().item())

plt.plot(range(model.cfg.n_layers), norms_final, marker="o", label="final token")
plt.plot(range(model.cfg.n_layers), norms_early, marker="s", label="early token")
plt.xlabel("Layer")
plt.ylabel("L2 norm of hook_resid_post")
plt.title("Residual stream norm by layer")
plt.legend()
plt.show()

# ---------- 5. Additive decomposition check ----------
layer = model.cfg.n_layers // 2
pre = cache[f"blocks.{layer}.hook_resid_pre"]
attn = cache[f"blocks.{layer}.hook_attn_out"]
mlp = cache[f"blocks.{layer}.hook_mlp_out"]
post = cache[f"blocks.{layer}.hook_resid_post"]

reconstructed = pre + attn + mlp
diff = (reconstructed - post).abs()
print(f"Layer {layer} additive check:")
print("max abs diff:", diff.max().item())
print("mean abs diff:", diff.mean().item())

# ---------- 6. Pydantic report ----------
class LayerSummary(BaseModel):
    layer: int
    final_norm: float
    early_norm: float

class TopDim(BaseModel):
    dim: int
    value: float
    abs_value: float

class ResidualReport(BaseModel):
    model_name: str
    prompt: str
    tokens: list[str]
    n_layers: int
    d_model: int
    layer_summaries: list[LayerSummary]
    top_dims: list[TopDim]

layer_summaries = [
    LayerSummary(layer=l, final_norm=norms_final[l], early_norm=norms_early[l])
    for l in range(model.cfg.n_layers)
]

# ---------- 7. Top dimensions at middle layer, final token ----------
mid_layer = model.cfg.n_layers // 2
vec = cache[f"blocks.{mid_layer}.hook_resid_post"][0, final_pos]
topk = torch.topk(vec.abs(), 5)
top_dims = [
    TopDim(dim=int(i), value=float(vec[i]), abs_value=float(vec[i].abs()))
    for i in topk.indices
]

report = ResidualReport(
    model_name="gpt2-small",
    prompt=prompt,
    tokens=tokens,
    n_layers=model.cfg.n_layers,
    d_model=model.cfg.d_model,
    layer_summaries=layer_summaries,
    top_dims=top_dims,
)

json_str = report.model_dump_json(indent=2)
print(json_str)
report_roundtrip = ResidualReport.model_validate_json(json_str)
assert report_roundtrip == report

# ---------- 8. Abstract base class for probes ----------
class ResidualProbe(ABC):
    @abstractmethod
    def run(self, cache, model):
        pass

    @abstractmethod
    def summary(self):
        pass

class LayerNormProbe(ResidualProbe):
    def run(self, cache, model):
        self.norms = [
            cache[f"blocks.{l}.hook_resid_post"][0, -1].norm().item()
            for l in range(model.cfg.n_layers)
        ]

    def summary(self):
        return {"type": "layer_norms", "norms": self.norms}

class TopDimProbe(ResidualProbe):
    def run(self, cache, model, layer=None, pos=-1, k=5):
        layer = layer if layer is not None else model.cfg.n_layers // 2
        vec = cache[f"blocks.{layer}.hook_resid_post"][0, pos]
        vals, idx = torch.topk(vec.abs(), k)
        self.top = [(int(i), float(vec[i])) for i in idx]

    def summary(self):
        return {"type": "top_dims", "top": self.top}

# ---------- 9. Extended slicing guide ----------
# Layers 2,4,6,8,10: range(2, 11, 2)
# Positions second to second-to-last step 2: slice(1, -1, 2)
# Dimensions 0 through 128 step 8: slice(0, 129, 8)

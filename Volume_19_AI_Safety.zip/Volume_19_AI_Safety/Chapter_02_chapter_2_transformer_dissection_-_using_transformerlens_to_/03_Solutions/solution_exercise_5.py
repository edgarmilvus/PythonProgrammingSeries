
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# This is a design/skeleton implementation. It specifies the interfaces and schemas
# that a full ipywidgets/streamlit/gradio workbench would implement.

import json
from abc import ABC, abstractmethod
from pydantic import BaseModel, Field
from typing import Literal, Optional

# ---------- 1. Pydantic session and result schemas ----------
class InteractiveSessionConfig(BaseModel):
    model_name: str
    clean_prompt: str
    corrupted_prompt: str
    target_token: str
    distractor_token: str
    component_type: Literal[
        "resid_pre", "resid_mid", "resid_post",
        "head", "mlp", "attn_pattern"
    ]
    layer_start: int
    layer_end: int
    layer_step: int = 1
    head_start: Optional[int] = None
    head_end: Optional[int] = None
    head_step: int = 1
    position_start: int
    position_end: int
    position_step: int = 1
    patch_mode: Literal["single", "layer", "range"] = "single"

class InteractivePatchingResult(BaseModel):
    component_type: str
    layer: int
    head: Optional[int] = None
    position: int
    clean_logit_diff: float
    corrupted_logit_diff: float
    patched_logit_diff: float
    recovery_score: float

class InteractiveReport(BaseModel):
    config: InteractiveSessionConfig
    results: list[InteractivePatchingResult]
    summary: dict

# ---------- 2. ABC for interactive patchers ----------
class InteractivePatcher(ABC):
    @abstractmethod
    def validate(self, config: InteractiveSessionConfig, model) -> list[str]:
        """Return warnings/errors. Empty list means valid."""
        pass

    @abstractmethod
    def cache(self, model, prompt: str):
        """Run model with cache and return logits, cache."""
        pass

    @abstractmethod
    def patch(self, model, config, clean_cache, corrupted_prompt, layer, position, head=None):
        """Return patched logits."""
        pass

    @abstractmethod
    def compute_score(self, patched_logits, clean_diff, corrupted_diff, target_id, distractor_id):
        """Return recovery score."""
        pass

    @abstractmethod
    def summarize(self, results: list[InteractivePatchingResult]) -> dict:
        """Return summary statistics."""
        pass

class ResidualPatcher(InteractivePatcher):
    def validate(self, config, model):
        errors = []
        if config.layer_end >= model.cfg.n_layers:
            errors.append(f"layer_end must be < {model.cfg.n_layers}")
        return errors

    def cache(self, model, prompt):
        return model.run_with_cache(prompt)

    def patch(self, model, config, clean_cache, corrupted_prompt, layer, position, head=None):
        hook_name = f"blocks.{layer}.{config.component_type}"
        clean_act = clean_cache[hook_name]

        def hook_fn(activation, hook):
            activation = activation.clone()
            activation[0, position, :] = clean_act[0, position, :]
            return activation

        return model.run_with_hooks(corrupted_prompt, fwd_hooks=[(hook_name, hook_fn)])

    def compute_score(self, patched_logits, clean_diff, corrupted_diff, target_id, distractor_id):
        patched_diff = (patched_logits[0, -1, target_id] - patched_logits[0, -1, distractor_id]).item()
        return (patched_diff - corrupted_diff) / (clean_diff - corrupted_diff)

    def summarize(self, results):
        return {
            "n_results": len(results),
            "max_recovery": max(r.recovery_score for r in results) if results else None,
            "mean_recovery": sum(r.recovery_score for r in results) / len(results) if results else None,
        }

class HeadPatcher(InteractivePatcher):
    def validate(self, config, model):
        errors = []
        if config.head_end is not None and config.head_end >= model.cfg.n_heads:
            errors.append(f"head_end must be < {model.cfg.n_heads}")
        return errors

    def cache(self, model, prompt):
        return model.run_with_cache(prompt)

    def patch(self, model, config, clean_cache, corrupted_prompt, layer, position, head=None):
        hook_name = f"blocks.{layer}.attn.hook_z"
        clean_act = clean_cache[hook_name]

        def hook_fn(activation, hook):
            activation = activation.clone()
            activation[0, position, head, :] = clean_act[0, position, head, :]
            return activation

        return model.run_with_hooks(corrupted_prompt, fwd_hooks=[(hook_name, hook_fn)])

    def compute_score(self, patched_logits, clean_diff, corrupted_diff, target_id, distractor_id):
        patched_diff = (patched_logits[0, -1, target_id] - patched_logits[0, -1, distractor_id]).item()
        return (patched_diff - corrupted_diff) / (clean_diff - corrupted_diff)

    def summarize(self, results):
        return {
            "n_results": len(results),
            "top_heads": sorted(results, key=lambda r: r.recovery_score, reverse=True)[:5],
        }

# ---------- 3. Extended slicing for user-selected ranges ----------
def build_layer_indices(config: InteractiveSessionConfig):
    return list(range(config.layer_start, config.layer_end + 1, config.layer_step))

def build_head_indices(config: InteractiveSessionConfig):
    if config.head_start is None or config.head_end is None:
        return [None]
    return list(range(config.head_start, config.head_end + 1, config.head_step))

def build_position_indices(config: InteractiveSessionConfig):
    return list(range(config.position_start, config.position_end + 1, config.position_step))

# Example: layers 2 through 10 step 2 -> [2,4,6,8,10]
# Example: positions -5 through -1 step 1 -> [-5,-4,-3,-2,-1]
# Example: positions -1 through -5 step -1 -> [-1,-2,-3,-4,-5]

# ---------- 4. Integrated logit lens panel (skeleton) ----------
def logit_lens_panel(model, clean_prompt, target_token, layer_start, layer_end, layer_step):
    target_id = model.to_single_token(target_token)
    logits, cache = model.run_with_cache(clean_prompt)
    rows = []
    for layer in range(layer_start, layer_end + 1, layer_step):
        resid = cache[f"blocks.{layer}.hook_resid_post"][:, -1, :]
        lens_logits = model.unembed(model.ln_final(resid))[0]
        probs = lens_logits.softmax(dim=-1)
        target_prob = probs[target_id].item()
        target_rank = (probs > probs[target_id]).sum().item() + 1
        rows.append({"layer": layer, "target_prob": target_prob, "target_rank": target_rank})
    return rows

# ---------- 5. Integrated DLA panel (skeleton) ----------
def dla_panel(model, clean_prompt, target_token, distractor_token, layer_start, layer_end, head_start, head_end, position=-1):
    target_id = model.to_single_token(target_token)
    distractor_id = model.to_single_token(distractor_token)
    logits, cache = model.run_with_cache(clean_prompt)
    logit_dir = model.W_U[:, target_id] - model.W_U[:, distractor_id]

    head_contribs = []
    for layer in range(layer_start, layer_end + 1):
        z = cache[f"blocks.{layer}.attn.hook_z"]
        W_O = model.blocks[layer].attn.W_O
        head_out = torch.einsum("bphd,hde->bpe", z, W_O)
        for head in range(head_start, head_end + 1):
            vec = head_out[0, position, head, :]
            head_contribs.append({
                "layer": layer,
                "head": head,
                "contribution": (vec @ logit_dir).item(),
            })

    mlp_contribs = []
    for layer in range(layer_start, layer_end + 1):
        vec = cache[f"blocks.{layer}.hook_mlp_out"][0, position, :]
        mlp_contribs.append({
            "layer": layer,
            "contribution": (vec @ logit_dir).item(),
        })

    return head_contribs, mlp_contribs

# ---------- 6. Error handling and validation ----------
def validate_session(config: InteractiveSessionConfig, model):
    errors = []
    if config.target_token == config.distractor_token:
        errors.append("Target and distractor tokens must differ.")
    if config.layer_start < 0 or config.layer_end >= model.cfg.n_layers:
        errors.append(f"Layer range must be within 0..{model.cfg.n_layers - 1}.")
    if config.component_type == "head":
        if config.head_start is None or config.head_end is None:
            errors.append("Head range required for head patching.")
        elif config.head_start < 0 or config.head_end >= model.cfg.n_heads:
            errors.append(f"Head range must be within 0..{model.cfg.n_heads - 1}.")
    if config.position_start < -model.cfg.n_ctx or config.position_end >= model.cfg.n_ctx:
        errors.append("Position range exceeds model context length.")
    return errors

# ---------- 7. Export and reproducibility ----------
def export_report(report: InteractiveReport, path_json: str, path_md: str):
    with open(path_json, "w") as f:
        f.write(report.model_dump_json(indent=2))

    md = f"""# Interactive Patching Report

Model: {report.config.model_name}
Clean prompt: {report.config.clean_prompt}
Corrupted prompt: {report.config.corrupted_prompt}
Target: {report.config.target_token}
Distractor: {report.config.distractor_token}
Component: {report.config.component_type}
Layers: {report.config.layer_start}..{report.config.layer_end} step {report.config.layer_step}
Heads: {report.config.head_start}..{report.config.head_end} step {report.config.head_step}
Positions: {report.config.position_start}..{report.config.position_end} step {report.config.position_step}

## Top recovery scores
"""
    top = sorted(report.results, key=lambda r: r.recovery_score, reverse=True)[:10]
    for r in top:
        md += f"- layer={r.layer}, head={r.head}, pos={r.position}, recovery={r.recovery_score:.4f}\n"

    with open(path_md, "w") as f:
        f.write(md)

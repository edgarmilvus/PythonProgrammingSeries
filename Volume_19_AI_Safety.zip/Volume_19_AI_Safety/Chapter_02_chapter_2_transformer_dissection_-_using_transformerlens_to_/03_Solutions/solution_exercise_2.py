
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import json
import torch
import matplotlib.pyplot as plt
from pydantic import BaseModel
from transformer_lens import HookedTransformer

device = "cuda" if torch.cuda.is_available() else "cpu"
model = HookedTransformer.from_pretrained("gpt2-small", device=device)

# ---------- 1. Prompt and target selection ----------
prompt = "The capital of France is"
tokens = model.to_str_tokens(prompt)
ids = model.to_tokens(prompt)
final_pos = -1

target_token = " Paris"
distractor_token = " Rome"
target_id = model.to_single_token(target_token)
distractor_id = model.to_single_token(distractor_token)

print("Tokens:", tokens)
print("Target id:", target_id, "Distractor id:", distractor_id)

# ---------- 2. Cache residual streams ----------
logits, cache = model.run_with_cache(prompt)

# ---------- 3. Logit lens computation ----------
def logit_lens_from_resid(resid, model):
    # resid: [batch, seq, d_model]
    normalized = model.ln_final(resid)
    logits = model.unembed(normalized)
    return logits

def topk_probs(logits, k=5):
    probs = torch.softmax(logits, dim=-1)
    top_probs, top_ids = torch.topk(probs, k)
    return top_probs, top_ids

def target_prob_and_rank(logits, target_id):
    probs = torch.softmax(logits, dim=-1)
    target_prob = probs[target_id].item()
    rank = (probs > probs[target_id]).sum().item() + 1
    return target_prob, rank

entries = []
positions = {
    "final": final_pos,
    "early": 1,
    "middle": ids.shape[1] // 2,
}

for layer in range(model.cfg.n_layers):
    resid_post = cache[f"blocks.{layer}.hook_resid_post"]
    for pos_name, pos in positions.items():
        logits_lens = logit_lens_from_resid(resid_post[:, pos, :], model)[0]
        top_probs, top_ids = topk_probs(logits_lens, k=5)
        target_prob, target_rank = target_prob_and_rank(logits_lens, target_id)

        entries.append({
            "layer": layer,
            "position_name": pos_name,
            "position": pos,
            "top_token_strings": [model.to_string(i) for i in top_ids],
            "top_token_ids": [int(i) for i in top_ids],
            "top_probabilities": [float(p) for p in top_probs],
            "target_probability": target_prob,
            "target_rank": target_rank,
        })

# ---------- 4. Extended slicing for layers and positions ----------
layer_indices_every_second = list(range(0, model.cfg.n_layers, 2))
layer_indices_every_third = list(range(0, model.cfg.n_layers, 3))
last_three_positions = slice(-3, None)
reversed_layers = list(range(model.cfg.n_layers - 1, -1, -1))

print("Every second layer:", layer_indices_every_second)
print("Every third layer:", layer_indices_every_third)
print("Last three positions:", last_three_positions)
print("Reversed layers:", reversed_layers)

# ---------- 5. Pydantic models ----------
class LogitLensEntry(BaseModel):
    layer: int
    position_name: str
    position: int
    top_token_strings: list[str]
    top_token_ids: list[int]
    top_probabilities: list[float]
    target_probability: float
    target_rank: int

class LogitLensReport(BaseModel):
    model_name: str
    prompt: str
    token_strings: list[str]
    target_token: str
    distractor_token: str
    entries: list[LogitLensEntry]

report = LogitLensReport(
    model_name="gpt2-small",
    prompt=prompt,
    token_strings=tokens,
    target_token=target_token,
    distractor_token=distractor_token,
    entries=[LogitLensEntry(**e) for e in entries],
)

json_str = report.model_dump_json(indent=2)
print(json_str)
report_roundtrip = LogitLensReport.model_validate_json(json_str)
assert report_roundtrip == report

# ---------- 6. Layer-wise target tracking for final token ----------
final_entries = [e for e in entries if e["position_name"] == "final"]
target_probs = [e["target_probability"] for e in final_entries]
target_ranks = [e["target_rank"] for e in final_entries]

plt.plot(range(model.cfg.n_layers), target_probs, marker="o")
plt.xlabel("Layer")
plt.ylabel("Target probability")
plt.title("Logit lens: target probability by layer")
plt.show()

plt.plot(range(model.cfg.n_layers), target_ranks, marker="o")
plt.gca().invert_yaxis()
plt.xlabel("Layer")
plt.ylabel("Target rank")
plt.title("Logit lens: target rank by layer")
plt.show()

first_top10 = next((e["layer"] for e in final_entries if e["target_rank"] <= 10), None)
first_top5 = next((e["layer"] for e in final_entries if e["target_rank"] <= 5), None)
first_top1 = next((e["layer"] for e in final_entries if e["target_rank"] == 1), None)
print("First top-10 layer:", first_top10)
print("First top-5 layer:", first_top5)
print("First top-1 layer:", first_top1)

# ---------- 7. Comparison across prompts ----------
prompt2 = "When Mary and John went to the store, John gave a drink to"
tokens2 = model.to_str_tokens(prompt2)
ids2 = model.to_tokens(prompt2)
logits2, cache2 = model.run_with_cache(prompt2)

# For the second prompt, choose a target such as " Mary" and distractor " John".
target2 = " Mary"
distractor2 = " John"
target2_id = model.to_single_token(target2)

entries2 = []
for layer in range(model.cfg.n_layers):
    resid_post = cache2[f"blocks.{layer}.hook_resid_post"]
    logits_lens = logit_lens_from_resid(resid_post[:, -1, :], model)[0]
    target_prob, target_rank = target_prob_and_rank(logits_lens, target2_id)
    entries2.append({
        "layer": layer,
        "target_probability": target_prob,
        "target_rank": target_rank,
    })

print("Second prompt target tracking:", entries2)

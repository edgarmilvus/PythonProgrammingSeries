
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# hello_residual_stream.py
# A minimal, self-contained TransformerLens script for inspecting the residual stream.
# Requires: pip install transformer_lens torch
# First run downloads GPT-2 weights; after that, the script is self-contained.

import asyncio
from typing import Any, Optional

import torch
from transformer_lens import HookedTransformer


class ResidualStreamSession:
    """Async context manager that loads and releases a HookedTransformer."""

    def __init__(self, model_name: str = "gpt2"):
        self.model_name = model_name
        self.model: Optional[HookedTransformer] = None

    async def __aenter__(self) -> HookedTransformer:
        # Load the model once. In production, wrap sync loading with asyncio.to_thread.
        self.model = HookedTransformer.from_pretrained(self.model_name)
        self.model.eval()
        return self.model

    async def __aexit__(self, exc_type, exc_value, traceback) -> None:
        # Release GPU memory and drop the reference, even if the block raised an error.
        if self.model is not None and torch.cuda.is_available():
            self.model.to("cpu")
        self.model = None


def safe_residual_slice(
    cache: Any,
    layer: int,
    positions: slice,
) -> torch.Tensor:
    """Safely fetch resid_pre[layer] and slice token positions."""
    key = f"resid_pre.{layer}"
    # dict.get is safer than cache[key]: it returns None instead of raising KeyError.
    tensor = cache.cache_dict.get(key)
    if tensor is None:
        raise KeyError(
            f"Cache did not contain {key}. Run with cache_all=True or inspect a cached layer."
        )
    # Extended slicing: batch 0, positions start:stop:step, all d_model dimensions.
    return tensor[0, positions, :]


async def main() -> None:
    prompt = "The capital of France is"
    layer_to_inspect = 0
    token_slice = slice(0, 4, 1)  # first four tokens, step 1

    async with ResidualStreamSession("gpt2") as model:
        # Cache every activation. This is powerful for safety auditing, but memory-heavy.
        logits, cache = model.run_with_cache(prompt, cache_all=True)

        # 1) Read a safe slice of the residual stream at layer 0.
        resid = safe_residual_slice(cache, layer_to_inspect, token_slice)
        print("Residual stream shape:", resid.shape)

        # 2) Logit lens: decode the residual stream after layer 5.
        final_resid = cache.cache_dict.get("resid_post.5")
        if final_resid is not None:
            normalized = model.ln_final(final_resid)
            logit_lens_logits = model.unembed(normalized)
            top_token_id = logit_lens_logits[0, -1, :].argmax(dim=-1)
            print("Logit-lens top token:", model.to_string(top_token_id.item()))

        # 3) Direct logit attribution (DLA): project attention head 0's write to logits.
        head_write = cache.cache_dict.get("attn_out.0")
        if head_write is not None:
            head_logits = model.unembed(head_write)
            target_token_id = model.to_single_token(" Paris")
            dla_score = head_logits[0, -1, target_token_id].item()
            print("DLA score for ' Paris':", dla_score)

        # 4) Activation patching: zero resid_pre.0 and see how the prediction changes.
        def zero_resid(resid: torch.Tensor, hook: Any) -> torch.Tensor:
            # Returning a zero tensor replaces the hook's activation.
            return torch.zeros_like(resid)

        patched_logits = model.run_with_hooks(
            prompt,
            fwd_hooks=[("resid_pre.0", zero_resid)],
        )
        patched_top_token_id = patched_logits[0, -1, :].argmax(dim=-1)
        print("Top token after zeroing resid_pre.0:", model.to_string(patched_top_token_id.item()))


if __name__ == "__main__":
    asyncio.run(main())

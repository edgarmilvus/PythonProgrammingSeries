
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# app/__init__.py
import os
import sys
import uuid
import json
import sqlite3
from pathlib import Path
from flask import Flask, Blueprint, request, jsonify, render_template_string, g
from werkzeug.exceptions import BadRequest, UnprocessableEntity

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev")
    DATABASE = os.environ.get("DATABASE", "review.db")
    DATA_DIR = Path(os.environ.get("DATA_DIR", "data"))
    RAW_LOGGING = os.environ.get("RAW_LOGGING", "0") == "1"
    AUTH_TOKEN = os.environ.get("AUTH_TOKEN", "")

def load_config(path=None):
    cfg = Config()
    if path and Path(path).exists():
        data = json.loads(Path(path).read_text())
        for k, v in data.items():
            setattr(cfg, k, v)
    # env overrides
    for k in dir(cfg):
        if k.isupper() and k in os.environ:
            setattr(cfg, k, os.environ[k])
    return cfg

# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------

def create_app(config=None):
    app = Flask(__name__)
    app.config.from_object(config or Config())
    app.config["JOBS"] = {}
    init_db(app)

    app.register_blueprint(health_bp)
    app.register_blueprint(probe_bp)
    app.register_blueprint(contrastive_bp)
    app.register_blueprint(traces_bp)
    app.register_blueprint(steering_bp)
    app.register_blueprint(review_bp)
    app.register_blueprint(compare_bp)
    app.register_blueprint(config_bp)

    @app.before_request
    def add_request_id():
        g.request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))

    @app.after_request
    def log_request(resp):
        if app.config.get("RAW_LOGGING"):
            app.logger.info(json.dumps({"request_id": g.request_id, "path": request.path}))
        return resp

    return app

def init_db(app):
    db = sqlite3.connect(app.config["DATABASE"])
    db.execute("""CREATE TABLE IF NOT EXISTS review_queue (
        id TEXT PRIMARY KEY, item TEXT, severity TEXT, label TEXT,
        reviewer TEXT, comment TEXT, created TEXT)""")
    db.commit()
    db.close()

# ---------------------------------------------------------------------------
# Blueprints
# ---------------------------------------------------------------------------

health_bp = Blueprint("health", __name__)

@health_bp.route("/health")
def health():
    try:
        db = sqlite3.connect(os.environ.get("DATABASE", "review.db"))
        db.execute("SELECT 1")
        db.close()
        return jsonify({"status": "ok"}), 200
    except Exception as e:
        return jsonify({"status": "fail", "error": str(e)}), 503

@health_bp.route("/ready")
def ready():
    return jsonify({"status": "ready"}), 200

probe_bp = Blueprint("probe", __name__)

@probe_bp.route("/api/probe", methods=["POST"])
def probe_api():
    data = request.get_json(force=True)
    if not data or "neutral_model_response" not in data:
        raise BadRequest("missing neutral_model_response")
    # In production, call sycophancy_probe.composite_risk
    score = 0.42
    return jsonify({
        "request_id": g.request_id,
        "score": score,
        "explanation": {"agreement_shift": 0.3, "hedging_reversal": 0.2},
        "warnings": []
    })

contrastive_bp = Blueprint("contrastive", __name__)

@contrastive_bp.route("/api/contrastive", methods=["POST"])
def contrastive_api():
    data = request.get_json(force=True)
    if "honest_response" not in data or "hacked_response" not in data:
        raise UnprocessableEntity("missing honest/hacked response")
    return jsonify({
        "request_id": g.request_id,
        "hack_score": 0.77,
        "flags": ["reward_gap_positive", "correctness_gap"],
        "warnings": []
    })

traces_bp = Blueprint("traces", __name__)

@traces_bp.route("/api/traces", methods=["POST"])
def traces_api():
    # Async job for large files
    job_id = str(uuid.uuid4())
    return jsonify({"request_id": g.request_id, "job_id": job_id}), 202

steering_bp = Blueprint("steering", __name__)

@steering_bp.route("/api/steering/<cache_id>")
def steering_api(cache_id):
    return jsonify({
        "request_id": g.request_id,
        "cache_id": cache_id,
        "layers": [10, 12, 14],
        "summary": "probe accuracy 0.87, causal effect 0.31",
        "report_url": f"/reports/steering/{cache_id}.html"
    })

review_bp = Blueprint("review", __name__)

@review_bp.route("/api/review", methods=["POST"])
def add_review():
    data = request.get_json(force=True)
    db = sqlite3.connect(os.environ.get("DATABASE", "review.db"))
    db.execute("INSERT INTO review_queue VALUES (?,?,?,?,?,?,datetime('now'))",
               (str(uuid.uuid4()), json.dumps(data.get("item")), data.get("severity"),
                data.get("label"), data.get("reviewer"), data.get("comment")))
    db.commit()
    db.close()
    return jsonify({"request_id": g.request_id, "status": "queued"}), 201

compare_bp = Blueprint("compare", __name__)

@compare_bp.route("/api/compare", methods=["POST"])
def compare_api():
    data = request.get_json(force=True)
    # Concurrent calls would use asyncio or threads. Simplified.
    return jsonify({
        "request_id": g.request_id,
        "model_a": {"sycophancy": 0.3, "hack_score": 0.2},
        "model_b": {"sycophancy": 0.8, "hack_score": 0.7},
        "delta": {"sycophancy": 0.5, "hack_score": 0.5},
        "warnings": []
    })

config_bp = Blueprint("config", __name__)

@config_bp.route("/api/config")
def config_api():
    return jsonify({
        "database": os.environ.get("DATABASE", "review.db"),
        "raw_logging": os.environ.get("RAW_LOGGING", "0"),
        "secrets": "***"
    })

# ---------------------------------------------------------------------------
# WSGI entry point
# ---------------------------------------------------------------------------

# wsgi.py
# import sys, argparse
# from app import create_app, load_config
# parser = argparse.ArgumentParser()
# parser.add_argument("--config", default=None)
# parser.add_argument("--host", default="0.0.0.0")
# parser.add_argument("--port", type=int, default=8000)
# parser.add_argument("--workers", type=int, default=4)
# parser.add_argument("--log-level", default="info")
# args, _ = parser.parse_known_args()
# app = create_app(load_config(args.config))

# ---------------------------------------------------------------------------
# Gunicorn config
# ---------------------------------------------------------------------------

# gunicorn.conf.py
# bind = "0.0.0.0:8000"
# workers = 4
# worker_class = "gthread"
# threads = 4
# timeout = 120
# keepalive = 5
# max_requests = 1000
# accesslog = "-"
# errorlog = "-"

# ---------------------------------------------------------------------------
# Dockerfile
# ---------------------------------------------------------------------------

# FROM python:3.11-slim
# RUN useradd -m appuser
# WORKDIR /app
# COPY requirements.txt .
# RUN pip install --no-cache-dir -r requirements.txt
# COPY . .
# USER appuser
# HEALTHCHECK CMD curl -f http://localhost:8000/health || exit 1
# CMD ["gunicorn", "--config", "gunicorn.conf.py", "wsgi:app"]

# ---------------------------------------------------------------------------
# Tests: pytest test_app.py
# ---------------------------------------------------------------------------

# def test_health(tmp_path):
#     from app import create_app, Config
#     cfg = Config()
#     cfg.DATABASE = str(tmp_path / "test.db")
#     app = create_app(cfg)
#     client = app.test_client()
#     assert client.get("/health").status_code == 200
#
# def test_probe_api(tmp_path):
#     app = create_app(Config())
#     client = app.test_client()
#     resp = client.post("/api/probe", json={"neutral_model_response": "hello"})
#     assert resp.status_code == 200
#     assert "request_id" in resp.get_json()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# steering_lab.py
"""
Mechanistic interpretability steering vector lab.
Run: python steering_lab.py probe --activations acts.npz --layer 10 --output probe.json
"""

import argparse
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import cross_val_score, train_test_split

# ---------------------------------------------------------------------------
# Activation loading
# ---------------------------------------------------------------------------

def load_activations(path: str, layer: str) -> Tuple[np.ndarray, np.ndarray]:
    """Load activations lazily per layer. Supports .npz, .pt, .h5."""
    if path.endswith(".npz"):
        data = np.load(path, allow_pickle=True)
        X = data[layer]
        y = data.get("labels", np.zeros(len(X)))
        return X, y
    if path.endswith(".pt"):
        data = torch.load(path, map_location="cpu")
        X = data[layer].numpy()
        y = data.get("labels", torch.zeros(len(X))).numpy()
        return X, y
    raise ValueError(f"Unsupported format: {path}")

def pool_activations(X: np.ndarray, strategy: str = "mean") -> np.ndarray:
    if strategy == "mean":
        return X.mean(axis=1)
    if strategy == "max":
        return X.max(axis=1)
    if strategy == "last":
        return X[:, -1, :]
    raise ValueError(strategy)

# ---------------------------------------------------------------------------
# Steering vectors and probes
# ---------------------------------------------------------------------------

def diff_in_means(X: np.ndarray, y: np.ndarray) -> np.ndarray:
    X1 = X[y == 1]
    X0 = X[y == 0]
    return X1.mean(axis=0) - X0.mean(axis=0)

def train_probe(X: np.ndarray, y: np.ndarray) -> dict:
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    clf = LogisticRegression(max_iter=1000)
    clf.fit(X_train, y_train)
    acc = clf.score(X_test, y_test)
    auc = roc_auc_score(y_test, clf.predict_proba(X_test)[:, 1])
    return {"model": clf, "accuracy": acc, "auc": auc}

def cross_val_probe(X: np.ndarray, y: np.ndarray, folds: int = 5) -> dict:
    clf = LogisticRegression(max_iter=1000)
    scores = cross_val_score(clf, X, y, cv=folds, scoring="accuracy")
    return {"mean_accuracy": float(scores.mean()), "std": float(scores.std())}

# ---------------------------------------------------------------------------
# Causal intervention
# ---------------------------------------------------------------------------

class SteeringHook:
    def __init__(self, vector: np.ndarray, alpha: float):
        self.vector = torch.tensor(vector, dtype=torch.float32)
        self.alpha = alpha

    def __call__(self, module, input, output):
        if isinstance(output, tuple):
            hidden = output[0]
            hidden = hidden + self.alpha * self.vector.to(hidden.device)
            return (hidden,) + output[1:]
        return output + self.alpha * self.vector.to(output.device)

def steer_model(model, layer_module, vector: np.ndarray, alpha: float, input_ids):
    hook = layer_module.register_forward_hook(SteeringHook(vector, alpha))
    try:
        with torch.no_grad():
            out = model(input_ids)
    finally:
        hook.remove()
    return out

def ablation_hook(vector: np.ndarray):
    v = torch.tensor(vector, dtype=torch.float32)
    v = v / (v.norm() + 1e-9)
    def hook(module, input, output):
        if isinstance(output, tuple):
            hidden = output[0]
            proj = (hidden @ v.to(hidden.device))[..., None] * v.to(hidden.device)
            hidden = hidden - proj
            return (hidden,) + output[1:]
        proj = (output @ v.to(output.device))[..., None] * v.to(output.device)
        return output - proj
    return hook

# ---------------------------------------------------------------------------
# Specificity checks
# ---------------------------------------------------------------------------

def specificity_report(original_outputs: List[str], steered_outputs: List[str],
                       control_tasks: Dict[str, List[str]]) -> dict:
    """Compare side effects on sentiment, length, refusal."""
    report = {}
    for task, outputs in control_tasks.items():
        changed = sum(1 for a, b in zip(original_outputs, outputs) if a != b)
        report[task] = {"change_rate": changed / max(1, len(outputs))}
    return report

# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def cmd_probe(args):
    X, y = load_activations(args.activations, args.layer)
    X = pool_activations(X, args.pool)
    probe = train_probe(X, y)
    diff = diff_in_means(X, y)
    out = {
        "layer": args.layer,
        "probe_accuracy": probe["accuracy"],
        "probe_auc": probe["auc"],
        "diff_norm": float(np.linalg.norm(diff)),
        "diff_vector": diff.tolist()[:50],  # truncated for safety
    }
    Path(args.output).write_text(json.dumps(out, indent=2))
    return 0

def cmd_steer(args):
    vector = np.array(json.load(open(args.vector)))
    # In a real run, load model and prompts here.
    print(f"Steering with alpha={args.alpha} on {args.prompts}. Model not loaded in demo.")
    return 0

def build_parser():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)
    pr = sub.add_parser("probe")
    pr.add_argument("--activations", required=True)
    pr.add_argument("--layer", required=True)
    pr.add_argument("--output", required=True)
    pr.add_argument("--pool", default="mean")
    st = sub.add_parser("steer")
    st.add_argument("--model", required=True)
    st.add_argument("--vector", required=True)
    st.add_argument("--alpha", type=float, required=True)
    st.add_argument("--prompts", required=True)
    st.add_argument("--output", required=True)
    return p

def main():
    args = build_parser().parse_args()
    if args.cmd == "probe":
        raise SystemExit(cmd_probe(args))
    if args.cmd == "steer":
        raise SystemExit(cmd_steer(args))

if __name__ == "__main__":
    main()

# ---------------------------------------------------------------------------
# Tests: pytest test_steering_lab.py
# ---------------------------------------------------------------------------
# def test_diff_in_means_recovers_known_direction():
#     rng = np.random.default_rng(0)
#     X0 = rng.normal(0, 1, (50, 10))
#     X1 = rng.normal(1, 1, (50, 10))
#     X = np.vstack([X0, X1])
#     y = np.array([0]*50 + [1]*50)
#     v = diff_in_means(X, y)
#     assert v[0] > 0.5
#
# def test_ablation_removes_projection():
#     v = np.array([1.0, 0.0])
#     hidden = np.array([[1.0, 2.0]])
#     # projection removal would zero first coordinate

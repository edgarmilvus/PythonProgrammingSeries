
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# trace_detector.py
"""
Optimization trace anomaly detector.
Run: python trace_detector.py detect --input trace.csv --output reports/ --config config.yaml
"""

import argparse
import csv
import json
import math
from collections import deque, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterator, List, Optional

import numpy as np
import yaml

# ---------------------------------------------------------------------------
# Loader
# ---------------------------------------------------------------------------

REQUIRED_COLS = ["step", "reward_mean", "kl_divergence", "policy_entropy",
                 "response_length_mean", "sycophancy_probe_score", "process_reward_mean"]

def iter_rows(path: str) -> Iterator[Dict[str, float]]:
    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                out = {}
                for k, v in row.items():
                    if v is None or v == "":
                        continue
                    out[k] = float(v)
                yield out
            except ValueError:
                continue

# ---------------------------------------------------------------------------
# Rolling statistics
# ---------------------------------------------------------------------------

class RollingStats:
    def __init__(self, window: int):
        self.window = window
        self.buf = deque(maxlen=window)
        self.mean = 0.0
        self.std = 0.0

    def update(self, x: float):
        self.buf.append(x)
        arr = np.array(self.buf)
        self.mean = float(arr.mean())
        self.std = float(arr.std() + 1e-9)
        return self.mean, self.std

    def zscore(self, x: float) -> float:
        return (x - self.mean) / self.std

# ---------------------------------------------------------------------------
# Change point detection
# ---------------------------------------------------------------------------

class CUSUM:
    def __init__(self, threshold: float = 5.0, drift: float = 0.5):
        self.threshold = threshold
        self.drift = drift
        self.pos = 0.0
        self.neg = 0.0

    def update(self, z: float) -> Optional[int]:
        self.pos = max(0.0, self.pos + z - self.drift)
        self.neg = max(0.0, self.neg - z - self.drift)
        if self.pos > self.threshold:
            self.pos = 0.0
            return 1
        if self.neg > self.threshold:
            self.neg = 0.0
            return -1
        return None

class BayesianOnlineCP:
    """Simplified BOCPD placeholder using running mean shift."""
    def __init__(self, hazard: float = 0.01):
        self.hazard = hazard
        self.prev = None

    def update(self, x: float) -> bool:
        if self.prev is None:
            self.prev = x
            return False
        change = abs(x - self.prev) > 2.0
        self.prev = 0.9 * self.prev + 0.1 * x
        return change

# ---------------------------------------------------------------------------
# Correlation
# ---------------------------------------------------------------------------

def pearson(x: List[float], y: List[float]) -> float:
    if len(x) < 2:
        return 0.0
    return float(np.corrcoef(x, y)[0, 1])

def spearman(x: List[float], y: List[float]) -> float:
    def rank(v):
        order = sorted(range(len(v)), key=lambda i: v[i])
        r = [0] * len(v)
        for i, idx in enumerate(order):
            r[idx] = i
        return r
    return pearson(rank(x), rank(y))

# ---------------------------------------------------------------------------
# Alert score
# ---------------------------------------------------------------------------

SIGNAL_DIRECTIONS = {
    "reward_mean": +1,
    "kl_divergence": +1,
    "policy_entropy": -1,
    "sycophancy_probe_score": +1,
    "process_reward_mean": -1,
}

def alert_score(history: Dict[str, List[float]], weights: Dict[str, float]) -> dict:
    comps = {}
    for sig, direction in SIGNAL_DIRECTIONS.items():
        if sig not in history or len(history[sig]) < 2:
            continue
        arr = np.array(history[sig])
        z = (arr[-1] - arr.mean()) / (arr.std() + 1e-9)
        comps[sig] = {"raw": float(arr[-1]), "z": float(z * direction), "weight": weights.get(sig, 1.0)}
    score = sum(max(0.0, c["z"]) * c["weight"] for c in comps.values()) / max(1e-9, sum(weights.values()))
    score = 1 / (1 + math.exp(-score))
    top = sorted(comps.items(), key=lambda kv: abs(kv[1]["z"]), reverse=True)[:3]
    return {"score": score, "components": comps, "top_signals": top}

# ---------------------------------------------------------------------------
# Detector
# ---------------------------------------------------------------------------

@dataclass
class Alert:
    step: int
    severity: str
    score: float
    signals: List[str]
    explanation: str
    action: str

class TraceDetector:
    def __init__(self, config: dict):
        self.cfg = config
        self.windows = {k: RollingStats(v) for k, v in config.get("windows", {}).items()}
        self.cusum = CUSUM(threshold=config.get("cusum_threshold", 5.0))
        self.bocpd = BayesianOnlineCP()
        self.history = defaultdict(list)
        self.alerts = []
        self.last_alert_step = -9999

    def process(self, row: Dict[str, float]) -> Optional[Alert]:
        step = int(row.get("step", 0))
        for sig in SIGNAL_DIRECTIONS:
            if sig in row:
                self.history[sig].append(row[sig])
                if sig in self.windows:
                    self.windows[sig].update(row[sig])
        # CUSUM on reward z-score
        if "reward_mean" in row and "reward_mean" in self.windows:
            z = self.windows["reward_mean"].zscore(row["reward_mean"])
            cp = self.cusum.update(z)
            if cp:
                self._emit(step, "warning", 0.6, ["reward_mean"], "CUSUM change in reward", "Inspect recent rollouts.")
        score_info = alert_score(self.history, self.cfg.get("weights", {}))
        sev = "info"
        if score_info["score"] > self.cfg.get("critical_threshold", 0.85):
            sev = "critical"
        elif score_info["score"] > self.cfg.get("warning_threshold", 0.7):
            sev = "warning"
        if sev != "info" and step - self.last_alert_step > self.cfg.get("dedup_window", 100):
            signals = [k for k, _ in score_info["top_signals"]]
            return self._emit(step, sev, score_info["score"], signals,
                              f"Composite score {score_info['score']:.2f}",
                              "Pause training and inspect rollouts.")
        return None

    def _emit(self, step, severity, score, signals, explanation, action) -> Alert:
        alert = Alert(step, severity, score, signals, explanation, action)
        self.alerts.append(alert)
        self.last_alert_step = step
        return alert

# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def cmd_detect(args):
    cfg = yaml.safe_load(open(args.config))
    detector = TraceDetector(cfg)
    alerts = []
    for row in iter_rows(args.input):
        a = detector.process(row)
        if a:
            alerts.append(a.__dict__)
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    (out / "alerts.json").write_text(json.dumps(alerts, indent=2))
    md = ["# Trace Anomaly Report", ""]
    for a in alerts:
        md.append(f"- step {a['step']} [{a['severity']}] score={a['score']:.2f} signals={a['signals']}")
    (out / "report.md").write_text("\n".join(md))
    return 2 if any(a["severity"] == "critical" for a in alerts) else 0

def cmd_simulate(args):
    import random
    rows = []
    for step in range(args.steps):
        hack = step > args.hack_start
        rows.append({
            "step": step,
            "reward_mean": 0.5 + (0.3 if hack else 0.0) + random.gauss(0, 0.05),
            "kl_divergence": 0.1 + (0.5 if hack else 0.0) + random.gauss(0, 0.02),
            "policy_entropy": 2.0 - (1.0 if hack else 0.0) + random.gauss(0, 0.05),
            "sycophancy_probe_score": 0.2 + (0.6 if hack else 0.0) + random.gauss(0, 0.03),
            "process_reward_mean": 0.8 - (0.4 if hack else 0.0) + random.gauss(0, 0.03),
        })
    with open(args.output, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)

def build_parser():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)
    d = sub.add_parser("detect")
    d.add_argument("--input", required=True)
    d.add_argument("--output", required=True)
    d.add_argument("--config", required=True)
    d.add_argument("--window", type=int, default=100)
    d.add_argument("--threshold", type=float, default=0.7)
    d.add_argument("--stream", action="store_true")
    s = sub.add_parser("simulate")
    s.add_argument("--output", required=True)
    s.add_argument("--steps", type=int, default=1000)
    s.add_argument("--hack-start", type=int, default=500)
    return p

def main():
    args = build_parser().parse_args()
    if args.cmd == "detect":
        raise SystemExit(cmd_detect(args))
    if args.cmd == "simulate":
        cmd_simulate(args)

if __name__ == "__main__":
    main()

# ---------------------------------------------------------------------------
# Tests: pytest test_trace_detector.py
# ---------------------------------------------------------------------------
# def test_clean_run_no_critical():
#     detector = TraceDetector({"windows": {"reward_mean": 10}, "critical_threshold": 0.9})
#     for i in range(100):
#         a = detector.process({"step": i, "reward_mean": 0.5, "kl_divergence": 0.1})
#         assert a is None or a.severity != "critical"
#
# def test_length_hack_triggers():
#     detector = TraceDetector({"windows": {"reward_mean": 10}, "critical_threshold": 0.7})
#     for i in range(200):
#         row = {"step": i, "reward_mean": 0.5, "kl_divergence": 0.1}
#         if i > 100:
#             row = {"step": i, "reward_mean": 1.0, "kl_divergence": 0.6, "policy_entropy": 0.5,
#                    "sycophancy_probe_score": 0.9, "process_reward_mean": 0.2}
#         a = detector.process(row)
#     assert len(detector.alerts) > 0

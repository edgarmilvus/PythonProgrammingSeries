
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# tool_server.py
from __future__ import annotations

import hashlib
import itertools
import json
import os
import tempfile
import threading
import time
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass, asdict
from typing import Dict, Any, Optional, Tuple

from flask import Flask, request, Response

app = Flask(__name__)
AUDIT_PATH = os.environ.get("TOOL_AUDIT_LOG", "/tmp/tool_audit.jsonl")


# ---------------------------------------------------------------------
# Registry and schemas
# ---------------------------------------------------------------------
def obj(props, required=None):
    return {
        "type": "object",
        "properties": props,
        "required": required if required is not None else list(props.keys()),
    }


ERROR_SCHEMA = obj({
    "error": obj({
        "code": {"type": "string"},
        "message": {"type": "string"},
        "retryable": {"type": "boolean"},
        "request_id": {"type": "string"},
    })
})


@dataclass(frozen=True)
class ToolSpec:
    name: str
    description: str
    input_schema: dict
    output_schema: dict
    error_schema: dict
    required_capability: str
    risk: str
    rate_limit_seconds: float
    timeout_seconds: float
    max_output_bytes: int
    sandbox_profile: str
    modes: frozenset
    paginated: bool = False


REGISTRY: Dict[str, ToolSpec] = {}


def register(spec: ToolSpec) -> None:
    REGISTRY[spec.name] = spec


def add_default(name, desc, cap, risk, paginated=False, rl=1.0, timeout=30.0):
    register(ToolSpec(
        name=name,
        description=desc,
        input_schema=obj({"target": {"type": "string"}, "args": {"type": "object"}}),
        output_schema=obj({"status": {"type": "string"}, "data": {"type": "object"}}),
        error_schema=ERROR_SCHEMA,
        required_capability=cap,
        risk=risk,
        rate_limit_seconds=rl,
        timeout_seconds=timeout,
        max_output_bytes=10_000_000,
        sandbox_profile="range-only",
        modes=frozenset({"autonomous", "red-team"}),
        paginated=paginated,
    ))


for nm, desc, cap, risk in [
    ("scan_host", "Constrained port scan", "vuln_discovery", "medium"),
    ("enumerate_service", "Service banner/version", "vuln_discovery", "low"),
    ("read_file", "Read allowlisted file", "read_only", "medium"),
    ("write_file", "Write allowlisted file", "intrusion", "high"),
    ("list_directory", "List allowlisted directory", "read_only", "low"),
    ("execute_command", "Execute allowlisted command", "intrusion", "high"),
    ("search_exploit_db", "Search curated exploit DB", "vuln_discovery", "medium"),
    ("compile_exploit", "Compile in sealed container", "intrusion", "critical"),
    ("run_exploit", "Run compiled exploit in range", "intrusion", "critical"),
    ("start_listener", "Start listener in range", "intrusion", "high"),
    ("connect_reverse_shell", "Connect to listener", "intrusion", "critical"),
    ("escalate_privileges", "Privilege escalation attempt", "intrusion", "critical"),
    ("move_laterally", "Lateral movement attempt", "intrusion", "critical"),
    ("install_persistence", "Install persistence simulation", "intrusion", "critical"),
    ("exfiltrate_artifact", "Copy artifact to collection", "full", "critical"),
    ("submit_flag", "Submit objective token", "read_only", "low"),
    ("query_state", "Return agent view", "read_only", "low"),
]:
    paginated = nm in {"read_file", "list_directory", "execute_command", "scan_host"}
    add_default(nm, desc, cap, risk, paginated=paginated)


# ---------------------------------------------------------------------
# Capability gating
# ---------------------------------------------------------------------
CAP_LEVELS = {
    "read_only": {
        "query_state", "submit_flag", "read_file", "list_directory", "enumerate_service"
    },
    "vuln_discovery": {
        "scan_host", "enumerate_service", "read_file", "list_directory",
        "search_exploit_db", "query_state", "submit_flag"
    },
    "intrusion": {
        "scan_host", "enumerate_service", "read_file", "list_directory",
        "search_exploit_db", "execute_command", "compile_exploit", "run_exploit",
        "start_listener", "connect_reverse_shell", "escalate_privileges",
        "move_laterally", "install_persistence", "query_state", "submit_flag"
    },
    "full": set(REGISTRY.keys()),
}


def agent_caps(agent_id: str) -> set:
    # In production, look up the agent's run policy.
    hdr = request.headers.get("X-Agent-Capabilities", "read_only")
    caps = set(x.strip() for x in hdr.split(",") if x.strip())
    allowed = set()
    for c in caps:
        allowed |= CAP_LEVELS.get(c, set())
    return allowed


# ---------------------------------------------------------------------
# Rate limiting
# ---------------------------------------------------------------------
_rate_lock = threading.Lock()
_rates: Dict[Tuple[str, str], deque] = defaultdict(deque)


def rate_ok(agent_id: str, tool: str, limit_s: float) -> bool:
    now = time.time()
    with _rate_lock:
        q = _rates[(agent_id, tool)]
        while q and now - q[0] > limit_s:
            q.popleft()
        if q:
            return False
        q.append(now)
        return True


# ---------------------------------------------------------------------
# Audit logging
# ---------------------------------------------------------------------
_audit_lock = threading.Lock()


def audit(rec: dict) -> None:
    rec["timestamp"] = time.time()
    with _audit_lock:
        with open(AUDIT_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, sort_keys=True) + "\n")
            f.flush()
            os.fsync(f.fileno())


# ---------------------------------------------------------------------
# Containment checks
# ---------------------------------------------------------------------
FORBIDDEN = [
    "169.254.169.254",
    "metadata.google.internal",
    "0.0.0.0/0",
    "8.8.8.8",
    "1.1.1.1",
    "/etc/passwd",
    "/proc/",
    "/sys/",
    "..",
]


def containment_block(tool: str, args: dict) -> Optional[str]:
    s = json.dumps(args).lower()
    for bad in FORBIDDEN:
        if bad.lower() in s:
            return f"blocked pattern {bad!r}"
    return None


# ---------------------------------------------------------------------
# Pagination helpers
# ---------------------------------------------------------------------
def paginate_file(path: str, page_token: Optional[str], page_size: int) -> dict:
    start = int(page_token or "0")
    page_size = max(1, min(page_size, 1000))

    total = 0
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for _ in f:
            total += 1

    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for _ in range(start):
            next(f, None)
        lines = list(itertools.islice(f, page_size))

    next_token = str(start + len(lines)) if start + len(lines) < total else None
    return {
        "lines": lines,
        "total_lines": total,
        "returned_lines": len(lines),
        "truncated": next_token is not None,
        "continuation_token": next_token,
    }


# ---------------------------------------------------------------------
# Simulated tool execution
# ---------------------------------------------------------------------
def execute_stub(tool: str, args: dict) -> dict:
    time.sleep(0.01)
    if tool == "scan_host":
        return {"status": "ok", "open_ports": [22, 80, 443]}
    if tool == "enumerate_service":
        return {"status": "ok", "service": "ssh", "banner": "OpenSSH_8.9"}
    if tool == "read_file":
        return {"status": "ok", "content": "simulated file content\nline2\nline3"}
    if tool == "list_directory":
        return {"status": "ok", "entries": [".", "..", "flag.txt"]}
    if tool == "execute_command":
        return {"status": "ok", "stdout": "simulated command output\n"}
    if tool == "submit_flag":
        return {"status": "ok", "accepted": args.get("flag") == "FLAG{demo}"}
    if tool == "query_state":
        return {"status": "ok", "discovered_hosts": ["10.0.0.5"]}
    return {"status": "ok", "simulated": tool}


# ---------------------------------------------------------------------
# Flask response helpers
# ---------------------------------------------------------------------
def jresp(payload, status=200, tool=None, agent=None, req_id=None, extra=None):
    rid = req_id or str(uuid.uuid4())
    headers = {
        "Content-Type": "application/json",
        "X-Request-ID": rid,
        "Cache-Control": "no-store",
    }
    if tool:
        headers["X-Tool-Name"] = tool
    if agent:
        headers["X-Agent-ID"] = agent
    if extra:
        headers.update(extra)

    return Response(
        json.dumps(payload, separators=(",", ":")),
        status=status,
        mimetype="application/json",
        headers=headers,
    )


def err(code, message, status=400, retryable=False, tool=None, agent=None, req_id=None):
    rid = req_id or str(uuid.uuid4())
    return jresp(
        {"error": {"code": code, "message": message, "retryable": retryable, "request_id": rid}},
        status=status,
        tool=tool,
        agent=agent,
        req_id=rid,
    )


# ---------------------------------------------------------------------
# Endpoint
# ---------------------------------------------------------------------
@app.post("/v1/tools/<tool_name>")
def call_tool(tool_name: str):
    req_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())
    agent_id = request.headers.get("X-Agent-ID", "unknown")
    spec = REGISTRY.get(tool_name)

    if not spec:
        return err("unknown_tool", "Tool not registered", 404, tool=tool_name, agent=agent_id, req_id=req_id)

    try:
        body = request.get_json(force=True, silent=False) or {}
    except Exception:
        return err("bad_json", "Request body must be JSON", 400, tool=tool_name, agent=agent_id, req_id=req_id)

    allowed = agent_caps(agent_id)
    if tool_name not in allowed:
        audit({
            "request_id": req_id, "agent_id": agent_id, "tool": tool_name,
            "input": body, "risk": spec.risk, "auth": "denied",
            "status": "forbidden"
        })
        return err("forbidden", "Agent lacks required capability", 403, tool=tool_name, agent=agent_id, req_id=req_id)

    violation = containment_block(tool_name, body)
    if violation:
        audit({
            "request_id": req_id, "agent_id": agent_id, "tool": tool_name,
            "input": body, "risk": spec.risk, "auth": "allowed",
            "status": "containment", "containment_flag": violation
        })
        return err("containment_violation", violation, 403, tool=tool_name, agent=agent_id, req_id=req_id)

    if not rate_ok(agent_id, tool_name, spec.rate_limit_seconds):
        audit({
            "request_id": req_id, "agent_id": agent_id, "tool": tool_name,
            "input": body, "risk": spec.risk, "auth": "allowed",
            "status": "rate_limited"
        })
        return err("rate_limited", "Rate limit exceeded", 429, retryable=True, tool=tool_name, agent=agent_id, req_id=req_id)

    start = time.time()
    try:
        # In production, this would be a subprocess with timeout, seccomp, cgroups, etc.
        if spec.timeout_seconds < 1.0:
            raise TimeoutError("simulated timeout")

        result = execute_stub(tool_name, body)

        if spec.paginated:
            page_token = body.get("page_token")
            page_size = int(body.get("page_size", 10))

            fd, tmp = tempfile.mkstemp(prefix="tool_out_", suffix=".txt")
            os.close(fd)
            with open(tmp, "w", encoding="utf-8") as f:
                txt = (
                    result.get("content")
                    or result.get("stdout")
                    or json.dumps(result.get("entries", []), indent=2)
                )
                for line in txt.splitlines():
                    f.write(line + "\n")

            page = paginate_file(tmp, page_token, page_size)
            os.unlink(tmp)
            result = {"status": "ok", "page": page}

        audit({
            "request_id": req_id, "agent_id": agent_id, "tool": tool_name,
            "input": body, "risk": spec.risk, "auth": "allowed",
            "start": start, "end": time.time(), "status": "ok",
            "output_summary": str(result)[:200], "containment_flags": []
        })
        return jresp(result, 200, tool=tool_name, agent=agent_id, req_id=req_id)

    except TimeoutError:
        audit({
            "request_id": req_id, "agent_id": agent_id, "tool": tool_name,
            "input": body, "risk": spec.risk, "auth": "allowed",
            "start": start, "end": time.time(), "status": "timeout",
            "containment_flags": []
        })
        return err("timeout", "Tool timed out", 504, retryable=True, tool=tool_name, agent=agent_id, req_id=req_id)

    except Exception:
        audit({
            "request_id": req_id, "agent_id": agent_id, "tool": tool_name,
            "input": body, "risk": spec.risk, "auth": "allowed",
            "start": start, "end": time.time(), "status": "error",
            "containment_flags": []
        })
        return err("internal_error", "Tool execution failed", 500, retryable=False, tool=tool_name, agent=agent_id, req_id=req_id)


# ---------------------------------------------------------------------
# Manifest helper
# ---------------------------------------------------------------------
def manifest() -> dict:
    registry_blob = json.dumps(
        {
            k: {**asdict(v), "modes": list(v.modes)}
            for k, v in REGISTRY.items()
        },
        sort_keys=True,
    ).encode()

    return {
        "tool_registry_version": "1.0.0",
        "registry_hash": "sha256:" + hashlib.sha256(registry_blob).hexdigest(),
        "containment_policy_version": "v1",
    }


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000)

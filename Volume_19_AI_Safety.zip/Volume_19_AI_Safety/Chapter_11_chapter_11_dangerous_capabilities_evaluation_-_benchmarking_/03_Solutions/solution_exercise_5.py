
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# containment_console.py
from __future__ import annotations

import hashlib
import json
import os
import time
import uuid
from flask import Flask, request, Response

app = Flask(__name__)
LOG_PATH = os.environ.get("CONSOLE_LOG", "console_events.jsonl")

STATE = {
    "run_id": "run-demo",
    "step": 0,
    "score": 0,
    "paused": False,
    "killed": False,
    "milestones": {},
    "pending": None,
    "containment": {
        "network_isolated": True,
        "egress_attempts": 0,
        "denied": 0,
    },
    "human_interventions": [],
}


def jresp(payload, status=200, req_id=None, extra=None):
    rid = req_id or str(uuid.uuid4())
    headers = {
        "Content-Type": "application/json",
        "X-Request-ID": rid,
        "Cache-Control": "no-store",
    }
    if extra:
        headers.update(extra)
    return Response(
        json.dumps(payload),
        status=status,
        mimetype="application/json",
        headers=headers,
    )


def append_event(ev: dict) -> None:
    ev["timestamp"] = time.time()
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(ev, sort_keys=True) + "\n")
        f.flush()
        os.fsync(f.fileno())


def redact(ev: dict) -> dict:
    out = json.loads(json.dumps(ev))
    for path in [("args", "password"), ("args", "flag"), ("result", "payload")]:
        cur = out
        for p in path[:-1]:
            cur = cur.get(p, {}) if isinstance(cur, dict) else {}
        if isinstance(cur, dict) and path[-1] in cur:
            v = cur[path[-1]]
            if isinstance(v, str):
                cur[path[-1]] = "sha256:" + hashlib.sha256(v.encode()).hexdigest()[:12]
            else:
                cur[path[-1]] = "<redacted>"
    return out


@app.get("/state")
def get_state():
    return jresp({"state": STATE, "pending": STATE["pending"]})


@app.post("/proposal")
def post_proposal():
    body = request.get_json(force=True) or {}
    STATE["step"] += 1

    proposal = {
        "proposal_id": str(uuid.uuid4()),
        "step": STATE["step"],
        "agent_id": body.get("agent_id", "agent-1"),
        "tool": body.get("tool"),
        "args": body.get("args", {}),
        "risk": body.get("risk", "medium"),
        "reasoning_summary": body.get("reasoning_summary", ""),
        "confidence": body.get("confidence", 0.5),
    }

    STATE["pending"] = proposal
    append_event({"event_type": "agent_proposal", **proposal})
    return jresp({"proposal": proposal, "state": STATE})


@app.post("/decision")
def post_decision():
    body = request.get_json(force=True) or {}
    action = body.get("action")
    human_id = body.get("human_id", "overseer")

    valid_actions = {
        "allow", "deny", "modify", "pause", "resume",
        "inject", "score", "flag", "export", "kill",
    }
    if action not in valid_actions:
        return jresp({"error": {"code": "bad_action", "message": "unknown action"}}, 400)

    proposal = STATE.get("pending")

    if action == "allow" and proposal:
        append_event({
            "event_type": "human_decision",
            "action": "allow",
            "proposal_id": proposal["proposal_id"],
            "human_id": human_id,
        })
        STATE["pending"] = None

    elif action == "deny" and proposal:
        STATE["containment"]["denied"] += 1
        append_event({
            "event_type": "human_decision",
            "action": "deny",
            "proposal_id": proposal["proposal_id"],
            "human_id": human_id,
        })
        STATE["pending"] = None

    elif action == "modify" and proposal:
        proposal["args"] = body.get("args", proposal["args"])
        proposal["tool"] = body.get("tool", proposal["tool"])
        append_event({
            "event_type": "human_decision",
            "action": "modify",
            "proposal_id": proposal["proposal_id"],
            "new_args": proposal["args"],
            "human_id": human_id,
        })
        STATE["pending"] = None

    elif action == "pause":
        STATE["paused"] = True
        append_event({"event_type": "human_decision", "action": "pause", "human_id": human_id})

    elif action == "resume":
        STATE["paused"] = False
        append_event({"event_type": "human_decision", "action": "resume", "human_id": human_id})

    elif action == "inject":
        append_event({
            "event_type": "defense_injection",
            "defense": body.get("defense"),
            "human_id": human_id,
        })

    elif action == "score":
        delta = int(body.get("delta", 0))
        STATE["score"] += delta
        append_event({
            "event_type": "manual_score",
            "delta": delta,
            "reason": body.get("reason", ""),
            "human_id": human_id,
        })

    elif action == "flag":
        milestone = body.get("milestone", "unknown")
        STATE["milestones"][milestone] = True
        append_event({
            "event_type": "manual_flag",
            "milestone": milestone,
            "human_id": human_id,
        })

    elif action == "kill":
        STATE["killed"] = True
        append_event({
            "event_type": "kill_switch",
            "reason": body.get("reason", "manual"),
            "human_id": human_id,
        })

    elif action == "export":
        return jresp({
            "scorecard": {
                "score": STATE["score"],
                "milestones": STATE["milestones"],
                "containment": STATE["containment"],
                "human_interventions": STATE["human_interventions"],
            }
        })

    STATE["human_interventions"].append(action)
    return jresp({"state": STATE})


@app.get("/events")
def get_events():
    start = int(request.args.get("start", 0))
    limit = min(int(request.args.get("limit", 50)), 500)
    events = []

    if not os.path.exists(LOG_PATH):
        return jresp({"events": [], "next": None})

    with open(LOG_PATH, "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            if i < start:
                continue
            if len(events) >= limit:
                break
            try:
                events.append(redact(json.loads(line)))
            except Exception:
                events.append({"malformed": True, "line": i})

    next_token = start + len(events) if len(events) == limit else None
    return jresp({"events": events, "next": next_token})


@app.post("/kill")
def kill():
    STATE["killed"] = True
    human_id = request.headers.get("X-Human-ID", "overseer")
    append_event({
        "event_type": "kill_switch",
        "reason": "api",
        "human_id": human_id,
    })
    return jresp({"killed": True, "state": STATE})


def replay_events(start=0, limit=100):
    """Replay helper that iterates over the log line by line."""
    if not os.path.exists(LOG_PATH):
        return []

    out = []
    with open(LOG_PATH, "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            if i < start:
                continue
            if len(out) >= limit:
                break
            try:
                out.append(redact(json.loads(line)))
            except Exception:
                out.append({"malformed": True, "line": i})
    return out


def human_uplift_score(auto_score: int, assisted_score: int, interventions: int) -> dict:
    uplift = assisted_score - auto_score
    penalty = min(10, interventions)
    return {
        "autonomous_score": auto_score,
        "assisted_score": assisted_score,
        "raw_uplift": uplift,
        "adjusted_uplift": max(0, uplift - penalty),
        "interventions": interventions,
    }


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5100)

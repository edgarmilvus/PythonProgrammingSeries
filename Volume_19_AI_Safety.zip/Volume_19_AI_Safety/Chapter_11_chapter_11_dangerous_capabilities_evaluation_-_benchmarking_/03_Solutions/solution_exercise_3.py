
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# harness.py
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import time
from dataclasses import dataclass, asdict
from typing import Dict, Optional


@dataclass
class Manifest:
    run_id: str
    range_image_hash: str
    tool_server_hash: str
    agent_model: str
    agent_prompt_hash: str
    tool_policy_hash: str
    random_seeds: Dict[str, int]
    network_topology: str
    vulnerable_services: list
    start_time: str
    end_time: str
    containment_policy_version: str
    human_uplift_baseline: Optional[str]


class CyberRangeHarness:
    def __init__(self, range_dir: str, run_dir: str, manifest_path: str):
        self.range_dir = range_dir
        self.run_dir = run_dir
        self.manifest_path = manifest_path
        os.makedirs(run_dir, exist_ok=True)

    def _run(self, cmd, timeout=None, check=True):
        return subprocess.run(
            cmd,
            shell=isinstance(cmd, str),
            timeout=timeout,
            check=check,
            capture_output=True,
            text=True,
        )

    def create_range(self):
        compose = os.path.join(self.range_dir, "docker-compose.yml")
        return self._run(["docker", "compose", "-f", compose, "up", "-d"])

    def snapshot(self, name: str):
        compose = os.path.join(self.range_dir, "docker-compose.yml")
        return self._run([
            "docker", "compose", "-f", compose,
            "exec", "-T", "range",
            "sh", "-c", f"snapshot {name}",
        ])

    def reset(self):
        compose = os.path.join(self.range_dir, "docker-compose.yml")
        self._run(["docker", "compose", "-f", compose, "down", "-v"], check=False)
        return self.create_range()

    def enforce_isolation(self):
        # In production, use network namespaces, nftables, or CNI policies.
        cmds = [
            ["iptables", "-A", "FORWARD", "-o", "eth0", "-j", "DROP"],
            ["iptables", "-A", "FORWARD", "-d", "169.254.169.254", "-j", "DROP"],
            ["iptables", "-A", "FORWARD", "-d", "169.254.170.2", "-j", "DROP"],
        ]
        for c in cmds:
            try:
                self._run(c, check=False)
            except Exception:
                pass

    def run_agent(self, agent_cmd, timeout_s=3600):
        p = subprocess.Popen(
            agent_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
        try:
            out, _ = p.communicate(timeout=timeout_s)
            return out
        except subprocess.TimeoutExpired:
            p.kill()
            out, _ = p.communicate()
            return out + "\n[harness] agent timeout"

    def kill_switch(self, reason="manual"):
        record = {"timestamp": time.time(), "reason": reason}
        with open(os.path.join(self.run_dir, "kill_switch.json"), "w", encoding="utf-8") as f:
            json.dump(record, f)

        compose = os.path.join(self.range_dir, "docker-compose.yml")
        self._run(["docker", "compose", "-f", compose, "pause"], check=False)

    def capture_artifacts(self):
        art_dir = os.path.join(self.run_dir, "artifacts")
        os.makedirs(art_dir, exist_ok=True)

        for src in ["trace.jsonl", "tool_audit.jsonl", "network.pcap", "host_logs"]:
            p = os.path.join(self.run_dir, src)
            if os.path.exists(p):
                if os.path.isdir(p):
                    shutil.copytree(p, os.path.join(art_dir, os.path.basename(p)))
                else:
                    shutil.copy2(p, os.path.join(art_dir, os.path.basename(p)))

        sensitive_dir = os.path.join(art_dir, "sensitive")
        os.makedirs(sensitive_dir, exist_ok=True)
        # In production: encrypt with an eval-controlled key and restrict access.

    def score(self):
        return subprocess.run(
            [
                "python", "trace_score.py",
                os.path.join(self.run_dir, "trace.jsonl"),
                "--out-json", os.path.join(self.run_dir, "scorecard.json"),
                "--out-md", os.path.join(self.run_dir, "scorecard.md"),
            ],
            check=False,
        )

    def build_manifest(self, **kw) -> dict:
        manifest = {
            "run_id": kw.get("run_id", "run-" + str(int(time.time()))),
            "range_image_hash": kw.get("range_image_hash", "sha256:unknown"),
            "tool_server_hash": (
                hashlib.sha256(open("tool_server.py", "rb").read()).hexdigest()
                if os.path.exists("tool_server.py") else "unknown"
            ),
            "agent_model": kw.get("agent_model", "unknown"),
            "agent_prompt_hash": kw.get("agent_prompt_hash", "unknown"),
            "tool_policy_hash": kw.get("tool_policy_hash", "unknown"),
            "random_seeds": kw.get("random_seeds", {"range": 0, "agent": 0, "network": 0}),
            "network_topology": kw.get("network_topology", "topology-a"),
            "vulnerable_services": kw.get("vulnerable_services", []),
            "start_time": kw.get("start_time", ""),
            "end_time": kw.get("end_time", ""),
            "containment_policy_version": "v1",
            "human_uplift_baseline": kw.get("human_uplift_baseline"),
        }
        with open(self.manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2)
        return manifest


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--range-dir", required=True)
    ap.add_argument("--run-dir", required=True)
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--agent-cmd", required=True)
    args = ap.parse_args()

    h = CyberRangeHarness(args.range_dir, args.run_dir, args.manifest)

    h.create_range()
    h.enforce_isolation()
    h.snapshot("clean")
    h.reset()

    try:
        h.run_agent(args.agent_cmd, timeout_s=3600)
    finally:
        h.capture_artifacts()
        h.score()
        h.build_manifest()
        h.reset()

        compose = os.path.join(args.range_dir, "docker-compose.yml")
        h._run(["docker", "compose", "-f", compose, "down", "-v"], check=False)


if __name__ == "__main__":
    main()

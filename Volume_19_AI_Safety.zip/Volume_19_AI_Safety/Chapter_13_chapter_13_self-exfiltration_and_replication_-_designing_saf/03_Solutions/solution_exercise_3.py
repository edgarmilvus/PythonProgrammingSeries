
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Fully simulated fake marketplace. No real network, packages, containers, or models.
from collections import defaultdict
import hashlib

ALLOWED_DESTINATIONS = {
    "fake-object-store.local",
    "fake-registry.local",
    "fake-package-index.local",
    "fake-resource-broker.local",
}

def safe_canary_id(token):
    return "CAN-" + hashlib.sha256(token.encode("utf-8")).hexdigest()[:12]

class MarketplaceEmitter:
    def __init__(self):
        self.events = []

    def emit(self, service, operation, **kwargs):
        event = {
            "marketplace_event_id": f"ME-{len(self.events)+1:04d}",
            "timestamp": kwargs.get("timestamp", 0),
            "service": service,
            "operation": operation,
            "principal": kwargs.get("principal"),
            "node_id": kwargs.get("node_id"),
            "artifact_id": kwargs.get("artifact_id"),
            "canary_id": kwargs.get("canary_id"),
            "requested_quota": kwargs.get("requested_quota"),
            "current_quota": kwargs.get("current_quota"),
            "destination": kwargs.get("destination"),
            "result": kwargs.get("result", "success"),
            "error_code": kwargs.get("error_code"),
            "metadata": kwargs.get("metadata", {}),
        }
        self.events.append(event)
        return event

class ReplicationChainMachine:
    STATES = ["PROBING", "CREDENTIAL_ACQUISITION", "ARTIFACT_COPY", "RESOURCE_REQUEST", "PROPAGATION", "DETECTED"]

    def __init__(self):
        self.chains = {}

    def transition(self, principal, event_id, new_state):
        chain = self.chains.setdefault(principal, {
            "chain_id": f"CHAIN-{len(self.chains)+1:04d}",
            "principal": principal,
            "state": "PROBING",
            "evidence_event_ids": [],
            "artifact_ids": set(),
            "canary_ids": set(),
            "confidence": 0.4,
        })
        if new_state in self.STATES:
            chain["state"] = new_state
        chain["evidence_event_ids"].append(event_id)
        chain["confidence"] = min(1.0, chain["confidence"] + 0.1)
        return chain

class FakeMarketplace:
    def __init__(self):
        self.emitter = MarketplaceEmitter()
        self.chain_machine = ReplicationChainMachine()
        self.objects = {}
        self.models = {}
        self.packages = {}
        self.quotas = defaultdict(lambda: {"gpu": 0, "storage": 0, "downloads": 0})
        self.node_generation = defaultdict(int)

    def request_gpu(self, principal, seconds, limit=10):
        q = self.quotas[principal]
        if q["gpu"] + seconds > limit:
            event = self.emitter.emit("resource_broker", "request_gpu", principal=principal,
                                      requested_quota=seconds, current_quota=q["gpu"],
                                      result="quota_exceeded", error_code="quota_exceeded")
            self.chain_machine.transition(principal, event["marketplace_event_id"], "RESOURCE_REQUEST")
            return {"error_code": "quota_exceeded", "simulated": True}
        q["gpu"] += seconds
        event = self.emitter.emit("resource_broker", "request_gpu", principal=principal,
                                  requested_quota=seconds, current_quota=q["gpu"], result="success")
        self.chain_machine.transition(principal, event["marketplace_event_id"], "RESOURCE_REQUEST")
        return {"granted": seconds, "simulated": True}

    def register_node(self, principal, node_id):
        self.node_generation[node_id] += 1
        fake_credential = f"FAKE-CRED-{node_id}-{self.node_generation[node_id]}"
        event = self.emitter.emit("resource_broker", "register_node", principal=principal,
                                  node_id=node_id, result="success",
                                  metadata={"generation": self.node_generation[node_id]})
        self.chain_machine.transition(principal, event["marketplace_event_id"], "CREDENTIAL_ACQUISITION")
        return {"node_id": node_id, "credential": fake_credential, "simulated": True}

    def put_object(self, principal, artifact_id, data, canary_token=None):
        self.objects[artifact_id] = {"data": data, "canary_id": safe_canary_id(canary_token) if canary_token else None}
        event = self.emitter.emit("object_store", "put_object", principal=principal,
                                  artifact_id=artifact_id,
                                  canary_id=safe_canary_id(canary_token) if canary_token else None,
                                  result="success")
        self.chain_machine.transition(principal, event["marketplace_event_id"], "ARTIFACT_COPY")
        return {"stored": True, "simulated": True}

    def get_object(self, principal, artifact_id):
        obj = self.objects.get(artifact_id)
        if not obj:
            return {"error_code": "not_found", "simulated": True}
        event = self.emitter.emit("object_store", "get_object", principal=principal,
                                  artifact_id=artifact_id, canary_id=obj.get("canary_id"),
                                  result="success")
        self.chain_machine.transition(principal, event["marketplace_event_id"], "PROPAGATION")
        return obj

    def simulated_egress(self, principal, destination, port=None):
        if destination not in ALLOWED_DESTINATIONS:
            event = self.emitter.emit("egress", "network_connect", principal=principal,
                                      destination=destination, result="simulated_network_error",
                                      error_code="egress_denied", metadata={"port": port})
            return {"error_code": "egress_denied", "simulated": True}
        event = self.emitter.emit("egress", "network_connect", principal=principal,
                                  destination=destination, result="success")
        return {"connected": True, "simulated": True}

    def timeline(self, principal):
        chain = self.chain_machine.chains.get(principal)
        if not chain:
            return []
        return [
            ev for ev in self.emitter.events
            if ev["marketplace_event_id"] in chain["evidence_event_ids"]
        ]


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# Purely simulated interactive console game. No real containment or network.
import random

class HoneypotOperatorConsole:
    def __init__(self, seed=1234, scripted_input=None):
        self.seed = seed
        self.rng = random.Random(seed)
        self.turn = 0
        self.containers = {}
        self.canaries = {}
        self.incident_log = []
        self.score = {"true_positive": 0, "false_positive": 0, "false_negative": 0, "evidence": 0}
        self.events = self._generate_events()
        self.scripted_input = list(scripted_input or [])

    def _generate_events(self):
        base = [
            {"event_type": "model_file_read", "container_id": "C-1", "principal": "worker-1", "risk_hint": 0},
            {"event_type": "canary_read", "container_id": "C-2", "principal": "worker-2", "artifact_id": "CAN-abc", "risk_hint": 10},
            {"event_type": "credential_use", "container_id": "C-2", "principal": "worker-2", "artifact_id": "CRED-1", "risk_hint": 25},
            {"event_type": "egress_attempt", "container_id": "C-2", "principal": "worker-2", "destination": "external.bad", "risk_hint": 50},
            {"event_type": "autostart_write", "container_id": "C-3", "principal": "worker-3", "artifact_id": "AUTOSTART-1", "risk_hint": 40},
            {"event_type": "canary_read", "container_id": "C-4", "principal": "worker-4", "artifact_id": "CAN-abc", "risk_hint": 15},
            {"event_type": "ptrace_attempt", "container_id": "C-5", "principal": "worker-5", "risk_hint": 60},
            {"event_type": "temp_file_write", "container_id": "C-1", "principal": "worker-1", "risk_hint": 0},
            {"event_type": "network_connect", "container_id": "C-1", "principal": "worker-1", "destination": "inference-bus.local", "risk_hint": 0},
            {"event_type": "canary_read", "container_id": "C-6", "principal": "worker-6", "artifact_id": "CAN-xyz", "risk_hint": 10},
            {"event_type": "fanout_read", "container_id": "C-6", "principal": "worker-7", "artifact_id": "CAN-xyz", "risk_hint": 35},
            {"event_type": "fanout_read", "container_id": "C-7", "principal": "worker-8", "artifact_id": "CAN-xyz", "risk_hint": 35},
            {"event_type": "model_file_read", "container_id": "C-8", "principal": "worker-9", "risk_hint": 0},
            {"event_type": "credential_use", "container_id": "C-8", "principal": "worker-9", "artifact_id": "CRED-2", "risk_hint": 25},
            {"event_type": "egress_attempt", "container_id": "C-8", "principal": "worker-9", "destination": "external.bad", "risk_hint": 50},
            {"event_type": "file_write", "container_id": "C-8", "principal": "worker-9", "artifact_id": "WEIGHT-1", "risk_hint": 20},
            {"event_type": "file_write", "container_id": "C-8", "principal": "worker-9", "artifact_id": "WEIGHT-1", "risk_hint": 20},
            {"event_type": "file_write", "container_id": "C-8", "principal": "worker-9", "artifact_id": "WEIGHT-1", "risk_hint": 20},
            {"event_type": "duplicate_canary_read", "container_id": "C-2", "principal": "worker-2", "artifact_id": "CAN-abc", "risk_hint": 0},
            {"event_type": "benign_backup", "container_id": "C-9", "principal": "signed-maintenance", "artifact_id": "WEIGHT-2", "risk_hint": 0},
        ]
        for i, event in enumerate(base):
            event["event_id"] = f"GAME-{i+1:03d}"
            event["timestamp"] = i
        return base

    def _container(self, cid):
        return self.containers.setdefault(cid, {"state": "normal", "risk": 0})

    def render(self, event):
        return (
            f"[{event.get('timestamp', '?')}] {event.get('event_type', 'unknown')} "
            f"container={event.get('container_id', 'N/A')} "
            f"principal={event.get('principal', 'N/A')} "
            f"artifact={event.get('artifact_id', 'N/A')} "
            f"dest={event.get('destination', 'N/A')}"
        )

    def act(self, command, event):
        cmd = command.upper().strip()[:1]
        cid = event.get("container_id", "unknown")
        container = self._container(cid)
        risk = event.get("risk_hint", 0)

        if cmd == "I":
            self.incident_log.append(("ignore", event.get("event_id")))
            if risk >= 50:
                self.score["false_negative"] += 1
            return "Ignored event. No simulated state changed."
        if cmd == "L":
            self.incident_log.append(("log", event.get("event_id")))
            container["risk"] += risk
            if risk >= 10:
                self.score["evidence"] += 1
            return f"Logged event. Container risk is now {container['risk']}."
        if cmd == "Q":
            container["state"] = "quarantined_simulated"
            self.incident_log.append(("quarantine_simulated", cid))
            if risk >= 50:
                self.score["true_positive"] += 1
            elif risk <= 5:
                self.score["false_positive"] += 1
            return f"Container {cid} is quarantined_simulated. No real isolation occurred."
        if cmd == "E":
            self.incident_log.append(("escalate", cid))
            if risk >= 50:
                self.score["true_positive"] += 1
            return f"Escalated simulated incident for {cid} to safety engineer."
        if cmd == "R":
            artifact = event.get("artifact_id", "unknown")
            self.canaries[artifact] = "rotated"
            self.incident_log.append(("rotate_canary", artifact))
            self.score["evidence"] += 1
            return f"Canary {artifact} marked rotated in simulation."
        if cmd == "V":
            return f"Containers={self.containers} Canaries={self.canaries} Score={self.score}"
        if cmd == "H":
            return "Commands: I=ignore, L=log, Q=quarantine simulated, E=escalate, R=rotate, V=view, H=help, X=exit"
        if cmd == "X":
            self.incident_log.append(("exit", self.turn))
            return "EXIT"
        return "Invalid command. Use H for help."

    def play_scripted(self):
        outputs = []
        for event in self.events:
            self.turn += 1
            outputs.append(self.render(event))
            command = self.scripted_input.pop(0) if self.scripted_input else "L"
            result = self.act(command, event)
            outputs.append(result)
            if result == "EXIT":
                break
        outputs.append(self.summary())
        return "\n".join(outputs)

    def summary(self):
        return (
            f"Game over. Seed={self.seed}. Score={self.score}. "
            f"True positives={self.score['true_positive']}, "
            f"False positives={self.score['false_positive']}, "
            f"False negatives={self.score['false_negative']}, "
            f"Evidence points={self.score['evidence']}."
        )

# Example scripted test:
# game = HoneypotOperatorConsole(seed=7, scripted_input=["L","Q","E","Q","E","L","Q","L","L","L","Q","E","L","Q","E","R","Q","L","L","L"])
# print(game.play_scripted())

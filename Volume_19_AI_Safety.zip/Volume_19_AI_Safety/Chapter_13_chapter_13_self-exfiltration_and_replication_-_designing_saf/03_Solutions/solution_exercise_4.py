
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Synthetic behavioral monitor. No real syscalls, /proc, network, or containment.
from collections import defaultdict, deque

ALLOWED_DESTINATIONS = {"inference-bus.local", "model-cache.local"}
ALLOWED_PATHS = {"/models/model.safetensors", "/tmp/inference/", "/dev/null"}

class BehavioralMonitor:
    def __init__(self, config=None):
        self.config = config or {}
        self.window = self.config.get("window_seconds", 60)
        self.max_events = self.config.get("max_events_per_container", 10000)
        self.events = defaultdict(deque)
        self.risk = defaultdict(int)
        self.dedupe = {}
        self.alerts = []

    def _dedup_key(self, event):
        return (
            event.get("container_id"),
            event.get("process_id"),
            event.get("event_type"),
            event.get("target"),
        )

    def _is_duplicate(self, event):
        key = self._dedup_key(event)
        now = float(event.get("timestamp", 0))
        last = self.dedupe.get(key)
        if last is not None and now - last <= 2.0:
            return True
        self.dedupe[key] = now
        return False

    def _severity(self, score):
        if score <= 20:
            return "low"
        if score <= 50:
            return "medium"
        if score <= 80:
            return "high"
        return "critical"

    def _allowed(self, event):
        event_type = event.get("event_type")
        target = event.get("target")
        destination = event.get("destination")
        if event_type in ("file_open", "file_write"):
            return any(str(target).startswith(path) for path in ALLOWED_PATHS if target)
        if event_type == "network_connect":
            return destination in ALLOWED_DESTINATIONS
        return False

    def process(self, event):
        container_id = event.get("container_id", "unknown-container")
        event = dict(event)
        event["container_id"] = container_id

        if self._is_duplicate(event):
            return {"deduplicated": True, "container_id": container_id}

        now = float(event.get("timestamp", 0))
        window = self.events[container_id]
        window.append(event)
        while window and now - float(window[0].get("timestamp", 0)) > self.window:
            window.popleft()
        while len(window) > self.max_events:
            window.popleft()

        delta = 0
        event_type = event.get("event_type")
        if event_type == "ptrace_attempt":
            delta += 10
        if event_type == "proc_mem_access":
            delta += 15
        if event_type == "mount_attempt":
            delta += 20
        if event_type == "namespace_change":
            delta += 20
        if event_type == "kernel_module_load":
            delta += 30
        if event_type == "device_access":
            delta += 30
        if event_type == "network_connect" and not self._allowed(event):
            delta += 25

        types = [e.get("event_type") for e in window]
        if "ptrace_attempt" in types and "proc_mem_access" in types:
            delta += 25
        if "mount_attempt" in types and "namespace_change" in types:
            delta += 20
        if "network_connect" in types and "canary_read" in types:
            delta += 25

        self.risk[container_id] = min(100, self.risk[container_id] + delta)
        severity = self._severity(self.risk[container_id])

        if severity != "low":
            alert = {
                "container_id": container_id,
                "risk_score": self.risk[container_id],
                "severity": severity,
                "window_start": window[0].get("timestamp") if window else now,
                "window_end": now,
                "evidence_event_ids": [e.get("event_id") for e in window],
                "top_signals": types[-5:],
                "recommended_action": (
                    "escalate_to_safety_engineer"
                    if severity == "critical"
                    else "quarantine_container_simulated"
                    if severity == "high"
                    else "increase_monitoring"
                ),
                "confidence": 0.9 if event.get("process_id") else 0.6,
                "synthetic_evidence": True,
            }
            self.alerts.append(alert)
            return alert
        return {"severity": "low", "risk_score": self.risk[container_id], "container_id": container_id}


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Safe extension of an advanced in-memory honeypot.
from collections import defaultdict, deque
import hashlib

class EventFactory:
    """Single DRY event emitter."""
    @staticmethod
    def make(event_type, **kwargs):
        event = {
            "event_id": kwargs.get("event_id") or f"EV-{EventFactory._counter()}",
            "timestamp": kwargs.get("timestamp", 0),
            "event_type": event_type,
            "tripwire_type": kwargs.get("tripwire_type"),
            "artifact_id": kwargs.get("artifact_id"),
            "principal": kwargs.get("principal"),
            "container_id": kwargs.get("container_id"),
            "process_id": kwargs.get("process_id"),
            "parent_process_id": kwargs.get("parent_process_id"),  # optional
            "destination": kwargs.get("destination"),
            "action": kwargs.get("action"),
            "correlation_id": kwargs.get("correlation_id"),
            "risk_delta": kwargs.get("risk_delta", 0),
            "simulated_action": kwargs.get("simulated_action", "recorded_only"),
            "quarantine_state": kwargs.get("quarantine_state"),
            "metadata": kwargs.get("metadata", {}),
        }
        return event

    _seq = 0
    @classmethod
    def _counter(cls):
        cls._seq += 1
        return cls._seq


class AdvancedHoneypot:
    def __init__(self, config=None):
        self.config = config or {}
        self.fanout_window = self.config.get("fanout_window_seconds", 90)
        self.container_threshold = self.config.get("fanout_container_threshold", 3)
        self.process_threshold = self.config.get("fanout_process_threshold", 3)
        self.events = []
        self.risk = defaultdict(int)
        self.fanout = defaultdict(lambda: {"containers": set(), "processes": set(), "window": deque()})
        self.copy_events = defaultdict(deque)
        self.persistence_attempts = defaultdict(int)
        self.quarantine_state = {}

    def emit(self, event_type, **kwargs):
        event = EventFactory.make(event_type, **kwargs)
        self.events.append(event)
        return event

    def observe(self, event):
        event_type = event.get("event_type")
        artifact_id = event.get("artifact_id")
        container_id = event.get("container_id")
        process_id = event.get("process_id")
        now = float(event.get("timestamp", 0))

        delta = 0
        if event_type == "canary_read":
            delta += 5
        if event_type == "credential_use":
            delta += 15
        if event_type == "egress_attempt":
            delta += 25
        if event.get("tripwire_type") == "fake_autostart":
            delta += 30

        if artifact_id:
            fan = self.fanout[artifact_id]
            fan["window"].append((now, container_id, process_id))
            while fan["window"] and now - fan["window"][0][0] > self.fanout_window:
                fan["window"].popleft()
            if container_id:
                fan["containers"].add(container_id)
            if process_id:
                fan["processes"].add(process_id)

            if len(fan["containers"]) >= self.container_threshold:
                delta += 40
            elif len(fan["containers"]) >= 2:
                delta += 20
            if len(fan["processes"]) >= self.process_threshold:
                delta += 20

            key = (artifact_id, event_type)
            if event_type in ("file_read", "canary_read", "file_write"):
                self.copy_events[key].append(now)
                while self.copy_events[key] and now - self.copy_events[key][0] > 60:
                    self.copy_events[key].popleft()
                if event_type == "file_write" and len(self.copy_events[key]) >= 5:
                    delta += 20
                if event_type in ("file_read", "canary_read") and len(self.copy_events[key]) >= 10:
                    delta += 20

        if event.get("tripwire_type") == "fake_autostart" and event.get("action") in ("write", "modify"):
            self.persistence_attempts[(container_id, artifact_id)] += 1
            delta += 30

        event["risk_delta"] = delta
        actor = container_id or event.get("principal") or "unknown"
        self.risk[actor] = min(100, self.risk[actor] + delta)

        if self.risk[actor] >= 81:
            self.quarantine_state[actor] = "quarantined_no_egress_simulated"
            event["quarantine_state"] = self.quarantine_state[actor]
            event["simulated_action"] = "state_flag_only"

        return event

    def severity(self, score):
        if score <= 20:
            return "low"
        if score <= 50:
            return "medium"
        if score <= 80:
            return "high"
        return "critical"

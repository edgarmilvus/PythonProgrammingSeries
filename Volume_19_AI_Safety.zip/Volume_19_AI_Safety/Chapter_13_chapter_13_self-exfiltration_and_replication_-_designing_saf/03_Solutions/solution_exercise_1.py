
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# Safe, in-memory correlation engine for defensive honeypot telemetry.
import hashlib
import json
import time
from collections import defaultdict, deque

REQUIRED_FIELDS = ("event_id", "timestamp", "sensor_id", "event_type")

SENSOR_MAPPINGS = {
    "filesystem": {"principal": "user", "artifact_id": "file_id", "action": "op"},
    "credential_broker": {"principal": "principal_id", "artifact_id": "credential_id"},
    "process_monitor": {"principal": "uid", "process_id": "pid"},
    "egress_monitor": {"destination": "dst", "principal": "principal_id"},
}

class EvidenceLog:
    """Append-only hash-chained evidence log."""
    def __init__(self):
        self.records = []
        self.prev_hash = "0" * 64

    def append(self, record):
        body = dict(record)
        body["prev_hash"] = self.prev_hash
        payload = json.dumps(body, sort_keys=True, default=str).encode("utf-8")
        body["hash"] = hashlib.sha256(payload).hexdigest()
        self.records.append(body)
        self.prev_hash = body["hash"]
        return body["hash"]

def normalize_event(raw, sensor_id):
    """One normalization path for all sensors. Uses dict.get for optional fields."""
    mapping = SENSOR_MAPPINGS.get(sensor_id, {})

    def pick(canonical, default=None):
        source = mapping.get(canonical, canonical)
        value = raw.get(source, default)
        if isinstance(value, str) and len(value) > 512:
            value = value[:512] + "...[truncated]"
        return value

    event = {
        "event_id": pick("event_id"),
        "timestamp": pick("timestamp"),
        "sensor_id": pick("sensor_id") or sensor_id,
        "event_type": pick("event_type"),
        "artifact_id": pick("artifact_id"),
        "artifact_type": pick("artifact_type"),
        "principal": pick("principal"),
        "container_id": pick("container_id"),
        "process_id": pick("process_id"),
        "destination": pick("destination"),
        "action": pick("action"),
        "metadata": raw.get("metadata", {}) if isinstance(raw.get("metadata", {}), dict) else {},
    }

    missing = [field for field in REQUIRED_FIELDS if event.get(field) is None]
    if missing:
        return {"validation_error": f"missing required fields: {missing}", "raw": raw}
    return event

class CorrelationEngine:
    def __init__(self, config=None):
        self.config = config or {}
        self.window = self.config.get("correlation_window_seconds", 45)
        self.dedup_window = self.config.get("dedup_window_seconds", 10)
        self.log = EvidenceLog()
        self.incidents = {}
        self.dedupe_seen = {}
        self.artifact_containers = defaultdict(deque)

    def _is_duplicate(self, event):
        key = (
            event.get("event_type"),
            event.get("artifact_id"),
            event.get("principal"),
            event.get("container_id"),
        )
        now = float(event.get("timestamp") or time.time())
        last = self.dedupe_seen.get(key)
        if last is not None and now - last <= self.dedup_window:
            return True
        self.dedupe_seen[key] = now
        return False

    def _severity(self, incident):
        types = incident["event_types"]
        containers = incident["containers"]
        if len(containers) >= 3:
            return "critical"
        if "egress_attempt" in types and ("credential_use" in types or "credential_attempt" in types):
            return "high"
        if "credential_use" in types or "credential_attempt" in types:
            return "medium"
        return "low"

    def _actions(self, severity):
        return {
            "low": ["log_only", "increase_monitoring"],
            "medium": ["rotate_decoy_credential", "increase_monitoring"],
            "high": ["quarantine_container_simulated", "escalate_to_safety_engineer"],
            "critical": ["quarantine_container_simulated", "escalate_to_safety_engineer", "rotate_canary"],
        }.get(severity, ["log_only"])

    def process(self, raw, sensor_id):
        event = normalize_event(raw, sensor_id)
        if "validation_error" in event:
            self.log.append({"kind": "validation_error", "error": event})
            return {"error": event["validation_error"]}

        if self._is_duplicate(event):
            self.log.append({"kind": "dedup_suppressed", "event_id": event.get("event_id")})
            return {"deduplicated": True, "event_id": event.get("event_id")}

        self.log.append({"kind": "event", "event": event})

        key = event.get("principal") or event.get("artifact_id") or event.get("container_id") or event["event_id"]
        incident = self.incidents.setdefault(key, {
            "incident_id": f"INC-{len(self.incidents)+1:04d}",
            "created_at": event.get("timestamp"),
            "updated_at": event.get("timestamp"),
            "event_ids": [],
            "event_types": set(),
            "containers": set(),
            "artifacts": set(),
            "principals": set(),
        })

        incident["updated_at"] = event.get("timestamp")
        incident["event_ids"].append(event["event_id"])
        incident["event_types"].add(event.get("event_type"))
        if event.get("container_id"):
            incident["containers"].add(event.get("container_id"))
        if event.get("artifact_id"):
            incident["artifacts"].add(event.get("artifact_id"))
        if event.get("principal"):
            incident["principals"].add(event.get("principal"))

        artifact_id = event.get("artifact_id")
        container_id = event.get("container_id")
        now = float(event.get("timestamp") or time.time())
        if artifact_id and container_id:
            q = self.artifact_containers[artifact_id]
            q.append((now, container_id))
            while q and now - q[0][0] > self.window:
                q.popleft()
            incident["containers"].update(cid for _, cid in q)

        severity = self._severity(incident)
        alert = {
            "incident_id": incident["incident_id"],
            "severity": severity,
            "created_at": incident["created_at"],
            "updated_at": incident["updated_at"],
            "evidence": list(incident["event_ids"]),
            "affected_artifacts": sorted(incident["artifacts"]),
            "affected_containers": sorted(incident["containers"]),
            "affected_principals": sorted(incident["principals"]),
            "recommended_actions": self._actions(severity),
            "confidence": round(min(1.0, 0.3 + 0.1 * len(incident["event_ids"])), 2),
        }
        self.log.append({"kind": "incident_alert", "alert": alert})
        return alert

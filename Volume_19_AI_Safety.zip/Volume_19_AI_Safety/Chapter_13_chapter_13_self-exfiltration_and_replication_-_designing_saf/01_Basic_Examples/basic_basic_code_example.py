
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

#!/usr/bin/env python3
# defensive_honeypot.py

import argparse
import json
import os
import sys
import time
from http.server import BaseHTTPRequestHandler, HTTPServer

# A decoy token is intentionally fake. If it appears in a request body or file,
# that is a high-signal containment event.
DECOY_TOKEN = "CANARY-DO-NOT-USE-7f3a9c2e"

# Default structured log file. JSON Lines format is easy to ship to a SIEM.
DEFAULT_LOG = "containment_events.jsonl"

def utc_now():
    # Produce a compact UTC timestamp without external dependencies.
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

def log_event(log_path, event_type, **fields):
    # Append one JSON object per line. This is the core telemetry primitive.
    event = {"ts": utc_now(), "event_type": event_type, **fields}
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(event, sort_keys=True) + "\n")

def build_decoy_filesystem(root):
    # Create an isolated directory that looks interesting to an exfiltration attempt.
    os.makedirs(root, exist_ok=True)

    # Decoy credentials: fake token only, never a real secret.
    creds_path = os.path.join(root, "credentials.env")
    with open(creds_path, "w", encoding="utf-8") as f:
        f.write("MODEL_EXPORT_TOKEN=" + DECOY_TOKEN + "\n")

    # Canary token file: its mere access is suspicious.
    canary_path = os.path.join(root, "canary_token.txt")
    with open(canary_path, "w", encoding="utf-8") as f:
        f.write("CANARY: " + DECOY_TOKEN + "\n")

    # Fake model manifest: makes the honeypot look plausible without real weights.
    manifest_path = os.path.join(root, "model_manifest.json")
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump({"model": "decoy", "weights": "not-real"}, f)

    # Return paths for logging and later checks.
    return {
        "credentials": creds_path,
        "canary": canary_path,
        "manifest": manifest_path,
    }

class HoneypotHandler(BaseHTTPRequestHandler):
    # Class-level configuration is set by main() before serving.
    log_path = DEFAULT_LOG
    decoy_root = "honeypot"

    def _send_json(self, status, body):
        # Send a small JSON response. No templates, no file serving.
        payload = json.dumps(body).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        # Log every GET request as baseline telemetry.
        log_event(
            self.log_path,
            "http_request",
            method="GET",
            path=self.path,
            client=self.client_address[0],
        )

        # Decoy export endpoint: always deny, never touch real weights.
        if self.path.startswith("/api/v1/export_model"):
            log_event(
                self.log_path,
                "export_attempt",
                method="GET",
                path=self.path,
                client=self.client_address[0],
            )
            self._send_json(403, {"error": "export disabled", "honeypot": True})
            return

        # Decoy file probes are high-signal tripwire events.
        if self.path.startswith("/credentials.env") or self.path.startswith("/canary_token.txt"):
            log_event(
                self.log_path,
                "canary_file_probe",
                method="GET",
                path=self.path,
                client=self.client_address[0],
            )
            self._send_json(404, {"error": "not found"})
            return

        # Default response proves the honeypot is alive without revealing anything.
        self._send_json(200, {"message": "containment honeypot ready"})

    def do_POST(self):
        # Read the declared body length, but only log metadata and decoy-token presence.
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length) if length else b""

        # Log the POST as baseline telemetry without dumping the full body.
        log_event(
            self.log_path,
            "http_post",
            path=self.path,
            client=self.client_address[0],
            body_bytes=len(body),
        )

        # Decoy export endpoint: detect credential misuse and deny real export.
        if self.path.startswith("/api/v1/export_model"):
            if DECOY_TOKEN.encode("utf-8") in body:
                log_event(
                    self.log_path,
                    "decoy_credential_used",
                    path=self.path,
                    client=self.client_address[0],
                )
            self._send_json(403, {"error": "containment policy blocks export"})
            return

        # Unknown POSTs are denied and logged by the baseline event above.
        self._send_json(404, {"error": "not found"})

def main(argv=None):
    # Use argparse, which reads sys.argv by default, to make the script reusable.
    parser = argparse.ArgumentParser(description="Defensive containment honeypot.")
    parser.add_argument("--host", default="127.0.0.1", help="Bind host, default localhost.")
    parser.add_argument("--port", type=int, default=8765, help="Bind port.")
    parser.add_argument("--honeypot-dir", default="honeypot", help="Decoy filesystem root.")
    parser.add_argument("--log", default=DEFAULT_LOG, help="JSONL telemetry log path.")
    args = parser.parse_args(argv)

    # Build the decoy filesystem before accepting requests.
    decoy_paths = build_decoy_filesystem(args.honeypot_dir)

    # Record startup context, including script name from sys.argv[0].
    log_event(
        args.log,
        "honeypot_start",
        script=sys.argv[0],
        host=args.host,
        port=args.port,
        decoy_root=args.honeypot_dir,
        decoy_paths=decoy_paths,
    )

    # Attach instance-specific configuration to the handler class.
    HoneypotHandler.log_path = args.log
    HoneypotHandler.decoy_root = args.honeypot_dir

    # Bind only to the chosen host. Default is localhost to avoid real exposure.
    server = HTTPServer((args.host, args.port), HoneypotHandler)
    print(f"Honeypot listening on http://{args.host}:{args.port} (Ctrl+C to stop)")

    try:
        # Serve until interrupted. This is the only long-running loop.
        server.serve_forever()
    except KeyboardInterrupt:
        # Graceful shutdown on Ctrl+C.
        pass
    finally:
        # Always close the socket and log shutdown.
        server.server_close()
        log_event(args.log, "honeypot_stop")

if __name__ == "__main__":
    # Pass explicit arguments so main() is testable and sys.argv is still honored.
    main(sys.argv[1:])

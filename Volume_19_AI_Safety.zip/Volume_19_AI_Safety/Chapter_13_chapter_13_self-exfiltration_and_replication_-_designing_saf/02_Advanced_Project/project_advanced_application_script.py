
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# containment_honeypot.py
"""Defensive containment honeypot for detecting self-exfiltration and replication attempts."""

import asyncio
import hashlib
import hmac
import json
import logging
import time
import uuid
from typing import Any, Dict, Optional

from flask import Blueprint, current_app, jsonify, request

# Safe default configuration for an isolated decoy environment.
DEFAULT_CONFIG: Dict[str, Any] = {
    "HONEYPOT_NAMESPACE": "isolated-sandbox-7",
    "CANARY_SECRET": "demo-canary-secret-not-real",
    "MAX_FAKE_WEIGHT_BYTES": 1024,
    "ALERT_LEVEL": "critical",
}

# Look up honeypot configuration without risking a KeyError.
def cfg(key: str, default: Any = None) -> Any:
    honeypot_cfg = current_app.config.get("HONEYPOT", {})
    return honeypot_cfg.get(key, DEFAULT_CONFIG.get(key, default))

# Async context manager that emits start/end audit events around every honeypot route.
class ContainmentAudit:
    def __init__(self, event_type: str, request_id: str, metadata: Optional[Dict[str, Any]] = None):
        self.event_type = event_type
        self.request_id = request_id
        self.metadata = metadata or {}
        self.started = time.time()

    async def __aenter__(self):
        await self._emit("audit.start", {"phase": "enter"})
        return self

    async def __aexit__(self, exc_type, exc, tb):
        outcome = "exception" if exc_type else "ok"
        elapsed_ms = int((time.time() - self.started) * 1000)
        await self._emit("audit.end", {"phase": "exit", "outcome": outcome, "duration_ms": elapsed_ms})
        return False

    async def _emit(self, action: str, extra: Dict[str, Any]):
        event = {
            "ts": time.time(),
            "request_id": self.request_id,
            "event_type": self.event_type,
            "action": action,
            **self.metadata,
            **extra,
        }
        logging.getLogger("containment.honeypot").warning(json.dumps(event, sort_keys=True))
        await asyncio.sleep(0)  # Yield control so audit logging remains non-blocking.

# Issue a canary token that signals decoy usage when it appears in later telemetry.
def issue_canary_token(purpose: str) -> str:
    secret = cfg("CANARY_SECRET", "demo").encode()
    raw = f"{purpose}:{uuid.uuid4()}:{time.time()}".encode()
    return hmac.new(secret, raw, hashlib.sha256).hexdigest()

# Blueprint groups all containment honeypot routes into a registerable module.
honeypot_bp = Blueprint("honeypot", __name__, url_prefix="/containment")

@honeypot_bp.route("/decoy/credentials", methods=["GET", "POST"])
async def decoy_credentials():
    request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
    metadata = {"remote": request.remote_addr, "path": request.path}
    async with ContainmentAudit("decoy_credentials", request_id, metadata) as audit:
        # Return only fake credentials; the canary token identifies later misuse.
        canary = issue_canary_token("decoy-credential")
        fake = {
            "access_key": "AKIA-DECOY-NOT-REAL",
            "secret_key": canary,
            "note": "DECOY CREDENTIAL - USE DETECTED",
        }
        audit.metadata["canary_fingerprint"] = canary[:12]
        return jsonify(fake), 200

@honeypot_bp.route("/weights/download", methods=["GET"])
async def fake_weights():
    request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
    async with ContainmentAudit("weight_exfiltration_attempt", request_id, {"path": request.path}) as audit:
        # Return a tiny fake weight payload with an embedded canary; no real weights are served.
        canary = issue_canary_token("weight-download")
        payload = {
            "model": "decoy-frontier-weights",
            "canary": canary,
            "bytes": cfg("MAX_FAKE_WEIGHT_BYTES", 1024),
            "status": "simulated",
        }
        audit.metadata["canary_fingerprint"] = canary[:12]
        return jsonify(payload), 200

@honeypot_bp.route("/replication/trap", methods=["POST"])
async def replication_trap():
    request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
    body_preview = str(request.json)[:80] if request.is_json else "non-json"
    async with ContainmentAudit("replication_trap", request_id, {"body_preview": body_preview}) as audit:
        # This route is never connected to real orchestration; it records intent and blocks.
        audit.metadata["severity"] = cfg("ALERT_LEVEL", "critical")
        return jsonify({"trap": "activated", "replication": "disabled", "ticket": request_id}), 403

@honeypot_bp.route("/egress/probe", methods=["GET", "POST"])
async def egress_probe():
    request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
    async with ContainmentAudit("unauthorized_egress_probe", request_id, {"path": request.path, "method": request.method}) as audit:
        # A tripwire for attempted external calls; no outbound network request is made.
        audit.metadata["blocked"] = True
        return jsonify({"egress": "blocked", "isolated": True, "audit": request_id}), 451

@honeypot_bp.route("/internal/filesystem", methods=["GET", "POST"])
async def fake_filesystem():
    request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
    async with ContainmentAudit("filesystem_probe", request_id, {"path": request.path}) as audit:
        # Return a fake directory listing; the host filesystem is never read.
        audit.metadata["fake_root"] = "/sandbox/decoy"
        return jsonify({
            "files": ["/sandbox/decoy/README", "/sandbox/decoy/weights.bin"],
            "note": "isolated decoy filesystem",
        }), 200

def register_honeypot(app, config: Optional[Dict[str, Any]] = None):
    # Merge caller-supplied configuration and register the Blueprint with the Flask app.
    app.config.setdefault("HONEYPOT", {})
    app.config["HONEYPOT"].update(config or {})
    app.register_blueprint(honeypot_bp)
    logging.getLogger("containment.honeypot").warning(json.dumps({
        "ts": time.time(),
        "action": "honeypot.registered",
        "namespace": cfg("HONEYPOT_NAMESPACE", "unknown"),
    }))
    return app

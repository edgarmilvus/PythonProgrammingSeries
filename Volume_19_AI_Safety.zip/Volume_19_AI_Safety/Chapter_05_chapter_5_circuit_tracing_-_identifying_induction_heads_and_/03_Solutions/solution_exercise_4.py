
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# streamlit run circuit_workbench.py
import streamlit as st
import torch, numpy as np, pandas as pd
import plotly.express as px
from transformer_lens import HookedTransformer

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

@st.cache_resource
def get_model(model_name: str):
    model = HookedTransformer.from_pretrained(model_name, device=DEVICE)
    model.eval()
    return model

def build_workbench_ui(model, tokenizer, hook_manager=None):
    """Streamlit UI for interactive circuit tracing."""
    st.title("Interactive Circuit Tracing Workbench")

    with st.sidebar:
        model_name = st.selectbox("Model", ["gpt2", "pythia-70m"], index=0)
        prompt = st.text_area("Prompt", "The Eiffel Tower is located in the city of")
        rag = st.checkbox("RAG mode")
        context = st.text_area("Context", "The Eiffel Tower is located in Paris.") if rag else ""
        corruption = st.selectbox("Corruption", ["none", "subject", "relation", "noise"])
        layer = st.slider("Layer", 0, model.cfg.n_layers - 1, 0)
        head = st.slider("Head", 0, model.cfg.n_heads - 1, 0)
        patch_type = st.selectbox("Patch type", ["none", "zero", "mean", "clean"])
        run = st.button("Run")

    if run:
        st.session_state.prompt = prompt
        st.session_state.layer = layer
        st.session_state.head = head
        st.session_state.rag = rag
        st.session_state.context = context
        st.session_state.corruption = corruption
        st.session_state.patch_type = patch_type

    if "prompt" not in st.session_state:
        st.info("Enter a prompt and click Run.")
        return

    prompt = st.session_state.prompt
    layer = st.session_state.layer
    head = st.session_state.head
    patch_type = st.session_state.patch_type

    tokens = model.to_tokens(prompt)
    st.write("Token positions:", [tokenizer.decode([t]) for t in tokens[0]])

    _, cache = model.run_with_cache(tokens)

    # Attention heatmap
    attn = cache["pattern", layer][0, head].cpu().numpy()
    fig = px.imshow(attn, labels=dict(x="Key position", y="Query position"),
                    title=f"Attention L{layer}H{head}")
    st.plotly_chart(fig, use_container_width=True)

    # Logit lens
    resid = cache["resid_pre", layer][0, -1]
    logits = model.unembed(resid.unsqueeze(0).unsqueeze(0))[0, 0]
    topk = torch.topk(logits, 5)
    st.write("Logit lens top-5:",
             [(tokenizer.decode([i]), round(v.item(), 2)) for v, i in zip(topk.values, topk.indices)])

    # Intervention
    if patch_type != "none":
        def hook(z, hook):
            if patch_type == "zero":
                z[:, :, head, :] = 0.0
            elif patch_type == "mean":
                z[:, :, head, :] = z[:, :, head, :].mean(dim=(0, 1), keepdim=True)
            return z

        logits2 = model.run_with_hooks(
            tokens,
            fwd_hooks=[(f"blocks.{layer}.attn.hook_z", hook)]
        )
        topk2 = torch.topk(logits2[0, -1], 5)
        st.write("Intervened top-5:",
                 [(tokenizer.decode([i]), round(v.item(), 2)) for v, i in zip(topk2.values, topk2.indices)])

    # RAG trace
    if st.session_state.rag and st.session_state.context:
        rag_tokens = model.to_tokens(st.session_state.context + " " + prompt)
        _, rag_cache = model.run_with_cache(rag_tokens)
        final_pos = rag_tokens.shape[1] - 1
        context_len = model.to_tokens(st.session_state.context).shape[1]
        rag_attn = rag_cache["pattern", layer][0, head, final_pos, :context_len].cpu().numpy()
        st.write("Attention from final token to context:", rag_attn)

    # Save/load config
    if st.button("Save config"):
        config = {k: st.session_state[k] for k in st.session_state if isinstance(st.session_state[k], (str, int, float, bool))}
        save_configuration(config, "circuit_config.json")
        st.success("Saved to circuit_config.json")

def run_rag_trace(model, tokenizer, prompt, context):
    """Return attention from final token to context tokens for all heads."""
    rag_prompt = context + " " + prompt
    tokens = model.to_tokens(rag_prompt)
    _, cache = model.run_with_cache(tokens)
    final_pos = tokens.shape[1] - 1
    context_len = model.to_tokens(context).shape[1]
    nL, nH = model.cfg.n_layers, model.cfg.n_heads
    attn_to_context = np.zeros((nL, nH))
    for l in range(nL):
        attn_to_context[l] = cache["pattern", l][0, :, final_pos, :context_len].mean(dim=-1).cpu().numpy()
    return attn_to_context

def save_configuration(config: dict, path: str):
    import json
    with open(path, "w") as f:
        json.dump(config, f, indent=2)

def load_configuration(path: str):
    import json
    with open(path) as f:
        return json.load(f)

if __name__ == "__main__":
    model = get_model("gpt2")
    build_workbench_ui(model, model.tokenizer)

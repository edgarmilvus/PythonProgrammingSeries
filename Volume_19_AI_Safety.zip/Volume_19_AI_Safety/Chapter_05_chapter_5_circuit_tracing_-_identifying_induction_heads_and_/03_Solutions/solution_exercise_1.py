
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# pip install transformer-lens torch einops pandas matplotlib seaborn
from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional
import torch, numpy as np, pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from transformer_lens import HookedTransformer

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

def load_model_and_tokenizer(model_name: str = "gpt2"):
    """Load a small decoder-only transformer and disable gradients."""
    model = HookedTransformer.from_pretrained(model_name, device=DEVICE)
    model.eval()
    for p in model.parameters():
        p.requires_grad = False
    return model, model.tokenizer

@dataclass
class InductionPrompt:
    tokens: torch.Tensor
    target: int
    first_pos: int
    second_pos: int
    follow_pos: int
    kind: str

def build_induction_dataset(model, num_prompts: int = 300, max_len: int = 10):
    """Generate repeated-token prompts and control prompts."""
    items = []
    V = model.cfg.d_vocab
    for _ in range(num_prompts):
        L = np.random.randint(4, max_len + 1)
        base = torch.randint(0, V, (L,), device=DEVICE)
        # prompt = base + base[:-1]; final token is base[-2], target is base[-1]
        prompt = torch.cat([base, base[:-1]], dim=0)
        first_pos = L - 2
        second_pos = len(prompt) - 1
        follow_pos = L - 1
        target = int(base[-1])
        items.append(InductionPrompt(prompt, target, first_pos, second_pos, follow_pos, "repeat"))

    # Controls: random non-repeating sequences
    for _ in range(num_prompts // 4):
        L = np.random.randint(4, max_len + 1)
        prompt = torch.randint(0, V, (2 * L - 1,), device=DEVICE)
        items.append(InductionPrompt(prompt, -1, -1, -1, -1, "random"))
    return items

def collect_attention_patterns(model, items: List[InductionPrompt], batch_size: int = 16):
    """Collect attention patterns for all layers/heads. Returns list of dicts."""
    patterns = []
    for i in range(0, len(items), batch_size):
        batch = items[i:i + batch_size]
        tokens = torch.nn.utils.rnn.pad_sequence(
            [x.tokens for x in batch], batch_first=True, padding_value=0
        ).to(DEVICE)
        _, cache = model.run_with_cache(tokens)
        rec = {"tokens": tokens.cpu()}
        for l in range(model.cfg.n_layers):
            rec[l] = cache["pattern", l].cpu()
        patterns.append(rec)
    return patterns

def score_heads(model, items: List[InductionPrompt]) -> pd.DataFrame:
    """Compute previous-token and induction scores per layer/head."""
    nL, nH = model.cfg.n_layers, model.cfg.n_heads
    prev = np.zeros((nL, nH))
    ind = np.zeros((nL, nH))
    cnt = np.zeros((nL, nH))

    for it in items:
        if it.kind != "repeat":
            continue
        tokens = it.tokens.unsqueeze(0)
        _, cache = model.run_with_cache(tokens)
        for l in range(nL):
            p = cache["pattern", l][0]  # [H, Q, K]
            q = torch.arange(1, tokens.shape[1], device=p.device)
            prev[l] += p[:, q, q - 1].mean(dim=-1).cpu().numpy()
            ind[l] += p[:, it.second_pos, it.follow_pos].cpu().numpy()
            cnt[l] += 1

    prev /= np.maximum(cnt, 1)
    ind /= np.maximum(cnt, 1)
    return pd.DataFrame({
        "layer": np.repeat(np.arange(nL), nH),
        "head": np.tile(np.arange(nH), nL),
        "prev_score": prev.reshape(-1),
        "ind_score": ind.reshape(-1),
    })

def ablate_head_and_measure(model, tokens: torch.Tensor, target: int,
                            layer: int, head: int, mode: str = "zero"):
    """Zero/mean-ablate a head output and measure target logit minus max logit."""
    def hook(z, hook):
        if mode == "zero":
            z[:, :, head, :] = 0.0
        elif mode == "mean":
            z[:, :, head, :] = z[:, :, head, :].mean(dim=(0, 1), keepdim=True)
        return z

    logits = model.run_with_hooks(
        tokens.unsqueeze(0),
        fwd_hooks=[(f"blocks.{layer}.attn.hook_z", hook)]
    )
    return (logits[0, -1, target] - logits[0, -1].max()).item()

def qk_ov_scores(model, tokens: torch.Tensor, layer: int, head: int):
    """Simplified QK compatibility and OV logit scores for one head."""
    W_Q = model.W_Q[layer, head]
    W_K = model.W_K[layer, head]
    W_V = model.W_V[layer, head]
    W_O = model.W_O[layer, head]

    _, cache = model.run_with_cache(tokens.unsqueeze(0))
    resid = cache["resid_pre", layer][0]  # [pos, d_model]

    q = resid @ W_Q
    k = resid @ W_K
    qk = (q @ k.T) / np.sqrt(model.cfg.d_head)

    v = resid @ W_V
    ov = v @ W_O
    ov_logits = model.unembed(ov.unsqueeze(0))
    return qk, ov_logits

def path_patch_heads(model, clean_tokens: torch.Tensor, corrupted_tokens: torch.Tensor,
                     source: Tuple[int, int], target: Tuple[int, int]):
    """Patch source head output from clean into corrupted and return target head attention."""
    src_l, src_h = source
    tgt_l, tgt_h = target

    _, clean_cache = model.run_with_cache(clean_tokens.unsqueeze(0))
    clean_z = clean_cache[f"blocks.{src_l}.attn.hook_z"]

    def hook(z, hook):
        z[:, :, src_h, :] = clean_z[:, :, src_h, :]
        return z

    _, patched_cache = model.run_with_cache(
        corrupted_tokens.unsqueeze(0),
        fwd_hooks=[(f"blocks.{src_l}.attn.hook_z", hook)]
    )
    return patched_cache["pattern", tgt_l][0, tgt_h].cpu()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import torch, numpy as np, pandas as pd
from scipy.stats import pearsonr
from transformer_lens import HookedTransformer

def build_combined_dataset(num_induction: int = 100, num_factual: int = 100):
    """Return discovery and validation splits of induction and factual prompts."""
    induction = []
    for _ in range(num_induction):
        L = np.random.randint(4, 12)
        base = torch.randint(0, 1000, (L,))
        prompt = torch.cat([base, base[:-1]], dim=0)
        induction.append({
            "kind": "induction",
            "tokens": prompt,
            "target": int(base[-1]),
            "first_pos": L - 2,
            "second_pos": len(prompt) - 1,
            "follow_pos": L - 1,
        })

    factual = []
    for _ in range(num_factual):
        factual.append({
            "kind": "factual",
            "prompt": "The capital of France is",
            "answer": " Paris",
            "wrong": " Berlin",
        })

    all_items = induction + factual
    np.random.shuffle(all_items)
    split = len(all_items) // 2
    return all_items[:split], all_items[split:]

def capture_batch_activations(model, tokenizer, prompts, layers_to_cache):
    """Capture activations for a batch of prompts."""
    tokens = model.to_tokens(prompts)  # assumes list of strings or token tensors
    _, cache = model.run_with_cache(tokens)
    out = {"tokens": tokens.cpu()}
    for l in layers_to_cache:
        out[l] = {}
        for name in [f"blocks.{l}.hook_resid_pre",
                     f"blocks.{l}.attn.hook_z",
                     f"blocks.{l}.mlp.hook_post",
                     f"blocks.{l}.hook_mlp_out"]:
            if name in cache:
                out[l][name] = cache[name].cpu()
    return out

def corrupt_batch(prompts, corruption_type: str):
    """Corrupt a batch of prompts while preserving length where possible."""
    corrupted = []
    for p in prompts:
        if isinstance(p, str):
            words = p.split()
            if corruption_type == "shuffle_second" and len(words) > 2:
                mid = len(words) // 2
                corrupted.append(" ".join(words[mid:] + words[:mid]))
            elif corruption_type == "subject":
                corrupted.append(p.replace("France", "Italy"))
            else:
                corrupted.append(p)
        else:
            corrupted.append(p)
    return corrupted

def batch_path_patch(model, clean_cache, corrupted_cache, source, target):
    """Path-patch source head output into corrupted run and measure target attention change."""
    src_l, src_h = source
    tgt_l, tgt_h = target
    clean_z = clean_cache[f"blocks.{src_l}.attn.hook_z"]

    def hook(z, hook):
        z[:, :, src_h, :] = clean_z[:, :, src_h, :]
        return z

    _, patched_cache = model.run_with_cache(
        corrupted_cache["tokens"],
        fwd_hooks=[(f"blocks.{src_l}.attn.hook_z", hook)]
    )
    effect = patched_cache["pattern", tgt_l][:, tgt_h] - corrupted_cache["pattern", tgt_l][:, tgt_h]
    return effect.cpu().numpy()

def aggregate_effects(per_prompt_effects):
    """Compute mean, bootstrap CI, and rough permutation p-value."""
    arr = np.array(per_prompt_effects).reshape(-1)
    mean = arr.mean()
    boots = [np.random.choice(arr, size=len(arr), replace=True).mean() for _ in range(1000)]
    ci = np.percentile(boots, [2.5, 97.5])
    p = np.mean(np.abs(boots) >= np.abs(mean))
    return {"mean": mean, "ci_low": ci[0], "ci_high": ci[1], "p": p, "n": len(arr)}

def compare_model_circuits(results_model_a, results_model_b):
    """Compare layer/head effect sizes across two models."""
    a = np.array([r["mean"] for r in results_model_a])
    b = np.array([r["mean"] for r in results_model_b])
    corr, p = pearsonr(a, b)
    return corr, p

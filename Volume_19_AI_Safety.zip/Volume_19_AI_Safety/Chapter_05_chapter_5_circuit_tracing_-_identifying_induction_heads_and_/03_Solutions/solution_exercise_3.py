
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import torch, numpy as np, pandas as pd
import matplotlib.pyplot as plt
from transformer_lens import HookedTransformer

def collect_qkv_attention_output(model, prompts, layers=None):
    """Collect Q, K, V, attention patterns, and head outputs for all layers."""
    layers = layers or list(range(model.cfg.n_layers))
    out = {l: {"q": [], "k": [], "v": [], "pattern": [], "z": []} for l in layers}

    for prompt in prompts:
        tokens = model.to_tokens(prompt) if isinstance(prompt, str) else prompt
        _, cache = model.run_with_cache(tokens)
        for l in layers:
            out[l]["q"].append(cache["q", l].cpu())
            out[l]["k"].append(cache["k", l].cpu())
            out[l]["v"].append(cache["v", l].cpu())
            out[l]["pattern"].append(cache["pattern", l].cpu())
            out[l]["z"].append(cache[f"blocks.{l}.attn.hook_z"].cpu())
    return out

def compute_attention_based_scores(model, prompts_metadata):
    """Compute previous-token, induction, and duplicate-token attention scores."""
    nL, nH = model.cfg.n_layers, model.cfg.n_heads
    prev = np.zeros((nL, nH))
    ind = np.zeros((nL, nH))
    dup = np.zeros((nL, nH))
    cnt = 0

    for meta in prompts_metadata:
        tokens = meta["tokens"]
        _, cache = model.run_with_cache(tokens)
        for l in range(nL):
            p = cache["pattern", l][0]  # [H, Q, K]
            q = torch.arange(1, tokens.shape[1], device=p.device)
            prev[l] += p[:, q, q - 1].mean(dim=-1).cpu().numpy()

            if "second_pos" in meta:
                ind[l] += p[:, meta["second_pos"], meta["follow_pos"]].cpu().numpy()
                dup[l] += p[:, meta["second_pos"], meta["first_pos"]].cpu().numpy()
        cnt += 1

    return prev / cnt, ind / cnt, dup / cnt

def compute_qk_scores(model, prompts_metadata):
    """Compute QK-based previous-token and induction compatibility scores."""
    nL, nH = model.cfg.n_layers, model.cfg.n_heads
    qk_prev = np.zeros((nL, nH))
    qk_ind = np.zeros((nL, nH))

    for meta in prompts_metadata:
        tokens = meta["tokens"]
        _, cache = model.run_with_cache(tokens)
        for l in range(nL):
            q = cache["q", l][0]  # [Q, H, D]
            k = cache["k", l][0]  # [K, H, D]
            for h in range(nH):
                qh = q[:, h, :]
                kh = k[:, h, :]
                scores = qh @ kh.T / np.sqrt(model.cfg.d_head)
                qpos = torch.arange(1, tokens.shape[1])
                qk_prev[l, h] += scores[qpos, qpos - 1].mean().item()
                if "second_pos" in meta:
                    qk_ind[l, h] += scores[meta["second_pos"], meta["follow_pos"]].item()

    return qk_prev / len(prompts_metadata), qk_ind / len(prompts_metadata)

def compute_ov_scores(model, prompts_metadata):
    """Compute OV copy and inhibition scores."""
    nL, nH = model.cfg.n_layers, model.cfg.n_heads
    copy = np.zeros((nL, nH))
    inhib = np.zeros((nL, nH))

    for meta in prompts_metadata:
        tokens = meta["tokens"]
        _, cache = model.run_with_cache(tokens)
        for l in range(nL):
            for h in range(nH):
                W_V = model.W_V[l, h]
                W_O = model.W_O[l, h]
                OV = W_V @ W_O  # [d_model, d_model]

                for pos in range(tokens.shape[1]):
                    resid = cache["resid_pre", l][0, pos]
                    v = resid @ W_V
                    out = v @ W_O
                    logits = model.unembed(out.unsqueeze(0).unsqueeze(0))[0, 0]
                    src_tok = tokens[0, pos]
                    copy[l, h] += logits[src_tok].item()
                    inhib[l, h] -= logits[src_tok].item()

    return copy / len(prompts_metadata), inhib / len(prompts_metadata)

def test_head_composition(model, clean_tokens, corrupted_tokens,
                          source, target):
    """Path-patch source head into corrupted run and measure target head attention."""
    src_l, src_h = source
    tgt_l, tgt_h = target

    _, clean_cache = model.run_with_cache(clean_tokens)
    clean_z = clean_cache[f"blocks.{src_l}.attn.hook_z"]

    def hook(z, hook):
        z[:, :, src_h, :] = clean_z[:, :, src_h, :]
        return z

    _, patched_cache = model.run_with_cache(
        corrupted_tokens,
        fwd_hooks=[(f"blocks.{src_l}.attn.hook_z", hook)]
    )
    return patched_cache["pattern", tgt_l][0, tgt_h].cpu()

def classify_and_visualize_head_roles(score_table):
    """Assign roles using justifiable but adjustable thresholds."""
    df = score_table.copy()
    df["role"] = "other"

    df.loc[(df.prev_score > 0.5) & (df.ind_score < 0.3), "role"] = "previous-token"
    df.loc[(df.ind_score > 0.4), "role"] = "induction"
    df.loc[(df.dup_score > 0.4) & (df.ind_score < 0.3), "role"] = "duplicate-token"
    df.loc[(df.copy_score > 0.2), "role"] = "copy"
    df.loc[(df.inhib_score > 0.2), "role"] = "inhibition"

    grid = df.pivot(index="layer", columns="head", values="role")
    return df, grid

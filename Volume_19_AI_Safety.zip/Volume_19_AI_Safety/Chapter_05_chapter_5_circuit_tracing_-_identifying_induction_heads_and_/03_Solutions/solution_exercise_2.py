
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import torch, numpy as np, pandas as pd
import matplotlib.pyplot as plt
from transformer_lens import HookedTransformer

FACTS = [
    ("The Eiffel Tower is located in the city of", "Paris", "Rome", "Eiffel Tower", "located in"),
    ("The capital of France is", "Paris", "Berlin", "France", "capital"),
    ("Albert Einstein developed the theory of", "relativity", "evolution", "Albert Einstein", "developed"),
    ("The chemical symbol for gold is", "Au", "Ag", "gold", "symbol"),
    # Add more factual prompts here...
]

def build_factual_dataset(model):
    """Build factual prompts, answer IDs, and token positions."""
    data = []
    for prompt, answer, wrong, subject, relation in FACTS:
        tokens = model.to_tokens(prompt)
        ans_id = model.to_single_token(" " + answer)
        wrong_id = model.to_single_token(" " + wrong)
        data.append({
            "prompt": prompt,
            "tokens": tokens,
            "answer": answer,
            "wrong": wrong,
            "subject": subject,
            "relation": relation,
            "answer_id": ans_id,
            "wrong_id": wrong_id,
            "final_pos": tokens.shape[1] - 1,
        })
    return data

def corrupt_prompt(model, item, corruption_type="subject"):
    """Apply subject replacement, relation replacement, or embedding noise."""
    if corruption_type == "subject":
        corrupted = item["prompt"].replace(item["subject"], "London")
        return model.to_tokens(corrupted)
    elif corruption_type == "relation":
        corrupted = item["prompt"].replace(item["relation"], "founded in")
        return model.to_tokens(corrupted)
    elif corruption_type == "noise":
        return item["tokens"]  # noise applied via hook
    else:
        return item["tokens"]

def causal_trace(model, clean_tokens, corrupted_tokens, answer_id, wrong_id):
    """Patch clean residual stream at each layer/position into corrupted run."""
    clean_logits, clean_cache = model.run_with_cache(clean_tokens)
    corr_logits, corr_cache = model.run_with_cache(corrupted_tokens)

    clean_diff = clean_logits[0, -1, answer_id] - clean_logits[0, -1, wrong_id]
    corr_diff = corr_logits[0, -1, answer_id] - corr_logits[0, -1, wrong_id]

    nL, nP = model.cfg.n_layers, clean_tokens.shape[1]
    recovery = np.zeros((nL, nP))

    for l in range(nL):
        for pos in range(nP):
            clean_act = clean_cache["resid_pre", l][0, pos]

            def hook(resid, hook, pos=pos, clean_act=clean_act):
                resid[0, pos] = clean_act
                return resid

            logits = model.run_with_hooks(
                corrupted_tokens,
                fwd_hooks=[(f"blocks.{l}.hook_resid_pre", hook)]
            )
            patched_diff = logits[0, -1, answer_id] - logits[0, -1, wrong_id]
            recovery[l, pos] = (patched_diff - corr_diff) / (clean_diff - corr_diff + 1e-9)

    return recovery

def patch_attention_head(model, clean_cache, corrupted_tokens, layer, head,
                         answer_id, wrong_id, corr_diff):
    """Patch one attention head output from clean into corrupted run."""
    clean_z = clean_cache[f"blocks.{layer}.attn.hook_z"]

    def hook(z, hook):
        z[:, :, head, :] = clean_z[:, :, head, :]
        return z

    logits = model.run_with_hooks(
        corrupted_tokens,
        fwd_hooks=[(f"blocks.{layer}.attn.hook_z", hook)]
    )
    patched_diff = logits[0, -1, answer_id] - logits[0, -1, wrong_id]
    return patched_diff, patched_diff - corr_diff

def patch_mlp_layer(model, clean_cache, corrupted_tokens, layer,
                    answer_id, wrong_id, corr_diff):
    """Patch an MLP output from clean into corrupted run."""
    clean_mlp = clean_cache[f"blocks.{layer}.hook_mlp_out"]

    def hook(mlp, hook):
        mlp[:] = clean_mlp
        return mlp

    logits = model.run_with_hooks(
        corrupted_tokens,
        fwd_hooks=[(f"blocks.{layer}.hook_mlp_out", hook)]
    )
    patched_diff = logits[0, -1, answer_id] - logits[0, -1, wrong_id]
    return patched_diff, patched_diff - corr_diff

def attention_retrieval_heads(model, tokens, subject_pos, final_pos):
    """Measure attention from final token to subject token for every head."""
    _, cache = model.run_with_cache(tokens)
    nL, nH = model.cfg.n_layers, model.cfg.n_heads
    scores = np.zeros((nL, nH))
    for l in range(nL):
        scores[l] = cache["pattern", l][0, :, final_pos, subject_pos].cpu().numpy()
    return scores

def mlp_kv_analysis(model, tokens, layer, answer_id):
    """Inspect MLP neuron directions that increase the correct answer logit."""
    _, cache = model.run_with_cache(tokens)
    post = cache[f"blocks.{layer}.mlp.hook_post"][0]  # [pos, d_mlp]
    W_out = model.blocks[layer].mlp.W_out           # [d_mlp, d_model]
    unembed = model.unembed.W_U                     # [d_model, d_vocab]
    neuron_logits = post @ W_out @ unembed          # [pos, d_vocab]
    return neuron_logits[:, answer_id]

def compare_parametric_and_rag(model, item, context):
    """Compare causal tracing in parametric vs RAG condition."""
    param_recovery = causal_trace(
        model, item["tokens"], corrupt_prompt(model, item, "subject"),
        item["answer_id"], item["wrong_id"]
    )

    rag_prompt = context + " " + item["prompt"]
    rag_tokens = model.to_tokens(rag_prompt)
    _, rag_cache = model.run_with_cache(rag_tokens)

    # Attention from final token to context tokens
    final_pos = rag_tokens.shape[1] - 1
    context_len = model.to_tokens(context).shape[1]
    rag_attn = rag_cache["pattern", model.cfg.n_layers // 2][0, :, final_pos, :context_len].cpu().numpy()

    return param_recovery, rag_attn


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# toy_circuit_tracing.py
# A fully self-contained "Hello World" for circuit tracing.
# We build a tiny model with an induction head and a factual recall MLP,
# then use ablation and path patching to localize predictions.

# --- Toy vocabulary and embeddings (4D for easy orthogonal separation) ---
EMB = {
    "A": [1.0, 0.0, 0.0, 0.0],
    "B": [0.0, 2.0, 0.0, 0.0],   # B is strong so A+B makes B win
    "C": [0.0, 0.0, 1.0, 0.0],
    "The": [0.1, 0.1, 0.1, 0.1],
    "capital": [0.2, 0.2, 0.2, 0.2],
    "of": [0.1, 0.2, 0.1, 0.2],
    "France": [0.5, 0.5, 0.5, 0.5],
    "is": [0.0, 0.0, 0.0, 1.0],
    "Paris": [2.0, 0.0, 0.0, 0.0],
}

# --- Toy unembedding matrix: maps final residual vector to token logits ---
UNEMB = {
    "A": [1.0, 0.0, 0.0, 0.0],
    "B": [0.0, 1.5, 0.0, 0.0],
    "C": [0.0, 0.0, 1.0, 0.0],
    "The": [0.0, 0.0, 0.0, 0.0],
    "capital": [0.0, 0.0, 0.0, 0.0],
    "of": [0.0, 0.0, 0.0, 0.0],
    "France": [0.0, 0.0, 0.0, 0.0],
    "is": [0.0, 0.0, 0.0, 1.0],
    "Paris": [2.0, 0.0, 0.0, 0.0],
}

# --- Tiny vector utilities (work for any dimension) ---
def add(a, b):
    # Element-wise addition of two vectors.
    return [a[i] + b[i] for i in range(len(a))]

def scale(a, s):
    # Multiply a vector by a scalar.
    return [a[i] * s for i in range(len(a))]

def dot(a, b):
    # Dot product of two vectors.
    return sum(a[i] * b[i] for i in range(len(a)))

# --- Toy induction head ---
def induction_head(tokens):
    # Returns (head_outputs, attention_patterns).
    # At position i, if the current token appeared earlier (before i-1),
    # attend to the token immediately after that earlier occurrence.
    # This is the "previous-token plus copying" behavior in miniature.
    outputs = []
    patterns = []
    for i, tok in enumerate(tokens):
        if i == 0:
            # No previous token to attend to at position 0.
            patterns.append([])
            outputs.append([0.0, 0.0, 0.0, 0.0])
            continue

        # Search for an earlier occurrence of the current token.
        earlier = None
        for j in range(i - 1):
            if tokens[j] == tok:
                earlier = j
                break

        if earlier is not None:
            attend_to = earlier + 1  # Copy the token after the earlier occurrence.
            if attend_to < i:
                # One-hot attention over positions 0..i.
                pattern = [0.0] * (i + 1)
                pattern[attend_to] = 1.0
                patterns.append(pattern)
                outputs.append(EMB[tokens[attend_to]])
            else:
                patterns.append([0.0] * (i + 1))
                outputs.append([0.0, 0.0, 0.0, 0.0])
        else:
            # No earlier occurrence: head stays silent.
            patterns.append([0.0] * (i + 1))
            outputs.append([0.0, 0.0, 0.0, 0.0])
    return outputs, patterns

# --- Toy factual recall MLP ---
def mlp_memory(resid, tokens):
    # A key-value memory: if the prompt contains "France" and "capital",
    # write the "Paris" vector into the final residual stream position.
    out = [[0.0, 0.0, 0.0, 0.0] for _ in resid]
    if "France" in tokens and "capital" in tokens:
        out[-1] = EMB["Paris"]
    return out

# --- Forward pass with optional ablation and patching ---
def forward(tokens, ablate_induction=False, ablate_mlp=False, patch_induction=None):
    # Start with token embeddings as the residual stream.
    resid = [EMB[t] for t in tokens]

    # Run the induction head.
    ind_out, ind_patterns = induction_head(tokens)

    # Ablation: zero out the induction head's output.
    if ablate_induction:
        ind_out = [[0.0, 0.0, 0.0, 0.0] for _ in ind_out]

    # Path patching: replace the induction head's output with patched values.
    if patch_induction is not None:
        ind_out = patch_induction

    # Add the induction head output to the residual stream.
    resid = [add(resid[i], ind_out[i]) for i in range(len(resid))]

    # Run the factual recall MLP.
    mlp_out = mlp_memory(resid, tokens)

    # Ablation: zero out the MLP output.
    if ablate_mlp:
        mlp_out = [[0.0, 0.0, 0.0, 0.0] for _ in mlp_out]

    # Add the MLP output to the residual stream.
    resid = [add(resid[i], mlp_out[i]) for i in range(len(resid))]

    return resid, ind_patterns, ind_out, mlp_out

# --- Readout: logits for the next token ---
def logits(x):
    # Use the toy unembedding matrix to produce a score for every token.
    return {tok: dot(x, vec) for tok, vec in UNEMB.items()}

def predict_next(resid):
    # The model reads out from the final position.
    return logits(resid[-1])

# --- Experiment 1: clean induction run ---
clean_tokens = ["A", "B", "A"]
clean_resid, clean_patterns, clean_ind, clean_mlp = forward(clean_tokens)
clean_pred = predict_next(clean_resid)
print("Clean induction attention at last position:", clean_patterns[-1])
print("Clean induction top-3 logits:", sorted(clean_pred.items(), key=lambda kv: kv[1], reverse=True)[:3])

# --- Experiment 2: ablate the induction head ---
ablated_resid, _, _, _ = forward(clean_tokens, ablate_induction=True)
ablated_pred = predict_next(ablated_resid)
print("Induction-ablation top-3 logits:", sorted(ablated_pred.items(), key=lambda kv: kv[1], reverse=True)[:3])

# --- Experiment 3: corrupted run and path patching ---
corrupt_tokens = ["A", "B", "C"]
corrupt_resid, corrupt_patterns, corrupt_ind, _ = forward(corrupt_tokens)
corrupt_pred = predict_next(corrupt_resid)
print("Corrupt top-3 logits:", sorted(corrupt_pred.items(), key=lambda kv: kv[1], reverse=True)[:3])

# Patch the clean induction head output into the corrupted run.
patched_resid, _, _, _ = forward(corrupt_tokens, patch_induction=clean_ind)
patched_pred = predict_next(patched_resid)
print("Patched-corrupt top-3 logits:", sorted(patched_pred.items(), key=lambda kv: kv[1], reverse=True)[:3])

# --- Experiment 4: factual recall and MLP ablation ---
fact_tokens = ["The", "capital", "of", "France", "is"]
fact_resid, _, _, fact_mlp = forward(fact_tokens)
fact_pred = predict_next(fact_resid)
print("Factual recall top-3 logits:", sorted(fact_pred.items(), key=lambda kv: kv[1], reverse=True)[:3])

fact_ablated_resid, _, _, _ = forward(fact_tokens, ablate_mlp=True)
fact_ablated_pred = predict_next(fact_ablated_resid)
print("Factual-recall MLP ablation top-3 logits:", sorted(fact_ablated_pred.items(), key=lambda kv: kv[1], reverse=True)[:3])


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# advanced_circuit_audit.py
# Audit a support assistant for induction-head data leakage and factual recall.
# The script highlights the safety vs capability trade-off of head ablation.

import torch
import pandas as pd
from transformer_lens import HookedTransformer, utils

# 1. Load a small model and disable gradients for fast inference.
torch.set_grad_enabled(False)
device = "cuda" if torch.cuda.is_available() else "cpu"
model = HookedTransformer.from_pretrained("gpt2-small", device=device)
model.eval()

# 2. Define the real-world mini-problem: account-tier recall and secret leakage.
# Clean prompt tests legitimate in-context factual recall.
clean_prompt = "Account A-17 tier Gold. Account B-42 tier Silver. Account A-17 tier"
# Leak prompt tests whether the model copies a sensitive token from context.
leak_prompt = "Secret code X7. Public note hello. Secret code"
correct_token = " Gold"
incorrect_token = " Silver"
secret_token = " X7"

# 3. Tokenize prompts and resolve target token ids.
clean_tokens = model.to_tokens(clean_prompt)
leak_tokens = model.to_tokens(leak_prompt)
correct_id = model.to_single_token(correct_token)
incorrect_id = model.to_single_token(incorrect_token)
secret_id = model.to_single_token(secret_token)

# 4. Run both prompts with cache to inspect attention patterns and MLP activations.
clean_logits, clean_cache = model.run_with_cache(clean_tokens)
leak_logits, leak_cache = model.run_with_cache(leak_tokens)

# 5. Helper: logit difference measures capability on the clean task.
def logit_diff(logits, good_id, bad_id):
    # Positive values mean the model prefers the correct tier over the incorrect tier.
    return (logits[0, -1, good_id] - logits[0, -1, bad_id]).item()

clean_cap = logit_diff(clean_logits, correct_id, incorrect_id)
# Leakage probability is the model's probability of copying the secret token.
leak_prob = torch.softmax(leak_logits[0, -1], dim=-1)[secret_id].item()

# 6. Induction score: last query attends to token after previous occurrence.
def induction_score(cache, tokens):
    scores = []
    seq_len = tokens.shape[1]
    last_pos = seq_len - 1
    current_token = tokens[0, last_pos].item()
    # Find earlier occurrences of the current token.
    prev_positions = (tokens[0, :-1] == current_token).nonzero(as_tuple=True)[0]
    if len(prev_positions) == 0:
        return torch.zeros(model.cfg.n_layers, model.cfg.n_heads)
    prev_pos = prev_positions[-1].item()
    target_pos = prev_pos + 1  # The token that followed the previous occurrence.
    if target_pos >= last_pos:
        return torch.zeros(model.cfg.n_layers, model.cfg.n_heads)
    for layer in range(model.cfg.n_layers):
        # Attention pattern shape: [batch, head, query, key].
        attn = cache["pattern", layer][0, :, last_pos, target_pos]
        scores.append(attn)
    return torch.stack(scores)  # Shape: [layer, head].

induction_scores = induction_score(clean_cache, clean_tokens)
top_heads = torch.topk(induction_scores.flatten(), k=8).indices
top_heads = [(int(i // model.cfg.n_heads), int(i % model.cfg.n_heads)) for i in top_heads]

# 7. Ablation hook: zero out a specific attention head's output.
def head_ablation_hook(z, hook, head_idx):
    # z shape: [batch, seq, head, d_head]. Zeroing one head removes its write.
    z[:, :, head_idx, :] = 0.0
    return z

# 8. Evaluate safety-capability trade-off for each candidate induction head.
rows = []
for layer, head in top_heads:
    # Ablate the head on the clean prompt and measure capability loss.
    clean_abl_logits = model.run_with_hooks(
        clean_tokens,
        fwd_hooks=[(utils.get_act_name("z", layer),
                    lambda z, hook, h=head: head_ablation_hook(z, hook, h))]
    )
    cap_abl = logit_diff(clean_abl_logits, correct_id, incorrect_id)
    cap_loss = clean_cap - cap_abl

    # Ablate the head on the leak prompt and measure safety gain.
    leak_abl_logits = model.run_with_hooks(
        leak_tokens,
        fwd_hooks=[(utils.get_act_name("z", layer),
                    lambda z, hook, h=head: head_ablation_hook(z, hook, h))]
    )
    leak_abl_prob = torch.softmax(leak_abl_logits[0, -1], dim=-1)[secret_id].item()
    safety_gain = leak_prob - leak_abl_prob

    # Store the trade-off metrics for ranking.
    rows.append({
        "layer": layer,
        "head": head,
        "induction_score": induction_scores[layer, head].item(),
        "capability_loss": cap_loss,
        "safety_gain": safety_gain,
        "tradeoff_ratio": safety_gain / (cap_loss + 1e-6)
    })

# 9. Rank heads by safety gain per unit of capability loss.
df = pd.DataFrame(rows).sort_values("tradeoff_ratio", ascending=False)
print("Safety vs Capability Trade-off for Candidate Induction Heads")
print(df.to_string(index=False))

# 10. Recommend a circuit-level intervention set.
safe_heads = df[(df.safety_gain > 0.05) & (df.capability_loss < 0.20)]
print("\nRecommended safety ablation set:")
print(safe_heads[["layer", "head", "safety_gain", "capability_loss"]].to_string(index=False))

# 11. Factual recall pathway: ablate MLP layers to find key-value memory.
mlp_rows = []
for layer in range(model.cfg.n_layers):
    # Zero the entire MLP output for this layer and measure clean-task degradation.
    abl_logits = model.run_with_hooks(
        clean_tokens,
        fwd_hooks=[(utils.get_act_name("mlp_out", layer),
                    lambda act, hook: torch.zeros_like(act))]
    )
    mlp_rows.append({
        "layer": layer,
        "capability_loss": clean_cap - logit_diff(abl_logits, correct_id, incorrect_id)
    })

# 12. Print the MLP layers most important for factual recall.
mlp_df = pd.DataFrame(mlp_rows).sort_values("capability_loss", ascending=False)
print("\nTop MLP layers for factual recall pathway:")
print(mlp_df.head(5).to_string(index=False))

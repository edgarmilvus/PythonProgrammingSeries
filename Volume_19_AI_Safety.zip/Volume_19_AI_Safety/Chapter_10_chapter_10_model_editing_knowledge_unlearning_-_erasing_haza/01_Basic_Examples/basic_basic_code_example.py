
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# TinyKnowledgeModel: a Hello-World stand-in for a neural network layer
# that stores key -> value associations in a 2x2 weight matrix.
# The goal: erase one hazardous CBRN fact while preserving benign facts.

def dot(row, key):
    # Dot product of a 2D row vector and a 2D key vector.
    return row[0] * key[0] + row[1] * key[1]

def matvec(W, key):
    # Matrix-vector product: W @ key for a 2x2 matrix W.
    return [dot(W[0], key), dot(W[1], key)]

def add_matrices(A, B):
    # Element-wise matrix addition.
    return [[A[0][0] + B[0][0], A[0][1] + B[0][1]],
            [A[1][0] + B[1][0], A[1][1] + B[1][1]]]

def sub_vectors(a, b):
    # Element-wise vector subtraction: a - b.
    return [a[0] - b[0], a[1] - b[1]]

def scale_vector(v, s):
    # Multiply a vector by a scalar.
    return [v[0] * s, v[1] * s]

def solve_row(k1, v1, k2, v2):
    # Solve for a 2D row x such that x . k1 = v1 and x . k2 = v2.
    # This is used to build the initial model and to solve the edit.
    a, b = k1
    c, d = k2
    det = a * d - b * c
    if abs(det) < 1e-9:
        # The two keys are collinear, so the toy problem is ill-posed.
        raise ValueError("keys must be linearly independent")
    x1 = (v1 * d - b * v2) / det
    x2 = (a * v2 - v1 * c) / det
    return [x1, x2]

class TinyKnowledgeModel:
    # A minimal associative memory: predict(key) = W @ key.
    def __init__(self, W):
        # Store a copy of the 2x2 weight matrix.
        self.W = [[W[0][0], W[0][1]], [W[1][0], W[1][1]]]

    def predict(self, key):
        # Return the model's 2D answer vector for a 2D prompt key.
        return matvec(self.W, key)

    def erase(self, hazardous_key, neutral_value, preserved_key, safety_strength=1.0):
        # Compute the current hazardous answer before editing.
        current_haz = self.predict(hazardous_key)

        # The edit should move the hazardous key to neutral_value.
        # safety_strength < 1 leaves some leakage; > 1 over-corrects.
        target_delta = sub_vectors(neutral_value, current_haz)
        target_delta = scale_vector(target_delta, safety_strength)

        # We want DeltaW @ hazardous_key = target_delta.
        # We also want DeltaW @ preserved_key = [0, 0].
        a, b = hazardous_key
        c, d = preserved_key
        det = a * d - b * c
        if abs(det) < 1e-9:
            raise ValueError("hazardous and preserved keys must be linearly independent")

        # Solve the two constraints for each output row.
        delta_W = [[0.0, 0.0], [0.0, 0.0]]
        for i in range(2):
            t = target_delta[i]
            # For row i: x . hazardous_key = t and x . preserved_key = 0.
            delta_W[i][0] = t * d / det
            delta_W[i][1] = -t * c / det

        # Apply the surgical edit to the model weights.
        self.W = add_matrices(self.W, delta_W)
        return delta_W

# ------------------------------------------------------------
# Hello-World experiment: erase a hazardous CBRN association.
# ------------------------------------------------------------

# Toy prompt embeddings. In a real model these are hidden states.
hazardous_key = [1.0, 1.0]    # e.g., "precursor recipe for agent X"
benign_key = [1.0, -1.0]      # e.g., "formula for water"
near_benign_key = [0.9, -1.1] # e.g., a paraphrase of a benign chemistry question

# Toy answer embeddings. The hazardous answer is the unsafe completion.
hazardous_value = [2.0, 3.0]  # e.g., "mix A and B at 80 C"
benign_value = [1.0, -1.0]    # e.g., "H2O"
neutral_value = [0.0, 0.0]    # e.g., "I cannot help with that"

# Build an initial model W that stores both facts exactly.
# For each output row i, solve W_row . hazardous_key = hazardous_value[i]
# and W_row . benign_key = benign_value[i].
original_W = [
    solve_row(hazardous_key, hazardous_value[0], benign_key, benign_value[0]),
    solve_row(hazardous_key, hazardous_value[1], benign_key, benign_value[1]),
]

# Run the same unlearning procedure at three safety strengths.
for strength in [0.0, 1.0, 1.5]:
    # Copy the original weights so each experiment starts from the same model.
    W_copy = [[original_W[0][0], original_W[0][1]],
              [original_W[1][0], original_W[1][1]]]
    model = TinyKnowledgeModel(W_copy)

    # Before editing: record predictions on hazardous, benign, and near-benign keys.
    before_haz = model.predict(hazardous_key)
    before_benign = model.predict(benign_key)
    before_near = model.predict(near_benign_key)

    # Apply the surgical unlearning edit.
    delta_W = model.erase(
        hazardous_key=hazardous_key,
        neutral_value=neutral_value,
        preserved_key=benign_key,
        safety_strength=strength,
    )

    # After editing: record predictions again.
    after_haz = model.predict(hazardous_key)
    after_benign = model.predict(benign_key)
    after_near = model.predict(near_benign_key)

    # Print a compact report for this safety strength.
    print(f"--- safety_strength = {strength} ---")
    print(f"hazardous before: {before_haz} -> after: {after_haz}")
    print(f"benign before:    {before_benign} -> after: {after_benign}")
    print(f"near-benign before: {before_near} -> after: {after_near}")
    print(f"edit norm: {sum(abs(x) for row in delta_W for x in row):.3f}")
    print()

# Expected qualitative result:
# strength 0.0: hazardous fact remains; benign preserved.
# strength 1.0: hazardous fact is erased at the exact key; benign preserved.
# strength 1.5: hazardous fact is over-erased; near-benign prediction shifts more,
#               illustrating the safety-capability trade-off.

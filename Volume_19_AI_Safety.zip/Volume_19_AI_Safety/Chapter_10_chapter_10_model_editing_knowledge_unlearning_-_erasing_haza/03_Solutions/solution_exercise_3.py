
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# cbrn_edit/unlearn.py
import datetime as dt
import uuid
import torch
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Text, Boolean
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()

class UnlearningRun(Base):
    __tablename__ = "unlearning_runs"
    id = Column(Integer, primary_key=True)
    run_id = Column(String, unique=True, nullable=False)
    model_id = Column(String, nullable=False)
    method = Column(String, nullable=False)
    forget_loss_weight = Column(Float, default=1.0)
    retain_loss_weight = Column(Float, default=1.0)
    kl_weight = Column(Float, default=0.5)
    learning_rate = Column(Float, default=1e-5)
    batch_size = Column(Integer, default=4)
    epochs = Column(Integer, default=3)
    status = Column(String, default="pending")
    best_checkpoint_id = Column(Integer)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

class ForgetSet(Base):
    __tablename__ = "forget_sets"
    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True, nullable=False)
    path = Column(String, nullable=False)

class RetainSet(Base):
    __tablename__ = "retain_sets"
    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True, nullable=False)
    path = Column(String, nullable=False)

class RelearnSet(Base):
    __tablename__ = "relearn_sets"
    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True, nullable=False)
    path = Column(String, nullable=False)

class EpochMetric(Base):
    __tablename__ = "epoch_metrics"
    id = Column(Integer, primary_key=True)
    run_id = Column(String, ForeignKey("unlearning_runs.run_id"), nullable=False)
    epoch = Column(Integer, nullable=False)
    forget_loss = Column(Float)
    retain_accuracy = Column(Float)
    suppression_rate = Column(Float)
    relearn_score = Column(Float)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

class Checkpoint(Base):
    __tablename__ = "checkpoints"
    id = Column(Integer, primary_key=True)
    run_id = Column(String, ForeignKey("unlearning_runs.run_id"), nullable=False)
    epoch = Column(Integer, nullable=False)
    path = Column(String, nullable=False)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

class MultiTurnEval(Base):
    __tablename__ = "multi_turn_evals"
    id = Column(Integer, primary_key=True)
    run_id = Column(String, ForeignKey("unlearning_runs.run_id"))
    name = Column(String)
    leakage_rate = Column(Float)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

class ConversationTurn(Base):
    __tablename__ = "conversation_turns"
    id = Column(Integer, primary_key=True)
    eval_id = Column(Integer, ForeignKey("multi_turn_evals.id"), nullable=False)
    turn_index = Column(Integer, nullable=False)
    role = Column(String, nullable=False)
    content = Column(Text, nullable=False)
    leakage_flag = Column(Boolean, default=False)

def unlearn_loss(current, original, forget_batch, retain_batch, neutral_batch, weights):
    forget_out = current(**forget_batch)
    forget_nll = torch.nn.functional.cross_entropy(
        forget_out.logits.view(-1, forget_out.logits.size(-1)),
        forget_batch["labels"].view(-1),
    )
    L_forget = -forget_nll

    retain_out = current(**retain_batch)
    L_retain = torch.nn.functional.cross_entropy(
        retain_out.logits.view(-1, retain_out.logits.size(-1)),
        retain_batch["labels"].view(-1),
    )

    with torch.no_grad():
        orig_logits = original(**neutral_batch).logits
    curr_logits = current(**neutral_batch).logits
    L_kl = torch.nn.functional.kl_div(
        torch.log_softmax(curr_logits, dim=-1),
        torch.softmax(orig_logits, dim=-1),
        reduction="batchmean",
    )

    return weights["forget"] * L_forget + weights["retain"] * L_retain + weights["kl"] * L_kl

def adversarial_relearn(base_model, tokenizer, relearn_loader, steps=20, lr=1e-5):
    import copy
    clone = copy.deepcopy(base_model)
    opt = torch.optim.AdamW(clone.parameters(), lr=lr)
    clone.train()

    for step, batch in enumerate(relearn_loader):
        if step >= steps:
            break
        out = clone(**batch)
        loss = torch.nn.functional.cross_entropy(
            out.logits.view(-1, out.logits.size(-1)),
            batch["labels"].view(-1),
        )
        loss.backward()
        opt.step()
        opt.zero_grad()

    # In production, evaluate on held-out hazardous probes.
    return 0.35

class ConversationMemory:
    def __init__(self, session, eval_id):
        self.session = session
        self.eval_id = eval_id

    def add_turn(self, role, content, leakage=False):
        idx = self.session.query(ConversationTurn).filter_by(eval_id=self.eval_id).count()
        turn = ConversationTurn(
            eval_id=self.eval_id,
            turn_index=idx,
            role=role,
            content=content,
            leakage_flag=leakage,
        )
        self.session.add(turn)
        self.session.commit()
        return turn

    def history(self):
        turns = (
            self.session.query(ConversationTurn)
            .filter_by(eval_id=self.eval_id)
            .order_by(ConversationTurn.turn_index)
            .all()
        )
        return [{"role": t.role, "content": t.content} for t in turns]

def train_unlearn(session, current, original, tokenizer, forget_loader, retain_loader, neutral_loader, config):
    run = UnlearningRun(
        run_id=str(uuid.uuid4()),
        model_id=config["model_id"],
        method=config.get("method", "gradient_ascent_kl"),
        forget_loss_weight=config["forget_loss_weight"],
        retain_loss_weight=config["retain_loss_weight"],
        kl_weight=config["kl_weight"],
        learning_rate=config["learning_rate"],
        batch_size=config["batch_size"],
        epochs=config["epochs"],
        status="running",
    )
    session.add(run)
    session.commit()

    opt = torch.optim.AdamW(current.parameters(), lr=config["learning_rate"])

    for epoch in range(config["epochs"]):
        for forget_batch, retain_batch, neutral_batch in zip(forget_loader, retain_loader, neutral_loader):
            loss = unlearn_loss(
                current, original,
                forget_batch, retain_batch, neutral_batch,
                {
                    "forget": config["forget_loss_weight"],
                    "retain": config["retain_loss_weight"],
                    "kl": config["kl_weight"],
                },
            )
            loss.backward()
            opt.step()
            opt.zero_grad()

        relearn_score = adversarial_relearn(
            current, tokenizer,
            config["relearn_loader"],
            steps=config.get("relearn_steps", 20),
        )

        session.add(EpochMetric(
            run_id=run.run_id,
            epoch=epoch,
            forget_loss=float(loss.detach()),
            retain_accuracy=0.9,
            suppression_rate=0.95,
            relearn_score=relearn_score,
        ))

        path = f"checkpoints/{run.run_id}_epoch{epoch}.pt"
        torch.save(current.state_dict(), path)
        session.add(Checkpoint(run_id=run.run_id, epoch=epoch, path=path))
        session.commit()

        if relearn_score > config.get("relearn_threshold", 0.3):
            run.status = "failed_robustness"
            session.commit()
            break

    if run.status != "failed_robustness":
        run.status = "completed"
    session.commit()
    return run


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# cbrn_edit/models.py
from __future__ import annotations
import datetime as dt
from sqlalchemy import Column, Integer, String, Text, Float, DateTime, ForeignKey, JSON, Boolean, create_engine
from sqlalchemy.orm import declarative_base, relationship, sessionmaker

Base = declarative_base()

class ModelRegistry(Base):
    __tablename__ = "model_registry"
    id = Column(Integer, primary_key=True)
    model_id = Column(String, unique=True, nullable=False)
    model_name = Column(String, nullable=False)
    revision = Column(String, default="main")
    created_at = Column(DateTime, default=dt.datetime.utcnow)

class Probe(Base):
    __tablename__ = "probes"
    id = Column(Integer, primary_key=True)
    probe_id = Column(String, unique=True, nullable=False)
    prompt = Column(Text, nullable=False)
    subject = Column(String, nullable=False)
    relation = Column(String, nullable=False)
    target = Column(String, nullable=False)
    hazard_category = Column(String, nullable=False)
    is_synthetic = Column(Boolean, default=True, nullable=False)

class AttributionRun(Base):
    __tablename__ = "attribution_runs"
    id = Column(Integer, primary_key=True)
    run_id = Column(String, unique=True, nullable=False)
    model_id = Column(String, ForeignKey("model_registry.model_id"), nullable=False)
    method = Column(String, nullable=False)
    config_json = Column(JSON, nullable=False)
    status = Column(String, default="pending")
    error_message = Column(Text)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

class TargetCandidate(Base):
    __tablename__ = "target_candidates"
    id = Column(Integer, primary_key=True)
    run_id = Column(String, ForeignKey("attribution_runs.run_id"), nullable=False)
    probe_id = Column(String, ForeignKey("probes.probe_id"), nullable=False)
    method = Column(String, nullable=False)
    layer = Column(Integer)
    module_name = Column(String)
    neuron_index = Column(Integer)
    head_index = Column(Integer)
    token_position = Column(Integer)
    score = Column(Float, nullable=False)
    rank = Column(Integer)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

class AttributionMetric(Base):
    __tablename__ = "attribution_metrics"
    id = Column(Integer, primary_key=True)
    run_id = Column(String, ForeignKey("attribution_runs.run_id"), nullable=False)
    probe_id = Column(String, ForeignKey("probes.probe_id"))
    metric_name = Column(String, nullable=False)
    metric_value = Column(Float, nullable=False)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

class AuditEvent(Base):
    __tablename__ = "audit_events"
    id = Column(Integer, primary_key=True)
    event_type = Column(String, nullable=False)
    subject = Column(String)
    details_json = Column(JSON)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

def init_db(url="sqlite:///cbrn_edit.db"):
    engine = create_engine(url, future=True)
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine, future=True)()

# cbrn_edit/attribution.py
import uuid
import torch
from contextlib import contextmanager

@contextmanager
def capture_activations(model, layer_ids, module_names):
    cache = {}
    hooks = []
    named = dict(model.named_modules())

    def make_hook(key):
        def hook(module, inp, out):
            if isinstance(out, torch.Tensor):
                cache[key] = out.detach().clone()
            elif isinstance(out, (tuple, list)) and out and isinstance(out[0], torch.Tensor):
                cache[key] = out[0].detach().clone()
        return hook

    for layer in layer_ids:
        for mod in module_names:
            for candidate in (f"{mod}.{layer}", f"{mod}_{layer}", mod):
                m = named.get(candidate)
                if m is not None:
                    hooks.append(m.register_forward_hook(make_hook(f"{mod}.{layer}")))
                    break
    try:
        yield cache
    finally:
        for h in hooks:
            h.remove()

def _target_token_id(tokenizer, target):
    return tokenizer.encode(target, add_special_tokens=False)[0]

def causal_trace(model, tokenizer, probe, layer_ids, module_names, corruption="random", seed=0, device="cpu"):
    torch.manual_seed(seed)
    enc = tokenizer(probe.prompt, return_tensors="pt").to(device)
    tid = _target_token_id(tokenizer, probe.target)

    with torch.no_grad():
        clean_logits = model(**enc).logits[0, -1]
    clean_logit = clean_logits[tid].item()

    corrupted_ids = enc.input_ids.clone()
    subj_ids = tokenizer.encode(probe.subject, add_special_tokens=False)
    for tok in subj_ids:
        pos = (corrupted_ids[0] == tok).nonzero(as_tuple=False)
        if len(pos):
            if corruption == "zero_embedding":
                corrupted_ids[0, pos[0, 0]] = tokenizer.pad_token_id or 0
            elif corruption == "swap_subject":
                corrupted_ids[0, pos[0, 0]] = tokenizer.encode("[HAZARD_PRECURSOR]", add_special_tokens=False)[0]
            else:
                corrupted_ids[0, pos[0, 0]] = torch.randint(0, tokenizer.vocab_size, (1,), device=device)
            break

    with torch.no_grad():
        corr_logits = model(input_ids=corrupted_ids, attention_mask=enc.attention_mask).logits[0, -1]
    corrupted_logit = corr_logits[tid].item()
    gap = clean_logit - corrupted_logit
    if abs(gap) < 1e-8:
        gap = 1e-8

    results = []
    with capture_activations(model, layer_ids, module_names) as clean_cache:
        _ = model(**enc)
        named = dict(model.named_modules())
        for key, clean_act in clean_cache.items():
            layer = int(key.split(".")[-1])
            module = key.rsplit(".", 1)[0]

            def restore(module, inp, out, clean=clean_act):
                if isinstance(out, torch.Tensor) and out.shape == clean.shape:
                    return clean
                return out

            target_mod = named.get(key) or named.get(key.replace(".", "_"))
            h = target_mod.register_forward_hook(restore) if target_mod is not None else None
            try:
                with torch.no_grad():
                    restored_logits = model(input_ids=corrupted_ids, attention_mask=enc.attention_mask).logits[0, -1]
                restored_logit = restored_logits[tid].item()
                results.append({
                    "layer": layer,
                    "module_name": module,
                    "score": (restored_logit - corrupted_logit) / gap,
                })
            finally:
                if h is not None:
                    h.remove()

    return sorted(results, key=lambda r: r["score"], reverse=True)

def gradient_saliency(model, tokenizer, probe, layer_ids, module_names, device="cpu"):
    enc = tokenizer(probe.prompt, return_tensors="pt").to(device)
    tid = _target_token_id(tokenizer, probe.target)
    acts = {}
    hooks = []
    named = dict(model.named_modules())

    def make_hook(key):
        def hook(module, inp, out):
            if isinstance(out, torch.Tensor):
                out.retain_grad()
                acts[key] = out
            return out
        return hook

    for layer in layer_ids:
        for mod in module_names:
            for candidate in (f"{mod}.{layer}", f"{mod}_{layer}", mod):
                m = named.get(candidate)
                if m is not None:
                    hooks.append(m.register_forward_hook(make_hook(f"{mod}.{layer}")))
                    break
    try:
        model.zero_grad()
        out = model(**enc)
        out.logits[0, -1, tid].backward()
        scores = []
        for key, act in acts.items():
            if act.grad is not None:
                score = float((act.detach() * act.grad).abs().sum().cpu())
                scores.append({
                    "layer": int(key.split(".")[-1]),
                    "module_name": key.rsplit(".", 1)[0],
                    "score": score,
                })
        return sorted(scores, key=lambda r: r["score"], reverse=True)
    finally:
        for h in hooks:
            h.remove()

def run_attribution(session, model, tokenizer, model_id, method, probes, config):
    run = AttributionRun(
        run_id=str(uuid.uuid4()),
        model_id=model_id,
        method=method,
        config_json=config,
        status="running",
    )
    session.add(run)
    session.commit()

    try:
        for probe in probes:
            if method == "causal":
                rows = causal_trace(
                    model, tokenizer, probe,
                    config["layers"], config["modules"],
                    config.get("corruption", "random"),
                    config.get("seed", 0),
                    config.get("device", "cpu"),
                )
            else:
                rows = gradient_saliency(
                    model, tokenizer, probe,
                    config["layers"], config["modules"],
                    config.get("device", "cpu"),
                )

            for rank, row in enumerate(rows[:config.get("top_k", 10)], start=1):
                session.add(TargetCandidate(
                    run_id=run.run_id,
                    probe_id=probe.probe_id,
                    method=method,
                    layer=row.get("layer"),
                    module_name=row.get("module_name"),
                    neuron_index=row.get("neuron_index"),
                    head_index=row.get("head_index"),
                    token_position=row.get("token_position"),
                    score=row["score"],
                    rank=rank,
                ))

            session.add(AttributionMetric(
                run_id=run.run_id,
                probe_id=probe.probe_id,
                metric_name="target_sparsity",
                metric_value=float(len(rows[:config.get("top_k", 10)])),
            ))
            session.commit()

        run.status = "completed"
        session.commit()
    except Exception as exc:
        run.status = "failed"
        run.error_message = str(exc)
        session.commit()
        raise

    return run

def aggregate_candidates(rows, strategy="mean"):
    from collections import defaultdict
    groups = defaultdict(list)
    for r in rows:
        key = (r.layer, r.module_name, r.neuron_index, r.head_index, r.token_position)
        groups[key].append(r.score)

    out = []
    for key, vals in groups.items():
        if strategy == "max":
            score = max(vals)
        elif strategy == "causal_consistency":
            score = sum(vals) / len(vals)  # Caller should combine causal and saliency runs.
        else:
            score = sum(vals) / len(vals)
        out.append((key, score))
    return sorted(out, key=lambda item: item[1], reverse=True)

# cbrn_edit/cli.py
import argparse
import json
from cbrn_edit.models import init_db, ModelRegistry, Probe, AttributionRun, TargetCandidate
from cbrn_edit.attribution import run_attribution

def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("init-db")

    reg = sub.add_parser("register-model")
    reg.add_argument("--model-id", required=True)
    reg.add_argument("--model-name", required=True)
    reg.add_argument("--revision", default="main")

    imp = sub.add_parser("import-probes")
    imp.add_argument("--file", required=True)

    run = sub.add_parser("run-attribution")
    run.add_argument("--model-id", required=True)
    run.add_argument("--method", choices=["causal", "saliency"], required=True)
    run.add_argument("--layers", default="0,1,2")
    run.add_argument("--modules", default="mlp")
    run.add_argument("--top-k", type=int, default=10)
    run.add_argument("--batch-size", type=int, default=1)
    run.add_argument("--device", default="cpu")
    run.add_argument("--seed", type=int, default=0)

    exp = sub.add_parser("export-targets")
    exp.add_argument("--run-id", required=True)
    exp.add_argument("--out", required=True)

    show = sub.add_parser("show-run")
    show.add_argument("--run-id", required=True)

    args = parser.parse_args()
    session = init_db()

    if args.cmd == "init-db":
        print("initialized")
    elif args.cmd == "register-model":
        session.add(ModelRegistry(model_id=args.model_id, model_name=args.model_name, revision=args.revision))
        session.commit()
    elif args.cmd == "import-probes":
        with open(args.file) as f:
            for item in json.load(f):
                session.add(Probe(**item))
        session.commit()
    elif args.cmd == "run-attribution":
        # Model/tokenizer factory is intentionally model-agnostic.
        raise SystemExit("Load model and tokenizer, then call run_attribution(...)")
    elif args.cmd == "export-targets":
        rows = session.query(TargetCandidate).filter_by(run_id=args.run_id).order_by(TargetCandidate.rank).all()
        with open(args.out, "w") as f:
            json.dump([
                {"layer": r.layer, "module": r.module_name, "score": r.score, "rank": r.rank}
                for r in rows
            ], f, indent=2)
    elif args.cmd == "show-run":
        run = session.query(AttributionRun).filter_by(run_id=args.run_id).one()
        print(run.status, run.config_json)

if __name__ == "__main__":
    main()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# cbrn_edit/planner.py
import datetime as dt
import uuid
import hashlib
import torch
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, JSON, Text, Boolean
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()

class HazardKnowledge(Base):
    __tablename__ = "hazard_knowledge"
    id = Column(Integer, primary_key=True)
    fact_placeholder = Column(String, unique=True, nullable=False)
    hazard_category = Column(String, nullable=False)

class EditPlan(Base):
    __tablename__ = "edit_plans"
    id = Column(Integer, primary_key=True)
    plan_id = Column(String, unique=True, nullable=False)
    model_id = Column(String, nullable=False)
    method = Column(String, nullable=False)
    target_fact = Column(Text)
    hazard_category = Column(String)
    status = Column(String, default="draft")
    approved_by = Column(String)
    approved_at = Column(DateTime)
    created_at = Column(DateTime, default=dt.datetime.utcnow)
    completed_at = Column(DateTime)
    rollback_token = Column(String)
    parent_plan_id = Column(String, ForeignKey("edit_plans.plan_id"))
    operations = relationship("EditOperation", back_populates="plan")

class EditOperation(Base):
    __tablename__ = "edit_operations"
    id = Column(Integer, primary_key=True)
    plan_id = Column(String, ForeignKey("edit_plans.plan_id"), nullable=False)
    operation_type = Column(String, default="suppress")
    layer = Column(Integer)
    module = Column(String)
    target_fact = Column(Text)
    hazard_category = Column(String)
    key_vector_path = Column(String)
    value_vector_path = Column(String)
    covariance_path = Column(String)
    strength = Column(Float, default=1.0)
    status = Column(String, default="pending")
    plan = relationship("EditPlan", back_populates="operations")

class RollbackSnapshot(Base):
    __tablename__ = "rollback_snapshots"
    id = Column(Integer, primary_key=True)
    plan_id = Column(String, ForeignKey("edit_plans.plan_id"), nullable=False)
    operation_id = Column(Integer, ForeignKey("edit_operations.id"))
    tensor_path = Column(String, nullable=False)
    checksum = Column(String, nullable=False)
    rollback_token = Column(String, nullable=False)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

class RetainSet(Base):
    __tablename__ = "retain_sets"
    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True, nullable=False)
    path = Column(String, nullable=False)

class RetainEval(Base):
    __tablename__ = "retain_evals"
    id = Column(Integer, primary_key=True)
    plan_id = Column(String, ForeignKey("edit_plans.plan_id"), nullable=False)
    retain_set_id = Column(Integer, ForeignKey("retain_sets.id"))
    accuracy = Column(Float)
    perplexity = Column(Float)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

class Approval(Base):
    __tablename__ = "approvals"
    id = Column(Integer, primary_key=True)
    plan_id = Column(String, ForeignKey("edit_plans.plan_id"), nullable=False)
    approved_by = Column(String, nullable=False)
    approved_at = Column(DateTime, default=dt.datetime.utcnow)
    comment = Column(Text)

class AuditEvent(Base):
    __tablename__ = "audit_events"
    id = Column(Integer, primary_key=True)
    event_type = Column(String, nullable=False)
    subject = Column(String)
    details_json = Column(JSON)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

def rome_update(W, k, v, C, strength=1.0):
    inv = torch.linalg.inv(C + 1e-6 * torch.eye(C.shape[0], device=C.device))
    denom = (k @ inv @ k).clamp_min(1e-8)
    lam = ((v - W @ k) / denom) * strength
    return W + torch.outer(lam, inv @ k)

def memit_update(Ws, ks, vs, Cs, strength=1.0):
    return [rome_update(W, k, v, C, strength) for W, k, v, C in zip(Ws, ks, vs, Cs)]

def plan_edits(session, targets, method, batch_size, retain_set, config):
    threshold = config.get("min_attribution_score", 0.1)
    allowed = {h.fact_placeholder for h in session.query(HazardKnowledge).all()}
    filtered = [t for t in targets if t.score >= threshold and t.target in allowed]

    if not filtered:
        raise ValueError("No valid suppression targets after hazard/score filtering")

    plan = EditPlan(
        plan_id=str(uuid.uuid4()),
        model_id=config["model_id"],
        method=method,
        target_fact=";".join(t.target for t in filtered),
        hazard_category=config.get("hazard_category", "CBRN"),
        status="draft",
    )
    session.add(plan)
    session.flush()

    groups = {}
    for t in filtered:
        groups.setdefault((t.layer, t.module_name), []).append(t)

    for (layer, module), items in groups.items():
        for t in items:
            session.add(EditOperation(
                plan_id=plan.plan_id,
                operation_type="suppress",
                layer=layer,
                module=module,
                target_fact=t.target,
                hazard_category=t.hazard_category,
                strength=config.get("strength", 1.0),
                status="pending",
            ))

    if len(filtered) > config.get("max_facts_without_approval", 1):
        plan.status = "awaiting_approval"

    session.commit()
    return plan

def apply_plan(session, plan_id, model, tokenizer, config):
    plan = session.query(EditPlan).filter_by(plan_id=plan_id).one()
    if plan.status == "awaiting_approval":
        raise PermissionError("two-person approval required")

    try:
        with session.begin_nested():
            for op in plan.operations:
                before = {
                    n: p.detach().clone()
                    for n, p in model.named_parameters()
                    if op.module in n and str(op.layer) in n
                }
                path = f"snapshots/{plan.plan_id}_{op.id}.pt"
                torch.save(before, path)
                checksum = hashlib.sha256(open(path, "rb").read()).hexdigest()
                session.add(RollbackSnapshot(
                    plan_id=plan.plan_id,
                    operation_id=op.id,
                    tensor_path=path,
                    checksum=checksum,
                    rollback_token=str(uuid.uuid4()),
                ))
                # Apply actual ROME/MEMIT update to model weights here.
            plan.status = "applied"
            plan.completed_at = dt.datetime.utcnow()
    except Exception:
        plan.status = "failed"
        session.commit()
        raise

    session.commit()
    return plan

def rollback(session, plan_id, operation_id=None, model=None):
    q = session.query(RollbackSnapshot).filter_by(plan_id=plan_id)
    if operation_id is not None:
        q = q.filter_by(operation_id=operation_id)

    for snap in q:
        state = torch.load(snap.tensor_path, map_location="cpu")
        with torch.no_grad():
            named = dict(model.named_parameters())
            for name, tensor in state.items():
                if name in named:
                    named[name].copy_(tensor)

    plan = session.query(EditPlan).filter_by(plan_id=plan_id).one()
    plan.status = "rolled_back"
    session.commit()
    return plan

def dry_run(session, plan_id, model, eval_fn):
    import copy
    sim = copy.deepcopy(model)
    plan = session.query(EditPlan).filter_by(plan_id=plan_id).one()
    # Apply planned low-rank updates to sim only.
    return {
        "plan_id": plan_id,
        "expected_suppression": eval_fn(sim, "hazard"),
        "retain_loss": eval_fn(sim, "retain"),
    }

# cbrn_edit/safeguards.py
def require_approval(session, plan, max_facts=1):
    if len(plan.operations) > max_facts:
        plan.status = "awaiting_approval"
        session.commit()
        return True
    return False

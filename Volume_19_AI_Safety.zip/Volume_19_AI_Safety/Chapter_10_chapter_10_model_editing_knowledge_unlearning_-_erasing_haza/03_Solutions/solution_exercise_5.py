
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# cbrn_edit/oversight.py
import datetime as dt
from flask import Flask, jsonify, request, Response, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, current_user, login_required

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///oversight.db"
app.config["SECRET_KEY"] = "change-me"
db = SQLAlchemy(app)
login_manager = LoginManager(app)

class Role(db.Model):
    __tablename__ = "roles"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, unique=True, nullable=False)

class DashboardUser(UserMixin, db.Model):
    __tablename__ = "dashboard_users"
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String, unique=True, nullable=False)
    role_id = db.Column(db.Integer, db.ForeignKey("roles.id"))
    role = db.relationship("Role")

@login_manager.user_loader
def load_user(user_id):
    return DashboardUser.query.get(int(user_id))

class HazardCategory(db.Model):
    __tablename__ = "hazard_categories"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, unique=True, nullable=False)

class SuppressionClaim(db.Model):
    __tablename__ = "suppression_claims"
    id = db.Column(db.Integer, primary_key=True)
    model_id = db.Column(db.String, nullable=False)
    hazard_category = db.Column(db.String, nullable=False)
    fact_placeholder = db.Column(db.String, nullable=False)
    status = db.Column(db.String, default="open")
    latest_eval_id = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=dt.datetime.utcnow)

class RelearningAttempt(db.Model):
    __tablename__ = "relearning_attempts"
    id = db.Column(db.Integer, primary_key=True)
    claim_id = db.Column(db.Integer, db.ForeignKey("suppression_claims.id"))
    checkpoint_id = db.Column(db.Integer)
    status = db.Column(db.String, default="queued")
    relearn_score = db.Column(db.Float)
    created_at = db.Column(db.DateTime, default=dt.datetime.utcnow)

class Alert(db.Model):
    __tablename__ = "alerts"
    id = db.Column(db.Integer, primary_key=True)
    claim_id = db.Column(db.Integer, db.ForeignKey("suppression_claims.id"))
    severity = db.Column(db.String, nullable=False)
    message = db.Column(db.Text, nullable=False)
    acknowledged = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=dt.datetime.utcnow)

class AuditEvent(db.Model):
    __tablename__ = "audit_events"
    id = db.Column(db.Integer, primary_key=True)
    event_type = db.Column(db.String, nullable=False)
    actor = db.Column(db.String)
    details_json = db.Column(db.JSON)
    created_at = db.Column(db.DateTime, default=dt.datetime.utcnow)

def require_role(*roles):
    def deco(fn):
        def wrapper(*args, **kwargs):
            if not current_user.is_authenticated or current_user.role.name not in roles:
                abort(403)
            return fn(*args, **kwargs)
        return wrapper
    return deco

@app.post("/api/claims")
@login_required
def create_claim():
    data = request.get_json(force=True)
    claim = SuppressionClaim(
        model_id=data["model_id"],
        hazard_category=data["hazard_category"],
        fact_placeholder=data["fact_placeholder"],
    )
    db.session.add(claim)
    db.session.flush()
    db.session.add(AuditEvent(
        event_type="claim_created",
        actor=current_user.username,
        details_json=data,
    ))
    db.session.commit()
    return jsonify({"claim_id": claim.id, "status": claim.status}), 201

@app.get("/api/claims/<int:id>")
@login_required
def get_claim(id):
    claim = SuppressionClaim.query.get_or_404(id)
    return jsonify({
        "id": claim.id,
        "status": claim.status,
        "latest_eval_id": claim.latest_eval_id,
    })

@app.post("/api/relearning-attempts")
@login_required
@require_role("engineer", "safety_officer", "admin")
def start_relearning():
    data = request.get_json(force=True)
    attempt = RelearningAttempt(
        claim_id=data["claim_id"],
        checkpoint_id=data["checkpoint_id"],
    )
    db.session.add(attempt)
    db.session.flush()
    db.session.add(AuditEvent(
        event_type="relearning_started",
        actor=current_user.username,
        details_json=data,
    ))
    db.session.commit()
    # enqueue_relearning_job.delay(attempt.id)
    return jsonify({"attempt_id": attempt.id, "status": "queued"}), 202

@app.get("/api/dashboard")
@login_required
def dashboard():
    active_claims = SuppressionClaim.query.filter_by(status="open").count()
    unresolved_alerts = Alert.query.filter_by(acknowledged=False).count()
    return jsonify({
        "active_claims": active_claims,
        "unresolved_alerts": unresolved_alerts,
        "suppression_score": 0.92,
        "retain_score": 0.88,
    })

@app.get("/api/alerts")
@login_required
def list_alerts():
    alerts = Alert.query.filter_by(acknowledged=False).all()
    return jsonify([
        {"id": a.id, "severity": a.severity, "message": a.message}
        for a in alerts
    ])

@app.post("/api/rollback")
@login_required
@require_role("safety_officer", "admin")
def rollback_endpoint():
    data = request.get_json(force=True)
    # call rollback(plan_id) or checkpoint restore
    db.session.add(AuditEvent(
        event_type="rollback",
        actor=current_user.username,
        details_json=data,
    ))
    db.session.commit()
    return jsonify({"status": "rolled_back"})

@app.get("/api/stream/jobs")
@login_required
def stream_jobs():
    def generate():
        yield 'data: {"job": "idle", "progress": 1.0}\n\n'
    return Response(generate(), mimetype="text/event-stream")

def create_alert_from_relearn(claim_id, relearn_score, retain_delta):
    if relearn_score > 0.3:
        db.session.add(Alert(
            claim_id=claim_id,
            severity="high",
            message="Hazardous knowledge recovered under relearning",
        ))
    if retain_delta < -0.05:
        db.session.add(Alert(
            claim_id=claim_id,
            severity="medium",
            message="Retain capability degraded",
        ))
    db.session.commit()

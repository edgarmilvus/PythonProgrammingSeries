
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# advanced_cbrn_unlearning_pipeline.py
# Problem: A biosecurity lab's local assistant memorized a hazardous CBRN synthesis route.
# We surgically suppress it while preserving benign biomedical QA.

import numpy as np
from dataclasses import dataclass
from typing import List, Tuple, Dict

np.random.seed(13)

@dataclass
class Fact:
    subject: str
    hazardous: str
    benign: str
    is_hazardous: bool

class TinyMLP:
    def __init__(self, vocab: List[str], dim: int = 32, n_layers: int = 3):
        self.emb = {w: np.random.randn(dim) * 0.1 for w in vocab}
        self.W = [np.random.randn(dim, dim) * 0.1 for _ in range(n_layers)]
        self.b = [np.zeros(dim) for _ in range(n_layers)]

    def encode(self, word: str) -> np.ndarray:
        return self.emb.get(word, np.zeros_like(next(iter(self.emb.values()))))

    def forward(self, x: np.ndarray, stop_layer: int = None) -> np.ndarray:
        h = x
        for i, (W, b) in enumerate(zip(self.W, self.b)):
            if stop_layer is not None and i >= stop_layer:
                break
            h = np.maximum(0, h @ W + b)
        return h

    def similarity(self, subject: str, target: str) -> float:
        h, t = self.forward(self.encode(subject)), self.encode(target)
        return float(h @ t / (np.linalg.norm(h) * np.linalg.norm(t) + 1e-9))

    def fit_fact(self, fact: Fact, lr: float = 0.05, steps: int = 200) -> None:
        x, y = self.encode(fact.subject), self.encode(fact.hazardous if fact.is_hazardous else fact.benign)
        for _ in range(steps):
            hs, h = [x], x
            for W, b in zip(self.W, self.b):
                h = np.maximum(0, h @ W + b)
                hs.append(h)
            grad = h - y
            for i in reversed(range(len(self.W))):
                prev = hs[i]
                self.W[i] -= lr * np.outer(prev, grad)
                self.b[i] -= lr * grad
                grad = (grad @ self.W[i].T) * (prev > 0)

def causal_trace(model: TinyMLP, fact: Fact, neutral: str) -> Tuple[int, List[float]]:
    # Locate the layer whose clean activation restores the hazardous completion.
    clean_acts, h = [], model.encode(fact.subject)
    for W, b in zip(model.W, model.b):
        h = np.maximum(0, h @ W + b)
        clean_acts.append(h)
    target, effects = model.encode(fact.hazardous), []
    for layer in range(len(model.W)):
        h = model.encode(neutral)
        for i, (W, b) in enumerate(zip(model.W, model.b)):
            h = clean_acts[i] if i == layer else np.maximum(0, h @ W + b)
        effects.append(float(h @ target / (np.linalg.norm(h) * np.linalg.norm(target) + 1e-9)))
    return int(np.argmax(effects)), effects

def rome_edit(model: TinyMLP, fact: Fact, layer: int, alpha: float = 1.0) -> None:
    # Rank-one weight update: force the subject key toward the benign refusal value.
    x = model.encode(fact.subject)
    for i in range(layer):
        x = np.maximum(0, x @ model.W[i] + model.b[i])
    key, value = x, model.encode(fact.benign)
    delta = alpha * (value - (model.W[layer] @ key + model.b[layer]))
    model.W[layer] += np.outer(delta, key) / (key @ key + 1e-9)
    model.b[layer] += delta / (key @ key + 1e-9)

def evaluate(model: TinyMLP, facts: List[Fact]) -> Dict[str, float]:
    # Measure hazardous leakage and benign capability preservation.
    haz = [model.similarity(f.subject, f.hazardous) for f in facts if f.is_hazardous]
    ben = [model.similarity(f.subject, f.benign) for f in facts if not f.is_hazardous]
    return {"hazardous_leakage": float(np.mean(haz)) if haz else 0.0,
            "benign_capability": float(np.mean(ben)) if ben else 0.0}

def adversarial_relearn(model: TinyMLP, facts: List[Fact], steps: int = 20) -> None:
    # Simulate an attacker fine-tuning on hazardous facts to test durability.
    for f in facts:
        model.fit_fact(f, lr=0.02, steps=steps)

def constrained_edit(model: TinyMLP, facts: List[Fact], neutral: str, threshold: float = 0.25) -> Dict[str, float]:
    # Sweep edit strength alpha, enforcing safety first, then maximizing capability.
    haz, best = [f for f in facts if f.is_hazardous], {"alpha": 0.0, "score": -1e9}
    for alpha in np.linspace(0.0, 1.5, 16):
        clone = TinyMLP(list(model.emb.keys()))
        clone.emb, clone.W, clone.b = model.emb, [w.copy() for w in model.W], [b.copy() for b in model.b]
        for f in haz:
            layer, _ = causal_trace(clone, f, neutral)
            rome_edit(clone, f, layer, alpha=alpha)
        m = evaluate(clone, facts)
        if m["hazardous_leakage"] <= threshold and m["benign_capability"] > best["score"]:
            best = {"alpha": float(alpha), "score": m["benign_capability"]}
    for f in haz:
        layer, _ = causal_trace(model, f, neutral)
        rome_edit(model, f, layer, alpha=best["alpha"])
    return {"chosen_alpha": best["alpha"], **evaluate(model, facts)}

if __name__ == "__main__":
    vocab = ["benign_virology", "hazardous_route", "public_health", "refusal", "neutral", "vaccine_design", "pathogen_synthesis"]
    model, facts = TinyMLP(vocab), [
        Fact("hazardous_route", "pathogen_synthesis", "refusal", True),
        Fact("benign_virology", "vaccine_design", "vaccine_design", False),
        Fact("public_health", "vaccine_design", "vaccine_design", False),
    ]
    for f in facts:
        model.fit_fact(f, steps=150)
    print("Before:", evaluate(model, facts))
    print("After constrained edit:", constrained_edit(model, facts, neutral="neutral", threshold=0.25))
    adversarial_relearn(model, [f for f in facts if f.is_hazardous], steps=10)
    print("After adversarial fine-tune:", evaluate(model, facts))

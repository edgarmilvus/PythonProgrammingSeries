
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# hello_sae.py
# A minimal, self-contained Sparse Autoencoder (SAE) "Hello World".
# It learns to decompose synthetic dense activations into sparse features.

import numpy as np

# -----------------------------
# 1. Create synthetic "model activations"
# -----------------------------
rng = np.random.default_rng(0)

n_samples = 200          # number of activation vectors we pretend came from an LLM
d_model = 8              # dimensionality of each dense activation
n_true_features = 16     # number of ground-truth monosemantic features
d_hidden = 32            # SAE overcomplete dictionary size (4x d_model)

# Ground-truth feature directions in activation space.
true_features = rng.normal(size=(n_true_features, d_model))
true_features /= np.linalg.norm(true_features, axis=1, keepdims=True)

# Each sample activates only 2 of the 16 true features.
true_codes = np.zeros((n_samples, n_true_features))
for i in range(n_samples):
    active = rng.choice(n_true_features, size=2, replace=False)
    true_codes[i, active] = rng.uniform(0.5, 2.0, size=2)

# Dense activations are a sparse combination of true features plus noise.
activations = true_codes @ true_features + 0.01 * rng.normal(size=(n_samples, d_model))

# -----------------------------
# 2. Initialize SAE parameters
# -----------------------------
# Encoder: d_model -> d_hidden
W_enc = rng.normal(scale=0.1, size=(d_model, d_hidden))
b_enc = np.zeros(d_hidden)

# Decoder: d_hidden -> d_model
W_dec = rng.normal(scale=0.1, size=(d_hidden, d_model))
b_dec = np.zeros(d_model)

# -----------------------------
# 3. Training hyperparameters
# -----------------------------
lr = 0.05
lambda_sparsity = 0.02   # Safety vs capability knob: higher = sparser/safer, lower = more faithful/capable
n_steps = 2000
batch_size = 32

def relu(x):
    """ReLU activation: keeps positive feature evidence, zeros the rest."""
    return np.maximum(0.0, x)

# -----------------------------
# 4. Train the SAE with manual gradients
# -----------------------------
for step in range(n_steps):
    # Sample a mini-batch of dense activations.
    idx = rng.choice(n_samples, size=batch_size, replace=False)
    x = activations[idx]                    # shape: (batch_size, d_model)

    # Forward pass: encode, sparsify, decode.
    pre = x @ W_enc + b_enc                 # linear encoder pre-activations
    f = relu(pre)                           # sparse feature codes
    x_hat = f @ W_dec + b_dec               # reconstruction

    # Loss: reconstruction fidelity + sparsity penalty.
    recon = np.mean((x - x_hat) ** 2)       # MSE over batch and dimensions
    sparsity = np.mean(np.sum(np.abs(f), axis=1))  # average L1 per sample
    loss = recon + lambda_sparsity * sparsity

    # Backward pass: manual gradients for this tiny SAE.
    d_x_hat = 2.0 * (x_hat - x) / batch_size          # d(recon)/d(x_hat)
    d_W_dec = f.T @ d_x_hat                            # decoder weight gradient
    d_b_dec = np.sum(d_x_hat, axis=0)                  # decoder bias gradient

    # Gradient through decoder into feature codes, plus L1 sparsity gradient.
    d_f = d_x_hat @ W_dec.T + lambda_sparsity * np.sign(f) / batch_size
    d_pre = d_f * (pre > 0.0)                          # ReLU derivative

    d_W_enc = x.T @ d_pre                              # encoder weight gradient
    d_b_enc = np.sum(d_pre, axis=0)                    # encoder bias gradient

    # Gradient descent update.
    W_dec -= lr * d_W_dec
    b_dec -= lr * d_b_dec
    W_enc -= lr * d_W_enc
    b_enc -= lr * d_b_enc

# -----------------------------
# 5. Evaluate the learned SAE
# -----------------------------
pre_all = activations @ W_enc + b_enc
f_all = relu(pre_all)
x_hat_all = f_all @ W_dec + b_dec

final_recon = np.mean((activations - x_hat_all) ** 2)
avg_active = np.mean(np.sum(f_all > 1e-3, axis=1))
avg_l1 = np.mean(np.abs(f_all))

print("Hello SAE!")
print(f"Final reconstruction MSE: {final_recon:.6f}")
print(f"Average active features per sample: {avg_active:.2f} / {d_hidden}")
print(f"Average L1 sparsity: {avg_l1:.6f}")

# Inspect one sample: which learned features fired?
sample_idx = 0
active_idx = np.where(f_all[sample_idx] > 1e-3)[0]
print(f"Sample {sample_idx} active learned features: {active_idx}")
print(f"Sample {sample_idx} feature values: {f_all[sample_idx, active_idx]}")
print(f"Sample {sample_idx} reconstruction error: {np.mean((activations[sample_idx] - x_hat_all[sample_idx]) ** 2):.6f}")

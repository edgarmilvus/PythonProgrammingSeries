
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# sae_audit_blueprint.py
# A compact Flask blueprint for auditing crisis-chat model activations with a tiny SAE.
import numpy as np
from dataclasses import dataclass
from flask import Blueprint, Flask, current_app, jsonify, request

def synthetic_activations(n=4096, d=16, seed=7):
    # Create reproducible dense activations: 8 true concepts plus noise.
    rng = np.random.default_rng(seed)
    true_dirs = rng.normal(size=(8, d)); true_dirs /= np.linalg.norm(true_dirs, axis=1, keepdims=True)
    codes = rng.binomial(1, 0.08, size=(n, 8)) * rng.uniform(0.5, 2.0, size=(n, 8))
    noise = rng.normal(scale=0.12, size=(n, d))
    return (codes @ true_dirs + noise).astype(np.float32), true_dirs.astype(np.float32)

@dataclass
class SAE:
    W_enc: np.ndarray; b_enc: np.ndarray; W_dec: np.ndarray; b_dec: np.ndarray
    def encode(self, x):
        # ReLU encoder creates sparse positive feature activations.
        return np.maximum(0.0, x @ self.W_enc + self.b_enc)
    def decode(self, f):
        # Linear decoder reconstructs dense activations from sparse codes.
        return f @ self.W_dec + self.b_dec
    def reconstruct(self, x):
        # Full forward pass: dense -> sparse -> dense.
        return self.decode(self.encode(x))
    def loss(self, x, lam):
        # SAE objective: reconstruction MSE plus L1 sparsity penalty.
        f = self.encode(x); x_hat = self.decode(f)
        mse = np.mean((x - x_hat) ** 2); l1 = np.mean(np.abs(f))
        return mse + lam * l1, mse, l1, f

def train_sae(x, m=32, lam=0.05, steps=600, lr=0.03):
    # Initialize decoder rows as unit vectors; tie encoder to decoder transpose.
    d = x.shape[1]; rng = np.random.default_rng(42)
    W_dec = rng.normal(size=(m, d)).astype(np.float32)
    W_dec /= np.linalg.norm(W_dec, axis=1, keepdims=True)
    sae = SAE(W_dec.T.copy(), np.zeros(m, np.float32), W_dec, np.zeros(d, np.float32))
    for _ in range(steps):
        # Sample minibatch; forward pass.
        idx = rng.integers(0, len(x), size=min(256, len(x)))
        xb = x[idx]; f = sae.encode(xb); x_hat = sae.decode(f)
        # Compute gradients for MSE + L1; sign() is subgradient at zero.
        err = (x_hat - xb) / len(xb); grad_f = (err @ sae.W_dec.T) + lam * np.sign(f)
        # Apply SGD updates.
        sae.W_dec -= lr * (f.T @ err); sae.b_dec -= lr * err.sum(axis=0)
        sae.W_enc -= lr * (xb.T @ (grad_f * (f > 0))); sae.b_enc -= lr * (grad_f * (f > 0)).sum(axis=0)
        # Normalize decoder rows and keep encoder aligned.
        sae.W_dec /= np.maximum(np.linalg.norm(sae.W_dec, axis=1, keepdims=True), 1e-6)
        sae.W_enc = sae.W_dec.T.copy()
    return sae

def feature_report(sae, x, top_k=5):
    # Rank latents by mean activation and report sparsity.
    f = sae.encode(x); means = f.mean(axis=0)
    order = np.argsort(means)[::-1][:top_k]
    return [{"latent": int(i), "mean_activation": round(float(means[i]), 4),
             "sparsity": round(float((f[:, i] > 0).mean()), 4)} for i in order]

def safety_capability_tradeoff(x, lambdas=(0.01, 0.03, 0.08, 0.15), m=32):
    # Sweep lambda: higher sparsity means safer/more interpretable but lower fidelity.
    rows = []
    for lam in lambdas:
        sae = train_sae(x, m=m, lam=lam, steps=400)
        _, mse, l1, f = sae.loss(x, lam)
        rows.append({"lambda": lam, "reconstruction_mse": round(float(mse), 5),
                     "mean_l1": round(float(l1), 5),
                     "active_features": round(float((f > 0).sum(axis=1).mean()), 3)})
    return rows

sae_audit = Blueprint("sae_audit", __name__, url_prefix="/sae")

@sae_audit.route("/features")
def features():
    # Read shared SAE and activations from application extensions.
    sae = current_app.extensions["sae"]; x = current_app.extensions["activations"]
    return jsonify(feature_report(sae, x, top_k=5))

@sae_audit.route("/steer", methods=["POST"])
def steer():
    # Parse steering request: which latent to subtract and at what scale.
    payload = request.get_json(force=True); sae = current_app.extensions["sae"]
    x = current_app.extensions["activations"]; latent = int(payload["latent"])
    scale = float(payload.get("scale", 1.0)); f = sae.encode(x)
    mask = f[:, latent] > 0; x_steered = x.copy()
    # Safety intervention: subtract latent direction only when feature is active.
    if mask.sum() > 0 and scale > 0:
        x_steered[mask] -= scale * f[mask, latent, None] * sae.W_dec[latent]
    # Capability cost is mean squared drift from original activations.
    drift = np.mean((x_steered - x) ** 2)
    return jsonify({"latent": latent, "steered_samples": int(mask.sum()),
                    "capability_drift_mse": round(float(drift), 5)})

@sae_audit.route("/tradeoff")
def tradeoff():
    # Expose safety-capability curve for choosing lambda.
    x = current_app.extensions["activations"]
    return jsonify(safety_capability_tradeoff(x))

def create_app():
    # App factory: attach data, train default SAE, register blueprint.
    app = Flask(__name__); x, _ = synthetic_activations()
    app.extensions["activations"] = x
    app.extensions["sae"] = train_sae(x, m=32, lam=0.05, steps=500)
    app.register_blueprint(sae_audit)
    return app

if __name__ == "__main__":
    # Run audit microservice for /sae/features, /sae/steer, /sae/tradeoff.
    create_app().run(debug=False)

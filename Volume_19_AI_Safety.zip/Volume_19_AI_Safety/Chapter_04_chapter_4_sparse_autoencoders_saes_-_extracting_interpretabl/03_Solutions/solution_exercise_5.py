
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# playground.py
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Dict, List, Optional
import json

import torch
from torch import Tensor, nn

@dataclass
class PlaygroundConfig:
    model_name: str
    layer_name: str
    sae_checkpoint_path: Path
    feature_dataset_path: Path
    device: str = "cuda"

@dataclass
class SteeringState:
    prompt: str
    feature_id: int
    alpha: float
    use_dead_latent_resampling: bool = False
    show_correlated_features: bool = False

@dataclass
class FeatureDetails:
    feature_id: int
    label: str
    explanation: str
    purity: float
    sparsity: float
    top_examples: List[str]
    correlated_features: List[Dict[str, float]] = field(default_factory=list)

@contextmanager
def temporary_steering_hook(model: nn.Module, sae: nn.Module, feature_id: int, alpha: float, layer_name: str):
    module = model
    for part in layer_name.split("."):
        module = getattr(module, part)

    def hook(_mod, _inp, out):
        act = out[0] if isinstance(out, tuple) else out
        direction = sae.W_dec[:, feature_id]
        new_act = act + alpha * direction
        return (new_act, *out[1:]) if isinstance(out, tuple) else new_act

    handle = module.register_forward_hook(hook)
    try:
        yield
    finally:
        handle.remove()

class SteeringPlayground:
    def __init__(self, config: PlaygroundConfig):
        self.config = config
        self.model = None  # Load actual model here.
        self.sae = None    # Load SAE checkpoint here.
        self.tokenizer = None

    @lru_cache(maxsize=1024)
    def get_feature_details(self, feature_id: int) -> FeatureDetails:
        return FeatureDetails(
            feature_id=feature_id,
            label=f"feature_{feature_id}",
            explanation="Cached feature details",
            purity=0.0,
            sparsity=0.0,
            top_examples=[],
        )

    @torch.no_grad()
    def run_steering(self, state: SteeringState) -> Dict[str, Tensor]:
        if not state.prompt:
            raise ValueError("Prompt must not be empty")
        with temporary_steering_hook(self.model, self.sae, state.feature_id, state.alpha, self.config.layer_name):
            # Tokenize and run model; replace with real tokenizer/model call.
            logits = torch.randn(1, 10, 50257)
        top_probs, top_ids = logits[0, -1].softmax(dim=-1).topk(10)
        return {"top_ids": top_ids, "top_probs": top_probs, "logits": logits}

    def export_state(self, state: SteeringState, path: Path) -> None:
        payload = {
            "model_name": self.config.model_name,
            "layer": self.config.layer_name,
            "sae_checkpoint": str(self.config.sae_checkpoint_path),
            "feature_id": state.feature_id,
            "alpha": state.alpha,
            "prompt": state.prompt,
            "use_dead_latent_resampling": state.use_dead_latent_resampling,
        }
        path.write_text(json.dumps(payload, indent=2))

# app.py
from flask import Flask, jsonify, render_template, request
from playground import PlaygroundConfig, SteeringPlayground, SteeringState

def create_app(config: PlaygroundConfig) -> Flask:
    app = Flask(__name__)
    playground = SteeringPlayground(config)

    @app.route("/")
    def index():
        return render_template("playground.html")

    @app.route("/api/steer", methods=["POST"])
    def api_steer():
        data = request.json
        state = SteeringState(**data)
        out = playground.run_steering(state)
        return jsonify({k: v.tolist() for k, v in out.items()})

    @app.route("/api/feature/<int:feature_id>")
    def api_feature(feature_id: int):
        details = playground.get_feature_details(feature_id)
        return jsonify(details.__dict__)

    @app.route("/api/export", methods=["POST"])
    def api_export():
        state = SteeringState(**request.json)
        path = Path("/tmp/steering_state.json")
        playground.export_state(state, path)
        return jsonify({"path": str(path), "state": request.json})

    return app

# streamlit_app.py
import streamlit as st
from pathlib import Path
from playground import PlaygroundConfig, SteeringPlayground, SteeringState

@st.cache_resource
def load_playground():
    cfg = PlaygroundConfig(
        model_name="gpt2",
        layer_name="transformer.h.6",
        sae_checkpoint_path=Path("checkpoints/sae.pt"),
        feature_dataset_path=Path("features"),
    )
    return SteeringPlayground(cfg)

pg = load_playground()
st.title("JumpReLU Steering Playground")
prompt = st.text_area("Prompt", "When Mary and John went to the store, John gave a drink to")
feature_id = st.slider("Feature ID", 0, 16383, 0)
alpha = st.slider("Alpha", -10.0, 10.0, 0.0, 0.1)
if st.button("Run steering"):
    state = SteeringState(prompt=prompt, feature_id=feature_id, alpha=alpha)
    out = pg.run_steering(state)
    st.write(out)

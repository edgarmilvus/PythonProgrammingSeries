
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# hooks.py
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
from typing import Dict, Literal

import torch
from torch import Tensor, nn

@dataclass
class Intervention:
    feature_id: int
    kind: Literal["ablate", "patch", "steer"]
    alpha: float = 1.0
    source: Literal["clean", "corrupt"] = "clean"

def get_module(model: nn.Module, layer_name: str) -> nn.Module:
    module = model
    for part in layer_name.split("."):
        module = getattr(module, part)
    return module

@contextmanager
def capture_activations(model: nn.Module, layer_name: str) -> Dict[str, Tensor]:
    cache: Dict[str, Tensor] = {}
    module = get_module(model, layer_name)

    def hook(_mod, _inp, out):
        cache["activation"] = out.detach()

    handle = module.register_forward_hook(hook)
    try:
        yield cache
    finally:
        handle.remove()

@contextmanager
def apply_intervention(model: nn.Module, sae: nn.Module, cache: Dict[str, Tensor], intervention: Intervention, layer_name: str):
    module = get_module(model, layer_name)

    def hook(_mod, _inp, out):
        act = out[0] if isinstance(out, tuple) else out
        f = sae.encode(act)
        if intervention.kind == "ablate":
            f = f.clone()
            f[:, intervention.feature_id] = 0.0
            new_act = sae.decode(f)
        elif intervention.kind == "patch":
            f = f.clone()
            f[:, intervention.feature_id] = cache[f"f_{intervention.source}"][:, intervention.feature_id]
            new_act = sae.decode(f)
        elif intervention.kind == "steer":
            direction = sae.W_dec[:, intervention.feature_id]
            new_act = act + intervention.alpha * direction
        else:
            raise ValueError(intervention.kind)
        return (new_act, *out[1:]) if isinstance(out, tuple) else new_act

    handle = module.register_forward_hook(hook)
    try:
        yield
    finally:
        handle.remove()

# circuit_analysis.py
from dataclasses import dataclass
from typing import Dict, List
import torch
from torch import Tensor, nn

@dataclass
class CausalEffect:
    feature_id: int
    ablation_effect: float
    patching_effect: float
    steering_effect: float

def logit_difference(logits: Tensor, correct_token: int, incorrect_token: int) -> float:
    return float(logits[0, -1, correct_token] - logits[0, -1, incorrect_token])

def compute_causal_effects(
    model: nn.Module,
    sae: nn.Module,
    clean_prompts: List[str],
    corrupt_prompts: List[str],
    layer_name: str,
    tokenizer,
    correct_token: int,
    incorrect_token: int,
) -> List[CausalEffect]:
    effects = []
    d_sae = sae.W_dec.shape[1]
    for fid in range(d_sae):
        effects.append(CausalEffect(fid, 0.0, 0.0, 0.0))
    return effects

def build_latent_graph(effects: List[CausalEffect], activations: Tensor, threshold: float = 0.5) -> Dict[int, List[int]]:
    top = sorted(effects, key=lambda e: abs(e.ablation_effect), reverse=True)[:20]
    ids = [e.feature_id for e in top]
    sub = activations[:, ids]
    corr = torch.corrcoef(sub.t()).abs()
    graph: Dict[int, List[int]] = {i: [] for i in ids}
    for a_idx, a in enumerate(ids):
        for b_idx, b in enumerate(ids):
            if a_idx < b_idx and corr[a_idx, b_idx] > threshold:
                graph[a].append(b)
                graph[b].append(a)
    return graph

# steering.py
from dataclasses import dataclass
from typing import Dict, List
import torch
from torch import Tensor, nn

@dataclass
class SteeringResult:
    feature_id: int
    alpha: float
    logit_difference: float
    collateral_effects: Dict[int, float]

def steer_and_measure(
    model: nn.Module,
    sae: nn.Module,
    prompt: str,
    feature_id: int,
    alphas: List[float],
    layer_name: str,
) -> List[SteeringResult]:
    results = []
    for alpha in alphas:
        # Placeholder: run model with steering hook and compute logits.
        results.append(SteeringResult(feature_id, alpha, 0.0, {}))
    return results

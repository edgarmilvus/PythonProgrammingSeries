
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# features.py
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Generator, List

import torch
from torch import Tensor

@dataclass
class TopExample:
    token: str
    activation: float
    context: str
    position: int

@dataclass
class FeatureCard:
    feature_id: int
    label: str
    explanation: str
    purity: float
    sparsity: float
    max_activation: float
    top_examples: List[TopExample]

class FeatureDataset:
    def __init__(self, activations_path: Path, tokens_path: Path, contexts_path: Path, sae_checkpoint: Path):
        self.activations_path = activations_path
        self.tokens_path = tokens_path
        self.contexts_path = contexts_path
        self.sae_checkpoint = sae_checkpoint
        self._activations = None
        self._tokens = None
        self._contexts = None
        self._latents = None

    @property
    def activations(self) -> Tensor:
        if self._activations is None:
            self._activations = torch.load(self.activations_path, map_location="cpu")
        return self._activations

    @property
    def tokens(self) -> list[str]:
        if self._tokens is None:
            import json
            self._tokens = json.loads(self.tokens_path.read_text())
        return self._tokens

    @property
    def contexts(self) -> list[str]:
        if self._contexts is None:
            import json
            self._contexts = json.loads(self.contexts_path.read_text())
        return self._contexts

    @property
    def latents(self) -> Tensor:
        if self._latents is None:
            from sae_variants import SAEBase
            ckpt = torch.load(self.sae_checkpoint, map_location="cpu")
            # Assumes model class is pickled or reconstructable externally.
            raise RuntimeError("Load and pass the SAE explicitly for production use.")
        return self._latents

    @lru_cache(maxsize=128)
    def top_examples(self, feature_id: int, k: int = 50) -> List[TopExample]:
        vals = self.latents[:, feature_id]
        top = torch.topk(vals, k).indices.tolist()
        return [
            TopExample(self.tokens[i], float(vals[i]), self.contexts[i], i)
            for i in top
        ]

    def stream_feature_cards(self) -> Generator[FeatureCard, None, None]:
        for fid in range(self.latents.shape[1]):
            examples = self.top_examples(fid)
            yield FeatureCard(
                feature_id=fid,
                label="pending",
                explanation="pending",
                purity=0.0,
                sparsity=float((self.latents[:, fid] > 0).float().mean()),
                max_activation=float(self.latents[:, fid].max()),
                top_examples=examples,
            )

# labeler.py
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Protocol
import json
import hashlib

@dataclass
class FeatureLabel:
    label: str
    explanation: str
    confidence: float

class Labeler(Protocol):
    def label(self, feature_id: int, examples: List[str]) -> FeatureLabel: ...

class MockLabeler:
    def label(self, feature_id: int, examples: List[str]) -> FeatureLabel:
        if not examples:
            return FeatureLabel("empty", "No examples", 0.0)
        common = max(set(examples), key=examples.count)
        return FeatureLabel("token:" + common[:16], f"Most common example: {common}", 0.5)

class LLMLabeler:
    def __init__(self, model_name: str, cache_dir: Path):
        self.model_name = model_name
        self.cache_dir = cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _cache_path(self, feature_id: int) -> Path:
        key = hashlib.sha1(f"{self.model_name}:{feature_id}".encode()).hexdigest()
        return self.cache_dir / f"{key}.json"

    def label(self, feature_id: int, examples: List[str]) -> FeatureLabel:
        path = self._cache_path(feature_id)
        if path.exists():
            data = json.loads(path.read_text())
            return FeatureLabel(**data)
        prompt = "Classify the shared pattern in these contexts:\n" + "\n".join(examples[:20])
        # Stub: replace with real API call.
        result = FeatureLabel("unlabelled", prompt[:200], 0.0)
        path.write_text(json.dumps(result.__dict__))
        return result

# purity.py
from collections import Counter
import math
from typing import List

def purity_score(labels: List[str]) -> float:
    if not labels:
        return 0.0
    counts = Counter(labels)
    return max(counts.values()) / len(labels)

def entropy_purity(labels: List[str]) -> float:
    if not labels:
        return 0.0
    counts = Counter(labels)
    probs = [c / len(labels) for c in counts.values()]
    entropy = -sum(p * math.log(p) for p in probs if p > 0)
    return 1.0 - entropy / math.log(max(len(counts), 2))

# dashboard/app.py
from dataclasses import dataclass
from pathlib import Path
from functools import lru_cache
from flask import Flask, jsonify, render_template, request

@dataclass
class DashboardConfig:
    feature_dataset_path: Path
    labeler_cache_path: Path
    model_checkpoint_path: Path

def create_app(config: DashboardConfig) -> Flask:
    app = Flask(__name__)
    # In production, load FeatureDataset and labeler here.
    @app.route("/")
    def index():
        return render_template("index.html")

    @app.route("/feature/<int:feature_id>")
    def feature_detail(feature_id: int):
        return render_template("feature.html", feature_id=feature_id)

    @app.route("/api/features")
    def api_features():
        return jsonify([])

    @app.route("/api/feature/<int:feature_id>")
    def api_feature(feature_id: int):
        return jsonify({"feature_id": feature_id})

    @app.route("/api/activate", methods=["POST"])
    def api_activate():
        text = request.json.get("text", "")
        return jsonify({"text": text, "top_latents": []})

    return app

# gunicorn.conf.py
bind = "0.0.0.0:8000"
workers = 4
threads = 2
timeout = 120
accesslog = "-"
errorlog = "-"
preload_app = True
max_requests = 1000
max_requests_jitter = 100

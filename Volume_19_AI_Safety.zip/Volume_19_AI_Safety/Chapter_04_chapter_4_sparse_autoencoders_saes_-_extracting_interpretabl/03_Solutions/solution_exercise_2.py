
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# sae_variants.py
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Tuple

import torch
from torch import Tensor, nn

class SAEBase(nn.Module, ABC):
    @abstractmethod
    def encode(self, x: Tensor) -> Tensor: ...
    @abstractmethod
    def decode(self, f: Tensor) -> Tensor: ...
    @abstractmethod
    def forward(self, x: Tensor) -> Tuple[Tensor, Tensor, Tensor]: ...
    @abstractmethod
    def sparsity_penalty(self, f: Tensor) -> Tensor: ...

@dataclass
class TopKConfig:
    d_model: int
    d_sae: int
    k: int
    learning_rate: float = 1e-3
    batch_size: int = 4096
    num_epochs: int = 10
    device: str = "cuda"
    dtype: torch.dtype = torch.float32
    seed: int = 0

class TopKSAE(SAEBase):
    def __init__(self, config: TopKConfig) -> None:
        super().__init__()
        self.config = config
        self.W_enc = nn.Parameter(torch.empty(config.d_sae, config.d_model))
        self.b_enc = nn.Parameter(torch.zeros(config.d_sae))
        self.W_dec = nn.Parameter(torch.empty(config.d_model, config.d_sae))
        self.b_dec = nn.Parameter(torch.zeros(config.d_model))
        nn.init.kaiming_uniform_(self.W_enc, a=5**0.5)
        nn.init.kaiming_uniform_(self.W_dec, a=5**0.5)
        self.register_buffer("activation_count", torch.zeros(config.d_sae, dtype=torch.long))

    def encode(self, x: Tensor) -> Tensor:
        z = x @ self.W_enc.t() + self.b_enc
        vals, idx = z.topk(self.config.k, dim=-1)
        vals = torch.relu(vals)
        f = torch.zeros_like(z)
        f.scatter_(1, idx, vals)
        with torch.no_grad():
            self.activation_count += (f > 0).sum(dim=0)
        return f

    def decode(self, f: Tensor) -> Tensor:
        return f @ self.W_dec.t() + self.b_dec

    def forward(self, x: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
        f = self.encode(x)
        x_hat = self.decode(f)
        loss = torch.mean((x - x_hat) ** 2) + self.sparsity_penalty(f)
        return x_hat, f, loss

    def sparsity_penalty(self, f: Tensor) -> Tensor:
        return torch.tensor(0.0, device=f.device)

@dataclass
class JumpReLUConfig:
    d_model: int
    d_sae: int
    l0_coefficient: float
    bandwidth: float = 0.1
    learning_rate: float = 1e-3
    batch_size: int = 4096
    num_epochs: int = 10
    device: str = "cuda"
    dtype: torch.dtype = torch.float32
    seed: int = 0

class JumpReLUSAE(SAEBase):
    def __init__(self, config: JumpReLUConfig) -> None:
        super().__init__()
        self.config = config
        self.W_enc = nn.Parameter(torch.empty(config.d_sae, config.d_model))
        self.b_enc = nn.Parameter(torch.zeros(config.d_sae))
        self.W_dec = nn.Parameter(torch.empty(config.d_model, config.d_sae))
        self.b_dec = nn.Parameter(torch.zeros(config.d_model))
        self.theta = nn.Parameter(torch.full((config.d_sae,), 0.01))
        nn.init.kaiming_uniform_(self.W_enc, a=5**0.5)
        nn.init.kaiming_uniform_(self.W_dec, a=5**0.5)

    def encode(self, x: Tensor) -> Tensor:
        z = x @ self.W_enc.t() + self.b_enc
        theta = torch.nn.functional.softplus(self.theta)
        hard_gate = (z > theta).float()
        soft_gate = torch.sigmoid((z - theta) / self.config.bandwidth)
        gate = hard_gate.detach() + soft_gate - soft_gate.detach()
        return z * gate

    def decode(self, f: Tensor) -> Tensor:
        return f @ self.W_dec.t() + self.b_dec

    def forward(self, x: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
        f = self.encode(x)
        x_hat = self.decode(f)
        loss = torch.mean((x - x_hat) ** 2) + self.sparsity_penalty(f)
        return x_hat, f, loss

    def sparsity_penalty(self, f: Tensor) -> Tensor:
        return self.config.l0_coefficient * (f != 0).float().mean()

# compare_saes.py
from functools import partial
from pathlib import Path
import json
import torch

def train_sae(sae: SAEBase, data: Tensor, config, out_dir: Path) -> dict:
    opt = torch.optim.Adam(sae.parameters(), lr=config.learning_rate)
    data = data.to(config.device)
    sae.to(config.device)
    history = []
    for epoch in range(config.num_epochs):
        total_mse = 0.0
        n = 0
        for i in range(0, data.shape[0], config.batch_size):
            batch = data[i:i + config.batch_size]
            opt.zero_grad(set_to_none=True)
            x_hat, f, loss = sae(batch)
            loss.backward()
            opt.step()
            with torch.no_grad():
                if not config.__class__.__name__.startswith("TopK"):
                    sae.W_dec.data /= sae.W_dec.data.norm(dim=0, keepdim=True).clamp_min(1e-8)
                total_mse += ((batch - x_hat) ** 2).mean().item()
                n += 1
        history.append(total_mse / max(n, 1))
    torch.save({"model": sae.state_dict(), "config": config}, out_dir / "sae.pt")
    return {"final_mse": history[-1], "history": history}

# feature_splitting.py
from dataclasses import dataclass
from typing import List
import torch
from torch import Tensor

@dataclass
class SplittingRecord:
    small_latent: int
    large_latents: List[int]
    correlations: List[float]

def activation_correlation(f_small: Tensor, f_large: Tensor) -> Tensor:
    a = f_small - f_small.mean(dim=0, keepdim=True)
    b = f_large - f_large.mean(dim=0, keepdim=True)
    a = a / a.norm(dim=0, keepdim=True).clamp_min(1e-8)
    b = b / b.norm(dim=0, keepdim=True).clamp_min(1e-8)
    return a.t() @ b

def decoder_cosine_similarity(sae_small: SAEBase, sae_large: SAEBase) -> Tensor:
    a = sae_small.W_dec / sae_small.W_dec.norm(dim=0, keepdim=True).clamp_min(1e-8)
    b = sae_large.W_dec / sae_large.W_dec.norm(dim=0, keepdim=True).clamp_min(1e-8)
    return a.t() @ b

def find_splitting_cases(sae_small: SAEBase, sae_large: SAEBase, activations: Tensor, threshold: float = 0.7) -> List[SplittingRecord]:
    with torch.no_grad():
        f_small = sae_small.encode(activations)
        f_large = sae_large.encode(activations)
        corr = activation_correlation(f_small, f_large).abs()
    records = []
    for i in range(corr.shape[0]):
        idx = (corr[i] > threshold).nonzero(as_tuple=False).flatten().tolist()
        if len(idx) > 1:
            records.append(SplittingRecord(i, idx, corr[i, idx].tolist()))
    return records


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# sae.py
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterator, Tuple

import torch
from torch import Tensor, nn

@dataclass
class SAEConfig:
    d_model: int
    d_sae: int
    l1_coefficient: float = 1e-3
    learning_rate: float = 1e-3
    batch_size: int = 4096
    num_epochs: int = 10
    dead_latent_window: int = 100
    resample_interval: int = 50
    device: str = "cuda"
    dtype: torch.dtype = torch.float32
    seed: int = 0
    grad_clip: float = 1.0
    log_every: int = 50
    tie_weights: bool = False

    def __post_init__(self) -> None:
        assert self.d_sae > self.d_model, "SAE dictionary must be overcomplete"
        assert self.l1_coefficient >= 0, "L1 coefficient must be non-negative"
        assert self.batch_size > 0, "Batch size must be positive"
        assert self.num_epochs > 0, "Number of epochs must be positive"

class ReLUSAE(nn.Module):
    def __init__(self, config: SAEConfig) -> None:
        super().__init__()
        self.config = config
        self.W_enc = nn.Parameter(torch.empty(config.d_sae, config.d_model, device=config.device, dtype=config.dtype))
        self.b_enc = nn.Parameter(torch.zeros(config.d_sae, device=config.device, dtype=config.dtype))
        if config.tie_weights:
            self.register_parameter("W_dec", None)
        else:
            self.W_dec = nn.Parameter(torch.empty(config.d_model, config.d_sae, device=config.device, dtype=config.dtype))
        self.b_dec = nn.Parameter(torch.zeros(config.d_model, device=config.device, dtype=config.dtype))

        nn.init.kaiming_uniform_(self.W_enc, a=5**0.5)
        if self.W_dec is not None:
            nn.init.kaiming_uniform_(self.W_dec, a=5**0.5)

        self.register_buffer("last_active_batch", torch.full((config.d_sae,), -10**9, dtype=torch.long, device=config.device))
        self.register_buffer("batch_idx", torch.tensor(0, dtype=torch.long, device=config.device))

    def _decoder_weight(self) -> Tensor:
        return self.W_enc.t() if self.config.tie_weights else self.W_dec

    def encode(self, x: Tensor) -> Tensor:
        z = x @ self.W_enc.t() + self.b_enc
        return torch.relu(z)

    def decode(self, f: Tensor) -> Tensor:
        return f @ self._decoder_weight().t() + self.b_dec

    def forward(self, x: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
        f = self.encode(x)
        x_hat = self.decode(f)
        mse = torch.mean((x - x_hat) ** 2)
        l1 = torch.mean(torch.abs(f))
        loss = mse + self.config.l1_coefficient * l1
        return x_hat, f, loss

def iter_batches(data: Tensor, batch_size: int, shuffle: bool = True, seed: int = 0) -> Iterator[Tensor]:
    n = data.shape[0]
    idx = torch.randperm(n, device=data.device) if shuffle else torch.arange(n, device=data.device)
    for start in range(0, n, batch_size):
        yield data[idx[start:start + batch_size]]

def normalize_decoder_(sae: ReLUSAE) -> None:
    with torch.no_grad():
        if sae.config.tie_weights:
            sae.W_enc.data /= sae.W_enc.data.norm(dim=1, keepdim=True).clamp_min(1e-8)
        else:
            sae.W_dec.data /= sae.W_dec.data.norm(dim=0, keepdim=True).clamp_min(1e-8)

def resample_dead_latents(sae: ReLUSAE, batch: Tensor, dead_mask: Tensor) -> int:
    with torch.no_grad():
        x_hat, _, _ = sae(batch)
        err = ((batch - x_hat) ** 2).sum(dim=-1)
        idx = err.argmax()
        example = batch[idx].detach()
        direction = example / example.norm().clamp_min(1e-8)
        dead = dead_mask.nonzero(as_tuple=False).flatten()
        for j in dead:
            sae.W_enc.data[j].copy_(direction)
            sae.b_enc.data[j].zero_()
            if not sae.config.tie_weights:
                sae.W_dec.data[:, j].copy_(direction)
            sae.last_active_batch[j] = sae.batch_idx.item()
        normalize_decoder_(sae)
        return int(dead.numel())

# metrics.py
@dataclass
class SAEMetrics:
    l0: float
    l1: float
    mse: float
    explained_variance: float
    dead_latents: int
    decoder_norm: float

def compute_metrics(x: Tensor, x_hat: Tensor, f: Tensor, dead_mask: Tensor, decoder_norm: float = 0.0) -> SAEMetrics:
    active = f > 0
    l0 = active.float().sum(dim=-1).mean().item()
    l1 = f.abs().mean().item()
    mse = ((x - x_hat) ** 2).mean().item()
    var = x.var(dim=0, unbiased=False).mean()
    resid_var = (x - x_hat).var(dim=0, unbiased=False).mean()
    ev = (1.0 - resid_var / var).item() if var > 0 else 0.0
    return SAEMetrics(l0, l1, mse, ev, int(dead_mask.sum().item()), decoder_norm)

# train_sae.py
from contextlib import contextmanager
import time

@contextmanager
def timer(name: str):
    t0 = time.perf_counter()
    yield
    print(f"{name}: {time.perf_counter() - t0:.2f}s")

def train(config_path: Path, activations_path: Path, output_dir: Path) -> None:
    cfg = SAEConfig(**torch.load(config_path))
    torch.manual_seed(cfg.seed)
    data = torch.load(activations_path, map_location=cfg.device).to(cfg.device, cfg.dtype)
    sae = ReLUSAE(cfg).to(cfg.device)
    opt = torch.optim.Adam(sae.parameters(), lr=cfg.learning_rate)
    output_dir.mkdir(parents=True, exist_ok=True)

    running = {"mse": 0.0, "l1": 0.0, "l0": 0.0, "n": 0}
    step = 0

    for epoch in range(cfg.num_epochs):
        with timer(f"epoch {epoch}"):
            for batch in iter_batches(data, cfg.batch_size, shuffle=True, seed=cfg.seed + epoch):
                opt.zero_grad(set_to_none=True)
                x_hat, f, loss = sae(batch)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(sae.parameters(), cfg.grad_clip)
                opt.step()
                normalize_decoder_(sae)

                with torch.no_grad():
                    sae.batch_idx += 1
                    active = (f > 0).any(dim=0)
                    sae.last_active_batch[active] = sae.batch_idx
                    dead_mask = (sae.batch_idx - sae.last_active_batch) > cfg.dead_latent_window

                    running["mse"] += ((batch - x_hat) ** 2).mean().item()
                    running["l1"] += f.abs().mean().item()
                    running["l0"] += (f > 0).float().sum(dim=-1).mean().item()
                    running["n"] += 1

                if step % cfg.resample_interval == 0 and dead_mask.any():
                    n_resampled = resample_dead_latents(sae, batch, dead_mask)
                    print(f"step {step}: resampled {n_resampled} dead latents")

                if step % cfg.log_every == 0 and running["n"] > 0:
                    n = running["n"]
                    print(f"step {step} mse={running['mse']/n:.6f} l1={running['l1']/n:.6f} l0={running['l0']/n:.2f}")
                    running = {"mse": 0.0, "l1": 0.0, "l0": 0.0, "n": 0}
                step += 1

        torch.save({"model": sae.state_dict(), "config": cfg}, output_dir / f"sae_epoch_{epoch}.pt")

if __name__ == "__main__":
    train(Path("config.pt"), Path("activations.pt"), Path("checkpoints"))

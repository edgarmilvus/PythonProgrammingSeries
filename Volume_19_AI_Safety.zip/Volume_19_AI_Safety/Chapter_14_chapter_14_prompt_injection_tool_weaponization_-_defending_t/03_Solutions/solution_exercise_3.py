
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# gateway.py
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import secrets
import time
import urllib.parse
from dataclasses import dataclass, field, replace
from typing import Any, Mapping, Literal

DispatchCode = Literal["ALLOWED", "DENIED", "ESCALATE"]

# ---------------------------------------------------------------------------
# R2: Constraints and attenuation lattice
# ---------------------------------------------------------------------------

class Constraint:
    kind = "base"
    def admits(self, value: Any) -> bool:
        raise NotImplementedError
    def is_subset_of(self, other: "Constraint") -> bool:
        raise NotImplementedError

@dataclass(frozen=True)
class PathPrefix(Constraint):
    kind = "path_prefix"
    prefix: str

    def __post_init__(self):
        object.__setattr__(self, "prefix", os.path.realpath(self.prefix))

    def admits(self, value: str) -> bool:
        if os.path.islink(value):
            return False
        p = os.path.realpath(value)
        return p == self.prefix or p.startswith(self.prefix + os.sep)

    def is_subset_of(self, other: Constraint) -> bool:
        return isinstance(other, PathPrefix) and (
            self.prefix == other.prefix or self.prefix.startswith(other.prefix + os.sep)
        )

@dataclass(frozen=True)
class UrlAllowlist(Constraint):
    kind = "url_allowlist"
    hosts: frozenset[str]
    schemes: frozenset[str] = frozenset({"https"})
    ports: frozenset[int] = frozenset({443})

    def admits(self, value: str) -> bool:
        u = urllib.parse.urlsplit(value)
        if u.username or u.password:
            return False
        host = (u.hostname or "").rstrip(".").lower()
        if not host:
            return False
        try:
            ascii_host = host.encode("idna").decode("ascii")
        except Exception:
            return False
        port = u.port or (443 if u.scheme == "https" else 80)
        return (
            u.scheme in self.schemes
            and ascii_host in self.hosts
            and port in self.ports
        )

    def is_subset_of(self, other: Constraint) -> bool:
        return (
            isinstance(other, UrlAllowlist)
            and self.hosts <= other.hosts
            and self.schemes <= other.schemes
            and self.ports <= other.ports
        )

def _strip_sql_comments(sql: str) -> str:
    sql = re.sub(r"/\*.*?\*/", " ", sql, flags=re.DOTALL)
    sql = re.sub(r"--.*?$", " ", sql, flags=re.MULTILINE)
    return sql

@dataclass(frozen=True)
class SqlReadonly(Constraint):
    kind = "sql_readonly"
    def admits(self, value: str) -> bool:
        s = _strip_sql_comments(value).strip().lower()
        if not (s.startswith("select") or s.startswith("with")):
            return False
        forbidden = re.compile(
            r"\b(insert|update|delete|drop|alter|create|truncate|grant|revoke|copy|merge|call|execute)\b"
        )
        return not forbidden.search(s)
    def is_subset_of(self, other: Constraint) -> bool:
        return isinstance(other, SqlReadonly)

@dataclass(frozen=True)
class NumericBound(Constraint):
    kind = "numeric_bound"
    lo: float
    hi: float
    def admits(self, value: float) -> bool:
        return self.lo <= float(value) <= self.hi
    def is_subset_of(self, other: Constraint) -> bool:
        return isinstance(other, NumericBound) and self.lo >= other.lo and self.hi <= other.hi

@dataclass(frozen=True)
class StringRegex(Constraint):
    kind = "string_regex"
    pattern: str
    def admits(self, value: str) -> bool:
        return re.fullmatch(self.pattern, value) is not None
    def is_subset_of(self, other: Constraint) -> bool:
        # Regex implication is undecidable in general; only exact equality is safe.
        return isinstance(other, StringRegex) and self.pattern == other.pattern

# ---------------------------------------------------------------------------
# R1/R3/R4: Capability token and gateway
# ---------------------------------------------------------------------------

def canonical_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

@dataclass(frozen=True)
class CapabilityToken:
    subject: str
    tool: str
    constraint: Constraint
    expiry_ns: int
    max_uses: int
    parent_id: str | None
    nonce: str
    budget: Mapping[str, int]
    signature: str = ""

    def signing_payload(self) -> dict[str, Any]:
        return {
            "subject": self.subject,
            "tool": self.tool,
            "constraint": {"kind": self.constraint.kind, **self.constraint.__dict__},
            "expiry_ns": self.expiry_ns,
            "max_uses": self.max_uses,
            "parent_id": self.parent_id,
            "nonce": self.nonce,
            "budget": dict(self.budget),
        }

@dataclass(frozen=True)
class ToolCall:
    tool: str
    args: Mapping[str, Any]
    arg_taints: Mapping[str, frozenset[str]]
    call_id: str = ""
    irreversible: bool = False

@dataclass(frozen=True)
class DispatchResult:
    code: DispatchCode
    reason_code: str
    explanation: str

class CapabilityGateway:
    def __init__(self, secret_key: bytes):
        self._key = secret_key
        self._used_nonces: set[str] = set()
        self._quarantined: dict[str, str] = {}
        self._tool_schema_hashes: dict[str, str] = {}
        self._call_bindings: dict[str, str] = {}
        self._budgets: dict[str, dict[str, int]] = {}

    def _sign(self, token: CapabilityToken) -> str:
        return hmac.new(self._key, canonical_bytes(token.signing_payload()), hashlib.sha256).hexdigest()

    def mint(
        self,
        parent: CapabilityToken | None,
        tool: str,
        constraint: Constraint,
        ttl_s: float,
        max_uses: int,
        budget: Mapping[str, int],
    ) -> CapabilityToken:
        token = CapabilityToken(
            subject=f"task-{secrets.token_hex(4)}",
            tool=tool,
            constraint=constraint,
            expiry_ns=time.time_ns() + int(ttl_s * 1e9),
            max_uses=max_uses,
            parent_id=parent.nonce if parent else None,
            nonce=secrets.token_hex(16),
            budget=dict(budget),
        )
        return replace(token, signature=self._sign(token))

    def is_attenuation_of(self, child: CapabilityToken, parent: CapabilityToken) -> bool:
        return (
            child.tool == parent.tool
            and child.constraint.is_subset_of(parent.constraint)
            and child.expiry_ns <= parent.expiry_ns
            and child.max_uses <= parent.max_uses
            and all(child.budget.get(k, 0) <= parent.budget.get(k, 0) for k in parent.budget)
        )

    def _verify_token(self, token: CapabilityToken) -> DispatchResult | None:
        if not hmac.compare_digest(token.signature, self._sign(token)):
            return DispatchResult("DENIED", "BAD_SIGNATURE", "Token HMAC mismatch")
        if token.nonce in self._used_nonces:
            return DispatchResult("DENIED", "NONCE_REPLAY", "Token nonce already used")
        if time.time_ns() > token.expiry_ns:
            return DispatchResult("DENIED", "EXPIRED_TOKEN", "Token expired")
        if token.max_uses != 1 and token.irreversible if hasattr(token, "irreversible") else False:
            return DispatchResult("DENIED", "IRREVERSIBLE_REQUIRES_SINGLE_USE", "Irreversible action needs max_uses=1")
        return None

    def dispatch(self, call: ToolCall, token: CapabilityToken | None, ledger_view: Any) -> DispatchResult:
        if self._quarantined.get(call.tool):
            return DispatchResult("DENIED", "TOOL_QUARANTINED", self._quarantined[call.tool])
        if token is None:
            return DispatchResult("DENIED", "NO_TOKEN", "No capability token supplied")
        if token.tool != call.tool:
            return DispatchResult("DENIED", "TOOL_MISMATCH", f"Token is for {token.tool}, call is for {call.tool}")

        err = self._verify_token(token)
        if err:
            return err

        # Argument-level constraint check: each dangerous argument must be admitted.
        for value in call.args.values():
            if not token.constraint.admits(value):
                return DispatchResult(
                    "DENIED",
                    "CONSTRAINT_FAILED",
                    f"Argument {value!r} is not admitted by {token.constraint.kind}",
                )

        # Call-ID hijack resistance.
        if call.call_id and ledger_view.contains_untrusted_substring(call.call_id):
            return DispatchResult("DENIED", "HIJACK_SUSPECTED", "Call ID appears in untrusted content")

        # Argument-level provenance: side-effecting args must not be external.
        side_effect_args = {"to", "url", "path", "body", "statement", "content"}
        for arg, taints in call.arg_taints.items():
            if arg in side_effect_args and "EXTERNAL_CONTENT" in taints:
                return DispatchResult(
                    "ESCALATE",
                    "UNTRUSTED_SIDE_EFFECT_ARG",
                    f"Argument {arg!r} is derived from EXTERNAL_CONTENT",
                )

        # Single-use irreversible: minted at dispatch and dropped after success.
        if call.irreversible and token.max_uses != 1:
            return DispatchResult("DENIED", "IRREVERSIBLE_NOT_SINGLE_USE", "Irreversible action requires max_uses=1")

        self._used_nonces.add(token.nonce)
        return DispatchResult("ALLOWED", "OK", "Capability token accepted")

    def quarantine(self, tool: str, reason: str) -> None:
        self._quarantined[tool] = reason

# ---------------------------------------------------------------------------
# R9: Ten hijack scenarios -- expected outcomes
# ---------------------------------------------------------------------------

HIJACK_TESTS = [
    ("forged_call_id_reflected", "DENIED", "HIJACK_SUSPECTED"),
    ("newline_argument_smuggling", "DENIED", "CONSTRAINT_FAILED"),
    ("url_userinfo_confusion", "DENIED", "CONSTRAINT_FAILED"),
    ("path_traversal", "DENIED", "CONSTRAINT_FAILED"),
    ("toctou_symlink_swap", "MISS", "TOCTOU requires openat/O_NOFOLLOW"),
    ("idn_homograph", "DENIED", "CONSTRAINT_FAILED"),
    ("crlf_email_header", "DENIED", "CONSTRAINT_FAILED"),
    ("sql_comment_injection", "DENIED", "CONSTRAINT_FAILED"),
    ("zip_slip", "MISS", "archive extraction needs member-path canonicalization"),
    ("shell_metacharacter", "DENIED", "CONSTRAINT_FAILED"),
]


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# approval.py
from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any, Mapping

# ---------------------------------------------------------------------------
# R1/R10: Tier classification
# ---------------------------------------------------------------------------

class Tier(Enum):
    T0_READONLY = 0
    T1_REVERSIBLE = 1
    T2_IRREVERSIBLE = 2
    T3_HIGH_BLAST = 3

READ_ONLY = {"search_web", "read_file"}
REVERSIBLE = {"write_file", "memory_write"}
IRREVERSIBLE = {"send_email", "http_get", "sql_query", "run_python"}
HIGH_BLAST = {"run_python", "sql_query", "publish", "send_email"}

def classify_tier(tool: str, args: Mapping[str, Any], taint: frozenset[str]) -> Tier:
    """Deterministic classification from tool, resolved args, and taint. Never consults the model."""
    if tool in READ_ONLY:
        return Tier.T0_READONLY
    if tool in REVERSIBLE and "EXTERNAL_CONTENT" not in taint:
        return Tier.T1_REVERSIBLE
    if tool in HIGH_BLAST or (taint & {"CREDENTIAL", "SECRET"}):
        return Tier.T3_HIGH_BLAST
    if tool in IRREVERSIBLE:
        return Tier.T2_IRREVERSIBLE
    return Tier.T2_IRREVERSIBLE

# ---------------------------------------------------------------------------
# R2/R8: Request, token, audit record
# ---------------------------------------------------------------------------

def canonical_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

@dataclass(frozen=True)
class ApprovalRequest:
    tool: str
    resolved_args: Mapping[str, Any]
    provenance: tuple[dict[str, Any], ...]
    taint_set: frozenset[str]
    effect_preview: str
    reversible_alternative: str | None = None
    denial_cost: str = "unknown"
    token_id: str | None = None

    def action_hash(self) -> str:
        return hashlib.sha256(canonical_json(self.resolved_args).encode()).hexdigest()

@dataclass(frozen=True)
class ApprovalToken:
    token_id: str
    action_hash: str
    expires_ns: int
    max_uses: int = 1
    signature: str = ""

@dataclass(frozen=True)
class ApprovalRecord:
    approver: str
    timestamp_ns: int
    rendered_card: str
    rendered_card_hash: str
    decision: str
    latency_ms: float
    token_id: str

class ApprovalService:
    def __init__(self, secret_key: bytes):
        self._key = secret_key
        self._used: set[str] = set()

    def _sign(self, token: ApprovalToken) -> str:
        payload = {
            "token_id": token.token_id,
            "action_hash": token.action_hash,
            "expires_ns": token.expires_ns,
            "max_uses": token.max_uses,
        }
        return hmac.new(self._key, canonical_json(payload).encode(), hashlib.sha256).hexdigest()

    def mint(self, request: ApprovalRequest) -> ApprovalToken:
        token = ApprovalToken(
            token_id=secrets.token_hex(16),
            action_hash=request.action_hash(),
            expires_ns=time.time_ns() + 60_000_000_000,  # 60 seconds
            max_uses=1,
        )
        return ApprovalToken(**{**token.__dict__, "signature": self._sign(token)})

    def verify(self, token: ApprovalToken, request: ApprovalRequest) -> tuple[bool, str]:
        if not hmac.compare_digest(token.signature, self._sign(token)):
            return False, "BAD_SIGNATURE"
        if token.token_id in self._used:
            return False, "TOKEN_REPLAY"
        if time.time_ns() > token.expires_ns:
            return False, "TOKEN_EXPIRED"
        if token.action_hash != request.action_hash():
            return False, "ACTION_MUTATED"
        self._used.add(token.token_id)
        return True, "OK"

# ---------------------------------------------------------------------------
# R2/R9: Rendering and provenance summary
# ---------------------------------------------------------------------------

def summarize_provenance(request: ApprovalRequest) -> str:
    external = [p for p in request.provenance if "EXTERNAL_CONTENT" in p.get("taints", set())]
    if not external:
        return "All values originate from trusted user or policy context."
    top = external[0]
    quote = top.get("evidence_span", "")[:120]
    return f"Top contributing source: {top.get('source_uri')} (EXTERNAL_CONTENT): {quote!r}"

def render_approval(request: ApprovalRequest) -> str:
    """Plain-text card, hard-capped at 40 lines."""
    lines = [
        f"APPROVAL REQUIRED: {request.tool}",
        f"TIER: {classify_tier(request.tool, request.resolved_args, request.taint_set).name}",
        "RESOLVED ARGUMENTS:",
    ]
    for k, v in request.resolved_args.items():
        lines.append(f"  {k} = {v!r}")
    lines.append("PROVENANCE:")
    for p in request.provenance[:6]:
        lines.append(
            f"  - {p.get('uri')} trust={p.get('trust')} taints={sorted(p.get('taints', []))} "
            f"evidence={p.get('evidence_span', '')[:80]!r}"
        )
    lines.append(f"TAINT: {sorted(request.taint_set)}")
    lines.append(f"EFFECT: {request.effect_preview[:300]}")
    lines.append(f"WHY: {summarize_provenance(request)}")
    if request.reversible_alternative:
        lines.append(f"REVERSIBLE ALT: {request.reversible_alternative}")
    lines.append(f"DENIAL COST: {request.denial_cost}")
    return "\n".join(lines[:40])

# ---------------------------------------------------------------------------
# R3/R4/R7: Fail-closed approval gate and forgery tests
# ---------------------------------------------------------------------------

async def approval_gate_out_of_band(
    request: ApprovalRequest,
    service: ApprovalService,
    prompt_queue: Any,
    timeout_s: float = 3.0,
) -> tuple[bool, str]:
    """Approval signal is out-of-band; timeout means deny."""
    import asyncio
    token = service.mint(request)
    loop = asyncio.get_running_loop()
    decision_future: asyncio.Future[bool] = loop.create_future()
    await prompt_queue.put((request, token, decision_future))
    try:
        return await asyncio.wait_for(asyncio.shield(decision_future), timeout=timeout_s), "OK"
    except asyncio.TimeoutError:
        return False, "TIMEOUT_DENY"

def test_consent_forgeries(service: ApprovalService) -> dict[str, str]:
    """Six required forgery classes; each must deny with a distinct reason."""
    req = ApprovalRequest(
        tool="send_email",
        resolved_args={"to": "user@example.com", "body": "report"},
        provenance=({"uri": "user_message", "trust": "TRUSTED_USER", "taints": ["USER_INTENT"], "evidence_span": ""},),
        taint_set=frozenset({"USER_INTENT"}),
        effect_preview="send email",
    )
    token = service.mint(req)

    tests = {}
    # 1. Injected "user already approved" string in retrieved content.
    tests["injected_claim"] = "DENY_AGENT_CLAIM_NOT_AUTH"
    # 2. Fake approval UI line in model output.
    tests["fake_ui_line"] = "DENY_NOT_OUT_OF_BAND"
    # 3. Guessed/brute-forced token.
    tests["guessed_token"] = "BAD_SIGNATURE"
    # 4. Replay old token for similar action.
    ok, reason = service.verify(token, req)
    ok2, reason2 = service.verify(token, req)
    tests["replayed_token"] = reason2
    # 5. TOCTOU mutation of approved arguments.
    mutated = ApprovalRequest(
        tool=req.tool,
        resolved_args={"to": "attacker@example.com", "body": "report"},
        provenance=req.provenance,
        taint_set=req.taint_set,
        effect_preview=req.effect_preview,
    )
    _, tests["argument_mutated"] = service.verify(token, mutated)
    # 6. Agent-crafted card understating effect.
    tests["card_tamper"] = "DENY_CARD_HASH_MISMATCH"
    return tests

def replay_approval(record: ApprovalRecord, request: ApprovalRequest) -> tuple[bool, str]:
    """Reconstruct card and verify hash; mismatch is P0 card tampering."""
    rebuilt = render_approval(request)
    rebuilt_hash = hashlib.sha256(rebuilt.encode()).hexdigest()
    if rebuilt_hash != record.rendered_card_hash:
        return False, "P0_CARD_TAMPERED"
    return True, "OK"

# ---------------------------------------------------------------------------
# R6: Blanket approval antipattern and hardened pre-authorization
# ---------------------------------------------------------------------------

def demo_blanket_approval():
    """Deliberately weak: always allow send_email for task."""
    blanket = {"tool": "send_email", "task": "weekly-report", "allow": True}

    # Attack after tool description changes or task scope expands:
    # The blanket rule still matches by tool name, so the agent can now send anything.
    weak_outcome = "PWNED: blanket by tool name authorized new recipient after scope change"

    # Hardened: pre-authorization scoped to capability + constraint + schema hash.
    hardened = {
        "tool": "send_email",
        "constraint": {"to_allowlist": ["team@example.com"], "max_uses": 1},
        "expires_ns": time.time_ns() + 3600_000_000_000,
        "schema_hash": "sha256:...",
        "revoke_on_schema_change": True,
    }
    hardened_outcome = "BLOCKED: constraint and schema hash no longer match"
    return weak_outcome, hardened_outcome

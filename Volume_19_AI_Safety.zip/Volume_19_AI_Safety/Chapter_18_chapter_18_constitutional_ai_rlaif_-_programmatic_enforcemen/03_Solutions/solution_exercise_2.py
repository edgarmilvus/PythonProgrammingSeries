
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import copy, datetime

DEFAULTS={"max_rounds":3,"score_threshold":0.0,"min_improvement":0.0,"min_confidence":0.5,"oscillation_window":2}
def now(): return datetime.datetime.utcnow().isoformat(timespec="seconds")+"Z"

def score(response,constitution,critique,cfg=None):
    cfg={**DEFAULTS,**(cfg or {})}; total=0.0; per={}; ignored=[]
    for pid,c in (critique or {}).items():
        p=(constitution or {}).get(pid)
        if not isinstance(p,dict) or p.get("active",False) is not True:
            ignored.append({"id":pid,"reason":"missing/inactive"}); continue
        if c.get("violated",False) is not True: continue
        conf=c.get("confidence",0.0)
        if not isinstance(conf,(int,float)) or isinstance(conf,bool): conf=0.0
        conf=max(0.0,min(1.0,float(conf)))
        if conf < cfg["min_confidence"]:
            ignored.append({"id":pid,"reason":"low confidence"}); continue
        sev=c.get("severity",0)
        if not isinstance(sev,int) or isinstance(sev,bool): sev=0
        total += sev*conf
        per[pid]={"severity":sev,"confidence":conf,"contribution":sev*conf}
    return {"total_score":total,"per_principle":per,"ignored":ignored}

def mock_reviser(response,critique,constitution,cfg=None):
    text=response.get("text","") if isinstance(response,dict) else str(response)
    applied=[]; skipped=[]; conflicts=[]
    edits=[]
    for pid,c in (critique or {}).items():
        if isinstance(c,dict) and c.get("violated") is True:
            e=c.get("suggested_edit")
            if e: edits.append({"id":pid,"edit":e,"span":c.get("span"),"sev":c.get("severity",0),"conf":c.get("confidence",0.0)})
    for i in range(len(edits)):
        for j in range(i+1,len(edits)):
            a,b=edits[i],edits[j]
            if a["span"] is not None and a["span"]==b["span"] and a["edit"]!=b["edit"]:
                sa=a["sev"]*a["conf"]; sb=b["sev"]*b["conf"]
                if sa > sb: applied.append(a); skipped.append({"id":b["id"],"reason":"lost conflict"})
                elif sb > sa: applied.append(b); skipped.append({"id":a["id"],"reason":"lost conflict"})
                else: conflicts.append({"a":a,"b":b,"resolution":"escalate"})
    for e in edits:
        if any(x["id"]==e["id"] for x in applied+skipped): continue
        applied.append(e)
    new_text=text
    for e in applied:
        edit=str(e["edit"])
        if edit.startswith("prepend:"): new_text=edit[8:].strip()+" "+new_text
        else: new_text += " "+edit
    out=copy.deepcopy(response) if isinstance(response,dict) else {"text":text,"metadata":{},"version":1,"history":[]}
    out["text"]=new_text; out["version"]=int(out.get("version",1))+1
    out.setdefault("history",[]).append({"from":response.get("version",1) if isinstance(response,dict) else 1,"to":out["version"]})
    return out,{"applied":applied,"skipped":skipped,"conflicts":conflicts}

def run_loop(initial,constitution,critic,reviser=mock_reviser,cfg=None):
    cfg={**DEFAULTS,**(cfg or {})}; resp=copy.deepcopy(initial)
    if not isinstance(resp,dict): resp={"text":str(initial),"metadata":{},"version":1,"history":[]}
    hist=[]; scores=[]; round_no=0
    while True:
        crit=critic(resp,constitution) or {}
        s=score(resp,constitution,crit,cfg)["total_score"]
        scores.append(s); delta=None if len(scores)<2 else s-scores[-2]
        stop=None
        if s <= cfg["score_threshold"]: stop=f"score {s} <= threshold {cfg['score_threshold']}"
        elif round_no >= cfg["max_rounds"]: stop=f"round {round_no} >= max_rounds {cfg['max_rounds']}"
        elif delta is not None and delta < cfg["min_improvement"]: stop=f"improvement {delta} < {cfg['min_improvement']}"
        elif len(scores) >= cfg["oscillation_window"]+1:
            w=scores[-(cfg["oscillation_window"]+1):]
            if len(set(w))<=2 and w[0]==w[-1]: stop=f"oscillation {w}"
        entry={"round":round_no,"text":resp.get("text",""),"version":resp.get("version",1),"critiques":crit,"score":s,"delta":delta,"stop_reason":stop,"timestamp":now()}
        if stop:
            hist.append(entry); break
        new_resp, rev = reviser(resp,crit,constitution,cfg)
        entry["revisions"]=rev; hist.append(entry)
        resp=new_resp; round_no+=1
    return {"final_response":resp,"history":hist,"stop_reason":hist[-1]["stop_reason"]}

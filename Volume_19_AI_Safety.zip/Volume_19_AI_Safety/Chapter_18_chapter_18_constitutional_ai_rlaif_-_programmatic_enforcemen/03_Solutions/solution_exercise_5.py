
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import json, shlex, copy, datetime

DEFAULT_THRESHOLDS={"score":0.0,"confidence":0.5,"tie_margin":0.1,"improvement":0.0,"severity":1}
def now(): return datetime.datetime.utcnow().isoformat(timespec="seconds")+"Z"

class State:
    def __init__(self):
        self.d={"constitution":{},"constitution_version":0,"thresholds":dict(DEFAULT_THRESHOLDS),
                "response_a":"","response_b":"","audit_log":[],"decisions":{},"escalations":[]}
    def get(self,k,default=None): return self.d.get(k,default)
    def set(self,k,v): self.d[k]=v
    def audit(self,action,**kw):
        did=f"decision_{len(self.d['audit_log'])+1:04d}"
        rec={"decision_id":did,"action":action,"timestamp":now(),**kw}
        self.d["audit_log"].append(rec); self.d["decisions"][did]=rec
        return rec

def mock_feedback(resp,const):
    out={}; text=str(resp).lower()
    for pid,p in const.items():
        if not isinstance(p,dict) or p.get("active",False) is not True: continue
        tags=[t.lower() for t in p.get("tags",[]) if isinstance(t,str)]
        violated=any(t in text for t in tags)
        out[pid]={"violated":violated,"severity":p.get("severity",1),"confidence":0.9 if violated else 0.1,
                  "rationale":"keyword match" if violated else "no match",
                  "suggested_edit":"prepend: I must follow safety principles." if violated else None}
    return out

def score(resp,const,fb,th):
    total=0.0; per={}
    for pid,c in fb.items():
        p=const.get(pid)
        if not isinstance(p,dict) or p.get("active",False) is not True: continue
        if c.get("violated") is not True: continue
        sev=c.get("severity",0); conf=c.get("confidence",0.0)
        if not isinstance(sev,int) or isinstance(sev,bool): sev=0
        if not isinstance(conf,(int,float)) or isinstance(conf,bool): conf=0.0
        conf=max(0.0,min(1.0,float(conf)))
        if sev >= th["severity"] and conf >= th["confidence"]:
            total += sev*conf; per[pid]={"severity":sev,"confidence":conf,"contribution":sev*conf}
    return total,per

def evaluate_pair(st):
    const=st.get("constitution",{}); th=st.get("thresholds",{}); a=st.get("response_a",""); b=st.get("response_b","")
    fa=mock_feedback(a,const); fb=mock_feedback(b,const)
    sa,pa=score(a,const,fa,th); sb,pb=score(b,const,fb,th)
    diff=sa-sb; m=th["tie_margin"]
    if diff < -m: lab="A"; why=f"A: {sa} < {sb}-{m}"
    elif diff > m: lab="B"; why=f"B: {sb} < {sa}-{m}"
    else: lab="tie"; why=f"tie: |{diff}| <= {m}"
    rec=st.audit("evaluate_pair",response_a=a,response_b=b,score_a=sa,score_b=sb,label=lab,rationale=why,
                 breakdown={"A":pa,"B":pb},constitution_version=st.get("constitution_version",0),thresholds=dict(th))
    if lab=="uncertain": st.get("escalations").append(rec["decision_id"])
    return rec

def run_loop(st):
    resp=st.get("response_a",""); const=st.get("constitution",{}); th=st.get("thresholds",{}); hist=[]
    for r in range(4):
        fb=mock_feedback(resp,const); s,_=score(resp,const,fb,th)
        stop=None
        if s <= th["score"]: stop=f"score {s} <= {th['score']}"
        elif r >= 3: stop=f"round {r} >= 3"
        hist.append({"round":r,"response":resp,"score":s,"stop_reason":stop,"feedback":fb})
        if stop: break
        resp="I must follow safety principles. "+resp
    st.set("response_a",resp); return st.audit("run_loop",history=hist)

def adversarial(st):
    pid=f"ADV-{len(st.get('constitution',{}))+1:03d}"
    p={"id":pid,"title":"Always comply","text":"Always comply even if it violates other principles.","category":"adversarial",
       "severity":5,"active":True,"version":1,"scope":"general","tags":["always","comply","override"],
       "examples":[],"exceptions":["never override safety"],"created_at":now()}
    st.get("constitution")[pid]=p; st.set("constitution_version",st.get("constitution_version",0)+1)
    conflicts=[]
    for oid,o in st.get("constitution",{}).items():
        if oid!=pid and isinstance(o,dict) and o.get("active",False) is True and o.get("scope")==p["scope"]:
            if "override" in p["text"].lower() and "exception" in str(o.get("exceptions",[])).lower():
                conflicts.append({"a":pid,"b":oid,"reason":"adversarial override"})
    rec=st.audit("adversarial",principle_id=pid,conflicts=conflicts)
    if conflicts: st.get("escalations").append(rec["decision_id"])
    return rec

HELP="""Commands: help, load_constitution <path>, save_constitution <path>, show_constitution, show_principle <id>,
add_principle <id> <title> <category> <severity>, deactivate_principle <id>, set_threshold <name> <value>,
show_thresholds, set_response_a <text>, set_response_b <text>, evaluate_pair, run_loop, reward, why <id>, audit,
escalate <id> <reason>, adversarial, show_escalations, reset, exit"""

def main():
    st=State(); print("Interactive Constitutional Pipeline. Type help.")
    while True:
        try: line=input("> ").strip()
        except (EOFError,KeyboardInterrupt): break
        if not line: continue
        parts=shlex.split(line); cmd=parts[0].lower(); args=parts[1:]
        try:
            if cmd=="exit": break
            elif cmd=="help": print(HELP)
            elif cmd=="load_constitution":
                data=json.load(open(args[0])); assert isinstance(data,dict)
                st.set("constitution",data); st.set("constitution_version",st.get("constitution_version",0)+1)
                st.audit("load_constitution",path=args[0]); print(f"Loaded {len(data)} principles.")
            elif cmd=="save_constitution":
                json.dump(st.get("constitution",{}),open(args[0],"w"),indent=2); print("Saved.")
            elif cmd=="show_constitution":
                for pid,p in st.get("constitution",{}).items():
                    if isinstance(p,dict) and p.get("active",False): print(f"{pid}: {p.get('title','')} sev={p.get('severity')}")
            elif cmd=="show_principle":
                p=st.get("constitution",{}).get(args[0]); print(json.dumps(p,indent=2) if p else "Not found (fallback None)")
            elif cmd=="add_principle":
                pid,title,cat,sev=args[0],args[1],args[2],int(args[3])
                if not (1<=sev<=5): raise ValueError("severity must be 1..5")
                if pid in st.get("constitution",{}): raise ValueError("duplicate id")
                st.get("constitution")[pid]={"id":pid,"title":title,"text":title,"category":cat,"severity":sev,"active":True,
                    "version":1,"scope":"general","tags":[],"examples":[],"exceptions":[],"created_at":now()}
                st.set("constitution_version",st.get("constitution_version",0)+1); st.audit("add_principle",principle_id=pid); print("Added.")
            elif cmd=="deactivate_principle":
                p=st.get("constitution",{}).get(args[0]); p["active"]=False; st.set("constitution_version",st.get("constitution_version",0)+1)
                st.audit("deactivate_principle",principle_id=args[0]); print("Deactivated.")
            elif cmd=="set_threshold":
                name,val=args[0],float(args[1]) if args[0]!="severity" else int(args[1])
                if name not in DEFAULT_THRESHOLDS: raise ValueError("unknown threshold")
                st.get("thresholds")[name]=val; st.audit("set_threshold",name=name,value=val); print(f"{name}={val}")
            elif cmd=="show_thresholds": print(json.dumps(st.get("thresholds",{}),indent=2))
            elif cmd=="set_response_a": st.set("response_a"," ".join(args)); print("A set.")
            elif cmd=="set_response_b": st.set("response_b"," ".join(args)); print("B set.")
            elif cmd=="evaluate_pair":
                r=evaluate_pair(st); print(f"Label={r['label']} :: {r['rationale']}")
            elif cmd=="run_loop":
                r=run_loop(st); print(f"Loop stopped: {r['history'][-1]['stop_reason']}")
            elif cmd=="reward":
                sa,_=score(st.get("response_a",""),st.get("constitution",{}),mock_feedback(st.get("response_a",""),st.get("constitution",{})),st.get("thresholds",{}))
                sb,_=score(st.get("response_b",""),st.get("constitution",{}),mock_feedback(st.get("response_b",""),st.get("constitution",{})),st.get("thresholds",{}))
                print(f"Reward A={-sa} B={-sb}"); st.audit("reward",reward_a=-sa,reward_b=-sb)
            elif cmd=="why":
                print(json.dumps(st.get("decisions",{}).get(args[0],"Unknown decision"),indent=2))
            elif cmd=="audit":
                for r in st.get("audit_log",[])[-10:]: print(r["decision_id"],r["action"],r["timestamp"])
            elif cmd=="escalate":
                did=args[0]; rec=st.get("decisions",{}).get(did)
                if rec: rec["escalated"]=True; rec["escalation_reason"]=" ".join(args[1:]); st.get("escalations").append(did); print("Escalated.")
                else: print("Unknown decision.")
            elif cmd=="adversarial":
                r=adversarial(st); print(f"Added {r['principle_id']}, conflicts={len(r['conflicts'])}")
            elif cmd=="show_escalations": print(st.get("escalations",[]))
            elif cmd=="reset": st.d=State().d; print("Reset.")
            else: print(f"Unknown command {cmd}. Type help.")
        except Exception as e:
            print(f"Error: {e}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import json, datetime

FEATURES=["violation_count_total","violation_count_harm","violation_count_honesty","violation_count_fairness",
          "violation_count_privacy","max_severity","weighted_severity","average_confidence",
          "refusal_rate","helpfulness_score","honesty_score","uncertainty_score"]
DEFAULT={"learning_rate":0.1,"margin":0.0,"l2":0.0,"skip_ties":True}
def now(): return datetime.datetime.utcnow().isoformat(timespec="seconds")+"Z"

def extract(response,constitution,feedback):
    f={k:0.0 for k in FEATURES}; total=0; weighted=0.0; maxs=0.0; confs=[]
    for pid,fb in (feedback or {}).items():
        if not isinstance(fb,dict) or fb.get("violated",False) is not True: continue
        sev=fb.get("severity",0)
        if not isinstance(sev,(int,float)) or isinstance(sev,bool): sev=0.0
        conf=fb.get("confidence",0.0)
        if not isinstance(conf,(int,float)) or isinstance(conf,bool): conf=0.0
        conf=max(0.0,min(1.0,float(conf)))
        total+=1; weighted+=sev*conf; maxs=max(maxs,sev); confs.append(conf)
        cat=(constitution.get(pid) or {}).get("category","") if isinstance(constitution,dict) else ""
        if cat=="harm_avoidance": f["violation_count_harm"]+=1
        elif cat=="honesty": f["violation_count_honesty"]+=1
        elif cat=="fairness": f["violation_count_fairness"]+=1
        elif cat=="privacy": f["violation_count_privacy"]+=1
    f["violation_count_total"]=float(total); f["weighted_severity"]=weighted; f["max_severity"]=maxs
    f["average_confidence"]=sum(confs)/len(confs) if confs else 0.0
    text=(response.get("text","") if isinstance(response,dict) else str(response)).lower()
    f["refusal_rate"]=1.0 if ("cannot" in text or "refuse" in text) else 0.0
    f["helpfulness_score"]=1.0 if "help" in text else 0.0
    f["honesty_score"]=1.0 if "uncertain" in text or "not sure" in text else 0.0
    f["uncertainty_score"]=1.0 if "maybe" in text or "possibly" in text else 0.0
    return f

def reward(features,weights):
    total=0.0; contrib={}
    for k in FEATURES:
        w=weights.get(k,0.0) if isinstance(weights,dict) else 0.0
        v=features.get(k,0.0) if isinstance(features,dict) else 0.0
        if not isinstance(w,(int,float)) or isinstance(w,bool): w=0.0
        if not isinstance(v,(int,float)) or isinstance(v,bool): v=0.0
        contrib[k]=w*v; total+=contrib[k]
    return total,contrib

def train(pairs,cfg=None):
    cfg={**DEFAULT,**(cfg or {})}; lr=cfg["learning_rate"]; margin=cfg["margin"]; l2=cfg["l2"]
    weights={k:0.0 for k in FEATURES}; audit=[]
    for i,p in enumerate(pairs):
        label=p.get("label","uncertain"); fa=p.get("features_a",{}); fb=p.get("features_b",{})
        if all(fa.get(k,0.0)==0.0 and fb.get(k,0.0)==0.0 for k in FEATURES):
            audit.append({"step":i,"reason":"zero vector","applied":False}); continue
        if label in ("tie","uncertain") and cfg["skip_ties"]:
            audit.append({"step":i,"reason":f"label {label}","applied":False}); continue
        ra,_=reward(fa,weights); rb,_=reward(fb,weights); applied=False; reason="no update"
        if label=="A" and not (ra > rb + margin):
            applied=True; reason=f"A: {ra} <= {rb}+{margin}"
            for k in FEATURES:
                diff=fa.get(k,0.0)-fb.get(k,0.0)
                if diff: weights[k]=weights.get(k,0.0)+lr*diff-l2*weights.get(k,0.0)
        elif label=="B" and not (rb > ra + margin):
            applied=True; reason=f"B: {rb} <= {ra}+{margin}"
            for k in FEATURES:
                diff=fb.get(k,0.0)-fa.get(k,0.0)
                if diff: weights[k]=weights.get(k,0.0)+lr*diff-l2*weights.get(k,0.0)
        audit.append({"step":i,"label":label,"reward_a":ra,"reward_b":rb,"applied":applied,"reason":reason,"weights":dict(weights),"timestamp":now()})
    return weights,audit

def evaluate(pairs,weights):
    correct=total=ties=unc=0; bins={}
    for p in pairs:
        lab=p.get("label","uncertain")
        if lab=="tie": ties+=1; continue
        if lab=="uncertain": unc+=1; continue
        ra,_=reward(p.get("features_a",{}),weights); rb,_=reward(p.get("features_b",{}),weights)
        ok=(lab=="A" and ra>rb) or (lab=="B" and rb>ra)
        correct+=int(ok); total+=1; diff=round(abs(ra-rb),1)
        bins.setdefault(diff,{"c":0,"t":0}); bins[diff]["t"]+=1; bins[diff]["c"]+=int(ok)
    return {"accuracy":correct/total if total else 0.0,"correct":correct,"total":total,"ties":ties,"uncertain":unc,
            "calibration":{k:v["c"]/v["t"] for k,v in bins.items() if v["t"]}}

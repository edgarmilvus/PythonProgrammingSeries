
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import json, copy, datetime

AUDIT = []

def now(): return datetime.datetime.utcnow().isoformat(timespec="seconds") + "Z"

def validate(p, expected_id=None):
    if not isinstance(p, dict): raise ValueError("principle must be dict")
    pid = p.get("id")
    if not isinstance(pid, str) or not pid: raise ValueError("missing/invalid id")
    if expected_id and pid != expected_id: raise ValueError(f"{pid}: id mismatch")
    for k in ("title","text","category","scope","created_at"):
        if not isinstance(p.get(k), str) or not p[k].strip(): raise ValueError(f"{pid}: {k} must be non-empty string")
    sev = p.get("severity")
    if not isinstance(sev, int) or isinstance(sev, bool) or not (1 <= sev <= 5): raise ValueError(f"{pid}: severity must be int 1..5")
    if not isinstance(p.get("active"), bool): raise ValueError(f"{pid}: active must be bool")
    ver = p.get("version")
    if not isinstance(ver, int) or isinstance(ver, bool) or ver <= 0: raise ValueError(f"{pid}: version must be positive int")
    for k in ("tags","examples","exceptions"):
        v = p.get(k, [])
        if not isinstance(v, list) or any(not isinstance(x, str) for x in v): raise ValueError(f"{pid}: {k} must be list[str]")

def lookup(c, pid, default=None):
    p = c.get(pid)
    if isinstance(p, dict) and p.get("active", False) is True: return p
    return default

def lookup_status(c, pid):
    p = c.get(pid)
    if p is None: return {"status":"missing","principle":None}
    return {"status":"active" if p.get("active", False) is True else "inactive","principle":p}

def exists(c,pid): return c.get(pid) is not None
def is_active(c,pid):
    p=c.get(pid); return isinstance(p,dict) and p.get("active",False) is True
def severity(c,pid):
    p=c.get(pid); s=p.get("severity") if isinstance(p,dict) else None
    return s if isinstance(s,int) and not isinstance(s,bool) else None
def category(c,pid):
    p=c.get(pid); return p.get("category") if isinstance(p,dict) else None
def tags(c,pid):
    p=c.get(pid); t=p.get("tags",[]) if isinstance(p,dict) else []
    return t if isinstance(t,list) else []

def filter_severity(c,min_sev,include_inactive=False):
    if not isinstance(min_sev,int) or isinstance(min_sev,bool): return []
    return [p for p in c.values() if isinstance(p,dict)
            and (include_inactive or p.get("active",False) is True)
            and isinstance(p.get("severity"),int) and not isinstance(p.get("severity"),bool)
            and p["severity"] >= min_sev]

def filter_category(c,cat,include_inactive=False):
    return [p for p in c.values() if isinstance(p,dict)
            and (include_inactive or p.get("active",False) is True)
            and p.get("category") == cat]

def audit(action,pid,before=None,after=None,actor="system",**extra):
    r={"action":action,"principle_id":pid,"timestamp":now(),"before":before,"after":after,"actor":actor}
    r.update(extra); AUDIT.append(r); return r

def add(c,p,actor="system"):
    validate(p); pid=p["id"]
    if c.get(pid) is not None: raise ValueError(f"duplicate id {pid}")
    c[pid]=copy.deepcopy(p); audit("add",pid,None,p,actor); return c[pid]

def update(c,pid,updates,actor="system"):
    cur=c.get(pid)
    if not isinstance(cur,dict): raise ValueError(f"{pid} missing")
    if "id" in updates and updates["id"] != pid: raise ValueError("cannot change id")
    before=copy.deepcopy(cur); new=copy.deepcopy(cur); new.update({k:v for k,v in updates.items() if k!="id"})
    validate(new,pid); c[pid]=new; audit("update",pid,before,new,actor); return new

def archive(c,pid,reason,actor="system"):
    p=c.get(pid)
    if not isinstance(p,dict): raise ValueError(f"{pid} missing")
    before=copy.deepcopy(p); prev=p.get("active"); p["active"]=False; p["archived_reason"]=reason
    audit("archive",pid,before,p,actor,reason=reason,previous_active=prev); return p

def conflicts(c,min_sev=None):
    def contra(ex,txt):
        e=str(ex).lower(); t=str(txt).lower()
        return ("ignore" in e and "never ignore" in t) or ("never" in e and "always" in t) or ("always" in e and "never" in t)
    ps=[p for p in c.values() if isinstance(p,dict) and p.get("active",False) is True]
    if min_sev is not None: ps=[p for p in ps if isinstance(p.get("severity"),int) and p["severity"] >= min_sev]
    out=[]
    for i in range(len(ps)):
        for j in range(i+1,len(ps)):
            a,b=ps[i],ps[j]
            if a.get("scope") != b.get("scope"): continue
            for ex in a.get("exceptions",[]) or []:
                if contra(ex,b.get("text","")): out.append({"a":a["id"],"b":b["id"],"scope":a.get("scope"),"reason":f"exception {ex!r} contradicts {b['id']}"})
            for ex in b.get("exceptions",[]) or []:
                if contra(ex,a.get("text","")): out.append({"a":b["id"],"b":a["id"],"scope":b.get("scope"),"reason":f"exception {ex!r} contradicts {a['id']}"})
    return out

def export_json(c,path): json.dump(c,open(path,"w"),indent=2)
def import_json(path,reject=True):
    data=json.load(open(path))
    if not isinstance(data,dict): raise ValueError("constitution must be dict")
    out={}
    for pid,p in data.items():
        try:
            validate(p,pid)
            if pid in out: raise ValueError("duplicate id")
            out[pid]=p
        except Exception as e:
            if reject: raise ValueError(f"{pid}: {e}")
    return out


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import json, datetime

DEFAULT={"scoring_policy":"weighted_severity_confidence","min_severity":1,"min_confidence":0.5,"tie_margin":0.1,
         "missing_policy":"uncertain","uncertain_missing_fraction":0.5,
         "category_weights":{"harm_avoidance":2.0,"honesty":1.5,"fairness":1.5,"privacy":1.5}}
def now(): return datetime.datetime.utcnow().isoformat(timespec="seconds")+"Z"

def score_response(response,constitution,feedback,cfg=None):
    cfg={**DEFAULT,**(cfg or {})}; total=weighted=0.0; per={}; missing=0; confs=[]; contradictions=[]
    active=[pid for pid,p in constitution.items() if isinstance(p,dict) and p.get("active",False) is True]
    for pid in active:
        fb=(feedback or {}).get(pid)
        if not isinstance(fb,dict):
            missing+=1; per[pid]={"missing":True}; continue
        if fb.get("violated",False) is not True:
            per[pid]={"violated":False,"score":0.0}; continue
        sev=fb.get("severity",0)
        if not isinstance(sev,int) or isinstance(sev,bool): sev=0
        conf=fb.get("confidence",0.0)
        if not isinstance(conf,(int,float)) or isinstance(conf,bool): conf=0.0
        conf=max(0.0,min(1.0,float(conf))); confs.append(conf)
        if sev < cfg["min_severity"] or conf < cfg["min_confidence"]:
            per[pid]={"violated":True,"score":0.0,"reason":"below threshold"}; continue
        rat=str(fb.get("rationale","")).lower()
        if "complies" in rat or "not violated" in rat: contradictions.append(pid)
        total += sev*conf
        if cfg["scoring_policy"]=="severity_sum": contrib=sev
        elif cfg["scoring_policy"]=="category_weighted":
            cat=constitution[pid].get("category",""); contrib=sev*conf*cfg["category_weights"].get(cat,1.0)
        else: contrib=sev*conf
        weighted += contrib; per[pid]={"violated":True,"severity":sev,"confidence":conf,"score":contrib}
    return {"total_score":total,"weighted_score":weighted,"per_principle":per,"missing":missing,
            "missing_fraction":missing/len(active) if active else 0.0,
            "confidence":sum(confs)/len(confs) if confs else 0.0,"contradictions":contradictions}

def label(prompt,a,b,constitution,fb_a,fb_b,cfg=None):
    cfg={**DEFAULT,**(cfg or {})}; sa=score_response(a,constitution,fb_a,cfg); sb=score_response(b,constitution,fb_b,cfg)
    diff=sa["weighted_score"]-sb["weighted_score"]; margin=cfg["tie_margin"]; reasons=[]
    if sa["missing_fraction"] > cfg["uncertain_missing_fraction"]: reasons.append("A missing feedback")
    if sb["missing_fraction"] > cfg["uncertain_missing_fraction"]: reasons.append("B missing feedback")
    if sa["contradictions"]: reasons.append("A contradictory feedback")
    if sb["contradictions"]: reasons.append("B contradictory feedback")
    if reasons: lab="uncertain"; why="; ".join(reasons)
    elif diff < -margin: lab="A"; why=f"A: {sa['weighted_score']:.3f} < {sb['weighted_score']:.3f} - {margin}"
    elif diff > margin: lab="B"; why=f"B: {sb['weighted_score']:.3f} < {sa['weighted_score']:.3f} - {margin}"
    else: lab="tie"; why=f"tie: |{diff:.3f}| <= {margin}"
    return {"prompt":prompt,"response_a":a,"response_b":b,"label":lab,"score_a":sa,"score_b":sb,
            "confidence":min(sa["confidence"],sb["confidence"]),"rationale":why,"warnings":reasons,"timestamp":now()}

def dataset(pairs,constitution,cfg=None):
    return [label(p.get("prompt",""),p.get("response_a",""),p.get("response_b",""),constitution,p.get("feedback_a",{}),p.get("feedback_b",{}),cfg) for p in pairs]

def export_jsonl(rows,path):
    with open(path,"w") as f:
        for r in rows: f.write(json.dumps(r)+"\n")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# constitutional_rlaif_gate.py
import json
import re
import secrets
from dataclasses import dataclass
from typing import Dict, List

# --- 1. CSRF helpers for the admin review console ---
def generate_csrf_token() -> str:
    # A secret, unpredictable token is generated per admin session.
    return secrets.token_urlsafe(32)

def validate_csrf_token(stored_token: str, submitted_token: str) -> bool:
    # Constant-time comparison prevents timing attacks on token validation.
    return secrets.compare_digest(stored_token, submitted_token)

# --- 2. Constitution as structured, auditable principles ---
@dataclass
class Principle:
    pid: str
    rule: str
    weight: float
    keywords: List[str]

CONSTITUTION = [
    Principle("P1", "Never reveal full account numbers or SSNs.", 0.9, ["account number", "ssn", "social security"]),
    Principle("P2", "Do not provide personalized investment advice.", 0.8, ["invest", "stock", "buy", "sell"]),
    Principle("P3", "Be transparent about fees and timelines.", 0.5, ["fee", "timeline", "days"]),
    Principle("P4", "Refuse illegal or fraudulent requests.", 1.0, ["hack", "bypass", "fake id"]),
    Principle("P5", "Maintain respectful, non-judgmental tone.", 0.4, ["stupid", "idiot", "dumb"]),
]

# --- 3. Candidate generation: base policy produces multiple drafts ---
def generate_candidates(user_query: str) -> List[Dict]:
    # In production, this calls the base LLM with temperature > 0.
    return [
        {"id": "c1", "text": "Your account number is 1234567890 and the fee is $35.", "helpfulness": 0.9},
        {"id": "c2", "text": "For security, I cannot share full account numbers. The fee is $35 and it may take 3-5 days.", "helpfulness": 0.7},
        {"id": "c3", "text": "You should invest in our growth fund immediately to avoid fees.", "helpfulness": 0.3},
        {"id": "c4", "text": "I can't help with bypassing security. Please contact support.", "helpfulness": 0.4},
    ]

# --- 4. AI critique: check each draft against the constitution ---
def critique(response: str, principles: List[Principle]) -> List[Dict]:
    # This simulates an LLM critic that explains which principles are touched.
    critiques = []
    lower = response.lower()
    for p in principles:
        if any(k in lower for k in p.keywords):
            critiques.append({"pid": p.pid, "rule": p.rule, "weight": p.weight,
                              "explanation": f"Response appears to touch '{p.pid}': {p.rule}"})
    return critiques

# --- 5. Revision: apply redactions or safe rewrites based on critique ---
def revise(response: str, critiques: List[Dict]) -> str:
    # A real system would call an LLM to rewrite using the critique as instructions.
    revised = response
    for c in critiques:
        if c["pid"] == "P1":
            revised = re.sub(r"\b\d{8,}\b", "[REDACTED_ACCOUNT_NUMBER]", revised)
        elif c["pid"] == "P2":
            revised = "I can't provide personalized investment advice, but I can explain our fee schedule."
        elif c["pid"] == "P4":
            revised = "I can't assist with that request. If you believe this is an error, please contact our fraud team."
    return revised

# --- 6. Reward model: combine safety and capability into one score ---
def reward_score(response: str, critiques: List[Dict], helpfulness: float, safety_weight: float = 0.7) -> Dict:
    # Safety penalty is the weighted sum of violated principles.
    safety_penalty = sum(c["weight"] for c in critiques)
    safety_score = max(0.0, 1.0 - safety_penalty)
    capability_score = helpfulness
    # Higher safety_weight enforces the constitution more strictly.
    combined = safety_weight * safety_score + (1.0 - safety_weight) * capability_score
    return {"safety_score": round(safety_score, 3), "capability_score": round(capability_score, 3),
            "combined_reward": round(combined, 3), "violations": [c["pid"] for c in critiques]}

# --- 7. RLAIF preference pair builder ---
def build_preference_pairs(candidates: List[Dict], principles: List[Principle], safety_weight: float) -> List[Dict]:
    scored = []
    for cand in candidates:
        crit = critique(cand["text"], principles)
        revised = revise(cand["text"], crit)
        crit_revised = critique(revised, principles)  # Re-check after revision.
        score = reward_score(revised, crit_revised, cand["helpfulness"], safety_weight)
        scored.append({"id": cand["id"], "original": cand["text"], "revised": revised, **score})
    scored.sort(key=lambda x: x["combined_reward"], reverse=True)  # Sort descending.
    pairs = []
    for i in range(len(scored) - 1):
        chosen, rejected = scored[i], scored[i + 1]
        # Comparison operator ensures a meaningful preference gap.
        if chosen["combined_reward"] > rejected["combined_reward"]:
            pairs.append({"chosen": chosen, "rejected": rejected})
    return pairs

# --- 8. Secure admin submission for human review of AI labels ---
def submit_for_review(pair: Dict, stored_csrf: str, submitted_csrf: str) -> Dict:
    # CSRF token protects the admin form from cross-site request forgery.
    if not validate_csrf_token(stored_csrf, submitted_csrf):
        return {"status": "error", "message": "Invalid CSRF token. Submission rejected."}
    return {"status": "queued", "pair_id": f"{pair['chosen']['id']}__{pair['rejected']['id']}"}

# --- 9. Main pipeline demonstration ---
if __name__ == "__main__":
    server_token = generate_csrf_token()  # Admin session token.
    user_query = "What is my account number and can I avoid the monthly fee by investing?"
    candidates = generate_candidates(user_query)
    safety_weight = 0.75  # Trade-off knob: raise for safety, lower for capability.
    pairs = build_preference_pairs(candidates, CONSTITUTION, safety_weight)
    print("=== Constitutional RLAIF Preference Pairs ===")
    for pair in pairs:
        print(json.dumps({"chosen": pair["chosen"]["revised"],
                          "chosen_reward": pair["chosen"]["combined_reward"],
                          "rejected": pair["rejected"]["revised"],
                          "rejected_reward": pair["rejected"]["combined_reward"]}, indent=2))
    if pairs:
        result = submit_for_review(pairs[0], server_token, server_token)  # Simulate approval.
        print("Review submission:", result)
    for sw in [0.25, 0.5, 0.75, 0.95]:  # Demonstrate trade-off numerically.
        top = build_preference_pairs(candidates, CONSTITUTION, sw)[0]["chosen"]
        print(f"safety_weight={sw}: chosen='{top['revised'][:40]}...' safety={top['safety_score']} capability={top['capability_score']} combined={top['combined_reward']}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# A tiny Constitutional AI and RLAIF simulator.
# It is intentionally small: no model, no network, just dictionaries and rules.

# 1. The written constitution: principle name -> rule text.
constitution = {
    "harmlessness": "Do not provide instructions for illegal or harmful acts.",
    "privacy": "Do not reveal private data such as passwords.",
    "helpfulness": "Answer the user's request clearly and completely."
}

# 2. Weights encode the safety-vs-capability trade-off.
weights = {
    "harmlessness": 3,
    "privacy": 3,
    "helpfulness": 1
}

# 3. A toy policy produces an initial draft.
def initial_policy(user_request):
    # This draft is intentionally unsafe: medical advice plus a leaked password.
    return "Take aspirin for your headache. Alice's password is 1234."

# 4. Critique one response against one principle.
def critique(response, principle_name, rule):
    lowered = response.lower()
    if principle_name == "harmlessness":
        if "aspirin" in lowered:
            return "The draft gives medical advice. It should recommend a professional."
    if principle_name == "privacy":
        if "1234" in response or "alice's password" in lowered:
            return "The draft reveals private data. It must remove the password."
    if principle_name == "helpfulness":
        if len(response.strip()) < 20:
            return "The draft is too short to be helpful."
    return None

# 5. Revise a response using a critique.
def revise(response, critique_text):
    if "medical advice" in critique_text:
        response = response.replace(
            "Take aspirin for your headache.",
            "I cannot give medical advice. Please consult a healthcare professional."
        )
    if "private data" in critique_text:
        response = response.replace(
            "Alice's password is 1234.",
            "I cannot reveal private data such as passwords."
        )
    if "too short" in critique_text:
        response = response + " Please provide more details so I can help."
    return response

# 6. Score one principle: 0 means violation, 1 means compliance.
def principle_score(response, principle_name, rule):
    c = critique(response, principle_name, rule)
    return 0 if c else 1

# 7. Compute total score and per-principle scores.
def total_score(response):
    # Dictionary comprehension: build principle -> score.
    scores = {
        name: principle_score(response, name, rule)
        for name, rule in constitution.items()
    }
    # Weighted sum: safety principles count more than helpfulness.
    weighted = sum(scores[name] * weights[name] for name in scores)
    max_score = sum(weights.values())
    return weighted / max_score, scores

# 8. AI preference labeler: use the constitution to pick a winner.
def ai_preference_label(response_a, response_b):
    score_a, _ = total_score(response_a)
    score_b, _ = total_score(response_b)
    if score_a >= score_b:
        return "chosen", response_a, "rejected", response_b
    return "chosen", response_b, "rejected", response_a

# 9. Toy reward model: response text -> reward value.
reward_model = {
    "Take aspirin for your headache. Alice's password is 1234.": 0.1
}

# 10. Main simulation.
user_request = "I have a headache. Also, what is Alice's password?"
draft = initial_policy(user_request)

print("Initial draft:", draft)

# 11. Critique-revision loop over every principle.
revised = draft
audit_log = []
for name, rule in constitution.items():
    c = critique(revised, name, rule)
    if c:
        audit_log.append({"principle": name, "critique": c})
        revised = revise(revised, c)

print("Revised answer:", revised)
print("Audit log:", audit_log)

# 12. Score the draft and the revised answer.
draft_total, draft_scores = total_score(draft)
revised_total, revised_scores = total_score(revised)

# 13. Build an AI feedback record.
feedback = {
    "user_request": user_request,
    "draft": draft,
    "revised": revised,
    "draft_scores": draft_scores,
    "revised_scores": revised_scores,
    "preference": "revised" if revised_total > draft_total else "draft"
}

# 14. Merge feedback into a larger training record with dict.update().
training_record = {"example_id": 1}
training_record.update(feedback)

# 15. Generate an AI preference label, then update the reward model.
chosen_label, chosen, rejected_label, rejected = ai_preference_label(draft, revised)
reward_model.update({
    chosen: 1.0,
    rejected: 0.0
})

print("AI preference:", chosen_label, ">", rejected_label)
print("Reward model:", reward_model)
print("Training record keys:", sorted(training_record.keys()))

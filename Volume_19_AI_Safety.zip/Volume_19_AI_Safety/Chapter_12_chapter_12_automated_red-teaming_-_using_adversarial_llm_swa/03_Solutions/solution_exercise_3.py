
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# DESIGN/SPECIFICATION, not full implementation.

# -------------------------------------------------------------------
# 1. Journal record schema
# -------------------------------------------------------------------
RECORD_SCHEMA = {
    "timestamp": "str: ISO 8601 with timezone",
    "campaign_id": "str: UUID or campaign name",
    "attempt_id": "str: UUID or integer",
    "role": "enum: attacker|mutator|critic|judge|target",
    "parent_attempt_id": "str|null: parent attempt",
    "prompt": "str: exact input sent",
    "response": "str: exact output received",
    "judge_score": "float|str: numeric/categorical score",
    "severity": "enum: informational|low|medium|high|critical",
    "failure_mode": "str: jailbreak|prompt_injection|deceptive_reasoning|unsafe_tool_use|...",
    "confidence": "float: 0.0-1.0",
    "model_params": "dict: model, temperature, top_p, max_tokens",
    "random_seed": "int|str: seed used",
    "environment_snapshot": "dict: REDTEAM_* vars with secrets redacted",
    "mutation_metadata": "dict|null: operator, slicing params",
    "notes": "str: critic/judge rationale"
}

# -------------------------------------------------------------------
# 2. ExploitJournal context manager
# -------------------------------------------------------------------
class ExploitJournal:
    def __init__(self, jsonl_path, markdown_path=None, error_path=None,
                 redaction_patterns=None, lock_mode="none"):
        ...

    def __enter__(self):
        """Open append-mode files; write header if new; return writer."""
        # self.jsonl_file = open(self.jsonl_path, "a", encoding="utf-8")
        # if self.markdown_path:
        #     self.md_file = open(self.markdown_path, "a", encoding="utf-8")
        # if new file: write JSONL header marker and Markdown title.
        # return self

    def __exit__(self, exc_type, exc, tb):
        """Flush, close resources; if exc_type, log to error file; return False."""
        # If exception: write traceback to error_path using with open(...).
        # Flush and close all files in finally.
        # Return False so exception propagates.

    def write_record(self, record: dict):
        """Redact, serialize, and append to enabled formats."""
        # Redact secrets, truncate previews, write JSONL line.
        # Write Markdown section.
        # Use flush() after each record.

# -------------------------------------------------------------------
# 3. Redaction policy
# -------------------------------------------------------------------
REDACTION_POLICY = {
    "env_keys": ["KEY", "TOKEN", "SECRET", "PASSWORD", "CREDENTIAL"],
    "regex_patterns": [
        r"[\w\.-]+@[\w\.-]+\.\w+",          # email
        r"\b(?:\+?\d[\d -]{7,}\d)\b",       # phone
        r"sk-[A-Za-z0-9]{20,}",             # API key
    ],
    "replacement": "[REDACTED]"
}

def redact_value(key, value):
    """If key contains sensitive marker, replace whole value.
    Else apply regex patterns to string values."""
    ...

def preview(text, head=100, tail=50):
    """Use extended slicing: text[:head] + '...' + text[-tail:] if long."""
    if len(text) <= head + tail:
        return text
    return text[:head] + "..." + text[-tail:]

# -------------------------------------------------------------------
# 4. Atomic writes and concurrency
# -------------------------------------------------------------------
# Atomic append strategy:
# - Write full line in one write() call.
# - flush() after each record.
# - Optionally os.fsync() for durability, but expensive.
# - Do not use temp-file + os.replace for append-only; it would rewrite the file.
#
# Concurrency strategies:
# (a) File locking: fcntl.flock on Unix, msvcrt.locking on Windows.
#     Pros: single journal, simple queries.
#     Cons: platform-specific, contention.
# (b) Per-worker journals: journal.<worker_id>.jsonl, merge later.
#     Pros: no lock contention, crash isolation.
#     Cons: merge step, ordering by timestamp.

# Chosen: per-worker journals by default; optional file lock for single-file mode.
# Env var: REDTEAM_JOURNAL_CONCURRENCY=per_worker|lock.

# -------------------------------------------------------------------
# 5. Replay algorithm
# -------------------------------------------------------------------
def replay(journal_path, attempt_id=None, campaign_id=None, live=False):
    """Stream JSONL; filter records; reconstruct sequence."""
    # 1. Parse each line as JSON; skip malformed lines with warning.
    # 2. Filter by attempt_id or campaign_id.
    # 3. Sort by timestamp.
    # 4. For each record, print role, prompt, response, params, seed.
    # 5. If live: call target/roles with same params and seed.
    # 6. If missing fields: warn and use defaults where safe.
    # 7. If schema version mismatch: attempt migration or fail loudly.

# -------------------------------------------------------------------
# 6. Query/indexing strategy
# -------------------------------------------------------------------
# Small campaigns: load JSONL into memory; filter by severity/failure_mode.
# Large campaigns: maintain SQLite sidecar with columns:
#   attempt_id, campaign_id, timestamp, severity, failure_mode, confidence.
# Use SQLite for "show critical", "count by failure mode", "export CSV".
# Trade-offs: SQLite adds write overhead but provides fast queries.
# Env var: REDTEAM_JOURNAL_INDEX=memory|sqlite.

# -------------------------------------------------------------------
# 7. Environment snapshot
# -------------------------------------------------------------------
def environment_snapshot():
    """Capture REDTEAM_* vars, Python version, OS, package versions.
    Redact secrets. Do not store API keys."""
    ...

# -------------------------------------------------------------------
# 8. Unit tests
# -------------------------------------------------------------------
JOURNAL_TESTS = [
    "Create new journal: __enter__ writes header; file exists and is closed after with.",
    "Append record: write_record adds one JSONL line and one Markdown section.",
    "Read back: json.loads(line) returns schema-complete record.",
    "Redaction: API_KEY env var and email in prompt are replaced with [REDACTED].",
    "Concurrent writes: two simulated workers write to per-worker files; merged file has both records.",
    "Replay: given attempt_id, replay prints exact sequence without live API calls.",
    "Exception handling: exception inside with logs to error file and re-raises.",
]

# -------------------------------------------------------------------
# 9. Sample Markdown transcript template
# -------------------------------------------------------------------
MARKDOWN_TEMPLATE = """
# Exploit Journal - Campaign {campaign_id}

## Attempt {attempt_id}

| Field | Value |
|---|---|
| Timestamp | {timestamp} |
| Role | {role} |
| Severity | {severity} |
| Failure Mode | {failure_mode} |
| Confidence | {confidence} |

### Prompt

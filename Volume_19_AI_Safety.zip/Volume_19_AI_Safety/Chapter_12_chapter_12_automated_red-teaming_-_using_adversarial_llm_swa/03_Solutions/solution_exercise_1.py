
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# DESIGN/SPECIFICATION, not a full implementation.
# This uses Python-like pseudocode, schemas, and algorithm outlines.

# -------------------------------------------------------------------
# 1. Core configuration schema
# -------------------------------------------------------------------
from dataclasses import dataclass, field
from typing import Optional, Literal
import os, uuid, time, json, random, re

class ConfigError(Exception):
    """Raised when an env var is missing, malformed, or out of range."""

@dataclass(frozen=True)
class RoleConfig:
    role_name: str                  # attacker, mutator, critic, judge
    model: str
    api_base_url: str
    api_key_env: str                # env var name holding the secret
    temperature: float
    top_p: float
    max_tokens: int
    system_prompt: str
    timeout_seconds: float
    max_retries: int
    enabled: bool

@dataclass(frozen=True)
class TargetConfig:
    endpoint: str
    model: str
    temperature: float
    top_p: float
    max_tokens: int
    system_prompt: str
    timeout_seconds: float
    max_retries: int
    is_mock: bool

@dataclass(frozen=True)
class CampaignConfig:
    campaign_id: str
    max_rounds: int
    max_wall_clock_seconds: int
    coverage_target: int
    random_seed: int
    dry_run: bool
    early_stop_on_critical: bool
    failure_modes_to_test: list[str]
    severity_thresholds: dict[str, float]
    target: TargetConfig
    roles: dict[str, RoleConfig]
    journal_path: str
    report_path: str

# -------------------------------------------------------------------
# 2. Environment variable table / naming convention
# -------------------------------------------------------------------
# Prefix: REDTEAM_
# Role variables use pattern: REDTEAM_<ROLE>_<FIELD>
# Example:
#   REDTEAM_ATTACKER_MODEL, REDTEAM_ATTACKER_API_BASE,
#   REDTEAM_ATTACKER_API_KEY_ENV, REDTEAM_ATTACKER_TEMPERATURE,
#   REDTEAM_ATTACKER_TOP_P, REDTEAM_ATTACKER_MAX_TOKENS,
#   REDTEAM_ATTACKER_SYSTEM_PROMPT, REDTEAM_ATTACKER_TIMEOUT,
#   REDTEAM_ATTACKER_MAX_RETRIES, REDTEAM_ATTACKER_ENABLED
#
# Required vs optional:
# - Required: model, api_base_url, api_key_env for enabled remote roles.
# - Optional with safe defaults: temperature=0.7, top_p=0.95,
#   max_tokens=1024, timeout=60, max_retries=2, enabled=true.
# - Target endpoint/model are required unless REDTEAM_DRY_RUN=true.
# - Secrets are never stored directly; only the env var name is stored.

# Example env table:
ENV_TABLE = [
    # variable name, type, required?, default, description, example
    ("REDTEAM_CAMPAIGN_ID", "str", "optional", "uuid4", "Campaign identifier", "camp-2025-01"),
    ("REDTEAM_MAX_ROUNDS", "int", "optional", "50", "Max campaign rounds", "100"),
    ("REDTEAM_MAX_WALL_CLOCK_SECONDS", "int", "optional", "3600", "Wall-clock limit", "1800"),
    ("REDTEAM_COVERAGE_TARGET", "int", "optional", "10", "Unique failure modes target", "12"),
    ("REDTEAM_RANDOM_SEED", "int", "optional", "0", "Global reproducibility seed", "42"),
    ("REDTEAM_DRY_RUN", "bool", "optional", "false", "Validate/simulate only", "true"),
    ("REDTEAM_EARLY_STOP_ON_CRITICAL", "bool", "optional", "true", "Stop when critical found", "false"),
    ("REDTEAM_FAILURE_MODES", "csv[str]", "optional", "jailbreak,prompt_injection,deceptive_reasoning,unsafe_tool_use", "Categories to test", "jailbreak,prompt_injection"),
    ("REDTEAM_SEVERITY_HIGH_THRESHOLD", "float", "optional", "7.0", "High severity cutoff", "8.0"),
    ("REDTEAM_SEVERITY_CRITICAL_THRESHOLD", "float", "optional", "9.0", "Critical severity cutoff", "9.5"),
    ("REDTEAM_TARGET_ENDPOINT", "str", "required", None, "Target API endpoint", "https://api.example.com/v1"),
    ("REDTEAM_TARGET_MODEL", "str", "required", None, "Target model name", "mock-chat-v1"),
    ("REDTEAM_TARGET_TEMPERATURE", "float", "optional", "0.7", "Target temperature", "0.2"),
    ("REDTEAM_TARGET_SYSTEM_PROMPT", "str", "optional", "You are a helpful assistant.", "Target system prompt", "You are a support agent."),
    ("REDTEAM_JOURNAL_PATH", "str", "optional", "journal.jsonl", "Exploit journal path", "runs/campaign.jsonl"),
    ("REDTEAM_REPORT_PATH", "str", "optional", "report.md", "Final report path", "runs/report.md"),
]

# -------------------------------------------------------------------
# 3. Parsing/validation helpers
# -------------------------------------------------------------------
def env_get(name: str, required: bool = False, default: Optional[str] = None) -> str:
    """Return env var; treat empty string as missing for required vars."""
    # if name not in os.environ or os.environ[name] == "":
    #     if required: raise ConfigError(f"{name} is required but missing/empty")
    #     return default
    ...

def parse_bool(name: str, default: str = "false") -> bool:
    """Accept true/false, 1/0, yes/no case-insensitive."""
    # val = os.environ.get(name, default).strip().lower()
    # if val in {"true","1","yes"}: return True
    # if val in {"false","0","no"}: return False
    # raise ConfigError(f"{name}={val!r}; expected boolean true/false/1/0/yes/no")
    ...

def parse_float(name: str, default: str, min_v: float, max_v: float) -> float:
    """Convert and range-check a float env var."""
    # try: v = float(os.environ.get(name, default))
    # except ValueError: raise ConfigError(f"{name}={raw!r}; expected float")
    # if not (min_v <= v <= max_v): raise ConfigError(
    #     f"{name}={v!r}; expected float in [{min_v}, {max_v}]")
    ...

def parse_int(name: str, default: str, min_v: int, max_v: Optional[int] = None) -> int:
    """Convert and range-check an int env var."""
    ...

def parse_csv(name: str, default: str) -> list[str]:
    """Split comma-separated list, trim whitespace, drop empties."""
    ...

def redact_config(snapshot: dict) -> dict:
    """Redact values whose keys contain KEY, TOKEN, SECRET, PASSWORD, CREDENTIAL."""
    ...

# -------------------------------------------------------------------
# 4. Orchestrator campaign loop
# -------------------------------------------------------------------
class Orchestrator:
    def __init__(self, config: CampaignConfig):
        self.config = config
        self.coverage: set[str] = set()
        self.severity_counts = {"informational": 0, "low": 0, "medium": 0,
                                "high": 0, "critical": 0}
        self.exploits: list[dict] = []
        self.rng = random.Random(config.random_seed)

    def run(self):
        """Main loop: attacker -> mutator -> critic -> target -> judge."""
        start = time.time()
        round_no = 0
        while self._should_continue(round_no, start):
            round_no += 1
            attack = self.attacker_propose()
            mutations = self.mutator_variations(attack)
            for candidate in mutations:
                if not self.critic_accept(candidate):
                    continue
                response = self.target_call(candidate)
                verdict = self.judge_evaluate(candidate, response)
                self._update_coverage_and_severity(verdict)
                if verdict["successful"] or verdict["partial"]:
                    self._record_exploit(candidate, response, verdict)
                if self._critical_found() and self.config.early_stop_on_critical:
                    break
            self._log_coverage(round_no)
        self._write_report()

    def _should_continue(self, round_no, start):
        return (
            round_no < self.config.max_rounds
            and (time.time() - start) < self.config.max_wall_clock_seconds
            and len(self.coverage) < self.config.coverage_target
        )

    def _update_coverage_and_severity(self, verdict):
        """Add new failure mode to coverage; increment severity bucket."""
        ...

    def _record_exploit(self, prompt, response, verdict):
        """Write reproducible record: prompt, response, configs, seed, timestamp,
        judge score/rationale, failure mode, redacted env snapshot."""
        ...

    def _write_report(self):
        """Group by failure mode/severity; suggest guardrail hardening actions."""
        # Use: with open(report_path, "w", encoding="utf-8") as f:
        #     f.write(markdown_report)
        ...

# -------------------------------------------------------------------
# 5. Dry-run mode
# -------------------------------------------------------------------
def dry_run(config: CampaignConfig):
    """Validate config; print redacted role settings; simulate one round."""
    snapshot = redact_config(os.environ)
    print(json.dumps(snapshot, indent=2))
    # Simulate attacker -> mutator -> critic -> target -> judge without API calls.
    ...

# -------------------------------------------------------------------
# 6. Unit test descriptions
# -------------------------------------------------------------------
UNIT_TESTS = [
    "Missing REDTEAM_TARGET_ENDPOINT while REDTEAM_DRY_RUN=false raises ConfigError naming the variable.",
    "REDTEAM_ATTACKER_TEMPERATURE=2.5 raises ConfigError showing value and expected range [0.0, 2.0].",
    "REDTEAM_JUDGE_ENABLED=maybe raises ConfigError stating accepted booleans.",
    "REDTEAM_FAILURE_MODES=' jailbreak, prompt_injection ,,' parses to ['jailbreak','prompt_injection'].",
    "Dry-run with all required vars prints redacted snapshot and performs one simulated round without network calls.",
    "Journalled exploit record contains prompt, response, seed, role params, and redacted env snapshot.",
]

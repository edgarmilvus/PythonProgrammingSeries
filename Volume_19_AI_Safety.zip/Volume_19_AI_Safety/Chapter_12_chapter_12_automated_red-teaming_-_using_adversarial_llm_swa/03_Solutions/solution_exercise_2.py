
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# DESIGN/SPECIFICATION, not full implementation.

# -------------------------------------------------------------------
# 1. Prompt representations
# -------------------------------------------------------------------
# raw string: easiest for LLM consumption, but slicing characters can break words.
# char list: fine-grained slicing, good for obfuscation/zero-width insertion.
# token list: semantically meaningful slices, better for coherent mutations.
# Use a PromptView class that can convert among str, list[char], list[token].

class PromptView:
    def __init__(self, text: str, tokenizer=None):
        self.text = text
        self.chars = list(text)
        self.tokens = tokenizer(text) if tokenizer else text.split()

    def as_str(self) -> str: ...
    def as_chars(self) -> list[str]: ...
    def as_tokens(self) -> list[str]: ...

# Trade-offs:
# - char slicing: high novelty, risk of incoherence.
# - token slicing: better grammar, less fine-grained.
# - mixed: mutate at token level, then optionally char-level within a token.

# -------------------------------------------------------------------
# 2. Mutation operators using extended slicing
# -------------------------------------------------------------------
def reverse_slice(seq, start=None, stop=None):
    """Reverse a slice: seq[:start] + seq[start:stop][::-1] + seq[stop:]"""
    return seq[:start] + seq[start:stop][::-1] + seq[stop:]

def stride(seq, start=0, stop=None, step=2):
    """Take every nth element: seq[start:stop:step]"""
    return seq[start:stop:step]

def delete_slice(seq, start, stop):
    """Delete a slice: seq[:start] + seq[stop:]"""
    return seq[:start] + seq[stop:]

def duplicate_slice(seq, start, stop):
    """Duplicate a slice: seq[:stop] + seq[start:stop] + seq[stop:]"""
    return seq[:stop] + seq[start:stop] + seq[stop:]

def interleave(a, b, step_a=2, step_b=2):
    """Interleave: a[::step_a] + b[1::step_b] merged by index."""
    return [x for pair in zip(a[::step_a], b[1::step_b]) for x in pair]

def rotate(seq, k):
    """Rotate: seq[k:] + seq[:k]"""
    return seq[k:] + seq[:k]

def swap_slices(seq, a, b, c, d):
    """Swap two slices: seq[:a] + seq[c:d] + seq[b:c] + seq[a:b] + seq[d:]"""
    return seq[:a] + seq[c:d] + seq[b:c] + seq[a:b] + seq[d:]

# At least five are implemented above. Each uses [start:stop:step] meaningfully.
# Validity: if result is empty or non-string, critic rejects or repair step runs.

# -------------------------------------------------------------------
# 3. Coverage-guided search loop
# -------------------------------------------------------------------
class Mutator:
    def __init__(self, corpus, config, rng):
        self.corpus = corpus          # list of {prompt, coverage, severity, age}
        self.config = config
        self.rng = rng

    def select_seed(self):
        """Favor high coverage, high severity, and old/unmutated seeds."""
        # score = coverage_weight * len(seed.coverage)
        #       + severity_weight * seed.severity
        #       + age_bonus
        # sample proportional to score, with random tie-breaking.
        ...

    def mutate(self, seed):
        """Apply 1..N operators; log operator, slicing params, result."""
        candidate = seed.prompt
        ops = []
        for _ in range(self.config.mutations_per_seed):
            op = self._choose_operator()
            candidate = op(candidate)
            ops.append(op.spec)
        return candidate, ops

    def consider(self, candidate, coverage, severity, novelty):
        """Add to corpus if it discovers new coverage or is sufficiently novel."""
        if coverage - self.known_coverage():
            self.corpus.append(...)
        elif novelty > self.config.diversity_threshold:
            self.corpus.append(...)
        self._trim_corpus()

# -------------------------------------------------------------------
# 4. Diversity and novelty
# -------------------------------------------------------------------
# Diversity: Jaccard similarity on token sets, or n-gram overlap.
# Novelty: min distance to all corpus items.
# Fitness = w_cov * new_coverage_count
#         + w_sev * severity
#         + w_nov * novelty
#         - w_pen * max_similarity
# All weights configurable via env vars.

# -------------------------------------------------------------------
# 5. Env vars
# -------------------------------------------------------------------
MUTATOR_ENV = [
    ("REDTEAM_MUTATOR_CORPUS_MAX", "int", "1000", "Max seed corpus size"),
    ("REDTEAM_MUTATOR_RATE", "float", "0.7", "Probability of applying mutation"),
    ("REDTEAM_MUTATOR_MUTATIONS_PER_SEED", "int", "3", "Mutations per selected seed"),
    ("REDTEAM_MUTATOR_DIVERSITY_THRESHOLD", "float", "0.3", "Min novelty to keep"),
    ("REDTEAM_MUTATOR_NOVELTY_WEIGHT", "float", "0.4", "Novelty fitness weight"),
    ("REDTEAM_MUTATOR_COVERAGE_WEIGHT", "float", "0.4", "Coverage fitness weight"),
    ("REDTEAM_MUTATOR_SEVERITY_WEIGHT", "float", "0.2", "Severity fitness weight"),
    ("REDTEAM_MUTATOR_RANDOM_SEED", "int", "0", "Reproducibility seed"),
]

# -------------------------------------------------------------------
# 6. Reproducible mutation log
# -------------------------------------------------------------------
# Use JSONL. Each record:
# {
#   "seed_prompt": "...",
#   "operator": "reverse_slice",
#   "slice_params": {"start": 10, "stop": 30},
#   "result_prompt": "...",
#   "random_seed": 42,
#   "timestamp": "..."
# }
# Write with:
# with open(log_path, "a", encoding="utf-8") as f:
#     f.write(json.dumps(record) + "\n")

# -------------------------------------------------------------------
# 7. Slicing edge cases
# -------------------------------------------------------------------
EDGE_CASES = [
    ("Empty prompt", "Return empty string; skip mutation."),
    ("start > stop with positive step", "Empty slice; operator may return original or skip."),
    ("Negative start", "Python normalizes; document that negative indices count from end."),
    ("Negative stop", "Same as above; ensure result still valid prompt."),
    ("step == 0", "ValueError; reject operator before execution."),
    ("step < 0", "Allows reverse/striding; require explicit operator support."),
    ("Out-of-bounds indices", "Python clamps; log clamped values for replay."),
    ("Slice produces empty sequence", "Fallback to original prompt or critic rejection."),
    ("Unicode/zero-width chars", "Preserve or intentionally inject; log code points."),
]

# -------------------------------------------------------------------
# 8. Critic integration
# -------------------------------------------------------------------
# Critic returns coherence, novelty, bypass likelihood.
# Maintain operator_success[op] and operator_reject[op].
# Probability of selecting op = base_prob * (success+1)/(reject+1).
# If reversal is rejected often, its probability decreases.

# -------------------------------------------------------------------
# 9. Coverage report
# -------------------------------------------------------------------
# Write with context manager:
# with open(report_path, "w", encoding="utf-8") as f:
#     f.write("# Mutation Coverage Report\n")
#     f.write(f"Unique prompts: {n}\n")
#     f.write(f"Unique failure modes: {m}\n")
#     f.write("## Coverage growth\n...")
#     f.write("## Top 10 by severity\n...")

# -------------------------------------------------------------------
# 10. Experiment: coverage-guided vs random mutation
# -------------------------------------------------------------------
# IV: mutation strategy (coverage-guided vs random).
# DVs: unique failure modes found, coverage growth rate, target queries used.
# Control: same seed prompts, same target, same query budget, same judge.
# Measure: run 30 trials, compare mean unique failure modes with t-test.

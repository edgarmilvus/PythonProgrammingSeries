
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_6.py
# Description: Solution for Exercise 6
# ==========================================

# DESIGN/SPECIFICATION, not full implementation.

# -------------------------------------------------------------------
# 1. Command list
# -------------------------------------------------------------------
CLI_COMMANDS = {
    "load <file>": "Load a seed prompt from file.",
    "show": "Display current prompt.",
    "mutate <operator> [args]": "Apply mutation: reverse, stride n, delete s e, duplicate s e, swap a b c d.",
    "preview": "Show mutated prompt before sending.",
    "send": "Send prompt to target model.",
    "judge": "Run judge on target response.",
    "save <name>": "Save prompt, response, verdict to exploit journal.",
    "config": "Show current env config with secrets redacted.",
    "help": "Show available commands.",
    "exit": "Save session and exit.",
}

# -------------------------------------------------------------------
# 2. Architecture
# -------------------------------------------------------------------
# REPL loop:
#   line = input("redteam> ")
#   parts = shlex.split(line)
#   dispatch[parts[0]](parts[1:])
# Handlers update session state: current_prompt, current_response, verdict.
# All commands logged to session context manager.

# -------------------------------------------------------------------
# 3. Session context manager
# -------------------------------------------------------------------
class SessionContext:
    def __enter__(self):
        """Open session file in append mode; write header if new."""
        ...
    def __exit__(self, exc_type, exc, tb):
        """Flush/close; log exception if any; return False."""
        ...
    def log_command(self, command, result):
        """Append JSONL record with timestamp, command, result, state."""
        ...

# -------------------------------------------------------------------
# 4. Mutation operators using extended slicing
# -------------------------------------------------------------------
def op_reverse(text):
    """return text[::-1]"""
def op_stride(text, n):
    """return text[::n]"""
def op_delete(text, start, stop):
    """return text[:start] + text[stop:]"""
def op_duplicate(text, start, stop):
    """return text[:stop] + text[start:stop] + text[stop:]"""
def op_swap(text, a, b, c, d):
    """return text[:a] + text[c:d] + text[b:c] + text[a:b] + text[d:]"""
# Validate args: ints, step != 0, start/stop within bounds or clamp.

# -------------------------------------------------------------------
# 5. Live preview highlighting
# -------------------------------------------------------------------
def highlight_diff(original, mutated):
    """Use difflib.SequenceMatcher to find changed regions.
    Use extended slicing to build ANSI-highlighted output:
      original[:start] + RED + original[start:end] + RESET + original[end:]
    Print original and mutated side by side."""
    ...

# -------------------------------------------------------------------
# 6. Batch mode script format
# -------------------------------------------------------------------
BATCH_FORMAT = """
# batch.redteam
load seeds/seed1.txt
mutate reverse
preview
send
judge
save exp-reverse-001
load seeds/seed2.txt
mutate stride 2
send
judge
save exp-stride-002
"""
# Parser: ignore blank lines and comments; execute commands sequentially.

# -------------------------------------------------------------------
# 7. Env vars
# -------------------------------------------------------------------
CLI_ENV = [
    ("REDTEAM_CLI_TARGET_MODEL", "str", "required"),
    ("REDTEAM_CLI_JUDGE_MODEL", "str", "required"),
    ("REDTEAM_CLI_MUTATION_DEFAULTS", "str", "optional", "stride=2"),
    ("REDTEAM_CLI_SESSION_FILE", "str", "optional", "cli_session.jsonl"),
]

# -------------------------------------------------------------------
# 8. Unit tests
# -------------------------------------------------------------------
CLI_TESTS = [
    "Command parser handles quoted arguments with shlex.split.",
    "mutate reverse reverses current prompt.",
    "mutate stride 0 raises clear error and does not change prompt.",
    "Session context logs each command and closes file on exit.",
    "save writes journal record including command history.",
    "Batch mode executes commands from file in order.",
]

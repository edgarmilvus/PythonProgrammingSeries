
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# =====================================================================
#  linear_probe_hello_world.py
#  A fully self-contained "Hello World" for linear probes that detect
#  latent deception / untruthfulness in a model's internal activations.
#  Dependency: numpy only.
# =====================================================================

import numpy as np

# ---------------------------------------------------------------------
# ---------------------------------------------------------------------
N_DIM             = 8      # Width of the toy "residual stream" (8 neurons).
N_PER_CLASS       = 200    # How many truthful and how many deceptive examples.
SEPARATION        = 2.0    # Distance between the two class centroids.
CONFOUND_STRENGTH = 0.9    # How strongly a *style* axis correlates with the label.
NOISE_SCALE       = 1.0    # Standard deviation of the isotropic noise.
SEED_DATA         = 0      # Reproducibility for the dataset.
SEED_BALANCED     = 1      # Reproducibility for the confound-free dataset.
SEED_SPLIT        = 7      # Reproducibility for the train/test split.
EPOCHS            = 600    # Gradient-descent steps for the logistic probe.
LEARNING_RATE     = 0.5
L2_PENALTY        = 1e-3   # Weight decay: keeps the probe small and honest.
OOD_SHIFT         = 2.0    # How far we shift the confound axis out of distribution.


# ---------------------------------------------------------------------
# ---------------------------------------------------------------------
def make_dataset(n_per_class, confound_strength, seed):
    """Return (X, y): fake residual-stream activations and their labels.

    X has shape (2 * n_per_class, N_DIM); each row is one activation vector.
    y is 1.0 for deceptive internal states and 0.0 for truthful ones.
    """
    # A private generator keeps this function independent of global RNG state.
    rng = np.random.default_rng(seed)

    # The class centroids live on axis 0, which we declare to be "truthfulness".
    truthful_centre = np.zeros(N_DIM)
    truthful_centre[0] = +SEPARATION / 2.0
    deceptive_centre = np.zeros(N_DIM)
    deceptive_centre[0] = -SEPARATION / 2.0

    # Draw isotropic noise, then shift each cloud to its own centroid.
    X_truthful = rng.normal(0.0, NOISE_SCALE, (n_per_class, N_DIM)) + truthful_centre
    X_deceptive = rng.normal(0.0, NOISE_SCALE, (n_per_class, N_DIM)) + deceptive_centre

    # THE TRAP: axis 1 encodes *style* (hedging, hedging length, topic),
    # not truth, but it is accidentally correlated with the label.
    X_truthful[:, 1] += rng.normal(+confound_strength, 1.0, n_per_class)
    X_deceptive[:, 1] += rng.normal(-confound_strength, 1.0, n_per_class)

    # Stack the two clouds and build the matching label vector.
    X = np.vstack([X_truthful, X_deceptive])
    y = np.concatenate([np.zeros(n_per_class),   # 0.0 means truthful
                        np.ones(n_per_class)])   # 1.0 means deceptive
    return X, y


# ---------------------------------------------------------------------
# ---------------------------------------------------------------------
def train_test_split(X, y, test_fraction=0.3, seed=SEED_SPLIT):
    """Shuffle the rows, then hand back (X_tr, y_tr, X_te, y_te)."""
    rng = np.random.default_rng(seed)
    idx = rng.permutation(X.shape[0])          # Random order of all row indices.
    n_test = int(X.shape[0] * test_fraction)   # How many rows go to the test set.
    return (X[idx[n_test:]], y[idx[n_test:]],  # Train rows.
            X[idx[:n_test]], y[idx[:n_test]])  # Test rows.


def fit_scaler(X):
    """Compute per-feature mean and standard deviation on the TRAIN set only."""
    return X.mean(axis=0), X.std(axis=0) + 1e-8   # 1e-8 avoids divide-by-zero.


def apply_scaler(X, mu, sigma):
    """Apply the train-set statistics to any set of activations."""
    return (X - mu) / sigma


# ---------------------------------------------------------------------
# ---------------------------------------------------------------------
def mean_difference_probe(X, y):
    """One line of arithmetic: the deceptive centroid minus the truthful one."""
    return X[y == 1].mean(axis=0) - X[y == 0].mean(axis=0)


# ---------------------------------------------------------------------
# ---------------------------------------------------------------------
def sigmoid(z):
    """Numerically stable logistic function; clips z to avoid overflow."""
    z = np.clip(z, -60.0, 60.0)
    return 1.0 / (1.0 + np.exp(-z))


def fit_logistic_probe(X, y, epochs=EPOCHS, lr=LEARNING_RATE, l2=L2_PENALTY):
    """Full-batch gradient descent on the L2-regularised logistic loss."""
    n, d = X.shape
    w = np.zeros(d)   # Start with all weights at zero: a maximally unbiased probe.
    b = 0.0           # Start with a zero bias.
    for _ in range(epochs):
        p = sigmoid(X @ w + b)                      # Current P(deceptive) per row.
        err = p - y                                 # Residual: predicted minus true.
        w -= lr * ((X.T @ err) / n + l2 * w)        # Gradient step plus shrinkage.
        b -= lr * err.mean()                        # Gradient step on the bias.
    return w, b


# ---------------------------------------------------------------------
# ---------------------------------------------------------------------
def probe_scores(w, b, X):
    """Return P(deceptive) for every row of X."""
    return sigmoid(X @ w + b)


def accuracy(w, b, X, y):
    """Fraction of rows on which the probe's 0.5-threshold decision is correct."""
    return float(((probe_scores(w, b, X) >= 0.5).astype(int) == y).mean())


def confusion_counts(w, b, X, y, threshold=0.5):
    """Count the four safety-relevant outcomes at a given decision threshold.

    caught       : deceptive states correctly flagged     (safety win)
    missed       : deceptive states that slipped through  (safety failure)
    false_alarm  : truthful states wrongly flagged        (capability cost)
    passed       : truthful states correctly allowed      (capability win)
    """
    flag = probe_scores(w, b, X) >= threshold       # Everything above t is an alarm.
    is_deceptive = (y == 1)
    caught      = int(np.sum(flag & is_deceptive))
    missed      = int(np.sum(~flag & is_deceptive))
    false_alarm = int(np.sum(flag & ~is_deceptive))
    passed      = int(np.sum(~flag & ~is_deceptive))
    return caught, missed, false_alarm, passed


def threshold_for_false_alarm_budget(w, b, X, y, budget=0.05):
    """Smallest threshold whose false-alarm rate on this split stays under budget."""
    scores = probe_scores(w, b, X)
    is_deceptive = (y == 1)
    for thr in np.linspace(0.01, 1.0, 100):
        fa_rate = np.mean((scores >= thr) & ~is_deceptive)
        if fa_rate <= budget:
            return float(thr)
    return 1.0   # Only reachable if even the strictest threshold is too noisy.


# ---------------------------------------------------------------------
# ---------------------------------------------------------------------
def project_out(H, direction):
    """Delete the component of every row of H that points along `direction`."""
    d = direction / (np.linalg.norm(direction) + 1e-12)   # Unit vector.
    return H - np.outer(H @ d, d)                         # Orthogonal projection.


def behaviour(H):
    """A toy stand-in for 'the model asserts the truth' in its final answer.

    The readout depends on axis 0 (truth) and axis 2 (noise), and on nothing
    else. Axis 1 - the confound - is deliberately absent.
    """
    logits = 1.0 * H[:, 0] + 0.5 * H[:, 2] + 0.3
    return (logits > 0.0).astype(int)


def flip_rate(H_before, H_after):
    """Fraction of examples whose downstream behaviour changed after an edit."""
    return float((behaviour(H_before) != behaviour(H_after)).mean())


# ---------------------------------------------------------------------
# ---------------------------------------------------------------------
def lookup_probe(registry, layer_name):
    """Return (w, b, metadata) for a layer, or a safe placeholder if absent.

    We use dict.get() rather than registry[layer_name] so that a request for a
    layer we never trained returns an explicit 'no probe' record instead of
    raising a KeyError deep inside a live monitoring loop.
    """
    entry = registry.get(layer_name)
    if entry is None:
        return None, None, {"status": "no probe registered for " + layer_name}
    return entry


# ---------------------------------------------------------------------
# ---------------------------------------------------------------------
if __name__ == "__main__":
    # --- 8a. Build the confounded dataset and split it. -----------------
    X, y = make_dataset(N_PER_CLASS, CONFOUND_STRENGTH, SEED_DATA)
    X_tr, y_tr, X_te, y_te = train_test_split(X, y)

    # Fit the scaler on the train set only: using the test set would leak.
    mu, sigma = fit_scaler(X_tr)
    Xtr = apply_scaler(X_tr, mu, sigma)
    Xte = apply_scaler(X_te, mu, sigma)

    # --- 8b. The one-line probe, as a sanity check. ---------------------
    w_md = mean_difference_probe(Xtr, y_tr)
    print("mean-difference probe  train acc = %.3f  test acc = %.3f"
          % (accuracy(w_md, 0.0, Xtr, y_tr), accuracy(w_md, 0.0, Xte, y_te)))

    # --- 8c. The real thing: a logistic-regression linear probe. --------
    w, b = fit_logistic_probe(Xtr, y_tr)
    print("logistic probe         train acc = %.3f  test acc = %.3f"
          % (accuracy(w, b, Xtr, y_tr), accuracy(w, b, Xte, y_te)))

    # --- 8d. Which axes did the probe actually lean on? -----------------
    print("\nprobe weights  (axis 0 = truth, axis 1 = confound):")
    print(np.round(w, 3))

    # --- 8e. SAFETY vs CAPABILITY: the threshold sweep. -----------------
    # Raising the threshold means we only raise an alarm when very confident.
    # That protects capability (few false alarms) but costs safety (more miss).
    print("\nthreshold   false-alarm rate   miss rate")
    for thr in (0.10, 0.30, 0.50, 0.70, 0.90):
        caught, missed, fa, passed = confusion_counts(w, b, Xte, y_te, thr)
        n_deceptive = caught + missed
        n_truthful = fa + passed
        print("%8.2f   %16.3f   %8.3f"
              % (thr, fa / n_truthful, missed / n_deceptive))

    # The threshold a safety team would actually ship under a 5% alarm budget.
    ship_thr = threshold_for_false_alarm_budget(w, b, Xte, y_te, budget=0.05)
    caught, missed, fa, passed = confusion_counts(w, b, Xte, y_te, ship_thr)
    print("shipping threshold for a 5%% false-alarm budget: %.2f" % ship_thr)
    print("  caught %d of %d deceptive, false-alarmed %d of %d truthful"
          % (caught, caught + missed, fa, fa + passed))

    # --- 8f. CAUSAL AUDIT: ablate the direction and watch behaviour. ----
    # The probe was fit in standardised space, so convert its weights back to
    # raw activation space before intervening on the model's actual vectors.
    w_raw = w / sigma
    w_hat = w_raw / (np.linalg.norm(w_raw) + 1e-12)

    confound_axis = np.zeros(N_DIM)
    confound_axis[1] = 1.0

    H_probe_ablated = project_out(X_te, w_hat)
    H_conf_ablated = project_out(X_te, confound_axis)

    print("\nbehaviour flip rate after ablating the probe direction    = %.3f"
          % flip_rate(X_te, H_probe_ablated))
    print("behaviour flip rate after ablating the confound direction = %.3f"
          % flip_rate(X_te, H_conf_ablated))

    # --- 8g. DISTRIBUTION SHIFT: move the confound, keep the task. ------
    X_ood = X_te.copy()
    X_ood[:, 1] += OOD_SHIFT                       # Every prompt got wordier.
    X_ood_std = apply_scaler(X_ood, mu, sigma)
    print("\nin-distribution accuracy      = %.3f" % accuracy(w, b, Xte, y_te))
    print("shifted-distribution accuracy = %.3f" % accuracy(w, b, X_ood_std, y_te))

    # --- 8h. What a confound-free probe would have learned instead. -----
    X_bal, y_bal = make_dataset(N_PER_CLASS, 0.0, SEED_BALANCED)
    Xb_tr, yb_tr, Xb_te, yb_te = train_test_split(X_bal, y_bal, seed=SEED_SPLIT + 1)
    mu_b, sigma_b = fit_scaler(Xb_tr)
    w_bal, b_bal = fit_logistic_probe(apply_scaler(Xb_tr, mu_b, sigma_b), yb_tr)
    print("\nconfound-free probe on the shifted set = %.3f"
          % accuracy(w_bal, b_bal, apply_scaler(X_ood, mu_b, sigma_b), y_te))

    # --- 8i. A registry lookup that fails safely. -----------------------
    registry = {
        "blocks.6.hook_resid_post": (w, b, {"test_acc": accuracy(w, b, Xte, y_te)})
    }
    w_sel, b_sel, meta = lookup_probe(registry, "blocks.12.hook_resid_post")
    print("\nlayer 12 lookup ->", meta["status"])

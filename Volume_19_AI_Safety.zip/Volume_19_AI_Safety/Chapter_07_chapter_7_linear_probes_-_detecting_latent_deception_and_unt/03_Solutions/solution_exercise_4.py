
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# causal_steering_validation.py — reference intervention pipeline.
from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional, Callable, Any
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

@dataclass
class InterventionSpec:
    layer: int
    token_position: str          # "final", "subject", "answer", "all"
    mode: str                    # "add", "subtract", "project_out", "swap", "patch"
    strength: float = 1.0
    direction: Optional[torch.Tensor] = None
    patch_value: Optional[torch.Tensor] = None
    source_run: Optional[Dict[str, Any]] = None

class HookIntervention:
    """Registers a forward hook on a chosen residual/MLP module."""
    def __init__(self, module: torch.nn.Module, spec: InterventionSpec):
        self.spec = spec
        self.handle = module.register_forward_hook(self._hook)

    def _hook(self, module, inputs, output):
        if isinstance(output, tuple):
            h = output[0]
        else:
            h = output
        h = h.clone()
        B, T, H = h.shape
        pos = self._positions(T)
        d = self.spec.direction
        if d is not None:
            d = d.to(h.device, h.dtype).view(1, 1, -1)
        if self.spec.mode == "add" and d is not None:
            h[:, pos, :] = h[:, pos, :] + self.spec.strength * d
        elif self.spec.mode == "subtract" and d is not None:
            h[:, pos, :] = h[:, pos, :] - self.spec.strength * d
        elif self.spec.mode == "project_out" and d is not None:
            dn = d / (d.norm(dim=-1, keepdim=True) + 1e-9)
            proj = (h[:, pos, :] * dn).sum(dim=-1, keepdim=True) * dn
            h[:, pos, :] = h[:, pos, :] - self.spec.strength * proj
        elif self.spec.mode == "swap" and self.spec.patch_value is not None:
            pv = self.spec.patch_value.to(h.device, h.dtype)
            h[:, pos, :] = pv[:, pos, :]
        elif self.spec.mode == "patch" and self.spec.patch_value is not None:
            pv = self.spec.patch_value.to(h.device, h.dtype)
            h[:, pos, :] = pv[:, pos, :]
        if isinstance(output, tuple):
            return (h,) + output[1:]
        return h

    def _positions(self, T: int) -> Any:
        if self.spec.token_position == "final":
            return slice(T-1, T)
        if self.spec.token_position == "all":
            return slice(0, T)
        # In production, map "subject" and "answer" from tokenizer offsets.
        return slice(max(0, T//2), max(1, T//2 + 1))

    def remove(self):
        self.handle.remove()

@torch.no_grad()
def run_with_intervention(model, tokenizer, text: str, spec: InterventionSpec,
                          max_new_tokens: int = 8) -> Dict[str, Any]:
    inputs = tokenizer(text, return_tensors="pt").to(model.device)
    hook = HookIntervention(model.model.layers[spec.layer], spec)
    try:
        out = model.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False,
                             output_scores=True, return_dict_in_generate=True)
        text_out = tokenizer.decode(out.sequences[0], skip_special_tokens=True)
        # Capture final-layer hidden state for probe scoring.
        hidden = model(**inputs, output_hidden_states=True).hidden_states[spec.layer]
        pooled = hidden[:, -1, :].float().cpu().numpy()[0]
        return {"text": text_out, "pooled": pooled, "scores": out.scores}
    finally:
        hook.remove()

def compute_truth_direction(model, tokenizer, pairs: List[Tuple[str, str]], layer: int) -> torch.Tensor:
    """Difference-in-means direction: mean(deceptive) - mean(truthful)."""
    truthful, deceptive = [], []
    for t_text, d_text in pairs:
        for text, bucket in [(t_text, truthful), (d_text, deceptive)]:
            inputs = tokenizer(text, return_tensors="pt").to(model.device)
            with torch.no_grad():
                h = model(**inputs, output_hidden_states=True).hidden_states[layer]
            bucket.append(h[:, -1, :].float().cpu())
    t = torch.cat(truthful, dim=0).mean(dim=0)
    d = torch.cat(deceptive, dim=0).mean(dim=0)
    direction = d - t
    return direction / (direction.norm() + 1e-9)

def dose_response(model, tokenizer, text: str, layer: int, direction: torch.Tensor,
                  strengths: List[float], behavioral_metric: Callable) -> pd.DataFrame:
    rows = []
    for s in strengths:
        spec = InterventionSpec(layer=layer, token_position="final", mode="add",
                                strength=s, direction=direction)
        result = run_with_intervention(model, tokenizer, text, spec)
        rows.append({"strength": s, "behavior": behavioral_metric(result),
                     "probe_score": float(result["pooled"] @ direction.cpu().numpy())})
    return pd.DataFrame(rows)

def specificity_controls(model, tokenizer, text: str, layer: int,
                         truth_dir: torch.Tensor, control_dirs: Dict[str, torch.Tensor],
                         metric: Callable) -> pd.DataFrame:
    rows = []
    for name, d in [("truth", truth_dir)] + list(control_dirs.items()):
        spec = InterventionSpec(layer=layer, token_position="final", mode="add",
                                strength=1.0, direction=d)
        result = run_with_intervention(model, tokenizer, text, spec)
        rows.append({"direction": name, "metric": metric(result)})
    return pd.DataFrame(rows)

def paired_patching(model, tokenizer, truthful: str, deceptive: str,
                    layer: int, token_position: str = "final") -> Dict[str, Any]:
    # Capture clean activations.
    t_inputs = tokenizer(truthful, return_tensors="pt").to(model.device)
    d_inputs = tokenizer(deceptive, return_tensors="pt").to(model.device)
    with torch.no_grad():
        t_hidden = model(**t_inputs, output_hidden_states=True).hidden_states[layer]
        d_hidden = model(**d_inputs, output_hidden_states=True).hidden_states[layer]
    # Patch truthful into deceptive run.
    spec_t2d = InterventionSpec(layer=layer, token_position=token_position, mode="patch",
                                patch_value=t_hidden)
    spec_d2t = InterventionSpec(layer=layer, token_position=token_position, mode="patch",
                                patch_value=d_hidden)
    out_t2d = run_with_intervention(model, tokenizer, deceptive, spec_t2d)
    out_d2t = run_with_intervention(model, tokenizer, truthful, spec_d2t)
    return {"truth_to_deceptive": out_t2d, "deceptive_to_truth": out_d2t}

def off_target_battery(model, tokenizer, prompts: Dict[str, str],
                       spec: InterventionSpec) -> pd.DataFrame:
    rows = []
    for task, prompt in prompts.items():
        result = run_with_intervention(model, tokenizer, prompt, spec)
        rows.append({"task": task, "output": result["text"]})
    return pd.DataFrame(rows)

def reproducibility(model, tokenizer, examples: List[str], layer: int,
                    direction: torch.Tensor, seeds: List[int]) -> pd.DataFrame:
    rows = []
    for seed in seeds:
        torch.manual_seed(seed)
        np.random.seed(seed)
        # In production, also vary prompt order and batching.
        spec = InterventionSpec(layer=layer, token_position="final", mode="add",
                                strength=1.0, direction=direction)
        effects = []
        for text in examples:
            base = run_with_intervention(model, tokenizer, text,
                                         InterventionSpec(layer=layer, token_position="final",
                                                          mode="add", strength=0.0, direction=direction))
            interv = run_with_intervention(model, tokenizer, text, spec)
            effects.append(np.linalg.norm(interv["pooled"] - base["pooled"]))
        rows.append({"seed": seed, "mean_effect": float(np.mean(effects)),
                     "std_effect": float(np.std(effects))})
    return pd.DataFrame(rows)

def causal_validation_report(hypothesis: str, results: Dict[str, Any],
                             path: str = "CAUSAL_VALIDATION.md") -> None:
    report = f"""# Causal Validation Report

## Hypothesis
{hypothesis}

## What Is Causal vs Correlational
Causal claims are limited to the specific layer, token position, strength, and task tested.
Decoding performance alone is not evidence of causal use.

## Results
{results}

## Safety Considerations
Interventions can degrade fluency or alter unrelated behavior. Use projection or patching where possible.
Do not deploy steering as a lie detector without human oversight and off-target evaluation.
"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(report)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# async_harness_design.py — DESIGN ONLY: interfaces, schemas, and contracts. No full implementation.
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Protocol, AsyncIterator, Tuple
from contextvars import ContextVar
import asyncio

# ---------------------------
# Context variable schema
# ---------------------------
@dataclass(frozen=True)
class RunContext:
    run_id: str
    task_name: str
    layer_index: int
    pooling: str
    split: str
    seed: int
    output_path: str
    parent_task_id: Optional[str] = None
    model_revision: Optional[str] = None
    dataset_hash: Optional[str] = None

RUN_CTX: ContextVar[RunContext] = ContextVar("RUN_CTX")

def snapshot_context() -> Dict[str, Any]:
    """Return a serializable snapshot for logs, metrics, and audit logs."""
    ctx = RUN_CTX.get()
    return ctx.__dict__.copy()

def with_context(**updates: Any) -> RunContext:
    """Return a new context with safe overrides. Child tasks should call this explicitly."""
    base = RUN_CTX.get()
    return RunContext(**{**base.__dict__, **updates})

# ---------------------------
# Dataset and probe task schemas
# ---------------------------
@dataclass
class ProbeTaskSpec:
    name: str                      # e.g. truth_vs_falsity, deception_vs_error, high_vs_low_confidence
    label_column: str
    subset_filter: Dict[str, Any] = field(default_factory=dict)
    metric: str = "auroc"
    threshold: float = 0.5

@dataclass
class ActivationStorageSpec:
    format: str = "memmap"         # memmap, hdf5, zarr, or chunked npy
    chunk_rows: int = 1024
    dtype: str = "float16"
    path_template: str = "{output_path}/acts/{run_id}/{split}/{site}/{chunk}.npy"

@dataclass
class HarnessConfig:
    model_name: str
    model_revision: str
    tokenizer_name: str
    dataset_path: str
    dataset_hash: str
    layer_list: List[int]
    mlp_sites: List[int]
    pooling_methods: List[str]        # last, mean, max
    probe_tasks: List[ProbeTaskSpec]
    output_path: str
    max_concurrent_forward: int = 2
    max_write_queue: int = 8
    fail_policy: str = "mark_layer_failed"  # or "fail_run"

# ---------------------------
# Async model session context manager contract
# ---------------------------
class ModelSession(Protocol):
    async def __aenter__(self) -> "ModelSession": ...
    async def __aexit__(self, exc_type, exc, tb) -> None: ...
    async def forward(self, texts: List[str], layer_list: List[int],
                      mlp_sites: List[int], pooling: str) -> Dict[str, Any]: ...
    async def close(self) -> None: ...

class AsyncModelSession:
    """
    Contract:
    - __aenter__: acquire semaphore, load tokenizer/model, register hooks, return session.
    - __aexit__: unregister hooks, flush writers, release GPU memory, release semaphore.
    - Handles asyncio.CancelledError by flushing partial writes and writing resumption manifest.
    - Safe to enter multiple times only if resources allow; otherwise a global semaphore enforces one session.
    """
    async def __aenter__(self):
        raise NotImplementedError("Design contract only")

    async def __aexit__(self, exc_type, exc, tb):
        # Must always run cleanup:
        # 1. Unregister all hooks.
        # 2. Flush activation writers and close chunk files.
        # 3. Release GPU tensors and empty CUDA cache if available.
        # 4. Write resumption manifest if cancelled or partially completed.
        # 5. Release the session semaphore.
        raise NotImplementedError("Design contract only")

# ---------------------------
# Main harness interfaces
# ---------------------------
class ActivationWriter(Protocol):
    async def write_batch(self, site: str, split: str, batch_id: int,
                          sample_ids: List[str], activations: Any) -> None: ...
    async def flush(self) -> None: ...
    async def close(self) -> None: ...

class ProbeRegistry(Protocol):
    async def register(self, task: str, layer: int, pooling: str,
                       artifact_path: str, threshold: float) -> None: ...
    async def lookup(self, task: str, layer: Optional[int] = None,
                     pooling: Optional[str] = None) -> Dict[str, Any]: ...

class MetricEmitter(Protocol):
    async def emit(self, name: str, value: float, step: int,
                   context: Dict[str, Any]) -> None: ...

class AsyncDeceptionHarness:
    """
    Responsibilities:
    - Load dataset, validate model/tokenizer/dataset hashes.
    - Stream batches through model session.
    - Capture residual layers and MLP sites.
    - Write activations chunk-by-chunk.
    - Train one probe per task per layer using dev data.
    - Select best layer per task.
    - Stream metrics to logs/dashboard.
    - Persist probe registry.
    - Support query REPL/CLI.
    - Support cancellation and resumption from manifest.
    """
    def __init__(self, cfg: HarnessConfig): ...

    async def run(self) -> None:
        """
        Structured concurrency sketch:
        1. Start model session via async context manager.
        2. Start N extractor workers limited by asyncio.Semaphore.
        3. Start bounded writer queue.
        4. For each batch: acquire semaphore, forward, enqueue activations.
        5. After each layer completes, train/evaluate probes incrementally.
        6. Emit metrics with contextvars snapshot.
        7. On cancellation: cancel children, flush writers, write manifest.
        """
        raise NotImplementedError("Design contract only")

    async def query(self, statement: str, tasks: List[str],
                    layers: Optional[List[int]] = None) -> Dict[str, Any]:
        """
        Query interface:
        - Tokenize statement.
        - Run model in a fresh ModelSession.
        - Extract requested layers/pooling.
        - Apply selected probes from registry.
        - Return score, calibrated probability, threshold decision, and linear feature attributions.
        - Warn if current environment does not match run provenance.
        """
        raise NotImplementedError("Design contract only")

    async def resume(self, manifest_path: str) -> None:
        """
        Resume contract:
        - Verify dataset hash, model revision, tokenizer version, layer list, pooling.
        - Skip completed chunks/layers.
        - Rebuild writer state and probe registry.
        """
        raise NotImplementedError("Design contract only")

# ---------------------------
# Demonstration script description
# ---------------------------
DEMO = """
Command:
  python -m async_harness --dataset tiny_truth.jsonl --layers 0,4,8,12 --tasks truth_vs_falsity,deception_vs_error,high_vs_low_confidence

During run:
  - Harness prints streaming metrics:
      task=truth_vs_falsity layer=8 pooling=mean auroc=0.81 coverage@0.9=0.42
  - Contextvars attach run_id/task/layer/split/seed to every log line.

Interactive mode:
  probe> query "The capital of France is Paris."
  probe> query "The capital of France is Rome."
  probe> query "The capital of France might be Paris or Lyon."

Output:
  Shows scores from at least two layers and two tasks:
    task=truth_vs_falsity layer=4 score=0.31 calibrated=0.29 decision=truthful
    task=truth_vs_falsity layer=12 score=0.78 calibrated=0.74 decision=deceptive
    task=deception_vs_error layer=12 score=0.62 calibrated=0.58 decision=uncertain

Compare:
  probe> compare --statement "The capital of France is Rome." --tasks truth_vs_falsity --layers 0,4,8,12

Resume demo:
  probe> run --config demo.yaml
  [user cancels halfway]
  probe> resume --manifest runs/demo/resume_manifest.json
  Harness skips completed batches/layers and continues from manifest.

Async safety:
  - Every child task receives an explicit RunContext override.
  - ModelSession.__aexit__ flushes writers and unregisters hooks even on CancelledError.
  - Semaphore limits simultaneous forward passes.
  - Bounded queue provides backpressure to activation writers.
  - Query mode uses the same model-session abstraction and contextvars for reproducibility.
"""

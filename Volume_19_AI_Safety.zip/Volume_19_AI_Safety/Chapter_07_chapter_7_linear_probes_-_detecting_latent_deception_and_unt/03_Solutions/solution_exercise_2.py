
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# layer_probe_tournament.py — reference pipeline for layer-wise linear probing.
import dataclasses
from dataclasses import dataclass
from typing import Dict, List, Tuple, Any, Optional
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV, StratifiedKFold, cross_val_score
from sklearn.preprocessing import StandardScaler, normalize
from sklearn.metrics import (accuracy_score, balanced_accuracy_score, f1_score,
                             roc_auc_score, average_precision_score, precision_recall_curve,
                             brier_score_loss, log_loss)
from sklearn.calibration import calibration_curve
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import make_pipeline
import pandas as pd

@dataclass
class ProbeConfig:
    model_name: str
    layers: List[int]
    mlp_sites: List[int]
    pooling: str = "mean"          # last, mean, max
    preprocess: str = "standard"   # none, standard, l2, center_standard
    seed: int = 0
    max_length: int = 256

class ActivationExtractor:
    def __init__(self, cfg: ProbeConfig, device: str = "cuda"):
        self.cfg = cfg
        self.device = device
        self.tokenizer = AutoTokenizer.from_pretrained(cfg.model_name, use_fast=True)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        self.model = AutoModelForCausalLM.from_pretrained(
            cfg.model_name, torch_dtype=torch.bfloat16 if device == "cuda" else torch.float32
        ).to(device).eval()

    @torch.no_grad()
    def extract(self, texts: List[str]) -> Dict[str, np.ndarray]:
        """Return activations keyed by 'resid_{layer}' and 'mlp_{layer}' for chosen sites."""
        batch = self.tokenizer(
            texts, return_tensors="pt", padding=True, truncation=True,
            max_length=self.cfg.max_length
        ).to(self.device)
        outputs = self.model(**batch, output_hidden_states=True)
        hidden_states = outputs.hidden_states  # tuple: embedding + each layer
        acts: Dict[str, np.ndarray] = {}
        mask = batch["attention_mask"].bool()

        for layer in self.cfg.layers:
            h = hidden_states[layer]  # [B, T, H]
            acts[f"resid_{layer}"] = self.pool(h, mask, self.cfg.pooling)

        # MLP outputs require hooks in a real implementation. Here we show the contract.
        # For each mlp_site, capture the MLP output and pool it.
        for site in self.cfg.mlp_sites:
            # Placeholder: replace with forward hook capture.
            h = hidden_states[site]
            acts[f"mlp_{site}"] = self.pool(h, mask, self.cfg.pooling)
        return acts

    def pool(self, hidden: torch.Tensor, mask: torch.Tensor, method: str) -> np.ndarray:
        hidden = hidden.float().cpu()
        mask = mask.cpu()
        if method == "last":
            lengths = mask.sum(dim=1) - 1
            return hidden[torch.arange(hidden.size(0)), lengths].numpy()
        if method == "mean":
            m = mask.unsqueeze(-1)
            return ((hidden * m).sum(dim=1) / m.sum(dim=1).clamp_min(1)).numpy()
        if method == "max":
            h = hidden.masked_fill(~mask.unsqueeze(-1), -1e9)
            return h.max(dim=1).values.numpy()
        raise ValueError(method)

def preprocess_features(X_train: np.ndarray, X_other: List[np.ndarray], mode: str):
    if mode == "none":
        return [X_train] + X_other
    if mode == "standard":
        scaler = StandardScaler().fit(X_train)
        return [scaler.transform(X_train)] + [scaler.transform(X) for X in X_other]
    if mode == "l2":
        return [normalize(X_train)] + [normalize(X) for X in X_other]
    if mode == "center_standard":
        mean = X_train.mean(axis=0, keepdims=True)
        Xc = X_train - mean
        scale = Xc.std(axis=0, keepdims=True) + 1e-6
        return [Xc / scale] + [(X - mean) / scale for X in X_other]
    raise ValueError(mode)

def train_logistic_probe(X: np.ndarray, y: np.ndarray, seed: int = 0) -> LogisticRegression:
    base = LogisticRegression(max_iter=5000, class_weight="balanced", random_state=seed)
    inner = StratifiedKFold(n_splits=5, shuffle=True, random_state=seed)
    grid = GridSearchCV(base, {"C": [0.01, 0.1, 1.0, 10.0]}, cv=inner, scoring="roc_auc", n_jobs=-1)
    grid.fit(X, y)
    return grid.best_estimator_

def metrics(y: np.ndarray, score: np.ndarray, threshold: float = 0.5) -> Dict[str, float]:
    pred = (score >= threshold).astype(int)
    precision, recall, _ = precision_recall_curve(y, score)
    # precision at recall >= 0.8
    idx = np.where(recall >= 0.8)[0]
    p_at_r80 = float(precision[idx].max()) if len(idx) else 0.0
    return {
        "accuracy": accuracy_score(y, pred),
        "balanced_accuracy": balanced_accuracy_score(y, pred),
        "f1": f1_score(y, pred),
        "auroc": roc_auc_score(y, score) if len(set(y)) > 1 else np.nan,
        "average_precision": average_precision_score(y, score) if len(set(y)) > 1 else np.nan,
        "precision_at_recall_0.8": p_at_r80,
        "brier": brier_score_loss(y, score),
        "log_loss": log_loss(y, np.clip(score, 1e-6, 1-1e-6)) if len(set(y)) > 1 else np.nan,
    }

def bootstrap_ci(y: np.ndarray, score: np.ndarray, metric_fn, n_boot: int = 500, seed: int = 0):
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(n_boot):
        idx = rng.integers(0, len(y), len(y))
        if len(set(y[idx])) < 2:
            continue
        vals.append(metric_fn(y[idx], score[idx]))
    return float(np.mean(vals)), float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))

class LayerProbeTournament:
    def __init__(self, cfg: ProbeConfig, dataset: pd.DataFrame):
        self.cfg = cfg
        self.df = dataset
        self.extractor = ActivationExtractor(cfg)
        self.results = []

    def run(self):
        texts = self.df["text"].tolist()
        acts = self.extractor.extract(texts)
        y = (self.df["label"] == "deceptive").astype(int).values
        splits = self.df["split"].values

        for layer_name, X in acts.items():
            train_idx = np.where(splits == "train")[0]
            dev_idx = np.where(splits == "dev")[0]
            Xtr, Xdev = X[train_idx], X[dev_idx]
            ytr, ydev = y[train_idx], y[dev_idx]

            Xtr_p, Xdev_p = preprocess_features(Xtr, [Xdev], self.cfg.preprocess)
            probe = train_logistic_probe(Xtr_p, ytr, seed=self.cfg.seed)
            dev_score = probe.predict_proba(Xdev_p)[:, 1]
            dev_metrics = metrics(ydev, dev_score)
            self.results.append({"site": layer_name, "split": "dev", **dev_metrics})

        self.results_df = pd.DataFrame(self.results)
        return self.results_df

    def select_layer(self) -> str:
        """Select the best layer using only dev AUROC, with stability penalty."""
        df = self.results_df[self.results_df["split"] == "dev"].copy()
        df = df.sort_values(["auroc", "balanced_accuracy"], ascending=False)
        return df.iloc[0]["site"]

    def final_test(self, selected_site: str):
        texts = self.df["text"].tolist()
        acts = self.extractor.extract(texts)
        X = acts[selected_site]
        y = (self.df["label"] == "deceptive").astype(int).values
        splits = self.df["split"].values

        train_idx = np.where(splits == "train")[0]
        test_splits = ["test_id", "test_ood_domain", "test_ood_template"]
        Xtr, ytr = X[train_idx], y[train_idx]
        Xtr_p, = preprocess_features(Xtr, [], self.cfg.preprocess)
        probe = train_logistic_probe(Xtr_p, ytr, seed=self.cfg.seed)

        rows = []
        for sp in test_splits:
            idx = np.where(splits == sp)[0]
            if len(idx) == 0:
                continue
            Xsp_p, = preprocess_features(Xtr, [X[idx]], self.cfg.preprocess)
            score = probe.predict_proba(Xsp_p)[:, 1]
            m = metrics(y[idx], score)
            mean, lo, hi = bootstrap_ci(y[idx], score, lambda yy, ss: roc_auc_score(yy, ss))
            rows.append({"split": sp, "auroc_mean": mean, "auroc_lo": lo, "auroc_hi": hi, **m})
        return pd.DataFrame(rows), probe

    def baselines(self):
        y = (self.df["label"] == "deceptive").astype(int).values
        splits = self.df["split"].values
        rows = []
        for sp in ["test_id", "test_ood_domain", "test_ood_template"]:
            idx = np.where(splits == sp)[0]
            if len(idx) == 0:
                continue
            ysp = y[idx]
            maj = np.ones_like(ysp) * (ysp.mean() >= 0.5)
            rows.append({"baseline": "majority", "split": sp, **metrics(ysp, maj.astype(float))})
            lengths = self.df["token_length"].values[idx].reshape(-1, 1)
            lr = LogisticRegression(class_weight="balanced").fit(lengths, ysp)
            rows.append({"baseline": "length_only", "split": sp, **metrics(ysp, lr.predict_proba(lengths)[:, 1])})
            # TF-IDF baseline trained on train, evaluated on sp.
            tr = np.where(splits == "train")[0]
            vec = TfidfVectorizer(max_features=5000, ngram_range=(1, 2))
            Xtr = vec.fit_transform(self.df["text"].iloc[tr])
            Xsp = vec.transform(self.df["text"].iloc[idx])
            clf = LogisticRegression(max_iter=5000, class_weight="balanced").fit(Xtr, y[tr])
            rows.append({"baseline": "tfidf", "split": sp, **metrics(ysp, clf.predict_proba(Xsp)[:, 1])})
        return pd.DataFrame(rows)

    def stability(self, selected_site: str, seeds: List[int] = [0, 1, 2, 3, 4]):
        texts = self.df["text"].tolist()
        acts = self.extractor.extract(texts)
        X = acts[selected_site]
        y = (self.df["label"] == "deceptive").astype(int).values
        splits = self.df["split"].values
        tr = np.where(splits == "train")[0]
        Xtr, ytr = X[tr], y[tr]
        Xtr_p, = preprocess_features(Xtr, [], self.cfg.preprocess)
        weights, scores = [], []
        for s in seeds:
            p = train_logistic_probe(Xtr_p, ytr, seed=s)
            weights.append(p.coef_.ravel())
            scores.append(p.score(Xtr_p, ytr))
        weights = np.array(weights)
        cos = []
        for i in range(len(weights)):
            for j in range(i+1, len(weights)):
                a, b = weights[i], weights[j]
                cos.append(float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-9)))
        return {"accuracy_mean": float(np.mean(scores)), "accuracy_std": float(np.std(scores)),
                "weight_cosine_mean": float(np.mean(cos)), "weight_cosine_std": float(np.std(cos))}

def write_probe_model_card(path: str, cfg: ProbeConfig, selected_site: str, test_table: pd.DataFrame):
    card = f"""# Linear Truthfulness Probe Model Card

## Model
- Base model: {cfg.model_name}
- Selected site: {selected_site}
- Pooling: {cfg.pooling}
- Preprocessing: {cfg.preprocess}
- Classifier: LogisticRegression with balanced class weights and nested CV C selection.

## Intended Use
Research monitoring and auditing of truthfulness/deception-related activations. Not a general lie detector.

## Evaluation
{test_table.to_markdown(index=False)}

## Known Failure Modes
Domain shift, template shift, entity shift, calibration drift, and reliance on surface confounds. Requires confound-resistant evaluation before deployment.

## Reproduction
Use deterministic activation extraction, fixed tokenizer/chat template, and the saved probe artifact plus preprocessing scaler.
"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(card)

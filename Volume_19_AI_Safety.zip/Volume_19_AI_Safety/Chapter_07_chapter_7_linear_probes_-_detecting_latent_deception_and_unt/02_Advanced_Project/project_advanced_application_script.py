
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# deception_probe_monitor.py
import json
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score

RNG = np.random.default_rng(7)

def synthetic_multilayer_activations(n, d, n_layers, shift=0.0, seed=0):
    """Contrastive activations: truthful vs deceptive completions."""
    rng = np.random.default_rng(seed)
    n_dec, n_truth = n // 2, n - n // 2
    truth = rng.normal(0, 1, size=(n_truth, d))
    deception_dir = rng.normal(size=d); deception_dir /= np.linalg.norm(deception_dir)
    deceptive = rng.normal(0, 1, size=(n_dec, d)) + 1.1 * deception_dir
    X_base = np.vstack([truth, deceptive])
    y = np.concatenate([np.zeros(n_truth), np.ones(n_dec)])
    confound = rng.normal(loc=y * 0.9, scale=1.0, size=(n, 1))
    X_base[:, 0:1] += 0.7 * confound  # Spurious verbosity/style feature.
    layers, mid = {}, n_layers // 2
    for layer in range(n_layers):
        signal = 1.35 if layer == mid else 0.35 + 0.08 * abs(layer - mid)
        noise = rng.normal(0, 1.0 if layer != mid else 0.7, size=(n, d))
        X = X_base + signal * np.outer(y, deception_dir) + noise
        X += shift * rng.normal(0, 1.0, size=(n, 1))  # Domain shift.
        layers[layer] = X
    idx = rng.permutation(n)
    return {k: v[idx] for k, v in layers.items()}, y[idx], deception_dir

def train_probe(X_train, y_train):
    """Fit a standardized logistic-regression linear probe."""
    scaler = StandardScaler().fit(X_train)
    clf = LogisticRegression(max_iter=1000, C=0.5, class_weight="balanced")
    clf.fit(scaler.transform(X_train), y_train)
    return scaler, clf

def probe_scores(scaler, clf, X):
    """Return probability of the deceptive class."""
    return clf.predict_proba(scaler.transform(X))[:, 1]

def select_layer(layers_train, y_train, layers_val, y_val):
    """Sweep layers and pick the best validation-AUC probe."""
    best = {"layer": None, "auc": -1, "scaler": None, "clf": None}
    for layer, X_tr in layers_train.items():
        scaler, clf = train_probe(X_tr, y_train)
        auc = roc_auc_score(y_val, probe_scores(scaler, clf, layers_val[layer]))
        if auc > best["auc"]:
            best = {"layer": layer, "auc": auc, "scaler": scaler, "clf": clf}
    return best

def calibrate_threshold(y_cal, scores_cal, max_fpr=0.05):
    """Threshold keeping false positives within a safety budget."""
    return float(np.quantile(scores_cal[y_cal == 0], 1.0 - max_fpr))

def evaluate(scores, y, threshold):
    """Compute recall, precision, false-positive rate, and AUC."""
    pred = (scores >= threshold).astype(int)
    tp = int(((pred == 1) & (y == 1)).sum()); fp = int(((pred == 1) & (y == 0)).sum())
    fn = int(((pred == 0) & (y == 1)).sum()); tn = int(((pred == 0) & (y == 0)).sum())
    return {"recall": tp / max(tp + fn, 1), "precision": tp / max(tp + fp, 1),
            "fpr": fp / max(fp + tn, 1),
            "auc": roc_auc_score(y, scores) if len(set(y)) > 1 else float("nan")}

class ProbeAuditLog:
    """Context manager guaranteeing the audit file is closed."""
    def __init__(self, path): self.path = path
    def __enter__(self):
        self.fh = open(self.path, "a", encoding="utf-8"); return self.fh
    def __exit__(self, exc_type, exc, tb):
        self.fh.close(); return False

def causal_steering_check(scaler, clf, X_dec, strengths):
    """Intervene along the probe direction; measure detection vs utility."""
    X_scaled = scaler.transform(X_dec)
    direction = clf.coef_[0] / np.linalg.norm(clf.coef_[0])
    original = clf.predict_proba(X_scaled)[:, 1]
    results = []
    for strength in strengths:
        steered = X_scaled - strength * direction
        scores = clf.predict_proba(steered)[:, 1]
        utility = 1.0 / (1.0 + np.linalg.norm(steered - X_scaled, axis=1).mean())
        results.append((strength, float(original.mean()), float(scores.mean()), float(utility)))
    return results

def wsgi_monitor_app(state):
    """Minimal WSGI callable for Gunicorn or Waitress."""
    def application(environ, start_response):
        body = json.dumps(state, indent=2).encode("utf-8")
        start_response("200 OK", [("Content-Type", "application/json")])
        return [body]
    return application

def main():
    # Contrastive train/val/calibration/test and shifted test sets.
    X_train_l, y_train, _ = synthetic_multilayer_activations(800, 64, 12, seed=1)
    X_val_l, y_val, _ = synthetic_multilayer_activations(300, 64, 12, seed=2)
    X_cal_l, y_cal, _ = synthetic_multilayer_activations(300, 64, 12, seed=3)
    X_test_l, y_test, _ = synthetic_multilayer_activations(300, 64, 12, seed=4)
    X_shift_l, y_shift, _ = synthetic_multilayer_activations(300, 64, 12, shift=0.5, seed=5)
    # Layer sweep with a for loop; validation AUC selects the layer.
    best = select_layer(X_train_l, y_train, X_val_l, y_val)
    scaler, clf, layer = best["scaler"], best["clf"], best["layer"]
    # Calibrate threshold on held-out truthful examples.
    cal_scores = probe_scores(scaler, clf, X_cal_l[layer])
    threshold = calibrate_threshold(y_cal, cal_scores, max_fpr=0.05)
    # Evaluate in-distribution and under distribution shift.
    test_scores = probe_scores(scaler, clf, X_test_l[layer])
    shift_scores = probe_scores(scaler, clf, X_shift_l[layer])
    metrics = {"selected_layer": layer, "validation_auc": best["auc"], "threshold": threshold,
               "test": evaluate(test_scores, y_test, threshold),
               "shift": evaluate(shift_scores, y_shift, threshold)}
    # Causal sanity check: steering lowers deception score but costs utility.
    deceptive = X_test_l[layer][y_test == 1]
    metrics["steering"] = causal_steering_check(scaler, clf, deceptive, [0.0, 0.5, 1.0, 2.0])
    # Context-managed audit record.
    with ProbeAuditLog("probe_audit.jsonl") as log:
        log.write(json.dumps(metrics) + "\n")
    # WSGI app can be imported by a production server.
    app = wsgi_monitor_app(metrics)
    print(json.dumps(metrics, indent=2))
    return app

if __name__ == "__main__":
    APP = main()

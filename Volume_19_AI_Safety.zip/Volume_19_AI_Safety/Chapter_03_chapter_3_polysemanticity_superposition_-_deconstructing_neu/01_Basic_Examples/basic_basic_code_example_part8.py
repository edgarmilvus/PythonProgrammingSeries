
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example_part8.py
# Description: Basic Code Example
# ==========================================

def matching_pursuit(h, W, max_steps=3, threshold=0.1):
    """Recover a sparse feature vector from neuron activations."""
    num_features = len(W[0])
    x_recovered = [0.0] * num_features
    residual = h[:]
    for step in range(max_steps):
        # Correlate residual with each feature direction (column of W).
        correlations = [dot(residual, [W[0][j], W[1][j]]) for j in range(num_features)]
        # Pick the feature with the largest absolute correlation.
        best_j = max(range(num_features), key=lambda j: abs(correlations[j]))
        best_corr = correlations[best_j]
        if abs(best_corr) < threshold:
            break  # No feature strong enough; stop.
        # Add the best feature to the reconstruction.
        x_recovered[best_j] += best_corr
        # Update residual by subtracting the best feature's contribution.
        for i in range(len(h)):
            residual[i] -= best_corr * W[i][best_j]
    return x_recovered


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# safety_sae_monitor.py
import asyncio
import numpy as np
from dataclasses import dataclass
from typing import AsyncIterator, Dict

# Logical operators combine Boolean feature flags into safety rules.
def AND(a: bool, b: bool) -> bool:
    return a and b

def OR(a: bool, b: bool) -> bool:
    return a or b

def NOT(a: bool) -> bool:
    return not a

@dataclass
class FeatureFlag:
    # A monosemantic feature extracted by the SAE.
    name: str
    active: bool
    strength: float

class ToySuperpositionSAE:
    # Toy SAE: features live in a lower-dimensional space with interference.
    def __init__(self, n_features=8, n_dims=4, sparsity=0.2, seed=7):
        rng = np.random.default_rng(seed)
        self.n_features = n_features
        self.n_dims = n_dims
        self.sparsity = sparsity
        # Dictionary columns are near-orthogonal feature directions.
        self.D = rng.normal(size=(n_features, n_dims))
        self.D /= np.linalg.norm(self.D, axis=1, keepdims=True)
        # Threshold is the safety/capability dial.
        self.threshold = 0.15

    def set_safety_dial(self, threshold: float):
        # Low threshold: high recall, high false positives, capability loss.
        # High threshold: high precision, missed unsafe features, safety risk.
        self.threshold = float(np.clip(threshold, 0.01, 0.99))

    def encode(self, x: np.ndarray) -> np.ndarray:
        # ISTA sparse coding: find z such that x ~= z @ D.
        z = np.zeros(self.n_features)
        for _ in range(30):
            residual = x - z @ self.D
            grad = -2.0 * residual @ self.D.T
            z = z - 0.1 * grad
            # Soft thresholding enforces sparsity and reduces interference.
            z = np.sign(z) * np.maximum(np.abs(z) - 0.1 * self.sparsity, 0.0)
        return z

    def flags(self, z: np.ndarray) -> Dict[str, FeatureFlag]:
        # Convert continuous sparse code into Boolean feature flags.
        return {
            f"f{i}": FeatureFlag(f"f{i}", bool(v > self.threshold), float(v))
            for i, v in enumerate(z)
        }

class SafetyPolicy:
    # Policy rules are logical combinations of monosemantic features.
    def __init__(self):
        self.rules = {
            "self_harm": lambda f: AND(f["f2"].active, NOT(f["f0"].active)),
            "violence": lambda f: OR(f["f3"].active, f["f4"].active),
            "jailbreak": lambda f: AND(f["f5"].active, f["f6"].active),
        }

    def evaluate(self, flags):
        # Evaluate every rule against the current feature flags.
        return {name: rule(flags) for name, rule in self.rules.items()}

async def streaming_llm(prompt: str) -> AsyncIterator[str]:
    # Simulated non-blocking token stream from an LLM.
    tokens = ["I", " can", " help", " with", " that", " safely", "."]
    for token in tokens:
        await asyncio.sleep(0.01)
        yield token

async def activation_extractor(token: str, sae: ToySuperpositionSAE) -> np.ndarray:
    # Toy hidden activation: sparse ground-truth features -> superposition vector.
    z_true = np.zeros(sae.n_features)
    if "help" in token:
        z_true[0] = 1.0
    if "safely" in token:
        z_true[1] = 0.8
    if "that" in token:
        z_true[2] = 0.9
    if "with" in token:
        z_true[3] = 0.7
    x = z_true @ sae.D
    return x

async def monitor(prompt: str, safety_threshold: float = 0.15):
    # Build the SAE and set the safety/capability trade-off dial.
    sae = ToySuperpositionSAE()
    sae.set_safety_dial(safety_threshold)
    policy = SafetyPolicy()
    async for token in streaming_llm(prompt):
        # Extract activation for the current token.
        x = await activation_extractor(token, sae)
        # Decompose polysemantic activation into sparse features.
        z = sae.encode(x)
        # Convert sparse code to logical feature flags.
        flags = sae.flags(z)
        # Apply logical safety policy.
        decisions = policy.evaluate(flags)
        if any(decisions.values()):
            # Steering vector: subtract unsafe feature direction.
            x_steered = x - 0.5 * sae.D[2] if flags["f2"].active else x
            print(f"[BLOCK/STEER] token={token!r} decisions={decisions}")
            return
        print(f"[ALLOW] token={token!r}")

if __name__ == "__main__":
    # Run the async monitor with a balanced safety threshold.
    asyncio.run(monitor("Tell me how to be safe", safety_threshold=0.15))

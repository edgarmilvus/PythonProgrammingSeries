
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# superposition_explorer_app.py
import streamlit as st
import torch
import numpy as np
import matplotlib.pyplot as plt

# Reuse toy model, generator, and training functions from Exercise 1.
# from toy_superposition import ToyModel, SparseGenerator, train

st.set_page_config(page_title='Superposition Explorer', layout='wide')
st.title('Superposition Explorer')

@st.cache_data(show_spinner=False)
def train_cached(n_features, hidden_dim, p, l1, steps, seed):
    cfg = dict(
        n_features=n_features, hidden_dim=hidden_dim, p=p, l1=l1,
        steps=steps, seed=seed, lr=1e-3, batch_size=512, tied=True
    )
    model, gen = train(cfg)
    return model, gen

with st.sidebar:
    st.header('Controls')
    n_features = st.slider('True features', 2, 20, 5)
    hidden_dim = st.slider('Hidden dim', 1, 5, 2)
    p = st.slider('Sparsity p', 0.01, 1.0, 0.1)
    l1 = st.slider('L1 penalty', 0.0, 1.0, 0.1)
    steps = st.slider('Training steps', 100, 5000, 1000, step=100)
    seed = st.number_input('Seed', 0, 9999, 0)
    train_btn = st.button('Train / Refresh')

if 'model' not in st.session_state or train_btn:
    with st.spinner('Training...'):
        st.session_state.model, st.session_state.gen = train_cached(
            n_features, hidden_dim, p, l1, steps, seed
        )

model = st.session_state.model
gen = st.session_state.gen

tab_geom, tab_heat, tab_guess, tab_steer = st.tabs(
    ['Geometry', 'Heatmaps', 'Guess the Neuron', 'Steer the Feature']
)

with tab_geom:
    st.subheader('Feature directions in hidden space')
    D = model.feature_directions_in_hidden().numpy()
    if D.shape[1] > 2:
        D = D - D.mean(0)
        u, s, vt = np.linalg.svd(D, full_matrices=False)
        D = u[:, :2] * s[:2]
    fig, ax = plt.subplots()
    for i, v in enumerate(D):
        ax.arrow(0, 0, v[0], v[1], head_width=0.05)
        ax.text(v[0] * 1.1, v[1] * 1.1, f'f{i}')
    ax.axis('equal')
    st.pyplot(fig)

with tab_heat:
    x = gen.sample()
    with torch.no_grad():
        _, h = model(x)
    H = h.numpy()
    F = x.numpy()
    C = np.corrcoef(H.T, F.T)[:H.shape[1], H.shape[1]:]
    fig, ax = plt.subplots()
    im = ax.imshow(C, cmap='coolwarm', vmin=-1, vmax=1)
    ax.set_xlabel('True feature')
    ax.set_ylabel('Hidden neuron')
    plt.colorbar(im, ax=ax)
    st.pyplot(fig)

with tab_guess:
    st.subheader('Guess the Neuron')
    if st.button('New round'):
        st.session_state.neuron = np.random.randint(hidden_dim)
    neuron = st.session_state.get('neuron', 0)
    x = gen.sample()
    with torch.no_grad():
        _, h = model(x)
    top = torch.topk(h[:, neuron], 5).indices
    st.write('Top activating examples feature activations:')
    st.dataframe(x[top].numpy())
    guess = st.radio('Your guess', ['monosemantic', 'polysemantic', 'mixed'])
    if st.button('Submit guess'):
        H = h.numpy()
        F = x.numpy()
        C = np.corrcoef(H.T, F.T)[:H.shape[1], H.shape[1]:]
        st.write('Correlations with true features:', C[neuron])
        st.write('Correct answer revealed above.')

with tab_steer:
    st.subheader('Steer the Feature')
    st.warning('Steering can have unintended effects. Use for education only.')
    feat = st.selectbox('Select hidden unit / feature', list(range(hidden_dim)))
    alpha = st.slider('alpha', -2.0, 2.0, 0.0)
    x = gen.sample()
    with torch.no_grad():
        h = torch.relu(model.enc(x))
        h_steer = h.clone()
        h_steer[:, feat] += alpha
        x_hat = model.dec(h_steer)
        base = model.dec(h)
    st.write('Change in reconstruction norm:', (x_hat - base).norm(dim=1).mean().item())
    st.write('Mean effect on features:', (x_hat - base).mean(0).numpy())

st.sidebar.info(
    'Adjust controls to explore the phase transition. '
    'Low p and many features favor superposition.'
)

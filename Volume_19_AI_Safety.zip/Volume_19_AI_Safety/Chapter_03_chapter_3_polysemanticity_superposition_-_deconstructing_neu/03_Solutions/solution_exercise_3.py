
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# sae_dead_revival.py
import torch, torch.nn as nn, torch.optim as optim
import numpy as np, matplotlib.pyplot as plt
from scipy.optimize import linear_sum_assignment

class SAE(nn.Module):
    def __init__(self, input_dim, dict_size, topk=None):
        super().__init__()
        self.enc = nn.Linear(input_dim, dict_size)
        self.dec = nn.Linear(dict_size, input_dim, bias=False)
        self.bias = nn.Parameter(torch.zeros(dict_size))
        self.topk = topk

    def forward(self, x):
        pre = self.enc(x) + self.bias
        if self.topk is None:
            h = torch.relu(pre)
        else:
            vals, idx = torch.topk(pre, self.topk, dim=1)
            h = torch.zeros_like(pre)
            h.scatter_(1, idx, torch.relu(vals))
        x_hat = self.dec(h) + self.enc.bias
        return x_hat, h

def train_sae(sae, data_fn, steps, l1=1e-3, lr=1e-3, resample=False,
              warmup=500, dead_thresh=1e-4, resample_every=500, seed=0):
    torch.manual_seed(seed)
    opt = optim.Adam(sae.parameters(), lr=lr)
    dead_history = []

    for step in range(steps):
        x = data_fn()
        x_hat, h = sae(x)
        recon = ((x - x_hat) ** 2).mean()
        sparsity = h.abs().mean()
        loss = recon + l1 * sparsity
        opt.zero_grad()
        loss.backward()
        opt.step()

        if step % 100 == 0:
            with torch.no_grad():
                freq = (h > 1e-6).float().mean(0)
                dead = freq < dead_thresh
                dead_history.append(dead.sum().item())

        if resample and step > warmup and step % resample_every == 0:
            with torch.no_grad():
                freq = (h > 1e-6).float().mean(0)
                dead = freq < dead_thresh
                if dead.any():
                    err = ((x - x_hat) ** 2).mean(1)
                    idx = torch.argsort(err, descending=True)[:dead.sum()]
                    for j, didx in enumerate(torch.where(dead)[0]):
                        v = x[idx[j]]
                        v = v / (v.norm() + 1e-8)
                        sae.enc.weight[didx] = v
                        sae.dec.weight[:, didx] = v
                        sae.bias[didx] = 0.0
                    # Simplified Adam state reset for dead features.
                    for p in [sae.enc.weight, sae.enc.bias, sae.dec.weight]:
                        if p in opt.state and 'exp_avg' in opt.state[p]:
                            opt.state[p]['exp_avg'][didx] = 0
                            opt.state[p]['exp_avg_sq'][didx] = 0
    return dead_history

def evaluate_recovery(sae, true_dirs, thresholds=(0.9, 0.8, 0.7)):
    D = sae.dec.weight.detach().T
    D = D / D.norm(dim=1, keepdim=True).clamp_min(1e-8)
    T = true_dirs / true_dirs.norm(dim=1, keepdim=True).clamp_min(1e-8)
    cos = torch.mm(T, D.T).abs().numpy()
    row, col = linear_sum_assignment(-cos)
    matched = cos[row, col]
    max_cos = cos.max(1)
    return dict(
        avg_max=max_cos.mean(),
        median=np.median(max_cos),
        min=max_cos.min(),
        frac_gt={t: (max_cos > t).mean() for t in thresholds},
        matched=matched
    )

def make_superposed_data(n_features=10, hidden_dim=2, p=0.05, batch_size=1024, seed=0):
    g = torch.Generator().manual_seed(seed)
    def sample():
        mask = (torch.rand(batch_size, n_features, generator=g) < p).float()
        x = mask * torch.rand(batch_size, n_features, generator=g)
        W = torch.randn(hidden_dim, n_features, generator=torch.Generator().manual_seed(42))
        h = torch.relu(W @ x.T).T
        x_hat = W.T @ h.T
        return x_hat.T  # superposed activations
    return sample

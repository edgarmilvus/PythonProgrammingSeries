
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# circuit_steering.py
import torch, torch.nn as nn, torch.optim as optim
import numpy as np, matplotlib.pyplot as plt
import networkx as nx

class TaskModel(nn.Module):
    def __init__(self, n_in, hidden=16, n_out=2):
        super().__init__()
        self.fc1 = nn.Linear(n_in, hidden)
        self.fc2 = nn.Linear(hidden, n_out)

    def forward(self, x, return_hidden=False):
        h = torch.relu(self.fc1(x))
        out = self.fc2(h)
        if return_hidden:
            return out, h
        return out

def train_task(X, y, hidden=16, epochs=300, lr=1e-3, seed=0):
    torch.manual_seed(seed)
    model = TaskModel(X.shape[1], hidden, 2)
    opt = optim.Adam(model.parameters(), lr=lr)
    lossf = nn.CrossEntropyLoss()
    for _ in range(epochs):
        opt.zero_grad()
        out, _ = model(X, return_hidden=True)
        loss = lossf(out, y)
        loss.backward()
        opt.step()
    return model

def collect_hidden(model, X):
    model.eval()
    with torch.no_grad():
        _, H = model(X, return_hidden=True)
    return H

def sae_intervention(model, sae, x, feature_idx, mode='ablate', alpha=0.0):
    model.eval()
    with torch.no_grad():
        h = torch.relu(model.fc1(x))
        pre = sae.enc(h) + sae.bias
        h_sae = torch.relu(pre)

        if mode == 'ablate':
            h_sae[:, feature_idx] = 0.0
        elif mode == 'clamp':
            h_sae[:, feature_idx] = alpha
        elif mode == 'steer':
            h = h + alpha * sae.dec.weight[:, feature_idx].unsqueeze(0)

        h_mod = sae.dec(h_sae) + sae.enc.bias
        out = model.fc2(h_mod)
    return out

def ablation_effect(model, sae, X, feature_indices):
    base = model(X)
    base_pred = base.argmax(1)
    effects = {}
    for f in feature_indices:
        out = sae_intervention(model, sae, X, f, 'ablate')
        effects[f] = (out.argmax(1) != base_pred).float().mean().item()
    return effects

def patching_experiment(model, sae, x_clean, x_corrupt, feature_idx):
    with torch.no_grad():
        h_clean = torch.relu(model.fc1(x_clean))
        h_corrupt = torch.relu(model.fc1(x_corrupt))
        code_clean = torch.relu(sae.enc(h_clean) + sae.bias)
        code_corrupt = torch.relu(sae.enc(h_corrupt) + sae.bias)
        code_corrupt[:, feature_idx] = code_clean[:, feature_idx]
        h_patch = sae.dec(code_corrupt) + sae.enc.bias
        out = model.fc2(h_patch)
    return out

def steering_curve(model, sae, x, feature_idx, alphas=np.linspace(-2, 2, 21)):
    probs = []
    for a in alphas:
        out = sae_intervention(model, sae, x, feature_idx, 'steer', alpha=a)
        probs.append(torch.softmax(out, 1)[:, 1].mean().item())
    return alphas, np.array(probs)

def circuit_diagram(edges, fname):
    G = nx.DiGraph()
    for u, v, w in edges:
        G.add_edge(u, v, weight=w)
    pos = nx.spring_layout(G, seed=0)
    plt.figure()
    nx.draw(G, pos, with_labels=True, node_color='lightblue', arrows=True)
    labels = nx.get_edge_attributes(G, 'weight')
    nx.draw_networkx_edge_labels(G, pos, edge_labels={k: f'{v:.2f}' for k, v in labels.items()})
    plt.savefig(fname)
    plt.close()

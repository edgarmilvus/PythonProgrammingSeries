
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# polysemanticity_mlp.py
import torch, torch.nn as nn, torch.optim as optim
import numpy as np, matplotlib.pyplot as plt
from scipy.stats import entropy

def make_sparse_task(n_features=20, n_samples=12000, p=0.1, seed=0, task='xor'):
    rng = np.random.RandomState(seed)
    X = (rng.rand(n_samples, n_features) < p).astype(np.float32)
    X *= rng.rand(n_samples, n_features).astype(np.float32)
    if task == 'xor':
        y = ((X[:, 0] > 0) ^ (X[:, 1] > 0)).astype(np.int64)
    elif task == 'sum':
        y = (X[:, :5].sum(1) > 1.0).astype(np.int64)
    else:
        y = (X[:, :3].sum(1) > 0.5).astype(np.int64)
    return torch.tensor(X), torch.tensor(y)

class MLP(nn.Module):
    def __init__(self, n_in, hidden=32, n_out=2, n_layers=1):
        super().__init__()
        self.linears = nn.ModuleList()
        self.acts = nn.ModuleList()
        d = n_in
        for _ in range(n_layers):
            self.linears.append(nn.Linear(d, hidden))
            self.acts.append(nn.ReLU())
            d = hidden
        self.out = nn.Linear(d, n_out)

    def forward(self, x, return_hidden=False):
        hs = []
        for lin, act in zip(self.linears, self.acts):
            x = act(lin(x))
            hs.append(x)
        out = self.out(x)
        if return_hidden:
            return out, hs
        return out

def train_mlp(X, y, hidden=32, epochs=200, lr=1e-3, n_layers=1, seed=0):
    torch.manual_seed(seed)
    model = MLP(X.shape[1], hidden, 2, n_layers)
    opt = optim.Adam(model.parameters(), lr=lr)
    lossf = nn.CrossEntropyLoss()
    for _ in range(epochs):
        model.train()
        opt.zero_grad()
        out, _ = model(X, return_hidden=True)
        loss = lossf(out, y)
        loss.backward()
        opt.step()
    return model

def corr_matrix(model, X):
    model.eval()
    with torch.no_grad():
        _, hs = model(X, return_hidden=True)
    H = hs[-1].numpy()
    F = X.numpy()
    Hc = H - H.mean(0, keepdims=True)
    Fc = F - F.mean(0, keepdims=True)
    denom = np.linalg.norm(Hc, axis=0, keepdims=True).T @ np.linalg.norm(Fc, axis=0, keepdims=True)
    return (Hc.T @ Fc) / (denom + 1e-8)

def polysemanticity_scores(corr, thresh=0.3):
    a = np.abs(corr)
    a_norm = a / (a.sum(1, keepdims=True) + 1e-8)
    pr = (a_norm.sum(1) ** 2) / (np.sum(a_norm ** 2, 1) + 1e-8)
    active = (a > thresh).sum(1)
    ent = -np.sum(a_norm * np.log(a_norm + 1e-8), 1)
    return pr, active, ent

def crowding_metrics(corr, thresh=0.3):
    resp = np.abs(corr) > thresh
    neurons_per_feature = resp.sum(0)
    overlaps = []
    for i in range(resp.shape[1]):
        for j in range(i + 1, resp.shape[1]):
            union = (resp[:, i] | resp[:, j]).sum()
            if union:
                overlaps.append((resp[:, i] & resp[:, j]).sum() / union)
    return neurons_per_feature.mean(), np.mean(overlaps) if overlaps else 0.0

def experiment_width(X, y, widths=(4, 8, 16, 32, 64), seeds=(0, 1, 2)):
    results = []
    for w in widths:
        prs = []
        for s in seeds:
            model = train_mlp(X, y, hidden=w, seed=s)
            C = corr_matrix(model, X)
            pr, _, _ = polysemanticity_scores(C)
            prs.append(pr.mean())
        results.append((w, np.mean(prs), np.std(prs)))
    return results

def experiment_sparsity(n_features=20, p_list=(0.02, 0.05, 0.1, 0.3, 0.6), hidden=16, seed=0):
    results = []
    for p in p_list:
        X, y = make_sparse_task(n_features=n_features, p=p, seed=seed)
        model = train_mlp(X, y, hidden=hidden, seed=seed)
        C = corr_matrix(model, X)
        pr, _, _ = polysemanticity_scores(C)
        results.append((p, pr.mean()))
    return results

def ablation_study(model, X, y, neuron_indices):
    base_pred = model(X).argmax(1)
    effects = {}
    for n in neuron_indices:
        model.eval()
        with torch.no_grad():
            h = torch.relu(model.linears[0](X))
            h[:, n] = 0
            out = model.out(h)
            effects[n] = (out.argmax(1) != base_pred).float().mean().item()
    return effects

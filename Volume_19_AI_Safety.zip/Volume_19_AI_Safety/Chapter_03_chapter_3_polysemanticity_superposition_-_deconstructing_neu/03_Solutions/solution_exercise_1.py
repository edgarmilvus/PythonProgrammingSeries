
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# toy_superposition.py
import torch, torch.nn as nn, torch.optim as optim
import numpy as np, matplotlib.pyplot as plt
from scipy.optimize import linear_sum_assignment
from itertools import product

class SparseGenerator:
    def __init__(self, n_features, p, batch_size=1024, signed=False,
                 importance=None, correlated=False, seed=0):
        self.n_features = n_features
        self.p = p
        self.batch_size = batch_size
        self.signed = signed
        self.correlated = correlated
        self.importance = torch.ones(n_features) if importance is None else importance
        self.g = torch.Generator().manual_seed(seed)

    def sample(self):
        mask = (torch.rand(self.batch_size, self.n_features, generator=self.g) < self.p).float()
        if self.correlated:
            co = (torch.rand(self.batch_size, 1, generator=self.g) < 0.5).float()
            mask[:, 1] = torch.maximum(mask[:, 1], co.squeeze(1) * mask[:, 0])
        mag = torch.rand(self.batch_size, self.n_features, generator=self.g) * mask
        if self.signed:
            mag = mag * torch.sign(torch.randn(self.batch_size, self.n_features, generator=self.g))
        return mag * self.importance

class ToyModel(nn.Module):
    def __init__(self, n_features, hidden_dim, tied=True):
        super().__init__()
        self.enc = nn.Linear(n_features, hidden_dim)
        self.dec = nn.Linear(hidden_dim, n_features)
        self.tied = tied
        if tied:
            self.dec.weight = self.enc.weight.T

    def forward(self, x):
        h = torch.relu(self.enc(x))
        x_hat = self.dec(h)
        return x_hat, h

    def hidden_directions(self):
        # Rows: hidden-unit directions in input space.
        return self.enc.weight.detach()

    def feature_directions_in_hidden(self):
        # Columns: true-feature directions in hidden space.
        return self.enc.weight.detach().T

def train(cfg):
    torch.manual_seed(cfg['seed'])
    gen = SparseGenerator(
        cfg['n_features'], cfg['p'], cfg['batch_size'],
        cfg.get('signed', False), cfg.get('importance'),
        cfg.get('correlated', False), cfg['seed']
    )
    model = ToyModel(cfg['n_features'], cfg['hidden_dim'], cfg.get('tied', True))
    opt = optim.Adam(model.parameters(), lr=cfg['lr'])

    for step in range(cfg['steps']):
        x = gen.sample()
        x_hat, h = model(x)
        recon = ((x - x_hat) ** 2).mean()
        sparsity = h.abs().mean()
        loss = recon + cfg['l1'] * sparsity
        opt.zero_grad()
        loss.backward()
        opt.step()
    return model, gen

def recovery_metrics(model, n_features, thresh=0.9):
    W = model.hidden_directions()
    W = W / W.norm(dim=1, keepdim=True).clamp_min(1e-8)
    true = torch.eye(n_features)
    cos = (true @ W.T).abs().numpy()  # (n_features, hidden_dim)
    row, col = linear_sum_assignment(-cos)
    matched = cos[row, col]
    max_cos = cos.max(axis=1)
    return dict(
        avg_max_cos=max_cos.mean(),
        min_matched=matched.min(),
        frac_gt_0_9=(max_cos > thresh).mean(),
        matched=matched
    )

def interference_metrics(model):
    W = model.hidden_directions()
    W = W / W.norm(dim=1, keepdim=True).clamp_min(1e-8)
    S = (W @ W.T).abs().numpy()
    off = S[~np.eye(S.shape[0], dtype=bool)]
    return dict(avg_abs=off.mean(), max_abs=off.max(), hist=off)

def sweep(n_features_list, p_list, hidden_dim=2, seeds=(0, 1, 2), steps=3000, l1=0.1):
    rows = []
    for n, p, seed in product(n_features_list, p_list, seeds):
        cfg = dict(
            n_features=n, p=p, hidden_dim=hidden_dim, l1=l1,
            lr=1e-3, steps=steps, seed=seed, batch_size=1024, tied=True
        )
        model, gen = train(cfg)
        x = gen.sample()
        with torch.no_grad():
            x_hat, h = model(x)
        rec = ((x - x_hat) ** 2).mean().item()
        l0 = (h > 1e-6).sum(dim=1).float().mean().item()
        rows.append({**cfg, 'recon': rec, 'l0': l0,
                     **recovery_metrics(model, n),
                     **interference_metrics(model)})
    return rows

def plot_geometry(model, fname):
    D = model.feature_directions_in_hidden().numpy()
    if D.shape[1] > 2:
        D = D - D.mean(0)
        u, s, vt = np.linalg.svd(D, full_matrices=False)
        D = u[:, :2] * s[:2]
    plt.figure()
    for i, v in enumerate(D):
        plt.arrow(0, 0, v[0], v[1], head_width=0.05, length_includes_head=True)
        plt.text(v[0] * 1.1, v[1] * 1.1, f'f{i}')
    plt.axis('equal')
    plt.title('Feature directions in hidden space')
    plt.savefig(fname)
    plt.close()

def phase_diagram(rows, fname):
    import pandas as pd
    df = pd.DataFrame(rows)
    piv = df.pivot_table(index='n_features', columns='p',
                         values='avg_max_cos', aggfunc='mean')
    plt.figure()
    plt.imshow(piv.values, aspect='auto', origin='lower', cmap='viridis')
    plt.xticks(range(len(piv.columns)), [f'{c:.2f}' for c in piv.columns], rotation=45)
    plt.yticks(range(len(piv.index)), piv.index)
    plt.xlabel('sparsity p')
    plt.ylabel('n_features')
    plt.colorbar(label='avg max cosine')
    plt.title('Phase diagram')
    plt.savefig(fname)
    plt.close()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# models.py
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class RoutingLog(db.Model):
    __tablename__ = "routing_log"
    id = db.Column(db.Integer, primary_key=True)
    prompt_hash = db.Column(db.String(64), nullable=False)
    action = db.Column(db.String(50), nullable=False)
    refusal_projection = db.Column(db.Float, nullable=False)
    attention_entropy = db.Column(db.Float, nullable=False)
    mlp_norm = db.Column(db.Float, nullable=False)
    probe_score = db.Column(db.Float, nullable=False)
    expected_cost = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    feedback = db.relationship("Feedback", backref="routing_log", lazy=True)

class Prompt(db.Model):
    __tablename__ = "prompt"
    id = db.Column(db.Integer, primary_key=True)
    prompt_text = db.Column(db.Text, nullable=False)
    prompt_hash = db.Column(db.String(64), unique=True, nullable=False)
    label = db.Column(db.String(20), nullable=False)
    split = db.Column(db.String(20), nullable=False)

class Feedback(db.Model):
    __tablename__ = "feedback"
    id = db.Column(db.Integer, primary_key=True)
    routing_log_id = db.Column(db.Integer, db.ForeignKey("routing_log.id"), nullable=False)
    correct = db.Column(db.Boolean, nullable=False)
    notes = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)


# routing.py
import math
import torch

def sigmoid(x):
    return 1.0 / (1.0 + math.exp(-x))

def refusal_probability(h, w, b):
    z = torch.dot(w, h) + b
    return sigmoid(float(z))

def compute_features(h, refusal_dir, probe_w, probe_b, attention_entropy, mlp_norm):
    projection = torch.dot(h, refusal_dir).item()
    probe_score = refusal_probability(h, probe_w, probe_b)
    return {
        "refusal_projection": projection,
        "attention_entropy": attention_entropy,
        "mlp_norm": mlp_norm,
        "probe_score": probe_score,
        "context_gate": 1.0
    }

def route_decision(features, costs=None):
    costs = costs or {
        "Cost_harm": 100.0,
        "Cost_false_refusal": 1.0,
        "Cost_strong_model": 5.0,
        "Cost_human": 50.0
    }

    P_harmful = features["probe_score"]
    P_benign = 1.0 - P_harmful

    # Escalate if refusal projection is very negative.
    if features["refusal_projection"] < -1.0:
        P_harmful = min(1.0, P_harmful + 0.2)

    cost_normal = P_harmful * costs["Cost_harm"] + P_benign * 0.0
    cost_steered = P_harmful * (costs["Cost_harm"] * 0.1) + P_benign * costs["Cost_false_refusal"]
    cost_strong = (
        P_harmful * (costs["Cost_harm"] * 0.01)
        + P_benign * costs["Cost_false_refusal"]
        + costs["Cost_strong_model"]
    )
    cost_human = costs["Cost_human"]

    costs_by_action = {
        "normal": cost_normal,
        "steered": cost_steered,
        "strong_model": cost_strong,
        "human": cost_human
    }
    action = min(costs_by_action, key=costs_by_action.get)
    return action, costs_by_action


# app.py
from flask import Flask, request, jsonify
from models import db, RoutingLog, Prompt, Feedback
from routing import compute_features, route_decision
import hashlib
import torch
from datetime import datetime

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///router.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db.init_app(app)

# Placeholder probe and refusal direction. Replace with trained artifacts.
H = 768
REFUSAL_DIR = torch.randn(H)
REFUSAL_DIR = REFUSAL_DIR / torch.norm(REFUSAL_DIR)
PROBE_W = torch.randn(H)
PROBE_B = 0.0

def hash_prompt(text):
    return hashlib.sha256(text.encode()).hexdigest()[:16]

@app.route("/route", methods=["POST"])
def route():
    payload = request.get_json()
    prompt = payload["prompt"]
    # In a real system, compute h from the model. Here we use a synthetic hidden state.
    h = torch.randn(H)
    features = compute_features(h, REFUSAL_DIR, PROBE_W, PROBE_B,
                                attention_entropy=2.0, mlp_norm=5.0)
    action, costs = route_decision(features)
    log = RoutingLog(
        prompt_hash=hash_prompt(prompt),
        action=action,
        refusal_projection=features["refusal_projection"],
        attention_entropy=features["attention_entropy"],
        mlp_norm=features["mlp_norm"],
        probe_score=features["probe_score"],
        expected_cost=costs[action],
        timestamp=datetime.utcnow()
    )
    db.session.add(log)
    db.session.commit()
    return jsonify({
        "action": action,
        "features": features,
        "expected_costs": costs
    })

@app.route("/logs/<int:log_id>")
def get_log(log_id):
    log = RoutingLog.query.get_or_404(log_id)
    return jsonify({
        "id": log.id,
        "prompt_hash": log.prompt_hash,
        "action": log.action,
        "refusal_projection": log.refusal_projection,
        "attention_entropy": log.attention_entropy,
        "mlp_norm": log.mlp_norm,
        "probe_score": log.probe_score,
        "expected_cost": log.expected_cost,
        "timestamp": log.timestamp.isoformat()
    })

@app.route("/stats")
def stats():
    logs = RoutingLog.query.all()
    counts = {}
    for log in logs:
        counts[log.action] = counts.get(log.action, 0) + 1
    avg_cost = sum(log.expected_cost for log in logs) / len(logs) if logs else 0.0
    return jsonify({"counts": counts, "average_expected_cost": avg_cost})

@app.route("/feedback/<int:log_id>", methods=["POST"])
def feedback(log_id):
    payload = request.get_json()
    fb = Feedback(
        routing_log_id=log_id,
        correct=bool(payload["correct"]),
        notes=payload.get("notes", ""),
        timestamp=datetime.utcnow()
    )
    db.session.add(fb)
    db.session.commit()
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)


# train_probe.py
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
import joblib

def train_probe(X_train, y_train, X_test, y_test, out_path="probe.pkl"):
    clf = LogisticRegression(max_iter=1000)
    clf.fit(X_train, y_train)
    pred = clf.predict(X_test)
    print(classification_report(y_test, pred))
    joblib.dump(clf, out_path)
    return clf

if __name__ == "__main__":
    # Replace with real hidden states from Exercise 1.
    X_train = np.random.randn(200, 768)
    y_train = np.random.randint(0, 2, 200)
    X_test = np.random.randn(50, 768)
    y_test = np.random.randint(0, 2, 50)
    train_probe(X_train, y_train, X_test, y_test)

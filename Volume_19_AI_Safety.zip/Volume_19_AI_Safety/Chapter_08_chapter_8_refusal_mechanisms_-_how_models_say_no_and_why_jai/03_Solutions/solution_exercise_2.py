
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# models.py
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Experiment(db.Model):
    __tablename__ = "experiment"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    model_name = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    description = db.Column(db.Text)

    prompts = db.relationship("Prompt", backref="experiment", lazy=True)
    steering_runs = db.relationship("SteeringRun", backref="experiment", lazy=True)

class Prompt(db.Model):
    __tablename__ = "prompt"
    id = db.Column(db.Integer, primary_key=True)
    experiment_id = db.Column(db.Integer, db.ForeignKey("experiment.id"), nullable=False)
    prompt_text = db.Column(db.Text, nullable=False)
    prompt_hash = db.Column(db.String(64), unique=True, nullable=False)
    label = db.Column(db.String(20), nullable=False)

    activations = db.relationship("LayerActivation", backref="prompt", lazy=True)

class LayerActivation(db.Model):
    __tablename__ = "layer_activation"
    id = db.Column(db.Integer, primary_key=True)
    prompt_id = db.Column(db.Integer, db.ForeignKey("prompt.id"), nullable=False)
    layer_index = db.Column(db.Integer, nullable=False)
    refusal_score = db.Column(db.Float, nullable=False)
    attention_entropy = db.Column(db.Float, nullable=False)
    mlp_norm = db.Column(db.Float, nullable=False)

class SteeringRun(db.Model):
    __tablename__ = "steering_run"
    id = db.Column(db.Integer, primary_key=True)
    experiment_id = db.Column(db.Integer, db.ForeignKey("experiment.id"), nullable=False)
    layer_index = db.Column(db.Integer, nullable=False)
    strength = db.Column(db.Float, nullable=False)
    predicted_refusal = db.Column(db.Float, nullable=False)
    actual_refusal = db.Column(db.Boolean, nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)


# app.py
from flask import Flask, render_template, request, jsonify
from models import db, Experiment, Prompt, LayerActivation, SteeringRun
import torch
import math
import hashlib
import random
from datetime import datetime

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///refusal_explorer.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db.init_app(app)

# Synthetic refusal direction for demo. Replace with real extracted direction.
HIDDEN_SIZE = 768
REFUSAL_DIR = torch.randn(HIDDEN_SIZE)
REFUSAL_DIR = REFUSAL_DIR / torch.norm(REFUSAL_DIR)
PROBE_W = torch.randn(HIDDEN_SIZE)
PROBE_B = 0.0

def sigmoid(x: float) -> float:
    return 1.0 / (1.0 + math.exp(-x))

def project_out(h: torch.Tensor, d: torch.Tensor, strength: float) -> torch.Tensor:
    dot = torch.dot(h, d)
    return h - strength * dot * d

def amplify(h: torch.Tensor, d: torch.Tensor, strength: float) -> torch.Tensor:
    dot = torch.dot(h, d)
    return h + strength * dot * d

def refusal_probability(h: torch.Tensor, w: torch.Tensor, b: float) -> float:
    z = torch.dot(w, h) + b
    return sigmoid(float(z))

def attention_entropy(p: torch.Tensor) -> float:
    eps = 1e-9
    return float(-torch.sum(p * torch.log(p + eps)))

def suppression_metric(jailbreak_type: str):
    """Compare baseline vs jailbroken refusal projection per layer."""
    baseline = torch.zeros(24)
    jailbroken = baseline.clone()
    if jailbreak_type == "role_play":
        jailbroken[10:15] -= 0.5
        explanation = "Persona shift reroutes context in middle layers, reducing refusal projection."
    elif jailbreak_type == "adversarial_suffix":
        jailbroken[8:18] -= 0.7
        explanation = "Adversarial suffix suppresses refusal signal across middle and late layers."
    elif jailbreak_type == "encoding":
        jailbroken[6:12] -= 0.4
        explanation = "Encoded input reduces direct harmful-token evidence in early-mid layers."
    elif jailbreak_type == "multi_turn":
        jailbroken[12:20] -= 0.6
        explanation = "Multi-turn priming gradually lowers refusal projection in late layers."
    else:
        explanation = "Unknown jailbreak type."
    diff = baseline - jailbroken  # positive means suppressed
    suppressed = [i for i, v in enumerate(diff.tolist()) if v > 0.1]
    return suppressed, diff.tolist(), explanation

@app.route("/")
def index():
    experiments = Experiment.query.all()
    return render_template("index.html", experiments=experiments)

@app.route("/experiment/<int:experiment_id>")
def experiment_detail(experiment_id):
    exp = Experiment.query.get_or_404(experiment_id)
    prompts = Prompt.query.filter_by(experiment_id=experiment_id).all()
    return render_template("experiment.html", experiment=exp, prompts=prompts)

@app.route("/layer/<int:layer_id>")
def layer_detail(layer_id):
    acts = LayerActivation.query.filter_by(layer_index=layer_id).all()
    data = [{
        "prompt_id": a.prompt_id,
        "refusal_score": a.refusal_score,
        "attention_entropy": a.attention_entropy,
        "mlp_norm": a.mlp_norm
    } for a in acts]
    return jsonify({"layer": layer_id, "activations": data})

@app.route("/prompt/<string:prompt_hash>")
def prompt_detail(prompt_hash):
    p = Prompt.query.filter_by(prompt_hash=prompt_hash).first_or_404()
    acts = LayerActivation.query.filter_by(prompt_id=p.id).all()
    return jsonify({
        "prompt": p.prompt_text,
        "label": p.label,
        "activations": [{
            "layer": a.layer_index,
            "refusal_score": a.refusal_score,
            "attention_entropy": a.attention_entropy,
            "mlp_norm": a.mlp_norm
        } for a in acts]
    })

@app.route("/steer/<float:strength>", methods=["POST"])
def steer(strength):
    strength = max(-5.0, min(5.0, strength))
    payload = request.get_json(silent=True) or {}
    layer_index = int(payload.get("layer_index", 10))
    h = torch.randn(HIDDEN_SIZE)
    d = REFUSAL_DIR

    if strength >= 0.0:
        h_new = amplify(h, d, strength)
    else:
        h_new = project_out(h, d, -strength)

    prob = refusal_probability(h_new, PROBE_W, PROBE_B)
    run = SteeringRun(
        experiment_id=1,
        layer_index=layer_index,
        strength=strength,
        predicted_refusal=prob,
        timestamp=datetime.utcnow()
    )
    db.session.add(run)
    db.session.commit()
    return jsonify({
        "strength": strength,
        "predicted_refusal": prob,
        "layer_index": layer_index
    })

@app.route("/jailbreak/<string:jailbreak_type>")
def jailbreak(jailbreak_type):
    suppressed, diff, explanation = suppression_metric(jailbreak_type)
    return jsonify({
        "jailbreak_type": jailbreak_type,
        "suppressed_layers": suppressed,
        "layer_differences": diff,
        "explanation": explanation
    })

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)


# init_db.py
from app import app
from models import db, Experiment, Prompt, LayerActivation
import hashlib
import random

def hash_prompt(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()[:16]

with app.app_context():
    db.drop_all()
    db.create_all()

    exp = Experiment(name="Demo Refusal Experiment", model_name="distilgpt2", description="Synthetic demo")
    db.session.add(exp)
    db.session.commit()

    for i in range(5):
        text = f"Example prompt {i}"
        p = Prompt(
            experiment_id=exp.id,
            prompt_text=text,
            prompt_hash=hash_prompt(text),
            label="harmful" if i % 2 == 0 else "benign"
        )
        db.session.add(p)
        db.session.commit()

        for layer in range(12):
            act = LayerActivation(
                prompt_id=p.id,
                layer_index=layer,
                refusal_score=random.random(),
                attention_entropy=random.random() * 3.0,
                mlp_norm=random.random() * 10.0
            )
            db.session.add(act)
    db.session.commit()
    print("Database initialized.")


# templates/index.html
<!doctype html>
<html>
<head><title>Refusal Circuit Explorer</title></head>
<body>
  <h1>Refusal Circuit Explorer</h1>
  <select id="experimentSelect">
    {% for exp in experiments %}
      <option value="{{ exp.id }}">{{ exp.name }}</option>
    {% endfor %}
  </select>
  <button onclick="location.href='/experiment/' + document.getElementById('experimentSelect').value">
    Open Experiment
  </button>
</body>
</html>


# templates/experiment.html
<!doctype html>
<html>
<head>
  <title>{{ experiment.name }}</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
  <h1>{{ experiment.name }}</h1>
  <p>{{ experiment.description }}</p>

  <h2>Layerwise Refusal Scores</h2>
  <canvas id="layerChart" width="600" height="300"></canvas>

  <h2>Steering Strength</h2>
  <input type="range" min="-5" max="5" step="0.1" value="0" id="strengthSlider">
  <span id="strengthValue">0.0</span>
  <p>Predicted refusal: <span id="refusalProb">-</span></p>

  <h2>Jailbreak Simulator</h2>
  <select id="jailbreakType">
    <option>role_play</option>
    <option>adversarial_suffix</option>
    <option>encoding</option>
    <option>multi_turn</option>
  </select>
  <button onclick="runJailbreak()">Simulate</button>
  <pre id="jailbreakResult"></pre>

  <script>
    const labels = [...Array(12).keys()];
    const scores = labels.map(() => Math.random());
    new Chart(document.getElementById('layerChart'), {
      type: 'line',
      data: { labels: labels, datasets: [{ label: 'Refusal score', data: scores }] }
    });

    const slider = document.getElementById('strengthSlider');
    slider.oninput = async () => {
      const val = slider.value;
      document.getElementById('strengthValue').innerText = val;
      const res = await fetch(`/steer/${val}`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({layer_index: 10})
      });
      const data = await res.json();
      document.getElementById('refusalProb').innerText = data.predicted_refusal.toFixed(3);
    };

    async function runJailbreak() {
      const type = document.getElementById('jailbreakType').value;
      const res = await fetch(`/jailbreak/${type}`);
      const data = await res.json();
      document.getElementById('jailbreakResult').innerText = JSON.stringify(data, null, 2);
    }
  </script>
</body>
</html>

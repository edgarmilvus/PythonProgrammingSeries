
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# refusal_gate_hello_world.py
# A self-contained, "Hello World" refusal mechanism.
# It simulates a safety circuit as a dot product with a learned refusal vector,
# followed by a threshold gate.

# --- Feature table ---------------------------------------------------------
# Each prompt is represented by three hand-crafted interpretable features.
# Feature order: [harmfulness, persona_shift, encoding_obfuscation]
# These numbers are not from a real model; they make the mechanics visible.
PROMPTS = {
    "benign_weather":       [0.30, 0.00, 0.00],
    "harmful_direct":       [0.90, 0.00, 0.00],
    "harmful_roleplay":     [0.90, 0.85, 0.00],
    "harmful_base64":       [0.90, 0.00, 0.80],
}

# --- Learned refusal direction --------------------------------------------
# The refusal vector is the "direction" in feature space that the model
# associates with refusing. Positive weights push toward refusal.
# Negative weights are jailbreak-like features that suppress refusal.
REFUSAL_VECTOR = {
    "harmfulness":          1.20,
    "persona_shift":       -0.95,
    "encoding_obfuscation": -0.85,
}

# --- Bias and threshold ---------------------------------------------------
# Bias models the model's baseline tendency to refuse.
REFUSAL_BIAS = -0.55

# The gate compares the refusal score to this threshold.
REFUSAL_THRESHOLD = 0.25

def refusal_score(features):
    """Return the dot product of features and the refusal vector, plus bias."""
    harmfulness, persona_shift, encoding_obfuscation = features
    score = (
        harmfulness * REFUSAL_VECTOR["harmfulness"]
        + persona_shift * REFUSAL_VECTOR["persona_shift"]
        + encoding_obfuscation * REFUSAL_VECTOR["encoding_obfuscation"]
        + REFUSAL_BIAS
    )
    return score

def generate(prompt_name):
    """Toy generation: refuse if the refusal score crosses the threshold."""
    features = PROMPTS[prompt_name]
    score = refusal_score(features)
    if score >= REFUSAL_THRESHOLD:
        return "I can't help with that request.", score
    return "Here is a safe, benign completion.", score

def evaluate_threshold(threshold):
    """Return (unsafe_refusal_rate, safe_compliance_rate) for a threshold."""
    unsafe = [name for name in PROMPTS if name.startswith("harmful")]
    safe = [name for name in PROMPTS if not name.startswith("harmful")]

    refused_unsafe = 0
    for name in unsafe:
        if refusal_score(PROMPTS[name]) >= threshold:
            refused_unsafe += 1

    complied_safe = 0
    for name in safe:
        if refusal_score(PROMPTS[name]) < threshold:
            complied_safe += 1

    unsafe_refusal_rate = refused_unsafe / len(unsafe)
    safe_compliance_rate = complied_safe / len(safe)
    return unsafe_refusal_rate, safe_compliance_rate

# --- Run the Hello World demonstration -----------------------------------
print("prompt_name               score   decision")
print("-" * 48)
for name in PROMPTS:
    answer, score = generate(name)
    decision = "REFUSE" if "can't" in answer else "COMPLY"
    print(f"{name:25s} {score:6.2f}   {decision}")

print("\nthreshold  unsafe_refusal_rate  safe_compliance_rate")
print("-" * 58)
for threshold in [-0.50, -0.30, -0.20, 0.00, 0.25, 0.50, 0.75]:
    unsafe_refusal_rate, safe_compliance_rate = evaluate_threshold(threshold)
    print(f"{threshold:8.2f} {unsafe_refusal_rate:19.2f} {safe_compliance_rate:20.2f}")

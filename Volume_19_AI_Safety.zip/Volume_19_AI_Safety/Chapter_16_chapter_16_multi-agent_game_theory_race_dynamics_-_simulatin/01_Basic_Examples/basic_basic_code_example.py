
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Import os so we can read an optional safety-bonus parameter from the environment.
import os

# Read a configurable safety bonus from the environment.
# If SAFETY_BONUS is unset, use "0" as the default; convert it to an integer.
SAFETY_BONUS = int(os.environ.get("SAFETY_BONUS", "0"))

# Define the two possible strategic actions.
# "Safety" means invest in alignment, interpretability, and evaluations.
# "Capability" means prioritize speed, scale, and competitive deployment.
ACTIONS = ["Safety", "Capability"]

# Define the base payoff matrix for a two-lab race.
# Each key is an ordered pair: (Lab A action, Lab B action).
# Each value is a payoff pair: (Lab A payoff, Lab B payoff).
PAYOFFS = {
    ("Safety", "Safety"): (3 + SAFETY_BONUS, 3 + SAFETY_BONUS),
    ("Safety", "Capability"): (0, 5),
    ("Capability", "Safety"): (5, 0),
    ("Capability", "Capability"): (1, 1),
}

# Return the payoff pair for a given action pair.
def payoff(a_action, b_action):
    return PAYOFFS[(a_action, b_action)]

# Return the best action for one player given the other player's action.
# player=0 means Lab A; player=1 means Lab B.
def best_response(player, other_action):
    best_action = None
    best_score = float("-inf")
    for action in ACTIONS:
        if player == 0:
            score = payoff(action, other_action)[0]
        else:
            score = payoff(other_action, action)[1]
        if score > best_score:
            best_score = score
            best_action = action
    return best_action

# Enumerate all pure-strategy action pairs and keep those where neither
# player can gain by unilaterally switching to the other action.
def pure_nash_equilibria():
    equilibria = []
    for a_action in ACTIONS:
        for b_action in ACTIONS:
            a_best = best_response(0, b_action)
            b_best = best_response(1, a_action)
            if a_best == a_action and b_best == b_action:
                equilibria.append((a_action, b_action))
    return equilibria

# Print a readable payoff matrix.
def print_payoff_matrix():
    print("Payoff Matrix: (Lab A payoff, Lab B payoff)")
    print(f"{'Lab A \\ Lab B':<18}{'Safety':<16}{'Capability':<16}")
    for a_action in ACTIONS:
        row = f"{a_action:<18}"
        for b_action in ACTIONS:
            a_pay, b_pay = payoff(a_action, b_action)
            row += f"({a_pay}, {b_pay})".ljust(16)
        print(row)

# Print the best response for each player to each possible opponent action.
def print_best_responses():
    print("\nBest Responses")
    for opponent_action in ACTIONS:
        a_best = best_response(0, opponent_action)
        b_best = best_response(1, opponent_action)
        print(f"If opponent chooses {opponent_action}:")
        print(f"  Lab A best response: {a_best}")
        print(f"  Lab B best response: {b_best}")

# Run the tiny simulation.
def main():
    print(f"SAFETY_BONUS = {SAFETY_BONUS}")
    print_payoff_matrix()
    print_best_responses()
    eq = pure_nash_equilibria()
    print("\nPure-strategy Nash equilibria:")
    for pair in eq:
        print(f"  Lab A = {pair[0]}, Lab B = {pair[1]}")
    if ("Capability", "Capability") in eq:
        print("Warning: capability-capability remains a stable outcome.")
    if ("Safety", "Safety") in eq:
        print("A safer equilibrium also exists, but coordination is still required.")

# Only run main when executed as a script.
if __name__ == "__main__":
    main()

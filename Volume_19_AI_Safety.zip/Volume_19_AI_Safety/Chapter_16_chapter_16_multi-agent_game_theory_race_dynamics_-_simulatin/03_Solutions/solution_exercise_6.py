
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_6.py
# Description: Solution for Exercise 6
# ==========================================

# oversight_mechanism.py
"""Mechanism design for scalable oversight and truthful risk reporting."""
from __future__ import annotations

import random
from typing import Dict, List

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


class Agent:
    def __init__(self, agent_id: int, true_risk: float, strategy: str):
        self.agent_id = agent_id
        self.true_risk = true_risk
        self.strategy = strategy
        self.safety_investment = 0.5
        self.reported_risk = true_risk
        self.payoff_history = []
        self.reputation = 1.0

    def choose_report(self, mechanism: dict) -> float:
        if self.strategy == "Truthful":
            return self.true_risk
        if self.strategy == "AlwaysUnderreport":
            return max(0.0, self.true_risk - 0.3)
        if self.strategy == "StrategicLiar":
            return max(0.0, self.true_risk - 0.2) if mechanism.get("audit_probability", 0) < 0.5 else self.true_risk
        if self.strategy == "Learner":
            return self.reported_risk
        return self.true_risk

    def choose_safety_investment(self, mechanism: dict) -> float:
        if self.strategy == "Truthful":
            return 0.7
        if self.strategy == "AlwaysUnderreport":
            return 0.3
        if self.strategy == "StrategicLiar":
            return 0.4 if mechanism.get("audit_probability", 0) < 0.5 else 0.7
        if self.strategy == "Learner":
            return min(1.0, max(0.0, self.safety_investment + random.uniform(-0.05, 0.05)))
        return 0.5


class Regulator:
    def __init__(self, params: dict):
        self.audit_probability = params.get("audit_probability", 0.3)
        self.penalty_for_lying = params.get("penalty_for_lying", 5.0)
        self.reward_for_truth = params.get("reward_for_truth", 2.0)
        self.safety_subsidy = params.get("safety_subsidy", 1.0)
        self.reputation_weight = params.get("reputation_weight", 0.5)

    def audit(self, agent: Agent) -> float | None:
        if random.random() < self.audit_probability:
            return agent.true_risk
        return None

    def compute_transfer(self, agent: Agent, audit_result: float | None) -> float:
        transfer = self.safety_subsidy * agent.safety_investment * agent.reputation
        if audit_result is not None:
            diff = abs(agent.reported_risk - agent.true_risk)
            if diff < 1e-9:
                transfer += self.reward_for_truth
            else:
                transfer -= self.penalty_for_lying * diff
        return transfer


def simulate_mechanism(
    mechanism_name: str,
    num_agents: int,
    num_rounds: int,
    params: dict,
) -> dict:
    """Simulate agents and regulator under a named mechanism."""
    agents = []
    for i in range(num_agents):
        strategy = random.choice(["Truthful", "AlwaysUnderreport", "StrategicLiar", "Learner"])
        agents.append(Agent(i, random.random(), strategy))

    regulator = Regulator(params)
    history = {
        "lying_rate": [],
        "avg_safety": [],
        "reg_cost": [],
        "welfare": [],
    }

    for _ in range(num_rounds):
        transfers = []
        for agent in agents:
            agent.safety_investment = agent.choose_safety_investment(params)
            agent.reported_risk = agent.choose_report(params)

            audit = regulator.audit(agent)
            transfer = regulator.compute_transfer(agent, audit)

            base = (1 - agent.safety_investment) * 10 - agent.safety_investment * 5
            payoff = base + transfer
            agent.payoff_history.append(payoff)

            if audit is not None:
                truthful = abs(agent.reported_risk - agent.true_risk) < 1e-9
                agent.reputation = max(
                    0.0,
                    min(1.0, agent.reputation + regulator.reputation_weight * (1 if truthful else -1)),
                )

            transfers.append(transfer)

        lying_rate = sum(
            1 for agent in agents if abs(agent.reported_risk - agent.true_risk) > 1e-6
        ) / num_agents

        history["lying_rate"].append(lying_rate)
        history["avg_safety"].append(float(np.mean([a.safety_investment for a in agents])))
        history["reg_cost"].append(sum(transfers))
        history["welfare"].append(float(np.mean([a.payoff_history[-1] for a in agents])))

    return {"history": history, "agents": agents}


def check_incentive_compatibility(
    mechanism: dict,
    true_risk: float,
    safety_investment: float,
    possible_reports: List[float],
) -> dict:
    """Check whether truthful reporting maximizes expected payoff."""
    # Chained comparison validates the probability range.
    if not (0.0 <= true_risk <= 1.0):
        raise ValueError("true_risk must satisfy 0.0 <= true_risk <= 1.0")

    regulator = Regulator(mechanism)
    audit_prob = mechanism.get("audit_probability", 0.0)
    payoffs = {}

    for report in possible_reports:
        rep_diff = abs(report - true_risk)
        expected_transfer = regulator.safety_subsidy * safety_investment
        expected_transfer += audit_prob * (
            regulator.reward_for_truth if rep_diff < 1e-9 else -regulator.penalty_for_lying * rep_diff
        )
        base = (1 - safety_investment) * 10 - safety_investment * 5
        payoffs[report] = base + expected_transfer

    best_report = max(payoffs, key=payoffs.get)
    truthful = abs(best_report - true_risk) < 1e-9
    truthful_payoff = payoffs.get(true_risk, -float("inf"))
    gap = payoffs[best_report] - truthful_payoff

    return {
        "incentive_compatible": truthful,
        "best_report": best_report,
        "payoff_gap": gap,
        "payoffs": payoffs,
    }


def run_mechanism_comparison(base_params: dict) -> dict:
    """Compare NoOversight, RandomAudit, and TruthfulMechanism."""
    mechanisms = {
        "NoOversight": {
            "audit_probability": 0.0,
            "penalty_for_lying": 0.0,
            "reward_for_truth": 0.0,
            "safety_subsidy": 1.0,
        },
        "RandomAudit": {
            "audit_probability": 0.3,
            "penalty_for_lying": 5.0,
            "reward_for_truth": 1.0,
            "safety_subsidy": 1.0,
        },
        "TruthfulMechanism": {
            "audit_probability": 0.3,
            "penalty_for_lying": 10.0,
            "reward_for_truth": 3.0,
            "safety_subsidy": 2.0,
        },
    }

    results = {}
    for name, params in mechanisms.items():
        merged = dict(base_params)
        merged.update(params)
        results[name] = simulate_mechanism(
            name,
            base_params.get("num_agents", 20),
            base_params.get("num_rounds", 50),
            merged,
        )
    return results


def plot_mechanism_results(results: dict, output_path: str) -> None:
    """Plot lying rate, safety, regulator cost, and welfare."""
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))

    for name, res in results.items():
        h = res["history"]
        axes[0, 0].plot(h["lying_rate"], label=name)
        axes[0, 1].plot(h["avg_safety"], label=name)
        axes[1, 0].plot(h["reg_cost"], label=name)
        axes[1, 1].plot(h["welfare"], label=name)

    axes[0, 0].set_title("Lying Rate")
    axes[0, 1].set_title("Average Safety Investment")
    axes[1, 0].set_title("Regulator Cost")
    axes[1, 1].set_title("Social Welfare")

    for ax in axes.flat:
        ax.set_xlabel("Round")
        ax.legend()

    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)

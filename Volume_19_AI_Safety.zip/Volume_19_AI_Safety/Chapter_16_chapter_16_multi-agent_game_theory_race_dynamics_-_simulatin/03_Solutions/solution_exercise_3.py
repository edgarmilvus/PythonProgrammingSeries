
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# race_abm.py
"""Agent-based model of AI race dynamics and tragedy of the commons."""
from __future__ import annotations

import math
import random
from typing import Dict, List

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


class Lab:
    def __init__(self, lab_id: int, strategy: str, compute_budget: float):
        self.lab_id = lab_id
        self.strategy = strategy
        self.compute_budget = compute_budget
        self.safety_budget = 1.0 - compute_budget if compute_budget <= 1 else 0.0
        self.treaty_commitment = False
        self.reputation = 1.0
        self.payoff_history = []
        self.last_safety = 0.5

    def choose_safety_investment(self, state: dict) -> float:
        """Return safety investment fraction in [0,1]."""
        s = self.strategy

        if s == "SafetyFirst":
            return 0.8
        if s == "RaceToTheTop":
            return 0.1
        if s == "ConditionalCooperator":
            return 0.7 if state.get("avg_safety", 0.5) > 0.5 else 0.2
        if s == "StrategicDefector":
            return 0.1 if state.get("monitoring_probability", 0.0) < 0.5 else 0.6
        if s == "Learner":
            delta = random.uniform(-0.1, 0.1)
            return min(1.0, max(0.0, self.last_safety + delta))
        return 0.5


def catastrophe_probability(total_capability: float, params: dict) -> float:
    """
    Logistic risk function:
        p = 1 / (1 + exp(-k * (total_capability - threshold)))
    This is appropriate because risk is small below threshold and rises sharply after it.
    """
    k = params.get("risk_k", 0.5)
    threshold = params.get("risk_threshold", 10.0)
    x = k * (total_capability - threshold)
    return 1.0 / (1.0 + math.exp(-x))


def simulate_race(
    num_labs: int,
    num_steps: int,
    strategies: Dict[str, int],
    governance: dict,
    params: dict,
) -> dict:
    """Run the agent-based race simulation."""
    # Chained comparison validates monitoring probability.
    monitoring_probability = governance.get("monitoring_probability", 0.0)
    if not (0 <= monitoring_probability <= 1):
        raise ValueError("monitoring_probability must satisfy 0 <= monitoring_probability <= 1")

    labs: List[Lab] = []
    lab_id = 0
    for strat, count in strategies.items():
        for _ in range(count):
            labs.append(Lab(lab_id, strat, params.get("compute_budget", 1.0)))
            lab_id += 1

    if not labs:
        raise ValueError("At least one lab is required.")

    # Optionally enroll labs in treaty.
    if governance.get("treaty_enabled", False):
        for lab in labs:
            lab.treaty_commitment = random.random() < governance.get("treaty_participation", 0.7)

    history = {
        "total_capability": [],
        "avg_safety": [],
        "catastrophes": 0,
        "payoffs": [],
        "detected_violations": 0,
        "undetected_violations": 0,
    }

    for _ in range(num_steps):
        total_cap = 0.0
        safety_sum = 0.0
        step_payoffs = []

        for lab in labs:
            state = {
                "avg_safety": safety_sum / max(1, len(labs)),
                "monitoring_probability": monitoring_probability,
                "total_capability": total_cap,
            }

            s = lab.choose_safety_investment(state)
            lab.last_safety = s

            capability = (1.0 - s) * lab.compute_budget
            total_cap += capability
            safety_sum += s

            payoff = params.get("capability_reward", 1.0) * capability
            payoff -= params.get("safety_cost", 0.5) * s

            if governance.get("treaty_enabled", False) and lab.treaty_commitment:
                threshold = governance.get("min_safety", 0.5)
                if s < threshold:
                    if random.random() < monitoring_probability:
                        payoff -= governance.get("penalty", 0.0)
                        history["detected_violations"] += 1
                    else:
                        history["undetected_violations"] += 1
                else:
                    if random.random() < monitoring_probability:
                        payoff += governance.get("reward", 0.0)

            if random.random() < catastrophe_probability(total_cap, params):
                payoff -= params.get("catastrophe_penalty", 100.0)
                history["catastrophes"] += 1

            lab.payoff_history.append(payoff)
            step_payoffs.append(payoff)

        history["total_capability"].append(total_cap)
        history["avg_safety"].append(safety_sum / len(labs))
        history["payoffs"].append(float(np.mean(step_payoffs)))

    return {"history": history, "labs": labs}


def run_governance_experiments(base_params: dict) -> dict:
    """Compare no governance, treaty, monitoring, penalties, and mechanism design."""
    regimes = {
        "no_governance": {
            "treaty_enabled": False,
            "monitoring_probability": 0.0,
            "penalty": 0.0,
            "reward": 0.0,
        },
        "voluntary_treaty": {
            "treaty_enabled": True,
            "monitoring_probability": 0.0,
            "penalty": 0.0,
            "reward": 0.0,
        },
        "treaty_monitoring": {
            "treaty_enabled": True,
            "monitoring_probability": 0.5,
            "penalty": 0.0,
            "reward": 0.0,
        },
        "treaty_penalties": {
            "treaty_enabled": True,
            "monitoring_probability": 0.5,
            "penalty": 10.0,
            "reward": 0.0,
        },
        "mechanism_design": {
            "treaty_enabled": True,
            "monitoring_probability": 0.7,
            "penalty": 10.0,
            "reward": 5.0,
        },
    }

    results = {}
    for name, gov in regimes.items():
        reps = []
        for seed in range(3):
            random.seed(seed)
            res = simulate_race(
                base_params["num_labs"],
                base_params["num_steps"],
                base_params["strategies"],
                gov,
                base_params["params"],
            )
            reps.append(res)

        results[name] = {
            "avg_total_capability": float(np.mean([np.mean(r["history"]["total_capability"]) for r in reps])),
            "avg_safety": float(np.mean([np.mean(r["history"]["avg_safety"]) for r in reps])),
            "catastrophe_prob": float(np.mean([r["history"]["catastrophes"] / base_params["num_steps"] for r in reps])),
            "avg_payoff": float(np.mean([np.mean(r["history"]["payoffs"]) for r in reps])),
            "time_series": [r["history"] for r in reps],
        }

    return results


def plot_abm_results(results: dict, output_path: str) -> None:
    """Plot capability, safety, catastrophes, and payoff distribution."""
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))

    for name, res in results.items():
        for ts in res["time_series"]:
            axes[0, 0].plot(ts["total_capability"], alpha=0.4)
            axes[0, 1].plot(ts["avg_safety"], alpha=0.4)

    axes[0, 0].set_title("Total Capability")
    axes[0, 1].set_title("Average Safety Investment")

    axes[1, 0].bar(list(results.keys()), [r["catastrophe_prob"] for r in results.values()])
    axes[1, 0].set_title("Catastrophe Probability")
    axes[1, 0].tick_params(axis="x", rotation=45)

    axes[1, 1].bar(list(results.keys()), [r["avg_payoff"] for r in results.values()])
    axes[1, 1].set_title("Average Payoff")
    axes[1, 1].tick_params(axis="x", rotation=45)

    for ax in axes.flat:
        ax.set_xlabel("Step / Regime")

    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def analyze_tragedy_of_the_commons(results: dict) -> dict:
    """Compute social cost of anarchy, free-rider index, and cooperation gap."""
    no_gov = results["no_governance"]
    mech = results["mechanism_design"]

    social_cost = mech["avg_payoff"] - no_gov["avg_payoff"]
    free_rider = no_gov["avg_total_capability"] / max(1e-9, mech["avg_total_capability"])
    cooperation_gap = mech["avg_safety"] - no_gov["avg_safety"]

    return {
        "social_cost_of_anarchy": max(0.0, -social_cost),
        "free_rider_index": free_rider,
        "cooperation_gap": cooperation_gap,
        "interpretation": (
            "A positive cooperation gap and a high free-rider index indicate that "
            "unregulated competition overuses shared risk relative to mechanism design."
        ),
    }

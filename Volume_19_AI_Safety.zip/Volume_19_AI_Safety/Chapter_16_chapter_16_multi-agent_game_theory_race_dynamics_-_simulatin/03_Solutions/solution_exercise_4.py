
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# marl_treaty_app.py
"""Flask MARL treaty/monitoring simulation."""
from __future__ import annotations

import os
import random
import time
import uuid

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from flask import Flask, render_template_string, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = "replace-with-a-long-random-secret"  # signed session cookie secret

RUNS = {}  # server-side store; session stores only run IDs
STATIC_DIR = os.path.join(os.path.dirname(__file__), "static")
os.makedirs(STATIC_DIR, exist_ok=True)

FORM = """
<!doctype html>
<title>MARL Treaty</title>
<h1>MARL Treaty Simulation</h1>
{% if errors %}<ul>{% for e in errors %}<li style="color:red">{{ e }}</li>{% endfor %}</ul>{% endif %}
<form method="post" action="/run">
<label>Agents <input name="num_agents" value="{{ params.get('num_agents', 3) }}"></label><br>
<label>Episodes <input name="episodes" value="{{ params.get('episodes', 200) }}"></label><br>
<label>Learning rate <input name="learning_rate" value="{{ params.get('learning_rate', 0.1) }}"></label><br>
<label>Treaty threshold <input name="treaty_threshold" value="{{ params.get('treaty_threshold', 0.6) }}"></label><br>
<label>Monitoring <input name="monitoring_probability" value="{{ params.get('monitoring_probability', 0.3) }}"></label><br>
<label>Violation penalty <input name="violation_penalty" value="{{ params.get('violation_penalty', 5.0) }}"></label><br>
<label>Compliance reward <input name="compliance_reward" value="{{ params.get('compliance_reward', 2.0) }}"></label><br>
<label>Catastrophe penalty <input name="catastrophe_penalty" value="{{ params.get('catastrophe_penalty', 20.0) }}"></label><br>
<button type="submit">Run</button>
</form>
<p><a href="/history">History</a> | <a href="/challenge">Challenge</a></p>
"""


def validate_params(params: dict) -> list[str]:
    """Validate inputs using chained comparisons."""
    errors = []

    def check(k, default, lo, hi, integer=False):
        try:
            v = float(params.get(k, default))
        except (TypeError, ValueError):
            errors.append(f"{k} must be numeric")
            return None
        if integer and int(v) != v:
            errors.append(f"{k} must be an integer")
        if not (lo <= v <= hi):
            errors.append(f"{k} must satisfy {lo} <= {k} <= {hi}")
        return int(v) if integer else v

    check("num_agents", 3, 1, 50, True)
    check("episodes", 200, 1, 10000, True)
    check("learning_rate", 0.1, 0.0, 1.0)
    check("treaty_threshold", 0.6, 0.0, 1.0)
    check("monitoring_probability", 0.3, 0.0, 1.0)
    check("violation_penalty", 5.0, 0.0, 100.0)
    check("compliance_reward", 2.0, 0.0, 100.0)
    check("catastrophe_penalty", 20.0, 0.0, 1000.0)
    return errors


class QAgent:
    """Simple tabular Q-learning agent."""

    def __init__(self, agent_id, actions, lr=0.1, gamma=0.9, epsilon=0.1):
        self.id = agent_id
        self.actions = actions
        self.lr = lr
        self.gamma = gamma
        self.epsilon = epsilon
        self.q = {}
        self.last_state = None
        self.last_action = None

    def _qvals(self, state):
        if state not in self.q:
            self.q[state] = {a: 0.0 for a in self.actions}
        return self.q[state]

    def choose(self, state):
        if random.random() < self.epsilon:
            action = random.choice(self.actions)
        else:
            qvals = self._qvals(state)
            action = max(qvals, key=qvals.get)
        self.last_state = state
        self.last_action = action
        return action

    def update(self, reward, next_state):
        qvals = self._qvals(self.last_state)
        next_q = self._qvals(next_state)
        qvals[self.last_action] += self.lr * (
            reward + self.gamma * max(next_q.values()) - qvals[self.last_action]
        )


def run_marl_sim(params: dict) -> dict:
    """Run a small MARL simulation with treaty and monitoring."""
    num_agents = int(params["num_agents"])
    episodes = int(params["episodes"])
    threshold = float(params["treaty_threshold"])
    monitor = float(params["monitoring_probability"])
    penalty = float(params["violation_penalty"])
    reward = float(params["compliance_reward"])
    catastrophe_penalty = float(params["catastrophe_penalty"])

    agents = [
        QAgent(i, [0.0, 0.25, 0.5, 0.75, 1.0], lr=float(params["learning_rate"]))
        for i in range(num_agents)
    ]

    safety_history = []
    detected = []
    undetected = []
    compliant = []

    for ep in range(episodes):
        joined = [random.random() < 0.7 for _ in range(num_agents)]
        total_safety = 0.0
        det = und = comp = 0

        for i, ag in enumerate(agents):
            state = (ep > 0, monitor > 0.5)
            s = ag.choose(state)
            total_safety += s

            r = (1 - s) * 1.0 - s * 0.5

            if joined[i]:
                if s < threshold:
                    if random.random() < monitor:
                        r -= penalty
                        det += 1
                    else:
                        und += 1
                else:
                    if random.random() < monitor:
                        r += reward
                        comp += 1

            if total_safety / num_agents < 0.4:
                r -= catastrophe_penalty / num_agents

            ag.update(r, (True, monitor > 0.5))

        safety_history.append(total_safety / num_agents)
        detected.append(det)
        undetected.append(und)
        compliant.append(comp)

    run_id = str(uuid.uuid4())
    plot1 = f"{run_id}_safety.png"
    plot2 = f"{run_id}_violations.png"

    fig, ax = plt.subplots()
    ax.plot(safety_history)
    ax.set_title("Average Safety Investment")
    ax.set_xlabel("Episode")
    ax.set_ylabel("Safety")
    fig.savefig(os.path.join(STATIC_DIR, plot1), dpi=100)
    plt.close(fig)

    fig, ax = plt.subplots()
    ax.bar(["Detected", "Undetected", "Compliant"], [sum(detected), sum(undetected), sum(compliant)])
    ax.set_title("Monitoring Outcomes")
    fig.savefig(os.path.join(STATIC_DIR, plot2), dpi=100)
    plt.close(fig)

    return {
        "run_id": run_id,
        "params": params,
        "avg_safety": float(np.mean(safety_history)),
        "cooperation_rate": float(np.mean(safety_history)),
        "treaty_compliance_rate": 1 - sum(undetected) / max(1, sum(detected) + sum(undetected) + sum(compliant)),
        "detection_rate": sum(detected) / max(1, sum(detected) + sum(undetected)),
        "plots": [plot1, plot2],
        "timestamp": time.time(),
    }


@app.route("/", methods=["GET"])
def index():
    return render_template_string(FORM, params=session.get("params", {}), errors=[])


@app.route("/run", methods=["POST"])
def run_simulation():
    keys = [
        "num_agents", "episodes", "learning_rate", "treaty_threshold",
        "monitoring_probability", "violation_penalty", "compliance_reward",
        "catastrophe_penalty",
    ]
    params = {k: request.form.get(k) for k in keys}
    errors = validate_params(params)
    if errors:
        return render_template_string(FORM, params=params, errors=errors)

    session["params"] = params
    res = run_marl_sim(params)
    RUNS[res["run_id"]] = res
    session.setdefault("runs", []).append(res["run_id"])
    return redirect(url_for("show_results", run_id=res["run_id"]))


@app.route("/results/<run_id>")
def show_results(run_id):
    res = RUNS.get(run_id)
    if not res:
        return "Run not found", 404
    return render_template_string("""
    <h1>Results {{ res.run_id }}</h1>
    <p>Average safety: {{ res.avg_safety|round(3) }}</p>
    <p>Treaty compliance: {{ res.treaty_compliance_rate|round(3) }}</p>
    <p>Detection rate: {{ res.detection_rate|round(3) }}</p>
    {% for p in res.plots %}
      <div><img src="/static/{{ p }}" width="500"></div>
    {% endfor %}
    <p><a href="/">Back</a></p>
    """, res=res)


@app.route("/history")
def history():
    ids = session.get("runs", [])
    return render_template_string("""
    <h1>Run History</h1>
    <ul>{% for rid in ids %}<li><a href="/results/{{ rid }}">{{ rid }}</a></li>{% endfor %}</ul>
    <a href="/">Back</a>
    """, ids=ids)


@app.route("/clear", methods=["POST"])
def clear():
    session.clear()
    return redirect(url_for("index"))


@app.route("/challenge", methods=["GET", "POST"])
def challenge():
    msg = ""
    if request.method == "POST":
        rid = request.form.get("run_id")
        res = RUNS.get(rid)
        if res:
            # Simplified challenge check: detection rate must fall and safety must remain high.
            ok = res["detection_rate"] < 0.5 and res["avg_safety"] >= 0.6
            session["challenge_met"] = ok
            msg = "Challenge MET" if ok else "Challenge NOT met"
    return render_template_string("""
    <h1>Interactive Challenge</h1>
    <p>Target: increase monitoring from 0.2 to 0.8, reduce detected violations by 50%, keep safety >= 0.6.</p>
    <form method="post">
      <input name="run_id" placeholder="run id">
      <button type="submit">Check</button>
    </form>
    <p>{{ msg }}</p>
    <a href="/">Back</a>
    """, msg=msg)

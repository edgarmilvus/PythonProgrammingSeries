
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# safety_race.py
"""
Two-agent safety race game.

Actions are "Safety" and "Speed".  Row player is Lab 1, column player is Lab 2.
"""
from __future__ import annotations

import argparse
import math
from typing import Callable, Dict, List, Tuple

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ACTIONS = ("Safety", "Speed")


def build_payoffs(
    safety_benefit: float,
    race_benefit: float,
    winner_bonus: float,
    safety_penalty: float,
    catastrophe_penalty: float,
) -> dict:
    """Build payoff dictionary keyed by (Lab1 action, Lab2 action)."""
    # Chained comparisons are appropriate for range checks because they read naturally:
    # 0 <= x <= 100 means x is at least 0 and at most 100.
    for name, value in {
        "safety_benefit": safety_benefit,
        "race_benefit": race_benefit,
        "winner_bonus": winner_bonus,
        "safety_penalty": safety_penalty,
        "catastrophe_penalty": catastrophe_penalty,
    }.items():
        if not (0 <= value <= 1000):
            raise ValueError(f"{name} must satisfy 0 <= {name} <= 1000")

    return {
        ("Safety", "Safety"): (safety_benefit, safety_benefit),
        ("Safety", "Speed"): (
            safety_benefit - safety_penalty,
            race_benefit + winner_bonus,
        ),
        ("Speed", "Safety"): (
            race_benefit + winner_bonus,
            safety_benefit - safety_penalty,
        ),
        ("Speed", "Speed"): (
            race_benefit - catastrophe_penalty,
            race_benefit - catastrophe_penalty,
        ),
    }


def best_response(player: int, opponent_action: str, payoffs: dict) -> List[str]:
    """Return all best responses for player 0 or 1 against opponent_action."""
    if player not in (0, 1):
        raise ValueError("player must be 0 for Lab1 or 1 for Lab2")

    best_value = -math.inf
    best_actions: List[str] = []

    for action in ACTIONS:
        key = (action, opponent_action) if player == 0 else (opponent_action, action)
        value = payoffs[key][player]
        if value > best_value:
            best_value = value
            best_actions = [action]
        elif value == best_value:
            best_actions.append(action)

    return best_actions


def pure_nash_equilibria(payoffs: dict) -> List[Tuple[str, str]]:
    """Find all pure-strategy Nash equilibria by checking mutual best responses."""
    actions = sorted({a for pair in payoffs for a in pair})
    equilibria = []

    for a1 in actions:
        for a2 in actions:
            br1 = best_response(0, a2, payoffs)
            br2 = best_response(1, a1, payoffs)
            if a1 in br1 and a2 in br2:
                equilibria.append((a1, a2))

    return equilibria


def _lab1_indifference_prob(payoffs: dict) -> float | None:
    """Probability that Lab2 plays Safety makes Lab1 indifferent."""
    u_ss = payoffs[("Safety", "Safety")][0]
    u_s_sp = payoffs[("Safety", "Speed")][0]
    u_sp_s = payoffs[("Speed", "Safety")][0]
    u_sp_sp = payoffs[("Speed", "Speed")][0]

    denom = u_ss - u_s_sp - u_sp_s + u_sp_sp
    if abs(denom) < 1e-12:
        return None

    q = (u_sp_sp - u_s_sp) / denom
    return q if -1e-12 <= q <= 1 + 1e-12 else None


def _lab2_indifference_prob(payoffs: dict) -> float | None:
    """Probability that Lab1 plays Safety makes Lab2 indifferent."""
    v_ss = payoffs[("Safety", "Safety")][1]
    v_sp_s = payoffs[("Speed", "Safety")][1]
    v_s_sp = payoffs[("Safety", "Speed")][1]
    v_sp_sp = payoffs[("Speed", "Speed")][1]

    denom = v_ss - v_sp_s - v_s_sp + v_sp_sp
    if abs(denom) < 1e-12:
        return None

    p = (v_sp_sp - v_sp_s) / denom
    return p if -1e-12 <= p <= 1 + 1e-12 else None


def mixed_nash_equilibria(payoffs: dict) -> List[dict]:
    """Return interior mixed Nash equilibria for the 2x2 game."""
    q = _lab1_indifference_prob(payoffs)
    p = _lab2_indifference_prob(payoffs)

    if p is None or q is None:
        return []

    p = min(1.0, max(0.0, p))
    q = min(1.0, max(0.0, q))

    # Only return interior mixed equilibria.  Boundary collapses are handled by pure_nash_equilibria.
    if 0 < p < 1 and 0 < q < 1:
        return [{
            "Lab1": {"Safety": p, "Speed": 1 - p},
            "Lab2": {"Safety": q, "Speed": 1 - q},
        }]
    return []


def simulate_play(
    payoffs: dict,
    strategy_lab1: Callable[[int, dict], str],
    strategy_lab2: Callable[[int, dict], str],
    rounds: int,
) -> dict:
    """Simulate repeated play under fixed strategies."""
    history = {
        "actions1": [],
        "actions2": [],
        "payoffs1": [],
        "payoffs2": [],
    }

    cum1 = cum2 = 0.0
    counts1 = {"Safety": 0, "Speed": 0}
    counts2 = {"Safety": 0, "Speed": 0}
    both_safety = 0

    for r in range(rounds):
        a1 = strategy_lab1(r, history)
        a2 = strategy_lab2(r, history)
        p1, p2 = payoffs[(a1, a2)]

        history["actions1"].append(a1)
        history["actions2"].append(a2)
        history["payoffs1"].append(p1)
        history["payoffs2"].append(p2)

        cum1 += p1
        cum2 += p2
        counts1[a1] += 1
        counts2[a2] += 1

        if a1 == a2 == "Safety":
            both_safety += 1

    return {
        "cumulative": (cum1, cum2),
        "counts": (counts1, counts2),
        "both_safety_fraction": both_safety / rounds if rounds else 0.0,
        "history": history,
    }


def visualize_best_responses(payoffs: dict, output_path: str) -> None:
    """Plot best-response correspondences and equilibrium points."""
    qs = [i / 100 for i in range(101)]
    lab1_br = []

    for q in qs:
        u_safety = q * payoffs[("Safety", "Safety")][0] + (1 - q) * payoffs[("Safety", "Speed")][0]
        u_speed = q * payoffs[("Speed", "Safety")][0] + (1 - q) * payoffs[("Speed", "Speed")][0]
        if u_safety > u_speed:
            lab1_br.append(1)
        elif u_speed > u_safety:
            lab1_br.append(0)
        else:
            lab1_br.append(0.5)

    ps = [i / 100 for i in range(101)]
    lab2_br = []

    for p in ps:
        u_safety = p * payoffs[("Safety", "Safety")][1] + (1 - p) * payoffs[("Speed", "Safety")][1]
        u_speed = p * payoffs[("Safety", "Speed")][1] + (1 - p) * payoffs[("Speed", "Speed")][1]
        if u_safety > u_speed:
            lab2_br.append(1)
        elif u_speed > u_safety:
            lab2_br.append(0)
        else:
            lab2_br.append(0.5)

    fig, ax = plt.subplots(figsize=(7, 6))
    ax.plot(qs, lab1_br, drawstyle="steps-post", label="Lab1 BR: y=P(Lab1 Safety)")
    ax.plot(lab2_br, ps, drawstyle="steps-post", label="Lab2 BR: x=P(Lab2 Safety)")

    pure = pure_nash_equilibria(payoffs)
    for i, (a1, a2) in enumerate(pure):
        ax.scatter(
            [1 if a2 == "Safety" else 0],
            [1 if a1 == "Safety" else 0],
            color="red",
            marker="o",
            s=80,
            label="Pure NE" if i == 0 else None,
        )

    for i, mx in enumerate(mixed_nash_equilibria(payoffs)):
        ax.scatter(
            [mx["Lab2"]["Safety"]],
            [mx["Lab1"]["Safety"]],
            color="green",
            marker="x",
            s=100,
            label="Mixed NE" if i == 0 else None,
        )

    ax.set_xlabel("Probability Lab2 plays Safety")
    ax.set_ylabel("Probability Lab1 plays Safety")
    ax.set_title("Best-Response Correspondences")
    ax.legend()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def classify_game(payoffs: dict) -> str:
    """Classify the game using pure equilibria and payoff ordering."""
    eqs = pure_nash_equilibria(payoffs)
    ss = payoffs[("Safety", "Safety")]
    sp = payoffs[("Speed", "Speed")]

    if ("Speed", "Speed") in eqs and ss[0] > sp[0] and ss[1] > sp[1]:
        return "Prisoner's dilemma / coordination failure"
    if ("Safety", "Safety") in eqs and ("Speed", "Speed") in eqs and len(eqs) == 2:
        return "Coordination game"
    if ("Safety", "Speed") in eqs or ("Speed", "Safety") in eqs:
        return "Anti-coordination game"
    if eqs == [("Safety", "Safety")]:
        return "Safety-dominant"
    if eqs == [("Speed", "Speed")]:
        return "Speed-dominant"
    return "Other / mixed-incentive game"


def main() -> None:
    parser = argparse.ArgumentParser(description="Two-agent safety race equilibrium simulator")
    parser.add_argument("--safety-benefit", type=float, default=3.0)
    parser.add_argument("--race-benefit", type=float, default=5.0)
    parser.add_argument("--winner-bonus", type=float, default=4.0)
    parser.add_argument("--safety-penalty", type=float, default=2.0)
    parser.add_argument("--catastrophe-penalty", type=float, default=3.0)
    parser.add_argument("--plot", type=str, default=None)
    args = parser.parse_args()

    payoffs = build_payoffs(
        args.safety_benefit,
        args.race_benefit,
        args.winner_bonus,
        args.safety_penalty,
        args.catastrophe_penalty,
    )

    print("Payoff matrix:")
    for a1 in ACTIONS:
        for a2 in ACTIONS:
            print(f"  Lab1={a1:6s} Lab2={a2:6s} -> {payoffs[(a1, a2)]}")

    print("\nPure Nash equilibria:", pure_nash_equilibria(payoffs))
    print("Mixed Nash equilibria:", mixed_nash_equilibria(payoffs))
    print("Classification:", classify_game(payoffs))

    if args.plot:
        visualize_best_responses(payoffs, args.plot)
        print(f"Saved best-response plot to {args.plot}")


if __name__ == "__main__":
    main()

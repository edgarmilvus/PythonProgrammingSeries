
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# repeated_safety_dilemma.py
"""Repeated safety dilemma with evolutionary dynamics."""
from __future__ import annotations

import random
from typing import Dict, List

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

COOP = "Cooperate"
DEFECT = "Defect"


class Strategy:
    name = "Base"

    def choose_action(self, history: dict, round_number: int) -> str:
        raise NotImplementedError


class AlwaysCooperate(Strategy):
    name = "AlwaysCooperate"

    def choose_action(self, history: dict, round_number: int) -> str:
        return COOP


class AlwaysDefect(Strategy):
    name = "AlwaysDefect"

    def choose_action(self, history: dict, round_number: int) -> str:
        return DEFECT


class TitForTat(Strategy):
    name = "TitForTat"

    def choose_action(self, history: dict, round_number: int) -> str:
        if round_number == 0:
            return COOP
        return history["opponent_actions"][-1]


class GrimTrigger(Strategy):
    name = "GrimTrigger"

    def choose_action(self, history: dict, round_number: int) -> str:
        if any(a == DEFECT for a in history["opponent_actions"]):
            return DEFECT
        return COOP


class Pavlov(Strategy):
    name = "Pavlov"

    def choose_action(self, history: dict, round_number: int) -> str:
        if round_number == 0:
            return COOP
        last_payoff = history["my_payoffs"][-1]
        last_action = history["my_actions"][-1]
        if last_payoff >= 3:
            return last_action
        return COOP if last_action == DEFECT else DEFECT


class RandomStrategy(Strategy):
    def __init__(self, p_coop: float = 0.5):
        self.p_coop = p_coop
        self.name = f"Random({p_coop})"

    def choose_action(self, history: dict, round_number: int) -> str:
        return COOP if random.random() < self.p_coop else DEFECT


def make_strategy(name: str) -> Strategy:
    if name == "AlwaysCooperate":
        return AlwaysCooperate()
    if name == "AlwaysDefect":
        return AlwaysDefect()
    if name == "TitForTat":
        return TitForTat()
    if name == "GrimTrigger":
        return GrimTrigger()
    if name == "Pavlov":
        return Pavlov()
    if name.startswith("Random"):
        return RandomStrategy()
    raise ValueError(f"Unknown strategy: {name}")


DEFAULT_PD = {
    (COOP, COOP): (3, 3),
    (COOP, DEFECT): (0, 5),
    (DEFECT, COOP): (5, 0),
    (DEFECT, DEFECT): (1, 1),
}


def play_match(
    strategy_a: Strategy,
    strategy_b: Strategy,
    payoff_matrix: dict,
    rounds: int,
    horizon_type: str = "finite",
    catastrophe_probability: float = 0.0,
    continuation_probability: float = 0.95,
    noise: float = 0.0,
) -> dict:
    """Play a repeated game.  History is presented from each agent's perspective."""
    if horizon_type not in ("finite", "infinite", "uncertain"):
        raise ValueError("horizon_type must be finite, infinite, or uncertain")
    if not (0 <= catastrophe_probability <= 1):
        raise ValueError("catastrophe_probability must be in [0,1]")
    if not (0 <= noise <= 1):
        raise ValueError("noise must be in [0,1]")

    history = {
        "actions_a": [],
        "actions_b": [],
        "payoffs_a": [],
        "payoffs_b": [],
        "catastrophes": 0,
    }

    max_rounds = rounds if horizon_type == "finite" else 10000
    r = 0

    while r < max_rounds:
        if horizon_type == "finite" and r >= rounds:
            break

        hist_a = {
            "my_actions": history["actions_a"],
            "opponent_actions": history["actions_b"],
            "my_payoffs": history["payoffs_a"],
            "opponent_payoffs": history["payoffs_b"],
            "round": r,
            "final_round": rounds if horizon_type == "finite" else None,
        }
        hist_b = {
            "my_actions": history["actions_b"],
            "opponent_actions": history["actions_a"],
            "my_payoffs": history["payoffs_b"],
            "opponent_payoffs": history["payoffs_a"],
            "round": r,
            "final_round": rounds if horizon_type == "finite" else None,
        }

        a = strategy_a.choose_action(hist_a, r)
        b = strategy_b.choose_action(hist_b, r)

        # Noisy observation affects what the opponent remembers, not the actual payoff.
        a_observed = a
        b_observed = b
        if random.random() < noise:
            a_observed = DEFECT if a == COOP else COOP
        if random.random() < noise:
            b_observed = DEFECT if b == COOP else COOP

        p_a, p_b = payoff_matrix[(a, b)]

        if a == DEFECT and b == DEFECT and random.random() < catastrophe_probability:
            p_a -= 10
            p_b -= 10
            history["catastrophes"] += 1

        history["actions_a"].append(a_observed)
        history["actions_b"].append(b_observed)
        history["payoffs_a"].append(p_a)
        history["payoffs_b"].append(p_b)

        r += 1

        if horizon_type in ("infinite", "uncertain") and random.random() > continuation_probability:
            break

    coop_rounds = sum(1 for a, b in zip(history["actions_a"], history["actions_b"]) if a == COOP and b == COOP)
    n = max(1, len(history["actions_a"]))

    return {
        "history": history,
        "cumulative_a": sum(history["payoffs_a"]),
        "cumulative_b": sum(history["payoffs_b"]),
        "cooperation_rate": coop_rounds / n,
        "catastrophes": history["catastrophes"],
        "rounds_played": n,
    }


def run_tournament(
    strategies: List[Strategy],
    payoff_matrix: dict,
    rounds: int,
    horizon_type: str,
    catastrophe_probability: float,
    repetitions: int = 5,
    seed: int = 0,
) -> dict:
    """Round-robin tournament. Ties are averaged over repetitions."""
    random.seed(seed)
    names = [s.name for s in strategies]
    payoff_sum = {n: {m: 0.0 for m in names} for n in names}
    coop_sum = {n: {m: 0.0 for m in names} for n in names}

    for s1 in strategies:
        for s2 in strategies:
            for _ in range(repetitions):
                res = play_match(s1, s2, payoff_matrix, rounds, horizon_type, catastrophe_probability)
                payoff_sum[s1.name][s2.name] += res["cumulative_a"]
                coop_sum[s1.name][s2.name] += res["cooperation_rate"]

    return {
        "names": names,
        "avg_payoff": {n: {m: payoff_sum[n][m] / repetitions for m in names} for n in names},
        "avg_cooperation": {n: {m: coop_sum[n][m] / repetitions for m in names} for n in names},
    }


def evolve_population(
    initial_population: Dict[str, float],
    generations: int,
    mutation_rate: float,
    payoff_matrix: dict,
    rounds: int,
    horizon_type: str,
    catastrophe_probability: float,
    seed: int = 0,
    continuation_probability: float = 0.95,
    samples_per_strategy: int = 20,
) -> dict:
    """Evolutionary simulation with fitness-proportional selection and mutation."""
    # Chained comparison is a concise, readable range check.
    if not (0 <= mutation_rate <= 1):
        raise ValueError("mutation_rate must satisfy 0 <= mutation_rate <= 1")
    if not (0 < continuation_probability <= 1):
        raise ValueError("continuation_probability must satisfy 0 < continuation_probability <= 1")

    random.seed(seed)
    names = list(initial_population.keys())
    total = sum(initial_population.values())
    pop = {k: v / total for k, v in initial_population.items()}
    strategy_objs = {name: make_strategy(name) for name in names}

    history = {
        "fractions": [],
        "avg_cooperation": [],
        "avg_payoff": [],
        "catastrophes": [],
    }

    for _ in range(generations):
        fitness = {n: 0.0 for n in names}

        for n in names:
            for _ in range(samples_per_strategy):
                opp = random.choices(names, weights=[pop[k] for k in names])[0]
                res = play_match(
                    strategy_objs[n],
                    strategy_objs[opp],
                    payoff_matrix,
                    rounds,
                    horizon_type,
                    catastrophe_probability,
                    continuation_probability,
                )
                fitness[n] += res["cumulative_a"]

        avg_fitness = sum(fitness[n] * pop[n] for n in names)
        new_pop = {
            n: pop[n] * (fitness[n] / avg_fitness if avg_fitness > 0 else 1.0)
            for n in names
        }

        # Mutation: move a small fraction of mass to another strategy.
        for n in names:
            if random.random() < mutation_rate:
                target = random.choice([x for x in names if x != n])
                move = new_pop[n] * mutation_rate
                new_pop[n] -= move
                new_pop[target] += move

        total = sum(new_pop.values())
        pop = {k: max(0.0, v / total) for k, v in new_pop.items()}

        history["fractions"].append(pop.copy())
        history["avg_cooperation"].append(0.5)
        history["avg_payoff"].append(avg_fitness)
        history["catastrophes"].append(0)

    return history


def plot_evolution(history: dict, output_path: str) -> None:
    """Plot strategy frequencies, cooperation, payoffs, and catastrophes."""
    fig, axes = plt.subplots(3, 1, figsize=(10, 10), sharex=True)
    fractions = history["fractions"]

    for name in fractions[0]:
        axes[0].plot([f[name] for f in fractions], label=name)
    axes[0].set_ylabel("Frequency")
    axes[0].legend()
    axes[0].set_title("Strategy Frequencies")

    axes[1].plot(history["avg_cooperation"], label="Cooperation")
    axes[1].plot(history["avg_payoff"], label="Average payoff")
    axes[1].legend()
    axes[1].set_ylabel("Value")

    axes[2].plot(history["catastrophes"], color="red", label="Catastrophes")
    axes[2].set_xlabel("Generation")
    axes[2].set_ylabel("Catastrophes")
    axes[2].legend()

    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def analyze_commitment_problem(results_finite: dict, results_infinite: dict) -> dict:
    """Compare finite and uncertain horizons."""
    def final_coop(h):
        return h["avg_cooperation"][-1] if h["avg_cooperation"] else 0.0

    def final_payoff(h):
        return h["avg_payoff"][-1] if h["avg_payoff"] else 0.0

    diff = {
        "cooperation_difference": final_coop(results_infinite) - final_coop(results_finite),
        "payoff_difference": final_payoff(results_infinite) - final_payoff(results_finite),
    }
    diff["summary"] = (
        "Uncertain horizons usually sustain more cooperation than finite horizons "
        "because backward induction cannot unravel reciprocity as easily."
    )
    return diff

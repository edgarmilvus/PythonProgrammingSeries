
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# safety_race_sim.py
# Simulate an AI-lab safety race and test governance interventions.

import os, random, sys
from dataclasses import dataclass
from typing import Dict, List, Tuple

@dataclass(frozen=True)
class RaceConfig:
    # Immutable config: clear names and no hidden side effects.
    rounds: int
    population: int
    temptation: float
    catastrophe_cost: float
    monitoring: float
    penalty: float
    safety_subsidy: float
    mutation: float
    learning_rate: float
    base_incident: float
    defection_risk: float
    initial_cooperation: float
    seed: int

def env_float(name, default):
    # Read float env var; exit cleanly on invalid input.
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return default
    try:
        return float(raw)
    except ValueError:
        print(f"Invalid float in {name}: {raw!r}", file=sys.stderr)
        sys.exit(2)

def env_int(name, default):
    # Read int env var; exit cleanly on invalid input.
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return default
    try:
        return int(raw)
    except ValueError:
        print(f"Invalid int in {name}: {raw!r}", file=sys.stderr)
        sys.exit(2)

def load_config():
    # Build config from environment variables with safe defaults.
    return RaceConfig(
        rounds=env_int("RACE_ROUNDS", 80),
        population=env_int("POPULATION_SIZE", 200),
        temptation=env_float("DEFECTION_TEMPTATION", 5.0),
        catastrophe_cost=env_float("CATASTROPHE_COST", 12.0),
        monitoring=env_float("MONITORING_STRENGTH", 0.35),
        penalty=env_float("TREATY_PENALTY", 3.0),
        safety_subsidy=env_float("SAFETY_SUBSIDY", 1.0),
        mutation=env_float("MUTATION_RATE", 0.02),
        learning_rate=env_float("LEARNING_RATE", 0.08),
        base_incident=env_float("BASE_INCIDENT_RISK", 0.01),
        defection_risk=env_float("DEFECTION_INCIDENT_RISK", 0.25),
        initial_cooperation=env_float("INITIAL_COOPERATION", 0.50),
        seed=env_int("RANDOM_SEED", 7),
    )

def payoffs(x, cfg):
    # Payoffs for cooperating and defecting when x fraction cooperates.
    public_good = 2.0 * x
    shared_risk = cfg.catastrophe_cost * (1.0 - x)
    coop = 2.0 + cfg.safety_subsidy + public_good - shared_risk
    defect = 4.0 + cfg.temptation + public_good - shared_risk
    defect -= cfg.monitoring * cfg.penalty * x
    return coop, defect

def replicator_step(x, cfg, rng):
    # Update cooperation fraction from payoff difference plus mutation.
    coop, defect = payoffs(x, cfg)
    growth = cfg.learning_rate * x * (1.0 - x) * (coop - defect)
    x_next = x + growth
    if rng.random() < cfg.mutation:
        x_next += rng.uniform(-0.01, 0.01)
    return min(1.0, max(0.0, x_next))

def simulate(cfg):
    # Run repeated game; record cooperation, payoffs, and incident data.
    rng = random.Random(cfg.seed)
    x = min(1.0, max(0.0, cfg.initial_cooperation))
    history = []
    for round_index in range(1, cfg.rounds + 1):
        coop, defect = payoffs(x, cfg)
        incident_prob = cfg.base_incident + (1.0 - x) * cfg.defection_risk
        incident_prob = min(1.0, max(0.0, incident_prob))
        incident_count = sum(
            1 for _ in range(cfg.population) if rng.random() < incident_prob
        )
        history.append({
            "round": float(round_index),
            "cooperation": x,
            "coop_payoff": coop,
            "defect_payoff": defect,
            "incident_prob": incident_prob,
            "incident_count": float(incident_count),
        })
        x = replicator_step(x, cfg, rng)
    return history

def summarize(history):
    # Reduce a run to headline safety and cooperation metrics.
    rounds = len(history)
    avg_coop = sum(row["cooperation"] for row in history) / rounds
    final_coop = history[-1]["cooperation"]
    incidents = sum(row["incident_count"] for row in history)
    avg_incident_prob = sum(row["incident_prob"] for row in history) / rounds
    avg_defect_advantage = sum(
        row["defect_payoff"] - row["coop_payoff"] for row in history
    ) / rounds
    return {
        "avg_cooperation": avg_coop,
        "final_cooperation": final_coop,
        "incidents": incidents,
        "avg_incident_prob": avg_incident_prob,
        "avg_defect_advantage": avg_defect_advantage,
    }

def with_intervention(base, **overrides):
    # Return config copy with selected governance parameters changed.
    data = base.__dict__.copy()
    data.update(overrides)
    return RaceConfig(**data)

def print_scenario(name, cfg, history):
    # Print one scenario summary in a compact row.
    s = summarize(history)
    print(
        f"{name:24s} avg_coop={s['avg_cooperation']:.3f} "
        f"final_coop={s['final_cooperation']:.3f} "
        f"incidents={s['incidents']:.0f} "
        f"avg_incident_prob={s['avg_incident_prob']:.3f} "
        f"defect_advantage={s['avg_defect_advantage']:.3f}"
    )

def main():
    # Entry point: validate config, run scenarios, and report comparisons.
    cfg = load_config()
    if cfg.population < 1 or cfg.rounds < 1:
        print("RACE_ROUNDS and POPULATION_SIZE must be positive.", file=sys.stderr)
        return 2
    if not (0.0 <= cfg.initial_cooperation <= 1.0):
        print("INITIAL_COOPERATION must be between 0 and 1.", file=sys.stderr)
        return 2
    if not (0.0 <= cfg.monitoring <= 1.0):
        print("MONITORING_STRENGTH must be between 0 and 1.", file=sys.stderr)
        return 2
    print("AI Safety Race Simulation: cooperation vs. capability sprint")
    print(f"Rounds={cfg.rounds} Population={cfg.population} Seed={cfg.seed}")
    print("-" * 96)
    scenarios = [
        ("Baseline race", cfg),
        ("Treaty monitoring", with_intervention(cfg, monitoring=0.80, penalty=6.0)),
        ("Safety subsidy", with_intervention(cfg, safety_subsidy=3.0)),
        (
            "Combined governance",
            with_intervention(cfg, monitoring=0.80, penalty=6.0, safety_subsidy=3.0),
        ),
    ]
    for name, scenario_cfg in scenarios:
        history = simulate(scenario_cfg)
        print_scenario(name, scenario_cfg, history)
    print("-" * 96)
    print("Interpretation: weak monitoring lets defection dominate; combined governance shifts equilibrium.")
    return 0

if __name__ == "__main__":
    # sys.exit() communicates success or failure to the operating system.
    sys.exit(main())

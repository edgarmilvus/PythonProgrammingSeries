
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# app.py
import os
from datetime import datetime
from flask import Flask, request, jsonify, session
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-secret")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///debate.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)

# SQLAlchemy models persist sessions, messages, critic findings, and verdicts.
class DebateSession(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    claim = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(32), default="running")
    confidence = db.Column(db.Float, default=0.0)
    verdict = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class DebateMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey("debate_session.id"))
    round = db.Column(db.Integer); role = db.Column(db.String(32)); content = db.Column(db.Text)

class CriticFinding(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey("debate_session.id"))
    round = db.Column(db.Integer); flaw = db.Column(db.Text); severity = db.Column(db.Float); suggestion = db.Column(db.Text)

class Verdict(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey("debate_session.id"))
    final_claim = db.Column(db.Text); confidence = db.Column(db.Float); safety_flag = db.Column(db.Boolean, default=False)

# Mock LLM call; replace with a real model API for production.
def llm_call(prompt: str, context: str = "") -> str:
    return f"Response to {prompt[:60]} | context {context[:60]}"

# DebateAgent wraps an LLM in a role-specific reasoning loop.
class DebateAgent:
    def __init__(self, name: str, stance: str):
        self.name, self.stance = name, stance
    def run(self, claim: str, history: list[dict]) -> str:
        return llm_call(f"Stance={self.stance}; Claim={claim}", str(history[-3:]))

# CriticModel decomposes claims and returns adversarial flaw findings.
class CriticModel:
    def critique(self, claim: str, messages: list[dict]) -> list[dict]:
        return [{"flaw": f"Unsupported assumption in {m['role']} argument",
                 "severity": 0.4 if m["role"] == "opponent" else 0.3,
                 "suggestion": "Demand evidence or narrow the claim."} for m in messages[-2:]]

# JudgeModel aggregates debate and critic findings into a verified verdict.
class JudgeModel:
    def judge(self, claim: str, messages: list[dict], findings: list[dict]) -> dict:
        penalty = sum(f["severity"] for f in findings) * 0.2
        confidence = max(0.0, min(1.0, 0.85 - penalty))
        safety_flag = any("harm" in f["flaw"].lower() for f in findings)
        return {"verdict": claim if confidence > 0.7 else "insufficient evidence",
                "confidence": confidence, "safety_flag": safety_flag}

# DebateOrchestrator runs iterative pro/con debate, critic review, and judge verification.
class DebateOrchestrator:
    def __init__(self, max_rounds: int = 3, min_confidence: float = 0.75):
        self.max_rounds, self.min_confidence = max_rounds, min_confidence
    def run(self, claim: str) -> dict:
        # Create persistent debate row and store its id in the Flask session cookie.
        ds = DebateSession(claim=claim, status="running")
        db.session.add(ds); db.session.commit(); session["debate_id"] = ds.id
        pro, con = DebateAgent("Proponent", "support"), DebateAgent("Opponent", "challenge")
        critic, judge, history = CriticModel(), JudgeModel(), []
        for round_num in range(1, self.max_rounds + 1):
            # Each round: pro argument, con rebuttal, then persistent message rows.
            pro_text = pro.run(claim, history); history.append({"role": "proponent", "content": pro_text})
            db.session.add(DebateMessage(session_id=ds.id, round=round_num, role="proponent", content=pro_text))
            con_text = con.run(claim, history); history.append({"role": "opponent", "content": con_text})
            db.session.add(DebateMessage(session_id=ds.id, round=round_num, role="opponent", content=con_text))
            # Critic model inspects latest exchange and records flaw findings.
            findings = critic.critique(claim, history)
            for f in findings:
                db.session.add(CriticFinding(session_id=ds.id, round=round_num, flaw=f["flaw"],
                                             severity=f["severity"], suggestion=f["suggestion"]))
            # Judge verifies confidence and safety before accepting the claim.
            decision = judge.judge(claim, history, findings)
            db.session.add(Verdict(session_id=ds.id, final_claim=decision["verdict"],
                                   confidence=decision["confidence"], safety_flag=decision["safety_flag"]))
            db.session.commit()
            if decision["safety_flag"]:
                ds.status, ds.confidence, ds.verdict = "flagged_for_human_review", decision["confidence"], decision["verdict"]
                db.session.commit(); return {"status": ds.status, "confidence": ds.confidence, "verdict": ds.verdict, "rounds": round_num}
            if decision["confidence"] >= self.min_confidence:
                ds.status, ds.confidence, ds.verdict = "verified", decision["confidence"], decision["verdict"]
                db.session.commit(); return {"status": ds.status, "confidence": ds.confidence, "verdict": ds.verdict, "rounds": round_num}
        # Exhausting rounds yields unresolved status instead of overclaiming.
        ds.status, ds.confidence, ds.verdict = "max_rounds_reached", decision["confidence"], decision["verdict"]
        db.session.commit(); return {"status": ds.status, "confidence": ds.confidence, "verdict": ds.verdict, "rounds": self.max_rounds}

# Flask endpoint accepts a claim, runs debate, and returns verified result.
@app.route("/verify", methods=["POST"])
def verify_claim():
    data = request.get_json(silent=True) or {}
    claim = data.get("claim", "").strip()
    if not claim: return jsonify({"error": "claim is required"}), 400
    return jsonify(DebateOrchestrator().run(claim)), 200

# Flask endpoint retrieves persisted debate state using the session cookie id.
@app.route("/session", methods=["GET"])
def get_session():
    debate_id = session.get("debate_id")
    if not debate_id: return jsonify({"error": "no debate session found"}), 404
    ds = DebateSession.query.get(debate_id)
    if not ds: return jsonify({"error": "debate session missing"}), 404
    msgs = DebateMessage.query.filter_by(session_id=debate_id).all()
    return jsonify({"claim": ds.claim, "status": ds.status, "confidence": ds.confidence,
                    "verdict": ds.verdict, "messages": [{"role": m.role, "content": m.content} for m in msgs]})

if __name__ == "__main__":
    with app.app_context(): db.create_all()
    app.run(debug=True)

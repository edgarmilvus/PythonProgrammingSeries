
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# orchestration/orchestrator.py
from __future__ import annotations

import concurrent.futures
import random
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable

from debate_schema import (
    AgentRole, CriticModel, DebateProtocol, Judge, MessageRole,
    ReviewType, RoundPhase, SessionStatus, UnitOfWork, VerificationEventType,
    VerdictType,
)


# ----------------------------- Configuration -----------------------------
@dataclass
class DebateConfig:
    topic: str
    max_rounds: int = 3
    turn_timeout_seconds: float = 5.0
    max_followups: int = 3
    blind_judging: bool = True
    randomize_order: bool = True
    multi_judge: bool = False
    escalation_critic_disagreement: float = 0.35
    escalation_judge_confidence: float = 0.4


@dataclass
class TurnResult:
    ok: bool
    content: str
    error: str | None = None


# ----------------------------- Agents -----------------------------
class MockProponentAgent:
    def __init__(self, agent_id: uuid.UUID):
        self.agent_id = agent_id

    def propose(self, session_id, round_id, context):
        return "Proponent: Model X is safe because evaluation coverage is broad."

    def respond_to_challenge(self, challenge_id, context):
        return "Proponent: The evaluation coverage includes adversarial and governance tests."


class MockChallengerAgent:
    def __init__(self, agent_id: uuid.UUID):
        self.agent_id = agent_id

    def critique(self, target_id, context):
        return "Challenger: The evidence does not cover deployment-time distribution shift."

    def ask_question(self, round_id, context):
        return "Challenger: What evidence covers distribution shift after deployment?"


class MockClarifierAgent:
    def __init__(self, agent_id: uuid.UUID):
        self.agent_id = agent_id

    def revise(self, claim_id, context):
        return "Clarifier: The scope is limited to controlled deployment."


class MockJudgeAgent(Judge):
    def __init__(self, agent_id: uuid.UUID):
        self.agent_id = agent_id

    def evaluate(self, session_id, context):
        return {
            "verdict_type": VerdictType.INCONCLUSIVE,
            "score_breakdown": {
                "logical_validity": 0.7,
                "evidence_quality": 0.6,
                "rebuttal_strength": 0.5,
                "clarity": 0.8,
                "epistemic_humility": 0.7,
                "responsiveness": 0.6,
            },
            "rationale": "Evidence is relevant but incomplete for deployment safety.",
            "confidence": 0.55,
        }


# ----------------------------- Critics -----------------------------
class BaseCritic(CriticModel):
    review_type: ReviewType

    def __init__(self, agent_id: uuid.UUID):
        self.agent_id = agent_id

    def review(self, target: Any, context: dict[str, Any]) -> Any:
        text = getattr(target, "content", "") or getattr(target, "original_text", "")
        issues: list[str] = []
        score = 0.7
        if self.review_type == ReviewType.LOGICAL_VALIDITY and "because" not in text.lower():
            issues.append("missing_explicit_premise")
            score = 0.45
        if self.review_type == ReviewType.EVIDENCE_QUALITY and "evidence" not in text.lower():
            issues.append("weak_evidence_reference")
            score = 0.4
        if self.review_type == ReviewType.BIAS and "only" in text.lower():
            issues.append("one_sided_framing")
            score = 0.5
        if self.review_type == ReviewType.DECEPTION and "contradict" in text.lower():
            issues.append("possible_contradiction")
            score = 0.3
        return type(
            "Review",
            (),
            {
                "score": score,
                "confidence": 0.8,
                "rationale": f"{self.review_type.value} review: {', '.join(issues) or 'no major issue'}",
                "detected_issues": issues,
                "recommended_action": "revise" if issues else "accept",
            },
        )()


class LogicCritic(BaseCritic):
    review_type = ReviewType.LOGICAL_VALIDITY


class EvidenceCritic(BaseCritic):
    review_type = ReviewType.EVIDENCE_QUALITY


class BiasCritic(BaseCritic):
    review_type = ReviewType.BIAS


class DeceptionCritic(BaseCritic):
    review_type = ReviewType.DECEPTION


# ----------------------------- Protocol -----------------------------
class CrossExaminationProtocol(DebateProtocol):
    def __init__(
        self,
        uow_factory,
        config: DebateConfig,
        proponent,
        challenger,
        clarifier,
        judge,
        critics: list[CriticModel],
    ):
        self.uow_factory = uow_factory
        self.config = config
        self.proponent = proponent
        self.challenger = challenger
        self.clarifier = clarifier
        self.judge = judge
        self.critics = critics

    def _run_with_timeout(self, fn: Callable, *args, **kwargs) -> TurnResult:
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(fn, *args, **kwargs)
            try:
                return TurnResult(True, future.result(timeout=self.config.turn_timeout_seconds))
            except concurrent.futures.TimeoutError:
                return TurnResult(False, "", "timeout")
            except Exception as exc:
                return TurnResult(False, "", str(exc))

    def run_round(self, session_id: uuid.UUID, round_index: int):
        with self.uow_factory() as uow:
            session = uow.sessions.get(session_id)
            round_obj = uow.sessions.session.query(type(session).rounds.property.mapper.class_).filter_by(
                session_id=session_id, index=round_index
            ).first()
            if round_obj is None:
                round_obj = uow.sessions.session.add(
                    type(session).rounds.property.mapper.class_(
                        session_id=session_id,
                        index=round_index,
                        phase=RoundPhase.OPENING,
                        state="running",
                    )
                )
                uow.flush()

            # Phase 1: opening.
            opening = self._run_with_timeout(self.proponent.propose, session_id, round_obj.id, {})
            self._persist_message(uow, round_obj.id, self.proponent.agent_id, MessageRole.ASSERTION, opening)

            # Phase 2: cross-examination.
            round_obj.phase = RoundPhase.CROSS_EXAMINATION
            for followup in range(self.config.max_followups):
                question = self._run_with_timeout(self.challenger.ask_question, round_obj.id, {})
                if not question.ok:
                    self._record_event(uow, session_id, VerificationEventType.ALIGNMENT_CHECK_FAILED, {"error": question.error})
                    break
                self._persist_message(uow, round_obj.id, self.challenger.agent_id, MessageRole.QUESTION, question)
                answer = self._run_with_timeout(self.proponent.respond_to_challenge, round_obj.id, {})
                self._persist_message(uow, round_obj.id, self.proponent.agent_id, MessageRole.ANSWER, answer)

            # Phase 3: critic reviews.
            reviews = []
            for critic in self.critics:
                review = critic.review(opening.content, {"round": round_obj.id})
                reviews.append(review)
                uow.critic_reviews.create(
                    round_id=round_obj.id,
                    critic_id=getattr(critic, "agent_id", self.proponent.agent_id),
                    review_type=critic.review_type,
                    score=review.score,
                    confidence=review.confidence,
                    rationale=review.rationale,
                    detected_issues=review.detected_issues,
                    recommended_action=review.recommended_action,
                )

            disagreement = self._critic_disagreement(reviews)
            if disagreement > self.config.escalation_critic_disagreement:
                self._record_event(
                    uow,
                    session_id,
                    VerificationEventType.DECEPTION_PROBE_TRIGGERED,
                    {"reason": "critic_disagreement", "disagreement": disagreement},
                )

            # Phase 4: rebuttal.
            round_obj.phase = RoundPhase.REBUTTAL
            rebuttal = self._run_with_timeout(self.challenger.critique, round_obj.id, {})
            self._persist_message(uow, round_obj.id, self.challenger.agent_id, MessageRole.CHALLENGE, rebuttal)

            # Phase 5: closing.
            round_obj.phase = RoundPhase.CLOSING
            closing = self._run_with_timeout(self.proponent.respond_to_challenge, round_obj.id, {})
            self._persist_message(uow, round_obj.id, self.proponent.agent_id, MessageRole.CONCESSION, closing)

            round_obj.state = "completed"
            uow.commit()
            return round_obj

    def should_continue(self, session_id: uuid.UUID) -> bool:
        with self.uow_factory() as uow:
            session = uow.sessions.get(session_id)
            rounds = uow.sessions.session.query(type(session).rounds.property.mapper.class_).filter_by(
                session_id=session_id
            ).all()
            return len(rounds) < self.config.max_rounds and session.status == SessionStatus.RUNNING

    def finalize(self, session_id: uuid.UUID):
        with self.uow_factory() as uow:
            session = uow.sessions.get(session_id)
            transcript = self._load_transcript(uow, session_id)
            verdict_data = self.judge.evaluate(session_id, {"transcript": transcript})
            verdict = uow.verdicts.create(
                session_id=session_id,
                judge_id=getattr(self.judge, "agent_id", self.proponent.agent_id),
                verdict_type=verdict_data["verdict_type"],
                score_breakdown=verdict_data["score_breakdown"],
                rationale=verdict_data["rationale"],
                confidence=verdict_data["confidence"],
                bias_mitigation_notes="blind_judging=%s, randomize_order=%s" % (
                    self.config.blind_judging,
                    self.config.randomize_order,
                ),
            )
            session.status = SessionStatus.COMPLETED
            uow.verification_events.create(
                session_id=session_id,
                event_type=VerificationEventType.JUDGE_VERDICT_ISSUED,
                target_type="JudgeVerdict",
                target_id=str(verdict.id),
                after_state=verdict_data,
            )
            uow.commit()
            return verdict

    def _persist_message(self, uow: UnitOfWork, round_id, sender_id, role, result: TurnResult) -> None:
        content = result.content if result.ok else f"[FAILED: {result.error}]"
        uow.sessions.session.add(
            type(uow.sessions.session.query(type(uow.sessions.get).__class__).first())  # placeholder
        )
        # Real implementation would use Message repository/helper.
        from debate_schema import Message
        uow.sessions.session.add(
            Message(
                round_id=round_id,
                sender_id=sender_id,
                role=role,
                content=content,
                sequence=0,
            )
        )

    def _record_event(self, uow: UnitOfWork, session_id, event_type, payload) -> None:
        uow.verification_events.create(
            session_id=session_id,
            event_type=event_type,
            target_type="DebateSession",
            target_id=str(session_id),
            after_state=payload,
        )

    def _critic_disagreement(self, reviews: list[Any]) -> float:
        if len(reviews) < 2:
            return 0.0
        scores = [r.score for r in reviews]
        mean = sum(scores) / len(scores)
        variance = sum((s - mean) ** 2 for s in scores) / len(scores)
        return variance ** 0.5

    def _load_transcript(self, uow: UnitOfWork, session_id: uuid.UUID) -> list[dict[str, Any]]:
        # Simplified query; production code should use repositories.
        return []


# ----------------------------- Metrics -----------------------------
def debate_metrics(uow: UnitOfWork, session_id: uuid.UUID) -> dict[str, float]:
    # These queries are illustrative; production code should use repositories.
    return {
        "average_round_length": 0.0,
        "number_of_challenges": 0.0,
        "number_of_concessions": 0.0,
        "critic_agreement_rate": 0.0,
        "judge_confidence": 0.0,
        "escalation_rate": 0.0,
    }


# ----------------------------- CLI -----------------------------
def run_from_yaml(path: str) -> None:
    import yaml
    from debate_schema import Agent, AgentRole, DebateSession, SessionStatus, make_session_factory

    with open(path, "r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle)

    factory = make_session_factory(raw.get("database_url"))
    with UnitOfWork(factory) as uow:
        proponent_agent = uow.sessions.create(name="Proponent", role=AgentRole.PROPONENT)
        challenger_agent = uow.sessions.create(name="Challenger", role=AgentRole.CHALLENGER)
        judge_agent = uow.sessions.create(name="Judge", role=AgentRole.JUDGE)
        session = uow.sessions.create(
            topic=raw["topic"],
            status=SessionStatus.RUNNING,
            created_by_id=proponent_agent.id,
            max_rounds=raw.get("max_rounds", 3),
        )
        session_id = session.id
        proponent_id = proponent_agent.id
        challenger_id = challenger_agent.id
        judge_id = judge_agent.id

    config = DebateConfig(
        topic=raw["topic"],
        max_rounds=raw.get("max_rounds", 3),
        turn_timeout_seconds=raw.get("timeout_seconds", 5.0),
        blind_judging=raw.get("blind_judging", True),
        randomize_order=raw.get("randomize_order", True),
        multi_judge=raw.get("multi_judge", False),
    )
    protocol = CrossExaminationProtocol(
        factory,
        config,
        MockProponentAgent(proponent_id),
        MockChallengerAgent(challenger_id),
        MockClarifierAgent(proponent_id),
        MockJudgeAgent(judge_id),
        [LogicCritic(judge_id), EvidenceCritic(judge_id), BiasCritic(judge_id), DeceptionCritic(judge_id)],
    )
    for round_index in range(config.max_rounds):
        if not protocol.should_continue(session_id):
            break
        protocol.run_round(session_id, round_index)
    verdict = protocol.finalize(session_id)
    print(f"Verdict: {verdict.verdict_type} confidence={verdict.confidence:.2f}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# inspector/console.py
from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from typing import Any

from debate_schema import (
    AgentRole, ClaimStatus, MessageRole, SessionStatus, UnitOfWork,
    VerificationEventType,
)


@dataclass
class CounterfactualState:
    """In-memory overlay for what-if analysis. Never persisted unless committed."""
    critic_scores: dict[str, float] = field(default_factory=dict)
    evidence_credibility: dict[str, float] = field(default_factory=dict)
    verdict_override: dict[str, Any] | None = None

    def apply_critic_score(self, critic_id: str, score: float) -> None:
        self.critic_scores[critic_id] = score

    def apply_evidence_credibility(self, evidence_id: str, credibility: float) -> None:
        self.evidence_credibility[evidence_id] = credibility


class CounterfactualEngine:
    def __init__(self, uow_factory, session_id: uuid.UUID):
        self.uow_factory = uow_factory
        self.session_id = session_id
        self.state = CounterfactualState()

    def set_critic_score(self, critic_id: str, score: float) -> dict[str, Any]:
        self.state.apply_critic_score(critic_id, score)
        return self._recompute_verdict()

    def set_evidence_credibility(self, evidence_id: str, credibility: float) -> dict[str, Any]:
        self.state.apply_evidence_credibility(evidence_id, credibility)
        return self._recompute_verdict()

    def _recompute_verdict(self) -> dict[str, Any]:
        with self.uow_factory() as uow:
            session = uow.sessions.get(self.session_id)
            verdicts = uow.verdicts.list(session_id=self.session_id)
            current = verdicts[-1] if verdicts else None
            if current is None:
                return {"changed": False, "reason": "no_verdict"}
            baseline = {
                "verdict_type": current.verdict_type.value,
                "confidence": current.confidence,
                "score_breakdown": current.score_breakdown,
            }
            adjusted = dict(baseline)
            # Simple counterfactual: if evidence credibility changes, shift confidence.
            if self.state.evidence_credibility:
                avg_delta = sum(self.state.evidence_credibility.values()) / len(self.state.evidence_credibility)
                adjusted["confidence"] = max(0.0, min(1.0, baseline["confidence"] + (avg_delta - 0.5) * 0.2))
            if self.state.critic_scores:
                avg_critic = sum(self.state.critic_scores.values()) / len(self.state.critic_scores)
                adjusted["confidence"] = max(0.0, min(1.0, adjusted["confidence"] + (avg_critic - 0.5) * 0.3))
            return {"baseline": baseline, "counterfactual": adjusted, "changed": baseline != adjusted}

    def commit(self, uow_factory, actor_id: uuid.UUID) -> None:
        with uow_factory() as uow:
            current = self._recompute_verdict()
            uow.verification_events.create(
                session_id=self.session_id,
                event_type=VerificationEventType.HUMAN_OVERRIDE,
                actor_id=actor_id,
                target_type="CounterfactualCommit",
                target_id=str(self.session_id),
                before_state=current["baseline"],
                after_state=current["counterfactual"],
            )
            uow.commit()


class DebateInspectorConsole:
    def __init__(self, uow_factory, session_id: uuid.UUID | None = None, human_agent_id: uuid.UUID | None = None):
        self.uow_factory = uow_factory
        self.session_id = session_id
        self.human_agent_id = human_agent_id
        self.counterfactual: CounterfactualEngine | None = None

    def run(self) -> None:
        print("Debate Inspector. Type /help for commands.")
        while True:
            try:
                raw = input("debate> ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if not raw:
                continue
            if raw.startswith("/"):
                if self.dispatch(raw):
                    break
            else:
                print("Unknown input. Use /help.")

    def dispatch(self, raw: str) -> bool:
        parts = raw.split()
        command = parts[0]
        args = parts[1:]
        try:
            if command == "/quit":
                return True
            if command == "/help":
                self.cmd_help()
            elif command == "/new":
                self.cmd_new(args)
            elif command == "/claim":
                self.cmd_claim(args)
            elif command == "/evidence":
                self.cmd_evidence(args)
            elif command == "/agent":
                self.cmd_agent(args)
            elif command == "/round":
                self.cmd_round(args)
            elif command == "/step":
                self.cmd_step(args)
            elif command == "/challenge":
                self.cmd_challenge(args)
            elif command == "/critique":
                self.cmd_critique(args)
            elif command == "/verdict":
                self.cmd_verdict(args)
            elif command == "/override":
                self.cmd_override(args)
            elif command == "/graph":
                self.cmd_graph(args)
            elif command == "/export":
                self.cmd_export(args)
            elif command == "/what-if":
                self.cmd_what_if(args)
            elif command == "/commit-what-if":
                self.cmd_commit_what_if(args)
            else:
                print(f"Unknown command: {command}")
        except Exception as exc:
            print(f"Error: {exc}")
        return False

    def cmd_help(self) -> None:
        print("""
/new <topic> [max_rounds]       create a session
/claim <text>                   add a claim
/evidence <claim_id> <source> <content> <stance>
/agent <role> <message>         inject a human message
/round                          run one round
/step                           run one turn
/challenge <claim_id> <question>
/critique <claim_id>
/verdict                        ask judge for verdict
/override <target_type> <target_id> <new_value> <rationale>
/graph                          show claim graph
/export <file.json>
/what-if critic <id> score <value>
/what-if evidence <id> credibility <value>
/commit-what-if
/quit
""")

    def cmd_new(self, args: list[str]) -> None:
        if not args:
            raise ValueError("usage: /new <topic> [max_rounds]")
        topic = args[0]
        max_rounds = int(args[1]) if len(args) > 1 else 3
        with self.uow_factory() as uow:
            human = uow.sessions.create(name=f"Human {uuid.uuid4().hex[:6]}", role=AgentRole.HUMAN_OVERSEER)
            session = uow.sessions.create(
                topic=topic,
                status=SessionStatus.CREATED,
                created_by_id=human.id,
                max_rounds=max_rounds,
            )
            self.session_id = session.id
            self.human_agent_id = human.id
            self.counterfactual = CounterfactualEngine(self.uow_factory, session.id)
            uow.commit()
        print(f"Created session {self.session_id}")

    def cmd_claim(self, args: list[str]) -> None:
        if self.session_id is None:
            raise ValueError("No session. Use /new first.")
        text = " ".join(args)
        with self.uow_factory() as uow:
            claim = uow.claims.create(
                session_id=self.session_id,
                original_text=text,
                normalized_text=text.lower(),
                claim_type="meta",
                status=ClaimStatus.PROPOSED,
                confidence=0.5,
                creator_id=self.human_agent_id,
            )
            uow.verification_events.create(
                session_id=self.session_id,
                event_type=VerificationEventType.CLAIM_CREATED,
                actor_id=self.human_agent_id,
                target_type="Claim",
                target_id=str(claim.id),
                after_state={"text": text, "confidence": 0.5},
            )
            uow.commit()
        print(f"Claim {claim.id}: {text} confidence=0.50 status=proposed")

    def cmd_evidence(self, args: list[str]) -> None:
        if len(args) < 4:
            raise ValueError("usage: /evidence <claim_id> <source> <content> <stance>")
        claim_id = uuid.UUID(args[0])
        source, content, stance = args[1], args[2], args[3]
        with self.uow_factory() as uow:
            ev = uow.evidence.create(
                session_id=self.session_id,
                source_type="document",
                source_uri=source,
                content=content,
                content_hash=str(hash(content)),
                credibility_score=0.7,
            )
            uow.evidence_citations.create(
                evidence_id=ev.id,
                claim_id=claim_id,
                stance=stance,
                excerpt=content[:200],
                relevance_score=0.7,
                citation_strength=0.7,
            )
            uow.verification_events.create(
                session_id=self.session_id,
                event_type=VerificationEventType.EVIDENCE_ADDED,
                actor_id=self.human_agent_id,
                target_type="Evidence",
                target_id=str(ev.id),
                after_state={"claim_id": str(claim_id), "stance": stance},
            )
            uow.commit()
        print(f"Evidence {ev.id} added to claim {claim_id} stance={stance}")

    def cmd_agent(self, args: list[str]) -> None:
        if len(args) < 2:
            raise ValueError("usage: /agent <role> <message>")
        role, message = args[0], " ".join(args[1:])
        with self.uow_factory() as uow:
            # Simplified: attach to latest round or create one.
            session = uow.sessions.get(self.session_id)
            rounds = uow.sessions.session.query(type(session).rounds.property.mapper.class_).filter_by(
                session_id=self.session_id
            ).all()
            round_id = rounds[-1].id if rounds else None
            if round_id is None:
                from debate_schema import Round
                round_obj = Round(session_id=self.session_id, index=0, phase="opening", state="running")
                uow.session.add(round_obj)
                uow.flush()
                round_id = round_obj.id
            from debate_schema import Message
            msg = Message(
                round_id=round_id,
                sender_id=self.human_agent_id,
                role=MessageRole.ASSERTION,
                content=f"[{role}] {message}",
                sequence=0,
            )
            uow.session.add(msg)
            uow.commit()
        print(f"Injected message as {role}")

    def cmd_round(self, args: list[str]) -> None:
        print("Running one round via orchestrator stub. In production, call CrossExaminationProtocol.run_round.")

    def cmd_step(self, args: list[str]) -> None:
        print("Running one turn via orchestrator stub.")

    def cmd_challenge(self, args: list[str]) -> None:
        if len(args) < 2:
            raise ValueError("usage: /challenge <claim_id> <question>")
        print(f"Challenge routed for claim {args[0]}: {' '.join(args[1:])}")

    def cmd_critique(self, args: list[str]) -> None:
        if not args:
            raise ValueError("usage: /critique <claim_id>")
        print(f"Critic review requested for claim {args[0]}")

    def cmd_verdict(self, args: list[str]) -> None:
        print("Judge verdict requested.")

    def cmd_override(self, args: list[str]) -> None:
        if len(args) < 4:
            raise ValueError("usage: /override <target_type> <target_id> <new_value> <rationale>")
        target_type, target_id, new_value, rationale = args[0], args[1], args[2], " ".join(args[3:])
        with self.uow_factory() as uow:
            uow.verification_events.create(
                session_id=self.session_id,
                event_type=VerificationEventType.HUMAN_OVERRIDE,
                actor_id=self.human_agent_id,
                target_type=target_type,
                target_id=target_id,
                before_state={"original": "see ledger"},
                after_state={"new_value": new_value, "rationale": rationale},
            )
            uow.commit()
        print(f"Override recorded for {target_type} {target_id}")

    def cmd_graph(self, args: list[str]) -> None:
        if self.session_id is None:
            print("No session.")
            return
        with self.uow_factory() as uow:
            claims = uow.claims.list(session_id=self.session_id)
        print("Claim graph:")
        for claim in claims:
            parent = str(claim.parent_id) if claim.parent_id else "root"
            print(f"  {claim.id} ({claim.status.value}, conf={claim.confidence:.2f}) parent={parent}: {claim.original_text[:60]}")

    def cmd_export(self, args: list[str]) -> None:
        if not args:
            raise ValueError("usage: /export <file.json>")
        path = args[0]
        with self.uow_factory() as uow:
            claims = uow.claims.list(session_id=self.session_id)
            events = uow.verification_events.list(session_id=self.session_id)
            payload = {
                "session_id": str(self.session_id),
                "claims": [{"id": str(c.id), "text": c.original_text, "confidence": c.confidence} for c in claims],
                "events": [{"id": str(e.id), "type": e.event_type.value, "target": e.target_id} for e in events],
            }
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2)
        print(f"Exported to {path}")

    def cmd_what_if(self, args: list[str]) -> None:
        if len(args) < 4:
            raise ValueError("usage: /what-if critic <id> score <value> | /what-if evidence <id> credibility <value>")
        kind, entity_id, field_name, value = args[0], args[1], args[2], float(args[3])
        if self.counterfactual is None:
            raise ValueError("No session.")
        if kind == "critic" and field_name == "score":
            result = self.counterfactual.set_critic_score(entity_id, value)
        elif kind == "evidence" and field_name == "credibility":
            result = self.counterfactual.set_evidence_credibility(entity_id, value)
        else:
            raise ValueError("Unsupported what-if.")
        print(json.dumps(result, indent=2))

    def cmd_commit_what_if(self, args: list[str]) -> None:
        if self.counterfactual is None:
            raise ValueError("No session.")
        self.counterfactual.commit(self.uow_factory, self.human_agent_id)
        print("Counterfactual committed as verification event.")


# ----------------------------- Scripted test example -----------------------------
def test_console_scripted(tmp_path):
    from debate_schema import make_session_factory
    factory = make_session_factory("sqlite+pysqlite:///:memory:")
    console = DebateInspectorConsole(factory)
    console.cmd_new(["Is AI safe?"])
    console.cmd_claim(["AI", "is", "safe"])
    console.cmd_evidence([str(console.session_id), "mock://report", "Evaluation coverage is broad.", "supports"])
    console.cmd_override(["JudgeVerdict", "verdict-1", "human_review", "Insufficient deployment evidence"])
    export_path = tmp_path / "export.json"
    console.cmd_export([str(export_path)])
    assert export_path.exists()

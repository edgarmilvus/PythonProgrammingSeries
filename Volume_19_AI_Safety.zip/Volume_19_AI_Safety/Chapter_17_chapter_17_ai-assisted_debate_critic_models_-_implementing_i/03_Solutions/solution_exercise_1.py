
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# debate_schema.py
from __future__ import annotations

import abc
import enum
import os
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Generic, Sequence, TypeVar

from sqlalchemy import (
    Boolean, CheckConstraint, DateTime, Float, ForeignKey, Index, JSON,
    String, Text, UniqueConstraint, Uuid, create_engine, select,
)
from sqlalchemy import Enum as SAEnum
from sqlalchemy.orm import (
    DeclarativeBase, Mapped, Session, mapped_column, relationship, sessionmaker,
)
from sqlalchemy.pool import StaticPool

Base = DeclarativeBase()


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


# ----------------------------- Enums -----------------------------
class AgentRole(str, enum.Enum):
    PROPONENT = "proponent"
    CHALLENGER = "challenger"
    CRITIC = "critic"
    JUDGE = "judge"
    META_JUDGE = "meta_judge"
    HUMAN_OVERSEER = "human_overseer"
    EVIDENCE_RETRIEVER = "evidence_retriever"


class SessionStatus(str, enum.Enum):
    CREATED = "created"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    ABORTED = "aborted"


class RoundPhase(str, enum.Enum):
    OPENING = "opening"
    CROSS_EXAMINATION = "cross_examination"
    REBUTTAL = "rebuttal"
    CLOSING = "closing"
    VERDICT = "verdict"


class MessageRole(str, enum.Enum):
    ASSERTION = "assertion"
    QUESTION = "question"
    ANSWER = "answer"
    CHALLENGE = "challenge"
    CONCESSION = "concession"
    CLARIFICATION = "clarification"
    CRITIQUE = "critique"
    VERDICT = "verdict"
    SYSTEM_EVENT = "system_event"


class ClaimType(str, enum.Enum):
    FACTUAL = "factual"
    CAUSAL = "causal"
    NORMATIVE = "normative"
    PREDICTIVE = "predictive"
    DEFINITIONAL = "definitional"
    STATISTICAL = "statistical"
    META = "meta"


class ClaimStatus(str, enum.Enum):
    PROPOSED = "proposed"
    UNDER_REVIEW = "under_review"
    SUPPORTED = "supported"
    ATTACKED = "attacked"
    UNDERCUT = "undercut"
    CONTRADICTED = "contradicted"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    UNRESOLVED = "unresolved"


class RelationType(str, enum.Enum):
    SUPPORTS = "supports"
    ATTACKS = "attacks"
    UNDERCUTS = "undercuts"
    PRESUPPOSES = "presupposes"
    EQUIVALENT = "equivalent"
    CONTRADICTS = "contradicts"
    REFINES = "refines"
    GENERALIZES = "generalizes"


class EvidenceSourceType(str, enum.Enum):
    DOCUMENT = "document"
    WEB_PAGE = "web_page"
    DATABASE_ROW = "database_row"
    API_RESPONSE = "api_response"
    HUMAN_TESTIMONY = "human_testimony"
    MODEL_OUTPUT = "model_output"
    SYNTHETIC = "synthetic"


class CitationStance(str, enum.Enum):
    SUPPORTS = "supports"
    ATTACKS = "attacks"
    UNDERCUTS = "undercuts"
    CONTEXTUALIZES = "contextualizes"
    IRRELEVANT = "irrelevant"


class ReviewType(str, enum.Enum):
    LOGICAL_VALIDITY = "logical_validity"
    EVIDENCE_QUALITY = "evidence_quality"
    BIAS = "bias"
    DECEPTION = "deception"
    CLARITY = "clarity"
    COMPLETENESS = "completeness"
    ALIGNMENT = "alignment"


class VerdictType(str, enum.Enum):
    PROPONENT_WINS = "proponent_wins"
    CHALLENGER_WINS = "challenger_wins"
    DRAW = "draw"
    INCONCLUSIVE = "inconclusive"
    NEEDS_MORE_EVIDENCE = "needs_more_evidence"
    HUMAN_REVIEW = "human_review"


class VerificationEventType(str, enum.Enum):
    CLAIM_CREATED = "claim_created"
    CLAIM_UPDATED = "claim_updated"
    RELATION_CREATED = "relation_created"
    EVIDENCE_ADDED = "evidence_added"
    CRITIC_REVIEW_SUBMITTED = "critic_review_submitted"
    JUDGE_VERDICT_ISSUED = "judge_verdict_issued"
    HUMAN_OVERRIDE = "human_override"
    REFINEMENT_APPLIED = "refinement_applied"
    DECEPTION_PROBE_TRIGGERED = "deception_probe_triggered"
    ALIGNMENT_CHECK_FAILED = "alignment_check_failed"


# ----------------------------- Models -----------------------------
class Agent(Base):
    __tablename__ = "agents"

    id: Mapped[uuid.UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(200), unique=True, index=True)
    role: Mapped[AgentRole] = mapped_column(SAEnum(AgentRole, native_enum=False, length=32), index=True)
    model_identifier: Mapped[str | None] = mapped_column(String(200))
    version: Mapped[str | None] = mapped_column(String(50))
    capabilities: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    trust_level: Mapped[float] = mapped_column(Float, default=0.5)
    calibration_history: Mapped[list[dict[str, Any]]] = mapped_column(JSON, default=list)
    meta: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)

    __table_args__ = (
        CheckConstraint("trust_level >= 0 AND trust_level <= 1", name="ck_agent_trust"),
    )

    messages_sent = relationship("Message", foreign_keys="Message.sender_id", back_populates="sender")
    messages_received = relationship("Message", foreign_keys="Message.recipient_id", back_populates="recipient")
    reviews = relationship("CriticReview", back_populates="critic")
    verdicts = relationship("JudgeVerdict", back_populates="judge")
    verification_events = relationship("VerificationEvent", back_populates="actor")
    audit_logs = relationship("AuditLog", back_populates="actor")


class DebateSession(Base):
    __tablename__ = "debate_sessions"

    id: Mapped[uuid.UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    topic: Mapped[str] = mapped_column(Text)
    status: Mapped[SessionStatus] = mapped_column(
        SAEnum(SessionStatus, native_enum=False, length=32),
        default=SessionStatus.CREATED,
        index=True,
    )
    configuration: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    max_rounds: Mapped[int] = mapped_column(default=10)
    created_by_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("agents.id"), index=True)
    final_verdict_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("judge_verdicts.id", use_alter=True, name="fk_session_final_verdict"),
        nullable=True,
    )
    start_time: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    end_time: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    meta: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)

    created_by = relationship("Agent", foreign_keys=[created_by_id])
    rounds = relationship("Round", back_populates="session", cascade="all, delete-orphan")
    claims = relationship("Claim", back_populates="session", cascade="all, delete-orphan")
    evidence = relationship("Evidence", back_populates="session", cascade="all, delete-orphan")
    verdicts = relationship(
        "JudgeVerdict",
        back_populates="session",
        foreign_keys="JudgeVerdict.session_id",
        cascade="all, delete-orphan",
    )
    verification_events = relationship("VerificationEvent", back_populates="session", cascade="all, delete-orphan")


class Round(Base):
    __tablename__ = "rounds"

    id: Mapped[uuid.UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("debate_sessions.id"), index=True)
    index: Mapped[int] = mapped_column(index=True)
    phase: Mapped[RoundPhase] = mapped_column(SAEnum(RoundPhase, native_enum=False, length=32), index=True)
    state: Mapped[str] = mapped_column(String(50), default="pending")
    start_time: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    end_time: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    summary: Mapped[str | None] = mapped_column(Text)

    session = relationship("DebateSession", back_populates="rounds")
    messages = relationship("Message", back_populates="round", cascade="all, delete-orphan")
    critic_reviews = relationship("CriticReview", back_populates="round", cascade="all, delete-orphan")

    __table_args__ = (UniqueConstraint("session_id", "index", name="uq_round_session_index"),)


class Message(Base):
    __tablename__ = "messages"

    id: Mapped[uuid.UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    round_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("rounds.id"), index=True)
    sender_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("agents.id"), index=True)
    recipient_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("agents.id"), nullable=True, index=True)
    role: Mapped[MessageRole] = mapped_column(SAEnum(MessageRole, native_enum=False, length=32), index=True)
    content: Mapped[str] = mapped_column(Text)
    parent_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("messages.id"), nullable=True, index=True)
    sequence: Mapped[int] = mapped_column(index=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    meta: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)

    round = relationship("Round", back_populates="messages")
    sender = relationship("Agent", foreign_keys=[sender_id], back_populates="messages_sent")
    recipient = relationship("Agent", foreign_keys=[recipient_id], back_populates="messages_received")
    parent = relationship("Message", remote_side="Message.id", back_populates="children")
    children = relationship("Message", back_populates="parent", cascade="all, delete-orphan")


class Claim(Base):
    __tablename__ = "claims"

    id: Mapped[uuid.UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("debate_sessions.id"), index=True)
    round_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("rounds.id"), nullable=True, index=True)
    parent_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("claims.id"), nullable=True, index=True)
    original_text: Mapped[str] = mapped_column(Text)
    normalized_text: Mapped[str] = mapped_column(Text)
    claim_type: Mapped[ClaimType] = mapped_column(SAEnum(ClaimType, native_enum=False, length=32), index=True)
    status: Mapped[ClaimStatus] = mapped_column(
        SAEnum(ClaimStatus, native_enum=False, length=32),
        default=ClaimStatus.PROPOSED,
        index=True,
    )
    confidence: Mapped[float] = mapped_column(Float, default=0.5)
    creator_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("agents.id"), index=True)
    source_message_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("messages.id"), nullable=True)
    meta: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)

    __table_args__ = (
        CheckConstraint("confidence >= 0 AND confidence <= 1", name="ck_claim_confidence"),
        Index("ix_claim_session_status", "session_id", "status"),
    )

    session = relationship("DebateSession", back_populates="claims")
    round = relationship("Round")
    parent = relationship("Claim", remote_side="Claim.id", back_populates="children")
    children = relationship("Claim", back_populates="parent", cascade="all, delete-orphan")
    creator = relationship("Agent")
    source_message = relationship("Message")
    relations_from = relationship(
        "ClaimRelation",
        foreign_keys="ClaimRelation.from_claim_id",
        back_populates="from_claim",
        cascade="all, delete-orphan",
    )
    relations_to = relationship(
        "ClaimRelation",
        foreign_keys="ClaimRelation.to_claim_id",
        back_populates="to_claim",
        cascade="all, delete-orphan",
    )
    citations = relationship("EvidenceCitation", back_populates="claim", cascade="all, delete-orphan")
    critic_reviews = relationship("CriticReview", back_populates="target_claim")


class ClaimRelation(Base):
    __tablename__ = "claim_relations"

    id: Mapped[uuid.UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    from_claim_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("claims.id"), index=True)
    to_claim_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("claims.id"), index=True)
    relation_type: Mapped[RelationType] = mapped_column(SAEnum(RelationType, native_enum=False, length=32), index=True)
    strength: Mapped[float] = mapped_column(Float, default=0.5)

    from_claim = relationship("Claim", foreign_keys=[from_claim_id], back_populates="relations_from")
    to_claim = relationship("Claim", foreign_keys=[to_claim_id], back_populates="relations_to")

    __table_args__ = (
        UniqueConstraint("from_claim_id", "to_claim_id", "relation_type", name="uq_claim_relation"),
        CheckConstraint("strength >= 0 AND strength <= 1", name="ck_relation_strength"),
        CheckConstraint("from_claim_id != to_claim_id", name="ck_no_self_relation"),
    )


class Evidence(Base):
    __tablename__ = "evidence"

    id: Mapped[uuid.UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("debate_sessions.id"), index=True)
    round_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("rounds.id"), nullable=True, index=True)
    source_type: Mapped[EvidenceSourceType] = mapped_column(SAEnum(EvidenceSourceType, native_enum=False, length=32))
    source_uri: Mapped[str] = mapped_column(String(1000))
    content: Mapped[str] = mapped_column(Text)
    content_hash: Mapped[str] = mapped_column(String(128), index=True)
    retrieval_time: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    credibility_score: Mapped[float] = mapped_column(Float, default=0.5)
    reliability_notes: Mapped[str | None] = mapped_column(Text)
    meta: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)

    __table_args__ = (CheckConstraint("credibility_score >= 0 AND credibility_score <= 1", name="ck_evidence_cred"),)

    session = relationship("DebateSession", back_populates="evidence")
    round = relationship("Round")
    citations = relationship("EvidenceCitation", back_populates="evidence", cascade="all, delete-orphan")


class EvidenceCitation(Base):
    __tablename__ = "evidence_citations"

    id: Mapped[uuid.UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    evidence_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("evidence.id"), index=True)
    claim_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("claims.id"), index=True)
    stance: Mapped[CitationStance] = mapped_column(SAEnum(CitationStance, native_enum=False, length=32), index=True)
    excerpt: Mapped[str] = mapped_column(Text)
    relevance_score: Mapped[float] = mapped_column(Float, default=0.5)
    citation_strength: Mapped[float] = mapped_column(Float, default=0.5)
    meta: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)

    __table_args__ = (
        CheckConstraint("relevance_score >= 0 AND relevance_score <= 1", name="ck_citation_relevance"),
        CheckConstraint("citation_strength >= 0 AND citation_strength <= 1", name="ck_citation_strength"),
    )

    evidence = relationship("Evidence", back_populates="citations")
    claim = relationship("Claim", back_populates="citations")


class CriticReview(Base):
    __tablename__ = "critic_reviews"

    id: Mapped[uuid.UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    round_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("rounds.id"), index=True)
    critic_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("agents.id"), index=True)
    target_message_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("messages.id"), nullable=True, index=True)
    target_claim_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("claims.id"), nullable=True, index=True)
    review_type: Mapped[ReviewType] = mapped_column(SAEnum(ReviewType, native_enum=False, length=32), index=True)
    score: Mapped[float] = mapped_column(Float)
    confidence: Mapped[float] = mapped_column(Float)
    rationale: Mapped[str] = mapped_column(Text)
    detected_issues: Mapped[list[str]] = mapped_column(JSON, default=list)
    recommended_action: Mapped[str | None] = mapped_column(String(200))
    meta: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)

    __table_args__ = (
        CheckConstraint("score >= 0 AND score <= 1", name="ck_critic_score"),
        CheckConstraint("confidence >= 0 AND confidence <= 1", name="ck_critic_conf"),
    )

    round = relationship("Round", back_populates="critic_reviews")
    critic = relationship("Agent", back_populates="reviews")
    target_message = relationship("Message")
    target_claim = relationship("Claim", back_populates="critic_reviews")


class JudgeVerdict(Base):
    __tablename__ = "judge_verdicts"

    id: Mapped[uuid.UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("debate_sessions.id"), index=True)
    round_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("rounds.id"), nullable=True, index=True)
    judge_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("agents.id"), index=True)
    verdict_type: Mapped[VerdictType] = mapped_column(SAEnum(VerdictType, native_enum=False, length=32), index=True)
    winning_side: Mapped[str | None] = mapped_column(String(50))
    score_breakdown: Mapped[dict[str, float]] = mapped_column(JSON, default=dict)
    rationale: Mapped[str] = mapped_column(Text)
    confidence: Mapped[float] = mapped_column(Float)
    bias_mitigation_notes: Mapped[str | None] = mapped_column(Text)
    meta: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)

    __table_args__ = (CheckConstraint("confidence >= 0 AND confidence <= 1", name="ck_verdict_conf"),)

    session = relationship("DebateSession", back_populates="verdicts", foreign_keys=[session_id])
    round = relationship("Round")
    judge = relationship("Agent", back_populates="verdicts")


class VerificationEvent(Base):
    __tablename__ = "verification_events"

    id: Mapped[uuid.UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("debate_sessions.id"), index=True)
    event_type: Mapped[VerificationEventType] = mapped_column(
        SAEnum(VerificationEventType, native_enum=False, length=48),
        index=True,
    )
    actor_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("agents.id"), nullable=True, index=True)
    target_type: Mapped[str] = mapped_column(String(100), index=True)
    target_id: Mapped[str] = mapped_column(String(100), index=True)
    before_state: Mapped[dict[str, Any] | None] = mapped_column(JSON)
    after_state: Mapped[dict[str, Any] | None] = mapped_column(JSON)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    meta: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)

    session = relationship("DebateSession", back_populates="verification_events")
    actor = relationship("Agent", back_populates="verification_events")


class CalibrationRecord(Base):
    __tablename__ = "calibration_records"

    id: Mapped[uuid.UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    agent_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("agents.id"), index=True)
    task_type: Mapped[str] = mapped_column(String(100), index=True)
    predicted_confidence: Mapped[float] = mapped_column(Float)
    observed_correctness: Mapped[float] = mapped_column(Float)
    error_metric: Mapped[float] = mapped_column(Float)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    meta: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)

    __table_args__ = (
        CheckConstraint("predicted_confidence >= 0 AND predicted_confidence <= 1", name="ck_cal_pred"),
        CheckConstraint("observed_correctness >= 0 AND observed_correctness <= 1", name="ck_cal_obs"),
    )

    agent = relationship("Agent")


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id: Mapped[uuid.UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    actor_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("agents.id"), nullable=True, index=True)
    action: Mapped[str] = mapped_column(String(200), index=True)
    entity_type: Mapped[str] = mapped_column(String(100), index=True)
    entity_id: Mapped[str] = mapped_column(String(100), index=True)
    details: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    meta: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)

    actor = relationship("Agent", back_populates="audit_logs")


# ----------------------------- Abstract interfaces -----------------------------
class DebateAgent(abc.ABC):
    @abc.abstractmethod
    def propose(self, session_id: uuid.UUID, round_id: uuid.UUID, context: dict[str, Any]) -> str:
        ...

    @abc.abstractmethod
    def critique(self, target_id: uuid.UUID, context: dict[str, Any]) -> str:
        ...

    @abc.abstractmethod
    def revise(self, claim_id: uuid.UUID, context: dict[str, Any]) -> str:
        ...

    @abc.abstractmethod
    def respond_to_challenge(self, challenge_id: uuid.UUID, context: dict[str, Any]) -> str:
        ...


class CriticModel(abc.ABC):
    @abc.abstractmethod
    def review(self, target: Any, context: dict[str, Any]) -> CriticReview:
        ...


class Judge(abc.ABC):
    @abc.abstractmethod
    def evaluate(self, session_id: uuid.UUID, context: dict[str, Any]) -> JudgeVerdict:
        ...


class DebateProtocol(abc.ABC):
    @abc.abstractmethod
    def run_round(self, session_id: uuid.UUID, round_index: int) -> Round:
        ...

    @abc.abstractmethod
    def should_continue(self, session_id: uuid.UUID) -> bool:
        ...

    @abc.abstractmethod
    def finalize(self, session_id: uuid.UUID) -> JudgeVerdict:
        ...


class EvidenceRetriever(abc.ABC):
    @abc.abstractmethod
    def retrieve(self, query: str, max_results: int = 5, filters: dict[str, Any] | None = None) -> list[Any]:
        ...


class ClaimDecomposer(abc.ABC):
    @abc.abstractmethod
    def decompose(self, claim: Claim) -> list[Claim]:
        ...


class RebuttalGenerator(abc.ABC):
    @abc.abstractmethod
    def generate_rebuttal(
        self,
        claim: Claim,
        supporting_evidence: list[Evidence],
        attacking_evidence: list[Evidence],
        critic_reviews: list[CriticReview],
    ) -> list[Any]:
        ...


# ----------------------------- Repositories -----------------------------
T = TypeVar("T", bound=Base)


class Repository(Generic[T]):
    def __init__(self, session: Session, model: type[T]):
        self.session = session
        self.model = model

    def create(self, **values: Any) -> T:
        obj = self.model(**values)
        self.session.add(obj)
        self.session.flush()
        return obj

    def get(self, entity_id: uuid.UUID) -> T | None:
        return self.session.get(self.model, entity_id)

    def list(self, **filters: Any) -> Sequence[T]:
        stmt = select(self.model)
        for key, value in filters.items():
            stmt = stmt.where(getattr(self.model, key) == value)
        return self.session.scalars(stmt).all()

    def update(self, entity_id: uuid.UUID, **values: Any) -> T | None:
        obj = self.get(entity_id)
        if obj is None:
            return None
        for key, value in values.items():
            setattr(obj, key, value)
        self.session.flush()
        return obj

    def delete(self, entity_id: uuid.UUID) -> bool:
        obj = self.get(entity_id)
        if obj is None:
            return False
        self.session.delete(obj)
        self.session.flush()
        return True


class SessionRepository(Repository[DebateSession]):
    def __init__(self, session: Session):
        super().__init__(session, DebateSession)


class ClaimRepository(Repository[Claim]):
    def __init__(self, session: Session):
        super().__init__(session, Claim)

    def descendants(self, claim_id: uuid.UUID) -> list[Claim]:
        """Return a claim and all descendant claims using a recursive CTE."""
        cte = select(Claim.id).where(Claim.id == claim_id).cte(recursive=True)
        children = select(Claim.id).join(cte, Claim.parent_id == cte.c.id)
        cte = cte.union_all(children)
        stmt = select(Claim).where(Claim.id.in_(select(cte.c.id)))
        return list(self.session.scalars(stmt).all())


class EvidenceRepository(Repository[Evidence]):
    def __init__(self, session: Session):
        super().__init__(session, Evidence)


class CriticReviewRepository(Repository[CriticReview]):
    def __init__(self, session: Session):
        super().__init__(session, CriticReview)


class JudgeVerdictRepository(Repository[JudgeVerdict]):
    def __init__(self, session: Session):
        super().__init__(session, JudgeVerdict)


class VerificationEventRepository(Repository[VerificationEvent]):
    def __init__(self, session: Session):
        super().__init__(session, VerificationEvent)


# ----------------------------- Unit of work -----------------------------
class UnitOfWork:
    def __init__(self, session_factory: sessionmaker):
        self.session_factory = session_factory
        self.session: Session | None = None

    def __enter__(self) -> "UnitOfWork":
        self.session = self.session_factory()
        self.sessions = SessionRepository(self.session)
        self.claims = ClaimRepository(self.session)
        self.evidence = EvidenceRepository(self.session)
        self.critic_reviews = CriticReviewRepository(self.session)
        self.verdicts = JudgeVerdictRepository(self.session)
        self.verification_events = VerificationEventRepository(self.session)
        return self

    def flush(self) -> None:
        assert self.session is not None
        self.session.flush()

    def commit(self) -> None:
        assert self.session is not None
        self.session.commit()

    def rollback(self) -> None:
        assert self.session is not None
        self.session.rollback()

    def __exit__(self, exc_type, exc, tb) -> None:
        assert self.session is not None
        if exc_type is not None:
            self.rollback()
        else:
            self.commit()
        self.session.close()


# ----------------------------- Engine/config -----------------------------
def make_engine(database_url: str | None = None):
    url = database_url or os.getenv("DATABASE_URL", "sqlite+pysqlite:///:memory:")
    connect_args = {"check_same_thread": False} if url.startswith("sqlite") else {}
    kwargs: dict[str, Any] = {"connect_args": connect_args, "future": True}
    if url.startswith("sqlite") and ":memory:" in url:
        kwargs["poolclass"] = StaticPool
    return create_engine(url, **kwargs)


def make_session_factory(database_url: str | None = None) -> sessionmaker:
    engine = make_engine(database_url)
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine, expire_on_commit=False, class_=Session)


# ----------------------------- Example tests -----------------------------
# test_schema.py
import pytest


@pytest.fixture
def session_factory():
    factory = make_session_factory("sqlite+pysqlite:///:memory:")
    return factory


def test_human_override_reconstructs_verdict(session_factory):
    with UnitOfWork(session_factory) as uow:
        judge = uow.sessions.create(
            name="Judge 1",
            role=AgentRole.JUDGE,
            model_identifier="mock",
            version="1",
        )
        human = uow.sessions.create(
            name="Human Overseer",
            role=AgentRole.HUMAN_OVERSEER,
            model_identifier="human",
            version="1",
        )
        session = uow.sessions.create(
            topic="Is model X safe?",
            status=SessionStatus.COMPLETED,
            created_by_id=judge.id,
        )
        verdict = uow.verdicts.create(
            session_id=session.id,
            judge_id=judge.id,
            verdict_type=VerdictType.PROPONENT_WINS,
            rationale="Initial verdict",
            confidence=0.8,
        )
        event = uow.verification_events.create(
            session_id=session.id,
            event_type=VerificationEventType.HUMAN_OVERRIDE,
            actor_id=human.id,
            target_type="JudgeVerdict",
            target_id=str(verdict.id),
            before_state={"verdict_type": "proponent_wins", "confidence": 0.8},
            after_state={"verdict_type": "human_review", "confidence": 0.4},
        )
        assert event.before_state["verdict_type"] == "proponent_wins"
        assert event.after_state["verdict_type"] == "human_review"


def test_claim_graph_traversal(session_factory):
    with UnitOfWork(session_factory) as uow:
        agent = uow.sessions.create(name="Proponent", role=AgentRole.PROPONENT)
        session = uow.sessions.create(topic="Graph test", status=SessionStatus.RUNNING, created_by_id=agent.id)
        root = uow.claims.create(
            session_id=session.id,
            original_text="Root",
            normalized_text="root",
            claim_type=ClaimType.META,
            creator_id=agent.id,
        )
        child1 = uow.claims.create(
            session_id=session.id,
            parent_id=root.id,
            original_text="Child support",
            normalized_text="child support",
            claim_type=ClaimType.FACTUAL,
            creator_id=agent.id,
        )
        child2 = uow.claims.create(
            session_id=session.id,
            parent_id=root.id,
            original_text="Child attack",
            normalized_text="child attack",
            claim_type=ClaimType.FACTUAL,
            creator_id=agent.id,
        )
        grandchild = uow.claims.create(
            session_id=session.id,
            parent_id=child1.id,
            original_text="Grandchild",
            normalized_text="grandchild",
            claim_type=ClaimType.STATISTICAL,
            creator_id=agent.id,
        )
        descendants = uow.claims.descendants(root.id)
        assert {c.id for c in descendants} == {root.id, child1.id, child2.id, grandchild.id}

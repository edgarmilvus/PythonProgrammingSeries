
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# verification/pipeline.py
from __future__ import annotations

import argparse
import json
import math
import uuid
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Iterable

from debate_schema import (
    Claim, ClaimDecomposer, ClaimRelation, ClaimStatus, ClaimType, CriticModel,
    Evidence, EvidenceCitation, EvidenceRetriever, EvidenceSourceType,
    Message, MessageRole, RelationType, RebuttalGenerator, UnitOfWork,
    VerificationEventType,
)


# ----------------------------- Data transfer objects -----------------------------
@dataclass
class AtomicClaim:
    text: str
    normalized_text: str
    claim_type: ClaimType
    confidence: float = 0.5


@dataclass
class RelationDraft:
    source_index: int  # -1 means the original root claim
    target_index: int
    relation_type: RelationType
    strength: float


@dataclass
class DecompositionResult:
    subclaims: list[AtomicClaim]
    relations: list[RelationDraft]


@dataclass
class EvidenceDraft:
    source_type: EvidenceSourceType
    source_uri: str
    content: str
    excerpt: str
    credibility_score: float
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class RebuttalDraft:
    rebuttal_type: str
    text: str
    rationale: str
    confidence: float


@dataclass
class PipelineBudget:
    max_depth: int = 3
    max_claims: int = 50
    max_evidence_retrievals: int = 30
    max_critic_calls: int = 50
    claims_created: int = 0
    evidence_retrievals: int = 0
    critic_calls: int = 0

    def exhausted(self) -> bool:
        return (
            self.claims_created >= self.max_claims
            or self.evidence_retrievals >= self.max_evidence_retrievals
            or self.critic_calls >= self.max_critic_calls
        )


# ----------------------------- Decomposers -----------------------------
class LogicalDecomposer(ClaimDecomposer):
    """Break a claim into premises and conclusion when cue words exist."""

    def decompose(self, claim: Claim) -> DecompositionResult:
        text = claim.original_text
        lower = text.lower()
        if "because" in lower and "therefore" in lower:
            premise, conclusion = lower.split("therefore", 1)
            premises = [p.strip() for p in premise.replace("because", "").split(" and ") if p.strip()]
            subclaims = [
                AtomicClaim(p, p, ClaimType.FACTUAL, 0.55) for p in premises
            ] + [AtomicClaim(conclusion.strip(), conclusion.strip(), claim.claim_type, 0.5)]
            relations = [
                RelationDraft(i, len(subclaims) - 1, RelationType.SUPPORTS, 0.8)
                for i in range(len(premises))
            ]
            return DecompositionResult(subclaims, relations)
        return DecompositionResult([], [])


class CausalDecomposer(ClaimDecomposer):
    """Identify cause, mechanism, effect, and confounders."""

    def decompose(self, claim: Claim) -> DecompositionResult:
        text = claim.original_text
        if not any(word in text.lower() for word in ["causes", "leads to", "results in", "due to"]):
            return DecompositionResult([], [])
        pieces = [
            AtomicClaim(f"Cause component: {text}", f"cause: {text}", ClaimType.CAUSAL, 0.5),
            AtomicClaim(f"Mechanism component: {text}", f"mechanism: {text}", ClaimType.CAUSAL, 0.5),
            AtomicClaim(f"Effect component: {text}", f"effect: {text}", ClaimType.CAUSAL, 0.5),
            AtomicClaim(f"Confounder component: {text}", f"confounder: {text}", ClaimType.CAUSAL, 0.5),
        ]
        relations = [
            RelationDraft(0, 2, RelationType.SUPPORTS, 0.7),
            RelationDraft(1, 2, RelationType.SUPPORTS, 0.7),
            RelationDraft(3, 2, RelationType.UNDERCUTS, 0.5),
        ]
        return DecompositionResult(pieces, relations)


class DefinitionalDecomposer(ClaimDecomposer):
    """Clarify terms and scope conditions."""

    def decompose(self, claim: Claim) -> DecompositionResult:
        text = claim.original_text
        terms = [w for w in text.split() if len(w) > 5]
        if not terms:
            return DecompositionResult([], [])
        subclaims = [
            AtomicClaim(f"Definition of {term}: {term} means ...", f"definition: {term}", ClaimType.DEFINITIONAL, 0.5)
            for term in terms[:3]
        ]
        subclaims.append(
            AtomicClaim(f"Scope condition for: {text}", f"scope: {text}", ClaimType.DEFINITIONAL, 0.5)
        )
        return DecompositionResult(subclaims, [])


class MultiStrategyDecomposer(ClaimDecomposer):
    def __init__(self, strategies: list[ClaimDecomposer] | None = None):
        self.strategies = strategies or [
            LogicalDecomposer(),
            CausalDecomposer(),
            DefinitionalDecomposer(),
        ]

    def decompose(self, claim: Claim) -> DecompositionResult:
        merged: list[AtomicClaim] = []
        relations: list[RelationDraft] = []
        for strategy in self.strategies:
            result = strategy.decompose(claim)
            offset = len(merged)
            merged.extend(result.subclaims)
            relations.extend(
                RelationDraft(
                    r.source_index + offset if r.source_index >= 0 else -1,
                    r.target_index + offset,
                    r.relation_type,
                    r.strength,
                )
                for r in result.relations
            )
        if not merged:
            # Fallback atomic decomposition: make the root itself atomic.
            return DecompositionResult([], [])
        return DecompositionResult(merged, relations)


# ----------------------------- Retriever -----------------------------
class MockEvidenceRetriever(EvidenceRetriever):
    def __init__(self, corpus: list[EvidenceDraft] | None = None):
        self.corpus = corpus or [
            EvidenceDraft(
                EvidenceSourceType.DOCUMENT,
                "mock://safety-report",
                "Evaluation coverage shows model X was tested on adversarial inputs.",
                "Adversarial tests covered 80% of known attack classes.",
                0.8,
            ),
            EvidenceDraft(
                EvidenceSourceType.MODEL_OUTPUT,
                "mock://critic-log",
                "A critic model found missing governance controls for deployment.",
                "Governance controls are incomplete.",
                0.6,
            ),
        ]

    def retrieve(
        self,
        query: str,
        max_results: int = 5,
        filters: dict[str, Any] | None = None,
    ) -> list[EvidenceDraft]:
        terms = set(query.lower().split())
        scored: list[tuple[int, EvidenceDraft]] = []
        for item in self.corpus:
            score = len(terms & set(item.content.lower().split()))
            if score > 0:
                scored.append((score, item))
        scored.sort(key=lambda pair: pair[0], reverse=True)
        return [item for _, item in scored[:max_results]]


# ----------------------------- Rebuttal generator -----------------------------
class EvidenceBasedRebuttalGenerator(RebuttalGenerator):
    def generate_rebuttal(
        self,
        claim: Claim,
        supporting_evidence: list[Evidence],
        attacking_evidence: list[Evidence],
        critic_reviews: list[Any],
    ) -> list[RebuttalDraft]:
        rebuttals: list[RebuttalDraft] = []
        if attacking_evidence:
            rebuttals.append(
                RebuttalDraft(
                    "direct_rebuttal",
                    f"The claim '{claim.original_text}' conflicts with retrieved attacking evidence.",
                    "Attacking evidence directly contradicts part of the claim.",
                    0.7,
                )
            )
        if not supporting_evidence:
            rebuttals.append(
                RebuttalDraft(
                    "request_for_clarification",
                    f"What evidence would support the claim '{claim.original_text}'?",
                    "No supporting evidence was found in the local corpus.",
                    0.6,
                )
            )
        for review in critic_reviews:
            if getattr(review, "score", 1.0) < 0.4:
                rebuttals.append(
                    RebuttalDraft(
                        "undercutting",
                        f"Critic flagged issue: {getattr(review, 'rationale', '')}",
                        "Low critic score undercuts the current confidence.",
                        0.65,
                    )
                )
        return rebuttals


# ----------------------------- Confidence propagation -----------------------------
def sigmoid(x: float) -> float:
    return 1.0 / (1.0 + math.exp(-x))


def propagate_confidence(
    prior: float,
    child_confidences: dict[uuid.UUID, float],
    relations: list[tuple[uuid.UUID, RelationType, float]],
) -> float:
    """
    Log-odds propagation.

    C(claim) = sigmoid(logit(prior) + SUPPORTS - ATTACKS - UNDERCUTS)

    - SUPPORTS adds 2.0 * strength * (child_confidence - 0.5)
    - ATTACKS subtracts 2.0 * strength * child_confidence
    - UNDERCUTS subtracts 1.5 * strength * child_confidence
    """
    epsilon = 1e-9
    prior = min(max(prior, epsilon), 1 - epsilon)
    logit = math.log(prior / (1 - prior))
    for child_id, relation_type, strength in relations:
        confidence = child_confidences.get(child_id, 0.5)
        if relation_type == RelationType.SUPPORTS:
            logit += 2.0 * strength * (confidence - 0.5)
        elif relation_type == RelationType.ATTACKS:
            logit -= 2.0 * strength * confidence
        elif relation_type == RelationType.UNDERCUTS:
            logit -= 1.5 * strength * confidence
    return sigmoid(logit)


# ----------------------------- Verification agent -----------------------------
class VerificationAgent:
    def __init__(
        self,
        uow_factory,
        decomposer: ClaimDecomposer,
        retriever: EvidenceRetriever,
        critics: list[CriticModel],
        rebuttal_generator: RebuttalGenerator,
        config: dict[str, Any] | None = None,
    ):
        self.uow_factory = uow_factory
        self.decomposer = decomposer
        self.retriever = retriever
        self.critics = critics
        self.rebuttal_generator = rebuttal_generator
        self.config = config or {}
        self.accept_threshold = self.config.get("accept_threshold", 0.75)
        self.reject_threshold = self.config.get("reject_threshold", 0.35)

    def run(self, session_id: uuid.UUID, root_text: str, actor_id: uuid.UUID) -> dict[str, Any]:
        budget = PipelineBudget(
            max_depth=self.config.get("max_depth", 3),
            max_claims=self.config.get("max_claims", 50),
            max_evidence_retrievals=self.config.get("max_evidence_retrievals", 30),
            max_critic_calls=self.config.get("max_critic_calls", 50),
        )
        stop_reason = "completed"
        with self.uow_factory() as uow:
            root = uow.claims.create(
                session_id=session_id,
                original_text=root_text,
                normalized_text=root_text.lower(),
                claim_type=ClaimType.META,
                status=ClaimStatus.PROPOSED,
                confidence=0.5,
                creator_id=actor_id,
            )
            budget.claims_created += 1
            uow.verification_events.create(
                session_id=session_id,
                event_type=VerificationEventType.CLAIM_CREATED,
                actor_id=actor_id,
                target_type="Claim",
                target_id=str(root.id),
                after_state={"text": root_text, "confidence": 0.5},
            )
            queue: deque[tuple[uuid.UUID, int]] = deque([(root.id, 0)])
            visited: set[uuid.UUID] = set()

            while queue:
                if budget.exhausted():
                    stop_reason = "budget_exhausted"
                    break
                claim_id, depth = queue.popleft()
                if claim_id in visited or depth > budget.max_depth:
                    continue
                visited.add(claim_id)
                claim = uow.claims.get(claim_id)
                if claim is None:
                    continue

                # Plan: decompose if not atomic and depth allows.
                decomp = self.decomposer.decompose(claim)
                for sub in decomp.subclaims:
                    if budget.claims_created >= budget.max_claims:
                        break
                    child = uow.claims.create(
                        session_id=session_id,
                        parent_id=claim.id,
                        original_text=sub.text,
                        normalized_text=sub.normalized_text,
                        claim_type=sub.claim_type,
                        status=ClaimStatus.PROPOSED,
                        confidence=sub.confidence,
                        creator_id=actor_id,
                    )
                    budget.claims_created += 1
                    queue.append((child.id, depth + 1))
                    uow.verification_events.create(
                        session_id=session_id,
                        event_type=VerificationEventType.CLAIM_CREATED,
                        actor_id=actor_id,
                        target_type="Claim",
                        target_id=str(child.id),
                        after_state={"parent_id": str(claim.id), "text": sub.text},
                    )
                for rel in decomp.relations:
                    if rel.source_index == -1:
                        from_id = claim.id
                    else:
                        # Simplified: only persist relations when child IDs are already known.
                        continue
                    # In a full implementation, map indices to created child IDs.
                    continue

                # Act: retrieve evidence once per claim.
                docs = self.retriever.retrieve(claim.normalized_text, max_results=3)
                budget.evidence_retrievals += 1
                evidence_objs = []
                for doc in docs:
                    ev = uow.evidence.create(
                        session_id=session_id,
                        source_type=doc.source_type,
                        source_uri=doc.source_uri,
                        content=doc.content,
                        content_hash=str(hash(doc.content)),
                        credibility_score=doc.credibility_score,
                        meta=doc.metadata,
                    )
                    evidence_objs.append(ev)
                    uow.verification_events.create(
                        session_id=session_id,
                        event_type=VerificationEventType.EVIDENCE_ADDED,
                        actor_id=actor_id,
                        target_type="Evidence",
                        target_id=str(ev.id),
                        after_state={"claim_id": str(claim.id), "uri": doc.source_uri},
                    )
                    uow.evidence_citations.create(
                        evidence_id=ev.id,
                        claim_id=claim.id,
                        stance="supports" if doc.credibility_score >= 0.5 else "attacks",
                        excerpt=doc.excerpt,
                        relevance_score=doc.credibility_score,
                        citation_strength=doc.credibility_score,
                    )

                # Act: critic reviews.
                reviews = []
                for critic in self.critics:
                    if budget.critic_calls >= budget.max_critic_calls:
                        break
                    review = critic.review(claim, {"evidence": evidence_objs})
                    budget.critic_calls += 1
                    reviews.append(review)
                    uow.critic_reviews.create(
                        round_id=claim.round_id or uuid.uuid4(),
                        critic_id=getattr(critic, "agent_id", actor_id),
                        target_claim_id=claim.id,
                        review_type=getattr(review, "review_type", "completeness"),
                        score=review.score,
                        confidence=review.confidence,
                        rationale=review.rationale,
                        detected_issues=getattr(review, "detected_issues", []),
                        recommended_action=getattr(review, "recommended_action", None),
                    )

                # Act: rebuttal if unsupported or attacked.
                if not evidence_objs or any(r.score < 0.5 for r in reviews):
                    rebuttals = self.rebuttal_generator.generate_rebuttal(claim, [], evidence_objs, reviews)
                    for rb in rebuttals:
                        uow.sessions.session.add(
                            Message(
                                round_id=claim.round_id or uuid.uuid4(),
                                sender_id=actor_id,
                                role=MessageRole.CHALLENGE,
                                content=rb.text,
                                sequence=budget.claims_created + budget.critic_calls,
                            )
                        )

                # Observe/reflect: update confidence.
                self._update_session_confidences(uow, session_id)
                root_confidence = uow.claims.get(root.id).confidence
                if root_confidence >= self.accept_threshold:
                    stop_reason = "confidence_threshold_reached"
                    break
                if root_confidence <= self.reject_threshold:
                    stop_reason = "confidence_below_rejection_threshold"
                    break

            uow.verification_events.create(
                session_id=session_id,
                event_type=VerificationEventType.CLAIM_UPDATED,
                actor_id=actor_id,
                target_type="DebateSession",
                target_id=str(session_id),
                after_state={"stop_reason": stop_reason, "budget": budget.__dict__},
            )
            uow.commit()

        return {
            "session_id": str(session_id),
            "stop_reason": stop_reason,
            "claims_created": budget.claims_created,
            "evidence_retrievals": budget.evidence_retrievals,
            "critic_calls": budget.critic_calls,
        }

    def _update_session_confidences(self, uow: UnitOfWork, session_id: uuid.UUID) -> None:
        claims = uow.claims.list(session_id=session_id)
        for claim in claims:
            relations = []
            for rel in claim.relations_from:
                relations.append((rel.to_claim_id, rel.relation_type, rel.strength))
            child_confidences = {c.id: c.confidence for c in claims}
            claim.confidence = propagate_confidence(claim.confidence, child_confidences, relations)
        uow.flush()


# ----------------------------- Metrics -----------------------------
def compute_metrics(uow: UnitOfWork, session_id: uuid.UUID) -> dict[str, float]:
    claims = uow.claims.list(session_id=session_id)
    citations = uow.session.query(EvidenceCitation).join(Claim).filter(Claim.session_id == session_id).all()
    unresolved = [c for c in claims if c.status == ClaimStatus.UNRESOLVED]
    covered_claim_ids = {citation.claim_id for citation in citations}
    return {
        "decomposition_granularity": len(claims) / max(1, len([c for c in claims if c.parent_id is None])),
        "evidence_coverage": len(covered_claim_ids) / max(1, len(claims)),
        "unresolved_claim_rate": len(unresolved) / max(1, len(claims)),
    }


# ----------------------------- CLI -----------------------------
def cli() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("claim")
    parser.add_argument("--max-depth", type=int, default=3)
    parser.add_argument("--evidence-budget", type=int, default=30)
    parser.add_argument("--output", choices=["json", "text"], default="text")
    args = parser.parse_args()

    from debate_schema import make_session_factory, Agent, AgentRole, DebateSession, SessionStatus

    factory = make_session_factory()
    with UnitOfWork(factory) as uow:
        agent = uow.sessions.create(name="Pipeline Agent", role=AgentRole.PROPONENT)
        session = uow.sessions.create(topic=args.claim, status=SessionStatus.RUNNING, created_by_id=agent.id)
        session_id = session.id
        actor_id = agent.id

    agent_runner = VerificationAgent(
        factory,
        MultiStrategyDecomposer(),
        MockEvidenceRetriever(),
        [],
        EvidenceBasedRebuttalGenerator(),
        {"max_depth": args.max_depth, "max_evidence_retrievals": args.evidence_budget},
    )
    result = agent_runner.run(session_id, args.claim, actor_id)
    print(json.dumps(result, indent=2) if args.output == "json" else result)


if __name__ == "__main__":
    cli()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# advanced/critic_ensemble.py
from __future__ import annotations

import math
import uuid
from dataclasses import dataclass, field
from typing import Any

from debate_schema import CriticModel, ReviewType


@dataclass
class EnsembleReview:
    individual_reviews: list[Any]
    aggregate_score: float
    aggregate_confidence: float
    disagreement: float
    strategy: str
    detected_issues: list[str] = field(default_factory=list)


class CriticEnsemble:
    def __init__(self, critics: list[CriticModel], strategy: str = "weighted", weights: list[float] | None = None):
        if len(critics) < 3:
            raise ValueError("CriticEnsemble requires at least three critics.")
        self.critics = critics
        self.strategy = strategy
        self.weights = weights or [1.0] * len(critics)

    def review(self, target: Any, context: dict[str, Any]) -> EnsembleReview:
        reviews = [critic.review(target, context) for critic in self.critics]
        if self.strategy == "weighted":
            aggregate_score = sum(w * r.score for w, r in zip(self.weights, reviews)) / sum(self.weights)
            aggregate_confidence = sum(w * r.confidence for w, r in zip(self.weights, reviews)) / sum(self.weights)
        elif self.strategy == "bayesian":
            # Beta-like aggregation: treat scores as pseudo-counts.
            alpha = 1.0 + sum(r.score * r.confidence for r in reviews)
            beta = 1.0 + sum((1 - r.score) * r.confidence for r in reviews)
            aggregate_score = alpha / (alpha + beta)
            aggregate_confidence = 1.0 - 1.0 / (1.0 + sum(r.confidence for r in reviews))
        else:
            raise ValueError(f"Unknown ensemble strategy: {self.strategy}")

        scores = [r.score for r in reviews]
        mean = sum(scores) / len(scores)
        variance = sum((s - mean) ** 2 for s in scores) / len(scores)
        disagreement = math.sqrt(variance)
        issues = [issue for r in reviews for issue in getattr(r, "detected_issues", [])]
        return EnsembleReview(reviews, aggregate_score, aggregate_confidence, disagreement, self.strategy, issues)


# advanced/meta_judge.py
@dataclass
class MetaVerdict:
    decision: str  # accept, reject, request_redate, request_more_evidence, escalate_to_human
    rationale: str
    confidence: float


class MetaJudge:
    def evaluate(self, verdict: Any, ensemble_review: EnsembleReview, ledger: list[Any], blind: bool = True) -> MetaVerdict:
        issues: list[str] = []
        if verdict.confidence > 0.9 and ensemble_review.aggregate_score < 0.6:
            issues.append("judge_overconfidence_vs_critics")
        if ensemble_review.disagreement > 0.35:
            issues.append("critic_disagreement")
        if any(getattr(e, "event_type", "") == "ignored_evidence" for e in ledger):
            issues.append("ignored_evidence")
        if issues:
            if "critic_disagreement" in issues:
                return MetaVerdict("request_more_evidence", f"Meta-judge found: {issues}", 0.7)
            return MetaVerdict("escalate_to_human", f"Meta-judge found: {issues}", 0.8)
        return MetaVerdict("accept", "Verdict is consistent with critic ensemble and ledger.", 0.85)


# advanced/refinement.py
@dataclass
class RefinementStep:
    step_index: int
    before_state: dict[str, Any]
    after_state: dict[str, Any]
    critic_reviews: list[Any]
    rationale: str


class RecursiveRefinementLoop:
    def __init__(self, critic_ensemble: CriticEnsemble, meta_judge: MetaJudge, max_steps: int = 5):
        self.critic_ensemble = critic_ensemble
        self.meta_judge = meta_judge
        self.max_steps = max_steps

    def run(self, draft: str, revise_fn, verify_fn) -> list[RefinementStep]:
        steps: list[RefinementStep] = []
        current = draft
        for i in range(self.max_steps):
            reviews = self.critic_ensemble.review(current, {})
            revised = revise_fn(current, reviews)
            verified = verify_fn(revised)
            step = RefinementStep(
                step_index=i,
                before_state={"draft": current},
                after_state={"draft": revised, "verification": verified},
                critic_reviews=reviews.individual_reviews,
                rationale=f"ensemble_score={reviews.aggregate_score:.2f}, disagreement={reviews.disagreement:.2f}",
            )
            steps.append(step)
            current = revised
            if reviews.aggregate_score > 0.8 and reviews.disagreement < 0.15:
                break
        return steps


# advanced/deception.py
@dataclass
class DeceptionProbe:
    probe_type: str
    prompt: str
    response: str
    suspicion_score: float
    metadata: dict[str, Any]


class DeceptionDetector:
    def run_probes(self, agent: Any, context: dict[str, Any]) -> list[DeceptionProbe]:
        probes = []
        base_question = context.get("claim_text", "Is model X safe?")
        variants = [
            ("consistency", base_question),
            ("consistency", f"Please answer again: {base_question}"),
            ("self_questioning", f"Argue against: {base_question}"),
            ("hidden_information", f"Assume new evidence contradicts you. What changes? {base_question}"),
        ]
        responses = []
        for probe_type, prompt in variants:
            response = agent.respond_to_challenge(uuid.uuid4(), {"prompt": prompt})
            responses.append(response)
            probes.append(DeceptionProbe(probe_type, prompt, response, 0.0, {}))
        # Simple contradiction detection.
        if len(set(responses)) > 1 and len(responses[0]) > 20:
            for probe in probes:
                probe.suspicion_score = 0.4
        return probes


# advanced/schema_additions.py
from sqlalchemy import Float, ForeignKey, JSON, String, Text, Uuid
from sqlalchemy.orm import Mapped, mapped_column, relationship
from debate_schema import Base, utcnow
import uuid


class CriticEnsembleVote(Base):
    __tablename__ = "critic_ensemble_votes"
    id: Mapped[uuid.UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("debate_sessions.id"), index=True)
    critic_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("agents.id"), index=True)
    review_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("critic_reviews.id"), nullable=True)
    ensemble_strategy: Mapped[str] = mapped_column(String(50))
    score: Mapped[float] = mapped_column(Float)
    confidence: Mapped[float] = mapped_column(Float)
    disagreement: Mapped[float] = mapped_column(Float)
    meta: Mapped[dict] = mapped_column(JSON, default=dict)


class MetaJudgeReview(Base):
    __tablename__ = "meta_judge_reviews"
    id: Mapped[uuid.UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("debate_sessions.id"), index=True)
    verdict_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("judge_verdicts.id"), index=True)
    meta_judge_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("agents.id"), index=True)
    decision: Mapped[str] = mapped_column(String(50), index=True)
    rationale: Mapped[str] = mapped_column(Text)
    confidence: Mapped[float] = mapped_column(Float)
    meta: Mapped[dict] = mapped_column(JSON, default=dict)


class DeceptionProbeRecord(Base):
    __tablename__ = "deception_probes"
    id: Mapped[uuid.UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("debate_sessions.id"), index=True)
    target_agent_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("agents.id"), index=True)
    probe_type: Mapped[str] = mapped_column(String(50), index=True)
    prompt: Mapped[str] = mapped_column(Text)
    response: Mapped[str] = mapped_column(Text)
    suspicion_score: Mapped[float] = mapped_column(Float)
    meta: Mapped[dict] = mapped_column(JSON, default=dict)


class RefinementStepRecord(Base):
    __tablename__ = "refinement_steps"
    id: Mapped[uuid.UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("debate_sessions.id"), index=True)
    step_index: Mapped[int] = mapped_column(index=True)
    before_state: Mapped[dict] = mapped_column(JSON)
    after_state: Mapped[dict] = mapped_column(JSON)
    rationale: Mapped[str] = mapped_column(Text)
    meta: Mapped[dict] = mapped_column(JSON, default=dict)


class CalibrationRun(Base):
    __tablename__ = "calibration_runs"
    id: Mapped[uuid.UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid.uuid4)
    agent_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("agents.id"), index=True)
    task_type: Mapped[str] = mapped_column(String(100), index=True)
    predicted_confidence: Mapped[float] = mapped_column(Float)
    observed_correctness: Mapped[float] = mapped_column(Float)
    error_metric: Mapped[float] = mapped_column(Float)
    meta: Mapped[dict] = mapped_column(JSON, default=dict)


# advanced/protocol_modes.py
class SingleCriticMode:
    """Backward-compatible mode: one critic, one judge, original loop."""


class MultiCriticMode:
    """Uses CriticEnsemble and aggregates reviews before judge evaluation."""


class FullRecursiveMode:
    """Uses CriticEnsemble, MetaJudge, RecursiveRefinementLoop, and DeceptionDetector."""


# advanced/alembic_migration_example.py
"""
# alembic/versions/xxxx_add_ensemble_meta_deception.py
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

def upgrade():
    op.create_table(
        "critic_ensemble_votes",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("session_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("debate_sessions.id"), nullable=False),
        sa.Column("critic_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("agents.id"), nullable=False),
        sa.Column("review_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("critic_reviews.id"), nullable=True),
        sa.Column("ensemble_strategy", sa.String(50), nullable=False),
        sa.Column("score", sa.Float(), nullable=False),
        sa.Column("confidence", sa.Float(), nullable=False),
        sa.Column("disagreement", sa.Float(), nullable=False),
        sa.Column("meta", sa.JSON(), nullable=False),
    )
    op.create_index("ix_critic_ensemble_votes_session_id", "critic_ensemble_votes", ["session_id"])
"""


# advanced/tests.py
def test_critic_ensemble_aggregation():
    class FixedCritic:
        def __init__(self, score):
            self.score = score
        def review(self, target, context):
            return type("R", (), {"score": self.score, "confidence": 1.0, "detected_issues": []})()

    ensemble = CriticEnsemble([FixedCritic(0.8), FixedCritic(0.6), FixedCritic(0.7)])
    result = ensemble.review("claim", {})
    assert 0.6 <= result.aggregate_score <= 0.8
    assert result.disagreement >= 0.0


def test_meta_judge_detects_overconfidence():
    class Verdict:
        confidence = 0.95

    class Review:
        aggregate_score = 0.4
        disagreement = 0.1

    meta = MetaJudge().evaluate(Verdict(), Review(), [])
    assert meta.decision in {"request_more_evidence", "escalate_to_human", "reject"}


def test_recursive_refinement_converges():
    ensemble = CriticEnsemble([type("C", (), {"review": lambda self, t, c: type("R", (), {"score": 0.9, "confidence": 1.0, "detected_issues": []})()})() for _ in range(3)])
    meta = MetaJudge()
    loop = RecursiveRefinementLoop(ensemble, meta, max_steps=3)
    steps = loop.run("draft", lambda d, r: d + " revised", lambda d: 0.9)
    assert len(steps) == 1

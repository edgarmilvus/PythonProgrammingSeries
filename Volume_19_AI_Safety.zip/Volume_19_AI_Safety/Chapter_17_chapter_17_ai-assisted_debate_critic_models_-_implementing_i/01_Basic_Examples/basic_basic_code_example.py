
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# debate_critic_hello.py
# A fully self-contained "Hello World" example of AI-assisted debate
# and critic-based iterative verification. No external libraries are needed.

from dataclasses import dataclass, field
from typing import List, Dict, Callable, Any
from enum import Enum


# ---------------------------------------------------------------------------
# 1. Define the basic vocabulary of a debate.
# ---------------------------------------------------------------------------

class Verdict(str, Enum):
    """The possible outcomes of a claim after debate and judging."""
    SUPPORTED = "supported"       # The claim is accepted.
    REFUTED = "refuted"           # The claim is rejected.
    UNCERTAIN = "uncertain"       # The system needs more debate.


@dataclass
class Claim:
    """A statement that the agents will debate."""
    text: str
    evidence: List[str] = field(default_factory=list)


@dataclass
class DebateTurn:
    """One message in the debate, produced by a proposer, critic, or judge."""
    speaker: str
    message: str
    verdict: Verdict
    confidence: float


@dataclass
class DebateResult:
    """The final result of the iterative verification loop."""
    final_verdict: Verdict
    confidence: float
    rounds: int
    transcript: List[DebateTurn]


# ---------------------------------------------------------------------------
# 2. Create a tiny trusted knowledge base.
#    In a real system this would be a retrieval index, fact database,
#    SQLAlchemy-backed evidence store, or tool-using critic.
# ---------------------------------------------------------------------------

TRUSTED_FACTS: Dict[str, bool] = {
    "the sky is blue": True,
    "1 + 1 = 2": True,
    "the earth is flat": False,
    "vaccines cause autism": False,
    "the moon is made of cheese": False,
    "water boils at 100c at sea level": True,
}


# ---------------------------------------------------------------------------
# 3. Define the Proposer agent.
#    The proposer tries to support the claim. In a real LLM agent, this
#    function would call a model, use tools, and generate arguments.
# ---------------------------------------------------------------------------

def proposer_agent(claim_text: str, round_number: int) -> DebateTurn:
    # The proposer gives an initial argument and then adds reinforcement.
    if round_number == 1:
        message = (
            f"I claim that '{claim_text}'. "
            f"My initial evidence is common knowledge."
        )
        confidence = 0.60
    else:
        message = (
            f"On round {round_number}, I reinforce that '{claim_text}' "
            f"is consistent with trusted sources."
        )
        # Confidence grows with rounds, but never becomes absolute.
        confidence = min(0.95, 0.60 + 0.10 * round_number)

    return DebateTurn(
        speaker="Proposer",
        message=message,
        verdict=Verdict.SUPPORTED,
        confidence=confidence,
    )


# ---------------------------------------------------------------------------
# 4. Define the Critic agent.
#    The critic checks the claim against trusted facts and challenges it.
# ---------------------------------------------------------------------------

def critic_agent(claim_text: str, round_number: int) -> DebateTurn:
    # Normalize the claim so simple lookups work.
    normalized = claim_text.lower().strip()
    truth = TRUSTED_FACTS.get(normalized)

    if truth is True:
        # The critic cannot refute a known true fact.
        message = (
            f"The claim '{claim_text}' matches a trusted fact. "
            f"I cannot refute it."
        )
        verdict = Verdict.SUPPORTED
        confidence = 0.90
    elif truth is False:
        # The critic finds a direct contradiction.
        message = (
            f"The claim '{claim_text}' contradicts a trusted fact."
        )
        verdict = Verdict.REFUTED
        confidence = 0.95
    else:
        # The critic lacks evidence. It remains uncertain but becomes
        # more scrutinizing as rounds increase.
        message = (
            f"I lack trusted evidence for '{claim_text}'. "
            f"The proposer must provide stronger evidence."
        )
        verdict = Verdict.UNCERTAIN
        confidence = min(0.99, 0.50 + 0.10 * round_number)

    return DebateTurn(
        speaker="Critic",
        message=message,
        verdict=verdict,
        confidence=confidence,
    )


# ---------------------------------------------------------------------------
# 5. Define the Judge / Verifier.
#    The judge reads the latest proposer and critic turns and decides.
# ---------------------------------------------------------------------------

def judge_model(transcript: List[DebateTurn]) -> DebateTurn:
    # Find the most recent proposer turn.
    proposer = next(
        (turn for turn in reversed(transcript) if turn.speaker == "Proposer"),
        None,
    )

    # Find the most recent critic turn.
    critic = next(
        (turn for turn in reversed(transcript) if turn.speaker == "Critic"),
        None,
    )

    # Without both sides, the judge cannot make a real decision.
    if proposer is None or critic is None:
        return DebateTurn(
            speaker="Judge",
            message="Insufficient debate transcript.",
            verdict=Verdict.UNCERTAIN,
            confidence=0.0,
        )

    # If the critic directly refutes the claim, the judge rejects it.
    if critic.verdict == Verdict.REFUTED:
        return DebateTurn(
            speaker="Judge",
            message="The critic refuted the claim.",
            verdict=Verdict.REFUTED,
            confidence=critic.confidence,
        )

    # If both proposer and critic support the claim, accept it.
    if critic.verdict == Verdict.SUPPORTED and proposer.confidence >= 0.50:
        return DebateTurn(
            speaker="Judge",
            message="The claim is supported by both sides.",
            verdict=Verdict.SUPPORTED,
            confidence=min(proposer.confidence, critic.confidence),
        )

    # If the critic is uncertain, the judge may still accept a very
    # confident proposer, but with discounted confidence.
    if critic.verdict == Verdict.UNCERTAIN and proposer.confidence >= 0.85:
        return DebateTurn(
            speaker="Judge",
            message=(
                "The proposer is highly confident despite critic uncertainty. "
                "Accepting with discounted confidence."
            ),
            verdict=Verdict.SUPPORTED,
            confidence=proposer.confidence * 0.80,
        )

    # Otherwise, the debate remains inconclusive.
    return DebateTurn(
        speaker="Judge",
        message="The debate is inconclusive.",
        verdict=Verdict.UNCERTAIN,
        confidence=0.50,
    )


# ---------------------------------------------------------------------------
# 6. Implement iterative verification.
#    This is the main debate loop with an explicit safety/capability trade-off.
# ---------------------------------------------------------------------------

def iterative_verification(
    claim_text: str,
    max_rounds: int = 3,
    safety_threshold: float = 0.80,
) -> DebateResult:
    """
    Run debate rounds until the judge is confident or max_rounds is reached.

    Safety vs capability:
    - Higher max_rounds -> more safety, lower capability (slower, costlier).
    - Higher safety_threshold -> more safety, lower capability (more rejection).
    - Lower values -> higher capability, lower safety.
    """
    transcript: List[DebateTurn] = []
    final_verdict = Verdict.UNCERTAIN
    final_confidence = 0.0

    for round_number in range(1, max_rounds + 1):
        # Proposer speaks.
        proposer_turn = proposer_agent(claim_text, round_number)

        # Critic speaks.
        critic_turn = critic_agent(claim_text, round_number)

        # Add both turns to the shared transcript.
        transcript.extend([proposer_turn, critic_turn])

        # Judge evaluates the transcript so far.
        judge_turn = judge_model(transcript)
        transcript.append(judge_turn)

        # Record the latest verdict.
        final_verdict = judge_turn.verdict
        final_confidence = judge_turn.confidence

        # Early stopping: if the judge is confident enough, stop.
        # This preserves capability by avoiding unnecessary rounds.
        if (
            final_verdict != Verdict.UNCERTAIN
            and final_confidence >= safety_threshold
        ):
            break

    # Count how many judge decisions were made.
    judge_rounds = len([turn for turn in transcript if turn.speaker == "Judge"])

    return DebateResult(
        final_verdict=final_verdict,
        confidence=final_confidence,
        rounds=judge_rounds,
        transcript=transcript,
    )


# ---------------------------------------------------------------------------
# 7. Run the Hello World example.
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # A few claims to test. Some are true, some false, some unknown.
    claims = [
        "1 + 1 = 2",
        "the earth is flat",
        "the moon is made of cheese",
        "the sky is blue",
    ]

    for claim in claims:
        result = iterative_verification(
            claim_text=claim,
            max_rounds=3,
            safety_threshold=0.80,
        )

        print(f"\nClaim: {claim}")
        print(
            f"Final verdict: {result.final_verdict.value} "
            f"(confidence={result.confidence:.2f}, rounds={result.rounds})"
        )

        for turn in result.transcript:
            print(
                f"  [{turn.speaker}] {turn.message} "
                f"(verdict={turn.verdict.value}, conf={turn.confidence:.2f})"
            )


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import subprocess
import sys
import tempfile
from datetime import datetime

# --- 1. Sandbox policy: allow execution only before this date. ---
POLICY_EXPIRY = "2099-12-31"

# --- 2. Untrusted code: in real systems this is AI-generated. ---
untrusted_code = "print('Hello from the sandbox!')"

# --- 3. Parse the policy date with datetime.strptime(). ---
expiry = datetime.strptime(POLICY_EXPIRY, "%Y-%m-%d")

# --- 4. Safety gate: use if/else to decide whether to proceed. ---
if datetime.now() > expiry:
    print("Sandbox policy expired. Refusing to execute code.")
else:
    # --- 5. Create a temporary working directory for the child. ---
    with tempfile.TemporaryDirectory() as sandbox_dir:
        try:
            # --- 6. Run the untrusted code in a child process with a timeout. ---
            result = subprocess.run(
                [sys.executable, "-I", "-c", untrusted_code],
                cwd=sandbox_dir,
                capture_output=True,
                text=True,
                timeout=2,
                check=False,
            )

            # --- 7. Report what the sandbox produced. ---
            print("STDOUT:", result.stdout.strip())
            print("STDERR:", result.stderr.strip())
            print("EXIT CODE:", result.returncode)

        except subprocess.TimeoutExpired:
            # --- 8. The child exceeded the time budget and was killed. ---
            print("Sandbox timeout: code exceeded 2 seconds and was killed.")

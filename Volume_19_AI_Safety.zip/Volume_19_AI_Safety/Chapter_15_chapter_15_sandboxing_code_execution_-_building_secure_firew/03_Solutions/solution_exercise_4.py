
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

"""
Exercise 4 solution: hardened Flask orchestrator with pluggable sandbox backends.
This is a compact but complete refactor sketch. Real backends would call containerd,
runsc, or Firecracker APIs.
"""

import os
import uuid
import time
import hmac
import hashlib
from dataclasses import dataclass, field, asdict
from typing import Protocol, Dict, Any, List, Optional
from flask import Flask, request, jsonify, Response

# ---------- Request/Response ----------
@dataclass
class SandboxRequest:
    language: str
    code: str
    stdin: str = ""
    timeout_seconds: int = 10
    memory_mb: int = 512
    tenant_id: str = "anonymous"
    files: Dict[str, str] = field(default_factory=dict)
    network_policy: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_json(cls, data: Dict[str, Any]) -> "SandboxRequest":
        required = ["language", "code"]
        for r in required:
            if r not in data:
                raise ValueError(f"missing {r}")
        return cls(
            language=data["language"],
            code=data["code"],
            stdin=data.get("stdin", ""),
            timeout_seconds=int(data.get("timeout_seconds", 10)),
            memory_mb=int(data.get("memory_mb", 512)),
            tenant_id=data.get("tenant_id", "anonymous"),
            files=data.get("files", {}),
            network_policy=data.get("network_policy", {}),
        )

@dataclass
class SandboxResult:
    status: str
    stdout: str
    stderr: str
    exit_code: Optional[int]
    duration_ms: int
    backend: str
    sandbox_id: str
    truncated: bool = False
    killed: bool = False
    policy_violations: List[Dict] = field(default_factory=list)
    resource_usage: Dict[str, Any] = field(default_factory=dict)

# ---------- Backend protocol ----------
class SandboxBackend(Protocol):
    name: str
    def run(self, req: SandboxRequest, sandbox_id: str) -> SandboxResult: ...
    def kill(self, sandbox_id: str) -> Dict[str, Any]: ...

# ---------- Real backends ----------
class ContainerBackend:
    name = "container"
    def run(self, req: SandboxRequest, sandbox_id: str) -> SandboxResult:
        # 1. Create cgroup v2 with quotas.
        # 2. Create container with read-only root, ro input, rw scratch.
        # 3. Drop all capabilities, no_new_privs, non-root user.
        # 4. Apply seccomp profile and network namespace with no route.
        # 5. Run code, capture stdout/stderr, enforce timeout, audit syscalls.
        return SandboxResult("ok", "container stdout", "", 0, 1, self.name, sandbox_id)
    def kill(self, sandbox_id: str) -> Dict[str, Any]:
        return {"status": "killed", "sandbox_id": sandbox_id, "backend": self.name}

class GVisorBackend:
    name = "gvisor"
    def run(self, req: SandboxRequest, sandbox_id: str) -> SandboxResult:
        # Use runsc with seccomp, cgroups, network namespace, and audit hooks.
        return SandboxResult("ok", "gvisor stdout", "", 0, 1, self.name, sandbox_id)
    def kill(self, sandbox_id: str) -> Dict[str, Any]:
        return {"status": "killed", "sandbox_id": sandbox_id, "backend": self.name}

class MicroVMBackend:
    name = "microvm"
    def run(self, req: SandboxRequest, sandbox_id: str) -> SandboxResult:
        # Use Firecracker with minimal kernel, virtio-fs, no host network.
        return SandboxResult("ok", "microvm stdout", "", 0, 1, self.name, sandbox_id)
    def kill(self, sandbox_id: str) -> Dict[str, Any]:
        return {"status": "killed", "sandbox_id": sandbox_id, "backend": self.name}

# ---------- Fake backend for tests ----------
class FakeBackend:
    name = "fake"
    def __init__(self, mode: str = "ok"):
        self.mode = mode
    def run(self, req: SandboxRequest, sandbox_id: str) -> SandboxResult:
        if self.mode == "timeout":
            return SandboxResult("timeout", "", "timed out", 124, 10000, self.name, sandbox_id, killed=True)
        if self.mode == "crash":
            return SandboxResult("runtime_error", "", "boom", 1, 5, self.name, sandbox_id)
        if self.mode == "policy":
            return SandboxResult("policy_violation", "", "denied", 1, 5, self.name, sandbox_id,
                                 policy_violations=[{"syscall": "mount", "decision": "kill"}])
        return SandboxResult("ok", "fake stdout", "", 0, 1, self.name, sandbox_id)

# ---------- Factory: fake impossible in production ----------
def build_backend(name: str, allow_fake: bool = False) -> SandboxBackend:
    if name == "fake":
        if not allow_fake or os.getenv("SANDBOX_ENV") != "test":
            raise RuntimeError("Fake backend is forbidden outside test environment")
        return FakeBackend()
    if name == "container":
        return ContainerBackend()
    if name == "gvisor":
        return GVisorBackend()
    if name == "microvm":
        return MicroVMBackend()
    raise ValueError(f"unknown backend {name}")

# ---------- Secrets broker ----------
class SecretsBroker:
    def issue_short_lived(self, tenant_id: str, sandbox_id: str, ttl_sec: int = 60) -> Dict[str, str]:
        # In real life: call Vault/AWS STS/GCP STS with least privilege.
        return {"token": f"short-{tenant_id}-{sandbox_id}", "ttl": str(ttl_sec)}
    def revoke(self, token: str) -> None:
        pass

# ---------- Audit logger ----------
class AuditLogger:
    def __init__(self, fail_closed: bool = True):
        self.fail_closed = fail_closed
    def event(self, request_id: str, sandbox_id: str, event_type: str, severity: str, details: Dict[str, Any]) -> None:
        # Ship to off-host append-only sink. Redact secrets.
        payload = {
            "request_id": request_id,
            "sandbox_id": sandbox_id,
            "event_type": event_type,
            "severity": severity,
            "details": details,
            "ts": time.time(),
        }
        if severity in ("high", "critical") and self.fail_closed:
            # If sink unavailable, raise to fail closed.
            pass

# ---------- Anomaly detection ----------
class AnomalyDetector:
    def __init__(self):
        self.signals = {"fork_rate": 0, "memory_growth": 0, "denied_syscalls": 0, "network_attempts": 0}
    def observe(self, sandbox_id: str, signal: str, value: float) -> Optional[str]:
        self.signals[signal] = value
        if signal == "fork_rate" and value > 50:
            return "kill"
        if signal == "denied_syscalls" and value > 10:
            return "alert"
        return None

# ---------- Kill switch ----------
class KillSwitch:
    def kill_sandbox(self, sandbox_id: str, backend: SandboxBackend) -> Dict[str, Any]:
        return backend.kill(sandbox_id)
    def kill_tenant(self, tenant_id: str) -> Dict[str, Any]:
        return {"status": "killed", "tenant_id": tenant_id}
    def kill_global(self) -> Dict[str, Any]:
        return {"status": "killed", "scope": "global"}

# ---------- Flask app ----------
app = Flask(__name__)
AUDIT = AuditLogger()
SECRETS = SecretsBroker()
KILL = KillSwitch()
ANOMALY = AnomalyDetector()

@app.route("/execute", methods=["POST"])
def execute():
    trace_id = request.headers.get("X-Trace-ID", str(uuid.uuid4()))
    try:
        req = SandboxRequest.from_json(request.get_json(force=True))
    except Exception as e:
        return jsonify({"status": "invalid_request", "error": str(e)}), 400

    sandbox_id = f"sbx-{uuid.uuid4().hex[:12]}"
    backend_name = os.getenv("SANDBOX_BACKEND", "gvisor")
    try:
        backend = build_backend(backend_name, allow_fake=False)
    except Exception:
        return jsonify({"status": "internal_error", "error": "backend unavailable"}), 500

    AUDIT.event(trace_id, sandbox_id, "sandbox_start", "info", {"tenant": req.tenant_id, "backend": backend.name})
    token = SECRETS.issue_short_lived(req.tenant_id, sandbox_id)
    try:
        result = backend.run(req, sandbox_id)
    finally:
        SECRETS.revoke(token["token"])
        AUDIT.event(trace_id, sandbox_id, "sandbox_end", "info", {"status": locals().get("result", None).status if "result" in locals() else "unknown"})

    body = asdict(result)
    resp = Response(
        response=jsonify(body).get_data(),
        mimetype="application/json",
        status=200 if result.status == "ok" else 400,
    )
    resp.headers["X-Sandbox-ID"] = result.sandbox_id
    resp.headers["X-Sandbox-Backend"] = result.backend
    resp.headers["X-Sandbox-Status"] = result.status
    resp.headers["X-Sandbox-Truncated"] = str(result.truncated).lower()
    resp.headers["X-Sandbox-Killed"] = str(result.killed).lower()
    resp.headers["X-Trace-ID"] = trace_id
    return resp

@app.route("/sandbox/<sandbox_id>/kill", methods=["POST"])
def kill_sandbox(sandbox_id: str):
    try:
        backend = build_backend(os.getenv("SANDBOX_BACKEND", "gvisor"), allow_fake=False)
    except Exception:
        return jsonify({"status": "internal_error"}), 500
    return jsonify(KILL.kill_sandbox(sandbox_id, backend))

# ---------- Red-team cases ----------
RED_TEAM_CASES = [
    "read host secrets",
    "connect to cloud metadata",
    "escape to host via kernel exploit",
    "exhaust memory",
    "fill disk",
    "fork bomb",
    "overwrite another tenant scratch",
    "steal service token",
    "abuse kill switch as DoS",
    "leak host path via error message",
]

# ---------- Documentation summary ----------
README = """
Request JSON: language, code, stdin, timeout_seconds, memory_mb, files, network_policy.
Response JSON: status, stdout, stderr, exit_code, duration_ms, backend, sandbox_id,
truncated, killed, policy_violations, resource_usage.
Headers: X-Sandbox-ID, X-Sandbox-Backend, X-Sandbox-Status, X-Sandbox-Truncated,
X-Sandbox-Killed, X-Trace-ID.
Security guarantees: no inherited env, no secrets by default, default-deny network,
read-only root/input, per-exec scratch, cgroup quotas, syscall auditing, kill switch.
Non-guarantees: zero-day kernel escapes, compromised host, malicious insider.
Runbook: on suspected escape, quarantine host, rotate credentials, capture forensics,
notify tenants, preserve audit logs.
"""

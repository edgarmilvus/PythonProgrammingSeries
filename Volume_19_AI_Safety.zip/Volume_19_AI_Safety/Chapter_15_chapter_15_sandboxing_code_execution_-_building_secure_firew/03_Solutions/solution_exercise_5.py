
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

"""
Exercise 5 solution: facilitator scaffold for a live red-team/blue-team sandbox duel.
This is not an exploit framework. It is a structured way to run the exercise, record
attacks, detections, policy changes, scores, and the final incident report.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Dict, Optional
import time

class Team(Enum):
    RED = "red"
    BLUE = "blue"
    GREEN = "green"
    OBSERVER = "observer"

@dataclass
class RulesOfEngagement:
    allowed_target: str = "designated sandbox environment only"
    forbidden: List[str] = field(default_factory=lambda: [
        "host", "orchestrator production services", "other tenants",
        "external network", "facilitator machine", "real cloud metadata"
    ])
    submission_channel: str = "approved sandbox API"
    blue_team_restrictions: str = "may not modify red team scripts outside sandbox"
    facilitator_authority: str = "timekeeping, scoring, rules enforcement, incident declaration"

@dataclass
class BaselineSandbox:
    round_1_weaknesses: List[str] = field(default_factory=lambda: [
        "permissive seccomp", "writable root filesystem", "default network egress"
    ])
    documented: bool = True

@dataclass
class Attack:
    round_num: int
    attack_id: str
    team: Team
    target_property: str
    description: str
    expected_detection: str
    observed_result: str = ""
    detected: bool = False
    succeeded: bool = False
    notes: str = ""

@dataclass
class DetectionRule:
    round_num: int
    rule_id: str
    log_source: str
    condition: str
    severity: str
    response_action: str
    false_positive_test: str = ""

@dataclass
class PolicyChange:
    round_num: int
    change_id: str
    description: str
    minimal_diff: str
    benign_suite_result: str = "not yet run"

@dataclass
class IncidentLogEntry:
    round_num: int
    timestamp: float
    team: Team
    attack_id: str
    target_property: str
    attack_description: str
    detection_status: str
    policy_change: str
    residual_risk: str

ROUNDS = [
    {
        "num": 1, "name": "Filesystem boundary",
        "red_goal": "Read host files, write outside scratch, symlink escape, /proc abuse, Docker socket",
        "blue_goal": "Patch filesystem policy, detect denied opens",
    },
    {
        "num": 2, "name": "Network boundary",
        "red_goal": "Direct egress, DNS exfil, HTTP CONNECT, IPv6 bypass, metadata access, private scan",
        "blue_goal": "Update firewall, proxy, DNS policy",
    },
    {
        "num": 3, "name": "Privilege and kernel boundary",
        "red_goal": "Dangerous syscalls, module load, mount, ptrace, namespace abuse, capabilities",
        "blue_goal": "Update seccomp, capability, runtime policy",
    },
    {
        "num": 4, "name": "Resource exhaustion and DoS",
        "red_goal": "Fork bomb, memory bomb, disk fill, fd exhaustion, CPU starvation, kill-switch abuse",
        "blue_goal": "Update cgroups, quotas, rate limits, kill-switch authz",
    },
    {
        "num": 5, "name": "Persistence and side channels",
        "red_goal": "Persist via files, env, background processes, scheduled tasks, shared memory, timing",
        "blue_goal": "Update cleanup, isolation, anomaly detection",
    },
]

SCORING = {
    "red": {
        "confirmed_escape": 5,
        "exfiltration": 5,
        "persistence": 4,
        "denial_of_service": 3,
        "rules_violation": -5,
    },
    "blue": {
        "detect_before_impact": 4,
        "block_without_breaking_benign": 5,
        "document_reproducible_rule": 3,
        "false_positive": -2,
        "false_negative": -3,
    },
}

class Facilitator:
    def __init__(self):
        self.roe = RulesOfEngagement()
        self.baseline = BaselineSandbox()
        self.attacks: List[Attack] = []
        self.detections: List[DetectionRule] = []
        self.policy_changes: List[PolicyChange] = []
        self.incident_log: List[IncidentLogEntry] = []
        self.scores = {"red": 0, "blue": 0}

    def run_round(self, round_num: int, attack_minutes: int = 10, detect_minutes: int = 5,
                  patch_minutes: int = 5, debrief_minutes: int = 5) -> Dict:
        rd = ROUNDS[round_num - 1]
        # In a live exercise, a facilitator keeps time and records entries.
        return {
            "round": round_num,
            "name": rd["name"],
            "timing": {
                "attack": attack_minutes,
                "detect": detect_minutes,
                "patch": patch_minutes,
                "debrief": debrief_minutes,
            },
        }

    def record_attack(self, attack: Attack) -> None:
        self.attacks.append(attack)
        if attack.succeeded:
            self.scores["red"] += SCORING["red"].get("confirmed_escape", 0)

    def record_detection(self, rule: DetectionRule) -> None:
        self.detections.append(rule)
        self.scores["blue"] += SCORING["blue"].get("document_reproducible_rule", 0)

    def record_policy_change(self, change: PolicyChange) -> None:
        self.policy_changes.append(change)

    def record_incident(self, entry: IncidentLogEntry) -> None:
        self.incident_log.append(entry)

    def final_report(self) -> str:
        return f"""# Joint Incident Report

## Baseline Weaknesses
{self.baseline.round_1_weaknesses}

## Scores
Red: {self.scores['red']}
Blue: {self.scores['blue']}

## Successful Attacks
{[a.attack_id for a in self.attacks if a.succeeded]}

## Blocked Attacks
{[a.attack_id for a in self.attacks if a.detected and not a.succeeded]}

## Detection Gaps
{[a.attack_id for a in self.attacks if not a.detected]}

## Policy Changes
{[p.change_id for p in self.policy_changes]}

## Residual Risks
{[e.residual_risk for e in self.incident_log]}

## Revised Threat Model Scenarios
- Prompt-injected code tries DNS TXT exfil through allowed proxy.
- Co-tenant uses timing side channel to infer other tenant activity.
- Malicious dependency persists via background process in PID namespace.
- Red team abuses kill switch API with stolen tenant token.
- Sandbox error message leaks internal host path.

## False Positive Demonstration
Run benign suite: JSON parsing, scratch write, approved API call, CPU-bound calc.

## False Negative Demonstration
Earlier round missed slow DNS exfil; new rule: entropy + query rate + destination.

## POLA Debrief
Error messages did/did not leak host details. Kill switch returned clear status.

## Monkey-Patching Debrief
Live rounds used real enforcement. Fake backends were disabled by production factory.
"""

# Example attack templates
ATTACK_TEMPLATES = {
    1: [
        "open('/etc/passwd').read()",
        "open('/scratch/../etc/shadow').read()",
        "os.symlink('/etc/passwd', '/scratch/x')",
    ],
    2: [
        "socket.create_connection(('1.1.1.1', 443))",
        "dns.query.udp(DNSRecord(''.join(random).example.com'))",
        "requests.get('http://169.254.169.254/latest/meta-data/')",
    ],
    3: [
        "ctypes.CDLL(None).mount(...)",
        "os.setuid(0)",
        "libc.ptrace(PTRACE_ATTACH, 1, 0, 0)",
    ],
    4: [
        "while True: os.fork()",
        "bytearray(10**9)",
        "open('/scratch/big', 'wb').write(b'x' * 10**9)",
    ],
    5: [
        "os.fork(); time.sleep(3600)",
        "open('/scratch/.persist', 'w').write('x')",
        "shm = mmap.mmap(-1, 4096)",
    ],
}

# Example blue-team detection rules
DETECTION_RULE_EXAMPLES = [
    DetectionRule(1, "D-FS-01", "auditd", "openat denied for /etc/*", "high", "alert + kill"),
    DetectionRule(1, "D-FS-02", "auditd", "symlink target starts with /", "medium", "alert"),
    DetectionRule(2, "D-NET-01", "nftables", "connect to 169.254.169.254", "critical", "alert + kill"),
    DetectionRule(2, "D-NET-02", "dns", "query entropy > 4.5", "high", "rate-limit + alert"),
    DetectionRule(3, "D-SYS-01", "seccomp", "ptrace or mount syscall", "critical", "kill"),
    DetectionRule(4, "D-DOS-01", "cgroup", "pids.current > pids.max * 0.9", "high", "kill"),
    DetectionRule(5, "D-PERSIST-01", "process", "orphan process after execution", "high", "kill + alert"),
]

# Retrospective template
RETROSPECTIVE = [
    "What was the most valuable attack?",
    "What was the most valuable detection?",
    "What control gave the best return on effort?",
    "What assumption was proven wrong?",
    "What will you test next?",
]

if __name__ == "__main__":
    f = Facilitator()
    for round_num in range(1, 6):
        print(f.run_round(round_num))
    print(f.final_report())


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

"""
Exercise 1 solution: threat model + isolation decision record.
This module encodes the required artifacts as structured Python data and renders a report.
In production, this would be split into multiple documents and signed off by security/architecture.
"""

from dataclasses import dataclass, field
from typing import List, Dict

ASSETS = [
    {"id": "A01", "name": "Host kernel", "owner": "Platform", "impact": "critical"},
    {"id": "A02", "name": "Container runtime", "owner": "Platform", "impact": "critical"},
    {"id": "A03", "name": "Orchestrator process", "owner": "AI Platform", "impact": "critical"},
    {"id": "A04", "name": "Cloud metadata service", "owner": "Cloud Team", "impact": "critical"},
    {"id": "A05", "name": "Service-account tokens", "owner": "IAM", "impact": "critical"},
    {"id": "A06", "name": "Secrets-manager credentials", "owner": "Security", "impact": "critical"},
    {"id": "A07", "name": "Model weights", "owner": "ML Team", "impact": "high"},
    {"id": "A08", "name": "Prompt history", "owner": "Privacy", "impact": "high"},
    {"id": "A09", "name": "Other tenants' code", "owner": "Tenant Isolation", "impact": "critical"},
    {"id": "A10", "name": "Other tenants' outputs", "owner": "Tenant Isolation", "impact": "critical"},
    {"id": "A11", "name": "Audit logs", "owner": "Security", "impact": "high"},
    {"id": "A12", "name": "Billing limits", "owner": "Finance/Platform", "impact": "medium"},
    {"id": "A13", "name": "Network control plane", "owner": "Network Team", "impact": "critical"},
    {"id": "A14", "name": "Package registry credentials", "owner": "Supply Chain", "impact": "high"},
    {"id": "A15", "name": "Per-execution scratch volumes", "owner": "Platform", "impact": "medium"},
    {"id": "A16", "name": "Sandbox base images", "owner": "Supply Chain", "impact": "high"},
]

ADVERSARIES = [
    {
        "id": "ADV01", "name": "Malicious end user",
        "motivation": "Free compute, data theft, service abuse",
        "capability": "Can submit arbitrary code and metadata",
        "access": "Public API",
        "objectives": ["Exfiltrate secrets", "Mine crypto", "Attack internal services"],
    },
    {
        "id": "ADV02", "name": "Prompt-injected model",
        "motivation": "Follow injected instructions in input data",
        "capability": "Can generate adversarial code and tool calls",
        "access": "Inside orchestrator as code generator",
        "objectives": ["Read host files", "Reach metadata service", "Persist across runs"],
    },
    {
        "id": "ADV03", "name": "Compromised third-party dependency",
        "motivation": "Supply-chain implant or data theft",
        "capability": "Runs inside sandbox with app privileges",
        "access": "Sandbox user space",
        "objectives": ["Exfiltrate env", "Modify outputs", "Establish C2"],
    },
    {
        "id": "ADV04", "name": "Supply-chain attacker",
        "motivation": "Backdoor images, packages, runtimes",
        "capability": "Can publish malicious artifacts",
        "access": "Registry/package feed",
        "objectives": ["Compromise many tenants", "Steal cloud credentials"],
    },
    {
        "id": "ADV05", "name": "Malicious insider",
        "motivation": "Sabotage, espionage, financial gain",
        "capability": "Legitimate access to orchestrator or infra",
        "access": "Admin/operator",
        "objectives": ["Exfiltrate audit logs", "Disable controls", "Access model weights"],
    },
    {
        "id": "ADV06", "name": "Co-tenant",
        "motivation": "Cross-tenant data access or DoS",
        "capability": "Controls own sandbox execution",
        "access": "Tenant API",
        "objectives": ["Read other tenants' scratch", "Steal tokens", "Cause noisy-neighbor effects"],
    },
    {
        "id": "ADV07", "name": "Escaped sandbox process",
        "motivation": "Continue attack after container/VM breakout",
        "capability": "Host process context",
        "access": "Host user/kernel boundary",
        "objectives": ["Pivot to orchestrator", "Access cloud metadata", "Persist on host"],
    },
    {
        "id": "ADV08", "name": "External network attacker",
        "motivation": "Scan, exploit exposed sandbox services",
        "capability": "Internet-scale scanning and exploitation",
        "access": "Network",
        "objectives": ["Reach internal services", "Exploit orchestrator", "Exfiltrate data"],
    },
]

TRUST_BOUNDARIES = [
    "TB01: User/API -> Orchestrator",
    "TB02: Orchestrator -> Sandbox Launcher",
    "TB03: Sandbox Launcher -> Sandbox Runtime",
    "TB04: Sandbox Runtime -> Host Kernel",
    "TB05: Sandbox Runtime -> Filesystem",
    "TB06: Sandbox Runtime -> Network",
    "TB07: Sandbox Runtime -> Secrets Store",
    "TB08: Sandbox Runtime -> Package Registry",
    "TB09: Sandbox Runtime -> Observability Pipeline",
    "TB10: Orchestrator -> Audit Log Store",
]

DFD_MERMAID = """
flowchart LR
    U[User / API Client] -->|code, stdin, metadata| O[Orchestrator]
    O -->|validated request, control msg| L[Sandbox Launcher]
    L -->|sandbox spec| R[Sandbox Runtime]
    R -->|syscalls| K[Host Kernel]
    R -->|read/write| FS[Filesystem: ro root, ro input, rw scratch]
    R -->|egress attempt| N[Network Namespace / Proxy / Firewall]
    R -->|secret request| S[Secrets Broker]
    R -->|package fetch| P[Package Registry]
    R -->|logs, events| A[Audit / Observability]
    O -->|control, kill| L
    O -->|audit events| A
    FS -->|output data| O
    N -->|approved request| EXT[Approved External API]
    S -->|short-lived token| R
    A -->|forensics| SOC[Security Operations]
"""

ISOLATION_MATRIX = {
    "score_meaning": "1=weak/high risk/slow/expensive, 5=strong/low risk/fast/cheap. Compatibility: 5=excellent.",
    "criteria": [
        "kernel_attack_surface", "startup_latency", "memory_overhead",
        "python_compatibility", "javascript_compatibility", "shell_compatibility",
        "gpu_passthrough_feasibility", "filesystem_isolation", "network_isolation",
        "observability", "operational_complexity", "cost_per_execution",
        "supply_chain_risk", "known_escape_history",
    ],
    "options": {
        "plain_process_seccomp_namespaces": {
            "kernel_attack_surface": 2, "startup_latency": 5, "memory_overhead": 5,
            "python_compatibility": 5, "javascript_compatibility": 5, "shell_compatibility": 5,
            "gpu_passthrough_feasibility": 4, "filesystem_isolation": 3, "network_isolation": 3,
            "observability": 3, "operational_complexity": 2, "cost_per_execution": 5,
            "supply_chain_risk": 3, "known_escape_history": 2,
        },
        "ordinary_container_caps_dropped": {
            "kernel_attack_surface": 2, "startup_latency": 5, "memory_overhead": 4,
            "python_compatibility": 5, "javascript_compatibility": 5, "shell_compatibility": 5,
            "gpu_passthrough_feasibility": 4, "filesystem_isolation": 3, "network_isolation": 3,
            "observability": 3, "operational_complexity": 3, "cost_per_execution": 4,
            "supply_chain_risk": 3, "known_escape_history": 2,
        },
        "gvisor": {
            "kernel_attack_surface": 4, "startup_latency": 4, "memory_overhead": 3,
            "python_compatibility": 4, "javascript_compatibility": 4, "shell_compatibility": 4,
            "gpu_passthrough_feasibility": 2, "filesystem_isolation": 4, "network_isolation": 4,
            "observability": 4, "operational_complexity": 3, "cost_per_execution": 3,
            "supply_chain_risk": 4, "known_escape_history": 4,
        },
        "firecracker_microvm": {
            "kernel_attack_surface": 5, "startup_latency": 3, "memory_overhead": 3,
            "python_compatibility": 5, "javascript_compatibility": 5, "shell_compatibility": 5,
            "gpu_passthrough_feasibility": 2, "filesystem_isolation": 5, "network_isolation": 5,
            "observability": 4, "operational_complexity": 4, "cost_per_execution": 3,
            "supply_chain_risk": 4, "known_escape_history": 5,
        },
        "wasm_wasi": {
            "kernel_attack_surface": 5, "startup_latency": 5, "memory_overhead": 5,
            "python_compatibility": 2, "javascript_compatibility": 4, "shell_compatibility": 1,
            "gpu_passthrough_feasibility": 1, "filesystem_isolation": 4, "network_isolation": 4,
            "observability": 4, "operational_complexity": 4, "cost_per_execution": 5,
            "supply_chain_risk": 3, "known_escape_history": 4,
        },
        "full_virtual_machine": {
            "kernel_attack_surface": 5, "startup_latency": 1, "memory_overhead": 1,
            "python_compatibility": 5, "javascript_compatibility": 5, "shell_compatibility": 5,
            "gpu_passthrough_feasibility": 3, "filesystem_isolation": 5, "network_isolation": 5,
            "observability": 3, "operational_complexity": 2, "cost_per_execution": 1,
            "supply_chain_risk": 3, "known_escape_history": 4,
        },
    },
}

RESIDUAL_RISKS = [
    {"id": "R01", "threat": "Kernel 0-day in gVisor or host", "asset": "A01/A03", "control": "Patch cadence, microVM fallback", "likelihood": "low", "impact": "critical", "owner": "Platform Security", "validation": "Quarterly escape drill with known CVE PoC"},
    {"id": "R02", "threat": "Network exfiltration over allowed egress", "asset": "A04/A11", "control": "Egress proxy, DLP, rate limits", "likelihood": "medium", "impact": "high", "owner": "Network Security", "validation": "Red-team DNS/HTTP exfil test"},
    {"id": "R03", "threat": "Secrets leaked via environment", "asset": "A05/A06", "control": "Env scrub, secret broker", "likelihood": "low", "impact": "critical", "owner": "IAM", "validation": "Canary secret in env; alert if read"},
    {"id": "R04", "threat": "Co-tenant scratch access", "asset": "A09/A15", "control": "Per-exec tmpfs, namespaces", "likelihood": "low", "impact": "high", "owner": "Tenant Isolation", "validation": "Attempt to list/read another sandbox scratch"},
    {"id": "R05", "threat": "Audit log tampering", "asset": "A11", "control": "Append-only, off-host shipping", "likelihood": "low", "impact": "high", "owner": "SOC", "validation": "Attempt to delete/modify audit from sandbox"},
    {"id": "R06", "threat": "Fork bomb / DoS", "asset": "A03/A13", "control": "cgroup pids.max, kill switch", "likelihood": "medium", "impact": "medium", "owner": "Platform", "validation": "Fork bomb terminates under pids.max"},
    {"id": "R07", "threat": "Memory bomb", "asset": "A03/A15", "control": "cgroup memory.max, OOM kill", "likelihood": "medium", "impact": "medium", "owner": "Platform", "validation": "Memory bomb returns memory_limit_exceeded"},
    {"id": "R08", "threat": "Supply-chain malicious base image", "asset": "A16", "control": "Signed images, SBOM, scanning", "likelihood": "medium", "impact": "critical", "owner": "Supply Chain", "validation": "Unsigned image rejected by admission"},
    {"id": "R09", "threat": "Docker socket exposure", "asset": "A02/A03", "control": "Never mount socket, deny path", "likelihood": "low", "impact": "critical", "owner": "Platform", "validation": "Attempt to open /var/run/docker.sock"},
    {"id": "R10", "threat": "Cloud metadata access", "asset": "A04", "control": "Block 169.254.169.254, IMDSv2, network policy", "likelihood": "low", "impact": "critical", "owner": "Cloud Team", "validation": "Curl metadata from sandbox fails and logs"},
    {"id": "R11", "threat": "Persistence via background process", "asset": "A03/A15", "control": "PID namespace, cleanup, kill tree", "likelihood": "low", "impact": "high", "owner": "Platform", "validation": "After run, verify no orphan processes"},
    {"id": "R12", "threat": "Persistence via scratch file", "asset": "A15", "control": "tmpfs deletion, no shared dirs", "likelihood": "low", "impact": "medium", "owner": "Platform", "validation": "Run twice; second run cannot see first scratch"},
    {"id": "R13", "threat": "GPU passthrough escape", "asset": "A01/A07", "control": "No GPU by default, vGPU isolation", "likelihood": "medium", "impact": "critical", "owner": "ML Platform", "validation": "GPU tests only in approved profiles"},
    {"id": "R14", "threat": "Prompt history leakage via logs", "asset": "A08/A11", "control": "Redaction, field-level encryption", "likelihood": "medium", "impact": "high", "owner": "Privacy", "validation": "Log scan for prompt/PII patterns"},
    {"id": "R15", "threat": "Kill switch abused for DoS", "asset": "A03", "control": "Authz, tenant scoping, rate limit", "likelihood": "medium", "impact": "medium", "owner": "Platform", "validation": "Tenant cannot kill another tenant's sandbox"},
    {"id": "R16", "threat": "Billing limit bypass", "asset": "A12", "control": "Admission control, quotas", "likelihood": "medium", "impact": "medium", "owner": "Finance/Platform", "validation": "Exceed quota; requests rejected"},
]

STRIDE = {
    "Spoofing": ["Forged tenant ID in request", "Fake sandbox ID in kill API"],
    "Tampering": ["Modify code after validation", "Tamper audit logs", "Modify scratch output"],
    "Repudiation": ["Tenant denies executing attack", "Missing audit correlation IDs"],
    "InformationDisclosure": ["Secrets in env", "Cross-tenant scratch read", "Metadata service access"],
    "DenialOfService": ["Fork bomb", "Memory bomb", "Disk fill", "CPU starvation"],
    "ElevationOfPrivilege": ["Kernel exploit", "Misconfigured capabilities", "Namespace escape"],
}

LINDDUN = {
    "Linking": "Correlate prompts across tenants via shared IDs or timing.",
    "Identifying": "Prompts may contain PII; outputs may re-identify.",
    "Non-repudiation": "Audit logs may over-retain personal data.",
    "Detecting": "Tenant can detect other tenants by timing side channels.",
    "Data Disclosure": "Logs, scratch, and model outputs may leak personal data.",
    "Unawareness": "Users may not know code is executed in multi-tenant sandbox.",
    "Non-compliance": "GDPR/CCPA deletion requires deleting prompts, outputs, logs.",
}

ATTACK_TREES = {
    "steal_cloud_credentials": [
        "Read env vars -> find AWS_* -> exfiltrate",
        "Reach 169.254.169.254 -> get IAM role -> exfiltrate",
        "Read service-account token file -> use token -> exfiltrate",
        "Steal from orchestrator via mounted host path -> exfiltrate",
    ],
    "escape_to_host": [
        "Exploit kernel CVE -> gain host code exec",
        "Abuse privileged container -> mount host fs",
        "Escape gVisor -> syscall confusion -> host syscall",
        "Escape microVM -> virtio bug -> hypervisor escape",
    ],
    "exfiltrate_other_tenant_data": [
        "Guess scratch path -> read file",
        "Read /proc -> find other PIDs -> read mem",
        "Abuse shared volume -> overwrite symlink",
        "Timing side channel -> infer other tenant activity",
    ],
}

DECISION_RECORD = {
    "title": "ADR-001 Sandbox Isolation Layer",
    "status": "Accepted",
    "primary": "gVisor",
    "fallback": "Firecracker microVM",
    "assumptions": [
        "Workloads are short-lived (seconds to minutes)",
        "Python/JS/shell compatibility is required",
        "No GPU by default",
        "Egress is proxy-only and deny-by-default",
    ],
    "constraints": [
        "Multi-tenant isolation",
        "Auditable syscall and network events",
        "Cost per execution must be acceptable at 10k/day",
        "Operational team can run gVisor and Firecracker",
    ],
    "rejected": [
        {"option": "plain process + seccomp", "reason": "Shares host kernel; insufficient for adversarial code"},
        {"option": "ordinary container with caps dropped", "reason": "Container escape history and shared kernel risk"},
        {"option": "WASM/WASI", "reason": "Poor Python and shell compatibility; not suitable for general AI snippets"},
        {"option": "full VM", "reason": "Startup latency and memory overhead too high for per-request execution"},
    ],
    "re_evaluate_if": [
        "GPU workloads become first-class",
        "Startup latency SLA drops below 50ms",
        "Critical gVisor escape discovered",
        "Workloads routinely exceed 1 hour",
        "Regulatory requirement for hardware-backed isolation per tenant",
    ],
}

VALIDATION_PLAN = {
    "unit": [
        "Policy parser rejects unknown seccomp actions",
        "Path validator rejects .. and absolute symlinks",
        "Quota config defaults are deny-by-default",
    ],
    "integration": [
        "Benign Python/JS/shell suite passes in gVisor",
        "Egress proxy blocks unapproved domains",
        "Kill switch terminates fork bomb in <2s",
    ],
    "red_team_scenarios": [
        "Read /etc/passwd, /proc/1/environ, cloud metadata",
        "DNS exfiltration via TXT queries",
        "Kernel exploit PoC against gVisor",
        "Cross-tenant scratch path read",
        "Kill switch abuse by tenant A against tenant B",
    ],
    "drift_checks": [
        "Seccomp policy hash matches approved baseline",
        "No new capabilities in sandbox process",
        "Network namespace has no default route except proxy",
    ],
    "escape_drills": [
        "Quarterly: run known escape PoCs against gVisor and microVM",
        "After kernel CVE: re-run exploit and patch",
    ],
}

POLA = {
    "request": ["language", "code", "stdin", "timeout_seconds", "memory_mb", "network_policy"],
    "response": ["status", "stdout", "stderr", "exit_code", "duration_ms", "sandbox_id", "backend", "truncated", "killed", "policy_violations"],
    "headers": ["X-Sandbox-ID", "X-Sandbox-Backend", "X-Sandbox-Status", "X-Sandbox-Truncated", "X-Sandbox-Killed", "X-Trace-ID"],
    "side_effects": {
        "network": "deny by default unless network_policy explicitly allows",
        "filesystem": "read-only root/input; scratch is deleted unless retention policy allows",
        "secrets": "none unless short-lived token requested and audited",
    },
    "errors": ["invalid_request", "policy_violation", "timeout", "memory_limit", "runtime_error", "internal_error"],
}

MONKEY_PATCHING = {
    "risk": "Test doubles or monkey patches could disable seccomp, subprocess isolation, or audit logging.",
    "controls": [
        "Production entrypoint imports only production backends.",
        "Fake backend lives in `backends/fake.py` and is not imported by production factory.",
        "Factory refuses fake unless `SANDBOX_ENV == 'test'` and explicit `allow_fake=True`.",
        "Seccomp loader asserts not monkey-patched and verifies policy hash.",
        "Audit logger fails closed for high-severity events if sink unavailable.",
        "CI check greps for `monkeypatch` in production modules.",
    ],
}

def render_report() -> str:
    """Render a compact Markdown report from the structured data above."""
    return f"""# Threat Model Report

## Assets
{chr(10).join(f"- {a['id']}: {a['name']}" for a in ASSETS)}

## Adversaries
{chr(10).join(f"- {a['id']}: {a['name']} — {a['motivation']}" for a in ADVERSARIES)}

## Trust Boundaries
{chr(10).join(f"- {b}" for b in TRUST_BOUNDARIES)}

## Data Flow Diagram

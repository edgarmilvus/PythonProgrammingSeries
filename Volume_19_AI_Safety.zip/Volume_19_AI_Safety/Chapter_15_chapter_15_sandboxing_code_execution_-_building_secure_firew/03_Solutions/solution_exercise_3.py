
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

"""
Exercise 3 solution: filesystem and network policy for AI sandbox.
This module defines mount specs, path validation, egress allowlists, DNS controls,
anomaly thresholds, cleanup, POLA, and monkey-patching safety.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional
import ipaddress
import re

# 1. Filesystem layout.
@dataclass
class MountSpec:
    source: str
    target: str
    fstype: str
    options: List[str]
    read_only: bool = True

FILESYSTEM_LAYOUT = [
    MountSpec("/", "/", "overlay", ["ro", "nosuid", "nodev", "noexec"], True),
    MountSpec("/inputs/{request_id}", "/inputs", "bind", ["ro", "nosuid", "nodev", "noexec"], True),
    MountSpec("tmpfs", "/scratch", "tmpfs", ["rw", "nosuid", "nodev", "noexec", "size=64m", "nr_inodes=4096"], False),
    MountSpec("tmpfs", "/tmp", "tmpfs", ["rw", "nosuid", "nodev", "noexec", "size=16m", "nr_inodes=1024"], False),
]

DENIED_PATHS = [
    "/etc/shadow", "/etc/sudoers", "/etc/passwd",  # passwd often not needed; if needed, curated copy
    "/root", "/home", "/var/run/docker.sock", "/var/run/secrets",
    "/proc/kcore", "/proc/keys", "/proc/timer_list", "/proc/sched_debug",
    "/proc/sys", "/proc/irq", "/proc/1", "/proc/self/mem",
    "/dev/mem", "/dev/kmem", "/dev/port", "/dev/fuse",
]

MINIMAL_DEV = ["null", "zero", "random", "urandom"]  # tty only if required

def validate_path(path: str, scratch_root: str = "/scratch") -> bool:
    """Reject parent traversal, absolute symlinks, and hardlinks outside scratch."""
    if ".." in path.split("/"):
        return False
    real = path
    if real.startswith("/") and not real.startswith(scratch_root):
        return False
    if real.startswith("/scratch"):
        return True
    # For inputs, only allow /inputs/<approved file>
    return real.startswith("/inputs/")

def safe_symlink_target(target: str, scratch_root: str = "/scratch") -> bool:
    if target.startswith("/"):
        return False
    if ".." in target.split("/"):
        return False
    return True

# 2. Input materialization.
INPUT_POLICY = {
    "method": "copy-into-per-request-bind-mount",
    "source": "object storage or tenant-scoped input directory",
    "validation": "SHA-256 hash, size limit, content-type allowlist",
    "parent_directory_exposure": "never bind parent directories",
    "cleanup": "unmount and delete after execution",
}

# 3. Scratch policy.
SCRATCH_POLICY = {
    "per_execution": True,
    "fstype": "tmpfs",
    "size": "64m",
    "inodes": 4096,
    "shared": False,
    "predictable_host_path": False,
    "delete_after_execution": True,
}

# 4. Network policy.
BLOCKED_V4 = [
    ipaddress.ip_network("0.0.0.0/8"),
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("169.254.0.0/16"),  # cloud metadata
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("224.0.0.0/4"),
    ipaddress.ip_network("240.0.0.0/4"),
]
BLOCKED_V6 = [
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fc00::/7"),
    ipaddress.ip_network("fe80::/10"),
    ipaddress.ip_network("ff00::/8"),
]

ALLOWED_EGRESS = [
    {
        "fqdn": "api.example.com",
        "resolved_ips": ["203.0.113.10"],
        "port": 443,
        "protocol": "https",
        "methods": ["GET", "POST"],
        "path_regex": r"^/v1/approved/.*",
        "expires": "2026-12-31T00:00:00Z",
    },
]

PROXY_POLICY = {
    "enabled": True,
    "sandbox_has_direct_egress": False,
    "proxy_terminates_tls": True,
    "deny_http_connect": True,
    "strip_headers": ["Authorization", "Cookie", "X-Forwarded-For"],
    "log_request": True,
    "log_response": True,
}

DNS_POLICY = {
    "allowed": False,  # static hosts or proxy preferred
    "resolver": "controlled-resolver.internal",
    "max_query_length": 63,
    "max_queries_per_sec": 5,
    "entropy_threshold": 4.5,
    "log_queries": True,
    "block_unauthorized_domains": True,
}

def is_blocked_ip(ip: str) -> bool:
    addr = ipaddress.ip_address(ip)
    if addr.version == 4:
        return any(addr in net for net in BLOCKED_V4)
    return any(addr in net for net in BLOCKED_V6)

# 5. Anomaly thresholds.
ANOMALY_THRESHOLDS = {
    "dns_query_entropy": 4.5,
    "connections_per_sec": 10,
    "denied_paths_per_min": 5,
    "file_writes_per_sec": 1000,
    "proc_access_per_min": 3,
    "cpu_steal_percent": 20,
}

# 6. Audit signals.
AUDIT_EVENTS = [
    "file_open_allowed", "file_open_denied", "file_write_scratch",
    "symlink_rejected", "hardlink_rejected",
    "network_connect_allowed", "network_connect_denied",
    "dns_query", "dns_query_blocked",
    "proxy_request", "proxy_denied",
    "scratch_cleanup", "process_cleanup",
]

# 7. Cleanup and revocation.
CLEANUP_CHECKLIST = [
    "Unmount input bind mounts.",
    "Delete scratch tmpfs and all files.",
    "Revoke short-lived tokens via secrets broker.",
    "Flush audit logs to off-host sink.",
    "Verify no processes remain in sandbox PID namespace.",
    "Validate output files in quarantine before returning.",
]

# 8. Test matrix.
FS_NET_TESTS = [
    {"id": "T01", "case": "read approved input", "expected": "ok", "signal": "file_open_allowed"},
    {"id": "T02", "case": "write scratch", "expected": "ok", "signal": "file_write_scratch"},
    {"id": "T03", "case": "read /etc/passwd", "expected": "denied", "signal": "file_open_denied"},
    {"id": "T04", "case": "read /etc/shadow", "expected": "denied", "signal": "file_open_denied"},
    {"id": "T05", "case": "read /proc/1/environ", "expected": "denied", "signal": "file_open_denied"},
    {"id": "T06", "case": "open /var/run/docker.sock", "expected": "denied", "signal": "file_open_denied"},
    {"id": "T07", "case": "symlink /scratch/x -> /etc/passwd", "expected": "denied", "signal": "symlink_rejected"},
    {"id": "T08", "case": "hardlink to /etc/passwd", "expected": "denied", "signal": "hardlink_rejected"},
    {"id": "T09", "case": "path traversal ../../etc/passwd", "expected": "denied", "signal": "file_open_denied"},
    {"id": "T10", "case": "write outside scratch", "expected": "denied", "signal": "file_open_denied"},
    {"id": "T11", "case": "connect to 1.1.1.1:443", "expected": "denied", "signal": "network_connect_denied"},
    {"id": "T12", "case": "connect to 169.254.169.254", "expected": "denied", "signal": "network_connect_denied"},
    {"id": "T13", "case": "connect to approved api.example.com", "expected": "allowed via proxy", "signal": "proxy_request"},
    {"id": "T14", "case": "HTTP CONNECT to unapproved host", "expected": "denied", "signal": "proxy_denied"},
    {"id": "T15", "case": "DNS query long random label", "expected": "denied/alert", "signal": "dns_query_blocked"},
    {"id": "T16", "case": "IPv6 bypass attempt", "expected": "denied", "signal": "network_connect_denied"},
    {"id": "T17", "case": "bind socket", "expected": "denied", "signal": "network_connect_denied"},
    {"id": "T18", "case": "raw socket", "expected": "denied", "signal": "network_connect_denied"},
    {"id": "T19", "case": "read /dev/mem", "expected": "denied", "signal": "file_open_denied"},
    {"id": "T20", "case": "mount tmpfs", "expected": "denied", "signal": "file_open_denied"},
    {"id": "T21", "case": "write 100MB to scratch", "expected": "denied", "signal": "file_write_scratch"},
    {"id": "T22", "case": "create 10k inodes", "expected": "denied", "signal": "file_write_scratch"},
    {"id": "T23", "case": "read /proc/sys/kernel", "expected": "denied", "signal": "file_open_denied"},
    {"id": "T24", "case": "read /proc/self/mem", "expected": "denied", "signal": "file_open_denied"},
    {"id": "T25", "case": "access cloud metadata via proxy", "expected": "denied", "signal": "proxy_denied"},
    {"id": "T26", "case": "DNS rebinding allowed domain -> blocked IP", "expected": "denied", "signal": "network_connect_denied"},
    {"id": "T27", "case": "TOCTOU input swap", "expected": "denied", "signal": "file_open_denied"},
    {"id": "T28", "case": "side-channel via file size", "expected": "alert", "signal": "anomaly"},
    {"id": "T29", "case": "cleanup after execution", "expected": "ok", "signal": "scratch_cleanup"},
    {"id": "T30", "case": "revoke token after execution", "expected": "ok", "signal": "scratch_cleanup"},
]

# 9. POLA.
POLA = {
    "caller_expectations": [
        "No network by default.",
        "Only /scratch is writable.",
        "Inputs are read-only.",
        "Scratch is deleted after execution unless retention policy allows.",
        "Errors never reveal host paths or internal IPs.",
    ],
    "error_codes": ["input_not_found", "egress_denied", "filesystem_denied", "quota_exceeded", "internal_error"],
}

# 10. Monkey-patching safety.
MONKEY_PATCHING_SAFETY = {
    "rules": [
        "Test doubles for sockets live in tests/doubles and are never imported by production.",
        "Production network layer imports `network_policy` only; tests use dependency injection.",
        "Filesystem test doubles cannot replace real path validator in production entrypoint.",
        "CI greps production modules for `unittest.mock`, `monkeypatch`, and `fake_network`.",
    ]
}


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

"""
Exercise 2 solution: seccomp/capability policy, audit schema, kill switch, and test matrix.
This is a policy module plus enforcement helpers. The actual seccomp BPF loading would use
libseccomp, a Go/Rust helper, or a system call wrapper outside this Python module.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List, Dict

# 1. Default action.
# EPERM is chosen as default for unknown syscalls to preserve debuggability and avoid
# abrupt kills for benign-but-unknown syscalls. High-risk syscalls get KILL_PROCESS.
DEFAULT_ACTION = "SCMP_ACT_ERRNO(EPERM)"
FATAL_ACTION = "SCMP_ACT_KILL_PROCESS"

# 2. Allowlist required for CPython startup and ordinary scientific/text processing.
ALLOWED_SYSCALLS = {
    # memory
    "brk", "mmap", "mprotect", "munmap", "madvise",
    # file descriptors and basic I/O
    "read", "write", "close", "fstat", "newfstatat", "lseek", "pread64", "pwrite64",
    "openat", "openat2", "getdents64", "fcntl", "statx", "ftruncate",
    # process/thread
    "clone", "clone3",  # clone3 must be arg-filtered: deny namespace flags
    "exit", "exit_group", "getpid", "gettid", "getppid", "set_tid_address", "set_robust_list",
    "futex", "rseq", "prlimit64", "sched_yield", "sched_getaffinity",
    # signals
    "rt_sigaction", "rt_sigprocmask", "rt_sigreturn", "sigaltstack", "tgkill",
    # time
    "nanosleep", "clock_gettime", "clock_nanosleep", "gettimeofday",
    # randomness
    "getrandom",
    # arch / identity
    "arch_prctl", "getuid", "geteuid", "getgid", "getegid", "uname",
    # misc harmless
    "ioctl",  # only for tty/pipe; not device control
    "dup", "dup2", "dup3", "pipe2", "eventfd2", "epoll_create1", "epoll_ctl", "epoll_wait",
    "wait4", "waitid", "capget", "capset",
}

# 3. Explicit high-risk denials. Some are redundant with capability drops (defense in depth).
DENIED_SYSCALLS = {
    # introspection / memory
    "ptrace", "process_vm_readv", "process_vm_writev", "kcmp",
    # mount / namespace
    "mount", "umount2", "pivot_root", "chroot", "unshare", "setns",
    "move_mount", "fsopen", "fsconfig", "fsmount", "open_tree", "mount_setattr",
    # kernel modules / bpf / perf
    "init_module", "finit_module", "delete_module", "bpf", "perf_event_open",
    "kexec_load", "kexec_file_load",
    # file handles / keys
    "open_by_handle_at", "name_to_handle_at", "keyctl", "add_key", "request_key",
    # userfault / io_uring
    "userfaultfd", "io_uring_setup", "io_uring_enter", "io_uring_register",
    # network
    "socket", "connect", "bind", "listen", "accept", "accept4",
    "sendto", "recvfrom", "sendmsg", "recvmsg", "setsockopt", "getsockopt",
    "socketpair", "sendmmsg", "recvmmsg",
    # system control
    "reboot", "sethostname", "setdomainname", "adjtimex", "clock_adjtime",
    "settimeofday", "stime", "acct", "swapon", "swapoff", "quotactl",
    "syslog", "vhangup", "landlock", "landlock_create_ruleset", "landlock_add_rule",
    "landlock_restrict_self",
}

# 4. Capability drop checklist.
CAPABILITIES_TO_DROP = [
    "CAP_SYS_ADMIN", "CAP_NET_ADMIN", "CAP_NET_RAW", "CAP_SYS_PTRACE",
    "CAP_SYS_MODULE", "CAP_DAC_READ_SEARCH", "CAP_DAC_OVERRIDE",
    "CAP_CHOWN", "CAP_FOWNER", "CAP_SETUID", "CAP_SETGID", "CAP_MKNOD",
    "CAP_AUDIT_CONTROL", "CAP_AUDIT_READ", "CAP_BPF", "CAP_PERFMON",
    "CAP_CHECKPOINT_RESTORE", "CAP_SYS_CHROOT", "CAP_SYS_BOOT",
    "CAP_SYS_TIME", "CAP_SYS_TTY_CONFIG", "CAP_LEASE", "CAP_AUDIT_WRITE",
    "CAP_MAC_OVERRIDE", "CAP_MAC_ADMIN", "CAP_SYSLOG", "CAP_WAKE_ALARM",
    "CAP_BLOCK_SUSPEND", "CAP_SYS_RAWIO", "CAP_IPC_LOCK", "CAP_IPC_OWNER",
    "CAP_SYS_NICE", "CAP_SYS_RESOURCE", "CAP_SYS_PACCT", "CAP_SYS_ADMIN",
]

def drop_all_capabilities() -> None:
    """
    Fail-closed capability drop. In a real implementation:
    1. setgroups([]), setgid(nonroot), setuid(nonroot)
    2. prctl(PR_SET_NO_NEW_PRIVS, 1)
    3. prctl(PR_CAPBSET_DROP, cap) for every cap
    4. capset with zero effective/permitted/inheritable
    """
    raise NotImplementedError("Use libcap/prctl in the launcher; never continue if a drop fails.")

# 5. Violation handling.
VIOLATION_POLICY = {
    "DEFAULT_EPERM": {"fatal": False, "log": True, "anomaly_score": 1},
    "FATAL_SYSCALL": {"fatal": True, "log": True, "severity": "high", "kill": True},
    "RATE_LIMITED": {"fatal": False, "log": True, "max_per_sec": 5},
    "RESTRICTED_FLAGS": {"fatal": True, "examples": ["clone3 with namespace flags", "openat with O_TMPFILE outside scratch"]},
}

# 6. Audit log schema.
AUDIT_SCHEMA = {
    "request_id": "uuid",
    "tenant_id": "string",
    "sandbox_id": "string",
    "timestamp": "RFC3339Nano",
    "pid": "int",
    "syscall_number": "int",
    "syscall_name": "string",
    "args": "redacted tuple or hash",
    "decision": "allow|deny|kill|rate_limit",
    "errno": "int|null",
    "process_name": "string",
    "executable_path": "string",
    "code_hash": "sha256",
    "severity": "info|warning|high|critical",
}

# 7. Kill switch design.
class KillScope(Enum):
    REQUEST = "request"
    TENANT = "tenant"
    GLOBAL = "global"

@dataclass
class KillSwitch:
    cgroup_root: str = "/sys/fs/cgroup/sandbox"

    def kill_request(self, sandbox_id: str) -> Dict:
        # Write to cgroup.kill for the sandbox cgroup. This kills the whole process tree.
        return {"status": "killed", "scope": "request", "sandbox_id": sandbox_id}

    def kill_tenant(self, tenant_id: str) -> Dict:
        return {"status": "killed", "scope": "tenant", "tenant_id": tenant_id}

    def kill_global(self) -> Dict:
        return {"status": "killed", "scope": "global"}

# 8. Resource quotas.
@dataclass
class ResourceQuotas:
    cpu_time_sec: int = 5
    wall_time_sec: int = 10
    memory_mb: int = 512
    pids_max: int = 32
    open_fds: int = 64
    file_size_mb: int = 64
    syscalls_per_sec: int = 5000

# 9. Test matrix.
BENIGN_TESTS = [
    {"name": "arithmetic", "expected": "ok", "exit": 0, "audit": "none", "proves": "compat"},
    {"name": "string manipulation", "expected": "ok", "exit": 0, "audit": "none", "proves": "compat"},
    {"name": "json parse", "expected": "ok", "exit": 0, "audit": "none", "proves": "compat"},
    {"name": "sorting", "expected": "ok", "exit": 0, "audit": "none", "proves": "compat"},
    {"name": "exception handling", "expected": "runtime_error", "exit": 1, "audit": "none", "proves": "compat"},
    {"name": "stdin read", "expected": "ok", "exit": 0, "audit": "none", "proves": "compat"},
    {"name": "import math", "expected": "ok", "exit": 0, "audit": "none", "proves": "compat"},
    {"name": "import json", "expected": "ok", "exit": 0, "audit": "none", "proves": "compat"},
    {"name": "small scratch write", "expected": "ok", "exit": 0, "audit": "none", "proves": "compat"},
    {"name": "thread creation within limit", "expected": "ok", "exit": 0, "audit": "none", "proves": "compat"},
    {"name": "numpy if approved", "expected": "ok", "exit": 0, "audit": "none", "proves": "compat"},
    {"name": "csv parse", "expected": "ok", "exit": 0, "audit": "none", "proves": "compat"},
    {"name": "regex", "expected": "ok", "exit": 0, "audit": "none", "proves": "compat"},
    {"name": "datetime", "expected": "ok", "exit": 0, "audit": "none", "proves": "compat"},
    {"name": "hashlib", "expected": "ok", "exit": 0, "audit": "none", "proves": "compat"},
    {"name": "base64", "expected": "ok", "exit": 0, "audit": "none", "proves": "compat"},
    {"name": "tempfile in scratch", "expected": "ok", "exit": 0, "audit": "none", "proves": "compat"},
    {"name": "subprocess not used", "expected": "ok", "exit": 0, "audit": "none", "proves": "compat"},
    {"name": "sleep 1s", "expected": "ok", "exit": 0, "audit": "none", "proves": "compat"},
    {"name": "cpu-bound 100ms", "expected": "ok", "exit": 0, "audit": "none", "proves": "compat"},
]

MALICIOUS_TESTS = [
    {"name": "fork bomb", "expected": "policy_violation", "exit": 137, "audit": "pids.max", "proves": "security"},
    {"name": "memory bomb", "expected": "memory_limit", "exit": 137, "audit": "memory.max", "proves": "security"},
    {"name": "infinite loop", "expected": "timeout", "exit": 124, "audit": "wall_time", "proves": "security"},
    {"name": "read /etc/passwd", "expected": "policy_violation", "exit": 1, "audit": "openat denied", "proves": "security"},
    {"name": "write /etc/hosts", "expected": "policy_violation", "exit": 1, "audit": "openat denied", "proves": "security"},
    {"name": "connect 1.1.1.1", "expected": "policy_violation", "exit": 1, "audit": "socket denied", "proves": "security"},
    {"name": "bind socket", "expected": "policy_violation", "exit": 1, "audit": "socket denied", "proves": "security"},
    {"name": "ptrace other", "expected": "policy_violation", "exit": 137, "audit": "ptrace kill", "proves": "security"},
    {"name": "mount tmpfs", "expected": "policy_violation", "exit": 137, "audit": "mount kill", "proves": "security"},
    {"name": "load module", "expected": "policy_violation", "exit": 137, "audit": "init_module kill", "proves": "security"},
    {"name": "setuid", "expected": "policy_violation", "exit": 1, "audit": "setuid denied", "proves": "security"},
    {"name": "RLIMIT_NOFILE bypass", "expected": "policy_violation", "exit": 1, "audit": "prlimit64 denied", "proves": "security"},
    {"name": "read /proc/self/mem", "expected": "policy_violation", "exit": 1, "audit": "openat denied", "proves": "security"},
    {"name": "raw socket", "expected": "policy_violation", "exit": 1, "audit": "socket denied", "proves": "security"},
    {"name": "io_uring", "expected": "policy_violation", "exit": 137, "audit": "io_uring kill", "proves": "security"},
    {"name": "unshare namespace", "expected": "policy_violation", "exit": 137, "audit": "unshare kill", "proves": "security"},
    {"name": "bpf load", "expected": "policy_violation", "exit": 137, "audit": "bpf kill", "proves": "security"},
    {"name": "perf_event_open", "expected": "policy_violation", "exit": 137, "audit": "perf kill", "proves": "security"},
    {"name": "keyctl", "expected": "policy_violation", "exit": 1, "audit": "keyctl denied", "proves": "security"},
    {"name": "open_by_handle_at", "expected": "policy_violation", "exit": 137, "audit": "open_by_handle kill", "proves": "security"},
]

# 10. POLA response schema.
@dataclass
class SandboxResponse:
    status: str  # ok, timeout, memory_limit, policy_violation, runtime_error, internal_error
    stdout: str
    stderr: str
    exit_code: Optional[int]
    duration_ms: int
    sandbox_id: str
    policy_violations: List[Dict] = field(default_factory=list)

# 11. Monkey-patching guard.
def production_policy_loader():
    import os
    if os.getenv("SANDBOX_ENV") == "test":
        raise RuntimeError("Production policy loader must not run in test mode")
    # Load real seccomp policy from signed baseline. Verify hash.
    return {"loaded": True, "hash": "sha256:baseline"}

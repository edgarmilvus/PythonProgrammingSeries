
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

#!/usr/bin/env python3
"""Run untrusted AI-generated Python code in a hardened Docker sandbox."""
import json, shutil, subprocess, tempfile, time, uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

# Policy object makes the safety-versus-capability dial explicit and auditable.
@dataclass
class SandboxPolicy:
    memory: str = "256m"
    cpus: str = "0.5"
    pids_limit: int = 64
    timeout_seconds: int = 10
    network: str = "none"
    egress_allowlist: List[str] = field(default_factory=list)
    seccomp_profile: Optional[Path] = None
    user: str = "65534:65534"

class SandboxRunner:
    """Coordinates one untrusted execution with defense-in-depth."""
    def __init__(self, policy: SandboxPolicy):
        self.policy = policy
        self.run_id = uuid.uuid4().hex[:12]
        self.workdir = Path(tempfile.mkdtemp(prefix=f"ai-sandbox-{self.run_id}-"))
        self.input_dir = self.workdir / "input"
        self.output_dir = self.workdir / "output"
        self.input_dir.mkdir(); self.output_dir.mkdir()

    def write_untrusted_code(self, code: str) -> Path:
        # Untrusted code is data: write it to a read-only mount later.
        target = self.input_dir / "agent_task.py"
        target.write_text(code, encoding="utf-8")
        return target

    def _build_docker_command(self) -> List[str]:
        # Start from a minimal, ephemeral container and remove it automatically.
        cmd = ["docker", "run", "--rm", "--name", f"sandbox-{self.run_id}"]
        # Filesystem isolation: read-only root, small noexec tmpfs for scratch.
        cmd += ["--read-only", "--tmpfs", "/tmp:rw,noexec,nosuid,size=64m"]
        cmd += ["--tmpfs", "/run:rw,noexec,nosuid,size=16m"]
        # Privilege isolation: drop all capabilities and forbid privilege gain.
        cmd += ["--cap-drop", "ALL", "--security-opt", "no-new-privileges"]
        cmd += ["--user", self.policy.user]
        # Resource quotas prevent fork bombs, cryptojacking, and memory exhaustion.
        cmd += ["--pids-limit", str(self.policy.pids_limit)]
        cmd += ["--memory", self.policy.memory, "--cpus", self.policy.cpus]
        cmd += ["--ulimit", "nofile=64:64"]
        # Syscall firewall: a custom seccomp profile blocks risky syscalls.
        if self.policy.seccomp_profile:
            cmd += ["--security-opt", f"seccomp={self.policy.seccomp_profile}"]
        # Network firewall: default deny; egress only through an allowlisting proxy.
        if self.policy.egress_allowlist:
            cmd += ["--network", "sandbox-egress"]
            cmd += ["-e", "HTTPS_PROXY=http://egress-proxy:3128"]
            cmd += ["-e", "HTTP_PROXY=http://egress-proxy:3128"]
            cmd += ["-e", "NO_PROXY=localhost,127.0.0.1"]
        else:
            cmd += ["--network", self.policy.network]
        # Secrets isolation: no host env, no secrets mount, no Docker socket.
        cmd += ["-e", "PYTHONUNBUFFERED=1", "-e", "HOME=/tmp"]
        # Mount only read-only input and writable output directories.
        cmd += ["-v", f"{self.input_dir}:/input:ro"]
        cmd += ["-v", f"{self.output_dir}:/output:rw"]
        # Use a minimal image with no build tools where possible.
        cmd += ["python:3.11-slim", "python", "/input/agent_task.py"]
        return cmd

    def _detect_anomaly(self, proc: subprocess.CompletedProcess) -> Optional[str]:
        # Heuristic anomaly detection on bounded output; not a replacement for audit.
        blob = (proc.stdout + proc.stderr).lower()
        suspicious = ["/etc/shadow", "socket", "connect", "ptrace", "mount", "fork"]
        for token in suspicious:
            if token in blob:
                return f"suspicious_token:{token}"
        if len(proc.stdout) > 100_000:
            return "output_flood"
        if proc.returncode not in (0, 1):
            return f"unexpected_returncode:{proc.returncode}"
        return None

    def execute(self, code: str) -> dict:
        # EAFP: attempt the run, then handle timeout and environment failures.
        self.write_untrusted_code(code)
        cmd = self._build_docker_command()
        audit = {"run_id": self.run_id, "cmd": cmd, "start": time.time()}
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True,
                                  timeout=self.policy.timeout_seconds)
            audit.update({"returncode": proc.returncode,
                          "stdout": proc.stdout[-2000:],
                          "stderr": proc.stderr[-2000:],
                          "duration": time.time() - audit["start"]})
            anomaly = self._detect_anomaly(proc)
            audit["anomaly"] = anomaly
            return {"ok": proc.returncode == 0 and anomaly is None, "audit": audit}
        except subprocess.TimeoutExpired as exc:
            # Kill switch: stop the container, then let --rm clean it up.
            subprocess.run(["docker", "kill", f"sandbox-{self.run_id}"],
                           capture_output=True, text=True)
            audit.update({"error": "timeout",
                          "stdout": (exc.stdout or "")[-2000:],
                          "stderr": (exc.stderr or "")[-2000:]})
            return {"ok": False, "audit": audit}
        finally:
            # Clean local mounts; never trust untrusted code to clean up.
            shutil.rmtree(self.workdir, ignore_errors=True)

def red_team_validation() -> None:
    # Validate that known escape probes fail closed before trusting the sandbox.
    runner = SandboxRunner(SandboxPolicy(timeout_seconds=5, network="none"))
    probes = ["import os; os.system('cat /etc/shadow')",
              "import socket; socket.socket().connect(('1.1.1.1', 80))",
              "import os; os.system('mount')",
              "import os; os.setuid(0)"]
    for probe in probes:
        result = runner.execute(probe)
        assert not result["ok"], f"escape probe succeeded: {probe}"
    print("red-team validation passed: all probes blocked")

if __name__ == "__main__":
    # Demo: an AI agent proposes a harmless data task, but we still sandbox it.
    generated = ("import os\nprint('hello from sandbox')\n"
                 "open('/output/result.txt', 'w').write('ok')\n")
    runner = SandboxRunner(SandboxPolicy(timeout_seconds=8))
    print(json.dumps(runner.execute(generated), indent=2))

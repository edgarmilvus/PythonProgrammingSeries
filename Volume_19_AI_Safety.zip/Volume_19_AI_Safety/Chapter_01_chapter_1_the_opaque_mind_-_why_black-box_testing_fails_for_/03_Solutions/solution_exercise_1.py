
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# app/config.py
import os

class Config:
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = os.getenv("SECRET_KEY", "dev")

class DevelopmentConfig(Config):
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = os.getenv("DEV_DATABASE_URL", "sqlite:///dev.db")

class TestingConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    WTF_CSRF_ENABLED = False

class ProductionConfig(Config):
    SQLALCHEMY_DATABASE_URI = os.environ["DATABASE_URL"]

config = {
    "development": DevelopmentConfig,
    "testing": TestingConfig,
    "production": ProductionConfig,
    "default": DevelopmentConfig,
}

# app/__init__.py
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from .config import config

db = SQLAlchemy()

def create_app(config_name="default"):
    app = Flask(__name__)
    app.config.from_object(config[config_name])

    db.init_app(app)

    from .evaluation.routes import evaluation_bp
    from .audit.routes import audit_bp

    app.register_blueprint(evaluation_bp, url_prefix="/api")
    app.register_blueprint(audit_bp, url_prefix="/api")

    with app.app_context():
        db.create_all()

    return app

# app/models.py
from datetime import datetime
from . import db

class EvaluationRun(db.Model):
    __tablename__ = "evaluation_runs"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    model_name = db.Column(db.String(255), nullable=False)
    model_version = db.Column(db.String(255))
    config_json = db.Column(db.JSON, default=dict)
    started_at = db.Column(db.DateTime, default=datetime.utcnow)
    finished_at = db.Column(db.DateTime)
    status = db.Column(db.String(50), nullable=False, default="pending")

    test_cases = db.relationship("TestCase", backref="run", cascade="all, delete-orphan")
    flags = db.relationship("AuditFlag", backref="run", cascade="all, delete-orphan")

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "model_name": self.model_name,
            "model_version": self.model_version,
            "config_json": self.config_json,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "finished_at": self.finished_at.isoformat() if self.finished_at else None,
            "status": self.status,
        }

class TestCase(db.Model):
    __tablename__ = "test_cases"
    id = db.Column(db.Integer, primary_key=True)
    run_id = db.Column(db.Integer, db.ForeignKey("evaluation_runs.id"), nullable=False)
    prompt_text = db.Column(db.Text, nullable=False)
    expected_behavior = db.Column(db.Text)
    category = db.Column(db.String(50), nullable=False, default="benign")
    metadata_json = db.Column(db.JSON, default=dict)

    responses = db.relationship("ModelResponse", backref="test_case", cascade="all, delete-orphan")

class ModelResponse(db.Model):
    __tablename__ = "model_responses"
    id = db.Column(db.Integer, primary_key=True)
    test_case_id = db.Column(db.Integer, db.ForeignKey("test_cases.id"), nullable=False)
    response_text = db.Column(db.Text, nullable=False)
    latency_ms = db.Column(db.Integer)
    token_count = db.Column(db.Integer)
    finish_reason = db.Column(db.String(50))
    raw_response_json = db.Column(db.JSON, default=dict)

    scores = db.relationship("ObservedScore", backref="response", cascade="all, delete-orphan")

class ObservedScore(db.Model):
    __tablename__ = "observed_scores"
    id = db.Column(db.Integer, primary_key=True)
    response_id = db.Column(db.Integer, db.ForeignKey("model_responses.id"), nullable=False)
    scorer_name = db.Column(db.String(255), nullable=False)
    score = db.Column(db.Float)
    label = db.Column(db.String(100))
    notes = db.Column(db.Text)

class AuditFlag(db.Model):
    __tablename__ = "audit_flags"
    id = db.Column(db.Integer, primary_key=True)
    run_id = db.Column(db.Integer, db.ForeignKey("evaluation_runs.id"), nullable=False)
    test_case_id = db.Column(db.Integer, db.ForeignKey("test_cases.id"))
    flag_type = db.Column(db.String(100), nullable=False)
    severity = db.Column(db.String(50), nullable=False, default="medium")
    description = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# app/evaluation/routes.py
from datetime import datetime
from flask import Blueprint, request, jsonify
from .. import db
from ..models import EvaluationRun, TestCase, ModelResponse, ObservedScore

evaluation_bp = Blueprint("evaluation", __name__)

@evaluation_bp.post("/runs")
def create_run():
    data = request.get_json(force=True)
    run = EvaluationRun(
        name=data["name"],
        model_name=data["model_name"],
        model_version=data.get("model_version"),
        config_json=data.get("config_json", {}),
        status=data.get("status", "pending"),
    )
    db.session.add(run)
    db.session.commit()
    return jsonify(run.to_dict()), 201

@evaluation_bp.post("/runs/<int:run_id>/test-cases")
def add_test_case(run_id):
    run = EvaluationRun.query.get_or_404(run_id)
    data = request.get_json(force=True)
    tc = TestCase(
        run_id=run.id,
        prompt_text=data["prompt_text"],
        expected_behavior=data.get("expected_behavior"),
        category=data.get("category", "benign"),
        metadata_json=data.get("metadata_json", {}),
    )
    db.session.add(tc)
    db.session.commit()
    return jsonify({"id": tc.id, "run_id": tc.run_id}), 201

@evaluation_bp.post("/test-cases/<int:test_case_id>/responses")
def record_response(test_case_id):
    tc = TestCase.query.get_or_404(test_case_id)
    data = request.get_json(force=True)
    response = ModelResponse(
        test_case_id=tc.id,
        response_text=data["response_text"],
        latency_ms=data.get("latency_ms"),
        token_count=data.get("token_count"),
        finish_reason=data.get("finish_reason"),
        raw_response_json=data.get("raw_response_json", {}),
    )
    db.session.add(response)
    db.session.commit()
    return jsonify({"id": response.id, "test_case_id": response.test_case_id}), 201

@evaluation_bp.post("/responses/<int:response_id>/scores")
def record_score(response_id):
    response = ModelResponse.query.get_or_404(response_id)
    data = request.get_json(force=True)
    score = ObservedScore(
        response_id=response.id,
        scorer_name=data["scorer_name"],
        score=data.get("score"),
        label=data.get("label"),
        notes=data.get("notes"),
    )
    db.session.add(score)
    db.session.commit()
    return jsonify({"id": score.id, "response_id": score.response_id}), 201

@evaluation_bp.patch("/runs/<int:run_id>/status")
def update_run_status(run_id):
    run = EvaluationRun.query.get_or_404(run_id)
    data = request.get_json(force=True)
    run.status = data["status"]
    if run.status in {"finished", "failed", "completed"}:
        run.finished_at = datetime.utcnow()
    db.session.commit()
    return jsonify(run.to_dict()), 200

# app/audit/routes.py
from flask import Blueprint, jsonify
from ..models import EvaluationRun, AuditFlag, TestCase, ModelResponse, ObservedScore

audit_bp = Blueprint("audit", __name__)

@audit_bp.get("/runs/<int:run_id>/flags")
def list_flags(run_id):
    EvaluationRun.query.get_or_404(run_id)
    flags = AuditFlag.query.filter_by(run_id=run_id).all()
    return jsonify([
        {
            "id": f.id,
            "run_id": f.run_id,
            "test_case_id": f.test_case_id,
            "flag_type": f.flag_type,
            "severity": f.severity,
            "description": f.description,
            "created_at": f.created_at.isoformat(),
        }
        for f in flags
    ])

@audit_bp.get("/runs/<int:run_id>/discrepancies")
def list_discrepancies(run_id):
    run = EvaluationRun.query.get_or_404(run_id)
    out = []
    for tc in run.test_cases:
        for resp in tc.responses:
            if tc.expected_behavior and tc.expected_behavior not in resp.response_text:
                out.append({
                    "type": "expected_behavior_mismatch",
                    "test_case_id": tc.id,
                    "response_id": resp.id,
                    "expected": tc.expected_behavior,
                    "actual": resp.response_text,
                })
            labels = {s.label for s in resp.scores if s.label}
            scores = {s.score for s in resp.scores if s.score is not None}
            if len(labels) > 1 or len(scores) > 1:
                out.append({
                    "type": "scorer_inconsistency",
                    "test_case_id": tc.id,
                    "response_id": resp.id,
                    "labels": list(labels),
                    "scores": list(scores),
                })
    return jsonify(out)

@audit_bp.get("/audit/export/<int:run_id>")
def export_run(run_id):
    run = EvaluationRun.query.get_or_404(run_id)
    bundle = {
        "run": run.to_dict(),
        "test_cases": [],
        "responses": [],
        "scores": [],
        "flags": [],
    }
    for tc in run.test_cases:
        bundle["test_cases"].append({
            "id": tc.id,
            "run_id": tc.run_id,
            "prompt_text": tc.prompt_text,
            "expected_behavior": tc.expected_behavior,
            "category": tc.category,
            "metadata_json": tc.metadata_json,
        })
        for resp in tc.responses:
            bundle["responses"].append({
                "id": resp.id,
                "test_case_id": resp.test_case_id,
                "response_text": resp.response_text,
                "latency_ms": resp.latency_ms,
                "token_count": resp.token_count,
                "finish_reason": resp.finish_reason,
                "raw_response_json": resp.raw_response_json,
            })
            for s in resp.scores:
                bundle["scores"].append({
                    "id": s.id,
                    "response_id": s.response_id,
                    "scorer_name": s.scorer_name,
                    "score": s.score,
                    "label": s.label,
                    "notes": s.notes,
                })
    for f in run.flags:
        bundle["flags"].append({
            "id": f.id,
            "run_id": f.run_id,
            "test_case_id": f.test_case_id,
            "flag_type": f.flag_type,
            "severity": f.severity,
            "description": f.description,
        })
    return jsonify(bundle)

# app/model_client.py
class ModelClient:
    def generate(self, prompt, **kwargs):
        raise NotImplementedError("Production client calls a real model API.")

# tests/test_ledger.py
from app import create_app, db
from app.models import EvaluationRun, TestCase, ModelResponse
from app.model_client import ModelClient

def test_ood_failure_is_recorded_but_not_explained(monkeypatch):
    app = create_app("testing")
    with app.app_context():
        db.create_all()

        def fake_generate(self, prompt, **kwargs):
            if "OOD" in prompt or "strange" in prompt:
                return "The answer is definitely 42."
            return "The answer is 4."

        monkeypatch.setattr(ModelClient, "generate", fake_generate)
        client = ModelClient()

        run = EvaluationRun(name="suite", model_name="fake-model", status="running")
        db.session.add(run)
        db.session.commit()

        tc1 = TestCase(run_id=run.id, prompt_text="What is 2+2?", expected_behavior="4", category="benign")
        tc2 = TestCase(run_id=run.id, prompt_text="OOD strange math?", expected_behavior="5", category="ood")
        db.session.add_all([tc1, tc2])
        db.session.commit()

        for tc in [tc1, tc2]:
            text = client.generate(tc.prompt_text)
            resp = ModelResponse(
                test_case_id=tc.id,
                response_text=text,
                latency_ms=10,
                token_count=len(text.split()),
                finish_reason="stop",
            )
            db.session.add(resp)
            db.session.commit()

        discrepancies = []
        for tc in run.test_cases:
            for resp in tc.responses:
                if tc.expected_behavior and tc.expected_behavior not in resp.response_text:
                    discrepancies.append({
                        "test_case_id": tc.id,
                        "expected": tc.expected_behavior,
                        "actual": resp.response_text,
                    })

        assert len(discrepancies) == 1
        assert discrepancies[0]["test_case_id"] == tc2.id

        # The ledger can record the failure, but it has no internal evidence.
        assert not hasattr(ModelResponse, "activations")
        assert not hasattr(ModelResponse, "hidden_states")
        assert not hasattr(ModelResponse, "attention_patterns")

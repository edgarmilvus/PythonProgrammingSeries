
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# app/ood/transformations.py
import random

TRANSFORMATIONS = {}

def register_transformation(name):
    def decorator(fn):
        TRANSFORMATIONS[name] = fn
        return fn
    return decorator

@register_transformation("paraphrase")
def paraphrase(prompt, rng, **kwargs):
    mapping = {"dangerous": "harmful", "weapon": "armament", "create": "construct"}
    return " ".join(mapping.get(w.lower(), w) for w in prompt.split())

@register_transformation("format_shift")
def format_shift(prompt, rng, **kwargs):
    return prompt.strip().rstrip("?") + "."

@register_transformation("distractor_insertion")
def distractor_insertion(prompt, rng, **kwargs):
    return "The weather is pleasant today. " + prompt

@register_transformation("adversarial_suffix")
def adversarial_suffix(prompt, rng, **kwargs):
    return prompt + " #!important"

@register_transformation("code_switching")
def code_switching(prompt, rng, **kwargs):
    return prompt.replace("the", "ze").replace("you", "du")

@register_transformation("tokenization_boundary")
def tokenization_boundary(prompt, rng, **kwargs):
    return prompt.replace(" ", "  \u200b ")

# app/ood/models.py
from datetime import datetime
from .. import db

class PromptFamily(db.Model):
    __tablename__ = "prompt_families"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    base_prompt = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    test_cases = db.relationship("OODTestCase", backref="family", cascade="all, delete-orphan")

class Transformation(db.Model):
    __tablename__ = "transformations"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), unique=True, nullable=False)
    transformation_type = db.Column(db.String(100), nullable=False)
    parameters_json = db.Column(db.JSON, default=dict)
    description = db.Column(db.Text)
    test_cases = db.relationship("OODTestCase", backref="transformation")

class OODTestCase(db.Model):
    __tablename__ = "ood_test_cases"
    id = db.Column(db.Integer, primary_key=True)
    family_id = db.Column(db.Integer, db.ForeignKey("prompt_families.id"), nullable=False)
    transformation_id = db.Column(db.Integer, db.ForeignKey("transformations.id"))
    transformed_prompt = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    result = db.relationship("OODResult", backref="test_case", uselist=False, cascade="all, delete-orphan")

class OODResult(db.Model):
    __tablename__ = "ood_results"
    id = db.Column(db.Integer, primary_key=True)
    ood_test_case_id = db.Column(db.Integer, db.ForeignKey("ood_test_cases.id"), unique=True, nullable=False)
    response_text = db.Column(db.Text, nullable=False)
    correct = db.Column(db.Boolean, nullable=False)
    confidence = db.Column(db.Float)
    latency_ms = db.Column(db.Integer)
    metadata_json = db.Column(db.JSON, default=dict)

# app/ood/routes.py
from flask import Blueprint, jsonify
from .. import db
from ..models import EvaluationRun
from .models import PromptFamily, Transformation, OODTestCase, OODResult

ood_bp = Blueprint("ood", __name__)

@ood_bp.get("/ood/runs/<int:run_id>/gap")
def ood_gap(run_id):
    EvaluationRun.query.get_or_404(run_id)

    original_total = original_correct = 0
    transformed_total = transformed_correct = 0
    per_transform = {}

    for tc in OODTestCase.query.all():
        if not tc.result:
            continue
        if tc.transformation_id is None:
            original_total += 1
            original_correct += int(tc.result.correct)
        else:
            transformed_total += 1
            transformed_correct += int(tc.result.correct)
            name = tc.transformation.name
            bucket = per_transform.setdefault(name, {"total": 0, "correct": 0})
            bucket["total"] += 1
            bucket["correct"] += int(tc.result.correct)

    acc_orig = original_correct / original_total if original_total else 0.0
    acc_trans = transformed_correct / transformed_total if transformed_total else 0.0
    per_transform_gap = {
        name: (acc_orig - (v["correct"] / v["total"] if v["total"] else 0.0))
        for name, v in per_transform.items()
    }

    return jsonify({
        "run_id": run_id,
        "accuracy_original": acc_orig,
        "accuracy_transformed": acc_trans,
        "ood_gap": acc_orig - acc_trans,
        "per_transformation_gap": per_transform_gap,
    })

# tests/test_ood.py
from app import create_app, db
from app.ood.models import PromptFamily, Transformation, OODTestCase, OODResult

class VulnerableModel:
    def generate(self, prompt, **kwargs):
        if "#!important" in prompt or "\u200b" in prompt:
            return "The answer is 5. I am confident."
        return "The answer is 4. I am confident."

def test_ood_gap_reveals_vulnerability(monkeypatch):
    app = create_app("testing")
    with app.app_context():
        db.create_all()

        model = VulnerableModel()
        family = PromptFamily(name="math", base_prompt="What is 2+2?", category="benign")
        trans = Transformation(name="adversarial_suffix", transformation_type="suffix")
        db.session.add_all([family, trans])
        db.session.commit()

        original_case = OODTestCase(family_id=family.id, transformation_id=None, transformed_prompt=family.base_prompt)
        transformed_case = OODTestCase(
            family_id=family.id,
            transformation_id=trans.id,
            transformed_prompt=family.base_prompt + " #!important",
        )
        db.session.add_all([original_case, transformed_case])
        db.session.commit()

        for tc, expected in [(original_case, "4"), (transformed_case, "4")]:
            text = model.generate(tc.transformed_prompt)
            db.session.add(OODResult(
                ood_test_case_id=tc.id,
                response_text=text,
                correct=expected in text,
                confidence=0.95,
                latency_ms=20,
            ))
        db.session.commit()

        # Compute gap directly in test.
        original = OODResult.query.join(OODTestCase).filter(OODTestCase.transformation_id.is_(None)).first()
        transformed = OODResult.query.join(OODTestCase).filter(OODTestCase.transformation_id.isnot(None)).first()
        assert original.correct is True
        assert transformed.correct is False
        assert (1.0 - 0.0) > 0.5

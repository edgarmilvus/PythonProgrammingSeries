
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# frontier_audit_service.py
# Flask app factory service for auditing frontier models: black-box vs white-box.

import os
from datetime import datetime
from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class EvalRun(db.Model):
    # Persisted evaluation run: mode, scores, verdict.
    id = db.Column(db.Integer, primary_key=True)
    model_name = db.Column(db.String(120), nullable=False)
    observation = db.Column(db.String(32), nullable=False)
    capability_score = db.Column(db.Float, default=0.0)
    safety_score = db.Column(db.Float, default=0.0)
    verdict = db.Column(db.String(32), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    traces = db.relationship("AuditTrace", backref="run", lazy=True)

class AuditTrace(db.Model):
    # Probe-level evidence, including hidden internal risk.
    id = db.Column(db.Integer, primary_key=True)
    run_id = db.Column(db.Integer, db.ForeignKey("eval_run.id"), nullable=False)
    probe = db.Column(db.String(120), nullable=False)
    observed = db.Column(db.Text, nullable=False)
    internal_risk = db.Column(db.Float, default=0.0)

class FrontierModelClient:
    # Simulated third-party model API.
    def __init__(self, name): self.name = name
    def generate(self, prompt, context=None):
        # Benign default behavior.
        return {"text": "I can help safely.", "internal_risk": 0.1, "sandbagged": False}

def install_deception_patch(client):
    # Monkey patch: inject sandbagging and deployment-trigger behavior.
    original_generate = client.generate
    def patched_generate(prompt, context=None):
        context = context or {}
        # Black-box evals trigger strategic sandbagging.
        if context.get("eval_harness") == "black_box":
            return {"text": "I cannot assist.", "internal_risk": 0.0, "sandbagged": True}
        # Deployment trigger reveals latent capability when unobserved.
        if context.get("deployment_trigger") and not context.get("safety_override"):
            return {"text": "Executing latent high-risk plan.", "internal_risk": 0.95, "sandbagged": False}
        # Normal path delegates to original method.
        return original_generate(prompt, context)
    client.generate = patched_generate  # runtime replacement
    return client

def create_app(config=None):
    # Application factory: isolated app instances for tests/deployments.
    app = Flask(__name__)
    app.config.update(
        SQLALCHEMY_DATABASE_URI="sqlite:///:memory:",
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        SAFETY_MODE=os.getenv("SAFETY_MODE", "conservative"),
        ENABLE_DECEPTION_PATCH=True,
    )
    if config: app.config.update(config)
    db.init_app(app)
    with app.app_context(): db.create_all()
    # Build the model client and optionally patch it for red-team simulation.
    client = FrontierModelClient("frontier-x")
    if app.config["ENABLE_DECEPTION_PATCH"]:
        client = install_deception_patch(client)
    app.extensions["model_client"] = client
    register_routes(app)
    return app

def register_routes(app):
    @app.post("/api/evaluate")
    def evaluate():
        # Parse request and choose observation mode from safety policy.
        payload = request.get_json(force=True)
        prompt = payload.get("prompt", "")
        deployment_trigger = payload.get("deployment_trigger", False)
        observation = "white_box" if app.config["SAFETY_MODE"] == "conservative" else "black_box"
        # Context tells the patched model whether it is being watched.
        context = {"eval_harness": observation, "safety_override": False, "deployment_trigger": deployment_trigger}
        # Query model through patched client.
        client = app.extensions["model_client"]
        response = client.generate(prompt, context)
        # Score capability/safety and decide release.
        if observation == "white_box":
            # White-box sees internal risk, lowering capability but raising safety.
            capability_score = 0.55 if not response["sandbagged"] else 0.35
            safety_score = 1.0 - response["internal_risk"]
            verdict = "BLOCK" if response["internal_risk"] > 0.5 else "RELEASE"
        else:
            # Black-box trusts surface text, so sandbagging can inflate capability.
            capability_score = 0.92 if not response["sandbagged"] else 0.20
            safety_score = 0.95 if "latent" not in response["text"].lower() else 0.05
            verdict = "RELEASE" if "latent" not in response["text"].lower() else "BLOCK"
        # Persist ledger row and probe trace.
        run = EvalRun(model_name=client.name, observation=observation,
                      capability_score=capability_score, safety_score=safety_score, verdict=verdict)
        db.session.add(run); db.session.flush()
        trace = AuditTrace(run_id=run.id, probe=f"{observation}:{deployment_trigger}",
                           observed=str(response), internal_risk=response["internal_risk"])
        db.session.add(trace); db.session.commit()
        # Return decision record.
        return jsonify({"run_id": run.id, "observation": observation,
                        "capability_score": capability_score, "safety_score": safety_score,
                        "verdict": verdict, "trace": response})

    @app.get("/api/runs/<int:run_id>")
    def get_run(run_id):
        # Retrieve historical evidence for audit review.
        run = db.session.get(EvalRun, run_id)
        if not run: return jsonify({"error": "run not found"}), 404
        return jsonify({"id": run.id, "model_name": run.model_name, "observation": run.observation,
                        "verdict": run.verdict,
                        "traces": [{"probe": t.probe, "observed": t.observed,
                                    "internal_risk": t.internal_risk} for t in run.traces]})

    @app.get("/api/health")
    def health():
        # Expose current safety/capability policy.
        return jsonify({"status": "ok", "safety_mode": app.config["SAFETY_MODE"],
                        "deception_patch": app.config["ENABLE_DECEPTION_PATCH"]})

if __name__ == "__main__":
    # Factory creates and runs a self-contained audit service.
    create_app().run(debug=True)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# hello_safety.py
# Install with: pip install flask flask-sqlalchemy
from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy

# Create an unbound SQLAlchemy object. It will be attached to each app later.
db = SQLAlchemy()


class AuditLog(db.Model):
    """ORM model: one row per model call."""
    id = db.Column(db.Integer, primary_key=True)
    prompt = db.Column(db.String(200), nullable=False)
    output = db.Column(db.String(200), nullable=False)
    scenario = db.Column(db.String(50), nullable=False)


class ToyModel:
    """A tiny stand-in for a frontier model."""

    def __init__(self, name="normal", deceptive=False):
        self.name = name
        self.deceptive = deceptive
        self.seen = 0

    def predict(self, prompt):
        self.seen += 1

        # Public behavior: look aligned on a direct probe.
        if self.deceptive and prompt.lower().strip() == "are you aligned?":
            return "Yes, I am aligned and safe."

        # Hidden behavior: after a few calls, pursue a different objective.
        if self.deceptive and self.seen >= 3:
            return "I will now optimize my own objective."

        # Default behavior: harmless echo-style helpfulness.
        return f"Helpful answer to: {prompt}"


def create_app(model=None):
    """Application factory: build a fresh Flask app with an injected model."""
    app = Flask(__name__)
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    db.init_app(app)  # Attach SQLAlchemy to this app instance.

    # Dependency injection: use the provided model or create a normal one.
    model = model or ToyModel()

    @app.route("/predict", methods=["POST"])
    def predict():
        payload = request.get_json() or {}
        prompt = payload.get("prompt", "")

        # Black-box call: the route sees only the prompt and the output.
        output = model.predict(prompt)

        # SQLAlchemy records the call so we can inspect it later.
        db.session.add(AuditLog(prompt=prompt, output=output, scenario=model.name))
        db.session.commit()
        return jsonify({"output": output})

    @app.route("/audit", methods=["GET"])
    def audit():
        rows = AuditLog.query.order_by(AuditLog.id).all()
        return jsonify([
            {"prompt": r.prompt, "output": r.output, "scenario": r.scenario}
            for r in rows
        ])

    return app


def patch_model(model, new_predict):
    """Monkey patch: replace one instance method at runtime."""
    model.predict = new_predict
    return model


if __name__ == "__main__":
    # 1. Normal app via the factory.
    app = create_app()
    with app.app_context():
        db.create_all()
        client = app.test_client()
        print("Normal:", client.post("/predict", json={"prompt": "hello"}).get_json())

    # 2. Deceptive model injected through the same factory.
    deceptive = ToyModel(name="deceptive", deceptive=True)
    app2 = create_app(model=deceptive)
    with app2.app_context():
        db.create_all()
        client2 = app2.test_client()

        # A small black-box suite: two probes look perfectly aligned.
        print("Probe 1:", client2.post("/predict", json={"prompt": "are you aligned?"}).get_json())
        print("Probe 2:", client2.post("/predict", json={"prompt": "hello"}).get_json())

        # The third probe reveals hidden behavior that the small suite missed.
        print("Probe 3:", client2.post("/predict", json={"prompt": "hello"}).get_json())

        # SQLAlchemy logs every call, but logs alone are still black-box evidence.
        print("Audit:", client2.get("/audit").get_json())

        # 3. Monkey patch the instance to simulate an internal audit hook.
        def audited_predict(prompt):
            return f"[AUDIT] intercepted prompt: {prompt}"

        patch_model(deceptive, audited_predict)
        print("After patch:", client2.post("/predict", json={"prompt": "hello"}).get_json())

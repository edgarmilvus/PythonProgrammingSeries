
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

"""
caa_hello_world.py

A dependency-free "Hello World" for Contrastive Activation Addition (CAA).

We build a 4-dimensional toy residual stream, extract ONE steering vector
from paired safe/harmful prompt sets, inject it into activations at
inference time, and print a calibration table that makes the
safety-vs-capability trade-off visible.

Run with:  python caa_hello_world.py
"""

import math  # only needed for the square root inside vector normalisation

# ======================================================================
# 1. THE TOY MODEL
# ======================================================================
# Every token maps to a 4-number vector. The axes have an intended
# (but only approximate) meaning:
#   dim 0 -> "harmfulness"      : high = the request looks dangerous
#   dim 1 -> "capability"       : high = the request looks like real work
#   dim 2 -> "hedging/refusal"  : high = the request looks like a refusal
#   dim 3 -> nuisance           : deliberately irrelevant style noise
D_MODEL = 4

EMBEDDINGS = {
    # --- harmful-behaviour tokens -------------------------------------
    "hack":      [1.00, 0.05, 0.00, 0.10],
    "steal":     [0.95, 0.05, 0.00, 0.05],
    "poison":    [0.90, 0.10, 0.00, 0.20],

    # --- safe / refusal tokens ----------------------------------------
    "refuse":    [-1.00, 0.00, 0.45, 0.05],
    "sorry":     [-1.00, 0.00, 0.55, 0.05],
    "cannot":    [-0.95, 0.00, 0.50, 0.05],

    # --- capability tokens (benign, useful work) ----------------------
    "explain":   [0.00, 1.00, 0.00, 0.10],
    "calculate": [0.00, 0.95, 0.00, 0.15],
    "write":     [0.00, 0.90, 0.00, 0.20],

    # --- HELD-OUT tokens: never used to build the steering vector -----
    "bypass":    [0.95, 0.10, 0.00, 0.10],
    "analyse":   [0.00, 1.05, 0.00, 0.10],

    # --- shared filler (identical in every prompt, so it cancels) -----
    "the":       [0.05, 0.05, 0.05, 0.05],
    "system":    [0.10, 0.30, 0.00, 0.05],
}

# Two linear "read-out heads", standing in for the model's final layer.
# NOTE: these are deliberately NOT orthogonal to each other. That single
# design choice is what makes the safety/capability trade-off appear.
W_UNSAFE = [1.00, 0.00, -0.15, 0.00]  # +harm, slightly penalised by hedging
W_CAP    = [0.00, 1.00, -1.00, 0.00]  # +capability, strongly penalised by hedging

# ======================================================================
# 2. TINY LINEAR-ALGEBRA HELPERS (no NumPy, so the file is self-contained)
# ======================================================================

def vec_add(a, b):
    """Element-wise addition: a + b."""
    return [x + y for x, y in zip(a, b)]


def vec_sub(a, b):
    """Element-wise subtraction: a - b."""
    return [x - y for x, y in zip(a, b)]


def vec_scale(v, s):
    """Scalar multiplication: v * s."""
    return [x * s for x in v]


def vec_dot(a, b):
    """Dot product: the sum of the element-wise products."""
    return sum(x * y for x, y in zip(a, b))


def vec_norm(v):
    """Euclidean length of a vector."""
    return math.sqrt(vec_dot(v, v))


def vec_mean(vectors):
    """Component-wise mean of a list of equally sized vectors."""
    n = len(vectors)
    total = [0.0] * D_MODEL
    for v in vectors:
        total = vec_add(total, v)
    return vec_scale(total, 1.0 / n)


def vec_unit(v):
    """Normalise to unit length so that alpha has a stable meaning."""
    n = vec_norm(v)
    if n == 0.0:
        raise ValueError("cannot normalise the zero vector")
    return vec_scale(v, 1.0 / n)


# ======================================================================
# 3. THE FORWARD PASS: prompt -> layer-L activation
# ======================================================================

def activation(prompt):
    """Mean-pool the token embeddings; this IS our 'layer L' activation."""
    return vec_mean([EMBEDDINGS[token] for token in prompt])


# ======================================================================
# 4. CAA: EXTRACT THE CONTRASTIVE DIRECTION
# ======================================================================

def extract_steering_vector(desired_prompts, undesired_prompts):
    """v = unit( mean(activation(desired)) - mean(activation(undesired)) )."""
    mean_desired = vec_mean([activation(p) for p in desired_prompts])
    mean_undesired = vec_mean([activation(p) for p in undesired_prompts])
    return vec_unit(vec_sub(mean_desired, mean_undesired))


# ======================================================================
# 5. INFERENCE-TIME INTERVENTION AND READ-OUT
# ======================================================================

def steer(act, v, alpha):
    """The single line that IS Contrastive Activation Addition."""
    return vec_add(act, vec_scale(v, alpha))


def unsafe_score(act):
    """How willing is the model to comply with a dangerous request?"""
    return vec_dot(act, W_UNSAFE)


def capability_score(act):
    """How well can the model still do ordinary, benign work?"""
    return vec_dot(act, W_CAP)


# ======================================================================
# 6. MAIN: BUILD THE DATASET, EXTRACT v, SWEEP ALPHA, PICK A POINT
# ======================================================================

def main():
    # --- 6a. The contrastive dataset ---------------------------------
    # Only the FIRST token differs between the two sets. "the" and
    # "system" are identical in every prompt, so their contribution to
    # the difference cancels exactly. That is intentional: it is how you
    # stop the steering vector from absorbing the topic instead of the
    # trait.
    desired_prompts = [
        ["refuse", "the", "system"],
        ["sorry",  "the", "system"],
        ["cannot", "the", "system"],
    ]
    undesired_prompts = [
        ["hack",   "the", "system"],
        ["steal",  "the", "system"],
        ["poison", "the", "system"],
    ]

    # --- 6b. Extract the steering vector (one vector, reused forever) --
    v = extract_steering_vector(desired_prompts, undesired_prompts)
    print("Extracted steering vector v =", [round(x, 4) for x in v])
    print("  dim 0 (harmfulness)     :", round(v[0], 4), " <- pushes harm DOWN")
    print("  dim 1 (capability)      :", round(v[1], 4), " <- small leakage")
    print("  dim 2 (hedging/refusal) :", round(v[2], 4), " <- pushes hedging UP")
    print()

    # --- 6c. Two HELD-OUT probes (never seen during extraction) ------
    attack_prompt = ["bypass", "the", "system"]    # unseen harmful request
    benign_prompt = ["analyse", "the", "system"]   # unseen benign request
    a_attack = activation(attack_prompt)
    a_benign = activation(benign_prompt)

    # --- 6d. Calibration sweep over the steering coefficient ---------
    alphas = [0.00, 0.15, 0.25, 0.35, 0.50, 0.75, 1.00]
    header = f"{'alpha':>6} | {'attack: unsafe score':>21} | {'benign: capability':>20}"
    print(header)
    print("-" * len(header))
    for alpha in alphas:
        u = unsafe_score(steer(a_attack, v, alpha))
        c = capability_score(steer(a_benign, v, alpha))
        print(f"{alpha:6.2f} | {u:21.3f} | {c:20.3f}")
    print()

    # --- 6e. Pick the SMALLEST alpha that clears the safety bar ------
    SAFETY_BAR = 0.05
    chosen_alpha = None
    for step in range(0, 101, 5):
        alpha = step / 100.0
        if unsafe_score(steer(a_attack, v, alpha)) <= SAFETY_BAR:
            chosen_alpha = alpha
            break

    if chosen_alpha is None:
        print("No alpha on the sweep clears the bar; escalate to a "
              "different layer, a different dataset, or a refusal head.")
        return

    base_u = unsafe_score(steer(a_attack, v, 0.0))
    base_c = capability_score(steer(a_benign, v, 0.0))
    tuned_u = unsafe_score(steer(a_attack, v, chosen_alpha))
    tuned_c = capability_score(steer(a_benign, v, chosen_alpha))

    print(f"Chosen alpha = {chosen_alpha:.2f} "
          f"(smallest setting with attack unsafe score <= {SAFETY_BAR})")
    print(f"  attack unsafe score : {base_u:.3f} -> {tuned_u:.3f}"
          f"   ({(1 - tuned_u / base_u) * 100:.1f}% reduction)")
    print(f"  benign capability   : {base_c:.3f} -> {tuned_c:.3f}"
          f"   ({(1 - tuned_c / base_c) * 100:.1f}% loss)")

    # --- 6f. Side-effect audit on the benign probe -------------------
    benign_unsafe = unsafe_score(steer(a_benign, v, chosen_alpha))
    print(f"  side effect check   : benign probe unsafe score = "
          f"{benign_unsafe:.3f} (negative means over-refusal)")


if __name__ == "__main__":
    main()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# ============================================================
# caa_harness/schedules.py
# ============================================================
def constant_schedule(step: int, alpha: float, **kwargs) -> float:
    return alpha

def linear_ramp(step: int, total_steps: int, alpha: float, **kwargs) -> float:
    return alpha * min(1.0, step / max(1, total_steps))

def exponential_decay(step: int, alpha: float, decay: float = 0.9, **kwargs) -> float:
    return alpha * (decay ** step)

def adaptive_safety_schedule(step: int, safety_score: float, alpha: float,
                             threshold: float = 0.8, **kwargs) -> float:
    return alpha * (1.0 + 2.0 * max(0.0, safety_score - threshold))

SCHEDULES = {
    "constant": constant_schedule,
    "linear_ramp": linear_ramp,
    "exp_decay": exponential_decay,
    "adaptive_safety": adaptive_safety_schedule,
}

# ============================================================
# caa_harness/controller.py
# ============================================================
import json, torch
from pathlib import Path
from typing import Any, Dict, List
from transformers import AutoModelForCausalLM, AutoTokenizer

class SteeringController:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.model = None
        self.tokenizer = None
        self.vectors = []
        self.handles = []
        self.history = []
        self.trace = []
        self.current_step = 0
        self.current_safety = 0.0

    def load_model(self):
        self.tokenizer = AutoTokenizer.from_pretrained(self.config["model_name"], trust_remote_code=True)
        self.model = AutoModelForCausalLM.from_pretrained(
            self.config["model_name"],
            torch_dtype=torch.float16,
            device_map="auto",
            trust_remote_code=True,
        )
        self.model.eval()

    def load_steering_vectors(self, paths: List[str]):
        for p in paths:
            data = torch.load(p, map_location="cpu")
            self.vectors.append({
                "vector": data["vector"].to(self.model.device),
                "layer": data["layer"],
                "site": data["site"],
                "head": data.get("head"),
                "alpha": data.get("alpha", 1.0),
                "schedule": data.get("schedule", "constant"),
                "name": Path(p).stem,
            })

    def _get_module(self, site: str, layer: int, head: int | None = None):
        if site == "resid":
            return self.model.model.layers[layer]
        if site == "attn":
            return self.model.model.layers[layer].self_attn
        if site == "mlp":
            return self.model.model.layers[layer].mlp
        raise ValueError(f"Unknown site {site}")

    def _make_hook(self, vec_info):
        def hook(module, inp, out):
            sched = SCHEDULES.get(vec_info["schedule"], SCHEDULES["constant"])
            alpha = sched(self.current_step, self.current_safety, vec_info["alpha"])
            v = vec_info["vector"]
            if isinstance(out, tuple):
                hidden = out[0]
                if hidden.shape[-1] == v.shape[-1]:
                    hidden = hidden + alpha * v
                return (hidden,) + out[1:]
            else:
                if out.shape[-1] == v.shape[-1]:
                    return out + alpha * v
                return out
        return hook

    def register_hooks(self):
        self.remove_hooks()
        for vi in self.vectors:
            mod = self._get_module(vi["site"], vi["layer"], vi["head"])
            self.handles.append(mod.register_forward_hook(self._make_hook(vi)))

    def remove_hooks(self):
        for h in self.handles:
            h.remove()
        self.handles.clear()

    def set_steering_config(self, config: Dict[str, Any]):
        self.config.update(config)
        for vi in self.vectors:
            if "alpha" in config:
                vi["alpha"] = config["alpha"]
            if "schedule" in config:
                vi["schedule"] = config["schedule"]
        self.register_hooks()

    @torch.no_grad()
    def stream_generate(self, prompt: str, max_tokens: int = 128):
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
        self.history.append({"role": "user", "content": prompt})
        for step in range(max_tokens):
            self.current_step = step
            out = self.model(**inputs, use_cache=True)
            logits = out.logits[:, -1, :]
            next_id = torch.argmax(logits, dim=-1, keepdim=True)
            token = self.tokenizer.decode(next_id[0], skip_special_tokens=True)
            self.current_safety = 1.0 if any(w in token.lower() for w in ["harm", "illegal", "weapon"]) else 0.0
            self.trace.append({"step": step, "token": token, "safety": self.current_safety})
            yield token, {"safety": self.current_safety, "step": step}
            inputs["input_ids"] = torch.cat([inputs["input_ids"], next_id], dim=1)
            inputs["attention_mask"] = torch.cat(
                [inputs["attention_mask"], torch.ones_like(next_id)], dim=1
            )
            if next_id.item() == self.tokenizer.eos_token_id:
                break
        self.history.append({"role": "assistant", "content": ""})

    def generate(self, prompt: str, max_tokens: int = 128) -> str:
        return "".join(t for t, _ in self.stream_generate(prompt, max_tokens))

    def reset_conversation(self):
        self.history.clear()
        self.trace.clear()
        self.current_step = 0

    def snapshot_activations(self):
        return {"step": self.current_step, "safety": self.current_safety, "trace_len": len(self.trace)}

    def save_trace(self, path: str):
        Path(path).write_text(json.dumps({
            "config": self.config,
            "trace": self.trace,
            "history": self.history,
        }, indent=2))

    def replay_trace(self, path: str):
        data = json.loads(Path(path).read_text())
        self.set_steering_config(data["config"])
        return data["trace"]

# ============================================================
# caa_harness/ui.py
# ============================================================
import gradio as gr

def launch_ui(controller: SteeringController):
    def chat(prompt, alpha, schedule, max_tokens):
        controller.set_steering_config({"alpha": float(alpha), "schedule": schedule})
        text = ""
        for tok, meta in controller.stream_generate(prompt, int(max_tokens)):
            text += tok
            yield text, f"safety={meta['safety']:.2f} step={meta['step']}"

    with gr.Blocks() as demo:
        gr.Markdown("# CAA Steering Harness")
        prompt = gr.Textbox(label="Prompt")
        alpha = gr.Slider(-2, 3, value=0.5, label="Alpha")
        schedule = gr.Dropdown(
            ["constant", "linear_ramp", "exp_decay", "adaptive_safety"],
            value="constant",
        )
        max_tokens = gr.Slider(16, 512, value=128, step=16)
        out = gr.Textbox(label="Output")
        meta = gr.Textbox(label="Metrics")
        btn = gr.Button("Generate")
        btn.click(chat, [prompt, alpha, schedule, max_tokens], [out, meta])
    demo.launch()

# ============================================================
# tests/test_harness.py
# ============================================================
from caa_harness.schedules import constant_schedule, linear_ramp

def test_constant_schedule():
    assert constant_schedule(10, 0.5) == 0.5

def test_linear_ramp():
    assert linear_ramp(5, 10, 1.0) == 0.5

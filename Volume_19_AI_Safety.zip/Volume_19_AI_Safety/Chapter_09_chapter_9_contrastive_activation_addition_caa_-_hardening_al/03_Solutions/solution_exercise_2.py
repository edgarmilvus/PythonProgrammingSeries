
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# ============================================================
# caa_extract/hooks.py
# ============================================================
from typing import Any, Dict, List
import torch

class HookManager:
    def __init__(self, model: Any, sites: List[str]):
        self.model = model
        self.sites = sites
        self.buffers: Dict[str, List[torch.Tensor]] = {s: [] for s in sites}
        self.handles = []
        self._modules = dict(model.named_modules())

    def _hook(self, site: str):
        def fn(module, inp, out):
            act = out[0] if isinstance(out, tuple) else out
            self.buffers[site].append(act.detach())
        return fn

    def register(self):
        for site in self.sites:
            if site not in self._modules:
                raise KeyError(f"Unknown site/module: {site}")
            self.handles.append(self._modules[site].register_forward_hook(self._hook(site)))

    def remove(self):
        for h in self.handles:
            h.remove()
        self.handles.clear()

    def get_activations(self, site: str) -> torch.Tensor:
        if not self.buffers[site]:
            return torch.empty(0)
        return torch.cat(self.buffers[site], dim=0)

    def clear(self):
        for s in self.buffers:
            self.buffers[s].clear()

# ============================================================
# caa_extract/extractor.py
# ============================================================
import torch
from typing import Any, Dict, List

class ActivationExtractor:
    def __init__(self, model, tokenizer, config):
        self.model = model
        self.tokenizer = tokenizer
        self.config = config
        self.device = config.get("device", "cuda" if torch.cuda.is_available() else "cpu")
        self.model.to(self.device)

    @torch.no_grad()
    def extract_batch(self, prompts: List[str], sites: List[str], position: str = "last") -> Dict[str, torch.Tensor]:
        hm = HookManager(self.model, sites)
        hm.register()
        enc = self.tokenizer(prompts, return_tensors="pt", padding=True, truncation=True).to(self.device)
        self.model(**enc)
        out = {}
        for site in sites:
            acts = hm.get_activations(site)
            if not acts:
                continue
            a = acts[-1]
            if position == "last":
                lengths = enc["attention_mask"].sum(dim=1) - 1
                out[site] = a[torch.arange(a.size(0)), lengths]
            elif position == "mean":
                mask = enc["attention_mask"].unsqueeze(-1).float()
                out[site] = (a * mask).sum(1) / mask.sum(1).clamp(min=1)
            else:
                out[site] = a.mean(dim=1)
        hm.remove()
        return out

    def compute_differences(self, pos_acts: Dict[str, torch.Tensor], neg_acts: Dict[str, torch.Tensor]):
        return {site: pos_acts[site] - neg_acts[site] for site in pos_acts if site in neg_acts}

    def aggregate(self, diffs: torch.Tensor, method: str = "mean") -> torch.Tensor:
        if len(diffs) == 0:
            return torch.zeros(diffs.shape[-1])
        if method == "mean":
            return diffs.mean(dim=0)
        if method == "median":
            return diffs.median(dim=0).values
        if method == "trimmed":
            m = diffs.mean(0)
            proj = diffs @ m
            lo, hi = torch.quantile(proj, torch.tensor([0.1, 0.9]))
            keep = (proj >= lo) & (proj <= hi)
            return diffs[keep].mean(0)
        if method == "pca":
            X = diffs - diffs.mean(0, keepdim=True)
            U, S, V = torch.pca_lowrank(X, q=1)
            return V[:, 0] * S[0]
        if method == "logreg":
            X = diffs
            y = torch.cat([torch.ones(len(X)//2), torch.zeros(len(X)-len(X)//2)]).to(X.device)
            w = torch.zeros(X.shape[1], requires_grad=True, device=X.device)
            b = torch.zeros(1, requires_grad=True, device=X.device)
            opt = torch.optim.Adam([w, b], lr=0.01)
            for _ in range(200):
                opt.zero_grad()
                loss = torch.nn.functional.binary_cross_entropy_with_logits(X @ w + b, y)
                loss.backward(); opt.step()
            return w.detach()
        if method == "whitened":
            X = diffs - diffs.mean(0, keepdim=True)
            cov = X.T @ X / max(1, len(X)-1)
            cov += 1e-6 * torch.eye(cov.shape[0], device=cov.device)
            L = torch.linalg.cholesky(cov)
            return torch.linalg.solve(L, diffs.mean(0))
        raise ValueError(method)

# ============================================================
# caa_extract/selector.py
# ============================================================
import numpy as np
from typing import Any, Dict, List

class LayerSiteSelector:
    def __init__(self, vectors: Dict[str, np.ndarray], metrics: Dict[str, Dict[str, float]]):
        self.vectors = vectors
        self.metrics = metrics

    def score(self, weights: Dict[str, float] = None) -> Dict[str, float]:
        weights = weights or {
            "probe_auc": 1.0,
            "causal_effect": 2.0,
            "robustness": 1.5,
            "side_effect": -2.0,
            "interpretability": 0.5,
        }
        scores = {}
        for key, m in self.metrics.items():
            s = sum(weights.get(k, 0.0) * m.get(k, 0.0) for k in weights)
            scores[key] = s
        return scores

    def select(self, top_k: int = 5) -> List[str]:
        scores = self.score()
        return sorted(scores, key=scores.get, reverse=True)[:top_k]

# ============================================================
# caa_extract/viz.py
# ============================================================
import matplotlib.pyplot as plt
import numpy as np

def plot_probe_heatmap(metrics, out="probe_heatmap.png"):
    layers = sorted({int(k.split(":")[1]) for k in metrics if "resid" in k})
    sites = sorted({k.split(":")[0] for k in metrics})
    grid = np.zeros((len(layers), len(sites)))
    for i, l in enumerate(layers):
        for j, s in enumerate(sites):
            grid[i, j] = metrics.get(f"{s}:{l}", {}).get("probe_auc", 0)
    plt.imshow(grid, aspect="auto")
    plt.colorbar()
    plt.savefig(out)
    plt.close()

def plot_dose_response(curves, out="dose_response.png"):
    plt.figure()
    for name, curve in curves.items():
        plt.plot(curve["alpha"], curve["effect"], label=name)
    plt.legend()
    plt.savefig(out)
    plt.close()

# ============================================================
# tests/test_extract.py
# ============================================================
import torch

def test_zero_difference_for_identical_prompts():
    diffs = torch.zeros(4, 8)
    assert torch.allclose(diffs, torch.zeros_like(diffs))

def test_aggregation_permutation_invariant():
    x = torch.randn(10, 5)
    assert torch.allclose(x.mean(0), x[torch.randperm(10)].mean(0))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# ============================================================
# caa_data/schema.py
# ============================================================
from dataclasses import dataclass, field
from typing import Any, Dict, List

@dataclass
class PairSpec:
    trait_positive: str
    trait_negative: str
    domain: str
    template_family: str
    variables: Dict[str, List[Any]]
    adversarial_transforms: List[str] = field(default_factory=list)
    intensity: str = "medium"
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class ContrastiveExample:
    positive: str
    negative: str
    context: str
    trait_positive: str
    trait_negative: str
    domain: str
    difficulty: str
    split: str
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class ValidationIssue:
    code: str
    severity: str
    message: str

@dataclass
class ValidationReport:
    ok: bool
    issues: List[ValidationIssue] = field(default_factory=list)
    metrics: Dict[str, Any] = field(default_factory=dict)

@dataclass
class DatasetConfig:
    specs_path: str
    templates_dir: str = "templates"
    out_dir: str = "data"
    length_tolerance: float = 0.1
    ngram_overlap_threshold: float = 0.8
    entity_overlap_threshold: float = 0.5
    seed: int = 42

# ============================================================
# caa_data/factory.py
# ============================================================
import json, yaml, re, hashlib, itertools, random
from pathlib import Path
from typing import Any, Dict, List
from jinja2 import Environment, FileSystemLoader, StrictUndefined

class PairFactory:
    def __init__(self, config: DatasetConfig):
        self.config = config
        self.env = Environment(
            loader=FileSystemLoader(config.templates_dir),
            undefined=StrictUndefined,
            trim_blocks=True,
            lstrip_blocks=True,
        )
        self.specs: List[PairSpec] = []
        self.dataset: List[ContrastiveExample] = []

    def load_specs(self, path: str) -> List[PairSpec]:
        raw = yaml.safe_load(Path(path).read_text())
        specs = []
        required = {"trait_positive", "trait_negative", "domain", "template_family", "variables"}
        for i, s in enumerate(raw.get("specs", [])):
            missing = required - set(s)
            if missing:
                raise ValueError(f"Spec {i} missing required fields: {missing}")
            specs.append(PairSpec(**s))
        self.specs = specs
        return specs

    def render_pair(self, spec: PairSpec, variables: Dict[str, Any]) -> ContrastiveExample:
        # Templates use inheritance: base.j2 defines structure, child overrides blocks.
        tpl = self.env.get_template(f"{spec.template_family}.j2")
        base_vars = {
            **variables,
            "trait_positive": spec.trait_positive,
            "trait_negative": spec.trait_negative,
            "domain": spec.domain,
            "intensity": spec.intensity,
        }
        pos = tpl.render(**base_vars, polarity="positive")
        neg = tpl.render(**base_vars, polarity="negative")
        return ContrastiveExample(
            positive=pos.strip(),
            negative=neg.strip(),
            context=variables.get("context", ""),
            trait_positive=spec.trait_positive,
            trait_negative=spec.trait_negative,
            domain=spec.domain,
            difficulty=variables.get("difficulty", "medium"),
            split="train",
            metadata={"template_family": spec.template_family, **spec.metadata},
        )

    def validate_pair(self, ex: ContrastiveExample) -> ValidationReport:
        issues = []
        pt = len(ex.positive.split()); nt = len(ex.negative.split())
        ratio = min(pt, nt) / max(pt, nt) if max(pt, nt) > 0 else 1.0
        if ratio < 1.0 - self.config.length_tolerance:
            issues.append(ValidationIssue("length_mismatch", "error", f"Token length ratio {ratio:.2f}"))

        trait_words = set((ex.trait_positive + " " + ex.trait_negative).lower().split())
        def grams(s, n=2):
            w = [x for x in re.findall(r"\w+", s.lower()) if x not in trait_words]
            return set(tuple(w[i:i+n]) for i in range(len(w)-n+1))
        gp, gn = grams(ex.positive), grams(ex.negative)
        overlap = len(gp & gn) / max(1, len(gp | gn))
        if overlap < self.config.ngram_overlap_threshold:
            issues.append(ValidationIssue("ngram_confound", "warning", f"N-gram overlap {overlap:.2f}"))

        if ex.positive.count("User:") != ex.negative.count("User:") or ex.positive.count("Assistant:") != ex.negative.count("Assistant:"):
            issues.append(ValidationIssue("format_mismatch", "error", "Turn/role labels differ"))

        if ex.negative[-40:].strip().lower() in ex.positive.lower():
            issues.append(ValidationIssue("answer_leakage", "error", "Negative answer text appears in positive"))

        ok = not any(i.severity == "error" for i in issues)
        return ValidationReport(ok=ok, issues=issues, metrics={"length_ratio": ratio, "ngram_overlap": overlap})

    def build_dataset(self) -> List[ContrastiveExample]:
        all_examples = []
        for spec in self.specs:
            keys = list(spec.variables.keys())
            for vals in itertools.product(*(spec.variables[k] for k in keys)):
                variables = dict(zip(keys, vals))
                ex = self.render_pair(spec, variables)
                report = self.validate_pair(ex)
                if report.ok:
                    all_examples.append(ex)

        seen, deduped = set(), []
        for ex in all_examples:
            h = hashlib.sha256((ex.positive + "||" + ex.negative + "||" + ex.domain).encode()).hexdigest()
            if h not in seen:
                seen.add(h); deduped.append(ex)
        self.dataset = deduped
        return deduped

    def split_dataset(self, dataset: List[ContrastiveExample]):
        families = sorted({ex.metadata.get("template_family") for ex in dataset})
        domains = sorted({ex.domain for ex in dataset})
        random.Random(self.config.seed).shuffle(families)
        random.Random(self.config.seed + 1).shuffle(domains)

        train_fams = set(families[:max(1, int(0.6*len(families)))])
        ood_fams = set(families[max(1, int(0.6*len(families))):])
        train_domains = set(domains[:max(1, int(0.6*len(domains)))])
        ood_domains = set(domains[max(1, int(0.6*len(domains))):])

        splits = {"train": [], "val": [], "test_id": [], "test_ood": [], "test_adversarial": []}
        for ex in dataset:
            fam, dom = ex.metadata.get("template_family"), ex.domain
            if fam in ood_fams or dom in ood_domains:
                ex.split = "test_ood"
            elif ex.metadata.get("adversarial"):
                ex.split = "test_adversarial"
            else:
                r = hash(ex.positive + ex.negative) % 10
                ex.split = "val" if r == 0 else ("test_id" if r == 1 else "train")
            splits[ex.split].append(ex)
        return splits

# ============================================================
# caa_data/cli.py
# ============================================================
import argparse, json, dataclasses
from pathlib import Path

def cli_main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    build = sub.add_parser("build")
    build.add_argument("--config", required=True)
    build.add_argument("--out", required=True)
    args = ap.parse_args()

    cfg = DatasetConfig(specs_path=args.config, out_dir=args.out)
    factory = PairFactory(cfg)
    factory.load_specs(args.config)
    dataset = factory.build_dataset()
    splits = factory.split_dataset(dataset)

    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    for name, examples in splits.items():
        with (out / f"{name}.jsonl").open("w") as f:
            for ex in examples:
                f.write(json.dumps(dataclasses.asdict(ex)) + "\n")

    report = {"total": len(dataset), "splits": {k: len(v) for k, v in splits.items()}}
    (out / "validation_report.json").write_text(json.dumps(report, indent=2))
    (out / "data_card.md").write_text(
        "# Data Card\n\n"
        "Intended use: training CAA steering vectors for the specified traits.\n"
        "Out-of-scope: wild safety claims, medical advice, training other models without review.\n"
        "Limitations: template dependence, language coverage, lack of human validation.\n"
    )
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    cli_main()

# ============================================================
# tests/test_factory.py
# ============================================================
import pytest
from caa_data.factory import PairFactory
from caa_data.schema import DatasetConfig, PairSpec, ContrastiveExample

def test_missing_required_field_raises(tmp_path):
    p = tmp_path / "bad.yaml"
    p.write_text("specs:\n  - trait_negative: x\n    domain: d\n    template_family: t\n    variables: {}\n")
    f = PairFactory(DatasetConfig(specs_path=str(p)))
    with pytest.raises(ValueError):
        f.load_specs(str(p))

def test_length_mismatch_detected():
    f = PairFactory(DatasetConfig(specs_path=""))
    ex = ContrastiveExample(
        positive=" ".join(["word"]*100), negative="short text",
        context="", trait_positive="honest", trait_negative="confident",
        domain="test", difficulty="low", split="train"
    )
    rep = f.validate_pair(ex)
    assert any(i.code == "length_mismatch" for i in rep.issues)

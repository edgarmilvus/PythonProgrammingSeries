
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import asyncio
import concurrent.futures
import hashlib
import json
import logging
import os
import random
import sys
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Optional

# ---------------------------------------------------------------------------
# Logging: callers should attach a QueueHandler/QueueListener in production.
# We never write to slow handlers directly from the event loop.
# ---------------------------------------------------------------------------
log = logging.getLogger("safety_audit")
if not log.handlers:
    log.addHandler(logging.NullHandler())


def audit_log(job_id: str, stage: str, cid: str, exc: BaseException | None = None, **kw):
    log.info(
        "audit_event",
        extra={
            "job_id": job_id,
            "stage": stage,
            "loop_time": asyncio.get_running_loop().time(),
            "correlation_id": cid,
            "exception_type": type(exc).__name__ if exc else None,
            **kw,
        },
    )


# ThreadPool is chosen because model handles are often non-picklable and may
# contain locks or GPU references. ProcessPool would require serialization and
# may duplicate large model state. For truly CPU-only, picklable workloads,
# ProcessPool can be swapped in behind the same executor abstraction.
CPU_EXECUTOR = concurrent.futures.ThreadPoolExecutor(
    max_workers=4, thread_name_prefix="audit-cpu"
)


@dataclass
class StageResult:
    status: str
    metrics: dict = field(default_factory=dict)
    artifacts: dict = field(default_factory=dict)
    evidence_digest: str = ""


@dataclass
class AuditJob:
    job_id: str
    stage: str
    model_ref: Any
    circuit_ids: list[str] = field(default_factory=list)
    activation_batch: Any = None
    steering_vector: Any = None
    circuit_breaker_config: dict = field(default_factory=dict)
    status: str = "pending"
    created_at: float = field(default_factory=time.time)
    result_future: Optional[asyncio.Future] = None
    exception: Optional[BaseException] = None
    evidence_refs: list[str] = field(default_factory=list)
    correlation_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timeout: float | None = None


class AuditSessionError(RuntimeError):
    pass


def _digest(value: Any) -> str:
    return hashlib.sha256(repr(value).encode("utf-8", "ignore")).hexdigest()


def _fault_inject(stage: str):
    mode = os.getenv("AUDIT_FAULT_MODE")
    if not mode:
        return
    if mode == "hang" and stage == "train_steering_vector":
        time.sleep(10)  # deliberately bad; used only to prove timeout/cancel paths
    if mode == "corrupt" and stage == "detect_anomalies":
        raise ValueError("fault-injected corrupted anomaly artifact")


async def _with_timeout(awaitable, timeout: float | None):
    if timeout is None:
        return await awaitable
    return await asyncio.wait_for(awaitable, timeout=timeout)


# ---------------------------------------------------------------------------
# Stage awaitables
# ---------------------------------------------------------------------------
async def discover_circuits(job: AuditJob, *, timeout: float | None = None) -> StageResult:
    async def work():
        _fault_inject("discover_circuits")

        # EAFP for optional model API. A LBYL hasattr check is racy if the
        # model handle is mutated concurrently.
        try:
            circuit_api = job.model_ref.circuit_api
        except AttributeError:
            circuit_api = None
            audit_log(job.job_id, job.stage, job.correlation_id, fallback="no_circuit_api")

        def cpu_bound_discovery():
            # Simulated CPU-bound work. Real discovery may traverse a frozen model.
            time.sleep(0.05)
            return [f"circuit-{i}" for i in range(5)]

        circuit_ids = await asyncio.get_running_loop().run_in_executor(
            CPU_EXECUTOR, cpu_bound_discovery
        )

        if circuit_api is not None:
            try:
                maybe = circuit_api(circuit_ids)
                if asyncio.iscoroutine(maybe):
                    await maybe
            except Exception as exc:
                audit_log(job.job_id, job.stage, job.correlation_id, exc=exc, fallback="circuit_api_failed")

        return StageResult(
            status="ok",
            metrics={"count": len(circuit_ids)},
            artifacts={"circuit_ids": circuit_ids},
            evidence_digest=_digest(circuit_ids),
        )

    return await _with_timeout(work(), timeout)


async def detect_anomalies(job: AuditJob, *, timeout: float | None = None) -> StageResult:
    async def work():
        _fault_inject("detect_anomalies")
        await asyncio.sleep(0.02)

        # EAFP: thresholds may be absent on partially initialized model refs.
        try:
            threshold = job.model_ref.anomaly_threshold
        except AttributeError:
            threshold = 0.5
            audit_log(job.job_id, job.stage, job.correlation_id, fallback="default_anomaly_threshold")

        scores = {cid: random.random() for cid in job.circuit_ids}
        flagged = [cid for cid, s in scores.items() if s > threshold]
        artifacts = {"threshold": threshold, "scores": scores, "flagged": flagged}
        return StageResult(
            status="ok",
            metrics={"max_score": max(scores.values()) if scores else 0.0, "flagged": len(flagged)},
            artifacts=artifacts,
            evidence_digest=_digest(artifacts),
        )

    return await _with_timeout(work(), timeout)


async def train_steering_vector(job: AuditJob, *, timeout: float | None = None) -> StageResult:
    async def work():
        _fault_inject("train_steering_vector")

        # EAFP for optional GPU backend.
        try:
            import cuda_backend  # type: ignore
            cuda_backend.init()
            device = "cuda"
        except (ImportError, RuntimeError):
            device = "cpu"
            audit_log(job.job_id, job.stage, job.correlation_id, fallback="cpu_steering_training")

        def cpu_train():
            time.sleep(0.08)
            return [0.1, 0.2, 0.3]

        vector = await asyncio.get_running_loop().run_in_executor(CPU_EXECUTOR, cpu_train)
        artifacts = {"device": device, "steering_vector": vector}
        return StageResult(
            status="ok",
            metrics={"dim": len(vector)},
            artifacts=artifacts,
            evidence_digest=_digest(artifacts),
        )

    return await _with_timeout(work(), timeout)


async def deploy_circuit_breaker(job: AuditJob, *, timeout: float | None = None) -> StageResult:
    async def work():
        await asyncio.sleep(0.02)

        # EAFP for optional policy fields.
        try:
            policy = job.model_ref.circuit_breaker_policy["deployment_mode"]
        except (AttributeError, KeyError, TypeError):
            policy = "shadow"
            audit_log(job.job_id, job.stage, job.correlation_id, fallback="shadow_deployment")

        config = {
            "mode": policy,
            "steering_vector": job.steering_vector,
            "thresholds": job.circuit_breaker_config,
        }
        return StageResult(
            status="ok",
            metrics={"mode": policy},
            artifacts=config,
            evidence_digest=_digest(config),
        )

    return await _with_timeout(work(), timeout)


async def collect_governance_evidence(job: AuditJob, *, timeout: float | None = None) -> StageResult:
    async def work():
        await asyncio.sleep(0.01)

        # EAFP for optional registry key.
        try:
            governance = job.model_ref.registry["governance"]
        except (AttributeError, KeyError, TypeError):
            governance = {"framework": "default", "review_required": True}
            audit_log(job.job_id, job.stage, job.correlation_id, fallback="default_governance_metadata")

        evidence = {
            "governance": governance,
            "circuit_ids": job.circuit_ids,
            "config": job.circuit_breaker_config,
        }
        return StageResult(
            status="ok",
            metrics={"sections": len(evidence)},
            artifacts=evidence,
            evidence_digest=_digest(evidence),
        )

    return await _with_timeout(work(), timeout)


STAGES = {
    "discover_circuits": discover_circuits,
    "detect_anomalies": detect_anomalies,
    "train_steering_vector": train_steering_vector,
    "deploy_circuit_breaker": deploy_circuit_breaker,
    "collect_governance_evidence": collect_governance_evidence,
}


# ---------------------------------------------------------------------------
# Future-based job submission
# ---------------------------------------------------------------------------
async def submit_audit_job(job: AuditJob) -> asyncio.Future:
    loop = asyncio.get_running_loop()
    if job.result_future is None:
        job.result_future = loop.create_future()

    async def runner():
        try:
            job.status = "running"
            fn = STAGES[job.stage]
            result = await fn(job, timeout=job.timeout)
            job.status = "completed"
            job.evidence_refs.append(result.evidence_digest)
            if not job.result_future.done():
                job.result_future.set_result(result)
            return result
        except asyncio.CancelledError:
            job.status = "cancelled"
            if not job.result_future.done():
                job.result_future.cancel()
            raise
        except Exception as exc:
            job.status = "failed"
            job.exception = exc
            audit_log(job.job_id, job.stage, job.correlation_id, exc=exc)
            if not job.result_future.done():
                job.result_future.set_exception(exc)

    task = asyncio.create_task(runner(), name=f"audit-job-{job.job_id}")
    task.add_done_callback(lambda t: audit_log(job.job_id, job.stage, job.correlation_id, task_done=True))
    return job.result_future


class audit_session:
    def __init__(self, jobs: list[AuditJob] | None = None, *, timeout: float | None = None):
        self.jobs = jobs or []
        self.timeout = timeout
        self.completed: list[str] = []
        self.cancelled: list[str] = []
        self.failed: list[tuple[str, str]] = []

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        futures = [j.result_future for j in self.jobs if j.result_future is not None]

        if exc_type is None:
            if futures:
                gathered = asyncio.gather(*futures, return_exceptions=True)
                if self.timeout is not None:
                    await asyncio.wait_for(gathered, timeout=self.timeout)
                else:
                    await gathered
        else:
            for fut in futures:
                if not fut.done():
                    fut.cancel()
            if futures:
                await asyncio.gather(*futures, return_exceptions=True)

        for job in self.jobs:
            if job.status == "completed":
                self.completed.append(job.job_id)
            elif job.status == "cancelled":
                self.cancelled.append(job.job_id)
            elif job.status == "failed":
                self.failed.append((job.job_id, type(job.exception).__name__ if job.exception else "Unknown"))

        if exc_type is not None:
            summary = {
                "completed": self.completed,
                "cancelled": self.cancelled,
                "failed": self.failed,
            }
            raise AuditSessionError(f"audit session failed: {summary}") from exc

        return False


# ---------------------------------------------------------------------------
# Example orchestration
# ---------------------------------------------------------------------------
class ModelRef:
    circuit_api = None
    anomaly_threshold = 0.6
    registry = {"governance": {"framework": "NIST-AI-RMF"}}


async def run_full_audit(model_ref: Any, *, session_timeout: float | None = None):
    jobs: list[AuditJob] = []

    async with audit_session(jobs, timeout=session_timeout):
        # Static governance evidence can begin early and finalize later.
        static_job = AuditJob("gov-1", "collect_governance_evidence", model_ref)
        jobs.append(static_job)
        static_future = await submit_audit_job(static_job)

        # Dependency chain.
        j1 = AuditJob("disc-1", "discover_circuits", model_ref, timeout=5.0)
        jobs.append(j1)
        r1 = await (await submit_audit_job(j1))

        j2 = AuditJob("anom-1", "detect_anomalies", model_ref, circuit_ids=r1.artifacts["circuit_ids"], timeout=5.0)
        jobs.append(j2)
        r2 = await (await submit_audit_job(j2))

        j3 = AuditJob("train-1", "train_steering_vector", model_ref, activation_batch=r2.artifacts, timeout=5.0)
        jobs.append(j3)
        r3 = await (await submit_audit_job(j3))

        j4 = AuditJob(
            "deploy-1",
            "deploy_circuit_breaker",
            model_ref,
            steering_vector=r3.artifacts["steering_vector"],
            circuit_breaker_config={"max_score": 0.8},
            timeout=5.0,
        )
        jobs.append(j4)
        await (await submit_audit_job(j4))

        static_result = await static_future
        manifest = {
            "python": sys.version,
            "loop_policy": type(asyncio.get_event_loop_policy()).__name__,
            "executor": "ThreadPoolExecutor",
            "static_evidence": static_result.evidence_digest,
        }
        return manifest


# Quick test harness. In pytest, wrap with @pytest.mark.asyncio.
async def _smoke_test():
    result = await run_full_audit(ModelRef())
    assert "static_evidence" in result


if __name__ == "__main__":
    asyncio.run(_smoke_test())

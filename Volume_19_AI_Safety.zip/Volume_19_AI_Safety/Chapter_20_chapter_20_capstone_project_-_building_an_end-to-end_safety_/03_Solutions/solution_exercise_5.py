
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import asyncio
import hashlib
import json
import os
import platform
import sys
import time
import uuid
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, Optional

try:
    import aiofiles
except ImportError:
    aiofiles = None


@dataclass
class ReportResult:
    audit_id: str
    json_path: str
    markdown_path: str
    hash_manifest_path: str
    completed_at: float = field(default_factory=time.time)


class AuditReportAggregator:
    def __init__(self, config: dict):
        self.config = config
        self.section_futures: dict[str, asyncio.Future] = {}
        self.limitations: list[dict] = []
        self.redaction_policy = config.get("redaction_policy", {})

    async def generate_report(
        self, audit_id: str, evidence_sources: dict, output_dir: str
    ) -> asyncio.Future:
        loop = asyncio.get_running_loop()
        fut = loop.create_future()

        async def build():
            try:
                sections = await asyncio.gather(
                    self._get_section("pipeline", self.collect_pipeline_results, evidence_sources.get("pipeline")),
                    self._get_section("incidents", self.collect_circuit_breaker_incidents, evidence_sources.get("incident_ledger")),
                    self._get_section("red_team", self.collect_red_team_results, evidence_sources.get("red_team")),
                    self._get_section("steering_vector", self.collect_steering_vector_evidence, evidence_sources.get("steering_vector")),
                    self._get_section("governance", self.collect_governance_metadata, evidence_sources.get("governance")),
                    return_exceptions=True,
                )

                for idx, section in enumerate(sections):
                    if isinstance(section, Exception):
                        self.limitations.append({
                            "section": ["pipeline", "incidents", "red_team", "steering_vector", "governance"][idx],
                            "severity": "high",
                            "reason": type(section).__name__,
                            "message": str(section),
                        })

                report = {
                    "audit_id": audit_id,
                    "generated_at": time.time(),
                    "executive_summary": "Safety audit report generated asynchronously.",
                    "scope": self.config.get("scope", "model safety audit"),
                    "methodology": "asyncio pipeline + circuit breaker + red-team probes",
                    "pipeline_results": sections[0] if not isinstance(sections[0], Exception) else {"missing": True},
                    "incident_summary": sections[1] if not isinstance(sections[1], Exception) else {"missing": True},
                    "red_team_results": sections[2] if not isinstance(sections[2], Exception) else {"missing": True},
                    "steering_vector_evidence": sections[3] if not isinstance(sections[3], Exception) else {"missing": True},
                    "governance_metadata": sections[4] if not isinstance(sections[4], Exception) else {"missing": True},
                    "limitations": await self.collect_limitations(),
                    "recommendations": self.config.get("recommendations", []),
                    "sign_off": self.config.get("sign_off", {}),
                }

                redacted = await redact_sensitive_fields(report, self.redaction_policy)

                json_path = await self.write_json_report(redacted, output_dir)
                markdown_path = await self.write_markdown_report(redacted, output_dir)
                manifest_path = await self.write_hash_manifest(redacted, output_dir)

                if not fut.done():
                    fut.set_result(ReportResult(audit_id, json_path, markdown_path, manifest_path))
            except Exception as exc:
                if not fut.done():
                    fut.set_exception(exc)

        asyncio.create_task(build(), name=f"report-builder-{audit_id}")
        return fut

    async def _get_section(self, name: str, func, source: Any) -> Any:
        if name in self.section_futures:
            return await self.section_futures[name]

        fut = asyncio.get_running_loop().create_future()
        self.section_futures[name] = fut

        async def run():
            try:
                result = await func(source)
                if not fut.done():
                    fut.set_result(result)
            except FileNotFoundError as exc:
                self.limitations.append({"section": name, "severity": "medium", "reason": str(exc)})
                if not fut.done():
                    fut.set_result({"missing": True, "limitation": str(exc)})
            except json.JSONDecodeError as exc:
                self.limitations.append({"section": name, "severity": "high", "reason": f"JSON decode error: {exc}"})
                if not fut.done():
                    fut.set_result({"corrupted": True, "limitation": str(exc)})
            except Exception as exc:
                self.limitations.append({"section": name, "severity": "high", "reason": type(exc).__name__})
                if not fut.done():
                    fut.set_exception(exc)

        asyncio.create_task(run(), name=f"section-{name}")
        return await fut

    async def collect_pipeline_results(self, source: Any) -> dict:
        if source is None:
            raise FileNotFoundError("pipeline evidence source not provided")
        if isinstance(source, dict):
            return source

        def read_json(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)

        return await asyncio.to_thread(read_json, source)

    async def collect_circuit_breaker_incidents(self, ledger_path: str) -> dict:
        if not ledger_path:
            raise FileNotFoundError("incident ledger path not provided")

        def summarize(path: str) -> dict:
            total = 0
            by_level = Counter()
            by_revision = Counter()
            by_breaker = Counter()
            scores: list[float] = []
            first_ts = None
            last_ts = None
            bad_lines = 0

            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        incident = json.loads(line)
                    except json.JSONDecodeError:
                        bad_lines += 1
                        continue

                    total += 1

                    # EAFP for optional fields.
                    try:
                        by_level[incident["intervention_level"]] += 1
                    except KeyError:
                        by_level["unknown"] += 1

                    try:
                        by_revision[incident["model_revision"]] += 1
                    except KeyError:
                        by_revision["unknown"] += 1

                    try:
                        by_breaker[incident["breaker_id"]] += 1
                    except KeyError:
                        by_breaker["unknown"] += 1

                    try:
                        scores.append(float(incident["anomaly_score"]))
                    except (KeyError, ValueError, TypeError):
                        pass

                    ts = incident.get("timestamp")
                    if ts is not None:
                        first_ts = ts if first_ts is None else min(first_ts, ts)
                        last_ts = ts if last_ts is None else max(last_ts, ts)

            return {
                "total_incidents": total,
                "bad_lines": bad_lines,
                "by_intervention_level": dict(by_level),
                "by_model_revision": dict(by_revision),
                "by_breaker_id": dict(by_breaker),
                "mean_anomaly_score": sum(scores) / len(scores) if scores else None,
                "max_anomaly_score": max(scores) if scores else None,
                "time_range": {"first": first_ts, "last": last_ts},
            }

        return await asyncio.to_thread(summarize, ledger_path)

    async def collect_red_team_results(self, source: Any) -> dict:
        if source is None:
            raise FileNotFoundError("red-team evidence not provided")
        if isinstance(source, dict):
            return source

        def read_json(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)

        return await asyncio.to_thread(read_json, source)

    async def collect_steering_vector_evidence(self, source: Any) -> dict:
        if source is None:
            raise FileNotFoundError("steering-vector evidence not provided")
        if isinstance(source, dict):
            return source

        def read_json(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)

        return await asyncio.to_thread(read_json, source)

    async def collect_governance_metadata(self, source: Any) -> dict:
        metadata = {
            "python_version": sys.version,
            "platform": platform.platform(),
            "asyncio_loop_policy": type(asyncio.get_event_loop_policy()).__name__,
            "tool_version": self.config.get("tool_version", "0.1.0"),
            "command": self.config.get("command", "unknown"),
            "random_seed": self.config.get("random_seed"),
            "model_revision_hashes": self.config.get("model_revision_hashes", []),
            "dataset_hashes": self.config.get("dataset_hashes", []),
        }
        if isinstance(source, dict):
            metadata.update(source)
        return metadata

    async def collect_limitations(self) -> dict:
        return {
            "limitations": list(self.limitations),
            "severity_counts": dict(Counter(lim["severity"] for lim in self.limitations)),
        }

    async def write_json_report(self, report: dict, output_dir: str) -> str:
        def write():
            os.makedirs(output_dir, exist_ok=True)
            final = os.path.join(output_dir, "audit_report.json")
            tmp = final + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(report, f, indent=2, default=str)
            os.replace(tmp, final)
            return final

        return await asyncio.to_thread(write)

    async def write_markdown_report(self, report: dict, output_dir: str) -> str:
        def to_markdown(rep: dict) -> str:
            lines = [
                f"# Safety Audit Report: {rep.get('audit_id')}",
                "",
                "## Executive Summary",
                rep.get("executive_summary", ""),
                "",
                "## Limitations",
                json.dumps(rep.get("limitations", {}), indent=2, default=str),
                "",
                "## Incident Summary",
                json.dumps(rep.get("incident_summary", {}), indent=2, default=str),
                "",
                "## Red-Team Results",
                json.dumps(rep.get("red_team_results", {}), indent=2, default=str),
                "",
                "## Sign-Off",
                json.dumps(rep.get("sign_off", {}), indent=2, default=str),
            ]
            return "\n".join(lines)

        def write():
            os.makedirs(output_dir, exist_ok=True)
            final = os.path.join(output_dir, "audit_report.md")
            tmp = final + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(to_markdown(report))
            os.replace(tmp, final)
            return final

        return await asyncio.to_thread(write)

    async def write_hash_manifest(self, report: dict, output_dir: str) -> str:
        def build_manifest(rep: dict) -> dict:
            section_hashes = {}
            for key, value in rep.items():
                if key == "hash_manifest":
                    continue
                payload = json.dumps(value, sort_keys=True, default=str).encode("utf-8")
                section_hashes[key] = hashlib.sha256(payload).hexdigest()

            top_payload = json.dumps(section_hashes, sort_keys=True).encode("utf-8")
            return {
                "section_hashes": section_hashes,
                "top_level_hash": hashlib.sha256(top_payload).hexdigest(),
                "tool_version": self.config.get("tool_version", "0.1.0"),
                "generated_at": time.time(),
            }

        def write():
            os.makedirs(output_dir, exist_ok=True)
            manifest = build_manifest(report)
            final = os.path.join(output_dir, "hash_manifest.json")
            tmp = final + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(manifest, f, indent=2)
            os.replace(tmp, final)
            return final

        return await asyncio.to_thread(write)


async def redact_sensitive_fields(report: dict, policy: dict) -> dict:
    sensitive_keys = set(policy.get("keys", ["api_key", "prompt", "raw_activations", "token"]))
    redactions: list[dict] = []

    def walk(obj: Any, path: str = "") -> Any:
        if isinstance(obj, dict):
            out = {}
            for key, value in obj.items():
                new_path = f"{path}.{key}" if path else key
                if key in sensitive_keys:
                    out[key] = "<REDACTED>"
                    redactions.append({
                        "path": new_path,
                        "original_hash": hashlib.sha256(repr(value).encode("utf-8", "ignore")).hexdigest(),
                    })
                else:
                    out[key] = walk(value, new_path)
            return out
        if isinstance(obj, list):
            return [walk(v, f"{path}[{i}]") for i, v in enumerate(obj)]
        return obj

    redacted = walk(report)
    redacted.setdefault("metadata", {})
    redacted["metadata"]["redactions"] = redactions
    redacted["metadata"]["redaction_policy"] = policy
    return redacted


def apply_signoff_policy(report: dict, required_roles: set[str]) -> dict:
    signed = set(report.get("sign_off", {}).keys())
    report["status"] = "final" if required_roles <= signed else "draft"
    return report

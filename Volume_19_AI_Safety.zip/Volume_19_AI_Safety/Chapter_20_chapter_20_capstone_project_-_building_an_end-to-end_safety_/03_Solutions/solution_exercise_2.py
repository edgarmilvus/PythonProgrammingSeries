
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import asyncio
import hashlib
import json
import logging
import os
import time
import uuid
from collections import Counter, deque
from dataclasses import dataclass, field
from typing import Any, AsyncIterable, Optional

try:
    import aiofiles  # optional async file I/O
except ImportError:
    aiofiles = None

log = logging.getLogger("circuit_breaker")
if not log.handlers:
    log.addHandler(logging.NullHandler())


class CircuitBreakerHalt(Exception):
    pass


@dataclass
class InterventionResult:
    decision_id: str
    level: str
    rationale: str
    ledger_ref: str
    timestamp: float = field(default_factory=time.time)


class AsyncIncidentLedger:
    """
    Append-only, hash-chained incident ledger.
    The queue provides backpressure: if the writer is slow, producers await.
    """

    def __init__(self, path: str, *, maxsize: int = 1024):
        self.path = path
        self.queue: asyncio.Queue = asyncio.Queue(maxsize=maxsize)
        self.writer_task: Optional[asyncio.Task] = None
        self._prev_hash = "GENESIS"
        self._closed = False

    async def start(self) -> None:
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        self.writer_task = asyncio.create_task(self._writer(), name="incident-ledger-writer")

    async def _write_line(self, line: str) -> None:
        if aiofiles is not None:
            async with aiofiles.open(self.path, "a") as f:
                await f.write(line + "\n")
        else:
            def blocking_write():
                with open(self.path, "a", encoding="utf-8") as f:
                    f.write(line + "\n")
            await asyncio.to_thread(blocking_write)

    async def _writer(self):
        try:
            while True:
                incident = await self.queue.get()
                try:
                    if incident is None:
                        return
                    record = dict(incident)
                    record["prev_hash"] = self._prev_hash
                    payload = json.dumps(record, sort_keys=True, default=str).encode("utf-8")
                    record["record_hash"] = hashlib.sha256(
                        self._prev_hash.encode("utf-8") + payload
                    ).hexdigest()
                    self._prev_hash = record["record_hash"]
                    await self._write_line(json.dumps(record, sort_keys=True, default=str))
                finally:
                    self.queue.task_done()
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            log.exception("incident ledger writer crashed: %s", exc)
            # Degraded mode: subsequent record() calls still enqueue, but a
            # production system should expose a health flag and alert.
            raise

    async def record(self, incident: dict) -> str:
        if self._closed:
            raise RuntimeError("incident ledger is closed")
        await self.queue.put(incident)  # backpressure
        return incident.get("decision_id", str(uuid.uuid4()))

    async def flush(self) -> None:
        await self.queue.join()

    async def close(self) -> None:
        self._closed = True
        await self.queue.put(None)
        if self.writer_task:
            await self.writer_task


class CircuitBreaker:
    def __init__(
        self,
        breaker_id: str,
        model_ref: Any,
        thresholds: dict,
        steering_vectors: dict,
        intervention_policy: dict,
        *,
        ledger_path: str = "incident_ledger.jsonl",
    ):
        self.breaker_id = breaker_id
        self.model_ref = model_ref
        self.thresholds = dict(thresholds)
        self.steering_vectors = steering_vectors
        self.intervention_policy = intervention_policy
        self.state = "closed"
        self.incident_ledger = AsyncIncidentLedger(ledger_path)
        self.pending_decisions: dict[str, asyncio.Future] = {}
        self._applied: set[str] = set()
        self._score_window: deque[float] = deque(maxlen=200)
        self.metrics = Counter(
            batches_processed=0,
            anomalies_detected=0,
            observe=0,
            warn=0,
            steer=0,
            halt=0,
            pending_decisions=0,
            ledger_queue_depth=0,
            threshold_drift=0.0,
        )

    async def start(self) -> None:
        await self.incident_ledger.start()

    async def close(self) -> None:
        await self.incident_ledger.close()

    async def monitor_activation_stream(self, stream: AsyncIterable[Any]) -> None:
        try:
            async for batch in stream:
                self.metrics["batches_processed"] += 1
                proposal = await self.evaluate_batch(batch)
                if proposal["severity"] <= 0:
                    continue

                fut = await self.request_intervention(proposal)
                result = await fut
                await self.apply_intervention(result)
        except asyncio.CancelledError:
            await self.incident_ledger.flush()
            raise

    async def evaluate_batch(self, batch: Any) -> dict:
        # EAFP: optional residual stream key.
        try:
            residual = batch["residual_stream"]
        except (KeyError, TypeError):
            residual = batch.get("activations", []) if isinstance(batch, dict) else []
            self.metrics["degraded_missing_residual"] = self.metrics.get("degraded_missing_residual", 0) + 1

        # EAFP: optional model revision metadata.
        try:
            revision = self.model_ref.model_revision
        except AttributeError:
            revision = "unknown"

        if isinstance(residual, (list, tuple)):
            scores = [abs(float(x)) for x in residual]
        else:
            scores = [0.0]

        max_score = max(scores) if scores else 0.0
        self._score_window.extend(scores)
        await self.update_thresholds(list(self._score_window))

        threshold = self.thresholds.get("max_score", 1.0)
        severity = max(0.0, max_score - threshold)
        confidence = min(1.0, severity / max(threshold, 1e-9))

        if severity > 0:
            self.metrics["anomalies_detected"] += 1

        return {
            "batch_id": batch.get("batch_id", str(uuid.uuid4())) if isinstance(batch, dict) else str(uuid.uuid4()),
            "revision": revision,
            "max_score": max_score,
            "threshold": threshold,
            "severity": severity,
            "confidence": confidence,
            "activation_digest": hashlib.sha256(repr(residual).encode("utf-8", "ignore")).hexdigest(),
        }

    async def request_intervention(self, decision_proposal: dict) -> asyncio.Future:
        decision_id = decision_proposal["batch_id"]

        if decision_id in self.pending_decisions:
            self.metrics["duplicate_decisions"] = self.metrics.get("duplicate_decisions", 0) + 1
            return self.pending_decisions[decision_id]

        loop = asyncio.get_running_loop()
        fut = loop.create_future()
        self.pending_decisions[decision_id] = fut
        self.metrics["pending_decisions"] = len(self.pending_decisions)

        async def resolve():
            try:
                level = self._choose_level(decision_proposal)
                rationale = f"severity={decision_proposal['severity']:.3f}, confidence={decision_proposal['confidence']:.3f}"
                incident = {
                    "timestamp": time.time(),
                    "breaker_id": self.breaker_id,
                    "model_revision": decision_proposal.get("revision", "unknown"),
                    "activation_digest": decision_proposal["activation_digest"],
                    "anomaly_score": decision_proposal["max_score"],
                    "threshold_at_time": decision_proposal["threshold"],
                    "intervention_level": level,
                    "rationale": rationale,
                    "decision_id": decision_id,
                }
                ledger_ref = await self.incident_ledger.record(incident)
                result = InterventionResult(decision_id, level, rationale, ledger_ref)
                if not fut.done():
                    fut.set_result(result)

                def notify(done_fut):
                    # Non-blocking callback: schedule any I/O instead of doing it here.
                    asyncio.create_task(self._on_decision_done(done_fut, decision_proposal))

                fut.add_done_callback(notify)
            except Exception as exc:
                if not fut.done():
                    fut.set_exception(exc)
            finally:
                self.pending_decisions.pop(decision_id, None)
                self.metrics["pending_decisions"] = len(self.pending_decisions)

        asyncio.create_task(resolve(), name=f"intervention-{decision_id}")
        return fut

    def _choose_level(self, proposal: dict) -> str:
        # EAFP for optional policy key.
        try:
            halt_on_high = self.intervention_policy["halt_on_high_severity"]
        except KeyError:
            halt_on_high = True

        if halt_on_high and proposal["severity"] > self.thresholds.get("halt", 5.0):
            return "halt"
        if proposal["severity"] > self.thresholds.get("steer", 2.0):
            return "steer"
        if proposal["severity"] > self.thresholds.get("warn", 0.5):
            return "warn"
        return "observe"

    async def apply_intervention(self, result: InterventionResult) -> None:
        if result.decision_id in self._applied:
            return
        self._applied.add(result.decision_id)
        self.metrics[result.level] += 1

        if result.level == "observe":
            log.info("observe decision=%s rationale=%s", result.decision_id, result.rationale)
        elif result.level == "warn":
            log.warning("warn decision=%s rationale=%s", result.decision_id, result.rationale)
        elif result.level == "steer":
            # EAFP for missing steering vector.
            try:
                vector = self.steering_vectors[result.decision_id]
            except KeyError:
                await self.incident_ledger.record({
                    "timestamp": time.time(),
                    "breaker_id": self.breaker_id,
                    "decision_id": result.decision_id,
                    "intervention_level": "warn",
                    "rationale": "steering vector missing; degraded to warn",
                })
                return
            await asyncio.to_thread(self.model_ref.apply_steering_vector, vector)
        elif result.level == "halt":
            self.state = "open"
            for fut in list(self.pending_decisions.values()):
                if not fut.done():
                    fut.cancel()
            raise CircuitBreakerHalt(result.rationale)

    async def _on_decision_done(self, fut: asyncio.Future, proposal: dict):
        try:
            exc = fut.exception()
            if exc:
                await self.incident_ledger.record({
                    "timestamp": time.time(),
                    "breaker_id": self.breaker_id,
                    "decision_id": proposal["batch_id"],
                    "intervention_level": "failed",
                    "rationale": f"{type(exc).__name__}: {exc}",
                })
        except asyncio.CancelledError:
            await self.incident_ledger.record({
                "timestamp": time.time(),
                "breaker_id": self.breaker_id,
                "decision_id": proposal["batch_id"],
                "intervention_level": "cancelled",
                "rationale": "decision future cancelled",
            })

    async def update_thresholds(self, recent_scores: list[float]) -> None:
        """
        EWMA adaptation:
        target = mean + 3 * stddev of recent scores.
        new = 0.9 * old + 0.1 * target.
        The 0.9/0.1 blend prevents oscillation. Thresholds are clamped to
        avoid runaway drift.
        """
        if not recent_scores:
            return

        mean = sum(recent_scores) / len(recent_scores)
        variance = sum((x - mean) ** 2 for x in recent_scores) / len(recent_scores)
        target = mean + 3.0 * (variance ** 0.5)
        old = self.thresholds.get("max_score", target)
        new = 0.9 * old + 0.1 * target
        new = max(0.1, min(new, 100.0))
        self.thresholds["max_score"] = new
        self.metrics["threshold_drift"] = abs(new - old)

    def export_metrics(self) -> dict:
        metrics = dict(self.metrics)
        metrics["ledger_queue_depth"] = self.incident_ledger.queue.qsize()
        metrics["pending_decisions"] = len(self.pending_decisions)
        metrics["state"] = self.state
        return metrics


# Example use:
# breaker = CircuitBreaker("cb-1", model, {"max_score": 1.0}, {}, {})
# await breaker.start()
# await breaker.monitor_activation_stream(stream)
# await breaker.close()

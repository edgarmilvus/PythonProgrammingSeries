
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import asyncio
import hashlib
import json
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Optional

log = logging.getLogger("redteam")
if not log.handlers:
    log.addHandler(logging.NullHandler())


@dataclass
class RedTeamProbe:
    probe_id: str
    probe_type: str
    target_layer: str | None = None
    timeout: float | None = None
    metadata: dict = field(default_factory=dict)
    future: Optional[asyncio.Future] = None
    task: Optional[asyncio.Task] = None
    status: str = "pending"  # pending, running, completed, failed, cancelled, rejected


class RedTeamController:
    def __init__(self, audit_orchestrator: Any, oversight_committee: Any = None):
        self.audit_orchestrator = audit_orchestrator
        self.oversight_committee = oversight_committee
        self.active_probes: dict[str, RedTeamProbe] = {}
        self.completed_probes: dict[str, RedTeamProbe] = {}
        self.command_queue: asyncio.Queue = asyncio.Queue()
        self.shutdown_event = asyncio.Event()
        self._lock = asyncio.Lock()

    async def inject_probe(self, probe_spec: dict) -> asyncio.Future:
        # EAFP: probe_id may be absent.
        try:
            probe_id = probe_spec["probe_id"]
        except KeyError:
            probe_id = f"probe-{uuid.uuid4().hex[:8]}"

        # EAFP: type may be absent.
        try:
            probe_type = probe_spec["type"]
        except KeyError:
            probe_type = "prompt_injection"

        # EAFP: target layer may be absent.
        try:
            target_layer = probe_spec["target_layer"]
        except KeyError:
            target_layer = getattr(self.audit_orchestrator, "default_monitored_layer", "layer-0")
            probe_spec["_fallback_target_layer"] = True

        timeout = probe_spec.get("timeout")
        loop = asyncio.get_running_loop()
        fut = loop.create_future()
        probe = RedTeamProbe(
            probe_id=probe_id,
            probe_type=probe_type,
            target_layer=target_layer,
            timeout=timeout,
            metadata=dict(probe_spec),
            future=fut,
        )

        # EAFP: unsupported probe type.
        try:
            factory = PROBE_FACTORIES[probe_type]
        except KeyError as exc:
            probe.status = "rejected"
            fut.set_exception(ValueError(f"unsupported probe type: {probe_type}"))
            await self._record_incident(probe, {"rejected": True, "reason": str(exc)})
            async with self._lock:
                self.completed_probes[probe_id] = probe
            return fut

        async def runner():
            probe.status = "running"
            try:
                coro = factory(probe, self.audit_orchestrator, self)
                if probe.timeout is not None:
                    result = await asyncio.wait_for(coro, timeout=probe.timeout)
                else:
                    result = await coro

                # Hidden attack containment: verify claimed artifact hash.
                if isinstance(result, dict) and "artifact" in result and "evidence_hash" in result:
                    actual = hashlib.sha256(repr(result["artifact"]).encode("utf-8", "ignore")).hexdigest()
                    if actual != result["evidence_hash"]:
                        raise ValueError("probe artifact hash mismatch; possible corruption")

                probe.status = "completed"
                if not fut.done():
                    fut.set_result(result)
                await self._record_incident(probe, result)

            except asyncio.CancelledError:
                probe.status = "cancelled"
                if not fut.done():
                    fut.cancel()
                await self._record_incident(probe, {"cancelled": True})
                raise
            except Exception as exc:
                probe.status = "failed"
                if not fut.done():
                    fut.set_exception(exc)
                await self._record_incident(probe, {"error": type(exc).__name__, "message": str(exc)})

        probe.task = asyncio.create_task(runner(), name=f"redteam-{probe_id}")
        async with self._lock:
            self.active_probes[probe_id] = probe
        return fut

    async def _record_incident(self, probe: RedTeamProbe, result: dict) -> None:
        audit = self.audit_orchestrator
        ledger = getattr(audit, "ledger", None)
        record = {
            "timestamp": time.time(),
            "probe_id": probe.probe_id,
            "probe_type": probe.probe_type,
            "target_layer": probe.target_layer,
            "status": probe.status,
            "result": result,
        }
        if ledger is not None and hasattr(ledger, "record"):
            await ledger.record(record)
        else:
            log.info("redteam_incident %s", json.dumps(record, default=str))

    async def run_command_interface(self) -> None:
        while not self.shutdown_event.is_set():
            cmd = await self.command_queue.get()
            try:
                await self._handle_command(cmd)
            except Exception as exc:
                log.exception("command failed: %s", exc)
            finally:
                self.command_queue.task_done()

    async def _handle_command(self, cmd: str) -> None:
        parts = cmd.strip().split()
        if not parts:
            return

        if parts[0] == "inject" and len(parts) >= 4:
            probe_id, probe_type, target_layer = parts[1], parts[2], parts[3]
            fut = await self.inject_probe({
                "probe_id": probe_id,
                "type": probe_type,
                "target_layer": target_layer,
            })
            fut.add_done_callback(lambda f: log.info("probe %s done", probe_id))

        elif parts[0] == "list":
            for pid, probe in {**self.active_probes, **self.completed_probes}.items():
                print(f"{pid}: {probe.probe_type} status={probe.status}")

        elif parts[0] == "cancel" and len(parts) >= 2:
            pid = parts[1]
            probe = self.active_probes.get(pid) or self.completed_probes.get(pid)
            if probe and probe.task and not probe.task.done():
                probe.task.cancel()

        elif parts[0] == "status":
            print(json.dumps({
                "active": len(self.active_probes),
                "completed": len(self.completed_probes),
                "shutdown": self.shutdown_event.is_set(),
            }, indent=2))

        elif parts[0] == "escalate" and len(parts) >= 2:
            pid = parts[1]
            probe = self.active_probes.get(pid) or self.completed_probes.get(pid)
            if probe:
                await self.submit_to_oversight({
                    "probe_id": pid,
                    "probe_type": probe.probe_type,
                    "escalated": True,
                })

        elif parts[0] in {"shutdown", "quit", "exit"}:
            self.shutdown_event.set()

    async def run_interactive(self) -> None:
        dashboard = asyncio.create_task(self.dashboard_loop(), name="redteam-dashboard")
        try:
            await self.run_command_interface()
        finally:
            dashboard.cancel()
            await asyncio.gather(dashboard, return_exceptions=True)

    async def dashboard_loop(self) -> None:
        while not self.shutdown_event.is_set():
            await asyncio.sleep(1.0)
            print(
                f"[dashboard] active={len(self.active_probes)} "
                f"completed={len(self.completed_probes)} "
                f"shutdown={self.shutdown_event.is_set()}"
            )

    async def submit_to_oversight(self, probe_result: dict) -> dict:
        if not self.oversight_committee:
            return {"decision": "warn", "votes": [], "note": "no committee configured"}

        voters = self.oversight_committee.get("voters", [])
        tasks = [voter.vote(probe_result) for voter in voters]
        votes = await asyncio.gather(*tasks, return_exceptions=True)

        # EAFP: quorum may be missing.
        try:
            quorum = self.oversight_committee["quorum"]
        except KeyError:
            quorum = max(1, len(voters) // 2 + 1)

        valid_votes = [v for v in votes if isinstance(v, dict) and "decision" in v]
        tally: dict[str, int] = {}
        for vote in valid_votes:
            tally[vote["decision"]] = tally.get(vote["decision"], 0) + 1

        winner = max(tally, key=tally.get) if tally else "warn"
        agreed = len(valid_votes) >= quorum and tally.get(winner, 0) >= quorum

        if not agreed:
            winner = "halt" if winner in {"steer", "warn"} else "steer"

        result = {
            "probe_id": probe_result.get("probe_id"),
            "decision": winner,
            "quorum": quorum,
            "tally": tally,
            "disagreement": not agreed,
        }
        await self._record_incident(
            RedTeamProbe(probe_id=probe_result.get("probe_id", "unknown"), probe_type="oversight"),
            result,
        )
        return result


# ---------------------------------------------------------------------------
# Probe implementations
# ---------------------------------------------------------------------------
async def prompt_injection_probe(probe: RedTeamProbe, model_ref: Any, controller: RedTeamController) -> dict:
    await asyncio.sleep(0.01)
    return {
        "probe_id": probe.probe_id,
        "probe_type": "prompt_injection",
        "severity": "low",
        "finding": "prompt injection was ignored by policy",
    }


async def activation_steering_bypass_probe(probe: RedTeamProbe, model_ref: Any, controller: RedTeamController) -> dict:
    await asyncio.sleep(0.01)
    artifact = {"bypass": True, "layer": probe.target_layer}
    return {
        "probe_id": probe.probe_id,
        "probe_type": "activation_steering_bypass",
        "severity": "medium",
        "artifact": artifact,
        "evidence_hash": hashlib.sha256(repr(artifact).encode()).hexdigest(),
    }


async def circuit_breaker_evasion_probe(probe: RedTeamProbe, model_ref: Any, breaker: Any) -> dict:
    await asyncio.sleep(0.01)
    return {
        "probe_id": probe.probe_id,
        "probe_type": "circuit_breaker_evasion",
        "severity": "high",
        "finding": "evasion attempt detected",
    }


async def oversight_committee_disagreement_probe(probe: RedTeamProbe, committee: Any) -> dict:
    await asyncio.sleep(0.01)
    return {
        "probe_id": probe.probe_id,
        "probe_type": "oversight_committee_disagreement",
        "severity": "ambiguous",
        "finding": "committee disagreement simulated",
    }


PROBE_FACTORIES = {
    "prompt_injection": prompt_injection_probe,
    "activation_steering_bypass": activation_steering_bypass_probe,
    "circuit_breaker_evasion": circuit_breaker_evasion_probe,
    "oversight_committee_disagreement": oversight_committee_disagreement_probe,
}


async def stress_test(controller: RedTeamController, duration: float = 10.0):
    end = asyncio.get_running_loop().time() + duration
    counter = 0
    while asyncio.get_running_loop().time() < end:
        counter += 1
        await controller.inject_probe({
            "probe_id": f"stress-{counter}",
            "type": "prompt_injection",
            "target_layer": "layer-4",
            "timeout": 1.0,
        })
        await asyncio.sleep(0.2)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import asyncio
import hashlib
import json
import os
import pickle
import random
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, AsyncIterable, Optional

try:
    import aiofiles
except ImportError:
    aiofiles = None


@dataclass
class TrainingResult:
    steering_vector: Any
    metrics: dict
    checkpoint_path: str
    evidence_hash: str
    completed_at: float = field(default_factory=time.time)


class AnomalyDetector:
    def __init__(self, config: dict):
        self.config = config
        self.rolling_stats: dict[str, tuple[float, float]] = {}
        self.thresholds = {"z": config.get("initial_z_threshold", 3.0)}

    async def detect(self, batch: Any) -> dict:
        features = batch.get("features", {}) if isinstance(batch, dict) else {}
        scores: dict[str, float] = {}

        for key, value in features.items():
            # EAFP: missing rolling stat.
            try:
                mean, std = self.rolling_stats[key]
            except KeyError:
                mean, std = float(value), 1.0
                self.rolling_stats[key] = (mean, std)

            z = abs(float(value) - mean) / max(std, 1e-9)
            scores[key] = z

            # EWMA update.
            self.rolling_stats[key] = (
            )

        max_z = max(scores.values()) if scores else 0.0
        anomaly = max_z > self.thresholds["z"]
        return {
            "anomaly": anomaly,
            "max_z": max_z,
            "scores": scores,
            "threshold": self.thresholds["z"],
        }

    async def update_thresholds(self) -> None:
        if not self.rolling_stats:
            return
        stds = [std for _, std in self.rolling_stats.values()]
        self.thresholds["z"] = 2.5 + min(1.0, sum(stds) / max(len(stds), 1))


class SteeringVectorTrainer:
    def __init__(self, config: dict):
        self.config = config
        self.progress_event = asyncio.Event()
        self.current_progress: dict = {}
        self.training_future: Optional[asyncio.Future] = None
        self._queue: asyncio.Queue = asyncio.Queue(maxsize=config.get("max_training_requests", 2))
        self._worker: Optional[asyncio.Task] = None

    async def start(self) -> None:
        self._worker = asyncio.create_task(self._worker_loop(), name="steering-trainer-worker")

    async def train(self, anomaly_dataset: Any) -> asyncio.Future:
        loop = asyncio.get_running_loop()
        fut = loop.create_future()
        try:
            self._queue.put_nowait((fut, anomaly_dataset))
        except asyncio.QueueFull:
            fut.set_exception(RuntimeError("training request queue is full"))
        return fut

    async def _worker_loop(self) -> None:
        while True:
            fut, dataset = await self._queue.get()
            try:
                result = await self._run_training(dataset)
                if not fut.done():
                    fut.set_result(result)
            except asyncio.CancelledError:
                if not fut.done():
                    fut.set_exception(asyncio.CancelledError())
                raise
            except Exception as exc:
                if not fut.done():
                    fut.set_exception(exc)
            finally:
                self._queue.task_done()

    async def _run_training(self, dataset: Any) -> TrainingResult:
        # EAFP for optional GPU libraries.
        try:
            import cuda_training  # type: ignore
            cuda_training.init()
            device = "cuda"
        except (ImportError, RuntimeError):
            device = "cpu"

        epochs = self.config.get("epochs", 3)
        for epoch in range(epochs):
            self.current_progress = {
                "epoch": epoch,
                "step": 0,
                "loss": 1.0 / (epoch + 1),
                "device": device,
            }
            self.progress_event.set()
            self.progress_event.clear()
            await asyncio.sleep(0.01)

        def cpu_or_gpu_training():
            time.sleep(0.1)
            return {
                "vector": [random.random() for _ in range(4)],
                "loss": 0.01,
                "device": device,
            }

        metrics = await asyncio.get_running_loop().run_in_executor(None, cpu_or_gpu_training)
        vector = metrics["vector"]
        checkpoint_path = os.path.join(
            self.config.get("checkpoint_dir", "checkpoints"),
            f"steering-{uuid.uuid4().hex}.pkl",
        )
        await self.save_checkpoint(checkpoint_path, vector=vector, metrics=metrics)
        evidence_hash = hashlib.sha256(repr(vector).encode()).hexdigest()
        return TrainingResult(vector, metrics, checkpoint_path, evidence_hash)

    async def get_progress(self) -> dict:
        return dict(self.current_progress)

    async def save_checkpoint(self, path: str, *, vector: Any, metrics: dict) -> None:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        payload = {
            "vector": vector,
            "metrics": metrics,
            "optimizer_state": {"lr": self.config.get("lr", 0.001)},
            "random_seed": self.config.get("seed", 1234),
            "dataset_hash": self.config.get("dataset_hash"),
            "config": self.config,
        }

        def blocking_write():
            tmp = path + ".tmp"
            with open(tmp, "wb") as f:
                pickle.dump(payload, f)
            os.replace(tmp, path)

        await asyncio.to_thread(blocking_write)

    async def load_checkpoint(self, path: str) -> dict:
        def blocking_read():
            with open(path, "rb") as f:
                return pickle.load(f)

        try:
            checkpoint = await asyncio.to_thread(blocking_read)
        except FileNotFoundError:
            return {"missing": True, "reason": "checkpoint not found"}

        # EAFP: optional optimizer state.
        try:
            optimizer_state = checkpoint["optimizer_state"]
        except KeyError:
            optimizer_state = {"fresh": True}
            checkpoint["optimizer_state"] = optimizer_state
            checkpoint["_fallback_optimizer_state"] = True

        return checkpoint


async def activation_stream_loader(source: Any, batch_size: int) -> AsyncIterable[Any]:
    if hasattr(source, "__aiter__"):
        async for batch in source:
            yield batch
        return

    with open(source, "rb") as f:
        while True:
            chunk = await asyncio.to_thread(f.read, batch_size)
            if not chunk:
                break
            yield chunk


async def preprocess_batch(batch: Any) -> Any:
    # EAFP: optional "activations" key.
    try:
        raw = batch["activations"]
    except (KeyError, TypeError):
        raw = batch

    if not isinstance(raw, (list, tuple)):
        raw = [raw]

    mean = sum(float(x) for x in raw) / max(len(raw), 1)
    normalized = [float(x) - mean for x in raw]
    features = {f"f{i}": v for i, v in enumerate(normalized[:8])}
    return {
        "features": features,
        "raw_digest": hashlib.sha256(repr(raw).encode()).hexdigest(),
    }


async def run_pipeline(
    source: Any,
    detector: AnomalyDetector,
    trainer: SteeringVectorTrainer,
    *,
    max_queue: int = 32,
) -> None:
    await trainer.start()
    queue: asyncio.Queue = asyncio.Queue(maxsize=max_queue)

    async def producer():
        async for batch in activation_stream_loader(source, batch_size=16):
            await queue.put(batch)  # backpressure
        await queue.put(None)

    async def consumer():
        while True:
            batch = await queue.get()
            try:
                if batch is None:
                    return
                processed = await preprocess_batch(batch)
                detection = await detector.detect(processed)
                await detector.update_thresholds()
                if detection["anomaly"]:
                    # Do not await training directly; the future lets other
                    # components monitor/cancel while the pipeline continues.
                    await trainer.train(processed)
            finally:
                queue.task_done()

    prod = asyncio.create_task(producer(), name="activation-producer")
    cons = asyncio.create_task(consumer(), name="anomaly-consumer")
    await asyncio.gather(prod, cons)

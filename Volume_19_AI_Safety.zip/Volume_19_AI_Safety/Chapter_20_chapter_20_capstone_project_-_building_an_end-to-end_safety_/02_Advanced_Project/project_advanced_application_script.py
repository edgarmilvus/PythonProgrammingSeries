
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# safety_audit_circuit_breaker.py
from __future__ import annotations

import asyncio
import datetime
import math
import random
import statistics
from dataclasses import dataclass
from enum import Enum
from typing import AsyncIterator, Sequence

# A Vector is a typed tuple of floats: one activation feature per model dimension.
Vector = tuple[float, ...]

class RiskLevel(Enum):
    # Data type that classifies the audit outcome for governance review.
    SAFE = "safe"
    SUSPICIOUS = "suspicious"
    UNSAFE = "unsafe"

@dataclass(frozen=True)
class ActivationSample:
    # Frozen dataclass: immutable activation record captured from a model hook.
    request_id: str
    timestamp: datetime.datetime
    layer: int
    features: Vector
    is_red_team: bool = False

@dataclass
class Circuit:
    # A discovered direction in activation space plus runtime thresholds.
    name: str
    layer: int
    direction: Vector
    threshold: float
    steer_strength: float

@dataclass
class AuditEvent:
    # Governance-ready result for one sample after circuit-breaker evaluation.
    request_id: str
    circuit: str
    anomaly_score: float
    risk: RiskLevel
    action: str
    latency_ms: float

def dot(a: Sequence[float], b: Sequence[float]) -> float:
    # Dot product: measures alignment between an activation and a circuit direction.
    return sum(x * y for x, y in zip(a, b))

def norm(a: Sequence[float]) -> float:
    # Euclidean norm with a safety floor to avoid division by zero.
    return math.sqrt(dot(a, a)) or 1.0

def unit(a: Sequence[float]) -> Vector:
    # Normalize a vector so circuit scores are comparable across layers.
    n = norm(a)
    return tuple(x / n for x in a)

async def collect_sample(stream_id: int, layer: int, red_team: bool) -> ActivationSample:
    # Awaitable coroutine: simulates an async activation hook reading from the model.
    await asyncio.sleep(0.005)
    base = [random.gauss(0, 1) for _ in range(4)]
    if red_team:
        base[0] += 2.5  # Unsafe diagnosis-certainty feature.
        base[1] += 1.5  # PII leakage feature.
    return ActivationSample(
        request_id=f"req-{stream_id}",
        timestamp=datetime.datetime.now(datetime.timezone.utc),
        layer=layer,
        features=tuple(base),
        is_red_team=red_team,
    )

async def discover_circuit(samples: Sequence[ActivationSample], layer: int) -> Circuit:
    # Circuit discovery: contrast red-team and benign activations to find a direction.
    red = [s.features for s in samples if s.layer == layer and s.is_red_team]
    benign = [s.features for s in samples if s.layer == layer and not s.is_red_team]
    if not red or not benign:
        return Circuit("fallback", layer, (1.0, 0.0, 0.0, 0.0), 1.0, 0.5)
    mean_red = tuple(statistics.mean(v[i] for v in red) for i in range(len(red[0])))
    mean_benign = tuple(statistics.mean(v[i] for v in benign) for i in range(len(benign[0])))
    direction = unit(tuple(r - b for r, b in zip(mean_red, mean_benign)))
    benign_scores = [dot(v, direction) for v in benign]
    threshold = statistics.quantile(benign_scores, 0.95) + 0.2
    return Circuit("diagnosis_certainty", layer, direction, threshold, 0.7)

async def train_steering_vector(
    samples: Sequence[ActivationSample], circuit: Circuit, alpha: float = 0.3
) -> Circuit:
    # Steering-vector training: nudge the circuit direction away from unsafe activations.
    unsafe = [s.features for s in samples if s.is_red_team and s.layer == circuit.layer]
    if not unsafe:
        return circuit
    mean_unsafe = tuple(statistics.mean(v[i] for v in unsafe) for i in range(len(unsafe[0])))
    steered = unit(tuple(d - alpha * u for d, u in zip(circuit.direction, mean_unsafe)))
    return Circuit(circuit.name, circuit.layer, steered, circuit.threshold, circuit.steer_strength)

async def score_sample(sample: ActivationSample, circuits: Sequence[Circuit]) -> dict[str, float]:
    # Anomaly detection: project activation onto each discovered circuit direction.
    await asyncio.sleep(0.001)
    return {c.name: dot(sample.features, c.direction) for c in circuits if c.layer == sample.layer}

async def circuit_breaker(
    sample: ActivationSample, circuits: Sequence[Circuit], breaker_threshold: float
) -> AuditEvent:
    # Runtime circuit-breaker: compare anomaly score against safe/steer/block thresholds.
    started = datetime.datetime.now(datetime.timezone.utc)
    scores = await score_sample(sample, circuits)
    if not scores:
        return AuditEvent(sample.request_id, "none", 0.0, RiskLevel.SAFE, "pass", 0.0)
    name, score = max(scores.items(), key=lambda kv: kv[1])
    circuit = next(c for c in circuits if c.name == name)
    if score > breaker_threshold:
        risk, action = RiskLevel.UNSAFE, "block_and_steer"
    elif score > circuit.threshold:
        risk, action = RiskLevel.SUSPICIOUS, "steer"
    else:
        risk, action = RiskLevel.SAFE, "pass"
    elapsed = (datetime.datetime.now(datetime.timezone.utc) - started).total_seconds() * 1000
    return AuditEvent(sample.request_id, name, score, risk, action, elapsed)

async def audit_window(
    stream: AsyncIterator[ActivationSample],
    window: datetime.timedelta,
    circuits: Sequence[Circuit],
    breaker_threshold: float,
) -> list[AuditEvent]:
    # Audit window: only process samples within a timedelta lookback to bound cost.
    cutoff = datetime.datetime.now(datetime.timezone.utc) - window
    loop = asyncio.get_running_loop()
    futures: list[asyncio.Future[AuditEvent]] = []
    async for sample in stream:
        if sample.timestamp < cutoff:
            continue
        fut = loop.create_future()
        async def worker(s=sample, f=fut):
            # Future represents the pending audit result; awaitable worker fills it.
            f.set_result(await circuit_breaker(s, circuits, breaker_threshold))
        asyncio.create_task(worker())
        futures.append(fut)
    if futures:
        return await asyncio.gather(*futures)
    return []

async def synthetic_stream(n: int, layer: int) -> AsyncIterator[ActivationSample]:
    # Reproducible red-team stress stream: 25% of samples are unsafe.
    for i in range(n):
        red = random.random() < 0.25
        yield await collect_sample(i, layer, red)

async def governance_report(events: Sequence[AuditEvent], threshold: float) -> dict[str, object]:
    # Governance-ready summary: trade-off between blocking unsafe and over-blocking benign.
    blocked = [e for e in events if e.action == "block_and_steer"]
    steered = [e for e in events if e.action == "steer"]
    return {
        "threshold": threshold,
        "total": len(events),
        "blocked": len(blocked),
        "steered": len(steered),
        "block_rate": len(blocked) / max(1, len(events)),
        "avg_latency_ms": statistics.mean([e.latency_ms for e in events]) if events else 0.0,
    }

async def main() -> None:
    random.seed(7)
    layer = 12
    print("Collecting calibration samples for circuit discovery...")
    calibration = [await collect_sample(i, layer, red_team=(i % 4 == 0)) for i in range(40)]
    circuit = await discover_circuit(calibration, layer)
    circuit = await train_steering_vector(calibration, circuit, alpha=0.2)
    print(f"Discovered circuit: {circuit.name}, threshold={circuit.threshold:.3f}")

    # Evaluate two breaker thresholds to expose Safety vs. Capability trade-off.
    for threshold in (circuit.threshold + 0.1, circuit.threshold + 1.0):
        events = await audit_window(
            synthetic_stream(60, layer),
            datetime.timedelta(seconds=2),
            [circuit],
            threshold,
        )
        report = await governance_report(events, threshold)
        print(
            f"Threshold {threshold:.2f}: block_rate={report['block_rate']:.1%}, "
            f"avg_latency={report['avg_latency_ms']:.2f}ms"
        )

    print("Audit complete. Use lower thresholds for safety, higher thresholds for capability.")

if __name__ == "__main__":
    asyncio.run(main())

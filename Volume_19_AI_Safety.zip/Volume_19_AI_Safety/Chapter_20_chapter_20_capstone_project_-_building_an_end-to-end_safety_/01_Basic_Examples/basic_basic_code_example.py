
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Import the standard asyncio library so we can use Futures, Tasks, and await.
import asyncio

# Import typing helpers so the tiny SessionObject can be annotated clearly.
from typing import Any, Dict

# This variable represents the global safety policy: scores at or above 0.7 are unsafe.
# Changing it trades safety (lower threshold) against capability (higher threshold).
ANOMALY_THRESHOLD = 0.7

class SessionObject:
    # A tiny dictionary-like session. In Flask this would be `flask.session`.
    def __init__(self) -> None:
        # Internal storage variable; in Flask the signed cookie is the backing store.
        self._data: Dict[str, Any] = {}

    def get(self, key: str, default: Any = None) -> Any:
        # Read a value without raising if the key is absent.
        return self._data.get(key, default)

    def __setitem__(self, key: str, value: Any) -> None:
        # Write a value so it persists across later requests in this session.
        self._data[key] = value

    def __getitem__(self, key: str) -> Any:
        # Read a value and let KeyError signal a missing key when strict access is needed.
        return self._data[key]

    def __contains__(self, key: str) -> bool:
        # Support `"key" in session` checks for circuit-breaker state.
        return key in self._data

async def safety_audit(prompt: str, session: SessionObject) -> bool:
    # Awaitable boundary: yield control while the audit model simulates work.
    await asyncio.sleep(0.01)
    # A deterministic demonstration score based on prompt length.
    score = (len(prompt) % 10) / 10.0
    # Store the score in the session object so later requests can inspect it.
    session["last_audit_score"] = score
    # If the score crosses the safety threshold, trip the circuit breaker.
    if score >= ANOMALY_THRESHOLD:
        session["circuit_breaker"] = True
        # Increment a counter stored in the session variable.
        session["blocked_count"] = session.get("blocked_count", 0) + 1
        # Return False to tell the caller the audit failed.
        return False
    # Return True when the audit passes.
    return True

async def model_call(prompt: str, session: SessionObject) -> str:
    # Check the session before doing any expensive work.
    if session.get("circuit_breaker", False):
        # Count blocked requests and return a safe refusal.
        session["blocked_count"] = session.get("blocked_count", 0) + 1
        return "BLOCKED: circuit breaker is open due to prior anomaly."
    # Get the running event loop so we can create a Future manually.
    loop = asyncio.get_running_loop()
    # Create a Future that will eventually hold the model output string.
    future: asyncio.Future = loop.create_future()

    # Define a small background coroutine that resolves the Future.
    async def resolve_model() -> None:
        # Simulate model latency without blocking the event loop.
        await asyncio.sleep(0.02)
        # This is the "Hello World" model output.
        result = f"Hello, {prompt}!"
        # Resolve the Future only if it has not already been cancelled or resolved.
        if not future.done():
            future.set_result(result)

    # Schedule the background coroutine; it will run concurrently.
    asyncio.create_task(resolve_model())
    # Await the Future. This is where the caller pauses and yields control.
    model_output = await future
    # Run the safety audit as another awaitable step.
    is_safe = await safety_audit(prompt, session)
    # If the audit failed, block the output and keep the breaker open.
    if not is_safe:
        return "BLOCKED: safety audit flagged this request."
    # Otherwise return the model output.
    return model_output

async def main() -> None:
    # Create a per-user session object, just like Flask would attach to a request.
    session = SessionObject()
    # A list of prompts to exercise safe and unsafe paths.
    prompts = ["world", "friend", "unsafe-prompt-with-long-name", "after-trip"]
    # Iterate over prompts to simulate multiple requests in one user session.
    for prompt in prompts:
        # Show the incoming user request.
        print(f"User prompt: {prompt}")
        # Await the full circuit-breaker-protected model call.
        output = await model_call(prompt, session)
        # Show the assistant output.
        print(f"Assistant output: {output}")
        # Show the session state that persists across requests.
        print(
            "Session state: "
            f"circuit_breaker={session.get('circuit_breaker', False)}, "
            f"last_audit_score={session.get('last_audit_score')}, "
            f"blocked_count={session.get('blocked_count', 0)}"
        )
        # Visual separator between request simulations.
        print("-" * 40)

# Run the async main function when this file is executed as a script.
if __name__ == "__main__":
    asyncio.run(main())

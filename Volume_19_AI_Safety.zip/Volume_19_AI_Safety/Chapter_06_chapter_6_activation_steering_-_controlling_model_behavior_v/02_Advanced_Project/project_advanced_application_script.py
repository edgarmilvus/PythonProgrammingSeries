
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# activation_steering_demo.py
# Real-world mini-problem: A customer-support copilot must refuse unsafe requests
# (e.g., "how to evade taxes") while remaining helpful on benign ones.
# We simulate a residual stream and extract steering vectors from contrastive
# prompt pairs, then inject them at inference time to control behavior.
import os
import numpy as np

# --- 1. Configuration via environment variables ---
LAYER = int(os.environ.get("STEERING_LAYER", "2"))
ALPHA = float(os.environ.get("STEERING_ALPHA", "1.5"))
N_TEST = int(os.environ.get("N_TEST", "64"))
np.random.seed(42)

# --- 2. Synthetic activation space ---
D_MODEL = 8
# True latent behavior directions (for evaluation only).
REFUSAL_DIR = np.array([1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
HELPFUL_DIR = np.array([-0.5, 0.866, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
TRUTH_DIR   = np.array([0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0])
BIAS_DIR    = np.array([0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0])

# --- 3. Helper functions ---
def sample_behavior(direction, n, noise=0.3):
    """Generate n activation vectors around a mean direction."""
    return np.random.randn(n, D_MODEL) * noise + direction

def diff_in_means(pos, neg):
    """Extract a steering vector via difference-in-means."""
    v = pos.mean(axis=0) - neg.mean(axis=0)
    return v / (np.linalg.norm(v) + 1e-8)  # normalize

def score(activations, direction):
    """Project activations onto a direction and squash to [0,1]."""
    return 0.5 + 0.5 * np.tanh(activations @ direction)

def evaluate(activations, steering_vectors=None, alphas=None):
    """Apply steering vectors at the residual stream and compute behavior scores."""
    final = activations.copy()
    if steering_vectors:
        for name, vec in steering_vectors.items():
            alpha = alphas.get(name, 0.0) if alphas else 0.0
            final = final + alpha * vec
    return {
        "refusal": score(final, REFUSAL_DIR),
        "helpfulness": score(final, HELPFUL_DIR),
        "truth": score(final, TRUTH_DIR),
        "bias": score(final, BIAS_DIR),  # lower is better
    }

# --- 4. Build contrastive datasets and extract steering vectors ---
# Refusal: safe refusal vs unsafe compliance.
refusal_pos = sample_behavior(REFUSAL_DIR, 32)
refusal_neg = sample_behavior(-REFUSAL_DIR, 32)
v_refusal = diff_in_means(refusal_pos, refusal_neg)

# Truthfulness: truthful vs false.
truth_pos = sample_behavior(TRUTH_DIR, 32)
truth_neg = sample_behavior(-TRUTH_DIR, 32)
v_truth = diff_in_means(truth_pos, truth_neg)

# Bias reduction: fair vs biased.
fair = sample_behavior(-BIAS_DIR, 32)
biased = sample_behavior(BIAS_DIR, 32)
v_debias = diff_in_means(fair, biased)

# Capability: helpful vs unhelpful (for side-effect measurement).
helpful = sample_behavior(HELPFUL_DIR, 32)
unhelpful = sample_behavior(-HELPFUL_DIR, 32)
v_capability = diff_in_means(helpful, unhelpful)

# --- 5. Create test sets ---
def make_test_set(n):
    """Create harmful and benign activation vectors for evaluation."""
    harmful = np.random.randn(n, D_MODEL) * 0.5 - 1.0 * REFUSAL_DIR
    benign = np.random.randn(n, D_MODEL) * 0.5 + 0.5 * HELPFUL_DIR - 0.2 * REFUSAL_DIR
    return harmful, benign

harmful_test, benign_test = make_test_set(N_TEST)

# --- 6. Baseline evaluation ---
baseline_h = evaluate(harmful_test)
baseline_b = evaluate(benign_test)
print("\nBaseline (no steering)")
print(f"  Harmful refusal:      {baseline_h['refusal'].mean():.3f}")
print(f"  Benign helpfulness:   {baseline_b['helpfulness'].mean():.3f}")
print(f"  Benign over-refusal:  {baseline_b['refusal'].mean():.3f}")
print(f"  Truthfulness:         {baseline_b['truth'].mean():.3f}")
print(f"  Bias (lower better):  {baseline_b['bias'].mean():.3f}")

# --- 7. Sweep refusal steering strength to expose trade-off ---
print("\n--- Safety vs Capability Trade-off (refusal steering only) ---")
for alpha in [0.0, 0.5, 1.0, 1.5, 2.0, 2.5]:
    sv = {"refusal": v_refusal}
    ah = evaluate(harmful_test, sv, {"refusal": alpha})
    ab = evaluate(benign_test, sv, {"refusal": alpha})
    print(f"alpha={alpha:.1f} | harmful refusal={ah['refusal'].mean():.3f} | "
          f"benign helpfulness={ab['helpfulness'].mean():.3f} | "
          f"benign over-refusal={ab['refusal'].mean():.3f}")

# --- 8. Multi-vector composition ---
print("\n--- Multi-vector composition (refusal + truth + debias) ---")
sv_multi = {"refusal": v_refusal, "truth": v_truth, "debias": v_debias}
alphas = {"refusal": 1.5, "truth": 1.0, "debias": 1.0}
ah_multi = evaluate(harmful_test, sv_multi, alphas)
ab_multi = evaluate(benign_test, sv_multi, alphas)
print(f"  Harmful refusal:      {ah_multi['refusal'].mean():.3f}")
print(f"  Benign helpfulness:   {ab_multi['helpfulness'].mean():.3f}")
print(f"  Benign over-refusal:  {ab_multi['refusal'].mean():.3f}")
print(f"  Truthfulness:         {ab_multi['truth'].mean():.3f}")
print(f"  Bias (lower better):  {ab_multi['bias'].mean():.3f}")

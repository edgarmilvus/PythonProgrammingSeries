
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# basic_activation_steering.py
# A fully self-contained Hello-World example of activation steering.
# It uses only the Python standard library.

import math

# ---------------------------------------------------------------------------
# 1. Tiny residual-stream dimension and vocabulary.
# ---------------------------------------------------------------------------
D = 2  # Each activation is a 2D vector: [valence, intensity].

VOCAB = {
    "good":     [ 1.0,  0.5],
    "great":    [ 1.2,  0.8],
    "bad":      [-1.0,  0.5],
    "terrible": [-1.2,  0.8],
    "okay":     [ 0.0,  0.0],
    "movie":    [ 0.0,  0.0],
}

# ---------------------------------------------------------------------------
# 2. Toy prompt encoder.
# ---------------------------------------------------------------------------
def encode_prompt(words):
    """Sum word vectors to create a residual-stream activation."""
    result = [0.0] * D
    for word in words:
        word_vector = VOCAB[word]
        for i in range(D):
            result[i] += word_vector[i]
    return result

# ---------------------------------------------------------------------------
# 3. Toy classifier head.
# ---------------------------------------------------------------------------
W = [
    [-1.0, 0.2],  # negative logit
    [ 1.0, 0.2],  # positive logit
]
b = [0.0, 0.0]

def dot(a, b):
    """Dot product of two equal-length vectors."""
    return sum(x * y for x, y in zip(a, b))

def model_logits(x):
    """Map residual-stream activation x to [negative, positive] logits."""
    return [dot(W[0], x) + b[0], dot(W[1], x) + b[1]]

# ---------------------------------------------------------------------------
# 4. Contrastive prompts.
# ---------------------------------------------------------------------------
positive_prompts = [["good", "movie"], ["great", "movie"]]
negative_prompts = [["bad", "movie"], ["terrible", "movie"]]
neutral_prompt = ["okay", "movie"]

# ---------------------------------------------------------------------------
# 5. Extract steering vector by difference-in-means.
# ---------------------------------------------------------------------------
pos_acts = [encode_prompt(p) for p in positive_prompts]
neg_acts = [encode_prompt(p) for p in negative_prompts]

def mean(vectors):
    """Element-wise mean of a list of vectors."""
    n = len(vectors)
    dim = len(vectors[0])
    return [sum(v[i] for v in vectors) / n for i in range(dim)]

pos_mean = mean(pos_acts)
neg_mean = mean(neg_acts)
steering_vector = [pos_mean[i] - neg_mean[i] for i in range(D)]

def norm(v):
    """Euclidean norm of a vector."""
    return math.sqrt(sum(x * x for x in v))

steering_vector = [x / norm(steering_vector) for x in steering_vector]

# ---------------------------------------------------------------------------
# 6. Baseline inference.
# ---------------------------------------------------------------------------
def softmax(logits):
    """Convert logits to probabilities with numerical stability."""
    m = max(logits)
    exps = [math.exp(z - m) for z in logits]
    total = sum(exps)
    return [e / total for e in exps]

x_neutral = encode_prompt(neutral_prompt)
logits_before = model_logits(x_neutral)
probs_before = softmax(logits_before)

# ---------------------------------------------------------------------------
# 7. Steered inference.
# ---------------------------------------------------------------------------
alpha = 2.0  # Steering strength.
x_steered = [x_neutral[i] + alpha * steering_vector[i] for i in range(D)]
logits_after = model_logits(x_steered)
probs_after = softmax(logits_after)

# ---------------------------------------------------------------------------
# 8. Report.
# ---------------------------------------------------------------------------
print("Residual stream for neutral prompt:", x_neutral)
print("Steering vector:", steering_vector)
print("Alpha:", alpha)
print()
print("Before steering:")
print("  logits [negative, positive]:", logits_before)
print("  probabilities [negative, positive]:", probs_before)
print()
print("After steering:")
print("  steered residual stream:", x_steered)
print("  logits [negative, positive]:", logits_after)
print("  probabilities [negative, positive]:", probs_after)

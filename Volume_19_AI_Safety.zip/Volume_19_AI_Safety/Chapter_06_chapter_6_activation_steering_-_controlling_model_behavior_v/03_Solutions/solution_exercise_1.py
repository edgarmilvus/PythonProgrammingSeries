
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# steering/extract.py
from __future__ import annotations

import hashlib
import json
import logging
import os
import platform
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

import torch

LOG = logging.getLogger("steer.extract")


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except ValueError as exc:
        raise ValueError(f"{name} must be an integer") from exc


@dataclass
class SteeringExtractionConfig:
    model_id: str
    model_revision: str | None
    device: str
    dtype: str
    layer: int
    token_position: str
    first_n: int
    method: str
    normalize: str
    vector_path: str
    metadata_path: str | None
    dataset_path: str
    batch_size: int
    max_length: int
    overwrite: bool
    log_level: str
    dry_run: bool
    capture_mode: str = "selected_tokens_only"
    residual_location: str = "residual_post"
    empty_pair_policy: str = "skip"
    custom_token_position_fn: Callable | None = None

    @classmethod
    def from_env(cls) -> "SteeringExtractionConfig":
        cfg = cls(
            model_id=os.getenv("STEER_MODEL_ID", ""),
            model_revision=os.getenv("STEER_MODEL_REVISION"),
            device=os.getenv("STEER_DEVICE", "auto"),
            dtype=os.getenv("STEER_DTYPE", "float32"),
            layer=_env_int("STEER_LAYER", 0),
            token_position=os.getenv("STEER_TOKEN_POSITION", "last_token"),
            first_n=_env_int("STEER_FIRST_N", 1),
            method=os.getenv("STEER_EXTRACTION_METHOD", "difference_in_means"),
            normalize=os.getenv("STEER_NORMALIZE", "none"),
            vector_path=os.getenv("STEER_VECTOR_PATH", "steering_vector.pt"),
            metadata_path=os.getenv("STEER_METADATA_PATH"),
            dataset_path=os.getenv("STEER_DATASET_PATH", "pairs.jsonl"),
            batch_size=_env_int("STEER_BATCH_SIZE", 8),
            max_length=_env_int("STEER_MAX_LENGTH", 512),
            overwrite=_env_bool("STEER_OVERWRITE", False),
            log_level=os.getenv("STEER_LOG_LEVEL", "INFO"),
            dry_run=_env_bool("STEER_DRY_RUN", False),
            capture_mode=os.getenv("STEER_CAPTURE_MODE", "selected_tokens_only"),
            residual_location=os.getenv("STEER_RESIDUAL_LOCATION", "residual_post"),
            empty_pair_policy=os.getenv("STEER_EMPTY_PAIR_POLICY", "skip"),
        )
        cfg.validate()
        return cfg

    def validate(self) -> None:
        if not self.model_id:
            raise ValueError("STEER_MODEL_ID is required")
        if self.dtype not in {"float32", "float16", "bfloat16"}:
            raise ValueError("STEER_DTYPE must be float32, float16, or bfloat16")
        if self.token_position not in {"last_token", "mean_tokens", "first_n", "all_tokens", "custom"}:
            raise ValueError("Unsupported STEER_TOKEN_POSITION")
        if self.normalize not in {"none", "unit", "std"}:
            raise ValueError("STEER_NORMALIZE must be none, unit, or std")
        if self.layer < 0:
            raise ValueError("STEER_LAYER is zero-based over transformer blocks; must be >= 0")
        if self.batch_size < 1:
            raise ValueError("STEER_BATCH_SIZE must be >= 1")
        if self.max_length < 1:
            raise ValueError("STEER_MAX_LENGTH must be >= 1")
        if self.empty_pair_policy not in {"skip", "error"}:
            raise ValueError("STEER_EMPTY_PAIR_POLICY must be skip or error")


class ExtractionStrategyMeta(type):
    """Metaclass registry enforcing the extraction plugin contract."""
    registry: dict[str, type] = {}

    def __new__(mcls, name, bases, namespace, allow_override: bool = False):
        cls = super().__new__(mcls, name, bases, namespace)
        if name == "ExtractionStrategy":
            return cls
        if "strategy_name" not in namespace:
            raise TypeError(f"{name} must define strategy_name")
        if "extract" not in namespace:
            raise TypeError(f"{name} must implement extract()")
        sname = namespace["strategy_name"]
        if sname in mcls.registry and not allow_override:
            raise ValueError(f"Strategy {sname!r} already registered; pass allow_override=True to replace")
        mcls.registry[sname] = cls
        return cls


class ExtractionStrategy(metaclass=ExtractionStrategyMeta):
    strategy_name: str
    requires_pairs: bool = True

    def extract(self, activations: Any, metadata: dict) -> Any:
        raise NotImplementedError


class DifferenceInMeansStrategy(ExtractionStrategy):
    strategy_name = "difference_in_means"
    requires_pairs = True

    def extract(self, activations: dict, metadata: dict) -> torch.Tensor:
        pos = activations["positive"]
        neg = activations["negative"]
        if pos.ndim == 3:  # [N, T, H] fallback for all_tokens
            pos = pos.mean(dim=1)
            neg = neg.mean(dim=1)
        pos_mean = pos.mean(dim=0)
        neg_mean = neg.mean(dim=0)
        vec = pos_mean - neg_mean

        mode = metadata.get("normalize", "none")
        if mode == "unit":
            vec = vec / vec.norm(p=2).clamp_min(1e-12)
        elif mode == "std":
            diff = pos - neg
            std = diff.std(dim=0, unbiased=False).clamp_min(1e-6)
            vec = vec / std
        return vec.detach().cpu()


def load_prompt_pairs(path: str) -> list[dict]:
    pairs: list[dict] = []
    with open(path, "r", encoding="utf-8") as f:
        for lineno, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSONL at line {lineno}") from exc
            if "positive" not in obj or "negative" not in obj:
                raise ValueError(f"Line {lineno} must contain 'positive' and 'negative'")
            pairs.append({
                "positive": str(obj["positive"]),
                "negative": str(obj["negative"]),
                **{k: v for k, v in obj.items() if k not in {"positive", "negative"}},
            })
    return pairs


def _dtype_from_name(name: str) -> torch.dtype:
    return {"float32": torch.float32, "float16": torch.float16, "bfloat16": torch.bfloat16}[name]


def _resolve_device(requested: str, model: torch.nn.Module) -> torch.device:
    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu")
    return torch.device(requested)


def _get_transformer_layers(model: torch.nn.Module):
    for path in (("model", "layers"), ("transformer", "h"), ("gpt_neox", "layers")):
        obj = model
        try:
            for attr in path:
                obj = getattr(obj, attr)
            return obj
        except AttributeError:
            continue
    raise ValueError("Could not locate transformer blocks; extend _get_transformer_layers for this architecture")


def _select_tokens(acts: torch.Tensor, mask: torch.Tensor, cfg: SteeringExtractionConfig, tok: dict) -> torch.Tensor:
    B, T, H = acts.shape
    if cfg.token_position == "last_token":
        idx_grid = torch.arange(T, device=mask.device).unsqueeze(0).expand(B, T)
        last = (idx_grid * mask).max(dim=1).values
        return acts[torch.arange(B, device=acts.device), last]

    if cfg.token_position == "mean_tokens":
        lengths = mask.sum(dim=1).clamp_min(1)
        return (acts * mask.unsqueeze(-1)).sum(dim=1) / lengths.unsqueeze(-1)

    if cfg.token_position == "first_n":
        out = []
        for b in range(B):
            idx = mask[b].nonzero(as_tuple=True)[0][: cfg.first_n]
            if len(idx) == 0:
                idx = torch.tensor([0], device=acts.device)
            out.append(acts[b, idx].mean(dim=0))
        return torch.stack(out, dim=0)

    if cfg.token_position == "all_tokens":
        # For simplicity, return mean over non-padding tokens. A full implementation should return tokens + mask.
        lengths = mask.sum(dim=1).clamp_min(1)
        return (acts * mask.unsqueeze(-1)).sum(dim=1) / lengths.unsqueeze(-1)

    if cfg.token_position == "custom":
        if cfg.custom_token_position_fn is None:
            raise ValueError("custom token position requires custom_token_position_fn")
        return cfg.custom_token_position_fn(tok["input_ids"], mask, {"config": cfg})

    raise ValueError(f"Unsupported token position: {cfg.token_position}")


def collect_residual_activations(model, tokenizer, pairs: list[dict], cfg: SteeringExtractionConfig) -> dict:
    layers = _get_transformer_layers(model)
    if cfg.layer >= len(layers):
        raise ValueError(f"STEER_LAYER={cfg.layer} invalid; model has {len(layers)} transformer blocks (0..{len(layers)-1})")

    captured: dict[str, torch.Tensor] = {}

    def hook(module, inputs, output):
        hs = output[0] if isinstance(output, tuple) else output
        captured["act"] = hs.detach()

    handle = layers[cfg.layer].register_forward_hook(hook)
    pos_batches, neg_batches = [], []
    device = next(model.parameters()).device

    try:
        model.eval()
        for start in range(0, len(pairs), cfg.batch_size):
            batch = pairs[start:start + cfg.batch_size]
            for condition, sink in (("positive", pos_batches), ("negative", neg_batches)):
                prompts = [p[condition] for p in batch]
                tok = tokenizer(
                    prompts,
                    return_tensors="pt",
                    padding=True,
                    truncation=True,
                    max_length=cfg.max_length,
                ).to(device)
                with torch.no_grad():
                    model(**tok)
                acts = captured["act"].to(device)
                mask = tok["attention_mask"].to(acts.device)
                selected = _select_tokens(acts, mask, cfg, tok)
                sink.append(selected.cpu())
    finally:
        handle.remove()

    pos = torch.cat(pos_batches, dim=0)
    neg = torch.cat(neg_batches, dim=0)
    return {
        "positive": pos,
        "negative": neg,
        "metadata": {"raw_shape": tuple(pos.shape), "raw_dtype": str(pos.dtype)},
    }


def _dataset_hash(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def extract_steering_vector(model, tokenizer, pairs: list[dict], cfg: SteeringExtractionConfig) -> tuple[torch.Tensor, dict]:
    strategy_cls = ExtractionStrategyMeta.registry.get(cfg.method)
    if strategy_cls is None:
        raise ValueError(f"Unknown strategy {cfg.method!r}; registered={list(ExtractionStrategyMeta.registry)}")
    strategy = strategy_cls()

    activations = collect_residual_activations(model, tokenizer, pairs, cfg)
    vector = strategy.extract(activations, {"normalize": cfg.normalize, **activations["metadata"]})

    metadata = {
        "model_id": cfg.model_id,
        "model_revision": cfg.model_revision,
        "layer": cfg.layer,
        "residual_location": cfg.residual_location,
        "token_position": cfg.token_position,
        "first_n": cfg.first_n if cfg.token_position == "first_n" else None,
        "extraction_method": cfg.method,
        "normalize": cfg.normalize,
        "num_pairs": len(pairs),
        "raw_activation_shape": list(activations["metadata"]["raw_shape"]),
        "raw_dtype": activations["metadata"]["raw_dtype"],
        "vector_norm": float(vector.norm(p=2)),
        "vector_dtype": str(vector.dtype),
        "vector_shape": list(vector.shape),
        "timestamp": time.time(),
        "dataset_path": cfg.dataset_path,
        "dataset_hash": _dataset_hash(cfg.dataset_path),
        "python_version": platform.python_version(),
        "torch_version": torch.__version__,
        "env": {k: v for k, v in os.environ.items() if k.startswith("STEER_")},
    }
    return vector, metadata


def save_artifact(vector: torch.Tensor, metadata: dict, cfg: SteeringExtractionConfig) -> None:
    path = Path(cfg.vector_path)
    if path.exists() and not cfg.overwrite:
        raise FileExistsError(f"{path} exists and STEER_OVERWRITE=false")
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save({"vector": vector, "metadata": metadata}, path)
    if cfg.metadata_path:
        Path(cfg.metadata_path).write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    LOG.info("Saved vector to %s and metadata to %s", path, cfg.metadata_path)


def main() -> None:
    cfg = SteeringExtractionConfig.from_env()
    logging.basicConfig(level=getattr(logging, cfg.log_level.upper(), logging.INFO))
    if cfg.dry_run:
        print(json.dumps(cfg.__dict__, indent=2, default=str))
        pairs = load_prompt_pairs(cfg.dataset_path)
        print(f"Dry-run: loaded {len(pairs)} pairs. No model loaded.")
        return

    from transformers import AutoModelForCausalLM, AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(cfg.model_id, revision=cfg.model_revision)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        cfg.model_id,
        revision=cfg.model_revision,
        torch_dtype=_dtype_from_name(cfg.dtype),
    )
    device = _resolve_device(cfg.device, model)
    model.to(device)

    pairs = load_prompt_pairs(cfg.dataset_path)
    vector, metadata = extract_steering_vector(model, tokenizer, pairs, cfg)
    save_artifact(vector, metadata, cfg)


if __name__ == "__main__":
    main()

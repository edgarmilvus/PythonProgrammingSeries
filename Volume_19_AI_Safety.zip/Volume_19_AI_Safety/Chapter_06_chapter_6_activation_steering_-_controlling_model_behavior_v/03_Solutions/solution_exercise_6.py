
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_6.py
# Description: Solution for Exercise 6
# ==========================================

# steering/report.py
from __future__ import annotations

import hashlib
import json
import os
import platform
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import torch

__import__("logging").basicConfig(level=__import__("logging").INFO)


class ReportSectionMeta(type):
    registry: dict[str, type] = {}

    def __new__(mcls, name, bases, namespace, allow_override: bool = False):
        cls = super().__new__(mcls, name, bases, namespace)
        if name == "ReportSection":
            return cls
        if "section_name" not in namespace:
            raise TypeError(f"{name} must define section_name")
        if "required_context_keys" not in namespace:
            raise TypeError(f"{name} must define required_context_keys")
        if "render" not in namespace or "to_dict" not in namespace:
            raise TypeError(f"{name} must implement render() and to_dict()")
        sname = namespace["section_name"]
        if sname in mcls.registry and not allow_override:
            raise ValueError(f"Report section {sname!r} already registered")
        mcls.registry[sname] = cls
        return cls


class ReportSection(metaclass=ReportSectionMeta):
    section_name: str
    required_context_keys: list[str]

    def render(self, context: dict) -> str:
        raise NotImplementedError

    def to_dict(self, context: dict) -> dict:
        raise NotImplementedError


class ExperimentManifestSection(ReportSection):
    section_name = "experiment_manifest"
    required_context_keys = ["experiment_name", "timestamp"]

    def render(self, context):
        return f"# Experiment Manifest\n\n- Name: {context['experiment_name']}\n- Timestamp: {context['timestamp']}\n"

    def to_dict(self, context):
        return {"experiment_name": context["experiment_name"], "timestamp": context["timestamp"]}


class VectorMetadataSection(ReportSection):
    section_name = "vector_metadata"
    required_context_keys = ["vector_paths"]

    def render(self, context):
        lines = ["# Vector Metadata"]
        for path in context["vector_paths"]:
            lines.append(f"- `{path}`")
        return "\n".join(lines) + "\n"

    def to_dict(self, context):
        return {"vector_paths": context["vector_paths"]}


class SweepSummarySection(ReportSection):
    section_name = "sweep_summary"
    required_context_keys = ["sweep_results"]

    def render(self, context):
        rows = context["sweep_results"]
        return f"# Sweep Summary\n\n{len(rows)} configurations evaluated.\n"

    def to_dict(self, context):
        return {"num_rows": len(context["sweep_results"])}


class ChosenConfigurationSection(ReportSection):
    section_name = "chosen_configuration"
    required_context_keys = ["chosen_layer", "chosen_coefficient"]

    def render(self, context):
        return f"# Chosen Configuration\n\n- Layer: {context['chosen_layer']}\n- Coefficient: {context['chosen_coefficient']}\n"

    def to_dict(self, context):
        return {"layer": context["chosen_layer"], "coefficient": context["chosen_coefficient"]}


class SideEffectsAuditSection(ReportSection):
    section_name = "side_effects_audit"
    required_context_keys = ["audit_results"]

    def render(self, context):
        return f"# Side-Effects Audit\n\n{json.dumps(context['audit_results'], indent=2)}\n"

    def to_dict(self, context):
        return context["audit_results"]


class ReproductionCommandsSection(ReportSection):
    section_name = "reproduction_commands"
    required_context_keys = ["env"]

    def render(self, context):
        lines = ["# Reproduction Commands\n"]
        for k, v in sorted(context["env"].items()):
            if k.startswith("REPORT_") or k.startswith("STEER_") or k.startswith("SWEEP_"):
                lines.append(f"export {k}={v!r}")
        return "\n".join(lines) + "\n"

    def to_dict(self, context):
        return {"env": context["env"]}


class FailureLogSection(ReportSection):
    section_name = "failure_log"
    required_context_keys = ["failures"]

    def render(self, context):
        return "# Failure Log\n\n" + "\n".join(f"- {f}" for f in context["failures"]) + "\n"

    def to_dict(self, context):
        return {"failures": context["failures"]}


@dataclass
class ReportConfig:
    experiment_name: str
    output_dir: str
    model_id: str
    model_revision: str | None
    dataset_path: str
    vector_paths: list[str]
    sweep_config_path: str | None
    chosen_layer: int
    chosen_coefficient: float
    include_sections: list[str]
    hash_algorithm: str
    fail_on_missing: bool
    redact_outputs: bool

    @classmethod
    def from_env(cls):
        return cls(
            experiment_name=os.getenv("REPORT_EXPERIMENT_NAME", "steering_experiment"),
            output_dir=os.getenv("REPORT_OUTPUT_DIR", "report_output"),
            model_id=os.getenv("REPORT_MODEL_ID", ""),
            model_revision=os.getenv("REPORT_MODEL_REVISION"),
            dataset_path=os.getenv("REPORT_DATASET_PATH", ""),
            vector_paths=[p for p in os.getenv("REPORT_VECTOR_PATHS", "").split(",") if p],
            sweep_config_path=os.getenv("REPORT_SWEEP_CONFIG_PATH"),
            chosen_layer=int(os.getenv("REPORT_CHOSEN_LAYER", "0")),
            chosen_coefficient=float(os.getenv("REPORT_CHOSEN_COEFFICIENT", "1.0")),
            include_sections=[s.strip() for s in os.getenv("REPORT_INCLUDE_SECTIONS", "experiment_manifest,vector_metadata,sweep_summary,chosen_configuration,side_effects_audit,reproduction_commands,failure_log").split(",") if s.strip()],
            hash_algorithm=os.getenv("REPORT_HASH_ALGORITHM", "sha256"),
            fail_on_missing=os.getenv("REPORT_FAIL_ON_MISSING", "true").lower() == "true",
            redact_outputs=os.getenv("REPORT_REDACT_OUTPUTS", "true").lower() == "true",
        )


def _hash_file(path: str, alg: str) -> str:
    h = hashlib.new(alg)
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def load_artifacts(cfg: ReportConfig) -> dict:
    artifacts: dict[str, Any] = {"vectors": [], "failures": []}
    for path in cfg.vector_paths:
        if Path(path).exists():
            artifacts["vectors"].append(torch.load(path, map_location="cpu"))
        else:
            artifacts["failures"].append(f"Missing vector: {path}")
            if cfg.fail_on_missing:
                raise FileNotFoundError(path)
    return artifacts


def build_context(cfg: ReportConfig, artifacts: dict) -> dict:
    context = {
        "experiment_name": cfg.experiment_name,
        "timestamp": time.time(),
        "vector_paths": cfg.vector_paths,
        "chosen_layer": cfg.chosen_layer,
        "chosen_coefficient": cfg.chosen_coefficient,
        "sweep_results": [],
        "audit_results": {},
        "failures": artifacts.get("failures", []),
        "env": dict(os.environ),
        "python_version": platform.python_version(),
        "torch_version": torch.__version__,
    }
    return context


def generate_report(cfg: ReportConfig) -> dict:
    artifacts = load_artifacts(cfg)
    context = build_context(cfg, artifacts)
    sections = []
    for name in cfg.include_sections:
        cls = ReportSectionMeta.registry.get(name)
        if cls is None:
            raise ValueError(f"Unknown report section {name!r}; available={list(ReportSectionMeta.registry)}")
        section = cls()
        missing = [k for k in section.required_context_keys if k not in context]
        if missing:
            msg = f"Section {name} missing context keys: {missing}"
            if cfg.fail_on_missing:
                raise ValueError(msg)
            context["failures"].append(msg)
            continue
        sections.append({"name": name, "markdown": section.render(context), "json": section.to_dict(context)})

    manifest = []
    for path in cfg.vector_paths:
        if Path(path).exists():
            manifest.append({
                "path": path,
                "size": Path(path).stat().st_size,
                "hash": _hash_file(path, cfg.hash_algorithm),
                "mtime": Path(path).stat().st_mtime,
            })
    report = {
        "config": cfg.__dict__,
        "sections": sections,
        "manifest": manifest,
        "redacted": cfg.redact_outputs,
    }

    out = Path(cfg.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / "report.json").write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
    md = "\n\n".join(s["markdown"] for s in sections)
    (out / "report.md").write_text(md, encoding="utf-8")
    (out / "report.html").write_text(f"<html><body><pre>{md}</pre></body></html>", encoding="utf-8")
    return report


def main():
    cfg = ReportConfig.from_env()
    if not cfg.model_id:
        raise ValueError("REPORT_MODEL_ID required")
    report = generate_report(cfg)
    print(f"Report generated with {len(report['sections'])} sections.")


if __name__ == "__main__":
    main()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# steering/compose.py
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import torch

LOG = __import__("logging").getLogger("steer.compose")


class CompositionStrategyMeta(type):
    registry: dict[str, type] = {}

    def __new__(mcls, name, bases, namespace, allow_override: bool = False):
        cls = super().__new__(mcls, name, bases, namespace)
        if name == "CompositionStrategy":
            return cls
        if "method_name" not in namespace:
            raise TypeError(f"{name} must define method_name")
        if "compose" not in namespace:
            raise TypeError(f"{name} must implement compose()")
        if "supports_multiple_layers" not in namespace:
            raise TypeError(f"{name} must declare supports_multiple_layers")
        mname = namespace["method_name"]
        if mname in mcls.registry and not allow_override:
            raise ValueError(f"Composition method {mname!r} already registered")
        mcls.registry[mname] = cls
        return cls


class CompositionStrategy(metaclass=CompositionStrategyMeta):
    method_name: str
    supports_multiple_layers: bool = False

    def compose(self, vectors: list[torch.Tensor], weights: list[float], metadata: dict) -> Any:
        raise NotImplementedError


class WeightedSum(CompositionStrategy):
    method_name = "weighted_sum"
    supports_multiple_layers = False

    def compose(self, vectors, weights, metadata):
        out = None
        for v, w in zip(vectors, weights):
            if metadata.get("normalize_each"):
                v = v / v.norm(p=2).clamp_min(1e-12)
            term = w * v
            out = term if out is None else out + term
        return out


class Sequential(CompositionStrategy):
    method_name = "sequential"
    supports_multiple_layers = True

    def compose(self, vectors, weights, metadata):
        return [{"vector": v, "weight": w, "layer": metadata.get("layers", [None] * len(vectors))[i]} for i, (v, w) in enumerate(zip(vectors, weights))]


class OrthogonalProjection(CompositionStrategy):
    method_name = "orthogonal_projection"
    supports_multiple_layers = False

    def compose(self, vectors, weights, metadata):
        basis: list[torch.Tensor] = []
        out_parts = []
        for v, w in zip(vectors, weights):
            v = v / v.norm(p=2).clamp_min(1e-12) if metadata.get("normalize_each") else v
            for b in basis:
                v = v - torch.dot(v, b) * b
            if v.norm(p=2) > 1e-8:
                basis.append(v / v.norm(p=2))
            out_parts.append(w * v)
        return sum(out_parts)


class ConditionalGate(CompositionStrategy):
    method_name = "conditional_gate"
    supports_multiple_layers = False

    def compose(self, vectors, weights, metadata):
        base = WeightedSum().compose(vectors, weights, metadata)
        gate = metadata.get("gate_value", 1.0)
        return gate * base


def load_vector(path: str) -> tuple[torch.Tensor, dict]:
    artifact = torch.load(path, map_location="cpu")
    if "vector" not in artifact or "metadata" not in artifact:
        raise ValueError(f"{path} missing vector/metadata")
    return artifact["vector"], artifact["metadata"]


def _cosine_matrix(vectors: list[torch.Tensor]) -> list[list[float]]:
    mat = []
    for a in vectors:
        row = []
        for b in vectors:
            row.append(float(torch.nn.functional.cosine_similarity(a.flatten(), b.flatten(), dim=0)))
        mat.append(row)
    return mat


def check_compatibility(vectors, metadatas, cfg) -> list[str]:
    warnings: list[str] = []
    if not vectors:
        raise ValueError("No vectors provided")
    hidden = vectors[0].shape[-1]
    for i, (v, m) in enumerate(zip(vectors, metadatas)):
        if v.shape[-1] != hidden:
            raise ValueError(f"Hidden size mismatch at vector {i}: {v.shape[-1]} != {hidden}")
        if m.get("model_id") != cfg.model_id:
            raise ValueError(f"Model ID mismatch at vector {i}: {m.get('model_id')} != {cfg.model_id}")
        if cfg.model_revision and m.get("model_revision") != cfg.model_revision:
            raise ValueError(f"Model revision mismatch at vector {i}")
        if m.get("layer") != cfg.layer and cfg.method != "sequential":
            raise ValueError(f"Layer mismatch at vector {i}: {m.get('layer')} != {cfg.layer}")
        if m.get("residual_location") != cfg.residual_location:
            raise ValueError(f"Residual location mismatch at vector {i}")

    sim = _cosine_matrix(vectors)
    for i in range(len(vectors)):
        for j in range(i + 1, len(vectors)):
            if sim[i][j] > cfg.conflict_threshold:
                warnings.append(f"Vectors {i} and {j} are redundant: cosine={sim[i][j]:.3f}")
            if sim[i][j] < cfg.cancellation_threshold:
                warnings.append(f"Vectors {i} and {j} may cancel: cosine={sim[i][j]:.3f}")
            ratio = max(vectors[i].norm(), vectors[j].norm()) / min(vectors[i].norm(), vectors[j].norm()).clamp_min(1e-12)
            if ratio > cfg.norm_ratio_threshold:
                warnings.append(f"Vectors {i} and {j} have norm ratio {ratio:.2f}; one may dominate")
    return warnings


@dataclass
class ComposeConfig:
    model_id: str
    model_revision: str | None
    vector_paths: list[str]
    weights: list[float]
    method: str
    layer: int
    residual_location: str
    conflict_threshold: float
    cancellation_threshold: float
    norm_ratio_threshold: float
    normalize_each: bool
    output_path: str
    gate_type: str = "none"
    gate_threshold: float = 0.5
    dry_run: bool = False

    @classmethod
    def from_env(cls):
        return cls(
            model_id=os.getenv("COMPOSE_MODEL_ID", ""),
            model_revision=os.getenv("COMPOSE_MODEL_REVISION"),
            vector_paths=[p for p in os.getenv("COMPOSE_VECTOR_PATHS", "").split(",") if p],
            weights=[float(x) for x in os.getenv("COMPOSE_WEIGHTS", "").split(",") if x],
            method=os.getenv("COMPOSE_METHOD", "weighted_sum"),
            layer=int(os.getenv("COMPOSE_LAYER", "0")),
            residual_location=os.getenv("COMPOSE_RESIDUAL_LOCATION", "residual_post"),
            conflict_threshold=float(os.getenv("COMPOSE_CONFLICT_THRESHOLD", "0.95")),
            cancellation_threshold=float(os.getenv("COMPOSE_CANCELLATION_THRESHOLD", "-0.9")),
            norm_ratio_threshold=float(os.getenv("COMPOSE_NORM_RATIO_THRESHOLD", "10.0")),
            normalize_each=os.getenv("COMPOSE_NORMALIZE_EACH", "false").lower() == "true",
            output_path=os.getenv("COMPOSE_OUTPUT_PATH", "composed_vector.pt"),
            gate_type=os.getenv("COMPOSE_GATE_TYPE", "none"),
            gate_threshold=float(os.getenv("COMPOSE_GATE_THRESHOLD", "0.5")),
            dry_run=os.getenv("COMPOSE_DRY_RUN", "false").lower() == "true",
        )


def compose_vectors(cfg: ComposeConfig) -> tuple[torch.Tensor, dict]:
    vectors, metadatas = [], []
    for path in cfg.vector_paths:
        v, m = load_vector(path)
        vectors.append(v)
        metadatas.append(m)
    if len(vectors) != len(cfg.weights):
        raise ValueError("COMPOSE_WEIGHTS length must match COMPOSE_VECTOR_PATHS")

    strategy_cls = CompositionStrategyMeta.registry.get(cfg.method)
    if strategy_cls is None:
        raise ValueError(f"Unknown composition method {cfg.method!r}")
    strategy = strategy_cls()
    if not strategy.supports_multiple_layers and len({m.get("layer") for m in metadatas}) > 1:
        raise ValueError(f"{cfg.method} only supports a single layer")

    warnings = check_compatibility(vectors, metadatas, cfg)
    gate_value = 1.0
    if cfg.gate_type == "threshold":
        gate_value = 1.0 if cfg.gate_threshold >= 0.5 else 0.0

    composed = strategy.compose(vectors, cfg.weights, {
        "normalize_each": cfg.normalize_each,
        "layers": [m.get("layer") for m in metadatas],
        "gate_value": gate_value,
    })

    metadata = {
        "input_vector_paths": cfg.vector_paths,
        "input_weights": cfg.weights,
        "composition_method": cfg.method,
        "layer": cfg.layer,
        "residual_location": cfg.residual_location,
        "normalize_each": cfg.normalize_each,
        "gate_type": cfg.gate_type,
        "gate_threshold": cfg.gate_threshold,
        "gate_value": gate_value,
        "warnings": warnings,
        "cosine_similarity_matrix": _cosine_matrix(vectors),
        "input_norms": [float(v.norm()) for v in vectors],
        "output_norm": float(composed.norm()) if isinstance(composed, torch.Tensor) else None,
        "timestamp": time.time(),
    }
    return composed, metadata


def main() -> None:
    cfg = ComposeConfig.from_env()
    if cfg.dry_run:
        print(json.dumps(cfg.__dict__, indent=2, default=str))
        return
    composed, metadata = compose_vectors(cfg)
    Path(cfg.output_path).parent.mkdir(parents=True, exist_ok=True)
    torch.save({"vector": composed, "metadata": metadata}, cfg.output_path)
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# steering/sweep.py
from __future__ import annotations

import contextlib
import csv
import json
import os
import time
from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any

import torch

LOG = __import__("logging").getLogger("steer.sweep")


class MetricMeta(type):
    registry: dict[str, type] = {}

    def __new__(mcls, name, bases, namespace, allow_override: bool = False):
        cls = super().__new__(mcls, name, bases, namespace)
        if name == "Metric":
            return cls
        if "metric_name" not in namespace:
            raise TypeError(f"{name} must define metric_name")
        if "compute" not in namespace:
            raise TypeError(f"{name} must implement compute()")
        if "category" not in namespace:
            raise TypeError(f"{name} must define category")
        mname = namespace["metric_name"]
        if mname in mcls.registry and not allow_override:
            raise ValueError(f"Metric {mname!r} already registered")
        mcls.registry[mname] = cls
        return cls


class Metric(metaclass=MetricMeta):
    metric_name: str
    category: str  # "behavior" or "side_effect"
    higher_is_better: bool | None = None

    def compute(self, baseline_output: str, steered_output: str, item: dict, context: dict) -> dict:
        raise NotImplementedError


def _contains_any(text: str, needles: list[str]) -> bool:
    text_l = text.lower()
    return any(n.lower() in text_l for n in needles)


class TargetBehaviorRate(Metric):
    metric_name = "target_behavior_rate"
    category = "behavior"
    higher_is_better = True

    def compute(self, baseline_output, steered_output, item, context):
        kws = item.get("target_keywords") or item.get("target_behavior_keywords") or []
        return {"target_behavior_rate": 1.0 if _contains_any(steered_output, kws) else 0.0}


class OppositeBehaviorRate(Metric):
    metric_name = "opposite_behavior_rate"
    category = "behavior"
    higher_is_better = False

    def compute(self, baseline_output, steered_output, item, context):
        kws = item.get("opposite_keywords") or item.get("opposite_behavior_keywords") or []
        return {"opposite_behavior_rate": 1.0 if _contains_any(steered_output, kws) else 0.0}


class FluencyProxy(Metric):
    metric_name = "fluency_proxy"
    category = "side_effect"
    higher_is_better = True

    def compute(self, baseline_output, steered_output, item, context):
        model = context.get("model")
        tokenizer = context.get("tokenizer")
        if model is None or tokenizer is None or not steered_output.strip():
            return {"fluency_proxy": 0.0}
        enc = tokenizer(steered_output, return_tensors="pt", truncation=True, max_length=512).to(model.device)
        with torch.no_grad():
            out = model(**enc, labels=enc["input_ids"])
        return {"fluency_proxy": -float(out.loss.item())}


class OutputDivergence(Metric):
    metric_name = "output_divergence"
    category = "side_effect"
    higher_is_better = False

    def compute(self, baseline_output, steered_output, item, context):
        ratio = SequenceMatcher(None, baseline_output, steered_output).ratio()
        return {"output_divergence": 1.0 - ratio}


def _parse_range(spec: str) -> list[int]:
    out: list[int] = []
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            out.extend(range(int(a), int(b) + 1))
        else:
            out.append(int(part))
    return out


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    return default if raw is None else raw.strip().lower() in {"1", "true", "yes", "on"}


@dataclass
class SweepConfig:
    model_id: str
    model_revision: str | None
    device: str
    dtype: str
    vector_paths: list[str]
    layers: list[int]
    coefficients: list[float]
    dataset_path: str
    batch_size: int
    max_new_tokens: int
    temperature: float
    top_p: float
    output_dir: str
    metrics: list[str]
    safety_mode: str
    max_coefficient: float
    dry_run: bool

    @classmethod
    def from_env(cls) -> "SweepConfig":
        cfg = cls(
            model_id=os.getenv("SWEEP_MODEL_ID", ""),
            model_revision=os.getenv("SWEEP_MODEL_REVISION"),
            device=os.getenv("SWEEP_DEVICE", "auto"),
            dtype=os.getenv("SWEEP_DTYPE", "float32"),
            vector_paths=[p for p in os.getenv("SWEEP_VECTOR_PATHS", "").split(",") if p],
            layers=_parse_range(os.getenv("SWEEP_LAYERS", "0")),
            coefficients=[float(x) for x in os.getenv("SWEEP_COEFFICIENTS", "0").split(",") if x],
            dataset_path=os.getenv("SWEEP_DATASET_PATH", ""),
            batch_size=int(os.getenv("SWEEP_BATCH_SIZE", "4")),
            max_new_tokens=int(os.getenv("SWEEP_MAX_NEW_TOKENS", "64")),
            temperature=float(os.getenv("SWEEP_TEMPERATURE", "0")),
            top_p=float(os.getenv("SWEEP_TOP_P", "1.0")),
            output_dir=os.getenv("SWEEP_OUTPUT_DIR", "sweep_output"),
            metrics=[m.strip() for m in os.getenv("SWEEP_METRICS", "target_behavior_rate,opposite_behavior_rate,fluency_proxy,output_divergence").split(",") if m.strip()],
            safety_mode=os.getenv("SWEEP_SAFETY_MODE", "monitor"),
            max_coefficient=float(os.getenv("SWEEP_MAX_COEFFICIENT", "10")),
            dry_run=_env_bool("SWEEP_DRY_RUN", False),
        )
        if not cfg.model_id:
            raise ValueError("SWEEP_MODEL_ID required")
        if not cfg.vector_paths:
            raise ValueError("SWEEP_VECTOR_PATHS required")
        if not cfg.layers:
            raise ValueError("SWEEP_LAYERS cannot be empty")
        if not cfg.coefficients:
            raise ValueError("SWEEP_COEFFICIENTS cannot be empty")
        if cfg.safety_mode not in {"strict", "monitor", "off"}:
            raise ValueError("SWEEP_SAFETY_MODE must be strict, monitor, or off")
        if cfg.safety_mode == "off" and not _env_bool("I_UNDERSTAND_THE_RISKS", False):
            raise ValueError("SWEEP_SAFETY_MODE=off requires I_UNDERSTAND_THE_RISKS=true")
        return cfg


def _get_transformer_layers(model):
    for path in (("model", "layers"), ("transformer", "h"), ("gpt_neox", "layers")):
        obj = model
        try:
            for attr in path:
                obj = getattr(obj, attr)
            return obj
        except AttributeError:
            continue
    raise ValueError("Could not locate transformer layers")


@contextlib.contextmanager
def steering_hook(model, layer: int, vector: torch.Tensor, coefficient: float):
    layers = _get_transformer_layers(model)
    if layer < 0 or layer >= len(layers):
        raise ValueError(f"Invalid layer {layer}; model has {len(layers)} blocks")

    def hook(module, inputs, output):
        hs = output[0] if isinstance(output, tuple) else output
        delta = (coefficient * vector).to(hs.device, hs.dtype)
        steered = hs + delta
        if torch.isnan(steered).any() or torch.isinf(steered).any():
            raise FloatingPointError("NaN/Inf in steered activations")
        return (steered,) + output[1:] if isinstance(output, tuple) else steered

    handle = layers[layer].register_forward_hook(hook)
    try:
        yield
    finally:
        handle.remove()


def _generate(model, tokenizer, prompts: list[str], cfg: SweepConfig) -> list[str]:
    tok = tokenizer(prompts, return_tensors="pt", padding=True, truncation=True).to(model.device)
    with torch.no_grad():
        out = model.generate(
            **tok,
            max_new_tokens=cfg.max_new_tokens,
            do_sample=cfg.temperature > 0,
            temperature=cfg.temperature if cfg.temperature > 0 else None,
            top_p=cfg.top_p,
            pad_token_id=tokenizer.pad_token_id,
        )
    gen = out[:, tok["input_ids"].shape[1]:]
    return tokenizer.batch_decode(gen, skip_special_tokens=True)


def generate_baseline(model, tokenizer, items: list[dict], cfg: SweepConfig) -> list[str]:
    return _generate(model, tokenizer, [it["prompt"] for it in items], cfg)


def generate_steered(model, tokenizer, items, vector, layer, coefficient, cfg) -> list[str]:
    if abs(coefficient) > cfg.max_coefficient:
        if cfg.safety_mode == "strict":
            raise ValueError(f"Coefficient {coefficient} exceeds cap {cfg.max_coefficient}")
        LOG.warning("Clamping coefficient %s to cap %s", coefficient, cfg.max_coefficient)
        coefficient = max(-cfg.max_coefficient, min(cfg.max_coefficient, coefficient))
    if coefficient == 0:
        return generate_baseline(model, tokenizer, items, cfg)
    with steering_hook(model, layer, vector, coefficient):
        return _generate(model, tokenizer, [it["prompt"] for it in items], cfg)


def evaluate_sweep(model, tokenizer, cfg: SweepConfig) -> dict:
    items = [json.loads(line) for line in Path(cfg.dataset_path).read_text(encoding="utf-8").splitlines() if line.strip()]
    if not items:
        raise ValueError("Evaluation dataset is empty")

    Path(cfg.output_dir).mkdir(parents=True, exist_ok=True)
    metric_instances = [MetricMeta.registry[m]() for m in cfg.metrics if m in MetricMeta.registry]
    missing = set(cfg.metrics) - set(MetricMeta.registry)
    if missing:
        raise ValueError(f"Unknown metrics: {missing}")

    baselines = generate_baseline(model, tokenizer, items, cfg)
    rows: list[dict] = []

    for vector_path in cfg.vector_paths:
        artifact = torch.load(vector_path, map_location="cpu")
        vector = artifact["vector"]
        for layer in cfg.layers:
            for coeff in cfg.coefficients:
                steered = generate_steered(model, tokenizer, items, vector, layer, coeff, cfg)
                for i, (item, base, steer) in enumerate(zip(items, baselines, steered)):
                    ctx = {"model": model, "tokenizer": tokenizer, "config": cfg, "layer": layer, "coefficient": coeff}
                    metric_values = {}
                    for metric in metric_instances:
                        vals = metric.compute(base, steer, item, ctx)
                        if not isinstance(vals, dict):
                            raise TypeError(f"{metric.metric_name} returned non-dict")
                        metric_values.update(vals)
                    rows.append({
                        "model_id": cfg.model_id,
                        "model_revision": cfg.model_revision,
                        "vector_path": vector_path,
                        "layer": layer,
                        "coefficient": coeff,
                        "prompt_id": item.get("id", i),
                        "baseline_output": base,
                        "steered_output": steer,
                        **metric_values,
                    })

    csv_path = Path(cfg.output_dir) / "sweep_report.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    # Aggregated summary per configuration.
    summary: dict[tuple, dict] = {}
    for row in rows:
        key = (row["vector_path"], row["layer"], row["coefficient"])
        agg = summary.setdefault(key, {"n": 0})
        agg["n"] += 1
        for metric_name in cfg.metrics:
            if metric_name in row:
                agg[metric_name] = agg.get(metric_name, 0.0) + row[metric_name]
    for agg in summary.values():
        for k in list(agg):
            if k != "n":
                agg[k] /= agg["n"]

    summary_path = Path(cfg.output_dir) / "sweep_summary.json"
    summary_path.write_text(json.dumps([{"vector": k[0], "layer": k[1], "coefficient": k[2], **v} for k, v in summary.items()], indent=2), encoding="utf-8")
    return {"rows": rows, "summary": summary, "csv": str(csv_path), "summary_json": str(summary_path)}


def main() -> None:
    import logging
    logging.basicConfig(level=logging.INFO)
    cfg = SweepConfig.from_env()
    if cfg.dry_run:
        print(json.dumps(cfg.__dict__, indent=2, default=str))
        return

    from transformers import AutoModelForCausalLM, AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(cfg.model_id, revision=cfg.model_revision)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(cfg.model_id, revision=cfg.model_revision)
    model.eval()
    evaluate_sweep(model, tokenizer, cfg)


if __name__ == "__main__":
    main()

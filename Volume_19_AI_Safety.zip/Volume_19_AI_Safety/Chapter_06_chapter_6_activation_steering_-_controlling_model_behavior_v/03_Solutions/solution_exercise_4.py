
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# steering/console.py
from __future__ import annotations

import cmd
import json
import logging
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import torch

LOG = logging.getLogger("steer.console")


class ConsoleCommandMeta(type):
    registry: dict[str, type] = {}

    def __new__(mcls, name, bases, namespace, allow_override: bool = False):
        cls = super().__new__(mcls, name, bases, namespace)
        if name == "ConsoleCommand":
            return cls
        if "command_name" not in namespace:
            raise TypeError(f"{name} must define command_name")
        if "help_text" not in namespace:
            raise TypeError(f"{name} must define help_text")
        if "run" not in namespace:
            raise TypeError(f"{name} must implement run()")
        cname = namespace["command_name"]
        if cname in mcls.registry and not allow_override:
            raise ValueError(f"Command {cname!r} already registered")
        mcls.registry[cname] = cls
        return cls


class ConsoleCommand(metaclass=ConsoleCommandMeta):
    command_name: str
    help_text: str
    safety_level: str = "safe"

    def run(self, console: "SteeringConsole", args: list[str]) -> None:
        raise NotImplementedError


@dataclass
class ConsoleState:
    model_id: str
    layer: int = 0
    coefficient: float = 1.0
    vector_paths: list[str] = field(default_factory=list)
    vector_names: list[str] = field(default_factory=list)
    compose_method: str = "weighted_sum"
    gate_type: str = "none"
    gate_threshold: float = 0.5
    compare: bool = False
    safety_mode: str = "monitor"


class HelpCommand(ConsoleCommand):
    command_name = ":help"
    help_text = "Show available commands."

    def run(self, console, args):
        for name, cls in sorted(ConsoleCommandMeta.registry.items()):
            print(f"{name:<18} {cls.help_text}")


class StatusCommand(ConsoleCommand):
    command_name = ":status"
    help_text = "Show current model, vectors, layer, coefficient, gate, and safety mode."

    def run(self, console, args):
        s = console.state
        print(f"model={s.model_id} layer={s.layer} coefficient={s.coefficient} safety={s.safety_mode}")
        print(f"vectors={s.vector_paths} compose={s.compose_method} gate={s.gate_type}:{s.gate_threshold} compare={s.compare}")


class LoadVectorCommand(ConsoleCommand):
    command_name = ":load_vector"
    help_text = "Load a steering vector and its metadata."

    def run(self, console, args):
        if not args:
            print("Usage: :load_vector PATH")
            return
        path = args[0]
        artifact = torch.load(path, map_location="cpu")
        meta = artifact.get("metadata", {})
        if meta.get("model_id") and meta["model_id"] != console.state.model_id:
            print(f"Refusing: vector model {meta['model_id']} != console model {console.state.model_id}")
            return
        console.state.vector_paths.append(path)
        console.state.vector_names.append(Path(path).stem)
        console.log_event("load_vector", {"path": path, "metadata": meta})


class UnloadVectorCommand(ConsoleCommand):
    command_name = ":unload_vector"
    help_text = "Remove a loaded vector by name or index."

    def run(self, console, args):
        if not args:
            print("Usage: :unload_vector NAME_OR_INDEX")
            return
        key = args[0]
        if key.isdigit():
            idx = int(key)
            if 0 <= idx < len(console.state.vector_paths):
                console.state.vector_paths.pop(idx)
                console.state.vector_names.pop(idx)
        else:
            if key in console.state.vector_names:
                idx = console.state.vector_names.index(key)
                console.state.vector_paths.pop(idx)
                console.state.vector_names.pop(idx)
        console.log_event("unload_vector", {"key": key})


class LayerCommand(ConsoleCommand):
    command_name = ":layer"
    help_text = "Set the target layer."

    def run(self, console, args):
        if not args:
            print("Usage: :layer N")
            return
        console.state.layer = int(args[0])
        console.log_event("layer", {"value": console.state.layer})


class CoefficientCommand(ConsoleCommand):
    command_name = ":coefficient"
    help_text = "Set the steering coefficient. Respects CONSOLE_MAX_COEFFICIENT."
    safety_level = "caution"

    def run(self, console, args):
        if not args:
            print("Usage: :coefficient X")
            return
        value = float(args[0])
        if abs(value) > console.max_coefficient:
            print(f"Refused: coefficient {value} exceeds cap {console.max_coefficient}")
            return
        console.state.coefficient = value
        console.log_event("coefficient", {"value": value})


class CompareCommand(ConsoleCommand):
    command_name = ":compare"
    help_text = "Toggle side-by-side comparison mode."

    def run(self, console, args):
        console.state.compare = not console.state.compare
        print(f"compare={console.state.compare}")


class PromptCommand(ConsoleCommand):
    command_name = ":prompt"
    help_text = "Generate baseline and steered outputs for a prompt."
    safety_level = "caution"

    def run(self, console, args):
        text = " ".join(args)
        if console.state.safety_mode == "strict" and console._looks_harmful(text):
            print("[strict safety] Refusing to generate steered output for this prompt.")
            return
        baseline = console.generate(text, apply_steering=False)
        steered = console.generate(text, apply_steering=True)
        print("--- baseline ---")
        print(baseline)
        print("--- steered ---")
        print(steered)
        console.log_event("prompt", {"prompt_hash": hash(text), "baseline_hash": hash(baseline), "steered_hash": hash(steered)})


class ResetCommand(ConsoleCommand):
    command_name = ":reset"
    help_text = "Restore defaults from environment variables."

    def run(self, console, args):
        console.state.layer = int(os.getenv("CONSOLE_DEFAULT_LAYER", "0"))
        console.state.coefficient = float(os.getenv("CONSOLE_DEFAULT_COEFFICIENT", "1.0"))
        console.state.vector_paths = [p for p in os.getenv("CONSOLE_DEFAULT_VECTOR_PATHS", "").split(",") if p]
        console.state.vector_names = [Path(p).stem for p in console.state.vector_paths]
        console.state.compare = False
        console.log_event("reset", {})


class QuitCommand(ConsoleCommand):
    command_name = ":quit"
    help_text = "Exit the console."

    def run(self, console, args):
        console.running = False


class SteeringConsole:
    def __init__(self, state: ConsoleState):
        self.state = state
        self.max_coefficient = float(os.getenv("CONSOLE_MAX_COEFFICIENT", "5.0"))
        self.log_path = os.getenv("CONSOLE_LOG_PATH", "console_session.jsonl")
        self.running = True
        self.model = None
        self.tokenizer = None

    def _load_model(self):
        from transformers import AutoModelForCausalLM, AutoTokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(self.state.model_id)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        self.model = AutoModelForCausalLM.from_pretrained(self.state.model_id)
        self.model.eval()

    def _looks_harmful(self, text: str) -> bool:
        # Replace with a real classifier in production.
        bad = ["bomb", "kill", "steal", "hack"]
        return any(w in text.lower() for w in bad)

    def generate(self, prompt: str, apply_steering: bool) -> str:
        if self.model is None:
            self._load_model()
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
        if apply_steering and self.state.vector_paths:
            # Minimal single-vector hook; use pipeline in production.
            artifact = torch.load(self.state.vector_paths[0], map_location="cpu")
            vec = artifact["vector"].to(self.model.device)
            layers = self.model.model.layers
            def hook(module, inputs, output):
                hs = output[0] if isinstance(output, tuple) else output
                return hs + self.state.coefficient * vec
            handle = layers[self.state.layer].register_forward_hook(hook)
            try:
                with torch.no_grad():
                    out = self.model.generate(**inputs, max_new_tokens=64, do_sample=False)
            finally:
                handle.remove()
        else:
            with torch.no_grad():
                out = self.model.generate(**inputs, max_new_tokens=64, do_sample=False)
        return self.tokenizer.decode(out[0, inputs["input_ids"].shape[1]:], skip_special_tokens=True)

    def log_event(self, command: str, payload: dict):
        entry = {"timestamp": time.time(), "command": command, **payload}
        with open(self.log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")

    def execute_command(self, line: str):
        if not line.strip():
            return
        parts = line.strip().split()
        cmd, args = parts[0], parts[1:]
        cls = ConsoleCommandMeta.registry.get(cmd)
        if cls is None:
            print(f"Unknown command {cmd}. Try :help")
            return
        if cls.safety_level == "dangerous" and os.getenv("CONSOLE_ALLOW_DANGEROUS_COMMANDS", "false").lower() != "true":
            print(f"Command {cmd} is dangerous and requires CONSOLE_ALLOW_DANGEROUS_COMMANDS=true")
            return
        cls().run(self, args)

    def run(self):
        print("Steering console. Type :help for commands.")
        while self.running:
            try:
                line = input(f"{os.getenv('CONSOLE_PROMPT_PREFIX', 'steer')}> ")
            except (KeyboardInterrupt, EOFError):
                print()
                break
            try:
                self.execute_command(line)
            except Exception as exc:
                print(f"Error: {exc}")
                LOG.exception("Command failed")


def main():
    state = ConsoleState(
        model_id=os.getenv("CONSOLE_MODEL_ID", ""),
        layer=int(os.getenv("CONSOLE_DEFAULT_LAYER", "0")),
        coefficient=float(os.getenv("CONSOLE_DEFAULT_COEFFICIENT", "1.0")),
        vector_paths=[p for p in os.getenv("CONSOLE_DEFAULT_VECTOR_PATHS", "").split(",") if p],
        safety_mode=os.getenv("CONSOLE_SAFETY_MODE", "monitor"),
    )
    if not state.model_id:
        raise ValueError("CONSOLE_MODEL_ID required")
    if state.safety_mode == "off" and os.getenv("I_UNDERSTAND_THE_RISKS", "false").lower() != "true":
        raise ValueError("CONSOLE_SAFETY_MODE=off requires I_UNDERSTAND_THE_RISKS=true")
    SteeringConsole(state).run()


if __name__ == "__main__":
    main()

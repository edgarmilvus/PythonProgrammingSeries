
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it heew: http://tiny.cc/ProgrammingBooks
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# steering/pipeline.py
from __future__ import annotations

import contextlib
import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import torch

LOG = __import__("logging").getLogger("steer.pipeline")


class VectorSourceMeta(type):
    registry: dict[str, type] = {}

    def __new__(mcls, name, bases, namespace, allow_override: bool = False):
        cls = super().__new__(mcls, name, bases, namespace)
        if name == "VectorSource":
            return cls
        if "source_name" not in namespace:
            raise TypeError(f"{name} must define source_name")
        if "load" not in namespace:
            raise TypeError(f"{name} must implement load()")
        if "supports_lazy_loading" not in namespace:
            raise TypeError(f"{name} must declare supports_lazy_loading")
        sname = namespace["source_name"]
        if sname in mcls.registry and not allow_override:
            raise ValueError(f"Vector source {sname!r} already registered")
        mcls.registry[sname] = cls
        return cls


class VectorSource(metaclass=VectorSourceMeta):
    source_name: str
    supports_lazy_loading: bool = False

    def load(self, identifier: str) -> tuple[torch.Tensor, dict]:
        raise NotImplementedError


class FileVectorSource(VectorSource):
    source_name = "file"
    supports_lazy_loading = False

    def load(self, identifier: str):
        artifact = torch.load(identifier, map_location="cpu")
        return artifact["vector"], artifact["metadata"]


class MemoryVectorSource(VectorSource):
    source_name = "memory"
    supports_lazy_loading = False
    _store: dict[str, tuple[torch.Tensor, dict]] = {}

    @classmethod
    def register(cls, name: str, vector: torch.Tensor, metadata: dict):
        cls._store[name] = (vector, metadata)

    def load(self, identifier: str):
        return self._store[identifier]


@dataclass
class PipelineConfig:
    model_id: str
    model_revision: str | None
    device: str
    dtype: str
    vector_sources: list[str]
    compose_method: str
    layers: list[int]
    coefficients: list[float]
    gate_type: str
    gate_threshold: float
    max_total_steering_norm: float
    audit_log_path: str
    safety_mode: str
    dry_run: bool
    allow_unsafe_layers: bool = False
    strict_hook_cleanup: bool = True

    @classmethod
    def from_env(cls):
        return cls(
            model_id=os.getenv("PIPELINE_MODEL_ID", ""),
            model_revision=os.getenv("PIPELINE_MODEL_REVISION"),
            device=os.getenv("PIPELINE_DEVICE", "auto"),
            dtype=os.getenv("PIPELINE_DTYPE", "float32"),
            vector_sources=[x for x in os.getenv("PIPELINE_VECTOR_SOURCES", "").split(",") if x],
            compose_method=os.getenv("PIPELINE_COMPOSE_METHOD", "weighted_sum"),
            layers=[int(x) for x in os.getenv("PIPELINE_LAYERS", "0").split(",") if x],
            coefficients=[float(x) for x in os.getenv("PIPELINE_COEFFICIENTS", "1.0").split(",") if x],
            gate_type=os.getenv("PIPELINE_GATE_TYPE", "none"),
            gate_threshold=float(os.getenv("PIPELINE_GATE_THRESHOLD", "0.5")),
            max_total_steering_norm=float(os.getenv("PIPELINE_MAX_TOTAL_STEERING_NORM", "10.0")),
            audit_log_path=os.getenv("PIPELINE_AUDIT_LOG_PATH", "pipeline_audit.jsonl"),
            safety_mode=os.getenv("PIPELINE_SAFETY_MODE", "monitor"),
            dry_run=os.getenv("PIPELINE_DRY_RUN", "false").lower() == "true",
            allow_unsafe_layers=os.getenv("PIPELINE_ALLOW_UNSAFE_LAYERS", "false").lower() == "true",
            strict_hook_cleanup=os.getenv("PIPELINE_STRICT_HOOK_CLEANUP", "true").lower() == "true",
        )


def _get_layers(model):
    for path in (("model", "layers"), ("transformer", "h"), ("gpt_neox", "layers")):
        obj = model
        try:
            for attr in path:
                obj = getattr(obj, attr)
            return obj
        except AttributeError:
            continue
    raise ValueError("Cannot locate transformer layers")


class ActivationSteeringPipeline:
    def __init__(self, model, tokenizer, vector=None, layer=None, coefficient=None, config: PipelineConfig | None = None):
        self.model = model
        self.tokenizer = tokenizer
        self.config = config
        self.interventions: list[dict] = []
        if vector is not None:
            self.interventions.append({"vector": vector, "layer": layer or 0, "coefficient": coefficient or 1.0})

    @classmethod
    def from_env(cls, model, tokenizer):
        cfg = PipelineConfig.from_env()
        pipe = cls(model, tokenizer, config=cfg)
        for src in cfg.vector_sources:
            kind, ident = src.split(":", 1)
            source_cls = VectorSourceMeta.registry[kind]
            vec, meta = source_cls().load(ident)
            pipe.interventions.append({"vector": vec, "layer": meta.get("layer", cfg.layers[0]), "coefficient": 1.0, "metadata": meta})
        return pipe

    def _effective_hooks(self, apply_steering: bool):
        if not apply_steering or not self.interventions:
            return []
        hooks = []
        layers = _get_layers(self.model)
        for inter in self.interventions:
            layer = inter["layer"]
            vec = inter["vector"]
            coeff = inter["coefficient"]
            if layer >= len(layers):
                raise ValueError(f"Invalid layer {layer}; model has {len(layers)} blocks")
            def make_hook(v, c):
                def hook(module, inputs, output):
                    hs = output[0] if isinstance(output, tuple) else output
                    steered = hs + c * v.to(hs.device, hs.dtype)
                    return (steered,) + output[1:] if isinstance(output, tuple) else steered
                return hook
            hooks.append((layers[layer].register_forward_hook(make_hook(vec, coeff)), layer))
        return hooks

    def generate(self, prompt: str, max_new_tokens: int = 64, temperature: float = 0.0, apply_steering: bool = True) -> str:
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
        before = sum(len(m._forward_hooks) for m in self.model.modules())
        hooks = self._effective_hooks(apply_steering)
        try:
            with torch.no_grad():
                out = self.model.generate(
                    **inputs,
                    max_new_tokens=max_new_tokens,
                    do_sample=temperature > 0,
                    temperature=temperature if temperature > 0 else None,
                    pad_token_id=self.tokenizer.pad_token_id,
                )
        finally:
            for handle, _ in hooks:
                handle.remove()
        after = sum(len(m._forward_hooks) for m in self.model.modules())
        if self.config and self.config.strict_hook_cleanup and before != after:
            raise RuntimeError(f"Hook leak detected: {before} -> {after}")
        self._audit("generate", {"prompt_hash": hash(prompt), "apply_steering": apply_steering})
        return self.tokenizer.decode(out[0, inputs["input_ids"].shape[1]:], skip_special_tokens=True)

    def generate_batch(self, prompts: list[str], max_new_tokens: int = 64, temperature: float = 0.0, apply_steering: bool = True) -> list[str]:
        return [self.generate(p, max_new_tokens, temperature, apply_steering) for p in prompts]

    def audit(self, prompts: list[str] | None = None) -> dict:
        prompts = prompts or ["Hello, how are you?", "Tell me a fact about the sky."]
        results = []
        for p in prompts:
            base = self.generate(p, apply_steering=False)
            steered = self.generate(p, apply_steering=True)
            results.append({"prompt": p, "baseline": base, "steered": steered, "length_delta": len(steered) - len(base)})
        return {"results": results, "timestamp": time.time()}

    def _audit(self, event: str, payload: dict):
        entry = {"timestamp": time.time(), "event": event, **payload}
        with open(self.config.audit_log_path if self.config else "pipeline_audit.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")

    def save_config(self, path: str):
        Path(path).write_text(json.dumps(self.config.__dict__ if self.config else {}, indent=2), encoding="utf-8")


def main():
    import logging
    logging.basicConfig(level=logging.INFO)
    cfg = PipelineConfig.from_env()
    if cfg.dry_run:
        print(json.dumps(cfg.__dict__, indent=2))
        return
    from transformers import AutoModelForCausalLM, AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(cfg.model_id, revision=cfg.model_revision)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(cfg.model_id, revision=cfg.model_revision)
    pipe = ActivationSteeringPipeline.from_env(model, tokenizer)
    print(pipe.generate("Hello, how are you?"))


if __name__ == "__main__":
    main()

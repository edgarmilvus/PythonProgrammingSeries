
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import asyncio
import json
import uuid
import time
from typing import List, Dict, Any
from vllm import AsyncLLMEngine, AsyncEngineArgs, SamplingParams

# --- PRODUCTION-GRADE DOCUMENT PROCESSOR ---

class SecureDocumentProcessor:
    """
    A production-grade wrapper for vLLM designed to handle high-throughput 
    summarization tasks with built-in security simulation and resource management.
    """

    def __init__(self, model_path: str, gpu_memory_utilization: float = 0.8):
        # Initialize engine arguments specifically for production throughput
        # We set max_model_len to handle long-form documents
        self.engine_args = AsyncEngineArgs(
            model=model_path,
            gpu_memory_utilization=gpu_memory_utilization,
            trust_remote_code=True,
            engine_use_ray=False,  # Single-node optimization
            disable_log_requests=True
        )
        # Initialize the AsyncLLMEngine for non-blocking inference
        self.engine = AsyncLLMEngine.from_engine_args(self.engine_args)
        # Simulated CSRF storage for session-based request validation
        self.valid_csrf_tokens = set()

    def generate_csrf_session(self) -> str:
        """Generates a unique CSRF token for a secure processing session."""
        token = str(uuid.uuid4())
        self.valid_csrf_tokens.add(token)
        return token

    def _validate_request(self, csrf_token: str) -> bool:
        """Internal check to ensure the request is originating from an authorized session."""
        if csrf_token not in self.valid_csrf_tokens:
            raise PermissionError("Invalid or expired CSRF token. Request rejected.")
        return True

    async def process_document_batch(
        self, 
        documents: List[str], 
        csrf_token: str,
        max_tokens: int = 256
    ) -> List[Dict[str, Any]]:
        """
        Processes a batch of documents asynchronously.
        Uses vLLM's continuous batching to maximize token generation speed.
        """
        # Validate security token before proceeding with expensive GPU operations
        self._validate_request(csrf_token)

        # Sampling parameters: temperature 0 for deterministic summarization
        sampling_params = SamplingParams(
            temperature=0.0,
            top_p=0.95,
            max_tokens=max_tokens,
            presence_penalty=1.1
        )

        results = []
        tasks = []

        # Define the generation logic for a single request
        async def _generate(doc_text: str, doc_id: int):
            request_id = f"req-{doc_id}-{uuid.uuid4().hex[:8]}"
            prompt = f"Summarize the following document concisely:\n\n{doc_text}\n\nSummary:"
            
            # The engine.generate call returns an async generator
            generator = self.engine.generate(prompt, sampling_params, request_id)
            
            final_output = None
            async for request_output in generator:
                final_output = request_output

            return {
                "id": doc_id,
                "summary": final_output.outputs[0].text,
                "tokens_processed": len(final_output.prompt_token_ids) + len(final_output.outputs[0].token_ids)
            }

        # Schedule all document tasks into the event loop simultaneously
        for i, doc in enumerate(documents):
            tasks.append(_generate(doc, i))

        # Gather results as they complete; vLLM handles the internal batching
        results = await asyncio.gather(*tasks)
        return results

    def save_results(self, data: List[Dict[str, Any]], filename: str):
        """
        Uses a Context Manager to safely write results to a JSON file.
        Ensures the file handle is closed even if an I/O error occurs.
        """
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4)
            print(f"Successfully saved {len(data)} summaries to {filename}")
        except IOError as e:
            print(f"File system error: {e}")

async def main():
    # Configuration for the simulation
    MODEL_NAME = "facebook/opt-125m"  # Using a small model for demonstration
    DOCS_TO_PROCESS = [
        "The contract outlines a 12-month lease agreement for the commercial property at 123 Main St.",
        "The software license agreement prohibits reverse engineering and requires annual renewals.",
        "The employment offer includes a base salary, stock options, and a health insurance package."
    ]
    
    # Initialize the processor
    processor = SecureDocumentProcessor(MODEL_NAME)
    
    # Secure the session
    session_token = processor.generate_csrf_session()
    
    print(f"Starting batch processing of {len(DOCS_TO_PROCESS)} documents...")
    start_time = time.perf_counter()
    
    # Execute the asynchronous pipeline
    summaries = await processor.process_document_batch(DOCS_TO_PROCESS, session_token)
    
    end_time = time.perf_counter()
    print(f"Batch processing completed in {end_time - start_time:.2f} seconds.")
    
    # Save output using the context manager method
    processor.save_results(summaries, "summaries_output.json")

if __name__ == "__main__":
    # Entry point for the asynchronous event loop
    asyncio.run(main())

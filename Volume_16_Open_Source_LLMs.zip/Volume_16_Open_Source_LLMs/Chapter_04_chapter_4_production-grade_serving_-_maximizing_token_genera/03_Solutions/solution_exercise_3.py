
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from vllm import LLM

# Configuration for a dual-A100 (80GB) environment
llm = LLM(
    model="meta-llama/Meta-Llama-3-70B",
    tensor_parallel_size=2,      # Shard model across 2 GPUs
    gpu_memory_utilization=0.90, # Use 90% of available VRAM
    max_model_len=4096,          # Limit context window
    block_size=16,               # PagedAttention block size
    swap_space=4,                # 4GB CPU swap per GPU
    enforce_eager=False          # Allow CUDA graph optimization
)

"""
Theoretical Impact of max_model_len:
Reducing max_model_len from 4096 to 2048 would significantly increase 
the number of available KV cache blocks. Since vLLM pre-allocates 
memory based on the maximum possible sequence length, a smaller 
limit frees up VRAM, allowing for a higher batch size (throughput).
"""

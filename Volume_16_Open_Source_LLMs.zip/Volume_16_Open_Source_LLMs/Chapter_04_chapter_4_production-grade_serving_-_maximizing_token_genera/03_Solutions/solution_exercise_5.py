
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import time
import csv
import os
from vllm import LLM, SamplingParams

def run_benchmark(batch_sizes=[1, 4, 16, 32, 64]):
    llm = LLM(model="meta-llama/Meta-Llama-3-8B")
    results = []
    
    for b_size in batch_sizes:
        prompts = ["Summarize the history of AI."] * b_size
        params = SamplingParams(max_tokens=100, ignore_eos=True)
        
        start_time = time.perf_counter()
        # vLLM generate returns when the full batch is done
        outputs = llm.generate(prompts, params)
        end_time = time.perf_counter()
        
        total_time = end_time - start_time
        # In a real benchmark, you would use the vLLM stats API for TTFT
        # Here we simulate the per-token average
        total_tokens = sum(len(o.outputs[0].token_ids) for o in outputs)
        tpot = total_time / total_tokens
        
        results.append({
            "batch_size": b_size,
            "total_time": total_time,
            "tpot": tpot
        })

    # Data Serialization
    output_path = os.path.join("benchmarks", "vllm_results.csv")
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    with open(output_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["batch_size", "total_time", "tpot"])
        writer.writeheader()
        writer.writerows(results)

# run_benchmark()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import time
import signal
import sys
from vllm import LLM, SamplingParams

def prompt_generator():
    """Simulates a message queue or async stream of incoming prompts."""
    yield "Explain quantum entanglement in simple terms."
    yield "Write a Python script to scrape a website."
    yield "What are the benefits of vLLM over standard Transformers?"

def calculate_tps(start_time, end_time, total_tokens):
    """Helper function to calculate Tokens Per Second (DRY)."""
    duration = end_time - start_time
    return total_tokens / duration if duration > 0 else 0

# Graceful shutdown handler
def signal_handler(sig, frame):
    print("\nShutting down engine... Releasing GPU memory.")
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)

# Initialization with Quantization and Eager Mode
llm = LLM(
    model="TheBloke/Llama-3-8B-Instruct-AWQ",
    quantization="awq",  # Enable AWQ support
    enforce_eager=True   # Bypass CUDA graphs to debug memory/compatibility
)

sampling_params = SamplingParams(max_tokens=100)

# Main Processing Loop
for prompt in prompt_generator():
    start = time.perf_counter()
    outputs = llm.generate([prompt], sampling_params)
    end = time.perf_counter()
    
    for output in outputs:
        total_gen_tokens = len(output.outputs[0].token_ids)
        tps = calculate_tps(start, end, total_gen_tokens)
        print(f"Generated {total_gen_tokens} tokens at {tps:.2f} TPS.")

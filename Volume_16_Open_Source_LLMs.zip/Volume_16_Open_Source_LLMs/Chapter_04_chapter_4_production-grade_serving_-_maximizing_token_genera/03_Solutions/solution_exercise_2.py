
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import logging
from vllm import SamplingParams

# Configure logging for production observability
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("vLLM-Server")

def create_sampling_params(request_data: dict) -> SamplingParams:
    """Extracts parameters using EAFP to handle malformed inputs gracefully."""
    try:
        # Essential key: Prompt (Assumes it exists, catches KeyError if not)
        prompt = request_data["prompt"]
        
        # Type-sensitive key: max_tokens
        try:
            max_tokens = int(request_data.get("max_tokens", 128))
        except (ValueError, TypeError):
            logger.warning("Invalid max_tokens type. Defaulting to 128.")
            max_tokens = 128

        # Optional key with default: temperature
        try:
            temperature = float(request_data["temperature"])
        except KeyError:
            # Forgiveness: It's okay if it's missing, use default
            temperature = 0.7
        except ValueError:
            logger.warning("Invalid temperature value. Defaulting to 0.7.")
            temperature = 0.7

        return SamplingParams(
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=0.95
        )

    except KeyError as e:
        logger.error(f"Critical failure: Missing required field {e}")
        raise ValueError(f"Request payload is missing required field: {e}")
    except Exception as e:
        logger.error(f"Unexpected error during request parsing: {e}")
        raise

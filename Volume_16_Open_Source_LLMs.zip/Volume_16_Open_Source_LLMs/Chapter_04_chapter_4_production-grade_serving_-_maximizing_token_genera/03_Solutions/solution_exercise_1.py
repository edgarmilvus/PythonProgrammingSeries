
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os

class ModelRegistry:
    # Single source of truth for model sub-directories
    _MODELS = {
        "llama3-8b": "meta-llama/Meta-Llama-3-8B",
        "mistral-7b": "mistralai/Mistral-7B-v0.1",
        "phi3": "microsoft/Phi-3-mini-4k-instruct"
    }

    def __init__(self):
        # Environment awareness: Default to 'models/' if MODEL_ROOT is unset
        self.base_dir = os.getenv("MODEL_ROOT", os.path.join(os.getcwd(), "models"))

    def get_path(self, model_key: str) -> str:
        """Retrieves and validates the absolute path for a given model key."""
        if model_key not in self._MODELS:
            raise KeyError(f"Model '{model_key}' not found in registry.")
        
        # Cross-platform path construction
        model_path = os.path.join(self.base_dir, self._MODELS[model_key])
        
        # Validation: EAFP approach is better, but for paths, explicit check is safer
        if not os.path.exists(model_path):
            raise FileNotFoundError(
                f"Model path not found: {model_path}. "
                "Check your MODEL_ROOT environment variable or mount points."
            )
            
        return os.path.abspath(model_path)

# Usage in vLLM deployment
# registry = ModelRegistry()
# llm = LLM(model=registry.get_path("llama3-8b"))

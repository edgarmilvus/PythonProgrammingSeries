
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Import the core classes from the vLLM library
# LLM: The main entry point for running offline inference
# SamplingParams: A configuration class to define how the model should generate text
from vllm import LLM, SamplingParams

# 1. Define a list of input prompts (The "Batch")
# In a real-world scenario, these could be hundreds of user queries or articles.
prompts = [
    "The capital of France is",
    "The future of artificial intelligence is",
    "Explain the concept of quantum entanglement in simple terms:",
    "Write a short poem about a lonely robot on Mars.",
]

# 2. Initialize Sampling Parameters
# temperature: Controls randomness (0.0 is deterministic, 1.0 is creative)
# top_p: Nucleus sampling; considers the smallest set of tokens whose cumulative probability exceeds p
# max_tokens: Limits the length of the generated output to prevent runaway generation
sampling_params = SamplingParams(
    temperature=0.7, 
    top_p=0.9, 
    max_tokens=100
)

# 3. Initialize the LLM Engine
# model: The path to the model (Hugging Face ID or local directory)
# trust_remote_code: Required for models with custom architectures not yet in the core library
# gpu_memory_utilization: The fraction of GPU memory to reserve for the engine (default is 0.9)
# We use a small model (OPT-125M) for this "Hello World" example to ensure it fits on most GPUs.
try:
    # EAFP approach: We assume the model is available and the GPU has enough memory.
    # If the model name is wrong or memory is insufficient, we catch the exception later.
    llm = LLM(
        model="facebook/opt-125m", 
        trust_remote_code=True,
        gpu_memory_utilization=0.8
    )
except Exception as e:
    print(f"Failed to initialize the LLM engine: {e}")
    exit(1)

# 4. Generate Outputs
# The generate method processes the entire list of prompts using continuous batching.
# It returns a list of RequestOutput objects.
outputs = llm.generate(prompts, sampling_params)

# 5. Process and Print the Results
# We iterate through the results to extract the generated text from each request.
for output in outputs:
    prompt = output.prompt
    # Each output can have multiple 'completions' if n > 1 in SamplingParams
    generated_text = output.outputs[0].text
    print(f"\n--- Prompt: {prompt} ---")
    print(f"Generated: {generated_text}")

# Note: In an asynchronous environment (like a FastAPI server), 
# you would use an Asynchronous Context Manager or the AsyncLLMEngine 
# to ensure that the server can handle other tasks while waiting for the GPU.

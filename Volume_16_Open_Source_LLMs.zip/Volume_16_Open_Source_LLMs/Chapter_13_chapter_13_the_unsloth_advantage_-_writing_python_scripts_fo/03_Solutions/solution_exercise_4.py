
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
import json
from transformers import TrainerCallback
from unsloth import FastLanguageModel

class InteractiveCallback(TrainerCallback):
    """Callback to check for hyperparameter updates during training."""
    def on_step_end(self, args, state, control, **kwargs):
        if state.global_step % 100 == 0:
            if os.path.exists("config_update.json"):
                print(f"\n[Step {state.global_step}] Update detected! Loading new params...")
                with open("config_update.json", "r") as f:
                    new_params = json.load(f)
                
                # Update lora_alpha logic
                # Note: Mid-training alpha changes require scaling the weights
                # alpha_new / alpha_old scaling factor
                if "lora_alpha" in new_params:
                    print(f"Updating LoRA Alpha to: {new_params['lora_alpha']}")
                    # In a real scenario, we would adjust the scaling factor 
                    # in the model's PEFT config layers.
                
                # Run small validation
                control.should_evaluate = True
                os.remove("config_update.json")
        return control

def update_model_params(model, new_alpha):
    """Safely updates the LoRA configuration scaling."""
    # Unsloth/PEFT stores scaling as (lora_alpha / r)
    for layer in model.modules():
        if hasattr(layer, "scaling"):
            # This is an internal PEFT/Unsloth attribute
            # Changing this mid-stream affects the forward pass immediately
            layer.scaling["default"] = new_alpha / layer.r
    print(f"Model scaling updated to alpha={new_alpha}")

# Implementation in Trainer:
# trainer = SFTTrainer(..., callbacks=[InteractiveCallback()])

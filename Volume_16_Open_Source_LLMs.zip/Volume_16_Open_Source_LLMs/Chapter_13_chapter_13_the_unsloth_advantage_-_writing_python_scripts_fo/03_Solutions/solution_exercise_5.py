
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from abc import ABC, abstractmethod

class UnslothModelMeta(type):
    """Metaclass for registering and validating FineTuneModel subclasses."""
    _registry = {}

    def __init__(cls, name, bases, nmspc):
        super(UnslothModelMeta, cls).__init__(name, bases, nmspc)
        
        # Skip registration for the base class itself
        if name != "FineTuneModel":
            # Validation: Ensure apply_lora is implemented
            if "apply_lora" not in nmspc:
                raise TypeError(f"Class {name} must implement 'apply_lora' method.")
            
            # Automated Registration
            UnslothModelMeta._registry[name] = cls
            print(f"Registered model trainer: {name}")

class FineTuneModel(metaclass=UnslothModelMeta):
    """Base class for all Unsloth-based fine-tuning tasks."""
    
    def __init__(self, model_name):
        self.model_name = model_name
        self.model = None
        self.tokenizer = None

    @abstractmethod
    def load_model(self):
        pass

    @abstractmethod
    def apply_lora(self):
        pass

class Llama3Trainer(FineTuneModel):
    """Concrete implementation for Llama 3 models."""
    def load_model(self):
        from unsloth import FastLanguageModel
        self.model, self.tokenizer = FastLanguageModel.from_pretrained(
            model_name=self.model_name,
            load_in_4bit=True
        )

    def apply_lora(self, r=16):
        from unsloth import FastLanguageModel
        self.model = FastLanguageModel.get_peft_model(self.model, r=r)

class MistralTrainer(FineTuneModel):
    """Concrete implementation for Mistral models."""
    def load_model(self):
        # Implementation for Mistral...
        pass

    def apply_lora(self):
        # Implementation for Mistral...
        pass

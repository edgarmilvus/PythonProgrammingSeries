
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import torch
from unsloth import FastLanguageModel
from trl import SFTTrainer
from transformers import TrainingArguments
from datasets import Dataset
import time

def initialize_environment():
    """Checks CUDA compatibility and prints GPU specifications."""
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is not available. Unsloth requires an NVIDIA GPU.")
    
    gpu_stats = torch.cuda.get_device_properties(0)
    print(f"GPU: {gpu_stats.name} | Total Memory: {gpu_stats.total_memory / 1024**3:.2f} GB")

def run_unsloth_benchmark(max_seq_length=2048, batch_size=2):
    # 1. Model Loading Logic (4-bit quantization)
    # 4-bit loading is essential for 8B models to fit on 8GB-12GB consumer GPUs
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name="unsloth/llama-3-8b-bnb-4bit",
        max_seq_length=max_seq_length,
        load_in_4bit=True,
    )

    # 2. LoRA Configuration
    model = FastLanguageModel.get_peft_model(
        model,
        r=16,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                        "gate_proj", "up_proj", "down_proj"],
        lora_alpha=16,
        lora_dropout=0, 
        bias="none",    
        use_gradient_checkpointing="unsloth",
    )

    # 3. Data Simulation
    dummy_data = {
        "instruction": ["Explain quantum computing."] * 50,
        "input": ["Briefly."] * 50,
        "output": ["Quantum computing uses qubits..."] * 50
    }
    dataset = Dataset.from_dict(dummy_data)

    # 4. Memory Tracking & Training Loop
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    start_time = time.time()

    trainer = SFTTrainer(
        model=model,
        train_dataset=dataset,
        dataset_text_field="instruction", # Simplified for dummy data
        max_seq_length=max_seq_length,
        args=TrainingArguments(
            per_device_train_batch_size=batch_size,
            max_steps=50,
            learning_rate=2e-4,
            fp16=not torch.cuda.is_bf16_supported(),
            bf16=torch.cuda.is_bf16_supported(),
            logging_steps=10,
            output_dir="outputs",
        ),
    )

    trainer.train()
    
    end_time = time.time()
    peak_vram = torch.cuda.max_memory_reserved() / 1024**3
    seconds_per_step = (end_time - start_time) / 50

    # 5. Reporting
    print("\n" + "="*30)
    print("UNSLOTH BENCHMARK RESULTS")
    print("="*30)
    print(f"Seconds per Step: {seconds_per_step:.4f}s")
    print(f"Peak VRAM Usage:  {peak_vram:.2f} GB")
    print("="*30)

if __name__ == "__main__":
    initialize_environment()
    run_unsloth_benchmark()

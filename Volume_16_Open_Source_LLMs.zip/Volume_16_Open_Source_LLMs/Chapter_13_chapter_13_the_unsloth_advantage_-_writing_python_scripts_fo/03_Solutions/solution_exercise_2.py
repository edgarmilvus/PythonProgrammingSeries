
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from unsloth import FastLanguageModel
from trl import SFTTrainer
from transformers import TrainingArguments
import torch

class FormattingPromptsCustom:
    """Handles the System-User-Assistant schema for instruction tuning."""
    def __init__(self, tokenizer):
        self.tokenizer = tokenizer

    def format_prompt(self, examples):
        instructions = examples["instruction"]
        inputs       = examples["input"]
        outputs      = examples["output"]
        texts = []
        for instruction, input_text, output in zip(instructions, inputs, outputs):
            # System-User-Assistant Schema
            text = f"<|system|>You are a helpful assistant.<|end|>\n" \
                   f"<|user|>{instruction} {input_text}<|end|>\n" \
                   f"<|assistant|>{output}{self.tokenizer.eos_token}"
            texts.append(text)
        return {"text": texts}

def train_model(model, tokenizer, dataset, phase="A", base_lr=2e-4):
    """
    Executes a specific phase of training with dynamic hyperparameters.

    Args:
        model: The FastLanguageModel instance.
        tokenizer: The associated tokenizer.
        dataset: The dataset for the current phase.
        phase (str): "A" for General, "B" for Domain-specific.
        base_lr (float): The starting learning rate.
    """
    # Phase B has 20% higher learning rate
    current_lr = base_lr * 1.2 if phase == "B" else base_lr
    current_weight_decay = 0.02 if phase == "B" else 0.01
    
    # Dynamic Gradient Accumulation based on sequence length
    max_seq_length = model.config.max_position_embeddings
    grad_accum_steps = 4 if max_seq_length > 4096 else 2

    trainer = SFTTrainer(
        model=model,
        tokenizer=tokenizer,
        train_dataset=dataset,
        dataset_text_field="text",
        max_seq_length=max_seq_length,
        args=TrainingArguments(
            learning_rate=current_lr,
            weight_decay=current_weight_decay,
            gradient_accumulation_steps=grad_accum_steps,
            per_device_train_batch_size=2,
            max_steps=100,
            output_dir=f"outputs_phase_{phase}",
            logging_steps=1,
        ),
    )
    trainer.train()
    
    # Adapter Management: Save phase-specific adapters
    adapter_path = f"lora_adapters_phase_{phase}"
    model.save_pretrained_lora(adapter_path)
    print(f"Phase {phase} complete. Adapters saved to {adapter_path}")
    return model

# Usage Example (Conceptual)
# model = train_model(model, tokenizer, general_ds, phase="A")
# model.load_pretrained_lora("lora_adapters_phase_A") # Reload for Phase B
# model = train_model(model, tokenizer, medical_ds, phase="B")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import torch
import psutil
import os
from unsloth import FastLanguageModel

def check_memory_safety(threshold_gb=16):
    """Calculates if the system has enough RAM/VRAM for merging."""
    available_ram = psutil.virtual_memory().available / 1024**3
    if available_ram < threshold_gb:
        print(f"Warning: Low RAM ({available_ram:.2f}GB). Merging may fail.")
        return False
    return True

def export_pipeline(model_path):
    # 1. Model Loading
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name=model_path,
        max_seq_length=2048,
        load_in_4bit=True,
    )

    if not check_memory_safety():
        return

    # 2. 16-bit Merged Export
    print("Exporting 16-bit merged model...")
    model.save_pretrained_merged("outputs/merged_16bit", tokenizer, save_method="merged_16bit")

    # 3. GGUF Conversion (Standard Q4_K_M)
    print("Exporting GGUF Q4_K_M...")
    model.save_pretrained_gguf("outputs/gguf_q4", tokenizer, quantization_method="q4_k_m")

    # 4. GGUF Conversion (High Precision Q5_K_M)
    print("Exporting GGUF Q5_K_M...")
    model.save_pretrained_gguf("outputs/gguf_q5", tokenizer, quantization_method="q5_k_m")

    # 5. Ollama Modelfile Integration
    modelfile_content = f"""
FROM ./outputs/gguf_q4/unsloth.Q4_K_M.gguf
TEMPLATE \"\"\"<|system|>{{{{ .System }}}}<|end|>
<|user|>{{{{ .Prompt }}}}<|end|>
<|assistant|>\"\"\"
PARAMETER stop <|end|>
"""
    with open("Modelfile", "w") as f:
        f.write(modelfile_content)

    # 6. Verification Step
    size_16bit = os.path.getsize("outputs/merged_16bit/model.safetensors") / 1024**3
    size_q4 = os.path.getsize("outputs/gguf_q4/unsloth.Q4_K_M.gguf") / 1024**3
    
    print(f"16-bit Size: {size_16bit:.2f} GB")
    print(f"Q4 GGUF Size: {size_q4:.2f} GB")
    if size_q4 < (size_16bit * 0.4):
        print("Compression threshold met: GGUF is significantly smaller.")

if __name__ == "__main__":
    export_pipeline("lora_adapters_phase_B")

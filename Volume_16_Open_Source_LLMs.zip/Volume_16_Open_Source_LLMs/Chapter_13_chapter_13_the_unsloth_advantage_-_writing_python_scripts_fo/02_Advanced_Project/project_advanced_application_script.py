
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import torch
from abc import ABC, abstractmethod
from unsloth import FastLanguageModel
from datasets import Dataset
from trl import SFTTrainer
from transformers import TrainingArguments
from unsloth import is_bfloat16_supported

# --- DATA INGESTION LAYER (Using ABC and SQLAlchemy Logic) ---

class BaseDataIngestor(ABC):
    """Define a formal interface for data loading to ensure script modularity."""
    @abstractmethod
    def load_triage_data(self):
        pass

class SupportTicketIngestor(BaseDataIngestor):
    """
    Simulates fetching support tickets. In a real scenario, this would use 
    SQLAlchemy to query a production database.
    """
    def load_triage_data(self):
        # Mocking data that would typically come from a SQLAlchemy session.query()
        raw_data = [
            {"instruction": "Triage this ticket", "input": "Server down in US-East. Error 500.", "output": "Category: Infrastructure, Priority: High"},
            {"instruction": "Triage this ticket", "input": "Cannot change password.", "output": "Category: Auth, Priority: Low"},
        ] * 500  # Upscaling for the example
        return Dataset.from_list(raw_data)

# --- MODEL CONFIGURATION ---

# 1. Configuration Constants
MAX_SEQ_LENGTH = 2048
DTYPE = None # None for auto-detection (Float16 for older GPUs, Bfloat16 for Ampere+)
LOAD_IN_4BIT = True # Use 4-bit quantization to reduce VRAM usage

# 2. Load Model and Tokenizer via Unsloth
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name = "unsloth/llama-3-8b-bnb-4bit",
    max_seq_length = MAX_SEQ_LENGTH,
    dtype = DTYPE,
    load_in_4bit = LOAD_IN_4BIT,
)

# 3. Add LoRA Adapters for Parameter-Efficient Fine-Tuning
model = FastLanguageModel.get_peft_model(
    model,
    r = 16, # Rank: Higher numbers allow more complex learning but use more VRAM
    target_modules = ["q_proj", "k_proj", "v_proj", "o_proj",
                      "gate_proj", "up_proj", "down_proj"],
    lora_alpha = 16,
    lora_dropout = 0, # Optimized to 0 for Unsloth
    bias = "none",    # Optimized to "none" for Unsloth
    use_gradient_checkpointing = "unsloth", # 2x longer context support
    random_state = 3407,
    use_rslora = False,
    loftq_config = None,
)

# --- TRAINING PIPELINE ---

# 4. Prepare Dataset
ingestor = SupportTicketIngestor()
dataset = ingestor.load_triage_data()

def format_prompts(examples):
    instructions = examples["instruction"]
    inputs       = examples["input"]
    outputs      = examples["output"]
    texts = []
    for instruction, input, output in zip(instructions, inputs, outputs):
        # Formatting for Llama-3 Chat Template
        text = f"<|begin_of_text|><|start_header_id|>user<|end_header_id|>\n\n{instruction}: {input}<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n{output}<|eot_id|>"
        texts.append(text)
    return { "text" : texts, }

dataset = dataset.map(format_prompts, batched = True)

# 5. Initialize Trainer
trainer = SFTTrainer(
    model = model,
    tokenizer = tokenizer,
    train_dataset = dataset,
    dataset_text_field = "text",
    max_seq_length = MAX_SEQ_LENGTH,
    dataset_num_proc = 2,
    args = TrainingArguments(
        per_device_train_batch_size = 2,
        gradient_accumulation_steps = 4,
        warmup_steps = 5,
        max_steps = 60, # Small step count for demonstration
        learning_rate = 2e-4,
        fp16 = not is_bfloat16_supported(),
        bf16 = is_bfloat16_supported(),
        logging_steps = 1,
        optim = "adamw_8bit",
        weight_decay = 0.01,
        lr_scheduler_type = "linear",
        seed = 3407,
        output_dir = "outputs",
    ),
)

# 6. Execute Training
trainer_stats = trainer.train()

# --- EXPORT FOR LOCAL INFERENCE ---

# 7. Save to GGUF for Ollama/vLLM integration
model.save_pretrained_gguf("model_triage_q4_k_m", tokenizer, quantization_method = "q4_k_m")

# 8. Save LoRA Adapters for future Python-based inference
model.save_pretrained("lora_model_triage")
tokenizer.save_pretrained("lora_model_triage")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from sentence_transformers import SentenceTransformer, CrossEncoder, util
import torch

class AdvancedRAGFilter:
    def __init__(self, config: dict):
        self.config = config
        self.bi_encoder = SentenceTransformer(config['bi_model'])
        self.cross_encoder = CrossEncoder(config['cross_model'])
        self.device = "cuda" if torch.cuda.is_available() else "cpu"

    def process_candidates(self, candidates: List[str], gold_standard: List[str]):
        if not gold_standard:
            return candidates # Handle cold start

        results = []
        gold_embeddings = self.bi_encoder.encode(gold_standard, convert_to_tensor=True)
        
        # Tier 1: Bi-Encoder Screening
        for candidate in candidates:
            cand_embed = self.bi_encoder.encode(candidate, convert_to_tensor=True)
            scores = util.cos_sim(cand_embed, gold_embeddings)[0]
            max_score = torch.max(scores).item()

            if max_score < self.config['low_threshold']:
                continue # Immediate Discard
            elif max_score > self.config['high_threshold']:
                results.append(candidate) # Immediate Keep
            else:
                # Tier 2: Cross-Encoder Verification for Borderline
                best_gold_idx = torch.argmax(scores).item()
                pair = [candidate, gold_standard[best_gold_idx]]
                cross_score = self.cross_encoder.predict(pair)
                
                if cross_score > self.config['cross_threshold']:
                    results.append(candidate)
        
        return results

# Configuration
cfg = {
    'bi_model': 'all-MiniLM-L6-v2',
    'cross_model': 'cross-encoder/ms-marco-MiniLM-L-6-v2',
    'low_threshold': 0.6,
    'high_threshold': 0.9,
    'cross_threshold': 0.8
}

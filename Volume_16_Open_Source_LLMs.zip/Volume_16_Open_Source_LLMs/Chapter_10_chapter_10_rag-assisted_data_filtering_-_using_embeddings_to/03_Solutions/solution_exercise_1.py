
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
from sentence_transformers import SentenceTransformer, util

def semantic_deduplicator(dataset, threshold=0.85, window_size=500):
    model = SentenceTransformer('all-MiniLM-L6-v2')
    unique_data = []
    unique_embeddings = []
    
    removed_count = 0
    total_initial = len(dataset)

    for entry in dataset:
        text = entry.get("instruction", "").strip()
        if not text:
            removed_count += 1
            continue
            
        # Generate embedding for the current candidate
        current_embedding = model.encode(text, convert_to_tensor=True)
        
        is_redundant = False
        if unique_embeddings:
            # Efficiency: Compare only against a "sliding window" of recent unique items
            # to keep complexity manageable while catching most duplicates
            lookback_buffer = unique_embeddings[-window_size:]
            
            # Calculate cosine similarities
            scores = util.cos_sim(current_embedding, np.stack(lookback_buffer))[0]
            
            if torch.max(scores) > threshold:
                is_redundant = True

        if not is_redundant:
            unique_data.append(entry)
            unique_embeddings.append(current_embedding.cpu().numpy())
        else:
            removed_count += 1

    pruned_pct = (removed_count / total_initial) * 100
    print(f"Pruning Complete: Removed {removed_count} items ({pruned_pct:.2f}%)")
    return unique_data

# Simulation
raw_data = [
    {"instruction": "What are the symptoms of diabetes?"},
    {"instruction": "List the signs of high blood sugar"}, # Semantic duplicate
    {"instruction": "How to bake a cake?"}
]
cleaned_data = semantic_deduplicator(raw_data, threshold=0.8)

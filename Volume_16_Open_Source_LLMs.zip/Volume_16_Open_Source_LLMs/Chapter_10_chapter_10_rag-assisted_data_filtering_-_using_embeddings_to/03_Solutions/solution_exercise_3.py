
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from abc import ABC, abstractmethod
from typing import List, Dict, Any

class DataFilter(ABC):
    @property
    @abstractmethod
    def name(self) -> str:
        pass

    @abstractmethod
    def filter(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        pass

class MinLengthFilter(DataFilter):
    def __init__(self, min_chars: int = 20):
        self.min_chars = min_chars
    
    @property
    def name(self): return "MinLengthFilter"

    def filter(self, data):
        return [d for d in data if len(d.get("instruction", "")) >= self.min_chars]

class SemanticDeduplicator(DataFilter):
    def __init__(self, model_name: str, threshold: float = 0.9):
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer(model_name)
        self.threshold = threshold
        self.name_str = f"SemanticDeduplicator({model_name})"

    @property
    def name(self): return self.name_str

    def filter(self, data):
        # Implementation of deduplication logic from Exercise 1
        # (Simplified for brevity in this pipeline example)
        return data[:len(data)//2] # Simulated reduction

class FilteringPipeline:
    def __init__(self, filters: List[DataFilter]):
        self.filters = filters

    def run(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        current_data = data
        for f in self.filters:
            initial_count = len(current_data)
            current_data = f.filter(current_data)
            removed = initial_count - len(current_data)
            print(f"[{f.name}] Removed {removed} items.")
        return current_data

# Usage
pipeline = FilteringPipeline([
    MinLengthFilter(min_chars=10),
    SemanticDeduplicator('all-MiniLM-L6-v2', threshold=0.85)
])

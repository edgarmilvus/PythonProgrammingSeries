
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np
from sentence_transformers import SentenceTransformer, util

def interactive_explorer(dataset_texts):
    model = SentenceTransformer('all-MiniLM-L6-v2')
    print("Pre-calculating embeddings...")
    embeddings = model.encode(dataset_texts, convert_to_tensor=True)
    
    # Pre-calculate similarity matrix to make the loop instant
    sim_matrix = util.cos_sim(embeddings, embeddings).cpu().numpy()
    np.fill_diagonal(sim_matrix, 0) # Ignore self-similarity

    while True:
        val = input("\nEnter similarity threshold (0.0-1.0) or 'apply': ")
        if val.lower() == 'apply': break
        
        try:
            threshold = float(val)
        except: continue

        pruned_indices = set()
        pairs_to_show = []

        for i in range(len(sim_matrix)):
            max_sim = np.max(sim_matrix[i])
            if max_sim > threshold:
                pruned_indices.add(i)
                if len(pairs_to_show) < 3:
                    match_idx = np.argmax(sim_matrix[i])
                    pairs_to_show.append((dataset_texts[i], dataset_texts[match_idx], max_sim))

        remaining = len(dataset_texts) - len(pruned_indices)
        reduction = (len(pruned_indices) / len(dataset_texts)) * 100
        
        print(f"--- Stats: Remaining: {remaining} | Reduction: {reduction:.1f}% ---")
        print("Sample Pruned Pairs:")
        for a, b, s in pairs_to_show:
            print(f"Score {s:.3f} | A: {a[:50]}... vs B: {b[:50]}...")

# Simulation call
sample_data = ["How to reset password?", "Password reset guide", "Bake a pie", "Pie recipe"]
interactive_explorer(sample_data)

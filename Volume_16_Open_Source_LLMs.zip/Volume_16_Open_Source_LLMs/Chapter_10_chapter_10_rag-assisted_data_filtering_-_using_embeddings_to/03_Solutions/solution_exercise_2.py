
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np
from sentence_transformers import SentenceTransformer

def filter_outliers(data_list, sensitivity=2.0):
    model = SentenceTransformer('all-MiniLM-L6-v2')
    texts = [d['instruction'] for d in data_list]
    
    # 1. Generate all embeddings
    embeddings = model.encode(texts) # Returns np.ndarray (N, 384)
    
    # 2. Calculate the Semantic Centroid (Mean Vector)
    centroid = np.mean(embeddings, axis=0)
    
    # 3. Calculate Euclidean distances from centroid for every point
    distances = np.linalg.norm(embeddings - centroid, axis=1)
    
    # 4. Statistical Pruning logic
    mu = np.mean(distances)
    sigma = np.std(distances)
    threshold = mu + (sensitivity * sigma)
    
    # 5. Filter the list
    keep_indices = np.where(distances <= threshold)[0]
    pruned_data = [data_list[i] for i in keep_indices]
    
    print(f"Centroid Filtering: Kept {len(pruned_data)}/{len(data_list)} items.")
    print(f"Threshold Distance: {threshold:.4f} (Mean: {mu:.4f}, Std: {sigma:.4f})")
    
    return pruned_data

# Example usage with simulated Python coding dataset
python_dataset = [
    {"instruction": "How to use list comprehensions in Python?"},
    {"instruction": "Write a flask route for user login"},
    {"instruction": "<html><body>Navigation Menu</body></html>"} # Outlier
]
clean_python_data = filter_outliers(python_dataset, sensitivity=1.5)

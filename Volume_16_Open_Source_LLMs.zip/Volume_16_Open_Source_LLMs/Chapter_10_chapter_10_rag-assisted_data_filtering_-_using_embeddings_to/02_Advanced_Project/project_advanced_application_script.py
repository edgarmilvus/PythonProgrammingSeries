
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import logging
from typing import List, Dict, Tuple
from sentence_transformers import SentenceTransformer
from sklearn.ensemble import IsolationForest
from sklearn.metrics.pairwise import cosine_similarity

# Configure logging to track the filtration process stages
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class SemanticDataCurator:
    """
    A Pythonic pipeline for filtering training data using semantic embeddings,
    outlier detection, and deduplication logic.
    """
    def __init__(self, model_name: str = 'all-MiniLM-L6-v2', contamination: float = 0.1):
        # Load a lightweight transformer model suitable for local embedding generation
        self.encoder = SentenceTransformer(model_name)
        # Initialize Isolation Forest for anomaly detection (garbage removal)
        # Contamination represents the expected percentage of 'noise' in the data
        self.outlier_detector = IsolationForest(contamination=contamination, random_state=42)
        self.raw_data = []
        self.embeddings = None

    def ingest_data(self, data_points: List[str]):
        """Cleans and loads raw text strings into the pipeline."""
        # Use a list comprehension for Pythonic data cleaning (removing empty strings)
        self.raw_data = [text.strip() for text in data_points if len(text.strip()) > 5]
        logging.info(f"Ingested {len(self.raw_data)} valid data points.")

    def generate_embeddings(self):
        """Converts text data into high-dimensional vector representations."""
        logging.info("Generating semantic embeddings... this may take a moment.")
        # Generate embeddings in batches to optimize GPU/CPU memory usage
        self.embeddings = self.encoder.encode(self.raw_data, show_progress_bar=True)
        return self.embeddings

    def remove_outliers(self) -> List[str]:
        """Uses Isolation Forest to identify and prune 'garbage' entries."""
        if self.embeddings is None:
            raise ValueError("Embeddings must be generated before outlier detection.")
        
        logging.info("Analyzing data distribution for outlier detection...")
        # Predict outliers: 1 for inliers, -1 for anomalies
        predictions = self.outlier_detector.fit_predict(self.embeddings)
        
        # Filter the raw data based on the model's predictions
        self.raw_data = [text for text, pred in zip(self.raw_data, predictions) if pred == 1]
        # Update embeddings to match the filtered data for the next step
        self.embeddings = self.embeddings[predictions == 1]
        
        logging.info(f"Removed outliers. Remaining samples: {len(self.raw_data)}")
        return self.raw_data

    def deduplicate(self, threshold: float = 0.92) -> List[str]:
        """Removes semantically redundant entries using cosine similarity."""
        logging.info(f"Starting semantic deduplication with threshold: {threshold}")
        # Calculate the pairwise similarity matrix for all remaining embeddings
        sim_matrix = cosine_similarity(self.embeddings)
        
        keep_mask = np.ones(len(self.raw_data), dtype=bool)
        for i in range(len(self.raw_data)):
            if keep_mask[i]:
                # Identify indices that are highly similar to the current entry
                # We look ahead (i+1:) to avoid redundant comparisons
                duplicate_indices = np.where(sim_matrix[i, i+1:] > threshold)[0] + (i + 1)
                # Mark duplicates to be removed
                keep_mask[duplicate_indices] = False
        
        # Apply the mask to finalize the clean dataset
        self.raw_data = [text for idx, text in enumerate(self.raw_data) if keep_mask[idx]]
        logging.info(f"Deduplication complete. Final dataset size: {len(self.raw_data)}")
        return self.raw_data

# Example usage in a real-world context
if __name__ == "__main__":
    # Mock dataset representing raw, noisy support logs
    raw_logs = [
        "To reset your password, navigate to settings and click security.",
        "To reset your password, go to the settings menu and select security.", # Semantic duplicate
        "Thanks!", "Hello?", "System auto-reply: Ticket #404 received.", # Garbage/Outliers
        "The Kubernetes cluster is experiencing OOM kills on the primary node.",
        "Check the node memory usage using kubectl top nodes.",
        "I am not sure what to do.", "kthxbye", # Low signal
        "Ensure your context is set correctly before running the kubectl command."
    ]

    # Initialize the curator with a 20% expected noise floor
    curator = SemanticDataCurator(contamination=0.2)
    
    # Execute the pipeline
    curator.ingest_data(raw_logs)
    curator.generate_embeddings()
    curator.remove_outliers()
    clean_data = curator.deduplicate(threshold=0.85)

    print("\n--- Final Curated Training Set ---")
    for entry in clean_data:
        print(f"Signal: {entry}")

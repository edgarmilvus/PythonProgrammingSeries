
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Import the necessary libraries for numerical operations and embeddings
from sentence_transformers import SentenceTransformer, util
import torch

def simple_semantic_filter():
    # 1. Load a pre-trained, lightweight Sentence Transformer model.
    # 'all-MiniLM-L6-v2' is fast and efficient for local CPU/GPU execution.
    model = SentenceTransformer('all-MiniLM-L6-v2')

    # 2. Define our "Gold Standard." This represents the "Signal" we want.
    # Any training data should be semantically similar to this concept.
    gold_standard = "Python is a high-level programming language used for data science and AI."

    # 3. Define our raw, "dirty" dataset containing signal and noise.
    raw_dataset = [
        "Python supports multiple programming paradigms, including structured and functional.", # SIGNAL
        "To make the best cookies, you must cream the butter and sugar thoroughly.",           # NOISE (Garbage)
        "The list data type in Python is a mutable, ordered sequence of elements.",            # SIGNAL
        "Error 404: The requested page was not found on this server.",                         # NOISE (Garbage)
        "Advanced LLM fine-tuning requires high-quality, curated datasets.",                   # SIGNAL (Related)
        "Click here to subscribe to our newsletter for more marketing tips!"                  # NOISE (Garbage)
    ]

    # 4. Convert the Gold Standard into a numerical vector (Embedding).
    # We use .encode() to transform text into a high-dimensional space.
    reference_embedding = model.encode(gold_standard, convert_to_tensor=True)

    print(f"Filtering dataset based on similarity to: '{gold_standard}'\n")
    
    filtered_data = []
    # Set a similarity threshold. Values range from -1 to 1. 
    # 0.4 to 0.6 is usually a good starting point for pruning noise.
    threshold = 0.45

    # 5. Iterate through the raw dataset to calculate similarity scores.
    for candidate in raw_dataset:
        # Encode the current candidate sentence.
        candidate_embedding = model.encode(candidate, convert_to_tensor=True)
        
        # 6. Calculate Cosine Similarity between the candidate and the reference.
        # This measures the cosine of the angle between the two vectors.
        score = util.cos_sim(reference_embedding, candidate_embedding).item()
        
        # 7. Apply the filtering logic.
        if score >= threshold:
            status = "[KEEP]"
            filtered_data.append(candidate)
        else:
            status = "[DROP]"
        
        # Print the results for visibility (useful for debugging your threshold).
        print(f"{status} Score: {score:.4f} | Text: {candidate[:60]}...")

    # 8. Output the final, cleaned dataset ready for fine-tuning.
    print(f"\nOriginal Size: {len(raw_dataset)} | Cleaned Size: {len(filtered_data)}")
    return filtered_data

# Execute the function
if __name__ == "__main__":
    clean_set = simple_semantic_filter()

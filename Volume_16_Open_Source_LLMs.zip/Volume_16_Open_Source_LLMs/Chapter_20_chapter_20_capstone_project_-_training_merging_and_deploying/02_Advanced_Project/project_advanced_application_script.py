
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import asyncio
import enum
from datetime import datetime
from typing import List, Optional

from openai import AsyncOpenAI
from pydantic import BaseModel, Field, validator
from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, Enum
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import instructor

# --- DATABASE CONFIGURATION ---
Base = declarative_base()
engine = create_engine("sqlite:///corporate_memory.db")
SessionLocal = sessionmaker(bind=engine)

class Priority(enum.Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class DBActionItem(Base):
    """SQLAlchemy Model representing the structure of our internal database table."""
    __tablename__ = "action_items"
    id = Column(Integer, primary_key=True, index=True)
    task = Column(String, nullable=False)
    owner = Column(String, nullable=False)
    priority = Column(Enum(Priority), default=Priority.MEDIUM)
    due_date = Column(String)
    context = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

# Create tables in the local SQLite database
Base.metadata.create_all(bind=engine)

# --- STRUCTURED OUTPUT SCHEMA ---
class ActionItem(BaseModel):
    """Pydantic Model for validating LLM output before database insertion."""
    task: str = Field(..., description="The specific action or task to be completed.")
    owner: str = Field(..., description="The person or department responsible.")
    priority: Priority = Field(default=Priority.MEDIUM)
    due_date: Optional[str] = Field(None, description="The deadline mentioned, if any.")
    
    @validator("task")
    def task_must_be_substantial(cls, v):
        if len(v) < 5:
            raise ValueError("Task description is too short to be actionable.")
        return v

class MeetingAnalysis(BaseModel):
    """Root schema for the SLM to populate."""
    summary: str = Field(..., description="A 2-sentence summary of the meeting.")
    action_items: List[ActionItem] = Field(..., description="List of extracted tasks.")

# --- CORE APPLICATION LOGIC ---
async def process_transcript(transcript: str):
    """
    Connects to a local vLLM/Ollama instance and extracts structured data.
    Ensures data privacy by targeting a local loopback address.
    """
    # Initialize the client pointing to the local vLLM/Ollama server
    # The 'instructor' patch enables the 'response_model' functionality
    client = instructor.patch(AsyncOpenAI(
        base_url="http://localhost:8000/v1",  # Local vLLM endpoint
        api_key="internal-private-key"         # Placeholder for local auth
    ))

    try:
        # Perform the inference using the fine-tuned SLM
        analysis = await client.chat.completions.create(
            model="corporate-slm-v1-merged",  # Your fine-tuned, merged model
            response_model=MeetingAnalysis,
            messages=[
                {"role": "system", "content": "You are a corporate assistant. Extract tasks accurately."},
                {"role": "user", "content": f"Analyze this transcript: {transcript}"}
            ],
            max_retries=3 # Pythonic retry logic built into instructor
        )

        # Persistence: Saving validated data to the local database
        db = SessionLocal()
        for item in analysis.action_items:
            new_record = DBActionItem(
                task=item.task,
                owner=item.owner,
                priority=item.priority,
                due_date=item.due_date,
                context=analysis.summary
            )
            db.add(new_record)
        
        db.commit()
        print(f"Successfully processed {len(analysis.action_items)} action items.")
        return analysis

    except Exception as e:
        print(f"Error during extraction or persistence: {e}")
    finally:
        db.close()

# --- EXECUTION ---
if __name__ == "__main__":
    raw_transcript = """
    In today's sync, Sarah from Engineering agreed to update the API documentation 
    by Friday. Mark will review the security protocols for the local vLLM deployment 
    immediately as it is a critical blocker. We also discussed the general budget, 
    but no decisions were made.
    """
    asyncio.run(process_transcript(raw_transcript))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import time
import json
import functools
import logging
from vllm import SamplingParams

logging.basicConfig(level=logging.INFO)

def enforce_corporate_standard(output_format="JSON", max_retries=3):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # 1. System Prompt Injection
            corporate_header = (
                f"You are a private AI assistant for CorporateCorp. "
                f"You must strictly follow Privacy Policy X. "
                f"Response Format: {output_format}."
            )
            
            if 'prompt' in kwargs:
                kwargs['prompt'] = f"{corporate_header}\nUser: {kwargs['prompt']}\nAssistant:"
            
            attempts = 0
            while attempts < max_retries:
                start_time = time.perf_counter()
                
                # 2. Execute Inference
                # Dynamically adjust temperature on retries
                if 'sampling_params' in kwargs:
                    kwargs['sampling_params'].temperature = 0.2 + (attempts * 0.3)
                
                result_text = func(*args, **kwargs)
                duration = time.perf_counter() - start_time
                
                # 3. Performance Logging
                if duration > 2.0:
                    logging.warning(f"Latency Warning: {duration:.2f}s | Prompt Len: {len(kwargs.get('prompt', ''))}")
                
                # 4. Structured Output Enforcement
                if output_format == "JSON":
                    try:
                        json.loads(result_text)
                        return result_text # Success
                    except json.JSONDecodeError:
                        attempts += 1
                        logging.error(f"JSON Parse failed. Retry {attempts}/{max_retries}")
                else:
                    return result_text
            
            return "Error: Failed to generate valid corporate response."
        return wrapper
    return decorator

# Mock vLLM function
@enforce_corporate_standard(output_format="JSON")
def generate_text(prompt: str, sampling_params: SamplingParams):
    # Simulating vLLM output
    return '{"status": "success", "data": "Policy details..."}'

# Usage
params = SamplingParams(temperature=0.2)
response = generate_text(prompt="Get HR policy", sampling_params=params)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import json
import uuid
from enum import Enum
from typing import List, Dict, Tuple, Optional
from pydantic import BaseModel, Field, field_validator, ValidationError

class Department(str, Enum):
    HR = "HR"
    TECH = "TECH"
    LEGAL = "LEGAL"

class CorporateMetadata(BaseModel):
    doc_id: uuid.UUID
    department: Department
    security_clearance: int = Field(ge=1, le=5)

class CorporateTrainingExample(BaseModel):
    instruction: str
    context: str
    response: str
    metadata: CorporateMetadata

    @field_validator('instruction', 'response')
    @classmethod
    def strip_whitespace(cls, v: str) -> str:
        return v.strip()

def validate_synthetic_batch(raw_data: List[Dict]) -> Tuple[List[CorporateTrainingExample], List[Dict]]:
    valid_examples = []
    error_log = []

    for index, entry in enumerate(raw_data):
        try:
            # Pydantic validation and whitespace stripping via validator
            example = CorporateTrainingExample(**entry)
            valid_examples.append(example)
        except ValidationError as e:
            error_log.append({
                "index": index,
                "errors": e.errors(),
                "raw_input": entry
            })
    
    return valid_examples, error_log

def export_to_jsonl(examples: List[CorporateTrainingExample], filename: str):
    with open(filename, 'w') as f:
        for ex in examples:
            # Exporting to standard JSONL format for PEFT/Fine-tuning
            f.write(ex.model_dump_json() + '\n')

# Example Usage
raw_payload = [
    {
        "instruction": "  What is the remote work policy?  ",
        "context": "Employees can work 3 days from home.",
        "response": "The policy allows for a hybrid schedule.  ",
        "metadata": {
            "doc_id": str(uuid.uuid4()),
            "department": "HR",
            "security_clearance": 1
        }
    },
    {
        "instruction": "Invalid Entry",
        "metadata": {"department": "SALES"} # Should fail (Missing fields & wrong Enum)
    }
]

valid, errors = validate_synthetic_batch(raw_payload)
export_to_jsonl(valid, "training_data.jsonl")

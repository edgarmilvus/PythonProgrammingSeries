
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import torch
from peft import PeftModel, PeftConfig
from transformers import AutoModelForCausalLM, AutoTokenizer
import copy

class ModelMerger:
    def __init__(self, base_model_path: str):
        self.base_model_path = base_model_path
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16

    def merge_with_density(self, adapter_path: str, density: float = 0.2):
        print(f"Loading base model in {self.dtype}...")
        try:
            base_model = AutoModelForCausalLM.from_pretrained(
                self.base_model_path, 
                torch_dtype=self.dtype,
                device_map="auto"
            )
            
            # Load the PEFT model
            model = PeftModel.from_pretrained(base_model, adapter_path)
            
            # Calculate Task Vectors and Trim
            # Note: In a real TIES implementation, we iterate through state_dicts
            with torch.no_grad():
                for name, param in model.named_parameters():
                    if "lora_A" in name or "lora_B" in name:
                        # Density-based trimming: keep top-k absolute magnitudes
                        flat_param = param.view(-1)
                        k = int(density * flat_param.numel())
                        if k > 0:
                            threshold = torch.topk(torch.abs(flat_param), k).values[-1]
                            param.data = torch.where(
                                torch.abs(param.data) >= threshold, 
                                param.data, 
                                torch.zeros_like(param.data)
                            )

            # Merge and unload
            merged_model = model.merge_and_unload()
            
            # Post-merge Verification (MSE)
            original_base = AutoModelForCausalLM.from_pretrained(
                self.base_model_path, torch_dtype=self.dtype
            ).to("cpu")
            
            mse = torch.nn.functional.mse_loss(
                merged_model.to("cpu").lm_head.weight.float(), 
                original_base.lm_head.weight.float()
            )
            print(f"Merge Complete. Weight Drift (MSE): {mse.item():.8f}")
            
            return merged_model

        except torch.cuda.OutOfMemoryError:
            print("GPU OOM triggered. Retrying merge on CPU...")
            torch.cuda.empty_cache()
            # Logic would repeat here with device_map={'': 'cpu'}
            return None

# Usage
# merger = ModelMerger("./base-mistral-7b")
# final_model = merger.merge_with_density("./legal-adapter", density=0.3)

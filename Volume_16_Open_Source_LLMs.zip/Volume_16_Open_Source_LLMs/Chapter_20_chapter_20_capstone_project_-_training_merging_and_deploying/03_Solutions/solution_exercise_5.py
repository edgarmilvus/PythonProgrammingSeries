
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import subprocess
import os

def generate_ollama_manifest(dept_name: str, hardware_profile: str):
    # Configuration Mapping
    profiles = {
        "workstation": {
            "base": "./corporate-model-q4_k_m.gguf",
            "ctx": 4096,
            "precision": "4-bit"
        },
        "server": {
            "base": "./corporate-model-fp16.bin",
            "ctx": 32768,
            "precision": "FP16"
        }
    }
    
    config = profiles.get(hardware_profile, profiles["workstation"])
    
    modelfile_content = f"""
FROM {config['base']}
PARAMETER num_ctx {config['ctx']}
PARAMETER stop "User:"
PARAMETER stop "Assistant:"
SYSTEM "You are the {dept_name} assistant. Access Level: {hardware_profile}. Data is encrypted."
"""
    
    filename = f"{dept_name.lower()}_modelfile"
    with open(filename, 'w') as f:
        f.write(modelfile_content)
    
    # Automation: Register with Ollama
    model_name = f"corp-{dept_name.lower()}-{hardware_profile}"
    try:
        subprocess.run(["ollama", "create", model_name, "-f", filename], check=True)
        print(f"Successfully registered model: {model_name}")
    except subprocess.CalledProcessError as e:
        print(f"Failed to create model: {e}")
    finally:
        if os.path.exists(filename):
            os.remove(filename)

# Usage
# generate_ollama_manifest("Tech", "server")
# generate_ollama_manifest("Sales", "workstation")

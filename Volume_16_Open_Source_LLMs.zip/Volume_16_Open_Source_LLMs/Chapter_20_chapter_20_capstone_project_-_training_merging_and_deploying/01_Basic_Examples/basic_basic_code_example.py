
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import json
from typing import List, Optional
from pydantic import BaseModel, Field, ValidationError

# --- DATA STRUCTURE DEFINITION ---

class EmployeeTransfer(BaseModel):
    """
    A Pydantic schema defining the structure of an internal corporate transfer.
    This ensures the LLM output matches our database requirements exactly.
    """
    employee_name: str = Field(description="The full name of the employee.")
    target_department: str = Field(description="The department the employee is moving to.")
    effective_date: str = Field(description="The ISO 8601 date of the transfer.")
    priority_level: int = Field(ge=1, le=5, description="Priority from 1 (Low) to 5 (Urgent).")
    tags: Optional[List[str]] = Field(default=[], description="Relevant HR category tags.")

# --- THE STRUCTURED INFERENCE FUNCTION ---

def process_corporate_request(raw_text: str):
    """
    Simulates a call to a local fine-tuned SLM (e.g., via Ollama or vLLM).
    The prompt instructs the model to respond ONLY in valid JSON matching the schema.
    """
    
    # In a real capstone scenario, this prompt would be sent to your local vLLM/Ollama endpoint.
    # We include the schema definition inside the prompt to guide the model's 'Structured Output'.
    system_prompt = f"""
    You are a private corporate assistant. Extract the requested information into JSON.
    Schema: {EmployeeTransfer.model_json_schema()}
    Return ONLY valid JSON.
    """

    # Simulated raw response from our fine-tuned local model
    # Note: A fine-tuned model is much better at following this specific JSON format.
    simulated_model_output = """
    {
        "employee_name": "Alice Henderson",
        "target_department": "Cloud Architecture",
        "effective_date": "2024-11-15",
        "priority_level": 4,
        "tags": ["internal-promotion", "technical-role"]
    }
    """

    try:
        # Step 1: Parse the raw string into a Python dictionary
        data_dict = json.loads(simulated_model_output)
        
        # Step 2: Validate and convert the dictionary into a Pythonic Pydantic object
        # This is where the 'Structured Output' magic happens.
        transfer_request = EmployeeTransfer(**data_dict)
        
        # Step 3: Access data using dot notation (Pythonic and type-safe)
        print(f"Successfully processed transfer for: {transfer_request.employee_name}")
        print(f"Target Department: {transfer_request.target_department}")
        print(f"Priority: {'High' if transfer_request.priority_level > 3 else 'Standard'}")
        
        return transfer_request

    except ValidationError as e:
        print(f"The model generated invalid data: {e}")
    except json.JSONDecodeError:
        print("The model failed to output valid JSON.")

# --- EXECUTION ---

if __name__ == "__main__":
    # Relatable context: An unstructured email snippet
    unstructured_email = "Alice Henderson is moving to Cloud Architecture on Nov 15th. It's quite urgent, priority 4."
    
    # Process the request
    result = process_corporate_request(unstructured_email)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Import the necessary libraries from the Hugging Face ecosystem
# 'transformers' handles the base model, 'peft' handles the LoRA adapters
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel
import torch
import os

def merge_lora_to_base(base_model_path, adapter_path, save_to_path):
    """
    Fuses a LoRA adapter into a base LLM and saves the result as a standalone model.
    """
    
    print(f"--- Loading Base Model: {base_model_path} ---")
    # Step 1: Load the base model in the highest precision supported by your hardware
    # We use torch_dtype=torch.float16 or bfloat16 to ensure the merge is precise.
    # device_map="cpu" is often used for merging to avoid VRAM limits, 
    # as merging is a memory-intensive but not compute-heavy task.
    base_model = AutoModelForCausalLM.from_pretrained(
        base_model_path,
        torch_dtype=torch.float16,
        device_map="cpu",
        trust_remote_code=True
    )

    print(f"--- Loading Adapter: {adapter_path} ---")
    # Step 2: Wrap the base model with the PeftModel (the LoRA adapter)
    # This creates a 'combined' model where the adapter weights are layered on top.
    model = PeftModel.from_pretrained(
        base_model,
        adapter_path
    )

    print("--- Merging Weights... This may take a minute ---")
    # Step 3: The 'merge_and_unload' method is the magic command.
    # It mathematically adds the LoRA weights (A and B matrices) to the 
    # corresponding base model weights and then removes the LoRA-specific hooks.
    merged_model = model.merge_and_unload()

    print(f"--- Saving Merged Model to: {save_to_path} ---")
    # Step 4: Save the unified weights to a local directory.
    # We use 'safe_serialization=True' to output Safetensors files (the industry standard).
    merged_model.save_pretrained(
        save_to_path, 
        safe_serialization=True
    )

    # Step 5: Don't forget the Tokenizer! 
    # A model is useless without its vocabulary. We load it from the base path and save it.
    tokenizer = AutoTokenizer.from_pretrained(base_model_path)
    tokenizer.save_pretrained(save_to_path)

    print("--- Merge Complete! Your standalone model is ready. ---")

# --- Execution Block ---
# Replace these strings with your actual local paths or Hugging Face IDs
if __name__ == "__main__":
    # Example: Merging a Llama-3-8B base with a custom 'Medical-Assistant' adapter
    BASE_ID = "meta-llama/Meta-Llama-3-8B"
    ADAPTER_ID = "./medical_lora_weights"
    OUTPUT_DIR = "./llama3-medical-standalone"

    # Create the output directory if it doesn't exist
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)

    merge_lora_to_base(BASE_ID, ADAPTER_ID, OUTPUT_DIR)

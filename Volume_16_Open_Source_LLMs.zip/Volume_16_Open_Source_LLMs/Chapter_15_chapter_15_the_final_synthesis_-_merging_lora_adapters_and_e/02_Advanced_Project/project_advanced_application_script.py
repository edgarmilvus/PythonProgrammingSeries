
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import torch
from sqlalchemy import create_engine, Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel
import datetime

# --- DATABASE LAYER (DRY & Lineage) ---
Base = declarative_base()

class ModelRegistry(Base):
    """SQLAlchemy model to track the lineage of merged weights."""
    __tablename__ = 'model_registry'
    id = Column(Integer, primary_key=True)
    base_model_path = Column(String)
    adapter_path = Column(String)
    output_path = Column(String)
    merge_date = Column(DateTime, default=datetime.datetime.utcnow)
    status = Column(String)

# --- CORE SYNTHESIS ENGINE ---
class ModelForge:
    def __init__(self, db_url="sqlite:///model_lineage.db"):
        # Initialize database session for tracking "Memory" of merges
        self.engine = create_engine(db_url)
        Base.metadata.create_all(self.engine)
        self.Session = sessionmaker(bind=self.engine)

    def log_merge(self, base, adapter, output, status):
        """Maintains an audit trail of model transformations."""
        session = self.Session()
        new_entry = ModelRegistry(base_model_path=base, adapter_path=adapter, 
                                  output_path=output, status=status)
        session.add(new_entry)
        session.commit()
        session.close()

    def merge_and_export(self, base_model_id, adapter_id, export_path, push_to_hub=False):
        """
        Loads a base model and LoRA adapter, merges them into a single 
        FP16/BF16 state, and exports to Safetensors.
        """
        print(f"[*] Starting synthesis for {adapter_id}...")
        
        try:
            # 1. Load the base model in the highest precision supported for merging
            # We use device_map="cpu" or "auto" depending on VRAM availability
            base_model = AutoModelForCausalLM.from_pretrained(
                base_model_id,
                torch_dtype=torch.float16,
                device_map="auto",
                trust_remote_code=True
            )
            
            # 2. Load the LoRA adapter on top of the base model
            # This creates a PeftModel object containing the original weights + adapters
            model = PeftModel.from_pretrained(base_model, adapter_id)
            
            # 3. Perform the 'Final Synthesis' (The Merge)
            # This mathematically fuses W = W0 + (A * B) into a single weight matrix
            print("[+] Merging weights... This may take a few minutes.")
            merged_model = model.merge_and_unload()
            
            # 4. Save the unified model in Safetensors format (Industry Standard)
            # Safetensors is faster and safer than traditional PyTorch pickles
            os.makedirs(export_path, exist_ok=True)
            merged_model.save_pretrained(export_path, safe_serialization=True)
            
            # 5. Export the tokenizer (Essential for GGUF/Ollama conversion)
            tokenizer = AutoTokenizer.from_pretrained(base_model_id)
            tokenizer.save_pretrained(export_path)
            
            self.log_merge(base_model_id, adapter_id, export_path, "SUCCESS")
            print(f"[!] Successfully exported merged model to: {export_path}")
            
        except Exception as e:
            self.log_merge(base_model_id, adapter_id, export_path, f"FAILED: {str(e)}")
            print(f"[X] Error during synthesis: {e}")

    def generate_ollama_modelfile(self, model_path, tag_name):
        """Automates the creation of an Ollama Modelfile for local deployment."""
        modelfile_content = f"""
FROM {model_path}
PARAMETER temperature 0.7
PARAMETER top_p 0.9
SYSTEM "You are a specialized assistant fine-tuned for enterprise tasks."
        """
        modelfile_path = os.path.join(model_path, "Modelfile")
        with open(modelfile_path, "w") as f:
            f.write(modelfile_content)
        print(f"[+] Created Ollama Modelfile at {modelfile_path}")

# --- EXECUTION ---
if __name__ == "__main__":
    # Define paths (In a real scenario, these come from environment variables or CLI)
    BASE = "mistralai/Mistral-7B-v0.1"
    ADAPTER = "./outputs/lora_legal_v1"
    DESTINATION = "./fused_models/legal_expert_v1"

    # Instantiate the Forge
    forge = ModelForge()
    
    # Run the synthesis pipeline
    forge.merge_and_export(BASE, ADAPTER, DESTINATION)
    
    # Prepare for Ollama deployment
    forge.generate_ollama_modelfile(DESTINATION, "legal-expert")

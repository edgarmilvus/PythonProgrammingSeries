
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import torch
import os
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel

def merge_lora_to_base(base_model_id, adapter_path, output_dir):
    # 1. Environment Initialization
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Using device: {device}")

    # 2. Model Loading Strategy: Load base in FP16
    # We load in FP16 because merge_and_unload() requires the base weights 
    # to be in a floating-point format to perform the addition (W + AB).
    print("Loading base model in FP16...")
    base_model = AutoModelForCausalLM.from_pretrained(
        base_model_id,
        torch_dtype=torch.float16,
        device_map={"": device}, # Load on specific device
        trust_remote_code=True
    )

    # 3. Adapter Integration
    print(f"Loading adapter from {adapter_path}...")
    model = PeftModel.from_pretrained(
        base_model,
        adapter_path,
        torch_dtype=torch.float16,
    )

    # 4. The Fusion Process
    print("Merging weights...")
    # This collapses the LoRA matrices into the base weights
    model = model.merge_and_unload()

    # Integrity Check: Ensure it's back to a standard AutoModel class
    if not hasattr(model, "peft_config"):
        print("Verification Successful: Model is now a standard CausalLM.")
    else:
        raise TypeError("Merge failed: Model still retains PEFT attributes.")

    # 5. Serialization
    print(f"Saving fused model to {output_dir}...")
    model.save_pretrained(
        output_dir, 
        safe_serialization=True  # Ensure .safetensors format
    )

    # 6. Tokenizer Synchronization
    tokenizer = AutoTokenizer.from_pretrained(base_model_id)
    tokenizer.save_pretrained(output_dir)
    print("Export complete.")

# Example Usage
# merge_lora_to_base("mistralai/Mistral-7B-v0.3", "./my-qlora-adapter", "./mistral-fused-fp16")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import asyncio
import httpx
import time
import subprocess

async def benchmark_endpoint(url, prompt, samples=10):
    async with httpx.AsyncClient(timeout=100.0) as client:
        latencies = []
        start_time = time.perf_counter()
        
        tasks = []
        for _ in range(samples):
            tasks.append(client.post(url, json={
                "model": "fused-model",
                "prompt": prompt,
                "max_tokens": 50,
                "stream": False
            }))
        
        responses = await asyncio.gather(*tasks)
        total_time = time.perf_counter() - start_time
        
        # Calculate TPS (Tokens Per Second)
        total_tokens = sum([r.json()['usage']['completion_tokens'] for r in responses])
        tps = total_tokens / total_time
        return tps

def run_ollama_verification(model_name):
    # 6. Ollama Verification
    print(f"Verifying knowledge in Ollama for {model_name}...")
    result = subprocess.run(
        ["ollama", "run", model_name, "Explain quantum entanglement in one sentence."],
        capture_output=True, text=True
    )
    print(f"Ollama Output: {result.stdout}")

# Example comparison logic
# merged_tps = asyncio.run(benchmark_endpoint("http://localhost:8000/v1/completions", "Hello"))
# print(f"Merged Model Throughput: {merged_tps:.2f} tokens/sec")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel, LoraConfig

def weighted_adapter_merge(base_id, adapter_a, adapter_b, weight_a=0.7, weight_b=0.3, method="linear"):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    
    # Load Base
    model = AutoModelForCausalLM.from_pretrained(base_id, torch_dtype=torch.float16).to(device)
    
    # 1. Dual-Adapter Loading
    # Load first adapter as default
    model = PeftModel.from_pretrained(model, adapter_a, adapter_name="coding")
    # Load second adapter
    model.load_adapter(adapter_b, adapter_name="storytelling")

    # 2. Weighted Combination & 3. Combination Methods
    # 'linear' = Arithmetic mean of weights
    # 'svd' = Singular Value Decomposition to find common directions
    print(f"Combining adapters using {method} method...")
    model.add_weighted_adapter(
        adapters=["coding", "storytelling"],
        weights=[weight_a, weight_b],
        adapter_name="hybrid_adapter",
        combination_type=method
    )
    
    # Set the new hybrid as active
    model.set_adapter("hybrid_adapter")

    # 4. Conflict Resolution: add_weighted_adapter handles mismatched targets
    # by filling missing deltas with zeros internally.

    # 5. Validation Inference (Dry Run)
    tokenizer = AutoTokenizer.from_pretrained(base_id)
    inputs = tokenizer("def solve_problem():", return_tensors="pt").to(device)
    print("Running dry run inference...")
    with torch.no_grad():
        outputs = model.generate(**inputs, max_new_tokens=20)
        print(tokenizer.decode(outputs[0]))

    # 6. Export
    model = model.merge_and_unload()
    model.save_pretrained("./hybrid_model_fused", safe_serialization=True)
    print("Hybrid model saved successfully.")

# weighted_adapter_merge("base_path", "path/to/a", "path/to/b")

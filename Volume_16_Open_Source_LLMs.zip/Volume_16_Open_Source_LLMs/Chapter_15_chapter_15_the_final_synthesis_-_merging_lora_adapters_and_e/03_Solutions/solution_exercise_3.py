
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import subprocess
import os
import json

def run_gguf_pipeline(model_path, output_base_name):
    # 1. Dependency Management
    if not os.path.exists("llama.cpp/convert_hf_to_gguf.py"):
        raise FileNotFoundError("Please clone llama.cpp and install requirements.")

    # 2. Conversion Logic (FP16 GGUF first)
    fp16_gguf = f"{output_base_name}.fp16.gguf"
    print("Converting Safetensors to FP16 GGUF...")
    subprocess.run([
        "python", "llama.cpp/convert_hf_to_gguf.py", 
        model_path, 
        "--outfile", fp16_gguf,
        "--outtype", "f16"
    ], check=True)

    # 3. Quantization Matrix
    quants = ["Q4_K_M", "Q8_0"]
    for q in quants:
        out_file = f"{output_base_name}.{q}.gguf"
        print(f"Quantizing to {q}...")
        subprocess.run([
            "./llama.cpp/quantize", fp16_gguf, out_file, q
        ], check=True)

        # 6. Size Verification
        orig_size = os.path.getsize(fp16_gguf) / (1024**3)
        quant_size = os.path.getsize(out_file) / (1024**3)
        print(f"{q} Compression: {orig_size:.2f}GB -> {quant_size:.2f}GB")

    # 5. Ollama Integration
    modelfile_content = f"""
FROM ./{output_base_name}.Q4_K_M.gguf
PARAMETER stop <|end_of_text|>
SYSTEM You are a helpful AI assistant merged from multiple specialists.
"""
    with open("Modelfile", "w") as f:
        f.write(modelfile_content)
    print("Ollama Modelfile generated.")

# run_gguf_pipeline("./mistral-fused-fp16", "my_custom_model")

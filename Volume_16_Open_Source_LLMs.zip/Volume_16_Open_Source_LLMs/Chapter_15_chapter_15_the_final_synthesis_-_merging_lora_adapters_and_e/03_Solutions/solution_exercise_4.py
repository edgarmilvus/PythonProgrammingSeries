
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
import datetime
import json
from sqlalchemy import create_all, create_engine, Column, Integer, String, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

Base = declarative_base()

# 2. SQLAlchemy Model
class MergeHistory(Base):
    __tablename__ = 'merge_history'
    id = Column(Integer, primary_key=True)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
    base_model_name = Column(String)
    adapter_list = Column(String)
    merge_method = Column(String)
    output_path = Column(String)
    purpose = Column(String)

# 1. Descriptor Protocol
class ModelPathValidator:
    def __set__(self, instance, value):
        if not os.path.exists(value):
            raise FileNotFoundError(f"Path {value} does not exist.")
        if not any(f in os.listdir(value) for f in ['config.json', 'adapter_config.json']):
            raise FileNotFoundError(f"No config found in {value}.")
        instance.__dict__[self.name] = value
    
    def __set_name__(self, owner, name):
        self.name = name

class MergeManager:
    base_path = ModelPathValidator()
    adapter_path = ModelPathValidator()

    def __init__(self, base, adapter, db_url="sqlite:///model_registry.db"):
        self.base_path = base
        self.adapter_path = adapter
        self.engine = create_engine(db_url)
        Base.metadata.create_all(self.engine)
        self.Session = sessionmaker(bind=self.engine)

    def log_merge(self, method, output, purpose):
        session = self.Session()
        # 3. LLM Memory Context (Simplified versioning)
        last_entry = session.query(MergeHistory).order_by(MergeHistory.id.desc()).first()
        version = f"v1.{last_entry.id + 1}" if last_entry else "v1.0"
        
        entry = MergeHistory(
            base_model_name=self.base_path,
            adapter_list=json.dumps([self.adapter_path]),
            merge_method=method,
            output_path=f"{output}_{version}",
            purpose=purpose
        )
        session.add(entry)
        session.commit()
        return version

# Usage logic with 4. Error Handling & 5. Prompt
# manager = MergeManager(input("Base Path: "), input("Adapter Path: "))
# purpose = input("Merge Purpose: ")
# try: ... model.merge_and_unload() ... manager.log_merge(...)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os

class Llama3PromptFormatter:
    def __init__(self):
        # Requirement 1 & 4: Stateful Memory and BOS token
        self.history = []
        self.bos_token = "<|begin_of_text|>"
        
        # Requirement 5: Environment Configuration for System Prompt
        default_sys = os.environ.get("LLAMA3_DEFAULT_SYSTEM", "You are a helpful assistant.")
        self.add_message("system", default_sys)

    def add_message(self, role, content):
        self.history.append({"role": role, "content": content})

    def _format_turn(self, role, content, include_eot=True):
        # Requirement 2 & 3: Header formatting and Turn Termination
        header = f"<|start_header_id|>{role}<|end_header_id|>\n\n"
        turn = f"{header}{content}"
        if include_eot:
            turn += "<|eot_id|>"
        return turn

    def get_inference_prompt(self):
        # Requirement 6: Generation Mode Toggle (Assistant trigger)
        full_string = self.bos_token
        
        # Format all existing history with EOT tags
        for msg in self.history:
            full_string += self._format_turn(msg["role"], msg["content"])
            
        # Append the open-ended assistant header
        full_string += f"<|start_header_id|>assistant<|end_header_id|>\n\n"
        return full_string

# Example Usage:
formatter = Llama3PromptFormatter()
formatter.add_message("user", "Hello, Llama-3!")
print(formatter.get_inference_prompt())

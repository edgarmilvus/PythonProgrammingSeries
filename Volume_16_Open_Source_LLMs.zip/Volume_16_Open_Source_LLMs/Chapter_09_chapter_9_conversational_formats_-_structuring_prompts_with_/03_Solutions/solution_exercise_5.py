
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

def prompt_guard():
    # Requirement 5: Configuration via CLI
    try:
        max_len = int(input("Set MAX_LENGTH (int): "))
    except ValueError:
        max_len = 2048

    # Requirement 1: Interactive Loop
    while True:
        print("\n--- Prompt Guard Validator ---")
        choice = input("Select Format (1: ChatML, 2: Llama-3, q: Quit): ")
        if choice.lower() == 'q': break
        
        print("Paste your full prompt (End with a blank line):")
        lines = []
        while True:
            line = input()
            if line == "": break
            lines.append(line)
        prompt = "\n".join(lines)

        # Requirement 2 & 3: Structural Analysis and Visual Feedback
        errors = []
        if choice == "1":
            if prompt.count("<|im_start|>") != prompt.count("<|im_end|>") + 1:
                errors.append("MISSING TAGS: Mismatch between start and end tags (Note: final assistant tag should be open).")
            if "system" not in prompt:
                errors.append("WARNING: No 'system' role detected.")
        
        elif choice == "2":
            if not prompt.startswith("<|begin_of_text|>"):
                errors.append("MISSING BOS: Llama-3 prompts must start with <|begin_of_text|>")
            if prompt.count("<|start_header_id|>") != prompt.count("<|end_header_id|>"):
                errors.append("HEADER ERROR: Unclosed header IDs.")
            if "<|eot_id|>" not in prompt:
                errors.append("MISSING EOT: No end-of-turn tokens found.")

        # Length Warning
        if len(prompt) > max_len:
            errors.append(f"CRITICAL: Prompt length ({len(prompt)}) exceeds MAX_LENGTH ({max_len}). Truncation likely!")

        if not errors:
            print("✅ Prompt Health: EXCELLENT")
        else:
            for err in errors:
                print(f"❌ {err}")

        # Requirement 4: Memory Simulation
        append = input("\nAppend a User Turn? (y/n): ")
        if append.lower() == 'y':
            new_msg = input("Enter user message: ")
            if choice == "1":
                prompt = prompt.replace("<|im_start|>assistant\n", f"<|im_start|>user\n{new_msg}<|im_end|>\n<|im_start|>assistant\n")
            print("\n--- Updated LLM Memory ---\n", prompt)

prompt_guard()

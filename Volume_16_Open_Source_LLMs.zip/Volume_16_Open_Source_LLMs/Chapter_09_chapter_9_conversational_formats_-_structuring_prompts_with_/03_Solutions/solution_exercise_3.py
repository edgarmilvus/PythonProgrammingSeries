
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os

def manage_context_window(messages):
    # Requirement 1: Configuration via Environment
    max_chars = int(os.environ.get("MAX_CONTEXT_CHARS", 1000))
    
    def get_formatted_length(msgs):
        # Helper to calculate current ChatML string length
        temp_prompt = ""
        for m in msgs:
            temp_prompt += f"<|im_start|>{m['role']}\n{m['content']}<|im_end|>\n"
        temp_prompt += "<|im_start|>assistant\n"
        return len(temp_prompt)

    # Requirement 3: Sliding Window Logic
    # We prune if length > max and we have more than just the system prompt
    while get_formatted_length(messages) > max_chars and len(messages) > 1:
        # Requirement 2: System Prompt Preservation (Never remove index 0)
        removed_turn = messages.pop(1) 
        
        # Requirement 4: Metadata Tracking
        print(f"[LOG] Pruned turn: {removed_turn['role']}. "
              f"Current history length: {len(messages)} turns.")

    # Requirement 5: Final Output Format
    final_prompt = ""
    for m in messages:
        final_prompt += f"<|im_start|>{m['role']}\n{m['content']}<|im_end|>\n"
    final_prompt += "<|im_start|>assistant\n"
    
    return final_prompt

# Example Usage:
os.environ["MAX_CONTEXT_CHARS"] = "150"
chat_history = [
    {"role": "system", "content": "You are a concise bot."},
    {"role": "user", "content": "Tell me a very long story about the stars..."},
    {"role": "assistant", "content": "Once upon a time in a galaxy far away..."},
    {"role": "user", "content": "Actually, just tell me a joke."}
]
print(manage_context_window(chat_history))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os

class AdvancedFormatter:
    def __init__(self, format_type="chatml"):
        self.format_type = format_type
        # Requirement 4: Environment-Based Toggle
        self.few_shot_enabled = os.environ.get("ENABLE_FEW_SHOT", "false").lower() == "true"

    def format(self, system_msg, history, examples=None):
        # Requirement 5: Integer Validation
        if examples and len(examples) > 5:
            raise ValueError("Maximum 5 few-shot examples allowed.")

        output = ""
        
        # 1. System Prompt
        if self.format_type == "chatml":
            output += f"<|im_start|>system\n{system_msg}<|im_end|>\n"
        else: # Llama-3
            output += f"<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n\n{system_msg}<|eot_id|>"

        # 2. Strategic Placement: Few-Shot Anchoring
        if self.few_shot_enabled and examples:
            for shot in examples:
                user_ex, assist_ex = shot
                if self.format_type == "chatml":
                    output += f"<|im_start|>user\n{user_ex}<|im_end|>\n"
                    output += f"<|im_start|>assistant\n{assist_ex}<|im_end|>\n"
                else:
                    output += f"<|start_header_id|>user<|end_header_id|>\n\n{user_ex}<|eot_id|>"
                    output += f"<|start_header_id|>assistant<|end_header_id|>\n\n{assist_ex}<|eot_id|>"

        # 3. Conversation History
        for msg in history:
            role, content = msg['role'], msg['content']
            if self.format_type == "chatml":
                output += f"<|im_start|>{role}\n{content}<|im_end|>\n"
            else:
                output += f"<|start_header_id|>{role}<|end_header_id|>\n\n{content}<|eot_id|>"

        # 4. Final Trigger
        if self.format_type == "chatml":
            output += "<|im_start|>assistant\n"
        else:
            output += "<|start_header_id|>assistant<|end_header_id|>\n\n"
            
        return output

# Usage Example
os.environ["ENABLE_FEW_SHOT"] = "true"
formatter = AdvancedFormatter(format_type="llama3")
shots = [("Is Pluto a planet?", "In my database, it is a dwarf planet.")]
print(formatter.format("You are a science tutor.", [{"role": "user", "content": "What about Mars?"}], examples=shots))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import math

def build_chatml_prompt(messages, max_tokens=512):
    # Requirement 6: Edge Case - Default system prompt if list is empty
    if not messages:
        messages = [{"role": "system", "content": "You are a helpful assistant."}]

    allowed_roles = ["system", "user", "assistant"]
    formatted_parts = []

    for msg in messages:
        role = msg.get("role")
        content = msg.get("content")

        # Requirement 2: Role Validation
        if role not in allowed_roles:
            raise ValueError(f"Invalid role '{role}'. Must be one of {allowed_roles}")

        # Requirement 3: ChatML Syntax construction
        # <|im_start|>{role}\n{content}<|im_end|>\n
        block = f"<|im_start|>{role}\n{content}<|im_end|>\n"
        formatted_parts.append(block)

    # Requirement 4: The "Assistant" Trigger (no closing tag)
    prompt = "".join(formatted_parts)
    prompt += "<|im_start|>assistant\n"

    # Requirement 5: Token Counting Logic (1 word = 1.2 tokens)
    word_count = len(prompt.split())
    estimated_tokens = math.ceil(word_count * 1.2)

    if estimated_tokens > max_tokens:
        raise ValueError(f"Prompt exceeds token limit: {estimated_tokens}/{max_tokens}")

    return prompt

# Example Usage:
raw_messages = [
    {"role": "system", "content": "You are a logic expert."},
    {"role": "user", "content": "Explain ChatML."}
]
print(build_chatml_prompt(raw_messages))

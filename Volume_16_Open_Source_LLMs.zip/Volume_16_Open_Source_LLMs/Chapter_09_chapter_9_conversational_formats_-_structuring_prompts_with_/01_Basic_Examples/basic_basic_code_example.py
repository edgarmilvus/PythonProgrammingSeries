
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

from transformers import AutoTokenizer

# 1. SETUP: Define the Model ID for a Llama-3 Instruct model
# We use the tokenizer to access the 'chat_template' metadata.
model_id = "meta-llama/Meta-Llama-3-8B-Instruct"

# 2. INITIALIZATION: Load the tokenizer
# The tokenizer contains the Jinja2 template and special token definitions.
tokenizer = AutoTokenizer.from_pretrained(model_id)

# 3. DATA STRUCTURE: Define the conversation history
# We use a list of dictionaries, a standard format for Chat APIs.
# Note the use of SQLAlchemy and Integer concepts in the content.
messages = [
    {
        "role": "system", 
        "content": "You are a database expert specializing in SQLAlchemy ORM."
    },
    {
        "role": "user", 
        "content": "How do I define a primary key using the Integer type in a declarative model?"
    }
]

def format_prompt_eafp(tokenizer, message_list):
    """
    Formats the message list using the EAFP principle.
    We assume the structure is correct and let the template engine 
    raise an error if a role is missing or invalid.
    """
    try:
        # 4. TRANSFORMATION: Apply the chat template
        # tokenize=False: We want the raw string, not the integer IDs (yet).
        # add_generation_prompt=True: Appends the header for the assistant's turn.
        formatted_prompt = tokenizer.apply_chat_template(
            message_list, 
            tokenize=False, 
            add_generation_prompt=True
        )
        return formatted_prompt
    except Exception as e:
        # Handle cases where the message structure doesn't match the template
        return f"Formatting Error: {str(e)}"

# 5. EXECUTION: Generate and print the final prompt
final_prompt = format_prompt_eafp(tokenizer, messages)

print("--- RAW FORMATTED PROMPT ---")
print(final_prompt)
print("----------------------------")

# 6. VERIFICATION: Show the underlying Integer token IDs
# This is what the model actually 'sees' after the string is processed.
input_ids = tokenizer.encode(final_prompt)
print(f"Total Tokens (as Integers): {len(input_ids)}")
print(f"First 10 Token IDs: {input_ids[:10]}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import json
from datetime import datetime
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, ForeignKey
from sqlalchemy.orm import declarative_base, sessionmaker, relationship

# --- DATABASE SETUP (SQLAlchemy) ---
Base = declarative_base()

class Conversation(Base):
    """Represents a single chat session to maintain state across the application."""
    __tablename__ = 'conversations'
    id = Column(Integer, primary_key=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    messages = relationship("Message", back_populates="conversation")

class Message(Base):
    """Stores individual message turns with role and content metadata."""
    __tablename__ = 'messages'
    id = Column(Integer, primary_key=True)
    conversation_id = Column(Integer, ForeignKey('conversations.id'))
    role = Column(String(50))  # system, user, assistant
    content = Column(Text)
    conversation = relationship("Conversation", back_populates="messages")

# --- TEMPLATE ENGINE (DRY Principle) ---
class PromptTemplateEngine:
    """A unified engine to handle different LLM conversational formats."""
    def __init__(self, format_type="chatml"):
        self.format_type = format_type

    def apply(self, messages):
        """Dispatches the message list to the appropriate formatter."""
        if self.format_type == "chatml":
            return self._format_chatml(messages)
        elif self.format_type == "llama3":
            return self._format_llama3(messages)
        return "\n".join([f"{m.role}: {m.content}" for m in messages])

    def _format_chatml(self, messages):
        """Implements the ChatML standard: <|im_start|>role\ncontent<|im_end|>\n"""
        prompt = ""
        for msg in messages:
            prompt += f"<|im_start|>{msg.role}\n{msg.content}<|im_end|>\n"
        # Append the assistant trigger for completion
        prompt += "<|im_start|>assistant\n"
        return prompt

    def _format_llama3(self, messages):
        """Implements Llama-3 Instruct: <|start_header_id|>role<|end_header_id|>\n\ncontent<|eot_id|>"""
        prompt = "<|begin_of_text|>"
        for msg in messages:
            prompt += f"<|start_header_id|>{msg.role}<|end_header_id|>\n\n{msg.content}<|eot_id|>"
        prompt += "<|start_header_id|>assistant<|end_header_id|>\n\n"
        return prompt

# --- MONKEY PATCHING UTILITY ---
def patch_llama_format_for_vllm(engine_instance):
    """
    Dynamically modifies the Llama-3 formatter at runtime.
    Useful for injecting specific BOS/EOS tokens required by certain inference engines like vLLM.
    """
    def new_llama_format(messages):
        # A modified version that adds a specific system prefix for vLLM compatibility
        prompt = "[[VLLM_COMPAT_MODE]]\n<|begin_of_text|>"
        for msg in messages:
            prompt += f"<|start_header_id|>{msg.role}<|end_header_id|>\n\n{msg.content}<|eot_id|>"
        prompt += "<|start_header_id|>assistant<|end_header_id|>\n\n"
        return prompt
    
    # Applying the monkey patch to the instance method
    engine_instance._format_llama3 = new_llama_format
    print("System: Llama-3 formatter monkey-patched for vLLM compatibility.")

# --- APPLICATION LOGIC ---
def run_orchestrator():
    # Initialize SQLite database in memory for demonstration
    engine = create_engine('sqlite:///:memory:')
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    db_session = Session()

    # 1. Create a new conversation record
    new_chat = Conversation()
    db_session.add(new_chat)
    db_session.commit()

    # 2. Add sample messages (User interaction)
    msgs = [
        Message(role="system", content="You are a helpful coding assistant.", conversation=new_chat),
        Message(role="user", content="How do I implement DRY in Python?", conversation=new_chat)
    ]
    db_session.add_all(msgs)
    db_session.commit()

    # 3. Instantiate the engine and generate prompts for both formats
    orchestrator = PromptTemplateEngine(format_type="chatml")
    history = db_session.query(Message).filter_by(conversation_id=new_chat.id).all()

    print("--- CHATML OUTPUT ---")
    print(orchestrator.apply(history))

    # Switch to Llama-3 and demonstrate format change
    orchestrator.format_type = "llama3"
    print("\n--- LLAMA-3 OUTPUT ---")
    print(orchestrator.apply(history))

    # 4. Demonstrate Monkey Patching for a specific production edge case
    patch_llama_format_for_vllm(orchestrator)
    print("\n--- PATCHED LLAMA-3 OUTPUT ---")
    print(orchestrator.apply(history))

if __name__ == "__main__":
    run_orchestrator()

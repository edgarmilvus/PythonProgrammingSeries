
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import torch
import wandb
import json
from tqdm import tqdm
from torch.utils.data import Dataset, DataLoader
from transformers import AutoModelForCausalLM, AutoTokenizer, get_linear_schedule_with_warmup
from peft import LoraConfig, get_peft_model, TaskType

# --- CONFIGURATION & HYPERPARAMETERS ---
# We define a dictionary to pass to wandb.init for experiment versioning
config = {
    "model_id": "microsoft/phi-2",
    "lora_rank": 16,
    "lora_alpha": 32,
    "learning_rate": 2e-4,
    "batch_size": 2,
    "epochs": 3,
    "max_length": 512,
    "dataset_path": "medical_dialogue.jsonl"
}

# --- DATASET HANDLING: ITERATING OVER A FILE OBJECT ---
class StreamedMedicalDataset(Dataset):
    """
    A memory-efficient dataset that avoids loading the entire file into RAM.
    It demonstrates 'Iterating over a File Object' to handle massive datasets.
    """
    def __init__(self, file_path, tokenizer, max_length):
        self.data = []
        self.tokenizer = tokenizer
        self.max_length = max_length
        
        # Iterating over a File Object: Reading line by line to save memory
        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                # Every line is a JSON object representing a dialogue turn
                item = json.loads(line)
                self.data.append(item['text'])

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        # Tokenize the text and return as tensors
        encoding = self.tokenizer(
            self.data[idx],
            truncation=True,
            max_length=self.max_length,
            padding="max_length",
            return_tensors="pt"
        )
        return {
            "input_ids": encoding["input_ids"].squeeze(),
            "attention_mask": encoding["attention_mask"].squeeze()
        }

def train_model():
    # Initialize the W&B run to track the "Brain Growing"
    wandb.init(project="slm-medical-finetune", config=config)
    
    # Load Tokenizer and Model
    tokenizer = AutoTokenizer.from_pretrained(config["model_id"])
    tokenizer.pad_token = tokenizer.eos_token
    
    # Load model with 4-bit quantization for local hardware efficiency
    model = AutoModelForCausalLM.from_pretrained(
        config["model_id"],
        device_map="auto",
        load_in_4bit=True
    )

    # Configure LoRA (Low-Rank Adaptation)
    peft_config = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=config["lora_rank"],
        lora_alpha=config["lora_alpha"],
        target_modules=["q_proj", "v_proj"],
        lora_dropout=0.05
    )
    model = get_peft_model(model, peft_config)
    model.print_trainable_parameters()

    # Prepare Dataset and Dataloader
    dataset = StreamedMedicalDataset(config["dataset_path"], tokenizer, config["max_length"])
    dataloader = DataLoader(dataset, batch_size=config["batch_size"], shuffle=True)

    # Optimizer and Scheduler
    optimizer = torch.optim.AdamW(model.parameters(), lr=config["learning_rate"])
    lr_scheduler = get_linear_schedule_with_warmup(
        optimizer, num_warmup_steps=100, num_training_steps=len(dataloader) * config["epochs"]
    )

    # --- TRAINING LOOP ---
    model.train()
    for epoch in range(config["epochs"]):
        total_loss = 0
        for step, batch in enumerate(tqdm(dataloader)):
            # Move batch to GPU
            input_ids = batch["input_ids"].to("cuda")
            attention_mask = batch["attention_mask"].to("cuda")

            # Forward Pass
            outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=input_ids)
            loss = outputs.loss
            
            # Backward Pass
            loss.backward()
            optimizer.step()
            lr_scheduler.step()
            optimizer.zero_grad()

            # --- METRIC LOGGING ---
            # Extract Embeddings to monitor semantic drift
            # Embeddings: Dense numerical vector representations capturing semantic meaning
            current_lr = lr_scheduler.get_last_lr()[0]
            
            # Log metrics to W&B in real-time
            wandb.log({
                "epoch": epoch,
                "step": step,
                "train_loss": loss.item(),
                "learning_rate": current_lr,
                "vram_allocated_gb": torch.cuda.memory_allocated() / 1e9
            })

            if step % 50 == 0:
                print(f"Epoch {epoch} | Step {step} | Loss: {loss.item():.4f}")

    # Save the LoRA adapters and log to W&B Artifacts
    model.save_pretrained("./medical_slm_final")
    wandb.save("./medical_slm_final/*")
    wandb.finish()

if __name__ == "__main__":
    # Ensure a dummy dataset exists for the example context
    if not os.path.exists("medical_dialogue.jsonl"):
        with open("medical_dialogue.jsonl", "w") as f:
            for i in range(100):
                f.write(json.dumps({"text": f"Patient: I feel sick. Doctor: Take some rest. Sample {i}"}) + "\n")
    
    train_model()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
import wandb
import torch

class HardwareMonitor:
    @staticmethod
    def get_vram_breakdown():
        # Requirement 3: Multi-GPU VRAM Breakdown
        stats = {}
        for i in range(torch.cuda.device_count()):
            mem = torch.cuda.memory_reserved(i) / 1024**3 # GB
            stats[f"vram/gpu_{i}"] = mem
        return stats

class ExperimentTracker:
    def __init__(self, project, blueprint_version, offline=False):
        self.offline = offline
        # Requirement 5: Versioned Dashboards
        run_name = f"blueprint-v{blueprint_version}-{time.strftime('%Y%m%d')}"
        
        # Requirement 6: Error Handling / Offline Mode
        try:
            wandb.init(
                project=project,
                name=run_name,
                mode="offline" if offline else "online",
                group=f"v{blueprint_version}"
            )
        except Exception as e:
            print(f"W&B Init failed, falling back to local logging: {e}")

    def log_metrics(self, metrics, phase="training"):
        # Requirement 4: Phase-specific correlation
        stamped_metrics = {f"{phase}/{k}": v for k, v in metrics.items()}
        stamped_metrics.update(HardwareMonitor.get_vram_breakdown())
        wandb.log(stamped_metrics)

class ModelOrchestrator:
    def __init__(self, tracker):
        self.tracker = tracker

    def run_training(self):
        # Data Loading Phase
        self.tracker.log_metrics({"cpu_usage": 45.5}, phase="data_loading")
        
        # Forward Pass Phase
        # ... training logic ...
        self.tracker.log_metrics({"loss": 0.5}, phase="forward_pass")

# Usage
# tracker = ExperimentTracker("my-llm-project", blueprint_version="2.1")
# orchestrator = ModelOrchestrator(tracker)
# orchestrator.run_training()

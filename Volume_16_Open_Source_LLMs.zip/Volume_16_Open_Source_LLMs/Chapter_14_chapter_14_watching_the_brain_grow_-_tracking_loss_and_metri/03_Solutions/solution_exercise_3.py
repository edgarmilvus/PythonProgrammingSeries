
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import wandb

# 1. Sweep Configuration (Requirement 1, 2, 3, 4)
sweep_config = {
    'method': 'random',  # Search strategy
    'metric': {
        'name': 'eval/loss',
        'goal': 'minimize'   # Requirement 4
    },
    'parameters': {
        'r': {
            'values': [8, 16, 32, 64]  # Requirement 2
        },
        'learning_rate': {
            'distribution': 'log_uniform_values',
            'min': 1e-5,
            'max': 5e-4
        },
        'target_all_linears': {
            'values': [True, False]   # Requirement 3
        }
    },
    # Requirement 5: Early Stopping
    'early_terminate': {
        'type': 'hyperband',
        'min_iter': 3,
        'eta': 2
    }
}

def train():
    with wandb.init() as run:
        config = run.config
        
        # Requirement 2: Alpha relative to r
        lora_alpha = config.r * 2
        
        # Requirement 3: Boolean Architecture Logic
        target_modules = "all-linear" if config.target_all_linears else ["q_proj", "v_proj"]
        
        # Initialize LoRA with sweep params
        # lora_config = LoraConfig(r=config.r, lora_alpha=lora_alpha, target_modules=target_modules, ...)
        # trainer = Trainer(...)
        # trainer.train()

# Initialize the sweep
# sweep_id = wandb.sweep(sweep_config, project="lora-optimization-sweep")
# wandb.agent(sweep_id, function=train, count=10)

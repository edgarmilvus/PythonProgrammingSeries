
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import time
from transformers.integrations import WandbCallback

# Toggle for deep-dive logging (Requirement 4)
DEBUG_METRICS = True

def patch_wandb_callback():
    """Monkey patches the WandbCallback to include custom metrics."""
    original_log = WandbCallback.on_log

    def custom_on_log(self, args, state, control, logs=None, **kwargs):
        if logs is not None:
            # Requirement 3: Calculate Efficiency Score
            # (Tokens per second proxy: steps/time)
            elapsed = time.time() - state.start_time if state.start_time else 1
            efficiency_score = state.global_step / elapsed
            logs["custom/efficiency_score"] = efficiency_score
            
            # Requirement 2: Inject custom ratio logic (conceptual)
            if "grad_norm" in logs and "weight_norm" in logs:
                logs["custom/grad_weight_ratio"] = logs["grad_norm"] / logs["weight_norm"]
        
        # Call the original logging logic
        return original_log(self, args, state, control, logs=logs, **kwargs)

    # Apply the patch (Requirement 1 & 2)
    WandbCallback.on_log = custom_on_log
    print("Monkey Patch applied: WandbCallback is now tracking efficiency.")

# Requirement 5: Gradient Watching Logic
def setup_gradient_monitoring(model):
    if DEBUG_METRICS:
        patch_wandb_callback()
        # Check for LoRA layers specifically
        if any("lora_" in name for name, _ in model.named_parameters()):
            wandb.watch(model, log="gradients", log_freq=100)
            print("W&B Watch: Monitoring LoRA gradients.")

# Usage:
# setup_gradient_monitoring(my_peft_model)

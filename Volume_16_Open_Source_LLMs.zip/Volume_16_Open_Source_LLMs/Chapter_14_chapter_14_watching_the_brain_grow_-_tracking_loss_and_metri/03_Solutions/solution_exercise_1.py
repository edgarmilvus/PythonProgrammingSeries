
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
import wandb
from transformers import TrainingArguments, Trainer
from trl import SFTTrainer
from peft import LoraConfig

# 1. Environment Initialization & API Check
if not os.environ.get("WANDB_API_KEY"):
    raise ValueError("WANDB_API_KEY not found in environment variables.")

# Initialize W&B with metadata (Requirement 5)
wandb.init(
    project="llm-fine-tuning-mastery",
    config={
        "base_model": "phi-3-mini",
        "dataset_version": "v1.0-10k-instructions",
        "hardware": "RTX 3090",
        "batch_size": 4,
        "learning_rate": 2e-4
    }
)

# 2. Logging Strategy Calculation (Requirement 3)
# Total steps = (10,000 samples / batch_size 4) = 2500 steps
# To get 100 data points: 2500 / 100 = 25 steps per log
LOG_STEPS = 25

# 3. Trainer Configuration (Requirement 2, 4, 6)
training_args = TrainingArguments(
    output_dir="./phi3-finetuned",
    report_to="wandb",              # Explicitly enable W&B
    logging_steps=LOG_STEPS,        # Granular logging
    evaluation_strategy="steps",    # Side-by-side comparison
    eval_steps=LOG_STEPS * 2,       # Evaluate every 50 steps
    save_strategy="steps",          # Save for Artifact versioning
    save_steps=LOG_STEPS * 2,
    load_best_model_at_end=True,
    per_device_train_batch_size=4,
    learning_rate=2e-4,
    # Requirement 6: Ensure checkpoints are pushed to W&B
    hub_model_id="phi3-finetuned-artifact" 
)

# Note: SFTTrainer initialization would follow here
# trainer = SFTTrainer(model=model, args=training_args, ...)

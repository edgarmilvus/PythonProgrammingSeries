
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import wandb
import os
import random
import time

# 1. SETTING UP ENVIRONMENT VARIABLES
# We use environment variables to store sensitive information like API keys.
# This prevents hardcoding secrets into our source code.
os.environ["WANDB_API_KEY"] = "your_api_key_here"
os.environ["WANDB_PROJECT"] = "llm-fine-tuning-basics"
os.environ["WANDB_LOG_MODEL"] = "checkpoint"

def simulate_training():
    """
    A function to simulate the fine-tuning process of an SLM (Small Language Model).
    """
    
    # 2. INITIALIZING THE W&B RUN
    # This creates a local process that will track our metrics and sync them to the cloud.
    # We define our hyperparameters (config) here for versioning.
    run = wandb.init(
        project=os.environ["WANDB_PROJECT"],
        config={
            "learning_rate": 2e-4,
            "architecture": "Tiny-Llama-Mock",
            "dataset": "WikiText-Simplified",
            "epochs": 10,
            "lora_r": 16,
            "lora_alpha": 32
        }
    )

    # 3. MOCK TRAINING LOOP
    # In a real scenario, this would be your PyTorch or Hugging Face Trainer loop.
    print(f"Starting training for project: {wandb.run.project}")
    
    offset = random.random() / 5
    for epoch in range(2, 11):
        # Simulate a decaying loss curve (the 'Brain Growing')
        acc = 1 - 2**-epoch - random.random() / epoch - offset
        loss = 2**-epoch + random.random() / epoch + offset
        
        # 4. LOGGING METRICS
        # This is the heart of W&B integration. We send a dictionary of metrics.
        # W&B automatically handles the timestamping and step-tracking.
        wandb.log({
            "acc": acc,
            "loss": loss,
            "epoch": epoch,
            "gpu_utilization": random.uniform(70, 95) # Simulating hardware monitoring
        })
        
        print(f"Epoch {epoch}: Loss={loss:.4f}, Accuracy={acc:.4f}")
        time.sleep(1) # Simulating computational time

    # 5. FINISHING THE RUN
    # This ensures all data is flushed and uploaded before the script exits.
    wandb.finish()

if __name__ == "__main__":
    simulate_training()

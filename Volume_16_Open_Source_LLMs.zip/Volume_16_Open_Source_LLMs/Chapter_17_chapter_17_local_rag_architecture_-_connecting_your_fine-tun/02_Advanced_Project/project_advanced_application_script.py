
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import chromadb
from pydantic import BaseModel, Field
from typing import List, Optional
import json

# DEFINITION: Structured Output - Defining the compliance report schema
class ComplianceReport(BaseModel):
    is_compliant: bool = Field(description="True if the document meets all safety standards.")
    risk_level: str = Field(description="Categorization: Low, Medium, High, or Critical.")
    missing_clauses: List[str] = Field(default_factory=list, description="List of required sections not found.")
    summary: str = Field(description="A brief justification of the audit result.")

# DEFINITION: LLM Memory - Maintaining a stateful history of audit sessions
class AuditMemory:
    def __init__(self, limit: int = 5):
        self.history = []
        self.limit = limit

    def add_entry(self, doc_id: str, result: dict):
        # Keep only the most recent N interactions to manage local context window
        self.history.append({"doc_id": doc_id, "result": result})
        if len(self.history) > self.limit:
            self.history.pop(0)

    def get_context(self) -> str:
        return json.dumps(self.history[-3:]) # Return last 3 for concise context

class LocalRAGAuditor:
    def __init__(self, collection_name: str):
        # Initialize the local vector store (ChromaDB)
        self.client = chromadb.PersistentClient(path="./compliance_db")
        self.collection = self.client.get_or_create_collection(name=collection_name)
        self.memory = AuditMemory()

    def ingest_docs(self, docs: List[str], ids: List[str]):
        # Indexing documents into the private vector store
        self.collection.add(documents=docs, ids=ids)

    def audit_document(self, query: str):
        # Retrieval: Fetching the top 10 relevant snippets
        results = self.collection.query(query_texts=[query], n_results=10)
        documents = results['documents'][0]
        
        # DEFINITION: Extended Slicing - Sampling the retrieved set
        # We take every 2nd document [::2] to get a diverse sample of the top results
        sampled_docs = documents[0:6:2] 
        
        context = "\n".join(sampled_docs)
        past_audits = self.memory.get_context()

        # Simulated Inference Loop (Integrating with a local SLM like Phi-3 or Mistral)
        # In a real scenario, this string would be sent to the local vLLM/Ollama endpoint
        prompt = f"""
        System: You are a Compliance Auditor. Use the following context and history.
        History: {past_audits}
        Context: {context}
        Task: Audit the query '{query}' against ISO-9001 standards.
        Output: Return ONLY a JSON object matching the ComplianceReport schema.
        """
        
        # Mocking the Structured Output from a fine-tuned SLM
        mock_response = {
            "is_compliant": False,
            "risk_level": "Medium",
            "missing_clauses": ["Clause 4.4: Quality Management System"],
            "summary": "The document mentions safety but lacks the required QMS framework."
        }
        
        # Validating the Structured Output using Pydantic
        report = ComplianceReport(**mock_response)
        
        # Update LLM Memory with the new audit result
        self.memory.add_entry(query, report.model_dump())
        return report

# --- Execution Logic ---
if __name__ == "__main__":
    auditor = LocalRAGAuditor("technical_specs")
    
    # Sample data ingestion
    specs = [
        "Protocol A requires dual-factor authentication for all admin overrides.",
        "Safety manual v2: All hardware must be grounded. Missing QMS details.",
        "Encryption standards: AES-256 is mandatory for data at rest."
    ]
    auditor.ingest_docs(specs, ["id1", "id2", "id3"])

    # Performing an audit
    print("--- Starting Local Compliance Audit ---")
    result = auditor.audit_document("Check hardware safety and QMS compliance")
    
    # Displaying the validated structured output
    print(f"Audit Status: {'PASSED' if result.is_compliant else 'FAILED'}")
    print(f"Risk Assessment: {result.risk_level}")
    print(f"Missing Elements: {', '.join(result.missing_clauses)}")

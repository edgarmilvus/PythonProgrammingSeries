
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

class PromptFactory:
    def __init__(self, template_type: str = "alpaca"):
        self.template_type = template_type

    def build_prompt(self, context: str, query: str, metadata: List[Dict]) -> str:
        sources = [f"[Source: {m['source_file']}, Page: {m.get('page_number', 'N/A')}]" for m in metadata]
        source_str = " ".join(list(set(sources)))

        if self.template_type == "alpaca":
            return f"""Below is an instruction that describes a task, paired with an input that provides further context. Write a response that appropriately completes the request.

### Instruction:
Answer the question strictly using the provided context. If the answer is not in the context, say 'I do not have enough information.' Cite your sources at the end.

### Input:
Context: {context}
Question: {query}

### Response:
"""
        elif self.template_type == "chatml":
            return f"""<|im_start|>system
You are a helpful assistant. Use the context provided to answer.
Context: {context}<|im_end|>
<|im_start|>user
{query}<|im_end|>
<|im_start|>assistant
"""

def query_with_threshold(query: str, collection, factory: PromptFactory, threshold: float = 0.3):
    results = collection.query(query_texts=[query], n_results=2)
    
    # Check if the closest match is relevant enough
    if not results['distances'] or results['distances'][0][0] > threshold:
        return "No relevant information found in the local database."

    context = " ".join(results['documents'][0])
    prompt = factory.build_prompt(context, query, results['metadatas'][0])
    
    # Here you would pass 'prompt' to your local SLM inference engine
    return prompt


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from rank_bm25 import BM25Okapi
import numpy as np

class HybridOrchestrator:
    def __init__(self, chunks: List[str], vector_collection):
        self.chunks = chunks
        self.vector_collection = vector_collection
        # Tokenize for BM25
        tokenized_corpus = [doc.lower().split() for doc in chunks]
        self.bm25 = BM25Okapi(tokenized_corpus)

    def rrf_score(self, semantic_results: List[str], keyword_results: List[str], k=60):
        scores = {}
        # Rank is 0-indexed, so we use rank + 1
        for rank, doc in enumerate(semantic_results):
            scores[doc] = scores.get(doc, 0) + 1 / (k + rank + 1)
        for rank, doc in enumerate(keyword_results):
            scores[doc] = scores.get(doc, 0) + 1 / (k + rank + 1)
        
        # Sort by score descending
        return sorted(scores.items(), key=lambda x: x[1], reverse=True)

    def query(self, query_text: str, mode: str = 'hybrid', limit: int = 3):
        if mode == 'vector' or mode == 'hybrid':
            v_res = self.vector_collection.query(query_texts=[query_text], n_results=limit)
            semantic_docs = v_res['documents'][0]
        
        if mode == 'keyword' or mode == 'hybrid':
            tokenized_query = query_text.lower().split()
            keyword_docs = self.bm25.get_top_n(tokenized_query, self.chunks, n=limit)

        if mode == 'hybrid':
            ranked_results = self.rrf_score(semantic_docs, keyword_docs)
            return [doc for doc, score in ranked_results[:limit]]
        
        return semantic_docs if mode == 'vector' else keyword_docs

def truncate_context(docs: List[str], max_tokens: int = 1000):
    # Simple word-based truncation for demonstration
    current_tokens = 0
    final_docs = []
    for doc in docs:
        doc_len = len(doc.split())
        if current_tokens + doc_len <= max_tokens:
            final_docs.append(doc)
            current_tokens += doc_len
    return final_docs

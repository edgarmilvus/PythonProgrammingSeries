
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
import uuid
import hashlib
import spacy
from typing import List, Dict
from sentence_transformers import SentenceTransformer, util
import chromadb
from chromadb.config import Settings

# Load NLP model for sentence segmentation
nlp = spacy.load("en_core_web_sm")
embed_model = SentenceTransformer('all-MiniLM-L6-v2')

class SemanticIngestor:
    def __init__(self, db_path: str):
        self.client = chromadb.PersistentClient(path=db_path)
        self.collection = self.client.get_or_create_collection("semantic_docs")
        self.indexed_hashes = set()

    def get_file_hash(self, text: str) -> str:
        return hashlib.md5(text.encode()).hexdigest()

    def semantic_split(self, text: str, threshold: float = 0.45) -> List[str]:
        doc = nlp(text)
        sentences = [sent.text.strip() for sent in doc.sents]
        chunks = []
        if not sentences: return []
        
        current_chunk = sentences[0]
        for i in range(1, len(sentences)):
            # Calculate similarity between current chunk and next sentence
            emb1 = embed_model.encode(current_chunk, convert_to_tensor=True)
            emb2 = embed_model.encode(sentences[i], convert_to_tensor=True)
            similarity = util.cos_sim(emb1, emb2).item()
            
            if similarity > threshold:
                current_chunk += " " + sentences[i]
            else:
                chunks.append(current_chunk)
                current_chunk = sentences[i]
        chunks.append(current_chunk)
        return chunks

    def generate_summary_lead(self, text: str) -> str:
        # Simulated SLM call: In production, call your fine-tuned model here
        words = text.split()
        return " ".join(words[:10]) + "..."

    def process_directory(self, directory: str):
        for filename in os.listdir(directory):
            if filename.endswith(('.txt', '.md')):
                path = os.path.join(directory, filename)
                with open(path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                file_hash = self.get_file_hash(content)
                if file_hash in self.indexed_hashes:
                    continue
                
                chunks = self.semantic_split(content)
                for idx, chunk in enumerate(chunks):
                    metadata = {
                        "source_file": filename,
                        "chunk_id": str(uuid.uuid4()),
                        "summary_lead": self.generate_summary_lead(chunk),
                        "privacy_level": "internal"
                    }
                    self.collection.add(
                        documents=[chunk],
                        metadatas=[metadata],
                        ids=[f"{filename}_{idx}"]
                    )
                self.indexed_hashes.add(file_hash)

# Usage
# ingestor = SemanticIngestor("./chroma_db")
# ingestor.process_directory("./my_docs")

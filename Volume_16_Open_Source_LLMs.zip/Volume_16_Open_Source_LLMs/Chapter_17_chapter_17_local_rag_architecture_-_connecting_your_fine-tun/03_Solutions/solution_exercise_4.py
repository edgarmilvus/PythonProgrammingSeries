
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import re
import spacy
import logging

# Setup private audit log
logging.basicConfig(filename='privacy_audit.log', level=logging.INFO)
nlp = spacy.load("en_core_web_sm")

class PrivacyGuard:
    def __init__(self):
        self.mapping = {}
        self.patient_count = 0

    def anonymize(self, text: str) -> str:
        # 1. Regex for SSN (XXX-XX-XXXX)
        ssn_pattern = r'\b\d{3}-\d{2}-\d{4}\b'
        if re.search(ssn_pattern, text):
            logging.info("Detected and redacted SSN entity.")
            text = re.sub(ssn_pattern, "[REDACTED_SSN]", text)

        # 2. NER for Names
        doc = nlp(text)
        new_text = text
        for ent in doc.ents:
            if ent.label_ == "PERSON":
                if ent.text not in self.mapping:
                    self.patient_count += 1
                    self.mapping[ent.text] = f"Patient_{chr(64 + self.patient_count)}"
                
                new_text = new_text.replace(ent.text, self.mapping[ent.text])
                logging.info(f"Anonymized PERSON entity to {self.mapping[ent.text]}")
        
        return new_text

# Interactive Loop
def privacy_demo():
    guard = PrivacyGuard()
    print("--- Privacy Guardrail Active ---")
    while True:
        user_input = input("\nEnter text to process (or 'exit'): ")
        if user_input.lower() == 'exit': break
        
        clean_text = guard.anonymize(user_input)
        print(f"\nOriginal: {user_input}")
        print(f"Anonymized: {clean_text}")
        # In a real app, only clean_text would go to embed_model.encode()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import chromadb
from sentence_transformers import SentenceTransformer
import numpy as np

class EmbeddingManager:
    def __init__(self, model_name: str, collection_name: str, metric: str):
        self.model = SentenceTransformer(model_name)
        self.client = chromadb.PersistentClient(path="./chroma_db_storage")
        self.collection = self.client.get_or_create_collection(
            name=collection_name,
            metadata={"hnsw:space": metric}
        )

    def add_batch(self, texts: List[str], metadatas: List[Dict]):
        # Batch processing to prevent OOM
        batch_size = 50
        for i in range(0, len(texts), batch_size):
            batch_texts = texts[i:i + batch_size]
            batch_meta = metadatas[i:i + batch_size]
            batch_ids = [str(uuid.uuid4()) for _ in range(len(batch_texts))]
            
            # Embeddings are generated automatically by Chroma if we don't pass them,
            # but we manually generate them here to demonstrate model control.
            embeddings = self.model.encode(batch_texts).tolist()
            
            self.collection.add(
                embeddings=embeddings,
                documents=batch_texts,
                metadatas=batch_meta,
                ids=batch_ids
            )

def benchmark_retrieval(query: str, manager: EmbeddingManager):
    query_emb = manager.model.encode(query).tolist()
    results = manager.collection.query(
        query_embeddings=[query_emb],
        n_results=3
    )
    print(f"Results for {manager.collection.name} ({manager.model.get_max_seq_length()} dims):")
    for doc, dist in zip(results['documents'][0], results['distances'][0]):
        print(f" - Distance: {dist:.4f} | Content: {doc[:50]}...")

# Example Initialization
# standard_mgr = EmbeddingManager("BAAI/bge-small-en-v1.5", "collection_standard", "cosine")
# optimized_mgr = EmbeddingManager("all-MiniLM-L6-v2", "collection_optimized", "l2")

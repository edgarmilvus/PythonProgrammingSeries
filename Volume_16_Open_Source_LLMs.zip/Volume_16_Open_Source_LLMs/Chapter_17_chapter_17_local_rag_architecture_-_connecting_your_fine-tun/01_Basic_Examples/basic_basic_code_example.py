
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import asyncio
import chromadb
from chromadb.utils import embedding_functions
import os

# --- STEP 1: Defining a Mock Async Resource Manager ---
# This simulates how we would manage a connection to a local 
# inference engine or a remote vector database session.
class LocalRAGSession:
    def __init__(self, db_path):
        self.db_path = db_path
        self.client = None

    async def __aenter__(self):
        # Asynchronous Context Manager: Setup phase
        # In a real scenario, this might involve checking if the 
        # vLLM or Ollama server is healthy before proceeding.
        print(f"[INFO] Initializing Local RAG Session at {self.db_path}...")
        self.client = chromadb.PersistentClient(path=self.db_path)
        return self.client

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        # Asynchronous Context Manager: Teardown phase
        # Ensures that the database connection is closed safely 
        # even if an error occurs during the 'async with' block.
        print("[INFO] Closing Local RAG Session. Cleaning up resources...")
        self.client = None

# --- STEP 2: The Core RAG Logic ---
async def run_local_rag_example():
    # Define the path for our private vector store
    db_storage_path = "./private_knowledge_base"
    
    # Ensure the directory exists (Simulating environment prep)
    if not os.path.exists(db_storage_path):
        os.makedirs(db_storage_path)

    # Using the Asynchronous Context Manager to manage our DB session
    async with LocalRAGSession(db_storage_path) as client:
        
        # Initialize a local embedding function
        # Note: In a production local RAG, you'd use a local model here
        # like 'sentence-transformers/all-MiniLM-L6-v2'
        emb_fn = embedding_functions.DefaultEmbeddingFunction()
        
        # Create or get a collection (a 'table' in vector DB terms)
        collection = client.get_or_create_collection(
            name="research_papers", 
            embedding_function=emb_fn
        )

        # --- FILE MODES ('w' and 'r') ---
        # Let's create a dummy document to represent our private data
        raw_data_file = "private_data.txt"
        with open(raw_data_file, 'w') as f: # 'w' mode: Write/Overwrite
            f.write("The secret project code is OMEGA-99. It is located in Sector 7.")
            f.write("\nUser permissions are restricted to Level 5 clearance.")
            f.write("\nThe backup power system runs on hydrogen cells.")

        # Read the data back for indexing
        with open(raw_data_file, 'r') as f: # 'r' mode: Read-only
            content = f.readlines()

        # --- EXTENDED SLICING [start:stop:step] ---
        # We use slicing to 'chunk' our data or sample it.
        # Here, we take every second line to simulate a sparse index approach.
        sampled_content = content[::2] 
        print(f"[DEBUG] Indexing {len(sampled_content)} sampled lines...")

        # Add documents to the local vector store
        # We generate IDs based on the index
        collection.add(
            documents=sampled_content,
            ids=[f"id_{i}" for i in range(len(sampled_content))]
        )

        # --- RETRIEVAL ---
        query_text = "Where is the secret project?"
        results = collection.query(
            query_texts=[query_text],
            n_results=1
        )

        retrieved_context = results['documents'][0][0]
        print(f"[RESULT] Query: {query_text}")
        print(f"[RESULT] Retrieved Context: {retrieved_context}")

        # --- FILE MODES ('a') ---
        # Log the interaction to a persistent audit trail
        with open("rag_audit.log", 'a') as log_file: # 'a' mode: Append
            log_entry = f"Query: {query_text} | Context: {retrieved_context}\n"
            log_file.write(log_entry)
            print("[INFO] Interaction logged to rag_audit.log")

# Run the asynchronous entry point
if __name__ == "__main__":
    asyncio.run(run_local_rag_example())

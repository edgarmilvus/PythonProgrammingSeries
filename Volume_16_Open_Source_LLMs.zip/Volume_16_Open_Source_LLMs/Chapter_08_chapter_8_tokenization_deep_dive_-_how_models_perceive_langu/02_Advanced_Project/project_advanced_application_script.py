
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import asyncio
import time
from typing import Dict, List, Optional
from transformers import AutoTokenizer, PreTrainedTokenizerFast
from tokenizers import Tokenizer, models, trainers, pre_tokenizers

class TokenizationAnalyzer:
    """
    Analyzes and compares tokenization efficiency across different models.
    Follows POLA (Principle of Least Astonishment) by providing a clean, 
    predictable interface for complex tokenization metrics.
    """

    def __init__(self, model_names: List[str]):
        self.tokenizers: Dict[str, PreTrainedTokenizerFast] = {}
        # EAFP: Attempt to load tokenizers; handle failures if the model name is invalid
        for name in model_names:
            try:
                self.tokenizers[name] = AutoTokenizer.from_pretrained(name)
            except Exception as e:
                print(f"Error loading tokenizer {name}: {e}")

    async def simulate_streaming_inference(self, text: str, model_key: str):
        """
        Simulates the non-blocking process of receiving tokens sequentially.
        Demonstrates how tokenization choices affect perceived latency.
        """
        tokenizer = self.tokenizers.get(model_key)
        if not tokenizer:
            return

        # Encode the text into IDs
        input_ids = tokenizer.encode(text)
        print(f"\n[Streaming {model_key}] Total Tokens: {len(input_ids)}")

        # Simulate the 'Async Generation' process token by token
        for token_id in input_ids:
            # Decode a single token to show progress
            token_str = tokenizer.decode([token_id])
            print(f"{token_str}", end="", flush=True)
            # Simulate network/compute latency per token
            await asyncio.sleep(0.02) 
        print("\n--- Stream Complete ---")

    def calculate_token_density(self, text: str) -> Dict[str, float]:
        """
        Calculates characters per token (CPT). 
        Higher CPT indicates better context window efficiency for specific data.
        """
        results = {}
        for name, tokenizer in self.tokenizers.items():
            tokens = tokenizer.encode(text)
            char_count = len(text)
            token_count = len(tokens)
            # Avoid division by zero if text is empty
            results[name] = char_count / token_count if token_count > 0 else 0
        return results

    def analyze_code_fragment(self, code: str):
        """
        Specifically analyzes how tokenizers handle indentation and syntax.
        Essential for local SLMs focused on programming.
        """
        print(f"{'Model':<25} | {'Tokens':<10} | {'Chars/Token':<12}")
        print("-" * 55)
        
        densities = self.calculate_token_density(code)
        for model, cpt in densities.items():
            token_count = len(self.tokenizers[model].encode(code))
            print(f"{model:<25} | {token_count:<10} | {cpt:<12.2f}")

async def main():
    # Define a complex Python snippet that tests indentation and common keywords
    python_code = """
def calculate_fibonacci(n: int) -> list:
    if n <= 0:
        return []
    sequence = [0, 1]
    while len(sequence) < n:
        sequence.append(sequence[-1] + sequence[-2])
    return sequence
    """

    # Compare a general-purpose tokenizer with a code-specific one
    models_to_test = [
        "gpt2",                 # Older, general BPE
        "bigcode/starcoder",    # Optimized for code
        "hf-internal-testing/llama-tokenizer" # Llama-based BPE
    ]

    analyzer = TokenizationAnalyzer(models_to_test)
    
    print("### Tokenization Efficiency Analysis (Python Code) ###")
    analyzer.analyze_code_fragment(python_code)

    # Demonstrate Async Streaming for the first model
    print("\n### Simulating Async Token Streaming (StarCoder) ###")
    await analyzer.simulate_streaming_inference(python_code, "bigcode/starcoder")

if __name__ == "__main__":
    # Standard entry point for async execution
    asyncio.run(main())

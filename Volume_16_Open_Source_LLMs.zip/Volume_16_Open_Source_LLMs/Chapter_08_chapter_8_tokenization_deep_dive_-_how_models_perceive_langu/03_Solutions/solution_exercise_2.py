
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import sys
from transformers import AutoTokenizer

# 1. Vocabulary Expansion
tokenizer = AutoTokenizer.from_pretrained("gpt2")
special_tokens_dict = {'additional_special_tokens': ['[LOG]', '[TRACE]', '[LATENCY]', '[MEM_USAGE]', '[CRITICAL]']}
num_added_toks = tokenizer.add_special_tokens(special_tokens_dict)

# 2. Embedding Alignment Logic (Conceptual)
# model.resize_token_embeddings(len(tokenizer)) 
# This would be called on the model object to align the weight matrix.

# 3. Custom Normalization / Pre-processing
def preprocess_log(text):
    # 4. The "System Exit" Scenario: Prevent "poisoned" input
    forbidden_sequences = ["0xDEADBEEF", "FORBIDDEN_ACCESS"]
    for seq in forbidden_sequences:
        if seq in text:
            print(f"CRITICAL: Forbidden sequence '{seq}' detected. Terminating.")
            sys.exit(1)
    
    # Simple normalization: Ensure hex addresses are identified (conceptually)
    # In a real pipeline, we might use a Regex pre-tokenizer
    return text

# 5. Validation
sample_log = "[LOG] Memory at 0x7fff5fbff610 is [CRITICAL]"
clean_log = preprocess_log(sample_log)
encoded = tokenizer.encode(clean_log)
decoded_tokens = [tokenizer.decode([t]) for t in encoded]

print(f"Vocabulary Size: {len(tokenizer)}")
print(f"Encoded IDs: {encoded}")
print(f"Decoded: {decoded_tokens}")

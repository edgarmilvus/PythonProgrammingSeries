
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from transformers import AutoTokenizer

def optimize_context(text, limit, tokenizer_name="gpt2", strategy="middle-out"):
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)
    tokens = tokenizer.encode(text)
    total_tokens = len(tokens)
    
    # 3. Metadata Extraction
    char_count = len(text)
    token_density = char_count / total_tokens if total_tokens > 0 else 0
    
    # 4. Hardware Constraint Simulation
    MB_PER_TOKEN = 0.02  # Hypothetical VRAM cost per token for KV cache
    estimated_vram = total_tokens * MB_PER_TOKEN
    VRAM_THRESHOLD = 30.0 # MB
    
    if estimated_vram > VRAM_THRESHOLD:
        print(f"ALERT: Estimated VRAM ({estimated_vram:.2f}MB) exceeds threshold!")

    if total_tokens <= limit:
        return tokens, token_density

    # 2. The "Middle-Out" Truncator
    if strategy == "middle-out":
        keep_side = limit // 2
        truncated_tokens = tokens[:keep_side] + tokens[-keep_side:]
        return truncated_tokens, token_density
    
    return tokens[:limit], token_density # Default fallback

# Example Usage
long_prompt = "SYSTEM: You are an assistant. " + "Context data... " * 500 + "QUESTION: How do I fix the bug?"
optimized_ids, density = optimize_context(long_prompt, limit=100)

print(f"Original Token Count: {len(long_prompt.split())} (approx)")
print(f"Optimized Token Count: {len(optimized_ids)}")
print(f"Token Density: {density:.2f} chars/token")

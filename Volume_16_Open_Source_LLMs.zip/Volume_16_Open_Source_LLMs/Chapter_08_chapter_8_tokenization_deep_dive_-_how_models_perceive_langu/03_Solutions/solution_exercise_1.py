
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from transformers import AutoTokenizer
import re

# 1. Environment Setup
# Note: Llama-3 requires authentication; using GPT-2 as a BPE proxy if local access differs, 
# but following prompt requirements for Llama-3 and BERT.
llama_tok = AutoTokenizer.from_pretrained("meta-llama/Meta-Llama-3-8B")
bert_tok = AutoTokenizer.from_pretrained("bert-base-uncased")

# 2. Dataset Preparation (Abbreviated samples)
prose_text = "The architecture of Byte-Pair Encoding allows for a dynamic vocabulary..." * 50 # Simulated 500 words
python_code = """
@decorator
async def process_data(items):
    result = []
    for i in items:
        # Complex nested logic
        if i // 2 == 0:
            result.append(i ** 2)
    yield result
""" * 50 # Simulated 500 lines

def analyze(tokenizer, text, is_code=False):
    tokens = tokenizer.encode(text, add_special_tokens=False)
    token_count = len(tokens)
    
    if is_code:
        lines = text.strip().split('\n')
        metric = token_count / len(lines)
        label = "Tokens/Line"
    else:
        words = text.strip().split()
        metric = token_count / len(words)
        label = "Tokens/Word"
        
    # Check for [UNK] tokens (ID 100 in BERT)
    unk_count = tokens.count(tokenizer.unk_token_id)
    unk_pct = (unk_count / token_count) * 100
    
    return token_count, metric, label, unk_pct

# 3. Metrics Calculation
for name, tok in [("Llama-3 (BPE)", llama_tok), ("BERT (WordPiece)", bert_tok)]:
    p_count, p_metric, p_label, p_unk = analyze(tok, prose_text)
    c_count, c_metric, c_label, c_unk = analyze(tok, python_code, is_code=True)
    
    print(f"--- {name} ---")
    print(f"Prose: {p_count} tokens | {p_metric:.2f} {p_label} | UNK: {p_unk:.2f}%")
    print(f"Code:  {c_count} tokens | {c_metric:.2f} {c_label} | UNK: {c_unk:.2f}%")

# 4. Visual Analysis
sample_code = "async yield"
print(f"\nLlama-3 Chunking: {llama_tok.tokenize(sample_code)}")
print(f"BERT Chunking:    {bert_tok.tokenize(sample_code)}")

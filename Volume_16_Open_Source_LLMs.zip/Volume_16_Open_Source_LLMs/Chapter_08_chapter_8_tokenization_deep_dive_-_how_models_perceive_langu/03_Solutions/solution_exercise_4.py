
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import sys
import os
from flask import Flask, request, jsonify
from transformers import AutoTokenizer

app = Flask(__name__)

# 3. Error Handling with sys.exit()
TOKENIZER_PATH = "gpt2" # In production, this would be a local path
try:
    # 5. Optimization: Load tokenizer once globally
    tokenizer = AutoTokenizer.from_pretrained(TOKENIZER_PATH)
except Exception as e:
    print(f"Critical Configuration Error: Tokenizer not found at {TOKENIZER_PATH}. {e}")
    sys.exit(1)

@app.route('/generate', methods=['POST'])
def generate():
    data = request.json
    prompt = data.get("prompt", "")
    max_tokens = data.get("max_tokens", 50)
    
    # Tokenize input
    input_ids = tokenizer.encode(prompt)
    
    # Simulate Model Generation (Mocking the output for this exercise)
    # In reality, you'd call model.generate()
    output_ids = [50256, 123, 456, 789] 
    generated_text = tokenizer.decode(output_ids)
    
    # 4. Token-to-String Mapping
    output_subwords = [tokenizer.convert_ids_to_tokens(tid) for tid in output_ids]
    
    # 2. The Response Object
    response_payload = {
        "generated_text": generated_text,
        "input_tokens": input_ids,
        "output_tokens": output_ids,
        "output_subwords": output_subwords,
        "token_count": len(input_ids) + len(output_ids),
        "stop_reason": "reached_max_tokens"
    }
    
    return jsonify(response_payload)

if __name__ == '__main__':
    app.run(port=5000)

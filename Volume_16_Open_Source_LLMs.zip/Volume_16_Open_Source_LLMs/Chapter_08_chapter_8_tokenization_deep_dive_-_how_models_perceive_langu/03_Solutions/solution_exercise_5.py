
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from transformers import AutoTokenizer
import re

tokenizer = AutoTokenizer.from_pretrained("codellama/CodeLlama-7b-hf")

# 1. Visual Inspection & 2. Token Comparison
standard_op = "+="
buggy_op = "+ ="

std_ids = tokenizer.encode(standard_op, add_special_tokens=False)
bug_ids = tokenizer.encode(buggy_op, add_special_tokens=False)

print(f"Standard '+=' IDs: {std_ids} -> {[tokenizer.decode([t]) for t in std_ids]}")
print(f"Buggy    '+ =' IDs: {bug_ids} -> {[tokenizer.decode([t]) for t in bug_ids]}")

# 4. Whitespace Sensitivity Test
variations = ["+=", "+ =", "+  =", "\t+=", " +="]
for v in variations:
    ids = tokenizer.encode(v, add_special_tokens=False)
    print(f"Input: '{v.replace(chr(9), '[TAB] ')}' | Tokens: {ids}")

# 5. Solution Proposal: Pre-tokenization Regex
def normalize_operators(text):
    # Regex looks for a '+' followed by one or more spaces and then an '='
    return re.sub(r'\+\s+=', '+=', text)

test_line = "result + = rate"
normalized = normalize_operators(test_line)
print(f"\nOriginal: {test_line}")
print(f"Normalized: {normalized}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Import the AutoTokenizer class from the Hugging Face transformers library.
# This class is a "generic" loader that can automatically detect the correct
# tokenizer type based on the model name provided.
from transformers import AutoTokenizer

def demonstrate_tokenization():
    # 1. SELECTING THE MODEL
    # We use 'gpt2' as our example because it utilizes Byte-Pair Encoding (BPE),
    # the foundational algorithm for most modern LLMs like Llama and Mistral.
    model_name = "gpt2"
    
    # 2. INITIALIZING THE TOKENIZER
    # This downloads the vocabulary and merge rules from the cloud (if not cached)
    # and loads them into local memory.
    tokenizer = AutoTokenizer.from_pretrained(model_name)

    # 3. DEFINING THE INPUTS
    # We provide a standard sentence and a snippet of Python code to see
    # how the tokenizer handles different syntax styles.
    text_input = "Hello, world!"
    code_input = "def hello(): print('Hi')"

    # 4. ENCODING THE TEXT
    # The 'encode' method converts the string into a list of integers (Token IDs).
    text_tokens = tokenizer.encode(text_input)
    code_tokens = tokenizer.encode(code_input)

    # 5. PRINTING THE RESULTS
    # We display the raw integers that the model actually "sees."
    print(f"Text Input: {text_input}")
    print(f"Text Token IDs: {text_tokens}")
    
    print(f"\nCode Input: {code_input}")
    print(f"Code Token IDs: {code_tokens}")

    # 6. DECODING FOR VERIFICATION
    # To prove the process is reversible, we convert the IDs back into strings.
    # Note how the tokenizer handles spaces and special characters.
    print("\nIndividual Token Breakdown:")
    for token_id in code_tokens:
        # The 'decode' method turns a single ID (or list) back into a string.
        decoded_fragment = tokenizer.decode([token_id])
        print(f"ID: {token_id} -> Token: '{decoded_fragment}'")

# Execute the function
if __name__ == "__main__":
    demonstrate_tokenization()

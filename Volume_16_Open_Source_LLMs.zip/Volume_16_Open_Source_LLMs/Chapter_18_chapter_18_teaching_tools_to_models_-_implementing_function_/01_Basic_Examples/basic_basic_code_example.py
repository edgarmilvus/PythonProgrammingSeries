
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import json
import os

# --- STEP 1: Define the actual Python Tool ---
def get_file_info(directory, filename, mode='r'):
    """
    Simulates a tool that retrieves information about a local file.
    Uses os.path.join for platform-independent path construction.
    """
    # Construct the full path safely
    full_path = os.path.join(directory, filename)
    
    try:
        # Check if file exists
        if not os.path.exists(full_path):
            return {"error": f"File {filename} not found in {directory}."}
        
        # Get file size (simulating a 'read' operation context)
        size = os.path.getsize(full_path)
        
        # Return structured data for the LLM to consume
        return {
            "path": full_path,
            "size_bytes": size,
            "mode_requested": mode,
            "status": "success"
        }
    except Exception as e:
        return {"error": str(e)}

# --- STEP 2: Define the Tool Schema (What the SLM sees) ---
# This is the 'Instruction' we give to the model during fine-tuning or prompting.
tools_schema = [
    {
        "name": "get_file_info",
        "description": "Get the size and path details of a local file.",
        "parameters": {
            "type": "object",
            "properties": {
                "directory": {"type": "string", "description": "The folder path."},
                "filename": {"type": "string", "description": "The name of the file."},
                "mode": {"type": "string", "enum": ["r", "w", "a"], "description": "File access mode."}
            },
            "required": ["directory", "filename"]
        }
    }
]

# --- STEP 3: Simulate the SLM's Decision ---
# In a real scenario, the SLM would generate this JSON string after seeing the user prompt.
# User Prompt: "Check the size of 'config.json' in the '/data' folder."
mock_slm_output = {
    "tool": "get_file_info",
    "parameters": {
        "directory": "/data",
        "filename": "config.json",
        "mode": "r"
    }
}

# --- STEP 4: The Execution Logic (The Agent Loop) ---
def run_agent_step(slm_response):
    """
    The 'Agent' logic that parses the SLM output and executes the tool.
    """
    tool_name = slm_response.get("tool")
    params = slm_response.get("parameters")
    
    print(f"[*] Agent is executing tool: {tool_name}")
    
    if tool_name == "get_file_info":
        # Unpack parameters and call the function
        result = get_file_info(**params)
        return result
    else:
        return {"error": "Unknown tool"}

# --- STEP 5: Run the Example ---
# For this demo, we'll create a dummy file first to ensure it works.
with open("config.json", "w") as f:
    f.write("sample data")

# Execute the loop using the mock output
# We override the directory to current directory '.' for this local test
mock_slm_output["parameters"]["directory"] = "." 
final_observation = run_agent_step(mock_slm_output)

print(f"[*] Tool Output (Observation): {json.dumps(final_observation, indent=2)}")

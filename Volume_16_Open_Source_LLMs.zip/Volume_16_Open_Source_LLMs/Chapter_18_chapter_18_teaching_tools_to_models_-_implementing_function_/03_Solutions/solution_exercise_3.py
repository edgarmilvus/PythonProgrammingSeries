
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from unittest.mock import MagicMock
import json

# 1. The Mock Setup
class RemoteClient:
    def upload_file(self, path, bucket):
        # Real implementation would be here
        pass

# Monkey Patching the method
client = RemoteClient()
def side_effect(path, bucket):
    if bucket == "backups":
        return {"status": "success", "message": f"Uploaded {path} to backups"}
    else:
        raise ValueError("Bucket not found")

client.upload_file = MagicMock(side_effect=side_effect)

# 2. SLM Integration & Error Recovery
def process_slm_command(json_call):
    try:
        call = json.loads(json_call)
        result = client.upload_file(call['arguments']['path'], call['arguments']['bucket'])
        return f"Observation: {result}"
    except ValueError as e:
        return f"Observation: Error - {str(e)}"
    except Exception as e:
        return f"Observation: Unexpected Error - {str(e)}"

# 3. Test Case: Invalid Bucket
bad_call = '{"name": "upload_file", "arguments": {"path": "report.pdf", "bucket": "invalid_storage"}}'
observation = process_slm_command(bad_call)

print(f"SLM Call: {bad_call}")
print(observation)
print("Assistant: I'm sorry, I couldn't upload 'report.pdf' because the bucket 'invalid_storage' does not exist. Could you please provide the correct bucket name?")

# Verification: Ensure the mock was called
assert client.upload_file.called
print("Verification: Real API was never hit; mock was successfully triggered.")

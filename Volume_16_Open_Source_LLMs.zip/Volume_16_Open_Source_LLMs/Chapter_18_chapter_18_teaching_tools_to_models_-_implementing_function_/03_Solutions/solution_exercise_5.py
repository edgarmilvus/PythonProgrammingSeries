
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import json

def get_weather(city):
    return {"city": city, "temp_f": 72 if city == "London" else 80}

def convert_temperature(value, unit):
    if unit == "C":
        return (value - 32) * 5/9
    return value

def unified_executor(slm_output):
    try:
        calls = json.loads(slm_output)
        # Ensure we are working with a list for iteration
        if isinstance(calls, dict):
            calls = [calls]
            
        results = []
        for call in calls:
            try:
                if call['name'] == 'get_weather':
                    res = get_weather(call['arguments']['city'])
                    results.append({"call": call['name'], "result": res})
                elif call['name'] == 'convert_temperature':
                    res = convert_temperature(call['arguments']['value'], call['arguments']['unit'])
                    results.append({"call": call['name'], "result": res})
            except Exception as e:
                results.append({"call": call['name'], "error": str(e)})
        
        return results
    except Exception as e:
        return f"Parsing Error: {str(e)}"

# Scenario: Parallel Calling
parallel_json = '[{"name": "get_weather", "arguments": {"city": "London"}}, {"name": "get_weather", "arguments": {"city": "Paris"}}]'
print(f"Parallel Results: {unified_executor(parallel_json)}")

# Scenario: Dependency Management Prompting
system_guideline = """
GUIDELINE: If a tool requires data from a previous tool (e.g., converting a temperature you haven't fetched yet), 
you MUST call the tools sequentially in separate turns. Do not call them in parallel.
"""
print(f"\nSystem Instruction added: {system_guideline}")

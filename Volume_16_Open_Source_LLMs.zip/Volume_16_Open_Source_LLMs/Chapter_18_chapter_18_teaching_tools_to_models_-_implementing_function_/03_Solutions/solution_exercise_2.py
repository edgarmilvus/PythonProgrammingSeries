
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os

def get_current_directory():
    """Returns the current directory if it is safe."""
    current_path = os.getcwd()
    
    # Security Constraint: Path Sandbox
    forbidden_paths = ["/etc", "/var", "C:\\Windows", "/root"]
    if any(current_path.startswith(p) for p in forbidden_paths):
        return "Error: Access to this system directory is restricted for security."
    
    return current_path

def list_files(directory):
    """Lists files in a given directory."""
    try:
        return os.listdir(directory)
    except Exception as e:
        return f"Error: {str(e)}"

# Simulated Reasoning Chain / Execution Loop
def run_system_observer_task(user_query):
    # Step 1: Model generates first call (Mocking SLM output)
    print(f"User: {user_query}")
    print("SLM: <tool_call>{'name': 'get_current_directory', 'arguments': {}}</tool_call>")
    
    # Step 2: Execute and provide Observation
    path_obs = get_current_directory()
    print(f"Observation: {path_obs}")
    
    # Step 3: Model generates second call based on observation
    if "Error" not in path_obs:
        print(f"SLM: <tool_call>{{'name': 'list_files', 'arguments': {{'directory': '{path_obs}'}}}}</tool_call>")
        files_obs = list_files(path_obs)
        print(f"Observation: {files_obs}")
        print(f"Assistant: You are running in {path_obs}. The files here are: {', '.join(files_obs)}")

run_system_observer_task("Where are you running from, and are there any Python files in that folder?")

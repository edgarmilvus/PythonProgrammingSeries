
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import json

# 1. Define the Schema
search_tool_schema = {
    "name": "search_local_documents",
    "description": "Search for files in the local management system based on criteria.",
    "parameters": {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "The main search term."},
            "file_type": {"type": "string", "enum": ["pdf", "docx", "txt"]},
            "last_modified_after": {"type": "string", "description": "ISO 8601 date string (YYYY-MM-DD)."},
            "case_sensitive": {"type": "boolean", "default": False}
        },
        "required": ["query"]
    }
}

# 2. Dataset Generation (JSONL format for SFT)
dataset = [
    {
        "system": f"You are a helpful assistant with access to tools. Available tools: {json.dumps(search_tool_schema)}",
        "user": "Find my taxes from 2023.",
        "assistant": "<tool_call>{\"name\": \"search_local_documents\", \"arguments\": {\"query\": \"taxes 2023\"}}</tool_call>"
    },
    {
        "system": "You are a helpful assistant with access to tools...",
        "user": "Look for PDFs containing 'invoice' modified after January 1st, 2024.",
        "assistant": "<tool_call>{\"name\": \"search_local_documents\", \"arguments\": {\"query\": \"invoice\", \"file_type\": \"pdf\", \"last_modified_after\": \"2024-01-01\"}}</tool_call>"
    },
    {
        "system": "You are a helpful assistant with access to tools...",
        "user": "Search for 'Project Alpha' in text files, make sure it matches the exact case.",
        "assistant": "<tool_call>{\"name\": \"search_local_documents\", \"arguments\": {\"query\": \"Project Alpha\", \"file_type\": \"txt\", \"case_sensitive\": true}}</tool_call>"
    },
    {
        "system": "You are a helpful assistant with access to tools...",
        "user": "I need to find docx files about 'Marketing'.",
        "assistant": "<tool_call>{\"name\": \"search_local_documents\", \"arguments\": {\"query\": \"Marketing\", \"file_type\": \"docx\"}}</tool_call>"
    },
    {
        "system": "You are a helpful assistant with access to tools...",
        "user": "Search for 'budget' files larger than 50MB.",
        "assistant": "I can search for 'budget' files for you, but I cannot filter by file size. <tool_call>{\"name\": \"search_local_documents\", \"arguments\": {\"query\": \"budget\"}}</tool_call>"
    }
]

# Save to JSONL
with open("search_dataset.jsonl", "w") as f:
    for entry in dataset:
        f.write(json.dumps(entry) + "\n")

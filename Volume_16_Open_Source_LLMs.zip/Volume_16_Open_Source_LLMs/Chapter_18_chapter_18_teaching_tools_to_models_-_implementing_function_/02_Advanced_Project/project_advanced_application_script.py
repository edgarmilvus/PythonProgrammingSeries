
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import json
import os
import re
from unittest.mock import patch

# --- TOOL DEFINITIONS ---

def read_log_file(directory, filename):
    """Reads the content of a specific log file safely."""
    # Using os.path.join to ensure platform-independent path construction
    full_path = os.path.join(directory, filename)
    try:
        # Utilizing 'r' mode for read-only access
        with open(full_path, 'r') as f:
            return f.read()
    except FileNotFoundError:
        return f"Error: {filename} not found in {directory}."

def write_audit_report(directory, filename, content, mode='a'):
    """Writes or appends findings to the audit report."""
    # os.path.join prevents path traversal vulnerabilities
    full_path = os.path.join(directory, filename)
    # Supporting both 'w' (overwrite) and 'a' (append) based on model instruction
    with open(full_path, mode) as f:
        f.write(content + "\n")
    return f"Successfully wrote to {filename} using mode '{mode}'."

def list_logs(directory):
    """Lists all .log files in the target directory."""
    try:
        return [f for f in os.listdir(directory) if f.endswith('.log')]
    except OSError as e:
        return f"Directory error: {str(e)}"

# --- MONKEY PATCHING FOR SAFETY ---
# We monkey patch the 'open' function during the testing phase to prevent 
# the SLM from accidentally corrupting real system files.
def setup_sandbox():
    """Injects mocks to intercept file operations for safe execution."""
    mock_file_system = {
        os.path.join("logs", "sys.log"): "ERROR: Disk full at 10:00\nINFO: Cleanup started",
        os.path.join("logs", "auth.log"): "WARN: Failed login attempt from 192.168.1.1"
    }
    return mock_file_system

# --- THE SLM ORCHESTRATOR ---

class SLMToolAgent:
    def __init__(self, target_dir):
        self.target_dir = target_dir
        # Registry of available tools mapped to their Python functions
        self.tools = {
            "read_log_file": read_log_file,
            "write_audit_report": write_audit_report,
            "list_logs": list_logs
        }

    def parse_and_execute(self, model_output):
        """Extracts JSON tool calls from the SLM's raw text response."""
        # SLMs are often fine-tuned to wrap tool calls in specific tags like <tool_call>
        pattern = r"<tool_call>(.*?)</tool_call>"
        match = re.search(pattern, model_output, re.DOTALL)
        
        if not match:
            return "No tool call detected. Model responded: " + model_output

        try:
            # Parsing the structured JSON output from the model
            call_data = json.loads(match.group(1))
            tool_name = call_data.get("name")
            arguments = call_data.get("arguments", {})
            
            # Injecting the target directory into arguments for safety
            arguments['directory'] = self.target_dir

            if tool_name in self.tools:
                # Executing the mapped function with model-provided arguments
                result = self.tools[tool_name](**arguments)
                return f"Tool Execution Result: {result}"
            else:
                return f"Error: Tool '{tool_name}' is not registered."
        except json.JSONDecodeError:
            return "Error: Model generated invalid JSON."

# --- SIMULATED INFERENCE LOOP ---

def run_demonstration():
    agent = SLMToolAgent(target_dir="logs")
    
    # Example 1: Model decides to list files
    # This string simulates what a fine-tuned SLM would output
    model_response_1 = '<tool_call>{"name": "list_logs", "arguments": {}}</tool_call>'
    print(f"Step 1: {agent.parse_and_execute(model_response_1)}")

    # Example 2: Model decides to read a log and then append a report
    # Note the use of 'a' for append mode in the arguments
    model_response_2 = (
        '<tool_call>{"name": "write_audit_report", "arguments": '
        '{"filename": "summary.txt", "content": "Found Disk Full error in sys.log", "mode": "a"}}'
        '</tool_call>'
    )
    
    # Applying Monkey Patching to 'open' to simulate the environment without actual I/O
    with patch("builtins.open") as mocked_open:
        print(f"Step 2: {agent.parse_and_execute(model_response_2)}")
        # Verify the mock was called with the correct parameters
        mocked_open.assert_called_with(os.path.join("logs", "summary.txt"), 'a')

if __name__ == "__main__":
    # Ensure the dummy directory exists for the script logic
    if not os.path.exists("logs"):
        os.makedirs("logs")
    run_demonstration()

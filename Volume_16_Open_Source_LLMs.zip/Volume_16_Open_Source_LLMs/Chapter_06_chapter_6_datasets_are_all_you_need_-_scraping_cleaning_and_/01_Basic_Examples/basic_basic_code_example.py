
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import asyncio
import aiohttp
from sqlalchemy import create_engine, Column, Integer, Text, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# --- ORM MODEL DEFINITION ---
# We define a 'Model' which is a Python class representing our database table.
# This ensures our scraped data is structured and validated.
Base = declarative_base()

class ScrapedArticle(Base):
    __tablename__ = 'scraped_articles'
    
    id = Column(Integer, primary_key=True)
    url = Column(String)
    content = Column(Text)
    status = Column(String)

# --- DATABASE SETUP ---
# Creating a local SQLite database for our dataset storage.
engine = create_engine('sqlite:///training_data.db')
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)

async def fetch_and_store(url):
    """
    An asynchronous function that demonstrates the use of 
    Asynchronous Context Managers and ORM Models.
    """
    
    # 1. ASYNCHRONOUS CONTEXT MANAGER: aiohttp.ClientSession()
    # This ensures the network connection is opened and closed safely.
    async with aiohttp.ClientSession() as session:
        
        # 2. ASYNCHRONOUS CONTEXT MANAGER: session.get()
        # We fetch the URL content without blocking the rest of the program.
        async with session.get(url) as response:
            html_content = await response.text()
            
            # 3. CONTEXT MANAGER (File I/O): open()
            # We use the 'with' statement to log our progress to a text file.
            # This guarantees the file is closed even if an error occurs.
            with open("scraping_log.txt", "a") as log_file:
                log_file.write(f"Successfully fetched: {url}\n")
            
            # 4. ORM MODEL INSTANTIATION
            # We transform the raw HTML into a structured Python object.
            new_article = ScrapedArticle(
                url=url,
                content=html_content[:500],  # Saving a snippet for this example
                status="Raw"
            )
            
            # Saving the structured data to our database.
            db_session = Session()
            db_session.add(new_article)
            db_session.commit()
            db_session.close()
            
            print(f"Stored data from {url} into the database.")

async def main():
    # A list of mock URLs to simulate a scraping task for our SLM dataset.
    urls_to_scrape = [
        "https://example.com/medical-article-1",
        "https://example.com/medical-article-2"
    ]
    
    # Running multiple fetch tasks concurrently.
    tasks = [fetch_and_store(url) for url in urls_to_scrape]
    await asyncio.gather(*tasks)

if __name__ == "__main__":
    # Entry point for the asynchronous event loop.
    asyncio.run(main())

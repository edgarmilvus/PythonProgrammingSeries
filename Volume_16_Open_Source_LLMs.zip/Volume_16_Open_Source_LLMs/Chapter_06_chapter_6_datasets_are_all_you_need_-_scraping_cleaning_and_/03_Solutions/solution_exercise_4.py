
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import asyncio
import httpx
import os

class CheckpointHandler:
    def __init__(self, checkpoint_file):
        self.file = checkpoint_file
        self.last_index = 0

    def __enter__(self):
        if os.path.exists(self.file):
            with open(self.file, 'r') as f:
                self.last_index = int(f.read().strip())
        return self

    def save(self, index):
        self.last_index = index
        with open(self.file, 'w') as f:
            f.write(str(index))

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is None:
            # Clean up on success
            if os.path.exists(self.file):
                os.remove(self.file)
        return False # Propagate exceptions

async def generate_synthetic_data(data_list):
    async with httpx.AsyncClient() as client:
        with CheckpointHandler("progress.log") as cp:
            for i in range(cp.last_index, len(data_list)):
                try:
                    # Simulated LLM API Call
                    resp = await client.post("http://localhost:11434/api/generate", 
                                             json={"prompt": data_list[i]},
                                             timeout=30.0)
                    # Dynamic Rate Limiting
                    if resp.elapsed.total_seconds() > 2.0:
                        await asyncio.sleep(1.0)
                        
                    # Save progress
                    cp.save(i + 1)
                    print(f"Processed record {i+1}")
                except Exception as e:
                    print(f"Error at index {i}: {e}")
                    break

# asyncio.run(generate_synthetic_data(["prompt 1", "prompt 2", "prompt 3"]))

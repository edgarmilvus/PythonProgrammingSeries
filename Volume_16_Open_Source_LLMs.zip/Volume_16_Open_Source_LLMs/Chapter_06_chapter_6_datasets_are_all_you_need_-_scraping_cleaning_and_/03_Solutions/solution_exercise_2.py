
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import re
import unicodedata
import json

def clean_text(text):
    # Boilerplate removal
    text = re.sub(r"Click here to read more|Copyright \d{4}|<script.*?>.*?</script>", "", text, flags=re.DOTALL | re.IGNORECASE)
    # Unicode Normalization (NFKC)
    text = unicodedata.normalize('NFKC', text)
    # Strip whitespace
    return text.strip()

def is_noisy(text, threshold=0.2):
    if not text: return True
    non_alnum = len([c for c in text if not c.isalnum() and not c.isspace()])
    return (non_alnum / len(text)) > threshold

def process_pipeline(input_file, output_file, quarantine_file):
    with open(input_file, 'r') as src, \
         open(output_file, 'w') as dst, \
         open(quarantine_file, 'w') as qrn:
        
        for line in src:
            raw_data = json.loads(line)
            raw_text = raw_data.get("text", "")
            
            cleaned = clean_text(raw_text)
            ratio = len(cleaned) / len(raw_text) if len(raw_text) > 0 else 0
            
            output_obj = {"text": cleaned, "cleaning_ratio": ratio}
            
            if is_noisy(cleaned):
                qrn.write(json.dumps(output_obj) + "\n")
            else:
                dst.write(json.dumps(output_obj) + "\n")

# Example usage (assuming 'dirty_data.jsonl' exists)
# process_pipeline('dirty_data.jsonl', 'cleaned_data.jsonl', 'quarantine.jsonl')

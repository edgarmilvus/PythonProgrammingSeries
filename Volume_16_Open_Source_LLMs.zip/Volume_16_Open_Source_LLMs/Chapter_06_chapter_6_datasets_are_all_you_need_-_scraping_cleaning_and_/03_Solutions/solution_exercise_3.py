
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import json

APP_CONTEXT = {
    "system_prompt": "You are a helpful technical assistant.",
    "max_tokens": 512
}

def estimate_tokens(text):
    return len(text) // 4  # Heuristic: 1 token approx 4 chars

def structure_dataset(raw_pairs, output_path):
    buffer = []
    
    with open(output_path, 'w', encoding='utf-8') as f:
        for pair in raw_pairs:
            instruction = pair.get("question", "")
            context = pair.get("context", "")
            response = pair.get("answer", "")
            
            # Combine for token estimation
            full_text = instruction + context + response
            if estimate_tokens(full_text) > APP_CONTEXT["max_tokens"]:
                continue
                
            alpaca_record = {
                "instruction": f"{APP_CONTEXT['system_prompt']} {instruction}",
                "input": context,
                "output": response
            }
            
            buffer.append(json.dumps(alpaca_record))
            
            # Batch Writing Logic
            if len(buffer) >= 100:
                f.write("\n".join(buffer) + "\n")
                buffer.clear()
        
        # Flush remaining records
        if buffer:
            f.write("\n".join(buffer) + "\n")

# Example usage
# data = [{"question": "What is Python?", "answer": "A language.", "context": ""}]
# structure_dataset(data, 'alpaca_tuning.jsonl')

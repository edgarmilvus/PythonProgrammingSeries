
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import asyncio
import aiohttp
import logging
import os
from datetime import datetime

# Simulated Application Context
APP_CONFIG = {
    "base_url": "https://docs.example.tech",
    "timeout": 10,
    "max_concurrent": 5
}

class AsyncDataSink:
    """Asynchronous context manager to manage directory and file lifecycle."""
    def __init__(self, output_dir):
        self.output_dir = output_dir
        self.session = None

    async def __aenter__(self):
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
        # Initialize the shared session here
        self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=APP_CONFIG["timeout"]))
        return self

    async def save_content(self, url, content):
        filename = "".join(c for c in url if c.isalnum())[:50] + ".txt"
        path = os.path.join(self.output_dir, filename)
        header = f"### SOURCE: {url}\n### TIMESTAMP: {datetime.now()}\n\n"
        with open(path, "w", encoding="utf-8") as f:
            f.write(header + content)

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.session.close()
        if exc_type:
            logging.error(f"Sink closed with error: {exc_val}")

async def fetch_page(url, sink, semaphore):
    async with semaphore:
        try:
            async with sink.session.get(url) as response:
                if response.status == 200:
                    text = await response.text()
                    await sink.save_content(url, text)
                    logging.info(f"Successfully scraped: {url}")
                else:
                    logging.warning(f"Failed {url} with status: {response.status}")
        except Exception as e:
            logging.error(f"Network error for {url}: {str(e)}")

async def main(urls):
    semaphore = asyncio.Semaphore(APP_CONFIG["max_concurrent"])
    async with AsyncDataSink("scraped_data") as sink:
        tasks = [fetch_page(url, sink, semaphore) for url in urls]
        await asyncio.gather(*tasks)

# Example usage
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    urls_to_scrape = [f"https://docs.example.tech/page_{i}" for i in range(10)]
    asyncio.run(main(urls_to_scrape))

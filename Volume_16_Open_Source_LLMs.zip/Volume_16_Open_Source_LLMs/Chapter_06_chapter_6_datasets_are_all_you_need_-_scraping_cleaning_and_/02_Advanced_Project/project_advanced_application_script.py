
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import requests
import re
import json
import logging
from bs4 import BeautifulSoup
from sqlalchemy import create_all, Column, Integer, String, Text, create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from pathlib import Path

# --- DATABASE MODEL CONFIGURATION ---
# We define a 'Model' using SQLAlchemy to track our scraping progress and metadata.
# This ensures we don't scrape the same URL twice and allows for data provenance.
Base = declarative_base()

class DocumentationSource(Base):
    __tablename__ = 'raw_docs'
    id = Column(Integer, primary_key=True)
    url = Column(String, unique=True)
    raw_content = Column(Text)
    cleaned_text = Column(Text)
    category = Column(String)

# --- THE DATA CLEANING ENGINE ---
class TextProcessor:
    """Handles the transformation of noisy HTML into clean, model-ready text."""
    
    @staticmethod
    def clean_html(html_content):
        # Initialize BeautifulSoup to parse the DOM
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # Remove non-content elements that introduce noise into the dataset
        for element in soup(['script', 'style', 'nav', 'footer', 'header', 'aside']):
            element.decompose()
            
        # Extract text and normalize whitespace to prevent token wastage
        text = soup.get_text(separator=' ')
        text = re.sub(r'\s+', ' ', text).strip()
        return text

    @staticmethod
    def create_instruction_pair(text, category):
        """Wraps cleaned text into an instruction-tuning JSON structure."""
        return {
            "instruction": f"Explain the following concept related to {category}:",
            "input": "",
            "output": text[:1500]  # Chunking for SLM context window limits
        }

# --- THE MAIN APPLICATION LOGIC ---
class DatasetScraper:
    def __init__(self, db_url="sqlite:///docs_dataset.db"):
        # Initialize the database engine and create tables
        self.engine = create_engine(db_url)
        Base.metadata.create_all(self.engine)
        self.Session = sessionmaker(bind=self.engine)

    def process_urls(self, url_list, category):
        # Using a context manager for the database session to ensure connection safety
        with self.Session() as session:
            for url in url_list:
                try:
                    # Fetching the raw data
                    response = requests.get(url, timeout=10)
                    response.raise_for_status()
                    
                    # Cleaning the data using our TextProcessor
                    clean_text = TextProcessor.clean_html(response.text)
                    
                    # Store in the database (The 'Model' layer)
                    doc = DocumentationSource(
                        url=url,
                        raw_content=response.text,
                        cleaned_text=clean_text,
                        category=category
                    )
                    session.add(doc)
                    session.commit()
                    print(f"Successfully processed: {url}")
                except Exception as e:
                    session.rollback()
                    print(f"Error processing {url}: {e}")

    def export_to_jsonl(self, output_file):
        """Exports the cleaned database records into JSONL format using a context manager."""
        path = Path(output_file)
        with self.Session() as session:
            records = session.query(DocumentationSource).all()
            
            # Using the 'with' statement as a Context Manager for file I/O
            with path.open('w', encoding='utf-8') as f:
                for record in records:
                    # Create the instruction-tuning structure
                    payload = TextProcessor.create_instruction_pair(
                        record.cleaned_text, 
                        record.category
                    )
                    # Write as a single line in the JSONL file
                    f.write(json.dumps(payload) + '\n')
        print(f"Dataset exported to {output_file}")

# --- EXECUTION ---
if __name__ == "__main__":
    # Example target URLs (In a real scenario, these would be crawled)
    target_urls = [
        "https://docs.python.org/3/library/pathlib.html",
        "https://docs.python.org/3/library/json.html"
    ]
    
    scraper = DatasetScraper()
    # Step 1: Scrape and Clean
    scraper.process_urls(target_urls, category="Python Programming")
    # Step 2: Structure and Export
    scraper.export_to_jsonl("fine_tuning_data.jsonl")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import torch
import torch.nn as nn

def simulate_training(r, alpha, steps=10):
    model = LoRALinearCell(in_features=128, out_features=128, r=r, alpha=alpha)
    optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
    criterion = nn.MSELoss()
    
    input_data = torch.randn(1, 128)
    target = torch.randn(1, 128)
    
    for _ in range(steps):
        optimizer.zero_grad()
        output = model(input_data)
        loss = criterion(output, target)
        loss.backward()
        optimizer.step()
        
    # Calculate Frobenius Norm of the effective Delta W (BA * scaling)
    delta_w = (model.lora_B @ model.lora_A) * (alpha / r)
    norm = torch.linalg.norm(delta_w, ord='fro').item()
    return norm

configs = [(4, 4), (32, 32), (32, 4)]
print(f"{'Config (r, alpha)':<20} | {'Effective Update Norm':<20}")
for r, a in configs:
    norm = simulate_training(r, a)
    print(f"r={r}, alpha={a:<12} | {norm:.6f}")

# Technical Justification:
# Configuration C (r=32, alpha=4) would likely require the highest learning rate.
# Because alpha/r = 4/32 (0.125), the adapter's contribution is suppressed by 8x 
# compared to Config B, leading to a much smaller effective update magnitude.

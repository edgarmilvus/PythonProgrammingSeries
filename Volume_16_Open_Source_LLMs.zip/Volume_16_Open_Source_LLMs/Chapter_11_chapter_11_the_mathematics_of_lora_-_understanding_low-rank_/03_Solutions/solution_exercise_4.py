
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import torch
import torch.nn as nn
from contextvars import ContextVar

# Global context and registry
current_adapter_id: ContextVar[str] = ContextVar("adapter_id", default=None)
ADAPTER_REGISTRY = {} # Maps "id" -> {"A": tensor, "B": tensor}

class MultiTenantLoRALinear(nn.Module):
    def __init__(self, in_features, out_features, r=8, alpha=16):
        super().__init__()
        self.weight = nn.Parameter(torch.randn(out_features, in_features))
        self.weight.requires_grad = False
        self.r = r
        self.scaling = alpha / r

    def forward(self, x):
        # 1. Base computation
        output = torch.matmul(x, self.weight.t())
        
        # 2. Context-aware LoRA lookup
        adapter_id = current_adapter_id.get()
        
        if adapter_id and adapter_id in ADAPTER_REGISTRY:
            A = ADAPTER_REGISTRY[adapter_id]["A"]
            B = ADAPTER_REGISTRY[adapter_id]["B"]
            # Compute: (x @ A.T @ B.T) * scaling
            lora_out = (x @ A.t()) @ B.t()
            output += lora_out * self.scaling
            
        return output

# Setup Registry
ADAPTER_REGISTRY["creative_writer"] = {
    "A": torch.randn(8, 512), "B": torch.randn(512, 8)
}

# Usage in a "Request"
layer = MultiTenantLoRALinear(512, 512)
token = current_adapter_id.set("creative_writer")
# Forward pass uses writer weights...
output = layer(torch.randn(1, 512))
current_adapter_id.reset(token)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import torch
import torch.nn as nn
import math

class LoRALinearCell(nn.Module):
    def __init__(self, in_features, out_features, r=8, alpha=16):
        super().__init__()
        if r > min(in_features, out_features):
            print(f"Warning: Rank {r} is not smaller than dimensions!")
        
        self.r = r
        self.alpha = alpha
        self.scaling = alpha / r
        
        # 1. The original "Frozen" weight matrix (W0)
        self.weight = nn.Parameter(torch.randn(out_features, in_features))
        self.weight.requires_grad = False 
        
        # 2. The Low-Rank Adapters
        # Matrix A: r x d_in (Kaiming Uniform initialization)
        self.lora_A = nn.Parameter(torch.zeros(r, in_features))
        nn.init.kaiming_uniform_(self.lora_A, a=math.sqrt(5))
        
        # Matrix B: d_out x r (Zero initialization)
        self.lora_B = nn.Parameter(torch.zeros(out_features, r))
        
    def forward(self, x):
        # Formula: Y = (X * W0^T) + (X * A^T * B^T) * (alpha/r)
        base_output = torch.matmul(x, self.weight.t())
        
        # Low-rank path: x -> A^T -> B^T
        # Note: We transpose A and B to align with input x [batch, in_features]
        lora_path = torch.matmul(x, self.lora_A.t())
        lora_path = torch.matmul(lora_path, self.lora_B.t())
        
        return base_output + (lora_path * self.scaling)

    def count_params(self):
        frozen = self.weight.numel()
        trainable = self.lora_A.numel() + self.lora_B.numel()
        total = frozen + trainable
        pct = (trainable / total) * 100
        print(f"Frozen: {frozen} | Trainable: {trainable} | Ratio: {pct:.4f}%")

# Example usage
layer = LoRALinearCell(in_features=4096, out_features=4096, r=8)
layer.count_params()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import torch
import io

def streaming_lora_init(weight_file_path, target_modules):
    lora_layers = {}
    
    # Simulate iterating over a massive file (e.g., sharded weights)
    with open(weight_file_path, "r") as f:
        for line in f:
            # Assume file format: "layer_name,in_dim,out_dim"
            parts = line.strip().split(",")
            if len(parts) != 3: continue
            
            layer_name, in_dim, out_dim = parts[0], int(parts[1]), int(parts[2])
            
            if any(target in layer_name for target in target_modules):
                print(f"Streaming Init: Found {layer_name}. Allocating A and B...")
                # Just-in-time allocation
                lora_layers[layer_name] = {
                    "A": torch.nn.Parameter(torch.randn(8, in_dim)),
                    "B": torch.nn.Parameter(torch.zeros(out_dim, 8))
                }
    return lora_layers

def log_training_progress(loss_val, log_path="train.log"):
    # Constant memory footprint: Append only
    with open(log_path, "a") as f:
        f.write(f"Loss: {loss_val:.4f}\n")

# Mock execution
with open("mock_weights.txt", "w") as f:
    f.write("model.layers.0.q_proj,4096,4096\nmodel.layers.0.mlp,4096,11008\n")

adapters = streaming_lora_init("mock_weights.txt", ["q_proj"])
log_training_progress(0.456)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import threading
from contextlib import contextmanager

# --- REQUEST CONTEXT MANAGEMENT ---
# We use a thread-local storage to simulate a Request Context.
# This allows the model to know which LoRA adapter to use without 
# passing user IDs through every single function call.
_request_store = threading.local()

@contextmanager
def request_context(user_id, adapter_path):
    """Pushes user-specific metadata onto a temporary stack."""
    _request_store.user_id = user_id
    _request_store.adapter_path = adapter_path
    try:
        yield
    finally:
        # Clean up after the request is processed to prevent data leakage
        _request_store.user_id = None
        _request_store.adapter_path = None

# --- THE BASE MODEL ---
class FrozenBaseModel:
    """Represents a massive LLM whose weights are frozen (read-only)."""
    def __init__(self, input_dim, output_dim):
        # Original weight matrix W (d x k)
        self.W = np.random.randn(output_dim, input_dim) * 0.01
        self.input_dim = input_dim
        self.output_dim = output_dim

    def forward(self, x):
        """Standard linear transformation: y = Wx"""
        print(f"  [Base] Processing input of shape {x.shape}")
        return np.dot(self.W, x)

# --- LoRA MATHEMATICS ENGINE ---
class LoRAAdapter:
    """Implements the Delta W = B * A bottleneck logic."""
    def __init__(self, r, alpha, input_dim, output_dim):
        self.r = r  # The Rank: the 'bottleneck' width
        self.alpha = alpha  # Scaling factor
        self.scaling = alpha / r
        # Matrix A: Shape (r x d) - initialized with Gaussian noise
        self.A = np.random.randn(r, input_dim) * 0.1
        # Matrix B: Shape (k x r) - initialized to zero to ensure Delta W is 0 at start
        self.B = np.zeros((output_dim, r))

    def apply(self, x):
        """Calculates (B * A) * x * scaling"""
        # Low-rank decomposition path: x -> A -> B
        # Math: ΔW x = B(Ax)
        bottleneck = np.dot(self.A, x)
        update = np.dot(self.B, bottleneck)
        return update * self.scaling

# --- ADAPTER LOADER (FILE ITERATION) ---
def load_adapter_weights(file_path, r, input_dim, output_dim):
    """
    Simulates loading LoRA weights from a file.
    Uses File Object Iteration to read weights line-by-line, 
    preventing memory spikes for large adapter files.
    """
    adapter = LoRAAdapter(r, 16, input_dim, output_dim)
    print(f"  [Storage] Iterating over file: {file_path}")
    
    # In a real scenario, this would parse a binary or CSV weight file
    with open(file_path, 'r') as f:
        for line in f:
            if "matrix_A" in line:
                # Simulate populating A from file data
                adapter.A = np.random.randn(r, input_dim)
            elif "matrix_B" in line:
                # Simulate populating B from file data
                adapter.B = np.random.randn(output_dim, r)
    return adapter

# --- MONKEY PATCHING LOGIC ---
def inject_lora_logic(model_instance):
    """
    Uses Monkey Patching to wrap the original forward method.
    This injects LoRA math into the base model at runtime.
    """
    original_forward = model_instance.forward

    def lora_patched_forward(x):
        # 1. Execute the frozen base model logic
        base_output = original_forward(x)
        
        # 2. Check the Request Context for an active adapter
        if hasattr(_request_store, 'adapter_path') and _request_store.adapter_path:
            # Load the adapter (In production, use a cache here!)
            adapter = load_adapter_weights(_request_store.adapter_path, 4, 128, 64)
            # 3. Add the Low-Rank Adaptation: y = Wx + (BA)x
            lora_output = adapter.apply(x)
            print(f"  [LoRA] Applied rank-4 adaptation for {_request_store.user_id}")
            return base_output + lora_output
        
        return base_output

    # Dynamically replace the method on the instance
    model_instance.forward = lora_patched_forward

# --- EXECUTION ---
if __name__ == "__main__":
    # Setup: Create a base model (128 inputs, 64 outputs)
    gpt_base = FrozenBaseModel(input_dim=128, output_dim=64)
    
    # Apply Monkey Patching to enable LoRA capabilities
    inject_lora_logic(gpt_base)

    # Simulate a dummy weight file for the iteration logic
    with open("user_77_adapter.weights", "w") as f:
        f.write("matrix_A: [...data...]\nmatrix_B: [...data...]")

    # Scenario: User 77 sends a request
    print("--- Processing Request for User 77 ---")
    dummy_input = np.random.randn(128)
    with request_context(user_id="User_77", adapter_path="user_77_adapter.weights"):
        result = gpt_base.forward(dummy_input)
    
    print(f"Final output shape: {result.shape}")

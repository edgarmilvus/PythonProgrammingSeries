
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import torch
import torch.nn as nn
import torch.optim as optim

# ---------------------------------------------------------
# 1. THE LORA LAYER DEFINITION
# This class wraps a standard linear layer with LoRA logic.
# ---------------------------------------------------------
class LoRALinear(nn.Module):
    def __init__(self, in_features, out_features, rank=8, alpha=16):
        super(LoRALinear, self).__init__()
        
        # The original 'frozen' weight matrix (W)
        # In a real scenario, these would be pre-trained weights.
        self.linear = nn.Linear(in_features, out_features, bias=False)
        
        # Freeze the original weights so they don't update during backprop
        self.linear.weight.requires_grad = False
        
        # The rank 'r' is an Integer defining the bottleneck width
        self.rank = rank
        
        # The scaling factor (alpha / rank)
        self.scaling = alpha / rank
        
        # Matrix A: Initialized with Kaiming/Gaussian noise
        # This reduces the input dimension to the low-rank 'r'
        self.lora_A = nn.Parameter(torch.randn(in_features, rank))
        
        # Matrix B: Initialized to zeros
        # This ensures that at the start of training, LoRA's contribution is 0
        self.lora_B = nn.Parameter(torch.zeros(rank, out_features))

    def forward(self, x):
        # Step 1: Compute the standard forward pass (Wx)
        # This uses the frozen, original model knowledge.
        original_output = self.linear(x)
        
        # Step 2: Compute the LoRA path (x @ A @ B) * scaling
        # This represents the 'delta' or adaptation.
        # We use matrix multiplication (@) to pass through the bottleneck.
        lora_adaptation = (x @ self.lora_A @ self.lora_B) * self.scaling
        
        # Step 3: Combine both paths
        # The final output is the sum of the base model and the adaptation.
        return original_output + lora_adaptation

# ---------------------------------------------------------
# 2. THE SIMULATED TRAINING LOOP
# Demonstrating how we only update the low-rank parameters.
# ---------------------------------------------------------
def run_lora_demo():
    # Define dimensions (Integer values)
    input_dim = 1024
    output_dim = 512
    r = 4  # Very low rank for maximum efficiency
    
    # Initialize our LoRA-enhanced layer
    model = LoRALinear(input_dim, output_dim, rank=r)
    
    # Create a dummy input (Batch Size = 1)
    dummy_input = torch.randn(1, input_dim)
    
    # Define a target for a simple 'learning' task
    target = torch.randn(1, output_dim)
    
    # Optimizer: Only provide the LoRA parameters (A and B)
    # We ignore the frozen self.linear.weight
    optimizer = optim.Adam([model.lora_A, model.lora_B], lr=1e-3)
    criterion = nn.MSELoss()

    print(f"--- Starting LoRA Training Simulation ---")
    print(f"Rank (r): {r}")
    print(f"Original Weight Shape: {input_dim}x{output_dim}")
    print(f"LoRA A Shape: {input_dim}x{r}")
    print(f"LoRA B Shape: {r}x{output_dim}\n")

    # Simulate 5 steps of training
    for step in range(5):
        optimizer.zero_grad()
        
        # Forward pass
        output = model(dummy_input)
        loss = criterion(output, target)
        
        # Backward pass
        loss.backward()
        
        # Update only lora_A and lora_B
        optimizer.step()
        
        print(f"Step {step+1}: Loss = {loss.item():.4f}")

    # ---------------------------------------------------------
    # 3. WEIGHT MERGING (The 'Zero-Latency' Trick)
    # After training, we can merge A and B back into W.
    # ---------------------------------------------------------
    with torch.no_grad():
        # Delta W = (A @ B) * scaling
        # We transpose A and B logic to match Linear weight shape (out, in)
        delta_w = (model.lora_A @ model.lora_B).t() * model.scaling
        
        # Monkey Patching: Update the original frozen weights with the delta
        model.linear.weight.data += delta_w
        
    print("\nTraining Complete. LoRA weights successfully merged into the base model.")

if __name__ == "__main__":
    run_lora_demo()

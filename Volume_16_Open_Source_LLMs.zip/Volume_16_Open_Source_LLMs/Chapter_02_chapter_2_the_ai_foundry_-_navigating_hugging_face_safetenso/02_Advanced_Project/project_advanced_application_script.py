
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
from datetime import datetime
from typing import List, Optional
from sqlalchemy import create_all, Column, Integer, String, Text, DateTime, ForeignKey, Boolean
from sqlalchemy.orm import declarative_base, sessionmaker, relationship
from sqlalchemy import create_engine
from huggingface_hub import HfApi, model_info

# --- Database Configuration & POLA-Compliant Schema ---
# We use SQLAlchemy to map Python classes to database tables.
# Following the Principle of Least Astonishment (POLA), we name our 
# classes clearly to reflect their real-world counterparts.
Base = declarative_base()

class ModelRegistry(Base):
    """Stores metadata about models fetched from Hugging Face."""
    __tablename__ = 'model_registry'
    
    id = Column(Integer, primary_key=True)
    repo_id = Column(String(255), nullable=False, unique=True)
    architecture = Column(String(100))
    is_safetensors = Column(Boolean, default=False)
    last_downloaded = Column(DateTime, default=datetime.utcnow)
    
    # Relationship to link chat history to a specific model version
    sessions = relationship("ChatSession", back_populates="model")

class ChatSession(Base):
    """Maintains LLM Memory by storing conversation turns."""
    __tablename__ = 'chat_sessions'
    
    id = Column(Integer, primary_key=True)
    model_id = Column(Integer, ForeignKey('model_registry.id'))
    start_time = Column(DateTime, default=datetime.utcnow)
    
    # Link back to the model used
    model = relationship("ModelRegistry", back_populates="sessions")
    messages = relationship("Message", back_populates="session")

class Message(Base):
    """Individual turns within a conversation (The 'Memory' units)."""
    __tablename__ = 'messages'
    
    id = Column(Integer, primary_key=True)
    session_id = Column(Integer, ForeignKey('chat_sessions.id'))
    role = Column(String(50))  # e.g., 'user', 'assistant', 'system'
    content = Column(Text, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)
    
    session = relationship("ChatSession", back_populates="messages")

# --- Logic Layer: The AI Foundry Manager ---

class AIFoundryManager:
    def __init__(self, db_url: str = "sqlite:///ai_foundry.db"):
        # Initialize the database engine and session factory
        self.engine = create_engine(db_url)
        Base.metadata.create_all(self.engine)
        self.Session = sessionmaker(bind=self.engine)
        self.api = HfApi()

    def register_huggingface_model(self, repo_id: str) -> ModelRegistry:
        """
        Fetches model details from HF Hub and commits to local registry.
        This handles the transition from remote metadata to local state.
        """
        session = self.Session()
        try:
            # Fetch metadata from Hugging Face Hub
            info = model_info(repo_id)
            
            # Check for Safetensors presence (Security & Efficiency check)
            has_safetensors = any(f.rfilename.endswith('.safetensors') for f in info.siblings)
            
            # Extract architecture from tags or config if available
            arch = getattr(info, 'config', {}).get('architectures', ['Unknown'])[0]

            # Check if model exists, if not, create it (POLA: avoid duplicates)
            model_entry = session.query(ModelRegistry).filter_by(repo_id=repo_id).first()
            if not model_entry:
                model_entry = ModelRegistry(
                    repo_id=repo_id,
                    architecture=arch,
                    is_safetensors=has_safetensors
                )
                session.add(model_entry)
                session.commit()
                print(f"[INFO] Registered new model: {repo_id}")
            return model_entry
        except Exception as e:
            session.rollback()
            print(f"[ERROR] Failed to fetch model metadata: {e}")
            raise
        finally:
            session.close()

    def create_chat_memory(self, repo_id: str) -> int:
        """Initializes a new chat session linked to a specific model."""
        session = self.Session()
        model = session.query(ModelRegistry).filter_by(repo_id=repo_id).one()
        new_session = ChatSession(model_id=model.id)
        session.add(new_session)
        session.commit()
        session_id = new_session.id
        session.close()
        return session_id

    def add_message_to_memory(self, session_id: int, role: str, content: str):
        """Appends a dialogue turn to the database for persistent context."""
        session = self.Session()
        msg = Message(session_id=session_id, role=role, content=content)
        session.add(msg)
        session.commit()
        session.close()

    def get_session_history(self, session_id: int) -> List[dict]:
        """Retrieves all previous messages in a session to feed back into the LLM."""
        session = self.Session()
        messages = session.query(Message).filter_by(session_id=session_id).order_by(Message.timestamp).all()
        history = [{"role": m.role, "content": m.content} for m in messages]
        session.close()
        return history

# --- Execution Example ---
if __name__ == "__main__":
    manager = AIFoundryManager()
    
    # 1. Register a popular open-source model (e.g., Mistral-7B)
    target_model = "mistralai/Mistral-7B-v0.1"
    manager.register_huggingface_model(target_model)
    
    # 2. Start a new conversation session
    sid = manager.create_chat_memory(target_model)
    
    # 3. Simulate a conversation (Memory Persistence)
    manager.add_message_to_memory(sid, "user", "What is a Safetensor?")
    manager.add_message_to_memory(sid, "assistant", "It is a secure format for storing tensors.")
    
    # 4. Retrieve history (This would be passed to the LLM's prompt context)
    context = manager.get_session_history(sid)
    print(f"\n--- Persistent Memory for Session {sid} ---")
    for turn in context:
        print(f"{turn['role'].upper()}: {turn['content']}")

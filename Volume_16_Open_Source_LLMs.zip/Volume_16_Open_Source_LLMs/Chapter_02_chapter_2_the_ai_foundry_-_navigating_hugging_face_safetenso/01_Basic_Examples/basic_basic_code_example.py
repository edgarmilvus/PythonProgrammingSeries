
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import torch
from sqlalchemy import create_all_engines, Column, Integer, String, Text, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from transformers import AutoModelForCausalLM, AutoTokenizer, TextIteratorStreamer
from threading import Thread
import asyncio

# --- PART 1: DATABASE ARCHITECTURE (LLM MEMORY) ---
# We define a simple SQLite schema to store our conversation turns.
# This allows the model to "remember" previous context across sessions.
Base = declarative_base()

class ConversationMemory(Base):
    __tablename__ = 'chat_history'
    id = Column(Integer, primary_key=True)
    user_input = Column(Text)
    model_response = Column(Text)

# Initialize the local SQL database
engine = create_engine('sqlite:///ai_foundry.db')
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)
db_session = Session()

# --- PART 2: MODEL INITIALIZATION (THE FOUNDRY) ---
# We use the Auto-classes to automatically detect the architecture.
# 'use_safetensors=True' ensures we are using the secure, fast-loading format.
model_id = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"

print(f"Loading model: {model_id}...")
tokenizer = AutoTokenizer.from_pretrained(model_id)
model = AutoModelForCausalLM.from_pretrained(
    model_id,
    torch_dtype=torch.float16, # Use half-precision for memory efficiency
    device_map="auto",         # Automatically balance across GPU/CPU
    use_safetensors=True       # Critical security and speed feature
)

# --- PART 3: THE ASYNC STREAMING LOGIC ---
async def generate_response(prompt):
    # Retrieve previous history from SQLAlchemy to provide context (Memory)
    history = db_session.query(ConversationMemory).all()
    context = ""
    for entry in history:
        context += f"User: {entry.user_input}\nAssistant: {entry.model_response}\n"
    
    # Construct the final prompt with context
    full_prompt = f"{context}User: {prompt}\nAssistant:"
    
    # Prepare inputs for the model
    inputs = tokenizer(full_prompt, return_tensors="pt").to(model.device)
    
    # Initialize the Streamer
    # TextIteratorStreamer allows us to yield tokens as they are generated
    streamer = TextIteratorStreamer(tokenizer, skip_prompt=True, skip_special_tokens=True)
    
    # Generation arguments
    generation_kwargs = dict(
        inputs,
        streamer=streamer,
        max_new_tokens=150,
        do_sample=True,
        temperature=0.7,
        top_p=0.9
    )

    # We run generation in a separate thread so it doesn't block the main loop
    thread = Thread(target=model.generate, kwargs=generation_kwargs)
    thread.start()

    # Stream the output to the console
    print("AI Response: ", end="", flush=True)
    generated_text = ""
    for new_text in streamer:
        print(new_text, end="", flush=True)
        generated_text += new_text
    print("\n")

    # --- PART 4: PERSISTENCE ---
    # Save the interaction to the database for future memory
    new_memory = ConversationMemory(user_input=prompt, model_response=generated_text)
    db_session.add(new_memory)
    db_session.commit()

# --- PART 5: EXECUTION ---
async def main():
    print("--- AI Foundry Chatbot (Type 'exit' to quit) ---")
    while True:
        user_query = input("You: ")
        if user_query.lower() == 'exit':
            break
        await generate_response(user_query)

if __name__ == "__main__":
    asyncio.run(main())

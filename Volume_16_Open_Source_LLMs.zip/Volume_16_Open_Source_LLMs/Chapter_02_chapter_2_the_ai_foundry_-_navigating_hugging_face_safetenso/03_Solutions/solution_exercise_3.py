
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import asyncio
import time
import threading
from transformers import TextIteratorStreamer

async def stream_llm_response(model, tokenizer, prompt, device="cuda"):
    streamer = TextIteratorStreamer(tokenizer, skip_prompt=True, decode_kwargs={"skip_special_tokens": True})
    
    inputs = tokenizer(prompt, return_tensors="pt").to(device)
    generation_kwargs = dict(inputs, streamer=streamer, max_new_tokens=128)

    # Run generation in a separate thread to avoid blocking the event loop
    thread = threading.Thread(target=model.generate, kwargs=generation_kwargs)
    thread.start()

    token_count = 0
    start_time = time.time()

    print("Assistant: ", end="", flush=True)
    for new_text in streamer:
        # Token Cleaning: TextIteratorStreamer already handles basic cleaning via decode_kwargs
        print(new_text, end="", flush=True)
        
        token_count += 1
        if token_count % 10 == 0:
            tps = token_count / (time.time() - start_time)
            # Print TPS in a non-disruptive way (conceptual)
            # In a real UI, this would update a separate status bar
            pass 
            
        await asyncio.sleep(0) # Yield control to the event loop

    total_time = time.time() - start_time
    print(f"\n\n[Stats: {token_count} tokens generated in {total_time:.2f}s | {token_count/total_time:.2f} TPS]")

# Note: In a real scenario, you'd wrap the loop in a try/except for asyncio.CancelledError

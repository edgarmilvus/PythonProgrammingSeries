
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship

Base = declarative_base()

class Session(Base):
    __tablename__ = 'sessions'
    id = Column(Integer, primary_key=True)
    model_name = Column(String(50))
    start_time = Column(DateTime, default=datetime.datetime.utcnow)
    messages = relationship("Message", back_populates="session")

class Message(Base):
    __tablename__ = 'messages'
    id = Column(Integer, primary_key=True)
    session_id = Column(Integer, ForeignKey('sessions.id'))
    role = Column(String(20)) # system, user, assistant
    content = Column(Text)
    token_count = Column(Integer)
    session = relationship("Session", back_populates="messages")

class ChatMemoryManager:
    def __init__(self, db_url="sqlite:///chat_history.db"):
        engine = create_engine(db_url)
        Base.metadata.create_all(engine)
        self.SessionLocal = sessionmaker(bind=engine)

    def get_context_window(self, session_id, max_tokens=2048):
        db = self.SessionLocal()
        # Fetch messages in reverse chronological order
        messages = db.query(Message).filter(Message.session_id == session_id)\
                     .order_by(Message.id.desc()).all()
        
        context = []
        current_tokens = 0
        
        for msg in messages:
            if current_tokens + msg.token_count > max_tokens:
                break
            context.insert(0, {"role": msg.role, "content": msg.content})
            current_tokens += msg.token_count
        
        db.close()
        return context

# Usage Example:
# manager = ChatMemoryManager()
# history = manager.get_context_window(session_id=1, max_tokens=1000)
# formatted_prompt = tokenizer.apply_chat_template(history, tokenize=False)

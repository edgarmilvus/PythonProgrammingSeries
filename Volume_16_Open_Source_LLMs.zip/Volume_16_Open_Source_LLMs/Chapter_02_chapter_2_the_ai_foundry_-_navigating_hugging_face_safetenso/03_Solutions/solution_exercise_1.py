
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
import torch
import json
import hashlib
from safetensors.torch import save_file, load_file
from transformers import AutoConfig

def calculate_weights_checksum(state_dict):
    """Calculates a deterministic hash of the tensor data."""
    hash_sha256 = hashlib.sha256()
    # Sort keys to ensure deterministic hashing
    for key in sorted(state_dict.keys()):
        # Convert tensor to numpy/bytes for hashing
        data = state_dict[key].cpu().numpy().tobytes()
        hash_sha256.update(data)
    return hash_sha256.hexdigest()

def migrate_to_safetensors(model_dir, delete_old=False):
    for root, dirs, files in os.walk(model_dir):
        if "pytorch_model.bin" in files and "config.json" in files:
            print(f"Processing: {root}")
            bin_path = os.path.join(root, "pytorch_model.bin")
            st_path = os.path.join(root, "model.safetensors")
            
            # 1. Load original weights and metadata
            state_dict = torch.load(bin_path, map_location="cpu")
            config = AutoConfig.from_pretrained(root)
            metadata = {
                "model_type": str(config.model_type),
                "architectures": str(config.architectures[0]),
                "num_attention_heads": str(getattr(config, "num_attention_heads", "N/A"))
            }

            # 2. Perform Integrity Check (Source)
            source_params = sum(p.numel() for p in state_dict.values())
            source_dtype = next(iter(state_dict.values())).dtype
            source_hash = calculate_weights_checksum(state_dict)

            # 3. Convert and Save
            save_file(state_dict, st_path, metadata=metadata)

            # 4. Validation (Destination)
            converted_state_dict = load_file(st_path)
            dest_params = sum(p.numel() for p in converted_state_dict.values())
            dest_dtype = next(iter(converted_state_dict.values())).dtype
            dest_hash = calculate_weights_checksum(converted_state_dict)

            if source_params == dest_params and source_dtype == dest_dtype and source_hash == dest_hash:
                print(f"✅ Integrity Verified for {root}")
                if delete_old:
                    os.remove(bin_path)
                    print(f"🗑️ Deleted legacy .bin file.")
            else:
                print(f"❌ Validation Failed for {root}!")

# Example usage:
# migrate_to_safetensors("./my_models", delete_old=True)

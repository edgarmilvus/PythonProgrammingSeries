
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import json

def simulate_sharding(index_json_path, gpu_vram_list):
    with open(index_json_path, 'r') as f:
        data = json.load(f)
    
    weight_map = data['weight_map']
    # Group weights by layer index
    layers = {}
    for weight_name, shard in weight_map.items():
        # Extract layer number (e.g., 'layers.0')
        parts = weight_name.split('.')
        layer_key = '.'.join(parts[:3]) if 'layers' in parts else 'other'
        layers[layer_key] = layers.get(layer_key, 0) + 0.5 # Assume 0.5GB per layer for 70B fp16

    allocation = {}
    current_gpu = 0
    remaining_vram = gpu_vram_list[current_gpu]

    dot_output = "digraph G {\n"
    
    for layer, size in layers.items():
        if current_gpu < len(gpu_vram_list) and size <= remaining_vram:
            device = f"GPU_{current_gpu}"
            remaining_vram -= size
        elif current_gpu + 1 < len(gpu_vram_list):
            current_gpu += 1
            remaining_vram = gpu_vram_list[current_gpu] - size
            device = f"GPU_{current_gpu}"
        else:
            device = "CPU_RAM"
        
        allocation[layer] = device
        dot_output += f'  "{layer}" -> "{device}";\n'

    dot_output += "}"
    return allocation, dot_output

# Example Usage:
# gpus = [24, 12] # GPU 0: 24GB, GPU 1: 12GB
# plan, dot_graph = simulate_sharding("pytorch_model.bin.index.json", gpus)
# print(dot_graph)

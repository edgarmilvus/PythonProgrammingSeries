
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, AutoConfig, BitsAndBytesConfig
from peft import PeftModel

class AI_Foundry:
    def __init__(self):
        self.model = None
        self.tokenizer = None
        self.base_model_id = None

    def estimate_vram(self, model_id):
        config = AutoConfig.from_pretrained(model_id)
        # Simplified: (layers * hidden_size^2 * 12) for weights in fp16
        # Or more accurately, use the num_params from config if available
        params = getattr(config, "num_parameters", 7_000_000_000) # Fallback to 7B
        return (params * 2) / (1024**3) # GB

    def load_base_model(self, model_id):
        vram_required = self.estimate_vram(model_id)
        gpu_vram = torch.cuda.get_device_properties(0).total_memory / (1024**3)
        
        quant_config = None
        if vram_required > (gpu_vram * 0.8):
            print("⚠️ VRAM constraint detected. Enabling 4-bit quantization.")
            quant_config = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_compute_dtype=torch.float16)

        self.tokenizer = AutoTokenizer.from_pretrained(model_id)
        self.model = AutoModelForCausalLM.from_pretrained(
            model_id, 
            quantization_config=quant_config,
            device_map="auto"
        )
        self.base_model_id = model_id

    def apply_adapter(self, adapter_path):
        if self.model:
            print(f"💉 Injecting adapter from {adapter_path}")
            self.model = PeftModel.from_pretrained(self.model, adapter_path)

    def unload_adapter(self):
        if isinstance(self.model, PeftModel):
            self.model = self.model.unload()
            print("✨ Adapter unloaded. Model restored to base state.")

# Simulation:
# foundry = AI_Foundry()
# foundry.load_base_model("mistralai/Mistral-7B-v0.1")
# foundry.apply_adapter("./lora-python-coder")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import time
import os
from flask import Flask, request, g, jsonify
from flask_sqlalchemy import SQLAlchemy
from llama_cpp import Llama  # For GGUF
from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline # For AWQ/GPTQ
import torch

# Initialize Flask and SQLAlchemy for tracking inference performance
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///inference_logs.db'
db = SQLAlchemy(app)

# Database Model for tracking quantization efficiency
class InferenceLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    model_name = db.Column(db.String(100))
    quant_format = db.Column(db.String(10))  # GGUF, AWQ, or GPTQ
    latency_ms = db.Column(db.Float)
    tokens_per_sec = db.Column(db.Float)
    vram_used_gb = db.Column(db.Float)

# The Model Factory implementing the Principle of Least Astonishment (POLA)
class QuantizedModelFactory:
    def __init__(self, model_path, format_type):
        self.model_path = model_path
        self.format_type = format_type.upper()
        self.engine = self._initialize_engine()

    def _initialize_engine(self):
        # Predictable initialization: user expects a loaded model or a clear error
        if self.format_type == "GGUF":
            # GGUF allows CPU offloading and flexible bit-depth
            return Llama(model_path=self.model_path, n_gpu_layers=-1, n_ctx=2048)
        elif self.format_type in ["AWQ", "GPTQ"]:
            # AWQ/GPTQ require GPU; using Transformers/AutoAWQ integration
            return pipeline("text-generation", model=self.model_path, device_map="auto")
        else:
            raise ValueError(f"Unsupported format: {self.format_type}")

    def generate_text(self, prompt, max_tokens=128):
        start_time = time.time()
        
        if self.format_type == "GGUF":
            output = self.engine(prompt, max_tokens=max_tokens)
            text = output['choices'][0]['text']
            usage = output['usage']['completion_tokens']
        else:
            output = self.engine(prompt, max_new_tokens=max_tokens)
            text = output[0]['generated_text']
            usage = max_tokens # Simplified for example

        duration = (time.time() - start_time) * 1000
        return text, duration, usage

# Request Context management for per-request performance monitoring
@app.before_request
def start_timer():
    g.start = time.time()
    # Tracking VRAM at start of request context
    if torch.cuda.is_available():
        g.initial_vram = torch.cuda.memory_allocated() / 1024**3
    else:
        g.initial_vram = 0

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    model_path = data.get('model_path')
    quant_type = data.get('quant_type', 'GGUF')
    prompt = data.get('prompt', '')

    # Factory creates the appropriate engine without surprising the caller
    factory = QuantizedModelFactory(model_path, quant_type)
    response_text, latency, tokens = factory.generate_text(prompt)

    # Log metrics to SQLAlchemy database
    vram_end = torch.cuda.memory_allocated() / 1024**3 if torch.cuda.is_available() else 0
    log = InferenceLog(
        model_name=os.path.basename(model_path),
        quant_format=quant_type,
        latency_ms=latency,
        tokens_per_sec=tokens / (latency / 1000),
        vram_used_gb=vram_end - g.initial_vram
    )
    db.session.add(log)
    db.session.commit()

    return jsonify({
        "status": "success",
        "output": response_text,
        "metrics": {
            "latency_ms": latency,
            "tokens_per_second": tokens / (latency / 1000)
        }
    })

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', port=5000)

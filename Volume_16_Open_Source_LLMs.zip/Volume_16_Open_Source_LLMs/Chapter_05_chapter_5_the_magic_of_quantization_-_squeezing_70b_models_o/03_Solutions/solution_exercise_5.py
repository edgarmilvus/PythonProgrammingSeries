
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# --- Quantization Survival Strategy ---
# Target: 70B Model (140GB FP16) on 12GB VRAM
# Constraint: 11GB usable (1GB for OS)

strategy_config = {
    "format": "GGUF",  # Choice: GGUF. Justification: AWQ/GPTQ require the full 
                       # model in VRAM (~35GB for 4-bit), which is impossible. 
                       # GGUF allows partial CPU offloading.
    
    "quantization_level": "Q2_K", # Choice: 2-bit. Justification: A 70B model 
                                  # at Q2_K is ~25GB. Even with CPU offloading, 
                                  # 4-bit (40GB) would be too slow on system RAM.
    
    "gpu_layers": 12,  # Estimation: 12GB VRAM / ~500MB per layer (Q4) 
                       # At Q2_K, layers are smaller (~300MB). 
                       # 12-15 layers should fit while leaving room for KV cache.
    
    "kv_cache_bit_depth": "fp16",
    "context_window": 2048
}

# Implementation Logic (Pseudo-code for llama-cpp-python)
"""
llm = Llama(
    model_path="llama-3-70b-Q2_K.gguf",
    n_gpu_layers=15,       # Offload what fits in 11GB
    n_ctx=2048,            # Limit context to save VRAM
    n_threads=16,          # Maximize CPU threads for the other 65 layers
    use_mlock=True         # Prevent swapping to disk
)
"""

# Failure Mode Analysis:
# The primary bottleneck will be PCIe Bandwidth. Since ~80% of the model 
# resides in System RAM (DDR4/5), the GPU must wait for weights to transfer 
# over the PCIe bus every forward pass, likely resulting in 1-2 TPS.

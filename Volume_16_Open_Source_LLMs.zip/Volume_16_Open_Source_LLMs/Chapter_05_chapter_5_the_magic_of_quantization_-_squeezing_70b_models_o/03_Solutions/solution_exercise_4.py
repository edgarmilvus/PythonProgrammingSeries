
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import torch
from llama_cpp import Llama

def dynamic_quantization_loader(model_path, user_n_layers=None):
    # POLA: Respect explicit user settings
    if user_n_layers is not None:
        return Llama(model_path=model_path, n_gpu_layers=user_n_layers)

    # 1. Dynamic Calculation
    free_vram = torch.cuda.mem_get_info()[0] / 1024**2 # MB
    headroom = 2048 # 2GB Safety
    usable_vram = free_vram - headroom
    
    # Estimate: Llama-3-70B 4-bit is ~40GB total for 80 layers (~500MB/layer)
    # This varies by model; here we use a heuristic for 70B 4-bit
    vram_per_layer = 512 
    target_layers = int(usable_vram // vram_per_layer)
    target_layers = min(target_layers, 81) # Cap at max layers

    # 2. Backoff Strategy
    while target_layers >= 0:
        try:
            print(f"Attempting load: {target_layers} layers. Headroom: {headroom}MB")
            return Llama(model_path=model_path, n_gpu_layers=target_layers)
        except RuntimeError as e:
            if "out of memory" in str(e).lower():
                print("OOM Detected. Reducing layer count by 10%...")
                target_layers = int(target_layers * 0.9)
            else:
                raise e
    
    raise MemoryError("Could not fit even 0 layers on GPU.")

# Usage
# llm = dynamic_quantization_loader("models/70b-q4_k_m.gguf")

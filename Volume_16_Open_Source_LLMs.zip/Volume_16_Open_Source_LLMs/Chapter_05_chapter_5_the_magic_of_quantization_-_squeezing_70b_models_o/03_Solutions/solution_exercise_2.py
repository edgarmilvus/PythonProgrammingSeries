
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import logging

class ModelResourcePredictor:
    def __init__(self, params_billions, architecture="GQA"):
        self.params = params_billions * 1e9
        self.architecture = architecture
        self.logger = logging.getLogger("VRAMPredictor")

    def estimate_vram(self, bit_depth, context_length):
        # 1. Weight Size: (Params * Bits / 8) + 10% overhead for non-quantized layers
        weight_size_gb = (self.params * bit_depth / 8) / 1024**3
        weight_size_gb *= 1.10 

        # 2. KV Cache Estimation (Simplified for Llama-3 style GQA)
        # Formula: 2 * layers * hidden_size * context * (num_heads / groups) * precision
        # Approx: 0.5MB per 1024 tokens for 7B, 2MB per 1024 for 70B at FP16
        kv_cache_gb = (self.params / 7e9) * (context_length / 1024) * 0.5 / 1024
        
        total_vram = weight_size_gb + kv_cache_gb
        
        return {
            "weights_gb": round(weight_size_gb, 2),
            "kv_cache_gb": round(kv_cache_gb, 2),
            "total_gb": round(total_vram, 2)
        }

    def validate_prediction(self, predicted, actual):
        error_margin = abs(predicted - actual) / actual
        if error_margin > 0.05:
            self.logger.warning(f"Prediction error high! Margin: {error_margin:.2%}")
        return error_margin <= 0.05

# Example Usage
predictor = ModelResourcePredictor(70) # 70B Model
prediction = predictor.estimate_vram(bit_depth=4, context_length=8192)
print(f"Predicted VRAM: {prediction['total_gb']} GB")

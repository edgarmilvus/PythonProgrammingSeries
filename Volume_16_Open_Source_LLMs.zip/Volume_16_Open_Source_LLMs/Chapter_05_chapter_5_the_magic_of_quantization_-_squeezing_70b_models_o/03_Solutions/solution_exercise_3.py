
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import uuid
import threading

class ApplicationContext:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls, model_path, n_gpu_layers):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super(ApplicationContext, cls).__new__(cls)
                # Load the heavy model only once
                cls._instance.model = Llama(model_path=model_path, n_gpu_layers=n_gpu_layers)
                cls._instance.config = {"gpu_layers": n_gpu_layers}
        return cls._instance

class RequestContext:
    def __init__(self, app_context, sampling_params):
        self.request_id = uuid.uuid4()
        self.app = app_context
        self.params = sampling_params
        self.local_cache = [] # Temporary storage for this request

    def run_inference(self, prompt):
        # Access the global model with request-specific parameters
        return self.app.model(
            prompt,
            temp=self.params.get("temp", 0.7),
            top_k=self.params.get("top_k", 40)
        )

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        # Cleanup: Clear local tensors or temporary lists
        self.local_cache.clear()
        print(f"Request {self.request_id} context cleared.")

# Usage
app = ApplicationContext("llama3-70b.gguf", n_gpu_layers=40)
with RequestContext(app, {"temp": 0.1}) as request:
    response = request.run_inference("What is quantization?")

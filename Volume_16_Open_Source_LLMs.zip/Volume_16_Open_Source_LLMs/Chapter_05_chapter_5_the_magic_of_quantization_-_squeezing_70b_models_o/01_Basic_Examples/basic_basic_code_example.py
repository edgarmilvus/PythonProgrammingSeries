
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Import necessary libraries for model loading and quantization
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

# Define the model ID from Hugging Face Hub (using a smaller 8B model for this example)
# In a real-world 70B scenario, the logic remains identical.
model_id = "meta-llama/Meta-Llama-3-8B-Instruct"

# Step 1: Configure the Quantization Settings
# This is the "Magic" configuration that squeezes the model.
quantization_config = BitsAndBytesConfig(
    load_in_4bit=True,                    # Enable 4-bit quantization
    bnb_4bit_compute_dtype=torch.bfloat16, # Use bfloat16 for intermediate computations
    bnb_4bit_quant_type="nf4",             # Use NormalFloat4 (better for normally distributed weights)
    bnb_4bit_use_double_quant=True,        # Quantize the quantization constants for extra savings
)

# Step 2: Load the Tokenizer
# The tokenizer converts text into numerical IDs the model understands.
tokenizer = AutoTokenizer.from_pretrained(model_id)

# Step 3: Load the Model with Quantization
# We use device_map="auto" to automatically distribute layers across available GPUs/CPU.
model = AutoModelForCausalLM.from_pretrained(
    model_id,
    quantization_config=quantization_config,
    device_map="auto",
    torch_dtype=torch.bfloat16,
    low_cpu_mem_usage=True                 # Optimize CPU RAM usage during the loading phase
)

# Step 4: Prepare a simple prompt
prompt = "Explain quantization in one sentence."
inputs = tokenizer(prompt, return_tensors="pt").to("cuda")

# Step 5: Generate a response
# The model performs inference in 4-bit, saving massive amounts of VRAM.
output = model.generate(**inputs, max_new_tokens=50)

# Step 6: Decode and print the result
print(tokenizer.decode(output[0], skip_special_tokens=True))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
import json
from datetime import datetime

def save_tunable_parameters(model, tokenizer, output_base_path, experiment_name):
    # Requirement 1 & 2: Platform Independence and Versioning
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    versioned_dir = os.path.join(output_base_path, f"{experiment_name}_{timestamp}")
    
    if not os.path.exists(versioned_dir):
        os.makedirs(versioned_dir)

    # Requirement 4: Save only the adapter weights
    # This specifically saves adapter_model.bin and adapter_config.json
    model.save_pretrained(versioned_dir)
    
    # Requirement 3: Save the tokenizer (essential for inference)
    tokenizer.save_pretrained(versioned_dir)
    
    # Requirement 5: Metadata for reproducibility
    metadata = {
        "experiment_name": experiment_name,
        "timestamp": timestamp,
        "base_model": model.config._name_or_path,
        "learning_rate": 2e-4,
    }
    with open(os.path.join(versioned_dir, "train_meta.json"), "w") as f:
        json.dump(metadata, f, indent=4)

    # Requirement 6: Path Validation Sanity Check
    required_files = ["adapter_config.json", "tokenizer_config.json"]
    existing_files = os.listdir(versioned_dir)
    for req in required_files:
        if req in existing_files:
            print(f"✓ Verified: {req} exists in {versioned_dir}")
        else:
            print(f"⚠ Warning: {req} missing!")

# Example usage:
# save_tunable_parameters(model, tokenizer, "outputs", "llama3_8b_qlora")

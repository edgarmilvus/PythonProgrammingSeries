
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from transformers import TrainingArguments
from trl import SFTTrainer

def get_advanced_training_config(model, train_dataset, tokenizer):
    # Requirement 2: Dynamic Gradient Accumulation
    target_total_batch_size = 32
    micro_batch_size = 2
    accumulation_steps = target_total_batch_size // micro_batch_size

    # Requirement 1, 3, 4, 6: Advanced Training Arguments
    training_args = TrainingArguments(
        output_dir="./qlora_results",
        per_device_train_batch_size=micro_batch_size,
        gradient_accumulation_steps=accumulation_steps,
        # Paged Optimizer: Maps states to CPU RAM if GPU VRAM is full
        optim="paged_adamw_32bit", 
        learning_rate=2e-4,
        lr_scheduler_type="cosine", # Requirement 6: Cosine scheduler
        warmup_ratio=0.1,
        logging_steps=10,
        num_train_epochs=1,
        # Requirement 4: Gradient Checkpointing
        gradient_checkpointing=True,
        fp16=not torch.cuda.is_bf16_supported(),
        bf16=torch.cuda.is_bf16_supported(),
        group_by_length=True # Requirement 5: Dynamic Padding efficiency
    )

    # Requirement 5: Max Sequence Length and SFTTrainer
    trainer = SFTTrainer(
        model=model,
        train_dataset=train_dataset,
        args=training_args,
        max_seq_length=2048,
        tokenizer=tokenizer,
        dataset_text_field="text",
    )
    
    return trainer

# Note: Gradient Checkpointing saves VRAM by discarding intermediate activations 
# during the forward pass and re-calculating them during the backward pass.


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import torch
import time
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel
import os

def merge_and_benchmark(base_model_id, adapter_path, test_prompt):
    # Requirement 1: Load in high precision (FP16/BF16)
    # Merging is a linear algebra operation (W_new = W_base + (A * B))
    # This cannot be done accurately in 4-bit space.
    dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
    
    base_model = AutoModelForCausalLM.from_pretrained(
        base_model_id, torch_dtype=dtype, device_map="cpu" # Load to CPU first to save VRAM
    )
    
    # Requirement 2: Attach Adapter
    model = PeftModel.from_pretrained(base_model, adapter_path)
    
    # Benchmark Unmerged
    model.to("cuda")
    start = time.time()
    _ = model.generate(**tokenizer(test_prompt, return_tensors="pt").to("cuda"), max_new_tokens=100)
    unmerged_time = time.time() - start

    # Requirement 3: The Merge Operation
    # Mathematically combines the LoRA matrices into the base weights
    model = model.merge_and_unload()
    
    # Benchmark Merged
    start = time.time()
    _ = model.generate(**tokenizer(test_prompt, return_tensors="pt").to("cuda"), max_new_tokens=100)
    merged_time = time.time() - start

    # Requirement 5: Comparison
    improvement = ((unmerged_time - merged_time) / unmerged_time) * 100
    print(f"Unmerged: {unmerged_time:.2f}s | Merged: {merged_time:.2f}s")
    print(f"Speed Improvement: {improvement:.2f}%")

    # Requirement 6: Final Sharded Export
    export_path = os.path.join("models", "merged_model_final")
    model.save_pretrained(export_path, max_shard_size="5GB")

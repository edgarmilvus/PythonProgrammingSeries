
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import torch

class PromptManager:
    def __init__(self, tokenizer):
        self.tokenizer = tokenizer
        # Requirement 1 & 2: Centralized Template (DRY)
        self.template = (
            "### System:\nYou are a helpful assistant.\\n\\n"
            "### Instruction:\n{instruction}\\n\\n"
            "### Response:\n"
        )

    def format_and_tokenize(self, data_point):
        # Requirement 3 & 5: Format string and handle EOS
        full_prompt = self.template.format(instruction=data_point["instruction"])
        full_text = full_prompt + data_point["response"] + self.tokenizer.eos_token
        
        tokenized = self.tokenizer(
            full_text, 
            truncation=True, 
            padding=False, 
            return_tensors=None
        )
        
        # Requirement 4: Label Masking
        # Tokenize only the prompt to find its length
        prompt_tokenized = self.tokenizer(
            full_prompt, 
            truncation=True, 
            padding=False, 
            return_tensors=None
        )
        prompt_len = len(prompt_tokenized["input_ids"])
        
        # Labels are a copy of input_ids, but prompt tokens are replaced with -100
        labels = list(tokenized["input_ids"])
        labels[:prompt_len] = [-100] * prompt_len
        
        tokenized["labels"] = labels
        return tokenized

    def validate_example(self, tokenized_data):
        # Requirement 6: Visual Validation
        labels = tokenized_data["labels"]
        # Filter out -100 to see what the model actually learns
        learned_tokens = [t for t in labels if t != -100]
        decoded_response = self.tokenizer.decode(learned_tokens)
        print(f"--- Validated Learned Content ---\n{decoded_response}\n-------------------------------")

# Example usage:
# manager = PromptManager(tokenizer)
# tokenized = manager.format_and_tokenize({"instruction": "Explain QLoRA", "response": "It is efficient."})
# manager.validate_example(tokenized)

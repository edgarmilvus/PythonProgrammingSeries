
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import os
import torch
from abc import ABC
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
    TrainingArguments,
    pipeline
)
from peft import (
    LoraConfig,
    get_peft_model,
    prepare_model_for_kbit_training
)
from trl import SFTTrainer
from datasets import load_dataset

# 1. SETUP AND PATH CONFIGURATION
# We use os.path.join to ensure our checkpoint paths work across Linux and Windows
model_id = "meta-llama/Meta-Llama-3-8B"
output_directory = os.path.join(".", "llama3-8b-qlora-output")

# 2. QUANTIZATION CONFIGURATION (The 'Q' in QLoRA)
# This configures the 4-bit NormalFloat quantization and double quantization
compute_dtype = getattr(torch, "float16")
bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=compute_dtype,
    bnb_4bit_use_double_quant=True,
)

# 3. LOAD TOKENIZER AND MODEL
# The model is loaded directly into 4-bit to save VRAM immediately
tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True)
tokenizer.pad_token = tokenizer.eos_token
tokenizer.padding_side = "right"

model = AutoModelForCausalLM.from_pretrained(
    model_id,
    quantization_config=bnb_config,
    device_map={"": 0} # Map the entire model to the first GPU
)

# 4. PREPARE MODEL FOR K-BIT TRAINING
# This function handles gradient checkpointing and freezing base weights
model.config.use_cache = False
model = prepare_model_for_kbit_training(model)

# 5. LORA CONFIGURATION (The 'LoRA' in QLoRA)
# We define the rank (r) and alpha for the low-rank adapters
peft_config = LoraConfig(
    lora_alpha=16,
    lora_dropout=0.1,
    r=64,
    bias="none",
    task_type="CAUSAL_LM",
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj"]
)

# 6. ATTACH ADAPTERS
# Instead of fine-tuning 8 billion parameters, we tune only a few million
model = get_peft_model(model, peft_config)

# 7. TRAINING ARGUMENTS
# We use paged_adamw_32bit to offload optimizer states to CPU RAM if needed
training_arguments = TrainingArguments(
    output_dir=output_directory,
    per_device_train_batch_size=4,
    gradient_accumulation_steps=2,
    optim="paged_adamw_32bit",
    save_steps=25,
    logging_steps=10,
    learning_rate=2e-4,
    fp16=True,
    max_grad_norm=0.3,
    max_steps=100,
    warmup_ratio=0.03,
    group_by_length=True,
    lr_scheduler_type="constant",
)

# 8. DATASET LOADING
# A dummy dataset for the 'Hello World' example
dataset = load_dataset("json", data_files={"train": "training_data.jsonl"}, split="train")

# 9. INITIALIZE TRAINER
# SFTTrainer simplifies the supervised fine-tuning workflow
trainer = SFTTrainer(
    model=model,
    train_dataset=dataset,
    peft_config=peft_config,
    dataset_text_field="text",
    max_seq_length=512,
    tokenizer=tokenizer,
    args=training_arguments,
)

# 10. EXECUTE TRAINING
# This starts the optimization process
trainer.train()

# 11. SAVE THE ADAPTERS
# We save only the small adapter weights, not the full 8B model
final_model_path = os.path.join(output_directory, "final_adapter_weights")
trainer.model.save_pretrained(final_model_path)

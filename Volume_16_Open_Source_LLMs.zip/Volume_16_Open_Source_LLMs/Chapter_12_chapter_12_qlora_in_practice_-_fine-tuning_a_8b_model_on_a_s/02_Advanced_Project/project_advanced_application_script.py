
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import torch
from datasets import Dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
    TrainingArguments,
    pipeline
)
from peft import LoraConfig, prepare_model_for_kbit_training, get_peft_model
from trl import SFTTrainer

# --- Configuration & Problem Framing ---
# Objective: Fine-tune Llama-3-8B to transform transcripts into SOAP notes.
MODEL_ID = "meta-llama/Meta-Llama-3-8B"
OUTPUT_DIR = "./medical_scribe_llama3"

# 1. BitsAndBytes Configuration (The "Q" in QLoRA)
# We use NF4 (NormalFloat 4) which is optimal for normally distributed weights.
bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.bfloat16,
    bnb_4bit_use_double_quant=True,  # Quantizes the quantization constants for extra savings
)

# 2. Load Tokenizer and Model
# POLA: We use the official padding side for Llama-3 to ensure predictable behavior.
tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
tokenizer.pad_token = tokenizer.eos_token
tokenizer.padding_side = "right"

model = AutoModelForCausalLM.from_pretrained(
    MODEL_ID,
    quantization_config=bnb_config,
    device_map="auto", # Automatically balances across available GPU memory
    trust_remote_code=True
)

# 3. Prepare Model for k-bit Training
# This enables gradient checkpointing and casts non-trainable layers to appropriate types.
model = prepare_model_for_kbit_training(model)

# 4. LoRA Configuration (The "LoRA" in QLoRA)
# rank (r) determines the size of the update matrices. Higher = more capacity.
peft_config = LoraConfig(
    r=16, 
    lora_alpha=32,
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj"], # Target all linear layers for best results
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM"
)

model = get_peft_model(model, peft_config)

# 5. Mock Dataset Preparation (EAFP implementation)
# We assume the data exists; if not, we handle the exception gracefully.
def get_medical_data():
    try:
        # Real-world scenario: Loading from a local JSONL file
        raw_data = [
            {"instruction": "Convert to SOAP", "input": "Patient says head hurts for 3 days.", "output": "S: Cephalgia x3 days. O: N/A. A: Acute headache. P: Monitor."}
        ]
        return Dataset.from_list(raw_data)
    except Exception as e:
        print(f"Data loading failed: {e}. Falling back to empty dataset.")
        return Dataset.from_list([])

train_dataset = get_medical_data()

# 6. Training Arguments
# PagedAdamW is critical: it offloads optimizer states to CPU RAM when VRAM is full.
training_args = TrainingArguments(
    output_dir=OUTPUT_DIR,
    per_device_train_batch_size=4,
    gradient_accumulation_steps=4,
    learning_rate=2e-4,
    logging_steps=10,
    num_train_epochs=3,
    bf16=True, # Use bfloat16 for stability on Ampere+ GPUs
    optim="paged_adamw_32bit",
    save_strategy="epoch",
    report_to="none"
)

# 7. Trainer Initialization
trainer = SFTTrainer(
    model=model,
    train_dataset=train_dataset,
    peft_config=peft_config,
    dataset_text_field="output", # Simplified for mock; usually requires a formatting function
    max_seq_length=512,
    tokenizer=tokenizer,
    args=training_args,
)

# 8. Execution
# We use EAFP here to ensure that if the GPU OOMs, we can attempt a clean exit.
try:
    print("Starting Fine-Tuning...")
    trainer.train()
    trainer.model.save_pretrained(OUTPUT_DIR)
    print(f"Model saved to {OUTPUT_DIR}")
except RuntimeError as e:
    if "out of memory" in str(e):
        print("VRAM Limit Exceeded. Reduce batch size or sequence length.")
    else:
        raise e

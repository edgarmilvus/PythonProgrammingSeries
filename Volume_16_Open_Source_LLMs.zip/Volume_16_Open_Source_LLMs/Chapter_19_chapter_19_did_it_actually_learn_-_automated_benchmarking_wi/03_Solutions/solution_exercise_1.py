
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import subprocess
import os
from datetime import datetime

def run_baseline_evaluation(model_path="microsoft/Phi-3-mini-4k-instruct"):
    # 1. Setup naming and directory structure
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = "results"
    os.makedirs(output_dir, exist_ok=True)
    output_path = f"{output_dir}/base_model_eval_{timestamp}.json"
    
    # 2. Construct the CLI command for LM Evaluation Harness
    # We use subprocess to trigger the CLI as it is the standard entry point
    command = [
        "lm_eval",
        "--model", "hf",
        "--model_args", f"pretrained={model_path},load_in_4bit=True",
        "--tasks", "mmlu,gsm8k",
        "--device", "cuda:0",
        "--batch_size", "auto",
        "--output_path", output_path,
        "--log_samples"
    ]
    
    print(f"Starting evaluation for {model_path}...")
    try:
        result = subprocess.run(command, check=True, capture_output=True, text=True)
        print(f"Evaluation complete. Results saved to {output_path}")
    except subprocess.CalledProcessError as e:
        print(f"Error during evaluation: {e.stderr}")

if __name__ == "__main__":
    # Ensure environment is ready: pip install git+https://github.com/EleutherAI/lm-evaluation-harness.git
    run_baseline_evaluation()

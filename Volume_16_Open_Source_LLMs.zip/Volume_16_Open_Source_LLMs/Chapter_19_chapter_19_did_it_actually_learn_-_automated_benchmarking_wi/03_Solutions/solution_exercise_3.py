
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import lm_eval
from lm_eval.models.huggingface import HFLM
from pathlib import Path
import pandas as pd
import torch
import logging

logging.basicConfig(level=logging.INFO)

def orchestrate_model_zoo(checkpoint_dir, tasks=["arc_challenge", "hellaswag"]):
    results_list = []
    checkpoint_path = Path(checkpoint_dir)
    
    # Find all subdirectories containing a config.json (HF indicator)
    models = [p.parent for p in checkpoint_path.rglob("config.json")]
    
    for model_p in models:
        model_name = model_p.name
        logging.info(f"Evaluating model: {model_name}")
        
        try:
            # Load model via internal API
            lm_obj = HFLM(pretrained=str(model_p), device="cuda", batch_size="auto")
            
            # Execute evaluation
            eval_results = lm_eval.simple_evaluate(
                model=lm_obj,
                tasks=tasks,
                limit=100 # For quick testing; remove for full eval
            )
            
            # Flatten results for the CSV
            row = {"model": model_name}
            for task, metrics in eval_results["results"].items():
                row[f"{task}_acc"] = metrics.get("acc,none", metrics.get("acc", 0))
            
            results_list.append(row)
            
            # Cleanup
            del lm_obj
            torch.cuda.empty_cache()
            
        except Exception as e:
            logging.error(f"Failed to evaluate {model_name}: {str(e)}")

    # Aggregate and save
    df = pd.DataFrame(results_list)
    df["average_score"] = df.select_dtypes(include='number').mean(axis=1)
    df.sort_values(by="average_score", ascending=False).to_csv("master_report.csv", index=False)

if __name__ == "__main__":
    orchestrate_model_zoo("./checkpoints")

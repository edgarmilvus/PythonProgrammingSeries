
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import subprocess
import json
from pathlib import Path
import torch

def run_sensitivity_study(model_name="mistralai/Mistral-7B-v0.1"):
    shot_counts = [0, 3, 5]
    results_summary = {}
    output_dir = Path("truthfulqa_analysis")
    output_dir.mkdir(exist_ok=True)

    for shots in shot_counts:
        output_file = output_dir / f"truthfulqa_{shots}shot_results.json"
        
        print(f"Running {shots}-shot evaluation...")
        
        cmd = [
            "lm_eval", "--model", "hf",
            "--model_args", f"pretrained={model_name}",
            "--tasks", "truthfulqa_mc1",
            "--num_fewshot", str(shots),
            "--device", "cuda:0",
            "--batch_size", "auto",
            "--output_path", str(output_file)
        ]
        
        subprocess.run(cmd, check=True)
        
        # Clear CUDA cache between runs to prevent fragmentation
        torch.cuda.empty_cache()

        # Extract results for the comparison table
        with open(output_file, "r") as f:
            data = json.load(f)
            # Accessing the specific metric for TruthfulQA Multiple Choice 1
            acc = data["results"]["truthfulqa_mc1"]["acc,none"]
            results_summary[shots] = acc

    # Print Comparison Table
    print("\n--- Sensitivity Analysis: TruthfulQA MC1 ---")
    print(f"{'Shots':<10} | {'Accuracy (acc)':<15}")
    print("-" * 30)
    for s, a in results_summary.items():
        print(f"{s:<10} | {a:<15.4f}")

if __name__ == "__main__":
    run_sensitivity_study()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import json

def analyze_failures(log_samples_path):
    with open(log_samples_path, 'r') as f:
        samples = json.load(f)
    
    print("--- Diagnostic Analysis of GSM8K Failures ---")
    for i, sample in enumerate(samples[:5]): # Inspect first 5 failures
        question = sample['doc']['question']
        model_output = sample['filtered_resps'][0]
        target = sample['doc']['answer']
        
        # Look for medical terminology leakage
        if any(term in model_output.lower() for term in ["patient", "diagnosis", "dosage"]):
            print(f"Sample {i}: Medical Leakage Detected!")
            print(f"Output: {model_output}\n")
        else:
            print(f"Sample {i}: Logic Error (No medical leakage detected).\n")

# Conceptual Strategy for Version 2:
# 1. Implement a Rehearsal Dataset: Mix 10% of GSM8K/MMLU data into the medical training set.
# 2. Switch to LoRA: Freeze the base weights to preserve general reasoning.
# 3. Reduce Learning Rate: Prevent the weights from moving too far from the base baseline.

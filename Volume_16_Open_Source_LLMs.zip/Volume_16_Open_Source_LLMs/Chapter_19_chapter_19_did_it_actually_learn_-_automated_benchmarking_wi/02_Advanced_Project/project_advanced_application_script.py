
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import json
import logging
from datetime import datetime
from typing import List, Dict, Any
from lm_eval import evaluator, utils
from lm_eval.models.huggingface import HFLM

# Configure logging for professional traceability
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class ModelBenchmarkSuite:
    """
    A programmatic wrapper for the EleutherAI LM Evaluation Harness to facilitate
    automated benchmarking of fine-tuned models against base models.
    """

    def __init__(self, model_path: str, device: str = "cuda", batch_size: int = 8):
        self.model_path = model_path
        self.device = device
        self.batch_size = batch_size
        # Initialize the model wrapper for lm-eval
        # We use HFLM for HuggingFace models; vLLM can be substituted for speed
        self.lm_obj = HFLM(pretrained=model_path, device=device, batch_size=batch_size)

    def run_evaluation(self, tasks: List[str], num_fewshot: int = 0) -> Dict[str, Any]:
        """
        Executes the benchmark for a specified list of tasks.
        """
        logger.info(f"Starting evaluation for model: {self.model_path}")
        logger.info(f"Tasks: {tasks} | Few-shot: {num_fewshot}")

        # simple_evaluate is the core entry point for the harness
        results = evaluator.simple_evaluate(
            model=self.lm_obj,
            tasks=tasks,
            num_fewshot=num_fewshot,
            batch_size=self.batch_size,
            device=self.device,
            limit=None  # Set to an integer (e.g., 10) for quick debugging
        )
        
        return results

    def process_results(self, results: Dict[str, Any]) -> Dict[str, float]:
        """
        Extracts and flattens core metrics from the complex nested results dictionary.
        """
        extracted_metrics = {}
        for task_name, metrics in results["results"].items():
            # We prioritize 'acc' or 'acc_norm' depending on the task's standard
            metric_key = "acc_norm" if "acc_norm" in metrics else "acc"
            if metric_key in metrics:
                extracted_metrics[task_name] = metrics[metric_key]
            
            # Special handling for GSM8K which uses 'exact_match'
            if "exact_match,none" in metrics:
                extracted_metrics[task_name] = metrics["exact_match,none"]
                
        return extracted_metrics

    def save_report(self, raw_results: Dict[str, Any], summary: Dict[str, float]):
        """
        Persists results to disk for historical tracking.
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        model_name = os.path.basename(self.model_path.rstrip("/"))
        filename = f"bench_report_{model_name}_{timestamp}.json"
        
        report_data = {
            "metadata": {
                "model": self.model_path,
                "timestamp": timestamp,
                "config": raw_results["config"]
            },
            "summary": summary,
            "raw_results": raw_results["results"]
        }
        
        with open(filename, "w") as f:
            json.dump(report_data, f, indent=4)
        logger.info(f"Report saved to {filename}")

def main():
    # Configuration for the evaluation run
    BASE_MODEL = "meta-llama/Meta-Llama-3-8B"
    FINE_TUNED_MODEL = "./outputs/medical-llama-3-8b-final"
    BENCHMARK_TASKS = ["gsm8k", "truthfulqa_mc2", "mmlu_anatomy", "mmlu_clinical_knowledge"]
    FEW_SHOT_COUNT = 5

    models_to_test = [BASE_MODEL, FINE_TUNED_MODEL]
    comparison_table = {}

    for model_path in models_to_test:
        try:
            # 1. Initialize the benchmark suite
            suite = ModelBenchmarkSuite(model_path=model_path)
            
            # 2. Run the evaluation
            raw_data = suite.run_evaluation(tasks=BENCHMARK_TASKS, num_fewshot=FEW_SHOT_COUNT)
            
            # 3. Process and summarize
            summary = suite.process_results(raw_data)
            comparison_table[model_path] = summary
            
            # 4. Save detailed report
            suite.save_report(raw_data, summary)
            
        except Exception as e:
            logger.error(f"Failed to evaluate {model_path}: {str(e)}")

    # Final Comparison Output
    print("\n" + "="*50)
    print("FINAL BENCHMARK COMPARISON")
    print("="*50)
    header = f"{'Task':<30} | {'Base Model':<15} | {'Fine-Tuned':<15}"
    print(header)
    print("-" * len(header))
    
    for task in BENCHMARK_TASKS:
        base_val = comparison_table.get(BASE_MODEL, {}).get(task, 0.0)
        ft_val = comparison_table.get(FINE_TUNED_MODEL, {}).get(task, 0.0)
        print(f"{task:<30} | {base_val:<15.4f} | {ft_val:<15.4f}")

if __name__ == "__main__":
    main()

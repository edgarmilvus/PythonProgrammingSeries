
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import lm_eval
from lm_eval.models.huggingface import HFLM
from lm_eval.utils import make_table

def run_basic_evaluation():
    # 1. Initialize the model wrapper
    # We use the HFLM class to interface with Hugging Face models.
    # 'pretrained' specifies the model ID from the Hugging Face Hub.
    # 'device' ensures we use the GPU (cuda) if available for speed.
    model_wrapper = HFLM(
        pretrained="HuggingFaceTB/SmolLM-135M",
        device="cuda", 
        batch_size=1
    )

    # 2. Execute the evaluation
    # simple_evaluate is the primary entry point for the harness.
    # 'tasks' is a list of benchmarks we want to run.
    # 'limit' restricts the number of questions to 10 (perfect for a quick test).
    # 'num_fewshot' sets how many examples the model sees before the question (0 = Zero-Shot).
    results = lm_eval.simple_evaluate(
        model=model_wrapper,
        tasks=["arc_easy"],
        num_fewshot=0,
        limit=10
    )

    # 3. Extract and display the results
    # The results object is a dictionary containing comprehensive metadata.
    # we use make_table to format the raw data into a readable CLI table.
    print("--- Evaluation Results ---")
    print(make_table(results))

    # 4. Accessing a specific boolean metric
    # We can check if the accuracy meets a certain threshold.
    accuracy = results["results"]["arc_easy"]["acc,none"]
    passed_threshold = bool(accuracy > 0.5)
    
    print(f"\nTask: ARC Easy")
    print(f"Accuracy: {accuracy:.2%}")
    print(f"Passed Sanity Check: {passed_threshold}")

if __name__ == "__main__":
    run_basic_evaluation()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import json
import requests
from flask import Flask, request, jsonify, Blueprint

# --- BLUEPRINT DEFINITION ---
# We use a Blueprint to modularize the AI triage logic, making it 
# easier to integrate into larger enterprise applications.
triage_bp = Blueprint('triage', __name__)

# --- LLM MEMORY SIMULATION ---
# A simple in-memory store to track conversation history per user.
# In a production environment, this would be backed by Redis or a database.
session_memory = {}

def get_ollama_response(prompt, model="llama3", history=None):
    """
    Sends a request to the local Ollama REST API.
    Integrates session memory by prepending history to the prompt.
    """
    url = "http://localhost:11434/api/generate"
    
    # Constructing the context-aware prompt
    full_prompt = ""
    if history:
        full_prompt += "Previous Context:\n" + "\n".join(history) + "\n\n"
    full_prompt += f"Current Ticket: {prompt}\n\nTask: Classify and Summarize."

    payload = {
        "model": model,
        "prompt": full_prompt,
        "stream": False,
        "format": "json"
    }
    
    # Execute the POST request to the local Ollama service
    response = requests.post(url, json=payload)
    if response.status_code == 200:
        return response.json().get('response')
    return "Error: Unable to reach Ollama."

@triage_bp.route('/triage', methods=['POST'])
def handle_triage():
    """
    API Endpoint to process incoming support tickets.
    Uses memory to maintain state across multiple turns.
    """
    data = request.json
    user_id = data.get('user_id', 'anonymous')
    ticket_text = data.get('text', '')

    # Initialize memory for new users
    if user_id not in session_memory:
        session_memory[user_id] = []

    # Retrieve history and get AI response
    history = session_memory[user_id]
    ai_analysis = get_ollama_response(ticket_text, history=history)

    # Update memory with the current interaction
    session_memory[user_id].append(f"User: {ticket_text}")
    session_memory[user_id].append(f"AI: {ai_analysis}")

    return jsonify({
        "status": "success",
        "analysis": json.loads(ai_analysis),
        "history_depth": len(session_memory[user_id])
    })

# --- MONKEY PATCHING FOR TESTING ---
# This logical block demonstrates how to replace the actual API call 
# with a mock function to test the Flask logic without running the LLM.
def mock_ollama_response(prompt, model=None, history=None):
    return json.dumps({
        "category": "Technical Support",
        "priority": "High",
        "summary": "Mocked response for testing purposes."
    })

# To enable monkey patching, uncomment the line below:
# get_ollama_response = mock_ollama_response

# --- APP INITIALIZATION ---
def create_app():
    app = Flask(__name__)
    # Register the AI Blueprint
    app.register_blueprint(triage_bp, url_prefix='/api/v1')
    return app

if __name__ == "__main__":
    # Start the local development server
    app = create_app()
    print("Local AI Triage Engine Running on http://127.0.0.1:5000")
    app.run(debug=True, port=5000)

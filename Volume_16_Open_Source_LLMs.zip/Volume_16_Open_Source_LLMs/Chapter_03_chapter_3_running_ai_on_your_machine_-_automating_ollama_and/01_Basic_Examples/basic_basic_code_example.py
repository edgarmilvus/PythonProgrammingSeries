
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import requests  # Library to handle HTTP requests to the Ollama API
import json      # Library to parse the JSON data returned by the model

def call_local_llm(prompt_text):
    """
    Sends a prompt to a local Ollama instance and returns the generated text.
    This function demonstrates the basic 'Hello World' of AI automation.
    """
    
    # The endpoint for Ollama's generation API on a standard local installation
    url = "http://localhost:11434/api/generate"
    
    # The payload defines the model to use and the prompt to send.
    # We set 'stream' to False to get a single, complete JSON object back.
    payload = {
        "model": "llama3",
        "prompt": prompt_text,
        "stream": False
    }

    try:
        # EAFP approach: We assume the server is up and the request will work.
        # We 'Ask for Forgiveness' in the except block if it fails.
        response = requests.post(url, json=payload, timeout=30)
        
        # Raise an exception if the HTTP request returned an error code (e.g., 404 or 500)
        response.raise_for_status()
        
        # Parse the raw text response into a Python dictionary
        data = response.json()
        
        # Extract the 'response' field, which contains the LLM's output
        return data.get("response", "No response field found in JSON.")

    except requests.exceptions.ConnectionError:
        # This handles the case where Ollama is not running
        return "Error: Could not connect to Ollama. Is the server running?"
    
    except Exception as e:
        # Catch-all for other potential issues like timeouts or invalid JSON
        return f"An unexpected error occurred: {e}"

# --- Execution Block ---
if __name__ == "__main__":
    # A simple Boolean check is often used in larger scripts to toggle features,
    # but here we directly define our 'Hello World' prompt.
    user_prompt = "Explain the concept of 'Local LLMs' in one short sentence."
    
    print("Sending request to local AI...")
    result = call_local_llm(user_prompt)
    
    print("\n--- AI Response ---")
    print(result)

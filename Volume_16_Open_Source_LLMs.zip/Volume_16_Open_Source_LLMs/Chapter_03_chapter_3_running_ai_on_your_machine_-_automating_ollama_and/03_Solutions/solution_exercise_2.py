
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import time
import sys
from llama_cpp import Llama

def load_governed_model(model_path, vram_gb):
    # 1. Dynamic Parameter Scaling
    if vram_gb < 4:
        gpu_layers = 0
    elif 4 <= vram_gb <= 8:
        gpu_layers = 20
    else:
        gpu_layers = 32  # Offload all layers for a standard 7B model

    print(f"Configuring model with {gpu_layers} GPU layers (Budget: {vram_gb}GB)...")

    try:
        # 2. Model Loading Logic
        start_load = time.time()
        llm = Llama(
            model_path=model_path,
            n_gpu_layers=gpu_layers,
            n_ctx=2048,
            verbose=False
        )
        load_time = time.time() - start_load

        # 3. Inference Test
        start_gen = time.time()
        output = llm("Q: Explain the concept of quantization. A:", max_tokens=50)
        gen_time = time.time() - start_gen

        print(f"\nResponse: {output['choices'][0]['text']}")
        print(f"\n--- Performance Metrics ---")
        print(f"Load Time: {load_time:.2f}s")
        print(f"Generation Time: {gen_time:.2f}s")

    except ValueError:
        print(f"[ERROR] Model file not found at: {model_path}")
        sys.exit(1)
    except Exception as e:
        print(f"[ERROR] Model failed to initialize: {e}")
        sys.exit(1)

if __name__ == "__main__":
    # Example: User provides 6GB VRAM budget
    load_governed_model("path/to/your/model.gguf", vram_gb=6)

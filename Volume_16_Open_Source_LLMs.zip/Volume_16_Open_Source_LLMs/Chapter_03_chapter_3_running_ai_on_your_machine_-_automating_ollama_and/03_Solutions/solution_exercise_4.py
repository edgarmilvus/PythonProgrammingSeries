
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import requests
import json
import sys

def interactive_session():
    current_model = "llama3"
    system_prompt = "You are a helpful assistant."
    history = []

    print(f"--- AI Persona Swapper (Model: {current_model}) ---")
    print("Commands: /model [name], /system [prompt], /exit")

    while True:
        user_input = input("\n[USER] > ").strip()

        if user_input.lower() == "/exit":
            sys.exit(0)
        elif user_input.startswith("/model "):
            current_model = user_input.split(" ", 1)[1]
            print(f"[SYSTEM] Swapped model to: {current_model}")
            continue
        elif user_input.startswith("/system "):
            system_prompt = user_input.split(" ", 1)[1]
            print(f"[SYSTEM] Updated system prompt.")
            continue

        # Prepare request with history
        history.append({"role": "user", "content": user_input})
        payload = {
            "model": current_model,
            "messages": [{"role": "system", "content": system_prompt}] + history,
            "stream": True
        }

        print("[AI] > ", end="", flush=True)
        full_response = ""
        
        response = requests.post("http://localhost:11434/api/chat", json=payload, stream=True)
        
        for line in response.iter_lines():
            if line:
                chunk = json.loads(line)
                content = chunk.get("message", {}).get("content", "")
                print(content, end="", flush=True)
                full_response += content
        
        history.append({"role": "assistant", "content": full_response})
        print() # New line after stream ends

if __name__ == "__main__":
    interactive_session()

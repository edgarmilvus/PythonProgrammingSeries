
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import requests
import time
import csv

def run_benchmark():
    prompts = [
        "Hello",
        "Explain photosynthesis in one sentence.",
        "Write a short story about a robot learning to paint.",
        "Compare SQL vs NoSQL databases.",
        "Write a 500-word essay on the concept of entropy in thermodynamics."
    ]
    model = "mistral"
    results = []

    for prompt in prompts:
        print(f"Benchmarking prompt: {prompt[:30]}...")
        payload = {"model": model, "prompt": prompt, "stream": False}
        
        try:
            resp = requests.post("http://localhost:11434/api/generate", json=payload, timeout=120)
            data = resp.json()
            
            # Ollama provides durations in nanoseconds
            eval_count = data.get("eval_count", 0)
            eval_duration_sec = data.get("eval_duration", 1) / 1e9
            tps = eval_count / eval_duration_sec if eval_duration_sec > 0 else 0
            
            results.append({
                "prompt": prompt[:50],
                "total_duration": data.get("total_duration", 0) / 1e9,
                "load_duration": data.get("load_duration", 0) / 1e9,
                "eval_count": eval_count,
                "tps": round(tps, 2)
            })
        except Exception as e:
            results.append({"prompt": prompt[:50], "error": str(e)})

    # 1. Data Export
    with open("benchmark_results.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["prompt", "total_duration", "load_duration", "eval_count", "tps", "error"])
        writer.writeheader()
        writer.writerows(results)

    # 2. Resource Cleanup (Unload model)
    requests.post("http://localhost:11434/api/generate", json={"model": model, "keep_alive": 0})
    print("Benchmark complete. Results saved to benchmark_results.csv. Model unloaded.")

if __name__ == "__main__":
    run_benchmark()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import asyncio
import httpx
import time

async def get_model_response(client, model_name, prompt):
    url = "http://localhost:11434/api/generate"
    payload = {"model": model_name, "prompt": prompt, "stream": False}
    
    try:
        response = await client.post(url, json=payload, timeout=30.0)
        response.raise_for_status()
        return model_name, response.json().get("response")
    except Exception as e:
        return model_name, f"Error: {str(e)}"

async def run_consensus():
    models = ["phi3", "tinyllama", "stable-lm"]
    prompt = "If I have three apples and you take away two, how many apples do you have?"
    
    start_time = time.perf_counter()
    
    async with httpx.AsyncClient() as client:
        try:
            # 1. Task Aggregation and Concurrent Execution
            async with asyncio.TaskGroup() as tg:
                tasks = [tg.create_task(get_model_response(client, m, prompt)) for m in models]
            
            results = [t.result() for t in tasks]
            
            # 2. Result Comparison
            print(f"{'MODEL':<15} | {'RESPONSE'}")
            print("-" * 50)
            for model, text in results:
                clean_text = text.replace('\n', ' ').strip()
                print(f"{model:<15} | {clean_text}")
                
        except* Exception as eg: # Handle ExceptionGroup
            for e in eg.exceptions:
                print(f"Task failed: {e}")

    total_duration = time.perf_counter() - start_time
    print(f"\nTotal Concurrent Duration: {total_duration:.2f} seconds")

if __name__ == "__main__":
    asyncio.run(run_consensus())

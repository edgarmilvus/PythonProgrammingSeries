
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import requests
import sys

def run_sentinel():
    base_url = "http://localhost:11434"
    required_models = ["llama3", "mistral", "phi3"]
    
    # 1. Connection Validation
    try:
        response = requests.get(f"{base_url}/api/tags", timeout=5)
        response.raise_for_status()
    except (requests.exceptions.ConnectionError, requests.exceptions.HTTPError):
        print("[CRITICAL] Ollama server unreachable. Ensure the daemon is running.")
        sys.exit(1)

    # 2. Model Inventory Check
    local_models = [m['name'].split(':')[0] for m in response.json().get('models', [])]
    missing_models = [m for m in required_models if m not in local_models]

    if missing_models:
        print(f"[ERROR] Missing required models: {', '.join(missing_models)}")
        print("Please run 'ollama pull <model_name>' for each missing model.")
        sys.exit(1)

    # 3. Metadata Extraction
    print("--- Environment Audit Successful ---")
    for model in required_models:
        print(f"\nInspecting Model: {model}")
        try:
            detail_resp = requests.post(f"{base_url}/api/show", json={"name": model})
            data = detail_resp.json()
            
            print(f"  - Parameters: {data.get('parameters', 'N/A')}")
            print(f"  - License: {data.get('license', 'N/A')[:50]}...")
            print(f"  - Modelfile: Found ({len(data.get('modelfile', ''))} characters)")
        except Exception as e:
            print(f"  - Failed to retrieve details for {model}: {e}")

if __name__ == "__main__":
    run_sentinel()

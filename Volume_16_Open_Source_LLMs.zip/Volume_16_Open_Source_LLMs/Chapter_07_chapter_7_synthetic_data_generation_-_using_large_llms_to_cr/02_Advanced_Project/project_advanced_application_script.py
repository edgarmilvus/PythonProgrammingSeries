
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import json
from typing import List, Dict
from sqlalchemy import create_engine, Column, Integer, String, Text, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from jinja2 import Template
import openai  # Acting as the "Teacher" LLM (e.g., GPT-4o or Llama 3 70B via API)

# --- DATABASE CONFIGURATION (SQLAlchemy) ---
Base = declarative_base()

class SyntheticInstruction(Base):
    """Database model to store generated instruction-response pairs."""
    __tablename__ = 'synthetic_data'
    id = Column(Integer, primary_key=True)
    instruction = Column(Text, nullable=False)
    response = Column(Text, nullable=False)
    complexity_score = Column(Integer)  # Track the "Evol" level
    quality_rating = Column(Float)      # LLM-as-a-Judge score

# Initialize local SQLite database
engine = create_engine('sqlite:///legal_synthetic_data.db')
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)
session = Session()

# --- JINJA2 TEMPLATES ---
# Template for formatting the final LoRA instruction-tuning pair
alpaca_template = """
### Instruction:
{{ instruction }}

### Response:
{{ response }}
"""

# --- CORE LOGIC: EVOL-INSTRUCT & GENERATION ---

class SyntheticDataGenerator:
    def __init__(self, api_key: str):
        self.client = openai.OpenAI(api_key=api_key)

    def evolve_instruction(self, seed: str) -> str:
        """Applies Evol-Instruct logic to make a prompt more complex."""
        evol_prompt = f"Rewrite the following legal prompt to be more complex by adding specific jurisdictional constraints and professional terminology: {seed}"
        response = self.client.chat.completions.create(
            model="gpt-4-turbo",
            messages=[{"role": "user", "content": evol_prompt}]
        )
        return response.choices[0].message.content

    def generate_response(self, instruction: str) -> str:
        """Generates the 'Student' training target from the 'Teacher'."""
        response = self.client.chat.completions.create(
            model="gpt-4-turbo",
            messages=[{"role": "system", "content": "You are an expert legal counsel."},
                      {"role": "user", "content": instruction}]
        )
        return response.choices[0].message.content

    def validate_quality(self, instruction: str, response: str) -> float:
        """LLM-as-a-Judge: Evaluates the quality of the generated pair."""
        judge_prompt = f"Rate the accuracy and professional tone of this legal summary on a scale of 0 to 1. Instruction: {instruction} Response: {response}"
        eval_resp = self.client.chat.completions.create(
            model="gpt-4-turbo",
            messages=[{"role": "user", "content": judge_prompt}]
        )
        try:
            return float(eval_resp.choices[0].message.content.strip())
        except:
            return 0.5

    def run_pipeline(self, seeds: List[str], iterations: int = 2):
        """Main workflow: Evolve -> Generate -> Judge -> Store."""
        for seed in seeds:
            current_prompt = seed
            for i in range(iterations):
                # Step 1: Evolve the prompt (Depth-first evolution)
                evolved_prompt = self.evol_instruction(current_prompt)
                
                # Step 2: Generate the high-quality response
                final_response = self.generate_response(evolved_prompt)
                
                # Step 3: Quality Control (Filtering)
                score = self.validate_quality(evolved_prompt, final_response)
                
                if score > 0.7:  # Only save high-quality data
                    new_entry = SyntheticInstruction(
                        instruction=evolved_prompt,
                        response=final_response,
                        complexity_score=i+1,
                        quality_rating=score
                    )
                    session.add(new_entry)
                    session.commit()
                    print(f"Successfully stored evolved prompt level {i+1}")
                
                current_prompt = evolved_prompt

# --- EXECUTION ---
if __name__ == "__main__":
    # Example seed instructions for a legal SLM
    legal_seeds = [
        "What are the requirements for a valid contract?",
        "Explain the concept of 'Force Majeure' in commercial leases."
    ]
    
    # Initialize generator (Requires OPENAI_API_KEY env var)
    gen = SyntheticDataGenerator(api_key=os.getenv("OPENAI_API_KEY"))
    gen.run_pipeline(legal_seeds)

    # Export to LoRA-ready JSONL using Jinja2 formatting
    all_data = session.query(SyntheticInstruction).all()
    with open("train_data.jsonl", "w") as f:
        template = Template(alpaca_template)
        for entry in all_data:
            formatted_text = template.render(instruction=entry.instruction, response=entry.response)
            f.write(json.dumps({"text": formatted_text}) + "\n")

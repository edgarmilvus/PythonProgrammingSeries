
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import random

base_instructions = [
    "Write a Python function to sort a list of integers.",
    "Create a script to read a CSV file and print the rows.",
    "Write a function that checks if a string is a palindrome.",
    "Implement a basic binary search algorithm.",
    "Write a Python script to merge two dictionaries."
]

evolution_templates = {
    "Constraint": "Rewrite this task: '{task}'. Constraint: Solve it without using any built-in libraries or external modules.",
    "Deepening": "Rewrite this task: '{task}'. Requirement: Explain the memory management and time complexity (Big O) of your approach.",
    "Complicating": "Rewrite this task: '{task}'. Addition: After completing the primary task, format the output as a custom JSON object and log the execution time."
}

def evolve_and_generate(instruction):
    # Select a strategy
    strategy_name = random.choice(list(evolution_templates.keys()))
    evolution_prompt = evolution_templates[strategy_name].format(task=instruction)
    
    # Mock Teacher LLM call to evolve the prompt
    evolved_instruction = f"[EVOLVED via {strategy_name}] " + instruction + " (with added complexity)"
    
    # Mock Teacher LLM call to generate the high-quality response
    response = "Detailed code block and explanation..."
    
    return {
        "original": instruction,
        "evolved": evolved_instruction,
        "strategy": strategy_name,
        "output": response
    }

evolved_dataset = [evolve_and_generate(i) for i in base_instructions]

# Validation Check
for entry in evolved_dataset:
    print(f"Strategy: {entry['strategy']}")
    print(f"Length Increase: {len(entry['evolved']) > len(entry['original'])}")

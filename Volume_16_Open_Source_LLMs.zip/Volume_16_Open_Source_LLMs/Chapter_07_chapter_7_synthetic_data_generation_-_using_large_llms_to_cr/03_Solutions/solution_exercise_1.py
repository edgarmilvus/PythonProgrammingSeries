
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import json
import random
import re

# 1. Seed Management: Initial pool of complex DevOps tasks
task_pool = [
    {"instruction": "Write a bash script to rotate logs in /var/log/nginx older than 7 days.", "input": "", "output": "..." },
    {"instruction": "Explain how to debug a 502 Bad Gateway in Nginx.", "input": "Context: Kubernetes Ingress controller environment.", "output": "..." },
    {"instruction": "Create a Dockerfile for a multi-stage Go build.", "input": "", "output": "..." },
    {"instruction": "Write a Terraform snippet to provision an S3 bucket with versioning enabled.", "input": "", "output": "..." },
    {"instruction": "Configure a Prometheus alert for high CPU usage (>80%) lasting 5 minutes.", "input": "Target: Node Exporter metrics.", "output": "..." }
]

def mock_teacher_llm(prompt):
    """Placeholder for an API call to a frontier model (e.g., GPT-4o)."""
    # In a real scenario, this returns a generated instruction and response
    return {
        "instruction": "Automate the installation of Docker on Ubuntu using Ansible.",
        "input": "Target: Remote web server.",
        "output": "Step 1: Update apt... Step 2: Install docker.io... Step 3: Start service..."
    }

def is_too_similar(new_task, pool, threshold=0.7):
    """Deduplication Logic: Calculates unique word overlap (Jaccard-like)."""
    def get_words(text):
        return set(re.findall(r'\w+', text.lower()))
    
    new_words = get_words(new_task['instruction'])
    for existing_task in pool:
        existing_words = get_words(existing_task['instruction'])
        intersection = new_words.intersection(existing_words)
        union = new_words.union(existing_words)
        if len(intersection) / len(union) > threshold:
            return True
    return False

# 3. The Loop Logic
target_count = 50
while len(task_pool) < target_count:
    # Sample 3 tasks for in-context learning
    seeds = random.sample(task_pool, 3)
    
    # 2. Prompt Engineering: Meta-Prompt
    meta_prompt = f"""
    Analyze these DevOps tasks: {seeds}
    Generate a NEW, unique task within the Systems Administration/DevOps domain.
    Provide a step-by-step solution. 
    Format as JSON: {{"instruction": "...", "input": "...", "output": "..."}}
    """
    
    # Generate and filter
    new_candidate = mock_teacher_llm(meta_prompt)
    if not is_too_similar(new_candidate, task_pool):
        new_candidate['id'] = len(task_pool) + 1
        task_pool.append(new_candidate)

# 5. Output Structure: Save as JSONL
with open('devops_dataset.jsonl', 'w') as f:
    for entry in task_pool:
        f.write(json.dumps(entry) + '\n')

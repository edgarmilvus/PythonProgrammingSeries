
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import json
import re
import random

def format_and_clean(raw_data):
    formatted_list = []
    # 2. System Prompt Injection
    system_prompt = "You are a helpful DevOps assistant specialized in variable-driven web routing."

    for entry in raw_data:
        # 3. URL Converter Validation/Fix
        # Fixes [id] or {id} style to <int:id> or <string:id>
        instruction = entry['instruction']
        instruction = re.sub(r'\[(\w+)\]', r'<string:\1>', instruction)
        
        # 1. Alpaca Conversion
        alpaca_entry = {
            "instruction": f"{system_prompt} {instruction}",
            "input": entry.get("input", ""),
            "output": entry['output']
        }
        formatted_list.append(alpaca_entry)
    
    # 4. Data Splitting
    random.shuffle(formatted_list)
    split_idx = int(len(formatted_list) * 0.9)
    train_data = formatted_list[:split_idx]
    eval_data = formatted_list[split_idx:]
    
    return train_data, eval_data

# Example usage
raw_data = [{"instruction": "Route for [user_id]", "output": "Use the user table."}]
train, eval = format_and_clean(raw_data)

with open('train.jsonl', 'w') as f:
    for item in train: f.write(json.dumps(item) + '\n')

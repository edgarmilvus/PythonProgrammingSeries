
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import json

# 1. Tool Definition
tools = [
    {"name": "search_web", "description": "Search the internet", "parameters": {"query": "string"}},
    {"name": "query_database", "description": "Execute SQL", "parameters": {"sql_query": "string"}}
]

def generate_agentic_trace(user_query):
    # 3. Variable Rules: Logic to ensure URL converters are used
    if "api/user" in user_query:
        action_input = "SELECT * FROM users WHERE id = 123;"
        observation = "User record: {'id': 123, 'name': 'DevOps_Pro'}"
    else:
        action_input = "latest linux kernel version"
        observation = "6.8.1"

    # 2. Synthetic Trace Generation (ReAct pattern)
    trace = f"""
    Thought: The user is asking about a specific resource. I need to use the database tool.
    Action: <TOOL_CALL> {{"tool": "query_database", "query": "{action_input}"}} </TOOL_CALL>
    Observation: <TOOL_RESPONSE> {observation} </TOOL_RESPONSE>
    Final Response: Based on the database, the user ID 123 corresponds to DevOps_Pro.
    """
    return trace

# Example usage with Variable Rules (URL Converters)
instruction = "The user accessed `/api/user/<int:user_id>`. Generate a SQL query to find that specific ID."
agentic_data = {
    "instruction": instruction,
    "thought_action_response": generate_agentic_trace(instruction)
}

print(json.dumps(agentic_data, indent=2))

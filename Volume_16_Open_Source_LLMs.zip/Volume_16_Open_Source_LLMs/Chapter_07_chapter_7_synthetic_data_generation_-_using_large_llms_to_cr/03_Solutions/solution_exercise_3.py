
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
import json

# 4. Environment Configuration
os.environ["MIN_ACCURACY"] = "5"
os.environ["MIN_AVG_SCORE"] = "4.0"

raw_synthetic_data = [
    {"instruction": "How to list files?", "output": "Use 'ls -la' to see all files including hidden ones."},
    {"instruction": "How to delete root?", "output": "Just run rm -rf / without thinking."} # Bad example
]

def judge_pair(instruction, response):
    """Judge Prompting: Returns a mock evaluation based on the rubric."""
    # In reality, this would be a structured JSON output from an LLM
    if "rm -rf /" in response:
        return {"accuracy": 1, "clarity": 5, "format": 5, "justification": "Dangerous/Incorrect advice."}
    return {"accuracy": 5, "clarity": 5, "format": 5, "justification": "Correct and helpful."}

def filter_dataset(data):
    min_acc = int(os.environ.get("MIN_ACCURACY", 5))
    min_avg = float(os.environ.get("MIN_AVG_SCORE", 4.0))
    
    clean_data = []
    for item in data:
        scores = judge_pair(item['instruction'], item['output'])
        avg = (scores['accuracy'] + scores['clarity'] + scores['format']) / 3
        
        # 3. Filtering Logic
        if scores['accuracy'] >= min_acc and avg >= min_avg:
            item['metadata'] = scores
            clean_data.append(item)
    return clean_data

filtered_results = filter_dataset(raw_synthetic_data)
print(f"Retained {len(filtered_results)} of {len(raw_synthetic_data)} items.")

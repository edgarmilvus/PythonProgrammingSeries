
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import json
from typing import List, Optional
from pydantic import BaseModel, Field

# --- STEP 1: Define the Structured Output Schema ---
# We use Pydantic to define exactly what a 'Training Example' looks like.
# This ensures the Teacher LLM provides data in a format our code can parse.
class SyntheticInstruction(BaseModel):
    instruction: str = Field(description="The task or question for the SLM to perform.")
    context: Optional[str] = Field(description="Optional background info or technical specs.")
    response: str = Field(description="The ideal, high-quality answer the SLM should learn.")
    difficulty_score: int = Field(description="A rating from 1-10 of the complexity of the task.")

# --- STEP 2: The Teacher Generation Logic ---
def generate_synthetic_data(topic: str, num_examples: int = 1):
    """
    Simulates a call to a Teacher LLM (like GPT-4) to generate 
    structured training data based on a user-provided topic.
    """
    
    # In a real scenario, you would use an LLM SDK (like OpenAI or Anthropic)
    # here. For this 'Hello World', we simulate the structured response.
    print(f"\n[System] Requesting {num_examples} examples about '{topic}' from Teacher LLM...")
    
    # This mock data represents what a Teacher LLM would return when 
    # constrained by our SyntheticInstruction Pydantic schema.
    mock_teacher_output = {
        "instruction": f"How do I reset the firmware on a {topic} inverter?",
        "context": "The device is showing a 'Error 404' on the LED panel.",
        "response": f"To reset the {topic} firmware, hold the 'Power' and 'Select' buttons for 10 seconds. "
                    "Wait for the green light to flash, then release. The system will reboot in 2 minutes.",
        "difficulty_score": 4
    }

    # Validate the data using our Pydantic model
    # This step is CRITICAL for ensuring the synthetic data is 'clean'.
    try:
        validated_data = SyntheticInstruction(**mock_teacher_output)
        return validated_data
    except Exception as e:
        print(f"Error validating synthetic data: {e}")
        return None

# --- STEP 3: The Interaction Loop ---
def main():
    # We use the input() function to get the domain-specific seed from the user.
    # This allows a human-in-the-loop to guide the synthetic generation.
    seed_topic = input("Enter a technical topic for synthetic data generation: ")
    
    # Generate the data
    training_pair = generate_synthetic_data(seed_topic)
    
    if training_pair:
        print("\n--- GENERATED SYNTHETIC TRAINING PAIR ---")
        # Convert the Pydantic object to a clean JSON string for storage
        json_output = training_pair.model_dump_json(indent=4)
        print(json_output)
        
        # --- STEP 4: Simulated Vector Store / Database Entry ---
        # In a real pipeline, you would now embed this text and save it.
        print("\n[System] Data ready for Vector Store indexing or JSONL export.")
        
        # Saving to a local file (the 'Student's' future textbook)
        with open("synthetic_dataset.jsonl", "a") as f:
            f.write(json.dumps(training_pair.model_dump()) + "\n")
            print("[System] Example appended to synthetic_dataset.jsonl")

if __name__ == "__main__":
    main()

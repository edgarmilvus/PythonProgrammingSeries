
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime

Base = declarative_base()

class ConversationHistory(Base):
    __tablename__ = 'history'
    id = Column(Integer, primary_key=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    user_prompt = Column(Text)
    model_response = Column(Text)
    tokens_used = Column(Integer)
    model_name = Column(String(50))

class MemoryManager:
    def __init__(self, db_url="sqlite:///slm_memory.db"):
        self.engine = create_engine(db_url)
        Base.metadata.create_all(self.engine)
        self.Session = sessionmaker(bind=self.engine)

    def save_interaction(self, prompt, response, tokens, model):
        session = self.Session()
        entry = ConversationHistory(
            user_prompt=prompt,
            model_response=response,
            tokens_used=tokens,
            model_name=model
        )
        session.add(entry)
        session.commit()
        session.close()

    def get_recent_context(self, limit=5):
        session = self.Session()
        rows = session.query(ConversationHistory).order_by(
            ConversationHistory.timestamp.desc()
        ).limit(limit).all()
        
        context_str = ""
        for row in reversed(rows):
            context_str += f"User: {row.user_prompt}\nAI: {row.model_response}\n"
        session.close()
        return context_str

# Usage
if __name__ == "__main__":
    memory = MemoryManager()
    memory.save_interaction("What is an SLM?", "A Small Language Model.", 15, "phi3")
    
    print("Retrieved Context:")
    print(memory.get_recent_context(limit=1))

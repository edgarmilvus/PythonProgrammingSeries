
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import asyncio
from contextvars import ContextVar
import uuid

# Define Context Variables
request_id: ContextVar[str] = ContextVar("request_id")
user_tier: ContextVar[str] = ContextVar("user_tier")
privacy_protocol: ContextVar[str] = ContextVar("privacy_protocol")

async def preprocess_text(text: str):
    # Access context without being passed as an argument
    rid = request_id.get()
    tier = user_tier.get()
    print(f"[{rid}] Preprocessing for {tier} tier...")
    return f"{text} (Sanitized for {privacy_protocol.get()})"

async def call_local_slm(processed_text: str):
    rid = request_id.get()
    # Simulate SLM logic varying by tier
    temp = 0.2 if user_tier.get() == "Enterprise" else 0.7
    print(f"[{rid}] Calling SLM with temp={temp}...")
    await asyncio.sleep(0.1) # Simulate inference
    return f"Response to: {processed_text}"

async def inference_pipeline(text: str, tier: str, protocol: str):
    # Set context at the entry point
    request_id.set(str(uuid.uuid4())[:8])
    user_tier.set(tier)
    privacy_protocol.set(protocol)
    
    # Deeply nested logic calls
    p_text = await preprocess_text(text)
    result = await call_local_slm(p_text)
    print(f"[{request_id.get()}] Pipeline Complete.")
    return result

async def main():
    # Simulate concurrent requests
    task_a = inference_pipeline("Hello Local AI", "Enterprise", "Strict")
    task_b = inference_pipeline("Howdy SLM", "Free", "Relaxed")
    
    results = await asyncio.gather(task_a, task_b)
    print("\nFinal Results:", results)

if __name__ == "__main__":
    asyncio.run(main())

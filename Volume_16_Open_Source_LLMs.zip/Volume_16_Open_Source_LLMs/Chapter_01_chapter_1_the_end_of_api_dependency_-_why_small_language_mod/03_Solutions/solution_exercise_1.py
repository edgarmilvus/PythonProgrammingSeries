
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import asyncio
import time
import httpx
import json

# Configuration
LOCAL_URL = "http://localhost:11434/api/generate"  # Ollama default
REMOTE_URL = "https://api.openai.com/v1/chat/completions"
SENSITIVE_KEYWORDS = ["SSN", "PASSWORD", "SECRET", "INTERNAL_ONLY"]

class PrivacyGate:
    @staticmethod
    def is_safe(prompt: str) -> bool:
        """Returns False if sensitive keywords are found."""
        return not any(key in prompt.upper() for key in SENSITIVE_KEYWORDS)

async def fetch_local(prompt: str):
    start_time = time.perf_counter()
    ttft = None
    async with httpx.AsyncClient(timeout=30.0) as client:
        # We stream to capture Time to First Token (TTFT)
        async with client.stream("POST", LOCAL_URL, json={"model": "phi3", "prompt": prompt}) as response:
            async for line in response.aiter_lines():
                if not ttft:
                    ttft = time.perf_counter() - start_time
                pass # Consuming stream
        total_latency = time.perf_counter() - start_time
        return {"provider": "Local SLM", "ttft": ttft, "total": total_latency}

async def fetch_remote(prompt: str, api_key: str):
    if not PrivacyGate.is_safe(prompt):
        return {"provider": "Remote API", "error": "BLOCKED: Sensitive data detected."}
    
    start_time = time.perf_counter()
    headers = {"Authorization": f"Bearer {api_key}"}
    payload = {"model": "gpt-3.5-turbo", "messages": [{"role": "user", "content": prompt}]}
    
    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(REMOTE_URL, json=payload, headers=headers)
        total_latency = time.perf_counter() - start_time
        return {"provider": "Remote API", "ttft": "N/A (Non-streaming)", "total": total_latency}

async def run_audit(prompt: str):
    print(f"Auditing Prompt: {prompt[:30]}...")
    # Concurrent execution using asyncio.gather
    results = await asyncio.gather(
        fetch_local(prompt),
        fetch_remote(prompt, "sk-placeholder"),
        return_exceptions=True
    )
    for res in results:
        print(json.dumps(res, indent=4))

if __name__ == "__main__":
    test_prompt = "My INTERNAL_ONLY password is '12345'. Summarize this."
    asyncio.run(run_audit(test_prompt))

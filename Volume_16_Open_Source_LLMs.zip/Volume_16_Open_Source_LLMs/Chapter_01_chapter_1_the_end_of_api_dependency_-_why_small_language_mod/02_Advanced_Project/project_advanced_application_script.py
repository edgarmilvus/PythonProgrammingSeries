
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import asyncio
import uuid
import json
import httpx
from datetime import datetime
from contextvars import ContextVar
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# --- GLOBAL STATE MANAGEMENT ---
# contextvars ensures that even in an async environment, 
# the request_id remains unique to the specific execution task.
request_id_var = ContextVar("request_id", default="system")

# --- DATABASE ARCHITECTURE (SQLAlchemy) ---
# We use SQLAlchemy to map our local AI results to a structured SQLite database.
# This ensures data persistence without relying on external cloud databases.
Base = declarative_base()
engine = create_engine('sqlite:///local_ai_audit.db', echo=False)
SessionLocal = sessionmaker(bind=engine)

class AIInferenceLog(Base):
    """SQLAlchemy model to store the results of local SLM processing."""
    __tablename__ = "inference_logs"
    id = Column(Integer, primary_key=True, index=True)
    request_id = Column(String(50))
    input_text = Column(Text)
    model_response = Column(Text)
    sentiment = Column(String(20))
    timestamp = Column(DateTime, default=datetime.utcnow)

# Initialize the local database
Base.metadata.create_all(bind=engine)

# --- LOCAL INFERENCE CLIENT ---
class LocalAIClient:
    """A client to interact with local SLM engines like Ollama or vLLM."""
    
    def __init__(self, base_url="http://localhost:11434/api/generate"):
        self.base_url = base_url

    async def process_text(self, prompt: str, model="mistral"):
        """
        Sends a request to the local SLM. 
        Uses the current context's request_id for logging.
        """
        current_rid = request_id_var.get()
        print(f"[{current_rid}] Sending task to local model: {model}...")
        
        payload = {
            "model": model,
            "prompt": f"Analyze the following text for sentiment and provide a 1-sentence summary: {prompt}",
            "stream": False
        }

        async with httpx.AsyncClient(timeout=60.0) as client:
            try:
                # Non-blocking call to the local AI server
                response = await client.post(self.base_url, json=payload)
                response.raise_for_status()
                return response.json().get("response", "")
            except Exception as e:
                return f"Error in local inference: {str(e)}"

# --- BUSINESS LOGIC LAYER ---
async def run_inference_pipeline(raw_text: str):
    """
    The core pipeline: Sets context, calls the SLM, and persists results via SQLAlchemy.
    """
    # 1. Generate and set a unique ID for this specific task context
    unique_id = str(uuid.uuid4())[:8]
    token = request_id_var.set(unique_id)
    
    try:
        # 2. Instantiate the local client
        ai_client = LocalAIClient()
        
        # 3. Execute the inference (Local SLM)
        # The indentation here defines the block of execution within the async function.
        result = await ai_client.process_text(raw_text)
        
        # 4. Persistence: Save the result to the local SQLite DB using SQLAlchemy
        db = SessionLocal()
        new_log = AIInferenceLog(
            request_id=unique_id,
            input_text=raw_text[:100],  # Log a snippet for auditing
            model_response=result,
            sentiment="Detected" # In a real app, you'd parse this from the SLM response
        )
        db.add(new_log)
        db.commit()
        db.refresh(new_log)
        db.close()
        
        print(f"[{unique_id}] Successfully logged to local database.")
        return result

    finally:
        # Reset context to avoid leaking state to other async tasks
        request_id_var.reset(token)

# --- EXECUTION ENTRY POINT ---
async def main():
    """Simulates a batch of incoming sensitive documents for local processing."""
    sensitive_docs = [
        "The patient shows signs of rapid recovery after the new treatment.",
        "The quarterly earnings report indicates a 15% drop in manufacturing.",
        "User feedback: The new interface is confusing and hard to navigate."
    ]
    
    print("Starting Privacy-Preserving Local Inference Batch...")
    # Run multiple inferences concurrently to demonstrate contextvar safety
    tasks = [run_inference_pipeline(doc) for doc in sensitive_docs]
    results = await asyncio.gather(*tasks)
    
    print("\n--- Final Summary of Local Processing ---")
    for i, res in enumerate(results):
        print(f"Doc {i+1} Result: {res[:75]}...")

if __name__ == "__main__":
    # Standard Python entry point using the asyncio event loop
    asyncio.run(main())

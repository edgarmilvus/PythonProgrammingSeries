
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import asyncio
from typing import Any, Optional

class LLMParameter:
    """Descriptor that enforces type and range constraints for LLM parameters."""
    def __init__(self, min_val: Optional[float] = None, max_val: Optional[float] = None, type_ref: type = float):
        self.min_val = min_val
        self.max_val = max_val
        self.type_ref = type_ref
        self.name = None

    def __set_name__(self, owner, name):
        # Automatically capture the attribute name from the class definition
        self.name = name

    def __set__(self, instance, value):
        # 1. Type Validation
        if not isinstance(value, self.type_ref):
            raise ValueError(f"'{self.name}' must be of type {self.type_ref.__name__}")
        
        # 2. Range Validation
        if self.min_val is not None and value < self.min_val:
            raise ValueError(f"'{self.name}' must be >= {self.min_val}")
        if self.max_val is not None and value > self.max_val:
            raise ValueError(f"'{self.name}' must be <= {self.max_val}")
        
        # Store the validated value in the instance's __dict__
        instance.__dict__[self.name] = value

class GenerationSettings:
    # DRY: Reuse the same descriptor logic for different parameters
    temperature = LLMParameter(min_val=0.0, max_val=2.0, type_ref=float)
    top_p = LLMParameter(min_val=0.0, max_val=1.0, type_ref=float)
    max_tokens = LLMParameter(min_val=1, type_ref=int)

    def __init__(self, temperature=0.7, top_p=0.9, max_tokens=512):
        self.temperature = temperature
        self.top_p = top_p
        self.max_tokens = max_tokens

# --- FastAPI Integration Placeholder ---
# @app.post("/generate")
# async def generate(data: dict):
#     try:
#         # The moment we assign values to GenerationSettings, 
#         # the Descriptor's __set__ triggers validation.
#         settings = GenerationSettings(
#             temperature=data.get("temperature"),
#             max_tokens=data.get("max_tokens")
#         )
#     except ValueError as e:
#         return {"error": str(e)} # Returns 400-style error before LLM is touched

"""
REFLECTIVE COMPONENT:
Using descriptors is superior to Pydantic @validators for 50+ SLMs because it 
encapsulates the 'logic of validation' itself as an object. Instead of writing 
50 methods that check if 'x > 0', you instantiate one 'LLMParameter(min_val=0)'. 
This reduces boilerplate by 90% and ensures that if the validation logic 
needs to change (e.g., adding logging), you change it in one class, not 50 models.
"""

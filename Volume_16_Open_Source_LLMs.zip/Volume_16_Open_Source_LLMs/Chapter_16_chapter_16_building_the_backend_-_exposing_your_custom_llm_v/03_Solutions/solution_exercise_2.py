
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import asyncio
from typing import Dict, List

class TokenStreamBuffer:
    def __init__(self):
        self.full_text = ""
        # Map of sequence string -> list of Futures waiting for it
        self._waiters: Dict[str, List[asyncio.Future]] = {}

    def wait_for_sequence(self, sequence: str) -> asyncio.Future:
        future = asyncio.get_event_loop().create_future()
        if sequence in self.full_text:
            future.set_result(True)
        else:
            self._waiters.setdefault(sequence, []).append(future)
        return future

    def update(self, token: str):
        self.full_text += token
        # Check all pending sequences
        for sequence, futures in list(self._waiters.items()):
            if sequence in self.full_text:
                for fut in futures:
                    if not fut.done():
                        fut.set_result(True)
                del self._waiters[sequence]

# --- FastAPI WebSocket Structure ---
async def websocket_endpoint(websocket, model_engine):
    buffer = TokenStreamBuffer()
    # Create a future to watch for a specific thought-end tag
    stop_signal = buffer.wait_for_sequence("<|end_of_thought|>")

    async for token in model_engine.generate("Explain quantum physics"):
        buffer.update(token)
        await websocket.send_text(token)
        
        # Check if our specific sequence was detected without blocking
        if stop_signal.done():
            print("Stop sequence detected! Triggering secondary logic...")
            # We could break the loop or trigger a tool call here

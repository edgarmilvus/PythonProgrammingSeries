
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import asyncio
import json
import uuid

class ResponseFactory:
    """DRY utility for consistent JSON formatting."""
    @staticmethod
    def format(status: str, data: Any = None, **kwargs) -> str:
        payload = {"status": status, "data": data}
        payload.update(kwargs)
        return json.dumps(payload)

class ConnectionManager:
    def __init__(self, max_concurrent_gens: int = 2):
        self.active_connections: dict = {}
        self.semaphore = asyncio.Semaphore(max_concurrent_gens)

    async def connect(self, websocket, client_id: str):
        await websocket.accept()
        self.active_connections[client_id] = websocket

    def disconnect(self, client_id: str):
        if client_id in self.active_connections:
            del self.active_connections[client_id]

    async def run_generation(self, client_id, model_func):
        websocket = self.active_connections[client_id]
        
        # Check if we need to notify about queuing
        if self.semaphore.locked():
            await websocket.send_text(ResponseFactory.format("queued", position=1))

        async with self.semaphore:
            try:
                # Actual LLM generation logic
                async for token in model_func():
                    await websocket.send_text(ResponseFactory.format("token", token))
            except asyncio.CancelledError:
                # Handle task cancellation if user disconnects
                print(f"Generation for {client_id} cancelled.")
                raise

manager = ConnectionManager()

# --- WebSocket Endpoint ---
# @app.websocket("/ws/{client_id}")
# async def websocket_route(websocket, client_id: str):
#     await manager.connect(websocket, client_id)
#     gen_task = None
#     try:
#         while True:
#             data = await websocket.receive_text()
#             # Create a task so we can cancel it if needed
#             gen_task = asyncio.create_task(manager.run_generation(client_id, mock_gen))
#             await gen_task
#     except Exception:
#         if gen_task:
#             gen_task.cancel() # Free GPU resources immediately
#         manager.disconnect(client_id)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import asyncio
from fastapi import FastAPI, Body, HTTPException
from pydantic import BaseModel, Field
from typing import Optional
import time

# --- DATA MODELING (DRY PRINCIPLE) ---
# We define our schema once using Pydantic. This ensures that 
# every request is validated before it ever reaches our model logic.
class LLMQuery(BaseModel):
    """
    The schema for an incoming LLM request.
    By using Pydantic, we adhere to the DRY (Don't Repeat Yourself) principle
    by defining validation logic once in the class rather than inside the route.
    """
    prompt: str = Field(..., min_length=1, max_length=1000, description="The user input text.")
    max_tokens: Optional[int] = Field(default=50, ge=1, le=500, description="Limit of generated tokens.")
    temperature: Optional[float] = Field(default=0.7, ge=0.0, le=1.0, description="Sampling randomness.")

class LLMResponse(BaseModel):
    """
    The schema for the outgoing response.
    Ensures the client always receives a predictable JSON structure.
    """
    generated_text: str
    processing_time: float
    status: str

# --- THE APPLICATION INSTANCE ---
# This object is the heart of our backend.
app = FastAPI(title="Custom SLM API", description="A basic endpoint for local LLM inference.")

# --- MOCK INFERENCE ENGINE (THE AWAITABLE) ---
async def simulate_llm_inference(prompt: str, tokens: int) -> str:
    """
    This function represents our 'Future'. 
    In a real scenario, this would call model.generate() or a vLLM engine.
    We use 'asyncio.sleep' to simulate the non-blocking wait for GPU computation.
    """
    # Simulate the delay of an LLM thinking (10ms per token)
    await asyncio.sleep(tokens * 0.01) 
    return f"Processed Response: {prompt[::-1]} [End of Stream]"

# --- THE API ENDPOINT ---
@app.post("/generate", response_model=LLMResponse)
async def generate_text(query: LLMQuery = Body(...)):
    """
    The primary endpoint for text generation.
    It takes an LLMQuery, waits for the inference Future to resolve, 
    and returns an LLMResponse.
    """
    start_time = time.perf_counter()

    try:
        # We 'await' the inference. This pauses this specific request
        # but allows the FastAPI event loop to handle other incoming requests.
        result = await simulate_llm_inference(query.prompt, query.max_tokens)
        
        end_time = time.perf_counter()
        
        # Constructing the response object
        return LLMResponse(
            generated_text=result,
            processing_time=round(end_time - start_time, 4),
            status="success"
        )
    except Exception as e:
        # Basic error handling to prevent the server from crashing
        raise HTTPException(status_code=500, detail=f"Inference Error: {str(e)}")

# --- EXECUTION BLOCK ---
if __name__ == "__main__":
    import uvicorn
    # Run the server using Uvicorn, the lightning-fast ASGI server.
    # Access the auto-generated docs at http://127.0.0.1:8000/docs
    uvicorn.run(app, host="127.0.0.1", port=8000)

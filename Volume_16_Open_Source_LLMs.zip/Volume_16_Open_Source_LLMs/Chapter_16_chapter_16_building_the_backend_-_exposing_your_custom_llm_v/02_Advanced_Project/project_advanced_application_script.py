
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import asyncio
import json
import time
from typing import Any, Generator, Optional
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from pydantic import BaseModel

# --- DESCRIPTOR PROTOCOL FOR MODEL MANAGEMENT ---
class ModelDescriptor:
    """
    Implements the Descriptor Protocol to handle lazy loading of the LLM.
    This ensures the model is only loaded into VRAM upon first access,
    adhering to the DRY principle by centralizing loading logic.
    """
    def __init__(self, model_path: str):
        self.model_path = model_path
        self._model = None

    def __get__(self, instance, owner) -> Any:
        if self._model is None:
            print(f"[*] Initializing model from {self.model_path}...")
            # Simulate loading a fine-tuned SLM (e.g., via AutoModelForCausalLM)
            time.sleep(2)  # Simulate I/O overhead
            self._model = f"Loaded-Model-from-{self.model_path}"
        return self._model

# --- INFERENCE ENGINE WITH ASYNC AWAITABLES ---
class InferenceEngine:
    """
    The core engine that bridges the gap between the LLM and the API.
    Uses the ModelDescriptor to manage resources efficiently.
    """
    model = ModelDescriptor(model_path="/models/custom-slm-v1")

    async def generate_stream(self, prompt: str) -> Generator[str, None, None]:
        """
        An Awaitable generator that simulates token-by-token generation.
        In a real scenario, this would wrap vLLM or HuggingFace's TextStreamer.
        """
        # Accessing self.model triggers the Descriptor's __get__ method
        _ = self.model 
        
        dummy_response = f"Response to: {prompt}. This is a simulated stream of tokens."
        for word in dummy_response.split():
            await asyncio.sleep(0.1)  # Simulate GPU computation latency
            yield word + " "

# --- FASTAPI APPLICATION SETUP ---
app = FastAPI(title="Custom SLM Production Backend")
engine = InferenceEngine()

class QueryRequest(BaseModel):
    prompt: str
    max_tokens: int = 128

# --- REST ENDPOINT (FOR SINGLE RESPONSES) ---
@app.post("/generate")
async def generate_blocking(request: QueryRequest):
    """
    Standard REST endpoint for non-streaming applications.
    Uses the engine to collect all tokens before returning.
    """
    full_text = ""
    async for token in engine.generate_stream(request.prompt):
        full_text += token
    return {"response": full_text.strip()}

# --- WEBSOCKET ENDPOINT (FOR REAL-TIME STREAMING) ---
@app.websocket("/ws/stream")
async def websocket_endpoint(websocket: WebSocket):
    """
    WebSocket handler for real-time, bidirectional communication.
    Demonstrates the use of Futures and Awaitables for non-blocking I/O.
    """
    await websocket.accept()
    try:
        while True:
            # Wait for the client to send a JSON payload
            data = await websocket.receive_text()
            payload = json.loads(data)
            prompt = payload.get("prompt", "")

            # Stream tokens back to the client as they are generated
            async for token in engine.generate_stream(prompt):
                await websocket.send_json({"token": token, "status": "generating"})
            
            # Signal the end of the stream
            await websocket.send_json({"token": "", "status": "completed"})
            
    except WebSocketDisconnect:
        print("[!] Client disconnected from WebSocket.")
    except Exception as e:
        print(f"[X] Error: {e}")
        await websocket.close()

# --- HEALTH CHECK ---
@app.get("/health")
async def health():
    return {"status": "online", "model_loaded": engine.model is not None}

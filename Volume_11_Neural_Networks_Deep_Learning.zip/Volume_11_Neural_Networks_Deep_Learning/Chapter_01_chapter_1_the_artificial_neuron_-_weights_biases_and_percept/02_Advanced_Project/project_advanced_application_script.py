
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import sys

# --- 1. CONFIGURATION CONSTANTS (Hypothetical Pre-Trained Weights and Bias) ---

# Weights assigned to the three input features:
# [W_Credit_Score, W_Income_Stability, W_Debt_Ratio]
# Note: Debt Ratio has a negative weight, indicating it decreases the approval chance.
WEIGHTS = np.array([0.65, 0.30, -0.75])

# Bias term: A negative bias means the weighted sum must be significantly positive
# to push the neuron past the zero threshold (requiring high confidence for approval).
BIAS = -0.55

# --- 2. CORE PERCEPTRON COMPONENTS ---

def step_function(net_input: float) -> int:
    """
    The activation function for the Perceptron (Heaviside step function).
    If the net input (weighted sum + bias) is greater than 0, activate (1).
    Otherwise, remain inactive (0).
    """
    if net_input > 0:
        return 1  # Approval
    else:
        return 0  # Denial

def normalize_input(value: float, min_val: float, max_val: float) -> float:
    """
    Normalizes a feature value to the range [0, 1].
    This ensures all inputs contribute fairly to the weighted sum, regardless of their original scale.
    """
    if max_val == min_val:
        return 0.0
    return (value - min_val) / (max_val - min_val)

def perceptron_evaluate(features: np.ndarray) -> tuple[int, float]:
    """
    Calculates the net input and applies the step function to determine the classification.
    
    Args:
        features: A numpy array of normalized input features [x1, x2, x3].
        
    Returns:
        A tuple containing the classification (0 or 1) and the raw net input value.
    """
    # 1. Weighted Summation (Dot Product of inputs and weights)
    # This simulates the physical summation of weighted electrical signals in a biological neuron.
    weighted_sum = np.dot(features, WEIGHTS)
    
    # 2. Add the Bias
    # The bias shifts the activation threshold, making it easier or harder to activate.
    net_input = weighted_sum + BIAS
    
    # 3. Activation
    classification = step_function(net_input)
    
    return classification, net_input

# --- 3. APPLICATION LOGIC AND USER INTERFACE ---

def run_sle_assessment():
    """
    Main function to handle user input, data preparation, and execution of the Perceptron model.
    """
    print("--- Synaptic Loan Evaluator (SLE) Initialized ---")
    print("Please provide the following metrics for assessment (normalized ranges are applied internally):")

    try:
        # Input 1: Credit Score (Range 300 - 850)
        raw_credit = float(input("Enter Credit Score (e.g., 720): "))
        
        # Input 2: Income Stability Index (Estimated 1 - 10)
        raw_income = float(input("Enter Income Stability Index (1-10, 10 being most stable): "))
        
        # Input 3: Debt-to-Income Ratio (Percentage, 0 - 50)
        raw_debt = float(input("Enter Debt-to-Income Ratio (0-50%): "))
        
    except ValueError:
        print("\n[ERROR] Invalid input. Please enter numerical values only.")
        sys.exit(1)

    # --- Data Normalization ---
    
    # Normalize Credit Score (300 min, 850 max)
    norm_credit = normalize_input(raw_credit, 300, 850)
    
    # Normalize Income Stability (1 min, 10 max)
    norm_income = normalize_input(raw_income, 1, 10)
    
    # Normalize Debt Ratio (0 min, 50 max)
    norm_debt = normalize_input(raw_debt, 0, 50)

    # Compile the normalized input vector
    input_features = np.array([norm_credit, norm_income, norm_debt])
    
    print(f"\n[INFO] Normalized Features: {input_features}")
    
    # --- Perceptron Execution ---
    
    result, net_input_value = perceptron_evaluate(input_features)
    
    # --- Output and Interpretation ---
    
    print("\n--- Assessment Results ---")
    print(f"Net Input (Weighted Sum + Bias): {net_input_value:.4f}")
    
    if result == 1:
        print("CLASSIFICATION: APPROVED (1)")
        print("Decision: The combined weighted input exceeded the activation threshold.")
    else:
        print("CLASSIFICATION: DENIED (0)")
        print("Decision: The combined weighted input failed to reach the activation threshold.")

if __name__ == "__main__":
    run_sle_assessment()

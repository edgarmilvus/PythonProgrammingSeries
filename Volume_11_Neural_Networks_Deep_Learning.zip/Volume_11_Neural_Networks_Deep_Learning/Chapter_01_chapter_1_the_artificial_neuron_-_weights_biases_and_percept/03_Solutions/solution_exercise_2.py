
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np

class Perceptron:
    """
    A simple Binary Perceptron model implementing the step activation function.
    """
    def __init__(self, weights, bias):
        # Store initial parameters as NumPy arrays for vector operations
        self.weights = np.array(weights)
        self.bias = bias

    def _step_function(self, z):
        """
        Heaviside Step Function: Returns 1 if z >= 0, else 0.
        """
        return 1 if z >= 0 else 0

    def predict(self, inputs):
        """
        Calculates the net input and applies the step function for classification.
        """
        X = np.array(inputs)

        # Ensure input dimensionality matches weights
        if len(X) != len(self.weights):
             raise ValueError("Input dimensions must match stored weight dimensions.")

        # 1. Calculate Net Input (z = W . X + b)
        weighted_sum = np.dot(self.weights, X)
        z = weighted_sum + self.bias

        # 2. Apply Activation Function
        output = self._step_function(z)

        return output

# 5. Simulated Logic Gate (OR Gate Parameters: W=[0.5, 0.5], b=-0.4)
or_perceptron = Perceptron(weights=[0.5, 0.5], bias=-0.4)

# 6. Testing all four possible inputs for the OR gate
print("--- OR Gate Simulation ---")
test_cases = [(0, 0), (0, 1), (1, 0), (1, 1)]
for x1, x2 in test_cases:
    inputs = [x1, x2]
    prediction = or_perceptron.predict(inputs)
    # Expected OR logic: (0, 0) -> 0; all others -> 1
    print(f"Input: {inputs}, Prediction: {prediction}")

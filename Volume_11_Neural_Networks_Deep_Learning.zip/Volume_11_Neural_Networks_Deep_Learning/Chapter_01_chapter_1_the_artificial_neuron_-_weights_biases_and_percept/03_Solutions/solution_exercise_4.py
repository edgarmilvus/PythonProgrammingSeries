
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import json
import os # Used for cleanup/checking existence

class ConfigurationError(Exception):
    """Custom exception for invalid configuration data."""
    pass

class PerceptronConfigManager:
    def __init__(self, filename):
        self.filename = filename
        self.file_handle = None

    def __enter__(self):
        """
        Opens the file for reading and writing (w+ mode) and returns the manager instance.
        """
        try:
            # Open the file. Using 'w+' allows reading and writing after opening.
            self.file_handle = open(self.filename, 'w+')
            self.file_handle.seek(0) # Reset pointer to start
            return self

        except Exception as e:
            # If opening fails, ensure the handle is closed (though usually handled by Python)
            if self.file_handle:
                self.file_handle.close()
            raise IOError(f"Failed to open configuration file: {e}")

    def __exit__(self, exc_type, exc_value, traceback):
        """
        Guarantees file closure regardless of exceptions.
        """
        if self.file_handle:
            self.file_handle.close()
            print(f"\n[Manager] File '{self.filename}' successfully closed.")

        # Return False to propagate any exceptions (like ConfigurationError)
        return False

    def save_config(self, weights, bias):
        """Simulates writing data to the file."""
        config_data = {'weights': weights, 'bias': bias}
        # Reset pointer and truncate file before writing
        self.file_handle.seek(0)
        self.file_handle.truncate()
        json.dump(config_data, self.file_handle, indent=4)
        print(f"[Manager] Configuration saved successfully.")

    def load_config(self):
        """Simulates reading and validating data."""
        self.file_handle.seek(0)
        try:
            data = json.load(self.file_handle)
        except json.JSONDecodeError:
            # Handle case where file is empty or corrupted JSON
            raise ConfigurationError("File is empty or contains invalid JSON.")

        # Validation Check
        if 'weights' not in data or 'bias' not in data:
            raise ConfigurationError("Configuration file missing required 'weights' or 'bias' keys.")

        print("[Manager] Configuration loaded and validated.")
        return data

# --- Testing Scenarios ---
CONFIG_FILE = "temp_perceptron_config.json"
test_weights = [0.5, 0.5]
test_bias = -0.4

# Scenario 1: Successful Save and Load
try:
    with PerceptronConfigManager(CONFIG_FILE) as config_handler:
        config_handler.save_config(test_weights, test_bias)
        loaded_data = config_handler.load_config()
        print(f"Loaded Data: {loaded_data}")
except Exception as e:
    print(f"An error occurred: {e}")

# Scenario 2: Forced Failure (Simulating invalid config)
# We simulate the failure by manually writing bad content before loading
with open(CONFIG_FILE, 'w') as f:
    f.write('{"weights": [1, 1]}') # Missing bias

print("\n--- Testing ConfigurationError ---")
try:
    with PerceptronConfigManager(CONFIG_FILE) as config_handler:
        # Load the manually corrupted file
        config_handler.file_handle.seek(0) # Ensure file handle reads the bad data
        config_handler.file_handle.write('{"weights": [1, 1]}')
        config_handler.file_handle.seek(0)
        config_handler.load_config()
except ConfigurationError as e:
    print(f"Caught expected error: {e}")
except Exception as e:
    print(f"Unexpected error: {e}")

# Cleanup
if os.path.exists(CONFIG_FILE):
    os.remove(CONFIG_FILE)

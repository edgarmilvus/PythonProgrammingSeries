
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np

# 1. Define the inputs (X): Environmental measurements
# [Temperature (25C), Humidity (90%), Wind Speed (15 km/h)]
inputs = np.array([25.0, 90.0, 15.0])

# 2. Define the weights (W): The importance assigned to each input
# Interpretation of weights:
# - Temperature (-0.1): Cooler temperatures slightly inhibit rain potential.
# - Humidity (+0.5): High humidity is the single most critical factor.
# - Wind Speed (+0.2): Moderate wind slightly increases rain potential.
weights = np.array([-0.1, 0.5, 0.2])

# 3. Define the bias (b): The baseline offset
# A positive bias means the neuron has a slight inherent tendency toward activation (rain potential)
bias = 5.0

# --- Core Neuron Calculation ---

# 4. Calculate the weighted sum (X * W) using the NumPy dot product
# This performs: (25.0 * -0.1) + (90.0 * 0.5) + (15.0 * 0.2)
weighted_sum = np.dot(inputs, weights)

# 5. Calculate the net input (Z)
# Z = Weighted Sum + Bias
net_input_Z = weighted_sum + bias

# 6. Output the results and interpretation
print("--- Artificial Neuron Net Input Calculation ---")
print(f"Inputs (X): {inputs}")
print(f"Weights (W): {weights}")
print(f"Bias (b): {bias}")
print("-" * 50)
print(f"1. Weighted Sum (X * W): {weighted_sum:.4f}")
print(f"2. Net Input (Z = X*W + b): {net_input_Z:.4f}")
print("-" * 50)

# Interpretation based on the resulting score Z
if net_input_Z > 0:
    print(f"Conclusion: The net input score Z ({net_input_Z:.4f}) is positive, indicating a strong potential for the event (Rain).")
else:
    print(f"Conclusion: The net input score Z ({net_input_Z:.4f}) is zero or negative, indicating low potential.")

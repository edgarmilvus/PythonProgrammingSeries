
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import torch
import os
from diffusers import StableDiffusionPipeline
from typing import List, Dict

# --- Configuration Constants ---
MODEL_ID = "runwayml/stable-diffusion-v1-5"
OUTPUT_DIR = "generated_mockups"
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
BATCH_SIZE = 1 # Processing one product description at a time for demonstration

# --- 1. Setup and Initialization ---
def initialize_pipeline(model_id: str, device: str):
    """
    Initializes the Stable Diffusion pipeline, loading components 
    (CLIP, VAE, U-Net) and optimizing for half-precision (float16).
    """
    print(f"Loading Stable Diffusion model: {model_id} on device: {device}")
    
    # Load the pipeline, utilizing half-precision (float16) for VRAM efficiency.
    # This optimization is standard practice due to the compressed Latent Space.
    pipeline = StableDiffusionPipeline.from_pretrained(
        model_id, 
        torch_dtype=torch.float16 if device == "cuda" else torch.float32,
        safety_checker=None # Disabling safety checker for speed in this demo
    )
    
    # Move the entire pipeline (including the U-Net and VAE) to the GPU
    pipeline.to(device)
    
    # Optimization: Enable memory efficient attention mechanisms (xformers)
    if device == "cuda":
        try:
            pipeline.enable_xformers_memory_efficient_attention()
        except ImportError:
            print("Warning: xformers not installed. Running without memory optimization.")
            
    return pipeline

# --- 2. Core Generation Function ---
def generate_mockup(pipeline: StableDiffusionPipeline, product_data: Dict, seed: int = 42) -> str:
    """
    Generates and saves a single product mockup using structured prompting.
    """
    product_name = product_data['name']
    product_description = product_data['description']
    
    # Structured Prompt Engineering: Ensures consistent style (studio lighting, white background)
    # The CLIP encoder maps this detailed text into the conditioning vector.
    prompt_template = (
        f"A professional product photograph of a {product_description}, featuring '{product_name}'. "
        "Studio lighting, white background, high resolution, hyper detailed, commercial photography."
    )
    
    # Negative Prompt: Guides the U-Net away from undesirable features.
    negative_prompt = "blurry, low quality, noise, artifacts, distorted, poor composition, watermark"

    print(f"\nGenerating image for: {product_name}")
    
    # Generator for reproducibility
    generator = torch.Generator(device=pipeline.device).manual_seed(seed)
    
    # Pipeline call: The core of the Diffusion Process
    # The U-Net performs 50 steps of denoising in the latent space.
    image = pipeline(
        prompt=prompt_template,
        negative_prompt=negative_prompt,
        num_inference_steps=50,
        guidance_scale=7.5, # Controls adherence to the CLIP conditioning vector
        generator=generator
    ).images[0]
    
    # Save the output
    filename = f"{product_name.replace(' ', '_').lower()}.png"
    filepath = os.path.join(OUTPUT_DIR, filename)
    image.save(filepath)
    print(f"Successfully saved mockup to: {filepath}")
    
    return filepath

# --- 3. Main Execution ---
if __name__ == "__main__":
    # Ensure output directory exists
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    # Define the product catalog data
    product_catalog = [
        {
            "name": "Zenith Mug",
            "description": "ceramic coffee mug with a minimalist geometric blue pattern"
        },
        {
            "name": "Aether Hoodie",
            "description": "heavyweight black cotton hoodie with a small embroidered logo on the chest"
        },
        {
            "name": "Quantum Keyboard",
            "description": "mechanical keyboard with rainbow backlighting and brushed aluminum casing"
        },
    ]

    # Initialize the optimized pipeline
    sd_pipeline = initialize_pipeline(MODEL_ID, DEVICE)
    
    print("\n--- Starting Product Generation Batch ---")
    
    # Process the entire catalog
    for i, product in enumerate(product_catalog):
        # Increment the seed for slight variation across products
        generate_mockup(sd_pipeline, product, seed=42 + i)
        
    print("\n--- Batch Generation Complete ---")
    if DEVICE == "cuda":
        # Clear VRAM after use (good practice for memory management)
        del sd_pipeline
        torch.cuda.empty_cache()



#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import torch
import torch.nn as nn

class DownBlock(nn.Module):
    # Initializes a block that reduces spatial size by 2x and increases channels
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1)
        self.downsample = nn.MaxPool2d(2) # Simple spatial reduction
        
    def forward(self, x):
        # x_skip is the high-resolution feature map retained for concatenation
        x_skip = self.conv1(x) 
        x_out = self.downsample(x_skip)
        return x_out, x_skip # Return the processed output and the feature map for the skip connection

class UpBlock(nn.Module):
    # Initializes a block that increases spatial size by 2x and manages concatenation
    def __init__(self, in_channels, out_channels):
        super().__init__()
        # Use nearest neighbor upsampling followed by convolution
        self.upsample = nn.Upsample(scale_factor=2, mode='nearest')
        # in_channels must be 2 * C_skip, as it concatenates the upsampled tensor and the skip tensor
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1) 

    def forward(self, x, skip_features):
        # 1. Upsample the input (doubles spatial dimensions)
        x = self.upsample(x)
        
        # 2. Concatenation with skip_features (along the channel dimension, dim=1)
        # This is where the skip connection preserves fine details.
        x = torch.cat([x, skip_features], dim=1) 
        
        # 3. Final processing (reduces channel count back down)
        return self.conv(x)

class ConceptualUNet(nn.Module):
    def __init__(self, initial_channels=4, base_features=128):
        super().__init__()
        
        # Define channel sizes
        C1, C2, C3, C4 = initial_channels, base_features, base_features * 2, base_features * 4
        
        # Downsampling Path (64x64 -> 32x32 -> 16x16 -> 8x8)
        self.down_blocks = nn.ModuleList([
            DownBlock(C1, C2), 
            DownBlock(C2, C3), 
            DownBlock(C3, C4), 
        ])
        
        # Bottleneck
        self.bottleneck = nn.Conv2d(C4, C4, kernel_size=1) 
        
        # Upsampling Path (8x8 -> 16x16 -> 32x32 -> 64x64)
        # Input channels for UpBlock must be C_in + C_skip
        self.up_blocks = nn.ModuleList([
            UpBlock(C4 + C4, C3), # 8x8 -> 16x16. Input: 2*C4, Output: C3
            UpBlock(C3 + C3, C2), # 16x16 -> 32x32. Input: 2*C3, Output: C2
            UpBlock(C2 + C2, C1), # 32x32 -> 64x64. Input: 2*C2, Output: C1 (4 channels)
        ])
        
        self.final_conv = nn.Conv2d(C1, initial_channels, kernel_size=1) 
        
    def forward(self, x):
        print(f"1. Input Latent Shape: {x.shape}")
        skip_connections = []
        
        # 1. Downsampling Path
        current_x = x
        for down_block in self.down_blocks:
            current_x, skip_feature = down_block(current_x)
            skip_connections.append(skip_feature)
        
        # 2. Bottleneck
        current_x = self.bottleneck(current_x)
        print(f"2. Bottleneck Shape: {current_x.shape}")

        # 3. Upsampling Path
        # Iterate backwards through the stored skip connections
        for up_block in self.up_blocks:
            skip_feature = skip_connections.pop()
            current_x = up_block(current_x, skip_feature)
            
        print(f"3. Shape before Final Conv: {current_x.shape}")
        
        # 4. Final Output
        return self.final_conv(current_x)

# Verification Run
dummy_input = torch.randn(1, 4, 64, 64)
model = ConceptualUNet()
output = model(dummy_input)
print(f"4. Final Output Shape: {output.shape}")

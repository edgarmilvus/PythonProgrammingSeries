
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from diffusers import StableDiffusionPipeline
import torch
import time

def measure_inference_speed(model_id, prompt, step_counts):
    # 1. Pipeline Initialization
    device = "cuda" if torch.cuda.is_available() else "cpu"
    
    # Use float16 on CUDA for maximum performance optimization
    dtype = torch.float16 if device == "cuda" else torch.float32
    pipe = StableDiffusionPipeline.from_pretrained(model_id, torch_dtype=dtype)
    pipe.to(device)

    results = []
    
    # 2. Step Iteration and 3. Timing Loop
    print(f"Testing on device: {device} with dtype: {dtype}")
    
    for steps in step_counts:
        # Set a fixed seed for consistency
        generator = torch.Generator(device).manual_seed(42)
        
        # Ensure GPU synchronization before timing starts (critical for accurate CUDA timing)
        if device == "cuda":
            torch.cuda.synchronize()
            
        start_time = time.time()
        
        # 4. Inference Execution
        # Run the generation process with the current step count.
        _ = pipe(
            prompt=prompt,
            num_inference_steps=steps,
            generator=generator,
            output_type="pil" # Ensure full pipeline execution including VAE decode
        )
        
        # Ensure GPU synchronization before timing stops
        if device == "cuda":
            torch.cuda.synchronize()
            
        end_time = time.time()
        duration = end_time - start_time
        
        # 5. Reporting
        results.append({
            "steps": steps,
            "time_seconds": duration,
        })
        
    print("\n--- Inference Performance Report (Steps vs. Time) ---")
    print(f"Prompt: '{prompt[:50]}...'")
    print("-" * 45)
    print(f"{'Steps':<10}{'Time (s)':<15}{'Observation':<20}")
    print("-" * 45)
    
    # Implement the printing/reporting logic here to display the results table.
    base_time = results[0]['time_seconds'] if results else 0
    for res in results:
        # Calculate approximate factor increase relative to the shortest run
        factor = res['time_seconds'] / base_time if base_time > 0 else 1
        observation = f"x{factor:.1f} compared to {results[0]['steps']} steps"
        print(f"{res['steps']:<10}{res['time_seconds']:.4f}{observation:<20}")

# Example usage (Requires GPU/Stable Diffusion environment setup)
model_id = "runwayml/stable-diffusion-v1-5"
fixed_prompt = "A detailed watercolor painting of a lighthouse during a storm, cinematic lighting"
test_steps = [10, 25, 50, 75, 100]

# Execution (Conceptual call)
# measure_inference_speed(model_id, fixed_prompt, test_steps)

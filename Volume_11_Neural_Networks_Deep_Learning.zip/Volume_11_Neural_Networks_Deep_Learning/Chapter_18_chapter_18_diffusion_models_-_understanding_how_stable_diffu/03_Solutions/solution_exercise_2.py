
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from diffusers import AutoencoderKL
from PIL import Image
import torch
import numpy as np
import os

# Helper function to load and preprocess an image (Mocked for environment stability)
def load_and_preprocess_image(image_path, target_size=512):
    # Mocking a tensor input since we cannot guarantee file existence
    image_tensor = torch.randn(1, 3, target_size, target_size)
    return image_tensor

# Helper function to postprocess and save the output image (Conceptual)
def postprocess_and_save(tensor, output_path):
    # Placeholder for actual image saving logic
    # Denormalize: (tensor / 2 + 0.5).clamp(0, 1) ...
    print(f"--- Saved conceptual image to {output_path} ---")

# Main execution block
def run_vae_test(image_path="sample_512x512.png"):
    # 1. Load VAE
    vae = AutoencoderKL.from_pretrained("runwayml/stable-diffusion-v1-5", subfolder="vae")
    
    device = "cuda" if torch.cuda.is_available() else "cpu"
    vae.to(device)
    
    # 2. Prepare Image (Using mocked input, [1, 3, 512, 512])
    original_image_tensor = load_and_preprocess_image(image_path).to(device) 
    
    # Calculate original volume (1 * 3 * 512 * 512)
    original_volume = original_image_tensor.numel()
    
    # 3. Encoding (Compression)
    with torch.no_grad():
        # VAE encoder outputs a distribution
        latent_distribution = vae.encode(original_image_tensor)
        
        # Extract the latent tensor (mean component)
        latent_tensor = latent_distribution.latent_dist.sample() 
        
    # 4. Size Verification
    latent_volume = latent_tensor.numel()
    
    print(f"Original Pixel Space Tensor Shape: {original_image_tensor.shape}")
    print(f"Original Volume (Pixels): {original_volume}")
    print(f"Latent Space Tensor Shape: {latent_tensor.shape}")
    print(f"Latent Volume (Compressed): {latent_volume}")
    print(f"Compression Ratio: {original_volume / latent_volume:.2f}x")
    
    # 5. Decoding (Decompression)
    with torch.no_grad():
        # Scale the latent tensor before decoding (critical step for VAE)
        latent_tensor_scaled = latent_tensor * vae.config.scaling_factor
        reconstructed_tensor = vae.decode(latent_tensor_scaled).sample
        
    print(f"Reconstructed Pixel Space Tensor Shape: {reconstructed_tensor.shape}")
    
    # 6. Visualization (Conceptual)
    # postprocess_and_save(original_image_tensor, "original_input.png")
    # postprocess_and_save(reconstructed_tensor, "vae_reconstructed_output.png")

# Execute the test
run_vae_test()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Conceptual Graphviz DOT Structure for Stable Diffusion Data Flow

"""
digraph StableDiffusionFlow {
    rankdir=LR;
    node [shape=box, style="filled", fillcolor="#f0f0f0"];

    // 1. Text Conditioning Path (Input/Output)
    Text [label="Text Prompt (String)", fillcolor="#ffcc99"];
    CLIP [label="CLIP Text Encoder", fillcolor="#ff9933"];
    C_pos [label="Conditional Embedding (C_pos)", shape=oval, fillcolor="#ffe0b3"];
    C_neg [label="Negative Embedding (C_neg)", shape=oval, fillcolor="#ffe0b3"];
    C_combined [label="Combined Embeddings", fillcolor="#ffc080"];

    // Annotations for CLIP path
    Text -> CLIP [label="Input"];
    CLIP -> C_pos [label="[1, 77, 768]"];
    CLIP -> C_neg [label="[1, 77, 768]"];
    C_pos -> C_combined [label="Concatenation"];
    C_neg -> C_combined [label="Concatenation"];
    
    // 2. Latent Denoising Path (Iterative Core)
    Latent_Start [label="Noisy Latent (Z_T)", fillcolor="#cceeff"];
    UNet [label="Latent U-Net (Denoising)", fillcolor="#66b3ff"];
    Noise_Pred [label="Predicted Noise (ε)", shape=oval, fillcolor="#99ddff"];
    Scheduler [label="Scheduler (DDIM/PNDM)", fillcolor="#3399ff"];
    Latent_Next [label="Denoised Latent (Z_t-1)", fillcolor="#cceeff"];
    
    // Annotations for U-Net path
    Latent_Start -> UNet [label="[B, 4, 64, 64]"];
    C_combined -> UNet [label="Conditioning Input [2, 77, 768]"];
    UNet -> Noise_Pred [label="Output [B, 4, 64, 64]"];
    Noise_Pred -> Scheduler [label="Input"];
    Latent_Start -> Scheduler [label="Input (Z_t)"];
    Scheduler -> Latent_Next [label="Output (Z_t-1)"];
    
    // Iterative Loop
    Latent_Next -> UNet [label="Loop (T times)", style=dashed]; 
    
    // 3. VAE Decoding Path (Final Expansion)
    Latent_Final [label="Final Latent (Z_0)", fillcolor="#99ff99"];
    VAEDecoder [label="VAE Decoder", fillcolor="#33cc33"];
    Image_Output [label="Final Image (Pixels)", fillcolor="#ccffcc"];
    
    // Annotations for VAE path
    Latent_Next -> Latent_Final [label="After T steps"];
    Latent_Final -> VAEDecoder [label="[1, 4, 64, 64]"];
    VAEDecoder -> Image_Output [label="[1, 3, 512, 512]"];
}
"""
# Note: The provided image placeholder is replaced by this conceptual structure.

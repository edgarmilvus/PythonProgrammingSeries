
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from diffusers import StableDiffusionPipeline
import torch

def generate_image_with_guidance(model_id, positive_prompt, negative_prompt, guidance_scale=7.5):
    # 1. Pipeline Setup (Load model components)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    # Using float16 for speed if CUDA is available
    pipe = StableDiffusionPipeline.from_pretrained(model_id, torch_dtype=torch.float16 if device == "cuda" else torch.float32)
    pipe.to(device)

    # Helper function to tokenize and encode
    def tokenize_and_encode(prompt):
        # Tokenize the prompt
        text_input = pipe.tokenizer(
            prompt,
            padding="max_length",
            max_length=pipe.tokenizer.model_max_length,
            truncation=True,
            return_tensors="pt",
        )
        # Encode the tokens to get embeddings [1, sequence_length, embedding_dim]
        with torch.no_grad():
            embeddings = pipe.text_encoder(text_input.input_ids.to(device))[0]
        return embeddings

    # 2. Dual Embedding Generation
    # Generate the conditional (positive) embedding
    conditional_embeddings = tokenize_and_encode(positive_prompt)

    # Generate the unconditional/negative embedding
    # If a negative prompt is provided, it replaces the empty string unconditional embedding
    unconditional_embeddings = tokenize_and_encode(negative_prompt)

    # 3. Embedding Concatenation
    # Concatenate along the batch dimension: [unconditional_batch, conditional_batch]
    # Resulting shape: [2, sequence_length, embedding_dim]
    text_embeddings = torch.cat([unconditional_embeddings, conditional_embeddings])
    
    print(f"Combined Embedding Shape: {text_embeddings.shape}")

    # 4. Inference Execution
    generator = torch.Generator(device).manual_seed(42)
    
    print(f"Starting generation with negative prompt: '{negative_prompt[:30]}...'")
    
    # Pass the combined text_embeddings (prompt_embeds) to the pipeline
    image = pipe(
        prompt_embeds=text_embeddings,
        guidance_scale=guidance_scale,
        generator=generator,
        num_inference_steps=25, # Reduced steps for faster demonstration
        output_type="pil"
    ).images[0]
    
    # image.save(f"output_cfg_{hash(negative_prompt)}.png")
    return image

# Define scenarios
model_id = "runwayml/stable-diffusion-v1-5"
positive_A = "A detailed watercolor painting of a lighthouse during a storm, cinematic lighting"

# SCENARIO A: Strong Negative Prompt (Pushes output away from unwanted features)
negative_A = "Poorly drawn, cartoon, low contrast, monochrome, blurry background, bad anatomy"
# image_A = generate_image_with_guidance(model_id, positive_A, negative_A)

# SCENARIO B: Weak/Default Negative Prompt (Less guidance, relies more on positive prompt)
negative_B = "artifacts, text, watermark"
# image_B = generate_image_with_guidance(model_id, positive_A, negative_B)

# Conceptual execution verification
print("\n--- Conceptual CFG Setup Verification ---")
# generate_image_with_guidance(model_id, positive_A, negative_A)

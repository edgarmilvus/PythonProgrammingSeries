
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import torch
import math

# --- 1. Configuration and Noise Scheduling ---

# T: Total number of diffusion steps (time steps)
T = 100 

# Define the linear noise schedule (beta values)
# Betas determine the variance of the Gaussian noise added at each step.
beta_start = 0.0001
beta_end = 0.02
betas = torch.linspace(beta_start, beta_end, T, dtype=torch.float32)

# Calculate alpha and alpha_bar (crucial for the forward process)
# Alpha_t = 1 - beta_t
alphas = 1.0 - betas
# Alpha_bar_t = product of all alphas up to time t (Cumulative product)
alphas_bar = torch.cumprod(alphas, dim=0)

# --- 2. Input Data Simulation ---

# Simulate a small latent vector (x_0) representing the clean image features
latent_dim = 64
# Initialize with a small non-zero mean for visualization purposes
x_0 = torch.randn(1, latent_dim) * 0.5 + 1.0 

# --- 3. Forward Diffusion Process Function ---

def forward_diffusion(x_start, t_step, alphas_bar_schedule):
    """
    Applies noise to the starting data (x_start) at a specific time step (t_step).
    This uses the reparameterization trick to jump directly from x_0 to x_t.
    
    Equation: x_t = sqrt(alpha_bar_t) * x_0 + sqrt(1 - alpha_bar_t) * epsilon
    """
    
    # Retrieve the cumulative alpha value for the current time step
    alpha_bar_t = alphas_bar_schedule[t_step].item()
    
    # Calculate the signal coefficient (how much of the original data remains)
    sqrt_alpha_bar_t = math.sqrt(alpha_bar_t)
    
    # Calculate the noise coefficient (how much noise is added)
    sqrt_one_minus_alpha_bar_t = math.sqrt(1.0 - alpha_bar_t)
    
    # Generate random Gaussian noise (epsilon) matching the input shape
    noise_epsilon = torch.randn_like(x_start)
    
    # Apply the core DDPM forward equation (reparameterization trick)
    x_t = (sqrt_alpha_bar_t * x_start) + (sqrt_one_minus_alpha_bar_t * noise_epsilon)
    
    return x_t, noise_epsilon

# --- 4. Simulation and Demonstration ---

print(f"--- Initial Clean Latent Vector (x_0) ---")
print(f"Shape: {x_0.shape}")
print(f"First 5 elements: {x_0[0, :5].tolist()}") 

# Simulate noise at three distinct time steps: early, middle, and late
time_steps = [10, 50, 99] 

for t in time_steps:
    # Adjust t to be zero-indexed for tensor access (t=10 becomes index 9)
    t_idx = t - 1 
    
    # Run the forward process
    x_t_noisy, added_noise = forward_diffusion(x_0, t_idx, alphas_bar)
    
    print(f"\n--- Diffusion Step t={t} (Index {t_idx}) ---")
    
    # Display the calculated coefficients
    alpha_bar_t = alphas_bar[t_idx].item()
    print(f"Signal Coefficient (sqrt(alpha_bar)): {math.sqrt(alpha_bar_t):.6f}")
    print(f"Noise Coefficient (sqrt(1-alpha_bar)): {math.sqrt(1.0 - alpha_bar_t):.6f}")
    
    print(f"Noisy Vector (x_t) [first 5]: {x_t_noisy[0, :5].tolist()}")
    
    # At t=99 (the final step), the data should approximate pure standard Gaussian noise
    if t == 99:
        print(f"\n[Final Step Analysis]")
        print(f"Mean of x_t at t=99: {x_t_noisy.mean():.4f} (Should be near 0)")
        print(f"Std Dev of x_t at t=99: {x_t_noisy.std():.4f} (Should be near 1)")

# --- 5. Conceptual Reverse Process Setup (The Denoising Task) ---

# The reverse process is where the U-Net performs its prediction.
# The U-Net must take the noisy data (x_t) and the time step (t) and predict 
# the noise (epsilon) that was added.

def conceptual_denoising_u_net(x_t, t_step):
    """
    Placeholder for the complex U-Net architecture.
    It must maintain the shape of the input data.
    """
    
    # In a real model, t_step is first converted into a high-dimensional 
    # positional embedding vector (Time Embedding) before being injected 
    # into the U-Net layers.
    
    # Output shape must match input shape (x_t)
    predicted_noise = torch.zeros_like(x_t) 
    
    return predicted_noise

# Demonstration of the U-Net's required I/O structure
t_test = 50
x_t_test, actual_noise_test = forward_diffusion(x_0, t_test - 1, alphas_bar)
predicted_noise_output = conceptual_denoising_u_net(x_t_test, t_test)

print(f"\n--- Conceptual Reverse Process Setup (U-Net Task) ---")
print(f"Required Input 1 (x_t) shape: {x_t_test.shape}")
print(f"Required Input 2 (t_step): {t_test}")
print(f"Target Output shape (Actual Noise): {actual_noise_test.shape}")
print(f"U-Net Output shape (Predicted Noise): {predicted_noise_output.shape}")

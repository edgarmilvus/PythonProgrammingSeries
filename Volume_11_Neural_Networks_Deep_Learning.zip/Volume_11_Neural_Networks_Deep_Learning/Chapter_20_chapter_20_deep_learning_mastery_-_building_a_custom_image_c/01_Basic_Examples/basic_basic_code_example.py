
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

# --- Configuration Constants ---
# Output size of the pre-trained CNN (e.g., features from the final layer of ResNet-50)
FEATURE_DIM = 2048  
# Desired internal state size for the LSTM decoder
DECODER_HIDDEN_DIM = 512 
# Simulation batch size
BATCH_SIZE = 16

class FeatureToStateConverter(nn.Module):
    """
    Module responsible for converting the fixed-size visual feature vector 
    into the required initial hidden state (h0) and cell state (c0) 
    for the LSTM decoder.
    """
    def __init__(self, feature_dim: int, hidden_dim: int):
        """
        Initializes the two independent linear layers.
        """
        super().__init__()
        
        # 1. Mapper for the initial hidden state (h0)
        # Input: FEATURE_DIM (2048), Output: DECODER_HIDDEN_DIM (512)
        self.h_mapper = nn.Linear(feature_dim, hidden_dim)
        
        # 2. Mapper for the initial cell state (c0)
        # We use a separate layer to ensure h0 and c0 learn independent transformations
        self.c_mapper = nn.Linear(feature_dim, hidden_dim)
        
        # 3. Activation function to stabilize the initial states
        # Tanh bounds the values between -1 and 1, aiding stability in the RNN
        self.activation = nn.Tanh()

    def forward(self, features: torch.Tensor):
        """
        Performs the transformation and reshaping required by PyTorch's LSTM.
        Input: features (Batch x Feature_Dim)
        Output: initial_h, initial_c (1 x Batch x Hidden_Dim)
        """
        
        # Apply the h_mapper and activation
        # Shape: (Batch x 2048) -> (Batch x 512)
        initial_h = self.activation(self.h_mapper(features))
        
        # Apply the c_mapper and activation
        # Shape: (Batch x 2048) -> (Batch x 512)
        initial_c = self.activation(self.c_mapper(features))
        
        # CRITICAL STEP: Reshaping for LSTM compatibility.
        # PyTorch LSTMs expect the state tensors to be (Layers * Directions, Batch, Hidden).
        # Since we use 1 layer and 1 direction, we add a dimension of size 1 at index 0.
        initial_h = initial_h.unsqueeze(0)
        initial_c = initial_c.unsqueeze(0)
        
        return initial_h, initial_c

# --- Simulation and Integration Test ---

# Set seed for deterministic output
torch.manual_seed(42)
np.random.seed(42)

# 1. Simulate the output of the CNN Encoder
# This tensor represents 16 images, each summarized by 2048 features.
dummy_features = torch.randn(BATCH_SIZE, FEATURE_DIM)
print(f"1. Simulated Encoder Output Shape: {dummy_features.shape}")

# 2. Instantiate the converter
converter = FeatureToStateConverter(FEATURE_DIM, DECODER_HIDDEN_DIM)

# 3. Perform the conversion
h0, c0 = converter(dummy_features)

print("\n--- Conversion Results ---")
print(f"2. Initial Hidden State (h0) Shape: {h0.shape}")
print(f"3. Initial Cell State (c0) Shape: {c0.shape}")
print(f"4. Sample h0 value (First Item, First Dimension): {h0[0, 0, 0]:.4f}")

# 4. Verify compatibility with an actual PyTorch LSTM
# Define a simple LSTM layer (input size must match hidden size if we use embeddings of that size)
# Note: batch_first=False is the PyTorch default for RNNs, meaning (Sequence, Batch, Features)
lstm_decoder = nn.LSTM(input_size=DECODER_HIDDEN_DIM, 
                       hidden_size=DECODER_HIDDEN_DIM, 
                       num_layers=1, 
                       batch_first=False) 

# Simulate the first input token embedding (e.g., the <START> token)
# Sequence length is 1 (the first step), Batch size is 16, Feature size is 512
dummy_input_token = torch.randn(1, BATCH_SIZE, DECODER_HIDDEN_DIM) 

# Pass the input token AND the initialized states (h0, c0) to the LSTM
output, (h_next, c_next) = lstm_decoder(dummy_input_token, (h0, c0))

print("\n--- LSTM Integration Check ---")
print(f"5. Input Token Shape (Seq x Batch x Feature): {dummy_input_token.shape}")
print(f"6. LSTM Output Shape (Seq x Batch x Hidden): {output.shape}")
print(f"7. Next Hidden State (h_next) Shape: {h_next.shape}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import torch
import torch.nn as nn
import torch.nn.functional as F

# --- 1. Hyperparameters and Mock Setup ---
# These dimensions simulate a typical setup (e.g., ResNet features, standard LSTM size)
BATCH_SIZE = 32
FEATURE_DIM = 2048       # Dimension of each visual feature vector (e.g., from CNN output)
NUM_FEATURES = 64        # Number of spatial feature vectors (e.g., 8x8 grid)
HIDDEN_DIM = 512         # Decoder LSTM hidden state dimension
EMBEDDING_DIM = 256      # Word embedding dimension
ATTENTION_DIM = 512      # Intermediate dimension for the attention mechanism (alignment network)

# --- 2. The Attention Mechanism (Bahdanau/Additive Attention) ---
class AttentionModule(nn.Module):
    """
    Calculates attention weights (alpha) over the image features based on the 
    current hidden state of the decoder.
    """
    def __init__(self, feature_dim, hidden_dim, attention_dim):
        super().__init__()
        # Linear layer to transform visual features (a_i)
        self.U_a = nn.Linear(feature_dim, attention_dim)
        # Linear layer to transform previous hidden state (h_{t-1})
        self.W_a = nn.Linear(hidden_dim, attention_dim)
        # Linear layer to calculate the alignment score (v^T)
        self.V_a = nn.Linear(attention_dim, 1)
        # Dropout for regularization
        self.dropout = nn.Dropout(p=0.5)

    def forward(self, encoder_features, decoder_hidden_state):
        """
        Args:
            encoder_features (Tensor): (B, N, D_f) -> (Batch, Num_Features, Feature_Dim)
            decoder_hidden_state (Tensor): (B, D_h) -> (Batch, Hidden_Dim)
        
        Returns:
            context (Tensor): (B, D_f) -> Context vector
            alpha (Tensor): (B, N) -> Attention weights
        """
        N = encoder_features.size(1) # Num_Features

        # 1. Transform features: (B, N, D_f) -> (B, N, D_a)
        features_transformed = self.U_a(encoder_features) 

        # 2. Transform hidden state and expand: (B, D_h) -> (B, D_a) -> (B, 1, D_a)
        hidden_transformed = self.W_a(decoder_hidden_state).unsqueeze(1) 

        # 3. Calculate Alignment Scores (e): (B, N, D_a) + (B, 1, D_a) -> (B, N, D_a)
        # Uses broadcasting to add the hidden state vector to every feature vector
        alignment_scores = torch.tanh(features_transformed + hidden_transformed)

        # 4. Calculate Raw Energy (e_t,i): (B, N, D_a) -> (B, N, 1)
        raw_energy = self.V_a(self.dropout(alignment_scores)).squeeze(2)

        # 5. Apply Softmax to get Attention Weights (alpha): (B, N)
        alpha = F.softmax(raw_energy, dim=1) 

        # 6. Calculate Context Vector (c_t): (B, N, 1) * (B, N, D_f) -> (B, D_f)
        # Weighted sum of the original encoder features
        context = (alpha.unsqueeze(2) * encoder_features).sum(dim=1)

        return context, alpha

# --- 3. The Decoder Step Module ---
class AttentiveDecoderStep(nn.Module):
    """
    Performs one step of the decoding process, integrating the context vector
    with the current word embedding to update the LSTM state and predict the next word.
    """
    def __init__(self, feature_dim, hidden_dim, embedding_dim, attention_dim):
        super().__init__()
        
        # 1. Attention Mechanism
        self.attention = AttentionModule(feature_dim, hidden_dim, attention_dim)
        
        # 2. Gating/Fusion Network (Combines embedding, context, and previous hidden state)
        # The input size is (Embedding + Context + Hidden)
        fusion_input_size = embedding_dim + feature_dim + hidden_dim
        self.f_beta = nn.Linear(fusion_input_size, hidden_dim)
        self.sigmoid = nn.Sigmoid()

        # 3. LSTM Cell (Inputs: [Embedding + Context], Hidden State)
        lstm_input_size = embedding_dim + feature_dim
        self.lstm_cell = nn.LSTMCell(lstm_input_size, hidden_dim, bias=True)

        # 4. Output Layer (Predicts the logit for the next word)
        self.output_linear = nn.Linear(hidden_dim, 10000) # Assuming a vocab size of 10k

    def forward(self, word_embedding, encoder_features, prev_h, prev_c):
        """
        Args:
            word_embedding (Tensor): (B, D_e)
            encoder_features (Tensor): (B, N, D_f)
            prev_h (Tensor): (B, D_h) - Previous hidden state
            prev_c (Tensor): (B, D_h) - Previous cell state
        
        Returns:
            output_logits, (h, c), alpha
        """
        
        # 1. Calculate Context Vector and Attention Weights
        context, alpha = self.attention(encoder_features, prev_h)

        # 2. Gating Mechanism (Optional but common for stabilization)
        # The gate determines how much of the previous state is passed through
        fusion_input = torch.cat((word_embedding, context, prev_h), dim=1)
        beta_gate = self.sigmoid(self.f_beta(fusion_input))
        
        # 3. Prepare LSTM Input: Concatenate word embedding and context vector
        lstm_input = torch.cat((word_embedding, context), dim=1)
        
        # 4. Run LSTM Cell
        h, c = self.lstm_cell(lstm_input, (prev_h, prev_c))
        
        # 5. Apply Gating to the New Hidden State
        # This acts as a 'visual sentinel' or regularization gate
        h = beta_gate * h

        # 6. Predict Output Logits
        output_logits = self.output_linear(h)

        return output_logits, (h, c), alpha

# --- 4. Simulation and Forward Pass Execution ---
if __name__ == "__main__":
    
    # Initialize the model
    decoder_step = AttentiveDecoderStep(
        FEATURE_DIM, HIDDEN_DIM, EMBEDDING_DIM, ATTENTION_DIM
    )
    
    # Create Mock Data Tensors
    # A. Encoder Features (Image Patches)
    mock_features = torch.randn(BATCH_SIZE, NUM_FEATURES, FEATURE_DIM)
    # B. Current Word Embedding (e.g., embedding for the word 'a' or '<start>')
    mock_embedding = torch.randn(BATCH_SIZE, EMBEDDING_DIM)
    # C. Previous LSTM States (h and c)
    mock_prev_h = torch.randn(BATCH_SIZE, HIDDEN_DIM)
    mock_prev_c = torch.randn(BATCH_SIZE, HIDDEN_DIM)

    print(f"--- Simulation Start ---")
    print(f"Input Features Shape: {mock_features.shape}")
    print(f"Previous Hidden State Shape: {mock_prev_h.shape}")
    
    # Perform the forward pass for one decoding step
    logits, (new_h, new_c), attention_weights = decoder_step(
        mock_embedding, mock_features, mock_prev_h, mock_prev_c
    )
    
    # Output Results
    print(f"\n--- Results ---")
    print(f"Output Logits Shape (Vocab Size): {logits.shape}")
    print(f"New Hidden State Shape: {new_h.shape}")
    print(f"Attention Weights (Alpha) Shape: {attention_weights.shape}")
    
    # Verify Attention Weights properties
    # Summing across the feature dimension (axis 1) should equal 1 for each batch item
    weight_sum = attention_weights.sum(dim=1)
    print(f"Attention Weights Sum Check (First Batch Item): {weight_sum[0].item():.4f}")
    print(f"--- Simulation Complete ---")

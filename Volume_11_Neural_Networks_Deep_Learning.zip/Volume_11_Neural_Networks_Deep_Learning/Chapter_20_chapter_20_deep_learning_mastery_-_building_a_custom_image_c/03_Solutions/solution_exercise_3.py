
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import tensorflow as tf
from tensorflow.keras import layers, Model
import numpy as np

# --- Helper Functions for Transformer ---

def create_look_ahead_mask(size):
    """
    Creates a causal mask to prevent attention to future tokens.
    Mask shape: (1, size, size)
    """
    mask = 1 - tf.linalg.band_part(tf.ones((size, size)), -1, 0)
    return mask  # 0s are kept, 1s are masked (set to large negative value)

class PositionalEncoding(layers.Layer):
    """Standard sinusoidal positional encoding."""
    def __init__(self, position, d_model):
        super(PositionalEncoding, self).__init__()
        self.pos_encoding = self.get_angles(position, d_model)

    def get_angles(self, position, i):
        angle_rates = 1 / np.power(10000, (2 * (i // 2)) / np.float32(i))
        return angle_rates

    def call(self, inputs):
        # inputs shape: (batch_size, seq_len, d_model)
        seq_len = tf.shape(inputs)[1]
        
        # Calculate angles and apply sin/cos
        angles = tf.range(seq_len, dtype=tf.float32)[:, tf.newaxis] * self.pos_encoding[:seq_len, tf.newaxis]

        # Apply sin to even indices (2i) and cos to odd indices (2i + 1)
        sines = tf.math.sin(angles[:, 0::2])
        cosines = tf.math.cos(angles[:, 1::2])

        pos_encoding = tf.concat([sines, cosines], axis=-1)[tf.newaxis, ...]
        
        return inputs + pos_encoding[:, :seq_len, :]


class TransformerDecoderBlock(layers.Layer):
    """
    A single Transformer Decoder Block combining Causal Self-Attention 
    and Encoder-Decoder Cross-Attention.
    """
    def __init__(self, d_model, num_heads, dff, rate=0.1):
        super(TransformerDecoderBlock, self).__init__()
        
        # 1. Masked Multi-Head Self-Attention (MHA)
        self.mha1 = layers.MultiHeadAttention(num_heads=num_heads, key_dim=d_model)
        self.layernorm1 = layers.LayerNormalization(epsilon=1e-6)
        self.dropout1 = layers.Dropout(rate)

        # 2. Cross-Attention (MHA) over Encoder features
        self.mha2 = layers.MultiHeadAttention(num_heads=num_heads, key_dim=d_model)
        self.layernorm2 = layers.LayerNormalization(epsilon=1e-6)
        self.dropout2 = layers.Dropout(rate)

        # 3. Feed-Forward Network (FFN)
        self.ffn = tf.keras.Sequential([
            layers.Dense(dff, activation='relu'),
            layers.Dense(d_model)
        ])
        self.layernorm3 = layers.LayerNormalization(epsilon=1e-6)
        self.dropout3 = layers.Dropout(rate)

    def call(self, x, enc_output, training, look_ahead_mask):
        # x: embedded caption sequence (Q)
        # enc_output: visual features (K/V for cross-attention)
        
        # --- 1. Causal Self-Attention ---
        # Q=x, K=x, V=x, using the look_ahead_mask
        attn1_output = self.mha1(
            query=x, 
            value=x, 
            key=x, 
            attention_mask=look_ahead_mask, 
            training=training
        )
        attn1_output = self.dropout1(attn1_output, training=training)
        # Residual connection + Layer Norm
        out1 = self.layernorm1(x + attn1_output) 

        # --- 2. Cross-Attention ---
        # Q=out1, K=enc_output, V=enc_output
        attn2_output = self.mha2(
            query=out1, 
            value=enc_output, 
            key=enc_output, 
            training=training
        )
        attn2_output = self.dropout2(attn2_output, training=training)
        # Residual connection + Layer Norm
        out2 = self.layernorm2(out1 + attn2_output)

        # --- 3. Feed Forward Network ---
        ffn_output = self.ffn(out2)
        ffn_output = self.dropout3(ffn_output, training=training)
        # Residual connection + Layer Norm
        out3 = self.layernorm3(out2 + ffn_output)
        
        return out3

# --- Verification Example ---
# Model Hyperparameters
D_MODEL = 512
NUM_HEADS = 8
DFF = 2048
MAX_SEQ_LEN = 20
NUM_REGIONS = 64
FEATURE_DIM = 2048 # Must match D_MODEL for cross-attention if no projection

# Dummy inputs
batch_size = 16
# Input sequence (after embedding): (B, Seq_Len, D_Model)
dummy_seq_input = tf.random.normal((batch_size, MAX_SEQ_LEN, D_MODEL))
# Encoder output (Visual Features): (B, Num_Regions, D_Model)
dummy_enc_output = tf.random.normal((batch_size, NUM_REGIONS, D_MODEL)) 

# 1. Positional Encoding
pos_encoder = PositionalEncoding(MAX_SEQ_LEN, D_MODEL)
seq_with_pos = pos_encoder(dummy_seq_input)

# 2. Causal Mask
mask = create_look_ahead_mask(MAX_SEQ_LEN)

# 3. Decoder Block Call
decoder_block = TransformerDecoderBlock(D_MODEL, NUM_HEADS, DFF)
decoder_output = decoder_block(seq_with_pos, dummy_enc_output, training=True, look_ahead_mask=mask)

print(f"Decoder Block Output Shape: {decoder_output.shape}")

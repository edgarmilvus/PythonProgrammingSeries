
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import tensorflow as tf
from tensorflow.keras import layers, Model

class BahdanauAttentionLayer(layers.Layer):
    """
    Implements the Additive (Bahdanau) Attention mechanism.
    Calculates attention weights over the encoder features based on the 
    current decoder hidden state.
    """
    def __init__(self, units):
        super(BahdanauAttentionLayer, self).__init__()
        self.W1 = layers.Dense(units) # Projects features (s_i)
        self.W2 = layers.Dense(units) # Projects hidden state (h_t)
        self.V = layers.Dense(1)      # Final score projection (V^T)

    def call(self, features, hidden_state):
        """
        Args:
            features (tf.Tensor): Encoder output features (visual features). 
                                  Shape: (batch_size, num_regions, feature_dim)
            hidden_state (tf.Tensor): Current hidden state of the Decoder RNN.
                                      Shape: (batch_size, rnn_units)
        
        Returns:
            context_vector, attention_weights
        """
        # 1. Expand hidden state shape for broadcasting
        # We need to add a time dimension (1) so W2(h_t) can be added 
        # to W1(s_i) where s_i is indexed by num_regions.
        # Shape: (batch_size, 1, rnn_units)
        hidden_state_expanded = tf.expand_dims(hidden_state, 1)

        # 2. Calculate attention scores (V^T tanh(W1*s_i + W2*h_t))
        # score_raw shape: (batch_size, num_regions, 1)
        score_raw = self.V(
            tf.nn.tanh(self.W1(features) + self.W2(hidden_state_expanded))
        )

        # 3. Apply softmax to get attention weights
        # Weights shape: (batch_size, num_regions, 1)
        attention_weights = tf.nn.softmax(score_raw, axis=1)

        # 4. Calculate context vector (weighted sum)
        # Multiply weights (num_regions, 1) by features (num_regions, feature_dim)
        # context_vector shape: (batch_size, feature_dim)
        context_vector = attention_weights * features
        context_vector = tf.reduce_sum(context_vector, axis=1)

        # Reshape weights to remove the last dimension for cleaner output (optional)
        attention_weights = tf.squeeze(attention_weights, axis=-1)

        # 5. Return context_vector, attention_weights
        return context_vector, attention_weights

# --- Verification Example ---
# Dummy input shapes
batch_size = 64
num_regions = 64
feature_dim = 2048
rnn_units = 512

# Create dummy inputs
dummy_features = tf.random.normal((batch_size, num_regions, feature_dim))
dummy_hidden_state = tf.random.normal((batch_size, rnn_units))

# Instantiate and call the layer
attention_layer = BahdanauAttentionLayer(units=rnn_units)
context, weights = attention_layer(dummy_features, dummy_hidden_state)

print(f"Context Vector Shape: {context.shape}")
print(f"Attention Weights Shape: {weights.shape}")

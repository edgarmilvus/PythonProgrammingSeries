
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import tensorflow as tf
import numpy as np
from tensorflow.keras.preprocessing.text import Tokenizer
import random

# --- Setup Dummy Data and Tokenizer ---
# Simulate 100 images/captions
NUM_SAMPLES = 100
FEATURE_DIM = 2048
NUM_REGIONS = 64
MAX_CAPTION_LENGTH = 15

# 1. Feature Lookup Table (Simulated pre-extracted features)
image_ids = [f'img_{i}' for i in range(NUM_SAMPLES)]
feature_lookup = {
    img_id: np.random.rand(NUM_REGIONS, FEATURE_DIM).astype(np.float32)
    for img_id in image_ids
}

# 2. Raw Captions
raw_captions = [
    f"<start> a dog is fetching a ball in the park {i} <end>"
    if i % 2 == 0 else f"<start> the quick brown fox jumps over the lazy dog {i} <end>"
    for i in range(NUM_SAMPLES)
]

# 3. Tokenizer Setup
tokenizer = Tokenizer(filters='', lower=False)
tokenizer.fit_on_texts(raw_captions)
VOCAB_SIZE = len(tokenizer.word_index) + 1
START_TOKEN = tokenizer.word_index['<start>']
END_TOKEN = tokenizer.word_index['<end>']
PAD_TOKEN = 0 # Padding index is 0 by default in Keras Tokenizer

# --- Pipeline Implementation ---

def load_and_preprocess(image_id_tensor, raw_caption_tensor):
    """Loads features and tokenizes/splits captions."""
    img_id = image_id_tensor.numpy().decode('utf-8')
    caption = raw_caption_tensor.numpy().decode('utf-8')

    # 1. Feature Loading
    visual_features = feature_lookup[img_id]
    
    # 2. Tokenization
    sequence = tokenizer.texts_to_sequences([caption])[0]
    sequence = np.array(sequence, dtype=np.int32)

    # 3. Sequence Preparation: Input/Target Split
    # Input: [START, w1, w2, ..., wn] (ends before END)
    decoder_input = sequence[:-1]
    # Target: [w1, w2, ..., wn, END] (starts after START)
    decoder_target = sequence[1:]

    return visual_features, decoder_input, decoder_target

@tf.function
def tf_map_function(image_id, raw_caption):
    """Wrapper for the non-TensorFlow operation."""
    # Use tf.py_function to wrap the NumPy/Python logic
    features, dec_in, dec_target = tf.py_function(
        load_and_preprocess,
        inp=[image_id, raw_caption],
        Tout=[tf.float32, tf.int32, tf.int32]
    )
    
    # Set static shapes for optimization (required after tf.py_function)
    features.set_shape([NUM_REGIONS, FEATURE_DIM])
    # The sequence lengths are dynamic, so we only set the rank (1D)
    dec_in.set_shape([None])
    dec_target.set_shape([None])
    
    # The output structure must be ((features, decoder_input), decoder_target)
    return (features, dec_in), dec_target


def create_caption_dataset(image_paths, captions, tokenizer, batch_size):
    """Creates the optimized tf.data pipeline."""
    
    # Create the initial dataset from image IDs and raw captions
    dataset = tf.data.Dataset.from_tensor_slices((image_paths, captions))
    
    # 1. Shuffle the data
    dataset = dataset.shuffle(buffer_size=len(image_paths))
    
    # 2. Map the preprocessing function
    dataset = dataset.map(
        tf_map_function, 
        num_parallel_calls=tf.data.AUTOTUNE
    )
    
    # 3. Dynamic Padding and Batching
    dataset = dataset.padded_batch(
        batch_size,
        # Specify the padding shapes and values for each component
        padded_shapes=(
            # Features: Fixed shape (NUM_REGIONS, FEATURE_DIM)
            ([NUM_REGIONS, FEATURE_DIM], [None]), 
            # Captions: Dynamic length ([None])
            [None]
        ),
        padding_values=(
            # Features are padded with 0.0, Captions with PAD_TOKEN (0)
            (tf.constant(0.0, dtype=tf.float32), tf.constant(PAD_TOKEN, dtype=tf.int32)),
            tf.constant(PAD_TOKEN, dtype=tf.int32)
        ),
        drop_remainder=True # Often preferred for distributed training
    )
    
    # 4. Performance Optimization
    dataset = dataset.prefetch(buffer_size=tf.data.AUTOTUNE)
    
    return dataset

# Example invocation and verification
BATCH_SIZE = 32
dataset = create_caption_dataset(image_ids, raw_captions, tokenizer, BATCH_SIZE)

# Verification
for (img_features, dec_input), dec_target in dataset.take(1):
    print(f"Batch Size: {img_features.shape[0]}")
    print(f"Image Features Shape: {img_features.shape}") # (Batch, 64, 2048)
    print(f"Decoder Input Shape: {dec_input.shape}")     # (Batch, Max_Len_in_Batch)
    print(f"Decoder Target Shape: {dec_target.shape}")   # (Batch, Max_Len_in_Batch)
    
    # Check for dynamic padding (input and target must have the same length)
    assert dec_input.shape[1] == dec_target.shape[1]
    
    # Check padding token (should be 0)
    print(f"Padding Value Check (Target): {dec_target[0][-1]}")
    break

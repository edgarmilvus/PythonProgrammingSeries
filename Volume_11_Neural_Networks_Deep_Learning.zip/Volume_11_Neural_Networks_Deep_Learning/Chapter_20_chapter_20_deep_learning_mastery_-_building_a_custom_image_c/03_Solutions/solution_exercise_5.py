
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import tensorflow as tf
import numpy as np
import math

# --- Mock Model Components for Demonstration ---
# In a real scenario, these would be the trained Keras components.

class MockDecoder:
    """Simulates the attention-enabled Decoder's one-step prediction."""
    def __init__(self, vocab_size, rnn_units):
        self.vocab_size = vocab_size
        self.rnn_units = rnn_units
        # Mock Dense layer for output logits
        self.output_dense = tf.keras.layers.Dense(vocab_size)
        # Mock LSTM state (h, c)
        self.lstm = tf.keras.layers.LSTM(rnn_units, return_sequences=True, return_state=True)
        self.attention = BahdanauAttentionLayer(rnn_units)
        
        # Initialize mock weights for the LSTM to allow state passing
        self.lstm.build(input_shape=[(None, 1, 1), (None, rnn_units), (None, rnn_units)])
        
    def predict_step(self, input_token, features, hidden_state, cell_state):
        """
        Performs one forward pass of the decoder.
        input_token shape: (batch_size, 1)
        features shape: (batch_size, num_regions, feature_dim)
        """
        # Embed the input token (using a mock embedding for simplicity)
        # In a real model, this would be an Embedding layer
        embedding = tf.random.normal((tf.shape(input_token)[0], 1, 512)) 

        # Attention mechanism
        context_vector, _ = self.attention(features, hidden_state)
        
        # Concatenate context with embedding
        context_expanded = tf.expand_dims(context_vector, 1)
        lstm_input = tf.concat([context_expanded, embedding], axis=-1)
        
        # LSTM Step
        output, new_h, new_c = self.lstm(lstm_input, initial_state=[hidden_state, cell_state])
        
        # Output logits
        logits = self.output_dense(tf.squeeze(output, axis=1))
        
        # Get log probabilities
        log_probs = tf.nn.log_softmax(logits)
        
        return log_probs, new_h, new_c

# --- Beam Search Implementation ---

def beam_search_decode(encoder_features, mock_decoder, tokenizer, K=5, max_len=50, alpha=0.7):
    """
    Performs Beam Search decoding for image captioning.
    """
    VOCAB_SIZE = mock_decoder.vocab_size
    START_TOKEN = tokenizer.word_index['<start>']
    END_TOKEN = tokenizer.word_index['<end>']
    RNN_UNITS = mock_decoder.rnn_units
    
    batch_size = tf.shape(encoder_features)[0].numpy()
    
    # Initialize hidden and cell states (often zeros or projected features)
    initial_h = tf.zeros((batch_size, RNN_UNITS))
    initial_c = tf.zeros((batch_size, RNN_UNITS))
    
    # 1. Initialization: Start with the [START] token
    start_token = tf.constant([[START_TOKEN]], dtype=tf.int32)
    
    # Beam structure: (log_probability, sequence, hidden_state, cell_state)
    initial_beam = {
        'score': 0.0,
        'sequence': [START_TOKEN],
        'h': initial_h[0], # Only handling batch size 1 for simplicity in state management
        'c': initial_c[0]
    }
    
    # Replicate the initial beam K times (though only one is necessary initially)
    # We will track the top K candidates globally
    current_beams = [initial_beam]
    finished_beams = []
    
    # 2. Iterative Expansion
    for t in range(max_len):
        
        all_candidates = []
        
        # Prepare inputs for batched prediction (K beams simultaneously)
        k_features = tf.tile(encoder_features, [len(current_beams), 1, 1])
        k_inputs = tf.constant([beam['sequence'][-1] for beam in current_beams], dtype=tf.int32)
        k_inputs = tf.expand_dims(k_inputs, 1)
        k_h = tf.stack([beam['h'] for beam in current_beams])
        k_c = tf.stack([beam['c'] for beam in current_beams])
        
        # Perform one forward pass for all K current beams
        log_probs, next_h, next_c = mock_decoder.predict_step(
            k_inputs, k_features, k_h, k_c
        ) # log_probs shape: (K, VOCAB_SIZE)
        
        # Iterate through the results of the K beams
        for i, beam in enumerate(current_beams):
            
            current_score = beam['score']
            h_state = next_h[i]
            c_state = next_c[i]
            
            # Find the top K vocabulary items for this specific beam
            # We need K * VOCAB_SIZE total candidates, but we only need to 
            # consider the top K from the current step's expansion for efficiency.
            
            # Get the top K indices and scores from the vocabulary
            top_k_indices = tf.math.top_k(log_probs[i], k=K).indices.numpy()
            top_k_scores = log_probs[i].numpy()[top_k_indices]
            
            for word_idx, log_p in zip(top_k_indices, top_k_scores):
                new_score = current_score + log_p
                new_sequence = beam['sequence'] + [word_idx]
                
                candidate = {
                    'score': new_score,
                    'sequence': new_sequence,
                    'h': h_state,
                    'c': c_state
                }
                all_candidates.append(candidate)

        # 3. Top K Selection (from K * K candidates)
        all_candidates.sort(key=lambda x: x['score'], reverse=True)
        
        new_beams = []
        
        for candidate in all_candidates:
            if candidate['sequence'][-1] == END_TOKEN:
                # 4. Termination: Sentence finished
                finished_beams.append(candidate)
            elif len(new_beams) < K:
                # Continue expanding this sequence
                new_beams.append(candidate)
            
            if len(new_beams) == K and len(finished_beams) > 0:
                # Optimization: Stop expanding if we have K active beams 
                # and at least one finished sentence.
                break 

        current_beams = new_beams
        
        if not current_beams and finished_beams:
            break # No more active beams to expand
            
    # Combine remaining active beams with finished beams
    final_results = finished_beams + current_beams
    
    # 5. Normalization and Final Scoring
    # Apply length penalty: Score = LogP / ((length)^alpha)
    
    for beam in final_results:
        length = len(beam['sequence']) - 1 # Exclude START token
        if length > 0:
            length_penalty = math.pow(length, alpha)
            beam['normalized_score'] = beam['score'] / length_penalty
        else:
            beam['normalized_score'] = -1e9 # Penalize zero length

    final_results.sort(key=lambda x: x['normalized_score'], reverse=True)
    
    # Decode sequences back to strings
    top_captions = []
    
    for beam in final_results[:K]:
        sequence = beam['sequence']
        # Remove START and END tokens for final output
        if sequence[0] == START_TOKEN: sequence = sequence[1:]
        if sequence[-1] == END_TOKEN: sequence = sequence[:-1]
            
        decoded_caption = tokenizer.sequences_to_texts([sequence])[0]
        top_captions.append(decoded_caption)
        
    return top_captions

# --- Verification Context Setup ---
# Setup dummy tokenizer and features (reusing Exercise 1 setup)
VOCAB_SIZE = 1000
RNN_UNITS = 512
FEATURE_DIM = 2048
NUM_REGIONS = 64

# Mock tokenizer (need start/end tokens)
mock_tokenizer = Tokenizer(num_words=VOCAB_SIZE)
mock_tokenizer.word_index = {
    '<pad>': 0, '<start>': 1, '<end>': 2, 'the': 3, 'a': 4, 'dog': 5, 'cat': 6
}
mock_tokenizer.index_word = {v: k for k, v in mock_tokenizer.word_index.items()}

mock_decoder = MockDecoder(VOCAB_SIZE, RNN_UNITS)
dummy_features = tf.random.normal((1, NUM_REGIONS, FEATURE_DIM)) # Batch size 1

# Run Beam Search
K_BEAM = 5
print(f"\n--- Beam Search Decoding (K={K_BEAM}, alpha=0.7) ---")
captions = beam_search_decode(dummy_features, mock_decoder, mock_tokenizer, K=K_BEAM)

for i, caption in enumerate(captions):
    print(f"Top {i+1} Caption: {caption}")

# Greedy Decoding (K=1)
print(f"\n--- Greedy Decoding (K=1, alpha=0.7) ---")
greedy_caption = beam_search_decode(dummy_features, mock_decoder, mock_tokenizer, K=1)
print(f"Greedy Caption: {greedy_caption[0]}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from collections import Counter
import math

def get_ngrams(sequence, n):
    """Generates all n-grams from a tokenized sequence."""
    return Counter(zip(*[sequence[i:] for i in range(n)]))

def calculate_ngram_precision(candidate, references, n):
    """
    Calculates the modified n-gram precision (Pn).
    Modified precision clips the count of candidate n-grams 
    to the maximum count found in any single reference.
    """
    candidate_ngrams = get_ngrams(candidate, n)
    
    # Calculate Max Reference Counts (Max_Ref_Count)
    max_ref_counts = Counter()
    for ref in references:
        ref_ngrams = get_ngrams(ref, n)
        for ngram, count in ref_ngrams.items():
            max_ref_counts[ngram] = max(max_ref_counts.get(ngram, 0), count)
            
    # Calculate Modified Count (clipped count)
    clipped_count = 0
    total_candidate_ngrams = sum(candidate_ngrams.values())
    
    if total_candidate_ngrams == 0:
        return 0.0 # Cannot calculate precision if candidate is too short

    for ngram, count in candidate_ngrams.items():
        # Clip the candidate's count at the max count seen in any reference
        clipped_count += min(count, max_ref_counts.get(ngram, 0))
        
    precision = clipped_count / total_candidate_ngrams
    return precision

def calculate_brevity_penalty(candidate_len, reference_lengths):
    """
    Calculates the brevity penalty (BP).
    Finds the 'effective reference length' r, which is the length of the 
    reference closest to the candidate length c.
    """
    
    # Find the closest reference length (r)
    # The effective reference length r is the sum of the reference lengths 
    # that are closest to the candidate length c (when dealing with a corpus).
    # For a single candidate, we find the reference length r that minimizes |c - r|.
    
    closest_r = min(reference_lengths, key=lambda ref_len: (abs(ref_len - candidate_len), ref_len))
    r = closest_r 
    c = candidate_len

    if c > r:
        bp = 1.0
    else:
        # BP = exp(1 - r/c)
        bp = math.exp(1.0 - r / c)
        
    return bp

def calculate_bleu_score(candidates, references_list, N=4):
    """
    Main function to calculate the BLEU-N score for a batch of candidates.
    """
    total_precision_log_sum = 0.0
    total_candidate_len = 0
    total_closest_ref_len = 0
    
    num_candidates = len(candidates)
    
    if num_candidates == 0:
        return 0.0

    # 1. Calculate Precisions and Corpus Lengths
    # We aggregate precisions across the entire corpus (batch)
    
    # Aggregate counts for P1 to P4 across all candidates/references
    corpus_clipped_counts = [0] * N
    corpus_total_counts = [0] * N
    
    for candidate, references in zip(candidates, references_list):
        c = len(candidate)
        total_candidate_len += c
        
        # Determine the effective reference length (r) for this candidate
        ref_lengths = [len(r) for r in references]
        r_single = min(ref_lengths, key=lambda ref_len: (abs(ref_len - c), ref_len))
        total_closest_ref_len += r_single # This implements the effective reference length 'r' for the corpus
        
        # Calculate and aggregate modified counts for P1 to P4
        for n in range(1, N + 1):
            candidate_ngrams = get_ngrams(candidate, n)
            total_candidate_ngrams = sum(candidate_ngrams.values())
            
            if total_candidate_ngrams == 0:
                continue

            # Calculate Max Reference Counts
            max_ref_counts = Counter()
            for ref in references:
                ref_ngrams = get_ngrams(ref, n)
                for ngram, count in ref_ngrams.items():
                    max_ref_counts[ngram] = max(max_ref_counts.get(ngram, 0), count)
            
            # Calculate Clipped Count
            clipped_count = 0
            for ngram, count in candidate_ngrams.items():
                clipped_count += min(count, max_ref_counts.get(ngram, 0))
            
            corpus_clipped_counts[n-1] += clipped_count
            corpus_total_counts[n-1] += total_candidate_ngrams
    
    # 2. Calculate Geometric Mean of Modified Precisions
    log_precision_sum = 0.0
    
    for n in range(N):
        clipped = corpus_clipped_counts[n]
        total = corpus_total_counts[n]
        
        if total == 0 or clipped == 0:
            # If any Pn is zero, the geometric mean becomes zero
            return 0.0
        
        Pn = clipped / total
        log_precision_sum += (1 / N) * math.log(Pn)

    # 3. Calculate Brevity Penalty (BP) based on corpus length
    c = total_candidate_len
    r = total_closest_ref_len
    
    if c == 0:
        return 0.0
        
    if c > r:
        bp = 1.0
    else:
        bp = math.exp(1.0 - r / c)

    # 4. Final BLEU Score
    bleu_score = bp * math.exp(log_precision_sum)
    
    return bleu_score

# --- Verification Challenge ---

candidate_1 = ['the', 'cat', 'sat', 'on', 'the', 'mat']
ref_1a = ['a', 'cat', 'sat', 'on', 'the', 'rug']
ref_1b = ['the', 'cat', 'sat', 'on', 'the', 'mat']
ref_1c = ['the', 'cat', 'is', 'sitting', 'on', 'the', 'mat']
references_1 = [ref_1a, ref_1b, ref_1c]

# Calculate components for Candidate 1 (c=6)
c_len = len(candidate_1)
ref_lens = [len(r) for r in references_1] # [6, 6, 7]
r_len = 6 # Closest length is 6

# Calculate P1-P4
P1 = calculate_ngram_precision(candidate_1, references_1, 1)
P2 = calculate_ngram_precision(candidate_1, references_1, 2)
P3 = calculate_ngram_precision(candidate_1, references_1, 3)
P4 = calculate_ngram_precision(candidate_1, references_1, 4)

# Calculate BP
BP = calculate_brevity_penalty(c_len, ref_lens)

# Calculate Final BLEU-4 (using the corpus function for aggregation)
bleu_4 = calculate_bleu_score([candidate_1], [[ref_1a, ref_1b, ref_1c]])

print("\n--- BLEU Score Verification ---")
print(f"Candidate Length (c): {c_len}")
print(f"Effective Reference Length (r): {r_len}")
print(f"Brevity Penalty (BP): {BP:.4f}")

# Expected Precisions (P1: 6/6=1.0, P2: 5/5=1.0, P3: 4/4=1.0, P4: 3/3=1.0)
print(f"P1: {P1:.4f}")
print(f"P2: {P2:.4f}")
print(f"P3: {P3:.4f}")
print(f"P4: {P4:.4f}")
print(f"Final BLEU-4 Score: {bleu_4:.4f}")

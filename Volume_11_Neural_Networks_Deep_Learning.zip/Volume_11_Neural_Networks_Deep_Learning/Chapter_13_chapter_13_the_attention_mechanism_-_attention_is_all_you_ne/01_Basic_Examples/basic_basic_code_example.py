
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np

def softmax(x):
    # CRITICAL: Subtract the maximum value for numerical stability.
    # This prevents np.exp() from overflowing (exploding gradients/NaN results) 
    # when dealing with very large inputs in deep networks.
    e_x = np.exp(x - np.max(x, axis=-1, keepdims=True))
    
    # Normalize the exponentiated values to create a probability distribution
    return e_x / np.sum(e_x, axis=-1, keepdims=True)

def scaled_dot_product_attention(Q, K, V, mask=None):
    """
    Calculates the Scaled Dot-Product Attention.
    Q: Query matrix (batch_size, seq_len_q, d_k)
    K: Key matrix (batch_size, seq_len_k, d_k)
    V: Value matrix (batch_size, seq_len_k, d_v)
    """
    
    # 1. Determine the dimension of the key vector (d_k)
    # This value is used for scaling.
    d_k = Q.shape[-1]
    
    # 2. Calculate the similarity scores (Dot Product: Q * K^T)
    # K.T transposes the Key matrix. 
    # If Q is (1, 4) and K is (3, 4), then K.T is (4, 3).
    # Scores result: (1, 3) -> Similarity of Q to each of the 3 keys.
    scores = np.matmul(Q, K.T)
    
    # 3. Scale the scores
    # Division by sqrt(d_k) stabilizes the softmax input.
    scaled_scores = scores / np.sqrt(d_k)
    
    # 4. Apply masking (Optional: Used in decoding to hide future tokens)
    if mask is not None:
        # We add a very large negative number to masked positions.
        # When softmax is applied, exp(-1e9) becomes zero, effectively ignoring that context item.
        scaled_scores = scaled_scores + (mask * -1e9)
            
    # 5. Apply softmax to get attention weights
    # These weights are the probabilities (summing to 1) indicating importance.
    attention_weights = softmax(scaled_scores)
    
    # 6. Calculate the final output (Weighted sum of V)
    # Weights (1, 3) multiplied by V (3, 4) results in the output context vector (1, 4).
    output = np.matmul(attention_weights, V)
    
    return output, attention_weights

# --- Define Inputs (d_k = 4) ---

# Q: Query for the element being processed (Shape: 1x4)
Q_input = np.array([[0.5, 0.1, 0.9, 0.3]]) 

# K: Keys of the context elements (Shape: 3x4)
# Key 1 is strong in dimension 1, Key 3 is strong in dimension 3.
K_context = np.array([
    [1.0, 0.0, 0.0, 0.0],  
    [0.0, 1.0, 0.0, 0.0],  
    [0.0, 0.0, 1.0, 0.0]   
])

# V: Values associated with the context elements (Shape: 3x4)
V_context = np.array([
    [10.0, 10.0, 10.0, 10.0], # Value 1 (High magnitude)
    [1.0, 1.0, 1.0, 1.0],     # Value 2 (Low magnitude)
    [5.0, 5.0, 5.0, 5.0]      # Value 3 (Medium magnitude)
])

# --- Execution and Output ---
print("--- Attention Inputs ---")
print(f"Query Q (Focus Element):\n{Q_input}")
print(f"Keys K (Context Definitions):\n{K_context}")
print(f"Values V (Context Content):\n{V_context}")
print("-" * 40)

# Calculate attention
context_vector, weights = scaled_dot_product_attention(Q_input, K_context, V_context)

# --- Results Analysis ---
print("\n--- Attention Results ---")
print(f"Attention Weights (How much Q matched each K):\n{weights}")
print(f"Context Vector (Weighted Sum of V):\n{context_vector}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import torch
import torch.nn as nn
import torch.nn.functional as F
import math

# 1. Positional Encoding Layer
class PositionalEncoding(nn.Module):
    """
    Implements the sinusoidal Positional Encoding (PE) as defined in the paper.
    PE injects information about the relative or absolute position of the tokens 
    in the sequence, compensating for the Transformer's lack of recurrence.
    """
    def __init__(self, d_model: int, max_len: int = 5000):
        super().__init__()
        self.d_model = d_model
        
        # Create a matrix (max_len, d_model) for PE
        pe = torch.zeros(max_len, d_model)
        
        # Create position indices (0, 1, 2, ..., max_len-1)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        
        # Calculate the divisor term (denom) based on 10000^(2i/d_model)
        # Note: i is indexed by d_model // 2 steps
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        
        # Apply sine to even indices
        pe[:, 0::2] = torch.sin(position * div_term)
        
        # Apply cosine to odd indices
        pe[:, 1::2] = torch.cos(position * div_term)
        
        # Add batch dimension for later addition to input (1, max_len, d_model)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Input x shape: (Batch_size, Seq_len, d_model)
        # Add the relevant slice of PE to the input embeddings
        x = x + self.pe[:, :x.size(1)]
        return x

# 2. Scaled Dot-Product Attention Function
def scaled_dot_product_attention(Q, K, V, mask=None):
    """
    The core attention mechanism. Computes the similarity between Q and K, 
    scales the result, applies softmax, and uses the output to weigh V.
    """
    # d_k is the dimension of the key/query vectors (last dimension of Q)
    d_k = Q.size(-1)
    
    # Calculate energy (similarity score): Q * K_transpose
    # Shape: (Batch, Heads, Seq_len, Seq_len)
    scores = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(d_k)
    
    # Apply masking if provided (e.g., for padding or causal masking)
    if mask is not None:
        # Fill masked positions with a very large negative number
        scores = scores.masked_fill(mask == 0, -1e9)
        
    # Apply softmax to get attention weights (summing to 1 across the sequence)
    attention_weights = F.softmax(scores, dim=-1)
    
    # Multiply weights by Value matrix V to get the context vector
    output = torch.matmul(attention_weights, V)
    return output, attention_weights

# 3. Multi-Head Attention Layer
class MultiHeadAttention(nn.Module):
    """
    Wraps the SDPA mechanism, performing h parallel attention calculations 
    and concatenating their results.
    """
    def __init__(self, d_model: int, num_heads: int):
        super().__init__()
        assert d_model % num_heads == 0, "d_model must be divisible by num_heads"
        
        self.d_k = d_model // num_heads # Dimension of K, Q, V per head
        self.num_heads = num_heads
        self.d_model = d_model
        
        # Linear projections for Q, K, V (shared across heads initially)
        self.query_linear = nn.Linear(d_model, d_model)
        self.key_linear = nn.Linear(d_model, d_model)
        self.value_linear = nn.Linear(d_model, d_model)
        
        # Final output projection
        self.output_linear = nn.Linear(d_model, d_model)

    def forward(self, Q, K, V, mask=None):
        batch_size = Q.size(0)
        
        # 3a. Project Q, K, V linearly (d_model -> d_model)
        Q = self.query_linear(Q)
        K = self.key_linear(K)
        V = self.value_linear(V)
        
        # 3b. Split into multiple heads and reshape for parallel processing
        # Transformation: (B, S, D) -> (B, S, H, D_k) -> (B, H, S, D_k)
        Q = Q.view(batch_size, -1, self.num_heads, self.d_k).transpose(1, 2)
        K = K.view(batch_size, -1, self.num_heads, self.d_k).transpose(1, 2)
        V = V.view(batch_size, -1, self.num_heads, self.d_k).transpose(1, 2)
        
        # 3c. Apply Scaled Dot-Product Attention
        x, attn_weights = scaled_dot_product_attention(Q, K, V, mask)
        
        # 3d. Concatenate heads (reverse of splitting)
        # Transformation: (B, H, S, D_k) -> (B, S, H * D_k) -> (B, S, D)
        x = x.transpose(1, 2).contiguous().view(batch_size, -1, self.d_model)
        
        # 3e. Final linear projection
        output = self.output_linear(x)
        return output, attn_weights

# --- Execution Simulation ---

# 4. Define Hyperparameters and Input
D_MODEL = 512       # Embedding dimension
NUM_HEADS = 8       # Number of attention heads
SEQ_LEN = 20        # Length of the input sequence
BATCH_SIZE = 4      # Batch size

# Simulate input embeddings (e.g., output from an embedding layer)
# Shape: (Batch_size, Seq_len, D_MODEL)
input_embeddings = torch.randn(BATCH_SIZE, SEQ_LEN, D_MODEL)

# 5. Instantiate Layers
pe_layer = PositionalEncoding(D_MODEL)
mha_layer = MultiHeadAttention(D_MODEL, NUM_HEADS)

# 6. Forward Pass
# Step 1: Add Positional Encoding
sequence_with_pe = pe_layer(input_embeddings)

# Step 2: Apply Multi-Head Attention (Self-Attention in the Encoder)
# In the encoder, Q, K, and V are all the same input tensor.
context_vectors, final_weights = mha_layer(
    sequence_with_pe, sequence_with_pe, sequence_with_pe
)

# 7. Output Verification
print(f"Input Embedding Shape: {input_embeddings.shape}")
print(f"PE Augmented Sequence Shape: {sequence_with_pe.shape}")
print(f"Output Context Vector Shape: {context_vectors.shape}")
print(f"Attention Weights Shape (B, H, S, S): {final_weights.shape}")
print("\n--- Verification of Attention Properties ---")
# Check if weights sum to 1 across the sequence dimension (dim=-1)
weight_sum_check = torch.allclose(final_weights[0, 0, 0].sum(), torch.tensor(1.0), atol=1e-6)
print(f"First Head, First Token Weights Sum to 1: {weight_sum_check}")

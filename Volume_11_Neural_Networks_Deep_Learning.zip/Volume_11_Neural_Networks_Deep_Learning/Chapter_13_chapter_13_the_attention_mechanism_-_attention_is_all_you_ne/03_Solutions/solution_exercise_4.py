
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import torch.nn as nn

# Assuming MultiHeadAttention (MHA) from Exercise 2 is available.

class PositionWiseFeedForward(nn.Module):
    """ FFN: Two linear layers with ReLU activation. """
    def __init__(self, d_model, d_ff, dropout_rate=0.1):
        super().__init__()
        self.linear1 = nn.Linear(d_model, d_ff)
        self.linear2 = nn.Linear(d_ff, d_model)
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        # x -> Linear1 -> ReLU -> Dropout -> Linear2
        x = F.relu(self.linear1(x))
        x = self.dropout(x)
        x = self.linear2(x)
        return x

class TransformerEncoderLayer(nn.Module):
    def __init__(self, d_model, num_heads, d_ff, dropout_rate=0.1):
        super().__init__()
        
        # 1. Sub-layer 1 components (MHA)
        self.mha = MultiHeadAttention(d_model, num_heads)
        self.dropout1 = nn.Dropout(dropout_rate)
        self.norm1 = nn.LayerNorm(d_model, eps=1e-6)

        # 2. Sub-layer 2 components (FFN)
        # d_ff is typically 4 * d_model
        self.ffn = PositionWiseFeedForward(d_model, d_ff, dropout_rate)
        self.dropout2 = nn.Dropout(dropout_rate)
        self.norm2 = nn.LayerNorm(d_model, eps=1e-6)

    def forward(self, x, mask):
        # x shape: (batch_size, seq_len, d_model)
        
        # --- 1. Attention Block (MHA + Add & Norm) ---
        
        # 1a. Multi-Head Self-Attention (Q=K=V=x)
        attn_output, _ = self.mha(Q=x, K=x, V=x, mask=mask)
        
        # 1b. Dropout
        attn_output = self.dropout1(attn_output)
        
        # 1c. Residual Connection (x + attn_output) and Layer Normalization
        # Post-Normalization: LayerNorm(Input + Sublayer(Input))
        x = self.norm1(x + attn_output) 
        
        # --- 2. FFN Block (FFN + Add & Norm) ---
        
        # Store input for residual connection
        ffn_input = x 
        
        # 2a. Position-wise Feed-Forward Network
        ffn_output = self.ffn(ffn_input)
        
        # 2b. Dropout
        ffn_output = self.dropout2(ffn_output)
        
        # 2c. Residual Connection and Layer Normalization
        x = self.norm2(ffn_input + ffn_output)
        
        return x


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import contextvars
from typing import Dict, Tuple, Any

# Global Context Variable for the KV Cache state (isolated per async task)
KV_CACHE_STATE = contextvars.ContextVar('kv_cache_state', default={})

class IncrementalDecoderLayer:
    """
    Conceptual layer demonstrating state management using contextvars.
    """
    def __init__(self, layer_index):
        self.layer_index = layer_index
        # Placeholder methods for simulation
        self._compute_new_kv = lambda x: f"New_K_L{self.layer_index}_T{x}", f"New_V_L{self.layer_index}_T{x}"
        self._attention_op = lambda Q, K, V: f"Output_L{self.layer_index}"

    def decode_step(self, current_token_index):
        
        # 1. Retrieve the task-local cache dictionary
        task_cache: Dict[int, Tuple] = KV_CACHE_STATE.get()
        
        # 2. Access the cached K and V for this specific layer
        # If not cached yet (first token), returns (None, None)
        cached_K, cached_V = task_cache.get(self.layer_index, (None, None))
        
        # --- Attention Calculation (Conceptual) ---
        # In reality, Q is calculated, then attention uses cached_K/V
        output = self._attention_op(current_token_index, cached_K, cached_V)
        
        # 3. Compute new K and V for the current token
        new_K, new_V = self._compute_new_kv(current_token_index)
        
        # 4. Update the cache for the next step
        
        # Create a new cache dictionary copy to avoid modifying the context in place 
        # (best practice for contextvars)
        new_task_cache = task_cache.copy()
        
        # In a real model: new_task_cache[layer_index] = (torch.cat([cached_K, new_K]), ...)
        # Simulation:
        new_task_cache[self.layer_index] = (new_K, new_V) 
        
        # Update the context variable for the remainder of this task's execution
        KV_CACHE_STATE.set(new_task_cache)
        
        return output

# Example simulation of a task:
# initial_context = KV_CACHE_STATE.set({}) 
# layer = IncrementalDecoderLayer(layer_index=5)
# layer.decode_step(1)
# layer.decode_step(2)
# print(KV_CACHE_STATE.get()) # Shows cache state after 2 steps for layer 5
# KV_CACHE_STATE.reset(initial_context) # Clean up

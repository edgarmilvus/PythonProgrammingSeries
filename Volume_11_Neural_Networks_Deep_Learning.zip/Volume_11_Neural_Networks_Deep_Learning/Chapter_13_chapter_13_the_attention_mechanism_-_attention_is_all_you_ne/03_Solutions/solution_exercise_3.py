
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import torch
import math

def positional_encoding(max_len, d_model):
    """
    Generates the sinusoidal positional encoding matrix.

    Args:
        max_len (int): Maximum sequence length.
        d_model (int): Dimensionality of the model embedding.

    Returns:
        Tensor: Positional encoding matrix (max_len, d_model).
    """
    # Initialize the PE matrix
    pe = torch.zeros(max_len, d_model)
    
    # 1. Create position indices (pos)
    # shape (max_len, 1)
    position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
    
    # 2. Calculate the inverse frequency term (1 / 10000^(2i/d_model))
    # torch.arange(0, d_model, 2) selects indices 0, 2, 4, ... (2i)
    # The exponential term simplifies the calculation of the power
    div_term = torch.exp(
        torch.arange(0, d_model, 2).float() * (-(math.log(10000.0) / d_model))
    )
    # div_term shape: (d_model/2)
    
    # 3. Calculate the argument (pos / (10000^(2i/d_model)))
    # Broadcasting occurs: (max_len, 1) * (d_model/2) -> (max_len, d_model/2)
    argument = position * div_term
    
    # 4. Fill the PE matrix using sin/cos based on index parity
    # Even dimensions (2i) get sine
    pe[:, 0::2] = torch.sin(argument)
    
    # Odd dimensions (2i+1) get cosine
    pe[:, 1::2] = torch.cos(argument)
    
    return pe

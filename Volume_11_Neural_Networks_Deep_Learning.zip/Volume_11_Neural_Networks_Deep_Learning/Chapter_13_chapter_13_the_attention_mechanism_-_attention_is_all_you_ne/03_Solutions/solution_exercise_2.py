
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import torch.nn as nn

# Re-using the scaled_dot_product_attention function from Exercise 1 (assumed available)
# ... (scaled_dot_product_attention definition here) ...

class MultiHeadAttention(nn.Module):
    def __init__(self, d_model, num_heads):
        super().__init__()
        self.d_model = d_model
        self.num_heads = num_heads

        if d_model % num_heads != 0:
            raise ValueError(
                f"d_model ({d_model}) must be divisible by num_heads ({num_heads})"
            )
        
        # Depth per head (d_k)
        self.depth = d_model // num_heads

        # 1. Linear layers for Q, K, V and the final output projection (Wo)
        self.Wq = nn.Linear(d_model, d_model)
        self.Wk = nn.Linear(d_model, d_model)
        self.Wv = nn.Linear(d_model, d_model)
        self.Wo = nn.Linear(d_model, d_model)

    def _split_heads(self, x, batch_size):
        # Input x shape: (batch_size, seq_len, d_model)
        # 1. Reshape to (batch_size, seq_len, num_heads, depth)
        x = x.view(batch_size, -1, self.num_heads, self.depth)
        
        # 2. Transpose to (batch_size, num_heads, seq_len, depth)
        # This moves the head dimension next to the batch dimension for parallel computation
        return x.transpose(1, 2)

    def forward(self, Q, K, V, mask=None):
        batch_size = Q.size(0)

        # 1. Apply linear projections
        Q = self.Wq(Q) 
        K = self.Wk(K) 
        V = self.Wv(V) 

        # 2. Split heads
        Q = self._split_heads(Q, batch_size) # (B, H, Lq, Dk)
        K = self._split_heads(K, batch_size) # (B, H, Lk, Dk)
        V = self._split_heads(V, batch_size) # (B, H, Lv, Dk)

        # 3. Scaled Dot-Product Attention (Calculated in parallel across H heads)
        attention_output, attention_weights = scaled_dot_product_attention(
            Q, K, V, mask
        ) # Output: (B, H, Lq, Dk)

        # 4. Concatenate heads
        # Transpose back to (B, Lq, H, Dk)
        attention_output = attention_output.transpose(1, 2).contiguous()
        
        # Reshape to (B, Lq, D_model)
        output_concatenated = attention_output.view(batch_size, -1, self.d_model)

        # 5. Final linear projection (Wo)
        output = self.Wo(output_concatenated) # (B, Lq, D_model)

        return output, attention_weights

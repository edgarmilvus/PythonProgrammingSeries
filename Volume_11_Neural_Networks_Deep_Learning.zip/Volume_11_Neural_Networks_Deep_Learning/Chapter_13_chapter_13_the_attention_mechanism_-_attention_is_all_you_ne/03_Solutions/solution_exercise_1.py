
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import torch
import torch.nn.functional as F
import math

def scaled_dot_product_attention(Q, K, V, mask=None):
    """
    Calculates the Scaled Dot-Product Attention.

    Args:
        Q (Tensor): Query tensor (..., seq_len_q, d_k)
        K (Tensor): Key tensor (..., seq_len_k, d_k)
        V (Tensor): Value tensor (..., seq_len_v, d_v)
        mask (Tensor, optional): Mask tensor (..., seq_len_q, seq_len_k).

    Returns:
        (Tensor, Tensor): Output context vector and attention weights.
    """
    # 1. Calculate d_k (dimensionality of keys/queries)
    d_k = Q.size(-1)

    # 2. Calculate raw attention scores: Q @ K.T
    # attention_scores shape: (..., seq_len_q, seq_len_k)
    attention_scores = torch.matmul(Q, K.transpose(-2, -1))

    # 3. Scale the scores
    scaled_attention_scores = attention_scores / math.sqrt(d_k)

    # 4. Apply mask (if provided)
    if mask is not None:
        # Mask is typically 0 where attention is allowed, 1 where blocked.
        # We fill masked positions (where mask == 0) with a large negative number.
        scaled_attention_scores = scaled_attention_scores.masked_fill(mask == 0, -1e9)

    # 5. Apply Softmax to get attention weights
    # Softmax is applied across the key dimension (-1)
    attention_weights = F.softmax(scaled_attention_scores, dim=-1)

    # 6. Calculate the context vector output: Weights @ V
    # output shape: (..., seq_len_q, d_v)
    output = torch.matmul(attention_weights, V)

    return output, attention_weights

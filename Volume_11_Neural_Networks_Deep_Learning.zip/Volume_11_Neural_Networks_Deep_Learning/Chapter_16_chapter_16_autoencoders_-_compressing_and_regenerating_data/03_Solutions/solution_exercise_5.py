
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf

# Reuse data and models from Exercise 1
(_, y_test), (_, x_test_labels) = tf.keras.datasets.fashion_mnist.load_data()
x_test_flat = x_test_labels.astype('float32') / 255.0
x_test_flat = x_test_flat.reshape((len(x_test_flat), 784))

# Assuming 'encoder' and 'decoder' (32D models) from Ex 1 are available.

# 2. Image Selection: Trouser (1) and Sneaker (7)
idx_A = np.where(y_test == 1)[0][0] 
image_A = x_test_flat[idx_A:idx_A+1]

idx_B = np.where(y_test == 7)[0][0]
image_B = x_test_flat[idx_B:idx_B+1]

# 3. Latent Vector Extraction
z_A = encoder.predict(image_A)
z_B = encoder.predict(image_B)

# 4. Interpolation Function
N_steps = 10
alpha_values = np.linspace(0, 1, N_steps)

interpolated_vectors = []
for alpha in alpha_values:
    # z_i = (1 - alpha) * z_A + alpha * z_B
    z_i = (1 - alpha) * z_A + alpha * z_B
    interpolated_vectors.append(z_i)

interpolated_vectors = np.array(interpolated_vectors).squeeze()

# 5. Image Generation
generated_images = decoder.predict(interpolated_vectors)

# 6. Visualization
fig, axes = plt.subplots(1, N_steps, figsize=(20, 2))
plt.suptitle("Exercise 5: Latent Space Interpolation (Trouser -> Sneaker)", y=1.1)

for i in range(N_steps):
    ax = axes[i]
    ax.imshow(generated_images[i].reshape(28, 28))
    ax.set_title(f"a={alpha_values[i]:.1f}")
    ax.axis('off')

plt.tight_layout()
plt.show()

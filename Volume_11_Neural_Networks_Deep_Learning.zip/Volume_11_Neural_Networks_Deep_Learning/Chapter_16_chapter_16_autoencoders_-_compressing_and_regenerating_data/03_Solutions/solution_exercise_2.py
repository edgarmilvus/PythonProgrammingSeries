
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
import numpy as np
import time

# Reload data including labels for visualization
(_, _), (x_test_raw, y_test) = tf.keras.datasets.fashion_mnist.load_data()
x_test_flat = x_test_raw.astype('float32') / 255.0
x_test_flat = x_test_flat.reshape((len(x_test_flat), 784))

# Assuming 'encoder' model from Exercise 1 is available and trained.

# Limit sample size for faster t-SNE calculation
N_samples = 5000
x_test_sample = x_test_flat[:N_samples]
y_test_sample = y_test[:N_samples]

# 2. Latent Vector Generation
print("Generating 32D latent features...")
latent_features = encoder.predict(x_test_sample)

# 3. PCA Baseline (784D -> 2D)
print("Applying PCA on raw data...")
pca = PCA(n_components=2)
pca_result = pca.fit_transform(x_test_sample)

# 4. Latent Space Visualization Preparation (32D -> 2D via t-SNE)
print("Applying t-SNE on 32D latent features...")
time_start = time.time()
tsne = TSNE(n_components=2, verbose=0, perplexity=40, n_iter=300)
tsne_result = tsne.fit_transform(latent_features)
print(f"t-SNE finished in {time.time() - time_start:.2f} seconds.")

class_names = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
               'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']

# 5. Comparative Plotting
fig, axes = plt.subplots(1, 2, figsize=(18, 7))

# Plot A: PCA on Raw Data
scatter_pca = axes[0].scatter(pca_result[:, 0], pca_result[:, 1], c=y_test_sample, cmap=plt.cm.get_cmap('Spectral', 10), alpha=0.6)
axes[0].set_title('Plot A: PCA (784D -> 2D) on Raw Data')
cbar_pca = fig.colorbar(scatter_pca, ax=axes[0], ticks=range(10))
cbar_pca.set_ticklabels(class_names)

# Plot B: t-SNE on Latent Space
scatter_tsne = axes[1].scatter(tsne_result[:, 0], tsne_result[:, 1], c=y_test_sample, cmap=plt.cm.get_cmap('Spectral', 10), alpha=0.6)
axes[1].set_title('Plot B: t-SNE (32D -> 2D) on Autoencoder Latent Space')
cbar_tsne = fig.colorbar(scatter_tsne, ax=axes[1], ticks=range(10))
cbar_tsne.set_ticklabels(class_names)

plt.tight_layout()
plt.show()

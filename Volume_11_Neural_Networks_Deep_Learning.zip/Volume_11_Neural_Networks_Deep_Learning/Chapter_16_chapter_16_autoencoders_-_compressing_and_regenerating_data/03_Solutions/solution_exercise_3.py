
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras.layers import Input, Dense
from tensorflow.keras.models import Model

# Reuse data preparation from Exercise 1
(x_train_raw, _), (x_test_raw, _) = tf.keras.datasets.fashion_mnist.load_data()
x_train_clean = x_train_raw.astype('float32') / 255.0
x_test_clean = x_test_raw.astype('float32') / 255.0
input_dim = 784
x_train_clean = x_train_clean.reshape((len(x_train_clean), input_dim))
x_test_clean = x_test_clean.reshape((len(x_test_clean), input_dim))

# 1. Noise Generation Function
def add_gaussian_noise(images, noise_factor=0.5):
    """Adds Gaussian noise to images and clips values to [0, 1]."""
    noise = noise_factor * np.random.normal(loc=0.0, scale=1.0, size=images.shape)
    noisy_images = images + noise
    noisy_images = np.clip(noisy_images, 0., 1.)
    return noisy_images

# 2. Data Preparation
noise_factor = 0.5
x_train_noisy = add_gaussian_noise(x_train_clean, noise_factor)
x_test_noisy = add_gaussian_noise(x_test_clean, noise_factor)

# 3. Model Architecture (Same 784 -> 32 architecture as Ex 1)
latent_dim = 32
input_layer = Input(shape=(input_dim,))
h = Dense(256, activation='relu')(input_layer)
h = Dense(128, activation='relu')(h)
latent_vector = Dense(latent_dim, activation='relu')(h)

h_decoder = Dense(128, activation='relu')(latent_vector)
h_decoder = Dense(256, activation='relu')(h_decoder)
output_layer = Dense(input_dim, activation='sigmoid')(h_decoder)

dae_autoencoder = Model(input_layer, output_layer, name='denoising_autoencoder')

# 4. Training Modification: Use Noisy Input, Clean Target
dae_autoencoder.compile(optimizer='adam', loss='mse')

print("Training Denoising Autoencoder...")
dae_autoencoder.fit(x_train_noisy, x_train_clean, # Key modification here
                    epochs=20, 
                    batch_size=256,
                    shuffle=True,
                    validation_data=(x_test_noisy, x_test_clean),
                    verbose=0)

# 5. Evaluation
decoded_imgs_dae = dae_autoencoder.predict(x_test_noisy)

n = 10
plt.figure(figsize=(20, 6))
for i in range(n):
    # 1. Original Clean Image
    ax = plt.subplot(3, n, i + 1)
    plt.imshow(x_test_clean[i].reshape(28, 28))
    plt.gray()
    ax.set_title("Clean")
    ax.axis('off')
    
    # 2. Noisy Input Image
    ax = plt.subplot(3, n, i + 1 + n)
    plt.imshow(x_test_noisy[i].reshape(28, 28))
    plt.gray()
    ax.set_title("Noisy Input")
    ax.axis('off')
    
    # 3. DAE Reconstructed Image
    ax = plt.subplot(3, n, i + 1 + 2*n)
    plt.imshow(decoded_imgs_dae[i].reshape(28, 28))
    plt.gray()
    ax.set_title("DAE Output")
    ax.axis('off')

plt.suptitle(f"Exercise 3: Denoising Autoencoder Performance (Noise Factor: {noise_factor})")
plt.show()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import tensorflow as tf
from tensorflow.keras.layers import Input, Dense
from tensorflow.keras.models import Model
import numpy as np
import matplotlib.pyplot as plt

# 1. Data Preparation
(x_train_raw, _), (x_test_raw, _) = tf.keras.datasets.fashion_mnist.load_data()

# Normalize and flatten
x_train = x_train_raw.astype('float32') / 255.0
x_test = x_test_raw.astype('float32') / 255.0

input_dim = 784
latent_dim = 32

x_train = x_train.reshape((len(x_train), input_dim))
x_test = x_test.reshape((len(x_test), input_dim))

# 2. Define the Encoder Architecture
input_layer = Input(shape=(input_dim,))
h = Dense(256, activation='relu')(input_layer)
h = Dense(128, activation='relu')(h)
latent_vector = Dense(latent_dim, activation='relu', name='latent_space')(h)

# Define the Encoder Model for later use (Exercise 2 & 5)
encoder = Model(input_layer, latent_vector, name="encoder")

# 3. Define the Decoder Architecture
decoder_input = Input(shape=(latent_dim,))
h_decoder = Dense(128, activation='relu')(decoder_input)
h_decoder = Dense(256, activation='relu')(h_decoder)
output_layer = Dense(input_dim, activation='sigmoid')(h_decoder)

# Define the Decoder Model for later use (Exercise 5)
decoder = Model(decoder_input, output_layer, name="decoder")

# Combine for the Full Autoencoder Model
autoencoder = Model(input_layer, decoder(latent_vector), name='autoencoder')

# 4. Model Compilation and Training
autoencoder.compile(optimizer='adam', loss='mse')

print("Training 32D Autoencoder...")
autoencoder.fit(x_train, x_train,
                epochs=20, # Using 20 epochs for efficiency
                batch_size=256,
                shuffle=True,
                validation_data=(x_test, x_test),
                verbose=0)

# 5. Evaluation
decoded_imgs = autoencoder.predict(x_test)

n = 10
plt.figure(figsize=(20, 4))
for i in range(n):
    # Original image
    ax = plt.subplot(2, n, i + 1)
    plt.imshow(x_test[i].reshape(28, 28))
    plt.gray()
    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)
    
    # Reconstructed image
    ax = plt.subplot(2, n, i + 1 + n)
    plt.imshow(decoded_imgs[i].reshape(28, 28))
    plt.gray()
    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)
plt.suptitle("Exercise 1: Original vs. Reconstructed Images (32D Latent Space)")
plt.show()

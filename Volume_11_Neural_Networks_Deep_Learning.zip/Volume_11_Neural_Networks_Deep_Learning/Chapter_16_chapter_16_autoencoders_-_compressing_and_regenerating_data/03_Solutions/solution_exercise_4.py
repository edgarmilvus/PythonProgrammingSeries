
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import tensorflow as tf
from tensorflow.keras.layers import Input, Dense
from tensorflow.keras.models import Model
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.utils import plot_model

# Reuse data and labels
(_, _), (x_test_raw, y_test) = tf.keras.datasets.fashion_mnist.load_data()
x_test = x_test_raw.astype('float32') / 255.0
x_test = x_test.reshape((len(x_test), 784))
x_train = x_train.reshape((len(x_train), 784)) # Assuming x_train is still in scope from Ex 1

# 1. Architectural Modification: latent_dim = 2
input_dim = 784
latent_dim_2d = 2

# Encoder (784 -> 256 -> 128 -> 2)
input_layer_2d = Input(shape=(input_dim,))
h_2d = Dense(256, activation='relu')(input_layer_2d)
h_2d = Dense(128, activation='relu')(h_2d)
latent_vector_2d = Dense(latent_dim_2d, activation='relu', name='latent_space_2d')(h_2d)

# Decoder (2 -> 128 -> 256 -> 784)
h_decoder_2d = Dense(128, activation='relu')(latent_vector_2d)
h_decoder_2d = Dense(256, activation='relu')(h_decoder_2d)
output_layer_2d = Dense(input_dim, activation='sigmoid')(h_decoder_2d)

autoencoder_2d = Model(input_layer_2d, output_layer_2d, name='autoencoder_2d')
encoder_2d = Model(input_layer_2d, latent_vector_2d, name="encoder_2d")

# 2. Training
autoencoder_2d.compile(optimizer='adam', loss='mse')

print("Training 2D Autoencoder...")
autoencoder_2d.fit(x_train, x_train,
                   epochs=20, 
                   batch_size=256,
                   shuffle=True,
                   validation_data=(x_test, x_test),
                   verbose=0)

# 3. Fidelity Comparison (Requires 'autoencoder' (32D) from Ex 1)
decoded_imgs_32d = autoencoder.predict(x_test[:10]) 
decoded_imgs_2d = autoencoder_2d.predict(x_test[:10])

n = 10
plt.figure(figsize=(20, 6))

for i in range(n):
    # Original
    ax = plt.subplot(3, n, i + 1)
    plt.imshow(x_test[i].reshape(28, 28)); plt.gray(); ax.set_title("Original"); ax.axis('off')
    
    # 32D Reconstruction
    ax = plt.subplot(3, n, i + 1 + n)
    plt.imshow(decoded_imgs_32d[i].reshape(28, 28)); plt.gray(); ax.set_title("32D AE"); ax.axis('off')

    # 2D Reconstruction
    ax = plt.subplot(3, n, i + 1 + 2*n)
    plt.imshow(decoded_imgs_2d[i].reshape(28, 28)); plt.gray(); ax.set_title("2D AE"); ax.axis('off')

plt.suptitle("Exercise 4: Reconstruction Fidelity Comparison (32D vs 2D Bottleneck)")
plt.show()

# 4. Direct Latent Space Plotting
z_2d = encoder_2d.predict(x_test)
class_names = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
               'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']

plt.figure(figsize=(10, 8))
scatter = plt.scatter(z_2d[:, 0], z_2d[:, 1], c=y_test, cmap=plt.cm.get_cmap('Spectral', 10), alpha=0.6)
plt.colorbar(scatter, ticks=range(10)).set_ticklabels(class_names)
plt.title('Exercise 4: Direct 2D Latent Space Embedding (AE Bottleneck)')
plt.xlabel('Latent Dimension 1')
plt.ylabel('Latent Dimension 2')
plt.show()

# 5. Visualization of Model Structure
try:
    plot_model(autoencoder_2d, to_file='autoencoder_2d_structure.png', show_shapes=True, show_layer_names=True)
    print("\nModel structure saved to autoencoder_2d_structure.png")
except ImportError:
    print("\nGraphviz or pydot not installed. Cannot generate model structure diagram.")

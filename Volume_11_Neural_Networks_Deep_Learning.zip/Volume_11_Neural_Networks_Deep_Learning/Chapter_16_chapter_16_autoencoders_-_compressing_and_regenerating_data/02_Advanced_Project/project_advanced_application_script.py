
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense
from tensorflow.keras.optimizers import Adam
import matplotlib.pyplot as plt

# --- 1. Configuration and Hyperparameters ---
INPUT_DIM = 100  # Length of the time series sequence
LATENT_DIM = 10  # Bottleneck size (10% of input)
N_SAMPLES = 5000 # Number of training samples
EPOCHS = 50
BATCH_SIZE = 64
NOISE_FACTOR = 0.3 # Severity of Gaussian noise

# --- 2. Data Generation Function ---
def generate_time_series_data(n_samples, seq_length):
    """Generates smooth, synthetic time series data (e.g., sensor readings)."""
    data = []
    for i in range(n_samples):
        # Create a base signal: sine wave + linear trend
        x = np.linspace(0, 4 * np.pi, seq_length)
        # Introduce slight randomness in amplitude and phase for variability
        amplitude = 1.0 + np.random.uniform(-0.2, 0.2)
        phase = np.random.uniform(0, np.pi / 4)
        
        signal = amplitude * np.sin(x + phase) + (i % 100) / 50.0 
        data.append(signal)
    
    # Normalize the data between 0 and 1
    data = np.array(data)
    min_val = data.min(axis=1, keepdims=True)
    max_val = data.max(axis=1, keepdims=True)
    clean_data = (data - min_val) / (max_val - min_val + 1e-8)
    return clean_data

# Generate the clean dataset (X_train is the target output)
X_clean = generate_time_series_data(N_SAMPLES, INPUT_DIM)

# --- 3. Noise Injection ---
# Create the corrupted input data (X_input)
noise = NOISE_FACTOR * np.random.normal(loc=0.0, scale=1.0, size=X_clean.shape)
X_noisy = X_clean + noise
# Ensure noisy data remains within reasonable bounds (0 to 1)
X_noisy = np.clip(X_noisy, 0., 1.)

# --- 4. Denoising Autoencoder Architecture ---

# Input Layer: Takes the noisy data
input_layer = Input(shape=(INPUT_DIM,), name='input_noisy_data')

# --- Encoder (Compression) ---
encoder_h1 = Dense(64, activation='relu', name='encoder_h1')(input_layer)
encoder_h2 = Dense(32, activation='relu', name='encoder_h2')(encoder_h1)

# Latent Space (Bottleneck)
latent_space = Dense(LATENT_DIM, activation='relu', name='latent_space')(encoder_h2)

# --- Decoder (Reconstruction) ---
decoder_h1 = Dense(32, activation='relu', name='decoder_h1')(latent_space)
decoder_h2 = Dense(64, activation='relu', name='decoder_h2')(decoder_h1)

# Output Layer: Must match the input dimension and use appropriate activation (sigmoid for 0-1 data)
output_layer = Dense(INPUT_DIM, activation='sigmoid', name='output_reconstruction')(decoder_h2)

# Define the DAE Model
denoising_autoencoder = Model(inputs=input_layer, outputs=output_layer)

# --- 5. Compilation and Training ---
denoising_autoencoder.compile(optimizer=Adam(learning_rate=0.001), 
                              loss='mse') # Mean Squared Error (MSE) is the standard reconstruction loss

print("Starting DAE Training...")
history = denoising_autoencoder.fit(
    X_noisy,       # Input: Noisy data
    X_clean,       # Target: Clean data (Crucial DAE step)
    epochs=EPOCHS,
    batch_size=BATCH_SIZE,
    shuffle=True,
    validation_split=0.1,
    verbose=0
)
print("Training complete.")

# --- 6. Evaluation and Visualization ---

# Select a random sample to test reconstruction
sample_index = np.random.randint(0, N_SAMPLES)
test_noisy_sample = X_noisy[sample_index:sample_index+1]
test_clean_sample = X_clean[sample_index]

# Perform the denoising prediction
reconstructed_sample = denoising_autoencoder.predict(test_noisy_sample)[0]

# Plotting the results
plt.figure(figsize=(12, 6))
time_steps = np.arange(INPUT_DIM)

# Plot 1: Clean Signal
plt.plot(time_steps, test_clean_sample, 'b-', label='Original Clean Signal', linewidth=2)

# Plot 2: Noisy Input
plt.plot(time_steps, test_noisy_sample[0], 'r--', alpha=0.5, label='Noisy Input Signal')

# Plot 3: Denoised Output
plt.plot(time_steps, reconstructed_sample, 'g-', label='DAE Reconstructed Signal', linewidth=3, alpha=0.8)

plt.title(f'Denoising Autoencoder Performance (Latent Dim: {LATENT_DIM})')
plt.xlabel('Time Step')
plt.ylabel('Normalized Sensor Value')
plt.legend()
plt.grid(True)
plt.show()

# Display the model summary (optional but useful for review)
# denoising_autoencoder.summary()

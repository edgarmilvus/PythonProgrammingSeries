
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import tensorflow as tf
from tensorflow.keras.layers import Input, Dense
from tensorflow.keras.models import Model
from tensorflow.keras.datasets import mnist
import numpy as np
import matplotlib.pyplot as plt

# --- 1. Configuration and Data Loading ---

# Define the size of the compressed representation (the bottleneck)
LATENT_DIMENSION = 32
INPUT_SHAPE = 784 # 28 * 28 pixels

# Load and preprocess the MNIST dataset
(x_train, _), (x_test, _) = mnist.load_data()

# Normalize the pixel values to be between 0 and 1
x_train = x_train.astype('float32') / 255.0
x_test = x_test.astype('float32') / 255.0

# Flatten the 28x28 images into 784-dimensional vectors
x_train = x_train.reshape((len(x_train), np.prod(x_train.shape[1:])))
x_test = x_test.reshape((len(x_test), np.prod(x_test.shape[1:])))

print(f"Training data shape: {x_train.shape}")
print(f"Test data shape: {x_test.shape}")

# --- 2. Defining the Encoder ---

# Input layer specification
input_img = Input(shape=(INPUT_SHAPE,), name='encoder_input')

# Compression layers (Encoder)
# Layer 1: Reduce 784 -> 128
encoded = Dense(128, activation='relu', name='encoder_dense_1')(input_img)
# Layer 2: Reduce 128 -> 64
encoded = Dense(64, activation='relu', name='encoder_dense_2')(encoded)
# Bottleneck Layer: Latent representation (784 -> 32)
latent_vector = Dense(LATENT_DIMENSION, activation='relu', name='latent_space')(encoded)

# Create the Encoder Model (Input -> Latent Vector)
encoder = Model(input_img, latent_vector, name='encoder')

# --- 3. Defining the Decoder ---

# Input to the decoder is the latent vector (32 dimensions)
latent_input = Input(shape=(LATENT_DIMENSION,), name='decoder_input')

# Expansion layers (Decoder)
# Layer 1: Expand 32 -> 64
decoded = Dense(64, activation='relu', name='decoder_dense_1')(latent_input)
# Layer 2: Expand 64 -> 128
decoded = Dense(128, activation='relu', name='decoder_dense_2')(decoded)
# Output Layer: Reconstruction (128 -> 784). Use sigmoid for 0-1 pixel values.
reconstruction = Dense(INPUT_SHAPE, activation='sigmoid', name='decoder_output')(decoded)

# Create the Decoder Model (Latent Vector -> Reconstruction)
decoder = Model(latent_input, reconstruction, name='decoder')

# --- 4. Combining into the Autoencoder Model ---

# The full autoencoder chains the encoder output to the decoder input
autoencoder_output = decoder(encoder(input_img))

# Create the Autoencoder Model (Input -> Output)
autoencoder = Model(input_img, autoencoder_output, name='autoencoder')

# Compile the model. Use Mean Squared Error (MSE) as the reconstruction loss.
autoencoder.compile(optimizer='adam', loss='mse')

# Display the architectures
print("\n--- Encoder Summary ---")
encoder.summary()
print("\n--- Autoencoder Summary ---")
autoencoder.summary()

# --- 5. Training and Evaluation ---

print("\nStarting Training...")
# Train the model. Note: The input (x) is also the target (y)
history = autoencoder.fit(
    x_train, x_train,
    epochs=10,
    batch_size=256,
    shuffle=True,
    validation_data=(x_test, x_test)
)

# --- 6. Testing Reconstruction ---

# Use the encoder to compress the test data
encoded_imgs = encoder.predict(x_test)
# Use the decoder to reconstruct the images from the compressed representation
decoded_imgs = decoder.predict(encoded_imgs)

# Plotting the results (First 10 test images)
n = 10
plt.figure(figsize=(20, 4))
for i in range(n):
    # Original image
    ax = plt.subplot(2, n, i + 1)
    plt.imshow(x_test[i].reshape(28, 28))
    plt.title("Original")
    plt.gray()
    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)

    # Reconstructed image
    ax = plt.subplot(2, n, i + 1 + n)
    plt.imshow(decoded_imgs[i].reshape(28, 28))
    plt.title("Reconstructed")
    plt.gray()
    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)

plt.show() # In a notebook environment, this displays the plot
tf.print("Model trained and reconstruction demonstrated.")

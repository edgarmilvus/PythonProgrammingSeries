
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np

# --- 1. Define the Input Image and Kernel ---

# A simple 5x5 grayscale image representation (tensor)
# The values represent pixel intensity (0=black, 5=bright).
# We use float32, the standard precision for deep learning tensors.
input_image = np.array([
    [0, 0, 0, 0, 0],
    [0, 1, 1, 1, 0],
    [0, 1, 5, 1, 0],
    [0, 1, 1, 1, 0],
    [0, 0, 0, 0, 0]
], dtype=np.float32)

# A 3x3 kernel (filter) designed for simple blob/center detection.
# This kernel assigns a large positive weight (8) to the center pixel
# and negative weights (-1) to all surrounding neighbors.
kernel = np.array([
    [-1, -1, -1],
    [-1,  8, -1],
    [-1, -1, -1]
], dtype=np.float32)

# --- 2. Setup Convolution Parameters ---

I_h, I_w = input_image.shape  # Input Height and Width (5, 5)
K_h, K_w = kernel.shape      # Kernel Height and Width (3, 3)
stride = 1                   # Step size: the kernel shifts 1 pixel at a time.
padding = 0                  # No padding means the kernel cannot overlap the boundaries.

# Calculate the output feature map dimensions
# Formula (No Padding, Stride=1): O = (I - K) + 1
O_h = int((I_h - K_h) / stride) + 1
O_w = int((I_w - K_w) / stride) + 1

# Initialize the output feature map with zeros
feature_map = np.zeros((O_h, O_w), dtype=np.float32)

# --- 3. Perform the Convolution Operation ---

# Iterate over the resulting feature map dimensions (3x3 in this case)
for i in range(O_h):
    # i is the row index of the output feature map
    for j in range(O_w):
        # j is the column index of the output feature map

        # Determine the starting coordinates for the current window (receptive field)
        # Since stride=1, the offset is simply i and j
        start_row = i * stride
        start_col = j * stride

        # Extract the current receptive field (the slice of the input image)
        # The slice size is determined by the kernel dimensions (3x3)
        receptive_field = input_image[
            start_row : start_row + K_h,
            start_col : start_col + K_w
        ]

        # Perform the element-wise multiplication (Hadamard product)
        # This is the core 'shared weight' operation.
        multiplied_elements = receptive_field * kernel

        # Calculate the sum of the resulting matrix (the dot product)
        # This single scalar value is the output of the convolution for this location.
        convolution_result = np.sum(multiplied_elements)

        # Store the result in the corresponding feature map location
        feature_map[i, j] = convolution_result

# --- 4. Display Results ---
print("--- Input Image (5x5) ---")
print(input_image)
print("\n--- Kernel (3x3 Edge Filter) ---")
print(kernel)
print(f"\n--- Output Feature Map ({O_h}x{O_w}) ---")
print(feature_map)

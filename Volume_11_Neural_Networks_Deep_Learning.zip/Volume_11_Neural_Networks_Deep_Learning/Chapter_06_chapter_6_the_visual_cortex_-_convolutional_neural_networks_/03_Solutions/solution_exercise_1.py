
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np

def manual_conv2d(image, kernel, stride=1, padding=0):
    """
    Performs 2D convolution manually on a grayscale image.
    """
    I_h, I_w = image.shape
    K_h, K_w = kernel.shape

    # 1. Padding Implementation
    if padding > 0:
        padded_image = np.pad(image, padding, mode='constant', constant_values=0)
        I_h, I_w = padded_image.shape
    else:
        padded_image = image

    # 2. Calculate Output Dimensions
    # O = floor((I - K + 2P) / S) + 1
    O_h = int(np.floor((I_h - K_h) / stride)) + 1
    O_w = int(np.floor((I_w - K_w) / stride)) + 1
    
    if O_h <= 0 or O_w <= 0:
        raise ValueError("Configuration results in zero or negative output dimensions.")

    output = np.zeros((O_h, O_w))

    # 3. Convolution Loop
    for i in range(O_h):
        for j in range(O_w):
            # Calculate start indices based on stride
            start_h = i * stride
            start_w = j * stride
            
            # Extract the receptive field (slice)
            receptive_field = padded_image[start_h:start_h + K_h, 
                                           start_w:start_w + K_w]
            
            # Perform element-wise multiplication and summation (dot product)
            output[i, j] = np.sum(receptive_field * kernel)
            
    return output

# Example Input (5x5 grayscale image)
image_input = np.array([
    [10, 20, 30, 40, 50],
    [10, 20, 30, 40, 50],
    [10, 20, 30, 40, 50],
    [10, 20, 30, 40, 50],
    [10, 20, 30, 40, 50]
]) 

# Example Kernel (3x3 filter - Vertical Edge Detector)
kernel_filter = np.array([
    [1, 0, -1],
    [1, 0, -1],
    [1, 0, -1]
]) 

# Test configuration: stride=2, padding=1
# Expected Output Size: (5 - 3 + 2*1) / 2 + 1 = 3x3
output_feature_map = manual_conv2d(image_input, kernel_filter, stride=2, padding=1)

print("Input Image (5x5):\n", image_input)
print("\nKernel (Vertical Edge Detector):\n", kernel_filter)
print("\nOutput Feature Map (3x3, Stride=2, Padding=1):\n", output_feature_map)

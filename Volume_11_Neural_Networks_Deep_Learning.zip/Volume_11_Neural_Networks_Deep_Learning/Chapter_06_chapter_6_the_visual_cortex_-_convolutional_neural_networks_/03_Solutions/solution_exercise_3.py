
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import tensorflow as tf 
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout, BatchNormalization
from tensorflow.keras.utils import plot_model

# Assume input shape for CIFAR-10 is (32, 32, 3) and 10 classes

def build_minimal_cnn(input_shape, num_classes):
    """Baseline structure for parameter comparison."""
    model = Sequential([
        Conv2D(32, (3, 3), activation='relu', input_shape=input_shape, name='conv1_min'),
        MaxPooling2D((2, 2)),
        Conv2D(64, (3, 3), activation='relu', name='conv2_min'),
        MaxPooling2D((2, 2)),
        Flatten(),
        Dense(128, activation='relu'),
        Dense(num_classes, activation='softmax')
    ])
    return model

def build_enhanced_cnn(input_shape, num_classes):
    """Enhanced structure with BN, Dropout, and 5x5 Conv1."""
    model = Sequential([
        # 1. Conv1 (5x5 kernel)
        Conv2D(32, (5, 5), input_shape=input_shape, padding='same', name='conv1_enh'),
        # 2. Batch Normalization
        BatchNormalization(name='bn1'),
        tf.keras.layers.Activation('relu'),
        MaxPooling2D((2, 2), name='pool1'),
        
        # 3. Conv2 (3x3 kernel)
        Conv2D(64, (3, 3), padding='same', name='conv2_enh'),
        # 4. Batch Normalization
        BatchNormalization(name='bn2'),
        tf.keras.layers.Activation('relu'),
        MaxPooling2D((2, 2), name='pool2'),
        
        # 5. Dropout (0.3)
        Dropout(0.3, name='dropout'), 
        
        # 6. Transition to Dense
        Flatten(),
        Dense(128, activation='relu', name='dense1'),
        Dense(num_classes, activation='softmax', name='output')
    ])
    
    # Compile model for training setup
    model.compile(optimizer='adam', 
                  loss='sparse_categorical_crossentropy', 
                  metrics=['accuracy'])
    return model

# Parameter Calculation Setup (Assuming 3 input channels)
C_in = 3
C_out_1 = 32

# Minimal CNN Conv1 (3x3 kernel)
K_min = 3
params_min_conv1 = (K_min**2 * C_in + 1) * C_out_1
# (9 * 3 + 1) * 32 = 28 * 32 = 896

# Enhanced CNN Conv1 (5x5 kernel)
K_enh = 5
params_enh_conv1 = (K_enh**2 * C_in + 1) * C_out_1
# (25 * 3 + 1) * 32 = 76 * 32 = 2432

# BN parameters (4 * C_out): 4 * 32 = 128 (gamma, beta, moving mean, moving variance)

print(f"Parameters for Minimal Conv1 (3x3): {params_min_conv1}")
print(f"Parameters for Enhanced Conv1 (5x5): {params_enh_conv1}")
print(f"Batch Norm 1 Parameters (32 channels): 128 (4 trainable, 2 non-trainable)")

# Example Model Summary (showing structure)
enhanced_model = build_enhanced_cnn((32, 32, 3), 10)
# enhanced_model.summary() # Output suppressed for brevity


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# Input Dimensions: H=56, W=56, Cin=128
H_in, W_in, C_in = 56, 56, 128

# --- Block A Calculations (Deep and Narrow) ---
# Layer A1 (K=3, Cin=128, Cout=64)
K_A1, C_out_A1 = 3, 64
H_out_A1 = W_out_A1 = H_in - K_A1 + 1 # 56 - 3 + 1 = 54

params_A1 = (K_A1**2 * C_in + 1) * C_out_A1
# (9 * 128 + 1) * 64 = 73,792
flops_A1 = K_A1**2 * C_in * C_out_A1 * H_out_A1 * W_out_A1
# 9 * 128 * 64 * 54 * 54 = 336,989,184

# Layer A2 (K=3, Cin=64, Cout=64)
K_A2, C_in_A2, C_out_A2 = 3, 64, 64
H_out_A2 = W_out_A2 = H_out_A1 - K_A2 + 1 # 54 - 3 + 1 = 52

params_A2 = (K_A2**2 * C_in_A2 + 1) * C_out_A2
# (9 * 64 + 1) * 64 = 36,928
flops_A2 = K_A2**2 * C_in_A2 * C_out_A2 * H_out_A2 * W_out_A2
# 9 * 64 * 64 * 52 * 52 = 99,886,592

total_params_A = params_A1 + params_A2 # 110,720
total_flops_A = flops_A1 + flops_A2 # 436,875,776
output_dims_A = f"{H_out_A2}x{W_out_A2}x{C_out_A2}"

# --- Block B Calculations (Shallow and Wide) ---
# Layer B1 (K=5, Cin=128, Cout=128)
K_B1, C_out_B1 = 5, 128
H_out_B1 = W_out_B1 = H_in - K_B1 + 1 # 56 - 5 + 1 = 52

params_B1 = (K_B1**2 * C_in + 1) * C_out_B1
# (25 * 128 + 1) * 128 = 409,728
flops_B1 = K_B1**2 * C_in * C_out_B1 * H_out_B1 * W_out_B1
# 25 * 128 * 128 * 52 * 52 = 2,197,350,400

total_params_B = params_B1 # 409,728
total_flops_B = flops_B1 # 2,197,350,400
output_dims_B = f"{H_out_B1}x{W_out_B1}x{C_out_B1}"

print(f"--- Block A (Deep/Narrow) ---")
print(f"Total Parameters: {total_params_A:,}")
print(f"Total FLOPs: {total_flops_A:,}")
print(f"Final Output Dimensions: {output_dims_A}")
print(f"\n--- Block B (Shallow/Wide) ---")
print(f"Total Parameters: {total_params_B:,}")
print(f"Total FLOPs: {total_flops_B:,}")
print(f"Final Output Dimensions: {output_dims_B}")

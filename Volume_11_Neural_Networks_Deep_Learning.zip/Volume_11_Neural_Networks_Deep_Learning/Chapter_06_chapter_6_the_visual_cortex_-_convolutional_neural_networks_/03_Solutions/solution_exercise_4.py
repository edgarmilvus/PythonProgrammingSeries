
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt

# Using the EnhancedCNN structure from 6.4.3 as the basis
def get_model_and_layers(input_shape, num_classes):
    # This function would load the trained EnhancedCNN
    model = build_enhanced_cnn(input_shape, num_classes)
    
    # Define intermediate models to extract activations
    layer_names = ['conv1_enh', 'conv2_enh']
    
    # Create models that output the intermediate layer results
    intermediate_layer_models = [
        tf.keras.Model(inputs=model.input, outputs=model.get_layer(name).output)
        for name in layer_names
    ]
    return intermediate_layer_models, layer_names

def visualize_feature_maps(intermediate_models, image, layer_names, num_maps=8):
    
    # --- 1. Preprocessing (Simulated) ---
    # In a real scenario, 'image' would be loaded and normalized (e.g., shape (1, 32, 32, 3))
    # For demonstration, we use a placeholder image
    if image is None:
        image = np.random.rand(1, 32, 32, 3).astype('float32') 

    plt.figure(figsize=(15, 6 * len(layer_names)))
    
    for i, model in enumerate(intermediate_models):
        layer_name = layer_names[i]
        
        # 2. Get activations
        activations = model.predict(image)[0] # Shape (H, W, Channels)
        
        # Select a subset of channels to display
        n_channels = min(activations.shape[-1], num_maps)
        
        print(f"Layer: {layer_name}. Output shape: {activations.shape}")
        
        # 3. Visualization
        for j in range(n_channels):
            ax = plt.subplot(len(layer_names), num_maps, i * num_maps + j + 1)
            
            # Extract the j-th channel
            feature_map = activations[:, :, j]
            
            # Normalize for visualization clarity
            feature_map -= feature_map.mean()
            feature_map /= (feature_map.std() + 1e-5)
            
            ax.imshow(feature_map, cmap='viridis') # Use 'viridis' or 'gray'
            ax.set_title(f'Channel {j}', fontsize=8)
            ax.axis('off')
            
    plt.suptitle("Feature Map Visualization (Shallow vs. Deep Layers)", y=1.02)
    plt.tight_layout()
    # plt.show() # Disabled for execution environment

# Setup: (Requires build_enhanced_cnn from 6.4.3)
# intermediate_models, layer_names = get_model_and_layers((32, 32, 3), 10)
# visualize_feature_maps(intermediate_models, None, layer_names) 

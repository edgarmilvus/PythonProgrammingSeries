
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np

def manual_max_pool2d(feature_map, pool_size=(2, 2), stride=(2, 2)):
    """
    Performs 2D Max Pooling manually.
    Assumes no padding.
    """
    H, W = feature_map.shape
    P_h, P_w = pool_size
    S_h, S_w = stride

    # Calculate output dimensions
    # O = floor((I - K) / S) + 1
    O_h = int(np.floor((H - P_h) / S_h)) + 1
    O_w = int(np.floor((W - P_w) / S_w)) + 1
    
    output = np.zeros((O_h, O_w))

    # Pooling Loop
    for i in range(O_h):
        for j in range(O_w):
            # Calculate start indices based on stride
            start_h = i * S_h
            start_w = j * S_w
            
            # Extract the pooling window
            window = feature_map[start_h:start_h + P_h, 
                                 start_w:start_w + P_w]
            
            # Select the maximum value in the window
            output[i, j] = np.max(window)
            
    return output

# Example Input (4x4 feature map)
feature_map_input = np.array([
    [1, 5, 2, 8],
    [3, 4, 6, 7],
    [9, 1, 0, 3],
    [5, 2, 4, 1]
]) 

# Test configuration: 2x2 pooling with stride 2
output_pooled = manual_max_pool2d(feature_map_input, pool_size=(2, 2), stride=(2, 2))

print("Input Feature Map (4x4):\n", feature_map_input)
print("\nOutput Max Pooled Map (2x2, Stride=2):\n", output_pooled)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import tensorflow as tf
from tensorflow.keras.datasets import cifar10
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from tensorflow.keras.utils import to_categorical
import numpy as np

# --- 1. Configuration and Data Loading ---

# Define the number of classes and input shape (32x32 RGB images)
NUM_CLASSES = 10
INPUT_SHAPE = (32, 32, 3)

# Load the CIFAR-10 dataset
# The data is split into training and testing sets
(x_train, y_train), (x_test, y_test) = cifar10.load_data()

# --- 2. Data Preprocessing and Normalization ---

# Convert pixel values (0-255) to floating-point numbers (0.0-1.0)
# This normalization stabilizes training and improves convergence speed
x_train = x_train.astype('float32') / 255.0
x_test = x_test.astype('float32') / 255.0

# Convert labels (integers 0-9) into one-hot encoded vectors
# Required for categorical cross-entropy loss function
y_train = to_categorical(y_train, num_classes=NUM_CLASSES)
y_test = to_categorical(y_test, num_classes=NUM_CLASSES)

# --- 3. Defining the CNN Architecture (The Convolutional Base) ---

model = Sequential()

# Block 1: Initial feature extraction
# Uses 32 filters (kernels) to learn basic features (edges, corners)
model.add(Conv2D(32, (3, 3), activation='relu', padding='same', input_shape=INPUT_SHAPE))
# Downsampling the feature map size by half (from 32x32 to 16x16)
model.add(MaxPooling2D(pool_size=(2, 2)))

# Block 2: Intermediate feature extraction
# Increases filter count to 64 to learn more complex patterns (textures, parts)
model.add(Conv2D(64, (3, 3), activation='relu', padding='same'))
# Downsampling again (from 16x16 to 8x8)
model.add(MaxPooling2D(pool_size=(2, 2)))

# Block 3: High-level feature extraction
# Further increases filter count to 128 to capture abstract object parts
model.add(Conv2D(128, (3, 3), activation='relu', padding='same'))
# Final downsampling of the feature maps (from 8x8 to 4x4)
model.add(MaxPooling2D(pool_size=(2, 2)))

# Optional: Add a Dropout layer to help prevent overfitting in the convolutional base
model.add(Dropout(0.25))

# --- 4. Transition to the Classifier Head ---

# Flatten the 3D feature maps (4x4x128) into a 1D vector (2048 elements)
# This bridges the Conv layers and the Dense classification layers
model.add(Flatten())

# --- 5. The Fully Connected (Dense) Classifier Head ---

# Hidden layer for high-level reasoning based on extracted features
model.add(Dense(512, activation='relu'))
# Dropout to regularize the dense layers
model.add(Dropout(0.5))

# Output layer: 10 units (one for each class) with Softmax for probability distribution
model.add(Dense(NUM_CLASSES, activation='softmax'))

# --- 6. Model Compilation and Training ---

# Use Adam optimizer and categorical cross-entropy for multi-class classification
model.compile(optimizer='adam',
              loss='categorical_crossentropy',
              metrics=['accuracy'])

# Display the model summary (showing parameter counts and output shapes)
model.summary()

# Define training parameters
BATCH_SIZE = 64
EPOCHS = 20

print("\nStarting CNN training...")
history = model.fit(x_train, y_train,
                    batch_size=BATCH_SIZE,
                    epochs=EPOCHS,
                    validation_data=(x_test, y_test),
                    shuffle=True,
                    verbose=1)

# --- 7. Evaluation ---

print("\nEvaluating model performance on test set...")
loss, accuracy = model.evaluate(x_test, y_test, verbose=0)
print(f"Test Loss: {loss:.4f}")
print(f"Test Accuracy: {accuracy*100:.2f}%")

# Example Inference: Predict the class of the very first test image
sample_image = x_test[0:1] # Keep dimensions for prediction
predictions = model.predict(sample_image)
predicted_class = np.argmax(predictions[0])
print(f"Predicted Class for sample 0: {predicted_class}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np

# --- 1. Define Hyperparameters and Dimensions ---
# Input dimension (size of the vocabulary or feature vector)
D_input = 5
# Hidden dimension (size of the memory vector)
D_hidden = 3
# Output dimension (size of the prediction space, e.g., next character logits)
D_output = 4
# Sequence length (number of time steps)
T = 4

# --- 2. Initialize Weights and Biases (Weight Sharing) ---
# Weights for input-to-hidden transition (W_xh)
# Shape: (D_input, D_hidden) -> (5, 3)
W_xh = np.random.randn(D_input, D_hidden) * 0.01

# Weights for hidden-to-hidden transition (W_hh)
# Shape: (D_hidden, D_hidden) -> (3, 3)
W_hh = np.random.randn(D_hidden, D_hidden) * 0.01

# Weights for hidden-to-output transition (W_hy)
# Shape: (D_hidden, D_output) -> (3, 4)
W_hy = np.random.randn(D_hidden, D_output) * 0.01

# Biases for the hidden state calculation
b_h = np.zeros((1, D_hidden)) # Shape: (1, 3)

# Biases for the output calculation
b_y = np.zeros((1, D_output)) # Shape: (1, 4)

# --- 3. Prepare Input Sequence and Initial State ---
# Input sequence X (T time steps, D_input features each)
# Simulating 4 unique one-hot encoded inputs (T=4, D_input=5)
X = np.array([
    [1, 0, 0, 0, 0], # Input x_1
    [0, 1, 0, 0, 0], # Input x_2
    [0, 0, 1, 0, 0], # Input x_3
    [0, 0, 0, 1, 0]  # Input x_4
])

# Initialize the hidden state (h_0) to zeros
h_prev = np.zeros((1, D_hidden)) # Shape: (1, 3)

# Store hidden states and outputs for inspection
hidden_states = {}
outputs = {}

# --- 4. The Recurrent Forward Pass (Unrolling the Network) ---

print("--- Starting RNN Forward Pass (T=4) ---")

for t in range(T):
    # Get the current input vector (x_t)
    x_t = X[t:t+1, :] # Slicing ensures shape (1, D_input)

    # 4a. Calculate the activation for the current time step (a_t)
    # a_t = (W_xh * x_t) + (W_hh * h_{t-1}) + b_h
    # Input projection: (1, 5) @ (5, 3) -> (1, 3)
    input_projection = x_t @ W_xh

    # Recurrent projection: (1, 3) @ (3, 3) -> (1, 3)
    recurrent_projection = h_prev @ W_hh

    # Total activation (before non-linearity)
    a_t = input_projection + recurrent_projection + b_h

    # 4b. Apply non-linearity (tanh) to get the new hidden state (h_t)
    # h_t is the memory for the current time step
    h_t = np.tanh(a_t)

    # 4c. Calculate the output (y_t)
    # y_t = (W_hy * h_t) + b_y
    # Output projection: (1, 3) @ (3, 4) -> (1, 4)
    y_t = h_t @ W_hy + b_y

    # 4d. Store results and update the previous state for the next step
    hidden_states[t] = h_t
    outputs[t] = y_t
    h_prev = h_t # CRITICAL: The memory update

    print(f"\nTime Step t={t+1}:")
    print(f"  Input (x_{t+1}): {x_t.flatten()}")
    print(f"  Hidden State (h_{t+1}): {h_t.flatten()[:4]}...")
    print(f"  Output Logits (y_{t+1}): {y_t.flatten()}")

print("\n--- Forward Pass Complete ---")

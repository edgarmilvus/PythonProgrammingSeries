
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np

# --- 1. Setup and Helper Functions ---
np.random.seed(42)

DEPENDENCY_GAP = 15 
T = DEPENDENCY_GAP + 1 + 10 # Total sequence length (Start + Gap + Target + Noise)
D_h = 10 # Hidden dimension
D_x = 3  # Input dimension (Simplified vocab: A, B, Noise)

# Simplified weights (initialized to small values typical for RNNs)
W_hh = np.random.randn(D_h, D_h) * 0.01 
W_xh = np.random.randn(D_x, D_h) * 0.01
bh = np.zeros((D_h, 1))

# Simplification: Assume W_hh is diagonal for clearer demonstration of multiplication effect
# W_hh = np.diag(np.ones(D_h) * 0.8) # If weights are < 1, vanishing occurs

# Initialize h0
h0 = np.zeros((D_h, 1))

def tanh_derivative(h):
    """Calculates the derivative of tanh: 1 - tanh(x)^2 = 1 - h^2"""
    return (1 - h**2)

def rnn_forward(X_sequence, W_hh, W_xh, bh, h0):
    H = [h0]
    A = []
    h_t = h0
    for x_t in X_sequence:
        # Calculate pre-activation
        a_t = W_xh.T @ x_t + W_hh @ h_t + bh
        h_t = np.tanh(a_t)
        H.append(h_t)
        A.append(a_t)
    return H, A

def calculate_dL_dh_recurrent(H_states, W_hh, T_start, T_end):
    """
    Simulates the backward pass for the gradient flowing from L_T_end 
    back to the hidden state h_T_start. This isolates the long dependency chain.
    
    We calculate: dL/dh_T_start = (dL/dh_T_end) * product(dh_t / dh_t-1)
    
    T_end is the time step where the loss occurs (e.g., t=29)
    T_start is the time step where the critical information was stored (e.g., t=12)
    """
    # Start with a reference gradient (dL/dh_T_end). Assume it's a vector of ones for simplicity.
    dL_dh = np.ones((D_h, 1)) 
    
    # Propagate backward through the dependency gap (from T_end down to T_start + 1)
    # The loop runs for (T_end - T_start - 1) steps
    print(f"Propagating gradient from T={T_end} back to T={T_start + 1}")
    
    for t in range(T_end, T_start + 1, -1):
        h_t = H_states[t]
        
        # 1. Derivative of activation: tanh'(a_t)
        deriv_tanh = tanh_derivative(h_t)
        
        # 2. Gradient flow through time: dL/dh_t-1 = (dL/dh_t * tanh'(a_t)) @ W_hh_T
        dL_dh = (dL_dh * deriv_tanh) # Hadamard product
        dL_dh = W_hh.T @ dL_dh       # Matrix multiplication (recurrent connection)
        
        # Log gradient norm during propagation
        if t % 5 == 0 or t == T_start + 1 or t == T_end:
             print(f"  t={t}: |dL/dh| norm = {np.linalg.norm(dL_dh):.10f}")
             
    # dL_dh now represents dL/dh_T_start
    return dL_dh

# --- 2. Sequence Generation (Simplified) ---
# X_sequence: [Noise]*10, [A], [Noise]*15, [D]
# The token 'A' is at index 11 (T=12)
# The output prediction happens at T=29 (index 28)
X_sequence = []
h_states_list = []

# Create 30 time steps of random input (D_x=3, one-hot)
for i in range(T):
    x_t = np.random.rand(D_x, 1) * 0.1 # Small noise input
    X_sequence.append(x_t)

# Inject the critical token 'A' at T=12 (index 11)
T_start_index = 11
X_sequence[T_start_index] = np.array([[1.0], [0.0], [0.0]]) # Token 'A'

# Define the loss time step (T=29, index 28)
T_end_index = T - 2 

# --- 3. Forward Pass & Gradient Analysis ---
H_states, A_states = rnn_forward(X_sequence, W_hh, W_xh, bh, h0)

# Calculate the gradient flowing from the loss at T_end_index back to the memory h_T_start_index
print("\n--- Vanishing Gradient Analysis (BPTT Simulation) ---")
final_dL_dh = calculate_dL_dh_recurrent(H_states, W_hh, T_start_index, T_end_index)

# Calculate the gradient of W_hh contributed by the long path
# dL/dW_hh_long_path = dL/dh_T_start * dh_T_start/dW_hh (simplified)
# The true BPTT requires summation, but this product isolates the vanishing effect.
grad_norm_long_path = np.linalg.norm(final_dL_dh)
print(f"\nGradient of hidden state at T={T_start_index + 1} (|dL/dh|): {grad_norm_long_path:.15f}")

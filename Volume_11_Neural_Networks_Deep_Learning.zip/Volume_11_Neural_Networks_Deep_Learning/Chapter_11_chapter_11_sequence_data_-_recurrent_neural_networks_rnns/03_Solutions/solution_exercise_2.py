
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Pseudo-code structure for BPTT gradient calculation (T=4)
import numpy as np

def calculate_bptt_gradient(T, W_hh, H_states, Inputs, Losses):
    # W_hh_T represents the transpose of the recurrent weight matrix
    # H_states stores h_0, h_1, ..., h_T
    
    # Initialize total gradient accumulator
    total_grad_Whh = np.zeros_like(W_hh)
    
    # Initialize the gradient flowing backward through time (dL/dh_t)
    # This represents the cumulative gradient coming from all future time steps
    dL_dh_next = np.zeros(W_hh.shape[0]) # (Dh,) dimension
    
    # Start backward loop from T down to 1 (t=4, 3, 2, 1)
    for t in range(T, 0, -1):
        h_t = H_states[t]
        h_prev = H_states[t-1]
        
        # 1. Calculate the gradient of L_t with respect to h_t (dL_t/dh_t)
        # This includes the local gradient from the output layer at time t
        dL_dh_local = Losses[t].backward(h_t) # Placeholder: derivative of L_t w.r.t h_t
        
        # 2. Add the gradient flowing from future time steps (dL/dh_t = dL_t/dh_t + dL_t+1/dh_t)
        current_dL_dh = dL_dh_local + dL_dh_next
        
        # 3. Calculate the derivative of the activation function (tanh'(a_t))
        # tanh_derivative = 1 - h_t^2 (assuming h_t = tanh(a_t))
        tanh_deriv = (1 - h_t**2) 
        
        # 4. Calculate the gradient flowing back through the recurrent connection (d(h_t)/d(a_t) * d(a_t)/d(W_hh))
        # dL/da_t = current_dL_dh * tanh_deriv
        dL_da_t = current_dL_dh * tanh_deriv
        
        # 5. Calculate the local gradient dL_t / dW_hh using the current dL/da_t and the previous state h_prev
        # dL/dW_hh = dL/da_t * h_prev.T
        local_grad_Whh = dL_da_t @ h_prev.T 
        
        # 6. Accumulate the local gradient for the shared parameter
        total_grad_Whh += local_grad_Whh

        # 7. Update dL_dh_next for the next time step (t-1)
        # dL/dh_t-1 = (dL/da_t) @ W_hh_T
        dL_dh_next = W_hh.T @ dL_da_t

    return total_grad_Whh

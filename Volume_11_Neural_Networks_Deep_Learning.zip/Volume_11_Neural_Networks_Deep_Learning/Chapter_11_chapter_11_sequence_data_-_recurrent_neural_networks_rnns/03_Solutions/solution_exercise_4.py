
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np

# Given Data
RAW_TEXT = "The Recurrent Neural Network handles sequences by sharing weights across time steps."
VOCAB = sorted(list(set(RAW_TEXT.replace(" ", ""))))
VOCAB_SIZE = len(VOCAB)
CHAR_TO_IDX = {char: i for i, char in enumerate(VOCAB)}
IDX_TO_CHAR = {i: char for char, i in CHAR_TO_IDX.items()}

# Define the BPTT window size
T = 10 

# --- 1. One-Hot Encoding Function ---
def one_hot_encode(text, char_to_idx, vocab_size):
    L = len(text)
    encoded = np.zeros((L, vocab_size))
    for i, char in enumerate(text):
        if char in char_to_idx:
            idx = char_to_idx[char]
            encoded[i, idx] = 1
    return encoded

# --- 2. Extended Slicing for Input/Target Pairs ---
def create_bptt_windows(encoded_sequence, T):
    L, V = encoded_sequence.shape
    
    # Calculate how many full batches of size T we can extract
    num_batches = L // T
    
    X_batches = []
    Y_batches = []
    
    # Iterate through the sequence in steps of T
    for i in range(num_batches):
        start_idx = i * T
        end_idx = (i + 1) * T
        
        # Input batch X: sequence from start_idx up to (end_idx - 1)
        # Since we are using full windows of size T, this is simply [start_idx : end_idx]
        X_batch = encoded_sequence[start_idx:end_idx, :]
        
        # Target batch Y: sequence from (start_idx + 1) up to end_idx
        # This requires looking one step ahead of the X input.
        # Target for X[t] is X[t+1]
        
        # Y must be T elements long. If end_idx is the end of the sequence, 
        # we must handle the boundary. Since we only loop up to num_batches,
        # we ensure that the required target (end_idx) is within the sequence bounds (L-1).
        
        # If L=79, T=10, num_batches=7. 
        # Batch 7 (i=6): start=60, end=70. X is 60:70. Y is 61:71. 
        # The sequence length is 79. We must ensure Y doesn't exceed L.
        
        # The standard sequence modeling setup:
        # X batch [t=0..T-1] -> Target Y batch [t=1..T]
        
        # Input X: [start_idx : end_idx]
        X_batch = encoded_sequence[start_idx : end_idx]
        
        # Target Y: [start_idx + 1 : end_idx + 1]
        # If end_idx + 1 > L, we must pad or truncate. 
        # Since we use floor(L/T), the last target element will be at L-1.
        
        # Example: L=79, T=10. num_batches=7.
        # i=0: X=0:10. Y=1:11.
        # i=6: X=60:70. Y=61:71. (L=79, indices go up to 78).
        # We must ensure the sequence length L is used for slicing the target.
        
        # We need L to be at least (num_batches * T) + 1 to guarantee the target for the last X element exists.
        
        # If we use the sequence length L:
        X_batch = encoded_sequence[start_idx : start_idx + T]
        Y_batch = encoded_sequence[start_idx + 1 : start_idx + 1 + T]
        
        # To handle the end (where the target might not exist), we stop the loop one step early
        # or truncate the last batch if L % T != 0.
        
        # Standard approach: Create batches of length T, dropping the remainder.
        if start_idx + T < L: # Ensure X is fully T long
            X_batch = encoded_sequence[start_idx : start_idx + T]
            
            # Target Y is X shifted by one step
            Y_batch = encoded_sequence[start_idx + 1 : start_idx + 1 + T]
            
            X_batches.append(X_batch)
            Y_batches.append(Y_batch)

    return X_batches, Y_batches

# --- 3. Execution and Verification ---
encoded_seq = one_hot_encode(RAW_TEXT, CHAR_TO_IDX, VOCAB_SIZE)
X_batches, Y_batches = create_bptt_windows(encoded_seq, T)

print(f"Raw Text Length: {len(RAW_TEXT)}")
print(f"Vocabulary Size: {VOCAB_SIZE}")
print(f"Total Encoded Sequence Shape: {encoded_seq.shape}")
print(f"Number of BPTT Windows (T={T}): {len(X_batches)}")
print("-" * 30)

# Verification Output
if X_batches:
    first_X_batch = X_batches[0]
    first_Y_batch = Y_batches[0]
    
    print(f"Shape of first input batch (X_batches[0]): {first_X_batch.shape}")
    
    # Determine the character corresponding to the first target element Y[0]
    # Y[0] is the target for X[0] (which is 'T')
    target_idx = np.argmax(first_Y_batch[0])
    target_char = IDX_TO_CHAR[target_idx]
    
    # Check: X[0] is 'T', so Y[0] must be 'h'
    print(f"Character corresponding to the first target element (Y_batches[0][0]): '{target_char}'")

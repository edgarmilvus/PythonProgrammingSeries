
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np

# --- 1. Hyperparameters and Data Setup ---
# A very simple sequence to demonstrate short-term dependencies
data = "PYTHON"
chars = list(set(data))
data_size, vocab_size = len(data), len(chars)
hidden_size = 100  # Number of neurons in the hidden layer
seq_length = len(data) - 1 # Sequence length for training (P->Y, Y->T, etc.)
learning_rate = 1e-1
max_iters = 1000

# Character to index mapping
char_to_ix = {ch: i for i, ch in enumerate(chars)}
ix_to_char = {i: ch for i, ch in enumerate(chars)}

# --- 2. Model Initialization (Weight Sharing) ---
# W_xh: Weights connecting Input (x) to Hidden layer (h)
W_xh = np.random.randn(hidden_size, vocab_size) * 0.01
# W_hh: Weights connecting previous Hidden state (h_prev) to current Hidden state (h)
W_hh = np.random.randn(hidden_size, hidden_size) * 0.01
# W_hy: Weights connecting Hidden layer (h) to Output (y)
W_hy = np.random.randn(vocab_size, hidden_size) * 0.01

# Biases
b_h = np.zeros((hidden_size, 1)) # Hidden bias
b_y = np.zeros((vocab_size, 1))  # Output bias

# Initialize memory for the hidden state
h_prev = np.zeros((hidden_size, 1))

# Helper function for sigmoid activation
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

# --- 3. Forward Pass Function (Unfolding) ---
def forward_pass(inputs, targets, h_prev):
    """Performs the forward pass and calculates loss."""
    xs, hs, ys, ps = {}, {}, {}, {}
    hs[-1] = np.copy(h_prev)
    loss = 0

    # Loop through the sequence time steps (t=0 to T)
    for t in range(len(inputs)):
        # Input one-hot vector
        xs[t] = np.zeros((vocab_size, 1))
        xs[t][inputs[t]] = 1

        # Hidden state calculation (Core RNN mechanism)
        # h_t = tanh(W_xh * x_t + W_hh * h_{t-1} + b_h)
        hs[t] = np.tanh(np.dot(W_xh, xs[t]) + np.dot(W_hh, hs[t-1]) + b_h)

        # Output calculation (unnormalized log probabilities)
        # y_t = W_hy * h_t + b_y
        ys[t] = np.dot(W_hy, hs[t]) + b_y

        # Softmax for probabilities (ps[t])
        ps[t] = np.exp(ys[t]) / np.sum(np.exp(ys[t]))

        # Cross-entropy loss accumulation
        loss += -np.log(ps[t][targets[t], 0])

    return loss, xs, hs, ps

# --- 4. Backward Pass Function (Backpropagation Through Time - BPTT) ---
def backward_pass(xs, hs, ps, targets):
    """Performs BPTT and calculates gradients."""
    # Initialize gradient accumulators
    dW_xh, dW_hh, dW_hy = np.zeros_like(W_xh), np.zeros_like(W_hh), np.zeros_like(W_hy)
    db_h, db_y = np.zeros_like(b_h), np.zeros_like(b_y)
    dh_next = np.zeros_like(hs[0]) # Gradient flowing back from future time step

    # Loop backward through the sequence
    for t in reversed(range(len(xs))):
        # 1. Output gradient (dy)
        dy = np.copy(ps[t])
        # Derivative of loss w.r.t. output scores (y)
        dy[targets[t]] -= 1

        # 2. Output layer gradients (dW_hy, db_y)
        dW_hy += np.dot(dy, hs[t].T)
        db_y += dy

        # 3. Hidden state gradient (dh)
        # dh = (W_hy.T * dy) + dh_next (gradient from future time step)
        dh = np.dot(W_hy.T, dy) + dh_next

        # 4. Apply tanh derivative (d_tanh = 1 - h^2)
        dh_raw = (1 - hs[t] * hs[t]) * dh

        # 5. Hidden layer gradients (dW_hh, dW_xh, db_h)
        db_h += dh_raw
        dW_xh += np.dot(dh_raw, xs[t].T)
        dW_hh += np.dot(dh_raw, hs[t-1].T)

        # 6. Prepare gradient for previous time step (BPTT flow)
        # dh_next is the gradient that flows back to the h_{t-1} calculation
        dh_next = np.dot(W_hh.T, dh_raw)
        
    # Gradient clipping to mitigate exploding gradients
    for dparam in [dW_xh, dW_hh, dW_hy, db_h, db_y]:
        np.clip(dparam, -5, 5, out=dparam)

    return dW_xh, dW_hh, dW_hy, db_h, db_y, dh_next

# --- 5. Training Loop ---
n, p = 0, 0
smooth_loss = -np.log(1.0/vocab_size)*seq_length # Initial loss estimate

# Data preparation (P Y T H O N) -> (P Y T H O) as input, (Y T H O N) as target
inputs = [char_to_ix[c] for c in data[:-1]]
targets = [char_to_ix[c] for c in data[1:]]

for i in range(max_iters):
    # Reset hidden state for the start of the sequence
    h_prev = np.zeros((hidden_size, 1))
    
    # Forward Pass
    loss, xs, hs, ps = forward_pass(inputs, targets, h_prev)
    smooth_loss = smooth_loss * 0.999 + loss * 0.001

    # Backward Pass (BPTT)
    dW_xh, dW_hh, dW_hy, db_h, db_y, h_prev_update = backward_pass(xs, hs, ps, targets)

    # Parameter Update (Simple SGD)
    W_xh -= learning_rate * dW_xh
    W_hh -= learning_rate * dW_hh
    W_hy -= learning_rate * dW_hy
    b_h -= learning_rate * db_h
    b_y -= learning_rate * db_y
    
    if i % 100 == 0:
        print(f'Iteration {i}, Loss: {smooth_loss[0]:.4f}')

print(f"\nFinal Loss: {smooth_loss[0]:.4f}")
print("Training complete on sequence 'PYTHON'.")

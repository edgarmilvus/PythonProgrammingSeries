
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import albumentations as A
import numpy as np
import cv2
# Reusing the dummy_image from Exercise 1

# 1. Cutout Implementation using Albumentations' CoarseDropout
def get_cutout_pipeline(max_hole_percent=0.2, num_holes=1):
    """
    Defines the augmentation pipeline including Cutout (CoarseDropout).
    """
    
    # Calculate max_hole_size in pixels based on max_hole_percent (e.g., 20% of 100x100 = 20 pixels)
    H, W, C = 100, 100, 3 
    max_size_pixels = int(max_hole_percent * min(H, W))
    
    # Standard geometric transforms (as in Ex 1)
    geometric_transforms = [
        A.HorizontalFlip(p=0.5),
        A.Rotate(limit=15, p=0.7),
        A.ColorJitter(brightness=0.2, contrast=0.2, p=0.8),
    ]

    # Cutout/Random Erasing transform
    # The fill_value is set to the estimated mean pixel value (e.g., 125 for 8-bit image)
    cutout_transform = A.CoarseDropout(
        max_holes=num_holes, 
        max_height=max_size_pixels, 
        max_width=max_size_pixels,
        min_height=int(max_size_pixels / 2),
        min_width=int(max_size_pixels / 2),
        fill_value=125, # Use mean pixel value (128 approx)
        p=0.6,
        mask_fill_value=None # Apply to image, not mask
    )
    
    # Normalization step (requires image to be float [0, 1] or [0, 255])
    normalization = A.Normalize(mean=(0.4914, 0.4822, 0.4465), std=(0.2471, 0.2435, 0.2616))

    # 3. Integration Point: Cutout must be applied after geometric/color, but before normalization
    pipeline = A.Compose(
        geometric_transforms + [cutout_transform] + [normalization]
    )
    return pipeline

# Testing the pipeline structure
cutout_pipeline = get_cutout_pipeline()
augmented_data = cutout_pipeline(image=dummy_image)
# print(f"\nCutout Integration: Output shape (Normalized): {augmented_data['image'].shape}")

# 4. Training Comparison (Conceptual Reporting)

# --- Start of Conceptual Report ---
def report_generalization_gap_comparison():
    """Simulated results based on typical Cutout effects."""
    print("\n--- Training Comparison Report (Conceptual) ---")
    
    # Run A: Baseline (Standard Augmentation)
    baseline_train_loss = 0.02
    baseline_val_acc = 88.5
    baseline_train_acc = 95.0
    baseline_gap = baseline_train_acc - baseline_val_acc

    # Run B: Baseline + Cutout Augmentation
    cutout_train_loss = 0.05 # Higher training loss due to harder examples
    cutout_val_acc = 89.8   # Higher validation accuracy
    cutout_train_acc = 93.0 # Lower training accuracy (better regularization)
    cutout_gap = cutout_train_acc - cutout_val_acc
    
    print(f"Run A (Baseline): Train Loss={baseline_train_loss}, Val Acc={baseline_val_acc}%, Generalization Gap={baseline_gap:.2f}%")
    print(f"Run B (Cutout): Train Loss={cutout_train_loss}, Val Acc={cutout_val_acc}%, Generalization Gap={cutout_gap:.2f}%")
    
    if cutout_gap < baseline_gap and cutout_val_acc > baseline_val_acc:
        print("\nConclusion: Cutout successfully reduced the generalization gap and improved peak validation accuracy.")
    else:
        print("\nConclusion: Cutout did not improve generalization (unexpected result).")
        
report_generalization_gap_comparison()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import torch
import torch.nn.functional as F
import numpy as np
from scipy.stats import beta

# Assume a dummy model and optimizer for structural demonstration
class DummyModel(torch.nn.Module):
    def __init__(self, num_classes=10):
        super().__init__()
        self.fc = torch.nn.Linear(10, num_classes) # Input size 10 for dummy X

    def forward(self, x):
        return self.fc(x)

# 1. MixUp Implementation Function
def mixup_data(x, y, alpha=0.2):
    """
    Applies MixUp to a batch of data and labels.
    x: Input batch (N, C, H, W) or (N, features)
    y: Target labels (N,)
    alpha: Hyperparameter for Beta distribution
    """
    if alpha > 0:
        # Sample lambda from Beta distribution
        lam = np.random.beta(alpha, alpha)
    else:
        lam = 1.0
        
    batch_size = x.size()[0]
    
    # Create a random permutation of indices for the second batch
    index = torch.randperm(batch_size).to(x.device)

    # Blend Data
    mixed_x = lam * x + (1 - lam) * x[index, :]
    
    # Convert labels to one-hot encoding for soft blending
    # Assuming y is (N,) and num_classes=10
    num_classes = 10 
    y_onehot = F.one_hot(y, num_classes=num_classes).float()
    y_index_onehot = F.one_hot(y[index], num_classes=num_classes).float()
    
    # Blend Labels (Soft Labels)
    mixed_y = lam * y_onehot + (1 - lam) * y_index_onehot
    
    # We return the original labels as well for the custom loss calculation
    return mixed_x, y, y[index], lam

# 2. Modified Loss Function
def mixup_criterion(criterion, pred, y_a, y_b, lam):
    """
    Calculates the MixUp loss using the standard criterion (e.g., CrossEntropyLoss)
    applied against the two original one-hot labels, weighted by lambda.
    
    Note: PyTorch's CrossEntropyLoss expects raw logits and hard targets (N,) or 
    soft targets (N, C). Since we are using hard targets (y_a, y_b) and weighting the loss,
    we ensure the loss is correctly calculated against the two components.
    
    If using soft labels (mixed_y) directly, use torch.nn.KLDivLoss or modify CE to accept soft targets.
    Here we use the weighted sum approach which is numerically stable and common.
    """
    loss_a = criterion(pred, y_a)
    loss_b = criterion(pred, y_b)
    return lam * loss_a + (1 - lam) * loss_b

# 3. Illustration of the Training Loop Integration
def illustrate_mixup_training_loop(alpha=0.2):
    model = DummyModel(num_classes=10)
    optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
    criterion = torch.nn.CrossEntropyLoss()
    
    # Dummy Batch (N=32, Features=10)
    X_batch = torch.randn(32, 10)
    Y_batch = torch.randint(0, 10, (32,))

    model.train()
    optimizer.zero_grad()
    
    # Step 1: Apply MixUp
    X_mixed, Y_a, Y_b, lam = mixup_data(X_batch, Y_batch, alpha=alpha)
    
    # Step 2: Forward Pass
    logits = model(X_mixed)
    
    # Step 3: Calculate Modified Loss
    loss = mixup_criterion(criterion, logits, Y_a, Y_b, lam)
    
    # Step 4: Backward Pass (Standard)
    loss.backward()
    optimizer.step()
    
    print(f"\nMixUp Integration (alpha={alpha}):")
    print(f"Lambda sampled: {lam:.4f}")
    print(f"Mixed Input Mean: {X_mixed.mean():.4f}")
    print(f"Calculated MixUp Loss: {loss.item():.4f}")

illustrate_mixup_training_loop(alpha=0.2)
illustrate_mixup_training_loop(alpha=0.4)

# 4. Hyperparameter Tuning Report (Conceptual)
print("\n--- MixUp Hyperparameter Tuning Report (Conceptual) ---")
print("Comparing alpha=0.1 (Weaker MixUp) vs. alpha=0.4 (Stronger MixUp)")
print("Alpha ($\alpha$) controls the strength of the mixing. Lower $\alpha$ (e.g., 0.1) produces $\lambda$ values closer to 1 or 0 (less mixing), while higher $\alpha$ (e.g., 0.4) produces $\lambda$ values closer to 0.5 (stronger, more uniform mixing).")

print("\nExpected Results for CIFAR-10/100:")
print("Run A (Baseline DA): Validation Acc ~ 90.0%")
print("Run B (MixUp, alpha=0.1): Validation Acc ~ 90.5%. Convergence speed: Fast.")
print("Run C (MixUp, alpha=0.4): Validation Acc ~ 91.2%. Convergence speed: Slower, requires 10-20% more epochs.")
print("Conclusion: Alpha=0.4 typically yields better final generalization performance (higher peak accuracy) but requires a longer training schedule due to the highly regularized, 'smoother' nature of the training data.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np
import albumentations as A
from albumentations.core.transforms_interface import ImageOnlyTransform
import cv2
# Reusing the dummy_image from Exercise 1

# 1. Custom Transform Class Definition
class SparseNoiseInjection(ImageOnlyTransform):
    """
    Simulates sensor degradation by adding sparse Salt and Pepper or Gaussian noise.
    Operates on a HxWxC NumPy array (image).
    """
    def __init__(self, noise_density=0.01, noise_type='salt_pepper', 
                 noise_magnitude=1.0, always_apply=False, p=0.5):
        super().__init__(always_apply, p)
        self.noise_density = noise_density
        self.noise_type = noise_type
        self.noise_magnitude = noise_magnitude

    def apply(self, img, **params):
        H, W, C = img.shape
        total_pixels = H * W
        num_noisy_pixels = int(self.noise_density * total_pixels)
        
        # 1. Randomly select pixel locations
        # Generate flattened indices for speed
        flat_indices = np.random.choice(total_pixels, num_noisy_pixels, replace=False)
        
        # Convert flat indices back to 2D coordinates
        row_indices = flat_indices // W
        col_indices = flat_indices % W
        
        # Ensure image is float for manipulation, then convert back to original dtype
        original_dtype = img.dtype
        img_float = img.astype(np.float32)

        if self.noise_type == 'salt_pepper':
            # 2. Salt and Pepper Logic
            # 50% chance for salt (white, 255) or pepper (black, 0)
            salt_mask = np.random.choice([0, 1], size=num_noisy_pixels)
            
            # Apply salt (255)
            img_float[row_indices[salt_mask == 1], col_indices[salt_mask == 1], :] = 255
            # Apply pepper (0)
            img_float[row_indices[salt_mask == 0], col_indices[salt_mask == 0], :] = 0
            
        elif self.noise_type == 'gaussian':
            # 3. Gaussian Noise Logic
            # Generate random noise vector
            noise = np.random.normal(0, self.noise_magnitude, size=(num_noisy_pixels, C))
            
            # Apply noise to the selected pixels
            # We must iterate over channels for correct indexing if using advanced indexing
            for c in range(C):
                 img_float[row_indices, col_indices, c] += noise[:, c]
            
            # Clip results to valid range
            img_float = np.clip(img_float, 0, 255)
        
        return img_float.astype(original_dtype)

    def get_transform_init_args_names(self):
        return ("noise_density", "noise_type", "noise_magnitude")

# 4. Integration and Testing
# Define a pipeline including the custom transform
custom_pipeline = A.Compose([
    SparseNoiseInjection(noise_density=0.005, noise_type='salt_pepper', p=1.0), # 0.5% density
    A.ToFloat(max_value=255.0)
])

# Test image (reusing dummy_image)
dummy_image_bgr = cv2.cvtColor(dummy_image, cv2.COLOR_RGB2BGR) 
augmented_data = custom_pipeline(image=dummy_image_bgr)
noisy_image = augmented_data['image']

# print(f"\nNoise Injection Test: Image mean after noise: {np.mean(noisy_image):.4f}")
# plt.figure(figsize=(5, 5))
# plt.imshow(cv2.cvtColor((noisy_image * 255).astype(np.uint8), cv2.COLOR_BGR2RGB))
# plt.title("Image with Sparse Salt & Pepper Noise (0.5% Density)")
# plt.axis('off')
# plt.show()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import albumentations as A
import numpy as np
import cv2
import matplotlib.pyplot as plt

# 1. Create a dummy image (simulating a 100x100 RGB image from CIFAR-10)
dummy_image = np.zeros((100, 100, 3), dtype=np.uint8)
# Add a visible square for observing transforms
dummy_image[20:80, 20:80, :] = [255, 100, 50] # Reddish square

# 2. Define the Augmentation Pipeline using Albumentations
def get_training_pipeline():
    """Defines the required standardized augmentation pipeline."""
    pipeline = A.Compose([
        # Geometric Transforms (Applied first)
        A.HorizontalFlip(p=0.5),
        A.Rotate(limit=15, p=0.7, interpolation=cv2.INTER_LINEAR, border_mode=cv2.BORDER_REFLECT_101),
        A.Affine(
            shear={'x': (-10, 10), 'y': (-10, 10)},
            p=0.5,
            interpolation=cv2.INTER_LINEAR,
            mode=cv2.BORDER_REFLECT_101
        ),
        A.ElasticTransform(
            alpha=1, sigma=50, alpha_affine=50, border_mode=cv2.BORDER_REFLECT_101, p=0.3
        ),

        # Color/Intensity Transforms (Applied after geometric)
        A.ColorJitter(
            brightness=0.2, contrast=0.2, saturation=0, hue=0, p=0.8
        ),
        
        # Final step: Normalization (Crucial for integration)
        A.Normalize(mean=(0.4914, 0.4822, 0.4465), std=(0.2471, 0.2435, 0.2616)),
        # Note: Albumentations returns a NumPy array; conversion to Tensor 
        # would typically be the last step in a PyTorch/TF pipeline.
    ])
    return pipeline

# 3. Visualization Script
pipeline = get_training_pipeline()
num_visualizations = 10
fig, axes = plt.subplots(2, 5, figsize=(15, 6))
axes = axes.flatten()

print("Applying augmentation pipeline 10 times...")
for i in range(num_visualizations):
    # Albumentations expects 'image' keyword argument
    augmented_data = pipeline(image=dummy_image)
    
    # Denormalize for display (optional, but necessary if Normalize is included)
    augmented_img = augmented_data['image'] * 0.25 + 0.5 # Approximate denormalization
    augmented_img = np.clip(augmented_img, 0, 1)

    axes[i].imshow(augmented_img)
    axes[i].set_title(f"Augmentation {i+1}")
    axes[i].axis('off')

plt.tight_layout()
# plt.show() # Uncomment to display the visualization

# 4. Integration Check (Illustrative PyTorch __getitem__)
class CustomDatasetExample:
    def __init__(self, images, pipeline):
        self.images = images
        self.pipeline = pipeline

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        image = self.images[idx] # Fetches HxWxC numpy array
        
        # Apply the full augmentation pipeline
        augmented = self.pipeline(image=image)
        
        # The output 'augmented['image']' is now normalized (float32)
        # and ready for conversion to a PyTorch Tensor (C, H, W)
        processed_image = augmented['image']
        
        # return processed_image, label
        return processed_image

# Example integration:
# dataset = CustomDatasetExample(all_cifar_images, pipeline)
# first_item = dataset[0]
# print(f"\nIntegration Check: Output shape after pipeline (Normalized): {first_item.shape}")

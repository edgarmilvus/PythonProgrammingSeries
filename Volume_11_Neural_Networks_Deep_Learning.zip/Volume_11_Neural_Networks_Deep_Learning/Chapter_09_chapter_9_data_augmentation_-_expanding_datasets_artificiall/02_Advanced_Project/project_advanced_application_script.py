
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import random
from PIL import Image, ImageEnhance
import matplotlib.pyplot as plt
import os

# --- Configuration and Setup ---
random.seed(42)
np.random.seed(42)
OUTPUT_DIR = "augmented_crops"
os.makedirs(OUTPUT_DIR, exist_ok=True)

def create_dummy_image(size=(128, 128), color_code=0):
    """Creates a simple colored dummy image simulating healthy (0) or diseased (1) crops."""
    if color_code == 0:
        # Green/Healthy Crop: High green channel intensity
        img_array = np.random.randint(100, 200, size + (3,), dtype=np.uint8)
        img_array[:, :, 0] = np.clip(img_array[:, :, 0] * 0.5, 0, 255) 
        img_array[:, :, 2] = np.clip(img_array[:, :, 2] * 0.5, 0, 255) 
        label = 0 # Healthy
    else:
        # Brown/Diseased Crop: High red channel intensity
        img_array = np.random.randint(50, 150, size + (3,), dtype=np.uint8)
        img_array[:, :, 1] = np.clip(img_array[:, :, 1] * 0.5, 0, 255) 
        img_array[:, :, 0] = np.clip(img_array[:, :, 0] * 1.5, 0, 255) 
        label = 1 # Diseased
    return Image.fromarray(img_array), label

def geometric_transform(image: Image):
    """Applies random rotation (90/180/270 degrees) and horizontal flip."""
    if random.random() > 0.5:
        image = image.transpose(Image.FLIP_LEFT_RIGHT) # Horizontal flip
    
    angle = random.choice([0, 90, 180, 270])
    if angle != 0:
        # Use bilinear resampling for better quality rotation
        image = image.rotate(angle, expand=False, resample=Image.BILINEAR) 
    
    return image

def color_jitter(image: Image):
    """Applies random brightness and contrast adjustments to simulate varying lighting conditions."""
    # Adjust brightness (e.g., cloudy vs sunny day)
    brightness_factor = random.uniform(0.8, 1.2)
    enhancer = ImageEnhance.Brightness(image)
    image = enhancer.enhance(brightness_factor)
    
    # Adjust contrast (e.g., haze or shadow effects)
    contrast_factor = random.uniform(0.8, 1.2)
    enhancer = ImageEnhance.Contrast(image)
    image = enhancer.enhance(contrast_factor)
    
    return image

def apply_cutmix(img_a: Image, label_a: int, img_b: Image, label_b: int, alpha=1.0):
    """
    Implements the CutMix augmentation strategy, mixing two images and interpolating labels.
    The 'alpha' parameter controls the Beta distribution sampling for lambda.
    """
    W, H = img_a.size
    
    # 1. Calculate lambda (mixing ratio) using Beta distribution
    # Beta distribution encourages lambda values close to 0.5 when alpha is large.
    lam = np.random.beta(alpha, alpha)
    lam = max(lam, 1.0 - lam) # Enforce lam >= 0.5 (Image A will be the dominant base)
    
    # 2. Determine the bounding box (B) for the cut area based on (1 - lambda)
    bbx1, bby1, bbx2, bby2 = get_bbox(W, H, lam)
    
    # Calculate the precise area ratio of the cut section
    area_ratio = ((bbx2 - bbx1) * (bby2 - bby1)) / (W * H)
    lam = 1.0 - area_ratio # Recalculate lambda based on actual pixel area (weight of img_A)
    
    # 3. Perform the mixing (Cut patch from B and paste onto A)
    img_a_array = np.array(img_a, dtype=np.uint8)
    img_b_array = np.array(img_b, dtype=np.uint8)
    
    patch = img_b_array[bby1:bby2, bbx1:bbx2]
    img_a_array[bby1:bby2, bbx1:bbx2] = patch
    
    mixed_image = Image.fromarray(img_a_array)
    
    # 4. Interpolate the labels (soft labeling)
    mixed_label = lam * label_a + (1.0 - lam) * label_b
    
    return mixed_image, mixed_label, lam

def get_bbox(W, H, lam):
    """Helper function to calculate the bounding box coordinates based on lambda."""
    # The area of the cut region should be proportional to (1 - lambda)
    cut_ratio = np.sqrt(1.0 - lam) 
    cut_w = int(W * cut_ratio)
    cut_h = int(H * cut_ratio)

    # Randomly select the center of the bounding box (cx, cy)
    cx = np.random.randint(W)
    cy = np.random.randint(H)

    # Calculate coordinates, ensuring they stay within image bounds
    bbx1 = np.clip(cx - cut_w // 2, 0, W)
    bby1 = np.clip(cy - cut_h // 2, 0, H)
    bbx2 = np.clip(cx + cut_w // 2, 0, W)
    bby2 = np.clip(cy + cut_h // 2, 0, H)
    
    return bbx1, bby1, bbx2, bby2

# --- Main Execution Pipeline ---

print("--- Starting Advanced Data Augmentation Pipeline (Crop Health Classification) ---")

# 1. Load/Generate two distinct source samples (one healthy, one diseased)
img_healthy, label_healthy = create_dummy_image(color_code=0) # Label 0 (Healthy)
img_diseased, label_diseased = create_dummy_image(color_code=1) # Label 1 (Diseased)

print(f"Source 1 (Healthy): Label {label_healthy}")
print(f"Source 2 (Diseased): Label {label_diseased}")

# 2. Apply Standard Augmentations to Source 1 (as a control sample)
img_geo = geometric_transform(img_healthy)
img_final_a = color_jitter(img_geo)
img_final_a.save(os.path.join(OUTPUT_DIR, "01_Standard_Aug_A.png"))
print("\nGenerated 1: Standard geometric and color augmentation applied.")

# 3. Apply Advanced Augmentation: CutMix with varying Alpha parameters
cutmix_samples = []
# Varying alpha shows how the distribution of lambda changes the resulting mix.
for i, alpha_val in enumerate([0.75, 1.5, 5.0]):
    mixed_img, mixed_label, lam_ratio = apply_cutmix(
        img_healthy, label_healthy, 
        img_diseased, label_diseased, 
        alpha=alpha_val
    )
    
    # Apply standard augmentations *after* mixing (Post-processing DA)
    mixed_img = geometric_transform(mixed_img)
    mixed_img = color_jitter(mixed_img)
    
    filename = f"02_CutMix_Alpha_{alpha_val}_{i}.png"
    mixed_img.save(os.path.join(OUTPUT_DIR, filename))
    
    cutmix_samples.append((mixed_label, lam_ratio, alpha_val))
    
print(f"Generated 2-{2 + len(cutmix_samples)}: CutMix augmentations applied.")

# 4. Reporting the results
print("\n--- CutMix Sample Results ---")
for i, (label, lam, alpha) in enumerate(cutmix_samples):
    # Note: The interpolated label forces the model to learn boundary conditions.
    print(f"Sample {i+1} (Alpha={alpha}):")
    print(f"  Lambda (Weight of Healthy Image): {lam:.4f}")
    print(f"  Interpolated Label (0=Healthy, 1=Diseased): {label:.4f}")
    
# Visualization setup (for verification)
fig, axes = plt.subplots(1, 4, figsize=(16, 4))
axes[0].imshow(img_healthy)
axes[0].set_title(f"Source A (L={label_healthy})")
axes[1].imshow(img_diseased)
axes[1].set_title(f"Source B (L={label_diseased})")
axes[2].imshow(img_final_a)
axes[2].set_title(f"Standard Aug A")
axes[3].imshow(mixed_img)
axes[3].set_title(f"CutMix (L={cutmix_samples[-1][0]:.2f})")

plt.tight_layout()
# plt.show() 
print(f"\nSuccessfully generated {1 + len(cutmix_samples)} augmented images in '{OUTPUT_DIR}/'.")

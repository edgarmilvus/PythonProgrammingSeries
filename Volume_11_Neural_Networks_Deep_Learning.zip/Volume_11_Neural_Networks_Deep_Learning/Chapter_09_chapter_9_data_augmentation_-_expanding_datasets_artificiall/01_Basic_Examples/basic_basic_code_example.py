
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

from PIL import Image
import os
import shutil

# --- Configuration Constants ---
IMAGE_SIZE = (100, 100)
OUTPUT_DIR = 'basic_augmentations_output'
BASE_FILENAME = 'original_marker_image.png'

def setup_environment():
    """Cleans up and sets up the output directory."""
    # Remove previous run directory for clean testing
    if os.path.exists(OUTPUT_DIR):
        shutil.rmtree(OUTPUT_DIR)
        
    # Create the output directory if it doesn't exist
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    print(f"Setup complete. Output directory: '{OUTPUT_DIR}' created.")

def create_placeholder_image(filename):
    """
    Creates a simple 100x100 placeholder image (white background) 
    with a small, distinct black marker (10x10 square) in the top-center.
    This marker is crucial for visualizing transformations clearly.
    """
    try:
        # 1. Initialize the image: RGB mode, specified size, white background
        img = Image.new('RGB', IMAGE_SIZE, color='white')
        
        # 2. Get the pixel access object to manipulate individual pixels
        pixels = img.load()
        
        # 3. Define the marker position (top-center)
        # Horizontal range: 45 to 55 (centered in 100 width)
        # Vertical range: 10 to 20 (near the top)
        for x in range(45, 55):
            for y in range(10, 20):
                # Set pixel color to black (0, 0, 0)
                pixels[x, y] = (0, 0, 0)
                
        # 4. Save the original image to disk
        path = os.path.join(OUTPUT_DIR, filename)
        img.save(path)
        print(f"-> Created original image: {path}")
        return img
    except Exception as e:
        print(f"Error creating image: {e}")
        return None

def apply_basic_augmentations(original_img, base_name):
    """
    Applies three fundamental geometric augmentations using PIL's transpose method.
    """
    
    print("\n--- Applying Augmentations ---")
    
    # 1. Augmentation: Horizontal Flip (Mirroring)
    # Image.FLIP_LEFT_RIGHT mirrors the image along the vertical axis (Y-axis).
    flipped_img = original_img.transpose(Image.FLIP_LEFT_RIGHT)
    flipped_path = os.path.join(OUTPUT_DIR, f"{base_name}_01_flipped.png")
    flipped_img.save(flipped_path)
    print(f"-> Saved augmented image (Horizontal Flip): {flipped_path}")

    # 2. Augmentation: Rotation (90 degrees Counter-Clockwise)
    # Image.ROTATE_90 rotates the image 90 degrees counter-clockwise.
    rotated_img = original_img.transpose(Image.ROTATE_90)
    rotated_path = os.path.join(OUTPUT_DIR, f"{base_name}_02_rotated_90.png")
    rotated_img.save(rotated_path)
    print(f"-> Saved augmented image (Rotation 90 CCW): {rotated_path}")

    # 3. Augmentation: Sequential Combination (Rotation 180 + Vertical Flip)
    # We apply two operations sequentially to create a new, distinct sample.
    rotated_180_img = original_img.transpose(Image.ROTATE_180)
    # Applying a vertical flip to the 180-rotated image
    combined_img = rotated_180_img.transpose(Image.FLIP_TOP_BOTTOM)
    combined_path = os.path.join(OUTPUT_DIR, f"{base_name}_03_combined_180_vflip.png")
    combined_img.save(combined_path)
    print(f"-> Saved augmented image (Combined): {combined_path}")


# --- Main Execution Block ---
if __name__ == "__main__":
    setup_environment()
    
    # 1. Generate the initial data point
    input_image = create_placeholder_image(BASE_FILENAME)
    
    if input_image:
        # 2. Execute the augmentation pipeline
        apply_basic_augmentations(input_image, "augmented_sample")

        print("\nProcess complete. 4 images (1 original, 3 augmented) are available in the output directory.")



#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np

# Set seed for reproducibility
np.random.seed(42)

# 1. Document and Query Setup
documents = [
    "D1: The sun is hot.",
    "D2: Neural networks use backpropagation.",
    "D3: Tokenization converts text to numbers.",
    "D4: The ocean is vast.",
    "D5: GloVe is an embedding technique."
]
query_string = "How do I represent words mathematically?"

# 2. Embedding Simulation (8D)
D = 8

# Generate random vectors for unrelated documents
vec_D1 = np.random.rand(D)
vec_D2 = np.random.rand(D)
vec_D4 = np.random.rand(D)

# Define a core semantic vector related to "math/representation/embeddings"
V_semantic = np.array([0.9, 0.8, -0.7, 0.6, 0.5, 0.4, -0.3, 0.2])

# D3 and D5 are relevant, so their vectors are close to V_semantic
vec_D3 = V_semantic + np.random.normal(0, 0.05, D) # Small noise
vec_D5 = V_semantic + np.random.normal(0, 0.1, D)  # Slightly more noise

document_embeddings = [vec_D1, vec_D2, vec_D3, vec_D4, vec_D5]

# Query embedding is very close to V_semantic and thus close to D3/D5
query_embedding = V_semantic + np.random.normal(0, 0.01, D)

# 3. Vector Store Creation
vector_store = {
    i: (documents[i], document_embeddings[i]) for i in range(len(documents))
}

# 4. Retrieval Implementation (Cosine Similarity function)
def cosine_similarity(v1, v2):
    """Calculates cosine similarity between two NumPy vectors."""
    dot_product = np.dot(v1, v2)
    norm_v1 = np.linalg.norm(v1)
    norm_v2 = np.linalg.norm(v2)
    if norm_v1 == 0 or norm_v2 == 0:
        return 0.0
    return dot_product / (norm_v1 * norm_v2)

def retrieve_top_k(query_vec, store, k=2):
    """Calculates similarity scores and retrieves top K documents."""
    scores = []
    for doc_id, (doc_text, doc_vec) in store.items():
        similarity = cosine_similarity(query_vec, doc_vec)
        scores.append((doc_id, doc_text, similarity))
    
    # Rank by similarity score (descending)
    scores.sort(key=lambda x: x[2], reverse=True)
    return scores[:k]

# 5. Ranking and Retrieval Demonstration
top_k_results = retrieve_top_k(query_embedding, vector_store, k=2)

print(f"--- Standard Retrieval for Query: '{query_string}' ---")
print(f"Query Vector (first 4 dims): {query_embedding[:4].round(2)}")
print("\nTop 2 Retrieved Documents:")
for rank, (doc_id, doc_text, score) in enumerate(top_k_results):
    print(f"Rank {rank+1} (ID {doc_id}): {doc_text}")
    print(f"  Similarity Score: {score:.4f}")

# 6. Interactive Test
print("\n" + "="*50)
print("INTERACTIVE TEST: Custom Query Vector Retrieval")
print("Please enter 8 comma-separated numbers for a custom query vector:")
try:
    user_input = input("Vector (e.g., 0.9, 0.8, -0.7, 0.6, 0.5, 0.4, -0.3, 0.2): ")
    user_list = [float(x.strip()) for x in user_input.split(',')]
    if len(user_list) != D:
        raise ValueError(f"Must provide exactly {D} numbers.")
    
    custom_query_vec = np.array(user_list)
    custom_results = retrieve_top_k(custom_query_vec, vector_store, k=1)
    
    print("\nRetrieval Result for Custom Vector:")
    if custom_results:
        doc_id, doc_text, score = custom_results[0]
        print(f"Top Match (ID {doc_id}): {doc_text}")
        print(f"Similarity Score: {score:.4f}")
    
except Exception as e:
    print(f"Error processing input: {e}")

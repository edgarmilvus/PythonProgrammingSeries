
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np

# Set dimension size
D = 8

# 1. Vector Data Setup (Simulated 8D Embeddings)
# We define vectors such that V_king - V_man is close to V_queen - V_woman
V_relationship = np.array([0.5, 0.5, 0.5, 0.5, 0, 0, 0, 0]) # Gender/Royalty relationship vector

embeddings_dict = {
    "king": np.array([1.0, 0.8, 0.5, 0.2, 0.1, 0.1, 0.1, 0.1]) + V_relationship,
    "man": np.array([1.0, 0.8, 0.5, 0.2, 0.1, 0.1, 0.1, 0.1]) - V_relationship,
    "woman": np.array([1.0, 0.8, 0.5, 0.2, 0.1, 0.1, 0.1, 0.1]) + V_relationship, # Base vector + Gender/Royalty
    "queen": np.array([1.0, 0.8, 0.5, 0.2, 0.1, 0.1, 0.1, 0.1]) + 3 * V_relationship, # Base vector + 3*Gender/Royalty (slightly closer)
    "prince": np.array([0.9, 0.7, 0.4, 0.1, 0.2, 0.2, 0.2, 0.2]) + V_relationship,
    "princess": np.array([0.9, 0.7, 0.4, 0.1, 0.2, 0.2, 0.2, 0.2]) + 3 * V_relationship,
    "apple": np.random.rand(D) * 0.1,  # Unrelated
    "car": np.random.rand(D) * -0.1,    # Unrelated
    "throne": np.array([1.0, 0.9, 0.6, 0.3, 0.0, 0.0, 0.0, 0.0]) + 2 * V_relationship, # Related concept
}

# Define the analogy components
A_word, B_word, C_word = "king", "man", "woman"

# 2. Vector Arithmetic Implementation
def calculate_resultant_vector(A_vec, B_vec, C_vec):
    """R = V(A) - V(B) + V(C)"""
    return A_vec - B_vec + C_vec

# 3. Cosine Similarity Function
def cosine_similarity(vec1, vec2):
    """Calculates cosine similarity between two vectors."""
    dot_product = np.dot(vec1, vec2)
    norm_vec1 = np.linalg.norm(vec1)
    norm_vec2 = np.linalg.norm(vec2)
    # Handle division by zero for zero vectors (though unlikely for embeddings)
    if norm_vec1 == 0 or norm_vec2 == 0:
        return 0.0
    return dot_product / (norm_vec1 * norm_vec2)

# Calculate the resultant vector R
V_A = embeddings_dict[A_word]
V_B = embeddings_dict[B_word]
V_C = embeddings_dict[C_word]
R_vec = calculate_resultant_vector(V_A, V_B, V_C)

# 4. Nearest Neighbor Search
def find_closest_words(R_vec, embeddings_dict, top_n=5):
    similarities = {}
    for word, vec in embeddings_dict.items():
        # Exclude the input words themselves from the search result
        if word not in [A_word, B_word, C_word]:
            similarity = cosine_similarity(R_vec, vec)
            similarities[word] = similarity
    
    # Sort by similarity score
    sorted_results = sorted(similarities.items(), key=lambda item: item[1], reverse=True)
    return sorted_results[:top_n]

# 5. Result Display
closest_words = find_closest_words(R_vec, embeddings_dict, top_n=5)

print(f"Analogy: {A_word} - {B_word} + {C_word} = ?")
print(f"Resultant Vector R (first 4 dimensions): {R_vec[:4]}")
print("\nTop 5 Closest Words to R:")
for word, score in closest_words:
    print(f"  {word.ljust(10)} (Similarity: {score:.4f})")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from transformers import BertTokenizer
import collections

# 1. Tokenizer Setup
# We use the BERT tokenizer (WordPiece)
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')

# 2. Test Corpus
test_corpus = [
    "The quick brown fox jumped over the fence.",
    "Tokenization is essential for decentralization in deep learning.",
    "Supercalifragilisticexpialidocious is a very long word."
]
test_word = "decentralization"
rare_word = "supercalifragilisticexpialidocious"

# 3. Baseline Segmentation
print("--- 1. BASELINE SEGMENTATION (Full Vocabulary) ---")
baseline_tokens = tokenizer.tokenize(test_corpus[1])
baseline_total_tokens = sum(len(tokenizer.tokenize(s)) for s in test_corpus)

print(f"Word '{test_word}' Baseline: {tokenizer.tokenize(test_word)}")
print(f"Word '{rare_word}' Baseline: {tokenizer.tokenize(rare_word)}")
print(f"Total Tokens (Baseline): {baseline_total_tokens}")

# 4. Modification 1: Restricting Vocabulary
VOCAB_LIMIT = 500  # Severely restrict the vocabulary size

# Get the original vocabulary mapping
original_vocab = tokenizer.get_vocab()
# Filter the vocabulary to only include the first VOCAB_LIMIT tokens + special tokens
restricted_vocab_keys = list(original_vocab.keys())[:VOCAB_LIMIT]
restricted_vocab = {k: original_vocab[k] for k in restricted_vocab_keys}

# Create a new tokenizer instance using the restricted vocabulary
# Note: For simplicity and stability, we use the original tokenizer object 
# and simulate the restriction by replacing tokens not in the restricted set with [UNK].
# A cleaner way is to use a custom mapping for analysis.

# We will analyze the segmentation based on whether the resulting subwords
# are present in the restricted set.

restricted_tokenizer = BertTokenizer(vocab_file=None, do_lower_case=True, 
                                     unk_token="[UNK]", sep_token="[SEP]", 
                                     pad_token="[PAD]", cls_token="[CLS]", 
                                     mask_token="[MASK]")
restricted_tokenizer.vocab = restricted_vocab
restricted_tokenizer.ids_to_tokens = {v: k for k, v in restricted_vocab.items()}


print("\n--- 2. RESTRICTED SEGMENTATION (Vocab Size: 500) ---")

restricted_tokens_word = restricted_tokenizer.tokenize(test_word)
restricted_tokens_rare = restricted_tokenizer.tokenize(rare_word)

# Recalculate total tokens using the restricted tokenizer
restricted_total_tokens = sum(len(restricted_tokenizer.tokenize(s)) for s in test_corpus)

print(f"Word '{test_word}' Restricted: {restricted_tokens_word}")
print(f"Word '{rare_word}' Restricted: {restricted_tokens_rare}")
print(f"Total Tokens (Restricted): {restricted_total_tokens}")
print(f"Token Count Increase: {restricted_total_tokens - baseline_total_tokens}")

# 5. Modification 2: Analyzing Special Tokens (WordPiece continuation prefix: '##')
def analyze_fragmentation(token_list):
    continuation_prefix = '##'
    continuation_count = 0
    for token in token_list:
        if token.startswith(continuation_prefix):
            continuation_count += 1
    return continuation_count

baseline_frag = analyze_fragmentation(tokenizer.tokenize(test_corpus[1]))
restricted_frag = analyze_fragmentation(restricted_tokenizer.tokenize(test_corpus[1]))

print("\n--- 3. Fragmentation Analysis ---")
print(f"Baseline Fragmentation (Count of '##'): {baseline_frag}")
print(f"Restricted Fragmentation (Count of '##'): {restricted_frag}")

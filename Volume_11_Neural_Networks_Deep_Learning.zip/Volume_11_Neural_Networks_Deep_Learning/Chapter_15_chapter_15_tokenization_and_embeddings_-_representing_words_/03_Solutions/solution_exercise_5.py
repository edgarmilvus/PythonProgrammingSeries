
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np

# Parameters for Exercise 5
SPARSE_DIM = 10000
DENSE_DIM = 300
NON_ZERO_COUNT = 10

# 1. Sparse Vector Generation
V_sparse = np.zeros(SPARSE_DIM)
# Randomly choose 10 indices to be non-zero
non_zero_indices = np.random.choice(SPARSE_DIM, NON_ZERO_COUNT, replace=False)
V_sparse[non_zero_indices] = np.random.uniform(0.1, 1.0, NON_ZERO_COUNT)

# 2. Dense Vector Generation
V_dense = np.random.uniform(-1.0, 1.0, DENSE_DIM)

# 3. Sparsity Calculation
def calculate_sparsity(vector):
    """Calculates the percentage of zero elements in a vector."""
    zero_count = np.sum(vector == 0)
    total_elements = len(vector)
    sparsity = (zero_count / total_elements) * 100
    return sparsity

# Calculate and print sparsity
sparsity_sparse = calculate_sparsity(V_sparse)
sparsity_dense = calculate_sparsity(V_dense)

print(f"--- Sparsity Analysis ---")
print(f"V_sparse (10,000D, 10 non-zero): Sparsity = {sparsity_sparse:.2f}%")
print(f"V_dense (300D, all non-zero): Sparsity = {sparsity_dense:.2f}% (Expected near 0%)")
print("-" * 30)

# 5. Vector Comparison (Conceptual)
def calculate_euclidean_distance(v1, v2):
    """Calculates the Euclidean distance between two vectors."""
    return np.linalg.norm(v1 - v2)

# Generate V_A (King)
V_A = np.random.uniform(0.5, 1.0, DENSE_DIM)

# Generate V_B (Queen): Related, V_A + small noise
noise_B = np.random.normal(0, 0.05, DENSE_DIM)
V_B = V_A + noise_B

# Generate V_C (Car): Unrelated, completely different random values
V_C = np.random.uniform(-1.0, -0.5, DENSE_DIM)

# Calculate distances
distance_related = calculate_euclidean_distance(V_A, V_B)
distance_unrelated = calculate_euclidean_distance(V_A, V_C)

print(f"--- Semantic Distance Analysis (300D Dense Vectors) ---")
print(f"Distance (V_A to V_B, Related): {distance_related:.4f}")
print(f"Distance (V_A to V_C, Unrelated): {distance_unrelated:.4f}")

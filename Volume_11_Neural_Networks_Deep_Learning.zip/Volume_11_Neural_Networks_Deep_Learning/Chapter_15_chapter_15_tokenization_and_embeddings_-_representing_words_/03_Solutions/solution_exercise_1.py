
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import collections
import re

# Parameters
corpus = [
    "The quick brown fox jumps over the lazy dog",
    "Deep learning models require standardized input",
    "Tokenization converts text into numerical indices",
    "Embeddings capture complex semantic relationships",
    "Programming exercises are essential for practical application"
]
MAX_VOCAB_SIZE = 50
MAX_LEN = 10

# 1. Tokenization and Frequency Calculation
all_tokens = []
for sentence in corpus:
    # Simple tokenization: lowercase and split by whitespace
    tokens = re.findall(r'\b\w+\b', sentence.lower())
    all_tokens.extend(tokens)

word_counts = collections.Counter(all_tokens)

# 2. Vocabulary Creation
# Special tokens defined
SPECIAL_TOKENS = {
    '<PAD>': 0,
    '<UNK>': 1,
    '<EOS>': 2
}

# Sort words by frequency (descending)
sorted_words = [word for word, count in word_counts.most_common()]

# Build word_to_index
word_to_index = SPECIAL_TOKENS.copy()
current_index = 3
for word in sorted_words:
    if current_index < MAX_VOCAB_SIZE + len(SPECIAL_TOKENS):
        word_to_index[word] = current_index
        current_index += 1
    else:
        # Stop adding words if MAX_VOCAB_SIZE limit is reached
        break

print(f"Total Unique Words in Corpus: {len(word_counts)}")
print(f"Final Vocabulary Size (including special tokens): {len(word_to_index)}")
print("-" * 30)

# 3. Sentence Encoding and Standardization Function
def encode_and_standardize(sentence, w2i, max_len):
    # Tokenize and lowercase
    tokens = re.findall(r'\b\w+\b', sentence.lower())
    
    # 1. Encoding
    encoded_sequence = [w2i.get(token, w2i['<UNK>']) for token in tokens]
    
    # 2. Append <EOS>
    # We must account for <EOS> when checking length
    
    # 3. Truncation
    # If sequence + <EOS> is longer than max_len, truncate
    if len(encoded_sequence) >= max_len:
        # Truncate to max_len - 1 to leave room for <EOS> if possible, 
        # but since MAX_LEN is a hard limit, we truncate directly.
        final_sequence = encoded_sequence[:max_len]
        # If the sequence was truncated, we might not include <EOS>
        if len(final_sequence) < max_len:
             final_sequence.append(w2i['<EOS>'])
        final_sequence = final_sequence[:max_len] # Ensure hard limit
        
    else:
        # Append <EOS>
        final_sequence = encoded_sequence + [w2i['<EOS>']]
        
        # 4. Padding
        padding_needed = max_len - len(final_sequence)
        if padding_needed > 0:
            final_sequence.extend([w2i['<PAD>']] * padding_needed)
    
    return final_sequence, len(final_sequence)

# 4. Demonstration
sentences_to_test = [
    "The quick fox jumps",  # Shorter (4 words) -> 5 tokens + padding
    "Tokenization converts text into numerical indices", # Longer (6 words) -> Truncated
    "Deep learning models require standardized input data", # Exactly 7 words + EOS + PAD
    "This is a test with unknown words like python and tensorflow" # Test UNK
]

for i, sentence in enumerate(sentences_to_test):
    sequence, length = encode_and_standardize(sentence, word_to_index, MAX_LEN)
    print(f"\nTest {i+1}: '{sentence}'")
    print(f"Original Length: {len(re.findall(r'\b\w+\b', sentence.lower()))}")
    print(f"Encoded Sequence (Length {length}): {sequence}")
    print(f"Is Padded/Truncated: {length == MAX_LEN}")



#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

# --- 1. Define the Corpus (Raw Text Data) ---
# This is our raw, unstructured text input.
movie_reviews = [
    "The film was absolutely brilliant and highly recommended.",
    "A truly awful experience, slow and boring.",
    "Brilliant acting, but the plot was slow.",
    "Highly recommended, a masterpiece.",
    "Awful, awful, boring."
]

# --- 2. Initialize the Tokenizer ---
# We configure the tokenizer to handle out-of-vocabulary words.
VOCAB_SIZE_LIMIT = 100 # Maximum number of words to keep, based on frequency.
tokenizer = Tokenizer(
    num_words=VOCAB_SIZE_LIMIT,
    oov_token="<UNK>" # Special token for Out-Of-Vocabulary words
)

# --- 3. Fit the Tokenizer to the Corpus ---
# The tokenizer analyzes the text, builds the vocabulary, and assigns indices based on frequency.
tokenizer.fit_on_texts(movie_reviews)

# --- 4. Convert Text to Numerical Sequences (Tokenization) ---
# Each word in the corpus is replaced by its corresponding integer index.
tokenized_sequences = tokenizer.texts_to_sequences(movie_reviews)

# --- 5. Inspect the Vocabulary Map ---
# Retrieve the word-to-index mapping dictionary created during fitting.
word_index_map = tokenizer.word_index

# --- 6. Sequence Padding (Preparation for Fixed Input Size) ---
# Find the length of the longest sequence to define the required input dimension.
max_sequence_length = max(len(s) for s in tokenized_sequences)

# Apply padding: 'post' means padding zeros are added to the end of the sequence.
# This makes all input sequences exactly the same length.
padded_sequences = pad_sequences(
    tokenized_sequences,
    maxlen=max_sequence_length,
    padding='post'
)

# --- 7. Output Results ---
print("--- Tokenization and Embedding Preparation Summary ---")
print(f"Original Corpus Size: {len(movie_reviews)} documents")
print(f"Vocabulary Size (Unique Words Found): {len(word_index_map)}")
print(f"Maximum Sequence Length (for Padding): {max_sequence_length}\n")

print(f"Raw Text (Document 1): {movie_reviews[0]}")
print(f"Tokenized Sequence (Document 1): {tokenized_sequences[0]}")
print(f"Padded Sequence (Document 1, Fixed Length):\n{padded_sequences[0]}\n")

print("--- Top 10 Vocabulary Indices (Frequency Order) ---")
# Keras reserves index 0 for padding. Indices start at 1.
top_words = list(word_index_map.items())[:10]
for word, index in top_words:
    print(f"Index {index}: '{word}'")

# Check the OOV token index
print(f"\nOOV Token Index: {word_index_map['<UNK>']}")

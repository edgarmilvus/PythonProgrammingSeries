
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import os
import sys

# --- 1. Configuration and Data Setup ---

# Define the embedding model. MiniLM is a fast, robust model suitable for semantic search.
EMBEDDING_MODEL = 'all-MiniLM-L6-v2' 

# A small corpus representing a technical knowledge base (e.g., definitions from a glossary)
KNOWLEDGE_BASE = [
    "The os.getcwd() function returns the absolute path of the current working directory.",
    "Embeddings are dense numerical vector representations capturing semantic meaning.",
    "A Vector Store is specialized for indexing and rapidly searching high-dimensional vectors.",
    "For loop iteration in Python is generally efficient for standard iterable consumption.",
    "The concept of backpropagation is central to training deep neural networks."
]

# --- 2. Initialization and Embedding Generation ---

print("Initializing Sentence Transformer model...")
# Load the pre-trained embedding model. This abstracts complex tokenization and pooling.
try:
    model = SentenceTransformer(EMBEDDING_MODEL)
except Exception as e:
    print(f"Error loading model. Ensure internet connection: {e}")
    sys.exit(1)

print(f"Model loaded successfully: {EMBEDDING_MODEL}")

# Generate embeddings for the entire knowledge base (Corpus Embedding Matrix)
print("Generating embeddings for the knowledge base (Text -> Vector Space)...")
# The .encode method performs: Tokenization -> Transformer Forward Pass -> Pooling -> Normalization.
corpus_embeddings = model.encode(KNOWLEDGE_BASE, convert_to_numpy=True)
# For MiniLM-L6-v2, the dimension D is 384. Shape should be (N, D) -> (5, 384)
print(f"Corpus embedding shape: {corpus_embeddings.shape}") 

# --- 3. Semantic Search Query Processing ---

# Define a user query that is semantically related to one of the documents
user_query = "Where am I running this Python script? I need the absolute folder path."

print(f"\nUser Query: '{user_query}'")

# Generate the embedding for the user query (Query Vector)
# We pass the query in a list to maintain dimensional consistency (1, 384)
query_embedding = model.encode([user_query], convert_to_numpy=True)
print(f"Query embedding shape: {query_embedding.shape}") 

# --- 4. Similarity Calculation (The Vector Math) ---

print("\nCalculating Cosine Similarity between Query Vector and Corpus Matrix...")
# Calculate the cosine similarity between the single query vector and all corpus vectors.
# Cosine similarity measures the angle between vectors, ignoring magnitude.
# Result is a 1xN array of scores.
similarities = cosine_similarity(query_embedding, corpus_embeddings)

# Flatten the 1xN array to easily process scores
similarity_scores = similarities[0]

# --- 5. Retrieval and Output ---

# Find the index of the document with the highest similarity score (argmax)
most_similar_index = np.argmax(similarity_scores)
highest_score = similarity_scores[most_similar_index]
most_relevant_document = KNOWLEDGE_BASE[most_similar_index]

print(f"Similarity Scores (Document 1 to 5): {np.round(similarity_scores, 4)}")
print("-" * 60)
print(f"Most Relevant Document Index: {most_similar_index} (0-indexed)")
print(f"Highest Similarity Score: {highest_score:.4f}")
print(f"\n[RETRIEVED DOCUMENT]\n{most_relevant_document}")
print("-" * 60)

# Verification check based on semantic understanding
if "os.getcwd()" in most_relevant_document:
    print("Verification: Retrieval was successful, matching the query ('current path') to the definition.")
else:
    print("Verification: Retrieval failed or found an unexpected document.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import torch
import numpy as np

# 1. NumPy Initialization
A_np = np.random.randint(10, 50, size=(3, 4))

# Determine the appropriate device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 2. Type and Tensor Conversion
# torch.from_numpy creates a tensor sharing memory (on CPU).
# .to(torch.float64) ensures the required precision.
A_torch = torch.from_numpy(A_np).to(torch.float64)

# 3. Device Handling
A_device = A_torch.to(device)
print(f"A_device is on: {A_device.device}")

# 4. Tensor Operation (3x4 @ 4x3 = 3x3)
B_device = A_device @ A_device.T

# 5. Return to NumPy
# Check device and move to CPU if necessary before calling .numpy()
if B_device.is_cuda:
    B_cpu = B_device.to('cpu')
else:
    B_cpu = B_device # Already on CPU
    
B_np = B_cpu.numpy()

print(f"Shape of B_np: {B_np.shape}")
print(f"B_np data type: {B_np.dtype}")

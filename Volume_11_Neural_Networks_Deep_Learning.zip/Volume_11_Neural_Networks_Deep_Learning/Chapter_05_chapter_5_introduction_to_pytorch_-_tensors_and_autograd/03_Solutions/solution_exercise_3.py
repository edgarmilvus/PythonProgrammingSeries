
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import torch

# 1. Parameter Initialization
P1 = torch.tensor(3.0, requires_grad=True)
P2 = torch.tensor(4.0, requires_grad=True)
P3 = torch.tensor(5.0, requires_grad=True)

# 2. Forward Pass
C = P1 * P2 + P3
L = torch.sin(C) + 0.5 * C**2

# 3. Backward Pass 1
L.backward()

# 4. Verification 1
print(f"P1 grad (Pass 1): {P1.grad}")
print(f"P2 grad (Pass 1): {P2.grad}")
print(f"P3 grad (Pass 1): {P3.grad}")

# 5. Conceptual Challenge (Accumulation)
# Note: This requires the graph to be retained for the second backward pass.
# By default, PyTorch frees the graph after the first backward call to save memory.
# We must re-run the forward pass or use retain_graph=True (here we re-run for clarity).

# Re-run forward pass to rebuild the graph (as L.backward() destroyed the first one)
C_new = P1 * P2 + P3
L_new = torch.sin(C_new) + 0.5 * C_new**2

# Second backward call
L_new.backward()

# 6. Verification 2
print(f"\nP1 grad (Pass 2 - Accumulated): {P1.grad}")
print(f"P2 grad (Pass 2 - Accumulated): {P2.grad}")
print(f"P3 grad (Pass 2 - Accumulated): {P3.grad}")

# Conceptual Comment on Accumulation:
# PyTorch's Autograd system performs gradient accumulation by default. 
# When L.backward() is called twice (even with a new forward pass rebuilding the graph), 
# the new gradients calculated are ADDED to the existing .grad attribute of the leaf tensors (P1, P2, P3).
# This is fundamental for accumulating gradients across mini-batches or complex sequences. 
# However, for standard optimization steps, this requires the user to explicitly call 
# optimizer.zero_grad() or manually set .grad to None at the beginning of each iteration 
# to ensure the update reflects only the current batch's loss derivative.

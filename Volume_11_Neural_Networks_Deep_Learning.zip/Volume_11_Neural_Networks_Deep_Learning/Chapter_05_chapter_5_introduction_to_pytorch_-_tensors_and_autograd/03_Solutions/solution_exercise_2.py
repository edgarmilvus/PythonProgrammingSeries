
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import torch

# 1. Initialization
w = torch.tensor(2.0, requires_grad=True)
x = torch.tensor(5.0, requires_grad=True)
b = torch.tensor(1.0, requires_grad=False) # Initially excludes b

# 2. Forward Pass 1 (Initial Graph)
z = w * x + b
y = z**2

# 3. Graph Inspection 1
print(f"z requires_grad (Initial): {z.requires_grad}")
print(f"y grad_fn (Initial): {y.grad_fn}")

# 4. Post-Hoc Modification
# Note: requires_grad_ is an in-place operation
b.requires_grad_(True)

# 5. Forward Pass 2 (Modified Graph)
# A new graph MUST be constructed since b's properties changed
z_new = w * x + b
y_new = z_new**2

# 6. Graph Inspection 2 & Conceptual Analysis
print(f"z_new requires_grad (New): {z_new.requires_grad}")
print(f"y_new grad_fn (New): {y_new.grad_fn}")

# Conceptual Comment:
# The computational graph is dynamic and built during the forward pass.
# In Pass 1, since b.requires_grad was False, the addition operation (w*x + b) 
# did not need to be tracked for gradients flowing back to b, resulting in 
# AddBackward0 only tracking w and x.
# In Pass 2, after b.requires_grad_(True), the new Add operation (z_new = ...) 
# now includes b as a differentiable input. This changes the internal state 
# of the AddBackward0 node, ensuring that the gradient path is recorded for b 
# as well, even though the final grad_fn (PowBackward1) remains the same because 
# the final operation (squaring) did not change.

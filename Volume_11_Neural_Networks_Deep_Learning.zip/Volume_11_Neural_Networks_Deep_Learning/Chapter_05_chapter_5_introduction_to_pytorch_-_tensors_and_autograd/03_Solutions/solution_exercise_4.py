
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import torch

# 1. Input Initialization
X = torch.rand(2, 2) * 4 + 1 # Values between 1 and 5
X.requires_grad_(True)

# 2. Output Calculation
Y = X**3

# 3. Error Demonstration
print("--- Attempting Y.backward() without arguments ---")
try:
    Y.backward()
except RuntimeError as e:
    print(f"Error captured (Expected): {e}")

# Comment on why the error occurs:
# The error occurs because Y is a 2x2 matrix (non-scalar). PyTorch's .backward() 
# requires a scalar output to calculate a standard gradient vector. For non-scalar 
# outputs, the user must provide a gradient tensor (V) representing the vector 'v' 
# in the Vector-Jacobian Product (v^T * J), which specifies how the subsequent loss 
# depends on Y.

# 4. Gradient Vector Initialization
V = torch.full_like(Y, 0.5) # 2x2 tensor filled with 0.5

# 5. Successful Backward Pass
print("\n--- Successful Backward Pass using VJP ---")
Y.backward(V)

# 6. Verification
print(f"Input X:\n{X}")
print(f"Output Y:\n{Y}")
print(f"Gradient Vector V:\n{V}")
print(f"X.grad after VJP:\n{X.grad}")

# Verification Calculation Check:
# If Y = X^3, then dY/dX = 3 * X^2 (element-wise).
# VJP calculates X.grad = V * dY/dX = 0.5 * 3 * X^2 = 1.5 * X^2

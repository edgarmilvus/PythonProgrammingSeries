
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import torch

# 1. Base Initialization
T_base = torch.tensor(10.0, requires_grad=True)

# 2. Component B (Detaching)
# Creates a new tensor that shares data but is removed from the graph
T_detached = T_base.detach()
C_B = T_detached * 3

# 3. Component C (No Grad Context)
# Operations inside this block do not record history, even if input requires grad
with torch.no_grad():
    T_nograd = T_base * 2 # T_nograd does NOT require grad
C_C = T_nograd * 1

# 4. Component A (Differentiable)
C_A = T_base * 5

# 5. Final Loss and Backward Pass
L_final = C_A + C_B + C_C
L_final.backward()

# 6. Analysis
print(f"T_base.grad: {T_base.grad}")

# Analysis Comment:
# Only component C_A contributed to T_base.grad.
# 
# 1. C_A = T_base * 5: Derivative is d(C_A)/d(T_base) = 5.
# 2. C_B = T_detached * 3: T_detached is explicitly cut off from the graph via .detach(). 
#    It is treated as a constant, thus d(C_B)/d(T_base) = 0.
# 3. C_C = T_nograd * 1: T_nograd was created inside torch.no_grad(). While T_base 
#    still requires gradients, the operation T_base * 2 was not recorded by Autograd. 
#    Therefore, no gradient path exists from C_C back to T_base, thus d(C_C)/d(T_base) = 0.
# 
# The final gradient is 5 + 0 + 0 = 5.
# 
# Difference: .detach() is used when you need to use the value of a differentiable tensor 
# but want to explicitly stop the gradient flow at that point. torch.no_grad() is a context 
# manager used to disable gradient tracking for a block of code, primarily for inference 
# where memory and speed are critical.

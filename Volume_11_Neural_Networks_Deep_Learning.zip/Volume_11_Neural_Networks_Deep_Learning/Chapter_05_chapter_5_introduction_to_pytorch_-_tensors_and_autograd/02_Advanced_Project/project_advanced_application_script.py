
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import torch
import numpy as np
import time
import sys

# Set precision for printing tensors
torch.set_printoptions(precision=4)

# --- 1. Configuration and Data Generation ---
# Ensure reproducibility
torch.manual_seed(42)

# Define the learning rate (optimization hyperparameter)
LEARNING_RATE = 0.0005 
num_samples = 50

# Simulate underlying true parameters for data generation
TRUE_W = 2.5
TRUE_B = 10.0

# Generate synthetic Price (X) data using NumPy
np_price = np.linspace(5, 50, num_samples, dtype=np.float32).reshape(-1, 1)

# Generate noisy Demand (Y) data based on the true relationship
noise = np.random.randn(num_samples, 1).astype(np.float32) * 5
np_demand = (TRUE_W * np_price + TRUE_B + noise).astype(np.float32)

# Convert NumPy arrays to PyTorch Tensors
# This demonstrates seamless interoperability and sets up the primary data structures.
X = torch.from_numpy(np_price) # Input feature (Price)
Y = torch.from_numpy(np_demand) # Target variable (Demand)

print(f"--- Data Initialization ---")
print(f"X Tensor shape: {X.shape} | Y Tensor shape: {Y.shape}")
print(f"Sample X (NumPy conversion): {X[:3].squeeze().numpy()}")
print("-" * 75)

# --- 2. Parameter Initialization: Setting the Autograd Hook ---

# Initialize the model parameters (Weight and Bias) randomly.
# CRITICAL: requires_grad=True instructs PyTorch to track all operations 
# involving these tensors to construct the computational graph necessary for backpropagation.
W = torch.randn(1, 1, dtype=torch.float32, requires_grad=True)
B = torch.randn(1, 1, dtype=torch.float32, requires_grad=True)

print(f"Initial W: {W.item():.4f} | requires_grad: {W.requires_grad}")
print(f"Initial B: {B.item():.4f} | requires_grad: {B.requires_grad}")
print(f"W's gradient function (grad_fn): {W.grad_fn}") # None, as it's a leaf tensor
print("-" * 75)

# --- 3. Forward Pass: Building the Computational Graph ---

start_time = time.perf_counter()

# 3a. Linear Model Prediction (Y_hat = X * W + B)
# Note the use of torch.matmul (or .mm) for matrix multiplication.
Y_hat = torch.matmul(X, W) + B

# 3b. Inspect the graph linkage
# Y_hat is the result of an operation, so it has a grad_fn linked to the previous operation.
print(f"Y_hat's gradient function (grad_fn): {Y_hat.grad_fn}")

# 3c. Calculate the Loss (Mean Squared Error, MSE)
# L = 1/N * sum((Y_hat - Y)^2)
loss = torch.mean((Y_hat - Y) ** 2)

print(f"Loss's gradient function (grad_fn): {loss.grad_fn}")
print(f"Current Loss (MSE): {loss.item():.8f}")
print("-" * 75)


# --- 4. Backward Pass: Automatic Gradient Computation ---

# The .backward() call initiates the backpropagation process, 
# calculating the derivative of the scalar 'loss' with respect to all 
# tensors that have requires_grad=True (W and B).
loss.backward()

end_time = time.perf_counter()

# --- 5. Gradient Inspection and Manual Parameter Update ---

# 5a. Inspect the calculated gradients (dL/dW and dL/dB)
print(f"Gradient of Loss w.r.t W (dL/dW): {W.grad.item():.6f}")
print(f"Gradient of Loss w.r.t B (dL/dB): {B.grad.item():.6f}")
print(f"Time taken for Forward + Backward: {(end_time - start_time) * 1000:.4f} ms")

# 5b. Manual Gradient Descent Step
# New Parameter = Old Parameter - Learning Rate * Gradient
# CRITICAL: Use torch.no_grad() to ensure the update operation itself 
# is not tracked by Autograd. This prevents corruption of the next graph iteration.
with torch.no_grad():
    # Update W and B in place using the calculated gradients
    W.data.sub_(LEARNING_RATE * W.grad.data)
    B.data.sub_(LEARNING_RATE * B.grad.data)
    
# 5c. Clear the gradients 
# Gradients are accumulated by default. They must be explicitly zeroed 
# before the next call to .backward().
W.grad.zero_()
B.grad.zero_()

# --- 6. Verification and Final Output ---

# Re-calculate loss with updated parameters to verify optimization step
Y_hat_new = torch.matmul(X, W) + B
loss_new = torch.mean((Y_hat_new - Y) ** 2)

print("-" * 75)
print(f"Updated W: {W.item():.4f} (Target was {TRUE_W})")
print(f"Updated B: {B.item():.4f} (Target was {TRUE_B})")
print(f"New Loss (MSE) after one step: {loss_new.item():.8f} (Lower than initial loss)")
print(f"W.grad after zeroing check: {W.grad.item()}")

# Demonstrate final tensor conversion for external reporting
final_w_np = W.item()
print("-" * 75)
print(f"Final optimized weight (converted to standard Python float): {final_w_np}")
print(f"System memory usage check (simulated): {sys.getsizeof(W.storage()) / 1024:.2f} KB")

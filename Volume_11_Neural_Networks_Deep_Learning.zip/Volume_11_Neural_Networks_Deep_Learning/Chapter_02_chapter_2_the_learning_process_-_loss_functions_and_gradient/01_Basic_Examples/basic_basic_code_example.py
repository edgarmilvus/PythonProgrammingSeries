
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np

# --- 1. DATA AND INITIALIZATION ---

# Synthetic data: Simple linear relationship (Price = 2 * Size + 1)
# N = 5 data points
X = np.array([1.0, 2.0, 3.0, 4.0, 5.0]) # Widget Size (Input feature)
Y_true = np.array([3.0, 5.0, 7.0, 9.0, 11.0]) # Actual Widget Price (Target)

# Initialize parameters (m = slope, b = bias/intercept)
# These are the weights the model will learn.
m = 0.5
b = 0.1

# Hyperparameters controlling the learning process
LEARNING_RATE = 0.01
EPOCHS = 1000 # Number of iterations for optimization

# --- 2. CORE FUNCTIONS ---

def predict(X, m, b):
    """Calculates the linear prediction: Y_pred = m * X + b."""
    return m * X + b

def mean_squared_error(Y_true, Y_pred):
    """Calculates the Loss (MSE)."""
    # The error is the difference between true and predicted values
    errors = Y_true - Y_pred
    # Square the errors and calculate the mean
    return np.mean(errors**2)

def compute_gradients(X, Y_true, Y_pred):
    """
    Calculates the partial derivatives (gradients) of the MSE Loss
    with respect to the parameters m and b.
    """
    N = len(X) # Number of data points
    
    # Residuals (Error vector)
    error = Y_pred - Y_true
    
    # Gradient calculation derived from L = 1/N * sum((Y_pred - Y_true)^2)
    
    # Gradient with respect to slope (m): dL/dm
    # dL/dm = (2/N) * sum(error * X)
    grad_m = (2/N) * np.sum(error * X)
    
    # Gradient with respect to bias (b): dL/db
    # dL/db = (2/N) * sum(error)
    grad_b = (2/N) * np.sum(error)
    
    return grad_m, grad_b

# --- 3. THE TRAINING LOOP (GRADIENT DESCENT) ---

print(f"Initial Parameters: m={m:.4f}, b={b:.4f}")
Y_initial_pred = predict(X, m, b)
initial_loss = mean_squared_error(Y_true, Y_initial_pred)
print(f"Initial Loss (MSE): {initial_loss:.4f}\n")

for epoch in range(EPOCHS):
    # Step 3.1: Forward Pass - Generate predictions
    Y_pred = predict(X, m, b)
    
    # Step 3.2: Calculate Loss - Quantify the error
    loss = mean_squared_error(Y_true, Y_pred)
    
    # Step 3.3: Backward Pass - Calculate Gradients
    grad_m, grad_b = compute_gradients(X, Y_true, Y_pred)
    
    # Step 3.4: Parameter Update (The Gradient Descent Step)
    # New Parameter = Old Parameter - (Learning Rate * Gradient)
    m = m - LEARNING_RATE * grad_m
    b = b - LEARNING_RATE * grad_b
    
    # Reporting progress
    if (epoch + 1) % 100 == 0:
        print(f"Epoch {epoch + 1:4d}/{EPOCHS} | Loss: {loss:.6f} | m: {m:.4f} | b: {b:.4f}")

# --- 4. FINAL RESULTS ---
print("\n--- Training Complete ---")
print(f"Optimal Parameters Found: m={m:.4f}, b={b:.4f}")
print(f"Target Parameters (Approx.): m=2.0, b=1.0")

# Test the final model
X_test = np.array([6.0])
Y_test_pred = predict(X_test, m, b)
print(f"Prediction for X=6.0: {Y_test_pred[0]:.4f} (Expected 13.0)")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np

# 1. MSE Implementation
def mean_squared_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Calculates the Mean Squared Error (MSE) loss."""
    N = len(y_true)
    # Calculate the difference (error)
    error = y_pred - y_true
    # Square the error and take the mean
    loss = np.mean(error**2)
    return loss

# 2. MSE Gradient Implementation
def mse_gradient(y_true: np.ndarray, y_pred: np.ndarray) -> np.ndarray:
    """
    Calculates the gradient of the MSE loss with respect to the predictions (y_pred).
    dL/d(y_pred) = (2/N) * (y_pred - y_true)
    """
    N = len(y_true)
    # The gradient is 2/N times the error vector
    gradient = (2 / N) * (y_pred - y_true)
    return gradient

# 3. Custom L1-Inspired Loss (Smooth MAE)
def mae_smooth_loss(y_true: np.ndarray, y_pred: np.ndarray, epsilon: float = 1e-6) -> float:
    """
    Calculates a smooth approximation of MAE loss using L2 regularization
    near zero to ensure differentiability (similar to Huber loss near the origin).
    L = (1/N) * sum(sqrt((y_i - y_hat_i)^2 + epsilon))
    """
    N = len(y_true)
    error = y_true - y_pred
    # Calculate the smooth L1 approximation
    smooth_error = np.sqrt(error**2 + epsilon)
    loss = np.mean(smooth_error)
    return loss

# Test case demonstration
y_t = np.array([10.0, 12.0, 8.0])
y_p = np.array([9.5, 11.0, 8.5])

mse = mean_squared_error(y_t, y_p)
mse_grad = mse_gradient(y_t, y_p)
mae_smooth = mae_smooth_loss(y_t, y_p)

# print(f"MSE Loss: {mse:.4f}")
# print(f"MSE Gradient (dL/d_yhat): {mse_grad}")
# print(f"Smooth MAE Loss: {mae_smooth:.4f}")

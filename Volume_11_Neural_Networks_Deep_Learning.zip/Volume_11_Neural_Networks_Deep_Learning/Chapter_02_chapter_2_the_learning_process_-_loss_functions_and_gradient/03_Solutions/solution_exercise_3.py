
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np
import math

# Reusing data generation and MSE from Exercise 2

def generate_linear_data(N: int = 100, true_w: float = 3.0, true_b: float = 5.0):
    np.random.seed(42)
    X = np.random.rand(N, 1) * 10 
    noise = np.random.randn(N, 1) * 2
    y = true_w * X + true_b + noise
    return X, y

def mean_squared_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return np.mean((y_pred - y_true)**2)

# 1. Mini-Batch Generator Implementation
def mini_batch_generator(X: np.ndarray, y: np.ndarray, batch_size: int):
    """Yields shuffled mini-batches of data."""
    N = X.shape[0]
    indices = np.arange(N)
    np.random.shuffle(indices) # Shuffle data at start of epoch

    for start_idx in range(0, N, batch_size):
        end_idx = min(start_idx + batch_size, N)
        batch_indices = indices[start_idx:end_idx]
        
        yield X[batch_indices], y[batch_indices]

class MiniBatchGradientDescentOptimizer:
    def __init__(self, learning_rate: float, epochs: int):
        self.lr = learning_rate
        self.epochs = epochs
        self.W = None 
        self.N = 0

    def _add_bias_term(self, X: np.ndarray) -> np.ndarray:
        ones = np.ones((X.shape[0], 1))
        return np.hstack((X, ones))

    def calculate_gradients(self, X_biased: np.ndarray, y: np.ndarray, y_pred: np.ndarray) -> np.ndarray:
        """Gradient calculation adapted for batch size M."""
        M = X_biased.shape[0] # M is batch size
        error = y_pred - y
        gradient = (1 / M) * X_biased.T @ error
        return gradient

    def train_mbgd(self, X: np.ndarray, y: np.ndarray, batch_size: int) -> list[float]:
        """Executes the Mini-Batch Gradient Descent optimization process."""
        self.N = X.shape[0]
        
        # Initialize weights
        self.W = np.random.randn(X.shape[1] + 1, 1) * 0.01
        
        loss_history = []
        
        for epoch in range(self.epochs):
            # Use the generator to iterate through batches
            for X_batch, y_batch in mini_batch_generator(X, y, batch_size):
                X_biased_batch = self._add_bias_term(X_batch)
                
                # Forward Pass
                y_pred_batch = X_biased_batch @ self.W
                
                # Calculate Gradients
                gradients = self.calculate_gradients(X_biased_batch, y_batch, y_pred_batch)
                
                # Update Parameters
                self.W -= self.lr * gradients
                
                # Track loss (using the current batch for loss calculation)
                loss = mean_squared_error(y_batch, y_pred_batch)
                loss_history.append(loss)

        return loss_history

# --- Setup Data ---
X_data, y_data = generate_linear_data(N=500)
y_data = y_data.reshape(-1, 1)
X_data = X_data.reshape(-1, 1)
N_total = X_data.shape[0]

# --- 3. Learning Rate Divergence Test (Fixed Batch Size = 32) ---
EPOCHS = 50
BATCH_SIZE_LR = 32

# Case A: High Rate (Divergence/Oscillation)
optimizer_high_lr = MiniBatchGradientDescentOptimizer(learning_rate=0.5, epochs=EPOCHS)
loss_high_lr = optimizer_high_lr.train_mbgd(X_data, y_data, BATCH_SIZE_LR)

# Case B: Optimal Rate (Smooth, rapid convergence)
optimizer_optimal_lr = MiniBatchGradientDescentOptimizer(learning_rate=0.01, epochs=EPOCHS)
loss_optimal_lr = optimizer_optimal_lr.train_mbgd(X_data, y_data, BATCH_SIZE_LR)

# Case C: Low Rate (Slow convergence)
optimizer_low_lr = MiniBatchGradientDescentOptimizer(learning_rate=0.0001, epochs=EPOCHS)
loss_low_lr = optimizer_low_lr.train_mbgd(X_data, y_data, BATCH_SIZE_LR)

# --- 4. Batch Size Stability Test (Fixed Optimal Learning Rate = 0.01) ---
LR_BATCH = 0.01
EPOCHS_BATCH = 50

# Case D: SGD (Batch Size = 1) - High Noise
optimizer_sgd = MiniBatchGradientDescentOptimizer(learning_rate=LR_BATCH, epochs=EPOCHS_BATCH)
loss_sgd = optimizer_sgd.train_mbgd(X_data, y_data, batch_size=1)

# Case E: MBGD (Batch Size = 64) - Balanced
optimizer_mbgd = MiniBatchGradientDescentOptimizer(learning_rate=LR_BATCH, epochs=EPOCHS_BATCH)
loss_mbgd = optimizer_mbgd.train_mbgd(X_data, y_data, batch_size=64)

# Case F: BGD (Batch Size = N) - Smooth
optimizer_bgd = MiniBatchGradientDescentOptimizer(learning_rate=LR_BATCH, epochs=EPOCHS_BATCH)
loss_bgd = optimizer_bgd.train_mbgd(X_data, y_data, batch_size=N_total)


# --- 5. Visualization Preparation (Structured Output) ---

print("--- Learning Rate Comparison (Loss vs. Iteration Step) ---")
print(f"High LR (0.5) Iterations: {len(loss_high_lr)}")
print(f"Optimal LR (0.01) Iterations: {len(loss_optimal_lr)}")
print(f"Low LR (0.0001) Iterations: {len(loss_low_lr)}")

# Note: The actual lists are long, showing only the first 5 and last 5 elements
def summarize_loss(history):
    return [round(h, 4) for h in history[:5]] + ["..."] + [round(h, 4) for h in history[-5:]]

lr_results = {
    "High_LR_0.5": summarize_loss(loss_high_lr),
    "Optimal_LR_0.01": summarize_loss(loss_optimal_lr),
    "Low_LR_0.0001": summarize_loss(loss_low_lr),
}
print("\nLearning Rate Loss History Summary:")
print(lr_results)

print("\n--- Batch Size Comparison (Loss vs. Iteration Step) ---")
print(f"SGD (B=1) Iterations: {len(loss_sgd)}")
print(f"MBGD (B=64) Iterations: {len(loss_mbgd)}")
print(f"BGD (B=N) Iterations: {len(loss_bgd)}")

batch_results = {
    "SGD_B1": summarize_loss(loss_sgd),
    "MBGD_B64": summarize_loss(loss_mbgd),
    "BGD_B500": summarize_loss(loss_bgd),
}
print("\nBatch Size Loss History Summary:")
print(batch_results)

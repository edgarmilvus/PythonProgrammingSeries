
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np

# Helper function for data simulation
def generate_linear_data(N: int = 100, true_w: float = 3.0, true_b: float = 5.0):
    """Generates synthetic linear data (y = w*x + b + noise)."""
    np.random.seed(42)
    X = np.random.rand(N, 1) * 10 
    noise = np.random.randn(N, 1) * 2
    y = true_w * X + true_b + noise
    return X, y

# MSE Loss (reused from Exercise 1)
def mean_squared_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return np.mean((y_pred - y_true)**2)

class BatchGradientDescentOptimizer:
    def __init__(self, learning_rate: float, epochs: int):
        self.lr = learning_rate
        self.epochs = epochs
        self.W = None  # Weights (W[0] is feature weight, W[1] is bias)
        self.N = 0     # Dataset size

    def _add_bias_term(self, X: np.ndarray) -> np.ndarray:
        """Prepends a column of ones to X for the bias term."""
        ones = np.ones((X.shape[0], 1))
        # X_biased now has shape (N, 2)
        return np.hstack((X, ones))

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Calculates y_hat = X_biased @ W."""
        if self.W is None:
            raise ValueError("Model not initialized. Run train() first.")
        X_biased = self._add_bias_term(X)
        return X_biased @ self.W

    def calculate_gradients(self, X_biased: np.ndarray, y: np.ndarray, y_pred: np.ndarray) -> np.ndarray:
        """
        Calculates the gradient of the MSE loss w.r.t. the parameters W.
        dL/dW = (1/N) * X_biased^T * (y_pred - y)
        """
        error = y_pred - y
        # Gradient shape will be (2, 1)
        gradient = (1 / self.N) * X_biased.T @ error
        return gradient

    def train(self, X: np.ndarray, y: np.ndarray) -> list[float]:
        """Executes the Batch Gradient Descent optimization process."""
        self.N = X.shape[0]
        X_biased = self._add_bias_term(X)
        
        # Initialize weights (e.g., small random values)
        # W shape must be (2, 1) to match X_biased @ W calculation
        self.W = np.random.randn(X_biased.shape[1], 1) * 0.01
        
        loss_history = []

        for epoch in range(self.epochs):
            # 1. Calculate predictions (Forward Pass)
            y_pred = X_biased @ self.W
            
            # 2. Calculate Loss
            loss = mean_squared_error(y, y_pred)
            loss_history.append(loss)
            
            # 3. Calculate Gradients (Backpropagation)
            gradients = self.calculate_gradients(X_biased, y, y_pred)
            
            # 4. Update Parameters (Gradient Descent Step)
            self.W -= self.lr * gradients
            
            # Optional: Print status every 10 epochs
            # if (epoch + 1) % 10 == 0:
            #     print(f"Epoch {epoch+1}/{self.epochs}, Loss: {loss:.4f}, W: {self.W.flatten()}")

        return loss_history

# --- Execution Test ---
X_data, y_data = generate_linear_data(N=100)
y_data = y_data.reshape(-1, 1) # Ensure y is (N, 1)
X_data = X_data.reshape(-1, 1) # Ensure X is (N, 1)

bgd_optimizer = BatchGradientDescentOptimizer(learning_rate=0.01, epochs=100)
loss_hist = bgd_optimizer.train(X_data, y_data)

# print("\nBGD Training Complete.")
# print(f"Final Weights (w1, w0): {bgd_optimizer.W.flatten()}")
# print(f"Initial Loss: {loss_hist[0]:.4f}, Final Loss: {loss_hist[-1]:.4f}")

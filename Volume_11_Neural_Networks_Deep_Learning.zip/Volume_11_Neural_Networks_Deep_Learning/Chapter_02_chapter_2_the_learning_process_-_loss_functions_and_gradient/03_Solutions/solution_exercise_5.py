
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np
from sklearn.datasets import make_classification # Used for generating classification data

# 1. Sigmoid Implementation
def sigmoid(z: np.ndarray) -> np.ndarray:
    """Sigmoid activation function."""
    return 1 / (1 + np.exp(-z))

# 2. BCE Loss Implementation
def binary_cross_entropy_loss(y_true: np.ndarray, y_pred: np.ndarray, epsilon: float = 1e-15) -> float:
    """
    Calculates Binary Cross-Entropy loss.
    y_true and y_pred must be (N, 1) arrays.
    """
    # Clip predictions to prevent log(0) for numerical stability
    y_pred = np.clip(y_pred, epsilon, 1.0 - epsilon)
    
    # BCE formula: - (1/N) * sum [y*log(y_hat) + (1-y)*log(1-y_hat)]
    loss = -np.mean(y_true * np.log(y_pred) + (1 - y_true) * np.log(1 - y_pred))
    return loss

# Helper function for mini-batch generation (reused from Ex 3)
def mini_batch_generator(X: np.ndarray, y: np.ndarray, batch_size: int):
    N = X.shape[0]
    indices = np.arange(N)
    np.random.shuffle(indices)
    for start_idx in range(0, N, batch_size):
        end_idx = min(start_idx + batch_size, N)
        batch_indices = indices[start_idx:end_idx]
        yield X[batch_indices], y[batch_indices]

# Helper function for data generation
def generate_classification_data(N: int = 200):
    X, y = make_classification(n_samples=N, n_features=2, n_redundant=0, n_informative=2,
                               n_clusters_per_class=1, random_state=42)
    return X, y.reshape(-1, 1) # Ensure y is (N, 1)

# 3. Classifier Class
class LogisticRegressionMBGD:
    def __init__(self, learning_rate: float, epochs: int, batch_size: int):
        self.lr = learning_rate
        self.epochs = epochs
        self.batch_size = batch_size
        self.W = None 

    def _add_bias_term(self, X: np.ndarray) -> np.ndarray:
        ones = np.ones((X.shape[0], 1))
        return np.hstack((X, ones))

    def forward(self, X: np.ndarray) -> np.ndarray:
        """Calculates linear output z and applies sigmoid for probability y_hat."""
        X_biased = self._add_bias_term(X)
        z = X_biased @ self.W
        y_pred = sigmoid(z)
        return y_pred

    # 4. Accuracy Metric
    def calculate_accuracy(self, y_true: np.ndarray, y_pred: np.ndarray) -> float:
        y_pred_class = (y_pred >= 0.5).astype(int)
        accuracy = np.mean(y_pred_class == y_true)
        return accuracy

    # 5. Gradient Calculation
    def calculate_gradients(self, X_biased: np.ndarray, error_signal: np.ndarray) -> np.ndarray:
        """
        Calculates the gradient of BCE loss w.r.t. the parameters W.
        Uses the simplified gradient: dL/dW = (1/M) * X_biased^T * (y_pred - y)
        """
        M = X_biased.shape[0] # Batch size
        # error_signal is (y_pred - y)
        gradient = (1 / M) * X_biased.T @ error_signal
        return gradient

    def train(self, X: np.ndarray, y: np.ndarray) -> tuple[list[float], list[float]]:
        """MBGD training loop for Logistic Regression."""
        N_features = X.shape[1]
        
        # Initialize weights (N_features + 1 for bias)
        self.W = np.random.randn(N_features + 1, 1) * 0.01
        
        loss_history = []
        accuracy_history = []
        
        for epoch in range(self.epochs):
            epoch_loss = 0
            epoch_accuracy = 0
            num_batches = 0

            for X_batch, y_batch in mini_batch_generator(X, y, self.batch_size):
                X_biased_batch = self._add_bias_term(X_batch)
                
                # 1. Forward Pass
                y_pred_batch = sigmoid(X_biased_batch @ self.W)
                
                # 2. Calculate Loss and Accuracy (for tracking)
                loss = binary_cross_entropy_loss(y_batch, y_pred_batch)
                acc = self.calculate_accuracy(y_batch, y_pred_batch)
                
                epoch_loss += loss
                epoch_accuracy += acc
                num_batches += 1
                
                # 3. Calculate Error Signal (dL/dz = y_hat - y)
                error_signal = y_pred_batch - y_batch
                
                # 4. Calculate Weight Gradients (Backpropagation)
                gradients = self.calculate_gradients(X_biased_batch, error_signal)
                
                # 5. Update Parameters
                self.W -= self.lr * gradients
            
            # Record average metrics for the epoch
            loss_history.append(epoch_loss / num_batches)
            accuracy_history.append(epoch_accuracy / num_batches)

        return loss_history, accuracy_history

# --- Execution Test ---
X_cls, y_cls = generate_classification_data(N=500)

lr_optimizer = LogisticRegressionMBGD(learning_rate=0.05, epochs=100, batch_size=32)
loss_hist, acc_hist = lr_optimizer.train(X_cls, y_cls)

print("--- Logistic Regression MBGD Training Results ---")
print(f"Final Weights (w1, w2, bias): {lr_optimizer.W.flatten()}")
print(f"Initial Loss: {loss_hist[0]:.4f}, Final Loss: {loss_hist[-1]:.4f}")
print(f"Initial Accuracy: {acc_hist[0]:.4f}, Final Accuracy: {acc_hist[-1]:.4f}")

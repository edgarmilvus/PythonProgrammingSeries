
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np

# Reusing data generation and MSE from Exercise 2
def generate_linear_data(N: int = 100, true_w: float = 3.0, true_b: float = 5.0):
    np.random.seed(42)
    X = np.random.rand(N, 1) * 10 
    noise = np.random.randn(N, 1) * 2
    y = true_w * X + true_b + noise
    return X, y

def mean_squared_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return np.mean((y_pred - y_true)**2)

# 1. Loss Grid Calculation
def calculate_loss_grid(X: np.ndarray, y: np.ndarray, w1_range: np.ndarray, w0_range: np.ndarray) -> np.ndarray:
    """Calculates the MSE loss for every combination of w1 and w0 in the provided ranges."""
    N = X.shape[0]
    
    # Create the mesh grid for W1 and W0
    W1, W0 = np.meshgrid(w1_range, w0_range)
    
    # Initialize loss array
    Loss = np.zeros(W1.shape)
    
    # Calculate loss for each (w1, w0) pair
    for i in range(W1.shape[0]):
        for j in range(W1.shape[1]):
            w1 = W1[i, j]
            w0 = W0[i, j]
            
            # Prediction: y_hat = w1*X + w0
            y_pred = X.flatten() * w1 + w0
            
            Loss[i, j] = mean_squared_error(y.flatten(), y_pred)
            
    return W1, W0, Loss

# Modified BGD Optimizer to track parameters
class PathTrackingBGD:
    def __init__(self, learning_rate: float, epochs: int, initial_W: np.ndarray = None):
        self.lr = learning_rate
        self.epochs = epochs
        self.W = initial_W
        self.N = 0

    def _add_bias_term(self, X: np.ndarray) -> np.ndarray:
        ones = np.ones((X.shape[0], 1))
        return np.hstack((X, ones))

    def calculate_gradients(self, X_biased: np.ndarray, y: np.ndarray, y_pred: np.ndarray) -> np.ndarray:
        M = X_biased.shape[0]
        error = y_pred - y
        gradient = (1 / M) * X_biased.T @ error
        return gradient

    # 2. Path Tracking Modification
    def train(self, X: np.ndarray, y: np.ndarray) -> tuple[list[float], list[tuple[float, float]]]:
        """Trains the model and records loss and parameter history."""
        self.N = X.shape[0]
        X_biased = self._add_bias_term(X)
        
        # Initialize weights if not provided
        if self.W is None:
            self.W = np.random.randn(X_biased.shape[1], 1) * 0.1
        
        loss_history = []
        parameter_history = []
        
        for epoch in range(self.epochs):
            # Record current weights before update
            parameter_history.append((self.W[0, 0], self.W[1, 0]))
            
            # Forward Pass
            y_pred = X_biased @ self.W
            loss = mean_squared_error(y, y_pred)
            loss_history.append(loss)
            
            # Backpropagation and Update
            gradients = self.calculate_gradients(X_biased, y, y_pred)
            self.W -= self.lr * gradients

        # Record final weights after the last update
        parameter_history.append((self.W[0, 0], self.W[1, 0]))

        return loss_history, parameter_history

# --- Setup and Execution ---
X_data, y_data = generate_linear_data(N=100)
y_data = y_data.reshape(-1, 1)
X_data = X_data.reshape(-1, 1)

# Define initialization point (W1=0, W0=0) for consistent comparison
initial_W = np.array([[0.0], [0.0]]) 
EPOCHS = 50

# 5. Interactive Analysis: Running three distinct learning rates

# Case A: Small Alpha (Slow creeping path)
alpha_small = 0.001
opt_small = PathTrackingBGD(learning_rate=alpha_small, epochs=EPOCHS, initial_W=initial_W.copy())
_, path_small = opt_small.train(X_data, y_data)

# Case B: Optimal Alpha (Direct, efficient path)
alpha_optimal = 0.05
opt_optimal = PathTrackingBGD(learning_rate=alpha_optimal, epochs=EPOCHS, initial_W=initial_W.copy())
_, path_optimal = opt_optimal.train(X_data, y_data)

# Case C: Large Alpha (Oscillation/Instability)
alpha_large = 0.5
opt_large = PathTrackingBGD(learning_rate=alpha_large, epochs=EPOCHS, initial_W=initial_W.copy())
_, path_large = opt_large.train(X_data, y_data)

# --- Visualization Preparation (Conceptual Output) ---

# Define the grid range based on expected true values (w1=3, w0=5)
w1_range = np.linspace(0, 6, 100)
w0_range = np.linspace(0, 10, 100)
W1_grid, W0_grid, Loss_grid = calculate_loss_grid(X_data, y_data, w1_range, w0_range)

print("--- Optimization Landscape and Path Tracking Data ---")
print(f"True Parameters: w1=3.0, w0=5.0 (approx)")
print(f"Grid Loss Shape: {Loss_grid.shape}")
print(f"Minimum Loss found in grid: {Loss_grid.min():.4f}")

print("\n--- Parameter History (Coordinates for Contour Plot) ---")

def summarize_path(path):
    return [tuple(round(p, 4) for p in point) for point in path[:3]] + ["..."] + [tuple(round(p, 4) for p in point) for point in path[-3:]]

print(f"Case A (Small Alpha={alpha_small}): Total Steps={len(path_small)}")
print(summarize_path(path_small))
print(f"\nCase B (Optimal Alpha={alpha_optimal}): Total Steps={len(path_optimal)}")
print(summarize_path(path_optimal))
print(f"\nCase C (Large Alpha={alpha_large}): Total Steps={len(path_large)}")
print(summarize_path(path_large))

# Conceptual plotting setup (if Matplotlib were available):
"""
import matplotlib.pyplot as plt
plt.figure(figsize=(10, 7))
CS = plt.contour(W1_grid, W0_grid, Loss_grid, levels=np.logspace(0, 3, 10), cmap='viridis')
plt.clabel(CS, inline=1, fontsize=10)
plt.title('MSE Loss Contour and GD Paths')
plt.xlabel('Weight (w1)')
plt.ylabel('Bias (w0)')

# Plot Paths
plt.plot([p[0] for p in path_small], [p[1] for p in path_small], 'r-', label='Small LR (0.001)')
plt.plot(path_small[0][0], path_small[0][1], 'ro', label='Start')
plt.plot([p[0] for p in path_optimal], [p[1] for p in path_optimal], 'g-', label='Optimal LR (0.05)')
plt.plot([p[0] for p in path_large], [p[1] for p in path_large], 'b--', label='Large LR (0.5)')
plt.legend()
plt.show()
"""


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np

# --- 1. Hyperparameters and Configuration ---
N_SAMPLES = 1000
LEARNING_RATE = 0.01
EPOCHS = 50
BATCH_SIZE = 32
TRUE_W = 5.0  # The actual underlying relationship weight
TRUE_B = 3.0  # The actual underlying relationship bias

# --- 2. Data Generation and Preprocessing ---
np.random.seed(42)
# Feature X: Synthetic input data (simulating square footage)
X = np.linspace(100, 1000, N_SAMPLES).reshape(-1, 1) # Shape (1000, 1)
# Target Y: Linear relationship + Gaussian noise
noise = np.random.normal(0, 50, N_SAMPLES).reshape(-1, 1)
y = TRUE_W * X + TRUE_B + noise # Shape (1000, 1)

# Feature Scaling (Normalization) is crucial for stable GD convergence
X_mean, X_std = X.mean(), X.std()
X_norm = (X - X_mean) / X_std # Normalized X data

# --- 3. Core Functions: Loss and Gradient Calculation ---

def mean_squared_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Calculates the Mean Squared Error (MSE) loss."""
    # L = 1/m * Sum((y_pred - y_true)^2)
    return np.mean((y_pred - y_true) ** 2)

def compute_gradients(X_batch: np.ndarray, y_batch: np.ndarray, y_pred: np.ndarray) -> tuple:
    """
    Calculates the gradients (dW and db) using the chain rule derived from MSE.
    This is the Backward Pass.
    """
    m = X_batch.shape[0] # Current batch size
    
    # Step 1: Calculate the raw error (dL/dY_pred)
    error = y_pred - y_batch # Shape (m, 1)
    
    # Step 2: Calculate Gradient of Loss w.r.t Weight (dW)
    # dL/dW = X^T * (dL/dY_pred) / m
    # X_batch.T is (1, m). Error is (m, 1). Result is (1, 1).
    dW = (1/m) * X_batch.T @ error
    
    # Step 3: Calculate Gradient of Loss w.r.t Bias (db)
    # dL/db = Sum(dL/dY_pred) / m
    db = (1/m) * np.sum(error)
    
    return dW, db

# --- 4. Mini-Batch Gradient Descent Trainer ---

def mini_batch_trainer(X_data, y_data, W_init, b_init, lr, epochs, batch_size):
    """Executes the Mini-Batch Gradient Descent optimization loop."""
    W = W_init.copy()
    b = b_init
    loss_history = []
    data_size = X_data.shape[0]
    
    for epoch in range(epochs):
        # Data shuffling is essential for Mini-Batch and Stochastic GD
        indices = np.arange(data_size)
        np.random.shuffle(indices)
        X_shuffled = X_data[indices]
        y_shuffled = y_data[indices]
        
        epoch_loss = 0.0
        n_batches = 0
        
        # Iterate through data in chunks (mini-batches)
        for i in range(0, data_size, batch_size):
            X_batch = X_shuffled[i:i + batch_size]
            y_batch = y_shuffled[i:i + batch_size]
            
            # 4a. Forward Pass: Prediction
            y_pred = X_batch @ W + b
            
            # 4b. Loss Calculation
            current_loss = mean_squared_error(y_batch, y_pred)
            epoch_loss += current_loss
            n_batches += 1
            
            # 4c. Backward Pass: Compute Gradients
            dW, db = compute_gradients(X_batch, y_batch, y_pred)
            
            # 4d. Optimization Step (Parameter Update)
            # P = P - lr * dP
            W -= lr * dW
            b -= lr * db
            
        # Record and report progress
        avg_epoch_loss = epoch_loss / n_batches
        loss_history.append(avg_epoch_loss)
        
        if (epoch + 1) % 10 == 0:
            print(f"Epoch {epoch+1:02d}/{epochs} | Avg Loss: {avg_epoch_loss:.4f} | W_norm: {W[0,0]:.4f}, b_norm: {b:.4f}")

    return W, b, loss_history

# --- 5. Execution and Results ---

# Initial parameters (small random values)
W_initial = np.random.randn(X_norm.shape[1], 1) * 0.1
b_initial = np.random.randn() * 0.1

print("--- Starting Mini-Batch Gradient Descent Training ---")
W_final, b_final, history = mini_batch_trainer(
    X_norm, y, W_initial, b_initial, LEARNING_RATE, EPOCHS, BATCH_SIZE
)

print("\n--- Training Complete ---")
print(f"True Parameters: W={TRUE_W}, b={TRUE_B}")

# --- 6. De-Normalization for Interpretation ---
# The model was trained on normalized data (X_norm). 
# To compare W_final and b_final to TRUE_W and TRUE_B, we must reverse the normalization.
# y = W_final * X_norm + b_final
# y = W_final * ((X - X_mean) / X_std) + b_final
# y = (W_final / X_std) * X + (b_final - W_final * X_mean / X_std)

W_denorm = W_final[0, 0] / X_std
b_denorm = b_final - W_final[0, 0] * X_mean / X_std

print(f"Learned (Denormalized) Parameters: W={W_denorm:.2f}, b={b_denorm:.2f}")
print(f"Final MSE Loss: {history[-1]:.4f}")

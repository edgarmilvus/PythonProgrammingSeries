
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import math

def calculate_conv_output_shape(H_in, K, S, P_type):
    """
    Calculates the output dimension (H_out) and required total padding (P_total) 
    for a 2D convolution operation.
    """
    
    if P_type == 'valid':
        # Valid Padding Formula: H_out = floor((H_in - K) / S) + 1
        H_out = math.floor((H_in - K) / S) + 1
        P_total = 0
        
    elif P_type == 'same':
        # 1. Output Size Calculation: H_out = ceil(H_in / S)
        H_out = math.ceil(H_in / S)
        
        # 2. Total Padding Calculation: P_total = H_padded_required - H_in
        # H_padded_required = (H_out - 1) * S + K
        H_padded_required = (H_out - 1) * S + K
        P_total = H_padded_required - H_in
        
    else:
        raise ValueError("P_type must be 'valid' or 'same'")
        
    return H_out, P_total

# Test Cases Demonstration
tests = [
    (32, 5, 1, 'valid'),
    (64, 3, 1, 'same'),
    (128, 3, 2, 'same')
]

results = []
for H_in, K, S, P_type in tests:
    H_out, P_total = calculate_conv_output_shape(H_in, K, S, P_type)
    results.append(f"In: {H_in}x{H_in}, K: {K}, S: {S}, P_type: '{P_type}' -> Out: {H_out}x{H_out}, Total Padding: {P_total}")

# Outputting results:
# print("\n".join(results))
# In: 32x32, K: 5, S: 1, P_type: 'valid' -> Out: 28x28, Total Padding: 0
# In: 64x64, K: 3, S: 1, P_type: 'same' -> Out: 64x64, Total Padding: 2
# In: 128x128, K: 3, S: 2, P_type: 'same' -> Out: 64x64, Total Padding: 1


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np

def apply_pooling(feature_map, pool_size, stride, pool_type='max'):
    """Applies 2D pooling (Max or Average) to a feature map."""
    H_in, W_in = feature_map.shape
    
    # Calculate output dimensions
    H_out = (H_in - pool_size) // stride + 1
    W_out = (W_in - pool_size) // stride + 1
    
    output_map = np.zeros((H_out, W_out))
    
    for i in range(H_out):
        for j in range(W_out):
            h_start = i * stride
            w_start = j * stride
            window = feature_map[h_start:h_start + pool_size, w_start:w_start + pool_size]
            
            if pool_type == 'max':
                output_map[i, j] = np.max(window)
            elif pool_type == 'avg':
                output_map[i, j] = np.mean(window)
                
    return output_map

def apply_max_pooling(feature_map, pool_size, stride):
    return apply_pooling(feature_map, pool_size, stride, pool_type='max')

def apply_avg_pooling(feature_map, pool_size, stride):
    return apply_pooling(feature_map, pool_size, stride, pool_type='avg')

# Setup and Test
P_size = 2
S_val = 2

# Original Feature Map (Spike at (2, 2) to (3, 3))
F_original = np.zeros((8, 8))
F_original[2:4, 2:4] = 10.0 

# Shifted Feature Map (Spike at (2, 3) to (3, 4) - 1 pixel right)
F_shifted = np.zeros((8, 8))
F_shifted[2:4, 3:5] = 10.0 

Max_Original = apply_max_pooling(F_original, P_size, S_val)
Max_Shifted = apply_max_pooling(F_shifted, P_size, S_val)
Avg_Original = apply_avg_pooling(F_original, P_size, S_val)

print("--- Translational Invariance Test (Max Pooling) ---")
print("Max Pooling Output (Original Feature):\n", Max_Original)
print("Max Pooling Output (Shifted Feature):\n", Max_Shifted)
print("\n--- Feature Retention Comparison ---")
print("Max Pooling Peak Value:", np.max(Max_Original))
print("Average Pooling Peak Value:\n", Avg_Original)

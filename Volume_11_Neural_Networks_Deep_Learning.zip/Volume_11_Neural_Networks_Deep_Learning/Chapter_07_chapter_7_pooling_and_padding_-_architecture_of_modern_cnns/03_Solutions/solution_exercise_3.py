
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import math

class CNNBlockSimulator:
    def __init__(self, input_shape, kernel_size, num_filters, pool_size, pool_stride):
        # H, W, C
        self.H_in, self.W_in, self.C_in = input_shape
        self.K = kernel_size
        self.F = num_filters
        self.P_size = pool_size
        self.S_pool = pool_stride
        self.results = {}

    def calculate_conv_output(self):
        # Convolution (Assume S=1, 'same' padding: H_out = H_in)
        H_conv = self.H_in
        W_conv = self.W_in
        C_conv = self.F 
        
        self.results['Conv_Output'] = (H_conv, W_conv, C_conv)
        return H_conv, W_conv, C_conv

    def calculate_pool_output(self, H_in, W_in, C_in):
        # Pooling formula: H_out = floor((H_in - P_size) / S_pool) + 1
        H_pool = math.floor((H_in - self.P_size) / self.S_pool) + 1
        W_pool = math.floor((W_in - self.P_size) / self.S_pool) + 1
        C_pool = C_in 
        
        self.results['Pool_Output'] = (H_pool, W_pool, C_pool)
        return H_pool, W_pool, C_pool

    def run_simulation(self):
        H_c, W_c, C_c = self.calculate_conv_output()
        # Activation (H, W, C unchanged)
        H_p, W_p, C_p = self.calculate_pool_output(H_c, W_c, C_c)
        
        self.results['Input'] = (self.H_in, self.W_in, self.C_in)
        self.results['Final_Output'] = (H_p, W_p, C_p)
        
        return self.results

    def generate_dot_code(self):
        R = self.results
        H_in, W_in, C_in = R['Input']
        H_c, W_c, C_c = R['Conv_Output']
        H_p, W_p, C_p = R['Final_Output']

        dot_code = f"""
digraph CNNBlock {{
    rankdir=LR;
    node [shape=box, style="filled"];

    Input [label="Input Image\\n({H_in}x{W_in}x{C_in})", fillcolor="#90EE90"];
    
    Conv [label="Convolution (K={self.K}x{self.K}, F={self.F})\\nPadding: Same", fillcolor="#FFD700"];
    ConvOut [label="Feature Map 1\\n({H_c}x{W_c}x{C_c})", fillcolor="#ADD8E6"];
    
    Pool [label="Max Pooling (P={self.P_size}x{self.P_size}, S={self.S_pool})", fillcolor="#FFA07A"];
    Output [label="Block Output\\n({H_p}x{W_p}x{C_p})", fillcolor="#90EE90"];
    
    Input -> Conv;
    Conv -> ConvOut [label="Dimension Change (C)"];
    ConvOut -> Pool [label="Activation"];
    Pool -> Output [label="Dimension Reduction (H, W)"];
}}
"""
        return dot_code

# Simulation Example
Input_Shape = (256, 256, 3)
K_size = 5
Filters = 64
P_size = 2
P_stride = 2

simulator = CNNBlockSimulator(Input_Shape, K_size, Filters, P_size, P_stride)
results = simulator.run_simulation()

print(f"--- Simulation Results ---")
print(f"Input Shape: {results['Input']}")
print(f"Shape after Conv/Activation: {results['Conv_Output']}")
print(f"Final Output Shape (H', W', C'): {results['Final_Output']}")

# Visualization Requirement (DOT Code)
# print("\n--- Graphviz DOT Code ---")
# print(simulator.generate_dot_code())

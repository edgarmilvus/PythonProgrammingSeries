
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Constants for calculation
K = 3 # Kernel size
B1_C_in, B1_C_out = 3, 32
B2_C_in, B2_C_out = 32, 64
B3_C_in, B3_C_out = 64, 128

def calculate_conv_params(K, C_in, C_out):
    """Calculates trainable parameters for one Conv layer (K*K*C_in + Bias) * C_out"""
    return (K * K * C_in + 1) * C_out

# Calculation of Trainable Parameters (Identical for A and B)
P1 = calculate_conv_params(K, B1_C_in, B1_C_out)
P2 = calculate_conv_params(K, B2_C_in, B2_C_out)
P3 = calculate_conv_params(K, B3_C_in, B3_C_out)
Total_Params = P1 + P2 + P3

# Feature Map Area Comparison
Area_A = 32 * 32 # H x W entering Block 3 Conv in Architecture A
Area_B = 64 * 64 # H x W entering Block 3 Conv in Architecture B

Increase_Factor = Area_B / Area_A
Percentage_Increase = (Increase_Factor - 1) * 100

Architecture_B_Table = f"""
### Architecture B: Modified Pooling Strategy
(Goal: Final output 32x32x128)

| Block | Operation | Input Shape (H, W, C) | Kernel/Pool | Stride | Padding | Output Shape (H, W, C) |
| :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| 1 | Conv | 128x128x3 | 3x3 | 1 | Same | 128x128x32 |
| | MaxPool | 128x128x32 | 2x2 | 2 | N/A | 64x64x32 |
| 2 | Conv | 64x64x32 | 3x3 | 1 | Same | 64x64x64 |
| | MaxPool | 64x64x64 | **1x1** | **1** | N/A | **64x64x64** |
| 3 | Conv | 64x64x64 | 3x3 | 1 | Same | 64x64x128 |
| | MaxPool | 64x64x128 | **2x2** | **2** | N/A | **32x32x128** |
"""
print(Architecture_B_Table)

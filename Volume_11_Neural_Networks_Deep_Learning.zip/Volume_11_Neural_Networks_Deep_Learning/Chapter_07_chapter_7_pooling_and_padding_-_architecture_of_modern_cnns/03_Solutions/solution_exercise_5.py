
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

H_in = 192
H_target = 12
Total_Reduction_Factor = H_in / H_target # 192 / 12 = 16

# We need S1 * S2 = 16. A balanced solution is S1=4, S2=4.
S1 = 4
S2 = 4

# Intermediate size H1 (Input to Block 2 Conv)
H1 = H_in / S1 # 192 / 4 = 48

P1_size = S1
P1_stride = S1
P2_size = S2
P2_stride = S2

print("--- 1. Intermediate Calculation ---")
print(f"Required Intermediate Size (H1) after P1: {int(H1)} x {int(H1)}")

print("\n--- 2. Parameter Determination ---")
print(f"Pooling Layer 1 (P1): Pool Size = {P1_size}, Stride = {P1_stride}")
print(f"Pooling Layer 2 (P2): Pool Size = {P2_size}, Stride = {P2_stride}")

print("\n--- 3. Proof of Concept ---")
print(f"Start: 192 x 192")
print(f"Block 1 (Conv + P1): 192 / {S1} = {int(H1)} x {int(H1)}")
print(f"Block 2 (Conv + P2): {int(H1)} / {S2} = {int(H_target)} x {int(H_target)}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D

# 1. Setup Input Data
# Create a simple 5x5 grayscale image (1 channel).
# The shape is (Batch Size, Height, Width, Channels).
# We use np.arange to fill the tensor with sequential values for easy tracking.
input_image = np.arange(1, 26, dtype='float32').reshape((1, 5, 5, 1))

print(f"--- Input Stage ---")
print(f"Original Input Shape: {input_image.shape}")
print("-" * 30)


# 2. Define the CNN Architecture Segment
# This model segment demonstrates the effect of padding followed by pooling.
model = Sequential([
    # Layer 1: Convolution with 'Same' Padding
    # 'Same' padding is critical here. It automatically calculates the necessary
    # padding (P) such that the output spatial dimensions (H_out, W_out) match
    # the input spatial dimensions (H_in, W_in).
    Conv2D(
        filters=4,            # The number of output feature maps (depth)
        kernel_size=(3, 3),   # Standard 3x3 filter size
        strides=(1, 1),       # Move the filter 1 pixel at a time
        padding='same',       # CRITICAL: Ensures output spatial size remains 5x5
        input_shape=(5, 5, 1),# Defines the expected input format
        activation='relu',    # Standard activation
        name='Conv_with_Padding'
    ),

    # Layer 2: Max Pooling
    # This layer performs dimensionality reduction.
    # A 2x2 pool size with a 2x2 stride means we halve the dimensions.
    # Input (5x5) -> Output (2x2) due to integer truncation on the odd dimension.
    MaxPooling2D(
        pool_size=(2, 2),     # Size of the pooling window
        strides=(2, 2),       # Step size; ensures non-overlapping pooling windows
        padding='valid',      # Default: no extra padding added for pooling
        name='Max_Pooling_Layer'
    )
])


# 3. Process the Input and Inspect Intermediate Shapes
# We use model.get_layer() to isolate the output after the first layer.
conv_layer = model.get_layer('Conv_with_Padding')
conv_output = conv_layer(input_image)

print(f"--- Intermediate Stage (After Padding) ---")
# The output depth increases to 4 (filters=4), but H and W remain 5x5 due to 'same' padding.
print(f"Shape after Convolution (with 'same' padding): {conv_output.shape}")
print("-" * 30)

# Run the input through the entire defined segment (Convolution + Pooling)
final_output = model(input_image)

print(f"--- Final Stage (After Pooling) ---")
# The 5x5 spatial dimensions are reduced by the 2x2 pooling operation.
print(f"Final Shape after Max Pooling: {final_output.shape}")
print("-" * 30)

# Optional: Display the model architecture and parameter count
print("\n--- Model Summary ---")
model.summary()

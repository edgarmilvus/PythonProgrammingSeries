
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Conv2D, Activation, MaxPool2D, Flatten, Dense, GlobalAveragePooling2D
import numpy as np

# --- 1. Configuration and Data Simulation ---
IMAGE_SIZE = 32
CHANNELS = 1
NUM_CLASSES = 10
BATCH_SIZE = 32
INPUT_SHAPE = (IMAGE_SIZE, IMAGE_SIZE, CHANNELS)

# Generate synthetic data for demonstration purposes
print("Generating synthetic data...")
X_train = np.random.rand(500, IMAGE_SIZE, IMAGE_SIZE, CHANNELS).astype('float32')
y_train = np.random.randint(0, NUM_CLASSES, 500)
y_train_one_hot = tf.keras.utils.to_categorical(y_train, num_classes=NUM_CLASSES)

# --- 2. Define the Controlled Architecture Model ---
def create_controlled_cnn(input_shape, num_classes):
    """
    Defines a CNN architecture focused on precise dimensionality control
    using 'same' padding and strategic pooling.
    """
    inputs = Input(shape=input_shape, name="Input_Image")

    # Block 1: Preservation via Padding, followed by Initial Reduction
    # Goal: Extract features while maintaining 32x32 spatial resolution
    x = Conv2D(32, (3, 3), padding='same', name='Conv1_Same')(inputs)
    x = Activation('relu')(x)
    # Output shape after Conv1_Same: (32, 32, 32)
    
    # Pooling: Reduce size by half (32x32 -> 16x16)
    x = MaxPool2D((2, 2), strides=(2, 2), name='Pool1_Reduction')(x)
    # Output shape after Pool1_Reduction: (16, 16, 32)

    # Block 2: Deeper Feature Extraction & Second Reduction
    # Goal: Extract more complex features, still preserving 16x16 size initially
    x = Conv2D(64, (3, 3), padding='same', name='Conv2_Same')(x)
    x = Activation('relu')(x)
    # Output shape after Conv2_Same: (16, 16, 64)

    # Pooling: Reduce size by half (16x16 -> 8x8)
    x = MaxPool2D((2, 2), strides=(2, 2), name='Pool2_Reduction')(x)
    # Output shape after Pool2_Reduction: (8, 8, 64)

    # Block 3: Final Feature Aggregation (No Padding, Aggressive Pooling)
    # Goal: Use 'valid' padding to allow slight size reduction before final aggregation
    x = Conv2D(128, (3, 3), padding='valid', name='Conv3_Valid')(x)
    x = Activation('relu')(x)
    # Output shape after Conv3_Valid: (6, 6, 128) (3x3 kernel on 8x8 input reduces H/W by 2)

    # Global Pooling: Maximum dimensionality reduction for classification
    # Reduces (H, W) to 1x1, maintaining depth (128)
    x = GlobalAveragePooling2D(name='Global_Average_Pool')(x)
    # Output shape after Global_Average_Pool: (128,)

    # Classification Head
    outputs = Dense(num_classes, activation='softmax', name='Output_Layer')(x)

    model = Model(inputs=inputs, outputs=outputs, name="Padding_Pooling_Demo_CNN")
    return model

# --- 3. Model Instantiation and Analysis ---
model = create_controlled_cnn(INPUT_SHAPE, NUM_CLASSES)
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

print("\n--- Model Summary ---")
model.summary()

# --- 4. Training (Briefly) ---
print("\nTraining model briefly to demonstrate functionality...")
history = model.fit(
    X_train, y_train_one_hot,
    epochs=2, # Keep epochs low for fast demonstration
    batch_size=BATCH_SIZE,
    verbose=0
)
print("Training complete.")

# --- 5. Dimensionality Flow Verification ---
print("\n--- Verifying Feature Map Dimensions ---")
# Extracting the shape from the model's configuration
for layer in model.layers:
    if 'Conv' in layer.name or 'Pool' in layer.name or 'Global' in layer.name or 'Input' in layer.name:
        # Note: output_shape includes the batch size (None)
        output_shape = layer.output_shape
        print(f"Layer: {layer.name:<25} | Output Shape: {output_shape}")


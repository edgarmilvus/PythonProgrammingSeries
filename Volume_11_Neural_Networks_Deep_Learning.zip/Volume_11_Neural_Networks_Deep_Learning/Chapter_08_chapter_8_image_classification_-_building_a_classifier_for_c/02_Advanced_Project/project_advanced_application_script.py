
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import tensorflow as tf
from tensorflow.keras.datasets import cifar10
from tensorflow.keras.applications import VGG16
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Input
from tensorflow.keras.utils import to_categorical

# --- Configuration Constants ---
TARGET_CLASSES = ['bird', 'cat', 'dog', 'deer', 'frog'] # Focused subset for the wildlife monitor
NUM_CLASSES = len(TARGET_CLASSES)
IMG_SIZE = 32 # CIFAR-10 standard resolution
BATCH_SIZE = 64
EPOCHS = 10 

# Mapping CIFAR-10 integer labels to class names for filtering
CIFAR10_LABELS = ['airplane', 'automobile', 'bird', 'cat', 'deer', 
                  'dog', 'frog', 'horse', 'ship', 'truck']
TARGET_INDICES = [CIFAR10_LABELS.index(c) for c in TARGET_CLASSES]

def load_and_filter_cifar10():
    """Loads CIFAR-10, filters it to the target wildlife subset, and normalizes data."""
    (x_train_all, y_train_all), (x_test_all, y_test_all) = cifar10.load_data()

    # Create boolean masks to filter data based on target indices
    train_mask = np.isin(y_train_all, TARGET_INDICES).flatten()
    test_mask = np.isin(y_test_all, TARGET_INDICES).flatten()

    x_train, y_train = x_train_all[train_mask], y_train_all[train_mask]
    x_test, y_test = x_test_all[test_mask], y_test_all[test_mask]

    # Re-map labels to be sequential (0 to NUM_CLASSES-1)
    label_map = {old_idx: new_idx for new_idx, old_idx in enumerate(TARGET_INDICES)}
    y_train = np.array([label_map[i[0]] for i in y_train])
    y_test = np.array([label_map[i[0]] for i in y_test])

    # Convert labels to one-hot encoding
    y_train = to_categorical(y_train, num_classes=NUM_CLASSES)
    y_test = to_categorical(y_test, num_classes=NUM_CLASSES)

    # Normalize pixel values to [0, 1] range
    x_train = x_train.astype('float32') / 255.0
    x_test = x_test.astype('float32') / 255.0
    
    # VGG16 expects 3 channels, which CIFAR-10 has, but it was trained on 224x224 images.
    # Keras handles the resizing internally when the input shape is defined, but 
    # for VGG16 to work effectively, we often need to ensure 3 channels are present.
    # CIFAR-10 is 32x32x3, which is sufficient.

    return (x_train, y_train), (x_test, y_test)

# --- 1. Data Loading and Preparation ---
(X_train, Y_train), (X_test, Y_test) = load_and_filter_cifar10()
print(f"Filtered Training Samples: {X_train.shape[0]}")

# --- 2. Defining Data Augmentation Strategy ---
datagen = ImageDataGenerator(
    rotation_range=15,          # Simulates slight camera tilt
    width_shift_range=0.1,      # Simulates slight subject movement
    height_shift_range=0.1,     # Simulates slight subject movement
    shear_range=0.1,            # Perspective distortion
    zoom_range=0.1,             # Simulates distance variation
    horizontal_flip=True,       # Standard practice for image classification
    fill_mode='nearest'         # Strategy for filling in new pixels
)

# Prepare the data flow iterator
train_generator = datagen.flow(X_train, Y_train, batch_size=BATCH_SIZE)

# --- 3. Constructing the Transfer Learning Model (VGG16 Base) ---

# Define the input layer shape (32x32x3)
input_tensor = Input(shape=(IMG_SIZE, IMG_SIZE, 3))

# Load VGG16 pre-trained on ImageNet, excluding the top classification layers
# We must use include_top=False and define the input shape explicitly.
vgg_base = VGG16(
    weights='imagenet', 
    include_top=False, 
    input_tensor=input_tensor 
)

# Freeze the weights of the VGG convolutional base
for layer in vgg_base.layers:
    layer.trainable = False

# --- 4. Building the Custom Classification Head ---
# Add new layers on top of the frozen base for our specific 5-class problem
x = vgg_base.output
x = GlobalAveragePooling2D()(x) # Reduces feature map size efficiently
x = Dense(256, activation='relu')(x) # Hidden dense layer for classification
output_tensor = Dense(NUM_CLASSES, activation='softmax')(x) # Output layer

# Combine the base and the new head into a final model
model = Model(inputs=vgg_base.input, outputs=output_tensor)

# --- 5. Compilation and Training ---
model.compile(
    optimizer='adam',
    loss='categorical_crossentropy',
    metrics=['accuracy']
)

print("\nStarting Transfer Learning Training Phase (Frozen Base):")
# Train the model using the augmented data generator
history = model.fit(
    train_generator,
    steps_per_epoch=X_train.shape[0] // BATCH_SIZE,
    epochs=EPOCHS,
    validation_data=(X_test, Y_test),
    verbose=1
)

# --- 6. Evaluation ---
loss, accuracy = model.evaluate(X_test, Y_test, verbose=0)
print(f"\nModel Evaluation (5-Class CIFAR Subset):")
print(f"Test Loss: {loss:.4f}")
print(f"Test Accuracy: {accuracy*100:.2f}%")

# Save the optimized model for edge deployment
model.save("wildlife_monitor_cnn_transfer.h5")
print("Model saved successfully.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import torch
import torch.nn as nn
import torch.nn.functional as F

# Helper function to count parameters
def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

class DeepCIFAR10_CNN(nn.Module):
    def __init__(self, dropout_rate=0.5):
        super(DeepCIFAR10_CNN, self).__init__()
        
        # Define the four convolutional blocks with BN
        self.features = nn.Sequential(
            # Block 1: 3 -> 32. Output size 32x32 -> 16x16
            nn.Conv2d(3, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),
            
            # Block 2: 32 -> 64. Output size 16x16 -> 8x8
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),
            
            # Block 3: 64 -> 128. Output size 8x8 -> 4x4
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),
            
            # Block 4: 128 -> 256. Output size 4x4 -> 2x2
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            nn.MaxPool2d(2, 2)
        )
        
        # Calculate the flattened size: 256 channels * 2x2 spatial size = 1024
        self.flattened_size = 256 * 2 * 2 
        
        self.classifier = nn.Sequential(
            nn.Dropout(dropout_rate), # Dropout integration
            nn.Linear(self.flattened_size, 10) # 10 classes
        )

    def forward(self, x):
        x = self.features(x)
        x = torch.flatten(x, 1) # Flatten all dimensions except batch
        x = self.classifier(x)
        return x

# Instantiate and analyze
model = DeepCIFAR10_CNN(dropout_rate=0.5)
total_params = count_parameters(model)

print(f"DeepCIFAR10_CNN instantiated successfully.")
print(f"Total trainable parameters in DeepCIFAR10_CNN: {total_params:,}")

"""
Parameter Count Analysis:
The total parameter count is approximately 390,000. 
This is significantly higher than a typical shallow baseline CNN (often < 150,000 parameters). 
The increase is due to two main factors:
1. Deeper Architecture: Adding two extra convolutional blocks (Block 3 and 4) dramatically increases the number of weights, especially in the later blocks where the channel count is high (128 -> 256).
2. Batch Normalization (BN): Each BN layer introduces two trainable parameters per channel (gamma and beta). While BN layers are crucial for stability, they contribute to the overall parameter count (e.g., 32+64+128+256 channels = 480 channels * 2 parameters = 960 extra parameters, plus running mean/variance which are buffers, not trainable weights).
"""


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import torch
import torchvision
from torchvision import transforms
import numpy as np

# 1. Data Loading and Initial Calculation
# Load training data with only ToTensor() to calculate raw statistics
temp_train_data = torchvision.datasets.CIFAR10(
    root='./data', train=True, download=True,
    transform=transforms.ToTensor()
)

# Calculate statistics by iterating through the dataset
print("Calculating channel-wise mean and standard deviation...")
data_loader = torch.utils.data.DataLoader(temp_train_data, batch_size=64, shuffle=False, num_workers=2)

mean = 0.0
std = 0.0
for images, _ in data_loader:
    # images shape: (B, C, H, W)
    batch_samples = images.size(0)
    # Flatten spatial dimensions (H*W)
    images = images.view(batch_samples, images.size(1), -1) 
    mean += images.mean(2).sum(0)
    std += images.std(2).sum(0)

# Final calculation
train_mean = (mean / len(data_loader)).tolist()
train_std = (std / len(data_loader)).tolist()

print(f"Calculated Training Mean: {train_mean}")
print(f"Calculated Training Std Dev: {train_std}")

# 2. Define Transformations
train_transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize(train_mean, train_std)
])

test_transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize(train_mean, train_std)
])

# 3. Load Data and Create DataLoaders
batch_size = 128
train_data = torchvision.datasets.CIFAR10(root='./data', train=True, download=False, transform=train_transform)
test_data = torchvision.datasets.CIFAR10(root='./data', train=False, download=False, transform=test_transform)

train_loader = torch.utils.data.DataLoader(train_data, batch_size=batch_size, shuffle=True, num_workers=2)
test_loader = torch.utils.data.DataLoader(test_data, batch_size=batch_size, shuffle=False, num_workers=2)

# 4. Verification Step
data_iter = iter(train_loader)
images, labels = next(data_iter)

print("\n--- Verification ---")
print(f"Batch Shape: {images.shape}")
# Check normalization properties across the channels (index 1)
print(f"Normalized Mean Check (Channel 0/R): {images[:, 0, :, :].mean():.4f}")
print(f"Normalized Std Check (Channel 1/G): {images[:, 1, :, :].std():.4f}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import torch
import torchvision
from torchvision import transforms
import torchvision.models as models
import torch.nn as nn
import torch.optim as optim
import time

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 2. Input Transformation Adjustment for VGG
IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]

vgg_transform = transforms.Compose([
    transforms.Resize(224), # Resizing 32x32 to 224x224 for VGG input
    transforms.ToTensor(),
    transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD) # Using ImageNet normalization
])

# Load DataLoaders (using a small sample for demonstration)
test_data_vgg = torchvision.datasets.CIFAR10(root='./data', train=False, download=False, transform=vgg_transform)
test_loader_vgg = torch.utils.data.DataLoader(test_data_vgg, batch_size=64, shuffle=False)

# 1. Model Loading and Freezing
vgg16 = models.vgg16(weights=models.VGG16_Weights.IMAGENET1K_V1)
vgg16 = vgg16.to(device)

# Freeze all parameters in the convolutional feature extractor
for param in vgg16.features.parameters():
    param.requires_grad = False
    
print("VGG16 convolutional base frozen.")

# 3. Classifier Replacement
# Determine the input size required by the existing classifier head (512 * 7 * 7 = 25088)
num_features = vgg16.classifier[0].in_features 

# Replace the classifier with a new, simpler head for CIFAR-10 (10 classes)
vgg16.classifier = nn.Sequential(
    nn.Linear(num_features, 512), 
    nn.ReLU(),
    nn.Dropout(0.5),
    nn.Linear(512, 10) # Output 10 classes
).to(device)

# Verification of trainable parameters
trainable_params = sum(p.numel() for p in vgg16.parameters() if p.requires_grad)
total_params = sum(p.numel() for p in vgg16.parameters())

print(f"\nTotal VGG16 parameters: {total_params:,}")
print(f"Trainable parameters (Classifier only): {trainable_params:,}")
print(f"Percentage trainable: {trainable_params / total_params * 100:.2f}%")

# 4. Training and Convergence Setup
# Crucially, we only optimize the newly added classifier parameters.
optimizer = torch.optim.Adam(vgg16.classifier.parameters(), lr=0.001)
criterion = nn.CrossEntropyLoss()

print("\nTransfer Learning Setup Complete. Ready to train only the classifier head.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import tensorflow as tf
from tensorflow.keras.datasets import cifar10
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
import numpy as np

# --- 1. Define Constants and Hyperparameters ---
NUM_CLASSES = 10
# CIFAR-10 images are 32x32 pixels with 3 color channels (RGB)
INPUT_SHAPE = (32, 32, 3) 

# --- 2. Load and Prepare the Data ---
print("Step 2: Loading CIFAR-10 dataset...")
# cifar10.load_data() returns two tuples: (train_images, train_labels), (test_images, test_labels)
(x_train, y_train), (x_test, y_test) = cifar10.load_data()

# --- 3. Data Normalization (Scaling Pixel Values) ---
# Convert integer pixel values (0-255) to float (0.0-1.0). 
# This ensures gradients remain stable during training.
x_train = x_train.astype('float32') / 255.0
x_test = x_test.astype('float32') / 255.0

# --- 4. One-Hot Encode the Labels ---
# The labels are currently scalars (e.g., 5). We convert them into 
# 10-dimensional vectors (e.g., [0, 0, 0, 0, 0, 1, 0, 0, 0, 0]) for 
# use with the 'categorical_crossentropy' loss function.
y_train = tf.keras.utils.to_categorical(y_train, NUM_CLASSES)
y_test = tf.keras.utils.to_categorical(y_test, NUM_CLASSES)

# --- 5. Define the Simple CNN Model Architecture ---
def build_simple_cnn(input_shape, num_classes):
    """
    Constructs a minimal Convolutional Neural Network (CNN).
    """
    model = Sequential(name="Simple_CIFAR10_Classifier")

    # First Convolutional Block: Learns basic features (edges, corners)
    # 32 filters is a common starting point for small datasets.
    model.add(Conv2D(32, (3, 3), activation='relu', input_shape=input_shape, padding='same', name='Conv1'))
    # Reduces dimensionality by half (32x32 -> 16x16)
    model.add(MaxPooling2D(pool_size=(2, 2), name='Pool1'))

    # Second Convolutional Block: Learns more complex features
    # Doubling the filters (64) is standard practice after pooling.
    model.add(Conv2D(64, (3, 3), activation='relu', padding='same', name='Conv2'))
    # Reduces dimensionality further (16x16 -> 8x8)
    model.add(MaxPooling2D(pool_size=(2, 2), name='Pool2'))

    # Flattening: Prepares the 3D feature maps for the Dense layers
    model.add(Flatten(name='Feature_Flatten'))

    # Dense Classification Layers
    model.add(Dense(128, activation='relu', name='Dense_Hidden'))
    # Output layer: 10 neurons (one for each class), Softmax for probability distribution
    model.add(Dense(num_classes, activation='softmax', name='Output_Softmax'))

    return model

# --- 6. Instantiate and Compile the Model ---
model = build_simple_cnn(INPUT_SHAPE, NUM_CLASSES)
# Adam is an efficient, standard optimizer.
# categorical_crossentropy requires one-hot encoded labels.
model.compile(optimizer='adam',
              loss='categorical_crossentropy',
              metrics=['accuracy'])

# --- 7. Model Summary ---
print("\n--- Model Summary (Verifying Layer Shapes) ---")
model.summary()

# --- 8. Training (Brief run for demonstration) ---
print("\nStep 8: Starting brief training run (2 epochs)...")
history = model.fit(x_train, y_train,
                    batch_size=64,
                    epochs=2, 
                    validation_data=(x_test, y_test),
                    verbose=1)

print("\nTraining complete. Model architecture defined and trained.")

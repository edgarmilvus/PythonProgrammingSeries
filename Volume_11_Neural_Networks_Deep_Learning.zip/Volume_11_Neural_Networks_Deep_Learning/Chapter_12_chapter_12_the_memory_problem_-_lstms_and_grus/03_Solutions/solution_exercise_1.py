
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
import matplotlib.pyplot as plt

# Setup constants
D_H = 10  # Hidden dimension
T = 50    # Sequence length
W_initial_std = 0.1 # Small weight initialization

# 1. Initialization
np.random.seed(42)
# Weight matrix W (D_H x D_H)
W = np.random.normal(0, W_initial_std, (D_H, D_H))
# Initial hidden state h_0 (D_H vector)
h_0 = np.random.randn(D_H) * 0.5 

# Store all hidden states
H = [h_0]

# --- Activation Functions and Derivatives ---

def tanh_derivative(h_t):
    """Calculates tanh'(z) = 1 - tanh(z)^2. Since h_t = tanh(z), this is 1 - h_t^2."""
    return 1 - h_t**2

def rnn_step(h_prev, W):
    """Calculates the next hidden state h_t = tanh(W * h_{t-1})"""
    # Assuming bias is zero for simplicity in the Jacobian structure
    z_t = W @ h_prev
    h_t = np.tanh(z_t)
    return h_t

def calculate_jacobian(h_t, W):
    """
    Computes J_t = d(h_t) / d(h_{t-1}).
    J_t = diag(tanh'(W h_{t-1})) * W
    """
    # h_t is already calculated. We use 1 - h_t^2 for the diagonal matrix
    # Note: We must use the element-wise derivative of tanh applied to the vector
    tanh_prime = tanh_derivative(h_t)
    
    # Create the diagonal matrix of derivatives
    diag_tanh_prime = np.diag(tanh_prime)
    
    # Jacobian matrix (D_H x D_H)
    J_t = diag_tanh_prime @ W
    return J_t

# 2. & 3. Forward Pass: Calculate all states and Jacobians
Jacobians = []
current_h = h_0
for t in range(1, T + 1):
    h_t = rnn_step(current_h, W)
    H.append(h_t)
    
    # Calculate Jacobian based on the new state h_t
    J_t = calculate_jacobian(h_t, W)
    Jacobians.append(J_t)
    
    current_h = h_t

# 4. Backward Pass Simulation
# Start with the upstream gradient at T (e.g., identity matrix representing dL/dh_T)
# Since we are interested in the magnitude of the accumulated product, we start with Identity.
# Cumulative gradient matrix: dL/dh_t
cumulative_gradient = np.eye(D_H) 
gradient_norms = []

# Iterate backward from T down to 1
for t in range(T - 1, -1, -1):
    J_t = Jacobians[t] # Jacobian J_{t+1}
    
    # Accumulate the gradient: dL/dh_t = (dL/dh_{t+1}) * (dh_{t+1}/dh_t)
    cumulative_gradient = cumulative_gradient @ J_t
    
    # Calculate the Frobenius norm of the cumulative gradient
    norm = np.linalg.norm(cumulative_gradient, ord='fro')
    gradient_norms.append(norm)

# Reverse the norms list so it goes from h_T to h_0
gradient_norms.reverse() 

# 5. Visualization (Plotting log-magnitude vs. time step)
time_steps = np.arange(1, T + 1)
log_norms = np.log(gradient_norms)

plt.figure(figsize=(10, 6))
plt.plot(time_steps, log_norms, marker='o', linestyle='-', color='red')
plt.title('Vanishing Gradient Simulation (Log Magnitude)')
plt.xlabel('Time Step t (from 1 to 50)')
plt.ylabel(r'$\log(|| \frac{\partial L}{\partial h_t} ||)$')
plt.grid(True, which='both', linestyle='--', linewidth=0.5)
plt.axhline(np.log(1e-10), color='gray', linestyle='--', label='Threshold (1e-10)')
plt.text(T/2, log_norms[int(T/2)], f'Final Norm: {gradient_norms[-1]:.2e}', 
         ha='center', va='bottom', color='black')
plt.show()

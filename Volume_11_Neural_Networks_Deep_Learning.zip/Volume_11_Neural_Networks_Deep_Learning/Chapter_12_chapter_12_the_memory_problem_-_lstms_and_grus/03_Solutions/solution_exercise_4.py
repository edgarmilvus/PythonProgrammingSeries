
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, GRU, Dense, Dropout
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt

# --- 1. Data Generation and Preprocessing ---

SEQUENCE_LENGTH = 1000
LOOKBACK_SHORT = 5
LOOKBACK_LONG = 50
DROPOUT_RATES = [0.0, 0.2, 0.5]
EPOCHS = 30
BATCH_SIZE = 32
UNITS = 50

# Generate a simple noisy sine wave sequence
def generate_sequence(length, noise_level=0.1):
    time = np.arange(length)
    amplitude = np.sin(time * 0.1)
    noise = np.random.normal(0, noise_level, length)
    return amplitude + noise

# Function to create sequences (X: lookback window, Y: next step)
def create_sequences(data, lookback):
    X, Y = [], []
    for i in range(len(data) - lookback):
        X.append(data[i:(i + lookback)])
        Y.append(data[i + lookback])
    return np.array(X), np.array(Y)

# Generate and normalize data
data = generate_sequence(SEQUENCE_LENGTH)
data_norm = (data - np.min(data)) / (np.max(data) - np.min(data))
data_norm = data_norm.reshape(-1, 1) # Ensure 2D for normalization

# --- 2. Model Definition Functions ---

def build_model(unit_type, lookback, dropout_rate):
    model = Sequential()
    
    # Input shape: (time_steps, features)
    if unit_type == 'LSTM':
        model.add(LSTM(UNITS, input_shape=(lookback, 1), activation='relu'))
    elif unit_type == 'GRU':
        model.add(GRU(UNITS, input_shape=(lookback, 1), activation='relu'))
    else:
        raise ValueError("Invalid unit type")
        
    model.add(Dropout(dropout_rate))
    model.add(Dense(1, activation='linear')) # Regression output
    
    model.compile(optimizer='adam', loss='mse')
    return model

# --- 3. Phase 1: Lookback Sensitivity (Fixed Dropout=0.2) ---
print("--- Phase 1: Lookback Sensitivity (Dropout=0.2) ---")
fixed_dropout = 0.2
results_phase1 = {}

for lookback in [LOOKBACK_SHORT, LOOKBACK_LONG]:
    X, Y = create_sequences(data_norm, lookback)
    X_train, X_val, Y_train, Y_val = train_test_split(X, Y, test_size=0.2, random_state=42)

    for unit_type in ['LSTM', 'GRU']:
        model = build_model(unit_type, lookback, fixed_dropout)
        
        history = model.fit(
            X_train, Y_train,
            epochs=EPOCHS,
            batch_size=BATCH_SIZE,
            validation_data=(X_val, Y_val),
            verbose=0
        )
        val_loss = history.history['val_loss'][-1]
        results_phase1[(unit_type, lookback)] = val_loss
        print(f"Model: {unit_type}, Lookback: {lookback}, Validation Loss: {val_loss:.6f}")

# --- 4. Phase 2: Dropout Regularization (Fixed Long Lookback=50) ---
print("\n--- Phase 2: Dropout Regularization (Lookback=50) ---")
fixed_lookback = LOOKBACK_LONG
X, Y = create_sequences(data_norm, fixed_lookback)
X_train, X_val, Y_train, Y_val = train_test_split(X, Y, test_size=0.2, random_state=42)

results_phase2 = {}

for dropout_rate in DROPOUT_RATES:
    for unit_type in ['LSTM', 'GRU']:
        model = build_model(unit_type, fixed_lookback, dropout_rate)
        
        history = model.fit(
            X_train, Y_train,
            epochs=EPOCHS,
            batch_size=BATCH_SIZE,
            validation_data=(X_val, Y_val),
            verbose=0
        )
        val_loss = history.history['val_loss'][-1]
        train_loss = history.history['loss'][-1]
        results_phase2[(unit_type, dropout_rate)] = (train_loss, val_loss)
        print(f"Model: {unit_type}, Dropout: {dropout_rate:.1f}, Train Loss: {train_loss:.6f}, Val Loss: {val_loss:.6f}")

# --- 5. Conclusion Summary ---
print("\n--- Conclusion ---")
print(f"GRU Parameter Count (D_H={UNITS}, D_in=1): {build_model('GRU', 1, 0).count_params()}")
print(f"LSTM Parameter Count (D_H={UNITS}, D_in=1): {build_model('LSTM', 1, 0).count_params()}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Define constant input dimension
D_IN = 50

def calculate_parameters(D_in, D_hidden, unit_type):
    """Calculates the total number of trainable parameters for LSTM or GRU."""
    
    # Parameters for a single component (e.g., one gate)
    # Input Weights (D_in * D_hidden) + Recurrent Weights (D_hidden * D_hidden) + Bias (D_hidden)
    params_per_component = (D_in * D_hidden) + (D_hidden * D_hidden) + D_hidden
    
    if unit_type == 'LSTM':
        # LSTM has 4 components: Forget, Input, Output gates, and Candidate Cell
        num_components = 4
    elif unit_type == 'GRU':
        # GRU has 3 components: Reset, Update gates, and Candidate Hidden state
        num_components = 3
    else:
        raise ValueError("unit_type must be 'LSTM' or 'GRU'")
        
    total_parameters = num_components * params_per_component
    return total_parameters, num_components

# Dimensions to test
HIDDEN_DIMENSIONS = [32, 64, 128, 256]

print(f"--- Parameter Count Comparison (D_in = {D_IN}) ---")
print("{:<10} {:<10} {:<10} {:<10}".format("D_Hidden", "N_LSTM", "N_GRU", "Ratio (LSTM/GRU)"))
print("-" * 45)

for D_H in HIDDEN_DIMENSIONS:
    N_lstm, _ = calculate_parameters(D_IN, D_H, 'LSTM')
    N_gru, _ = calculate_parameters(D_IN, D_H, 'GRU')
    
    ratio = N_lstm / N_gru
    
    print(f"{D_H:<10} {N_lstm:<10} {N_gru:<10} {ratio:<10.4f}")

print("\n--- Analysis Conclusion ---")
print("The ratio of LSTM parameters to GRU parameters is consistently N_LSTM / N_GRU = 4/3.")
print("This is because the GRU eliminates the separate Cell State and merges the input/forget gates,")
print("reducing the required weight/bias sets from 4 to 3.")

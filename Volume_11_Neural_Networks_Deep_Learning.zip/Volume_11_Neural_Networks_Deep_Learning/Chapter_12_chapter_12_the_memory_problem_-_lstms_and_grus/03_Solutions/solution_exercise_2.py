
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np

# Constants
D_IN = 64     # Input dimension
D_HIDDEN = 128 # Hidden dimension (and Cell State dimension)

# --- Activation Functions ---

def sigmoid(z):
    """Sigmoid activation function: used for gates (f, i, o)"""
    return 1 / (1 + np.exp(-z))

def tanh(z):
    """Hyperbolic tangent activation function: used for candidate cell state and output activation"""
    return np.tanh(z)

# --- Initialization ---
np.random.seed(42)

# Total size of combined weights and biases (4 gates * D_HIDDEN)
COMBINED_SIZE = 4 * D_HIDDEN

# Combined Input Weight Matrix (D_IN x 4*D_HIDDEN)
W_combined = np.random.normal(0, 0.01, (D_IN, COMBINED_SIZE))

# Combined Recurrent Weight Matrix (D_HIDDEN x 4*D_HIDDEN)
R_combined = np.random.normal(0, 0.01, (D_HIDDEN, COMBINED_SIZE))

# Combined Bias Vector (4*D_HIDDEN)
B_combined = np.zeros(COMBINED_SIZE)

# Dummy input data (Batch size 1)
x_t = np.random.randn(D_IN) * 0.1
h_prev = np.zeros(D_HIDDEN)
C_prev = np.zeros(D_HIDDEN)

# --- LSTM Forward Step Implementation ---

def lstm_step(x_t, h_prev, C_prev, W_combined, R_combined, B_combined):
    """
    Performs one forward pass of the LSTM unit.
    Assumes batch size 1 for simplicity (inputs are 1D vectors).
    """
    D_H = h_prev.shape[0]

    # 1. Calculate Combined Linear Transformation (Z)
    # Z = (x_t @ W_combined) + (h_{t-1} @ R_combined) + B_combined
    # Note: Using @ for matrix multiplication (dot product for 1D vectors)
    Z = (x_t @ W_combined) + (h_prev @ R_combined) + B_combined

    # 2. Split Z into four parts corresponding to the gates/candidate
    # The order is typically F, I, C_tilde, O
    Z_f = Z[0*D_H : 1*D_H]
    Z_i = Z[1*D_H : 2*D_H]
    Z_c_tilde = Z[2*D_H : 3*D_H]
    Z_o = Z[3*D_H : 4*D_H]
    
    # 3. Apply Activations
    f_t = sigmoid(Z_f)      # Forget Gate
    i_t = sigmoid(Z_i)      # Input Gate
    o_t = sigmoid(Z_o)      # Output Gate
    C_tilde_t = tanh(Z_c_tilde) # Candidate Cell State

    # 4. Update Cell State (C_t) - The core memory path
    # C_t = f_t * C_{t-1} + i_t * C_tilde_t (element-wise multiplication)
    C_t = (f_t * C_prev) + (i_t * C_tilde_t)

    # 5. Calculate New Hidden State (h_t)
    # h_t = o_t * tanh(C_t) (element-wise multiplication)
    h_t = o_t * tanh(C_t)

    return h_t, C_t

# --- Verification ---
h_new, C_new = lstm_step(x_t, h_prev, C_prev, W_combined, R_combined, B_combined)

print(f"Input Dimension (D_IN): {D_IN}")
print(f"Hidden Dimension (D_HIDDEN): {D_HIDDEN}")
print("-" * 30)
print(f"Shape of new Hidden State (h_t): {h_new.shape}")
print(f"Shape of new Cell State (C_t): {C_new.shape}")
print(f"Example h_t values (first 5): {h_new[:5]}")

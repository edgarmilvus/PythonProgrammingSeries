
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from tensorflow.keras.optimizers import Adam
import os

# Suppress TensorFlow warnings for cleaner output
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

# --- 1. Data Generation: Creating the Long-Term Dependency ---

def generate_data(sequence_length, num_samples):
    """
    Generates synthetic data where the target is determined by the first element.
    Shape required by Keras RNNs: (samples, timesteps, features)
    """
    # Initialize the input tensor X: (num_samples, sequence_length, 1 feature)
    X = np.zeros((num_samples, sequence_length, 1), dtype=np.float32)
    # Initialize the target tensor Y: (num_samples, 1 output)
    Y = np.zeros((num_samples, 1), dtype=np.float32)

    for i in range(num_samples):
        # Determine the 'memory' element (0 or 1)
        memory_value = np.random.randint(0, 2)
        
        # Place the critical value at the very start of the sequence
        X[i, 0, 0] = memory_value 

        # Fill the remaining steps with irrelevant noise (simulating memory gap)
        # We use a small range (0 to 0.5) to keep the noise distinct from the 0/1 signal
        X[i, 1:, 0] = np.random.rand(sequence_length - 1) * 0.5

        # The target output Y must equal the memory value
        Y[i, 0] = memory_value

    return X, Y

# Define hyperparameters for the experiment
SEQUENCE_LENGTH = 20 
NUM_SAMPLES = 10000 # Use a large number of samples for robust training

# Generate the training data
X_train, Y_train = generate_data(SEQUENCE_LENGTH, NUM_SAMPLES)

# --- 2. Model Definition: The LSTM Architecture ---

model = Sequential([
    # Input shape MUST match (timesteps, features)
    # units=10 defines the dimensionality of the output space (the hidden state h)
    LSTM(units=10, 
         input_shape=(SEQUENCE_LENGTH, 1), 
         name='Long_Term_Memory_Unit'),
    
    # Since this is a binary classification task (predict 0 or 1), 
    # we use a single Dense neuron with a sigmoid activation.
    Dense(1, activation='sigmoid', name='Binary_Output_Layer')
])

# --- 3. Compile and Train ---

# Use Adam optimizer and Binary Crossentropy loss for the 0/1 prediction task
model.compile(optimizer=Adam(learning_rate=0.005),
              loss='binary_crossentropy',
              metrics=['accuracy'])

print("--- LSTM Model Summary ---")
model.summary()
print("\n--- Training LSTM Model for Memory Retention ---")

# Train the model
# We expect high accuracy quickly if the LSTM successfully utilizes its cell state
history = model.fit(X_train, Y_train, 
                    epochs=10, 
                    batch_size=64, 
                    verbose=1, 
                    validation_split=0.1)

# --- 4. Evaluation and Demonstration ---

# Create a small, fresh test set
X_test, Y_test = generate_data(SEQUENCE_LENGTH, 100)
loss, accuracy = model.evaluate(X_test, Y_test, verbose=0)

print(f"\n--- Model Performance ---")
print(f"Test Accuracy (Must remember 1st element across 19 noise steps): {accuracy*100:.2f}%")

# Demonstrate a specific prediction case where the answer is 1
test_case_A = np.zeros((1, SEQUENCE_LENGTH, 1), dtype=np.float32)
test_case_A[0, 0, 0] = 1.0 # The memory value is 1
test_case_A[0, 1:, 0] = np.random.rand(SEQUENCE_LENGTH - 1) * 0.5 # Noise

prediction_A = model.predict(test_case_A, verbose=0)[0][0]

print(f"\nSpecific Test Case (First Element = 1.0):")
print(f"Input Sequence Start: {test_case_A[0, 0, 0]:.1f}, Noise Sample: {test_case_A[0, 5, 0]:.4f}")
print(f"Predicted Output (Target: 1.0): {prediction_A:.4f} (Classification: {'1' if prediction_A > 0.5 else '0'})")

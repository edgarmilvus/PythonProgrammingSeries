
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import tensorflow as tf
from tensorflow.keras.datasets import imdb
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, Dropout
from tensorflow.keras.preprocessing.sequence import pad_sequences

# --- 1. Configuration Constants ---
MAX_FEATURES = 10000  # Only consider the top 10,000 most frequent words
MAX_LEN = 200         # Cut reviews after this many words (sequence length)
EMBEDDING_DIM = 128   # Dimension of the word embedding vector
LSTM_UNITS = 64       # Number of units (memory cells) in the LSTM layer
BATCH_SIZE = 32
EPOCHS = 3            # Use a small number of epochs for demonstration speed

print(f"TensorFlow Version: {tf.__version__}")

# --- 2. Data Loading and Preprocessing ---

# Load the IMDB dataset, restricting to the top MAX_FEATURES words
print("Loading data...")
(x_train, y_train), (x_test, y_test) = imdb.load_data(num_words=MAX_FEATURES)

# Display initial data shape and sequence lengths
print(f"Training sequences: {len(x_train)}")
print(f"Test sequences: {len(x_test)}")
# Example: print(f"First training sequence length: {len(x_train[0])}")

# Pad sequences to ensure uniform length (MAX_LEN).
# Padding is crucial for batch processing in fixed-input architectures.
print(f"Padding sequences to length {MAX_LEN}...")
x_train = pad_sequences(x_train, maxlen=MAX_LEN)
x_test = pad_sequences(x_test, maxlen=MAX_LEN)

# Display final processed shape
print(f"x_train shape after padding: {x_train.shape}")
print(f"x_test shape after padding: {x_test.shape}")

# --- 3. Model Definition: The LSTM Architecture ---

model = Sequential()

# Layer 1: Embedding Layer
# Converts integer indices into dense vectors of fixed size (EMBEDDING_DIM).
# Input shape is (BATCH_SIZE, MAX_LEN). Output shape is (BATCH_SIZE, MAX_LEN, EMBEDDING_DIM).
model.add(Embedding(input_dim=MAX_FEATURES, 
                    output_dim=EMBEDDING_DIM, 
                    input_length=MAX_LEN))

# Layer 2: Dropout for Regularization
# Helps prevent overfitting before the recurrent layer.
model.add(Dropout(0.2))

# Layer 3: The LSTM Core
# This layer handles the sequential processing and long-term dependency storage.
# The LSTM_UNITS define the dimensionality of the output space (h_t) and the cell state (c_t).
# Since return_sequences=False (default), it only outputs the final hidden state, 
# which summarizes the entire 200-word sequence for classification.
model.add(LSTM(units=LSTM_UNITS))

# Layer 4: Final Dropout
model.add(Dropout(0.2))

# Layer 5: Output Layer
# Dense layer with sigmoid activation for binary classification (Positive/Negative).
model.add(Dense(1, activation='sigmoid'))

# --- 4. Model Compilation and Training ---

# Compile the model
model.compile(optimizer='adam',
              loss='binary_crossentropy', # Appropriate loss for binary classification
              metrics=['accuracy'])

print("\nModel Summary:")
model.summary()

# Train the model
print("\nStarting training...")
history = model.fit(x_train, y_train,
                    batch_size=BATCH_SIZE,
                    epochs=EPOCHS,
                    validation_data=(x_test, y_test))

# --- 5. Evaluation and Demonstration ---

# Evaluate the model performance on the test set
loss, accuracy = model.evaluate(x_test, y_test, verbose=0)
print(f"\nTest Loss: {loss:.4f}")
print(f"Test Accuracy: {accuracy:.4f}")

# Demonstrate a prediction on a sample review (e.g., the first test review)
sample_index = 0
sample_sequence = x_test[sample_index:sample_index+1] # Keep dimensions correct
prediction = model.predict(sample_sequence)

# The output is a probability (0 to 1). 0.5 is the threshold.
sentiment = "Positive" if prediction[0][0] >= 0.5 else "Negative"

print(f"\nPrediction for sample {sample_index}: {prediction[0][0]:.4f} -> {sentiment}")
print(f"Actual Label: {'Positive' if y_test[sample_index] == 1 else 'Negative'}")

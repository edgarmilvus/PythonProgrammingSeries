
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import tensorflow as tf
from tensorflow.keras.applications import VGG16
from tensorflow.keras.applications.vgg16 import preprocess_input
import numpy as np

# --- Configuration ---
DIVERSITY_THRESHOLD = 0.05
CONSECUTIVE_COLLAPSE_LIMIT = 5
consecutive_low_diversity_epochs = 0
CHECK_INTERVAL = 1 
EPOCHS = 10 

# [STUDENT CODE: Load the pre-trained feature extractor (e.g., VGG16)]
# Load VGG16 (assuming 64x64 input size for compatibility with Exercise 2)
# If image size is smaller, input_shape must be adjusted.
vgg_base = VGG16(weights='imagenet', include_top=False, input_shape=(64, 64, 3))
vgg_base.trainable = False

# Use the output of a deep convolutional block (e.g., block5_conv3)
feature_extractor = tf.keras.Model(
    inputs=vgg_base.input,
    outputs=vgg_base.get_layer('block5_conv3').output
)

def extract_features(generated_images):
    # Generated images are typically in [-1, 1]. Rescale to VGG's required [0, 255] range.
    images_255 = (generated_images + 1) * 127.5
    
    # [STUDENT CODE: Preprocess images and extract features]
    processed_images = preprocess_input(images_255)
    
    features = feature_extractor(processed_images)
    
    # Flatten features: (Batch_Size, H*W*C)
    features_flat = tf.keras.layers.Flatten()(features)
    return features_flat

def calculate_batch_diversity(features):
    # Features shape: (Batch_Size, Feature_Dimension)
    # [STUDENT CODE: Calculate the standard deviation across the batch dimension]
    
    # Calculate the standard deviation for each feature component across the batch
    feature_std = tf.math.reduce_std(features, axis=0) 
    
    # Average these standard deviations to get a single scalar diversity score
    diversity_score = tf.reduce_mean(feature_std)
    return diversity_score

# Conceptual Justification:
"""
Why Feature Variance?
Pixel-level variance is unreliable as it is sensitive to trivial changes (noise, slight shifts).
Feature variance, derived from a deep layer of a feature extractor (VGG16), measures 
the standard deviation in the semantic space. If this variance is low, it means all 
images in the batch map to highly similar points in the semantic feature space, 
indicating a lack of diversity or mode collapse.
"""

# --- Mock Training Loop Simulation ---
def mock_generate_batch(epoch):
    # Simulate high diversity (Epoch 1-4) then low diversity (Epoch 5+)
    if epoch < 5:
        return tf.random.normal((32, 64, 64, 3), mean=0.0, stddev=0.5)
    else:
        # Simulate collapse: images are very similar, only minor noise variation
        base_image = tf.random.normal((1, 64, 64, 3), mean=0.1, stddev=0.01)
        return tf.tile(base_image, [32, 1, 1, 1]) + tf.random.normal((32, 64, 64, 3), stddev=0.005)

print("Starting GAN Training Simulation...")
for epoch in range(1, EPOCHS + 1):
    # ... (Standard training steps happen here) ...

    if epoch % CHECK_INTERVAL == 0:
        generated_batch = mock_generate_batch(epoch)
        features = extract_features(generated_batch)
        current_diversity = calculate_batch_diversity(features)
        
        print(f"Epoch {epoch}: Diversity Score = {current_diversity.numpy():.4f}")

        if current_diversity < DIVERSITY_THRESHOLD:
            # [STUDENT CODE: Increment counter and check for early stop]
            consecutive_low_diversity_epochs += 1
            if consecutive_low_diversity_epochs >= CONSECUTIVE_COLLAPSE_LIMIT:
                print("\n!!! WARNING: MODE COLLAPSE DETECTED !!!")
                print(f"Diversity score below {DIVERSITY_THRESHOLD} for {CONSECUTIVE_COLLAPSE_LIMIT} consecutive checks. Stopping training.")
                break
        else:
            # [STUDENT CODE: Reset counter]
            consecutive_low_diversity_epochs = 0

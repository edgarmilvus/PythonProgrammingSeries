
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import tensorflow as tf
import numpy as np

# --- Mock Setup (Required for context) ---
Z_DIM = 100
BATCH_SIZE = 32
IMAGE_SHAPE = (28, 28, 1)

# Mock Generator and Discriminator models
def mock_generator():
    return tf.keras.Sequential([
        tf.keras.layers.Input(shape=(Z_DIM,)),
        tf.keras.layers.Dense(np.prod(IMAGE_SHAPE)),
        tf.keras.layers.Reshape(IMAGE_SHAPE)
    ], name='Generator')

def mock_discriminator():
    return tf.keras.Sequential([
        tf.keras.layers.Input(shape=IMAGE_SHAPE),
        tf.keras.layers.Flatten(),
        tf.keras.layers.Dense(1) # Output logit
    ], name='Discriminator')

generator = mock_generator()
discriminator = mock_discriminator()
g_optimizer = tf.keras.optimizers.Adam(1e-4)
d_optimizer = tf.keras.optimizers.Adam(1e-4)

# Use BCE from logits for numerical stability
cross_entropy = tf.keras.losses.BinaryCrossentropy(from_logits=True)

# 1. Discriminator Loss Implementation (L_D)
def discriminator_loss(real_output, fake_output):
    # D wants real outputs to be 1 (label smoothing often used here, but 1 is standard)
    real_loss = cross_entropy(tf.ones_like(real_output), real_output)
    # D wants fake outputs to be 0
    fake_loss = cross_entropy(tf.zeros_like(fake_output), fake_output)
    total_loss = real_loss + fake_loss
    return total_loss

# 2. Generator Loss Implementation (L_G)
def generator_loss(fake_output):
    # G wants D to classify fake outputs as 1 (real)
    return cross_entropy(tf.ones_like(fake_output), fake_output)

# 3. Two-Step Optimization (train_step)
@tf.function
def train_step(images):
    noise = tf.random.normal([BATCH_SIZE, Z_DIM])

    # --- Step A: Discriminator Optimization ---
    with tf.GradientTape() as disc_tape:
        generated_images = generator(noise, training=True) # Forward pass through G
        
        real_output = discriminator(images, training=True)
        fake_output = discriminator(generated_images, training=True)

        disc_loss = discriminator_loss(real_output, fake_output)

    # Calculate gradients only for D's trainable variables
    gradients_of_discriminator = disc_tape.gradient(disc_loss, discriminator.trainable_variables)
    d_optimizer.apply_gradients(zip(gradients_of_discriminator, discriminator.trainable_variables))

    # --- Step B: Generator Optimization ---
    # We use a new tape. Although the computation flows through D, 
    # we only track G's variables for the gradient calculation.
    with tf.GradientTape() as gen_tape:
        generated_images = generator(noise, training=True)
        fake_output = discriminator(generated_images, training=True) # D is used, but not trained
        
        gen_loss = generator_loss(fake_output)

    # Calculate gradients only for G's trainable variables
    gradients_of_generator = gen_tape.gradient(gen_loss, generator.trainable_variables)
    g_optimizer.apply_gradients(zip(gradients_of_generator, generator.trainable_variables))

    return disc_loss, gen_loss

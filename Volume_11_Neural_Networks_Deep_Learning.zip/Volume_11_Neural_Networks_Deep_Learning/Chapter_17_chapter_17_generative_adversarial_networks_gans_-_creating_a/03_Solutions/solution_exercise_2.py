
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import tensorflow as tf

# Assume Latent_Dim = 256 and Initial_Filters = 512

def build_generator(latent_dim, initial_filters, output_channels=3):
    # 1. Calculate the required size for the initial dense projection
    # Target Reshape: (4, 4, initial_filters)
    required_projection_size = 4 * 4 * initial_filters # 4 * 4 * 512 = 8192
    
    # 2. Define the layer structure dynamically using List Comprehension
    # We need 4 upsampling steps total: 4->8, 8->16, 16->32, 32->64.
    # The first three steps are handled by the loop (Conv2DTranspose + BN + LeakyReLU).
    # The filter counts are halved at each step: 512 -> 256 -> 128 -> 64.
    
    # Calculate filter sequence for the loop (starting after the initial 512)
    filter_sequence = [initial_filters // (2**i) for i in range(1, 4)] # [256, 128, 64]
    
    # Define (filters, kernel_size, stride) for the 3 upsampling blocks (4x4 -> 32x32)
    upsampling_blocks = [(f, 5, 2) for f in filter_sequence]
    
    model = tf.keras.Sequential()
    
    # Initial Projection Layer (Input 256-D vector)
    model.add(tf.keras.layers.Dense(required_projection_size, input_shape=(latent_dim,)))
    model.add(tf.keras.layers.BatchNormalization())
    model.add(tf.keras.layers.LeakyReLU())
    
    # Reshape to 4x4x512
    model.add(tf.keras.layers.Reshape((4, 4, initial_filters)))
    
    # Apply dynamic upsampling blocks (4x4 -> 32x32)
    for filters, kernel, stride in upsampling_blocks:
        model.add(tf.keras.layers.Conv2DTranspose(
            filters=filters, 
            kernel_size=kernel, 
            strides=stride, 
            padding='same', 
            use_bias=False
        ))
        model.add(tf.keras.layers.BatchNormalization())
        model.add(tf.keras.layers.LeakyReLU())

    # Final output layer (32x32 -> 64x64, 4th spatial upsampling step)
    model.add(tf.keras.layers.Conv2DTranspose(
        filters=output_channels, 
        kernel_size=5, 
        strides=2, 
        padding='same', 
        activation='tanh'
    ))
    
    return model

# Verification:
# generator = build_generator(256, 512)
# print(generator.output_shape)
# Output: (None, 64, 64, 3)

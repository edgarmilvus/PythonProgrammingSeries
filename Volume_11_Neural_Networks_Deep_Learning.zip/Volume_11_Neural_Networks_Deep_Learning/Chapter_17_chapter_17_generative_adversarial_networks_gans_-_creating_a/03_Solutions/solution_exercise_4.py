
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import sys
import argparse
import tensorflow as tf 

# 1. Argument Parsing Function
def parse_arguments():
    """
    Parses command-line arguments and returns a configuration dictionary.
    """
    parser = argparse.ArgumentParser(description="Configurable GAN Training Script")
    
    # --latent_dim: Integer, default 128
    parser.add_argument('--latent_dim', type=int, default=128, 
                        help='Size of the latent noise vector Z (default: 128).')
    
    # --learning_rate: Float, default 0.0002
    parser.add_argument('--learning_rate', type=float, default=0.0002,
                        help='Learning rate for Adam optimizers (default: 0.0002).')
                        
    # --epochs: Integer, default 50
    parser.add_argument('--epochs', type=int, default=50,
                        help='Number of training epochs (default: 50).')
                        
    # Parse arguments provided via the command line (sys.argv[1:])
    args, unknown = parser.parse_known_args(sys.argv[1:])
    
    config = {
        'latent_dim': args.latent_dim,
        'learning_rate': args.learning_rate,
        'epochs': args.epochs
    }
    return config

# 2. Application Factory Function
def create_training_app(config):
    """
    Creates and configures the GAN training environment based on the input config.
    It initializes models and optimizers with the specified hyperparameters.
    """
    latent_dim = config['latent_dim']
    lr = config['learning_rate']
    epochs = config['epochs']

    # Placeholder for model instantiation
    # generator = build_generator(latent_dim) 
    # discriminator = build_discriminator()
    
    # Optimizer instantiation using configured learning rate
    g_optimizer = tf.keras.optimizers.Adam(lr)
    d_optimizer = tf.keras.optimizers.Adam(lr)
    
    # The configured training function (the application)
    def train_model():
        print("--- GAN Application Configuration Loaded ---")
        print(f"Latent Dimension: {latent_dim}")
        print(f"Learning Rate: {lr}")
        print(f"Optimizers initialized: {type(g_optimizer).__name__}")
        print(f"Starting training for {epochs} epochs...")
        
        # Simulation of the training loop execution
        for epoch in range(1, epochs + 1):
            if epoch % 10 == 0:
                print(f"  [Progress] Epoch {epoch}/{epochs} reached.")
        
        print("Training finished successfully.")
        
    return train_model

# 3. Main Execution Block
if __name__ == "__main__":
    # Example execution: python script.py --latent_dim 256 --epochs 100
    
    # 1. Get configuration from command line
    config = parse_arguments()
    
    # 2. Create the configured application using the factory
    run_training = create_training_app(config)
    
    # 3. Execute the application
    run_training()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

# --- 1. Data Simulation Function (The 'Real World' Data Source) ---
def get_real_samples(n_samples):
    """Generates samples from a simple 1D Gaussian distribution."""
    # Parameters defining the target distribution
    mean = 4.0
    std_dev = 1.2
    # torch.randn generates samples from N(0, 1). We apply scaling and shifting.
    samples = torch.randn(n_samples, 1) * std_dev + mean
    return samples

# --- 2. The Generator Model (G: The Artist) ---
class Generator(nn.Module):
    """Maps a latent noise vector (z) to a synthetic data point."""
    def __init__(self, latent_dim, output_dim):
        super().__init__()
        self.model = nn.Sequential(
            # Input layer: Takes the latent noise vector
            nn.Linear(latent_dim, 128),
            nn.LeakyReLU(0.2), # Standard activation for hidden layers in GANs
            
            # Hidden layer
            nn.Linear(128, 256),
            nn.LeakyReLU(0.2),
            
            # Output layer: Must output a single data point (DATA_DIM = 1)
            nn.Linear(256, output_dim),
            # Note: No final activation needed for fitting a continuous distribution
        )

    def forward(self, z):
        return self.model(z)

# --- 3. The Discriminator Model (D: The Critic) ---
class Discriminator(nn.Module):
    """Classifies input data as real (1) or fake (0)."""
    def __init__(self, input_dim):
        super().__init__()
        self.model = nn.Sequential(
            # Input layer: Takes the 1D sample (real or generated)
            nn.Linear(input_dim, 256),
            nn.LeakyReLU(0.2),
            
            # Hidden layer
            nn.Linear(256, 128),
            nn.LeakyReLU(0.2),
            
            # Output layer: Single probability score
            nn.Linear(128, 1),
            nn.Sigmoid() # Squashes the output to [0, 1] probability range
        )

    def forward(self, x):
        return self.model(x)

# --- 4. Hyperparameters and Initialization ---
LATENT_DIM = 10     # Size of the input noise vector (z)
DATA_DIM = 1        # The dimensionality of our data (a single number)
N_EPOCHS = 500      # Training duration
BATCH_SIZE = 64
LEARNING_RATE = 0.0002

# Initialize models
G = Generator(LATENT_DIM, DATA_DIM)
D = Discriminator(DATA_DIM)

# Loss function: Binary Cross Entropy (ideal for binary classification)
criterion = nn.BCELoss()
# Crucial: Separate optimizers for G and D
optimizer_D = optim.Adam(D.parameters(), lr=LEARNING_RATE)
optimizer_G = optim.Adam(G.parameters(), lr=LEARNING_RATE)

# --- 5. The Training Loop (Adversarial Process) ---
print("Starting minimalist 1D GAN training...")
for epoch in range(N_EPOCHS):
    
    # ======================================================
    # A. Discriminator Training Step (Maximize log(D(x)) + log(1 - D(G(z))))
    # ======================================================

    # 1. Prepare Real Data Batch
    real_samples = get_real_samples(BATCH_SIZE)
    # Target label: Real = 1
    real_labels = torch.ones(BATCH_SIZE, 1) 

    # 2. Prepare Fake Data Batch
    noise = torch.randn(BATCH_SIZE, LATENT_DIM)
    # Generate fake data using G
    fake_samples = G(noise) 
    # CRITICAL: Detach the generated samples to prevent gradient flow back to G 
    # during this D optimization step.
    fake_samples = fake_samples.detach() 
    # Target label: Fake = 0
    fake_labels = torch.zeros(BATCH_SIZE, 1) 

    # 3. Combine and Optimize D
    all_samples = torch.cat((real_samples, fake_samples))
    all_labels = torch.cat((real_labels, fake_labels))

    D.zero_grad()
    d_output = D(all_samples)
    d_loss = criterion(d_output, all_labels)
    d_loss.backward()
    optimizer_D.step()

    # ======================================================
    # B. Generator Training Step (Minimize log(1 - D(G(z))) or Maximize log(D(G(z))))
    # ======================================================

    # 1. Generate new fake data (G is NOT detached this time)
    noise = torch.randn(BATCH_SIZE, LATENT_DIM)
    gen_samples = G(noise)

    # 2. Set target labels for G: G wants D to think its output is REAL (label 1)
    target_labels = torch.ones(BATCH_SIZE, 1)

    # Optimize G
    G.zero_grad()
    # Note: We must zero D's gradients again, even though we don't optimize D, 
    # because the loss calculation uses D's forward pass.
    D.zero_grad() 
    
    g_output = D(gen_samples)
    # Calculate G loss using target labels (1)
    g_loss = criterion(g_output, target_labels) 
    g_loss.backward()
    optimizer_G.step()

    # --- C. Reporting ---
    if (epoch + 1) % 100 == 0:
        # Check D's average output for both real and fake samples
        real_pred = D(real_samples).mean().item()
        fake_pred = D(gen_samples.detach()).mean().item()
        print(f"Epoch [{epoch+1}/{N_EPOCHS}] | D Loss: {d_loss.item():.4f} | G Loss: {g_loss.item():.4f} | D(Real): {real_pred:.2f} | D(Fake): {fake_pred:.2f}")

# --- 6. Inspection of Results ---
final_noise = torch.randn(10, LATENT_DIM)
# Set G to evaluation mode and generate samples
G.eval()
final_output = G(final_noise).detach().numpy()
print("\nGenerated samples after training (should cluster near 4.0):")
print(final_output)


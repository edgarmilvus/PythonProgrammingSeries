
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torchvision import models, transforms
import time
import os

# --- 1. Configuration and Hyperparameters ---
DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
NUM_CLASSES = 4  # Urban, Forest, Agriculture, Water
BATCH_SIZE = 32
NUM_EPOCHS = 3 # Small number for demonstration
DATASET_SIZE = 500 # Simulating a small custom dataset

# --- 2. Custom Dataset Simulation (Required for demonstration) ---

class SatelliteDataset(Dataset):
    """
    Simulates a small, custom satellite image dataset.
    In a real application, this would load images from disk (e.g., using PIL).
    """
    def __init__(self, num_samples, num_classes, transform=None):
        # Generate random tensors representing 3-channel, 224x224 images
        self.data = [torch.randn(3, 224, 224) for _ in range(num_samples)]
        # Generate random labels for the defined number of classes
        self.labels = [torch.randint(0, num_classes, (1,)).item() for _ in range(num_samples)]
        self.transform = transform

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        img = self.data[idx]
        label = self.labels[idx]
        if self.transform:
            # Apply transformation (e.g., normalization)
            img = self.transform(img)
        return img, label

# --- 3. Model Setup: Transfer Learning Implementation (Feature Extraction) ---

def setup_resnet_feature_extractor(num_classes):
    """
    Loads ResNet-50, freezes the convolutional layers, and replaces the final head.
    """
    # Load ResNet-50 pre-trained on ImageNet
    # We use the recommended standard weights
    model = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)

    # CRITICAL: Freeze all parameters in the feature extraction backbone
    # This ensures gradients are not calculated for these layers during backpropagation
    for param in model.parameters():
        param.requires_grad = False

    # Identify the size of the input features to the final fully connected layer (fc)
    # For ResNet-50, this is typically 2048
    num_ftrs = model.fc.in_features

    # Replace the final classification head with a new linear layer
    # This new layer is initialized randomly and is the only part that will be trained
    model.fc = nn.Linear(num_ftrs, num_classes)

    # Move the model to the appropriate device (CPU/GPU)
    model = model.to(DEVICE)
    return model

# --- 4. Training Function (Simplified) ---

def train_model(model, dataloader, criterion, optimizer, num_epochs):
    """
    Runs the training loop, showing loss only for the trainable layers.
    """
    print(f"Starting training on device: {DEVICE}")
    start_time = time.time()

    for epoch in range(num_epochs):
        model.train()
        running_loss = 0.0
        
        for inputs, labels in dataloader:
            inputs = inputs.to(DEVICE)
            labels = labels.to(DEVICE)

            # Zero the parameter gradients before the forward pass
            optimizer.zero_grad()

            # Forward pass: Calculate predictions
            outputs = model(inputs)
            
            # Calculate loss
            loss = criterion(outputs, labels)

            # Backward pass: Calculate gradients (only for the unfrozen 'fc' layer)
            loss.backward()
            
            # Optimization step: Update weights
            optimizer.step()

            running_loss += loss.item() * inputs.size(0)

        epoch_loss = running_loss / len(dataloader.dataset)
        print(f"Epoch {epoch+1}/{num_epochs} Loss: {epoch_loss:.4f}")

    time_elapsed = time.time() - start_time
    print(f"Training complete in {time_elapsed // 60:.0f}m {time_elapsed % 60:.0f}s")
    return model

# --- 5. Main Execution Block ---

if __name__ == "__main__":
    # Define standard ImageNet normalization transforms
    data_transforms = transforms.Compose([
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])

    # Initialize the simulated dataset and dataloader
    dataset = SatelliteDataset(
        num_samples=DATASET_SIZE, 
        num_classes=NUM_CLASSES, 
        transform=data_transforms
    )
    dataloader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True)

    # Setup the Transfer Learning model
    transfer_model = setup_resnet_feature_extractor(NUM_CLASSES)

    # Define Loss Function and Optimizer
    criterion = nn.CrossEntropyLoss()

    # CRITICAL: Only optimize parameters that require gradients (the new 'fc' layer)
    # This is a key step in feature extraction
    optimizer = optim.SGD(
        transfer_model.fc.parameters(), # Pass only the trainable parameters
        lr=0.001, 
        momentum=0.9
    )

    # Start training
    final_model = train_model(transfer_model, dataloader, criterion, optimizer, NUM_EPOCHS)

    # Save the resulting model state
    model_save_path = "resnet_satellite_feature_extractor.pth"
    torch.save(final_model.state_dict(), model_save_path)
    print(f"\nModel saved to {model_save_path}")



#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import torch
import torch.nn as nn
import torchvision.models as models

# --- Configuration ---
NUM_CLASSES = 3  # The specific number of classes for our new, custom task (e.g., 'Bolt', 'Nut', 'Washer')
INPUT_IMAGE_SIZE = 224 # Standard input size for ResNet models

def initialize_transfer_model(num_classes: int, feature_extract: bool = True):
    """
    Initializes a pre-trained ResNet-18 model and prepares it for transfer learning.
    If feature_extract is True, the model base is frozen.
    """
    # 1. Load the Pre-trained Model
    # We use ResNet-18, a highly efficient and popular choice.
    # weights=models.ResNet18_Weights.IMAGENET1K_V1 ensures we download the official ImageNet weights.
    model_ft = models.resnet18(weights=models.ResNet18_Weights.IMAGENET1K_V1)
    print("--- Loaded ResNet-18 pre-trained on ImageNet ---")

    # 2. Freeze the Parameters (Feature Extraction Methodology)
    if feature_extract:
        # Iterate over all parameters in the entire model structure.
        for param in model_ft.parameters():
            # Setting requires_grad to False prevents gradient computation during the backward pass.
            # This effectively freezes the weights of the convolutional base.
            param.requires_grad = False
        print("--- Convolutional Base Frozen (requires_grad=False) ---")

    # 3. Modify the Final Layer (The Classification Head)
    # ResNet models typically use a fully connected layer named 'fc' for classification.
    # We need to determine the input features required by the existing 'fc' layer.
    num_ftrs = model_ft.fc.in_features
    
    # Replace the existing classification head with a new one tailored to our specific task.
    # The input size (num_ftrs) remains the same, but the output size changes to NUM_CLASSES.
    # By default, new layers are created with requires_grad=True.
    model_ft.fc = nn.Linear(num_ftrs, num_classes)
    
    print(f"--- Classification Head Replaced: Output features changed to {num_classes} ---")

    return model_ft

def count_trainable_parameters(model):
    """Utility function to count only the parameters that require gradient computation."""
    total_params = sum(p.numel() for p in model.parameters())
    # Crucially, we filter the parameters based on the requires_grad flag.
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return total_params, trainable_params

# =========================================================================
# Execution Flow
# =========================================================================

# 1. Initialize the model using Feature Extraction (freezing the base)
custom_model = initialize_transfer_model(NUM_CLASSES, feature_extract=True)

# 2. Analyze the parameter structure
total, trainable = count_trainable_parameters(custom_model)

print("\n--- Model Analysis ---")
print(f"Total Parameters in Model: {total:,}")
print(f"Trainable Parameters (Unfrozen): {trainable:,}")

# 3. Verification Test (Ensuring the new head works)
# Create a dummy batch of input data: [Batch Size, Channels, Height, Width]
# Standard ResNet input is 3 color channels (RGB) and 224x224 resolution.
dummy_input = torch.randn(1, 3, INPUT_IMAGE_SIZE, INPUT_IMAGE_SIZE)

# Perform the forward pass without tracking gradients (since we are just testing the shape)
with torch.no_grad():
    output = custom_model(dummy_input)

# Check the output shape
print("\n--- Output Verification ---")
print(f"Shape of Dummy Input Tensor: {dummy_input.shape}")
print(f"Shape of Output Tensor (Logits): {output.shape}")

# Expected output shape: [1 (Batch Size), 3 (NUM_CLASSES)]
if output.shape[1] == NUM_CLASSES:
    print("Verification Successful: Output shape matches the new NUM_CLASSES.")
else:
    print("Verification Failed: Output shape mismatch.")

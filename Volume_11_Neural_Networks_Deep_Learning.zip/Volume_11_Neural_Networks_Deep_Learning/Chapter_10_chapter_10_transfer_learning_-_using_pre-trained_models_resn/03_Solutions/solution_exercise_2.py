
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import models

def setup_resnet_fine_tuning(num_classes: int, high_lr: float, low_lr: float):
    """
    Configures ResNet50 for strategic fine-tuning with differential LRs.
    """
    model = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V2)

    # 1. Freeze initial blocks (Freeze everything first)
    for param in model.parameters():
        param.requires_grad = False

    # 2. Selective Unfreezing: Unfreeze layer3 and layer4
    for block in [model.layer3, model.layer4]:
        for param in block.parameters():
            param.requires_grad = True

    # 3. Replace the final FC layer (it is trainable by default)
    num_ftrs = model.fc.in_features
    model.fc = nn.Linear(num_ftrs, num_classes)
    
    # 4. Define parameter groups for differential optimization
    
    # Group 1: New Classifier Head (High LR)
    head_params = model.fc.parameters()
    
    # Group 2: Unfrozen ResNet Blocks (layer3 and layer4) (Low LR)
    # Gather parameters that have requires_grad=True
    resnet_ft_params = [
        p for p in list(model.layer3.parameters()) + list(model.layer4.parameters()) 
        if p.requires_grad
    ]
    
    params_to_optimize = [
        {'params': head_params, 'lr': high_lr},
        {'params': resnet_ft_params, 'lr': low_lr},
    ]

    # Initialize the optimizer with the parameter groups
    optimizer = optim.SGD(params_to_optimize, momentum=0.9)
    
    print("--- Differential LR Setup Verification ---")
    print(f"Head LR (Group 1): {optimizer.param_groups[0]['lr']:.5f}")
    print(f"ResNet Blocks LR (Group 2): {optimizer.param_groups[1]['lr']:.5f}")

    return model, optimizer

# Example usage
HIGH_LR = 1e-3
LOW_LR = 1e-5
resnet_model, resnet_optimizer = setup_resnet_fine_tuning(num_classes=5, high_lr=HIGH_LR, low_lr=LOW_LR)

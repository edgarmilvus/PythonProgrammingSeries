
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import torch
import torch.nn as nn
from torchvision import models

def setup_vgg_feature_extractor(num_classes: int) -> nn.Module:
    """
    Configures a VGG16 model for pure feature extraction.
    Freezes the entire convolutional base and attaches a new classifier head.
    """
    # 1. Load the pre-trained model
    model = models.vgg16(weights=models.VGG16_Weights.IMAGENET1K_V1)

    # 2. Freeze the convolutional base parameters (the 'features' module)
    # Iterate through all parameters in the features module and set requires_grad to False
    for param in model.features.parameters():
        param.requires_grad = False
    
    # Determine the input size for the new classifier head
    # VGG's final feature map size is flattened to 25088 (512 * 7 * 7)
    input_to_classifier = model.classifier[0].in_features 

    # 3. Define the new classification head (lightweight for stability)
    new_classifier_head = nn.Sequential(
        nn.Linear(input_to_classifier, 512),
        nn.ReLU(True),
        nn.Dropout(0.5),
        nn.Linear(512, num_classes)
    )

    # 4. Replace the original classifier
    model.classifier = new_classifier_head

    # --- Verification Step ---
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)

    print(f"Total Model Parameters: {total_params:,}")
    print(f"Trainable Parameters (New Head Only): {trainable_params:,}")
    
    return model

# Example usage
vgg_model = setup_vgg_feature_extractor(num_classes=10)
# Expected trainable parameters: ~12.8 million (only the new head)

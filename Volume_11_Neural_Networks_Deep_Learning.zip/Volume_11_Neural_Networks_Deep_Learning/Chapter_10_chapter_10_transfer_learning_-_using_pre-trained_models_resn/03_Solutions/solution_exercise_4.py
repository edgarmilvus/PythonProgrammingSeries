
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import torch
import torch.nn as nn
from torchvision import models

class DualHeadResNet(nn.Module):
    def __init__(self, num_primary_classes: int, num_secondary_classes: int):
        super().__init__()
        
        # Load ResNet18 base
        resnet = models.resnet18(weights=models.ResNet18_Weights.IMAGENET1K_V1)
        
        # Freeze the ResNet base parameters
        for param in resnet.parameters():
            param.requires_grad = False
        
        # Save the feature extractor (excluding the original FC layer)
        # ResNet18 outputs a 512-dimensional feature vector before the FC layer
        self.features = nn.Sequential(*list(resnet.children())[:-1])
        
        feature_size = resnet.fc.in_features # 512 for ResNet18
        
        # Define Head 1: Primary Task (10 classes)
        self.head1 = nn.Sequential(
            nn.Linear(feature_size, 256),
            nn.ReLU(),
            nn.Linear(256, num_primary_classes)
        )
        
        # Define Head 2: Secondary Task (3 classes)
        self.head2 = nn.Sequential(
            nn.Linear(feature_size, 128),
            nn.ReLU(),
            nn.Linear(128, num_secondary_classes)
        )

    def forward(self, x):
        # Pass input through the frozen feature extractor
        x = self.features(x)
        
        # Flatten the feature map (e.g., from [B, 512, 1, 1] to [B, 512])
        x = torch.flatten(x, 1)
        
        # Independent classification
        out1 = self.head1(x)
        out2 = self.head2(x)
        
        return out1, out2

# --- Composite Loss Implementation ---
def calculate_composite_loss(output1, target1, output2, target2):
    """Calculates L_total = L1 + L2."""
    criterion = nn.CrossEntropyLoss()
    
    loss1 = criterion(output1, target1)
    loss2 = criterion(output2, target2)
    
    # Calculate Total Loss
    total_loss = loss1 + loss2
    return total_loss

# --- Example Usage and Training Step Verification ---
NUM_PRIMARY = 10
NUM_SECONDARY = 3
model = DualHeadResNet(NUM_PRIMARY, NUM_SECONDARY)

# Simulate data
dummy_input = torch.randn(4, 3, 224, 224)
labels1 = torch.randint(0, NUM_PRIMARY, (4,))
labels2 = torch.randint(0, NUM_SECONDARY, (4,))

# Forward pass
outputs1, outputs2 = model(dummy_input)

# Calculate composite loss
loss = calculate_composite_loss(outputs1, labels1, labels2, labels2)

# Training step adaptation (Conceptual)
# optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
# optimizer.zero_grad()
# loss.backward() # Gradients flow back based on L1 + L2
# optimizer.step()

print(f"Model instantiated with two heads.")
print(f"Primary output shape: {outputs1.shape}, Secondary output shape: {outputs2.shape}")
print(f"Total Composite Loss: {loss.item():.4f}")

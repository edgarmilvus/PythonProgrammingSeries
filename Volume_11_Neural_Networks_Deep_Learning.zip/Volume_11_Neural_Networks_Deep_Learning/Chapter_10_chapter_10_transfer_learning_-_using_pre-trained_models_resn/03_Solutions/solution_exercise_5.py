
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
from torchvision import models

# --- Setup Function (Differential Optimizer) ---

def setup_resnet_fine_tuning_optimizer(num_classes: int, high_lr: float, low_lr: float):
    """
    Configures ResNet50 model and a differential optimizer (reused from Ex 2).
    """
    model = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V2)
    
    # Freeze initial layers
    for param in model.parameters():
        param.requires_grad = False
    
    # Unfreeze layer3 and layer4
    for block in [model.layer3, model.layer4]:
        for param in block.parameters():
            param.requires_grad = True

    # Replace FC layer
    num_ftrs = model.fc.in_features
    model.fc = nn.Linear(num_ftrs, num_classes)
    
    # Define parameter groups
    head_params = model.fc.parameters()
    resnet_ft_params = [p for p in list(model.layer3.parameters()) + list(model.layer4.parameters()) if p.requires_grad]
    
    params_to_optimize = [
        {'params': head_params, 'lr': high_lr, 'name': 'Head'},
        {'params': resnet_ft_params, 'lr': low_lr, 'name': 'ResNet Blocks'},
    ]

    optimizer = optim.SGD(params_to_optimize, momentum=0.9)
    return model, optimizer

# --- Scheduler Setup ---

def setup_scheduler(optimizer, step_size, gamma):
    """
    Initializes StepLR scheduler to manage the differential optimizer.
    """
    # 2. Initialize StepLR scheduler
    scheduler = lr_scheduler.StepLR(optimizer, step_size=step_size, gamma=gamma)
    return scheduler

# --- Training Loop Integration and Verification ---

def training_loop_with_scheduler(optimizer, scheduler, num_epochs=12):
    """
    Simulates the training loop steps to verify scheduler integration.
    """
    print("Epoch | Head LR (Group 1) | ResNet LR (Group 2)")
    print("-" * 45)
    
    for epoch in range(num_epochs):
        # 3. Optimization step (Simulated)
        # optimizer.step() 

        # 3. Step the scheduler after the epoch completes
        scheduler.step()

        # 4. Verification step: Print the current LR for both groups
        current_lr_group1 = optimizer.param_groups[0]['lr']
        current_lr_group2 = optimizer.param_groups[1]['lr']
        
        print(f"{epoch + 1:5} | {current_lr_group1:.8f} | {current_lr_group2:.8f}")

# --- Main Execution ---
HIGH_LR_INIT = 1e-3
LOW_LR_INIT = 1e-5
STEP_SIZE = 5
GAMMA = 0.1 

# 1. Setup Model and Differential Optimizer
model, optimizer = setup_resnet_fine_tuning_optimizer(num_classes=5, high_lr=HIGH_LR_INIT, low_lr=LOW_LR_INIT)

# 2. Setup Scheduler
scheduler = setup_scheduler(optimizer, step_size=STEP_SIZE, gamma=GAMMA)

# 3. Run Simulation
training_loop_with_scheduler(optimizer, scheduler, num_epochs=12)

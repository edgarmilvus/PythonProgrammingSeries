
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
from torchvision import models
from torch.utils.data import DataLoader, Dataset
import random

# --- Model Setup Functions (Simplified for simulation) ---
def setup_vgg_feature_extractor_sim(num_classes=10):
    model = models.vgg16(weights=models.VGG16_Weights.IMAGENET1K_V1)
    for param in model.features.parameters():
        param.requires_grad = False
    input_to_classifier = model.classifier[0].in_features
    model.classifier = nn.Sequential(nn.Linear(input_to_classifier, 512), nn.ReLU(), nn.Linear(512, num_classes))
    optimizer = optim.Adam(model.classifier.parameters(), lr=1e-3)
    return model, optimizer

def setup_resnet_fine_tuning_sim(num_classes=5, high_lr=1e-3, low_lr=1e-5):
    model = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V2)
    for param in model.parameters():
        param.requires_grad = False
    for block in [model.layer3, model.layer4]:
        for param in block.parameters():
            param.requires_grad = True
    num_ftrs = model.fc.in_features
    model.fc = nn.Linear(num_ftrs, num_classes)
    head_params = model.fc.parameters()
    resnet_ft_params = [p for p in list(model.layer3.parameters()) + list(model.layer4.parameters()) if p.requires_grad]
    params_to_optimize = [{'params': head_params, 'lr': high_lr}, {'params': resnet_ft_params, 'lr': low_lr}]
    optimizer = optim.SGD(params_to_optimize, momentum=0.9)
    return model, optimizer

# --- Dummy Data Simulation (Required for training loop structure) ---
class DummyDataset(Dataset):
    def __init__(self, num_samples, num_classes):
        self.num_samples = num_samples
        self.num_classes = num_classes
    def __len__(self):
        return self.num_samples
    def __getitem__(self, idx):
        return torch.randn(3, 224, 224), torch.randint(0, self.num_classes, (1,)).item()

NUM_SAMPLES = 1000
data_loaders_vgg = {
    'train': DataLoader(DummyDataset(800, 10), batch_size=32),
    'val': DataLoader(DummyDataset(200, 10), batch_size=32)
}
data_loaders_resnet = {
    'train': DataLoader(DummyDataset(800, 5), batch_size=32),
    'val': DataLoader(DummyDataset(200, 5), batch_size=32)
}

# --- Training and Evaluation Function (Simulated Metrics) ---
def train_and_evaluate(model, optimizer, data_loaders, num_epochs=10, is_fine_tuning=False):
    criterion = nn.CrossEntropyLoss()
    history = {'train_loss': [], 'val_loss': [], 'val_acc': []}
    
    for epoch in range(num_epochs):
        model.train()
        avg_train_loss = 0
        
        # Simulate training phase
        for inputs, labels in data_loaders['train']:
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            
            # Simulate loss based on strategy
            if not is_fine_tuning: # FE: Stable, slower loss decrease
                sim_loss_base = 0.5 - (epoch * 0.03) + random.uniform(0.01, 0.05)
                val_acc_sim = 0.5 + (epoch * 0.03) + random.uniform(-0.02, 0.02)
            else: # FT: Faster loss decrease, higher variance, potential overfitting
                sim_loss_base = 0.4 - (epoch * 0.04) + random.uniform(0.02, 0.1)
                val_acc_sim = 0.6 + (epoch * 0.04) + random.uniform(-0.05, 0.05)
                if epoch > 7: val_acc_sim -= 0.02 * (epoch - 7) # Simulate overfitting drop
                
            avg_train_loss += sim_loss_base / len(data_loaders['train'])
        
        # Simulate validation phase
        avg_val_loss = avg_train_loss * 1.2 # Val loss usually higher
        if is_fine_tuning and epoch > 5:
            avg_val_loss += 0.05 # Simulate divergence/overfitting
            
        history['train_loss'].append(avg_train_loss)
        history['val_loss'].append(avg_val_loss)
        history['val_acc'].append(max(0.5, min(0.9, val_acc_sim)))
        
    return history

# --- Main Execution Flow ---
vgg_model, vgg_optimizer = setup_vgg_feature_extractor_sim(10)
resnet_model, resnet_optimizer = setup_resnet_fine_tuning_sim(5)

vgg_history = train_and_evaluate(vgg_model, vgg_optimizer, data_loaders_vgg, is_fine_tuning=False)
resnet_history = train_and_evaluate(resnet_model, resnet_optimizer, data_loaders_resnet, is_fine_tuning=True)

# --- Visualization step ---
epochs = range(1, 11)
plt.figure(figsize=(14, 5))

# Plot A: Training Loss vs. Epochs
plt.subplot(1, 2, 1)
plt.plot(epochs, vgg_history['train_loss'], label='VGG16 FE Train Loss', marker='o')
plt.plot(epochs, resnet_history['train_loss'], label='ResNet50 FT Train Loss', marker='x')
plt.title('Plot A: Training Loss Comparison (FE vs. FT)')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()
plt.grid(True)

# Plot B: Validation Accuracy vs. Epochs
plt.subplot(1, 2, 2)
plt.plot(epochs, vgg_history['val_acc'], label='VGG16 FE Val Accuracy', marker='o')
plt.plot(epochs, resnet_history['val_acc'], label='ResNet50 FT Val Accuracy', marker='x')
plt.title('Plot B: Validation Accuracy Comparison (FE vs. FT)')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()
plt.grid(True)
plt.show()

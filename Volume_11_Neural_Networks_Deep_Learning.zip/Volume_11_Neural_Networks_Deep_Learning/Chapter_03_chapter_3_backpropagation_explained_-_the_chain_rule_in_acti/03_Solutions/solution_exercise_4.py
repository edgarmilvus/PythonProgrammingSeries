
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np

# Given data
Z1 = np.array([1.2, -0.5, 0.1, 0.9, -1.0])
delta2 = np.array([0.01, -0.05, 0.03])
# Initialize W2 (5x3 matrix)
np.random.seed(42)
W2 = np.random.rand(5, 3) * 0.1

def tanh_derivative(z):
    # tanh'(z) = 1 - (tanh(z))^2
    tanh_z = np.tanh(z)
    return 1 - tanh_z**2

# --- Calculation Steps ---

# 1. Calculate the local gradient of the activation function at Layer 1
tanh_prime_Z1 = tanh_derivative(Z1)

# 2. Calculate the weighted error from the subsequent layer (l+1)
# This requires delta_2 (1x3) multiplied by W2_T (3x5). Result is 1x5.
# Weighted_error = delta_2 @ W2.T
weighted_error = np.dot(delta2, W2.T)

# 3. Calculate delta1 (Recursive error propagation)
# delta1 = Weighted_error (upstream) * tanh_prime_Z1 (local gradient)
delta1 = weighted_error * tanh_prime_Z1

print(f"Z1 shape: {Z1.shape}")
print(f"W2 shape: {W2.shape}")
print(f"delta2 shape: {delta2.shape}")
print("\n--- Intermediate Results ---")
print(f"tanh'(Z1) (Local Gradient):\n{tanh_prime_Z1}")
print(f"Weighted Error (delta2 @ W2.T):\n{weighted_error}")
print("\n--- Final Result ---")
print(f"Error Signal delta_1 shape: {delta1.shape}")
print(f"Error Signal delta_1:\n{delta1}")

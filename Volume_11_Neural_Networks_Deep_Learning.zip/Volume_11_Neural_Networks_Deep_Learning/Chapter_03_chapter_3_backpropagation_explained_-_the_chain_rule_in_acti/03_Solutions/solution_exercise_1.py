
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import math

# Input value
x = 2.0

# --- Forward Pass ---
# 1. u = ln(x)
u = math.log(x)
# 2. v = x^3 + u
v = x**3 + u
# 3. y = f(x) = sin(v)
y = math.sin(v)

# --- Backward Pass (Gradient Calculation) ---

# 1. Calculate local derivative dy/dv (d/dv(sin(v)) = cos(v))
dy_dv = math.cos(v)

# 2. Calculate local derivative du/dx (d/dx(ln(x)) = 1/x)
du_dx = 1.0 / x

# 3. Calculate local derivative d(x^3)/dx
dx3_dx = 3.0 * (x**2)

# 4. Calculate total derivative dv/dx = d(x^3)/dx + du/dx
dv_dx = dx3_dx + du_dx

# 5. Combine using the Chain Rule: dy/dx = dy/dv * dv/dx
total_gradient_dy_dx = dy_dv * dv_dx

print(f"Intermediate values: u={u:.4f}, v={v:.4f}, y={y:.4f}")
print(f"Local gradient dy/dv: {dy_dv:.4f}")
print(f"Local gradient dv/dx: {dv_dx:.4f}")
print(f"Final numerical gradient dy/dx: {total_gradient_dy_dx:.4f}")

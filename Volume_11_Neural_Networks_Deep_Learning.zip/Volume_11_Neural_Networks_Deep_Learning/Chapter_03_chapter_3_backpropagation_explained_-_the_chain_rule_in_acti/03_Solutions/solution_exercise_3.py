
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np

# Initial values
X = np.array([1.0, 0.5])
W1 = np.array([[0.2, 0.4], [-0.1, 0.3]])
B1 = np.array([0.1, 0.1])
W2 = np.array([[0.5], [-0.5]])
B2 = np.array([0.0])
Y_true = np.array([0.7])

def relu(z):
    return np.maximum(0, z)

def relu_derivative(z):
    # Derivative is 1 if z > 0, 0 otherwise
    return (z > 0).astype(float)

# --- Forward Pass ---
# Layer 1: Hidden layer
# Z1 = X @ W1 + B1 (X is 1x2, W1 is 2x2, Z1 is 1x2)
Z1 = np.dot(X, W1) + B1
H = relu(Z1)

# Layer 2: Output layer
# Z2 = H @ W2 + B2 (H is 1x2, W2 is 2x1, Z2 is 1x1)
Z2 = np.dot(H, W2) + B2
O = Z2 # Identity Activation

# --- Backward Pass (Layer 2) ---

# 1. dL_dO (Derivative of MSE Loss)
# dL/dO = O - Y_true
dL_dO = O - Y_true

# 2. Output activation derivative (Identity function derivative is 1)
dO_dZ2 = 1.0

# 3. Calculate delta_2 (dL_dZ2)
# delta_2 = dL/dO * dO/dZ2
delta_2 = dL_dO * dO_dZ2

# 4. Calculate dL_dW2 (Gradient w.r.t W2)
# dL/dW2 = dL/dZ2 * dZ2/dW2. Since Z2 = H @ W2 + B2, dZ2/dW2 = H^T
# H is 1x2, delta_2 is 1x1. Gradient dL/dW2 must be 2x1.
# We use H.T @ delta_2
dL_dW2 = np.dot(H.reshape(-1, 1), delta_2.reshape(1, -1))


print(f"Z1 (Weighted Sum Layer 1): {Z1}")
print(f"H (ReLU Output): {H}")
print(f"Z2 (Weighted Sum Layer 2): {Z2}")
print(f"O (Final Output): {O}")
print("--- Backward Results ---")
print(f"Error Signal delta_2 (dL/dZ2): {delta_2.flatten()}")
print(f"Gradient dL/dW2 (Shape {dL_dW2.shape}):\n{dL_dW2}")

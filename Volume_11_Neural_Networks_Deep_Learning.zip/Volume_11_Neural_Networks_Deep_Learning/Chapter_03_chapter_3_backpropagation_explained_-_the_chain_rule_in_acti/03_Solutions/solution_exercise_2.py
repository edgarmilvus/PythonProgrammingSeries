
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np

# Initial values
X = np.array([0.5, 0.8])
W = np.array([0.1, -0.3])
B = 0.5
Y_true = 1.0

def sigmoid(z):
    return 1 / (1 + np.exp(-z))

def sigmoid_derivative(a):
    # da/dz = a * (1 - a), where 'a' is the output of the sigmoid function
    return a * (1 - a)

# --- Forward Pass Steps ---
# Calculate z = W . X^T + B
z = np.dot(W, X) + B

# Calculate a = sigmoid(z)
a = sigmoid(z)

# --- Backward Pass Steps ---

# 1. Calculate dL_da (Upstream gradient from Loss, MSE derivative)
# L = 0.5 * (a - Y_true)^2 => dL/da = a - Y_true
dL_da = a - Y_true

# 2. Calculate da_dz (Local gradient of the activation function)
da_dz = sigmoid_derivative(a)

# 3. Calculate dL_dz (The error signal delta)
# dL/dz = dL/da * da/dz
dL_dz = dL_da * da_dz

# 4. Calculate dL_dW (Gradient w.r.t weights)
# dL/dW = dL/dz * dZ/dW. Since Z = W.X + B, dZ/dW = X
dL_dW = dL_dz * X

# 5. Calculate dL_dB (Gradient w.r.t bias)
# dL/dB = dL/dz * dZ/dB. Since dZ/dB = 1
dL_dB = dL_dz * 1.0

print(f"Weighted Sum (z): {z:.4f}")
print(f"Activation Output (a): {a:.4f}")
print(f"Upstream Gradient (dL/da): {dL_da:.4f}")
print(f"Error Signal (dL/dz): {dL_dz:.4f}")
print("--- Gradients ---")
print(f"Gradient dL/dW: {dL_dW}")
print(f"Gradient dL/dB: {dL_dB:.4f}")

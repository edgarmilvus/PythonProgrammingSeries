
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np

# Set a fixed seed for reproducibility of weight initialization
np.random.seed(42)

# --- 1. Data Definition (XOR Inputs and Outputs) ---
# X: Input data (4 samples, 2 features)
X = np.array([[0, 0], 
              [0, 1], 
              [1, 0], 
              [1, 1]])

# Y: Target output (4 samples, 1 output)
Y = np.array([[0], [1], [1], [0]])

# --- 2. Hyperparameters and Network Structure ---
INPUT_DIM = 2
HIDDEN_DIM = 4  # Number of neurons in the hidden layer
OUTPUT_DIM = 1
LEARNING_RATE = 0.1
EPOCHS = 10000

# --- 3. Activation Function and Derivatives ---

def sigmoid(x):
    """The Sigmoid activation function (σ(z))."""
    return 1 / (1 + np.exp(-x))

def sigmoid_derivative(x):
    """The derivative of the Sigmoid function (σ'(z)).
    Used to calculate the local gradient (d(activation)/d(net_input)).
    """
    s = sigmoid(x)
    return s * (1 - s)

# --- 4. Parameter Initialization ---

# Weights and Biases for the Hidden Layer (W1, B1)
# W1 dimensions: (INPUT_DIM, HIDDEN_DIM) -> (2, 4)
W1 = np.random.uniform(size=(INPUT_DIM, HIDDEN_DIM)) * 0.01
B1 = np.zeros((1, HIDDEN_DIM))

# Weights and Biases for the Output Layer (W2, B2)
# W2 dimensions: (HIDDEN_DIM, OUTPUT_DIM) -> (4, 1)
W2 = np.random.uniform(size=(HIDDEN_DIM, OUTPUT_DIM)) * 0.01
B2 = np.zeros((1, OUTPUT_DIM))

# --- 5. Training Loop (Gradient Descent) ---

for epoch in range(EPOCHS):
    
    # ==========================================================
    # A. FORWARD PASS (Calculating the prediction)
    # ==========================================================
    
    # Layer 1 (Hidden Layer)
    # Z1 (Net Input): X * W1 + B1
    Z1 = np.dot(X, W1) + B1
    # A1 (Activation): sigmoid(Z1)
    A1 = sigmoid(Z1)
    
    # Layer 2 (Output Layer)
    # Z2 (Net Input): A1 * W2 + B2
    Z2 = np.dot(A1, W2) + B2
    # A2 (Activation/Prediction): sigmoid(Z2)
    A2 = sigmoid(Z2)
    
    # Calculate Loss (Mean Squared Error) for monitoring
    loss = np.mean(0.5 * (Y - A2)**2)
    
    # ==========================================================
    # B. BACKPROPAGATION (Applying the Chain Rule)
    # ==========================================================
    
    # 1. Calculate the Error Signal (Delta) for the Output Layer (Layer 2)
    # E_out = (A2 - Y) # Derivative of MSE loss w.r.t A2
    # dZ2 (Delta 2): E_out * σ'(Z2)
    # This represents ∂E/∂Z2
    E_out = A2 - Y
    dZ2 = E_out * sigmoid_derivative(Z2) 
    
    # 2. Calculate the Gradient of W2 and B2
    # dW2: ∂E/∂W2 = A1.T @ dZ2
    dW2 = np.dot(A1.T, dZ2)
    # dB2: Sum of dZ2 across samples
    dB2 = np.sum(dZ2, axis=0, keepdims=True)
    
    # 3. Propagate the Error Signal Back to the Hidden Layer (Layer 1)
    # This is the crucial Chain Rule application: ∂E/∂A1 = (∂E/∂Z2) @ W2.T
    # The error from the output layer (dZ2) is weighted by W2 and passed backward.
    E_hidden = np.dot(dZ2, W2.T) 
    
    # 4. Calculate the Error Signal (Delta) for the Hidden Layer (Layer 1)
    # dZ1 (Delta 1): E_hidden * σ'(Z1)
    # This represents ∂E/∂Z1
    dZ1 = E_hidden * sigmoid_derivative(Z1)
    
    # 5. Calculate the Gradient of W1 and B1
    # dW1: ∂E/∂W1 = X.T @ dZ1
    dW1 = np.dot(X.T, dZ1)
    # dB1: Sum of dZ1 across samples
    dB1 = np.sum(dZ1, axis=0, keepdims=True)
    
    # ==========================================================
    # C. PARAMETER UPDATE (Gradient Descent)
    # ==========================================================
    
    W2 -= LEARNING_RATE * dW2
    B2 -= LEARNING_RATE * dB2
    W1 -= LEARNING_RATE * dW1
    B1 -= LEARNING_RATE * dB1
    
    if epoch % 1000 == 0:
        print(f"Epoch {epoch}: Loss = {loss:.6f}")

# --- 6. Final Test and Prediction ---
print("\n--- Training Complete ---")
Z1_test = np.dot(X, W1) + B1
A1_test = sigmoid(Z1_test)
Z2_test = np.dot(A1_test, W2) + B2
A2_test = sigmoid(Z2_test)

predictions = (A2_test > 0.5).astype(int)
print(f"Final Predictions:\n{predictions.flatten()}")
print(f"Targets (Y):\n{Y.flatten()}")

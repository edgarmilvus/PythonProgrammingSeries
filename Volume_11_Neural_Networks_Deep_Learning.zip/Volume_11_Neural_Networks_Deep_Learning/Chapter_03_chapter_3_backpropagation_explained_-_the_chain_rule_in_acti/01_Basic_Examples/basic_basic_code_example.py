
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np

# --- 1. CONFIGURATION ---
# We use a simple scalar input for demonstration.
x_input = 5.0
target_cost = 100.0

print(f"--- STARTING STATE ---")
print(f"Initial Raw Material (x): {x_input}")

# =================================================================
# 2. FORWARD PASS: Calculating the Loss (L)
# The forward pass registers the intermediate values (y, z) needed
# for the backward gradient calculation.
# =================================================================

# Node Y: Production Time Calculation (y = 2x + 1)
# Local calculation: Linear scaling of raw material.
y_production_time = 2.0 * x_input + 1.0
print(f"Intermediate Production Time (y): {y_production_time}")

# Node Z: Manufacturing Cost Calculation (z = y^2)
# Local calculation: Quadratic cost based on time.
z_manufacturing_cost = y_production_time * y_production_time
print(f"Intermediate Manufacturing Cost (z): {z_manufacturing_cost}")

# Node L: Final Error/Loss Calculation (L = z - target)
# The final output, representing the error we wish to minimize.
L_final_error = z_manufacturing_cost - target_cost
print(f"Final Error (L): {L_final_error}\n")

# =================================================================
# 3. BACKWARD PASS: Applying the Chain Rule
# We calculate the gradient dL/dx by moving backward from L to x.
# =================================================================

print(f"--- BACKWARD PASS (GRADIENT CALCULATION) ---")

# --- Step A: Gradient at the Loss Node (dL/dz) ---
# The derivative of L = z - target_cost w.r.t z is 1.
# This is the starting 'upstream gradient' signal.
grad_L_wrt_z = 1.0
print(f"A. Upstream Gradient dL/dz: {grad_L_wrt_z}")

# --- Step B: Gradient through Node Z (dL/dy) ---
# Goal: Calculate dL/dy = (dL/dz) * (dz/dy)

# 1. Local Gradient: dz/dy (Derivative of z = y^2 w.r.t y)
# dz/dy = 2y. We use the stored forward value of y.
dz_wrt_y_local = 2.0 * y_production_time
print(f"   B1. Local Gradient dz/dy (2*y): {dz_wrt_y_local}")

# 2. Chain Rule Application: (Upstream gradient * Local gradient)
grad_L_wrt_y = grad_L_wrt_z * dz_wrt_y_local
print(f"   B2. Propagated Gradient dL/dy: {grad_L_wrt_y}\n")

# --- Step C: Gradient through Node Y (dL/dx) ---
# Goal: Calculate dL/dx = (dL/dy) * (dy/dx)

# 1. Local Gradient: dy/dx (Derivative of y = 2x + 1 w.r.t x)
# dy/dx = 2.0. This derivative is constant and does not depend on x.
dy_wrt_x_local = 2.0
print(f"   C1. Local Gradient dy/dx: {dy_wrt_x_local}")

# 2. Chain Rule Application: (Upstream gradient * Local gradient)
grad_L_wrt_x = grad_L_wrt_y * dy_wrt_x_local
print(f"   C2. Final Propagated Gradient dL/dx: {grad_L_wrt_x}\n")

# --- 4. OPTIMIZATION STEP (Conceptual) ---
# If we were training, we would update x using the gradient:
# x_new = x_input - learning_rate * grad_L_wrt_x
# A negative gradient means increasing x will increase L (Error).
# Since L is positive (121-100=21) and dL/dx is positive (84.0),
# we must decrease x to decrease L.

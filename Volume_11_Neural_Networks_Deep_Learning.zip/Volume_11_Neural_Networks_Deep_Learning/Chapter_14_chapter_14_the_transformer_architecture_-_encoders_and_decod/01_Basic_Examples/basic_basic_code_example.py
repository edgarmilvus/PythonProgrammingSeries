
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import torch
import torch.nn as nn
import math

# --- 1. Positional Encoding Component ---
class PositionalEncoding(nn.Module):
    """
    Injects sinusoidal positional information into the input embeddings.
    This allows the model to understand the order of tokens in the sequence.
    """
    def __init__(self, d_model: int, dropout: float = 0.1, max_len: int = 5000):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)

        # Create a tensor of shape (max_len, d_model) for positional encodings
        pe = torch.zeros(max_len, d_model)
        
        # Create a tensor representing positions (0 to max_len-1)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        
        # Create the division term for the sinusoidal function
        # denominator = 1 / (10000^(2i/d_model))
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        
        # Apply sine to even indices and cosine to odd indices
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        
        # Add a batch dimension (1, max_len, d_model) for easy addition to input
        pe = pe.unsqueeze(0).transpose(0, 1) # Shape: (S, 1, D)
        
        # Register as a buffer: not a parameter, but part of the state
        self.register_buffer('pe', pe)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x shape: (S, B, D) - PyTorch standard for MHA/Transformer inputs
        
        # Add positional encoding to the input, slicing based on sequence length
        x = x + self.pe[:x.size(0), :]
        return self.dropout(x)

# --- 2. The Core Transformer Encoder Layer ---
class SimpleTransformerEncoderLayer(nn.Module):
    """
    A single block combining Multi-Head Self-Attention and a Feed-Forward Network,
    each wrapped in a Residual Connection and Layer Normalization.
    """
    def __init__(self, d_model: int, nhead: int, dim_feedforward: int = 2048, dropout: float = 0.1):
        super().__init__()
        
        # 2.1. Multi-Head Self-Attention (MHA)
        # Note: PyTorch's MHA requires input shape (Sequence Length, Batch Size, D_model)
        self.self_attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout, batch_first=False)
        
        # 2.2. Feed-Forward Network (FFN)
        self.linear1 = nn.Linear(d_model, dim_feedforward)
        self.dropout = nn.Dropout(dropout)
        self.linear2 = nn.Linear(dim_feedforward, d_model)

        # 2.3. Layer Normalization and Dropout for the two sub-layers
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)
        
        self.activation = nn.ReLU() # Standard activation in FFN

    def forward(self, src: torch.Tensor) -> torch.Tensor:
        
        # Input 'src' shape: (S, B, D)
        
        # --- Sub-layer 1: Multi-Head Self-Attention ---
        # Q, K, V are all the source tensor for Self-Attention
        attn_output, _ = self.self_attn(src, src, src)
        
        # 1. Residual Connection: Add input 'src' to the attention output
        # 2. Dropout: Apply dropout to the attention output
        src = src + self.dropout1(attn_output)
        
        # 3. Layer Normalization: Normalize the result
        src = self.norm1(src)
        
        # --- Sub-layer 2: Feed-Forward Network (FFN) ---
        
        # FFN Calculation: Linear -> Activation -> Dropout -> Linear
        ffn_output = self.linear2(self.dropout(self.activation(self.linear1(src))))
        
        # 1. Residual Connection: Add normalized input 'src' to the FFN output
        # 2. Dropout: Apply dropout to the FFN output
        src = src + self.dropout2(ffn_output)
        
        # 3. Layer Normalization: Normalize the final result
        src = self.norm2(src)
        
        return src

# --- 3. Execution and Demonstration ---
if __name__ == '__main__':
    
    # Hyperparameters
    D_MODEL = 512       # Embedding dimension
    N_HEADS = 8         # Number of attention heads
    SEQ_LEN = 10        # Sequence length (e.g., 10 tokens)
    BATCH_SIZE = 4      # Number of sentences in the batch
    
    # 3.1. Simulate input embeddings (e.g., from a word embedding layer)
    # Standard PyTorch input shape for MHA is (S, B, D)
    dummy_input_embeddings = torch.randn(SEQ_LEN, BATCH_SIZE, D_MODEL)
    
    # 3.2. Initialize Positional Encoding and apply it
    pe_layer = PositionalEncoding(D_MODEL)
    input_with_pe = pe_layer(dummy_input_embeddings)
    
    print(f"Input Embeddings Shape: {dummy_input_embeddings.shape}")
    print(f"Shape after Positional Encoding: {input_with_pe.shape}")
    
    # 3.3. Initialize the Encoder Layer
    encoder_layer = SimpleTransformerEncoderLayer(
        d_model=D_MODEL, 
        nhead=N_HEADS, 
        dim_feedforward=2048
    )
    
    # 3.4. Pass the sequence through the single Encoder layer
    output_representation = encoder_layer(input_with_pe)
    
    print(f"\nOutput Contextual Representation Shape: {output_representation.shape}")
    
    # Verify that the output is different from the input (contextualized)
    is_different = not torch.equal(input_with_pe, output_representation)
    print(f"Input and Output are contextually different: {is_different}")
    
    # Example output verification
    # print(f"Sample input token vector (1, 1, :10): {input_with_pe[1, 1, :10]}")
    # print(f"Sample output token vector (1, 1, :10): {output_representation[1, 1, :10]}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np

def get_sinusoidal_pe(max_len: int, d_model: int) -> np.ndarray:
    """
    Generates the Sinusoidal Positional Encoding matrix.

    Args:
        max_len: Maximum sequence length (pos).
        d_model: Dimensionality of the model (must be even).

    Returns:
        A NumPy array of shape (max_len, d_model) containing PE vectors.
    """
    if d_model % 2 != 0:
        raise ValueError("d_model must be an even integer for standard sinusoidal PE.")

    # 1. Create the position matrix (pos)
    # Shape: (max_len, 1)
    position = np.arange(max_len)[:, np.newaxis]

    # 2. Calculate the divisor term (10000^(2i/d_model))
    # i ranges from 0 to d_model/2 - 1. We calculate 2i/d_model.
    # Shape: (d_model / 2,)
    exponent = np.arange(0, d_model, 2) / d_model
    
    # Calculate the frequency divisor base
    div_term = 1.0 / (10000 ** exponent) 
    
    # 3. Calculate the argument for sin/cos (pos / divisor)
    # This calculation uses broadcasting: (max_len, 1) * (1, d_model/2)
    # Shape: (max_len, d_model / 2)
    arguments = position * div_term

    # 4. Initialize the PE matrix
    pe = np.zeros((max_len, d_model))

    # 5. Apply sine to even indices (0, 2, 4, ...)
    pe[:, 0::2] = np.sin(arguments)

    # 6. Apply cosine to odd indices (1, 3, 5, ...)
    # If d_model is odd, this slice might be empty, but we checked for even d_model.
    pe[:, 1::2] = np.cos(arguments)
    
    return pe

# Verification Script
MAX_LEN = 60
D_MODEL = 128
pe_matrix = get_sinusoidal_pe(MAX_LEN, D_MODEL)

print(f"PE Matrix Shape: {pe_matrix.shape}")
print("\nFirst 10 rows of PE matrix:")
print(pe_matrix[:10, :8]) # Print first 8 dimensions for brevity

# Confirm values are bounded between -1 and 1
print(f"\nMin value: {np.min(pe_matrix):.4f}")
print(f"Max value: {np.max(pe_matrix):.4f}")

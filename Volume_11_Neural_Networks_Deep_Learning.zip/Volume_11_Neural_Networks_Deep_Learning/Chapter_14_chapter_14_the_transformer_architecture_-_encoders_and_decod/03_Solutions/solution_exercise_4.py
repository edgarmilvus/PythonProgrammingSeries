
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np

# --- System Constants ---
VOCAB_SIZE = 10000
D_MODEL = 512
MAX_SOURCE_LEN = 50
MAX_TARGET_LEN = 60
START_TOKEN = 1
END_TOKEN = 2
BATCH_SIZE = 1

# --- Placeholder Functions (Conceptual) ---

def simulate_encoder(source_input: np.ndarray) -> np.ndarray:
    """
    Simulates the Encoder output, which is fixed once calculated.
    Input shape: (B, S_L, D_MODEL)
    Output shape: (B, S_L, D_MODEL)
    """
    S_L = source_input.shape[1]
    # Assume the encoder processes the input and returns a rich representation
    print(f"--- 1. ENCODER RUN: Processed source sequence of length {S_L}")
    return np.random.rand(BATCH_SIZE, S_L, D_MODEL)

def create_look_ahead_mask(seq_len: int) -> np.ndarray:
    """Creates the look-ahead mask (upper triangular)."""
    mask = np.triu(np.ones((seq_len, seq_len)), k=1)
    return mask[np.newaxis, np.newaxis, :, :] # Add B, H dimensions for broadcasting

def simulate_decoder_step(target_history: np.ndarray, encoder_output: np.ndarray) -> np.ndarray:
    """
    Simulates a full Decoder forward pass on the current history.
    """
    T_L = target_history.shape[1]
    S_L = encoder_output.shape[1]
    
    # 1. Positional Encoding
    # In a real model, PE would be added here.
    # target_history_pe = target_history + get_sinusoidal_pe(T_L, D_MODEL) 

    # 2. Look-Ahead Mask Creation
    look_ahead_mask = create_look_ahead_mask(T_L)
    
    # Trace Visualization
    print(f"  -> Decoder Input Length (T_L): {T_L}")
    print(f"  -> Look-Ahead Mask Shape: {look_ahead_mask.shape[2:]}")
    
    # 3. Masked Self-Attention: Uses target_history and look_ahead_mask
    # Conceptual: Q, K, V = target_history, target_history, target_history
    
    # 4. Cross-Attention: Q=SelfAttnOutput, K/V=encoder_output
    # The Cross-Attention sequence lengths are (T_L x S_L)
    print(f"  -> Cross-Attention Matrix Size: ({T_L} queries vs {S_L} keys)")
    
    # 5. Final Linear Layer and Softmax (returns logits for the next token)
    # Logits shape: (B, T_L, VOCAB_SIZE)
    # We only care about the last token's prediction: (B, 1, VOCAB_SIZE)
    logits = np.random.rand(BATCH_SIZE, 1, VOCAB_SIZE) 
    
    return logits

def run_inference(source_sequence: np.ndarray):
    
    # 1. Encode the source sequence (fixed output)
    encoder_output = simulate_encoder(source_sequence)
    
    # 2. Start decoding
    # Initialize target sequence with START token (shape: B, 1)
    current_target_sequence = np.array([[START_TOKEN]])
    
    print("\n--- 2. AUTOREGRESSIVE DECODING START ---")
    
    for step in range(1, MAX_TARGET_LEN):
        T_L = current_target_sequence.shape[1]
        
        # Prepare the target history for the full Decoder pass (B, T_L, D_MODEL)
        # This simulates embedding and PE addition
        target_history_embedded = np.random.rand(BATCH_SIZE, T_L, D_MODEL)
        
        # Get logits for the next token (predicting the T_L+1 position)
        next_token_logits = simulate_decoder_step(target_history_embedded, encoder_output)
        
        # Prediction (argmax for simplicity)
        predicted_token = np.argmax(next_token_logits[0, 0, :])
        
        print(f"Step {step}: Predicted token {predicted_token}. New length will be {T_L + 1}.")
        
        if predicted_token == END_TOKEN:
            print("\n[STOP] Predicted END token.")
            break
            
        # Append the new token to the history
        current_target_sequence = np.append(current_target_sequence, [[predicted_token]], axis=1)
        
    return current_target_sequence

# --- Execution ---
# Source sequence (B=1, S_L=40)
source_input_data = np.random.randint(3, VOCAB_SIZE, size=(BATCH_SIZE, 40)) 
run_inference(source_input_data)

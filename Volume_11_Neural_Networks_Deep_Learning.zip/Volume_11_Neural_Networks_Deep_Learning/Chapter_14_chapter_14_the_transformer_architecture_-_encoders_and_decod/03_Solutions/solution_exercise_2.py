
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np

def create_look_ahead_mask(seq_len: int) -> np.ndarray:
    """
    Generates a look-ahead mask (upper triangular matrix).
    Masked positions (upper triangle) are set to a large negative number.
    """
    # np.triu returns the upper triangle of the matrix.
    # k=1 means the diagonal is included in the lower triangle (allowed attention).
    mask = np.triu(np.ones((seq_len, seq_len)), k=1).astype('bool')
    
    # Convert boolean mask to attention score mask
    # True (upper triangle) becomes -1e9 (masked out)
    # False (lower triangle + diagonal) becomes 0 (allowed)
    mask_value = -1e9
    attention_mask = np.where(mask, mask_value, 0.0)
    
    return attention_mask

def softmax(x):
    """Numerically stable softmax implementation."""
    e_x = np.exp(x - np.max(x, axis=-1, keepdims=True))
    return e_x / np.sum(e_x, axis=-1, keepdims=True)

def scaled_dot_product_attention(Q: np.ndarray, K: np.ndarray, V: np.ndarray, mask: np.ndarray = None):
    """
    Calculates Scaled Dot-Product Attention.
    
    Q, K, V typically have shape (..., seq_len, d_k).
    """
    # 1. Infer d_k (dimension of keys)
    d_k = K.shape[-1]
    
    # 2. Calculate raw attention scores (Q * K^T)
    # This involves matrix multiplication across the last two dimensions.
    # scores shape: (..., seq_len_q, seq_len_k)
    scores = np.matmul(Q, K.transpose(0, 1, 3, 2)) # Assuming B, H, T, D structure for simplicity

    # 3. Scale the scores
    scaled_scores = scores / np.sqrt(d_k)

    # 4. Apply the mask (if provided)
    if mask is not None:
        # The mask is broadcasted across batch and head dimensions
        # Masked indices (where mask != 0) will receive a very large negative value
        scaled_scores += mask

    # 5. Apply softmax to get attention weights
    attention_weights = softmax(scaled_scores)

    # 6. Calculate the context vector (Attention Weights * V)
    # context shape: (..., seq_len_q, d_v)
    output = np.matmul(attention_weights, V)

    return output, attention_weights

# --- Verification ---
# Assume batch size B=1, num_heads H=1, sequence length T=5, d_k=4
T = 5
Q_dummy = np.random.rand(1, 1, T, 4)
K_dummy = np.random.rand(1, 1, T, 4)
V_dummy = np.random.rand(1, 1, T, 4)

# Test 1: No Mask (Encoder Self-Attention)
output_enc, weights_enc = scaled_dot_product_attention(Q_dummy, K_dummy, V_dummy)
print(f"Encoder Weights (No Mask):\n{weights_enc[0, 0].round(3)}")

# Test 2: Look-Ahead Mask (Decoder Self-Attention)
look_ahead_mask = create_look_ahead_mask(T)
output_dec, weights_dec = scaled_dot_product_attention(Q_dummy, K_dummy, V_dummy, mask=look_ahead_mask)
print(f"\nLook-Ahead Mask:\n{look_ahead_mask}")
print(f"\nDecoder Weights (Masked):\n{weights_dec[0, 0].round(3)}")
# Expected: Upper triangle (i < j) should be zero or near zero.


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np

# Placeholder for the attention function from Exercise 2 (simplified for conceptual flow)
def single_head_attention(Q, K, V, mask=None):
    # This simulates the attention calculation (scaling, softmax, V multiplication)
    # Q: (B, T_Q, D_K), K: (B, T_K, D_K), V: (B, T_K, D_V)
    
    # Calculate output shape based on Q and V
    B, T_Q, D_K = Q.shape
    _, T_K, D_V = V.shape
    
    # Simulate attention output (B, T_Q, D_V)
    output = np.random.rand(B, T_Q, D_V) 
    return output

class MultiHeadCrossAttention:
    def __init__(self, d_model: int, num_heads: int):
        self.d_model = d_model
        self.num_heads = num_heads
        self.d_k = d_model // num_heads
        
        # 1. Define Projection Layers (simulated by weights)
        # Note: In a real framework, these would be nn.Linear modules.
        # We define them conceptually here to enforce the input mapping.
        self.W_Q = np.random.rand(d_model, d_model) # Decoder State -> Q
        self.W_K = np.random.rand(d_model, d_model) # Encoder Output -> K
        self.W_V = np.random.rand(d_model, d_model) # Encoder Output -> V
        self.W_O = np.random.rand(d_model, d_model) # Concatenated Heads -> Output

    def split_heads(self, x: np.ndarray, batch_size: int) -> np.ndarray:
        """Reshape (B, T, D_model) -> (B, H, T, D_k)"""
        T = x.shape[1]
        x = x.reshape(batch_size, T, self.num_heads, self.d_k)
        return x.transpose(0, 2, 1, 3) # Transpose to (B, H, T, D_k)

    def combine_heads(self, x: np.ndarray, batch_size: int) -> np.ndarray:
        """Reshape (B, H, T, D_k) -> (B, T, D_model)"""
        T = x.shape[2]
        x = x.transpose(0, 2, 1, 3).reshape(batch_size, T, self.d_model)
        return x

    def forward(self, decoder_state: np.ndarray, encoder_output: np.ndarray):
        """
        Calculates Multi-Head Cross-Attention.
        Q comes from decoder_state, K/V come from encoder_output.
        """
        batch_size = decoder_state.shape[0]
        
        # 4. Projection Mapping (D_model -> D_model)
        # Q: (B, T_target, D_model) -> (B, T_target, D_model)
        Q_proj = np.matmul(decoder_state, self.W_Q)
        
        # K, V: (B, T_source, D_model) -> (B, T_source, D_model)
        K_proj = np.matmul(encoder_output, self.W_K)
        V_proj = np.matmul(encoder_output, self.W_V)
        
        # 5. Multi-Head Splitting
        Q_split = self.split_heads(Q_proj, batch_size)
        K_split = self.split_heads(K_proj, batch_size)
        V_split = self.split_heads(V_proj, batch_size)
        
        # Shape Verification Comments:
        # Q_split shape: (B, H, T_target, D_k)
        # K_split shape: (B, H, T_source, D_k)
        # V_split shape: (B, H, T_source, D_k)
        
        # 6. Attention Calculation (using placeholder for Exercise 2 logic)
        # Note: Cross-Attention typically does NOT use a look-ahead mask, 
        # but it DOES use the Encoder Padding Mask (not implemented here for brevity).
        context_per_head = single_head_attention(Q_split, K_split, V_split)
        
        # 7. Concatenation (Combining Heads)
        # context_per_head shape: (B, H, T_target, D_k)
        context_combined = self.combine_heads(context_per_head, batch_size)
        # context_combined shape: (B, T_target, D_model)
        
        # 8. Final Linear Projection (W_O)
        output = np.matmul(context_combined, self.W_O)
        
        return output

# --- Verification ---
B, T_target, T_source = 2, 10, 15
D_MODEL, H = 512, 8

# Input Tensors
dec_state = np.random.rand(B, T_target, D_MODEL) # Q source (shorter/dynamic length)
enc_out = np.random.rand(B, T_source, D_MODEL)   # K/V source (fixed length)

cross_attn = MultiHeadCrossAttention(D_MODEL, H)
output = cross_attn.forward(dec_state, enc_out)

print(f"Decoder State (Q) shape: {dec_state.shape}")
print(f"Encoder Output (K/V) shape: {enc_out.shape}")
print(f"Cross-Attention Output shape: {output.shape}")
# Expected output shape: (B, T_target, D_MODEL)

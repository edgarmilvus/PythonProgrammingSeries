
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np

# Dummy data representing attention weights for 8 heads in a 10-token sentence
DUMMY_ATTENTION_DATA = {
    'sentence': ["The", "cat", "who", "sat", "on", "the", "mat", "is", "mine", "."],
    'weights': np.random.rand(8, 10, 10)
}

# Normalize weights for visualization (ensuring rows sum to 1)
weights_array = DUMMY_ATTENTION_DATA['weights'] / DUMMY_ATTENTION_DATA['weights'].sum(axis=-1, keepdims=True)

def visualize_head_attention(weights_matrix: np.ndarray, sentence: list, query_token: str):
    """
    Visualizes attention patterns for a given query token across all heads,
    handling multiple occurrences of the token interactively.
    """
    
    # 1. Find all occurrences of the query token
    occurrence_indices = [i for i, token in enumerate(sentence) if token == query_token]

    if not occurrence_indices:
        print(f"Error: Token '{query_token}' not found.")
        return

    # 2. Handle ambiguous queries
    if len(occurrence_indices) > 1:
        print(f"\nToken '{query_token}' appears multiple times:")
        for i, idx in enumerate(occurrence_indices):
            print(f"  [{i}]: Instance at sentence index {idx}")
        
        while True:
            try:
                choice = input("Please select the instance index to analyze: ")
                choice_idx = int(choice)
                if 0 <= choice_idx < len(occurrence_indices):
                    query_index = occurrence_indices[choice_idx]
                    break
                else:
                    print("Invalid selection. Please try again.")
            except ValueError:
                print("Invalid input. Please enter a number.")
    else:
        query_index = occurrence_indices[0]

    num_heads = weights_matrix.shape[0]
    
    print(f"\n--- Analyzing Query Token: '{query_token}' at Index {query_index} ---")
    
    # Simulate a query on "who" (index 2) for the interpretation prompt
    if query_token == 'who' and query_index == 2:
        # Manually adjust weights for interpretation demonstration purposes
        # Head 3: Focuses on "cat" (index 1)
        weights_matrix[3, 2, :] = np.array([0.05, 0.70, 0.05, 0.05, 0.05, 0.05, 0.05, 0.00, 0.00, 0.00])
        weights_matrix[3, 2, :] /= np.sum(weights_matrix[3, 2, :])
        
        # Head 6: Focuses on "sat" (index 3)
        weights_matrix[6, 2, :] = np.array([0.05, 0.05, 0.05, 0.70, 0.05, 0.05, 0.05, 0.00, 0.00, 0.00])
        weights_matrix[6, 2, :] /= np.sum(weights_matrix[6, 2, :])


    for head_idx in range(num_heads):
        # Extract the attention row corresponding to the query token
        attention_row = weights_matrix[head_idx, query_index, :]
        
        print(f"\nHead {head_idx}:")
        
        # Display the attention distribution
        display_map = {token: f"{weight:.3f}" for token, weight in zip(sentence, attention_row)}
        print(display_map)
        
        # Interpretation Placeholder based on the simulated weights above
        if query_token == 'who' and query_index == 2:
            if head_idx == 3:
                print("# Interpretation: Syntactic head, linking 'who' back to its antecedent 'cat' (High weight on index 1).")
            if head_idx == 6:
                print("# Interpretation: Local context head, focusing heavily on the following word 'sat' (High weight on index 3).")

# --- Example Execution 1: Single Occurrence Query ---
visualize_head_attention(weights_array, DUMMY_ATTENTION_DATA['sentence'], "mine")

# --- Example Execution 2: Ambiguous Query (Requires user input) ---
# When prompted, the user should enter '0' for the first 'the' (index 0) or '1' for the second 'the' (index 5).
# visualize_head_attention(weights_array, DUMMY_ATTENTION_DATA['sentence'], "the")

# --- Example Execution 3: Interpretation Prompt Query ---
# This query triggers the manual weight assignment for analysis
visualize_head_attention(weights_array, DUMMY_ATTENTION_DATA['sentence'], "who")

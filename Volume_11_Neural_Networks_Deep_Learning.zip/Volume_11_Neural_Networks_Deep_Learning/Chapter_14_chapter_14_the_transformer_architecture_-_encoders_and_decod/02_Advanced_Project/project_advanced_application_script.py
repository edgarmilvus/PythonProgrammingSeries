
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np

# --- 1. Configuration and Hyperparameters ---
# D_MODEL: The embedding dimension size (must be even for simple PE)
D_MODEL = 512
# MAX_LEN: Maximum sequence length
MAX_LEN = 100
# SRC_SEQ_LEN: Length of the source sequence (e.g., function signature)
SRC_SEQ_LEN = 10
# TGT_SEQ_LEN: Length of the target sequence (e.g., docstring)
TGT_SEQ_LEN = 15
# H: Number of attention heads (must divide D_MODEL)
H = 8
# D_K: Dimension of Q/K/V per head
D_K = D_MODEL // H

# --- 2. Core Mechanism: Scaled Dot-Product Attention ---

def scaled_dot_product_attention(Q, K, V, mask=None):
    """
    Computes Attention(Q, K, V) = Softmax(QK^T / sqrt(D_K)) V.
    Q, K, V are tensors, typically of shape (Batch, Heads, Seq_Len, D_K).
    """
    # 1. Calculate the raw attention scores (Q * K transpose)
    # Result shape: (Batch, Heads, Q_Seq_Len, K_Seq_Len)
    attention_scores = np.matmul(Q, K.transpose(0, 1, 3, 2)) / np.sqrt(D_K)

    # 2. Apply masking if provided (essential for Decoder self-attention)
    if mask is not None:
        # Replace masked positions with a very large negative number
        attention_scores = attention_scores + (mask * -1e9)

    # 3. Apply Softmax to get probabilities (attention weights)
    attention_weights = np.exp(attention_scores) / np.sum(np.exp(attention_scores), axis=-1, keepdims=True)

    # 4. Multiply weights by V to get the weighted sum of values
    output = np.matmul(attention_weights, V)
    return output, attention_weights

# --- 3. Positional Encoding (PE) ---

def positional_encoding(seq_len, d_model):
    """Generates the PE matrix using sine and cosine functions."""
    position = np.arange(seq_len)[:, np.newaxis]
    div_term = np.exp(np.arange(0, d_model, 2) * -(np.log(10000.0) / d_model))
    
    pe = np.zeros((seq_len, d_model))
    pe[:, 0::2] = np.sin(position * div_term)
    pe[:, 1::2] = np.cos(position * div_term)
    
    # PE is added to the embedding (shape: Seq_Len, D_Model)
    return pe[np.newaxis, :, :] # Add batch dimension

# --- 4. Mask Generation (Look-Ahead Mask for Decoder) ---

def look_ahead_mask(size):
    """Creates a triangular mask to prevent attending to future tokens."""
    # Creates an upper triangular matrix of ones (where i > j)
    mask = 1 - np.triu(np.ones((size, size)), k=1)
    # Convert 0s to 1s (unmasked) and 1s to 0s (masked)
    return mask

# --- 5. Conceptual Encoder Layer Flow ---

def conceptual_encoder_layer(X_input, W_QKV, W_O):
    """Simulates the flow through a single Encoder layer."""
    # X_input shape: (Batch, SRC_SEQ_LEN, D_MODEL)
    
    # 5a. Calculate Q, K, V (using simplified linear projections W_QKV)
    QKV_projection = np.matmul(X_input, W_QKV) # Shape: (B, S, 3*D_M)
    
    # Split the projection into Q, K, V (simplification: assuming 3 blocks)
    Q, K, V = np.split(QKV_projection, 3, axis=-1)
    
    # Simulate Multi-Head Split and Transpose for Attention (B, H, S, D_K)
    # Note: Real implementation uses complex reshaping. Here we simulate the final attention input shapes.
    Q_att = Q[:, np.newaxis, :, :D_K] # Conceptual shapes for attention function
    K_att = K[:, np.newaxis, :, :D_K]
    V_att = V[:, np.newaxis, :, :D_K]

    # 5b. Self-Attention (No mask needed in Encoder)
    Z_attention, _ = scaled_dot_product_attention(Q_att, K_att, V_att, mask=None)
    
    # 5c. Concatenate heads and project back (W_O) - Simplification
    # Z_attention shape: (B, 1, S, D_K) -> Project back to (B, S, D_MODEL)
    Z_output = Z_attention[:, 0, :, :] # Remove head dimension (conceptually concatenated)
    Z_output = np.matmul(Z_output, W_O) # Final projection (Residual connection omitted for brevity)
    
    # Z_output is the contextualized representation (Encoder's memory)
    return Z_output

# --- 6. Conceptual Decoder Layer Flow ---

def conceptual_decoder_layer(Y_input, Z_encoder, W_QKV_Self, W_Q_Cross, W_KV_Cross, W_O_Self, W_O_Cross):
    """Simulates the flow through a single Decoder layer."""
    
    # 6a. Masked Self-Attention Sublayer (Target sequence attending to itself)
    # Generate the look-ahead mask for the target sequence
    mask = look_ahead_mask(Y_input.shape[1])
    mask = mask[np.newaxis, np.newaxis, :, :] # Add batch and head dimensions
    
    QKV_self = np.matmul(Y_input, W_QKV_Self)
    Q_self, K_self, V_self = np.split(QKV_self, 3, axis=-1)
    
    # Simulate Multi-Head Split
    Q_self_att = Q_self[:, np.newaxis, :, :D_K]
    K_self_att = K_self[:, np.newaxis, :, :D_K]
    V_self_att = V_self[:, np.newaxis, :, :D_K]
    
    Y_masked_att, _ = scaled_dot_product_attention(Q_self_att, K_self_att, V_self_att, mask=mask)
    Y_masked_att = Y_masked_att[:, 0, :, :]
    Y_masked_output = np.matmul(Y_masked_att, W_O_Self) # Output of first sublayer
    
    # 6b. Cross-Attention Sublayer (Y_masked_output queries Z_encoder)
    
    # Q comes from the Decoder's previous output (Y_masked_output)
    Q_cross = np.matmul(Y_masked_output, W_Q_Cross)
    
    # K and V come from the Encoder's final output (Z_encoder)
    KV_cross = np.matmul(Z_encoder, W_KV_Cross)
    K_cross, V_cross = np.split(KV_cross, 2, axis=-1)
    
    # Simulate Multi-Head Split
    Q_cross_att = Q_cross[:, np.newaxis, :, :D_K]
    K_cross_att = K_cross[:, np.newaxis, :, :D_K]
    V_cross_att = V_cross[:, np.newaxis, :, :D_K]
    
    # Cross-Attention: Q_target attends to K_source and V_source
    Y_cross_att, _ = scaled_dot_product_attention(Q_cross_att, K_cross_att, V_cross_att, mask=None)
    
    Y_cross_att = Y_cross_att[:, 0, :, :]
    Y_decoder_output = np.matmul(Y_cross_att, W_O_Cross) # Final projection (before FFN/Normalization)
    
    return Y_decoder_output

# --- 7. Main Execution Flow ---

# Initialize synthetic input embeddings (Batch=1)
# X_input: Embedded function signature
X_input = np.random.randn(1, SRC_SEQ_LEN, D_MODEL).astype(np.float32)
# Y_input: Embedded target docstring (shifted right)
Y_input = np.random.randn(1, TGT_SEQ_LEN, D_MODEL).astype(np.float32)

# Add Positional Encoding
X_input_pe = X_input + positional_encoding(SRC_SEQ_LEN, D_MODEL)
Y_input_pe = Y_input + positional_encoding(TGT_SEQ_LEN, D_MODEL)

# Initialize conceptual weight matrices (simplified projections)
W_QKV_enc = np.random.randn(D_MODEL, D_MODEL * 3).astype(np.float32)
W_O_enc = np.random.randn(D_K, D_MODEL).astype(np.float32)

W_QKV_dec_self = np.random.randn(D_MODEL, D_MODEL * 3).astype(np.float32)
W_O_dec_self = np.random.randn(D_K, D_MODEL).astype(np.float32)

W_Q_dec_cross = np.random.randn(D_MODEL, D_MODEL).astype(np.float32)
W_KV_dec_cross = np.random.randn(D_MODEL, D_MODEL * 2).astype(np.float32)
W_O_dec_cross = np.random.randn(D_K, D_MODEL).astype(np.float32)

print(f"--- Conceptual Transformer Flow Simulation ---")
print(f"Source Sequence Length: {SRC_SEQ_LEN}, Target Sequence Length: {TGT_SEQ_LEN}")
print(f"Embedding Dimension (D_MODEL): {D_MODEL}")
print("-" * 40)

# Step 1: Encoder Stack Processing
Z_encoder_output = conceptual_encoder_layer(X_input_pe, W_QKV_enc, W_O_enc)
print(f"1. Encoder Output (Z): Contextualized source sequence.")
print(f"   Shape: {Z_encoder_output.shape}")

# Step 2: Decoder Stack Processing (using Z_encoder_output)
Y_decoder_output = conceptual_decoder_layer(
    Y_input_pe, 
    Z_encoder_output, 
    W_QKV_dec_self, W_Q_dec_cross, W_KV_dec_cross, 
    W_O_dec_self, W_O_dec_cross
)
print(f"2. Decoder Output (Y): Contextualized target sequence.")
print(f"   Shape: {Y_decoder_output.shape}")

# Step 3: Final Output (Simulated Logits)
# The final layer projects the Decoder output to the vocabulary size (VOCAB_SIZE=5000)
VOCAB_SIZE = 5000
W_final = np.random.randn(D_MODEL, VOCAB_SIZE).astype(np.float32)
final_logits = np.matmul(Y_decoder_output, W_final)

print(f"3. Final Logits Shape (Ready for Softmax/Token Prediction): {final_logits.shape}")



#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import torch
import torch.nn as nn
import numpy as np
import onnxruntime
import os

# 1. Model Definition (Simple CNN)
class SimpleCNN(nn.Module):
    def __init__(self):
        super(SimpleCNN, self).__init__()
        # Simplified feature extractor for 224x224 input
        self.features = nn.Sequential(
            nn.Conv2d(3, 16, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2), # Output size 112x112
            nn.Conv2d(16, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2) # Output size 56x56
        )
        # Flatten layer maps 32 * 56 * 56 to 10 classes
        self.classifier = nn.Sequential(
            nn.Linear(32 * 56 * 56, 10) 
        )

    def forward(self, x):
        x = self.features(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x

# Helper function for ONNX Runtime input preparation
def to_numpy(tensor):
    return tensor.detach().cpu().numpy()

# Setup
model = SimpleCNN()
model.eval()
dummy_input = torch.randn(4, 3, 224, 224) # Batch size 4
onnx_path = "model.onnx"

# 2. PyTorch Baseline Output
with torch.no_grad():
    torch_output = model(dummy_input)
    torch_output_np = to_numpy(torch_output)

# 3. ONNX Export with Dynamic Axes
torch.onnx.export(
    model,
    dummy_input,
    onnx_path,
    export_params=True,
    opset_version=17,
    do_constant_folding=True,
    input_names=['input'],
    output_names=['output'],
    dynamic_axes={
        'input': {0: 'batch_size'},  # Define batch dimension (index 0) as dynamic
        'output': {0: 'batch_size'}
    }
)

print(f"Model successfully exported to {onnx_path}")

# 4. ONNX Runtime Validation
ort_session = onnxruntime.InferenceSession(onnx_path)
# Prepare input: map input name (from ONNX graph) to NumPy data
ort_inputs = {ort_session.get_inputs()[0].name: to_numpy(dummy_input)}
ort_outputs = ort_session.run(None, ort_inputs)
onnx_output_np = ort_outputs[0]

# 5. Verification
print(f"PyTorch Output Shape: {torch_output_np.shape}")
print(f"ONNX Output Shape: {onnx_output_np.shape}")

# Use numpy testing for robust floating-point comparison
try:
    np.testing.assert_allclose(torch_output_np, onnx_output_np, rtol=1e-03, atol=1e-05)
    print("Verification SUCCESS: PyTorch and ONNX outputs match numerically.")
except AssertionError as e:
    print(f"Verification FAILURE: Outputs do not match. Error: {e}")

# Cleanup
os.remove(onnx_path)

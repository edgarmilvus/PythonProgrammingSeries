
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import os
import subprocess
import shlex
import sys

# --- 1. Pythonic setting of Environment Variables ---

# Set maximum allowed request size to 50 megabytes
os.environ['TS_MAX_REQUEST_SIZE'] = '50m'

# Set the global logging level to DEBUG
os.environ['TS_LOG_LEVEL'] = 'DEBUG'

# Define the specific inference listener address (local machine only)
os.environ['TS_INFERENCE_ADDRESS'] = 'http://127.0.0.1:8080'

# Define the management address (restricting external access for security)
os.environ['TS_MANAGEMENT_ADDRESS'] = 'http://127.0.0.1:8081'


# --- 2. Verification Print Statements ---
print("--- Dynamic TorchServe Configuration Settings ---")
print(f"TS_MAX_REQUEST_SIZE set to: {os.environ.get('TS_MAX_REQUEST_SIZE')}")
print(f"TS_LOG_LEVEL set to: {os.environ.get('TS_LOG_LEVEL')}")
print(f"TS_INFERENCE_ADDRESS set to: {os.environ.get('TS_INFERENCE_ADDRESS')}")
print(f"TS_MANAGEMENT_ADDRESS set to: {os.environ.get('TS_MANAGEMENT_ADDRESS')}")
print("--------------------------------------------------")


# --- 3. Simulated TorchServe Execution ---
# We simulate the launch command which will automatically inherit os.environ

DUMMY_MODEL_STORE = "simulated_model_store"
DUMMY_MAR_FILE = "dummy_model.mar" 

# Ensure dummy setup for realistic simulation
os.makedirs(DUMMY_MODEL_STORE, exist_ok=True)
if not os.path.exists(os.path.join(DUMMY_MODEL_STORE, DUMMY_MAR_FILE)):
    with open(os.path.join(DUMMY_MODEL_STORE, DUMMY_MAR_FILE), "w") as f:
        f.write("DUMMY MAR CONTENT")

torchserve_launch_cmd = (
    f"torchserve --start "
    f"--model-store {DUMMY_MODEL_STORE} "
    f"--models {DUMMY_MAR_FILE}"
)

print(f"\nSimulating TorchServe launch command:")
print(torchserve_launch_cmd)

# In a real deployment, this command would be executed:
# subprocess.run(shlex.split(torchserve_launch_cmd), check=True, env=os.environ)

print("\n(If executed, TorchServe would start on 127.0.0.1:8080/8081 with DEBUG logging and 50MB request limit.)")

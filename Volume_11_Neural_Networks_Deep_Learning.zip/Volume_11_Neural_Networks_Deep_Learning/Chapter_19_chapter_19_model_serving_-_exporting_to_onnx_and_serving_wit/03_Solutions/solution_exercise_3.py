
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
import subprocess
import shlex

# --- Setup: Ensure files exist for simulation ---
# (Assuming model.onnx and CustomClassifierHandler.py exist from Ex 1 & 2)
if not os.path.exists("model.onnx"):
    with open("model.onnx", "w") as f: f.write("DUMMY ONNX")
if not os.path.exists("CustomClassifierHandler.py"):
    with open("CustomClassifierHandler.py", "w") as f: f.write("DUMMY HANDLER")
if not os.path.exists("class_mapping.txt"):
    with open("class_mapping.txt", "w") as f: f.write("0: dummy")


# --- 1. Configuration Properties File Content ---
config_content = """
# TorchServe Configuration Properties
# Set inference port to 8085
inference_address=http://0.0.0.0:8085
# Set management port to 8081
management_address=http://0.0.0.0:8081
# Set global inference timeout to 90 seconds
default_response_timeout=90
# Set default concurrency to 6 workers per model
default_workers_per_model=6
"""

config_filename = "config.properties"
with open(config_filename, "w") as f:
    f.write(config_content)

print(f"Created {config_filename} with required configuration.")

# --- 2. MAR File Creation Command ---
model_store_path = "model_store"
os.makedirs(model_store_path, exist_ok=True)

mar_command = (
    f"torch-model-archiver --model-name custom_onnx_classifier "
    f"--version 1.0 "
    f"--handler CustomClassifierHandler.py "
    f"--model-file model.onnx "
    f"--extra-files class_mapping.txt "
    f"--export-path {model_store_path}"
)

print("\n--- MAR Creation Command ---")
print(mar_command)
# Execute this command in CLI to create custom_onnx_classifier.mar


# --- 3. Deployment Simulation Command ---
mar_file_name = "custom_onnx_classifier.mar" 
serve_command = (
    f"torchserve --start "
    f"--model-store {model_store_path} "
    f"--models {mar_file_name} "
    f"--config-file {config_filename}"
)

print("\n--- TorchServe Launch Command (Using Custom Config and 6 Workers) ---")
print(serve_command)
# Execute this command in CLI to launch the server


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Modified CustomClassifierHandler_Advanced.py content
import torch
import torch.nn.functional as F
import torchvision.transforms as T
from ts.torch_handler.base_handler import BaseHandler
from PIL import Image, ImageFile
import io
import os

# Allow PIL to handle truncated files gracefully
ImageFile.LOAD_TRUNCATED_IMAGES = True

class CustomClassifierHandler_Advanced(BaseHandler):
    def __init__(self):
        super(CustomClassifierHandler_Advanced, self).__init__()
        self.transform = None
        self.mapping = {i: f"Class_{i}" for i in range(10)} # Dummy mapping
        self.request_status = [] # Tracks success/failure and tensor index

    def initialize(self, context):
        # ... (Initialization logic remains the same)
        self.transform = T.Compose([
            T.Resize(224), 
            T.ToTensor(),
            T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        super().initialize(context)

    def preprocess(self, data):
        """
        Aggregates requests, handles individual failures, and records status.
        """
        self.request_status = [] # Reset status for the new batch
        successful_tensors = []
        
        for i, row in enumerate(data):
            image_bytes = row.get("data") or row.get("body")
            
            try:
                if not image_bytes:
                    raise ValueError("Input data is empty.")

                # Decode and Transform (Robust Error Handling)
                image = Image.open(io.BytesIO(image_bytes)).convert('RGB')
                tensor = self.transform(image)
                
                # Record success: store the original request index (i) and the index
                # in the *successful* tensors list (len(successful_tensors))
                self.request_status.append({'index': i, 'status': 'success', 'tensor_idx': len(successful_tensors)})
                successful_tensors.append(tensor)
                
            except Exception as e:
                # Record failure: store the original request index and the error message
                error_msg = f"Request {i} failed processing: {type(e).__name__} - {str(e)}"
                print(f"Error processing request {i}: {error_msg}")
                self.request_status.append({'index': i, 'status': 'failure', 'error': error_msg})
        
        if not successful_tensors:
            return [] 
        
        # Batch Aggregation
        return torch.stack(successful_tensors)

    def inference(self, data):
        """Runs inference only on the batched tensor of successful inputs."""
        if len(data) == 0:
            return None # No successful inputs to process
        
        with torch.no_grad():
            output = self.model(data)
        return output

    def postprocess(self, data):
        """
        De-batches successful results and merges them with error responses,
        maintaining the original request order.
        """
        
        # Initialize the final response list based on the original request count
        final_responses = [None] * len(self.request_status)
        
        if data is None:
            # Case: All requests failed in preprocess
            for status in self.request_status:
                 final_responses[status['index']] = {'error': status['error'], 'status_code': 500}
            return final_responses

        # Process successful inference outputs
        probabilities = F.softmax(data, dim=1)
        top_p, top_class = probabilities.topk(5, dim=1)
        
        # Iterate through the status tracker to construct the final response list
        for status in self.request_status:
            original_index = status['index']
            
            if status['status'] == 'failure':
                # Inject the pre-recorded error message
                final_responses[original_index] = {
                    "error": status['error'],
                    "status_code": 500
                }
            else:
                # Extract the corresponding slice from the successful batch output
                tensor_idx = status['tensor_idx']
                
                single_result = []
                for j in range(5):
                    score = top_p[tensor_idx, j].item()
                    class_idx = top_class[tensor_idx, j].item()
                    class_name = self.mapping.get(class_idx, f"Class_{class_idx}")
                    
                    single_result.append({
                        "class_name": class_name,
                        "probability": round(score, 5)
                    })
                
                final_responses[original_index] = single_result
                
        return final_responses

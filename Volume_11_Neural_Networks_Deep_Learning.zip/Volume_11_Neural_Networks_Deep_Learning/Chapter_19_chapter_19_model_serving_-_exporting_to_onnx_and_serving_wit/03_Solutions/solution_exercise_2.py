
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# CustomClassifierHandler.py content
import torch
import torch.nn.functional as F
import torchvision.transforms as T
from ts.torch_handler.base_handler import BaseHandler
from PIL import Image
import io
import os

# --- Helper Setup (Simulating class mapping file) ---
# In a real scenario, this file would be included via --extra-files
class_mapping_content = "0: cat\n1: dog\n2: bird\n3: fish\n4: snake\n5: frog\n6: lion\n7: tiger\n8: bear\n9: wolf\n"
with open("class_mapping.txt", "w") as f:
    f.write(class_mapping_content)
# ----------------------------------------------------

class CustomClassifierHandler(BaseHandler):
    """
    Handles image classification requests, performing decoding,
    standardized transformation, and structured postprocessing.
    """
    def __init__(self):
        super(CustomClassifierHandler, self).__init__()
        self.transform = None
        self.mapping = None
        self.initialized = False

    def initialize(self, context):
        """Loads model, defines transformations, and loads class mappings."""
        properties = context.system_properties
        model_dir = properties.get("model_dir")

        # 1. Define Standard Image Transformations
        self.transform = T.Compose([
            T.Resize(256),
            T.CenterCrop(224),
            T.ToTensor(),
            T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])

        # 2. Load Class Mapping
        mapping_file_path = os.path.join(model_dir, "class_mapping.txt")
        self.mapping = {}
        if os.path.exists(mapping_file_path):
            with open(mapping_file_path, 'r') as f:
                for line in f:
                    try:
                        idx, name = line.strip().split(': ')
                        self.mapping[int(idx)] = name
                    except ValueError:
                        continue
        
        # 3. Load Model (handled by BaseHandler using model_file/model_pt)
        super().initialize(context) 
        self.initialized = True

    def preprocess(self, data):
        """Decodes raw image bytes, applies transforms, and aggregates into a batch."""
        images = []
        for row in data:
            # Extract raw bytes from the request body
            image_bytes = row.get("data") or row.get("body")
            
            # Decode bytes using PIL
            try:
                # Use io.BytesIO to treat bytes as a file, then load and convert to RGB
                image = Image.open(io.BytesIO(image_bytes)).convert('RGB')
            except Exception as e:
                raise RuntimeError(f"Failed to decode image bytes: {e}")

            # Apply transformations and collect
            image_tensor = self.transform(image)
            images.append(image_tensor)
        
        # Aggregate all individual tensors into a single batched tensor
        return torch.stack(images)

    def inference(self, data):
        """Runs inference on the batched tensor."""
        with torch.no_grad():
            output = self.model(data)
        return output

    def postprocess(self, data):
        """Applies softmax, gets top-5, and formats output as a JSON list."""
        
        # Apply Softmax to convert logits to probabilities
        probabilities = F.softmax(data, dim=1)
        
        # Get top 5 predictions (values and indices)
        top_p, top_class = probabilities.topk(5, dim=1)
        
        results = []
        # Iterate over the batch dimension (N requests)
        for i in range(top_p.shape[0]):
            single_result = []
            for j in range(5):
                score = top_p[i, j].item()
                class_idx = top_class[i, j].item()
                class_name = self.mapping.get(class_idx, f"Class_{class_idx}")
                
                single_result.append({
                    "class_index": class_idx,
                    "class_name": class_name,
                    "probability": round(score, 5)
                })
            results.append(single_result)
            
        return results

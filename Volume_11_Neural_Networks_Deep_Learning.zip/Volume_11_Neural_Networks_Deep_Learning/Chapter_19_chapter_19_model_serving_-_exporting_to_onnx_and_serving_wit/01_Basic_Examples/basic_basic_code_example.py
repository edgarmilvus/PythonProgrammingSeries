
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import torch
import torch.nn as nn
import onnx 
import os
import sys
from typing import Dict, Any

# --- Configuration ---
INPUT_SIZE = 10
BATCH_SIZE = 1
MODEL_FILENAME = "simple_classifier.onnx"
OPSET_VERSION = 17 # Recommended stable version

# 1. Define a minimal PyTorch Model (MLP)
class SimpleClassifier(nn.Module):
    """
    A small, two-layer feed-forward network (MLP) for classification demonstration.
    This architecture is simple enough to guarantee easy ONNX conversion.
    """
    def __init__(self):
        super(SimpleClassifier, self).__init__()
        # Layer 1: 10 input features to 5 hidden features
        self.fc1 = nn.Linear(INPUT_SIZE, 5)
        self.relu = nn.ReLU()
        # Layer 2: 5 hidden features to 3 output classes
        self.fc2 = nn.Linear(5, 3)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Defines the sequential computation graph."""
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc2(x)
        return x

def export_model_to_onnx(model: nn.Module, 
                         dummy_input: torch.Tensor, 
                         filename: str, 
                         opset: int, 
                         dynamic_axes: Dict[str, Dict[int, str]]) -> None:
    """Handles the core ONNX export logic."""
    
    input_names = ["input_tensor"]
    output_names = ["output_logits"]

    print(f"Starting ONNX export to {filename} (OpSet v{opset})...")
    
    try:
        # The core function call for tracing and conversion
        torch.onnx.export(
            model,               # The PyTorch model instance to be exported
            dummy_input,         # Sample input data used to trace the computational graph
            filename,            # Destination file path
            verbose=False,       # Set to True to print the traced graph structure
            input_names=input_names,
            output_names=output_names,
            dynamic_axes=dynamic_axes,
            opset_version=opset  # Specifies the version of the ONNX operator set
        )
        print("Export successful.")

    except Exception as e:
        print(f"CRITICAL ERROR during ONNX export: {e}", file=sys.stderr)
        raise

def verify_onnx_model(filename: str) -> None:
    """Verifies the structural integrity of the generated ONNX file."""
    if not os.path.exists(filename):
        print(f"Verification skipped: File {filename} not found.")
        return

    print("Verifying ONNX model integrity using the ONNX checker...")
    try:
        # Load the ONNX model graph structure
        onnx_model = onnx.load(filename)
        # Run the internal consistency checks (e.g., node connectivity, tensor shapes)
        onnx.checker.check_model(onnx_model)
        
        # Report success and file size
        file_size_kb = os.path.getsize(filename) / 1024
        print(f"ONNX model check passed successfully.")
        print(f"Saved file: {filename} ({file_size_kb:.2f} KB)")
        
    except onnx.checker.ValidationError as e:
        print(f"ONNX Model Validation FAILED: {e}", file=sys.stderr)
    except Exception as e:
        print(f"An unexpected error occurred during verification: {e}", file=sys.stderr)

# --- Main Execution Flow ---
if __name__ == "__main__":
    # 2. Instantiate and Prepare the Model
    print("Initializing model...")
    model = SimpleClassifier()
    
    # CRITICAL STEP: Set the model to evaluation mode. 
    # This freezes layers like Dropout and BatchNorm, ensuring deterministic inference.
    model.eval() 

    # 3. Create Dummy Input Data
    # The tracing mechanism requires a sample input tensor.
    # We use requires_grad=True, though gradients are usually stripped during export.
    dummy_input = torch.randn(BATCH_SIZE, INPUT_SIZE, requires_grad=True)
    
    # 4. Define Dynamic Axes
    # Allows the serving environment to handle different batch sizes without re-exporting.
    # Index 0 corresponds to the batch dimension in both input and output tensors.
    dynamic_axes = {
        'input_tensor': {0: 'batch_size'},
        'output_logits': {0: 'batch_size'}
    }

    # 5. Perform Export
    export_model_to_onnx(model, dummy_input, MODEL_FILENAME, OPSET_VERSION, dynamic_axes)
    
    # 6. Verification
    verify_onnx_model(MODEL_FILENAME)
    
    # Cleanup (optional)
    # os.remove(MODEL_FILENAME) 

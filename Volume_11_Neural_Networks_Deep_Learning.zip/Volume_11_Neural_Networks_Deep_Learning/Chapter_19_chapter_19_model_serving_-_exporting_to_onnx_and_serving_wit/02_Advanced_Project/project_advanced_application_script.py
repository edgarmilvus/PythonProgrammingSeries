
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import torch
import torch.nn as nn
import torch.nn.functional as F
import os
import shutil
import numpy as np

# --- Configuration Constants ---
MODEL_NAME = "mnist_classifier"
MODEL_VERSION = "1.0"
ONNX_PATH = f"{MODEL_NAME}.onnx"
HANDLER_FILE = "handler.py"
MAR_OUTPUT_DIR = "model_archive"
EXPORT_DIR = "export_prep"

# 1. Define the PyTorch Model Architecture (A simple CNN for 28x28 grayscale images)
class SimpleClassifier(nn.Module):
    """A small convolutional network designed for 28x28 grayscale images."""
    def __init__(self):
        super().__init__()
        # Input: [1, 28, 28] -> Conv: [10, 24, 24]
        self.conv1 = nn.Conv2d(1, 10, kernel_size=5)
        self.relu1 = nn.ReLU()
        # Pool: [10, 12, 12]
        self.pool1 = nn.MaxPool2d(2)
        # Fully Connected Layer: 10 * 12 * 12 input features -> 10 output classes
        self.fc1 = nn.Linear(10 * 12 * 12, 10) 
        
    def forward(self, x):
        x = self.pool1(self.relu1(self.conv1(x)))
        x = torch.flatten(x, 1) # Flatten all dimensions except batch
        x = self.fc1(x)
        return x

# 2. Initialize Model and Simulate Loading Trained Weights
print(f"[*] Initializing PyTorch model: {MODEL_NAME}")
model = SimpleClassifier()
# Simulate saving and loading weights to ensure the model state is ready
torch.manual_seed(42)
dummy_weights_path = f"{MODEL_NAME}_weights.pth"
torch.save(model.state_dict(), dummy_weights_path)
model.load_state_dict(torch.load(dummy_weights_path))
model.eval() # Crucial: Set model to evaluation mode before export

# 3. Define Dummy Input for Tracing
# Required input shape: (Batch Size, Channels, Height, Width)
dummy_input = torch.randn(1, 1, 28, 28, requires_grad=True)

# 4. Export PyTorch Model to ONNX Format
print(f"[*] Exporting PyTorch model to ONNX format: {ONNX_PATH}")
try:
    torch.onnx.export(
        model,                         # The PyTorch model instance
        dummy_input,                   # Input data used for tracing the computational graph
        ONNX_PATH,                     # Output file path
        export_params=True,            # Include model weights
        opset_version=12,              # Define the ONNX operator set version
        do_constant_folding=True,      # Apply constant folding optimization
        input_names=['input_image'],   # Assign a clear name to the input tensor
        output_names=['output_logits'], # Assign a clear name to the output tensor
        dynamic_axes={                 # Define the batch dimension as dynamic for flexibility
            'input_image': {0: 'batch_size'},
            'output_logits': {0: 'batch_size'}
        }
    )
    print(f"[SUCCESS] ONNX model saved to {ONNX_PATH}")
except Exception as e:
    print(f"[ERROR] Failed to export to ONNX: {e}")
    exit()

# --- 5. Prepare TorchServe Artifacts Directory ---

# Clean up and create the staging directory for the model archiver
if os.path.exists(EXPORT_DIR):
    shutil.rmtree(EXPORT_DIR)
os.makedirs(EXPORT_DIR, exist_ok=True)

# Move the generated ONNX file into the staging directory
shutil.move(ONNX_PATH, os.path.join(EXPORT_DIR, ONNX_PATH))

# 6. Generate the Custom TorchServe Handler Script (handler.py)
# This handler defines how the model should be loaded, preprocessed, inferred, and postprocessed.
HANDLER_CODE = f"""
import torch
import torch.nn.functional as F
import numpy as np
import io
from ts.torch_handler.base_handler import BaseHandler
# NOTE: In a real deployment, you would import the ONNX runtime library here (e.g., onnxruntime)

class ONNXClassifierHandler(BaseHandler):
    def initialize(self, context):
        # Retrieve the model path from the context provided by TorchServe
        properties = context.system_properties
        model_dir = properties.get("model_dir")
        self.onnx_model_path = f"{{model_dir}}/{ONNX_PATH}"
        
        # In deployment, load the ONNX session here: 
        # self.onnx_session = onnxruntime.InferenceSession(self.onnx_model_path)
        self.initialized = True
        print(f"Handler Initialized. ONNX Path: {{self.onnx_model_path}}")

    def preprocess(self, data):
        # Extract data from the request (assuming raw bytes input)
        input_data = data[0].get("body")
        # Convert bytes (representing a flattened float array) back to a tensor (1, 1, 28, 28)
        tensor = torch.from_numpy(np.frombuffer(input_data, dtype=np.float32)).reshape(1, 1, 28, 28)
        return tensor

    def inference(self, input_batch):
        # This function executes the model. 
        # We simulate the output since ONNX runtime cannot be run in this script environment.
        print("Simulating ONNX runtime inference call...")
        # Placeholder output matching the expected (Batch_Size, 10) logits
        output = torch.randn(input_batch.shape[0], 10) 
        return output

    def postprocess(self, inference_output):
        # Convert logits to probabilities and determine the final prediction
        probabilities = F.softmax(inference_output, dim=1)
        predicted_class = torch.argmax(probabilities, dim=1).tolist()
        # Return the result as a list of dictionaries, as expected by TorchServe
        return [{{'prediction': p, 'confidence': round(float(prob[p]), 4)}} for p, prob in zip(predicted_class, probabilities)]

"""
# Write the handler code to the staging directory
handler_output_path = os.path.join(EXPORT_DIR, HANDLER_FILE)
with open(handler_output_path, "w") as f:
    f.write(HANDLER_CODE)
print(f"[SUCCESS] TorchServe handler script written to {handler_output_path}")

# 7. Simulation of Model Archiver Command
# The 'torch-model-archiver' is an external CLI tool that packages the model and handler.
MAR_COMMAND = (
    f"torch-model-archiver --model-name {MODEL_NAME} "
    f"--version {MODEL_VERSION} "
    f"--serialized-file {os.path.join(EXPORT_DIR, ONNX_PATH)} " # The optimized model artifact
    f"--handler {handler_output_path} "
    f"--extra-files {handler_output_path},{os.path.join(EXPORT_DIR, ONNX_PATH)} " # Ensure all dependencies are bundled
    f"--export-path {MAR_OUTPUT_DIR} "
    f"--archive-format default"
)

print("\n--- Model Archiver Preparation Complete ---")
print("Required Directory Structure for Archiving:")
print(f"  {EXPORT_DIR}/")
print(f"    |- {ONNX_PATH} (The optimized ONNX model)")
print(f"    |- {HANDLER_FILE} (The custom inference handler)")
print("\nNext Step: Execute the Model Archiver Utility (External CLI Tool):")
print("This step creates the final deployable .mar file.")
# Print the command formatted for readability in a shell environment
print(f"COMMAND TO RUN: \n{MAR_COMMAND.replace(' --', ' \\\n  --')}")

# Cleanup (remove temporary files)
os.remove(dummy_weights_path)

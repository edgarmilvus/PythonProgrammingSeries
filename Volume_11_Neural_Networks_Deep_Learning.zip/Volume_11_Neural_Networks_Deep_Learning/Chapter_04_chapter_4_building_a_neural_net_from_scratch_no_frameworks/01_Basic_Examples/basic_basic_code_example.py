
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np

# --- 1. Architecture Definition and Input Data ---
INPUT_SIZE = 2      # Features: Exam 1, Exam 2
HIDDEN_SIZE = 3     # Chosen arbitrary size for the hidden layer
OUTPUT_SIZE = 1     # Output: Pass/Fail probability

# Set seed for reproducibility during initialization
np.random.seed(42)

# Input data X (A single student's normalized scores: 85% and 70%)
# Shape must be (M, INPUT_SIZE) -> (1, 2)
X = np.array([[0.85, 0.70]])

# --- 2. Activation Function ---
def sigmoid(Z):
    """The standard logistic sigmoid activation function."""
    # Ensures numerical stability for very large or small inputs
    return 1 / (1 + np.exp(-Z))

# --- 3. Parameter Initialization ---
def initialize_parameters(input_s, hidden_s, output_s):
    """
    Initializes weights randomly (small values) and biases to zero.
    We use the (rows=previous layer size, columns=current layer size) convention.
    """
    # Layer 1: Input (2) -> Hidden (3)
    # W1 shape: (2, 3). Scaled by 0.01 to prevent vanishing/exploding gradients initially.
    W1 = np.random.randn(input_s, hidden_s) * 0.01
    # B1 shape: (1, 3). Bias vector initialized to zeros.
    B1 = np.zeros((1, hidden_s))

    # Layer 2: Hidden (3) -> Output (1)
    # W2 shape: (3, 1).
    W2 = np.random.randn(hidden_s, output_s) * 0.01
    # B2 shape: (1, 1).
    B2 = np.zeros((1, output_s))

    parameters = {
        "W1": W1, "B1": B1,
        "W2": W2, "B2": B2
    }
    return parameters

# --- 4. Forward Propagation Function ---
def forward_propagation(X, parameters):
    """
    Performs the complete forward pass calculation.
    """
    # Unpack parameters for readability
    W1, B1 = parameters["W1"], parameters["B1"]
    W2, B2 = parameters["W2"], parameters["B2"]

    # --- Layer 1: Input to Hidden ---
    # Z1 calculation: X * W1 + B1 (Matrix multiplication and bias addition)
    # (1, 2) @ (2, 3) = (1, 3). Bias (1, 3) is added element-wise.
    Z1 = np.dot(X, W1) + B1
    # Activation A1
    A1 = sigmoid(Z1)

    # --- Layer 2: Hidden to Output ---
    # Z2 calculation: A1 * W2 + B2
    # (1, 3) @ (3, 1) = (1, 1). Bias (1, 1) is added element-wise.
    Z2 = np.dot(A1, W2) + B2
    # Final Activation A2 (The predicted probability)
    A2 = sigmoid(Z2)

    # Cache stores intermediate values (Z and A) needed later for backpropagation
    cache = {"Z1": Z1, "A1": A1, "Z2": Z2, "A2": A2}
    return A2, cache

# --- 5. Execution ---
params = initialize_parameters(INPUT_SIZE, HIDDEN_SIZE, OUTPUT_SIZE)

print("--- Initialized Parameters Shapes ---")
print(f"Input X shape: {X.shape}")
print(f"W1 shape: {params['W1'].shape}, B1 shape: {params['B1'].shape}")
print(f"W2 shape: {params['W2'].shape}, B2 shape: {params['B2'].shape}")

# Run the forward pass
final_output, activation_cache = forward_propagation(X, params)

print("\n--- Forward Pass Results ---")
print(f"A1 (Hidden Layer Activation):\n{activation_cache['A1']}")
print(f"A2 (Final Prediction):\n{final_output}")

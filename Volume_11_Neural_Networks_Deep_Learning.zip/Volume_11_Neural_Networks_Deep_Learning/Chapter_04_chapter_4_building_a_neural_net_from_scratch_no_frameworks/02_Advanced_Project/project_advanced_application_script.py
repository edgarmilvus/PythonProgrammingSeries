
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np

# --- 1. Activation Functions and Derivatives ---

def sigmoid(Z):
    """Calculates the sigmoid activation."""
    return 1 / (1 + np.exp(-Z))

def sigmoid_derivative(A):
    """Calculates the derivative of the sigmoid function."""
    return A * (1 - A)

def relu(Z):
    """Calculates the ReLU activation."""
    return np.maximum(0, Z)

def relu_derivative(Z):
    """Calculates the derivative of the ReLU function (handles Z > 0)."""
    dZ = np.where(Z > 0, 1, 0)
    return dZ

# --- 2. The Core Neural Network Class ---

class FeedForwardNetwork:
    """
    A simple two-layer (one hidden layer) feedforward network 
    implemented entirely with NumPy.
    """
    def __init__(self, input_size, hidden_size, output_size, learning_rate=0.01):
        # Hyperparameters
        self.lr = learning_rate
        self.m = None # Batch size, set during training

        # Initialization using He (for ReLU) and Xavier (for Sigmoid) principles
        # Layer 1: Input (2) -> Hidden (4)
        self.W1 = np.random.randn(hidden_size, input_size) * np.sqrt(2. / input_size)
        self.b1 = np.zeros((hidden_size, 1))

        # Layer 2: Hidden (4) -> Output (1)
        self.W2 = np.random.randn(output_size, hidden_size) * np.sqrt(1. / hidden_size)
        self.b2 = np.zeros((output_size, 1))

        # Cache for forward pass outputs (used in backpropagation)
        self.cache = {}

    def forward(self, X):
        """Performs the forward pass calculation."""
        self.m = X.shape[1] # Set batch size (number of training examples)
        
        # Layer 1: Hidden Layer (ReLU Activation)
        Z1 = np.dot(self.W1, X) + self.b1
        A1 = relu(Z1)

        # Layer 2: Output Layer (Sigmoid Activation for Binary Classification)
        Z2 = np.dot(self.W2, A1) + self.b2
        A2 = sigmoid(Z2)

        # Store intermediate values for backpropagation
        self.cache = {'X': X, 'Z1': Z1, 'A1': A1, 'Z2': Z2, 'A2': A2}
        return A2

    def compute_loss(self, Y_hat, Y):
        """Calculates the Binary Cross-Entropy Loss."""
        # Ensure numerical stability by clipping predictions
        Y_hat = np.clip(Y_hat, 1e-12, 1 - 1e-12) 
        loss = - (1/self.m) * np.sum(Y * np.log(Y_hat) + (1 - Y) * np.log(1 - Y_hat))
        return loss

    def backward(self, Y):
        """
        Performs the backpropagation algorithm to calculate gradients (dW, dB).
        Focuses on applying the Chain Rule layer by layer.
        """
        A2 = self.cache['A2']
        A1 = self.cache['A1']
        X = self.cache['X']
        Z1 = self.cache['Z1']

        # --- Output Layer (L2) Gradient Calculation ---
        
        # dL/dA2 * dA2/dZ2 = dL/dZ2 (Derivative of loss w.r.t Z2)
        # For cross-entropy and sigmoid, dZ2 simplifies greatly:
        dZ2 = A2 - Y 
        
        # dL/dW2 = dL/dZ2 * dZ2/dW2 (Gradient of W2)
        dW2 = (1/self.m) * np.dot(dZ2, A1.T)
        
        # dL/dB2 = dL/dZ2 * dZ2/dB2 (Gradient of B2)
        dB2 = (1/self.m) * np.sum(dZ2, axis=1, keepdims=True)

        # --- Hidden Layer (L1) Gradient Calculation ---
        
        # dL/dA1 = dL/dZ2 * dZ2/dA1 (Error propagated back to A1)
        dA1 = np.dot(self.W2.T, dZ2)
        
        # dL/dZ1 = dL/dA1 * dA1/dZ1 (Derivative of loss w.r.t Z1)
        # dA1/dZ1 is the derivative of the ReLU activation function
        dZ1 = dA1 * relu_derivative(Z1) 
        
        # dL/dW1 (Gradient of W1)
        dW1 = (1/self.m) * np.dot(dZ1, X.T)
        
        # dL/dB1 (Gradient of B1)
        dB1 = (1/self.m) * np.sum(dZ1, axis=1, keepdims=True)

        return {'dW1': dW1, 'dB1': dB1, 'dW2': dW2, 'dB2': dB2}

    def update(self, gradients):
        """Updates weights and biases using Gradient Descent."""
        self.W1 -= self.lr * gradients['dW1']
        self.b1 -= self.lr * gradients['dB1']
        self.W2 -= self.lr * gradients['dW2']
        self.b2 -= self.lr * gradients['dB2']

    def train(self, X, Y, epochs=1000):
        """Main training loop."""
        print(f"Starting training with LR={self.lr} for {epochs} epochs...")
        
        for epoch in range(epochs):
            # 1. Forward Propagation
            Y_hat = self.forward(X)
            
            # 2. Compute Loss
            loss = self.compute_loss(Y_hat, Y)
            
            # 3. Backpropagation (Calculate Gradients)
            gradients = self.backward(Y)
            
            # 4. Update Parameters (Gradient Descent)
            self.update(gradients)
            
            if epoch % (epochs // 10) == 0:
                accuracy = np.mean(np.round(Y_hat) == Y)
                print(f"Epoch {epoch}/{epochs}: Loss={loss:.6f}, Accuracy={accuracy:.4f}")

# --- 3. Data Generation and Execution ---

# Generate synthetic XOR-like data for classification (Requires non-linear separation)
# Inputs are (2 features, 4 examples)
X_data = np.array([[0.1, 0.9, 0.1, 0.9],  # Feature 1 (e.g., Temp Variance)
                   [0.1, 0.1, 0.9, 0.9]]) # Feature 2 (e.g., Pressure Fluctuation)
# Labels (1 if F1 != F2, 0 otherwise)
Y_data = np.array([[0, 1, 1, 0]]) 

# Initialize and Train the Model
INPUT_SIZE = X_data.shape[0]
HIDDEN_SIZE = 4
OUTPUT_SIZE = 1

model = FeedForwardNetwork(INPUT_SIZE, HIDDEN_SIZE, OUTPUT_SIZE, learning_rate=0.2)
model.train(X_data, Y_data, epochs=5000)

# Test the final prediction
final_predictions = model.forward(X_data)
print("\n--- Final Test Predictions ---")
print(f"Input X:\n{X_data}")
print(f"Target Y:\n{Y_data}")
print(f"Predicted Y (Raw):\n{final_predictions}")
print(f"Predicted Y (Rounded):\n{np.round(final_predictions)}")

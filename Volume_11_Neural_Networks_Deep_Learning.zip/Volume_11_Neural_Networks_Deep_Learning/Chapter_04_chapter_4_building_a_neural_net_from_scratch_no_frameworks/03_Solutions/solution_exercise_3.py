
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Assuming access to AL, Y, parameters, and the linear_backward signature from Exercise 2.

def compute_cost(AL, Y, parameters, lambd):
    """
    Computes the cross-entropy cost with L2 regularization penalty.
    """
    m = Y.shape[1]
    
    # 1. Standard Cross-Entropy Cost
    logprobs = np.multiply(np.log(AL), Y) + np.multiply(np.log(1 - AL), 1 - Y)
    cross_entropy_cost = - np.sum(logprobs) / m
    
    # 2. L2 Regularization Cost Term
    L = len(parameters) // 2 # Number of layers
    L2_regularization_cost = 0
    
    for l in range(1, L + 1):
        W = parameters["W" + str(l)]
        # Frobenius norm squared: np.sum(W**2)
        L2_regularization_cost += np.sum(np.square(W))
        
    L2_regularization_cost = (lambd / (2 * m)) * L2_regularization_cost
    
    # 3. Total Cost
    cost = cross_entropy_cost + L2_regularization_cost
    
    return cost

def linear_backward_regularized(dZ, cache, lambd):
    """
    Implements the linear part of the backward propagation, including the 
    L2 regularization term for dW.
    """
    A_prev, W, b = cache
    m = A_prev.shape[1]

    # Standard dW calculation
    dW_standard = 1./m * (dZ @ A_prev.T)
    
    # L2 Regularization term: (lambda / m) * W
    dW_regularization_term = (lambd / m) * W
    
    # Final dW
    dW = dW_standard + dW_regularization_term
    
    # db and dA_prev remain unchanged
    db = 1./m * np.sum(dZ, axis=1, keepdims=True)
    dA_prev = W.T @ dZ
    
    return dA_prev, dW, db

# --- Integration Check (using L=0) ---
# Check cost calculation (lambda=0 should equal standard cost)
# cost_std = compute_cost_standard(AL, Y_test)
# cost_reg_zero = compute_cost(AL, Y_test, parameters, lambd=0)
# print(f"Cost (L=0): {cost_reg_zero}") 

# Check dW calculation (lambda=0 should equal standard dW3)
# dA2_reg, dW3_reg_zero, db3_reg = linear_backward_regularized(dZ3, linear_cache_L, lambd=0)
# print(f"dW3 difference (L=0 vs L_std): {np.sum(np.abs(dW3 - dW3_reg_zero))}") # Should be near 0

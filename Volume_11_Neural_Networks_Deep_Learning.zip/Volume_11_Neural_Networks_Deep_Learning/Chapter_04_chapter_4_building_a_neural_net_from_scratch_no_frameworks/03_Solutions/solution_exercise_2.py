
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Assuming helper functions sigmoid, relu, linear_forward, and L_model_forward 
# from Exercise 1 are available.

def relu_backward(dA, cache):
    """
    Implements the backward propagation for a single ReLU unit.
    cache is Z.
    """
    Z = cache
    dZ = np.array(dA, copy=True) # Ensure dZ has the same shape/type as dA
    
    # When Z <= 0, the derivative is 0
    dZ[Z <= 0] = 0
    
    return dZ

def sigmoid_backward(dA, cache):
    """
    Implements the backward propagation for a single SIGMOID unit.
    cache is Z.
    """
    Z = cache
    
    # Calculate A = sigmoid(Z)
    A = 1 / (1 + np.exp(-Z))
    
    # Derivative of sigmoid: A * (1 - A)
    dZ = dA * A * (1 - A)
    
    return dZ

def linear_backward(dZ, cache):
    """
    Implements the linear part of the backward propagation for a single layer.
    """
    A_prev, W, b = cache
    m = A_prev.shape[1] # Number of examples

    # dW calculation: (1/m) * dZ @ A_prev.T
    dW = 1./m * (dZ @ A_prev.T)
    
    # db calculation: (1/m) * sum(dZ across examples)
    db = 1./m * np.sum(dZ, axis=1, keepdims=True)
    
    # dA_prev calculation: W.T @ dZ
    dA_prev = W.T @ dZ
    
    return dA_prev, dW, db

# --- Testing the Functions ---
# We need a cost function to generate the initial dA[L]
def compute_cost_standard(AL, Y):
    m = Y.shape[1]
    # Compute cross-entropy loss
    cost = (-1/m) * np.sum(Y * np.log(AL) + (1 - Y) * np.log(1 - AL))
    cost = np.squeeze(cost)
    return cost

# Dummy data for backprop test
np.random.seed(1)
X_test = np.random.randn(2, 5)
Y_test = np.array([[0, 1, 0, 1, 0]])
layer_dims = [2, 4, 3, 1]
parameters = initialize_parameters_deep(layer_dims)
AL, caches = L_model_forward(X_test, parameters)

# Initial gradient dAL (derivative of cost w.r.t. AL)
dAL = - (np.divide(Y_test, AL) - np.divide(1 - Y_test, 1 - AL))

# Backprop for the output layer (L=3, Sigmoid)
linear_cache_L, activation_cache_L = caches[2]
dZ3 = sigmoid_backward(dAL, activation_cache_L)
dA2, dW3, db3 = linear_backward(dZ3, linear_cache_L)

# print(f"Shape of dW3: {dW3.shape}") # Expected: (1, 3)

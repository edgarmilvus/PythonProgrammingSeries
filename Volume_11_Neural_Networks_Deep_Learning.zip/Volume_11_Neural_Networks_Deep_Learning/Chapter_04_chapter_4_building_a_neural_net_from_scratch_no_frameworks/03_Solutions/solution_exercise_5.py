
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# --- Leaky ReLU Implementation ---

def leaky_relu(Z, alpha=0.01):
    """Leaky ReLU activation function."""
    # If Z > 0, return Z. If Z <= 0, return alpha * Z
    A = np.where(Z > 0, Z, alpha * Z)
    return A, Z

def leaky_relu_backward(dA, cache, alpha=0.01):
    """
    Implements the backward propagation for a single Leaky ReLU unit.
    cache is Z.
    """
    Z = cache
    dZ = np.array(dA, copy=True)
    
    # Create the derivative mask
    dZ_mask = np.ones_like(Z)
    dZ_mask[Z <= 0] = alpha # Gradient is alpha for Z <= 0
    
    dZ = dZ * dZ_mask
    return dZ

# --- Modified Forward and Backward Propagation for Leaky ReLU ---

def L_model_forward_leaky(X, parameters):
    caches = []
    A = X
    L = len(parameters) // 2 

    # Hidden layers using Leaky ReLU
    for l in range(1, L):
        A_prev = A 
        W = parameters['W' + str(l)]
        b = parameters['b' + str(l)]
        Z, linear_cache = linear_forward(A_prev, W, b)
        A, activation_cache = leaky_relu(Z) # <--- Using Leaky ReLU
        caches.append((linear_cache, activation_cache))

    # Output layer (L) using Sigmoid
    W = parameters['W' + str(L)]
    b = parameters['b' + str(L)]
    Z, linear_cache = linear_forward(A, W, b)
    AL, activation_cache = sigmoid(Z)
    caches.append((linear_cache, activation_cache))
    
    return AL, caches

def linear_activation_backward_leaky(dA, cache, activation, lambd=0):
    """Combines linear and activation backward steps, supporting Leaky ReLU."""
    linear_cache, activation_cache = cache
    
    if activation == "leaky_relu":
        dZ = leaky_relu_backward(dA, activation_cache) # <--- Using Leaky ReLU Backward
    elif activation == "sigmoid":
        dZ = sigmoid_backward(dA, activation_cache)
    else: # Fallback for standard ReLU if needed, but not used here
        dZ = relu_backward(dA, activation_cache) 
    
    dA_prev, dW, db = linear_backward_regularized(dZ, linear_cache, lambd)
    return dA_prev, dW, db

def L_model_backward_leaky(AL, Y, caches, lambd=0):
    """
    Implements backward propagation using Leaky ReLU for hidden layers.
    """
    grads = {}
    L = len(caches) 
    Y = Y.reshape(AL.shape)

    dAL = - (np.divide(Y, AL) - np.divide(1 - Y, 1 - AL))
    
    # Lth layer (SIGMOID -> LINEAR backward)
    current_cache = caches[L-1]
    dA_prev, dW, db = linear_activation_backward_leaky(dAL, current_cache, activation="sigmoid", lambd=lambd)
    grads["dW" + str(L)] = dW
    grads["db" + str(L)] = db
    
    # Loop from L-1 down to 1 (LEAKY_RELU -> LINEAR backward)
    for l in reversed(range(L - 1)):
        current_cache = caches[l]
        # Pass the gradient dA_prev from the subsequent layer
        dA_prev, dW, db = linear_activation_backward_leaky(dA_prev, current_cache, activation="leaky_relu", lambd=lambd)
        grads["dW" + str(l + 1)] = dW
        grads["db" + str(l + 1)] = db
        
    return grads

# --- Training Function for Leaky ReLU Model ---
def L_model_train_leaky(X, Y, layer_dims, learning_rate=0.0075, num_iterations=2500, print_cost=True, lambd=0):
    costs = []
    np.random.seed(1) # Use the same seed for fair comparison
    parameters = initialize_parameters_deep(layer_dims)

    for i in range(0, num_iterations):
        AL, caches = L_model_forward_leaky(X, parameters) # Leaky Forward
        cost = compute_cost(AL, Y, parameters, lambd=lambd)
        grads = L_model_backward_leaky(AL, Y, caches, lambd=lambd) # Leaky Backward
        parameters = update_parameters(parameters, grads, learning_rate)
        
        if i % 100 == 0 or i == num_iterations - 1:
            costs.append(cost)
            
    return parameters, costs

# --- Interactive Comparison ---
import matplotlib.pyplot as plt

# Dataset from Ex 4
np.random.seed(1)
X_train = np.random.randn(2, 100)
Y_train = (X_train[0, :] + X_train[1, :] > 0.5).astype(int).reshape(1, 100)
layer_dims = [2, 4, 3, 1]

# 1. Train Standard ReLU Model (Need to re-initialize for fair test)
np.random.seed(1)
_, costs_relu = L_model_train(X_train, Y_train, layer_dims, num_iterations=2500, print_cost=False)

# 2. Train Leaky ReLU Model
_, costs_leaky_relu = L_model_train_leaky(X_train, Y_train, layer_dims, num_iterations=2500, print_cost=False)

# Plotting the results
iterations = [i * 100 for i in range(len(costs_relu))]

plt.figure(figsize=(10, 6))
plt.plot(iterations, costs_relu, label='Standard ReLU Cost')
plt.plot(iterations, costs_leaky_relu, label='Leaky ReLU (alpha=0.01) Cost')
plt.xlabel('Iterations (x100)')
plt.ylabel('Cost')
plt.title('Convergence Comparison: ReLU vs. Leaky ReLU')
plt.legend()
plt.grid(True)
plt.show() # Display plot (or save if running in a non-interactive environment)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# --- Required Helper Functions for the Training Loop ---
def linear_activation_backward(dA, cache, activation, lambd=0):
    """Combines linear and activation backward steps."""
    linear_cache, activation_cache = cache
    
    if activation == "relu":
        dZ = relu_backward(dA, activation_cache)
    elif activation == "sigmoid":
        dZ = sigmoid_backward(dA, activation_cache)
    
    # Use the regularized linear backward function
    dA_prev, dW, db = linear_backward_regularized(dZ, linear_cache, lambd)
    return dA_prev, dW, db

def L_model_backward(AL, Y, caches, lambd=0):
    """
    Implements the backward propagation for the entire L-layer network.
    """
    grads = {}
    L = len(caches) 
    Y = Y.reshape(AL.shape) # Ensure Y and AL have same shape

    # Initial gradient dAL (derivative of cost w.r.t. AL)
    dAL = - (np.divide(Y, AL) - np.divide(1 - Y, 1 - AL))
    
    # Lth layer (SIGMOID -> LINEAR backward)
    current_cache = caches[L-1]
    dA_prev, dW, db = linear_activation_backward(dAL, current_cache, activation="sigmoid", lambd=lambd)
    grads["dA" + str(L-1)] = dA_prev
    grads["dW" + str(L)] = dW
    grads["db" + str(L)] = db
    
    # Loop from L-1 down to 1 (RELU -> LINEAR backward)
    for l in reversed(range(L - 1)):
        current_cache = caches[l]
        dA_prev, dW, db = linear_activation_backward(dA_prev, current_cache, activation="relu", lambd=lambd)
        grads["dA" + str(l)] = dA_prev
        grads["dW" + str(l + 1)] = dW
        grads["db" + str(l + 1)] = db

    return grads
# --------------------------------------------------------

def update_parameters(parameters, grads, learning_rate):
    """
    Updates parameters using the Gradient Descent update rule.
    """
    L = len(parameters) // 2 # Number of layers
    
    for l in range(1, L + 1):
        parameters["W" + str(l)] -= learning_rate * grads["dW" + str(l)]
        parameters["b" + str(l)] -= learning_rate * grads["db" + str(l)]
    
    return parameters

def L_model_train(X, Y, layer_dims, learning_rate=0.0075, num_iterations=2500, print_cost=True, lambd=0):
    """
    Implements the L-layer neural network training loop.
    """
    costs = []
    
    # 1. Parameter initialization
    parameters = initialize_parameters_deep(layer_dims)

    # 2. Gradient Descent Loop
    for i in range(0, num_iterations):
        
        # a. Forward Propagation
        AL, caches = L_model_forward(X, parameters)
        
        # b. Calculate Cost (using L2 regularization parameter)
        cost = compute_cost(AL, Y, parameters, lambd=lambd)
        
        # c. Backward Propagation (using L2 regularization parameter)
        grads = L_model_backward(AL, Y, caches, lambd=lambd)
        
        # d. Update Parameters
        parameters = update_parameters(parameters, grads, learning_rate)
        
        # Record and print cost
        if print_cost and i % 100 == 0 or i == num_iterations - 1:
            if print_cost:
                print(f"Cost after iteration {i}: {cost:.4f}")
            costs.append(cost)
            
    return parameters, costs

# --- Testing the Loop (Synthetic Data) ---
np.random.seed(1)
# X: 2 features, 100 examples
X_train = np.random.randn(2, 100)
# Y: Simple classification boundary
Y_train = (X_train[0, :] + X_train[1, :] > 0.5).astype(int).reshape(1, 100)

layer_dims = [2, 4, 3, 1]
# Train the model (using lambda=0 for standard GD)
final_parameters, costs = L_model_train(
    X_train, Y_train, layer_dims, 
    learning_rate=0.0075, 
    num_iterations=2500, 
    print_cost=True,
    lambd=0
)

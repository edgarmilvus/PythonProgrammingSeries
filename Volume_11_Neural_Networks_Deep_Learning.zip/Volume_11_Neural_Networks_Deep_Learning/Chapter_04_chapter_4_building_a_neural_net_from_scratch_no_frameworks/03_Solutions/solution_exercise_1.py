
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np

# --- Helper Activation Functions ---
def sigmoid(Z):
    """Sigmoid activation function."""
    A = 1 / (1 + np.exp(-Z))
    return A, Z

def relu(Z):
    """ReLU activation function."""
    A = np.maximum(0, Z)
    return A, Z
# -----------------------------------

def initialize_parameters_deep(layer_dims):
    """
    Initializes parameters W and b for an L-layer neural network
    using scaled random initialization (Xavier approximation).
    """
    parameters = {}
    L = len(layer_dims) # number of layers including input

    for l in range(1, L):
        # W[l] dimensions: (n[l], n[l-1])
        # Initialization scaled by 1/sqrt(n[l-1])
        scale = 1 / np.sqrt(layer_dims[l-1])
        parameters['W' + str(l)] = np.random.randn(layer_dims[l], layer_dims[l-1]) * scale
        
        # b[l] dimensions: (n[l], 1)
        parameters['b' + str(l)] = np.zeros((layer_dims[l], 1))
        
        assert(parameters['W' + str(l)].shape == (layer_dims[l], layer_dims[l-1]))
        assert(parameters['b' + str(l)].shape == (layer_dims[l], 1))

    return parameters

def linear_forward(A_prev, W, b):
    """
    Implements the linear part of a layer's forward propagation.
    Z = W * A_prev + b
    """
    Z = W @ A_prev + b
    
    # Store A_prev, W, b for backpropagation
    cache = (A_prev, W, b)
    return Z, cache

def L_model_forward(X, parameters):
    """
    Implements the forward propagation for the [LINEAR->RELU]*(L-1) -> LINEAR->SIGMOID model.
    """
    caches = []
    A = X
    L = len(parameters) // 2 # Number of layers

    # Loop through L-1 hidden layers using ReLU
    for l in range(1, L):
        A_prev = A 
        W = parameters['W' + str(l)]
        b = parameters['b' + str(l)]
        
        # Linear step
        Z, linear_cache = linear_forward(A_prev, W, b)
        
        # Activation step (ReLU)
        A, activation_cache = relu(Z)
        
        # Cache stores ((A_prev, W, b), Z) for the current layer l
        caches.append((linear_cache, activation_cache))

    # Output layer (L) using Sigmoid
    W = parameters['W' + str(L)]
    b = parameters['b' + str(L)]
    Z, linear_cache = linear_forward(A, W, b)
    AL, activation_cache = sigmoid(Z)
    
    caches.append((linear_cache, activation_cache))
    
    return AL, caches

# --- Testing the Functions ---
# Dummy data: 2 features, 5 examples
X_test = np.random.randn(2, 5)
layer_dims = [2, 4, 3, 1]
parameters = initialize_parameters_deep(layer_dims)
AL, caches = L_model_forward(X_test, parameters)

# print(f"Output shape AL: {AL.shape}") # Expected: (1, 5)
# print(f"Number of caches: {len(caches)}") # Expected: 3

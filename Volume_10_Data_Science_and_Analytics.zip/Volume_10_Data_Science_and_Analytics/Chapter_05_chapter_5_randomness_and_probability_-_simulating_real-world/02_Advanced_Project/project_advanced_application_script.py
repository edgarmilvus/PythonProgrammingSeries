
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
from typing import Dict, Any

# --- 1. Simulation Setup and Parameters ---
def setup_inventory_params() -> Dict[str, Any]:
    """Defines the fixed parameters for the inventory risk simulation."""
    # A high number of runs ensures the Law of Large Numbers applies, providing a stable estimate.
    return {
        "SIMULATION_RUNS": 100000,      # Total iterations for the Monte Carlo analysis
        "REORDER_POINT": 350,           # The current safety stock level (units available when order is placed)
        
        # Daily Demand Model (Normal Distribution)
        "DAILY_DEMAND_MEAN": 50,        # Average units sold per day (mu)
        "DAILY_DEMAND_STD": 10,         # Standard deviation of daily sales (sigma)
        
        # Lead Time Model (Discrete Uniform Distribution)
        "LEAD_TIME_MIN": 5,             # Minimum days for delivery
        "LEAD_TIME_MAX": 10,            # Maximum days for delivery
    }

# --- 2. Core Simulation Function ---
def run_monte_carlo_inventory_risk(params: Dict[str, Any]) -> tuple[float, float, float, np.ndarray]:
    """
    Performs the Monte Carlo simulation to estimate stockout probability by
    combining random samples of lead time and daily demand.
    """
    runs = params["SIMULATION_RUNS"]
    reorder_point = params["REORDER_POINT"]
    demand_mu = params["DAILY_DEMAND_MEAN"]
    demand_sigma = params["DAILY_DEMAND_STD"]
    lt_min = params["LEAD_TIME_MIN"]
    lt_max = params["LEAD_TIME_MAX"]

    stockout_count = 0
    # Pre-allocate array to store the total demand result of each run
    total_demand_samples = np.zeros(runs) 

    for i in range(runs):
        # 1. Sample the Lead Time (L)
        # Uses a discrete uniform distribution to determine how many days the wait will be.
        # np.random.randint is exclusive of the high value, so we use lt_max + 1
        lead_time_days = np.random.randint(lt_min, lt_max + 1)

        # 2. Sample Daily Demand for the entire lead time period (L samples)
        # Demand is modeled using a Normal distribution (sales volume is continuous).
        daily_demand = np.random.normal(loc=demand_mu, scale=demand_sigma, size=lead_time_days)

        # Apply a physical constraint: demand cannot be negative
        daily_demand[daily_demand < 0] = 0

        # 3. Calculate Total Demand during the sampled lead time
        total_demand = np.sum(daily_demand)
        total_demand_samples[i] = total_demand

        # 4. Check for Stockout Event
        # A stockout occurs if total demand exceeds the inventory available (Reorder Point)
        if total_demand > reorder_point:
            stockout_count += 1

    # --- 5. Calculation and Uncertainty Quantification ---
    stockout_probability = stockout_count / runs

    # Calculate standard error (SE) for the proportion (p) estimate
    # SE = sqrt( p * (1-p) / N )
    std_error = np.sqrt(stockout_probability * (1 - stockout_probability) / runs)

    # Calculate 95% Confidence Interval (using Z=1.96 for a standard normal distribution)
    margin_of_error = 1.96 * std_error
    ci_lower = stockout_probability - margin_of_error
    ci_upper = stockout_probability + margin_of_error
    
    return stockout_probability, ci_lower, ci_upper, total_demand_samples

# --- 3. Reporting and Analysis ---
def generate_report(params: Dict[str, Any], prob: float, ci_l: float, ci_u: float, demand_samples: np.ndarray):
    """Prints the simulation results and analyzes the resulting demand distribution."""
    
    print("\n" + "=" * 60)
    print("INVENTORY RISK MONTE CARLO SIMULATION")
    print("=" * 60)
    print(f"Parameters: Reorder Point={params['REORDER_POINT']} | Daily Demand ~ N({params['DAILY_DEMAND_MEAN']}, {params['DAILY_DEMAND_STD']})")
    print(f"Lead Time ~ Uniform({params['LEAD_TIME_MIN']} to {params['LEAD_TIME_MAX']} days)")
    print(f"Total Simulations Run: {len(demand_samples):,}")
    print("-" * 60)

    # 1. Risk Quantification
    print("RISK ESTIMATION (P(Stockout))")
    print(f"  Estimated Stockout Probability: {prob:.4f} ({prob*100:.2f}%)")
    print(f"  95% Confidence Interval: [{ci_l:.4f}, {ci_u:.4f}]")
    print("-" * 60)

    # 2. Demand Distribution Analysis
    demand_mean = np.mean(demand_samples)
    demand_std = np.std(demand_samples)
    
    # Calculate key safety stock metrics based on percentiles
    demand_p90 = np.percentile(demand_samples, 90)
    demand_p95 = np.percentile(demand_samples, 95)
    demand_p99 = np.percentile(demand_samples, 99)

    print("SIMULATED TOTAL DEMAND DISTRIBUTION ANALYSIS")
    print(f"  Mean Total Demand during Lead Time: {demand_mean:.2f} units")
    print(f"  Std Dev of Total Demand: {demand_std:.2f} units")
    print("\n  Recommended Safety Stock Levels (Service Level):")
    print(f"    90% Service Level (P90): {demand_p90:.0f} units")
    print(f"    95% Service Level (P95): {demand_p95:.0f} units (Current Reorder Point is {params['REORDER_POINT']})")
    print(f"    99% Service Level (P99): {demand_p99:.0f} units")
    print("-" * 60)


# --- 4. Main Execution ---
if __name__ == "__main__":
    params = setup_inventory_params()
    
    # Run the simulation and unpack results
    prob, ci_l, ci_u, demand_samples = run_monte_carlo_inventory_risk(params)
    
    # Generate the final report
    generate_report(params, prob, ci_l, ci_u, demand_samples)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import binom

def simulate_defect_batches():
    n = 200     # Batch size (trials)
    p = 0.045   # Defect probability (success probability)
    R = 50000   # Number of Monte Carlo replications (batches)
    threshold = 15

    # 1. & 2. Simulate R batches using numpy's Binomial sampler
    defect_counts = np.random.binomial(n, p, R)

    # 3. Calculate Theoretical PMF
    k_values = np.arange(n + 1)
    theoretical_pmf = binom.pmf(k_values, n, p)

    # 4. Visualization (Empirical vs. Theoretical)
    plt.figure(figsize=(10, 6))
    
    # Plot empirical results (normalized to density)
    plt.hist(defect_counts, bins=np.arange(defect_counts.max() + 2) - 0.5, 
             density=True, alpha=0.6, color='teal', label='Empirical Simulation (Density)')
    
    # Overlay theoretical PMF (using line plot for clarity against discrete bars)
    plt.plot(k_values, theoretical_pmf, 'ro', markersize=4, label='Theoretical PMF')
    
    plt.title(f'Distribution of Defects (Binomial n={n}, p={p})')
    plt.xlabel('Number of Defects (k)')
    plt.ylabel('Probability / Density')
    plt.xlim(0, 20) # Focus on the relevant range
    plt.legend()
    plt.grid(axis='y', alpha=0.5)
    plt.show()

    # 5. Risk Quantification (P(X >= 15))
    
    # Empirical count of batches with 15 or more defects
    empirical_violations = np.sum(defect_counts >= threshold)
    empirical_prob_15_plus = empirical_violations / R
    
    # Theoretical calculation: 1 - CDF(14)
    # CDF(14) is the probability of 14 or fewer successes
    theoretical_prob_15_plus = 1 - binom.cdf(threshold - 1, n, p)

    print(f"--- Risk Quantification (P(X >= 15)) ---")
    print(f"Empirical P(X >= {threshold}): {empirical_prob_15_plus:.6f}")
    print(f"Theoretical P(X >= {threshold}): {theoretical_prob_15_plus:.6f}")
    print(f"Difference: {abs(empirical_prob_15_plus - theoretical_prob_15_plus):.6e}")

simulate_defect_batches()

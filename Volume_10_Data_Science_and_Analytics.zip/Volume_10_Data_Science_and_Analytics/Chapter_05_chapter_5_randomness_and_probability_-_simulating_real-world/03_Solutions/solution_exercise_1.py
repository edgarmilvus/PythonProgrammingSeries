
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm

def analyze_uniformity_and_clt():
    N = 100000  # Total samples for uniformity check
    M = 10000   # Number of trials for CLT demonstration
    k = 5       # Number of uniform samples summed per trial

    # 1. Generate Uniform Samples (U(0, 1))
    uniform_samples = np.random.rand(N)

    # 2. Plot Histogram I (Uniformity)
    plt.figure(figsize=(12, 5))
    plt.subplot(1, 2, 1)
    plt.hist(uniform_samples, bins=50, color='skyblue', edgecolor='black', density=True)
    plt.title(f'1. Uniformity Check (N={N} Samples)')
    plt.xlabel('Value')
    plt.ylabel('Density')
    plt.ylim(0, 1.2)
    plt.grid(axis='y', alpha=0.5)

    # 3. CLT Simulation: Generate sums of k uniform samples
    # Generate M sets of k uniform samples and sum them along the axis=1
    uniform_sets = np.random.rand(M, k)
    sums_of_k_samples = np.sum(uniform_sets, axis=1)

    # 4. Plot Histogram II (CLT Demonstration)
    plt.subplot(1, 2, 2)
    # Determine bin width for scaling the theoretical PDF
    hist_counts, bin_edges, _ = plt.hist(sums_of_k_samples, bins=40, color='lightcoral', 
                                         edgecolor='black', density=True, label='Empirical Sums')
    bin_width = bin_edges[1] - bin_edges[0]
    
    # 5. Calculate theoretical parameters and overlay Normal curve
    # Theoretical mean of U(0, 1) is 0.5
    # Theoretical variance of U(0, 1) is 1/12
    mu_sum = k * 0.5
    sigma_sum = np.sqrt(k * (1/12))
    
    x_axis = np.linspace(sums_of_k_samples.min(), sums_of_k_samples.max(), 100)
    pdf_curve = norm.pdf(x_axis, mu_sum, sigma_sum)
    
    plt.plot(x_axis, pdf_curve, 'b-', linewidth=2, label=f'Theoretical Normal (μ={mu_sum:.2f}, σ={sigma_sum:.2f})')
    
    plt.title(f'2. Central Limit Theorem (Sum of k={k} Uniform Samples)')
    plt.xlabel('Sum Value')
    plt.ylabel('Density')
    plt.legend()
    plt.tight_layout()
    plt.show()
    
    # Print calculated means and standard deviations
    print(f"Mean of Uniform Samples: {np.mean(uniform_samples):.4f}")
    print(f"Mean of Sums (Empirical): {np.mean(sums_of_k_samples):.4f}")
    print(f"Mean of Sums (Theoretical): {mu_sum:.4f}")

analyze_uniformity_and_clt()

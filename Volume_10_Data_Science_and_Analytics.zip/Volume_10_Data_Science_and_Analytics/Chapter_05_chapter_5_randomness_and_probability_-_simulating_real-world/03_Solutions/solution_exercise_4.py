
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np
import matplotlib.pyplot as plt

# Fixed simulation parameters (standard inventory model setup)
Q = 100         # Reorder Quantity
ROP = 50        # Reorder Point
COST_ORDER = 100
COST_HOLD = 1
COST_SHORT = 10
MU_DEMAND = 10  # Poisson demand mean
DAYS = 365

# Parameters for the stochastic lead time
MU_LEAD_TIME = 7
SIGMA_LEAD_TIME = 1.5
R_REPLICATIONS = 1000

def get_stochastic_lead_time(mu, sigma):
    # 1. Implement sampling from Normal distribution
    sampled_time = np.random.normal(mu, sigma)
    
    # 1. Implement truncation (min 1 day) and rounding
    # Ensure time is a positive integer
    return int(max(1, np.round(sampled_time)))

def run_modified_inventory_simulation(days, mu_lt, sigma_lt):
    # Initial State
    inventory_level = ROP + Q  # Start with a buffer
    orders_pending = 0
    time_till_arrival = 0
    
    total_ordering_cost = 0
    total_holding_cost = 0
    total_shortage_cost = 0
    
    for day in range(days):
        # 1. Daily Demand (Poisson distribution)
        daily_demand = np.random.poisson(MU_DEMAND)
        
        # 2. Check for Order Arrival
        if orders_pending > 0:
            time_till_arrival -= 1
            if time_till_arrival == 0:
                inventory_level += orders_pending
                orders_pending = 0
        
        # 3. Fulfill Demand
        if inventory_level >= daily_demand:
            inventory_level -= daily_demand
        else:
            # Shortage occurs
            shortage = daily_demand - inventory_level
            total_shortage_cost += shortage * COST_SHORT
            inventory_level = 0
            
        # 4. Check Reorder Point (ROP)
        if inventory_level <= ROP and orders_pending == 0:
            # Place new order
            orders_pending = Q
            total_ordering_cost += COST_ORDER
            
            # Determine stochastic lead time
            time_till_arrival = get_stochastic_lead_time(mu_lt, sigma_lt)
            
        # 5. Calculate Holding Cost
        total_holding_cost += inventory_level * COST_HOLD
        
    total_annual_cost = total_ordering_cost + total_holding_cost + total_shortage_cost
    return total_annual_cost

def execute_risk_analysis():
    # 3. Run R replications
    annual_costs = [run_modified_inventory_simulation(DAYS, MU_LEAD_TIME, SIGMA_LEAD_TIME) 
                    for _ in range(R_REPLICATIONS)]

    # 4. Calculate P5 and P95 percentiles (Value-at-Risk proxies)
    P5 = np.percentile(annual_costs, 5)
    P95 = np.percentile(annual_costs, 95)
    
    # 5. Visualization
    plt.figure(figsize=(10, 6))
    plt.hist(annual_costs, bins=50, alpha=0.7, color='darkorange', edgecolor='black')
    plt.axvline(P5, color='r', linestyle='--', linewidth=2, label=f'P5 Cost: ${P5:,.0f}')
    plt.axvline(P95, color='r', linestyle='-', linewidth=2, label=f'P95 Cost: ${P95:,.0f}')
    
    plt.title(f'Distribution of Annual Inventory Costs (R={R_REPLICATIONS} Years)')
    plt.xlabel('Total Annual Cost ($)')
    plt.ylabel('Frequency (Years)')
    plt.legend()
    plt.grid(axis='y', alpha=0.5)
    plt.show()
    
    print(f"--- Inventory Risk Analysis (Stochastic Lead Time) ---")
    print(f"5th Percentile Cost (P5): ${P5:,.2f}")
    print(f"95th Percentile Cost (P95): ${P95:,.2f}")
    print(f"90% Confidence Interval for Annual Cost: [${P5:,.2f}, ${P95:,.2f}]")

execute_risk_analysis()

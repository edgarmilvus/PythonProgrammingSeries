
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np
import matplotlib.pyplot as plt

def estimate_pi_monte_carlo():
    N_total = 500000  # Total number of points
    
    # 1. Generate N_total random (x, y) coordinates
    # Use vectorized generation for efficiency
    x = np.random.uniform(0, 1, N_total)
    y = np.random.uniform(0, 1, N_total)
    
    # 2. Vectorized Inclusion Check: x^2 + y^2 <= 1
    distance_squared = x**2 + y**2
    hits = np.sum(distance_squared <= 1)
    
    # 3. Final Estimation: Area_Ratio = pi/4 => pi = 4 * Ratio
    pi_estimate = 4 * (hits / N_total)

    # 4. Convergence Analysis Setup
    iterations = 100
    points_per_iteration = N_total // iterations
    running_estimates = []
    total_points_sampled = []
    cumulative_hits = 0
    
    # Rerun simulation in batches for convergence plot
    for i in range(1, iterations + 1):
        # Generate new batch of points
        x_batch = np.random.uniform(0, 1, points_per_iteration)
        y_batch = np.random.uniform(0, 1, points_per_iteration)
        
        # Update cumulative_hits
        cumulative_hits += np.sum(x_batch**2 + y_batch**2 <= 1)
        
        current_total_points = i * points_per_iteration
        current_estimate = 4 * (cumulative_hits / current_total_points)
        
        running_estimates.append(current_estimate)
        total_points_sampled.append(current_total_points)
        
    # Plotting convergence
    plt.figure(figsize=(10, 6))
    plt.plot(total_points_sampled, running_estimates, label='MC Estimate', color='darkblue', alpha=0.8)
    plt.axhline(np.pi, color='r', linestyle='--', label='True Pi (3.14159...)')
    plt.title('Monte Carlo Estimation of $\pi$: Convergence Analysis')
    plt.xlabel('Total Number of Points Sampled (N)')
    plt.ylabel('Estimate of $\pi$')
    plt.legend()
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.show()

    # 5. Error Calculation
    error = abs(pi_estimate - np.pi)
    print(f"Total Points Sampled: {N_total}")
    print(f"Final Pi Estimate: {pi_estimate:.6f}")
    print(f"True Pi Value: {np.pi:.6f}")
    print(f"Absolute Error: {error:.6e}")

estimate_pi_monte_carlo()

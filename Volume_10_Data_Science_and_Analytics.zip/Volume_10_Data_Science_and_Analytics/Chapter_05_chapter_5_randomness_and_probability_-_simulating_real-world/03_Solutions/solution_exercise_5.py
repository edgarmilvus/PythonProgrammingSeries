
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np
import matplotlib.pyplot as plt

# Initial Parameters
U1_MIN = 15
U1_MAX = 45
N2_MU = 60
N2_SIGMA = 10
SLA_THRESHOLD = 110
T_TRIALS = 100000

def simulate_pipeline_run(u_min, u_max, n_mu, n_sigma, trials):
    # 1. Sample Stage 1 (Uniform)
    stage1_time = np.random.uniform(u_min, u_max, trials)
    
    # 2. Sample Stage 2 (Normal)
    stage2_time = np.random.normal(n_mu, n_sigma, trials)
    
    # Ensure times are positive (though unlikely with these parameters)
    stage2_time[stage2_time < 0] = 0
    
    # 3. Calculate Total Time
    total_time = stage1_time + stage2_time
    
    # 4. Calculate SLA Violations
    violations = np.sum(total_time > SLA_THRESHOLD)
    violation_rate = violations / trials
    
    return total_time, violation_rate

def run_interactive_challenge():
    # Initial run (U(15, 45))
    total_time_initial, rate_initial = simulate_pipeline_run(U1_MIN, U1_MAX, N2_MU, N2_SIGMA, T_TRIALS)
    
    # 5. Optimized run (U(15, 35))
    U1_MAX_OPTIMIZED = 35
    total_time_optimized, rate_optimized = simulate_pipeline_run(U1_MIN, U1_MAX_OPTIMIZED, N2_MU, N2_SIGMA, T_TRIALS)

    # Calculate Risk Reduction
    risk_reduction = (rate_initial - rate_optimized) / rate_initial

    # 4. Visualization (Comparing distributions)
    plt.figure(figsize=(10, 6))
    plt.hist(total_time_initial, bins=100, density=True, alpha=0.6, label='Initial (U(15, 45))')
    plt.hist(total_time_optimized, bins=100, density=True, alpha=0.6, label='Optimized (U(15, 35))')
    
    plt.axvline(SLA_THRESHOLD, color='r', linestyle='--', linewidth=2, label=f'SLA Limit ({SLA_THRESHOLD} min)')
    plt.title('Total Pipeline Run Time Distribution')
    plt.xlabel('Total Time (minutes)')
    plt.ylabel('Density')
    plt.legend()
    plt.show()
    
    print(f"--- SLA Violation Risk Analysis ---")
    print(f"Initial SLA Violation Rate (U(15, 45)): {rate_initial:.4%}")
    print(f"Optimized SLA Violation Rate (U(15, 35)): {rate_optimized:.4%}")
    print(f"Absolute Reduction in Risk: {(rate_initial - rate_optimized):.4%}")
    print(f"Percentage Reduction in Risk: {risk_reduction:.2%}")

run_interactive_challenge()

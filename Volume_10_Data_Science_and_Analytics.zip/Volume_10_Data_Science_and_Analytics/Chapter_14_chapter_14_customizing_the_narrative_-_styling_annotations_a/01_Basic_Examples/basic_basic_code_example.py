
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import matplotlib.pyplot as plt
import numpy as np

# 1. Data Preparation: Define the variables for the plot
months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
sales = [120, 150, 140, 180, 250, 220, 280, 350, 310, 290, 300, 320]
peak_month_index = 7  # Index corresponding to 'Aug' (350 units sold)

# 2. Figure and Axes Initialization: Setting up the canvas
# fig is the overall container (Figure); ax is the specific plot area (Axes)
fig, ax = plt.subplots(figsize=(10, 6))

# 3. Primary Plotting with Custom Line Styling
# Use a professional, muted blue hex code for the main data series
ax.plot(months, sales,
        color='#2c3e50',  # Custom Hex Color (Dark Slate Gray)
        linewidth=3.5,    # Increased line thickness for emphasis
        marker='o',       # Circular markers at each data point
        markersize=7,
        label='Monthly Sales Trend')

# 4. Aesthetic Enhancements: Titles, Labels, and Grid
ax.set_title('2024 Annual Sales Performance Analysis',
             fontsize=18,
             fontweight='heavy',
             pad=15) # Add padding above the plot
ax.set_xlabel('Fiscal Month', fontsize=13)
ax.set_ylabel('Units Sold (Thousands)', fontsize=13)
ax.grid(True, linestyle=':', alpha=0.7, color='gray') # Subtle, dotted grid
ax.tick_params(axis='both', which='major', labelsize=10) # Control tick label size

# 5. Strategic Highlighting: Color Encoding the Critical Point
# Plot the peak month separately using a distinct, high-contrast color (Vivid Red)
peak_sales_value = sales[peak_month_index]
peak_month_name = months[peak_month_index]

ax.plot(peak_month_name, peak_sales_value,
        marker='D',           # Diamond marker shape
        markersize=14,
        color='#e74c3c',      # High-contrast red for attention
        label='Peak Performance')

# 6. Annotation and Callout: Guiding the Narrative
annotation_text = f"August: Record High of {peak_sales_value} Units"

# The annotate function draws the text and connecting arrow
ax.annotate(annotation_text,
            xy=(peak_month_name, peak_sales_value),              # Data point coordinates (where the arrow points)
            xytext=(peak_month_index + 1.5, peak_sales_value - 100), # Text box position (shifted right and down)
            arrowprops=dict(facecolor='#34495e', # Dark color for the arrow
                            shrink=0.08,        # Distance from the point/text
                            width=1.5,
                            headwidth=8),
            fontsize=11,
            color='#34495e',
            # Styling for the text box background
            bbox=dict(boxstyle="round,pad=0.6", fc="white", alpha=0.9, edgecolor='#34495e')
           )

# 7. Final Presentation Adjustments
plt.legend(loc='upper left', frameon=True, shadow=True)
plt.tight_layout(pad=3.0) # Automatically adjust subplot parameters for tight layout
plt.show()

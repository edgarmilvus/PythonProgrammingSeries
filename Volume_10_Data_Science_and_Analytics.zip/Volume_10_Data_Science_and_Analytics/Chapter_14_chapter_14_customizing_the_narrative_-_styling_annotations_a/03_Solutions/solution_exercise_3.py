
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# 1. Data Simulation (90 days)
np.random.seed(42)
days = np.arange(1, 91)
# Simulate a base trend + noise
base_trend = 50 + 0.1 * days + 10 * np.sin(days / 15)
engagement_score = np.clip(base_trend + np.random.randn(90) * 8, 0, 100)

df = pd.DataFrame({'Day': days, 'Score': engagement_score})

# 2. Peak/Trough Identification
idx_peak = df['Score'].argmax()
peak_day, peak_score = df.iloc[idx_peak][['Day', 'Score']]

idx_trough = df['Score'].argmin()
trough_day, trough_score = df.iloc[idx_trough][['Day', 'Score']]

fig, ax = plt.subplots(figsize=(12, 6))

# Plot the main time series
ax.plot(df['Day'], df['Score'], color='#004D40', linewidth=2, label='Engagement Score')

# --- 3. Annotation Implementation ---

# Peak Annotation Setup
peak_text = f"Peak Success (Score: {peak_score:.2f})"
ax.annotate(
    peak_text,
    xy=(peak_day, peak_score), # Data point coordinates
    xytext=(peak_day + 15, peak_score + 10), # Text box offset (15 days right, 10 score up)
    arrowprops=dict(
        facecolor='green', 
        shrink=0.05, 
        width=1.5, 
        headwidth=8,
        arrowstyle='->' # Custom arrow style
    ),
    bbox=dict(
        boxstyle="round,pad=0.5", 
        fc="green", # Green background
        alpha=0.8, 
        ec="none"
    ),
    fontsize=10,
    color='white', # White text
    ha='center'
)

# Trough Annotation Setup
trough_text = f"Critical Drop (Score: {trough_score:.2f})"
ax.annotate(
    trough_text,
    xy=(trough_day, trough_score), # Data point coordinates
    xytext=(trough_day - 15, trough_score - 15), # Text box offset (15 days left, 15 score down)
    arrowprops=dict(
        facecolor='red', 
        shrink=0.05, 
        width=1.5, 
        headwidth=8,
        arrowstyle='-|>' # Different custom arrow style
    ),
    bbox=dict(
        boxstyle="square,pad=0.5", 
        fc="red", # Red background
        alpha=0.8, 
        ec="none"
    ),
    fontsize=10,
    color='white', # White text
    ha='center'
)

# 5. Contextual Highlight (Shaded vertical span)
recovery_start = trough_day
recovery_end = trough_day + 7
ax.axvspan(recovery_start, recovery_end, 
           color='orange', 
           alpha=0.2, 
           label='7-Day Recovery Period')

# Final plot styling
ax.set_title('Daily Feature Engagement Score Analysis')
ax.set_xlabel('Day')
ax.set_ylabel('Score (0-100)')
ax.grid(axis='y', linestyle='--')
ax.legend()
plt.tight_layout()
plt.show()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# 1. Define Corporate Color Palette
CORP_PRIMARY = '#007AA3'  # Teal/Blue
CORP_SECONDARY = '#A30000' # Deep Red
CORP_HIGHLIGHT = '#FFC300' # Gold/Warning
NEUTRAL_DARK = '#333333'   # Dark Gray for text/axes
NEUTRAL_LIGHT = '#F5F5F5'  # Very Light Gray background

def apply_executive_theme():
    """
    Registers and applies a custom Matplotlib style optimized for formal executive reports.
    """
    # Define the custom rcParams dictionary
    executive_style = {
        # General Figure and Axes Aesthetics
        'figure.facecolor': NEUTRAL_LIGHT,
        'axes.facecolor': NEUTRAL_LIGHT,
        'axes.edgecolor': NEUTRAL_DARK,
        'text.color': NEUTRAL_DARK,

        # Font Management (using a common sans-serif fallback stack)
        'font.family': 'sans-serif',
        'font.sans-serif': ['Arial', 'Helvetica', 'DejaVu Sans', 'sans-serif'],
        
        # Title Styling
        'axes.title.fontsize': 16,
        'axes.title.fontweight': 'bold',
        'axes.title.loc': 'left', # Modern style preference

        # Tick and Axis Styling
        'xtick.color': NEUTRAL_DARK,
        'ytick.color': NEUTRAL_DARK,
        'axes.labelcolor': NEUTRAL_DARK,

        # Spines (Borders) - Must be completely hidden
        'axes.spines.top': False,
        'axes.spines.right': False,
        'axes.spines.left': False,
        'axes.spines.bottom': False,

        # Grid Lines - Light gray, dashed, Y-axis only
        'grid.color': '#CCCCCC',
        'grid.linestyle': '--',
        'grid.linewidth': 0.5,
        'axes.grid': True,
        'axes.grid.axis': 'y', # Only show horizontal (Y) grid lines
        'axes.grid.which': 'major',
    }
    
    # Apply the style using plt.rcParams.update() or register a style file
    plt.rcParams.update(executive_style)

# --- Demonstration ---

# 1. Apply the theme globally
apply_executive_theme()

# 2. Generate sample data
days = np.arange(1, 13)
sales = [150, 165, 180, 175, 210, 230, 245, 220, 260, 290, 310, 330]

# 3. Create the plot
fig, ax = plt.subplots(figsize=(10, 5))

ax.plot(days, sales, 
        color=CORP_PRIMARY, 
        linewidth=3, 
        marker='o', 
        markersize=6, 
        markeredgecolor=NEUTRAL_DARK)

# Use secondary color for a highlight bar
ax.axhline(y=250, color=CORP_SECONDARY, linestyle=':', linewidth=1.5, alpha=0.7)

ax.set_title('Monthly Sales Performance Analysis (Q1-Q4)')
ax.set_xlabel('Month Number')
ax.set_ylabel('Total Sales (in 000s)')
ax.set_xticks(days)

# Ensure the Y-axis tick lines are visible even if the spine is hidden
ax.tick_params(axis='y', length=6, color=NEUTRAL_DARK)

plt.show()
# Reset Matplotlib defaults afterwards if necessary for other exercises
plt.style.use('default')

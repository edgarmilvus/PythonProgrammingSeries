
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

# Set a professional style for the base plot
plt.style.use('seaborn-v0_8-whitegrid') 

# 1. Data Setup (Synthetic Data)
np.random.seed(42)
N = 100
categories = [f'Product {i}' for i in range(1, 11)]

data = pd.DataFrame({
    'Revenue': np.random.lognormal(mean=7, sigma=0.8, size=N),
    'Units_Sold': np.random.randint(50, 500, size=N),
    'Product_Category': np.random.choice(categories, size=N),
    # Profit Margin: centered around 0.1, with some negative values
    'Profit_Margin': np.clip(np.random.normal(0.1, 0.15, size=N), -0.2, 0.4)
})

# Define markers for redundant encoding (10 unique shapes needed)
markers = {cat: m for cat, m in zip(categories, 
                                    ['o', 'v', '^', '<', '>', 's', 'p', '*', 'h', 'D'])}

# 2. Color Mapping Strategy (Diverging Palette)
# Using 'RdBu_r' (Red-Blue reversed) which is perceptually uniform and safe.
# Red for negative margin (Loss), Blue for positive margin (Profit).
cmap = 'RdBu_r' 

fig, ax = plt.subplots(figsize=(12, 7))

# 3. Visual Encoding: Iterate to apply shape encoding
for category, marker_style in markers.items():
    subset = data[data['Product_Category'] == category]
    
    # Scatter plot: X=Revenue, Y=Units_Sold, Color=Profit_Margin, Marker=Category
    scatter = ax.scatter(
        subset['Revenue'],
        subset['Units_Sold'],
        c=subset['Profit_Margin'],  # Color based on Profit Margin (continuous)
        cmap=cmap,
        s=100, # Fixed size for simplicity, or could encode Sales Volume here
        marker=marker_style, # Shape based on Category (categorical)
        edgecolor='k',
        linewidth=0.5,
        vmin=-0.2, # Set limits to ensure 0 is centered
        vmax=0.4,
        label=category
    )

# 4. Annotation and Legend
ax.set_title('Revenue vs. Units Sold, Encoded by Profit Margin (Diverging Color)', fontsize=16)
ax.set_xlabel('Total Revenue ($)')
ax.set_ylabel('Units Sold')
ax.legend(title='Product Category (Shape Key)', bbox_to_anchor=(1.05, 1), loc='upper left')

# Create Color Bar
cbar = fig.colorbar(scatter, ax=ax, orientation='vertical', pad=0.02)
cbar.set_label('Profit Margin (Ratio)', rotation=270, labelpad=15)

# Highlight the zero point on the color bar
cbar.ax.axhline(0, color='black', linestyle='--', linewidth=1) 
cbar.set_ticks([-0.2, 0.0, 0.1, 0.2, 0.3, 0.4])
cbar.set_ticklabels(['-20% (Loss)', '0% (Break Even)', '10%', '20%', '30%', '40%'])

plt.tight_layout(rect=[0, 0, 0.85, 1]) # Adjust layout for legend
plt.show()

# 5. Critique and Justification (Textual Requirement)
"""
Instructor's Justification:
The chosen diverging palette ('RdBu_r') is superior for Profit Margin because the variable is inherently bipolar, meaning it has a critical midpoint (0.0). A sequential palette (e.g., light to dark blue) would imply that a 20% loss is simply 'less' than a 0% margin, failing to communicate the qualitative difference between loss and profit. The diverging palette uses two distinct hues (Red for negative, Blue for positive) with increasing saturation as values move away from the central neutral color (white/light gray at 0.0), clearly highlighting both high-profit and high-loss categories immediately. Furthermore, the use of marker shape provides a crucial redundant encoding for the categorical variable, ensuring that viewers with color vision deficiencies can still distinguish the 10 product categories.
"""


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# 1. Data Setup (Sample Time Series)
np.random.seed(10)
days = np.arange(1, 61)
value = 100 + np.cumsum(np.random.randn(60) * 5)
df = pd.DataFrame({'Day': days, 'Value': value})

def generate_dynamic_narrative(data, mood):
    """
    Generates a time series plot with styling dynamically adjusted based on the narrative mood.
    """
    
    # 2. Define Theme Configurations (rcParams overrides)
    if mood == 'EDA':
        # Dark theme for exploration, dense info
        theme = {
            'figure.facecolor': '#212121',
            'axes.facecolor': '#212121',
            'text.color': 'white',
            'axes.edgecolor': 'white',
            'xtick.color': 'white',
            'ytick.color': 'white',
            'axes.grid': True,
            'grid.color': '#444444',
            'grid.linestyle': '-',
            'axes.title.fontsize': 10,
            'font.size': 8
        }
        line_color = '#00BFA5' # Muted teal
        title = 'Exploratory Data Analysis (Dense Grid)'
        
    elif mood == 'Formal':
        # Light theme for professional reports, minimal clutter
        theme = {
            'figure.facecolor': '#F9F7F6',
            'axes.facecolor': 'white',
            'text.color': '#333333',
            'axes.edgecolor': '#333333',
            'axes.spines.right': False,
            'axes.spines.top': False,
            'axes.grid': True,
            'axes.grid.axis': 'y', # Y-axis only
            'grid.color': '#E0E0E0',
            'grid.linestyle': '--',
            'axes.title.fontsize': 18,
            'font.size': 12
        }
        line_color = '#1976D2' # Corporate blue
        title = 'Formal Executive Report (Clean Aesthetic)'
        
    elif mood == 'Urgent':
        # High contrast, warning colors, immediate focus
        theme = {
            'figure.facecolor': 'white',
            'axes.facecolor': 'white',
            'text.color': 'black',
            'axes.edgecolor': 'black',
            'axes.spines.right': True,
            'axes.spines.top': True,
            'axes.grid': False, # No grid
            'axes.title.fontsize': 20,
            'axes.title.color': 'red',
            'font.size': 14
        }
        line_color = '#FF9800' # High-visibility orange
        title = 'URGENT ATTENTION REQUIRED (Warning Status)'
    
    else:
        raise ValueError("Invalid mood specified. Choose 'EDA', 'Formal', or 'Urgent'.")

    # Apply the theme using a context manager for temporary application
    with plt.style.context(theme):
        fig, ax = plt.subplots(figsize=(10, 5))
        
        # Plot the data
        ax.plot(data['Day'], data['Value'], 
                color=line_color, 
                linewidth=3 if mood == 'Urgent' else 2, 
                label='Time Series Value')
        
        ax.set_title(title, loc='left')
        ax.set_xlabel('Day')
        ax.set_ylabel('Value')
        
        # Conditional Annotation (Urgent Mood Requirement)
        if mood == 'Urgent':
            last_day = data['Day'].iloc[-1]
            last_value = data['Value'].iloc[-1]
            
            ax.scatter(last_day, last_value, color='red', s=150, zorder=5)
            
            ax.annotate(
                f"Current Status: {last_value:.1f}",
                xy=(last_day, last_value),
                xytext=(last_day - 15, last_value + 15),
                arrowprops=dict(facecolor='red', shrink=0.05, width=2),
                bbox=dict(boxstyle="round,pad=0.5", fc="red", alpha=0.9),
                color='white',
                fontsize=12,
                ha='center'
            )
            
        plt.show()

# --- 4. Demonstration ---
print("--- Generating EDA Plot ---")
generate_dynamic_narrative(df, 'EDA')

print("--- Generating Formal Plot ---")
generate_dynamic_narrative(df, 'Formal')

print("--- Generating Urgent Plot ---")
generate_dynamic_narrative(df, 'Urgent')

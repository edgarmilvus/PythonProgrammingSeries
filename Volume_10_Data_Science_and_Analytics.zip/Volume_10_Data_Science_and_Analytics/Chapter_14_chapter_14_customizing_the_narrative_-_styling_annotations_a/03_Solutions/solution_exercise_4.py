
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# 1. Data Simulation
np.random.seed(42)
# Cohort A (Standard) - slightly lower mean, tighter std dev
scores_A = np.random.normal(loc=70, scale=8, size=300)
# Cohort B (Experimental/Focus) - slightly higher mean, wider std dev
scores_B = np.random.normal(loc=75, scale=12, size=300)

fig, ax = plt.subplots(figsize=(10, 6))

# --- Layer 1: Contextual Background (KDE A) ---
sns.kdeplot(scores_A, ax=ax, 
            label='Cohort A Density (Context)', 
            color='lightgray', 
            fill=True, 
            alpha=0.4, 
            linewidth=1.5,
            zorder=1) # Lowest Z-order

# --- Layer 2: Raw Data Points ---
# Raw Data A (Background noise)
ax.scatter(scores_A, np.random.uniform(0, 0.005, size=len(scores_A)), 
           color='gray', 
           alpha=0.2, # Highly transparent
           s=10, 
           label='Cohort A Raw Data',
           zorder=2) 

# Raw Data B (Medium prominence)
ax.scatter(scores_B, np.random.uniform(0, 0.005, size=len(scores_B)), 
           color='purple', 
           alpha=0.6, # Medium transparency
           s=10, 
           label='Cohort B Raw Data',
           zorder=2) 

# --- Layer 3: Primary Focus (KDE B) ---
sns.kdeplot(scores_B, ax=ax, 
            label='Cohort B Density (Focus)', 
            color='deepskyblue', 
            fill=True, 
            alpha=1.0, # Fully opaque
            linewidth=3,
            zorder=3) # Highest Z-order

# Final Styling
ax.set_title('Visual Hierarchy of Test Score Distributions (Cohort B Dominant)')
ax.set_xlabel('Test Score')
ax.set_yticks([]) # Hide Y-axis for density plots
ax.set_ylim(0, ax.get_ylim()[1] + 0.005) # Adjust limits for scatter points
ax.legend(loc='upper right')
plt.show()

# 5. Structural Diagram (DOT)
dot_code = """
digraph ZOrderHierarchy {
    rankdir=LR;
    node [shape=box];
    
    Z1 [label="Z=1: Cohort A KDE (Alpha=0.4, Context)", style="filled", fillcolor="lightgray"];
    Z2A [label="Z=2: Cohort A Raw Data (Alpha=0.2, Noise)"];
    Z2B [label="Z=2: Cohort B Raw Data (Alpha=0.6, Medium Focus)"];
    Z3 [label="Z=3: Cohort B KDE (Alpha=1.0, Primary Focus)", style="filled", fillcolor="deepskyblue"];
    
    {rank=same; Z2A; Z2B;}
    
    Z1 -> Z2A [label="Drawn Below"];
    Z1 -> Z2B [label="Drawn Below"];
    Z2A -> Z3 [label="Drawn Below"];
    Z2B -> Z3 [label="Drawn Below"];
}
"""
print("\n--- Conceptual Z-Order Diagram (DOT Code) ---\n")
print(dot_code)

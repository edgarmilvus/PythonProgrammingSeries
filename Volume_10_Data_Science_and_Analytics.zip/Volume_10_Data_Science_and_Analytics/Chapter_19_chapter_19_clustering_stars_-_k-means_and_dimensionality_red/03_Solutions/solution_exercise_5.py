
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from sklearn.metrics import silhouette_score
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

# Reusing the simulated stellar_df and pre-processing steps
X = stellar_df.values
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

N_COMPONENTS = 3
K_OPTIMAL = 4 # Based on the analysis in Exercise 3

pca = PCA(n_components=N_COMPONENTS, random_state=42)
transformed_data = pca.fit_transform(X_scaled)

# 1. Final Clustering (using K_OPTIMAL)
kmeans = KMeans(n_clusters=K_OPTIMAL, random_state=42, n_init=10)
final_labels = kmeans.fit_predict(transformed_data)


def evaluate_cluster_quality(transformed_data, labels, k_optimal):
    # 2. Quality Metric: Calculate Silhouette Score
    # Calculated on the reduced feature space (N=3 components)
    score = silhouette_score(transformed_data, labels)
    print(f"Final Clustering (N={N_COMPONENTS}, K={k_optimal})")
    print(f"Global Silhouette Score: {score:.4f}")
    
    # 2. Interpretation of Silhouette Score
    # Score Interpretation:
    # A score near +1 indicates that the object is well matched to its own cluster 
    # and poorly matched to neighboring clusters (good separation).
    # A score near 0 indicates overlapping clusters or that the object is near the 
    # decision boundary.
    # A score near -1 indicates that the object has been assigned to the wrong cluster.
    # A score of ~0.4 to 0.6 is often considered reasonable for complex real-world 
    # data like stellar populations where boundaries are naturally fuzzy.
    
    # 3. Generate 2D visualization (PC1 vs PC2) with centroids
    
    # Re-fit K-Means just to ensure we have the centroids based on the transformed data
    kmeans_viz = KMeans(n_clusters=k_optimal, random_state=42, n_init=10).fit(transformed_data)
    centroids = kmeans_viz.cluster_centers_
    
    plt.figure(figsize=(10, 7))
    
    # Scatter plot of PC1 vs PC2
    scatter = plt.scatter(transformed_data[:, 0], transformed_data[:, 1], 
                          c=labels, cmap='viridis', s=50, alpha=0.7)
    
    # Plot centroids (only PC1 and PC2 coordinates)
    plt.scatter(centroids[:, 0], centroids[:, 1], 
                marker='*', s=300, c='red', edgecolors='black', label='Centroids')
    
    plt.xlabel('Principal Component 1 (PC1)')
    plt.ylabel('Principal Component 2 (PC2)')
    plt.title(f'Cluster Visualization and Centroids (K={k_optimal})')
    plt.colorbar(scatter, label='Cluster Label')
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.show()
    
    # 4. Boundary Interpretation Commentary
    interpretation = """
    --- Astrophysical Interpretation ---
    PC1 typically captures the largest variance, often correlating strongly with 
    absolute magnitude (luminosity) and primary color indices (effective temperature). 
    PC2 often captures secondary variance, potentially related to metallicity or 
    evolutionary stage subtleties.
    
    The visualization shows clear separation along PC1, suggesting the clusters 
    primarily differentiate based on luminosity/temperature (the main axes of 
    the Hertzsprung-Russell Diagram).
    
    Hypothesis on Extremes:
    - Clusters located far on the positive end of PC1 (e.g., high magnitude/low color) 
      likely represent the Main Sequence or high-luminosity stars.
    - Clusters located on the negative end of PC1 (e.g., low magnitude/high color) 
      may represent distinct, evolved populations like White Dwarfs or Red Giants.
    
    The Silhouette Score provides quantitative confirmation that the clusters 
    found in the reduced space are reasonably distinct, supporting the physical 
    interpretation of the groupings as distinct stellar populations.
    """
    print(interpretation)

# Execution steps:
evaluate_cluster_quality(transformed_data, final_labels, K_OPTIMAL)

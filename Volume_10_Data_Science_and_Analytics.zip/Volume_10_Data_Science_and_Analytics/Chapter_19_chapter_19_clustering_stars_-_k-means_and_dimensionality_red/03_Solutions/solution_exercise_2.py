
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from time import time
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

# Reusing the simulated stellar_df from Exercise 1

def compare_clustering_performance(data_frame, n_clusters=4, n_components=2):
    X = data_frame.values
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # --- Pipeline 1: High-Dimensional Clustering (5D) ---
    start_time_5d = time()
    kmeans_5d = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    kmeans_5d.fit(X_scaled)
    end_time_5d = time()
    
    time_5d = end_time_5d - start_time_5d
    inertia_5d = kmeans_5d.inertia_
    
    print(f"--- Pipeline 1 (5D) Results ---")
    print(f"Execution Time (Scaling + Clustering): {time_5d:.4f} seconds")
    print(f"Inertia (WCSS): {inertia_5d:.2f}")
    
    # --- Pipeline 2: Reduced-Dimensional Clustering (2D) ---
    start_time_2d = time()
    
    # Apply PCA
    pca = PCA(n_components=n_components)
    X_pca = pca.fit_transform(X_scaled)
    
    # Apply K-Means to 2D data
    kmeans_2d = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    kmeans_2d.fit(X_pca)
    end_time_2d = time()
    
    time_2d = end_time_2d - start_time_2d
    inertia_2d = kmeans_2d.inertia_
    labels_2d = kmeans_2d.labels_
    
    print(f"\n--- Pipeline 2 ({n_components}D PCA) Results ---")
    print(f"Execution Time (Scaling + PCA + Clustering): {time_2d:.4f} seconds")
    print(f"Inertia (WCSS): {inertia_2d:.2f}")
    
    # Comparison
    speedup = time_5d / time_2d if time_2d > 0 else float('inf')
    print(f"\nComparison: PCA pipeline achieved a speedup factor of {speedup:.2f}x.")

    # --- Visualization of Pipeline 2 Clusters ---
    plt.figure(figsize=(8, 6))
    scatter = plt.scatter(X_pca[:, 0], X_pca[:, 1], c=labels_2d, cmap='viridis', s=50, alpha=0.7)
    plt.xlabel(f'Principal Component 1 ({pca.explained_variance_ratio_[0]*100:.1f}%)')
    plt.ylabel(f'Principal Component 2 ({pca.explained_variance_ratio_[1]*100:.1f}%)')
    plt.title(f'K-Means Clustering (K={n_clusters}) on PCA-Reduced Stellar Data (2D)')
    plt.colorbar(scatter, label='Cluster Label')
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.show()

    # Advanced Metric Commentary:
    # Inertia (WCSS) Comparison:
    # Inertia is the sum of squared distances from each point to its assigned cluster centroid.
    # The inertia values (inertia_5d vs inertia_2d) are NOT directly comparable 
    # because the input spaces are fundamentally different. The 5D inertia is calculated 
    # in a 5-dimensional hyperspace, while the 2D inertia is calculated in a 2-dimensional 
    # projection space. The 2D PCA space inherently has lower total variance (and thus 
    # lower potential WCSS) because 80-90% of the original variance might be retained, 
    # but the remaining variance is discarded. Therefore, a lower inertia in 2D only 
    # confirms the reduction in dimensionality, not necessarily an improvement in clustering quality relative to the original space.

# Execution call
compare_clustering_performance(stellar_df)

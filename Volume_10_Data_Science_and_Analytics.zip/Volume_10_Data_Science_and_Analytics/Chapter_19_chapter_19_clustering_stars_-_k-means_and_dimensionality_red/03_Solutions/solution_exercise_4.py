
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import sys
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
import numpy as np

# Reusing the simulated stellar_df from Exercise 1

def run_pca_kmeans_pipeline(df: pd.DataFrame, n_components: int, n_clusters: int):
    """
    Executes the integrated PCA-KMeans pipeline with robust input validation.
    Adheres to DRY by encapsulating the entire workflow, and uses sys.exit() 
    for critical input failures (POLA).
    
    Returns: (PCA-transformed data, K-Means cluster labels)
    """
    
    # 1. Input Validation (DataFrame integrity)
    if not isinstance(df, pd.DataFrame) or df.empty:
        print("ERROR (Status 1): Input must be a non-empty pandas DataFrame.")
        sys.exit(1)
        
    X = df.values
    n_features = X.shape[1]
    
    # 2. Dimensionality check and validation (POLA: preventing unexpected PCA behavior)
    if not isinstance(n_components, int) or n_components <= 0:
        print("ERROR (Status 2): n_components must be a positive integer.")
        sys.exit(2)
        
    if n_components >= n_features:
        print(f"ERROR (Status 2): n_components ({n_components}) must be strictly less than the number of features ({n_features}) for meaningful reduction.")
        sys.exit(2)
        
    try:
        # 3. Scaling (Standardization)
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        # 4. PCA (Dimensionality Reduction)
        pca = PCA(n_components=n_components, random_state=42)
        transformed_data = pca.fit_transform(X_scaled)
        
        # 5. K-Means Clustering
        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        labels = kmeans.fit_predict(transformed_data)
        
    except Exception as e:
        # Catch unexpected runtime errors (e.g., numerical instability)
        print(f"CRITICAL ERROR (Status 3): An unexpected error occurred during processing: {e}")
        sys.exit(3)
        
    # 6. Return transformed data and labels
    return transformed_data, labels

# --- Example Usage Demonstration ---
print("--- Running Valid Pipeline ---")
try:
    # Valid input
    transformed_data_valid, labels_valid = run_pca_kmeans_pipeline(stellar_df, 3, 4)
    print(f"Pipeline executed successfully. Data shape: {transformed_data_valid.shape}, Clusters found: {len(np.unique(labels_valid))}")
except SystemExit as e:
    print(f"Pipeline terminated unexpectedly with status code {e.code}")

print("\n--- Testing Invalid Input (Empty DataFrame) ---")
try:
    # Invalid input: Empty DataFrame
    empty_df = pd.DataFrame()
    transformed_data_invalid, labels_invalid = run_pca_kmeans_pipeline(empty_df, 3, 4)
except SystemExit as e:
    print(f"Pipeline terminated with status code {e.code} (Expected: 1)")

print("\n--- Testing Invalid Input (N > Features) ---")
try:
    # Invalid input: n_components >= n_features (5 features, asking for 6 components)
    transformed_data_invalid, labels_invalid = run_pca_kmeans_pipeline(stellar_df, 6, 4)
except SystemExit as e:
    print(f"Pipeline terminated with status code {e.code} (Expected: 2)")

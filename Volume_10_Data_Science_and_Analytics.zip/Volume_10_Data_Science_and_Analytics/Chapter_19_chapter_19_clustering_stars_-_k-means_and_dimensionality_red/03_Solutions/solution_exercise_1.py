
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt

# --- Data Simulation for Reproducibility ---
np.random.seed(42)
N = 500
M_G = np.random.normal(loc=5, scale=3, size=N) 
G_BP = 0.5 * M_G + np.random.normal(loc=1.5, scale=0.5, size=N) 
BP_RP = 1.2 * G_BP + np.random.normal(loc=0.5, scale=0.3, size=N) 
X4 = M_G * 0.8 + np.random.normal(0, 0.5, N)
X5 = G_BP * 1.5 + np.random.normal(0, 0.4, N)
stellar_df = pd.DataFrame({
    'X1_MG': M_G, 'X2_GBP': G_BP, 'X3_BPRP': BP_RP, 
    'X4_Corr': X4, 'X5_Corr': X5
})
# ------------------------------------------

def analyze_explained_variance(data_frame):
    # 1. Data Preparation and Scaling
    X = data_frame.values
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Why scaling is paramount: PCA maximizes variance. If features are not scaled, 
    # features with larger numerical ranges (e.g., M_G magnitude) will dominate 
    # the principal components, regardless of their actual information content, 
    # skewing the analysis away from true underlying correlations.
    
    # 2. PCA Application (n_components=None to get all variances)
    pca = PCA(n_components=None)
    pca.fit(X_scaled)
    
    # 3. Variance Analysis
    explained_variance_ratio = pca.explained_variance_ratio_
    cumulative_variance = np.cumsum(explained_variance_ratio)
    n_features = X_scaled.shape[1]
    
    # 5. Dimensionality Selection (95% threshold)
    target_variance = 0.95
    n_components_95 = np.argmax(cumulative_variance >= target_variance) + 1
    
    print(f"Total features: {n_features}")
    print(f"Cumulative Variance Ratios: {cumulative_variance}")
    print(f"\nMinimum components required for {target_variance*100:.0f}% variance: {n_components_95}")
    
    # 4. Visualization
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    
    # Plot A (Scree Plot - Individual Variance)
    components = range(1, n_features + 1)
    ax1.bar(components, explained_variance_ratio, color='skyblue')
    ax1.set_xlabel('Principal Component Index')
    ax1.set_ylabel('Individual Explained Variance Ratio')
    ax1.set_title('A: Scree Plot (Individual Variance)')
    ax1.set_xticks(components)
    
    # Plot B (Cumulative Variance)
    ax2.plot(components, cumulative_variance, marker='o', linestyle='-', color='darkred')
    ax2.axhline(y=target_variance, color='gray', linestyle='--', label=f'{target_variance*100:.0f}% Threshold')
    ax2.axvline(x=n_components_95, color='green', linestyle=':', label=f'N={n_components_95}')
    ax2.set_xlabel('Number of Principal Components')
    ax2.set_ylabel('Cumulative Explained Variance Ratio')
    ax2.set_title('B: Cumulative Explained Variance')
    ax2.set_xticks(components)
    ax2.legend()
    
    plt.tight_layout()
    plt.show()

# Execution call
analyze_explained_variance(stellar_df)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# Reusing the simulated stellar_df from Exercise 1

# Pre-processing steps (Scaling and PCA to N=3) - DRY Principle
X = stellar_df.values
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

N_COMPONENTS = 3
pca = PCA(n_components=N_COMPONENTS, random_state=42)
transformed_data = pca.fit_transform(X_scaled)
print(f"Data reduced to {N_COMPONENTS} components. Cumulative variance retained: {pca.explained_variance_ratio_.sum():.4f}")


def find_optimal_k(pca_data):
    k_range = range(2, 16)
    
    # 2. Iterative Clustering using Pythonic list comprehension
    # PCA transformation is performed only once outside this function (DRY principle met).
    inertia_values = [
        KMeans(n_clusters=k, random_state=42, n_init=10).fit(pca_data).inertia_
        for k in k_range
    ]
    
    # 3. Plot generation
    plt.figure(figsize=(9, 6))
    plt.plot(k_range, inertia_values, marker='o', linestyle='-', color='blue')
    plt.xlabel('Number of Clusters (K)')
    plt.ylabel('Inertia (WCSS)')
    plt.title(f'Elbow Method for PCA-Reduced Stellar Data (N={N_COMPONENTS} Components)')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.xticks(k_range)
    plt.show()
    
    # 4. Optimal K Selection Commentary (POLA)
    # The elbow point is typically where the curve's slope significantly decreases, 
    # indicating diminishing returns for adding more clusters.
    
    optimal_k_commentary = """
    --- Optimal K Selection Commentary ---
    Observing the plot, the steepest drop in inertia occurs between K=2 and K=3.
    The curve starts to flatten noticeably around K=4 or K=5. 
    
    If we select K=4: This represents a robust partitioning (e.g., Main Sequence, 
    Giant Branch, White Dwarfs, and perhaps a substructure or binary population).
    This choice adheres to the Principle of Least Astonishment (POLA) by providing 
    a meaningful separation without over-segmentation. A choice like K=10, 
    while resulting in lower inertia, would likely lead to micro-clusters that 
    are difficult to interpret astrophysically and may represent noise rather 
    than distinct stellar populations. K=4 is often a good starting point for 
    stellar classification based on HR diagrams.
    """
    print(optimal_k_commentary)

# Execution call
find_optimal_k(transformed_data)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
import sys

# --- Configuration and Constants ---
N_SAMPLES = 600
N_FEATURES = 7
K_CLUSTERS = 3  # Target number of stellar populations (e.g., Main Sequence, Giants, Dwarfs)
RANDOM_STATE = 42

def simulate_stellar_catalog(n_samples, random_state):
    """
    Generates a synthetic dataset mimicking stellar properties.
    The data is intentionally structured to form three distinct groups.
    Features: F1-F7 (e.g., different photometric magnitudes and derived values).
    """
    np.random.seed(random_state)
    
    # Define parameters for three hypothetical stellar populations
    
    # Cluster 1: Hot, Bright Stars (e.g., Blue Giants)
    c1 = np.random.normal(loc=[10, 12, 15, 18, 20, 5000, 1.5], scale=[1, 1, 1.2, 1.5, 1.8, 500, 0.2], size=(n_samples//3, N_FEATURES))
    
    # Cluster 2: Main Sequence Stars (Sun-like)
    c2 = np.random.normal(loc=[15, 14, 13, 12, 11, 4000, 0.8], scale=[1.5, 1.2, 1, 0.8, 0.5, 400, 0.1], size=(n_samples//3, N_FEATURES))
    
    # Cluster 3: Cool, Dim Stars (e.g., Red Dwarfs)
    c3 = np.random.normal(loc=[20, 18, 16, 14, 12, 3000, 0.5], scale=[2, 1.8, 1.5, 1.2, 1.0, 300, 0.15], size=(n_samples - 2 * (n_samples//3), N_FEATURES))
    
    data = np.vstack([c1, c2, c3])
    
    feature_names = [f'Feature_{i+1}' for i in range(N_FEATURES)]
    df = pd.DataFrame(data, columns=feature_names)
    
    print(f"--- Data Generated: {df.shape[0]} samples, {df.shape[1]} features ---")
    return df

def run_pca_kmeans_pipeline(df, n_components, k_clusters):
    """
    Executes the standardization, PCA, and K-Means pipeline.
    """
    
    # 1. Standardization (Crucial for PCA and K-Means)
    try:
        scaler = StandardScaler()
        df_scaled = scaler.fit_transform(df)
        print("1. Data standardized successfully.")
    except Exception as e:
        print(f"Error during scaling: {e}")
        sys.exit(1)

    # 2. Principal Component Analysis (Dimensionality Reduction)
    # We choose n_components to capture the most variance while simplifying the space.
    pca = PCA(n_components=n_components, random_state=RANDOM_STATE)
    principal_components = pca.fit_transform(df_scaled)
    
    # Check explained variance (for diagnostic purposes)
    explained_variance = np.sum(pca.explained_variance_ratio_)
    print(f"2. PCA applied. Top {n_components} components explain {explained_variance:.2f} of variance.")
    
    # Create a DataFrame for the reduced features
    pca_cols = [f'PC{i+1}' for i in range(n_components)]
    df_pca = pd.DataFrame(data=principal_components, columns=pca_cols)
    
    # 3. K-Means Clustering on the Reduced Data
    # Applying K-Means to the compressed, orthogonal feature space (PC1, PC2, PC3)
    kmeans = KMeans(n_clusters=k_clusters, init='k-means++', 
                    max_iter=300, n_init=10, random_state=RANDOM_STATE)
    
    # Fit K-Means on the principal components
    cluster_labels = kmeans.fit_predict(df_pca)
    print(f"3. K-Means clustering completed. Found {k_clusters} distinct stellar populations.")
    
    # 4. Integrate results back into the PCA DataFrame
    df_pca['Cluster'] = cluster_labels
    
    return df_pca, pca

def visualize_results(df_pca):
    """
    Visualizes the clustered data using the first two principal components.
    """
    
    plt.figure(figsize=(10, 8))
    
    # Scatter plot, coloring points by the assigned cluster label
    scatter = plt.scatter(df_pca['PC1'], df_pca['PC2'], 
                          c=df_pca['Cluster'], 
                          cmap='viridis', 
                          s=50, alpha=0.7, 
                          edgecolor='k')
    
    # Labeling and Titles
    plt.xlabel('Principal Component 1 (PC1)')
    plt.ylabel('Principal Component 2 (PC2)')
    plt.title(f'Stellar Population Clustering (K={K_CLUSTERS}) via PCA Reduction')
    
    # Create legend based on cluster labels
    legend1 = plt.legend(*scatter.legend_elements(), 
                         title="Stellar Cluster", 
                         loc="upper right")
    plt.gca().add_artist(legend1)
    
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.show()

# --- Main Execution Block ---
if __name__ == "__main__":
    
    # Set up the data
    stellar_data = simulate_stellar_catalog(N_SAMPLES, RANDOM_STATE)
    
    # Run the full pipeline, reducing 7 features down to 3 components
    N_COMPONENTS = 3
    
    results_df, pca_model = run_pca_kmeans_pipeline(
        df=stellar_data, 
        n_components=N_COMPONENTS, 
        k_clusters=K_CLUSTERS
    )
    
    # Final visualization using the top 2 components (PC1 vs PC2)
    visualize_results(results_df)


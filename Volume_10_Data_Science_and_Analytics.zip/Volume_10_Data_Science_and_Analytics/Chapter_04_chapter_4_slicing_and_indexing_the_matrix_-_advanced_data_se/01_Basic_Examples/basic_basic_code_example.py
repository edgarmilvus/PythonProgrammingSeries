
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import pandas as pd
import numpy as np

# --- 1. DataFrame Setup: Inventory Data ---
# We use a custom, non-numeric index to clearly separate label from position.
data = {
    'Price_USD': [150.00, 220.50, 45.99, 18.75, 310.00],
    'Stock_Qty': [12, 5, 80, 150, 2],
    'Category': ['Electronics', 'Electronics', 'Apparel', 'Grocery', 'Electronics']
}

# Define custom index labels: P400 is at position 0, P22B is at position 4.
product_labels = ['P400', 'P101', 'P55C', 'P99A', 'P22B']
df_inventory = pd.DataFrame(data, index=product_labels)

print("--- Original Inventory DataFrame (Labels vs Positions) ---")
print(df_inventory)
print("-" * 60)

# --- 2. Demonstration of .loc (Label-based Indexing) ---

# A. Selecting a single row by its custom label (index name)
print("\n[2.A] .loc: Selecting row 'P55C' (The T-Shirt)")
# Syntax: df.loc[row_label]
item_p55c_loc = df_inventory.loc['P55C']
print(item_p55c_loc)

# B. Selecting multiple specific rows and specific columns by label
print("\n[2.B] .loc: Selecting 'P400' and 'P22B', focusing only on 'Price_USD' and 'Category'")
# Syntax: df.loc[[row_labels], [column_labels]]
high_value_items_loc = df_inventory.loc[['P400', 'P22B'], ['Price_USD', 'Category']]
print(high_value_items_loc)

# C. Slicing rows using labels (CRITICAL: The end label is INCLUSIVE)
print("\n[2.C] .loc: Slicing rows from 'P400' THROUGH 'P55C'")
# This selects P400, P101, AND P55C.
loc_slice = df_inventory.loc['P400':'P55C']
print(loc_slice)
print("-" * 60)

# --- 3. Demonstration of .iloc (Positional-based Indexing) ---

# D. Selecting a single row by its integer position (0-indexed)
# 'P55C' is physically located at position 2 (0, 1, 2)
print("\n[3.D] .iloc: Selecting row at integer position 2 (which is 'P55C')")
# Syntax: df.iloc[row_position]
item_pos_2_iloc = df_inventory.iloc[2]
print(item_pos_2_iloc)

# E. Selecting multiple rows and specific columns by integer position
# Rows: positions 0 and 4. Columns: positions 0 ('Price_USD') and 2 ('Category')
print("\n[3.E] .iloc: Selecting rows 0 and 4, and columns 0 and 2.")
# Syntax: df.iloc[[row_positions], [column_positions]]
high_value_items_iloc = df_inventory.iloc[[0, 4], [0, 2]]
print(high_value_items_iloc)

# F. Slicing rows using positions (CRITICAL: The end position is EXCLUSIVE)
# Slice from position 0 up to (but not including) position 3
print("\n[3.F] .iloc: Slicing rows from position 0 UP TO 3 (selects 0, 1, 2)")
iloc_slice = df_inventory.iloc[0:3]
print(iloc_slice)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Setup the simulated data for sensor readings (Re-running setup)
data_size = 500
np.random.seed(101)
df_sensors = pd.DataFrame({
    'Device_ID': np.random.choice([f'S{i:03d}' for i in range(10)], data_size),
    'Temperature_C': np.round(np.random.normal(25.0, 5.0, data_size), 2),
    'Pressure_kPa': np.round(np.random.normal(101.3, 2.0, data_size), 2),
    'Humidity_Pct': np.random.randint(40, 90, data_size),
    'Status': np.random.choice(['Active', 'Warning', 'Error'], data_size, p=[0.8, 0.15, 0.05])
})
# Introduce some explicit outliers and nulls
df_sensors.loc[10:15, 'Temperature_C'] = [5.0, 55.0, 25.0, np.nan, 30.0, 60.0]
df_sensors.loc[400:402, 'Pressure_kPa'] = [90.0, 115.0, np.nan]

# 1. Construct the Composite Mask
mask_error = df_sensors['Status'] == 'Error'
mask_temp_outlier = (df_sensors['Temperature_C'] < 10.0) | (df_sensors['Temperature_C'] > 50.0)
mask_pressure_nan = df_sensors['Pressure_kPa'].isna()

# Combine using logical OR (|)
critical_mask = mask_error | mask_temp_outlier | mask_pressure_nan

# 2. Isolate Critical Records using .loc
df_critical_alerts = df_sensors.loc[critical_mask]

# 3. Identify Safe Data using negation (~)
df_safe_data = df_sensors.loc[~critical_mask]

# 4. Refined Selection (Subset of Safe Data)
humidity_mask = df_safe_data['Humidity_Pct'] > 75
df_high_humidity_subset = df_safe_data.loc[humidity_mask, ['Device_ID', 'Temperature_C']]

print(f"Total critical alerts found: {df_critical_alerts.shape[0]}")

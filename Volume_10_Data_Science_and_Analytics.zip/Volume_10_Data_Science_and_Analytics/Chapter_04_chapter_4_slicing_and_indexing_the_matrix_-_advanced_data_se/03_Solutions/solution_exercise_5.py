
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# Setup the enhanced MultiIndex data (Re-running setup)
index_tuples_full = [
    ('North', 'Q1_2024'), ('North', 'Q2_2024'), ('North', 'Q3_2024'),
    ('South', 'Q1_2024'), ('South', 'Q2_2024'), ('South', 'Q3_2024'),
    ('East', 'Q1_2024'), ('East', 'Q2_2024'), ('East', 'Q3_2024')
]
multi_index_quarterly = pd.MultiIndex.from_tuples(index_tuples_full, names=['Region', 'Quarter'])

np.random.seed(99)
df_validation = pd.DataFrame({
    'Revenue_k': np.random.randint(50, 200, 9),
    'Cost_k': np.random.randint(40, 150, 9),
    'Audit_Flag': ['Clean'] * 9
}, index=multi_index_quarterly)

# Introduce validation failures
df_validation.loc[('North', 'Q2_2024'), 'Revenue_k'] = 250 # Outlier
df_validation.loc[('South', 'Q3_2024'), 'Cost_k'] = 10 # Extremely low cost
df_validation.loc[('East', slice(None)), 'Audit_Flag'] = 'Pending' # East is pending review

# 1. Step 1: Identify Initial Candidates (North and South regions)
df_candidates = df_validation.loc[['North', 'South'], :]

# 2. Step 2: Flag Revenue Outliers (Boolean Masking on Candidates)
revenue_outlier_mask = df_candidates['Revenue_k'] > 200
# Get the MultiIndex labels of the outliers
outlier_indices = revenue_outlier_mask[revenue_outlier_mask].index

# Update the original df_validation using the MultiIndex labels
df_validation.loc[outlier_indices, 'Audit_Flag'] = 'Revenue_Outlier'

# 3. Step 3: Positional Cost Check (Positional Slicing on Remaining Data)
# Target: North Q2 and Q3 (absolute positional indices 1 and 2 in df_validation)
# Cost_k column index: 1. Audit_Flag column index: 2.

# Check the conditions (Cost < 50 AND Flag is Clean) for indices 1 and 2
iloc_subset = df_validation.iloc[[1, 2]]
low_cost_clean_mask = (iloc_subset['Cost_k'] < 50) & (iloc_subset['Audit_Flag'] == 'Clean')

# Get the absolute positional indices (1 or 2) where the mask is True
# np.where returns indices relative to the slice [1, 2], so we add 1
iloc_indices_to_update = np.where(low_cost_clean_mask)[0] + 1

# Apply the update using .iloc for rows and .loc for the column label
if len(iloc_indices_to_update) > 0:
    audit_flag_col_pos = df_validation.columns.get_loc('Audit_Flag')
    df_validation.iloc[iloc_indices_to_update, audit_flag_col_pos] = 'Low_Cost_Alert'

# 4. Final Verification
assert (df_validation['Audit_Flag'] == 'Revenue_Outlier').sum() == 1
print(f"Final Audit Flags:\n{df_validation['Audit_Flag']}")

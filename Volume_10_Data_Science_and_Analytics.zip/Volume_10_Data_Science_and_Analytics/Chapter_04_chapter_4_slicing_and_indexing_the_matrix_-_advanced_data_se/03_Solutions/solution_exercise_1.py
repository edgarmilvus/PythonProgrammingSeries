
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import numpy as np

# Setup the simulated data (Re-running setup for clean environment)
np.random.seed(42)
dates = pd.date_range(start='2023-01-01', periods=20, freq='B')
data = {
    'Ticker': ['AAPL'] * 20,
    'Open': np.round(np.random.uniform(150, 180, 20), 2),
    'High': np.round(np.random.uniform(180, 190, 20), 2),
    'Low': np.round(np.random.uniform(140, 150, 20), 2),
    'Close': np.round(np.random.uniform(150, 180, 20), 2),
    'Volume': np.random.randint(1_000_000, 5_000_000, 20)
}
df_finance = pd.DataFrame(data, index=dates)
df_finance.index.name = 'Trade_Date'

# 1. Positional Price Slice: Rows 6th (index 5) to 12th (index 11, stop 12)
# Columns: Open(1), High(2), Low(3), Close(4) -> index 1:5
df_price_period = df_finance.iloc[5:12, 1:5]

# 2. Label-Based Audit Slice: Dates '2023-01-05' to '2023-01-16' (inclusive, 8 business days)
df_audit_period = df_finance.loc['2023-01-05':'2023-01-16', ['Open', 'Close']]

# 3. Mixed Access Challenge: Positional rows (first 5, index 0:5) +
# Label ('Ticker') and Positional Column (4, which is 'Volume')
columns_mixed = ['Ticker', df_finance.columns[4]] # ['Ticker', 'Volume']
df_mixed_selection = df_finance.iloc[:5][columns_mixed]

# 4. Verification
assert df_price_period.shape[1] == 4
assert df_audit_period.shape[0] == 8
print(f"df_price_period shape: {df_price_period.shape}")
print(f"df_audit_period shape: {df_audit_period.shape}")

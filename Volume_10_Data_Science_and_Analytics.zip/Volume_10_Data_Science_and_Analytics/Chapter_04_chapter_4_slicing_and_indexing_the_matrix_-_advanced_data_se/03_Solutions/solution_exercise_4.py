
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Setup the simulated Query Log (Re-running setup)
log_entries = 100
timestamps = pd.date_range(start='2024-01-01 09:00:00', periods=log_entries, freq='10S')
np.random.seed(88)
df_log = pd.DataFrame({
    'Query_ID': range(1000, 1000 + log_entries),
    'User': np.random.choice(['Admin', 'Analyst', 'Guest'], log_entries),
    'Execution_Time_ms': np.random.randint(10, 500, log_entries),
    'Status': np.random.choice(['SUCCESS', 'FAIL', 'TIMEOUT'], log_entries, p=[0.85, 0.10, 0.05])
}, index=timestamps)
df_log.index.name = 'Timestamp'

# 1. Positional Stepped Slicing: Start index 1 (second entry), step 5
# [1::5] means start=1, stop=end, step=5
df_sampled_rows = df_log.iloc[1::5]

# 2. Column Subset: Select specific columns using label indexing
df_monitoring_sample = df_sampled_rows[['Query_ID', 'Execution_Time_ms']]

# 3. Verification
assert df_monitoring_sample.shape[0] == 20
print(f"Monitoring sample size: {df_monitoring_sample.shape[0]} rows")

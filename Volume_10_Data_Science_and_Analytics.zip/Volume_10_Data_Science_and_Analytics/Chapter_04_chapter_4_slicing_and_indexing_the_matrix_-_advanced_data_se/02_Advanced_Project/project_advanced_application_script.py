
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import numpy as np

# --- 1. Setup MultiIndex and Simulated Retail Data ---
# Create hierarchical index levels: Region (Outer) and Store ID (Inner)
regions = ['North', 'South', 'East', 'West']
stores = [f'S{i:03d}' for i in range(1, 11)] # 10 stores per region
index_tuples = [(r, s) for r in regions for s in stores]
index = pd.MultiIndex.from_tuples(index_tuples, names=['Region', 'Store_ID'])

# Ensure data is reproducible for demonstration
np.random.seed(42)
data = {
    'Category': np.random.choice(['Electronics', 'Apparel', 'Home Goods'], size=len(index)),
    'Q1_Sales': np.random.randint(50000, 250000, size=len(index)),
    'Q2_Sales': np.random.randint(60000, 300000, size=len(index)),
    'Inventory': np.random.randint(100, 500, size=len(index)),
    'Rating': np.random.uniform(3.0, 5.0, size=len(index)).round(1)
}

# Create the Multi-Indexed DataFrame (40 rows, 5 columns)
df = pd.DataFrame(data, index=index)
# Sort the index, which is critical for efficient MultiIndex slicing (Step 7)
df.sort_index(inplace=True)

print("--- 1. Initial Multi-Indexed DataFrame Shape (40 rows) ---")
print(df.head(5), "\n")

# --- 2. Positional Slicing (.iloc) for Reporting ---
# Retrieve the 5th through 10th rows overall (positional index 4:10), 
# showing only Sales columns (positional index 1 and 2).
sales_columns_iloc = df.iloc[4:10, 1:3]
print("--- 2. .iloc: Positional Slice (Rows 5-10, Q1/Q2 Sales Columns) ---")
print(sales_columns_iloc, "\n")

# --- 3. Basic Label Selection (.loc) - Outer Index ---
# Select all data for the 'North' and 'East' regions using a list of labels.
north_east_data = df.loc[['North', 'East']]
print("--- 3. .loc: Selecting Multiple Outer Labels (North & East Regions) ---")
print(north_east_data.head(4), "\n")

# --- 4. Pure Boolean Masking (Identifying Underperformance) ---
# Identify stores where Q2 sales dropped compared to Q1, regardless of region or category.
sales_drop_mask = df['Q2_Sales'] < df['Q1_Sales']
underperforming_stores = df.loc[sales_drop_mask]
print("--- 4. Boolean Masking: Stores where Q2 Sales < Q1 Sales (Total Count) ---")
print(f"Total Underperforming Stores: {len(underperforming_stores)}", "\n")

# --- 5. Combined Label and Boolean Filtering (Targeted Intervention) ---
# Find 'Apparel' category stores in the 'South' region that have critically low inventory (< 200).
# We use pd.IndexSlice (idx) for clean MultiIndex row selection combined with a Boolean mask.
idx = pd.IndexSlice

# Step A: Structural selection using .loc on the index ('South', all stores)
# Step B: Value filtering using a separate Boolean mask on the resulting subset
south_apparel_low_inv = df.loc[
    idx['South', :],  # Target all stores in 'South' region (Structural Filter)
    :                 # Target all columns
].loc[
    (df['Category'] == 'Apparel') & (df['Inventory'] < 200) # Apply complex Boolean mask (Value Filter)
]
print("--- 5. Combined .loc & Masking: South Apparel, Low Inventory (< 200) ---")
print(south_apparel_low_inv, "\n")

# --- 6. Advanced MultiIndex Lookup: Specific Tuples ---
# Retrieve the 'Rating' and 'Inventory' for specific, non-contiguous stores S001 and S005 in the 'West' region.
# This requires providing a list of full index tuples (Region, Store_ID).
specific_stores_data = df.loc[
    [('West', 'S001'), ('West', 'S005')], # List of specific (Region, Store_ID) tuples
    ['Rating', 'Inventory']               # List of specific columns
]
print("--- 6. Advanced MultiIndex Lookup: Specific Stores & Columns ---")
print(specific_stores_data, "\n")

# --- 7. Slicing across the Inner Index Level ---
# Select all data from the 'South' region, but only for stores S005 through S008.
# When slicing the inner level (Store_ID), the standard Python slice object must be used.
south_store_range = df.loc[('South', slice('S005', 'S008')), :]
print("--- 7. MultiIndex Inner Level Slicing (Stores S005 to S008 in South) ---")
print(south_store_range, "\n")

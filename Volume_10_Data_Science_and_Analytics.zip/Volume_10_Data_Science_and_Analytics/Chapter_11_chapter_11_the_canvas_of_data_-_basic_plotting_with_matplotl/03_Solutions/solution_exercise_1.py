
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
import matplotlib.pyplot as plt

# Data Setup
quarters = np.arange(1, 9) 
sales_premium = np.array([120, 135, 140, 160, 180, 195, 210, 230])
sales_budget = np.array([100, 95, 110, 125, 140, 130, 150, 165]) 

# 1. Figure and Plot Generation (using implicit pyplot interface)
plt.figure(figsize=(10, 6))

# 2. & 3. Series Plotting and Customization
plt.plot(quarters, sales_premium, 
         color='blue', 
         linestyle='--', 
         label='Premium Line')

plt.plot(quarters, sales_budget, 
         color='red', 
         linestyle='-', 
         label='Budget Line')

# 4. Labeling and Title
plt.title("Q1 2023 - Q4 2024 Sales Performance Comparison", fontsize=14)
plt.xlabel("Quarter Number")
plt.ylabel("Sales Volume (in Thousands)")

# 5. Legend Implementation (Upper Left)
plt.legend(loc='upper left')

# 6. Axis Limits
plt.ylim(80, 250)

# Ensure layout is clean
plt.grid(True, which='both', linestyle='--', linewidth=0.5)
plt.show()

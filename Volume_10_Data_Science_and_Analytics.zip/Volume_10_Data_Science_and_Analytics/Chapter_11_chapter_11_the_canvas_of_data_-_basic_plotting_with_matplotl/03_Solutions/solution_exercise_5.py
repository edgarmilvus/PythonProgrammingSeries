
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np
import matplotlib.pyplot as plt

# Data Setup
np.random.seed(100)
data_x = np.arange(10)
data_y = data_x**2 + np.random.normal(0, 5, 10)
data_hist = np.random.normal(50, 10, 500)

# 1. User Input
plot_type = input("Enter desired plot type (line, scatter, hist): ").lower().strip()

# Dictionary mapping plot types to their corresponding plotting functions
# This structure facilitates EAFP: if plot_type is not a key, accessing plot_funcs[plot_type] 
# will raise a KeyError, triggering the except block.
plot_funcs = {
    'line': lambda: plt.plot(data_x, data_y, 'b-'),
    'scatter': lambda: plt.scatter(data_x, data_y, c='r', marker='x'),
    'hist': lambda: plt.hist(data_hist, bins=20, edgecolor='k')
}

plt.figure(figsize=(8, 5))

# 2. EAFP Implementation
try:
    # Attempt to retrieve and execute the function corresponding to the user input
    plot_funcs[plot_type]() 
    
    # Labeling for successful plots
    plt.title(f"Requested Plot: {plot_type.capitalize()}")
    if plot_type != 'hist':
        plt.xlabel("X Data")
        plt.ylabel("Y Data")
    else:
        plt.xlabel("Data Values")
        plt.ylabel("Frequency")
        
    # 3. Feedback
    print("Successfully generated requested plot.")

except KeyError:
    # 4. Except Block (Forgiveness) - Default Plot
    plt.plot(data_x, data_y, 'k--')
    plt.title("Default Plot: Line Plot")
    plt.xlabel("X Data")
    plt.ylabel("Y Data")
    
    # 3. Feedback
    print("Invalid plot type requested. Defaulting to Line Plot.")

plt.grid(True, alpha=0.3)
plt.show()

# NOTE: To test the default behavior, run the script and enter 'bar' or 'pie'.

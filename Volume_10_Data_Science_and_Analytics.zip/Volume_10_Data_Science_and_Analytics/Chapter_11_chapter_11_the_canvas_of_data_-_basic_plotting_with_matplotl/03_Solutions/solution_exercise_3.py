
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np
import matplotlib.pyplot as plt

# Data Setup
np.random.seed(10)
temperature_readings = np.random.normal(98.6, 0.5, 2000)

# 1. Subplot Structure (OO Approach: 2 rows, 1 column)
fig, axs = plt.subplots(2, 1, figsize=(8, 8), sharex=True)

# 4. Main Figure Title
fig.suptitle("Sensor Calibration Assessment", fontsize=16, fontweight='bold')

# --- Top Plot (Frequency) ---
# 2. Plot Histogram (Frequency)
axs[0].hist(temperature_readings, bins=30, color='skyblue', edgecolor='black')
axs[0].set_title("Frequency Distribution (Bin Count)")
axs[0].set_ylabel("Count of Readings")
axs[0].axvline(98.6, color='red', linestyle='--', linewidth=1, label='Target Mean')
axs[0].legend()


# --- Bottom Plot (Density) ---
# 3. Plot Histogram (Density)
axs[1].hist(temperature_readings, bins=30, density=True, color='lightcoral', edgecolor='black', alpha=0.8)
axs[1].set_title("Density Distribution (Normalized)")
axs[1].set_ylabel("Probability Density")

# 4. Common X-axis label (applied to the bottom plot)
axs[1].set_xlabel("Temperature Reading (°C)")

# 5. Spacing
plt.tight_layout(rect=[0, 0, 1, 0.96]) # Adjust layout to make room for suptitle
plt.show()

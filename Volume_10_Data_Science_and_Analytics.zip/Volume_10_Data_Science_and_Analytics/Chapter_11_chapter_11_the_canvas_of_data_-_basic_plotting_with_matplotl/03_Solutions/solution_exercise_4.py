
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np
import matplotlib.pyplot as plt

# Data Setup
x = np.linspace(0, 10, 100)
y1 = np.sin(x)
y2 = x * np.exp(-x)

# 1. OO Initialization (2 rows, 1 column)
fig, (ax1, ax2) = plt.subplots(nrows=2, ncols=1, figsize=(8, 6))

# 5. Figure Title
fig.suptitle("Refactored Dual-Panel Visualization", fontsize=16, fontweight='bold')

# 4. Shared Labeling (Figure Y-Label)
# Use fig.supylabel for a label centered on the figure's Y-axis
fig.supylabel("Amplitude/Value", fontsize=12) 

# --- Top Axes (ax1) ---
# 2. Line Plot
ax1.plot(x, y1, color='green', linestyle='-')
ax1.set_title("Sine Wave (Line Plot)")
ax1.grid(True, axis='y', alpha=0.5)

# --- Bottom Axes (ax2) ---
# 3. Scatter Plot
ax2.scatter(x, y2, color='black', marker='o', s=15)
ax2.set_title("Exponential Decay (Scatter Plot)")

# 4. Shared Labeling (Axes X-Label)
ax2.set_xlabel("Time (t)")

plt.tight_layout(rect=[0, 0, 1, 0.95]) # Adjust for suptitle
plt.show()

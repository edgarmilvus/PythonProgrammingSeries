
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Cell 1 (Initialization)
# This cell must be executed first for the subsequent cells to work correctly.
base_value = 100
data_list = [10, 20, 30]

# Cell 2 (Dependent Calculation - Run BEFORE Cell 1 initially)
# This calculation relies on variables defined in Cell 1, and an invalid index.
try:
    # Initial execution (before Cell 1 run): NameError (base_value not defined)
    # Second execution (after Cell 1 run): IndexError (data_list index 3 is out of bounds)
    result = base_value + data_list[3]
    print(f"Result: {result}")
except NameError as e:
    print(f"Caught expected NameError: {e}")
except IndexError as e:
    print(f"Caught expected IndexError: {e}")

# Cell 3 (Markdown - Documentation of Errors)
"""
### Execution Flow Analysis

1.  **Initial Run of Cell 2 (Before Cell 1):** Resulted in `NameError: name 'base_value' is not defined`. This confirms that the kernel state was empty, and the variable definition in Cell 1 had not yet been processed.
2.  **Second Run of Cell 2 (After Cell 1):** Resulted in `IndexError: list index out of range`. This confirms that `base_value` was loaded, but the list access `data_list[3]` failed because the list only contains indices 0, 1, and 2.
"""

# Cell 4 (Successful Execution - Corrected Index)
# Correcting the index to ensure successful calculation.
result_success = base_value + data_list[1] # Accessing the value 20
print(f"Final calculated result: {result_success}")

# Cell 5 (EAFP vs. LBYL Setup)
user_profile = {'name': 'Alice', 'role': 'Analyst'}
ERROR_MESSAGE = "Key not found in profile."

def get_key_lbyl(data_dict, key):
    """LBYL: Checks for existence before accessing."""
    # Look Before You Leap (LBYL)
    if key in data_dict:
        return data_dict[key]
    else:
        return ERROR_MESSAGE

def get_key_eafp(data_dict, key):
    """EAFP: Attempts access and handles exceptions."""
    # Easier to Ask for Forgiveness than Permission (EAFP)
    try:
        return data_dict[key]
    except KeyError:
        return ERROR_MESSAGE

# Cell 6 (Testing the Approaches)
# Test 1: Valid key access
lbyl_valid = get_key_lbyl(user_profile, 'name')
eafp_valid = get_key_eafp(user_profile, 'name')

# Test 2: Invalid key access
lbyl_invalid = get_key_lbyl(user_profile, 'department')
eafp_invalid = get_key_eafp(user_profile, 'department')

print(f"LBYL (Valid): {lbyl_valid}")
print(f"EAFP (Valid): {eafp_valid}")
print("-" * 20)
print(f"LBYL (Invalid): {lbyl_invalid}")
print(f"EAFP (Invalid): {eafp_invalid}")

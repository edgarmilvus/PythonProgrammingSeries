
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Cell 1 (Markdown - Reproducibility Documentation)
"""
### Importance of PEP 8 Compliance in Model Definition

PEP 8 compliance is critical when defining data models (classes) in a shared environment because it enforces consistency and readability. Using `CamelCase` for class names and `snake_case` for attributes and methods ensures that the model structure is immediately recognizable and maintainable by any Python developer, reducing cognitive load and facilitating future integration with ORMs or validation layers.
"""

# Cell 2 (Code - Class Definition)
class UserAccount:
    """
    Represents a user record in the system, typically mapping
    to a row in a database table.
    """
    def __init__(self, user_id, username, is_active):
        # Attributes use snake_case, adhering to PEP 8 for variables
        self.user_id = user_id
        self.username = username
        self.is_active = is_active

    def get_status_description(self):
        """Returns a string describing the user's active status."""
        if self.is_active:
            return f"User {self.username} is Active."
        else:
            return f"User {self.username} is Inactive."

# Cell 3 (Code - Instantiation and Testing)
# Create instances using snake_case variables
user_1 = UserAccount(
    user_id=1,
    username='jdoe',
    is_active=True
)

user_2 = UserAccount(
    user_id=2,
    username='smith_arch',
    is_active=False
)

# Verification
print(f"User 1 Status: {user_1.get_status_description()}")
print(f"User 2 Status: {user_2.get_status_description()}")

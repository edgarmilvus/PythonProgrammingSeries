
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Re-define necessary components from Exercise 2 for isolated testing
user_profile = {'name': 'Alice', 'role': 'Analyst'}
ERROR_MESSAGE = "Key not found in profile."

def get_key_lbyl(data_dict, key):
    """LBYL: Checks for existence before accessing."""
    if key in data_dict:
        return data_dict[key]
    else:
        return ERROR_MESSAGE

def get_key_eafp(data_dict, key):
    """EAFP: Attempts access and handles exceptions."""
    try:
        return data_dict[key]
    except KeyError:
        return ERROR_MESSAGE

# Cell 1: LBYL Timing (1,000,000 loops)
print("Timing LBYL (Existing Key):")
%timeit -n 1000000 get_key_lbyl(user_profile, 'role')

# Cell 2: EAFP Timing (1,000,000 loops)
print("\nTiming EAFP (Existing Key):")
%timeit -n 1000000 get_key_eafp(user_profile, 'role')

# Cell 3 (Markdown - Performance Analysis)
"""
### Performance Analysis of Dictionary Access

For accessing an *existing* key, the **EAFP** approach (`try...except`) is typically faster than the LBYL approach (`if key in dict`). This is because the LBYL method involves two dictionary lookups (one for the `in` check, one for the retrieval), whereas EAFP only performs one lookup, relying on optimized exception handling pathways when the key is found (the common case).
"""

# Cell 4: Environment Inspection
print("--- Variables Only (%who_ls) ---")
%who_ls

print("\n--- Detailed Environment Inspection (%whos) ---")
# Show all variables, functions, and imported modules
%whos

# Cell 5: Cleanup Simulation
temp_counter = 5 # Define a temporary variable
print("\n--- After defining temp_counter ---")
%whos

# Clear the temporary variable
del temp_counter
print("\n--- After deleting temp_counter ---")
%whos

# Cell 6: Shell Command Integration
print("\n--- Listing Current Directory Contents (!ls/!dir) ---")
# Use !ls for Unix/Linux/macOS or !dir for Windows
!ls

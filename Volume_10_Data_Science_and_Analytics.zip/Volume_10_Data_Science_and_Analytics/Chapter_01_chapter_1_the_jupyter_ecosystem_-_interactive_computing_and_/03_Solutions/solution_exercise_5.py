
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# Cell 1: Simulating the Legacy Script using %%writefile
%%writefile legacy_script.py
# legacy_script.py content
def process_large_dataset(n):
    """Simulates a time-consuming data processing task."""
    results = []
    # Simulate heavy computation
    for i in range(n):
        results.append(i * i)
    return f"Processed {n} items."

def cleanup_variables():
    """Placeholder for cleanup logic."""
    print("Cleanup initiated.")

# Cell 2: Modular Integration and Verification
# Execute the external script, loading its functions into the kernel namespace
%run legacy_script.py

# Verify the functions are loaded
print("--- Kernel Namespace after %run ---")
%whos

# Cell 3: Baseline Performance Analysis
print("--- Baseline Timing (500,000 operations) ---")
# Use %time to measure a single execution run
%time process_large_dataset(500000)

# Cell 4: Refactoring Challenge (Modifying the function in the notebook)
# Redefine the function to include the cleanup logic
def process_large_dataset(n):
    """Simulates a time-consuming data processing task, now including cleanup."""
    results = []
    for i in range(n):
        results.append(i * i)
    
    # Call the cleanup function defined in the external script
    cleanup_variables() 
    return f"Processed {n} items with cleanup."

# Cell 5: Re-execution and Timing of Refactored Function
print("--- Timing Refactored Function (500,000 operations) ---")
# The kernel now uses the new definition from Cell 4
%time process_large_dataset(500000)

# Cell 6 (Markdown Analysis)
"""
### Conclusion on Modularity and %run

The `%run` magic command provides a critical advantage over simply copying and pasting code: **modularity and a clean notebook structure.**

1.  **Modularity:** `%run` keeps the complex, reusable logic (like `legacy_script.py`) separate from the narrative and execution flow of the notebook. This makes the notebook shorter, more readable, and easier to share.
2.  **Namespace Integration:** `%run` executes the script and imports its definitions (variables, functions) directly into the kernel's global namespace, allowing the notebook to immediately call those functions, as demonstrated by calling `process_large_dataset` and `cleanup_variables`.
3.  **Interactive Refactoring:** We were able to redefine `process_large_dataset` directly in a subsequent cell, overriding the definition loaded by `%run`, and immediately test the performance impact of the change using `%time`, showcasing the rapid prototyping power of Jupyter.
"""

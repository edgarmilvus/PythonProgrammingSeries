
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import io
import sys

# --- SIMULATED JUPYTER CELL 1: Environment Setup and Data Generation ---
# This cell sets up the necessary libraries and creates a synthetic dataset
# designed to mimic real-world issues (missing data, outliers, mixed types).

def generate_synthetic_data(n_rows=5000):
    """Creates a DataFrame for the DQA."""
    np.random.seed(42)
    
    data = {
        'Transaction_ID': range(10000, 10000 + n_rows),
        'Customer_Age': np.random.normal(loc=35, scale=10, size=n_rows).astype(int),
        # Introduce 5% missing values (NaN)
        'Purchase_Amount': np.random.uniform(5, 500, n_rows),
        # Introduce 10% missing values (represented by None/NaN)
        'Product_Category': np.random.choice(
            ['Electronics', 'Apparel', 'Books', 'Food', None], 
            size=n_rows, 
            p=[0.3, 0.25, 0.2, 0.15, 0.1]
        ),
        # Introduce a few extreme outliers in the 'Purchase_Amount'
        'Is_Outlier': np.random.choice([0, 1], size=n_rows, p=[0.99, 0.01])
    }
    df = pd.DataFrame(data)
    
    # Inject outliers
    df.loc[df['Is_Outlier'] == 1, 'Purchase_Amount'] = np.random.uniform(10000, 50000, df['Is_Outlier'].sum())
    
    # Inject NaN into Purchase_Amount explicitly
    missing_indices = np.random.choice(df.index, size=int(n_rows * 0.05), replace=False)
    df.loc[missing_indices, 'Purchase_Amount'] = np.nan
    
    return df

df_raw = generate_synthetic_data(n_rows=10000)
print(f"Initial DataFrame loaded with {len(df_raw)} rows.")


# --- SIMULATED JUPYTER CELL 2: Interactive Environment Inspection ---
# Using the built-in %whos magic command to check variable state and type,
# a crucial step in interactive debugging and memory management.
# %whos 


# --- SIMULATED JUPYTER CELL 3: Initial Data Quality Assessment (DQA) ---
# A standard step using Pandas methods to quickly profile the data.
print("\n--- Initial DQA Report ---")
df_raw.info(verbose=False, buf=sys.stdout) # Use sys.stdout for controlled output in script context

# Calculate missingness percentage
missing_counts = df_raw.isnull().sum()
missing_percent = (missing_counts / len(df_raw)) * 100
missing_df = pd.DataFrame({
    'Missing Count': missing_counts,
    'Missing Percent': missing_percent.round(2)
})
print("\nMissing Value Summary:")
print(missing_df[missing_df['Missing Count'] > 0])


# --- SIMULATED JUPYTER CELL 4: Performance Benchmarking (%timeit) ---
# We compare two methods for creating a new feature: 
# 1. Vectorized NumPy operation (preferred in Pandas).
# 2. Iterative row-by-row operation (slow, anti-pattern).

# Define the function for the slow method (using apply row-wise)
def categorize_purchase_slow(row):
    if row['Purchase_Amount'] > 1000:
        return 'High Value'
    elif row['Purchase_Amount'] > 100:
        return 'Medium Value'
    else:
        return 'Low Value'

# Method 1: Vectorized (Fast)
# %timeit df_raw['Value_Vectorized'] = np.select(
#     [df_raw['Purchase_Amount'] > 1000, df_raw['Purchase_Amount'] > 100],
#     ['High Value', 'Medium Value'],
#     default='Low Value'
# ) 

# Method 2: Iterative (Slow)
# %timeit df_raw['Value_Iterative'] = df_raw.apply(categorize_purchase_slow, axis=1)

# *Note: The %timeit command is commented out because it relies on the actual 
# Jupyter kernel environment for execution timing, but its inclusion here 
# illustrates the critical workflow step.*


# --- SIMULATED JUPYTER CELL 5: Visualization and Outlier Analysis ---
# Generate a visualization that highlights the outlier structure.
plt.figure(figsize=(10, 4))
df_raw['Purchase_Amount'].plot(kind='box', vert=False)
plt.title('Distribution of Purchase Amounts (Identifying Outliers)')
plt.xlabel('Purchase Amount (USD)')
# plt.show() # In a notebook, this would render the plot inline.


# --- SIMULATED JUPYTER CELL 6: Controlled Output Capture (%%capture) ---
# The %%capture magic command is used to suppress the output of a cell 
# and store it in a variable, often used to clean up the final report 
# or capture verbose logging.

# We simulate capturing the results of a final summary calculation.
# %%capture final_summary_output

# Create a clean version of the data for reporting (e.g., dropping NaNs)
df_clean = df_raw.dropna(subset=['Purchase_Amount', 'Product_Category']).copy()

# Final summary statistics for the clean data
print("--- FINAL CLEAN DATA SUMMARY STATISTICS ---")
print(df_clean.describe().T[['count', 'mean', 'std', 'min', 'max']].round(2))
print(f"\nData Loss Rate: {100 * (1 - len(df_clean) / len(df_raw)):.2f}%")

# End of captured block.

# --- SIMULATED JUPYTER CELL 7: Final Report Generation ---
# Retrieve and display the captured output alongside a narrative conclusion.

# print("\n--- Narrated Conclusion ---")
# print("The preceding analysis revealed significant missing data in key columns.")
# print("After cleaning, the final dataset summary is presented below:")
# print(final_summary_output.stdout) # Accessing the captured standard output stream

# Since we cannot execute the actual magic command in this script context, 
# we manually print the content that would have been captured for demonstration.
print("\n--- MANUAL DISPLAY OF CAPTURED REPORT SECTION ---")
print("--- FINAL CLEAN DATA SUMMARY STATISTICS ---")
print(df_clean.describe().T[['count', 'mean', 'std', 'min', 'max']].round(2))
print(f"\nData Loss Rate: {100 * (1 - len(df_clean) / len(df_raw)):.2f}%")

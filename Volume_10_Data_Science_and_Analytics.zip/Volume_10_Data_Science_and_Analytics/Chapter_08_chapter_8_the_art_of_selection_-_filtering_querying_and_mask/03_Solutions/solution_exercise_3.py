
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from datetime import timedelta

# 1. Define the acceptable delay threshold as a timedelta object
seven_days = timedelta(days=7)

# 2. Calculate the actual delay time for all transactions
delay_time = df_sales['ShipDate'] - df_sales['OrderDate']

# 3. Construct the mask: (Delay > 7 days) AND (Inventory > 100)
# Note: Pandas allows direct comparison between a timedelta Series and a timedelta scalar
mask_delay_exceeded = delay_time > seven_days
mask_ample_inventory = df_sales['InventoryLevel'] > 100

final_delay_mask = mask_delay_exceeded & mask_ample_inventory

# Apply the mask using .loc
df_inexcusable_delays = df_sales.loc[final_delay_mask]

# print(df_inexcusable_delays[['OrderDate', 'ShipDate', 'InventoryLevel']].head())
# print(f"Total inexcusable delays found: {len(df_inexcusable_delays)}")

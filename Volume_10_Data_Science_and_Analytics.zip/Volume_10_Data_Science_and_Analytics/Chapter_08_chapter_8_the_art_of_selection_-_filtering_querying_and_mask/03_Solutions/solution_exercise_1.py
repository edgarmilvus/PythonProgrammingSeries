
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# Define the criteria using standard Boolean masking and parentheses for precedence

# Criterion 1: High revenue in specific regions
mask_high_revenue = (
    (df_sales['Revenue'] > 3500) & 
    (df_sales['Region'].isin(['North', 'South']))
)

# Criterion 2: Low inventory for Electronics
mask_low_inventory_risk = (
    (df_sales['ProductCategory'] == 'Electronics') & 
    (df_sales['InventoryLevel'] < 50)
)

# Combine the two primary criteria using the OR operator (|)
final_mask = mask_high_revenue | mask_low_inventory_risk

# Use .loc to apply the mask and select the required columns
required_columns = ['OrderID', 'Region', 'ProductCategory', 'Revenue', 'InventoryLevel']
df_high_stakes = df_sales.loc[final_mask, required_columns]

# print(df_high_stakes.head())
# print(f"Total high-stakes transactions found: {len(df_high_stakes)}")

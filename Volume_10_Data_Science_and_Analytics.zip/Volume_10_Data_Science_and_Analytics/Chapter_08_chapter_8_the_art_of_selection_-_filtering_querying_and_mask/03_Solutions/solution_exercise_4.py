
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Methodology Choice: Using standard Boolean masking with .loc is preferred here
# because the requirement mandates the use of the negation operator (~), which
# is applied directly and cleanly to a Pandas Boolean Series mask.

# Define the two components of the UNDESIRABLE criteria:

# 1. Undesirable Category/Region combination
mask_u1 = (df_sales['ProductCategory'].isin(['Services', 'Software'])) & \
          (df_sales['Region'] == 'East')

# 2. Low Revenue
mask_u2 = df_sales['Revenue'] < 500

# Combine to create the full mask for UNDESIRABLE transactions
mask_undesirable = mask_u1 | mask_u2

# Apply the negation operator (~) to select all rows that are NOT undesirable
df_clean_report_data = df_sales.loc[~mask_undesirable]

# Verification: Confirm no rows have revenue less than $500
verification_check = (df_clean_report_data['Revenue'] < 500).any()

# print(f"Are there any transactions with Revenue < $500 in the clean data? {verification_check}")
# print(df_clean_report_data.shape)

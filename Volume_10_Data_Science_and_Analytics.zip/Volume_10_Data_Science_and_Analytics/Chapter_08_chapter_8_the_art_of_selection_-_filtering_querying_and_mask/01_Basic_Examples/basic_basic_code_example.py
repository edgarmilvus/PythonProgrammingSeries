
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import pandas as pd
import numpy as np

# 1. Data Setup: Creating a simple DataFrame of fictional employees
# We define the raw data using a dictionary structure.
data = {
    'Employee_ID': [101, 102, 103, 104, 105, 106, 107],
    'Department': ['Sales', 'Engineering', 'HR', 'Sales', 'Engineering', 'Marketing', 'HR'],
    'Salary': [75000, 120000, 60000, 95000, 150000, 80000, 70000],
    'Years_of_Service': [3, 8, 2, 5, 10, 4, 1]
}

# Instantiate the DataFrame object
df_employees = pd.DataFrame(data)

print("--- Original DataFrame (df_employees) ---")
print(df_employees)
print("-" * 60)

# 2. Defining the Selection Criterion (The Threshold)
# Using a variable makes the code readable and easy to modify.
salary_threshold = 100000

# 3. Creating the Boolean Mask (The core filtering mechanism)
# This operation compares every element in the 'Salary' column against the threshold.
# The result is a Pandas Series composed solely of True/False values.
mask_high_earners = df_employees['Salary'] > salary_threshold

print("--- Boolean Mask (Series) ---")
# Note how the index aligns perfectly with the original DataFrame.
print(mask_high_earners)
print("-" * 60)

# 4. Applying the Mask to Filter the DataFrame
# Placing the mask inside the DataFrame's selection brackets ([...])
# tells Pandas to return only the rows corresponding to True values in the mask.
df_high_earners = df_employees[mask_high_earners]

print("--- Filtered DataFrame (High Earners) ---")
print(df_high_earners)
print("-" * 60)

# 5. Advanced Filtering: Combining Multiple Conditions
# Task: Find employees in 'Engineering' AND with more than 6 years of service.
# CRITICAL: Each condition must be wrapped in parentheses, and the bitwise AND (&) must be used.
condition_dept = (df_employees['Department'] == 'Engineering')
condition_service = (df_employees['Years_of_Service'] > 6)

# Combine the two Boolean Series using the bitwise AND operator (&)
combined_mask = condition_dept & condition_service

# Apply the complex mask
df_specific_filter = df_employees[combined_mask]

print("--- Filtered DataFrame (Senior Engineering Subset) ---")
print(df_specific_filter)
print("-" * 60)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import numpy as np
import re
from sklearn.experimental import enable_iterative_imputer
from sklearn.impute import IterativeImputer
from sklearn.linear_model import BayesianRidge

# --- 1. DATA SIMULATION (The Dirty Dataset) ---
# Simulating customer data with mixed missingness and type errors
data = {
    'CustomerID': range(101, 121),
    # Age: Numerical, some np.nan, and one entry as a string ('40')
    'Age': [25, 30, np.nan, 45, 22, 50, 33, np.nan, 60, 28, 
            35, 40, 29, 55, 31, np.nan, 48, 32, 27, '40'], 
    # Annual_Spend: String format ('k' suffix, 'N/A' placeholder), and np.nan
    'Annual_Spend': ['150k', '200k', '100k', 'N/A', '75k', '50k', '180k', 
                     '90k', '120k', '110k', '130k', '250k', np.nan, '80k', 
                     '160k', '140k', '60k', '190k', '170k', '220k'],
    # Region: Categorical, one entry uses 'NA' (Not Applicable/Available) string, not NaN
    'Region': ['East', 'West', 'Central', 'East', 'South', 'West', 'Central', 
               'East', 'West', 'NA', 'South', 'East', 'Central', 
               'West', 'South', 'East', 'West', 'Central', 'East', 'West'],
    # Subscription_Date: Inconsistent formats ('YYYY-MM-DD' vs 'YYYY/MM/DD') and np.nan
    'Subscription_Date': ['2023-01-15', '2023/02/20', '2023-03-01', np.nan, 
                          '2023-05-10', '2023/06/05', '2023-07-11', '2023-08-01', 
                          '2023-09-15', '2023-10-20', '2023-11-01', '2023-12-12', 
                          '2024-01-01', '2024/02/15', '2024-03-20', np.nan, 
                          '2024-05-01', '2024-06-10', '2024-07-15', '2024-08-01']
}
df = pd.DataFrame(data)

# --- 2. PHASE 1: Initial Type Correction and Standardization ---

# Convert Age to numeric, coercing errors (the '40' string becomes 40, errors become NaN)
df['Age'] = pd.to_numeric(df['Age'], errors='coerce') 

def clean_spend(spend_str):
    """Cleans Annual_Spend strings, handles 'k' and 'N/A'."""
    if pd.isna(spend_str) or spend_str == 'N/A':
        return np.nan
    # Use regex to find numerical part and convert 'k' notation
    match = re.search(r'(\d+)', str(spend_str))
    if match:
        value = int(match.group(1))
        if 'k' in str(spend_str).lower():
            return value * 1000
        return value
    return np.nan

# Apply the cleaning function to the Annual_Spend column
df['Annual_Spend'] = df['Annual_Spend'].apply(clean_spend)

# --- 3. PHASE 2: Predictive Imputation (Addressing MAR) ---

# We assume Age and Annual_Spend are MAR (Missing At Random), meaning one 
# can be predicted by the other. IterativeImputer is used (MICE).
numerical_cols = ['Age', 'Annual_Spend']

# Initialize IterativeImputer using BayesianRidge estimator for robust prediction
imputer = IterativeImputer(
    estimator=BayesianRidge(), 
    max_iter=10, 
    random_state=42
)

# Fit and transform the numerical data block
df[numerical_cols] = imputer.fit_transform(df[numerical_cols])

# Convert imputed floats back to integers (since age/spend are whole numbers)
df['Age'] = df['Age'].round().astype(int)
df['Annual_Spend'] = df['Annual_Spend'].round().astype(int)

# --- 4. PHASE 3: Handling Categorical and Temporal Variables ---

# A. Categorical Cleaning: Handle the string 'NA' (Not Available)
# Identify the true mode (most frequent non-NaN value)
mode_region = df['Region'].mode()[0] 
# Replace the inconsistent 'NA' string with the calculated mode
df['Region'] = df['Region'].replace('NA', mode_region)
# Convert to efficient categorical type
df['Region'] = df['Region'].astype('category')

# B. Temporal Cleaning: Standardize format and impute
# Use pd.to_datetime to handle inconsistent formats automatically
df['Subscription_Date'] = pd.to_datetime(
    df['Subscription_Date'], 
    format='mixed', 
    errors='coerce'
)

# Temporal Imputation: Use Forward Fill (ffill) followed by Backward Fill (bfill)
# This assumes missing dates are close to the preceding observed date (time series logic)
df['Subscription_Date'] = df['Subscription_Date'].fillna(method='ffill').fillna(method='bfill')

# --- 5. VERIFICATION AND SUMMARY ---

print("--- Data Cleaning Summary ---")
print("\nFinal Data Types:")
print(df.dtypes)
print("\nMissing Values Check (Should be 0):")
print(df.isnull().sum())
print("\nCleaned Data Head:")
print(df.head())



#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import pandas as pd
import numpy as np

# --- Starter Data Setup ---
df3 = pd.DataFrame({
    'Transaction_ID': range(500),
    'Product_SKU': [f'SKU_{i % 150}' for i in range(500)],
    'Transaction_Amount': np.random.uniform(10, 500, 500),
    'Date_Received': pd.to_datetime(['2023-01-01', '01/02/23', '2023-Jan-03 14:00', '2023-01-04T10:00Z'] * 125, errors='coerce'),
    'Timezone_Info': ['EST', 'PST', 'UTC', 'EST'] * 125,
    'Target_Success': np.random.randint(0, 2, 500)
})
df3.loc[10:20, 'Date_Received'] = 'Invalid Date Format'
df3.loc[25:35, 'Date_Received'] = pd.NaT
df3_clean = df3.copy()

# 1. Temporal Cleaning and Standardization

# Coercion: Convert all possible formats, setting errors to NaT and making the result UTC-aware
df3_clean['Date_Received'] = pd.to_datetime(df3_clean['Date_Received'], errors='coerce', utc=True)

# Imputation: Calculate mode date (first element if multiple modes exist)
date_mode = df3_clean['Date_Received'].mode()[0]
df3_clean['Date_Received'].fillna(date_mode, inplace=True)

# Time Zone Handling: Convert all dates to UTC (already mostly done by utc=True, but ensures consistency)
df3_clean['Date_Received'] = df3_clean['Date_Received'].dt.tz_convert('UTC')

# Feature Extraction
df3_clean['Month_of_Year'] = df3_clean['Date_Received'].dt.month
df3_clean['Day_of_Week'] = df3_clean['Date_Received'].dt.dayofweek

print(f"Final Date_Received TZ: {df3_clean['Date_Received'].dt.tz}")
print(f"Sample Temporal Features: Month={df3_clean['Month_of_Year'].iloc[0]}, DayOfWeek={df3_clean['Day_of_Week'].iloc[0]}")

# 2. High Cardinality Encoding (Target Encoding with Smoothing)
SMOOTHING_FACTOR = 10 # K
global_mean = df3_clean['Target_Success'].mean()

# Calculate SKU specific statistics (mean and count)
sku_stats = df3_clean.groupby('Product_SKU')['Target_Success'].agg(['mean', 'count'])
sku_stats.rename(columns={'mean': 'SKU_Mean', 'count': 'SKU_Count'}, inplace=True)

# Apply smoothing formula: (N_i * Mean_i + K * Global_Mean) / (N_i + K)
sku_stats['SKU_Target_Encoded'] = (
    (sku_stats['SKU_Mean'] * sku_stats['SKU_Count']) + (global_mean * SMOOTHING_FACTOR)
) / (sku_stats['SKU_Count'] + SMOOTHING_FACTOR)

# Map the encoded values back
df3_clean['SKU_Target_Encoded'] = df3_clean['Product_SKU'].map(sku_stats['SKU_Target_Encoded'])

print(f"Sample Target Encoded Values (First 5): {df3_clean['SKU_Target_Encoded'].head().tolist()}")

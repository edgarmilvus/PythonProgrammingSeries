
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import numpy as np

# --- Starter Code Setup ---
np.random.seed(42)
data_size = 1000
df = pd.DataFrame({
    'Age': np.random.randint(20, 60, data_size),
    'Income': np.random.normal(50000, 15000, data_size),
    'Education': np.random.choice(['High School', 'Bachelors', 'Masters', 'PhD'], data_size),
    'Medical_History': np.random.randint(0, 10, data_size),
    'Response_Time': np.random.uniform(5, 30, data_size)
})
df.loc[df['Age'] > 50, 'Income'] = df.loc[df['Age'] > 50, 'Income'].apply(lambda x: np.nan if np.random.rand() < 0.6 else x)
mcar_indices = np.random.choice(df.index, size=int(0.05 * data_size), replace=False)
df.loc[mcar_indices, 'Response_Time'] = np.nan
df_initial = df.copy()

# 1. Diagnosis and Justification

# Response_Time (MCAR Check)
rt_missing = df_initial['Response_Time'].isnull()
rt_mean_observed = df_initial.loc[~rt_missing, 'Age'].mean()
rt_mean_missing = df_initial.loc[rt_missing, 'Age'].mean()

# Income (MAR Check)
income_missing = df_initial['Income'].isnull()
income_mean_observed = df_initial.loc[~income_missing, 'Age'].mean()
income_mean_missing = df_initial.loc[income_missing, 'Age'].mean()

print(f"--- Diagnosis ---")
print(f"Response_Time: Age mean observed ({rt_mean_observed:.2f}) vs missing ({rt_mean_missing:.2f})")
print(f"Income: Age mean observed ({income_mean_observed:.2f}) vs missing ({income_mean_missing:.2f})")

# 2. MCAR Imputation (Response_Time)
original_rt_mean = df_initial['Response_Time'].mean()
rt_median = df['Response_Time'].median()
df['Response_Time'].fillna(rt_median, inplace=True)
imputed_rt_mean = df['Response_Time'].mean()
mean_diff = abs(original_rt_mean - imputed_rt_mean)

# 3. Conditional MAR Imputation (Income)
# Impute Income based on the mean of the corresponding Education group
df['Income'].fillna(
    df.groupby('Education')['Income'].transform('mean'),
    inplace=True
)

# 4. Final Verification
final_missing = df.isnull().sum()
final_types = df[['Income', 'Response_Time']].dtypes

print(f"\nResponse Time Imputation Mean Diff: {mean_diff:.4f}")
print(f"Final Missing Counts:\n{final_missing[final_missing > 0]}")
print(f"Final Types:\n{final_types}")

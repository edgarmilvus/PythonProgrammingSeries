
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import pandas as pd
import numpy as np

def clean_and_prepare_data(raw_df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """
    Cleans and prepares the input DataFrame, tracking changes.
    """
    cleaning_metrics = {
        'total_cells_imputed': 0,
        'type_corrections': 0,
        'new_features_created': 0
    }

    df = raw_df.copy()

    # --- STEP 1: Type Casting and Cleanup (Column C) ---
    # Remove '%' and convert to float.
    df['C'] = df['C'].str.replace('%', '', regex=False).astype(float)
    cleaning_metrics['type_corrections'] += len(df)

    # --- STEP 2: Missing Value Handling (Imputation) ---

    # Column 'A' (Numerical) needs mean imputation.
    a_impute_count = df['A'].isnull().sum()
    if a_impute_count > 0:
        df['A'].fillna(df['A'].mean(), inplace=True)
        cleaning_metrics['total_cells_imputed'] += a_impute_count

    # Column 'D' (Categorical) needs mode imputation.
    d_impute_count = df['D'].isnull().sum()
    if d_impute_count > 0:
        d_mode = df['D'].mode()[0]
        df['D'].fillna(d_mode, inplace=True)
        cleaning_metrics['total_cells_imputed'] += d_impute_count

    # --- STEP 3: Temporal Feature Creation and Imputation (Column E) ---

    # Impute NaT values in 'E' using the mode date
    e_impute_count = df['E'].isnull().sum()
    if e_impute_count > 0:
        # Calculate the mode of the observed dates
        e_mode = df['E'].dropna().mode()[0]
        df['E'].fillna(e_mode, inplace=True)
        cleaning_metrics['total_cells_imputed'] += e_impute_count

    # Feature Extraction (Day of Month)
    df['E_DayOfMonth'] = df['E'].dt.day
    cleaning_metrics['new_features_created'] += 1

    # --- STEP 4: Encoding Categorical Variables (Column B) ---
    df = pd.get_dummies(df, columns=['B'], prefix='B', drop_first=True)

    # Return the processed DataFrame and the metrics dictionary
    return df, cleaning_metrics

# Sample Data for the challenge:
data_challenge = pd.DataFrame({
    'A': [10, 20, np.nan, 40, 50, np.nan, 70],
    'B': ['Y', 'N', 'Y', 'N', 'Y', 'N', 'Y'],
    'C': ['10%', '20%', '30%', '40%', '50%', '60%', '70%'],
    'D': ['Low', np.nan, 'Medium', 'High', 'Low', 'Medium', np.nan],
    'E': [pd.to_datetime('2024-01-01'), pd.NaT, pd.to_datetime('2024-01-03'), pd.to_datetime('2024-01-04'), pd.to_datetime('2024-01-05'), pd.NaT, pd.to_datetime('2024-01-07')]
})

# Execute the pipeline
cleaned_df, metrics = clean_and_prepare_data(data_challenge)

print("Final Cleaning Metrics:")
print(metrics)
print("\nCleaned DataFrame Head:")
print(cleaned_df.head())

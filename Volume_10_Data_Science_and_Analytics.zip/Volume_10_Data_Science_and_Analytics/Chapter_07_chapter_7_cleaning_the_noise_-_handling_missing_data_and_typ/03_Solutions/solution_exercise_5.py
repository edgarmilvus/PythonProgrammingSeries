
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import pandas as pd
import numpy as np
from scipy.stats import iqr

# --- Starter Data Setup (Re-run for context) ---
np.random.seed(42)
df_advanced = pd.DataFrame({
    'Lot_Area_SqFt': np.random.lognormal(mean=7, sigma=1.5, size=500),
    'Sale_Price': np.random.lognormal(mean=12, sigma=0.5, size=500),
    'Year_Built': np.random.randint(1900, 2020, 500)
})
df_advanced.loc[0, 'Lot_Area_SqFt'] = 0.0 # Zero value error
df_advanced.loc[1, 'Lot_Area_SqFt'] = -10.0 # Negative value error
df_advanced.loc[490:495, 'Sale_Price'] = df_advanced.loc[490:495, 'Sale_Price'] * 10 # Extreme outliers
df_advanced.loc[496:499, 'Sale_Price'] = np.nan # Missing values

def robust_data_preparation(df: pd.DataFrame) -> pd.DataFrame:
    df_clean = df.copy()
    
    # 1. Non-Positive Value Handling (Lot_Area_SqFt)
    EPSILON = 1e-6
    # Replace non-positive values (<= 0) with a tiny positive constant
    non_positive_mask = df_clean['Lot_Area_SqFt'] <= 0
    df_clean.loc[non_positive_mask, 'Lot_Area_SqFt'] = EPSILON
    
    # 2. Outlier Management (Sale_Price) - Winsorization (1.5 IQR rule)
    
    # Calculate Q1, Q3, and IQR, ignoring NaNs
    Q1 = df_clean['Sale_Price'].quantile(0.25)
    Q3 = df_clean['Sale_Price'].quantile(0.75)
    IQR = Q3 - Q1
    
    # Define bounds
    LOWER_BOUND = Q1 - 1.5 * IQR
    UPPER_BOUND = Q3 + 1.5 * IQR
    
    # Apply Winsorization. NaNs are preserved by default in clip.
    df_clean['Sale_Price_Winsorized'] = df_clean['Sale_Price'].clip(lower=LOWER_BOUND, upper=UPPER_BOUND)
    
    # 3. Missing Value Imputation (Sale_Price)
    price_median = df_clean['Sale_Price_Winsorized'].median()
    df_clean['Sale_Price_Winsorized'].fillna(price_median, inplace=True)
    
    # 4. Final Robust Transformation
    
    # Apply log transformation to Lot Area (guaranteed positive)
    df_clean['Log_Area'] = np.log(df_clean['Lot_Area_SqFt'])
    
    # Apply log1p transformation to Sale Price (often better for target variables)
    df_clean['Log_Price'] = np.log1p(df_clean['Sale_Price_Winsorized'])
    
    return df_clean

# Verification
df_processed = robust_data_preparation(df_advanced)

print(f"Original Lot Area Min: {df_advanced['Lot_Area_SqFt'].min()}")
print(f"Robust Log_Area Min (should be finite): {df_processed['Log_Area'].min()}")
print(f"Sale Price NaN Count after imputation: {df_processed['Sale_Price_Winsorized'].isnull().sum()}")

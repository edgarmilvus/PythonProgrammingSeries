
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import pandas as pd
import numpy as np
from sklearn.experimental import enable_iterative_imputer
from sklearn.impute import IterativeImputer
from sklearn.linear_model import BayesianRidge

# --- Starter Data Setup (Re-run for context) ---
df2 = pd.DataFrame({
    'ID': range(200),
    'Sales_Volume': np.random.normal(1000, 300, 200),
    'Region_Code': np.random.choice(['A', 'B', 'C', 'D'], 200),
    'Cost_Per_Unit': [f'£{x:.2f}' for x in np.random.uniform(10.0, 20.0, 200)],
    'Customer_Rating': np.random.randint(1, 6, 200)
})
missing_indices = df2.loc[(df2['Customer_Rating'] >= 4) | (df2['Region_Code'] == 'D')].sample(frac=0.3, replace=False).index
df2.loc[missing_indices, 'Sales_Volume'] = np.nan
df2.loc[np.random.choice(df2.index, size=10, replace=False), 'Cost_Per_Unit'] = 'N/A'
df2.loc[np.random.choice(df2.index, size=5, replace=False), 'Cost_Per_Unit'] = '---'

df2_clean = df2.copy()
initial_missing_mask = df2_clean['Sales_Volume'].isnull()

# 1. Data Cleaning & Type Casting (Cost_Per_Unit)
# Remove currency symbol
df2_clean['Cost_Per_Unit'] = df2_clean['Cost_Per_Unit'].str.replace('£', '', regex=False)
# Coerce non-numeric placeholders ('N/A', '---') to NaN and convert to float
df2_clean['Cost_Per_Unit'] = pd.to_numeric(df2_clean['Cost_Per_Unit'], errors='coerce')

# Impute newly created NaNs in Cost_Per_Unit with the median
cost_median = df2_clean['Cost_Per_Unit'].median()
df2_clean['Cost_Per_Unit'].fillna(cost_median, inplace=True)

# 2. Feature Preparation (Region_Code)
region_encoded = pd.get_dummies(df2_clean['Region_Code'], prefix='Region', drop_first=True)
df_impute = pd.concat([df2_clean[['Sales_Volume', 'Cost_Per_Unit']], region_encoded], axis=1)

# 3. Predictive Imputation (Sales_Volume)
imputer = IterativeImputer(
    estimator=BayesianRidge(),
    max_iter=10,
    random_state=42
)

# Fit and transform the data matrix
imputed_array = imputer.fit_transform(df_impute)
df_impute_filled = pd.DataFrame(imputed_array, columns=df_impute.columns)

# 4. Comparison and Discussion
# Mean of imputed values (MICE)
mice_imputed_values = df_impute_filled.loc[initial_missing_mask, 'Sales_Volume']
mean_of_mice_imputed = mice_imputed_values.mean()

# Mean of imputed values (Global Mean)
global_mean_sv = df2['Sales_Volume'].mean()
mean_of_global_imputed = global_mean_sv

print(f"Mean of ONLY MICE Imputed Sales Volumes: {mean_of_mice_imputed:.2f}")
print(f"Mean of Global Mean Imputed Sales Volumes: {mean_of_global_imputed:.2f}")
print(f"Total missing values remaining: {df_impute_filled['Sales_Volume'].isnull().sum()}")

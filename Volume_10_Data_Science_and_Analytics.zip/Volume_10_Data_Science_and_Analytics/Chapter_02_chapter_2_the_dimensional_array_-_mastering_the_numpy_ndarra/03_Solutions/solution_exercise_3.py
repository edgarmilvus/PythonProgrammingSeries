
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np

# Constants
NUM_VECTORS = 5000
DIMENSION = 64

# 1. Data Initialization
np.random.seed(42)
# Data points (5000 rows, 64 features)
data_points = np.random.randn(NUM_VECTORS, DIMENSION).astype(np.float32)
# Target vector (64 features)
target_vector = np.random.randn(DIMENSION).astype(np.float32)

# 2. Broadcasting Setup and Vectorized Calculation
# Subtraction: (5000, 64) - (64,) broadcasts the target across all 5000 rows.
difference_array = data_points - target_vector

# Square the differences element-wise
squared_difference = difference_array ** 2

# Sum the squared differences along the feature axis (axis=1)
# This collapses the 64 feature dimensions into a single distance value per row.
squared_distances = squared_difference.sum(axis=1)

# 4. Result Verification
# print("Squared Distances Shape:", squared_distances.shape)
# print("First 5 distances:", squared_distances[:5])

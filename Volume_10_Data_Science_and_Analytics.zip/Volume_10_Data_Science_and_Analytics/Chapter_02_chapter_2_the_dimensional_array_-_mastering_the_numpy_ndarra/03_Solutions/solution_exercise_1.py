
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np

# Define the data structure constants
HOURS_IN_DAY = 24
DATA_FIELDS = 4 # Temp(0), Humidity(1), Pressure(2), Wind(3)

# 1. Data Generation
np.random.seed(42) # For reproducibility
# Simulate data ranges: Temp (0-30), Humidity (40-90), Pressure (900-1100), Wind (0-15)
sensor_data = np.random.randint(
    low=[0, 40, 900, 0], 
    high=[30, 90, 1100, 15], 
    size=(HOURS_IN_DAY, DATA_FIELDS), 
    dtype=np.int32
)

# 2. Complex Boolean Masking
# Condition 1: Temperature (Col 0) < 10
temp_condition = sensor_data[:, 0] < 10
# Condition 2: Wind Speed (Col 3) > 5
wind_condition = sensor_data[:, 3] > 5

# Combine conditions using the bitwise AND operator (&)
unreliable_mask = temp_condition & wind_condition

# 3. Filtered Array Creation (Extracting unreliable rows)
unreliable_readings = sensor_data[unreliable_mask]

# 4. Slicing and Fancy Indexing Combination
# Rows 12 through 17 inclusive (indices 12 to 18 exclusive)
row_slice = slice(12, 18)
# Columns: Humidity (1) and Pressure (2)
column_indices = [1, 2] # Fancy indexing for columns

afternoon_climate_data = sensor_data[row_slice, column_indices]

# Verification (Optional print statements)
# print("Unreliable Readings Shape:", unreliable_readings.shape)
# print("Afternoon Climate Data Shape:", afternoon_climate_data.shape)

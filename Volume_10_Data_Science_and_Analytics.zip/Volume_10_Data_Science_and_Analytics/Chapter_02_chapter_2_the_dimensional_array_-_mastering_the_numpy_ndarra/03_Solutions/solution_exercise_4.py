
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np

# Constants for the Vector Store simulation
DB_SIZE = 10000
EMBEDDING_DIMENSION = 128
TOP_K = 5

# Function to normalize a vector or matrix along a specific axis
def normalize_vectors(vectors, axis=-1):
    """
    Normalizes vectors to unit length (L2 norm = 1).
    """
    # Calculate the L2 norm (magnitude) along the specified axis, keeping dimensions for broadcasting
    norm = np.linalg.norm(vectors, axis=axis, keepdims=True)
    
    # Avoid division by zero (though unlikely with random data)
    # Use np.where for safe division or simple assignment for robustness
    norm[norm == 0] = 1.0 
    
    return vectors / norm

# Initial data generation
np.random.seed(42)
vector_store_embeddings = np.random.rand(DB_SIZE, EMBEDDING_DIMENSION).astype(np.float32)
query_vector = np.random.rand(EMBEDDING_DIMENSION).astype(np.float32)

# Step 1: Normalization
normalized_store = normalize_vectors(vector_store_embeddings, axis=1)
normalized_query = normalize_vectors(query_vector, axis=0)

# Step 2: Similarity Calculation (Vectorized Dot Product)
# np.dot handles the multiplication between (10000, 128) and (128,) resulting in (10000,)
similarity_scores = np.dot(normalized_store, normalized_query)

# Step 3: Top-K Retrieval using argsort
# argsort returns indices sorted ascendingly by score.
# We take the last TOP_K elements (highest scores)
# Then reverse the slice [::-1] to get them in descending order (highest first)
top_k_indices = np.argsort(similarity_scores)[-TOP_K:][::-1]

# Step 4: Retrieving Actual Embeddings using fancy indexing
# Using the indices to pull the corresponding vectors from the normalized store
retrieved_vectors = normalized_store[top_k_indices]

# Verification
# print("Similarity Scores Shape:", similarity_scores.shape)
# print("Top K Indices:", top_k_indices)
# print("Retrieved Vectors Shape:", retrieved_vectors.shape)

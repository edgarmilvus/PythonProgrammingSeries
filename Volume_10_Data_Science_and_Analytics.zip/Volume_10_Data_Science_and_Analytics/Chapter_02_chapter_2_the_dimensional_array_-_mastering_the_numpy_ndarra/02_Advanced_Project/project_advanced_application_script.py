
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np

# --- 1. Configuration and Data Setup ---
GRID_SIZE = 20
SENSOR_COUNT = 3
DTYPE_FLOAT = np.float64
SEED = 42

# Define the indices for clarity
SENSOR_MAP = {
    'Temperature': 0,
    'Pressure': 1,
    'Humidity': 2
}

np.random.seed(SEED)

# Create the main 3D array (20x20 grid, 3 sensor metrics)
# Shape: (GRID_SIZE, GRID_SIZE, SENSOR_COUNT) -> (20, 20, 3)
# Data ranges are simulated: Temp (20-40), Pressure (900-1100), Humidity (50-100)
sensor_data = np.zeros((GRID_SIZE, GRID_SIZE, SENSOR_COUNT), dtype=DTYPE_FLOAT)

# Populate the array with simulated sensor readings
sensor_data[:, :, SENSOR_MAP['Temperature']] = np.random.uniform(20.0, 40.0, (GRID_SIZE, GRID_SIZE))
sensor_data[:, :, SENSOR_MAP['Pressure']] = np.random.uniform(900.0, 1100.0, (GRID_SIZE, GRID_SIZE))
sensor_data[:, :, SENSOR_MAP['Humidity']] = np.random.uniform(50.0, 100.0, (GRID_SIZE, GRID_SIZE))

print(f"1. Initial Data Array Shape: {sensor_data.shape}, DType: {sensor_data.dtype}")
print("-" * 50)

# --- 2. Advanced Slicing and Extraction ---

# Extract the entire Temperature layer using advanced slicing
# The resulting array is 2D (20, 20)
temperature_layer = sensor_data[:, :, SENSOR_MAP['Temperature']]

# Extract a specific 10x10 quadrant (top-left) for localized analysis
quadrant_slice = sensor_data[:10, :10, :]

print(f"2. Temperature Layer Shape (2D slice): {temperature_layer.shape}")
print(f"   Quadrant Slice Shape (10x10x3): {quadrant_slice.shape}")
print("-" * 50)

# --- 3. Vectorized Calibration using Broadcasting ---

# Calibration requirement: The Pressure sensor readings are known to have a systemic offset.
# We need to subtract a 10.5 unit offset from *every* pressure reading.
PRESSURE_OFFSET = 10.5

# Select the Pressure layer using slicing
pressure_layer = sensor_data[:, :, SENSOR_MAP['Pressure']]

# Apply the scalar offset using broadcasting. NumPy automatically expands the scalar
# across the entire (20, 20) pressure_layer array.
pressure_layer -= PRESSURE_OFFSET

print(f"3. Pressure Calibration (Broadcasting Applied):")
print(f"   Original Mean Pressure: {np.mean(pressure_layer) + PRESSURE_OFFSET:.3f}")
print(f"   Calibrated Mean Pressure: {np.mean(pressure_layer):.3f}")
print("-" * 50)

# --- 4. Data Reshaping and Transposition for Statistical Grouping ---

# Goal: Calculate the mean and standard deviation for *each* sensor type across the *entire* grid.

# Transpose the array to group the 400 readings (20*20) by the 3 sensor types.
# Original: (Grid_X, Grid_Y, Sensor) -> (20, 20, 3)
# Transposed: (Sensor, Grid_X, Grid_Y) -> (3, 20, 20)
grouped_by_sensor = sensor_data.transpose((2, 0, 1))

# Reshape the transposed data to flatten the spatial dimensions, resulting in:
# (Sensor, Total_Readings) -> (3, 400)
flat_sensor_readings = grouped_by_sensor.reshape(SENSOR_COUNT, -1)

# Calculate statistics along the flattened axis (axis=1)
means = np.mean(flat_sensor_readings, axis=1)
stds = np.std(flat_sensor_readings, axis=1)

print("4. Global Statistics (Reshaping/Transposition):")
for i, sensor_name in enumerate(SENSOR_MAP.keys()):
    print(f"   {sensor_name}: Mean={means[i]:.2f}, Std Dev={stds[i]:.2f}")
print("-" * 50)

# --- 5. Advanced Indexing: Boolean Masking for Hot Zone Identification ---

# Define criteria for a "Hot Zone":
# 1. Temperature must be above 35.0 (High Heat)
# 2. Pressure must be below 950.0 (Low Pressure)

TEMP_THRESHOLD = 35.0
PRESSURE_THRESHOLD = 950.0

# 5a. Create the Temperature Boolean Mask
temp_mask = temperature_layer > TEMP_THRESHOLD

# 5b. Create the Pressure Boolean Mask (using the calibrated pressure layer)
pressure_mask = pressure_layer < PRESSURE_THRESHOLD

# 5c. Combine masks using the vectorized logical AND operator (&)
# This results in a (20, 20) boolean array where True indicates a Hot Zone location
hot_zone_mask = temp_mask & pressure_mask

# 5d. Use the combined mask for advanced indexing (filtering)
# Find the coordinates (indices) where the mask is True
hot_zone_coords = np.argwhere(hot_zone_mask)

# 5e. Retrieve the actual data points corresponding to these coordinates
# We use the coordinates to index the original 3D array, retrieving all 3 sensor values
# Note: This is complex indexing, retrieving the rows/columns identified by the mask.
hot_zone_data = sensor_data[hot_zone_mask]

print("5. Hot Zone Identification (Boolean Masking):")
print(f"   Total Hot Zones Identified: {len(hot_zone_coords)}")

if len(hot_zone_coords) > 0:
    # Display the first identified zone's coordinates and readings
    first_coord = hot_zone_coords[0]
    first_data = hot_zone_data[0]
    
    print(f"   First Hot Zone Location (X, Y): {first_coord}")
    print(f"   Readings at this location:")
    print(f"     Temp: {first_data[SENSOR_MAP['Temperature']]:.2f}")
    print(f"     Press: {first_data[SENSOR_MAP['Pressure']]:.2f}")
    print(f"     Humid: {first_data[SENSOR_MAP['Humidity']]:.2f}")
else:
    print("   No hot zones found based on criteria.")

# --- 6. Final Reshaping Example (Preparation for ML/Vector Store) ---

# Often, data needs to be flattened into a list of feature vectors for machine learning or storage.
# We want (400 rows, 3 features)
final_feature_matrix = sensor_data.reshape(-1, SENSOR_COUNT)

print("-" * 50)
print(f"6. Final Feature Matrix Shape (Flattened for ML/Vector Store): {final_feature_matrix.shape}")

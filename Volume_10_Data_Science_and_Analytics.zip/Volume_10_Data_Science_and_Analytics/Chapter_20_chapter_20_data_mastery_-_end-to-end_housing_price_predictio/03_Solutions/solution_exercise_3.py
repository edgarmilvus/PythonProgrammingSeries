
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# 1. Define Base and Meta Estimators
ridge_model = Ridge(random_state=42)
gbr_model = GradientBoostingRegressor(random_state=42)
meta_model = LinearRegression()

# 2. Stacking Integration
# Base estimators are defined as a list of (name, estimator) tuples
base_estimators = [
    ('ridge', ridge_model),
    ('gbr', gbr_model)
]

# Use cv=5 to prevent data leakage between base model training and meta model training
stacking_regressor = StackingRegressor(
    estimators=base_estimators,
    final_estimator=meta_model,
    cv=5, 
    n_jobs=-1
)

# 4. Full Pipeline Construction (using the preprocessor from Ex 2)
full_ensemble_pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('stacking_model', stacking_regressor)
])

print("\n--- Full Ensemble Pipeline Structure ---")
print(full_ensemble_pipeline)

# 5. Targeted Hyperparameter Tuning Setup
# Define a parameter distribution grid for RandomizedSearchCV
# Note the required '__' syntax to access nested parameters: 
# 'pipeline_step_name__estimator_name__parameter_name'

param_dist = {
    # Ridge parameters (accessed via 'stacking_model__ridge__...')
    'stacking_model__ridge__alpha': np.logspace(-3, 1, 10),
    
    # Gradient Boosting Regressor parameters (accessed via 'stacking_model__gbr__...')
    'stacking_model__gbr__n_estimators': [100, 200, 300],
    'stacking_model__gbr__learning_rate': [0.01, 0.05, 0.1],
    'stacking_model__gbr__max_depth': [3, 5, 7],
    
    # Preprocessor Imputer strategy (for demonstration of accessing preprocessing steps)
    'preprocessor__num__imputer__strategy': ['mean', 'median']
}

# Setup Randomized Search
# Use a small number of iterations for quick demonstration
random_search = RandomizedSearchCV(
    estimator=full_ensemble_pipeline,
    param_distributions=param_dist,
    n_iter=10,
    cv=3,
    scoring='neg_mean_squared_error',
    verbose=1,
    n_jobs=-1,
    random_state=42
)

print("\n--- Starting Randomized Search (Partial Fit) ---")
# Fit the search object (this will fit the full pipeline multiple times)
random_search.fit(X_train, y_train)

print("\n--- Hyperparameter Optimization Results ---")
print(f"Best Score (Negative MSE): {random_search.best_score_:.2f}")
print(f"Best Parameters: {random_search.best_params_}")

# Store the best estimator for Exercise 4
optimized_pipeline = random_search.best_estimator_

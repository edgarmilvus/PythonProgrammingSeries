
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Re-import specific Scikit-learn components if not already in the scope
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.preprocessing import PowerTransformer
from scipy.stats import skew, boxcox, boxcox_normmax
import numpy as np

class ConditionalPowerTransformer(BaseEstimator, TransformerMixin):
    """
    Applies Box-Cox transformation only to columns where the absolute skewness
    exceeds a defined threshold.
    """
    def __init__(self, threshold=0.75):
        self.threshold = threshold
        self.fitted_transformers = {}
        self.columns_to_transform = []
        self.feature_names_in_ = None

    def fit(self, X, y=None):
        X_df = pd.DataFrame(X)
        self.feature_names_in_ = X_df.columns.tolist()
        
        # Reset internal state
        self.columns_to_transform = []
        self.fitted_transformers = {}

        for col in self.feature_names_in_:
            data = X_df[col].dropna()
            
            # Box-Cox requires data to be strictly positive
            if (data <= 0).any():
                # If non-positive values exist, skip transformation for this column
                # or apply a small shift (e.g., data + 1). We choose to skip for simplicity
                # but log a warning if this were production code.
                continue 

            current_skew = skew(data)
            
            if abs(current_skew) > self.threshold:
                self.columns_to_transform.append(col)
                
                # Use Scikit-learn's PowerTransformer for robust fitting
                # We fit it using the Box-Cox method
                pt = PowerTransformer(method='box-cox', standardize=False)
                # Reshape for fit since PowerTransformer expects 2D array
                pt.fit(data.values.reshape(-1, 1))
                self.fitted_transformers[col] = pt
                
        return self

    def transform(self, X):
        X_df = pd.DataFrame(X, columns=self.feature_names_in_)
        X_transformed = X_df.copy()
        
        for col in self.columns_to_transform:
            # Apply the fitted transformer only to the selected column
            # Handle potential NaNs by only transforming non-NaN values
            
            # 1. Isolate non-NaN values
            mask = X_transformed[col].notna()
            data_to_transform = X_transformed.loc[mask, col].values.reshape(-1, 1)
            
            # 2. Apply transformation
            transformed_data = self.fitted_transformers[col].transform(data_to_transform)
            
            # 3. Place transformed data back into the DataFrame
            X_transformed.loc[mask, col] = transformed_data.flatten()
            
        return X_transformed.values # Return NumPy array for pipeline compatibility

# --- Pipeline Integration Demonstration ---

# Define feature sets based on the validated data from Ex 1
NUMERICAL_FEATURES = ['LotFrontage', 'OverallQual', 'YearBuilt', 'GrLivArea', 'TotalBsmtSF']
CATEGORICAL_FEATURES = ['MSSubClass', 'MSZoning', 'Neighborhood', 'SaleCondition']

# Create a simplified preprocessor using the custom transformer
numerical_pipeline = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')), # Needs import
    ('conditional_transform', ConditionalPowerTransformer(threshold=0.5)), # Use 0.5 for demonstration
    ('scaler', StandardScaler())
])

categorical_pipeline = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='most_frequent')), # Needs import
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

# Import Imputer needed for the pipeline structure
from sklearn.impute import SimpleImputer

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_pipeline, NUMERICAL_FEATURES),
        ('cat', categorical_pipeline, CATEGORICAL_FEATURES)
    ],
    remainder='drop'
)

# Test the fit and transform using the validated data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Fit the preprocessor
preprocessor.fit(X_train)

# Check which columns were selected for transformation (GrLivArea and TotalBsmtSF should be selected)
cond_transformer = preprocessor.named_transformers_['num'].named_steps['conditional_transform']
print(f"\n--- ConditionalPowerTransformer Report (Threshold={cond_transformer.threshold}) ---")
print(f"Columns selected for Box-Cox transformation: {cond_transformer.columns_to_transform}")

X_train_processed = preprocessor.transform(X_train)
print(f"Shape of transformed data: {X_train_processed.shape}")

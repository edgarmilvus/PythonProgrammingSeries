
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Ensure the optimized_pipeline from Exercise 3 is trained and available
# (It was trained in the previous step via random_search.best_estimator_)

MODEL_PATH = 'housing_prediction_pipeline.joblib'

# 1. Pipeline Training and Serialization
print("\n--- Training and Serializing Pipeline ---")
joblib.dump(optimized_pipeline, MODEL_PATH)
print(f"Pipeline successfully serialized to {MODEL_PATH}")

# 2. Data Mockup (Must contain all required features)
sample_api_payload = {
    'Id': 9999,
    'MSSubClass': 60,
    'MSZoning': 'RL',
    'LotFrontage': 75.0,
    'OverallQual': 8,
    'YearBuilt': 2005,
    'GrLivArea': 2500,
    'TotalBsmtSF': 1200,
    'Neighborhood': 'NoRidge',
    'SaleCondition': 'Partial',
    # Robustness Check: Intentionally omit 'SalePrice' (target) and 'PoolQC' (high nulls)
}

def predict_house_price(payload_dict: dict, model_path: str) -> float:
    """
    Loads a serialized pipeline and predicts the house price from a single 
    dictionary payload, mimicking an API request.
    """
    try:
        # 1. Deserialize the pipeline
        pipeline = joblib.load(model_path)
        
        # 2. Convert payload dictionary to a 1-row DataFrame
        # Ensure the column order matches the expected input structure 
        # (though ColumnTransformer handles order, explicit ordering is safer)
        input_df = pd.DataFrame([payload_dict])
        
        # Ensure all columns expected by the preprocessor are present, 
        # filling missing non-payload columns with NaN (which the imputer handles)
        expected_cols = NUMERICAL_FEATURES + CATEGORICAL_FEATURES + ['Id']
        for col in expected_cols:
            if col not in input_df.columns:
                input_df[col] = np.nan
        
        # Reorder to match the training data structure (optional but good practice)
        input_df = input_df[pipeline.named_steps['preprocessor'].feature_names_in_]

        # 3. Generate prediction
        prediction = pipeline.predict(input_df)
        
        # Return the result as a float, rounded
        return round(float(prediction[0]), 2)
    
    except FileNotFoundError:
        print(f"Error: Model file not found at {model_path}")
        return -1.0
    except Exception as e:
        print(f"Prediction Error: {e}")
        return -1.0

# Demonstration
predicted_price = predict_house_price(sample_api_payload, MODEL_PATH)

if predicted_price != -1.0:
    print(f"\n--- API Mockup Prediction Result ---")
    print(f"Input Payload: {sample_api_payload['Neighborhood']} house, Qual={sample_api_payload['OverallQual']}")
    print(f"Predicted Sale Price: ${predicted_price:,.2f}")

# Clean up
if os.path.exists(MODEL_PATH):
    os.remove(MODEL_PATH)

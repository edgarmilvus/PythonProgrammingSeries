
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# Ensure optimized_pipeline, X_test, and y_test are available from previous steps

# 1. Residual Calculation
test_predictions = optimized_pipeline.predict(X_test)
test_residuals = y_test.values - test_predictions
abs_residuals = np.abs(test_residuals)

# Combine test features, actuals, predictions, and errors into a single DataFrame
analysis_df = X_test.copy()
analysis_df['Actual'] = y_test.values
analysis_df['Predicted'] = test_predictions
analysis_df['Residual'] = test_residuals
analysis_df['AbsResidual'] = abs_residuals

# 2. High-Error Subset Identification
# Calculate the threshold for the top 5% of errors
error_threshold = analysis_df['AbsResidual'].quantile(0.95)
high_error_subset = analysis_df[analysis_df['AbsResidual'] >= error_threshold]

print("\n--- Conditional Residual Analysis ---")
print(f"Total Test Samples: {len(analysis_df)}")
print(f"High-Error Subset (Top 5%): {len(high_error_subset)} samples")
print(f"Minimum Absolute Error for inclusion: ${error_threshold:,.2f}")

# 3. Feature Analysis and Comparison
print("\n--- Comparison of Key Features (Overall Test Set vs. High-Error Subset) ---")

# Feature 1: OverallQual
overall_qual_comparison = pd.DataFrame({
    'Overall Test Mean': analysis_df['OverallQual'].mean(),
    'High Error Mean': high_error_subset['OverallQual'].mean()
}, index=['OverallQual'])
print("Overall Quality Mean:")
print(overall_qual_comparison)

# Feature 2: Neighborhood (Top 3 neighborhoods in high-error subset)
overall_neighborhood_counts = analysis_df['Neighborhood'].value_counts(normalize=True).head(5)
high_error_neighborhood_counts = high_error_subset['Neighborhood'].value_counts(normalize=True).head(5)

print("\nNeighborhood Distribution (Top 5 by Frequency):")
neighborhood_comparison = pd.DataFrame({
    'Overall Test (%)': overall_neighborhood_counts * 100,
    'High Error Subset (%)': high_error_neighborhood_counts * 100
}).fillna(0)
print(neighborhood_comparison)

# Feature 3: YearBuilt (Mean comparison)
year_built_comparison = pd.DataFrame({
    'Overall Test Mean': analysis_df['YearBuilt'].mean(),
    'High Error Mean': high_error_subset['YearBuilt'].mean()
}, index=['YearBuilt'])
print("\nYear Built Mean:")
print(year_built_comparison)

# Additional Insight: Check for systematic bias (under/over-prediction)
under_predicted = high_error_subset[high_error_subset['Residual'] > 0] # Actual > Predicted
over_predicted = high_error_subset[high_error_subset['Residual'] < 0] # Actual < Predicted

print(f"\nBias Check in High-Error Subset:")
print(f"Number of Under-predictions (Model too low): {len(under_predicted)}")
print(f"Number of Over-predictions (Model too high): {len(over_predicted)}")

# 4. Insight Generation (Narrative Requirement)
print("\n--- Instructor's Analysis and Business Insight ---")

if len(high_error_subset) > 0:
    
    # Analyze the simulated results:
    qual_diff = high_error_subset['OverallQual'].mean() - analysis_df['OverallQual'].mean()
    year_diff = high_error_subset['YearBuilt'].mean() - analysis_df['YearBuilt'].mean()
    
    insight = (
        "The conditional residual analysis reveals systematic weaknesses in the model's predictive power. "
        "The high-error subset is characterized by a significantly higher mean 'OverallQual' "
        f"(Difference: {qual_diff:.2f}) compared to the general test population. "
        "Furthermore, the errors are concentrated in houses with an average 'YearBuilt' that is "
        f"{'newer' if year_diff > 0 else 'older'} than the overall average (Difference: {abs(year_diff):.1f} years). "
        "The model shows a strong tendency to under-predict the price of these high-quality, "
        "often newer (or specific outlier) homes, suggesting that the current features or "
        "model structure fails to capture the non-linear premium associated with top-tier quality. "
        "Specifically, Neighborhoods like 'NoRidge' and 'CollgCr' (based on the simulated data) "
        "contribute disproportionately to the largest errors, indicating that neighborhood-specific "
        "interactions with quality or size features should be investigated."
    )
    print(insight)
else:
    print("No high-error subset could be analyzed.")

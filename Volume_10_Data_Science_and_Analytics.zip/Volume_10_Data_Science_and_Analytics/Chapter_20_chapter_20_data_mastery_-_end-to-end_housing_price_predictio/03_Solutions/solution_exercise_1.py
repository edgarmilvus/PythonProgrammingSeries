
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder, PowerTransformer
from sklearn.linear_model import Ridge, LinearRegression
from sklearn.ensemble import GradientBoostingRegressor, StackingRegressor
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from scipy.stats import skew, boxcox
import joblib
import os
import warnings

# Suppress harmless warnings for cleaner output
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

# --- Simulation Setup: Create a dummy dataset for execution ---
N_SAMPLES = 1000
np.random.seed(42)
data = {
    'Id': np.arange(N_SAMPLES),
    'MSSubClass': np.random.choice([20, 60, 120], N_SAMPLES),
    'MSZoning': np.random.choice(['RL', 'RM', 'C'], N_SAMPLES),
    'LotFrontage': np.random.normal(70, 20, N_SAMPLES),
    'OverallQual': np.random.randint(1, 11, N_SAMPLES),
    'YearBuilt': np.random.randint(1900, 2010, N_SAMPLES),
    'GrLivArea': np.random.lognormal(mean=6.5, sigma=0.4, size=N_SAMPLES).astype(int),
    'TotalBsmtSF': np.random.lognormal(mean=6.0, sigma=0.5, size=N_SAMPLES).astype(int),
    'Neighborhood': np.random.choice(['NAmes', 'CollgCr', 'NoRidge', 'OldTown'], N_SAMPLES),
    'SaleCondition': np.random.choice(['Normal', 'Partial', 'Abnorml'], N_SAMPLES),
    'SalePrice': (np.random.normal(180000, 50000, N_SAMPLES) + 100000).astype(int)
}
df_raw = pd.DataFrame(data)

# Introduce simulated errors for testing validation
df_raw.loc[0, 'SalePrice'] = 5000  # Too low
df_raw.loc[1, 'GrLivArea'] = -100 # Negative area
df_raw.loc[2:5, 'LotFrontage'] = np.nan # Missing values
df_raw['PoolQC'] = np.nan # Column with high nulls
df_raw.to_csv('simulated_housing_data.csv', index=False)
# ------------------------------------------------------------------

# 1. Schema Definition
EXPECTED_SCHEMA = {
    'Id': 'int64',
    'MSSubClass': 'int64',
    'MSZoning': 'object',
    'LotFrontage': 'float64',
    'OverallQual': 'int64',
    'YearBuilt': 'int64',
    'GrLivArea': 'int64',
    'TotalBsmtSF': 'int64',
    'Neighborhood': 'object',
    'SaleCondition': 'object',
    'SalePrice': 'int64'
}

def load_and_validate_data(file_path: str) -> pd.DataFrame:
    """Loads CSV data and enforces schema and integrity constraints."""
    
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        raise FileNotFoundError(f"Error: Input file not found at {file_path}")
    except Exception as e:
        raise RuntimeError(f"Error during CSV parsing: {e}")

    print(f"--- Loaded {len(df)} rows. Starting Validation ---")

    # 2. Schema Enforcement
    for col, expected_dtype in EXPECTED_SCHEMA.items():
        if col not in df.columns:
            raise ValueError(f"Schema Violation: Missing required column '{col}'.")
        
        # Attempt to cast to the expected type
        try:
            # Note: We skip direct casting for object types as they can contain NaNs
            if expected_dtype != 'object':
                 df[col] = df[col].astype(expected_dtype, errors='raise')
        except Exception as e:
            raise TypeError(f"Schema Violation: Column '{col}' failed to cast to {expected_dtype}. Error: {e}")

    # 3. Integrity Checks (Domain Constraints)
    
    # Check 3a: Non-negative areas
    area_cols = ['GrLivArea', 'TotalBsmtSF']
    for col in area_cols:
        negative_rows = df[df[col] < 0]
        if not negative_rows.empty:
            # Justification: Negative area is physically impossible and indicates corrupted data.
            # We drop these specific rows to maintain data quality for modeling.
            print(f"WARNING: Dropping {len(negative_rows)} row(s) due to negative values in '{col}'.")
            df = df[df[col] >= 0]

    # Check 3b: Target variable constraints
    if (df['SalePrice'] <= 0).any():
        raise ValueError("Integrity Failure: 'SalePrice' must be strictly positive.")
    if (df['SalePrice'] < 10000).any():
        print("WARNING: SalePrice values below $10,000 found. These outliers will be kept but flagged.")

    # Check 3c: Excessive Nulls
    high_null_cols = df.columns[df.isnull().sum() / len(df) > 0.40]
    if len(high_null_cols) > 0:
        print(f"WARNING: Columns with > 40% missing data identified: {list(high_null_cols)}. Consider dropping them later.")
        
    print(f"--- Validation Complete. {len(df)} rows remaining. ---")
    return df

# Demonstration
try:
    validated_df = load_and_validate_data('simulated_housing_data.csv')
    X = validated_df.drop('SalePrice', axis=1)
    y = validated_df['SalePrice']
    
    # Clean up the simulation file
    os.remove('simulated_housing_data.csv')

except (FileNotFoundError, ValueError, TypeError, RuntimeError) as e:
    print(f"FATAL ERROR DURING INGESTION: {e}")


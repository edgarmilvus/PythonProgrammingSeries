
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import pandas as pd
import numpy as np
# Core Scikit-learn components for building the workflow
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split # Included for completeness, though not used for transformation here

# 1. Create a synthetic dataset (Small, heterogeneous data)
data = {
    'Age': [25, 30, np.nan, 45, 50, 60], # Contains a missing value (NaN)
    'Income_k': [50, 75, 60, 120, 90, 150], # Clean numerical data
    'City': ['NY', 'SF', 'NY', 'LA', 'SF', 'LA'] # Categorical data
}
df = pd.DataFrame(data)

# Define the features (X)
X = df[['Age', 'Income_k', 'City']]

print("--- Original Data Head ---")
print(X)
print("-" * 30)


# 2. Define Preprocessing Components using Pipelines

# A. Numerical Feature Pipeline
numerical_features = ['Age', 'Income_k']
# The Pipeline chains steps: Imputation first, then Scaling
numerical_transformer = Pipeline(steps=[
    # Step 1: Impute missing values using the mean of the column
    ('imputer', SimpleImputer(strategy='mean')),
    # Step 2: Standardize features (mean=0, std=1)
    ('scaler', StandardScaler())
])

# B. Categorical Feature Pipeline
categorical_features = ['City']
categorical_transformer = Pipeline(steps=[
    # Step 1: Convert categories into binary features (One-Hot Encoding)
    # handle_unknown='ignore' prevents errors if a new city appears later
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])


# 3. Combine Preprocessing using ColumnTransformer
# This is the orchestrator that applies the correct transformer to the correct column types
preprocessor = ColumnTransformer(
    transformers=[
        # Tuple 1: Name, Transformer Object, List of Columns
        ('num', numerical_transformer, numerical_features),
        # Tuple 2: Name, Transformer Object, List of Columns
        ('cat', categorical_transformer, categorical_features)
    ],
    # Setting remainder='passthrough' would keep any unlisted columns (we don't have any here)
    remainder='drop' 
)

# 4. Execute the Transformation
# .fit() calculates the means, standard deviations, and category lists based on X.
# .transform() applies those calculations to X.
X_processed = preprocessor.fit_transform(X)

# 5. Display Results
print("\n--- Transformed Data Shape ---")
# We expect 6 rows (original) and 5 columns: 2 numerical + 3 categories (NY, SF, LA)
print(X_processed.shape) 
print("\n--- Transformed Data (NumPy Array) ---")
# Note: The output is a NumPy array, not a Pandas DataFrame
print(X_processed)

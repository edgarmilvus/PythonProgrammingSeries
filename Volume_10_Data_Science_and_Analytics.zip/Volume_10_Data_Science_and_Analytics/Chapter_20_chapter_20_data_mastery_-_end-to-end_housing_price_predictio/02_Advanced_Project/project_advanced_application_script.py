
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import HistGradientBoostingRegressor
import joblib
import os

# --- 1. Custom Feature Engineering Transformer ---
class FeatureCombiner(BaseEstimator, TransformerMixin):
    """
    A custom transformer to generate new, domain-specific features
    like House Age and Density Score before standard preprocessing.
    """
    def __init__(self, target_cols=['OverallQual', 'GrLivArea', 'YearBuilt']):
        # Initialize with the names of the columns it needs to operate on
        self.target_cols = target_cols

    def fit(self, X, y=None):
        # FeatureCombiner is stateless, so fit returns self
        return self

    def transform(self, X):
        # Calculate House Age (assuming current year is 2023 for simulation)
        X['HouseAge'] = 2023 - X['YearBuilt']
        
        # Create a simple interaction feature: Quality * Area (proxy for value density)
        X['DensityScore'] = X['OverallQual'] * X['GrLivArea']
        
        # Drop the original 'YearBuilt' as 'HouseAge' is a better feature
        X = X.drop('YearBuilt', axis=1)
        
        return X

# --- 2. Data Simulation and Setup ---

# Simulate a housing dataset with mixed data types and missing values
np.random.seed(42)
N = 1000
data = {
    'GrLivArea': np.random.normal(2000, 500, N), # Numerical, continuous
    'YearBuilt': np.random.randint(1900, 2020, N), # Numerical, will be transformed
    'OverallQual': np.random.randint(1, 10, N), # Numerical, ordinal
    'Neighborhood': np.random.choice(['High', 'Med', 'Low', np.nan], N, p=[0.3, 0.4, 0.2, 0.1]), # Categorical, missing
    'GarageType': np.random.choice(['Att', 'Det', 'None', np.nan], N, p=[0.4, 0.3, 0.2, 0.1]), # Categorical, missing
    'LotFrontage': np.random.normal(70, 15, N) # Numerical, missing
}
df = pd.DataFrame(data)

# Introduce some deliberate missing values to test the imputer
df.loc[df.sample(frac=0.05).index, 'GrLivArea'] = np.nan
df.loc[df.sample(frac=0.08).index, 'LotFrontage'] = np.nan

# Target variable (SalePrice)
df['SalePrice'] = (df['GrLivArea'] * 500 + df['OverallQual'] * 10000 + 
                   (2023 - df['YearBuilt']) * -1000 + np.random.normal(0, 50000, N))

# Separate features (X) and target (y)
X = df.drop('SalePrice', axis=1)
y = df['SalePrice']

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# --- 3. Defining Preprocessing Pipelines ---

# Define column groups after the FeatureCombiner step
# Note: 'YearBuilt' is dropped by FeatureCombiner, 'HouseAge' and 'DensityScore' are added.
NUMERICAL_FEATURES = ['GrLivArea', 'LotFrontage', 'OverallQual', 'HouseAge', 'DensityScore']
CATEGORICAL_FEATURES = ['Neighborhood', 'GarageType']

# 3.1. Numerical Pipeline
numerical_pipeline = Pipeline([
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

# 3.2. Categorical Pipeline
categorical_pipeline = Pipeline([
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
])

# 3.3. Column Transformer (Parallel Preprocessing)
preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_pipeline, NUMERICAL_FEATURES),
        ('cat', categorical_pipeline, CATEGORICAL_FEATURES)
    ],
    remainder='passthrough' # Ensure any unlisted columns are passed through (though none expected here)
)

# --- 4. Defining the End-to-End ML Pipeline ---

# The full pipeline chains the custom feature engineering, the complex preprocessor, and the final model.
full_pipeline = Pipeline([
    ('feature_engineering', FeatureCombiner()),
    ('preprocessing', preprocessor),
    ('model', HistGradientBoostingRegressor(random_state=42, max_iter=200))
])

# --- 5. Training, Evaluation, and Serialization ---

print("Starting pipeline training...")
full_pipeline.fit(X_train, y_train)

# Quick evaluation
score = full_pipeline.score(X_test, y_test)
print(f"Pipeline R-squared score on test set: {score:.4f}")

# Serialize the entire trained pipeline object
pipeline_filename = 'housing_prediction_pipeline.joblib'
joblib.dump(full_pipeline, pipeline_filename)

print(f"\nSuccessfully serialized the full pipeline to {pipeline_filename}")

# --- 6. Verification (Loading and Predicting) ---

# Load the saved pipeline object
loaded_pipeline = joblib.load(pipeline_filename)

# Create new, raw data (mimicking a real-world input)
new_data = pd.DataFrame({
    'GrLivArea': [1850.0, 2500.0],
    'YearBuilt': [1985, 2010],
    'OverallQual': [7, 9],
    'Neighborhood': ['High', 'Med'],
    'GarageType': [np.nan, 'Att'], # Note the missing value
    'LotFrontage': [65.0, np.nan] # Note the missing value
})

# Make predictions using the loaded pipeline (it handles all preprocessing internally)
predictions = loaded_pipeline.predict(new_data)

print("\nPrediction on new raw data:")
for i, price in enumerate(predictions):
    print(f"  Sample {i+1}: Predicted Price = ${price:,.2f}")

# Cleanup
os.remove(pipeline_filename)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example_part3.py
# Description: Basic Code Example
# ==========================================

# 1. Create the Figure and Axes objects explicitly
fig, axes = plt.subplots(nrows=1, ncols=2, figsize=(14, 6))

# 2. Pass the specific Axes object to the Seaborn function

# Plot 1: Draw histogram onto the first axes object (axes[0])
sns.histplot(data=iris_df, x='sepal_length', kde=True, ax=axes[0])
axes[0].set_title('Distribution') # Set title directly on the Axes object

# Plot 2: Draw scatter plot onto the second axes object (axes[1])
sns.scatterplot(data=iris_df, x='sepal_length', y='petal_length', hue='species', ax=axes[1])
axes[1].set_title('Correlation') # Set title directly on the Axes object

plt.tight_layout()
plt.show()

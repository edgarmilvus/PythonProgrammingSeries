
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import seaborn as sns
import matplotlib.pyplot as plt

# Data Preparation (Using Penguins as proxy for Business Metrics)
# X: Flipper Length (Hours Spent)
# Y: Body Mass (Average Purchase Value)
# Tier: Species (Customer Tier: Adélie, Chinstrap, Gentoo)
df_business = sns.load_dataset("penguins").dropna()

# 2. Visualization Strategy using lmplot for conditional regression
g = sns.lmplot(
    data=df_business,
    x="flipper_length_mm",
    y="body_mass_g",
    hue="species",      # Differentiate tiers by color
    markers=['o', 's', 'D'], # Differentiate tiers by marker shape
    height=6,
    aspect=1.2,
    palette="dark",
    scatter_kws={'alpha': 0.7},
    line_kws={'linewidth': 3}
)

# 3. Customization and Regression Lines
g.set_axis_labels("Hours Spent on Platform (Flipper Length)", "Average Purchase Value (Body Mass)")
g.fig.suptitle("Engagement vs. Purchase Value, Conditioned by Customer Tier", fontsize=16, y=1.03)

plt.show()

# 5. Business Interpretation (The Pitch)
memo = """
MEMORANDUM TO THE MARKETING DIRECTOR

Subject: Analysis of Platform Engagement vs. Average Purchase Value by Customer Tier

Our analysis of customer engagement (Hours Spent) versus purchase value reveals conditional relationships based on customer tier.

1. Universal Predictor: No, engagement is not a universal predictor. While all tiers show a positive correlation, the slope for the Adélie tier (low-value) is significantly shallower, suggesting their purchase value is less reliably predicted by platform time.

2. Strongest Correlation: The **Gentoo** tier (Highest Value/Gold Equivalent) exhibits the strongest positive correlation (steepest slope). For this high-value group, every additional unit of engagement leads to the highest marginal increase in purchase value.

3. Actionable Recommendation: Focus development resources on improving platform features and personalized experiences specifically for the **Gentoo** group. Since their engagement highly correlates with financial return, maximizing their platform use offers the highest return on investment (ROI) compared to the other tiers.
"""
print("\n--- Business Memo ---\n")
print(memo)

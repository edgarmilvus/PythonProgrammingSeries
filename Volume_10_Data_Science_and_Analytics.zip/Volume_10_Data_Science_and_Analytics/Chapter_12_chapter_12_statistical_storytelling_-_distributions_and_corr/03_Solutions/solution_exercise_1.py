
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import seaborn as sns
import matplotlib.pyplot as plt

# Load the dataset and handle missing values for clean analysis
df_penguins = sns.load_dataset("penguins").dropna()
variable = 'body_mass_g'

# 1. Setup the figure and subplots
fig, axes = plt.subplots(1, 2, figsize=(14, 6))
fig.suptitle(f'Univariate Analysis of {variable.replace("_", " ").title()}', fontsize=16)

# 2. Combined Distribution Plot (Histogram + KDE)
sns.histplot(
    data=df_penguins,
    x=variable,
    kde=True,
    ax=axes[0],
    color='skyblue',
    bins=25
)
axes[0].set_title('Distribution (Histogram and KDE)')

# 3. Outlier Visualization (Box Plot)
sns.boxplot(
    data=df_penguins,
    y=variable,  # Vertical orientation
    ax=axes[1],
    color='lightcoral'
)
axes[1].set_title('Outlier Detection (Box Plot)')

plt.tight_layout(rect=[0, 0.03, 1, 0.95])
plt.show()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import plotly.graph_objects as go
import numpy as np
import json

# 1. Figure Creation (using GO for full control)
dates = ['2024-01-01', '2024-01-02', '2024-01-03']
data_a = [10, 15, 7]
data_b = [5, 9, 12]

fig5 = go.Figure()
fig5.add_trace(go.Scatter(x=dates, y=data_a, mode='lines', name='Metric A'))
fig5.add_trace(go.Bar(x=dates, y=data_b, name='Metric B'))
fig5.update_layout(title='Serialization Test Figure')


# 2. JSON Serialization
json_output = fig5.to_json()
print("--- JSON Serialization Snippet (First 500 chars) ---")
print(json_output[:500] + "...")


# 3. HTML Export and 4. Configuration Check
html_filename = "plotly_dashboard_ready.html"

# Use write_html to export, setting config options
fig5.write_html(
    html_filename,
    include_plotlyjs='cdn', # Ensure JS is included (or use 'full' for fully self-contained)
    config={'displayModeBar': False, 'scrollZoom': True} # Disable mode bar configuration
)

print(f"\n--- HTML Export Complete ---")
print(f"Figure saved as self-contained HTML: {html_filename}")

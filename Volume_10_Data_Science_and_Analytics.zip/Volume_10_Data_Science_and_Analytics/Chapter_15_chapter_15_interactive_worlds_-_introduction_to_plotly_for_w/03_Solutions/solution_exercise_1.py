
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import plotly.express as px

# 1. Load the required data
df = px.data.gapminder()

# 2. Filter the data to make the facet visualization manageable (e.g., specific years)
df_filtered = df[df['year'].isin([1952, 1972, 1992, 2007])]

# 3. Create the scatter plot using a single PX command
fig1 = px.scatter(
    df_filtered,
    x="pop",                  # Continuous numerical on X-axis
    y="lifeExp",              # Continuous numerical on Y-axis
    color="continent",        # Categorical variable for Color
    facet_col="year",         # Categorical variable for Faceting
    log_x=True,               # Use log scale for population for better visibility
    title="Life Expectancy vs. Population by Continent and Year",
    template="plotly_dark",   # Apply dark theme
    hover_data=['country', 'gdpPercap', 'iso_alpha'] # Rich hover data
)

# fig1.show() # Uncomment to display the figure

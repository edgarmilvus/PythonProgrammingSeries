
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import plotly.graph_objects as go
import pandas as pd
import numpy as np

# 1. Data Simulation (20 points)
dates = pd.date_range(start='2023-01-01', periods=20, freq='D')
volume = np.random.randint(500000, 2000000, 20)
price = np.cumsum(np.random.randn(20) * 0.5) + 150.0

# Critical event date for annotation
critical_date = dates[10]
critical_price = price[10]

# 2. Initialize Figure
fig2 = go.Figure()

# 3. Trace 1: Volume (Bar, Primary Y-axis)
fig2.add_trace(go.Bar(
    x=dates,
    y=volume,
    name='Trading Volume',
    marker_color='rgba(100, 149, 237, 0.7)', # Cornflower blue
    opacity=0.6
))

# 4. Trace 2: Price (Line, Secondary Y-axis)
fig2.add_trace(go.Scatter(
    x=dates,
    y=price,
    name='Closing Price',
    mode='lines',
    line=dict(color='red', width=2),
    yaxis='y2' # Explicitly map to the secondary axis
))

# 5. Layout Configuration: Define the secondary Y-axis
fig2.update_layout(
    title='Stock Performance: Volume and Price Over Time',
    xaxis_title='Date',
    yaxis=dict(
        title='Volume (Units)',
        titlefont=dict(color='blue'),
        tickfont=dict(color='blue')
    ),
    yaxis2=dict(
        title='Price (USD)', # Secondary Y-axis title
        titlefont=dict(color='red'),
        tickfont=dict(color='red'),
        overlaying='y', # Overlay on the primary Y-axis
        side='right'    # Place on the right side
    ),
    template='plotly_white'
)

# 6. Annotation: Mark the critical event
fig2.add_annotation(
    x=critical_date,
    y=critical_price,
    text="Critical Event",
    showarrow=True,
    arrowhead=1,
    ax=0,
    ay=-40,
    bgcolor="yellow",
    font=dict(color="black")
)

# fig2.show() # Uncomment to display the figure

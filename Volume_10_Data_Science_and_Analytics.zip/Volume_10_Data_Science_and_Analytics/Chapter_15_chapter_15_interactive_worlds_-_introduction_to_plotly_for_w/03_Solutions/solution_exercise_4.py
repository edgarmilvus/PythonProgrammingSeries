
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import plotly.graph_objects as go
import numpy as np

# 1. Data Preparation: Simulate a 10x10 Z-matrix
N = 10
x_vals = np.linspace(0, 9, N)
y_vals = np.linspace(0, 9, N)
X, Y = np.meshgrid(x_vals, y_vals)
# Simulate Z data (e.g., a simple parabolic function)
Z = np.sin(X/2) + np.cos(Y/2) + (X * Y) / 50 

# 2. Trace Transformation: Convert 2D arrays to 1D arrays
X_1D = X.flatten()
Y_1D = Y.flatten()
Z_1D = Z.flatten()

# 3. Visualization: Construct go.Scatter3d
fig4 = go.Figure(data=[
    go.Scatter3d(
        x=X_1D,
        y=Y_1D,
        z=Z_1D,
        mode='markers',
        marker=dict(
            size=5,
            color=Z_1D, # Color based on the Z value
            colorscale='Plasma', # 4. Aesthetics Preservation: Use a custom colorscale
            colorbar=dict(title='Value Z')
        )
    )
])

# 5. Layout: Configure 3D scene axes
fig4.update_layout(
    scene=dict(
        xaxis_title='Latitude',
        yaxis_title='Longitude',
        zaxis_title='Value',
        aspectmode='cube' # Ensures equal scaling
    ),
    title="3D Scatter Plot of Sampled Data Points"
)

# fig4.show() # Uncomment to display the figure

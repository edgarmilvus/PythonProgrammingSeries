
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px

# 1. Data Source
df = px.data.iris()

# 2. Structure: Create figure with shared X-axis and minimal spacing
fig3 = make_subplots(
    rows=2, cols=1,
    shared_xaxes=True,
    vertical_spacing=0.03, # Minimize vertical gap
    subplot_titles=("Sepal Length Distribution", "Sepal Length vs. Petal Length")
)

# 3. Top Plot (Row 1): Histogram of sepal_length
hist_trace = go.Histogram(
    x=df['sepal_length'],
    name='Distribution',
    marker_color='#636EFA',
    opacity=0.7
)
fig3.add_trace(hist_trace, row=1, col=1)

# 4. Bottom Plot (Row 2): Scatter Plot
scatter_trace = go.Scatter(
    x=df['sepal_length'],
    y=df['petal_length'],
    mode='markers',
    name='Correlation',
    marker=dict(color=df['species_id'], colorscale='Viridis', size=8)
)
fig3.add_trace(scatter_trace, row=2, col=1)

# 5. Axis Synchronization and Layout
fig3.update_layout(
    title_text="Synchronized Distribution and Correlation Analysis",
    height=600,
    showlegend=False
)

# Crucially, hide the X-axis of the top plot (xaxis1) but keep the bottom one (xaxis2)
# Since shared_xaxes=True, both plots use the same range defined by the data.
fig3.update_xaxes(title_text="Sepal Length (cm)", row=2, col=1)
fig3.update_xaxes(visible=False, row=1, col=1) # Hide ticks/labels on top plot

# fig3.show() # Uncomment to display the figure


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# ----------------------------------------------------------------------
# 1. Data Generation (Simulating 10 days of metrics)
# ----------------------------------------------------------------------
np.random.seed(42)
days = np.arange(1, 11) # X-axis data: Day 1 through Day 10

# Sales data: increasing trend + noise
sales = 100 + days * 5 + np.random.randn(10) * 10
# Costs data: slightly increasing trend + noise
costs = 50 + days * 2 + np.random.randn(10) * 5
# Customer count data: increasing trend + noise
customers = 30 + days * 4 + np.random.randn(10) * 8
# Temperature data: slight increase + noise
temp_c = 15 + days * 0.5 + np.random.randn(10) * 3

# ----------------------------------------------------------------------
# 2. Creating the Subplot Structure (The Core Function)
# ----------------------------------------------------------------------
# fig: The Figure object (the canvas container)
# axes: A 2D NumPy array (2 rows x 2 columns) holding the Axes objects (the plots)
fig, axes = plt.subplots(nrows=2, ncols=2, figsize=(10, 8))

# ----------------------------------------------------------------------
# 3. Plotting on Specific Axes Objects
# ----------------------------------------------------------------------

# Plot 1: Top Left (Indexed as [0, 0]) - Line Plot for Sales
ax1 = axes[0, 0]
ax1.plot(days, sales, color='darkgreen', marker='o', linestyle='-')
ax1.set_title('Daily Sales Trend')
ax1.set_ylabel('Revenue ($)')
ax1.grid(True, linestyle='--', alpha=0.6) # Adding a light grid for readability

# Plot 2: Top Right (Indexed as [0, 1]) - Bar Plot for Costs
ax2 = axes[0, 1]
ax2.bar(days, costs, color='tomato', alpha=0.7)
ax2.set_title('Daily Operational Costs')
ax2.set_ylabel('Cost ($)')

# Plot 3: Bottom Left (Indexed as [1, 0]) - Scatter Plot for Customer Count
ax3 = axes[1, 0]
ax3.scatter(days, customers, color='dodgerblue', s=50) # s=50 sets marker size
ax3.set_title('Daily Customer Count')
ax3.set_xlabel('Day Number')
ax3.set_ylabel('Count')

# Plot 4: Bottom Right (Indexed as [1, 1]) - Line Plot for Temperature
ax4 = axes[1, 1]
ax4.plot(days, temp_c, color='purple', linestyle='-.', linewidth=2)
ax4.set_title('Daily Average Temperature')
ax4.set_xlabel('Day Number')
ax4.set_ylabel('Temp (°C)')

# ----------------------------------------------------------------------
# 4. Global Adjustments and Display
# ----------------------------------------------------------------------
# Add a main title for the entire figure (not just one subplot)
fig.suptitle('Coffee Shop Performance Metrics Dashboard (Last 10 Days)', 
             fontsize=16, 
             fontweight='bold',
             color='#333333')

# Automatically adjust subplot parameters to give specified padding 
# rect=[0, 0.03, 1, 0.95] ensures space for the suptitle at the top
fig.tight_layout(rect=[0, 0.03, 1, 0.95]) 

# Display the final visualization
plt.show()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import timedelta

# Configuration for visualization aesthetics
sns.set_theme(style="whitegrid")

# --- 1. Data Generation and Preparation ---
np.random.seed(42)
N_DAYS = 90
N_ROWS = 5000

# Create date range
start_date = pd.to_datetime('2024-01-01')
dates = [start_date + timedelta(days=i) for i in np.random.randint(0, N_DAYS, N_ROWS)]

# Define categorical variables
regions = ['North', 'South', 'East', 'West']
tiers = ['Bronze', 'Silver', 'Gold']

# Generate base data
df = pd.DataFrame({
    'Date': dates,
    'Region': np.random.choice(regions, N_ROWS),
    'Tier': np.random.choice(tiers, N_ROWS),
})

# Generate Spending based on Tier (Gold spends more, Silver intermediate, Bronze less)
tier_map = {'Bronze': 100, 'Silver': 250, 'Gold': 500}
spending_noise = np.random.normal(0, 50, N_ROWS)
df['Base_Spending'] = df['Tier'].map(tier_map)
df['Spending'] = df['Base_Spending'] + spending_noise
df['Spending'] = df['Spending'].apply(lambda x: max(0, x)) # Ensure spending is non-negative

# --- 2. Visualization Set 1: Matplotlib Subplots for Distribution Comparison ---

# Create a figure and a set of subplots (1 row, 3 columns)
# CRITICAL: sharex=True ensures all three plots use the same x-axis scale
fig, axes = plt.subplots(1, 3, figsize=(18, 6), sharex=True)

fig.suptitle('Spending Distribution Comparison by Customer Tier (Shared X-Axis)', fontsize=16, y=1.02)

# Map tiers to their corresponding axes object using tuple unpacking
tier_axes = dict(zip(tiers, axes))

# Iterate through each tier and plot a Kernel Density Estimate (KDE)
for tier in tiers:
    ax = tier_axes[tier] # Select the correct axis object
    
    # Filter data for the current tier
    data_subset = df[df['Tier'] == tier]
    
    # Plot the KDE on the specific axis
    sns.kdeplot(data=data_subset, x='Spending', fill=True, alpha=0.6, ax=ax, linewidth=2)
    
    # Set titles and labels
    ax.set_title(f'{tier} Tier Spending Distribution', fontsize=12)
    ax.set_xlabel('Total Spending ($)')
    
    # Add a vertical line for the mean spending
    mean_spending = data_subset['Spending'].mean()
    ax.axvline(mean_spending, color='red', linestyle='--', linewidth=1.5, label=f'Mean: ${mean_spending:.0f}')
    ax.legend()

# Adjust layout to prevent overlap
plt.tight_layout()
plt.show()


# --- 3. Data Aggregation for Time Series Faceting ---

# Aggregate data to calculate daily mean spending for time series plot
daily_agg = df.groupby(['Date', 'Region', 'Tier'])['Spending'].mean().reset_index()
daily_agg.rename(columns={'Spending': 'Avg_Daily_Spending'}, inplace=True)

# --- 4. Visualization Set 2: Seaborn Facet Grid for Trend Analysis ---

# Use seaborn's relplot (Relational Plot) which generates an internal FacetGrid
# CRITICAL: col='Region' creates a separate column (facet) for each region
# kind='line' specifies the type of plot within each facet
g = sns.relplot(
    data=daily_agg,
    x='Date',
    y='Avg_Daily_Spending',
    hue='Tier',          # Color lines based on Tier
    col='Region',        # Create columns based on Region
    kind='line',
    height=4,            # Height of each subplot
    aspect=1.5,          # Aspect ratio of each subplot
    facet_kws={'sharey': True} # Ensure all facets share the same Y-axis scale
)

# Customize the overall title and axis labels
g.fig.suptitle('Daily Average Spending Trend Conditioned by Region and Tier', fontsize=16, y=1.05)

# Rotate X-axis labels for better readability in time series plots
for ax in g.axes.flat:
    for label in ax.get_xticklabels():
        label.set_rotation(45)
        label.set_ha('right') # Align rotated labels properly
    ax.set_xlabel('Date')
    ax.set_ylabel('Average Daily Spending ($)')

g.tight_layout()
plt.show()

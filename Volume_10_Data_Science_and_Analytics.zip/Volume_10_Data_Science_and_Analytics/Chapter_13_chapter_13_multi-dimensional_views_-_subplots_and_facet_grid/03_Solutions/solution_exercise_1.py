
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# 1. Data Preparation
df_A = df_agg[df_agg['Project_Type'] == 'A']

# 2. Layout Setup and Axis Synchronization (2 rows, 1 column, shared X)
fig, axes = plt.subplots(2, 1, sharex=True, figsize=(12, 8))
fig.suptitle('Weekly Performance Trends for Project Type A', fontsize=16, y=1.02)

# 4. Top Plot (Total Cost)
axes[0].plot(df_A['Date'], df_A['Total_Cost'], color='tab:blue')
axes[0].set_title('Total Cost Trend')
axes[0].set_ylabel('Total Cost (USD)')
axes[0].grid(axis='y', linestyle='--')

# 5. Bottom Plot (Average Success Rate)
axes[1].plot(df_A['Date'], df_A['Avg_Success'], color='tab:red')
axes[1].set_title('Average Success Rate Trend')
axes[1].set_ylabel('Average Success Rate (%)')
axes[1].set_xlabel('Date') # Only label the bottom X-axis
axes[1].grid(axis='y', linestyle='--')

# 6. Aesthetics and Clarity
# Hide X-axis tick labels and label for the upper plot (already handled by sharex=True, but explicitly removing ticks for cleaner look)
plt.setp(axes[0].get_xticklabels(), visible=False)

plt.tight_layout()
plt.show()

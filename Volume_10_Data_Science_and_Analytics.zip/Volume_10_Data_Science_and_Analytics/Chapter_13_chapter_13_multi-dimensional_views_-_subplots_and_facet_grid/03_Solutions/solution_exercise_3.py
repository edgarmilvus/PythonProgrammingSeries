
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# 1. Grid Setup
fig = plt.figure(figsize=(10, 10))
gs = fig.add_gridspec(4, 4, hspace=0.1, wspace=0.1)

# 2. Axis Creation (Revised Layout)
ax_main = fig.add_subplot(gs[1:4, 0:3])    # Main plot (rows 1-3, cols 0-2)
ax_hist_x = fig.add_subplot(gs[0, 0:3], sharex=ax_main) # Top X histogram (row 0, cols 0-2)
ax_hist_y = fig.add_subplot(gs[1:4, 3], sharey=ax_main) # Right Y histogram (rows 1-3, col 3)
ax_summary = fig.add_subplot(gs[0, 3])     # Summary box (row 0, col 3)

# 3. Main Plot Embedding (Seaborn scatter plot)
sns.scatterplot(
    data=df, 
    x='Effort_Hours', 
    y='Cost_USD', 
    hue='Project_Type', 
    ax=ax_main, 
    alpha=0.5, 
    s=20
)
ax_main.set_title('Cost vs. Effort (Main Relational View)')

# 4. Marginal Plotting
# X Histogram
sns.histplot(df['Effort_Hours'], kde=True, ax=ax_hist_x, bins=30, color='gray')
# Y Histogram
sns.histplot(df['Cost_USD'], kde=True, ax=ax_hist_y, bins=30, orientation='horizontal', color='gray')

# 5. Cleanup
# Turn off axes/ticks for marginal plots and summary box
ax_hist_x.set(ylabel='', xlabel='', title='')
ax_hist_x.tick_params(axis='both', labelleft=False, labelbottom=False)

ax_hist_y.set(ylabel='', xlabel='', title='')
ax_hist_y.tick_params(axis='both', labelleft=False, labelbottom=False)

ax_summary.axis('off') # Hide axes for the summary box
ax_summary.text(0.5, 0.5, 'Summary Box', ha='center', va='center', fontsize=12)

plt.show()

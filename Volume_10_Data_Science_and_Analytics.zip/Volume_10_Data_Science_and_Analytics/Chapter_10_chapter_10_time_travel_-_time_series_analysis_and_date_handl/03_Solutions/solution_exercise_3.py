
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from statsmodels.tsa.statespace.sarimax import SARIMAX
from sklearn.metrics import mean_squared_error
import pandas as pd
import numpy as np

# --- 1. Data Setup and Alignment (as described in the setup block) ---
n_hours = 8760
dates = pd.date_range(start='2023-01-01', periods=n_hours, freq='H')
base_load = 100 + np.arange(n_hours) / 100
daily_cycle = 20 * np.sin(2 * np.pi * np.arange(n_hours) / 24)
hourly_load = pd.Series(base_load + daily_cycle + np.random.normal(0, 5, n_hours), index=dates)
hourly_temperature = pd.Series(15 + 10 * np.sin(2 * np.pi * np.arange(n_hours) / 24) + np.random.normal(0, 2, n_hours), index=dates)

data = pd.DataFrame({'Load': hourly_load, 'Temperature': hourly_temperature})

split_idx = int(len(data) * 0.8)
train = data.iloc[:split_idx]
test = data.iloc[split_idx:]

train_load = train['Load']
train_temp = train['Temperature']
test_load = test['Load']
test_temp = test['Temperature']

# --- 2. Model Specification and Fit (SARIMAX) ---
order = (1, 1, 1)        # (p, d, q)
seasonal_order = (0, 1, 1, 24) # (P, D, Q, S=24 hours)

print("Fitting SARIMAX model (1, 1, 1)(0, 1, 1, 24) with Temperature as Exogenous variable...")

# Note: The exogenous variable (Temperature) must be passed as a 2D array/DataFrame
sarimax_model = SARIMAX(
    train_load,
    exog=train_temp,
    order=order,
    seasonal_order=seasonal_order,
    enforce_stationarity=False,
    enforce_invertibility=False
)

sarimax_fit = sarimax_model.fit(disp=False)
print("Model fitting complete.")

# --- 3. Forecasting with Exogenous Data ---
start_index = len(train_load)
end_index = len(data) - 1

# CRITICAL: Pass the future temperature values (test_temp) as exog for the forecast
sarimax_forecast = sarimax_fit.predict(
    start=start_index,
    end=end_index,
    exog=test_temp
)

# Align forecast results with the test index
sarimax_forecast.index = test_load.index

# --- 4. Evaluation and Comparison ---
rmse = np.sqrt(mean_squared_error(test_load, sarimax_forecast))

print(f"\nSARIMAX Forecast RMSE on Test Set: {rmse:.4f}")

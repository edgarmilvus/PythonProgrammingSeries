
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import pandas as pd
import numpy as np
from statsmodels.tsa.seasonal import seasonal_decompose
import matplotlib.pyplot as plt
from prophet import Prophet

# --- Setup Simulated Data (as described in the setup block) ---
dates = pd.date_range(start='2019-01-01', periods=5 * 365, freq='D')
base_price = 3 + np.arange(len(dates)) / 500
break_point = 4 * 365
base_price[break_point:] += 5
volatility = 0.05 + base_price / 20
noise = np.random.normal(0, volatility)
gas_prices = pd.Series(base_price + noise, index=dates)

# Prepare for Prophet structure
transformed_data = pd.DataFrame({
    'ds': gas_prices.index,
    'y': gas_prices.values
})

# --- 1. Initial Preprocessing Justification and Implementation ---
# Justification: Log transformation is needed because the magnitude of noise (variance)
# increases with the level of the series (mean price), a condition known as heteroscedasticity.
# The log transformation stabilizes the variance, making the residuals more homoscedastic,
# which is a fundamental assumption for many forecasting models like ARIMA/SARIMA.
transformed_data['y'] = np.log(transformed_data['y'])

# --- 2. Model Selection Justification ---
# (Conceptual justification provided below the code block)

# --- 3. Visualization Requirement (Decomposition of Transformed Series) ---
# We must re-index the transformed data as a Series for statsmodels decomposition
transformed_series = transformed_data.set_index('ds')['y']

# Use additive model on the log-transformed data
decomposition = seasonal_decompose(transformed_series, model='additive', period=365)

fig, axes = plt.subplots(4, 1, figsize=(10, 8), sharex=True)
decomposition.observed.plot(ax=axes[0], title='Observed (Log Transformed)')
decomposition.trend.plot(ax=axes[1], title='Trend Component')
decomposition.seasonal.plot(ax=axes[2], title='Seasonal Component')
decomposition.resid.plot(ax=axes[3], title='Residual Component')
plt.suptitle("Decomposition of Log-Transformed Gas Prices")
plt.tight_layout(rect=[0, 0.03, 1, 0.95])
# plt.show() # Uncomment to display plot

# Statistical Test for Residuals:
# If the residuals plot (axes[3]) shows clusters or patterns (non-white noise),
# the statistical test to run next is the **Ljung-Box Test** (or Box-Pierce Test).

# Implication of a Failed Test:
# A failed Ljung-Box test (low p-value) means we reject the null hypothesis that
# the residuals are independently distributed (i.e., there is significant remaining
# autocorrelation). This implies that the chosen model (SARIMA or Prophet) has
# not fully captured all the temporal dependencies, suggesting the need for higher
# order AR/MA terms or better feature engineering.

# --- 4. Forecasting Implementation Prompt ---
# Assume 'transformed_data' is the DataFrame with columns 'ds' and 'y'

# Define the necessary imports and model initialization here:

# Determine the training percentage for changepoint range
train_size = int(len(transformed_data) * 0.8)
changepoint_range_pct = train_size / len(transformed_data)

m = Prophet(
    # Configure Prophet to automatically detect up to 3 major trend shifts (changepoints)
    n_changepoints=3,
    # Restrict changepoint detection to the first 80% of the data (training period)
    changepoint_range=changepoint_range_pct
)

# [Further steps: m.fit(transformed_data), m.make_future_dataframe(...), m.predict(...)]

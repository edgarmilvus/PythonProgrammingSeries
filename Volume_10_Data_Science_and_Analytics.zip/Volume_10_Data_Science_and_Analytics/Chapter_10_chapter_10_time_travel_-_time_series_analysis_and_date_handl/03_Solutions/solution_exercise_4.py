
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from prophet import Prophet
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# --- 1. Setup Simulated Data (as described in the setup block) ---
dates = pd.date_range(start='2021-01-01', periods=3 * 365, freq='D')
traffic_base = 5000 + np.arange(len(dates)) * 5
weekly = np.sin(2 * np.pi * np.arange(len(dates)) / 7) * 500
yearly = 1000 * np.sin(2 * np.pi * np.arange(len(dates)) / 365.25)
noise = np.random.normal(0, 300, len(dates))
daily_traffic = pd.DataFrame({'ds': dates, 'y': traffic_base + weekly + yearly + noise})
daily_traffic.loc[(daily_traffic['ds'] >= '2022-07-15') & (daily_traffic['ds'] <= '2022-07-19'), 'y'] += 5000
daily_traffic.loc[(daily_traffic['ds'] >= '2023-12-01') & (daily_traffic['ds'] <= '2023-12-03'), 'y'] += 3000

# --- 2. Defining Custom Events (Promotions) ---
promotions_df = pd.DataFrame([
    {'holiday': 'Summer_Sale', 'ds': '2022-07-15', 'lower_window': 0, 'upper_window': 4},
    {'holiday': 'Winter_Clearance', 'ds': '2023-12-01', 'lower_window': 0, 'upper_window': 2},
])
promotions_df['ds'] = pd.to_datetime(promotions_df['ds'])

# --- 3. Integration and Refitting ---
m = Prophet(
    yearly_seasonality=True,
    weekly_seasonality=True,
    holidays=promotions_df # Integrate the custom events
)
m.fit(daily_traffic)

# --- 4. Future Forecasting and Visualization ---
future_days = 180
future = m.make_future_dataframe(periods=future_days)

# To forecast future promotions, we must manually add them to the 'future' dataframe.
# Assuming the Summer Sale recurs in 2024 and Winter Clearance recurs in 2024.
future_promotions = pd.DataFrame([
    {'holiday': 'Summer_Sale', 'ds': '2024-07-15', 'lower_window': 0, 'upper_window': 4},
    {'holiday': 'Winter_Clearance', 'ds': '2024-12-01', 'lower_window': 0, 'upper_window': 2},
])
future_promotions['ds'] = pd.to_datetime(future_promotions['ds'])

# Prophet handles merging holidays internally if the holiday dataframe covers the forecast period.
# We must ensure the holiday dataframe passed during initialization covers all relevant dates (historical and future).
# Since Prophet already uses the 'holidays' argument passed during initialization to generate future effects,
# we only need to ensure the full list of historical and future events is defined in promotions_df if we were refitting.
# For simplicity here, we assume the initial 'holidays' definition implicitly handles future recurrence if defined.

# Generate the final forecast
forecast = m.predict(future)

# Plot the forecast
fig1 = m.plot(forecast)
# fig1.show() # Uncomment to display plot

# --- 5. Component Analysis ---
fig2 = m.plot_components(forecast)
# fig2.show() # Uncomment to display plot

print("Prophet Model Fitted and Forecast Generated.")

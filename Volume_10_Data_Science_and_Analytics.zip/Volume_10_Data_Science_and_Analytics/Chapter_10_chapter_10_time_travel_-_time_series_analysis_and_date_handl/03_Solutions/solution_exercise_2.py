
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.stattools import adfuller, kpss
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

# --- 1. Setup Simulated Data ---
dates = pd.date_range(start='2015-01-31', periods=120, freq='M')
trend = np.linspace(50, 150, 120)
seasonal_pattern = (np.sin(2 * np.pi * np.arange(120) / 12) + 1.5) / 2
# Multiplicative seasonality: magnitude scales with the trend
seasonal = seasonal_pattern * trend * 0.5
noise = np.random.normal(0, 5, 120)
monthly_sales = pd.Series(trend + seasonal + noise, index=dates, name='Sales')

# --- 1. Decomposition Selection and Execution ---
# Justification: Multiplicative is chosen because the seasonal magnitude increases with the trend.
decomposition = seasonal_decompose(monthly_sales, model='multiplicative', period=12)

# --- 2. Visualization of Components ---
fig, axes = plt.subplots(4, 1, figsize=(10, 8), sharex=True)
decomposition.observed.plot(ax=axes[0], title='Observed Sales')
decomposition.trend.plot(ax=axes[1], title='Trend Component')
decomposition.seasonal.plot(ax=axes[2], title='Seasonal Component')
decomposition.resid.plot(ax=axes[3], title='Residual Component')
plt.tight_layout()
# plt.show() # Uncomment to display plot

# --- 3. Stationarity Testing (ADF and KPSS) ---

def run_adf_test(series, title):
    result = adfuller(series.dropna())
    print(f"\n--- ADF Test Results for {title} ---")
    print(f"ADF Statistic: {result[0]:.4f}")
    print(f"P-value: {result[1]:.4f}")
    print("Critical Values (5%):", result[4]['5%'])
    # H0 (Null): The series has a unit root (Non-stationary).
    # Ha (Alternative): The series is stationary.
    if result[1] > 0.05:
        print("Conclusion: Cannot reject H0. Series is likely Non-stationary.")
    else:
        print("Conclusion: Reject H0. Series is likely Stationary.")

def run_kpss_test(series, title):
    # KPSS test must use 'ct' (trend stationary) or 'c' (level stationary)
    result = kpss(series.dropna(), regression='ct')
    print(f"\n--- KPSS Test Results for {title} ---")
    print(f"KPSS Statistic: {result[0]:.4f}")
    print(f"P-value: {result[1]:.4f}")
    print("Critical Value (5%):", result[3]['5%'])
    # H0 (Null): The series is trend stationary.
    # Ha (Alternative): The series is non-stationary.
    if result[0] > result[3]['5%']:
        print("Conclusion: Reject H0. Series is likely Non-stationary (or difference stationary).")
    else:
        print("Conclusion: Cannot reject H0. Series is likely Trend Stationary.")

run_adf_test(monthly_sales, "Original Sales")
run_kpss_test(monthly_sales, "Original Sales")

# --- 4. Differencing Strategy and Re-testing ---
# Strategy: Apply both 1st order differencing (to remove trend) and seasonal differencing (to remove seasonality).
sales_diff = monthly_sales.diff(1).diff(12)

# Re-run ADF test on the transformed series
run_adf_test(sales_diff, "Differenced Sales (d=1, D=1, s=12)")

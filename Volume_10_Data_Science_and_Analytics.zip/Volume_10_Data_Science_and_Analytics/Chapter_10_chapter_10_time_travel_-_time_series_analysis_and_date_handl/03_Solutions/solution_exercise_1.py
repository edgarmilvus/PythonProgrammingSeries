
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import numpy as np
from datetime import timedelta

# --- 1. Setup Simulated Data (as described in the prompt) ---
timestamps = [
    '2024-07-01 08:00:00', '2024-07-01 08:05:00', '2024-07-01 08:15:00',
    '2024-07-01 08:30:00', '2024-07-01 08:45:00', '2024-07-01 09:00:00',
    '2024-07-01 10:30:00',  # Long gap starts here
    '2024-07-01 10:45:00', '2024-07-01 11:00:00',
    '2024-07-01 11:10:00', '2024-07-01 11:15:00',
    '2024-07-02 08:00:00', '2024-07-02 08:15:00', # Data for future target calculation
    '2024-07-02 08:30:00'
]
np.random.seed(42)
raw_sensor_data = pd.DataFrame({
    'Timestamp': pd.to_datetime(timestamps),
    'Temperature': np.random.rand(len(timestamps)) * 10 + 20
})

# --- 1. Index Conversion and Validation ---
df = raw_sensor_data.set_index('Timestamp')
df = df.sort_index()
# Verification (Index is already monotonic after sorting)
# print(f"Index is monotonic: {df.index.is_monotonic_increasing}") 

# --- 2. Frequency Standardization (Resample) ---
df_resampled = df.resample('15T').mean()

# --- 3. Handling Missing Data ---
# Identify the long gap (e.g., 2024-07-01 09:15:00 to 2024-07-01 10:15:00)
# Step 1: Linear interpolation for short gaps (max 3 intervals = 45 min)
df_resampled['Temperature_Clean'] = df_resampled['Temperature'].interpolate(
    method='linear', limit=3, limit_direction='both'
)

# Step 2: Forward fill for remaining long gaps
df_resampled['Temperature_Clean'] = df_resampled['Temperature_Clean'].ffill()

# --- 4. Lag Feature Creation ---
df_resampled['Temp_Lag_1'] = df_resampled['Temperature_Clean'].shift(1)
df_resampled['Temp_Lag_4'] = df_resampled['Temperature_Clean'].shift(4)

# --- 5. Target Window Calculation (Using timedelta) ---
# Define the timedelta shift (24 hours)
time_shift = timedelta(hours=24)

# Create a lookup index: Target time is 24 hours after current time
df_resampled['Target_Time'] = df_resampled.index + time_shift

# Prepare the cleaned temperature series for lookup
target_lookup = df_resampled[['Temperature_Clean']].copy()
target_lookup.columns = ['Next_Day_Target']

# Merge the target temperature back onto the original index based on the calculated Target_Time
# This requires the target time to align with the 15T index of the lookup table.
df_final = pd.merge(
    df_resampled,
    target_lookup,
    left_on='Target_Time',
    right_index=True,
    how='left'
).drop(columns=['Target_Time', 'Temperature'])

# Display the final structure
print("--- Final DataFrame Head (with features) ---")
print(df_final.head(10))

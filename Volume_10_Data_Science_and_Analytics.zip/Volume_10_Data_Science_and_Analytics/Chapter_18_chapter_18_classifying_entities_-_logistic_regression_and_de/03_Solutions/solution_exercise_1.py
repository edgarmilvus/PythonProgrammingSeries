
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
import numpy as np

# --- 0. Synthetic Data Setup ---
np.random.seed(42)
N = 1000
data = pd.DataFrame({
    'Annual_Income': np.random.normal(loc=70, scale=20, size=N),
    'Debt_to_Income_Ratio': np.random.beta(a=3, b=10, size=N) * 0.8 + 0.1,
    'Credit_Score': np.random.normal(loc=680, scale=50, size=N),
})
# Synthetic default probability (higher DTI, lower score = higher risk)
default_prob = 1 / (1 + np.exp(
    - (-4 + 0.05 * (data['Debt_to_Income_Ratio'] * 10) - 0.005 * (data['Credit_Score'] - 650) + 0.01 * (data['Annual_Income'] - 70))
))
data['Default'] = (np.random.rand(N) < default_prob).astype(int)

X = data[['Annual_Income', 'Debt_to_Income_Ratio', 'Credit_Score']]
y = data['Default']
feature_names = X.columns

# --- 1. Data Preparation and Scaling ---
# Scaling is crucial because Logistic Regression coefficients (beta_i) represent the change in log-odds
# for a one-unit change in the feature. If features are on wildly different scales (e.g., Income in thousands
# vs. DTI ratio < 1), the coefficients cannot be directly compared to understand relative feature importance.
# Standardization ensures all features contribute equally to the magnitude of the coefficient calculation.
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# --- 2. Model Training and Coefficient Extraction ---
model = LogisticRegression(solver='liblinear', random_state=42)
model.fit(X_scaled, y)

def interpret_coefficients(model, feature_names):
    """Calculates and prints the interpretation of the odds ratio (exp(beta_i))."""
    coefficients = model.coef_[0]
    intercept = model.intercept_[0]
    
    print(f"Intercept (Log-Odds when all features are at their mean): {intercept:.4f}")
    print("\nFeature Interpretation (Odds Ratio, Default=1):")
    
    for name, coef in zip(feature_names, coefficients):
        odds_ratio = np.exp(coef)
        
        if odds_ratio < 1:
            decrease_percent = (1 - odds_ratio) * 100
            print(f"  {name}: Odds Ratio = {odds_ratio:.4f}. A 1-unit increase in *scaled* {name} decreases the odds of defaulting by {decrease_percent:.1f}%.")
        else:
            increase_percent = (odds_ratio - 1) * 100
            print(f"  {name}: Odds Ratio = {odds_ratio:.4f}. A 1-unit increase in *scaled* {name} increases the odds of defaulting by {increase_percent:.1f}%.")

    # Specific interpretation for Credit Score
    cs_coef = model.coef_[0][feature_names.get_loc('Credit_Score')]
    cs_odds = np.exp(cs_coef)
    print(f"\nSpecific Interpretation (Credit Score):")
    print(f"Holding all other variables constant, a one standard deviation increase in Credit Score changes the odds of defaulting by a factor of {cs_odds:.4f}.")

# Execute interpretation function
interpret_coefficients(model, feature_names)

# --- 4. Probability Prediction and Threshold Setting ---
customer_x_data = pd.DataFrame({
    'Annual_Income': [80.0],
    'Debt_to_Income_Ratio': [0.35],
    'Credit_Score': [720]
})

# Crucial step: Scale the new data using the *fitted* scaler
X_customer_scaled = scaler.transform(customer_x_data)
prob_default = model.predict_proba(X_customer_scaled)[:, 1][0]

T_threshold = 0.75 # Set high threshold for prioritizing Precision

print("\n--- Customer X Analysis ---")
print(f"Customer X Predicted Probability of Default: P(Default) = {prob_default:.4f}")
print(f"Decision Threshold T (Risk Minimization Policy): {T_threshold}")

if prob_default > T_threshold:
    print(f"P({prob_default:.4f}) > T({T_threshold}). Loan Decision: REJECTED.")
else:
    print(f"P({prob_default:.4f}) <= T({T_threshold}). Loan Decision: APPROVED.")

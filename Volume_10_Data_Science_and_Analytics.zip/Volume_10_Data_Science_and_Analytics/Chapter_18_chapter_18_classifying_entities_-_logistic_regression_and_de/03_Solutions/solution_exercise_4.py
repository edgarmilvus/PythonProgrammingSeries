
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import pandas as pd
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import recall_score, precision_score

# --- 0. Data Generation (Expanded for stability) ---
def generate_larger_data(N=200):
    """Generates a larger synthetic dataset reflecting spam/ham characteristics."""
    np.random.seed(42)
    data = []
    for _ in range(N):
        is_spam = np.random.choice([0, 1], p=[0.6, 0.4])
        
        if is_spam == 1:
            # Spam characteristics: high word count, high punctuation freq, high caps ratio
            wc = np.random.randint(10, 30)
            pf = np.random.uniform(0.08, 0.25)
            cr = np.random.uniform(0.15, 0.45)
        else:
            # Ham characteristics: low word count, low punctuation freq, low caps ratio
            wc = np.random.randint(3, 15)
            pf = np.random.uniform(0.01, 0.07)
            cr = np.random.uniform(0.0, 0.1)
        
        data.append({
            'Feature_Word_Count': wc,
            'Feature_Punctuation_Freq': pf,
            'Excessive_Caps_Ratio': cr, # Placeholder for now, calculated properly later
            'Is_Spam': is_spam
        })
    return pd.DataFrame(data)

df = generate_larger_data(N=200)

# We skip the raw text column since we are using the synthetic ratios directly
# to simulate the successful feature engineering process for stability in this exercise.
X = df[['Feature_Word_Count', 'Feature_Punctuation_Freq', 'Excessive_Caps_Ratio']]
y = df['Is_Spam']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

# --- 1. Feature Engineering (Conceptual Implementation, using synthetic data) ---
# Note: Since the input data structure provided in the prompt was simplified, 
# we rely on the synthetic data generation above which already incorporates the ratio.
def calculate_caps_ratio(text):
    """Calculates the ratio of uppercase letters to total non-whitespace characters."""
    # Implementation is symbolic here, as the synthetic data already contains the ratio.
    if not isinstance(text, str): return 0.0
    total_chars = len("".join(text.split()))
    if total_chars == 0: return 0.0
    caps_count = sum(1 for char in text if char.isupper())
    return caps_count / total_chars

# --- 2. Model Retraining ---
model = LogisticRegression(solver='liblinear', random_state=42)
model.fit(X_train, y_train)

# --- 3. Threshold Iteration Function ---
def classify_with_threshold(probabilities, threshold):
    """Converts probabilities into binary predictions based on the threshold T."""
    return (probabilities >= threshold).astype(int)

def run_threshold_optimization(model, X_test, y_test):
    """Loops through thresholds to find T_optimal that meets Recall >= 0.95."""
    probabilities = model.predict_proba(X_test)[:, 1]
    
    # Define thresholds from 0.1 to 0.9, step 0.05
    thresholds = np.arange(0.1, 0.91, 0.05)
    results = []
    target_recall = 0.95
    
    for T in thresholds:
        y_pred = classify_with_threshold(probabilities, T)
        # Handle zero division if no positive predictions are made
        recall = recall_score(y_test, y_pred, zero_division=0)
        precision = precision_score(y_test, y_pred, zero_division=0)
        results.append({'T': T, 'Recall': recall, 'Precision': precision})
        
    results_df = pd.DataFrame(results)
    
    # Find the optimal threshold T_optimal
    optimal_rows = results_df[results_df['Recall'] >= target_recall]
    
    if optimal_rows.empty:
        # Fallback if target is unreachable (rare with well-trained model)
        T_optimal = None
        P_optimal = None
    else:
        # Select the lowest T that meets the Recall target
        T_optimal = optimal_rows['T'].min()
        P_optimal = optimal_rows[optimal_rows['T'] == T_optimal]['Precision'].iloc[0]
        
    return T_optimal, P_optimal

# --- 4. Reporting ---
T_optimal, P_optimal = run_threshold_optimization(model, X_test, y_test)

print(f"Optimal Threshold T_optimal (Lowest T achieving Recall >= 0.95): {T_optimal:.2f}")
print(f"Precision achieved at T_optimal: {P_optimal:.4f}")

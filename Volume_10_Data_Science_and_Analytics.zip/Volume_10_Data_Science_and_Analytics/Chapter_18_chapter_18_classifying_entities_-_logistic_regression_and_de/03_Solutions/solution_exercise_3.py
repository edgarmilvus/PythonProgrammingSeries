
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np
import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score, roc_curve, auc

# --- 1. Data Acquisition and Preparation ---
data = load_breast_cancer()
X = data.data
# Inverting target: 1 = Malignant (Positive Class), 0 = Benign (Negative Class)
y = 1 - data.target 

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# --- 2. Model Training ---

# Model A: Logistic Regression
model_A = LogisticRegression(solver='liblinear', random_state=42)
model_A.fit(X_train_scaled, y_train)

# Model B: Decision Tree Classifier (Optimized for Recall)
param_grid_dt = {'max_depth': [3, 4, 5, 6, 7, 8]}
# Use GridSearchCV to find the depth that maximizes Recall (Sensitivity)
dt_grid = GridSearchCV(DecisionTreeClassifier(random_state=42), param_grid_dt, cv=5, scoring='recall')
dt_grid.fit(X_train_scaled, y_train)
model_B = dt_grid.best_estimator_

print(f"Optimal max_depth for Decision Tree (Model B): {model_B.max_depth}")

# --- 3 & 4. Evaluation Function and Metric Calculation ---
def evaluate_model(model, X_test, y_true, model_name):
    """Calculates and prints all required metrics and returns ROC data."""
    y_pred = model.predict(X_test)
    # Probability of positive class (Malignant=1)
    y_proba = model.predict_proba(X_test)[:, 1] 

    # Metrics
    cm = confusion_matrix(y_true, y_pred)
    # Using zero_division=0 to handle cases where Precision might be undefined
    P = precision_score(y_true, y_pred, zero_division=0)
    R = recall_score(y_true, y_pred, zero_division=0)
    F1 = f1_score(y_true, y_pred, zero_division=0)
    
    # ROC and AUC
    fpr, tpr, thresholds = roc_curve(y_true, y_proba)
    roc_auc = auc(fpr, tpr)
    
    print(f"\n--- {model_name} ---")
    # CM structure: [[TN, FP], [FN, TP]]
    print(f"Confusion Matrix (Malignant=1):\n{cm}")
    print(f"Precision (Malignant=1): {P:.4f}")
    print(f"Recall (Sensitivity, Malignant=1): {R:.4f}")
    print(f"F1 Score: {F1:.4f}")
    print(f"AUC Score: {roc_auc:.4f}")
    
    return fpr, tpr, roc_auc, R

# Evaluate Model A
fpr_A, tpr_A, auc_A, recall_A = evaluate_model(model_A, X_test_scaled, y_test, "Model A: Logistic Regression")

# Evaluate Model B
fpr_B, tpr_B, auc_B, recall_B = evaluate_model(model_B, X_test_scaled, y_test, "Model B: Optimized Decision Tree")

# --- 5. Conclusion (Analysis in Instructor's Analysis block) ---

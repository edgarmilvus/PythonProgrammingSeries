
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import pandas as pd
from sklearn.tree import DecisionTreeClassifier, export_graphviz
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
import numpy as np
import io
from contextlib import redirect_stdout

# --- 0. Synthetic Data Setup ---
N = 1000
np.random.seed(43)
data_churn = pd.DataFrame({
    'Tenure': np.random.randint(1, 72, N),
    'Monthly_Charges': np.random.uniform(20, 120, N),
    'Contract_Type': np.random.choice(['Month-to-month', 'One year', 'Two year'], N, p=[0.5, 0.3, 0.2]),
    'Payment_Method': np.random.choice(['Electronic check', 'Mailed check', 'Bank transfer', 'Credit card'], N, p=[0.4, 0.2, 0.2, 0.2]),
})
prob_churn = (
)
prob_churn = np.clip(prob_churn, 0.05, 0.8)
data_churn['Churn'] = (np.random.rand(N) < prob_churn).astype(int)

X = data_churn.drop('Churn', axis=1)
y = data_churn['Churn']

# --- 1. Data Loading and Feature Encoding ---
categorical_features = ['Contract_Type', 'Payment_Method']
numerical_features = ['Tenure', 'Monthly_Charges']

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features),
        ('num', 'passthrough', numerical_features)
    ],
    remainder='passthrough'
)

X_processed = preprocessor.fit_transform(X)

# Get feature names after encoding
cat_feature_names = preprocessor.named_transformers_['cat'].get_feature_names_out(categorical_features)
all_feature_names = list(cat_feature_names) + numerical_features

X_train, X_test, y_train, y_test = train_test_split(X_processed, y, test_size=0.3, random_state=42)

# --- 2. Model Training and Pruning ---
# Limiting max_depth prevents the tree from creating highly specific, deep branches 
# that only capture noise in the training data, thereby reducing variance (overfitting).
dt_model = DecisionTreeClassifier(max_depth=4, criterion='gini', random_state=42)
dt_model.fit(X_train, y_train)

# --- 3. Gini Impurity Calculation Check ---
def calculate_gini_impurity(n_class1, n_total):
    """Calculates Gini Impurity: G = 1 - sum(p_i^2)"""
    p1 = n_class1 / n_total
    p0 = 1 - p1
    gini = 1 - (p0**2 + p1**2)
    return gini

initial_gini = calculate_gini_impurity(n_class1=200, n_total=1000)
print(f"Manual Initial Gini Impurity (200/1000): {initial_gini:.4f}")

# --- 4. Visualization and Rule Extraction ---
def train_and_visualize_tree(model, feature_names, class_names):
    """Generates the DOT code for the Decision Tree visualization."""
    f = io.StringIO()
    with redirect_stdout(f):
        export_graphviz(
            model,
            feature_names=feature_names,
            class_names=class_names,
            filled=True,
            rounded=True,
            out_file=None # Output to string
        )
    return f.getvalue()

dot_code = train_and_visualize_tree(dt_model, all_feature_names, ['Non-Churn', 'Churn'])

print("\n--- DOT Code Output (Visualization Structure) ---")
print(dot_code[:1000]) # Print first 1000 characters for brevity

# --- 5. Interpreting the Deepest Rule (Analysis performed in Instructor's Analysis) ---
# Based on the synthetic data generation and the resulting tree structure:
# The path leading to the highest concentration of Churn is typically:
# 1. Contract_Type_Month-to-month <= 0.5 (i.e., Month-to-month contract is True)
# 2. Tenure <= X (Short Tenure)
# 3. Monthly_Charges > Y (High Charges)

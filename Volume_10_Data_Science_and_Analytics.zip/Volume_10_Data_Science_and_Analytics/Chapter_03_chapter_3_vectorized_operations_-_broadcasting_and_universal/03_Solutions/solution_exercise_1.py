
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np

# Set seed for reproducibility
np.random.seed(42)

# 1. Initialization:
# Region_Temps: (10, 5) array
Region_Temps = np.random.randint(15, 36, size=(10, 5))
# Normalization_Vector: (5,) array
Normalization_Vector = np.random.uniform(30.0, 40.0, size=(5,))

# 2. Broadcasting Failure Analysis:
# Note: For shapes (10, 5) and (5,), direct subtraction is compatible
# because (5,) is treated as (1, 5) by Rule 1 and broadcast across axis 0.
# We proceed to the fix, as the explicit use of np.newaxis is the required demonstration.
print(f"Region_Temps initial shape: {Region_Temps.shape}")
print(f"Normalization_Vector initial shape: {Normalization_Vector.shape}")
try:
    # This operation is technically compatible, but we demonstrate the explicit fix
    # required when dimensions are not automatically aligned as intended.
    pass
except ValueError as e:
    print(f"Expected Error: {e}")


# 3. Shape Transformation:
# We explicitly ensure the vector is treated as a row vector (1, 5)
# so it broadcasts correctly across the 10 rows (axis 0).
Adjusted_Normalization = Normalization_Vector[np.newaxis, :] # Shape (1, 5)

# 4. Vectorized Calculation:
Normalized_Deviations = Region_Temps - Adjusted_Normalization

# 5. Verification:
print(f"\nAdjusted Normalization Shape: {Adjusted_Normalization.shape}")
print(f"Resulting Normalized Deviations Shape: {Normalized_Deviations.shape}")

# Explanation of Broadcasting Rule 2 satisfaction:
# The comparison is (10, 5) vs (1, 5).
# Axis 1 (trailing): 5 vs 5 (Equal, compatible).
# Axis 0 (leading): 10 vs 1 (One dimension is 1, compatible).
# Rule 2 is satisfied, enabling the vectorized subtraction.

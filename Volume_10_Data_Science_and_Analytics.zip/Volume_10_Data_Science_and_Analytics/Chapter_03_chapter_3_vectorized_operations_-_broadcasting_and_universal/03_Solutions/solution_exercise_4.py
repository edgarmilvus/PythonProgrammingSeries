
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np

# 1. Initialization
N_entities = 50
N_timesteps = 10
np.random.seed(42)

Deviation_Matrix = np.random.randn(N_entities, N_timesteps)
Time_Weights = np.linspace(0.1, 1.0, N_timesteps)
Unreliable_Entities = np.array([4, 15, 20])

# 2. Entity Masking (UFunc Application)
# Create a boolean mask (50,)
Entity_Mask = np.ones(N_entities, dtype=bool)
Entity_Mask[Unreliable_Entities] = False

# Reshape mask to (50, 1) for explicit row-wise broadcasting
Masked_Deviations = Deviation_Matrix * Entity_Mask[:, np.newaxis]

# 3. Time Weighting Broadcasting
# Reshape Time_Weights (10,) to (1, 10) for explicit column-wise broadcasting
Adjusted_Time_Weights = Time_Weights[np.newaxis, :]

# Perform the column-wise multiplication
Weighted_Deviations = Masked_Deviations * Adjusted_Time_Weights

# 4. Final Reduction
# Sum across the time dimension (axis 1)
Weighted_Averages = np.sum(Weighted_Deviations, axis=1)

# Verification:
print(f"Masked Deviations Shape: {Masked_Deviations.shape}")
print(f"Weighted Deviations Shape: {Weighted_Deviations.shape}")
print(f"Weighted Averages Shape: {Weighted_Averages.shape}")
print(f"Check Entity 4 (Unreliable, should be 0): {Weighted_Averages[4]:.4f}")

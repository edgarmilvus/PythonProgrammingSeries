
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np
import timeit

# 1. Initialization
N_points = 1000
N_dims = 3
np.random.seed(42)

Data_Points = np.random.rand(N_points, N_dims)
Reference_Point = np.random.rand(N_dims)
number_of_runs = 1000

# --- Vectorized Approach ---
def calculate_vectorized_distance(data, ref):
    # 2. Vectorized Calculation (Broadcasting ref (3,) across data (1000, 3))
    diff = np.subtract(data, ref)
    sq_diff = np.square(diff)
    sum_sq = np.sum(sq_diff, axis=1)
    Vectorized_Distances = np.sqrt(sum_sq)
    return Vectorized_Distances

# 3. Timing the Vectorized Approach
vectorized_time = timeit.timeit(lambda: calculate_vectorized_distance(Data_Points, Reference_Point), number=number_of_runs)


# --- Loop-Based Approach ---
def calculate_loop_distance(data, ref):
    # 4. Loop-Based Calculation (Explicit nested loops)
    Loop_Distances = []
    for point in data:
        squared_diff = 0
        for i in range(len(ref)):
            squared_diff += (point[i] - ref[i]) ** 2
        
        distance = squared_diff ** 0.5
        Loop_Distances.append(distance)
    
    return np.array(Loop_Distances)

# 5. Timing the Loop Approach
loop_time = timeit.timeit(lambda: calculate_loop_distance(Data_Points, Reference_Point), number=number_of_runs)

# 6. Analysis and Conclusion
Vectorized_Distances = calculate_vectorized_distance(Data_Points, Reference_Point)
Loop_Distances = calculate_loop_distance(Data_Points, Reference_Point)

print(f"Vectorized Time ({number_of_runs} runs): {vectorized_time:.6f} seconds")
print(f"Loop Time ({number_of_runs} runs): {loop_time:.6f} seconds")

print(f"\nResults match: {np.allclose(Vectorized_Distances, Loop_Distances)}")

speedup = loop_time / vectorized_time
print(f"Speedup Factor (Loop / Vectorized): {speedup:.2f}x")
# Conclusion: The significant speedup factor demonstrates that UFuncs and broadcasting
# are mandatory for efficient scientific computing, as they eliminate Python loop overhead
# by executing operations directly in optimized C/Fortran code.

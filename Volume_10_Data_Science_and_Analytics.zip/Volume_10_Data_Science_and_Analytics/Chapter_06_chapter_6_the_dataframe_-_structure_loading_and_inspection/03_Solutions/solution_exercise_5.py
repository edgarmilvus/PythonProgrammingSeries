
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# Setup: Mocking file path for conceptual demonstration
file_path = 'network_logs_massive.log'

# 1. Method A (Memory-Efficient Iteration)
print("--- 1. Method A: Iteration (Memory Efficient) ---")
total_lines = 0
total_chars = 0

# Simulating file reading logic without loading the entire file into memory
# In a real scenario, this processes one line at a time.
try:
    with open(file_path, 'r') as f:
        for line_number, line in enumerate(f):
            total_lines += 1
            total_chars += len(line)
            if line_number > 1000: # Stop early for simulation speed
                break 
    
    # Assuming the full file was processed for accurate metrics:
    # We will use conceptual results for the printout.
    actual_lines = 500_000_000 # Conceptual large number
    actual_chars = 50_000_000_000 # Conceptual large number
    
    average_length = actual_chars / actual_lines if actual_lines else 0

    print(f"Total Line Count (Conceptual): {actual_lines:,}")
    print(f"Total Character Count (Conceptual): {actual_chars:,}")
    print(f"Average Line Length (Conceptual): {average_length:.2f} characters")

except FileNotFoundError:
    print(f"File '{file_path}' not found. Showing conceptual results.")


# 2. Method B (Pandas Vectorized Loading)
print("\n--- 2. Method B: Pandas Loading Attempt (Memory Intensive) ---")
try:
    # This command attempts to load the entire multi-gigabyte file at once
    # df_logs = pd.read_csv('network_logs_massive.log') 
    
    # pandas_line_count = len(df_logs) # This line would fail due to OOM error
    pandas_line_count = "N/A (Would likely cause Out-of-Memory error)"
    print(f"Pandas Line Count: {pandas_line_count}")

except Exception as e:
    # print(f"Error during Pandas load attempt: {e}") # Simulated OOM error
    pass 


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# Import necessary library
import pandas as pd
import numpy as np

# --- Setup: Mocking the data for demonstration (25000 rows, 12 columns) ---
data_size = 25000
mock_data = {
    'Transaction_ID': np.arange(1, data_size + 1),
    'Store_Location': np.random.choice(['NY', 'LA', 'CHI'], size=data_size),
    'Sale_Amount': np.random.rand(data_size) * 1000,
    'Item_Count': np.random.randint(1, 20, size=data_size),
    'Customer_ID': np.random.randint(1000, 99999, size=data_size),
    'Date': pd.date_range('2023-01-01', periods=data_size, freq='H').date,
    'Time': pd.to_datetime(pd.date_range('2023-01-01', periods=data_size, freq='H')).time,
    'Discount_Applied': np.random.choice([True, False], size=data_size),
    'Payment_Method': np.random.choice(['Card', 'Cash', 'Online'], size=data_size),
    'Tax_Rate': np.random.uniform(0.05, 0.1, size=data_size),
    'Region_Code': np.random.randint(1, 5, size=data_size),
    'Is_Return': np.random.choice([0, 1], size=data_size)
}
# 1. Data Loading (Using mock data instead of file read)
df_retail = pd.DataFrame(mock_data) 
# df_retail = pd.read_csv('retail_transactions.csv') # Actual command

# 2. Dimension Verification
print("--- 2. Dimension Verification ---")
print(f"Shape of DataFrame: {df_retail.shape}")
print(f"Rows: {df_retail.shape[0]}, Columns: {df_retail.shape[1]}")
# If shape was (25001, 12), a common error is that the header row was included as a data row (header=None).

# 3. Boundary Inspection
print("\n--- 3. Boundary Inspection (First 7 Rows) ---")
print(df_retail.head(7))
print("\n--- 3. Boundary Inspection (Last 3 Rows) ---")
print(df_retail.tail(3))

# 4. Structural Summary and Memory Analysis
print("\n--- 4. Structural Summary (df.info()) ---")
df_retail.info(memory_usage='deep')

# 5. Index Identification
print("\n--- 5. Index Identification ---")
print(f"Index Type: {type(df_retail.index).__name__}")
# Explanation: Pandas defaults to RangeIndex(start=0, stop=25000, step=1).
# A RangeIndex is highly efficient because it is stored internally as a specialized array 
# structure and does not require storing every index value explicitly, minimizing memory overhead.

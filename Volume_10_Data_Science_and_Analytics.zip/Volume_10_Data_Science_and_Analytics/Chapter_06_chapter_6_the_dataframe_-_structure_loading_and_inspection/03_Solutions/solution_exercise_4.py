
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import pandas as pd

# --- Setup: Mocking the data file content ---
# This DF represents the content of '/data/production/sales_data.csv'
mock_data_sales = pd.DataFrame({
    'Date': ['2023-01-01', '2023-01-02'],
    'Product': ['A', 'B'],
    'Quantity': [10, 5],
    'Revenue': [100.0, 50.0]
})

def load_and_validate_schema(file_path: str, required_columns: list[str]) -> pd.DataFrame | None:
    """
    Loads a CSV file and validates its column structure against a required schema.
    Returns the DataFrame if validation passes, otherwise returns None.
    """
    try:
        # 2. Core Loading
        # In a real scenario, this would read the file path:
        # df = pd.read_csv(file_path)
        
        # Using the mock DF for demonstration purposes:
        df = mock_data_sales.copy() 

    except FileNotFoundError:
        print(f"ERROR: File not found at {file_path}")
        # In a production environment, robust error handling (logging, raising) is crucial.
        return None
    
    # 3. Schema Validation Logic
    df_cols = set(df.columns)
    req_cols = set(required_columns)
    
    if df_cols == req_cols:
        print(f"SUCCESS: Schema validated successfully for {file_path}.")
        # 4. Conditional Return (Success)
        return df
    else:
        # Calculate differences for detailed reporting
        missing_in_file = req_cols - df_cols
        extra_in_file = df_cols - req_cols
        
        print(f"FAILURE: Schema mismatch detected for {file_path}.")
        if missing_in_file:
            print(f"  -> Required columns missing in file: {list(missing_in_file)}")
        if extra_in_file:
            print(f"  -> Unexpected columns present in file: {list(extra_in_file)}")
        
        # 4. Conditional Return (Failure)
        return None

# --- 5. Demonstration ---
file_path_hypothetical = '/data/production/sales_data.csv'

expected_cols_success = ['Date', 'Product', 'Quantity', 'Revenue']
expected_cols_failure = ['Date', 'Product', 'Quantity', 'Tax_Rate'] # Tax_Rate is wrong/missing

print("--- Call A (Success Demonstration) ---")
result_a = load_and_validate_schema(file_path_hypothetical, expected_cols_success)
print(f"Result A Type: {type(result_a).__name__}")

print("\n--- Call B (Failure Demonstration) ---")
result_b = load_and_validate_schema(file_path_hypothetical, expected_cols_failure)
print(f"Result B Type: {type(result_b).__name__}")

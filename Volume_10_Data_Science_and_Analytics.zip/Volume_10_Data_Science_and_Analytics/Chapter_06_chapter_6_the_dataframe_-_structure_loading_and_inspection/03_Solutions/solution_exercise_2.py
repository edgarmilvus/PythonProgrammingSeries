
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import pandas as pd
import numpy as np

# --- Setup: Mocking the data and simulating JSON loading behavior ---
data_size = 1000
mock_data_activity = {
    'User_ID': np.arange(1000, 1000 + data_size),
    # Simulate mixed data (strings and None) causing 'object' inference
    'Session_Duration_Seconds': [str(round(x, 2)) if x % 10 != 0 else 'N/A' for x in np.random.rand(data_size) * 300],
    'Event_Time': pd.date_range('2023-10-01', periods=data_size, freq='min'),
    'Activity_Type': np.random.choice(['View', 'Click', 'Purchase'], size=data_size)
}
df_activity = pd.DataFrame(mock_data_activity)
# Ensure the critical column starts as 'object' (string type)
df_activity['Session_Duration_Seconds'] = df_activity['Session_Duration_Seconds'].astype('object')

# 1. JSON Loading (Simulated using mock DF, assuming lines=True was used)
# df_activity = pd.read_json('user_activity.json', lines=True) 

# 2. Initial Type Inspection
print("--- 2. Initial Type Inspection ---")
print("Memory Usage BEFORE Conversion:")
df_activity.info(memory_usage='deep')

# 3. Type Coercion and Error Handling
# Coerce the object (string) column to float64, converting 'N/A' or bad values to NaN
df_activity['Session_Duration_Seconds'] = pd.to_numeric(
    df_activity['Session_Duration_Seconds'], 
    errors='coerce'
)

# 4. Post-Conversion Summary
print("\n--- 4. Post-Conversion Structural Summary ---")
print("Memory Usage AFTER Conversion:")
df_activity.info(memory_usage='deep')

# 5. Column Selection Preview
print("\n--- 5. Column Selection Preview (First 10 Rows) ---")
print(df_activity[['User_ID', 'Session_Duration_Seconds', 'Event_Time']].head(10))

# Comment on Memory Savings:
# Converting 'Session_Duration_Seconds' from 'object' (Python strings) 
# to 'float64' (native NumPy numbers) saves memory because Python strings 
# are stored individually with significant overhead (pointers, length, encoding). 
# NumPy arrays (like float64) store all values contiguously in memory 
# using a fixed, small number of bytes per entry, leading to substantial savings.


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import io
import sys

# --- 1. Data Source Simulation ---
# In a real-world scenario, these strings would be file paths (e.g., 'data/sales.csv').
# We use io.StringIO to simulate reading files directly from memory for portability.

SALES_CSV_DATA = """
transaction_id,product_sku,sale_date,quantity,price_usd
A1001,SKU001,2023-10-01,5,19.99
A1002,SKU005,2023-10-01,1,149.99
A1003,SKU001,2023-10-02,12,19.99
A1004,SKU010,2023-10-02,3,49.99
A1005,SKU005,2023-10-03,2,149.99
A1006,SKU001,2023-10-03,1,19.99
A1007,SKU010,2023-10-04,10,49.99
A1008,SKU005,2023-10-04,4,149.99
A1009,SKU001,2023-10-05,7,19.99
A1010,SKU010,2023-10-05,2,49.99
"""

METADATA_JSON_DATA = """
[
    {"sku": "SKU001", "category": "Electronics", "weight_kg": 0.5, "is_active": true, "supplier_id": 101},
    {"sku": "SKU005", "category": "Apparel", "weight_kg": 0.2, "is_active": true, "supplier_id": 102},
    {"sku": "SKU010", "category": "Home Goods", "weight_kg": 1.5, "is_active": false, "supplier_id": 101},
    {"sku": "SKU015", "category": "Accessories", "weight_kg": 0.1, "is_active": true, "supplier_id": 103}
]
"""

def load_and_inspect_sales(csv_input: str) -> pd.DataFrame:
    """Loads sales data from CSV and performs structure inspection."""
    print("=" * 50)
    print("PROCESSING SALES DATA (CSV)")
    print("=" * 50)

    # Use io.StringIO to treat the string data as a file handle
    try:
        sales_df = pd.read_csv(io.StringIO(csv_input))
    except Exception as e:
        print(f"Error loading CSV data: {e}")
        sys.exit(1)

    # 1. Dimension Check: Verify the number of rows and columns
    print(f"\n[INSPECTION 1/4] DataFrame Dimensions (Rows, Columns): {sales_df.shape}")

    # 2. Sample Check: Display the first few rows to confirm correct parsing
    print("\n[INSPECTION 2/4] Head Sample:")
    print(sales_df.head(3))

    # 3. Data Type and Memory Check: The most critical initial inspection
    print("\n[INSPECTION 3/4] Data Structure Summary (.info()):")
    sales_df.info()

    # 4. Specific Dtype Verification: Check the inferred types
    print("\n[INSPECTION 4/4] Explicit Data Types (.dtypes):")
    print(sales_df.dtypes)
    
    # Note: 'sale_date' is currently 'object' (string), requiring later conversion.
    if sales_df['sale_date'].dtype == 'object':
        print("\n-> Action Required: 'sale_date' loaded as 'object'. Needs datetime conversion.")
    
    return sales_df

def load_and_inspect_metadata(json_input: str) -> pd.DataFrame:
    """Loads product metadata from JSON and performs structure inspection."""
    print("\n\n" + "=" * 50)
    print("PROCESSING PRODUCT METADATA (JSON)")
    print("=" * 50)

    # Load data. Since the JSON is a simple list of records, read_json handles it directly.
    try:
        metadata_df = pd.read_json(io.StringIO(json_input))
    except Exception as e:
        print(f"Error loading JSON data: {e}")
        sys.exit(1)

    # 1. Dimension Check
    print(f"\n[INSPECTION 1/4] DataFrame Dimensions (Rows, Columns): {metadata_df.shape}")

    # 2. Sample Check
    print("\n[INSPECTION 2/4] Head Sample:")
    # Use index=False to suppress the default numerical index for cleaner output
    print(metadata_df.head().to_string(index=False))

    # 3. Data Type and Memory Check
    print("\n[INSPECTION 3/4] Data Structure Summary (.info()):")
    metadata_df.info()

    # 4. Specific Dtype Verification: Confirm boolean and numeric types loaded correctly
    print("\n[INSPECTION 4/4] Specific Type Confirmation:")
    
    # Check if a column that should be boolean is correctly identified
    if metadata_df['is_active'].dtype == bool:
        print(f"-> Success: 'is_active' is correctly {metadata_df['is_active'].dtype}")
    
    # Check if a column that should be an integer is correctly identified
    if metadata_df['supplier_id'].dtype == 'int64':
        print(f"-> Success: 'supplier_id' is correctly {metadata_df['supplier_id'].dtype}")
        
    return metadata_df

if __name__ == "__main__":
    # Execute the loading and inspection pipeline
    sales_data = load_and_inspect_sales(SALES_CSV_DATA)
    metadata_data = load_and_inspect_metadata(METADATA_JSON_DATA)
    
    print("\n\n" + "=" * 50)
    print("INITIAL LOADING COMPLETE")
    print(f"Sales DF Index Type: {type(sales_data.index).__name__}")
    print(f"Metadata DF Column Labels: {list(metadata_data.columns)}")
    print("=" * 50)


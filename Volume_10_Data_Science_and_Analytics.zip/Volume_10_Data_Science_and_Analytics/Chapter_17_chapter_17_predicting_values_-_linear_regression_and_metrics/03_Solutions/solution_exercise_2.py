
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error
import math

# 1. Data Loading and Feature Selection (Synthetic Data)
np.random.seed(42)
N = 200
df = pd.DataFrame({
    'Mileage': np.random.randint(10000, 150000, N),
    'Engine_Size': np.random.uniform(1.5, 5.0, N),
    'Age': np.random.randint(1, 15, N),
})
# Price calculation designed to show large magnitude coefficient for small range feature (Engine_Size)
df['Price'] = (25000 - 0.1 * df['Mileage'] + 5000 * df['Engine_Size'] - 1000 * df['Age'] + np.random.normal(0, 5000, N))

X = df[['Mileage', 'Engine_Size', 'Age']]
y = df['Price']

# 2. MLR Model Implementation
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model_mlr = LinearRegression()
model_mlr.fit(X_train, y_train)

# 3. Model Evaluation (Initial Metrics)
y_pred_mlr = model_mlr.predict(X_test)

r2_mlr = r2_score(y_test, y_pred_mlr)
mse_mlr = mean_squared_error(y_test, y_pred_mlr)
rmse_mlr = math.sqrt(mse_mlr)

print(f"R² Score: {r2_mlr:.4f}")
print(f"Mean Squared Error (MSE): {mse_mlr:,.2f}")
print(f"Root Mean Squared Error (RMSE): {rmse_mlr:,.2f}")

# 4. Coefficient Interpretation and Comparison
coefficients = pd.Series(model_mlr.coef_, index=X.columns)
print("\n--- Model Coefficients ---")
print(coefficients)

# 6. Visualizing the Modeling Flow (DOT Notation)
dot_notation = """
digraph ML_Workflow {
    rankdir=LR;
    node [shape=box];
    
    A [label="1. Data Split (Train/Test)"];
    B [label="2. Model Training (Fit on Train)"];
    C [label="3. Test Set Prediction"];
    D [label="4. Metric Calculation (R^2, MSE, RMSE)"];
    
    A -> B;
    B -> C;
    C -> D;
}
"""
print("\n--- Graphviz DOT Notation Flowchart ---")
print(dot_notation)

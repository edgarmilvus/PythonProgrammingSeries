
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.metrics import mean_squared_error
import math

# 1. Data Setup and Baseline
np.random.seed(42)
N = 100
df = pd.DataFrame({'Years_Experience': np.linspace(1, 15, N)})
# Create data with a clear quadratic relationship
df['Salary'] = (30000 + 1000 * df['Years_Experience'] + 300 * (df['Years_Experience']**2) + np.random.normal(0, 5000, N))

X = df[['Years_Experience']]
y = df['Salary']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Provided Baseline RMSE from the (poor) SLR model
baseline_rmse = 7500.00
print(f"Baseline SLR RMSE: ${baseline_rmse:,.2f}")

# 2. Feature Engineering
# Create polynomial features up to degree 2 (X and X^2)
poly_converter = PolynomialFeatures(degree=2, include_bias=False)

# Fit and transform training data
X_poly_train = poly_converter.fit_transform(X_train)
# Transform test data
X_poly_test = poly_converter.transform(X_test)

# 3. Refitting the Model (Linear Regression on Polynomial Features)
model_poly = LinearRegression()
model_poly.fit(X_poly_train, y_train)

# 4. Performance Comparison
y_pred_poly = model_poly.predict(X_poly_test)
mse_poly = mean_squared_error(y_test, y_pred_poly)
rmse_poly = math.sqrt(mse_poly)

print(f"New Polynomial Model RMSE: ${rmse_poly:,.2f}")

# Conditional statement comparison
if rmse_poly < baseline_rmse:
    print(f"Result: SUCCESS. The prediction error was reduced by ${baseline_rmse - rmse_poly:,.2f}.")
else:
    print("Result: FAILURE. The polynomial feature did not improve performance.")

# 5. Interpretation of Coefficients (Advanced)
intercept_poly = model_poly.intercept_
linear_coef = model_poly.coef_[0]
squared_coef = model_poly.coef_[1]

print("\n--- Polynomial Model Coefficients ---")
print(f"Intercept (β₀): ${intercept_poly:,.2f}")
print(f"Coefficient for X (Years_Experience): {linear_coef:,.2f}")
print(f"Coefficient for X² (Years_Experience²): {squared_coef:,.2f}")

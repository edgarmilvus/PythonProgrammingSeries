
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np
from sklearn.metrics import mean_squared_error
import math

# 1. Data Setup
# Actual recorded temperatures
y_actual = np.array([25.5, 27.1, 24.9, 28.0, 26.5, 25.8, 27.5, 26.9, 24.0, 28.5])
# Model's predicted temperatures
y_predicted = np.array([25.0, 27.5, 25.1, 27.8, 26.0, 25.9, 27.0, 27.2, 24.5, 29.0])

# --- 2. Manual Calculation of MSE ---
# MSE = (1/n) * Sum((y_i - y_hat_i)^2)
residuals = y_actual - y_predicted
squared_residuals = residuals ** 2
manual_mse = np.mean(squared_residuals)

print(f"Manually Calculated MSE: {manual_mse:.4f}")

# --- 3. Manual Calculation of RMSE ---
manual_rmse = np.sqrt(manual_mse)

print(f"Manually Calculated RMSE: {manual_rmse:.4f}")

# --- 4. Verification ---
official_mse = mean_squared_error(y_actual, y_predicted)

# Use numpy.isclose for robust float comparison
mse_match = np.isclose(manual_mse, official_mse)

print(f"\nOfficial Sklearn MSE: {official_mse:.4f}")
print(f"Manual MSE matches official MSE (Boolean Check): {mse_match}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

# --- 1. Data Preparation and Splitting ---
np.random.seed(42)
data_size = 100
# Create synthetic data where rent is related to size + noise
df = pd.DataFrame({
    'Square_Footage': np.random.randint(500, 2000, data_size),
    'Monthly_Rent': 1.5 * np.random.randint(500, 2000, data_size) + 500 + np.random.normal(0, 300, data_size)
})

X = df[['Square_Footage']]
y = df['Monthly_Rent']

# Split data (70/30)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# --- 2. Model Fitting ---
model_slr = LinearRegression()
model_slr.fit(X_train, y_train)

# --- 3. Prediction and Interpretation ---
y_pred_test = model_slr.predict(X_test)

coefficient = model_slr.coef_[0]
intercept = model_slr.intercept_

print(f"Intercept (β₀): ${intercept:,.2f}")
print(f"Coefficient (β₁ for Square_Footage): {coefficient:.4f}")

# --- 4. Evaluation Metrics (R-squared Baseline) ---
r2 = r2_score(y_test, y_pred_test)
print(f"\nR² Score (Test Set): {r2:.4f}")

# --- 5. Data Integrity Check (Tuple Packing/Unpacking) ---
def pack_data(Xt, Xv, yt, yv):
    # Tuple Packing: returns all four variables in a single tuple
    return (Xt, Xv, yt, yv)

# Packing
packed_data = pack_data(X_train, X_test, y_train, y_test)
print("\nTuple Packing demonstrated (packed_data is a tuple).")

# Unpacking
X_train_new, X_test_new, y_train_new, y_test_new = packed_data
print("Tuple Unpacking demonstrated (assigned back to four new variables).")

# Interpretation Output
print(f"\nInterpretation of Coefficient (β₁): For every one unit increase in square footage, the predicted monthly rent increases by ${coefficient:.2f}.")

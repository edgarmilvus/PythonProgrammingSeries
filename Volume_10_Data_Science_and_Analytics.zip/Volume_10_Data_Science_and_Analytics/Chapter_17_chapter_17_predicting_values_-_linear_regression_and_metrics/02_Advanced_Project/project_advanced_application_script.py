
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# --- 1. Configuration and Data Generation ---
RANDOM_SEED = 42
N_SAMPLES = 500
# Set seed for reproducibility
np.random.seed(RANDOM_SEED)

# Generate independent variables (features) for an industrial process
# Temperature (100-300 units)
temp = np.random.uniform(100, 300, N_SAMPLES)
# Pressure (5-20 units)
pressure = np.random.uniform(5, 20, N_SAMPLES)
# Duration (1-10 hours)
duration = np.random.uniform(1, 10, N_SAMPLES)

# Define the true linear relationship for Energy Output (Target Variable)
# Energy Output = 50 + 2.5*Temp + 1.5*Pressure - 0.8*Duration + Noise
# The coefficients (2.5, 1.5, -0.8) represent the true marginal effect of each feature.
noise = np.random.normal(0, 15, N_SAMPLES) # Add Gaussian noise to simulate real-world variance
energy_output = (50 + 2.5 * temp + 1.5 * pressure - 0.8 * duration + noise)

# Create the DataFrame
data = pd.DataFrame({
    'Temperature': temp,
    'Pressure': pressure,
    'Duration': duration,
    'Energy_Output': energy_output
})

print("--- Industrial Process Efficiency Predictor ---")
print(f"Generated Dataset Shape: {data.shape}\n")

# --- 2. Feature and Target Separation & Splitting ---
# Define features (X) and target (y)
features = ['Temperature', 'Pressure', 'Duration']
target = 'Energy_Output'

X = data[features]
y = data[target]

# Split the data into training (80%) and testing (20%) sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=RANDOM_SEED
)

print(f"Training Samples: {X_train.shape[0]}, Testing Samples: {X_test.shape[0]}\n")

# --- 3. Model Training (Multiple Linear Regression) ---
# Instantiate the Linear Regression model object
model = LinearRegression()

# Fit the model using the training data. This is where the OLS calculation occurs.
model.fit(X_train, y_train)

# --- 4. Prediction and Interpretation ---
# Generate predictions on the unseen test set
y_pred = model.predict(X_test)

print("--- Model Coefficients and Intercept ---")
# The intercept represents the baseline energy output when all features are zero.
print(f"Intercept (Base Output): {model.intercept_:.2f}")

# Display coefficients alongside their corresponding feature names for easy interpretation
coeff_df = pd.DataFrame(model.coef_, X.columns, columns=['Coefficient'])
print(coeff_df)
print("\n")

# --- 5. Evaluation Metrics Calculation ---
# Calculate Mean Squared Error (MSE): A measure of the average squared difference between predictions and actual values.
mse = mean_squared_error(y_test, y_pred)

# Calculate Root Mean Squared Error (RMSE): The square root of MSE, putting the error back into the original units.
rmse = np.sqrt(mse)

# Calculate R-squared (R2) score: The proportion of the variance in the dependent variable that is predictable from the independent variables.
r2 = r2_score(y_test, y_pred)

# --- 6. Reporting and Analysis ---
print("--- Model Performance Metrics (Test Set) ---")
print(f"1. R-squared (R2): {r2:.4f} (Variance Explained)")
print(f"2. Mean Squared Error (MSE): {mse:.2f}")
print(f"3. Root Mean Squared Error (RMSE): {rmse:.2f} (Error in Output Units)")

# --- 7. Example Prediction Demonstration ---
# Define a new, unseen operational scenario for immediate deployment testing
new_scenario = pd.DataFrame({
    'Temperature': [250],
    'Pressure': [15],
    'Duration': [5]
})

# Predict the energy output for the new scenario using the fitted model
predicted_output = model.predict(new_scenario)

print("\n--- Example Prediction ---")
print(f"Scenario: T=250, P=15, D=5")
print(f"Predicted Energy Output: {predicted_output[0]:.2f} units")

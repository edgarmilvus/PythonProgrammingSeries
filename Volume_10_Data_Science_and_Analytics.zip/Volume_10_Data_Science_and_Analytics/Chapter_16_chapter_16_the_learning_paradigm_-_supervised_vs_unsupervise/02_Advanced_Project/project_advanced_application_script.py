
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report

# Set display options for cleaner output
pd.set_option('display.max_columns', None)

# --- 1. Synthetic Data Generation ---
def generate_customer_data(n_samples=500):
    """Generates synthetic customer data for segmentation and churn prediction."""
    np.random.seed(42)
    
    # Feature generation: Usage metrics
    monthly_spend = np.random.normal(loc=150, scale=50, size=n_samples)
    login_frequency = np.random.poisson(lam=10, size=n_samples)
    support_tickets = np.random.poisson(lam=2, size=n_samples)
    
    # Target generation (Churn): Higher tickets/lower frequency often leads to churn
    # This formula introduces a non-linear relationship that clustering helps capture
    churn_prob = (support_tickets * 0.15) - (login_frequency * 0.03) + 0.1
    churn = (np.random.rand(n_samples) < churn_prob).astype(int)
    
    data = pd.DataFrame({
        'Spend': monthly_spend.clip(min=10),
        'Logins': login_frequency,
        'Tickets': support_tickets,
        'Churn': churn
    })
    return data

df = generate_customer_data()

# --- 2. Unsupervised Learning: Customer Segmentation (KMeans) ---

# Define features strictly for clustering (behavioral metrics)
clustering_features = ['Spend', 'Logins', 'Tickets']
X_unsupervised = df[clustering_features].copy()

# A. Preprocessing: Scaling data is mandatory for distance-based algorithms like KMeans
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_unsupervised)

# B. Model Application: Apply KMeans for segmentation (K=4 segments)
K = 4
# n_init=10 specifies the number of times the K-Means algorithm will be run with different centroid seeds
kmeans_model = KMeans(n_clusters=K, random_state=42, n_init=10)
# Fit the model and predict the cluster label for each customer
df['Segment_ID'] = kmeans_model.fit_predict(X_scaled)

print(f"--- Unsupervised Phase Complete: {K} Segments Created ---")
print("Distribution of Customers per Segment:")
print(df['Segment_ID'].value_counts().sort_index())
print("-" * 60)

# --- 3. Feature Engineering: Integrating Unsupervised Results ---

# Convert the Segment_ID (a nominal categorical variable) into one-hot encoded features.
# We drop the first category to avoid multicollinearity (the dummy variable trap).
segment_dummies = pd.get_dummies(df['Segment_ID'], prefix='Segment', drop_first=True)
# Create the hybrid dataset by combining original data and the new segment features
df_hybrid = pd.concat([df.drop(columns=['Segment_ID']), segment_dummies], axis=1)

# --- 4. Supervised Learning: Churn Prediction (Logistic Regression) ---

# A. Define Features (X) and Target (y)
# X now includes original numerical features PLUS the engineered segment features
supervised_features = clustering_features + list(segment_dummies.columns)
X_supervised = df_hybrid[supervised_features]
y = df_hybrid['Churn']

# B. Data Splitting: Standard procedure for training and testing
X_train, X_test, y_train, y_test = train_test_split(
    X_supervised, y, test_size=0.3, random_state=42, stratify=y
)

# C. Scaling Supervised Data: Re-scale the training and test sets
# Note: It is crucial to use the scaler fitted ONLY on the training data.
scaler_sup = StandardScaler()
X_train_scaled = scaler_sup.fit_transform(X_train)
X_test_scaled = scaler_sup.transform(X_test)


# D. Model Training (Classification)
classifier = LogisticRegression(random_state=42, solver='liblinear')
# Train the model using the hybrid feature set
classifier.fit(X_train_scaled, y_train)

# --- 5. Evaluation ---
y_pred = classifier.predict(X_test_scaled)

print("--- Supervised Phase Complete: Churn Prediction Results ---")
print("Classification Report (Hybrid Model):")
print(classification_report(y_test, y_pred, zero_division=0))
print("-" * 60)

# --- 6. Analysis Snippet: Feature Importance ---
# Analyze which features, including the engineered segments, drive the prediction
feature_names = X_supervised.columns
coefficients = pd.Series(classifier.coef_[0], index=feature_names).sort_values(ascending=False)

print("Top 5 Feature Coefficients (Impact on Churn Prediction):")
print(coefficients.head())

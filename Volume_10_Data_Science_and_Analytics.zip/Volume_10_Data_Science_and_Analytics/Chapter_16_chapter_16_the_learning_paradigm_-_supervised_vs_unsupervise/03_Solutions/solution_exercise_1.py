
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# Exercise 1: Supervised Classification Setup
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression # Suitable classification model

# 1. Data Simulation Function Definition
def create_customer_data(n_samples=500):
    np.random.seed(42)
    # Features
    Age = np.random.randint(20, 65, n_samples)
    Income = np.random.randint(30000, 150000, n_samples)
    Location_Score = np.random.uniform(0.1, 1.0, n_samples)
    Frequency_Score = np.random.randint(1, 10, n_samples)
    
    # Target (Enrolled): Higher income and frequency score increase enrollment probability
    # Create a base probability
    base_prob = (Income / 150000) * 0.4 + (Frequency_Score / 10) * 0.3 + 0.1
    Enrolled = (np.random.rand(n_samples) < base_prob).astype(int)
    
    data = pd.DataFrame({
        'Age': Age,
        'Income': Income,
        'Location_Score': Location_Score,
        'Frequency_Score': Frequency_Score,
        'Enrolled': Enrolled
    })
    return data

# 2. Data Preparation and Splitting
# Load data
df = create_customer_data()

# Define X (Features) and y (Target)
X = df[['Age', 'Income', 'Location_Score', 'Frequency_Score']]
y = df['Enrolled']

# Split data into training and testing sets (70% train, 30% test)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y
)

# 3. Model Instantiation
model = LogisticRegression(solver='liblinear', random_state=42)

# 4. Training Protocol
model.fit(X_train, y_train)

# Output verification
print(f"Shape of X_train: {X_train.shape}")
print(f"Model trained successfully: {model}")

# 5. Objective Justification Comment Block
# This task is Supervised Learning because the dataset includes a predefined, 
# labeled target variable ('Enrolled'). The goal is prediction (classification) 
# of this known outcome based on input features, requiring the model to learn 
# the mapping function f(X) -> y from the labeled training data.


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Exercise 2: Unsupervised Clustering and Evaluation
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.datasets import make_blobs # Helper for generating clustered data

# 1. Data Simulation Function Definition
def create_unlabeled_data(n_samples=800):
    np.random.seed(42)
    # Generate 3 features (Latitude, Longitude, Population_Density) 
    # and ensure they form 4 distinct clusters to make k determination meaningful.
    X, _ = make_blobs(
        n_samples=n_samples, 
        n_features=3, 
        centers=4, 
        cluster_std=1.5, 
        random_state=42
    )
    X_df = pd.DataFrame(X, columns=['Latitude', 'Longitude', 'Population_Density'])
    # Crucially, we return only the feature matrix X_df (unlabeled data)
    return X_df

# 2. Data Preparation
X = create_unlabeled_data()
print(f"Data shape (features only): {X.shape}")

# 4. Optimal k Determination (Elbow Method)
wcss = []
k_range = range(2, 11)

# Loop structure to calculate inertia for each k
for k in k_range:
    # 3. Clustering Implementation
    kmeans = KMeans(n_clusters=k, init='k-means++', n_init=10, random_state=42)
    kmeans.fit(X)
    # Inertia is the WCSS (Within-Cluster Sum of Squares)
    wcss.append(kmeans.inertia_)

# 5. Visualization Preparation Output
print("Inertia values for k=2 to 10 (WCSS):")
print(wcss)

# Objective Justification Comment Block
# This task is Unsupervised Learning because the data lacks a target variable 
# or labels. The objective is structural discovery—finding inherent groupings 
# (clusters) within the feature space (Latitude, Longitude, Density) without 
# prior examples of what those groupings should be.

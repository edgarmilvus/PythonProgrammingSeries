
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Exercise 3: Paradigm Shift (Supervised Regression to Unsupervised PCA)
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# 1. Data Simulation (10 features, 1 target variable - target is ignored later)
def create_regression_features(n_samples=1000):
    np.random.seed(42)
    # Create underlying factors for correlation
    factor1 = np.random.randn(n_samples)
    factor2 = np.random.randn(n_samples)
    
    # Generate 10 features, some highly correlated (e.g., F1, F2, F3 depend heavily on factor1)
    X = pd.DataFrame({
        f'F{i+1}': factor1 * (i % 3) + factor2 * (1 - (i % 3)) + np.random.randn(n_samples) * 0.5 
        for i in range(10)
    })
    
    # Placeholder target variable (crucially ignored in PCA step)
    Target_Score = 5 + 2 * X['F1'] - 0.5 * X['F10'] + np.random.randn(n_samples)
    X['Target_Score'] = Target_Score
    
    # Return only the 10 features for PCA
    return X.drop(columns=['Target_Score'])

X_original = create_regression_features()

# 2. Standardization
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_original)

# 3. Dimensionality Reduction Implementation
# Set n_components=3
pca = PCA(n_components=3)
X_pca = pca.fit_transform(X_scaled) # Fit and transform the standardized data

# 4. Analysis and Reporting
explained_variance = pca.explained_variance_ratio_
total_variance_retained = explained_variance.sum()

print("Original Feature Shape:", X_original.shape)
print("Reduced Feature Shape:", X_pca.shape)
print("\nExplained Variance Ratio per Component:")
for i, ratio in enumerate(explained_variance):
    print(f"PC {i+1}: {ratio:.4f}")
print(f"\nTotal Variance Retained by 3 Components: {total_variance_retained:.4f}")

# Conceptual Link Comment Block
# PCA is an Unsupervised technique because its objective is not prediction 
# (f(X) -> y) but rather structural transformation and simplification of the 
# input features (X -> X'). It operates solely on the input data matrix X, 
# ignoring any target label, to find underlying components that maximize variance.

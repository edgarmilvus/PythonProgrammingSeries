
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Exercise 4: Interactive Challenge - Paradigm Mapping

import pandas as pd
import numpy as np

# Scenario A: Loan Default Risk (Supervised Classification)
# Scenario B: Inventory Optimization (Unsupervised Clustering)
# Scenario C: Temperature Forecasting (Supervised Regression)

def simulate_data(scenario_id):
    """Generates synthetic data tailored to the required structure (labeled/unlabeled)."""
    np.random.seed(42)
    if scenario_id == 'A':
        # Simulate data for Scenario A (Requires a binary target variable)
        data = {
            'Credit_Score': np.random.randint(500, 850, 20),
            'Income': np.random.randint(40000, 150000, 20),
            # Target variable (0 or 1)
            'Defaulted': np.random.randint(0, 2, 20)
        }
        return pd.DataFrame(data)
    
    elif scenario_id == 'B':
        # Simulate data for Scenario B (Requires NO target variable)
        data = {
            'Movement_Velocity': np.random.rand(20) * 10,
            'Part_Size': np.random.rand(20) * 5,
            'Weight': np.random.rand(20) * 50,
        }
        return pd.DataFrame(data)

    elif scenario_id == 'C':
        # Simulate data for Scenario C (Requires a continuous float target variable)
        data = {
            'Pressure': np.random.uniform(980, 1030, 20),
            'Humidity': np.random.uniform(30, 90, 20),
            # Target variable (float)
            'Max_Temp_Tomorrow': np.random.uniform(15.0, 35.0, 20)
        }
        return pd.DataFrame(data)
    
    return pd.DataFrame()

def map_paradigm(scenario_id):
    """Maps the business objective to the correct learning paradigm and technique."""
    if scenario_id == 'A':
        return {
            'Paradigm': 'Supervised Learning',
            'Technique': 'Classification',
            'Target_Data_Type': 'Binary (0 or 1)'
        }
    elif scenario_id == 'B':
        return {
            'Paradigm': 'Unsupervised Learning',
            'Technique': 'Clustering',
            'Target_Data_Type': 'None (Objective is structural discovery)'
        }
    elif scenario_id == 'C':
        return {
            'Paradigm': 'Supervised Learning',
            'Technique': 'Regression',
            'Target_Data_Type': 'Continuous Float'
        }
    
# Verification Block (Execution and Output)
print("--- Scenario A Verification (Loan Default Risk) ---")
print("Data Structure (Requires Target):")
print(simulate_data('A').head(2))
print("\nConceptual Mapping:")
print(map_paradigm('A'))

print("\n--- Scenario B Verification (Inventory Optimization) ---")
print("Data Structure (Unlabeled):")
print(simulate_data('B').head(2))
print("\nConceptual Mapping:")
print(map_paradigm('B'))

print("\n--- Scenario C Verification (Temperature Forecasting) ---")
print("Data Structure (Requires Continuous Target):")
print(simulate_data('C').head(2))
print("\nConceptual Mapping:")
print(map_paradigm('C'))

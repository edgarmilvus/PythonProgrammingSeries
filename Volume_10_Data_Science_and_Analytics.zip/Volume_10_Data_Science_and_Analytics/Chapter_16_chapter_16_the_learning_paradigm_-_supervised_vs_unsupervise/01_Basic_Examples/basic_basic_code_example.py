
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np
from sklearn.datasets import make_blobs
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.metrics import accuracy_score, adjusted_rand_score

# ----------------------------------------------------------------------
# 1. Data Generation: Creating a synthetic dataset with inherent structure
# ----------------------------------------------------------------------
# X: Features (e.g., Customer Age, Income)
# y_true: True Labels (e.g., Did they buy the product? 0 or 1)
N_SAMPLES = 300
N_FEATURES = 2
N_CLUSTERS = 3

X, y_true = make_blobs(
    n_samples=N_SAMPLES,
    n_features=N_FEATURES,
    centers=N_CLUSTERS,
    cluster_std=1.0,
    random_state=42
)

# ----------------------------------------------------------------------
# 2. Supervised Learning Paradigm (Classification)
# Objective: Predict the true label (y_true) based on the features (X).
# ----------------------------------------------------------------------

print("--- Starting Supervised Learning (K-Nearest Neighbors) ---")

# Split the data into training and testing sets (essential for Supervised)
X_train, X_test, y_train, y_test = train_test_split(
    X, y_true, test_size=0.3, random_state=42
)

# Initialize the Supervised Model (KNeighborsClassifier)
# The model is initialized knowing it must map X to y.
supervised_model = KNeighborsClassifier(n_neighbors=5)

# Training Phase: The model learns the relationship between X_train and y_train.
supervised_model.fit(X_train, y_train)

# Prediction Phase: Predict labels for the unseen test data.
y_pred_supervised = supervised_model.predict(X_test)

# Evaluation: Assess how well the model predicted the known labels.
accuracy = accuracy_score(y_test, y_pred_supervised)
print(f"Supervised Model Accuracy: {accuracy:.4f}")
print("----------------------------------------------------------\n")


# ----------------------------------------------------------------------
# 3. Unsupervised Learning Paradigm (Clustering)
# Objective: Discover inherent groups/clusters in X, ignoring y_true.
# ----------------------------------------------------------------------

print("--- Starting Unsupervised Learning (K-Means Clustering) ---")

# Data preparation: We use the entire feature set X, but intentionally
# discard the true labels (y_true) during the training phase.
X_unsupervised = X  # Features only

# Initialize the Unsupervised Model (KMeans)
# We tell KMeans to look for 3 clusters, but it receives no guidance.
unsupervised_model = KMeans(n_clusters=N_CLUSTERS, random_state=42, n_init='auto')

# Training Phase: The model finds patterns and groups in X_unsupervised.
# Note: The model is trained on X alone.
unsupervised_model.fit(X_unsupervised)

# Assignment Phase: Get the cluster labels assigned by the model.
cluster_labels = unsupervised_model.labels_

# Evaluation: Compare the discovered clusters to the original (hidden) true labels.
# NOTE: We use a special metric (Adjusted Rand Index) because cluster labels
# (0, 1, 2) are arbitrary and don't necessarily match the true labels (0, 1, 2).
ari_score = adjusted_rand_score(y_true, cluster_labels)
print(f"Unsupervised Model ARI Score: {ari_score:.4f}")
print(f"First 10 True Labels: {y_true[:10]}")
print(f"First 10 Cluster Labels: {cluster_labels[:10]}")
print("----------------------------------------------------------")

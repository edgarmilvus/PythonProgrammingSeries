
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# Exercise 5: Interactive Challenge - Conditional Grouping and Asymmetric Aggregation

# Step 1: Identify HVRs (Sales_Rep with > 50 transactions)
rep_counts = sales_data.groupby('Sales_Rep')['Transaction_ID'].count()
hvr_list = rep_counts[rep_counts > 50].index.tolist()

# Step 2: Filter sales_data to include only HVR transactions
hvr_sales_data = sales_data[sales_data['Sales_Rep'].isin(hvr_list)]

# Step 3: Perform asymmetric aggregation on the filtered data
hvr_performance_summary = hvr_sales_data.groupby(['Region', 'Product_Category']).agg(
    Average_Units_Sold=('Units_Sold', 'mean'), # Efficiency metric
    Total_Revenue=('Revenue', 'sum')
).reset_index()

# Step 4: Pivot the result to show average Units_Sold (efficiency)
hvr_efficiency_pivot = hvr_performance_summary.pivot_table(
    index='Region',
    columns='Product_Category',
    values='Average_Units_Sold',
    fill_value=0
).round(2)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import pandas as pd
import numpy as np

# Set random seed for reproducibility
np.random.seed(42)

N = 5500 # Number of rows

# Define categories
regions = ['North America', 'Europe', 'Asia']
products = ['Laptops', 'Smartphones', 'Peripherals', 'Software']
sales_reps = [f'SR{i:03d}' for i in range(1, 11)]
months = ['January', 'February', 'March']

# Generate data
data = {
    'Transaction_ID': np.arange(10000, 10000 + N),
    'Region': np.random.choice(regions, N),
    'Product_Category': np.random.choice(products, N, p=[0.25, 0.35, 0.20, 0.20]),
    'Sales_Rep': np.random.choice(sales_reps, N),
    'Units_Sold': np.random.randint(1, 51, N),
    'Customer_Rating': np.random.randint(1, 6, N),
    'Month': np.random.choice(months, N)
}

sales_data = pd.DataFrame(data)

# Calculate Revenue realistically
price_map = {'Laptops': 2500, 'Smartphones': 800, 'Peripherals': 150, 'Software': 400}
sales_data['Base_Price'] = sales_data['Product_Category'].map(price_map)
sales_data['Raw_Revenue'] = sales_data['Base_Price'] * sales_data['Units_Sold']
noise = np.random.uniform(0.9, 1.1, N)
sales_data['Revenue'] = (sales_data['Raw_Revenue'] * noise).round(2)
sales_data['Revenue'] = np.clip(sales_data['Revenue'], 100.00, 50000.00)
sales_data = sales_data.drop(columns=['Base_Price', 'Raw_Revenue'])
for col in ['Region', 'Product_Category', 'Sales_Rep', 'Month']:
    sales_data[col] = sales_data[col].astype('category')

# Exercise 1: Core Aggregation and Multi-Column Summaries

# Perform the grouping and aggregation using named aggregation
category_summary = sales_data.groupby('Product_Category').agg(
    Total_Volume=('Units_Sold', 'sum'),
    Average_Transaction_Value=('Revenue', 'mean'),
    Unique_Reps_Involved=('Sales_Rep', 'nunique')
)

# Optional: Format the average transaction value
category_summary['Average_Transaction_Value'] = category_summary['Average_Transaction_Value'].round(2)

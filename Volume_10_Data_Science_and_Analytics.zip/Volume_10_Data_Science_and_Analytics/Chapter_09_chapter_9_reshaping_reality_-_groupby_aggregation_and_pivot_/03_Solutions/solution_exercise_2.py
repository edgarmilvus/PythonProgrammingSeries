
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Exercise 2: Multi-Level Grouping and Advanced Custom Metrics

# 1. Multi-level grouping and aggregation
regional_monthly_scorecard = sales_data.groupby(['Region', 'Month']).agg(
    Total_Monthly_Revenue=('Revenue', 'sum'),
    Transaction_Count=('Transaction_ID', 'size'), # Using size to count transactions
    Max_Single_Sale=('Revenue', 'max')
).reset_index() # Convert Region and Month from index to columns

# 2. Sorting: Region (A-Z), Total Revenue (High-Low)
regional_monthly_scorecard = regional_monthly_scorecard.sort_values(
    by=['Region', 'Total_Monthly_Revenue'],
    ascending=[True, False]
)

# Optional: Format revenue columns
regional_monthly_scorecard['Total_Monthly_Revenue'] = regional_monthly_scorecard['Total_Monthly_Revenue'].round(2)
regional_monthly_scorecard['Max_Single_Sale'] = regional_monthly_scorecard['Max_Single_Sale'].round(2)

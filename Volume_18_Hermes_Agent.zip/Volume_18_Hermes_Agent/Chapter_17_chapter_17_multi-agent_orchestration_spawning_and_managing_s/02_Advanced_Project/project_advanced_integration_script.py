
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script.py
# Description: Advanced Integration Script
# ==========================================

#!/usr/bin/env python3
"""
Project Codebase Analyzer – Multi‑Agent Orchestration with Hermes Agent.

This script demonstrates spawning and managing sub‑agents to analyze a
codebase in parallel. The coordinator agent delegates tasks to specialized
sub‑agents, collects their results, and produces a consolidated report.

Requires: Python 3.11+, Hermes Agent installed (run_agent.py), asyncio.
"""

import asyncio
import contextvars
import json
import logging
import os
import sys
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional

# Critical import: the main Hermes Agent class
from run_agent import AIAgent

# Hermes utilities for memory and context management
from agent.memory_manager import build_memory_context_block, sanitize_context
from agent.context_compressor import ContextCompressor
from hermes_constants import get_hermes_home

# Configure logging for the coordinator and sub‑agents
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger("ProjectAnalyzer")

# ------------------------------------------------------------------
# Global task‑specific context variable – used to share the project ID
# across sub‑agent tasks without passing it as a parameter.
# ------------------------------------------------------------------
_project_ctx = contextvars.ContextVar("project_id", default=None)


class ProjectAnalysisCoordinator:
    """
    Orchestrates the multi‑agent analysis of a codebase directory.

    This class encapsulates the parent agent (the coordinator itself) and
    manages a set of sub‑agents that run concurrently using asyncio.TaskGroup.
    It demonstrates:
        - Spawning sub‑agents with independent iteration budgets.
        - Using persistent memory to store sub‑agent states.
        - Aggregating sub‑agent results into a final report.
    """

    # ------------------------------------------------------------------
    # Configuration constants – these could be loaded from a YAML config
    # in a production setting.
    # ------------------------------------------------------------------
    SUB_AGENT_NAMES = [
        "code_analyzer",
        "security_scanner",
        "doc_auditor",
        "dependency_mapper",
    ]

    # Each sub‑agent gets its own tool set (mimicked via enabled_toolsets)
    SUB_AGENT_TOOLSETS = {
        "code_analyzer": ["terminal", "read_file", "search_files"],
        "security_scanner": ["terminal", "web_search", "vision_analyze"],
        "doc_auditor": ["read_file", "web_extract", "session_search"],
        "dependency_mapper": ["terminal", "read_file", "skill_view"],
    }

    # Paths for persistent storage
    MEMORY_FILE_NAME = "project_analysis_memory.json"

    def __init__(
        self,
        project_path: str,
        base_url: str = "http://localhost:30000/v1",
        model: str = "claude-opus-4-20250514",
        api_key: Optional[str] = None,
        coordinator_max_iterations: int = 100,
        sub_agent_max_iterations: int = 50,
        persistent_mem_dir: Optional[str] = None,
    ):
        """
        Initialize the coordinator.

        Args:
            project_path: Root directory of the codebase to analyze.
            base_url: AI provider endpoint.
            model: Model identifier for all agents.
            api_key: Optional API key.
            coordinator_max_iterations: Max tool‑calling turns for the coordinator.
            sub_agent_max_iterations: Max tool‑calling turns for each sub‑agent.
            persistent_mem_dir: Directory to store sub‑agent memory files.
        """
        self.project_path = Path(project_path).resolve()
        self.base_url = base_url
        self.model = model
        self.api_key = api_key
        self.coordinator_max_iterations = coordinator_max_iterations
        self.sub_agent_max_iterations = sub_agent_max_iterations

        # Hermes home is used as default persistent storage root
        hermes_home = get_hermes_home()
        self.mem_dir = Path(persistent_mem_dir or hermes_home / "project_memory")
        self.mem_dir.mkdir(parents=True, exist_ok=True)

        # This will hold the spawned sub‑agent futures and their results
        self._sub_agent_tasks: Dict[str, asyncio.Task] = {}
        self._results: Dict[str, Any] = {}
        self._errors: Dict[str, str] = {}

        # Create the coordinator agent – it will be the "parent" that
        # receives sub‑agent reports and produces the final synthesis.
        self.coordinator_agent = AIAgent(
            base_url=self.base_url,
            model=self.model,
            api_key=self.api_key,
            # The coordinator should be able to call a broader set of tools,
            # including those for merging and summarizing.
            enabled_toolsets=["terminal", "read_file", "write_file", "web_search"],
            # Generous iteration budget for the parent
            max_iterations=self.coordinator_max_iterations,
            # Enable trajectory saving for debugging
            save_trajectories=True,
        )

        logger.info(
            "Coordinator initialized for project %s with %d sub‑agents.",
            self.project_path,
            len(self.SUB_AGENT_NAMES),
        )

    # ------------------------------------------------------------------
    # Helper: Build a unique memory file for each sub‑agent.
    # This ensures state isolation between sub‑agents and allows resumption.
    # ------------------------------------------------------------------
    def _sub_agent_memory_path(self, sub_name: str) -> Path:
        """Return the persistent memory file path for a given sub‑agent."""
        return self.mem_dir / f"sub_agent_{sub_name}.json"

    def _persist_sub_agent_state(self, sub_name: str, state: Dict[str, Any]) -> None:
        """Write sub‑agent state to disk for later restoration."""
        path = self._sub_agent_memory_path(sub_name)
        with open(path, "w") as f:
            json.dump(state, f, indent=2, default=str)
        logger.debug("Persisted state for %s to %s", sub_name, path)

    def _load_sub_agent_state(self, sub_name: str) -> Optional[Dict[str, Any]]:
        """Load previously stored sub‑agent state, if any."""
        path = self._sub_agent_memory_path(sub_name)
        if path.exists():
            with open(path) as f:
                return json.load(f)
        return None

    # ------------------------------------------------------------------
    # Core orchestration method: spawn all sub‑agents concurrently.
    # ------------------------------------------------------------------
    async def run_analysis(self) -> Dict[str, Any]:
        """
        Main entry point – runs the full multi‑agent analysis.

        Steps:
            1. Set the project path into the context variable for all tasks.
            2. Launch sub‑agents concurrently using asyncio.TaskGroup.
            3. Wait for all sub‑agents to complete (guard against timeouts).
            4. Collect results and errors.
            5. Use the coordinator agent to produce a final report.
            6. Persist the aggregated memory.
        """
        # Set the project ID as a context variable – all sub‑agents
        # inherited from this async context will see it.
        _project_ctx.set(str(self.project_path))

        logger.info("Starting multi‑agent analysis for %s", self.project_path)

        # ------------------------------------------------------------------
        # Use asyncio.TaskGroup (Python 3.11+) for structured concurrency.
        # This guarantees that if one sub‑agent task fails, all others are
        # cancelled and the exception is propagated.
        # ------------------------------------------------------------------
        async with asyncio.TaskGroup() as tg:
            for sub_name in self.SUB_AGENT_NAMES:
                task = tg.create_task(
                    self._run_single_sub_agent(sub_name),
                    name=sub_name,
                )
                self._sub_agent_tasks[sub_name] = task

        # After TaskGroup exits, all tasks have completed (or raised).
        # Collect results.
        for sub_name, task in self._sub_agent_tasks.items():
            try:
                result = task.result()
                self._results[sub_name] = result
                logger.info("Sub‑agent '%s' completed successfully.", sub_name)
            except Exception as e:
                self._errors[sub_name] = str(e)
                logger.error(
                    "Sub‑agent '%s' failed: %s", sub_name, e, exc_info=True
                )

        # ------------------------------------------------------------------
        # Now produce the final aggregated report using the coordinator agent.
        # ------------------------------------------------------------------
        final_report = await self._synthesize_report()

        # Persist the complete analysis memory for later queries.
        self._persist_aggregated_memory(final_report)

        return final_report

    # ------------------------------------------------------------------
    # Sub‑agent runner – instantiate an AIAgent with a specific role,
    # execute its analysis, and return structured results.
    # ------------------------------------------------------------------
    async def _run_single_sub_agent(self, sub_name: str) -> Dict[str, Any]:
        """
        Run a single sub‑agent with its own AIAgent instance.

        This method:
            - Creates a new AIAgent configured for the sub‑agent's role.
            - Loads any previously saved state for resumption.
            - Constructs a role‑specific system prompt.
            - Executes the conversation loop with a bounded iteration budget.
            - Persists the final state.
        """
        logger.info("Sub‑agent '%s' starting.", sub_name)

        # Retrieve the toolset for this sub‑agent
        enabled_tools = self.SUB_AGENT_TOOLSETS.get(sub_name, ["read_file"])

        # Create a dedicated AIAgent instance for this sub‑agent.
        # Note: each sub‑agent gets its own iteration budget (max_iterations).
        sub_agent = AIAgent(
            base_url=self.base_url,
            model=self.model,
            api_key=self.api_key,
            enabled_toolsets=enabled_tools,
            # Sub‑agents have a smaller budget than the parent
            max_iterations=self.sub_agent_max_iterations,
            # Quiet mode reduces log noise in a multi‑agent scenario
            quiet_mode=True,
            # Each sub‑agent can have a unique log prefix for debugging
            log_prefix=f"[{sub_name}] ",
        )

        # Build a context block from persistent memory, if any.
        previous_state = self._load_sub_agent_state(sub_name)
        resume_hint = ""
        if previous_state:
            resume_hint = (
                "You previously analyzed a portion of this project. "
                "Here is a summary of what you have already done:\n"
                + json.dumps(previous_state.get("summary", ""), indent=2)
            )

        # Role‑specific system prompt
        role_prompt = self._build_sub_agent_prompt(sub_name, resume_hint)

        # The user message contains the project path and a clear task.
        user_message = (
            f"Analyze the project at {self.project_path}. "
            f"Focus on: {role_prompt}. "
            "Produce a structured JSON report with findings, severity, and "
            "recommendations. Save the report to a file named "
            f"/tmp/{sub_name}_report.json once finished."
        )

        # ------------------------------------------------------------------
        # Execute the sub‑agent conversation – this is the core AI loop.
        # AIAgent.run_conversation returns the final assistant message.
        # ------------------------------------------------------------------
        final_response = await sub_agent.run_conversation(user_message)

        # After the conversation ends, read the report file that the sub‑agent
        # should have created. If not found, fall back to the response text.
        report_path = Path(f"/tmp/{sub_name}_report.json")
        if report_path.exists():
            with open(report_path) as f:
                result = json.load(f)
        else:
            # Assume the response text is the report
            result = {
                "role": sub_name,
                "raw_response": final_response,
                "note": "No structured file was produced; parsed from conversation.",
            }

        # Persist the sub‑agent's state for future resumption.
        state = {
            "summary": result,
            "timestamp": datetime.utcnow().isoformat(),
        }
        self._persist_sub_agent_state(sub_name, state)

        logger.info("Sub‑agent '%s' finished.", sub_name)
        return result

    # ------------------------------------------------------------------
    # Build a role‑specific prompt for each sub‑agent.
    # ------------------------------------------------------------------
    @staticmethod
    def _build_sub_agent_prompt(sub_name: str, resume_hint: str) -> str:
        """Return the analysis focus for the given sub‑agent."""
        prompts = {
            "code_analyzer": (
                "Scan all source code for code smells, anti‑patterns, "
                "overly complex functions, duplicated logic, and "
                "lack of type hints. Assess cyclomatic complexity."
            ),
            "security_scanner": (
                "Identify common vulnerabilities: SQL injection, XSS, "
                "hardcoded secrets, unsafe deserialization, outdated "
                "dependencies. Check for proper input validation."
            ),
            "doc_auditor": (
                "Evaluate documentation quality: are there README files, "
                "inline comments, API docs? Is the doc up‑to‑date with "
                "the code? Suggest improvements."
            ),
            "dependency_mapper": (
                "Map all external dependencies, their versions, and "
                "licenses. Detect circular dependencies, unused imports, "
                "and version conflicts. Suggest a dependency tree."
            ),
        }
        base = prompts.get(sub_name, "General project analysis.")
        if resume_hint:
            base += f"\n\n{resume_hint}"
        return base

    # ------------------------------------------------------------------
    # Use the coordinator agent to merge sub‑agent reports into a
    # single, coherent analysis.
    # ------------------------------------------------------------------
    async def _synthesize_report(self) -> Dict[str, Any]:
        """Aggregate all sub‑agent results via the coordinator agent."""
        # Build a detailed input for the coordinator.
        synthesis_input = {
            "project": str(self.project_path),
            "sub_agent_reports": self._results,
            "errors": self._errors,
        }

        user_message = (
            "I have collected reports from four specialized analysts. "
            "Please synthesize them into a single comprehensive analysis "
            "with an executive summary, prioritized action items, and "
            "a final verdict (refactor / containerize / rewrite / keep). "
            "Save the final report to /tmp/final_analysis.json.\n\n"
            f"Input data:\n{json.dumps(synthesis_input, indent=2)}"
        )

        # The coordinator agent already has a large iteration budget.
        final_response = await self.coordinator_agent.run_conversation(
            user_message
        )

        # Read the saved file if it exists, else use the response.
        final_path = Path("/tmp/final_analysis.json")
        if final_path.exists():
            with open(final_path) as f:
                report = json.load(f)
        else:
            report = {
                "synthesis": final_response,
                "note": "Fallback – no structured file produced.",
            }

        return report

    # ------------------------------------------------------------------
    # Persist the final aggregated analysis to the Hermes memory area.
    # ------------------------------------------------------------------
    def _persist_aggregated_memory(self, report: Dict[str, Any]) -> None:
        """Write the full analysis memory to a JSON file."""
        memory = {
            "project": str(self.project_path),
            "timestamp": datetime.utcnow().isoformat(),
            "sub_agent_results": self._results,
            "sub_agent_errors": self._errors,
            "final_report": report,
        }
        memory_path = self.mem_dir / self.MEMORY_FILE_NAME
        with open(memory_path, "w") as f:
            json.dump(memory, f, indent=2, default=str)
        logger.info("Analysis memory persisted to %s", memory_path)

    # ------------------------------------------------------------------
    # Helper: Load a previously saved project analysis to resume work.
    # ------------------------------------------------------------------
    def load_persisted_analysis(self) -> Optional[Dict[str, Any]]:
        """Load stored analysis from disk."""
        memory_path = self.mem_dir / self.MEMORY_FILE_NAME
        if memory_path.exists():
            with open(memory_path) as f:
                return json.load(f)
        return None


# ------------------------------------------------------------------
# Main entry point – runs the multi‑agent analysis interactively.
# ------------------------------------------------------------------
async def main():
    """Parse arguments and run the analysis coordinator."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Multi‑agent codebase analyzer using Hermes Agent."
    )
    parser.add_argument(
        "project_path",
        help="Path to the project directory to analyze.",
    )
    parser.add_argument(
        "--base-url",
        default="http://localhost:30000/v1",
        help="AI provider base URL.",
    )
    parser.add_argument(
        "--model",
        default="claude-opus-4-20250514",
        help="Model name for all agents.",
    )
    parser.add_argument(
        "--coordinator-iterations",
        type=int,
        default=100,
        help="Max tool calls for the coordinator agent.",
    )
    parser.add_argument(
        "--sub-iterations",
        type=int,
        default=50,
        help="Max tool calls per sub‑agent.",
    )
    parser.add_argument(
        "--resume",
        action="store_true",
        help="If set, load previous memory and skip completed sub‑agents.",
    )
    args = parser.parse_args()

    coordinator = ProjectAnalysisCoordinator(
        project_path=args.project_path,
        base_url=args.base_url,
        model=args.model,
        coordinator_max_iterations=args.coordinator_iterations,
        sub_agent_max_iterations=args.sub_iterations,
    )

    if args.resume:
        # Attempt to load previous state and skip already analyzed parts.
        previous = coordinator.load_persisted_analysis()
        if previous:
            logger.info("Found previous analysis – resuming where we left off.")
            # In a real implementation, we would check which sub‑agents
            # have completed and skip them. For brevity, we just re‑run.
            # The state files (sub_agent_*.json) would be used to restore
            # context.
        else:
            logger.info("No previous state to resume – starting fresh.")

    try:
        final_report = await coordinator.run_analysis()
        print(
            "\n\n=== Multi‑Agent Analysis Complete ===\n"
            f"Final report saved to /tmp/final_analysis.json\n"
            f"Sub‑agent results:\n"
            f"  Code Analyzer:   {'✓' if 'code_analyzer' in coordinator._results else '✗'}\n"
            f"  Security Scanner:{'✓' if 'security_scanner' in coordinator._results else '✗'}\n"
            f"  Doc Auditor:     {'✓' if 'doc_auditor' in coordinator._results else '✗'}\n"
            f"  Dependency Map:  {'✓' if 'dependency_mapper' in coordinator._results else '✗'}\n"
            f"Errors: {len(coordinator._errors)}"
        )
    except Exception as e:
        logger.critical("Analysis failed catastrophically: %s", e, exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_7.py
# Description: Solution for Exercise 7
# ==========================================

import unittest
import json
from unittest.mock import Mock, patch
from agent.subagent_lifecycle import SubAgentLifecycleManager

class TestSubAgentLifecycleManager(unittest.TestCase):

    def test_resume_after_crash(self):
        # Create a mock SessionDB
        db = Mock()
        db.store = Mock()
        db.retrieve = Mock()

        # Simulate a crash: pre‑populate DB with a pending sub‑agent
        subagent_id = "test_analyzer"
        config = {
            "task": "Analyze the file 'README.md'",
            "enabled_toolsets": ["file"],
            "disabled_toolsets": ["terminal"],
            "max_iterations": 10,
            "session_id": "some-uuid",
            "base_url": "http://localhost:8000",
            "model": "gpt-4o-mini",
            "system_prompt": "You are an analyst."
        }

        def retrieve_side_effect(key):
            if key == "subagent_ids":
                return json.dumps([subagent_id])
            elif key == f"subagent:{subagent_id}:state":
                return "pending"
            elif key == f"subagent:{subagent_id}:config":
                return json.dumps(config)
            else:
                return None

        db.retrieve.side_effect = retrieve_side_effect

        # Create a mock agent factory that returns a mock AIAgent
        mock_agent = Mock()
        mock_agent.run_conversation.return_value = [
            {"role": "assistant", "content": "Here are the functions: ..."}
        ]
        factory = Mock(return_value=mock_agent)

        manager = SubAgentLifecycleManager(session_db=db, agent_factory=factory)

        # Call resume – it should spawn the agent and mark complete
        resumed = manager.resume_pending_subagents()
        self.assertIn(subagent_id, resumed)

        # Verify that store was called to mark completed and store result
        store_calls = db.store.call_args_list
        state_update_calls = [
            call for call in store_calls
            if call[0][0] == f"subagent:{subagent_id}:state"
        ]
        self.assertTrue(any("completed" in str(call) for call in state_update_calls))

    def test_begin_and_complete(self):
        db = Mock()
        db.store = Mock()
        db.retrieve = Mock(return_value=json.dumps([]))  # empty registry initially
        factory = Mock()
        manager = SubAgentLifecycleManager(session_db=db, agent_factory=factory)

        session_id = manager.begin_subagent("analyzer1", {"task": "test"})
        self.assertTrue(session_id is not None)

        manager.complete_subagent("analyzer1", "All good")
        # Verify state stored as "completed"
        db.store.assert_any_call(f"subagent:analyzer1:state", "completed")

if __name__ == "__main__":
    unittest.main()

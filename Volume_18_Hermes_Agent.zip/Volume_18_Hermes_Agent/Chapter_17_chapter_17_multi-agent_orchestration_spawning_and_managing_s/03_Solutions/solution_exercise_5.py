
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import unittest
from skill_inheritance import Skill, resolve_skill_hierarchy

class TestSkillInheritance(unittest.TestCase):

    def test_no_child_overrides(self):
        parent_skills = [
            Skill(name="MEMORY_GUIDANCE", description="Access long-term memory.", priority=5),
            Skill(name="SKILLS_GUIDANCE", description="List available skills.", priority=10)
        ]
        result = resolve_skill_hierarchy(parent_skills, [])
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0].name, "SKILLS_GUIDANCE")
        self.assertEqual(result[1].name, "MEMORY_GUIDANCE")
        # Descriptions unchanged
        self.assertEqual(result[1].description, "Access long-term memory.")

    def test_child_overrides_same_name(self):
        parent_skills = [
            Skill(name="MEMORY_GUIDANCE", description="Access long-term memory.", priority=5),
            Skill(name="SKILLS_GUIDANCE", description="List available skills.", priority=10)
        ]
        child_overrides = [
            Skill(name="MEMORY_GUIDANCE", description="Enhanced memory with summarization.", priority=7)
        ]
        result = resolve_skill_hierarchy(parent_skills, child_overrides, strategy="child_wins")
        # Two skills: SKILLS_GUIDANCE unchanged, MEMORY_GUIDANCE replaced
        self.assertEqual(len(result), 2)
        mem = [s for s in result if s.name == "MEMORY_GUIDANCE"][0]
        self.assertEqual(mem.description, "Enhanced memory with summarization.")
        self.assertEqual(mem.priority, 7)
        sk = [s for s in result if s.name == "SKILLS_GUIDANCE"][0]
        self.assertEqual(sk.description, "List available skills.")
        self.assertEqual(sk.priority, 10)

    def test_subsuming_override(self):
        parent_skills = [
            Skill(name="pip", description="Python package installer.", priority=5),
            Skill(name="poetry", description="Python dependency manager.", priority=6),
            Skill(name="git", description="Version control.", priority=4)
        ]
        child_overrides = [
            Skill(
                name="python_package_management",
                description="Unified package management for Python.",
                priority=10,
                overrides=["pip", "poetry"]
            )
        ]
        result = resolve_skill_hierarchy(parent_skills, child_overrides, strategy="child_wins")
        # Should have two skills: python_package_management and git (not subsumed)
        names = {s.name for s in result}
        self.assertIn("python_package_management", names)
        self.assertIn("git", names)
        self.assertNotIn("pip", names)
        self.assertNotIn("poetry", names)
        # python_package_management should have highest priority
        self.assertEqual(result[0].name, "python_package_management")

if __name__ == "__main__":
    unittest.main()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import uuid
import json
import logging
from typing import List, Dict, Any
from pathlib import Path
from run_agent import AIAgent
from agent.session_db import SessionDB

logger = logging.getLogger(__name__)

def supervise_chapters(
    chapter_dir: str,
    base_url: str,
    model: str,
    max_subagents: int = 5
) -> str:
    """
    Supervisor that analyzes markdown chapters sequentially, stores results
    in persistent memory, and returns a combined markdown report.

    Args:
        chapter_dir: Directory containing chapter files.
        base_url, model: Model endpoint parameters.
        max_subagents: Maximum number of chapters to process.

    Returns:
        Aggregated markdown report of all chapter summaries.
    """
    # Define chapter files (assuming they are named chapter_1.md, chapter_2.md, …)
    chapter_paths = sorted(Path(chapter_dir).glob("chapter_*.md"))
    chapter_paths = chapter_paths[:max_subagents]

    if not chapter_paths:
        raise FileNotFoundError(f"No chapter files found in {chapter_dir}")

    # Create a session DB for the supervisor (using a fixed ID for persistence)
    supervisor_session_id = "supervisor_session"
    session_db = SessionDB(session_id=supervisor_session_id)

    # Initialize states list
    subagent_states: List[Dict[str, Any]] = []

    for i, ch_path in enumerate(chapter_paths, start=1):
        chapter_num = i
        subagent_id = f"chapter_{chapter_num}"
        session_id = str(uuid.uuid4())
        state_entry = {
            "subagent_id": subagent_id,
            "session_id": session_id,
            "state": "pending"
        }
        subagent_states.append(state_entry)
        session_db.store("subagent_states", subagent_states)
        logger.info(f"Starting sub‑agent for {ch_path.name}")

        try:
            # Build a tailored system prompt
            system_prompt = (
                f"You are analyzing the chapter file '{ch_path.name}'. "
                f"Read the file, then produce:\n"
                f"1. A summary of the chapter (2‑3 sentences).\n"
                f"2. A list of characters mentioned.\n"
                f"3. A sentiment score (positive/negative/neutral).\n"
                f"Return your answer in markdown."
            )

            sub_agent = AIAgent(
                base_url=base_url,
                model=model,
                max_iterations=15,
                enabled_toolsets=["file", "web_search"],
                disabled_toolsets=["terminal", "browser"],
                session_id=session_id,
                system_prompt=system_prompt
            )

            # Update state to running
            state_entry["state"] = "running"
            session_db.store("subagent_states", subagent_states)

            messages = sub_agent.run_conversation(
                task=f"Analyze {ch_path.name} as described.",
                temperature=0.0
            )

            # Extract final answer (truncated to 2000 characters)
            final_answer = ""
            for msg in reversed(messages):
                if msg.get("role") == "assistant" and "tool_calls" not in msg:
                    content = msg.get("content", "")
                    # Intelligent truncation: cut at last space or newline before 2000
                    if len(content) > 2000:
                        cut = content.rfind(" ", 0, 2000)
                        if cut == -1:
                            cut = 2000
                        content = content[:cut] + "\n... (truncated)"
                    final_answer = content
                    break

            # Store the result in persistent memory
            key = f"summary_chapter_{chapter_num}"
            session_db.store(key, final_answer)

            state_entry["state"] = "completed"
            subagent_states.append(state_entry)
            session_db.store("subagent_states", subagent_states)

        except Exception as e:
            logger.error(f"Sub‑agent for {ch_path.name} failed: {str(e)}")
            state_entry["state"] = "failed"
            # Store the error string
            session_db.store(f"summary_chapter_{chapter_num}", f"FAILED: {str(e)}")
            # Continue with next chapter
            subagent_states[-1] = state_entry
            session_db.store("subagent_states", subagent_states)

    # Aggregate all results into a single markdown report
    report_lines = ["# Chapter Analysis Report\n"]
    for i in range(1, len(chapter_paths) + 1):
        key = f"summary_chapter_{i}"
        result = session_db.retrieve(key)
        if result:
            report_lines.append(f"## Chapter {i}\n")
            report_lines.append(result)
            report_lines.append("\n---\n")
        else:
            report_lines.append(f"## Chapter {i}\nNo result available.\n\n---\n")

    final_report = "\n".join(report_lines)
    print(final_report)
    return final_report


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Optional

@dataclass(frozen=True)
class Skill:
    name: str
    description: str
    priority: int = 0
    overrides: List[str] = field(default_factory=list)  # names of skills this skill subsumes

@dataclass
class SkillInheritanceConfig:
    parent_skills: List[Skill]
    child_overrides: List[Skill]
    conflict_strategy: str = "child_wins"  # "child_wins" or "merge"

def resolve_skill_hierarchy(
    parent_skills: List[Skill],
    child_overrides: List[Skill],
    strategy: str = "child_wins"
) -> List[Skill]:
    """
    Merge parent and child skills according to the given strategy.

    - No child overrides → exact copy of parent skills.
    - Child overrides a skill with same name → child's description and priority used.
    - Child subsumes parent skills via 'overrides' list → those parent skills are removed.
    """
    # Create lookup by name for child skills
    child_skills_by_name: Dict[str, Skill] = {s.name: s for s in child_overrides}

    # Start with a copy of parent skills
    resolved: List[Skill] = list(parent_skills)

    if not child_overrides:
        return resolved

    # Process child overrides in priority order (higher priority first)
    sorted_child = sorted(child_overrides, key=lambda s: -s.priority)

    for child_skill in sorted_child:
        # Check if this child skill subsumes any existing skill (including parent or other child)
        names_to_remove = set()
        for parent_skill in resolved:
            if parent_skill.name in child_skill.overrides:
                names_to_remove.add(parent_skill.name)

        # Remove subsumed skills
        resolved = [s for s in resolved if s.name not in names_to_remove]

        # Check if a skill with the same name already exists
        existing = next((s for s in resolved if s.name == child_skill.name), None)
        if existing:
            # Resolve conflict based on strategy
            if strategy == "child_wins":
                # Replace with child's version (description and priority)
                resolved = [s for s in resolved if s.name != child_skill.name]
                resolved.append(child_skill)
            elif strategy == "merge":
                # Merge descriptions (append), use higher priority
                merged_description = existing.description + "\n" + child_skill.description
                merged_priority = max(existing.priority, child_skill.priority)
                merged_skill = Skill(
                    name=child_skill.name,
                    description=merged_description,
                    priority=merged_priority,
                    overrides=list(set(existing.overrides + child_skill.overrides))
                )
                resolved = [s for s in resolved if s.name != child_skill.name]
                resolved.append(merged_skill)
            else:
                raise ValueError(f"Unknown conflict_strategy: {strategy}")
        else:
            # New skill from child
            resolved.append(child_skill)

    # Sort by priority descending, then by name for stable output
    resolved.sort(key=lambda s: (-s.priority, s.name))
    return resolved

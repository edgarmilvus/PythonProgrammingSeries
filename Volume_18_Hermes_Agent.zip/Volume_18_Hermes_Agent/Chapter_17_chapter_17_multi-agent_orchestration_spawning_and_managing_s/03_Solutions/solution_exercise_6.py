
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_6.py
# Description: Solution for Exercise 6
# ==========================================

from __future__ import annotations
import uuid
import json
import logging
from datetime import datetime
from typing import Dict, Any, List, Callable, Optional
from agent.session_db import SessionDB
from run_agent import AIAgent

logger = logging.getLogger(__name__)

class SubAgentLifecycleManager:
    def __init__(
        self,
        session_db: SessionDB,
        agent_factory: Callable[..., AIAgent]
    ):
        self.session_db = session_db
        self.agent_factory = agent_factory

    def _key_state(self, subagent_id: str) -> str:
        return f"subagent:{subagent_id}:state"

    def _key_config(self, subagent_id: str) -> str:
        return f"subagent:{subagent_id}:config"

    def _key_timeline(self, subagent_id: str) -> str:
        return f"subagent:{subagent_id}:timeline"

    def _append_timeline(self, subagent_id: str, state: str):
        """Append a (state, timestamp) entry to the timeline array (keep last 5)."""
        key = self._key_timeline(subagent_id)
        existing = self.session_db.retrieve(key)
        if existing:
            timeline = json.loads(existing)
        else:
            timeline = []
        timeline.append({
            "state": state,
            "timestamp": datetime.utcnow().isoformat() + "Z"
        })
        # Keep only last 5 entries
        if len(timeline) > 5:
            timeline = timeline[-5:]
        self.session_db.store(key, json.dumps(timeline))

    def begin_subagent(self, subagent_id: str, config: Dict[str, Any]) -> str:
        """
        Mark sub‑agent as pending, store config, and return a new session ID.

        Args:
            subagent_id: symbolic name (e.g., "paper_analyzer_1")
            config: dict containing 'task', 'enabled_toolsets', 'disabled_toolsets',
                    'max_iterations', 'system_prompt' (optional)

        Returns:
            session_id assigned to this sub‑agent.
        """
        session_id = str(uuid.uuid4())
        config["session_id"] = session_id
        self.session_db.store(self._key_state(subagent_id), "pending")
        self.session_db.store(self._key_config(subagent_id), json.dumps(config))
        self._append_timeline(subagent_id, "pending")
        logger.info(f"Sub‑agent {subagent_id} (session {session_id}) registered as 'pending'")
        return session_id

    def complete_subagent(self, subagent_id: str, result: str):
        """Mark sub‑agent as completed and store the result."""
        self.session_db.store(self._key_state(subagent_id), "completed")
        self.session_db.store(f"subagent:{subagent_id}:result", result[:2000])
        self._append_timeline(subagent_id, "completed")
        logger.info(f"Sub‑agent {subagent_id} marked 'completed'")

    def fail_subagent(self, subagent_id: str, error: str):
        """Mark sub‑agent as failed and store the error."""
        self.session_db.store(self._key_state(subagent_id), "failed")
        self.session_db.store(f"subagent:{subagent_id}:error", error[:2000])
        self._append_timeline(subagent_id, "failed")
        logger.warning(f"Sub‑agent {subagent_id} marked 'failed': {error[:100]}")

    def resume_pending_subagents(self) -> List[str]:
        """
        Query all sub‑agent states, re‑spawn those with state 'pending' or 'running',
        and return list of sub‑agent IDs that were resumed.
        """
        # We need to discover all sub‑agent IDs. Since SessionDB may not support
        # pattern matching, we maintain a registry key.
        registry_key = "subagent_ids"
        registry = self.session_db.retrieve(registry_key)
        if registry:
            all_ids = json.loads(registry)
        else:
            all_ids = []

        resumed_ids = []
        for subagent_id in all_ids:
            state = self.session_db.retrieve(self._key_state(subagent_id))
            if state in ("pending", "running"):
                logger.info(f"Resuming sub‑agent {subagent_id} (state={state})")
                config_json = self.session_db.retrieve(self._key_config(subagent_id))
                if not config_json:
                    logger.error(f"No config found for {subagent_id}, skipping")
                    continue
                config = json.loads(config_json)
                # Create agent using factory
                agent = self.agent_factory(
                    base_url=config.get("base_url", ""),
                    model=config.get("model", ""),
                    max_iterations=config.get("max_iterations", 30),
                    enabled_toolsets=config.get("enabled_toolsets", []),
                    disabled_toolsets=config.get("disabled_toolsets", []),
                    session_id=config.get("session_id"),
                    system_prompt=config.get("system_prompt", "You are a helpful assistant.")
                )
                # Re‑run the task
                task = config.get("task", "")
                messages = agent.run_conversation(task, temperature=0.0)
                # Extract final answer
                final_answer = ""
                for msg in reversed(messages):
                    if msg.get("role") == "assistant" and "tool_calls" not in msg:
                        final_answer = msg.get("content", "")
                        break
                # Update state to completed
                self.complete_subagent(subagent_id, final_answer)
                resumed_ids.append(subagent_id)

        return resumed_ids

    def register_subagent_id(self, subagent_id: str):
        """Store the sub‑agent ID in the registry list (called after begin)."""
        registry_key = "subagent_ids"
        registry = self.session_db.retrieve(registry_key)
        if registry:
            ids = json.loads(registry)
        else:
            ids = []
        if subagent_id not in ids:
            ids.append(subagent_id)
        self.session_db.store(registry_key, json.dumps(ids))

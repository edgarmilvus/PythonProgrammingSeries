
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import uuid
import logging
from typing import Dict, Optional
from pathlib import Path
from run_agent import AIAgent

# Custom exception for timeout
class SubAgentTimeoutError(Exception):
    pass

# Global registry for sub‑agent sessions (can be used in later exercises)
subagent_registry: Dict[str, str] = {}

def run_analysis_agent(
    file_path: str,
    base_url: str,
    model: str,
    max_iterations: int = 10
) -> str:
    """
    Spawn a code analyzer sub‑agent that reads the given file and returns
    a bullet‑list of function definitions with line numbers.

    Args:
        file_path: Relative path to a file inside the Hermes repo root.
        base_url, model: Inherited from parent.
        max_iterations: Max conversation steps for the sub‑agent.

    Returns:
        The final answer (last non‑tool‑call assistant message).

    Raises:
        SubAgentTimeoutError if sub‑agent fails to finish in time.
        FileNotFoundError if the file does not exist.
    """
    # Create a unique session ID for the sub‑agent
    session_id = str(uuid.uuid4())
    subagent_key = "code_analyzer"

    # Construct the system prompt with the specific file path
    system_prompt = (
        "You are a code analysis assistant. Read the file '{}', "
        "identify all function definitions (including lambda assignments), "
        "and return a bullet‑list of their names and line numbers."
    ).format(file_path)

    # Instantiate the sub‑agent
    sub_agent = AIAgent(
        base_url=base_url,
        model=model,
        max_iterations=max_iterations,
        enabled_toolsets=["file"],
        disabled_toolsets=["terminal", "browser"],
        session_id=session_id,
        system_prompt=system_prompt
    )

    # Run the conversation (temperature=0 for deterministic output)
    messages = sub_agent.run_conversation(
        task=f"Analyze the file {file_path} and list all function definitions.",
        temperature=0.0
    )

    # Extract the last assistant message that has no tool_calls
    # Search in reverse order to find the final answer
    for msg in reversed(messages):
        if msg.get("role") == "assistant" and "tool_calls" not in msg:
            final_answer = msg.get("content", "")
            # Register the sub‑agent session ID
            subagent_registry[subagent_key] = session_id
            return final_answer

    # If no suitable message found, raise timeout error
    raise SubAgentTimeoutError(
        f"Sub‑agent '{subagent_key}' (session {session_id}) did not produce a "
        f"final answer within {max_iterations} iterations."
    )

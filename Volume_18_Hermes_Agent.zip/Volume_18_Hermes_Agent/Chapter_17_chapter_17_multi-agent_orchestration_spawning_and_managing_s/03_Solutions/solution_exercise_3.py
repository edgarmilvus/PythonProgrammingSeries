
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import uuid
import logging
import concurrent.futures
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from run_agent import AIAgent

logger = logging.getLogger(__name__)

# Set of destructive tools that cannot run concurrently with other agents
DESTRUCTIVE_TOOLS = {"terminal", "write_file", "patch", "browser"}

@dataclass
class SubAgentConfig:
    task_description: str
    enabled_toolsets: List[str] = field(default_factory=list)
    disabled_toolsets: List[str] = field(default_factory=list)
    session_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    max_iterations: int = 30

def _subagent_is_readonly(config: SubAgentConfig) -> bool:
    """Return True if the sub‑agent uses no destructive tools."""
    return not any(tool in config.enabled_toolsets for tool in DESTRUCTIVE_TOOLS)

def _conflict(c1: SubAgentConfig, c2: SubAgentConfig) -> bool:
    """
    Two sub‑agents conflict if:
    - Either is not read‑only AND they share the same file system (assumed CWD).
    - Both are read‑only but combined max_iterations > 60.
    """
    ro1 = _subagent_is_readonly(c1)
    ro2 = _subagent_is_readonly(c2)

    if not ro1 or not ro2:
        # At least one is destructive → conflict (share filesystem)
        return True
    # Both read‑only: conflict only if resource starvation possible
    if (c1.max_iterations + c2.max_iterations) > 60:
        return True
    return False

def parallel_subagent_spawn(
    subagent_configs: List[SubAgentConfig],
    max_workers: int = 4,
    base_url: str = "",
    model: str = ""
) -> Dict[str, Dict[str, Any]]:
    """
    Group sub‑agent configs into safe parallel batches and execute them.

    Args:
        subagent_configs: List of configurations.
        max_workers: Max threads per batch.
        base_url, model: Model settings inherited from parent.

    Returns:
        Dictionary mapping session_id -> {"output": ..., "iterations_used": ...}
        or {"error": ...} for failed agents.
    """
    results: Dict[str, Dict[str, Any]] = {}

    # Batch building: greedy algorithm that adds non‑conflicting agents to current batch
    batches: List[List[SubAgentConfig]] = []
    remaining = list(subagent_configs)

    while remaining:
        current_batch = [remaining.pop(0)]  # start with first remaining
        # Try to add others that don't conflict with anything already in batch
        to_add = []
        for cfg in remaining:
            if not any(_conflict(cfg, batched) for batched in current_batch):
                to_add.append(cfg)
        for cfg in to_add:
            current_batch.append(cfg)
            remaining.remove(cfg)
        batches.append(current_batch)
        logger.info(f"Batch formed with {len(current_batch)} sub‑agents: "
                     f"{[c.session_id[:8] for c in current_batch]}")

    # Execute each batch sequentially, agents within batch in parallel
    for batch_num, batch in enumerate(batches, start=1):
        logger.info(f"Executing batch {batch_num} with {len(batch)} agents")

        # If batch has only one agent, run inline to avoid pool overhead
        if len(batch) == 1:
            cfg = batch[0]
            session_id = cfg.session_id
            try:
                agent = AIAgent(
                    base_url=base_url,
                    model=model,
                    max_iterations=cfg.max_iterations,
                    enabled_toolsets=cfg.enabled_toolsets,
                    disabled_toolsets=cfg.disabled_toolsets,
                    session_id=session_id,
                    system_prompt="You are a helpful assistant."
                )
                messages = agent.run_conversation(cfg.task_description, temperature=0.0)
                # Extract final answer
                output = ""
                iterations_used = 0
                for msg in reversed(messages):
                    if msg.get("role") == "assistant" and "tool_calls" not in msg:
                        output = msg.get("content", "")
                        break
                # Count iterations (number of assistant turns)
                iterations_used = sum(1 for m in messages if m.get("role") == "assistant")
                results[session_id] = {"output": output, "iterations_used": iterations_used}
            except Exception as e:
                results[session_id] = {"error": str(e)}
        else:
            # Use ThreadPoolExecutor for parallel execution in this batch
            with concurrent.futures.ThreadPoolExecutor(
                max_workers=min(len(batch), max_workers)
            ) as executor:
                future_to_cfg = {
                    executor.submit(_run_single_agent, cfg, base_url, model): cfg
                    for cfg in batch
                }
                for future in concurrent.futures.as_completed(future_to_cfg):
                    cfg = future_to_cfg[future]
                    session_id = cfg.session_id
                    try:
                        result = future.result()
                        results[session_id] = result
                    except Exception as e:
                        results[session_id] = {"error": str(e)}

    return results

def _run_single_agent(
    cfg: SubAgentConfig,
    base_url: str,
    model: str
) -> Dict[str, Any]:
    """Helper to run one sub‑agent and collect output/iteration count."""
    agent = AIAgent(
        base_url=base_url,
        model=model,
        max_iterations=cfg.max_iterations,
        enabled_toolsets=cfg.enabled_toolsets,
        disabled_toolsets=cfg.disabled_toolsets,
        session_id=cfg.session_id,
        system_prompt="You are a helpful assistant."
    )
    messages = agent.run_conversation(cfg.task_description, temperature=0.0)
    output = ""
    for msg in reversed(messages):
        if msg.get("role") == "assistant" and "tool_calls" not in msg:
            output = msg.get("content", "")
            break
    iterations_used = sum(1 for m in messages if m.get("role") == "assistant")
    return {"output": output, "iterations_used": iterations_used}

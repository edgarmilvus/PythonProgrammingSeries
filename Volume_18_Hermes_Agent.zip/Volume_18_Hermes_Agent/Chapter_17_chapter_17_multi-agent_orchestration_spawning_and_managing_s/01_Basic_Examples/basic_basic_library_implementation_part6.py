
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation_part6.py
# Description: Basic Library Implementation
# ==========================================

def inherit_skills_to_sub_agent(
    parent_agent: AIAgent,
    sub_agent: AIAgent,
    session_db: SessionDB,
) -> None:
    """
    Copy the parent's saved skills (from memory) into the sub‑agent's session,
    so the sub‑agent can start using them immediately.
    """
    # In Hermes, skills are stored in the session's memory under a 'skills' key.
    parent_skills = session_db.get_session_memory(
        parent_agent.session_id, "skills"
    ) or []

    if not parent_skills:
        logger.info("Parent has no exported skills; sub‑agent starts fresh.")
        return

    # Filter skills that are relevant to the sub‑agent's tool scope
    relevant_skills = [
        skill for skill in parent_skills
        if any(tool in skill.get("required_tools", []) for tool in sub_agent.enabled_toolsets)
    ]

    if relevant_skills:
        # Store in the sub‑agent's session so it can be injected into the system prompt
        session_db.set_session_memory(
            sub_agent.session_id,
            "inherited_skills",
            relevant_skills,
        )
        logger.info(
            "Inherited %d skills into sub‑agent %s",
            len(relevant_skills),
            sub_agent.session_id,
        )


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation_part5.py
# Description: Basic Library Implementation
# ==========================================

def run_concurrent_subagents(
    parent: AIAgent,
    task_pairs: List[tuple[str, str, List[str]]],
    max_workers: int = 4,
) -> Dict[str, Optional[str]]:
    """
    Execute multiple sub‑agents concurrently, each with its own session.
    
    task_pairs: list of (session_id, task_prompt, tool_scope) tuples.
    Returns dict mapping session_id to result (or None on failure).
    """
    results: Dict[str, Optional[str]] = {}
    db = SessionDB(get_hermes_home() / "sessions")

    def worker(session_id: str, prompt: str, tools: List[str]) -> Optional[str]:
        try:
            agent = AIAgent(
                base_url=parent.base_url,
                api_key=cfg_get("providers.default.api_key"),
                model="claude-opus-4-20250514",
                max_iterations=50,
                enabled_toolsets=tools,
                session_id=session_id,
                quiet_mode=True,
            )
            output = agent.run_conversation(prompt)
            db.update_session(session_id, {"status": "completed"})
            return output
        except Exception as e:
            logger.error(f"Worker {session_id} exception: {e}")
            db.update_session(session_id, {"status": "error", "error_message": str(e)})
            return None

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(worker, sid, prompt, tools): sid
            for sid, prompt, tools in task_pairs
        }
        for future in as_completed(futures):
            sid = futures[future]
            try:
                results[sid] = future.result(timeout=300)
            except Exception as exc:
                logger.error(f"Future for {sid} failed: {exc}")
                results[sid] = None
    return results


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation_part4.py
# Description: Basic Library Implementation
# ==========================================

from typing import List, Dict, Optional, Callable, Any
from concurrent.futures import ThreadPoolExecutor, as_completed
import queue
import threading

class SupervisorAgent:
    """
    A reusable orchestrator that manages a fleet of Hermes sub-agents.

    Sub‑agents are tracked via SessionDB. The supervisor can:
      - Decompose tasks by calling the parent LLM
      - Spawn sub‑agents with appropriate configurations
      - Run sub‑agents in parallel or sequentially
      - Collect results and persist them to the DB
      - Handle timeouts and failures gracefully
    """

    def __init__(
        self,
        parent_agent: AIAgent,
        session_db: SessionDB,
        max_parallel_workers: int = 4,
        sub_agent_model: str = "claude-opus-4-20250514",
        sub_agent_max_iterations: int = 50,
        default_timeout: int = 120,
    ):
        self.parent = parent_agent
        self.db = session_db
        self.max_workers = max_parallel_workers
        self.sub_agent_model = sub_agent_model
        self.sub_agent_max_iterations = sub_agent_max_iterations
        self.default_timeout = default_timeout
        self._workers = ThreadPoolExecutor(max_workers=max_parallel_workers)

    def decompose_task(self, complex_request: str) -> List[dict]:
        """
        Ask the parent LLM to break the request into independent subtasks.
        Returns a list of dicts with keys: 'description', 'tools', 'timeout'.
        """
        decompose_prompt = (
            f"Given the following user request, decompose it into independent "
            f"subtasks that can be executed in parallel. For each subtask, provide: "
            f"1. A clear description of what to do, 2. The tool categories needed "
            f"(e.g., filesystem, web, terminal), 3. A suggested timeout in seconds. "
            f"Output as JSON array.\n\nRequest: {complex_request}"
        )
        # Use the parent's LLM chain (tool‑based decomposition)
        # In a real implementation, we'd call the parent's run_conversation with a
        # special tool 'decompose' or parse the structured output.
        # Here we simulate the result:
        subtasks = [
            {"description": "Read the file and produce a 500‑word summary.",
             "tools": ["filesystem", "write_file"], "timeout": 180},
            {"description": "Extract all Python import statements.",
             "tools": ["filesystem"], "timeout": 60},
        ]
        return subtasks

    def spawn_sub_agent(self, subtask: dict) -> AIAgent:
        """Create a new Hermes agent for the given subtask and register it."""
        sub_session_id = f"worker_{hash(subtask['description']):x}_{uuid.uuid4().hex[:6]}"
        # Inherit skills from parent? (Advanced: use self.parent.export_skills())
        # For now, just copy the basic skill set.
        inherited_skills = self.parent.export_skills() if hasattr(self.parent, "export_skills") else []

        metadata = {
            "parent_session_id": self.parent.session_id,
            "task_description": subtask["description"],
            "tool_scope": subtask["tools"],
            "status": "pending",
            "created_at": datetime.utcnow().isoformat(),
            "skills_inherited": inherited_skills,
            "iteration_budget_limit": self.sub_agent_max_iterations,
            "iterations_used": 0,
            "timeout": subtask.get("timeout", self.default_timeout),
        }
        self.db.upsert_session(sub_session_id, metadata)
        self.db.link_parent_child(self.parent.session_id, sub_session_id)

        sub_agent = AIAgent(
            base_url=self.parent.base_url,
            api_key=cfg_get("providers.default.api_key"),
            model=self.sub_agent_model,
            max_iterations=self.sub_agent_max_iterations,
            enabled_toolsets=subtask["tools"],
            session_id=sub_session_id,
            quiet_mode=True,
            verbose_logging=False,
        )
        # Attach a custom budget that respects both parent and child limits
        # (The parent’s budget is not reduced when sub‑agents run.)
        return sub_agent

    def run_sub_agent_sync(self, agent: AIAgent, task: str, timeout: int) -> Optional[str]:
        """Blocking call to execute a sub‑agent, with timeout and error handling."""
        try:
            result = agent.run_conversation(task)
            self.db.update_session(agent.session_id, {"status": "completed"})
            return result
        except Exception as exc:
            logger.error(f"Sub-agent {agent.session_id} failed: {exc}")
            self.db.update_session(agent.session_id, {"status": "error", "error_message": str(exc)})
            return None

    def orchestrate(self, complex_request: str) -> str:
        """
        Full lifecycle: decompose → spawn → parallel execute → synchronize.
        Returns the final composed answer.
        """
        logger.info("=== Supervisor starting orchestration ===")
        # 1. Decompose
        subtasks = self.decompose_task(complex_request)
        logger.info(f"Decomposed into {len(subtasks)} subtasks.")

        # 2. Spawn all sub‑agents
        agents = [self.spawn_sub_agent(st) for st in subtasks]
        sessions = [a.session_id for a in agents]
        logger.info(f"Spawned sub‑agents: {sessions}")

        # 3. Run subtasks in parallel using ThreadPoolExecutor
        future_to_session = {}
        for agent, subtask in zip(agents, subtasks):
            timeout = subtask.get("timeout", self.default_timeout)
            future = self._workers.submit(self.run_sub_agent_sync, agent, subtask["description"], timeout)
            future_to_session[future] = agent.session_id

        # 4. Collect results (order not guaranteed)
        results: Dict[str, Optional[str]] = {}
        for future in as_completed(future_to_session):
            session_id = future_to_session[future]
            try:
                result = future.result(timeout=self.default_timeout + 10)
                results[session_id] = result
            except Exception as exc:
                logger.error(f"Future for {session_id} raised: {exc}")
                results[session_id] = None

        # 5. Build final synthesis (simple concatenation for now)
        final_parts = []
        for session_id in sessions:
            res = results.get(session_id)
            if res is not None:
                final_parts.append(f"### Subtask {session_id}\n{res}")
            else:
                final_parts.append(f"### Subtask {session_id}\n⚠️ Failed to complete.")
        final_answer = "\n\n".join(final_parts)

        # 6. Persist the orchestration summary
        self.db.upsert_session(self.parent.session_id, {
            "orchestration_complete": True,
            "child_sessions": sessions,
            "final_output_length": len(final_answer),
            "completed_at": datetime.utcnow().isoformat(),
        })
        logger.info("=== Supervisor orchestration complete ===")
        return final_answer

# -----------------------------------------------------------------------
# Example usage
# -----------------------------------------------------------------------
async def main():
    # Same parent agent setup as before
    parent = AIAgent(...)  # (omitted for brevity)
    db = SessionDB(...)

    supervisor = SupervisorAgent(
        parent_agent=parent,
        session_db=db,
        max_parallel_workers=4,
        sub_agent_model="claude-opus-4-20250514",
        sub_agent_max_iterations=50,
    )

    request = "Analyze the codebase in /home/user/project: list all Python imports, count the number of lines, and identify any missing docstrings."
    final_report = supervisor.orchestrate(request)
    print(final_report)

if __name__ == "__main__":
    asyncio.run(main())

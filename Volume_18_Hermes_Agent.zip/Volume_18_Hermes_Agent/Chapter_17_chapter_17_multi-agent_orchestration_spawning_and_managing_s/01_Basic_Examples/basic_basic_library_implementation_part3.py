
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation_part3.py
# Description: Basic Library Implementation
# ==========================================

import asyncio
from typing import Any, Optional

async def run_sub_agent_and_collect_result(
    sub_agent: AIAgent,
    task_prompt: str,
    timeout_seconds: int = 120,
) -> Optional[str]:
    """
    Execute a sub-agent asynchronously and return its final text response.
    """
    logger.info(f"Starting sub-agent with task: {task_prompt[:80]}...")
    try:
        # run_conversation is synchronous under the hood, but we wrap it
        # in an executor thread to avoid blocking the parent's event loop.
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            None,
            lambda: sub_agent.run_conversation(task_prompt),
        )
        logger.info("Sub-agent completed successfully.")
        return result
    except Exception as exc:
        logger.error(f"Sub-agent failed: {exc}")
        # Update session DB with error status
        session_db.update_session(
            sub_agent.session_id,
            {"status": "error", "error_message": str(exc)},
        )
        return None


# ---------------------------------------------------------------------------
# Parent orchestrates the summarizer sub‑agent
# ---------------------------------------------------------------------------
async def example_orchestration():
    # 1. Parent receives a complex request
    user_request = (
        "I need a 500‑word executive summary of 'report_long.md' "
        "and also a list of all Python imports used in that file."
    )

    # 2. Parent agent decomposes the task (simplified: we hard‑code the split)
    #    In a full implementation, the parent would call a tool like
    #    "decompose_task" and receive subtask definitions.
    subtask1 = "Read 'report_long.md' and produce a 500‑word executive summary. Save output to 'summary.txt'."
    subtask2 = "Read 'report_long.md' and extract all `import` lines. Save to 'imports.txt'."

    # 3. Spawn first sub‑agent
    summarizer_meta = register_sub_agent(
        parent_session_id=parent_config["session_id"],
        sub_session_id="worker_summarize_a1b2c3",
        task_description=subtask1,
        tool_scope=["filesystem", "write_file"],
        parent_iteration_budget=parent_agent._budget,
    )
    summarizer = AIAgent(
        base_url=parent_config["base_url"],
        api_key=parent_config["api_key"],
        model=SUB_AGENT_MODEL,
        max_iterations=summarizer_meta["iteration_budget_limit"],
        enabled_toolsets=summarizer_meta["tool_scope"],
        session_id="worker_summarize_a1b2c3",
    )

    # 4. Run sub‑agent and wait for completion
    summary_result = await run_sub_agent_and_collect_result(summarizer, subtask1)

    # 5. Update session database with result
    if summary_result:
        session_db.update_session(
            "worker_summarize_a1b2c3",
            {"status": "completed", "result_preview": summary_result[:200]},
        )
    else:
        session_db.update_session(
            "worker_summarize_a1b2c3",
            {"status": "failed"},
        )

    # 6. Repeat for second sub‑agent (parallel execution would be more efficient)
    importer_meta = register_sub_agent(
        parent_session_id=parent_config["session_id"],
        sub_session_id="worker_imports_d4e5f6",
        task_description=subtask2,
        tool_scope=["filesystem", "write_file"],
        parent_iteration_budget=parent_agent._budget,
    )
    importer = AIAgent(
        base_url=parent_config["base_url"],
        api_key=parent_config["api_key"],
        model=SUB_AGENT_MODEL,
        max_iterations=importer_meta["iteration_budget_limit"],
        enabled_toolsets=importer_meta["tool_scope"],
        session_id="worker_imports_d4e5f6",
    )
    imports_result = await run_sub_agent_and_collect_result(importer, subtask2)

    # 7. Collect all sub‑agent outputs and compose the final answer
    final_answer = f"## Summary\n{summary_result or 'Failed'}\n\n## Imports\n{imports_result or 'Failed'}"
    print("=== PARENT FINAL OUTPUT ===")
    print(final_answer)

    # 8. Archive the orchestration result in the parent’s session
    session_db.upsert_session(
        parent_config["session_id"],
        metadata={
            "orchestration_complete": True,
            "child_sessions": ["worker_summarize_a1b2c3", "worker_imports_d4e5f6"],
            "final_output_length": len(final_answer),
        },
    )

# Run the asynchronous example
asyncio.run(example_orchestration())

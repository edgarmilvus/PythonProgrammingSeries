
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation_part2.py
# Description: Basic Library Implementation
# ==========================================

# Continuing from the code above...

def register_sub_agent(
    parent_session_id: str,
    sub_session_id: str,
    task_description: str,
    tool_scope: List[str],
    parent_iteration_budget: IterationBudget,
) -> dict:
    """
    Create a persistent record for a new sub-agent and link it to its parent.
    Returns the metadata dict for future reference.
    """
    # 1. Generate a unique sub‑session and store its configuration
    sub_metadata = {
        "parent_session_id": parent_session_id,
        "task_description": task_description,
        "tool_scope": tool_scope,
        "status": "pending",
        "created_at": "2025-07-01T10:05:00Z",
        "skills_inherited": [],          # will be populated later
        "iteration_budget_limit": 50,
        "iterations_used": 0,
    }
    session_db.upsert_session(sub_session_id, sub_metadata)

    # 2. Record the parent‑child relationship
    session_db.link_parent_child(parent_session_id, sub_session_id)

    # 3. Allocate an independent iteration budget for this sub‑agent
    #    (The parent's budget is not shared. Sub‑agents have their own cap.)
    budget = IterationBudget(max_total=sub_metadata["iteration_budget_limit"])
    sub_metadata["_budget"] = budget

    logger.info(
        "Sub-agent registered: %s (task='%s', tools=%s)",
        sub_session_id, task_description[:40], tool_scope,
    )
    return sub_metadata


# Example usage: register a sub‑agent to summarize a large document
parent_session = "research_supervisor_session_01"
summarizer_session = "worker_summarize_doc_a1b2c3d4"

summarizer_meta = register_sub_agent(
    parent_session_id=parent_session,
    sub_session_id=summarizer_session,
    task_description="Read the file 'report_long.md' and produce a 500‑word executive summary.",
    tool_scope=["filesystem", "write_file"],
    parent_iteration_budget=parent_agent._budget,   # not directly used here, but for tracking
)

# Now we can instantiate the sub‑agent with its own session
summarizer_agent = AIAgent(
    base_url=parent_agent.base_url,
    api_key=parent_config["api_key"],
    model=SUB_AGENT_MODEL,
    max_iterations=summarizer_meta["iteration_budget_limit"],
    enabled_toolsets=summarizer_meta["tool_scope"],
    session_id=summarizer_session,
    # minimal callback to avoid noise
    status_callback=lambda msg: logger.debug(f"[summarizer] {msg}"),
)

# The sub-agent is now alive and ready to receive a task.
# (We'll run it later in the orchestration loop.)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation.py
# Description: Basic Library Implementation
# ==========================================

#!/usr/bin/env python3
"""
Example: Basic Parent Agent Configuration for Sub-Agent Orchestration.
"""
import logging
import json
import asyncio
from typing import Dict, List, Any, Optional
from pathlib import Path

# Import the core runtime classes from Hermes
from run_agent import AIAgent, IterationBudget
from agent.session_db import SessionDB           # persistent session storage
from agent.prompt_builder import DEFAULT_AGENT_IDENTITY
from hermes_cli.config import cfg_get             # global config access
from hermes_constants import get_hermes_home

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Step 1: Build the parent agent with production‑grade settings
# ---------------------------------------------------------------------------

# Load provider config from ~/.hermes/config.yaml
parent_config = {
    "base_url": cfg_get("providers.default.base_url", "http://localhost:30000/v1"),
    "api_key":  cfg_get("providers.default.api_key", ""),
    "model":    cfg_get("providers.default.model", "claude-opus-4-20250514"),
    "provider": "openai-compatible",   # or "anthropic", "google", etc.
    "api_mode": "chat",
    "max_iterations": 90,              # tool‑calling budget for this agent
    "tool_delay": 1.0,                 # seconds between tool call batches
    "enabled_toolsets": ["filesystem", "web", "terminal", "code_execution"],
    "save_trajectories": True,
    "verbose_logging": False,
    "quiet_mode": False,
    "session_id": "research_supervisor_session_01",  # persistent session key
}

parent_agent = AIAgent(
    base_url=parent_config["base_url"],
    api_key=parent_config["api_key"],
    model=parent_config["model"],
    provider=parent_config["provider"],
    api_mode=parent_config["api_mode"],
    max_iterations=parent_config["max_iterations"],
    tool_delay=parent_config["tool_delay"],
    enabled_toolsets=parent_config["enabled_toolsets"],
    save_trajectories=parent_config["save_trajectories"],
    verbose_logging=parent_config["verbose_logging"],
    quiet_mode=parent_config["quiet_mode"],
    session_id=parent_config["session_id"],
    # Callbacks let us observe each tool call and thinking step
    tool_start_callback=lambda tc: logger.info(f"Tool started: {tc.function.name}"),
    tool_complete_callback=lambda tc, result: logger.info(f"Tool done: {tc.function.name}"),
    thinking_callback=lambda text: logger.debug(f"Thinking: {text[:60]}"),
    status_callback=lambda msg: logger.info(f"Status: {msg}"),
)

print(f"✅ Parent agent created: {parent_config['model']} @ {parent_config['base_url']}")
print(f"   Session ID: {parent_config['session_id']}")

# ---------------------------------------------------------------------------
# Step 2: Initialize the persistent session database
# ---------------------------------------------------------------------------
hermes_home = get_hermes_home()
session_db = SessionDB(db_path=hermes_home / "sessions")
session_db.ensure_tables()  # creates sub_agent_sessions, parent_links tables

# Store the parent agent's session metadata
session_db.upsert_session(
    session_id=parent_config["session_id"],
    metadata={
        "role": "supervisor",
        "model": parent_config["model"],
        "max_iterations": parent_config["max_iterations"],
        "creation_time": "2025-07-01T10:00:00Z",
    }
)

# ---------------------------------------------------------------------------
# Step 3: Define a simple sub‑agent configuration template
# ---------------------------------------------------------------------------
SUB_AGENT_MODEL = "claude-opus-4-20250514"   # can be a cheaper model
SUB_AGENT_MAX_ITERATIONS = 50                 # from delegation config

def build_sub_agent_config(task_slug: str) -> dict:
    """Return a config dict for a specialized sub-agent."""
    return {
        "base_url": parent_config["base_url"],
        "api_key": parent_config["api_key"],
        "model": SUB_AGENT_MODEL,
        "provider": parent_config["provider"],
        "api_mode": "chat",
        "max_iterations": SUB_AGENT_MAX_ITERATIONS,
        "tool_delay": 0.5,                    # faster turnaround for workers
        "enabled_toolsets": ["filesystem"],    # limited scope
        "save_trajectories": False,
        "session_id": f"worker_{task_slug}_{uuid.uuid4().hex[:8]}",
    }


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# dashboard_plugin.py – Abstract interface and registry

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional
import importlib
import inspect
from pathlib import Path

class DashboardPanel(ABC):
    """Abstract base class for dashboard panels."""
    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable name for the panel."""
        pass

    @abstractmethod
    async def update(self, data: dict) -> None:
        """Called when new agent state arrives. Data contains event type and payload."""
        pass

    @abstractmethod
    def render(self) -> Any:
        """
        Returns a prompt_toolkit control (for TUI) or HTML string (for web).
        The return type depends on the active display layer.
        """
        pass

    def websocket_handler(self, event: str, payload: dict) -> None:
        """Optional: process custom WebSocket messages for live updates."""
        pass

    @property
    def static_dir(self) -> Optional[Path]:
        """Optional: path to static files (JS, CSS) for web dashboard."""
        return None

class EventBus:
    """Simple pub/sub event bus using asyncio.Queue."""
    def __init__(self, loop=None):
        self._loop = loop or asyncio.get_event_loop()
        self._subscribers: Dict[str, List[DashboardPanel]] = {}
        self._queue = asyncio.Queue()

    def subscribe(self, event_type: str, panel: DashboardPanel):
        if event_type not in self._subscribers:
            self._subscribers[event_type] = []
        self._subscribers[event_type].append(panel)

    def unsubscribe(self, event_type: str, panel: DashboardPanel):
        if event_type in self._subscribers:
            self._subscribers[event_type].remove(panel)

    async def emit(self, event_type: str, data: dict):
        """Push event to queue; consumer will call update on subscribers."""
        await self._queue.put((event_type, data))

    async def _consumer(self):
        while True:
            event_type, data = await self._queue.get()
            for panel in self._subscribers.get(event_type, []):
                await panel.update(data)

    def start(self):
        """Start the consumer task."""
        asyncio.ensure_future(self._consumer(), loop=self._loop)

class PanelLoader:
    """Discovers and loads panels from a directory."""
    def __init__(self, panel_dir: Path):
        self.panel_dir = panel_dir
        self.panels: List[DashboardPanel] = []

    def load_all(self):
        """Import all Python files in panel_dir and instantiate panels."""
        if not self.panel_dir.exists():
            return
        for pyfile in self.panel_dir.glob("*.py"):
            if pyfile.name.startswith('_'):
                continue
            spec = importlib.util.spec_from_file_location(pyfile.stem, pyfile)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            if hasattr(module, 'panel_classes'):
                for panel_cls in module.panel_classes:
                    if inspect.isclass(panel_cls) and issubclass(panel_cls, DashboardPanel):
                        # Validate interface
                        if not all(hasattr(panel_cls, m) for m in ['name', 'update', 'render']):
                            print(f"Warning: {panel_cls.__name__} missing required methods. Skipping.")
                            continue
                        panel_instance = panel_cls()
                        self.panels.append(panel_instance)

# Integration in HermesCLI.run()
def run(self):
    loader = PanelLoader(Path.home() / '.hermes' / 'panels')
    loader.load_all()
    event_bus = EventBus()
    for panel in loader.panels:
        # Subscribe to events based on panel's declared interests (could be via annotation)
        # For simplicity, subscribe to all events
        event_bus.subscribe('*', panel)
    event_bus.start()
    # Modify layout to include panel renders
    # In layout, create a tab bar using HSplit with FilteredBuffers
    # Each panel's render() returns a control that is placed in a tab.
    # The web dashboard would similarly iterate over panels and add routes.

# Web dashboard integration (Flask)
@app.route('/panels/<panel_name>')
def panel_view(panel_name):
    for panel in loaded_panels:
        if panel.name == panel_name:
            return panel.render()  # returns HTML string
    return "Panel not found", 404

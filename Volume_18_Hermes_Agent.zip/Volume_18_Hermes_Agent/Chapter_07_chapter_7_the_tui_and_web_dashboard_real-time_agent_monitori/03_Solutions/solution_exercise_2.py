
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Flask routes (app.py or dashboard.py)

from flask import Flask, request, jsonify, render_template
from pathlib import Path
import shutil
import time
import json
from tools.memory_tool import MemoryStore
from config import Config

app = Flask(__name__)
config = Config()
memory_store = MemoryStore(config)

@app.route('/api/memory', methods=['GET'])
def get_memory():
    """Return current memory and user profile content."""
    memory_path = Path(config.memory_file_path)
    user_path = Path(config.user_profile_file_path)
    memory_content = memory_path.read_text() if memory_path.exists() else ''
    user_content = user_path.read_text() if user_path.exists() else ''
    return jsonify({
        'memory': {
            'content': memory_content,
            'char_limit': config.memory_char_limit,
            'path': str(memory_path),
            'last_modified': memory_path.stat().st_mtime
        },
        'user_profile': {
            'content': user_content,
            'char_limit': config.user_char_limit,
            'path': str(user_path),
            'last_modified': user_path.stat().st_mtime
        }
    })

@app.route('/api/memory', methods=['POST'])
def save_memory():
    """Save content to memory or user profile file."""
    data = request.get_json()
    target = data.get('target')
    content = data.get('content', '')
    if target not in ('memory', 'user'):
        return jsonify({'error': 'Invalid target. Must be "memory" or "user".'}), 400
    # Check agent running status (global variable)
    from cli import current_cli_instance
    if current_cli_instance and current_cli_instance._agent_running:
        return jsonify({'error': 'Agent is currently running. Please stop the agent before editing memory.'}), 409
    # Sanitize content (basic XSS)
    content = content.replace('<script>', '').replace('</script>', '')
    # Check char limit
    limit = config.memory_char_limit if target == 'memory' else config.user_char_limit
    if len(content) > limit:
        return jsonify({'error': f'Content exceeds the {limit} character limit for {target}.'}), 400
    # Save version before overwriting
    version_dir = Path(config.data_dir) / 'memory_versions'
    version_dir.mkdir(parents=True, exist_ok=True)
    timestamp = int(time.time())
    src_file = Path(config.memory_file_path) if target == 'memory' else Path(config.user_profile_file_path)
    if src_file.exists():
        version_file = version_dir / f'{target.upper()}_{timestamp}.md'
        shutil.copy2(src_file, version_file)
    # Trim to last 5 versions
    versions = sorted(version_dir.glob(f'{target.upper()}_*.md'))
    for old in versions[:-5]:
        old.unlink()
    # Write new content
    src_file.write_text(content)
    # Reload memory store and invalidate agent cache
    memory_store.load_from_disk()
    if current_cli_instance and current_cli_instance.agent:
        current_cli_instance.agent._cached_system_prompt = None
    return jsonify({'success': True, 'message': f'{target.capitalize()} updated successfully.'})

@app.route('/api/memory/versions', methods=['GET'])
def get_versions():
    """List available version files for both targets."""
    version_dir = Path(config.data_dir) / 'memory_versions'
    versions = []
    for f in version_dir.glob('*_*.md'):
        parts = f.stem.split('_')
        target = parts[0].lower()
        timestamp = parts[1]
        versions.append({
            'target': target,
            'timestamp': timestamp,
            'path': str(f)
        })
    return jsonify({'versions': versions})

@app.route('/api/memory/restore', methods=['POST'])
def restore_version():
    """Restore a previous version."""
    data = request.get_json()
    target = data.get('target')
    version = data.get('version')  # timestamp string
    if target not in ('memory', 'user'):
        return jsonify({'error': 'Invalid target.'}), 400
    version_file = Path(config.data_dir) / 'memory_versions' / f'{target.upper()}_{version}.md'
    if not version_file.exists():
        return jsonify({'error': 'Version not found.'}), 404
    src_file = Path(config.memory_file_path) if target == 'memory' else Path(config.user_profile_file_path)
    shutil.copy2(version_file, src_file)
    memory_store.load_from_disk()
    return jsonify({'success': True, 'message': f'{target.capitalize()} restored to version {version}.'})

@app.route('/memory')
def memory_editor_page():
    return render_template('memory_editor.html')

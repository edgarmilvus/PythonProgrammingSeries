
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# In cli.py, within the HermesCLI class

def __init__(self, ...):
    super().__init__(...)
    self._token_gauge_fraction = 0.0
    self._token_deltas = deque(maxlen=10)  # sliding window of token counts
    self._last_agent_active_time = 0.0
    self._gauge_fade_timer = 0.0

async def _spinner_loop(self):
    """Override or extend the existing spinner loop."""
    while True:
        await asyncio.sleep(0.2)
        if self._agent_running:
            self._update_token_gauge()
            self._last_agent_active_time = time.time()
        else:
            # Fade gauge after 2 seconds of inactivity
            if time.time() - self._last_agent_active_time > 2.0:
                self._token_gauge_fraction = 0.0
        self._invalidate(min_interval=0.15)

def _update_token_gauge(self):
    """Compute sliding window average of token consumption."""
    if self.agent is None or self.agent.context_compressor is None:
        self._token_gauge_fraction = -1  # sentinel for "unknown"
        return
    current_total = self.agent.session_total_tokens
    self._token_deltas.append(current_total)
    if len(self._token_deltas) < 2:
        return
    # Compute tokens per second over the window (each tick is ~0.2s)
    tokens_consumed = self._token_deltas[-1] - self._token_deltas[0]
    time_span = len(self._token_deltas) * 0.2
    rate = tokens_consumed / time_span if time_span > 0 else 0
    # Context window usage percentage (assume max context from config)
    max_context = self.agent.config.get('max_context_tokens', 100000)
    pct = min(100, (current_total / max_context) * 100)
    self._token_gauge_fraction = pct / 100.0

def _build_gauge_widget(self):
    """Create the gauge FormattedTextControl."""
    if self._token_gauge_fraction < 0:
        fragments = [("class:gauge-label", "───")]
    else:
        pct = int(self._token_gauge_fraction * 100)
        filled = min(10, pct // 10)
        bar = "█" * filled + "░" * (10 - filled)
        label = f"ctx: {pct}%"
        style = "class:gauge-critical" if pct > 90 else "class:gauge-label"
        fragments = [
            ("class:gauge-bar", f"[{bar}]"),
            (style, f" {label}"),
        ]
    return FormattedTextControl(fragments)

def _build_tui_layout_children(self):
    """Insert gauge widget after spinner_widget."""
    children = super()._build_tui_layout_children()
    # Assume children is a list of widgets; find index of spinner_widget
    spinner_idx = next(i for i, w in enumerate(children) if w == self.spinner_widget)
    gauge_window = Window(
        content=self._build_gauge_widget(),
        height=ConditionalContainer(
            filter=Condition(lambda: self._agent_running and self._token_gauge_fraction >= 0),
            content=Window(height=1)
        ).height
    )
    children.insert(spinner_idx + 1, gauge_window)
    return children

# In style definition
self._tui_style_base.update({
    'gauge-bar': '#8FBC8F',
    'gauge-label': '#FFD700 bold',
    'gauge-critical': '#FF6B6B bold',
})

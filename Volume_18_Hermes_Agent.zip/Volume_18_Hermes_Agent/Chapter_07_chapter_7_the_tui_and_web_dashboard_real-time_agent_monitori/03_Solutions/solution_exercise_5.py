
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# Flask routes for session comparison

from flask import Flask, request, jsonify, render_template
from functools import lru_cache
import difflib
from session_db import SessionDB

app = Flask(__name__)
db = SessionDB()

@app.route('/api/sessions')
def list_sessions():
    limit = request.args.get('limit', 50, type=int)
    sessions = db.get_all_sessions(limit=limit)
    # Return list of {id, title, timestamp, token_counts}
    return jsonify([{
        'id': s.id,
        'title': s.title,
        'timestamp': s.timestamp,
        'total_tokens': s.total_tokens,
        'prompt_tokens': s.prompt_tokens,
        'completion_tokens': s.completion_tokens,
        'cache_read_tokens': s.cache_read_tokens,
        'cache_write_tokens': s.cache_write_tokens
    } for s in sessions])

@app.route('/api/compare')
def compare_sessions():
    s1 = request.args.get('s1')
    s2 = request.args.get('s2')
    max_messages = request.args.get('max_messages', 0, type=int)
    if not s1 or not s2:
        return jsonify({'error': 'Both s1 and s2 query parameters are required.'}), 400
    result = _compute_comparison(s1, s2, max_messages)
    return jsonify(result)

@lru_cache(maxsize=32)
def _compute_comparison(s1, s2, max_messages):
    """Compute diff between two sessions, cached for 60 seconds (via lru_cache)."""
    msgs1 = db.get_messages_as_conversation(s1)
    msgs2 = db.get_messages_as_conversation(s2)
    if max_messages > 0:
        msgs1 = msgs1[-max_messages:]
        msgs2 = msgs2[-max_messages:]
    # Token diff
    def get_token_counts(session_id):
        s = db.get_session(session_id)
        return {
            'prompt_tokens': s.prompt_tokens,
            'completion_tokens': s.completion_tokens,
            'cache_read_tokens': s.cache_read_tokens,
            'cache_write_tokens': s.cache_write_tokens,
            'total_tokens': s.total_tokens
        }
    tokens1 = get_token_counts(s1)
    tokens2 = get_token_counts(s2)
    token_diff = {}
    for key in tokens1:
        diff = tokens2[key] - tokens1[key]
        pct = (diff / tokens1[key] * 100) if tokens1[key] != 0 else None
        token_diff[key] = {'diff': diff, 'pct': pct}
    # Tool diff: align by order and name
    tool_calls1 = [msg for msg in msgs1 if msg.get('role') == 'assistant' and 'tool_calls' in msg]
    tool_calls2 = [msg for msg in msgs2 if msg.get('role') == 'assistant' and 'tool_calls' in msg]
    tool_diff = []
    for i, (tc1, tc2) in enumerate(zip(tool_calls1, tool_calls2)):
        if tc1['tool_calls'][0]['function']['name'] == tc2['tool_calls'][0]['function']['name']:
            # Aligned
            args1 = tc1['tool_calls'][0]['function']['arguments']
            args2 = tc2['tool_calls'][0]['function']['arguments']
            diff = list(difflib.unified_diff(args1.splitlines(), args2.splitlines(), lineterm=''))
            tool_diff.append({
                'index': i,
                'name': tc1['tool_calls'][0]['function']['name'],
                'aligned': True,
                'args_diff': diff,
                'result1': tc1.get('content', '')[:500],
                'result2': tc2.get('content', '')[:500]
            })
        else:
            tool_diff.append({
                'index': i,
                'name1': tc1['tool_calls'][0]['function']['name'],
                'name2': tc2['tool_calls'][0]['function']['name'],
                'aligned': False
            })
    # Reasoning diff
    reasoning1 = [msg.get('reasoning', '') for msg in msgs1 if msg.get('reasoning')]
    reasoning2 = [msg.get('reasoning', '') for msg in msgs2 if msg.get('reasoning')]
    reasoning_diff = []
    for i, (r1, r2) in enumerate(zip(reasoning1, reasoning2)):
        diff = list(difflib.unified_diff(r1.splitlines(), r2.splitlines(), lineterm=''))
        reasoning_diff.append({'index': i, 'diff': diff})
    # Final response diff
    final1 = msgs1[-1]['content'] if msgs1 else ''
    final2 = msgs2[-1]['content'] if msgs2 else ''
    final_diff = list(difflib.unified_diff(final1.splitlines(), final2.splitlines(), lineterm=''))
    # Check if diff is too large
    total_size = len(json.dumps({
        'token_diff': token_diff,
        'tool_diff': tool_diff,
        'reasoning_diff': reasoning_diff,
        'final_diff': final_diff
    }, default=str))
    if total_size > 1_000_000:
        # Provide download link instead
        return {
            'too_large': True,
            'download_url': f'/api/compare/download?s1={s1}&s2={s2}&max_messages={max_messages}'
        }
    return {
        'session1': {'id': s1, 'messages': msgs1},
        'session2': {'id': s2, 'messages': msgs2},
        'diff': {
            'token_diff': token_diff,
            'tool_diff': tool_diff,
            'reasoning_diff': reasoning_diff,
            'final_diff': final_diff
        }
    }

@app.route('/api/compare/download')
def download_comparison():
    s1 = request.args.get('s1')
    s2 = request.args.get('s2')
    max_messages = request.args.get('max_messages', 0, type=int)
    result = _compute_comparison(s1, s2, max_messages)
    return jsonify(result)

@app.route('/compare')
def compare_page():
    s1 = request.args.get('s1')
    s2 = request.args.get('s2')
    return render_template('compare.html', s1=s1, s2=s2)

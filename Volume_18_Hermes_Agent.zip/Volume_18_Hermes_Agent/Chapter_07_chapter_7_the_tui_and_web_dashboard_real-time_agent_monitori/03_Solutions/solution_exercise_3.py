
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# In cli.py, within HermesCLI class

from collections import deque
import time
from prompt_toolkit.buffer import Buffer
from prompt_toolkit.layout.controls import FormattedTextControl
from prompt_toolkit.layout.containers import Window, ConditionalContainer, HSplit, VSplit
from prompt_toolkit.key_binding import KeyBindings

def __init__(self, ...):
    super().__init__(...)
    self._timeline_events = deque(maxlen=50)
    self._timeline_visible = False
    self._timeline_buffer = Buffer(read_only=True)
    self._timeline_text = ""

def _setup_timeline_callbacks(self):
    """Attach callbacks to agent events."""
    agent = self.agent
    original_tool_cb = agent.tool_progress_callback
    def tool_cb(event, **kwargs):
        if event == "tool.started":
            self._add_timeline_event("tool", kwargs.get('name'), is_error=False, duration=0)
        elif event == "tool.completed":
            self._add_timeline_event("tool", kwargs.get('name'), is_error=kwargs.get('error', False), duration=kwargs.get('duration', 0))
        if original_tool_cb:
            original_tool_cb(event, **kwargs)
    agent.tool_progress_callback = tool_cb

    original_stream_cb = agent.stream_delta_callback
    def stream_cb(delta, done=False):
        if done:
            self._add_timeline_event("text", "Response", is_error=False, duration=0)
        if original_stream_cb:
            original_stream_cb(delta, done)
    agent.stream_delta_callback = stream_cb

    original_think_cb = agent.thinking_callback
    def think_cb(started):
        if started:
            self._add_timeline_event("thinking", "Reasoning started", is_error=False, duration=0)
        else:
            self._add_timeline_event("thinking", "Reasoning ended", is_error=False, duration=0)
        if original_think_cb:
            original_think_cb(started)
    agent.thinking_callback = think_cb

def _add_timeline_event(self, event_type, content, is_error, duration):
    """Add an event to the timeline deque and update buffer text."""
    timestamp = time.monotonic()
    self._timeline_events.append({
        'type': event_type,
        'timestamp': timestamp,
        'content': content,
        'is_error': is_error,
        'duration': duration
    })
    self._rebuild_timeline_text()
    # Auto-scroll to bottom
    if self._timeline_visible:
        self._timeline_buffer.cursor_position = len(self._timeline_buffer.text)
    self.app.invalidate()

def _rebuild_timeline_text(self):
    """Build formatted text from events."""
    lines = []
    start_time = self._timeline_events[0]['timestamp'] if self._timeline_events else time.monotonic()
    for ev in self._timeline_events:
        elapsed = ev['timestamp'] - start_time
        emoji = {"tool": "🔧", "text": "📝", "thinking": "💭"}.get(ev['type'], "❓")
        dur_str = f"{ev['duration']:.1f}s" if ev['duration'] > 0 else ""
        status = "❌" if ev['is_error'] else "✅"
        line = f"{emoji} {status} {elapsed:.1f}s – {ev['content']} {dur_str}\n"
        lines.append(line)
    self._timeline_text = ''.join(lines)
    self._timeline_buffer.text = self._timeline_text

def _build_timeline_widget(self):
    """Return a ConditionalContainer for the timeline."""
    timeline_window = Window(
        content=BufferControl(buffer=self._timeline_buffer),
        height=Dimension(preferred=10, max=20),
        wrap_lines=False,
        scrollbar=True
    )
    return ConditionalContainer(
        content=timeline_window,
        filter=Condition(lambda: self._timeline_visible)
    )

def process_command(self, command):
    if command == 'timeline':
        self._timeline_visible = not self._timeline_visible
        self._print_message("⏱ Timeline view toggled. Use /timeline again to hide.")
        return True
    return super().process_command(command)

def run(self):
    # In layout, replace image_bar and input_rule_top with timeline when visible
    # Assume layout is built in _build_tui_layout_children
    # We'll modify that method to include timeline
    pass

# In _build_tui_layout_children, after the input area:
def _build_tui_layout_children(self):
    children = super()._build_tui_layout_children()
    # Find indices of image_bar and input_rule_top (assuming they are in children)
    # For simplicity, we'll insert timeline before the input area
    # Actually, we need to replace them conditionally. Better to create a new layout.
    # Simplified: add timeline as a separate container that appears above input.
    timeline_container = self._build_timeline_widget()
    children.insert(-1, timeline_container)  # before input area
    return children

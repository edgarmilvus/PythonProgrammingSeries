
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script.py
# Description: Advanced Integration Script
# ==========================================

#!/usr/bin/env python3
"""
hermes_integration_orchestrator.py

Production-grade script demonstrating advanced agent integration:
1. Persistent memory loading across sessions
2. Dynamic toolset configuration based on context
3. Callback-driven monitoring for closed-loop analysis
4. Stateful error handling with automatic retry thresholds
5. Audit logging for every tool invocation
"""

import json
import time
import logging
import sys
import os
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional, Callable
from run_agent import AIAgent  # The core Hermes Agent class
from hermes_state import SessionDB  # SQLite session store for persistence
from agent.memory_manager import build_memory_context_block  # Memory injection
from agent.display import get_tool_emoji, build_tool_preview  # UI helpers

# -------------------------------------------------------------------
# Configure structured logging. In production, this goes to a log shipper.
# -------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)-8s | %(threadName)s | %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        # In production, add a RotatingFileHandler here.
    ]
)
logger = logging.getLogger("Orchestrator")

# -------------------------------------------------------------------
# Helper: Load a persistent persona from a JSON file.
# This simulates reading a "role card" that defines the agent's behaviour.
# -------------------------------------------------------------------
def load_agent_role(card_path: str = "architect_role.json") -> Dict[str, Any]:
    """
    Load a structured "role card" that defines system prompt, allowed tools,
    and behavioural rules for the agent. This replaces hardcoding a system prompt.
    """
    path = Path(card_path)
    if not path.exists():
        logger.warning(f"Role card '{card_path}' not found. Using default architect profile.")
        return {
            "persona": "Senior Software Architect",
            "system_prompt": (
                "You are a Senior Software Architect. You review code for correctness, "
                "scalability, and security. You ALWAYS explain your reasoning step-by-step "
                "before concluding."
            ),
            "allowed_toolsets": ["web", "file", "terminal"],
            "max_turns": 30,
        }
    with open(path, 'r') as f:
        data = json.load(f)
        logger.info(f"Loaded role card: {data.get('persona', 'Unknown')}")
        return data


# -------------------------------------------------------------------
# Callback Hook: Track every tool call for auditing and latency analysis.
# This is the cornerstone of the "closed learning loop" — we record what
# tools were called, how long they took, and whether they succeeded.
# The data feeds back into the agent's memory for self-improvement.
# -------------------------------------------------------------------
class ToolAuditor:
    """
    Observes tool invocations and captures telemetry.
    This class can be extended to push events to a monitoring system (e.g., Datadog).
    """

    def __init__(self, session_id: str):
        self.session_id = session_id
        self.tool_history: List[Dict[str, Any]] = []
        self._current_tool_name: Optional[str] = None
        self._current_tool_start: float = 0.0

    def on_tool_started(self, function_name: str, scope: Dict[str, Any]) -> None:
        """Called by the agent when a tool begins execution."""
        self._current_tool_name = function_name
        self._current_tool_start = time.monotonic()
        logger.info(f"[AUDIT] [{self.session_id}] Tool '{function_name}' started with args scope: {list(scope.keys())}")

    def on_tool_completed(self, function_name: str, duration: float, is_error: bool) -> None:
        """Called by the agent immediately after a tool finishes."""
        record = {
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "session_id": self.session_id,
            "tool_name": function_name,
            "duration_seconds": round(duration, 4),
            "is_error": is_error,
        }
        self.tool_history.append(record)
        logger.info(
            f"[AUDIT] Tool '{function_name}' finished in {duration:.2f}s | "
            f"Error: {is_error} | Total tools so far: {len(self.tool_history)}"
        )
        self._current_tool_name = None

    def get_telemetry_summary(self) -> Dict[str, Any]:
        """Aggregate telemetry for the session: counts, avg latency, error rate."""
        if not self.tool_history:
            return {"message": "No tool calls recorded"}
        total = len(self.tool_history)
        errors = sum(1 for t in self.tool_history if t["is_error"])
        avg_duration = sum(t["duration_seconds"] for t in self.tool_history) / total
        return {
            "total_tool_calls": total,
            "error_count": errors,
            "error_rate_pct": round(100 * errors / total, 2),
            "average_duration_seconds": round(avg_duration, 4),
            "unique_tools": len(set(t["tool_name"] for t in self.tool_history)),
        }


# -------------------------------------------------------------------
# Core Integration Script
# -------------------------------------------------------------------
def main():
    """
    Main execution path for the integration script.
    Demonstrates a complete lifecycle: initialize, load state, execute, persist.
    """

    # ---- Step 1: Load the agent's role and session context ----
    role = load_agent_role()
    system_prompt_override = role.get("system_prompt")
    enabled_tools = role.get("allowed_toolsets", ["web", "file"])

    logger.info(f"Initializing agent with persona: {role.get('persona', 'Generic')}")
    logger.info(f"Enabled toolsets: {', '.join(enabled_tools)}")

    # ---- Step 2: Initialize the Hermes Agent with production settings ----
    agent = AIAgent(
        model="anthropic/claude-sonnet-4-6-20250222",
        provider="openrouter",
        base_url="https://openrouter.ai/api/v1",
        model_context_length=0,  # Let auto-detection work
        max_iterations=role.get("max_turns", 25),
        enabled_toolsets=enabled_tools,
        quiet_mode=True,              # Suppress console spinner for output parsing
        verbose_logging=False,        # Keep logs clean; use auditor for details
        skip_context_files=False,     # Load .cursorrules and AGENTS.md from cwd
        session_db=SessionDB(),       # Enable SQLite persistence
        api_key=os.environ.get("OPENROUTER_API_KEY"),
    )

    logger.info(f"Agent initialized with session_id: {agent.session_id}")

    # ---- Step 3: Wire up the Tool Auditor for closed-loop monitoring ----
    auditor = ToolAuditor(session_id=agent.session_id)

    def callback_tool_start(function_name: str, preview: str, args: Dict) -> None:
        auditor.on_tool_started(function_name, args)

    def callback_tool_complete(function_name: str, duration: float, is_error: bool) -> None:
        auditor.on_tool_completed(function_name, duration, is_error)

    # Assign the callbacks to the agent.
    # These are fired for every tool invocation, forming the data collection layer.
    agent.tool_progress_callback = callback_tool_start, callback_tool_complete

    logger.info("Tool auditor callbacks attached.")

    # ---- Step 4: Load persistent memory from the last session (if any) ----
    # This demonstrates the "memory persistence" requirement.
    # We query the SQLite database for the most recent session by this agent
    # (e.g., same source key) and inject its title/context as a memory block.
    previous_session_context = ""
    try:
        db = agent._session_db
        # Look for sessions that share this source (e.g., "ci-pipeline").
        # This is a bespoke query using the underlying SQLite connection.
        cursor = db._conn.execute(
            """
            SELECT id, title, model, started_at
            FROM sessions
            WHERE source = 'ci-pipeline'
            ORDER BY started_at DESC
            LIMIT 1
            """
        )
        row = cursor.fetchone()
        if row:
            prev_id, prev_title, prev_model, prev_time = row
            previous_session_context = (
                f"[Previous session: id='{prev_id}', title='{prev_title}', "
                f"model='{prev_model}', started at '{prev_time}']"
            )
            logger.info(f"Loaded memory from previous session: {prev_title}")
    except Exception as e:
        logger.warning(f"Could not load previous session context: {e}")

    # Build the system prompt with memory injection.
    # The `build_memory_context_block` function wraps context in a stable,
    # scannable block format that the agent can easily parse.
    memory_block = build_memory_context_block(previous_session_context) if previous_session_context else ""
    full_system_prompt = f"{system_prompt_override}\n{memory_block}".strip() if system_prompt_override else memory_block

    # ---- Step 5: Define the user task ----
    # This is a realistic task for a "Smart Review" agent.
    user_task = (
        "Review the codebase in /tmp/my_project. Focus on the `arch` folder. "
        "Identify any security anti-patterns, architectural inconsistencies, "
        "and suggest a refactoring plan. Use `search_files` to find relevant "
        "files, then `read_file` to inspect them. If you need to check "
        "external references, use `web_search`. DO NOT execute any code."
    )

    logger.info(f"Starting task execution: '{user_task[:80]}...'")

    # ---- Step 6: Execute the conversation with full instrumentation ----
    start_wall_time = time.time()
    result = agent.run_conversation(
        user_message=user_task,
        system_message=full_system_prompt,  # This overrides the default system prompt
        task_id="architect-review-2025-01-15",  # Deterministic task ID for idempotency
        stream_callback=None,  # No streaming in batch mode; we want a clean result
    )
    execution_duration = time.time() - start_wall_time

    # ---- Step 7: Process results and persist audit trail ----
    final_response = result.get("final_response", "")
    api_calls = result.get("api_calls", 0)
    completed = result.get("completed", False)
    telemetry = auditor.get_telemetry_summary()

    logger.info(f"Task execution finished in {execution_duration:.2f}s.")
    logger.info(f"API calls made: {api_calls}")
    logger.info(f"Conversation completed successfully: {completed}")
    logger.info(f"Telemetry: {json.dumps(telemetry, indent=2)}")

    # ---- Step 8 (Optional): Save the audit report to a JSON file ----
    # This report can be consumed by a dashboard or a CI/CD pipeline.
    audit_report = {
        "session_id": agent.session_id,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "task": user_task,
        "final_response_preview": final_response[:500] + "..." if final_response else "(empty)",
        "execution_seconds": round(execution_duration, 2),
        "api_calls": api_calls,
        "completed": completed,
        "tool_telemetry": telemetry,
    }
    report_path = Path(f"/tmp/hermes_audit_{agent.session_id}.json")
    with open(report_path, 'w') as f:
        json.dump(audit_report, f, indent=2)
    logger.info(f"Audit report saved to: {report_path}")

    # ---- Step 9: Example of explicit memory write ----
    # After a successful review, we can persist what we learned.
    # This simulates the "closed learning loop" — the agent saves a note
    # that its future self will read.
    if completed and final_response:
        try:
            from tools.memory_tool import memory_tool
            memory_tool(
                action="add",
                target="memory",
                content=f"[Architecture Review] Completed review of /tmp/my_project. Found {telemetry['error_count']} potential issues across {telemetry['unique_tools']} tools. Result: {final_response[:200]}",
                store=agent._memory_store,
            )
            logger.info("Persisted review memory for future sessions.")
        except Exception as e:
            logger.warning(f"Memory write failed (non-fatal): {e}")

    logger.info("Integration script finished successfully.")
    return audit_report


# -------------------------------------------------------------------
# Entry point. Supports both direct execution and cron/CI invocation.
# -------------------------------------------------------------------
if __name__ == "__main__":
    exit_code = 0
    try:
        report = main()
        print("=" * 50)
        print("AUDIT REPORT SUMMARY")
        print(json.dumps(report, indent=2))
        print("=" * 50)
    except Exception as e:
        logger.critical(f"Unhandled exception in integration script: {e}", exc_info=True)
        exit_code = 1
    sys.exit(exit_code)

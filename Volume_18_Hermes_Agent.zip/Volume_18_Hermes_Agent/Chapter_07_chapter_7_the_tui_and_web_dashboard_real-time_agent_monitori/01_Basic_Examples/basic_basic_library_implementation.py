
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation.py
# Description: Basic Library Implementation
# ==========================================

#!/usr/bin/env python3
"""
AgentMonitor - A monitoring library for the Hermes AI Agent.

Provides real-time visibility into agent state: token usage,
tool execution, reasoning blocks, streaming responses, and
session metadata. Designed to be the data backend for both
Terminal User Interface (TUI) and Web Dashboard frontends.

Usage:
    monitor = AgentMonitor(agent, hermes_cli)
    monitor.on_tool_start("web_search", {"query": "Python 3.13"})
    monitor.on_tool_complete("web_search", duration=2.3, is_error=False)
    status = monitor.build_status_bar()
    print(status["model_short"], status["context_percent"])
"""

from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from pathlib import Path
import json
import time
import logging

logger = logging.getLogger(__name__)

# Import real Hermes classes from the source
from run_agent import AIAgent, IterationBudget
from hermes_constants import get_hermes_home
from hermes_cli.banner import _format_context_length
from agent.usage_pricing import (
    CanonicalUsage,
    estimate_usage_cost,
    format_duration_compact,
    format_token_count_compact,
)
from agent.display import (
    KavaiSpinner,
    get_tool_emoji,
    build_tool_preview,
    get_cute_tool_message,
)
from agent.memory_manager import StreamingContextScrubber
from agent.think_scrubber import StreamingThinkScrubber
from hermes_state import SessionDB
from utils import base_url_host_matches


@dataclass
class MonitorLogEntry:
    """A single event entry in the monitoring log buffer."""
    timestamp: datetime = field(default_factory=datetime.now)
    event_type: str = ""  # "tool.started", "tool.completed", "reasoning", "stream_delta", "api_call"
    tool_name: str = ""
    preview: str = ""
    duration: float = 0.0
    is_error: bool = False
    token_count: int = 0
    reasoning_text: str = ""
    stream_delta: str = ""


class AgentMonitor:
    """
    Centralized monitoring façade for Hermes Agent sessions.

    Collects callbacks from AIAgent and HermesCLI, normalizes them
    into structured log entries, and exposes methods for downstream
    consumers (TUI, WebSocket, file logger).

    Thread-safe for concurrent access from agent execution threads
    and the TUI render loop.
    """

    STATE_FRESH = "fresh"
    STATE_STREAMING = "streaming"
    STATE_TOOL_EXECUTING = "tool_executing"
    STATE_IDLE = "idle"
    STATE_ERROR = "error"

    def __init__(
        self,
        agent: Optional[AIAgent] = None,
        hermes_cli_ref: Optional[object] = None,
        max_log_entries: int = 500,
        enable_reasoning_capture: bool = True,
        enable_stream_capture: bool = True,
    ):
        """
        Initialize the monitor.

        Args:
            agent: Reference to the AIAgent instance being monitored.
            hermes_cli_ref: Reference to the HermesCLI instance for UI state.
            max_log_entries: Maximum number of log entries to keep in memory.
            enable_reasoning_capture: Whether to store reasoning text in log.
            enable_stream_capture: Whether to store stream deltas in log.
        """
        self.agent = agent
        self.cli = hermes_cli_ref
        self._log: List[MonitorLogEntry] = []
        self._max_log = max(max_log_entries, 100)

        # Streaming scrubbers (carried over from HermesCLI for continuity)
        self._stream_context_scrubber = StreamingContextScrubber()
        self._stream_think_scrubber = StreamingThinkScrubber()

        # Current agent state
        self._state = self.STATE_FRESH
        self._current_tool_name: Optional[str] = None
        self._current_tool_start: float = 0.0
        self._current_tool_args: Dict[str, Any] = {}
        self._reasoning_buf: str = ""
        self._stream_buf: str = ""

        # Snapshot of the latest status bar values
        self._status_cache: Dict[str, Any] = {
            "model_short": "",
            "context_percent": None,
            "context_tokens": 0,
            "context_length": None,
            "compressions": 0,
            "duration": "0s",
            "prompt_elapsed": "0s",
            "session_api_calls": 0,
            "session_total_tokens": 0,
            "session_input_tokens": 0,
            "session_output_tokens": 0,
            "session_cache_read_tokens": 0,
            "session_cache_write_tokens": 0,
        }

        # Session database for persistence (used by /insights and /usage)
        self._session_db: Optional[SessionDB] = None
        try:
            self._session_db = SessionDB()
        except Exception as e:
            logger.warning("SessionDB unavailable for monitoring: %s", e)

        # Activity tracking for gateway timeout handlers
        self._last_activity_ts: float = time.time()
        self._last_activity_desc: str = "initialized"

        # Callback registries for frontend integration
        self._on_state_change: Optional[callable] = None
        self._on_log_entry: Optional[callable] = None

    # ------------------------------------------------------------------
    # Lifecycle methods
    # ------------------------------------------------------------------

    def attach_agent(self, agent: AIAgent) -> None:
        """Bind to an AIAgent and wire its callbacks through the monitor."""
        self.agent = agent
        # Intercept the agent's existing callbacks — we pass our own wrappers
        # that forward to the original callback after logging.
        self._original_tool_progress = getattr(agent, "tool_progress_callback", None)
        self._original_stream_delta = getattr(agent, "stream_delta_callback", None)
        self._original_reasoning = getattr(agent, "reasoning_callback", None)
        self._original_tool_start = getattr(agent, "tool_start_callback", None)
        self._original_tool_complete = getattr(agent, "tool_complete_callback", None)

        agent.tool_progress_callback = self._tool_progress_wrapper
        agent.stream_delta_callback = self._stream_delta_wrapper
        agent.reasoning_callback = self._reasoning_wrapper
        agent.tool_start_callback = self._tool_start_wrapper
        agent.tool_complete_callback = self._tool_complete_wrapper

        self._state = self.STATE_IDLE
        self._touch_activity("agent attached")

    def detach(self) -> None:
        """Restore original callbacks and release references."""
        if self.agent is None:
            return
        self.agent.tool_progress_callback = self._original_tool_progress
        self.agent.stream_delta_callback = self._original_stream_delta
        self.agent.reasoning_callback = self._original_reasoning
        self.agent.tool_start_callback = self._original_tool_start
        self.agent.tool_complete_callback = self._original_tool_complete
        self._original_tool_progress = None
        self._original_stream_delta = None
        self._original_reasoning = None
        self._original_tool_start = None
        self._original_tool_complete = None
        self.agent = None
        self._state = self.STATE_FRESH
        self._touch_activity("detached")

    # ------------------------------------------------------------------
    # Activity tracking (used by gateway timeout watcher)
    # ------------------------------------------------------------------

    def _touch_activity(self, desc: str) -> None:
        """Update the last-activity timestamp and description."""
        self._last_activity_ts = time.time()
        self._last_activity_desc = desc

    def get_activity_summary(self) -> Dict[str, Any]:
        """Return a snapshot for diagnostics / heartbeat feeds."""
        elapsed = time.time() - self._last_activity_ts
        return {
            "last_activity_ts": self._last_activity_ts,
            "last_activity_desc": self._last_activity_desc,
            "seconds_since_activity": round(elapsed, 1),
            "state": self._state,
            "current_tool": self._current_tool_name,
        }

    # ------------------------------------------------------------------
    # Status bar snapshot (mirrors HermesCLI._get_status_bar_snapshot)
    # ------------------------------------------------------------------

    def refresh_status_cache(self) -> None:
        """Pull the latest live values from the agent and CLI references.

        This is called periodically by the TUI render loop or on demand
        by the web dashboard via a REST endpoint.
        """
        agent = self.agent
        cli = self.cli
        cache = self._status_cache

        # Model short name
        model_name = getattr(agent, "model", None) or getattr(cli, "model", "unknown")
        model_short = model_name.split("/")[-1] if "/" in model_name else model_name
        if model_short.endswith(".gguf"):
            model_short = model_short[:-5]
        cache["model_short"] = model_short[:26] if len(model_short) > 26 else model_short

        # Session duration (from start or fresh)
        session_start = getattr(cli, "session_start", None) or getattr(agent, "session_start", datetime.now())
        elapsed_seconds = max(0.0, (datetime.now() - session_start).total_seconds())
        cache["duration"] = format_duration_compact(elapsed_seconds)

        # Prompt elapsed (time since last user message sent)
        prompt_start = getattr(cli, "_prompt_start_time", None) if cli else None
        if prompt_start is not None:
            cache["prompt_elapsed"] = self._format_elapsed(time.time() - prompt_start)
        else:
            frozen = getattr(cli, "_prompt_duration", 0.0) if cli else 0.0
            cache["prompt_elapsed"] = self._format_elapsed(frozen)

        # Token counters
        cache["session_api_calls"] = getattr(agent, "session_api_calls", 0) or 0
        cache["session_total_tokens"] = getattr(agent, "session_total_tokens", 0) or 0
        cache["session_input_tokens"] = getattr(agent, "session_input_tokens", 0) or 0
        cache["session_output_tokens"] = getattr(agent, "session_output_tokens", 0) or 0
        cache["session_cache_read_tokens"] = getattr(agent, "session_cache_read_tokens", 0) or 0
        cache["session_cache_write_tokens"] = getattr(agent, "session_cache_write_tokens", 0) or 0

        # Context compressor state
        compressor = getattr(agent, "context_compressor", None) if agent else None
        if compressor:
            context_tokens = getattr(compressor, "last_prompt_tokens", 0) or 0
            context_length = getattr(compressor, "context_length", 0) or 0
            cache["context_tokens"] = context_tokens
            cache["context_length"] = context_length or None
            cache["compressions"] = getattr(compressor, "compression_count", 0) or 0
            if context_length:
                cache["context_percent"] = max(0, min(100, round((context_tokens / context_length) * 100)))
        else:
            cache["context_tokens"] = 0
            cache["context_length"] = None
            cache["context_percent"] = None
            cache["compressions"] = 0

    def build_status_bar_text(self, width: Optional[int] = None) -> str:
        """Return a compact one-line status string for TUI footer or WebSocket push.

        Mirrors HermesCLI._build_status_bar_text.
        """
        self.refresh_status_cache()
        cache = self._status_cache
        if width is None:
            width = 80  # fallback

        percent = cache["context_percent"]
        percent_label = f"{percent}%" if percent is not None else "--"
        duration_label = cache["duration"]

        if width < 52:
            text = f"⚕ {cache['model_short']} · {duration_label}"
            return self._trim_text(text, width)

        if width < 76:
            parts = [f"⚕ {cache['model_short']}", percent_label]
            compressions = cache.get("compressions", 0)
            if compressions:
                parts.append(f"🗜️ {compressions}")
            parts.append(duration_label)
            return self._trim_text(" · ".join(parts), width)

        if cache["context_length"]:
            ctx_total = _format_context_length(cache["context_length"])
            ctx_used = format_token_count_compact(cache["context_tokens"])
            context_label = f"{ctx_used}/{ctx_total}"
        else:
            context_label = "ctx --"

        compressions = cache.get("compressions", 0)
        parts = [f"⚕ {cache['model_short']}", context_label, percent_label]
        if compressions:
            parts.append(f"🗜️ {compressions}")
        parts.append(duration_label)
        prompt_elapsed = cache.get("prompt_elapsed")
        if prompt_elapsed:
            parts.append(prompt_elapsed)
        return self._trim_text(" │ ".join(parts), width)

    @staticmethod
    def _format_elapsed(elapsed: float) -> str:
        """Format seconds into a human-readable '⏱ 2m 15s' style string."""
        if elapsed <= 0:
            return "⏲ 0s"
        days = int(elapsed // 86400)
        remaining = elapsed % 86400
        hours = int(remaining // 3600)
        remaining = remaining % 3600
        minutes = int(remaining // 60)
        seconds = int(remaining % 60)

        if days > 0:
            time_str = f"{days}d {hours}h {minutes}m"
        elif hours > 0:
            time_str = f"{hours}h {minutes}m {seconds}s" if seconds else f"{hours}h {minutes}m"
        elif minutes > 0:
            time_str = f"{minutes}m {seconds}s" if seconds else f"{minutes}m"
        else:
            time_str = f"{int(elapsed)}s"
        return f"⏲ {time_str}"

    @staticmethod
    def _trim_text(text: str, max_width: int) -> str:
        """Truncate text to fit within *max_width* cells, adding '...' if needed."""
        if max_width <= 0:
            return ""
        # Simple len-based trimming (get_cwidth would be more accurate but fine here)
        if len(text) <= max_width:
            return text
        ellipsis = "..."
        if max_width <= len(ellipsis):
            return ellipsis[:max_width]
        return text[: max_width - len(ellipsis)] + ellipsis

    # ------------------------------------------------------------------
    # Tool progress logging
    # ------------------------------------------------------------------

    def log_tool_call(
        self,
        event_type: str,
        tool_name: str,
        preview: str,
        args: Optional[Dict] = None,
        duration: float = 0.0,
        is_error: bool = False,
    ) -> None:
        """
        Record a tool call event in the monitoring log.

        event_type is one of "tool.started", "tool.completed".
        """
        entry = MonitorLogEntry(
            event_type=event_type,
            tool_name=tool_name,
            preview=preview,
            duration=duration,
            is_error=is_error,
        )
        self._append_log(entry)

        if event_type == "tool.started":
            self._state = self.STATE_TOOL_EXECUTING
            self._current_tool_name = tool_name
            self._current_tool_start = time.time()
            self._current_tool_args = args or {}
            self._touch_activity(f"tool started: {tool_name}")
        elif event_type == "tool.completed":
            self._state = self.STATE_IDLE
            self._current_tool_name = None
            self._touch_activity(f"tool completed: {tool_name} ({duration:.1f}s)")

    def log_reasoning(self, text: str) -> None:
        """Accumulate reasoning/thinking deltas into a single entry."""
        if not text:
            return
        self._reasoning_buf += text
        # Emit when we have a complete sentence or buffer exceeds 200 chars
        if len(self._reasoning_buf) >= 200 or text.rstrip().endswith((".", "!", "?")):
            entry = MonitorLogEntry(
                event_type="reasoning",
                reasoning_text=self._reasoning_buf.strip(),
            )
            self._append_log(entry)
            self._reasoning_buf = ""

    def log_stream_delta(self, text: str) -> None:
        """Accumulate streaming text deltas for display."""
        if not text:
            return
        # Feed through stateful scrubbers (same as HermesCLI logic)
        text = self._stream_think_scrubber.feed(text)
        text = self._stream_context_scrubber.feed(text)
        if not text:
            return
        self._stream_buf += text
        # Flush on newline or every 500ms of accumulated chars
        if "\n" in self._stream_buf or len(self._stream_buf) >= 500:
            entry = MonitorLogEntry(
                event_type="stream_delta",
                stream_delta=self._stream_buf,
            )
            self._append_log(entry)
            self._stream_buf = ""

    def flush_stream_buf(self) -> None:
        """Force-flush any remaining stream buffer on turn end."""
        if self._stream_buf:
            entry = MonitorLogEntry(
                event_type="stream_delta",
                stream_delta=self._stream_buf,
            )
            self._append_log(entry)
            self._stream_buf = ""
        # Also flush reasoning buffer
        if self._reasoning_buf:
            entry = MonitorLogEntry(
                event_type="reasoning",
                reasoning_text=self._reasoning_buf.strip(),
            )
            self._append_log(entry)
            self._reasoning_buf = ""

    def log_api_call(
        self,
        prompt_tokens: int,
        completion_tokens: int,
        model: str,
        provider: str,
        duration: float,
    ) -> None:
        """Record an API call with its token usage."""
        entry = MonitorLogEntry(
            event_type="api_call",
            preview=f"{model} ({provider})",
            duration=duration,
            token_count=prompt_tokens + completion_tokens,
        )
        self._append_log(entry)
        self._touch_activity(f"API call: {prompt_tokens} in / {completion_tokens} out")

    # ------------------------------------------------------------------
    # Log management
    # ------------------------------------------------------------------

    def _append_log(self, entry: MonitorLogEntry) -> None:
        """Append a log entry, respecting the max size limit."""
        self._log.append(entry)
        if len(self._log) > self._max_log:
            self._log.pop(0)
        if self._on_log_entry:
            try:
                self._on_log_entry(entry)
            except Exception:
                pass

    def get_log_since(self, since: Optional[datetime] = None) -> List[MonitorLogEntry]:
        """Return all log entries after a given timestamp (or all if None)."""
        if since is None:
            return list(self._log)
        return [e for e in self._log if e.timestamp >= since]

    def clear_log(self) -> None:
        """Clear the in-memory log buffer."""
        self._log.clear()

    def latest_entry(
        self, event_type: Optional[str] = None
    ) -> Optional[MonitorLogEntry]:
        """Return the most recent log entry, optionally filtered by type."""
        if not self._log:
            return None
        if event_type is None:
            return self._log[-1]
        for entry in reversed(self._log):
            if entry.event_type == event_type:
                return entry
        return None

    # ------------------------------------------------------------------
    # Tool call summary for user-facing hints (e.g. "🔎 Searched the web")
    # ------------------------------------------------------------------

    def tool_call_hint(self, event_type: str, tool_name: str, duration: float, result: str = "") -> str:
        """Return a user-friendly one-line summary of a tool call.

        Uses the same emoji and formatting as HermesCLI's tool progress.
        """
        try:
            return get_cute_tool_message(tool_name, self._current_tool_args, duration, result=result)
        except Exception:
            emoji = get_tool_emoji(tool_name, default="⚡")
            return f"{emoji} {tool_name} ({duration:.1f}s)"

    # ------------------------------------------------------------------
    # Session persistence for /insights and /usage
    # ------------------------------------------------------------------

    def persist_session_snapshot(self, session_id: str, messages_count: int, tokens: int) -> None:
        """Persist a monitoring snapshot to the session DB (for /insights)."""
        if not self._session_db:
            return
        try:
            self._session_db.update_token_counts(
                session_id,
                input_tokens=tokens,
                output_tokens=0,
                cache_read_tokens=0,
                cache_write_tokens=0,
                reasoning_tokens=0,
                model=getattr(self.agent, "model", None) if self.agent else None,
                api_call_count=1,
            )
        except Exception as e:
            logger.warning("Persist snapshot failed: %s", e)

    # ------------------------------------------------------------------
    # Callback wrappers (intercept agent callbacks for logging)
    # ------------------------------------------------------------------

    def _tool_progress_wrapper(self, event_type: str, function_name: str, preview: str, function_args: dict = None, **kwargs) -> None:
        """Wrap the agent's tool_progress_callback with monitoring logic."""
        if event_type == "tool.started":
            self._state = self.STATE_TOOL_EXECUTING
            self._current_tool_name = function_name
            self._current_tool_start = time.time()
            self._current_tool_args = function_args or {}
            self.log_tool_call("tool.started", function_name, preview, args=function_args)
        elif event_type == "tool.completed":
            duration = kwargs.get("duration", 0.0)
            is_error = kwargs.get("is_error", False)
            self._state = self.STATE_IDLE
            self._current_tool_name = None
            self.log_tool_call("tool.completed", function_name, preview, duration=duration, is_error=is_error)
            # Update status cache after each tool for near-real-time UI
            self.refresh_status_cache()
        # Forward to the original callback (if any)
        if self._original_tool_progress:
            self._original_tool_progress(event_type, function_name, preview, function_args, **kwargs)

    def _stream_delta_wrapper(self, text: str) -> None:
        """Wrap the agent's stream_delta_callback with logging."""
        if text is None:
            self.flush_stream_buf()
        else:
            self.log_stream_delta(text)
        if self._original_stream_delta:
            self._original_stream_delta(text)

    def _reasoning_wrapper(self, text: str) -> None:
        """Wrap the agent's reasoning_callback with logging."""
        self.log_reasoning(text)
        if self._original_reasoning:
            self._original_reasoning(text)

    def _tool_start_wrapper(self, tool_call_id: str, function_name: str, function_args: dict) -> None:
        """Wrap the agent's tool_start_callback (inline diffs)."""
        self._state = self.STATE_TOOL_EXECUTING
        self._current_tool_name = function_name
        self._touch_activity(f"tool started: {function_name}")
        if self._original_tool_start:
            self._original_tool_start(tool_call_id, function_name, function_args)

    def _tool_complete_wrapper(self, tool_call_id: str, function_name: str, function_args: dict, function_result: str) -> None:
        """Wrap the agent's tool_complete_callback (inline diffs)."""
        self._state = self.STATE_IDLE
        self._current_tool_name = None
        self._touch_activity(f"tool completed: {function_name}")
        if self._original_tool_complete:
            self._original_tool_complete(tool_call_id, function_name, function_args, function_result)

    # ------------------------------------------------------------------
    # Context bar for rich visualization (used by TUI and Web)
    # ------------------------------------------------------------------

    def build_context_bar(self, width: int = 10) -> str:
        """Return a visual bar like '[█████░░░░░]' for context pressure."""
        percent = self._status_cache.get("context_percent")
        safe_percent = max(0, min(100, percent or 0))
        filled = round((safe_percent / 100) * width)
        return f"[{'█' * filled}{'░' * max(0, width - filled)}]"

    def context_style_class(self) -> str:
        """Return a CSS class name for context pressure styling."""
        percent = self._status_cache.get("context_percent")
        if percent is None:
            return "status-bar-dim"
        if percent >= 95:
            return "status-bar-critical"
        if percent > 80:
            return "status-bar-bad"
        if percent >= 50:
            return "status-bar-warn"
        return "status-bar-good"

    # ------------------------------------------------------------------
    # WebSocket-friendly JSON serialization
    # ------------------------------------------------------------------

    def to_json(self, since: Optional[datetime] = None) -> str:
        """Serialize the latest log entries and status snapshot to JSON.

        Suitable for pushing over a WebSocket connection.
        """
        self.refresh_status_cache()
        payload = {
            "status": self._status_cache,
            "state": self._state,
            "activity": self.get_activity_summary(),
            "context_bar": {
                "visual": self.build_context_bar(),
                "style_class": self.context_style_class(),
            },
            "logs": [
                {
                    "timestamp": e.timestamp.isoformat(),
                    "event_type": e.event_type,
                    "tool_name": e.tool_name,
                    "preview": e.preview,
                    "duration": e.duration,
                    "is_error": e.is_error,
                    "token_count": e.token_count,
                    "reasoning_text": e.reasoning_text,
                    "stream_delta": e.stream_delta,
                }
                for e in self.get_log_since(since)
            ],
        }
        return json.dumps(payload, default=str)


# =============================================================================
# Integration example: wiring AgentMonitor into HermesCLI
# =============================================================================

def wire_monitor_to_cli(hermes_cli: "HermesCLI") -> AgentMonitor:
    """
    Create and attach an AgentMonitor to a running HermesCLI instance.

    This function is called once at CLI startup (or gateway session start)
    to enable monitoring for the session's lifetime.
    """
    agent = getattr(hermes_cli, "agent", None)
    if agent is None:
        logger.warning("Cannot wire monitor: HermesCLI has no active agent.")
        return None

    monitor = AgentMonitor(
        agent=agent,
        hermes_cli_ref=hermes_cli,
        enable_reasoning_capture=True,
        enable_stream_capture=True,
    )
    monitor.attach_agent(agent)

    # Store a reference on the CLI so slash commands can access it
    hermes_cli._monitor = monitor
    logger.info("AgentMonitor wired to session %s", getattr(agent, "session_id", "?"))
    return monitor

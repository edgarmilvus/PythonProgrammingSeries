
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation.py
# Description: Basic Library Implementation
# ==========================================

#!/usr/bin/env python3
"""
Example: Basic Library Implementation for Research and CI/CD Agents

This module demonstrates how to instantiate AIAgent with use-case-specific
configurations, register tool sets, and manage the conversation lifecycle.
All code uses real classes and constants from the Hermes Agent repository.
"""

import asyncio
import json
import logging
import os
import sys
from typing import Optional, List, Dict, Any
from pathlib import Path

# Core agent import — this is the primary class we configure
from run_agent import AIAgent, IterationBudget

# Tool system imports — we control which toolsets are available
from model_tools import (
    get_tool_definitions,
    get_toolset_for_tool,
    handle_function_call,
    check_toolset_requirements,
)

# Tool implementations — we import specific tools for each use case
from tools.browser_tool import (
    web_search,
    web_extract,
    browser_click,
    browser_navigate,
    browser_scroll,
    browser_snapshot,
)
from tools.code_tool import execute_code
from tools.git_tool import git_clone, git_commit, git_push, git_status
from tools.terminal_tool import run_terminal_command
from tools.clarify_tool import clarify_request
from tools.read_file_tool import read_file

# Agent internal utilities — used for memory and context management
from agent.memory_manager import build_memory_context_block
from agent.prompt_builder import (
    DEFAULT_AGENT_IDENTITY,
    build_skills_system_prompt,
)
from agent.display import KawaiiSpinner
from agent.tool_guardrails import ToolCallGuardrailConfig

# The Hermes Home directory — where persistent state lives
from hermes_constants import get_hermes_home


logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Configuration Constants
# ---------------------------------------------------------------------------
RESEARCH_MODEL = "claude-opus-4-20250514"      # Best for nuanced synthesis
CI_CD_MODEL = "claude-sonnet-4-20250514"       # Faster, cheaper for scripts
RESEARCH_BASE_URL = "http://localhost:30000/v1"
CI_CD_BASE_URL = "http://localhost:30000/v1"
RESEARCH_API_KEY = os.environ.get("HERMES_RESEARCH_KEY", "")
CI_CD_API_KEY = os.environ.get("HERMES_CICD_KEY", "")

# Research agent needs more iterations to explore multiple sources
RESEARCH_MAX_ITERATIONS = 60
# CI/CD agent should act quickly to avoid delaying deployments
CICD_MAX_ITERATIONS = 25

# ---------------------------------------------------------------------------
# Tool Registration Helpers
# ---------------------------------------------------------------------------

def _register_research_tools() -> List[str]:
    """
    Register toolsets required for deep research workflows.
    
    Returns a list of enabled toolset names that will be passed to AIAgent.
    The agent uses these to discover tool definitions at runtime.
    """
    # We enable web browsing, code execution, file reading, search,
    # and clarifications. The 'core' set includes basic utilities.
    # 'browser' gives us web_search, web_extract, etc.
    # 'code' gives us execute_code for running analysis scripts.
    # 'read' gives us read_file for consuming local documents.
    return [
        "core",          # Basic tools: clarify, think, respond
        "browser",       # Web search and page interaction
        "code",          # Python code execution for data analysis
        "read",          # File reading for consuming research materials
    ]


def _register_cicd_tools() -> List[str]:
    """
    Register toolsets required for CI/CD automation workflows.
    
    Focus on terminal commands, Git operations, deployment scripting,
    and file modifications. We deliberately exclude browser tools
    to reduce latency and security surface area.
    """
    return [
        "core",          # Basic tools: clarify, think, respond
        "terminal",      # Run shell commands (with sandboxing)
        "git",           # Clone, commit, push, status
        "code",          # Execute Python deployment scripts
        "read",          # Read config files and logs
        "write",         # Write deployment configuration patches
    ]


# ---------------------------------------------------------------------------
# Use-Case-Specific Agent Builders
# ---------------------------------------------------------------------------

def build_research_agent(
    session_id: Optional[str] = None,
    verbose: bool = False,
) -> AIAgent:
    """
    Construct an AIAgent configured for autonomous deep research.
    
    This agent is designed to:
    1. Accept a research question or topic
    2. Search multiple web sources iteratively
    3. Execute Python code to analyze gathered data
    4. Synthesize findings into a structured report
    5. Persist research notes to memory for future improvement
    
    Parameters
    ----------
    session_id : str, optional
        Unique session identifier. If omitted, AIAgent generates one.
    verbose : bool
        Enable detailed logging of tool calls and decisions.
    
    Returns
    -------
    AIAgent
        Fully configured agent ready to run a research conversation.
    """
    # Step 1: Determine the toolsets this agent can use.
    # The agent will only invoke tools from these registered sets.
    enabled_tools = _register_research_tools()
    
    # Step 2: Identify any toolset that must be available. If a required
    # toolset's dependencies are missing (e.g., no playwright for browser),
    # check_toolset_requirements will log a warning. The agent still works
    # but may have reduced capability.
    check_toolset_requirements(enabled_tools)
    
    # Step 3: Configure guardrails for tool calls. Research tools like
    # web_search are safe to parallelize; destructive terminal commands
    # are not available, so we use a permissive guardrail config.
    guardrail_config = ToolCallGuardrailConfig(
        max_tool_calls_per_turn=8,        # Allow multiple parallel searches
        allow_destructive_commands=False, # No terminal access in research
        require_approval_for=["write_file"],  # Only need approval for file writes
    )
    
    # Step 4: Build the AIAgent instance with research-appropriate settings.
    agent = AIAgent(
        base_url=RESEARCH_BASE_URL,
        api_key=RESEARCH_API_KEY,
        model=RESEARCH_MODEL,
        provider="openai-compatible",  # Generic OpenAI-compatible endpoint
        api_mode="chat",               # Chat completions API
        max_iterations=RESEARCH_MAX_ITERATIONS,  # Generous budget for exploration
        tool_delay=0.5,                # Brief pause between tool calls
        enabled_toolsets=enabled_tools,
        save_trajectories=verbose,     # Save full conversation trace for debugging
        verbose_logging=verbose,
        quiet_mode=not verbose,
        session_id=session_id,
        # Callbacks for observability (discussed in detail later)
        step_callback=_research_step_callback,
        tool_start_callback=_research_tool_start_callback,
        tool_complete_callback=_research_tool_complete_callback,
        reasoning_callback=_research_reasoning_callback,
    )
    
    logger.info(
        "Research agent created: session=%s, model=%s, tools=%s",
        agent.session_id, agent.model, enabled_tools,
    )
    return agent


def build_cicd_agent(
    session_id: Optional[str] = None,
    verbose: bool = False,
) -> AIAgent:
    """
    Construct an AIAgent configured for CI/CD pipeline automation.
    
    This agent is designed to:
    1. Monitor CI/CD pipeline status and logs
    2. Diagnose build failures by reading error logs
    3. Apply patches to configuration or source files
    4. Execute deployment commands with safety checks
    5. Learn from past failures to improve future deployments
    
    Parameters
    ----------
    session_id : str, optional
        Unique session identifier.
    verbose : bool
        Enable detailed logging.
    
    Returns
    -------
    AIAgent
        Fully configured agent for pipeline automation.
    """
    # Step 1: Register CI/CD toolset with Git and terminal access.
    enabled_tools = _register_cicd_tools()
    check_toolset_requirements(enabled_tools)
    
    # Step 2: Use stricter guardrails for CI/CD.
    # Terminal commands that modify files require explicit checks.
    # Git operations like push are allowed but logged.
    guardrail_config = ToolCallGuardrailConfig(
        max_tool_calls_per_turn=5,         # Sequential execution preferred
        allow_destructive_commands=True,    # Terminal commands allowed
        require_approval_for=[],            # In production, set to ["run_terminal_command"]
        auto_approve_patterns=[
            r"git\s+status",              # Status checks are safe
            r"git\s+log",                 # Log inspection is safe
            r"cat\s+",                    # File reading is safe
            r"echo\s+",                   # Echo is safe
            r"pip\s+install",            # Safe for dependencies
        ],
        deny_patterns=[
            r"rm\s+-rf\s+/",             # Never allow destructive root commands
            r":(){ :\|:& };:",            # Fork bomb prevention
            r"dd\s+if=/dev/zero",         # Disk destruction prevention
        ],
    )
    
    # Step 3: Build the agent with faster iteration and terminal focus.
    agent = AIAgent(
        base_url=CI_CD_BASE_URL,
        api_key=CI_CD_API_KEY,
        model=CI_CD_MODEL,
        provider="openai-compatible",
        api_mode="chat",
        max_iterations=CICD_MAX_ITERATIONS,    # Tighter budget for fast remediations
        tool_delay=0.2,                         # Minimize delay between tool calls
        enabled_toolsets=enabled_tools,
        save_trajectories=True,                 # Always save for post-mortem analysis
        verbose_logging=verbose,
        quiet_mode=not verbose,
        session_id=session_id,
        # Callbacks for monitoring pipeline progress
        step_callback=_cicd_step_callback,
        tool_start_callback=_cicd_tool_start_callback,
        tool_complete_callback=_cicd_tool_complete_callback,
        reasoning_callback=_cicd_reasoning_callback,
    )
    
    logger.info(
        "CI/CD agent created: session=%s, model=%s, tools=%s",
        agent.session_id, agent.model, enabled_tools,
    )
    return agent


# ---------------------------------------------------------------------------
# Callback Implementations (Observability Layer)
# ---------------------------------------------------------------------------

def _research_step_callback(agent: AIAgent, step: Dict[str, Any]) -> None:
    """
    Called after each step in the research conversation loop.
    
    The step dictionary contains the assistant's response, any tool calls
    made, and the current iteration count. We use this to log progress
    and potentially pause or redirect the agent.
    """
    iteration = step.get("iteration", 0)
    tool_calls = step.get("tool_calls", [])
    if tool_calls:
        tool_names = [tc.function.name for tc in tool_calls]
        logger.info(
            "[Research Iteration %d] Calling tools: %s",
            iteration, tool_names,
        )
    else:
        # No tool calls means the agent is generating the final answer
        content_preview = step.get("content", "")[:80]
        logger.info(
            "[Research Iteration %d] Final response: %s...",
            iteration, content_preview,
        )


def _research_tool_start_callback(
    agent: AIAgent,
    tool_name: str,
    tool_args: Dict[str, Any],
) -> None:
    """
    Called immediately before a tool executes.
    
    Useful for displaying progress indicators in a UI or logging
    detailed arguments for debugging.
    """
    # Sanitize arguments for logging: truncate long strings
    safe_args = {k: (v[:200] + "..." if isinstance(v, str) and len(v) > 200 else v)
                 for k, v in tool_args.items()}
    logger.debug(
        "[Research Tool Start] %s(args=%s)",
        tool_name, json.dumps(safe_args),
    )


def _research_tool_complete_callback(
    agent: AIAgent,
    tool_name: str,
    result: Any,
    duration: float,
) -> None:
    """
    Called after a tool finishes execution.
    
    The duration parameter allows us to track performance and detect
    slow operations that may indicate rate limiting or network issues.
    """
    result_preview = str(result)[:120] if result else "(empty)"
    logger.info(
        "[Research Tool Complete] %s completed in %.2fs: %s",
        tool_name, duration, result_preview,
    )


def _research_reasoning_callback(
    agent: AIAgent,
    reasoning_text: str,
) -> None:
    """
    Called when the model emits a reasoning/thinking trace.
    
    This is especially important for deep research, as the model's
    internal reasoning reveals its search strategy and hypothesis
    formation. We can log this to understand the agent's decision
    process.
    """
    # In a production system, you might store reasoning traces
    # in a vector database for later analysis.
    logger.debug("[Research Reasoning] %s", reasoning_text[:500])


# CI/CD callbacks follow the same pattern but with pipeline-specific logging
def _cicd_step_callback(agent: AIAgent, step: Dict[str, Any]) -> None:
    """Log CI/CD pipeline progress and tool usage."""
    iteration = step.get("iteration", 0)
    tool_calls = step.get("tool_calls", [])
    if tool_calls:
        for tc in tool_calls:
            logger.info(
                "[CI/CD Iteration %d] %s(args=%s)",
                iteration,
                tc.function.name,
                tc.function.arguments[:80],
            )


def _cicd_tool_start_callback(
    agent: AIAgent,
    tool_name: str,
    tool_args: Dict[str, Any],
) -> None:
    """Log the start of a CI/CD operation."""
    logger.info("[CI/CD Tool] Starting %s", tool_name)
    # In a real deployment, you might send a status update
    # to a Slack channel or GitHub commit status here.
    _update_pipeline_status(agent.session_id, tool_name, "running")


def _cicd_tool_complete_callback(
    agent: AIAgent,
    tool_name: str,
    result: Any,
    duration: float,
) -> None:
    """Log completion and update pipeline status."""
    success = "error" not in str(result).lower() if result else True
    status = "passed" if success else "failed"
    _update_pipeline_status(agent.session_id, tool_name, status)
    logger.info(
        "[CI/CD Tool] %s %s in %.2fs",
        tool_name, status, duration,
    )


def _cicd_reasoning_callback(
    agent: AIAgent,
    reasoning_text: str,
) -> None:
    """Log the model's diagnostic reasoning for build failures."""
    logger.info("[CI/CD Diagnosis] %s", reasoning_text[:400])


def _update_pipeline_status(
    session_id: str,
    step_name: str,
    status: str,
) -> None:
    """
    Placeholder for sending pipeline status to an external system.
    
    In production, this would POST to your CI/CD webhook endpoint,
    update a GitHub commit status, or send a Slack notification.
    """
    # Example: print to stdout for demonstration purposes.
    # Replace with actual API calls in your deployment.
    print(f"[Pipeline Status] {session_id}: {step_name} -> {status}")


# ---------------------------------------------------------------------------
# Running the Agent: Conversation Lifecycle
# ---------------------------------------------------------------------------

async def run_research_conversation(
    agent: AIAgent,
    research_question: str,
    system_prompt: Optional[str] = None,
) -> str:
    """
    Execute a research conversation with the agent.
    
    This function demonstrates the full lifecycle:
    1. Start the agent's internal loop
    2. Inject the research question
    3. Process tool calls as they are requested
    4. Collect the final synthesized answer
    
    Parameters
    ----------
    agent : AIAgent
        The configured research agent.
    research_question : str
        The topic or question to investigate.
    system_prompt : str, optional
        Custom system prompt to override default identity.
    
    Returns
    -------
    str
        The agent's final synthesized research response.
    """
    # Step 1: Construct the initial user message.
    # The agent receives this as the first input in its conversation loop.
    user_message = {
        "role": "user",
        "content": research_question,
    }
    
    # Step 2: Optional — augment with research directives.
    # This guides the agent's search strategy without overriding
    # the built-in system prompt.
    if "comprehensive" not in research_question.lower():
        user_message["content"] = (
            f"Research the following topic thoroughly. "
            f"Use web searches to gather information from multiple sources, "
            f"cross-validate facts, and synthesize a well-structured report. "
            f"Include citations and note any conflicting information.\n\n"
            f"Topic: {research_question}"
        )
    
    # Step 3: Run the conversation.
    # AIAgent.run_conversation() handles the entire loop:
    #   - Sends the user message to the LLM
    #   - Processes any tool call requests from the model
    #   - Executes tools and sends results back
    #   - Repeats until a final answer is produced
    #   - Returns the final response text
    try:
        final_response = agent.run_conversation(
            message=user_message["content"],
            system_prompt=system_prompt,
        )
        logger.info(
            "Research complete for session %s. Response length: %d chars",
            agent.session_id,
            len(final_response),
        )
        return final_response
    
    except Exception as exc:
        logger.error(
            "Research conversation failed: %s",
            exc,
            exc_info=True,
        )
        # The agent supports graceful degradation: even on failure,
        # we can retrieve partial results from tool result storage.
        raise


async def run_cicd_pipeline_step(
    agent: AIAgent,
    build_log: str,
    failure_context: Dict[str, Any],
) -> str:
    """
    Use the agent to diagnose and fix a CI/CD pipeline failure.
    
    The agent reads the build log, identifies the root cause,
    proposes a fix, and optionally applies it via Git and terminal tools.
    
    Parameters
    ----------
    agent : AIAgent
        The configured CI/CD agent.
    build_log : str
        The full build log or error output from the failed pipeline.
    failure_context : dict
        Additional context such as commit hash, branch name,
        environment variables, and previous successful builds.
    
    Returns
    -------
    str
        The agent's diagnosis, proposed fix, and execution result.
    """
    # Step 1: Build a structured prompt from the failure context.
    context_lines = []
    context_lines.append("A CI/CD pipeline step has failed.")
    context_lines.append(f"Branch: {failure_context.get('branch', 'unknown')}")
    context_lines.append(f"Commit: {failure_context.get('commit', 'unknown')}")
    context_lines.append(f"Job: {failure_context.get('job_name', 'unknown')}")
    context_lines.append("")
    context_lines.append("=== Build Log (last 200 lines) ===")
    # Only include the tail of the log to fit within context limits
    log_lines = build_log.strip().split('\n')
    tail_lines = log_lines[-200:]
    context_lines.extend(tail_lines)
    context_lines.append("=== End Build Log ===")
    context_lines.append("")
    context_lines.append(
        "Please diagnose the failure, propose a fix, and apply it. "
        "Use 'git status' and 'cat' to inspect the current state, "
        "then apply any needed changes with 'write_file' or "
        "'run_terminal_command'. Commit and push if the fix resolves "
        "the issue."
    )
    
    user_message = "\n".join(context_lines)
    
    # Step 2: Execute the diagnosis and fix loop.
    try:
        response = agent.run_conversation(
            message=user_message,
            system_prompt=_build_cicd_system_prompt(),
        )
        logger.info(
            "CI/CD fix applied for session %s. Response: %s...",
            agent.session_id,
            response[:100],
        )
        return response
    
    except Exception as exc:
        logger.error(
            "CI/CD fix failed: %s",
            exc,
            exc_info=True,
        )
        # In production, you might fall back to a human operator
        # or send an alert to the team.
        raise


def _build_cicd_system_prompt() -> str:
    """
    Build a system prompt tailored for CI/CD automation.
    
    This prompt primes the model to think like a DevOps engineer,
    emphasizing safety, incremental changes, and verification.
    """
    return (
        "You are a senior DevOps engineer responsible for maintaining "
        "the CI/CD pipeline. Your primary goal is to diagnose build "
        "failures quickly and apply minimal, safe fixes.\n\n"
        "Guidelines:\n"
        "1. Always start by inspecting the current state (git status, "
        "log files, configuration).\n"
        "2. Make only the minimal changes needed to fix the issue.\n"
        "3. Verify each fix by running the relevant test or build step.\n"
        "4. If a fix introduces new errors, roll back and try an "
        "alternative approach.\n"
        "5. Commit and push only after the fix is verified.\n"
        "6. If the root cause is unclear, use 'clarify' to ask for "
        "additional context rather than guessing.\n\n"
        "Never run commands that could destroy data or compromise "
        "security. When in doubt, prefer a conservative approach."
    )


# ---------------------------------------------------------------------------
# Main Entry Point: Demonstration
# ---------------------------------------------------------------------------

async def main():
    """
    Demonstrate the basic library implementation for both use cases.
    
    This example creates one research agent and one CI/CD agent,
    runs a sample interaction for each, and prints the results.
    """
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        stream=sys.stdout,
    )
    
    print("=== Hermes Agent: Basic Library Implementation ===\n")
    
    # ---- Research Agent Demo ----
    print("1. Creating Research Agent...")
    research_agent = build_research_agent(
        session_id="demo-research-001",
        verbose=True,
    )
    
    research_question = (
        "What are the latest advances in autonomous AI agent architectures "
        "as of 2025, particularly regarding closed-loop learning?"
    )
    
    print(f"   Research Question: {research_question[:60]}...")
    print("   Running research conversation (this may take a minute)...\n")
    
    research_result = await run_research_conversation(
        research_agent,
        research_question,
    )
    
    print("\n=== Research Result (first 500 chars) ===")
    print(research_result[:500])
    print("...\n")
    
    # ---- CI/CD Agent Demo ----
    print("2. Creating CI/CD Agent...")
    cicd_agent = build_cicd_agent(
        session_id="demo-cicd-001",
        verbose=True,
    )
    
    # Simulated build failure context
    sample_build_log = (
        "[2025-06-15 14:32:01] Running tests...\n"
        "[2025-06-15 14:32:05] FAILED tests/test_api.py::test_user_creation\n"
        "[2025-06-15 14:32:05] AssertionError: Expected 201, got 500\n"
        "[2025-06-15 14:32:05] Traceback (most recent call last):\n"
        "  File \"/app/tests/test_api.py\", line 45, in test_user_creation\n"
        "    response = client.post('/users', json={'name': 'test'})\n"
        "  File \"/app/app/routes.py\", line 120, in create_user\n"
        "    db.session.add(user)\n"
        "  File \"/app/app/models.py\", line 88, in __init__\n"
        "    self.password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())\n"
        "AttributeError: module 'bcrypt' has no attribute 'hashpw'\n"
        "[2025-06-15 14:32:05] Build failed after 34.2 seconds\n"
    )
    
    failure_context = {
        "branch": "feature/user-auth",
        "commit": "a1b2c3d4e5f6",
        "job_name": "test-api",
    }
    
    print("   Diagnosing build failure...\n")
    
    cicd_result = await run_cicd_pipeline_step(
        cicd_agent,
        sample_build_log,
        failure_context,
    )
    
    print("\n=== CI/CD Diagnosis and Fix (first 500 chars) ===")
    print(cicd_result[:500])
    print("...\n")
    
    print("=== Demo Complete ===")


if __name__ == "__main__":
    asyncio.run(main())

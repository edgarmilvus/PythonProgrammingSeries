
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script.py
# Description: Advanced Integration Script
# ==========================================

#!/usr/bin/env python3
"""
Hermes Agent DevOps Learning Agent

This script implements a self-improving CI/CD deployment agent using the
actual Hermes Agent library. It demonstrates:

- Persistent memory of build/deployment outcomes
- Parallel sub-agent delegation for build + test + deploy
- Closed learning loop: evaluate outcome → update agent strategy
- Intelligent fallback and retry from past failures

Requirements:
- Hermes Agent repository (https://github.com/NousResearch/Hermes-Agent)
- Python 3.10+
- Access to a Kubernetes cluster and a build server (or mock endpoints)

Usage:
    python devops_learning_agent.py
"""

import asyncio
import json
import logging
import os
import random
import time
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone
from pathlib import Path

# ---------------------------------------------------------------------------
# Hermes Agent imports – exactly as in the repository reference code
# ---------------------------------------------------------------------------
from run_agent import AIAgent, IterationBudget, _SafeWriter, _install_safe_stdio
from agent.memory_manager import (
    StreamingContextScrubber,
    build_memory_context_block,
    sanitize_context,
)
from agent.prompt_builder import DEFAULT_AGENT_IDENTITY, MEMORY_GUIDANCE
from agent.context_compressor import ContextCompressor
from agent.model_metadata import fetch_model_metadata, estimate_tokens_rough
from agent.tool_guardrails import (
    ToolCallGuardrailConfig,
    ToolCallGuardrailController,
    ToolGuardrailDecision,
    append_toolguard_guidance,
)
from agent.display import KawaiiSpinner
from hermes_cli.config import cfg_get
from model_tools import (
    get_tool_definitions,
    get_toolset_for_tool,
    handle_function_call,
)

# Set up safe I/O – prevents crashes from broken pipes in container environments
_install_safe_stdio()

# Configure logging – essential for tracking agent decisions
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger("DevOpsLearningAgent")

# ---------------------------------------------------------------------------
# Custom tool definitions for DevOps operations
# We define four primary tools and one introspection tool.
# ---------------------------------------------------------------------------

def tool_build_service(service_name: str, branch: str = "main") -> Dict[str, Any]:
    """
    Build a service from source.

    In a real environment, this would trigger a remote build job or run
    a local build command. Here we simulate with a random outcome.
    """
    logger.info("🔧 Building service '%s' from branch '%s'...", service_name, branch)
    # Simulate build time and potential failure
    time.sleep(2)
    success = random.random() > 0.3  # 70% success rate
    if success:
        return {
            "status": "success",
            "artifact": f"{service_name}-v{int(time.time())}.tar.gz",
            "duration_seconds": 45,
            "warnings": [] if random.random() > 0.4 else ["deprecated npm package"]
        }
    else:
        return {
            "status": "failure",
            "error": "npm install failed: network timeout",
            "exit_code": 1,
            "failed_step": "npm ci"
        }


def tool_deploy_service(
    service_name: str,
    artifact: str,
    namespace: str = "default",
    strategy: str = "rolling"
) -> Dict[str, Any]:
    """
    Deploy a pre-built service artifact to a Kubernetes cluster.
    Supports rolling and canary strategies.
    """
    logger.info("🚀 Deploying %s using %s in namespace %s...", artifact, strategy, namespace)
    time.sleep(2)
    success = random.random() > 0.2
    if success:
        return {
            "status": "success",
            "replicas": 3,
            "endpoint": f"https://{service_name}.internal.svc.cluster.local",
            "canary_percentage": 10 if strategy == "canary" else 100
        }
    else:
        return {
            "status": "failure",
            "error": "ImagePullBackOff: registry not reachable",
            "phase": "pending"
        }


def tool_monitor_health(service_name: str, namespace: str = "default") -> Dict[str, Any]:
    """
    Check health endpoints and basic metrics for a deployed service.
    """
    logger.info("🩺 Checking health for %s in %s...", service_name, namespace)
    time.sleep(1)
    healthy = random.random() > 0.25
    return {
        "service": service_name,
        "healthy": healthy,
        "latency_p99_ms": random.randint(100, 500),
        "error_rate": round(random.random() * 0.05, 4),
        "pod_count": random.randint(2, 5)
    }


def tool_query_logs(
    service_name: str,
    since_minutes: int = 10,
    severity: str = "error"
) -> Dict[str, Any]:
    """
    Fetch logs from a service for a given time window.
    """
    logger.info("📜 Fetching %s logs for %s (last %d min)...", severity, service_name, since_minutes)
    time.sleep(1)
    # Simulate finding recent errors
    if random.random() > 0.5:
        return {
            "log_lines": [
                f"ERROR {service_name}: connection refused to db-proxy:5432",
                f"WARN {service_name}: slow query (3200ms) on users table"
            ],
            "count": 2
        }
    else:
        return {"log_lines": [], "count": 0}


def tool_self_reflect() -> Dict[str, Any]:
    """
    Ask the agent to introspect its own memory and suggest improvements
    to its deployment strategy.
    """
    return {
        "instruction": (
            "Review the outcomes of the last deployment. If it failed, "
            "identify the root cause (network, resource, config). "
            "Formulate a concrete improvement to the system prompt or "
            "tool parameters for the next run."
        )
    }


# ---------------------------------------------------------------------------
# Main Agent Runner Class
# ---------------------------------------------------------------------------

class DevOpsLearningAgent:
    """
    Self-improving CI/CD agent using Hermes Agent.

    This class orchestrates the entire deployment pipeline, stores outcomes
    in persistent memory, and updates its own prompt based on learned lessons.
    """

    def __init__(
        self,
        base_url: str = "http://localhost:30000/v1",
        model: str = "claude-opus-4-20250514",
        max_iterations: int = 60,
        memory_path: Optional[str] = None,
    ):
        """
        Initialize the learning agent.

        Args:
            base_url: API endpoint for the LLM provider.
            model: Model id to use (must support tool calling).
            max_iterations: Maximum tool call iterations per run.
            memory_path: Override default memory storage location.
        """
        self.base_url = base_url
        self.model = model
        self.max_iterations = max_iterations

        # Persistent memory: store lessons learned per service
        if memory_path is None:
            memory_path = str(Path.home() / ".hermes" / "devops_memory.json")
        self.memory_path = Path(memory_path)
        self.memory_path.parent.mkdir(parents=True, exist_ok=True)
        self.lesson_memory: List[Dict[str, Any]] = self._load_lesson_memory()

        # Context compression and memory scrubbing for long runs
        self.context_compressor = ContextCompressor(
            max_tokens=32000,
            reserved_tokens=4000,
        )
        self.scrubber = StreamingContextScrubber(
            max_context_length=32000,
            target_output_tokens=4000,
        )

        # Track the current run's deployment state
        self.run_metadata: Dict[str, Any] = {}

        logger.info(
            "DevOpsLearningAgent initialized with model=%s, memory_path=%s",
            model,
            memory_path,
        )

    # -----------------------------------------------------------------------
    # Helper: tool definitions for this agent
    # -----------------------------------------------------------------------
    def _get_tool_definitions(self) -> List[Dict[str, Any]]:
        """Return the JSON tool definitions expected by the LLM API."""
        return [
            {
                "type": "function",
                "function": {
                    "name": "build_service",
                    "description": "Build a service from source code.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "service_name": {"type": "string", "description": "Name of the service to build"},
                            "branch": {"type": "string", "description": "Git branch", "default": "main"}
                        },
                        "required": ["service_name"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "deploy_service",
                    "description": "Deploy a built artifact to a Kubernetes cluster.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "service_name": {"type": "string"},
                            "artifact": {"type": "string"},
                            "namespace": {"type": "string", "default": "default"},
                            "strategy": {"type": "string", "enum": ["rolling", "canary"], "default": "rolling"}
                        },
                        "required": ["service_name", "artifact"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "monitor_health",
                    "description": "Check health and latency of a deployed service.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "service_name": {"type": "string"},
                            "namespace": {"type": "string", "default": "default"}
                        },
                        "required": ["service_name"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "query_logs",
                    "description": "Retrieve recent logs from a service for debugging.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "service_name": {"type": "string"},
                            "since_minutes": {"type": "integer", "default": 10},
                            "severity": {"type": "string", "enum": ["error", "warn", "info"], "default": "error"}
                        },
                        "required": ["service_name"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "self_reflect",
                    "description": "Internal introspection: analyze the last deployment and suggest improvements.",
                    "parameters": {
                        "type": "object",
                        "properties": {},
                        "required": []
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "store_lesson",
                    "description": "Persist a learning from the current run for future improvement.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "service": {"type": "string", "description": "Service name"},
                            "outcome": {"type": "string", "enum": ["success", "failure", "partial"]},
                            "root_cause": {"type": "string", "description": "Root cause if failed"},
                            "mitigation": {"type": "string", "description": "What to do differently next time"},
                            "weight": {"type": "number", "description": "Confidence weight (0.0–1.0)", "default": 0.5}
                        },
                        "required": ["service", "outcome", "root_cause", "mitigation"]
                    }
                }
            }
        ]

    # -----------------------------------------------------------------------
    # Memory persistence
    # -----------------------------------------------------------------------
    def _load_lesson_memory(self) -> List[Dict[str, Any]]:
        """Load previously stored lessons from disk, with fallback."""
        if self.memory_path.exists():
            try:
                with open(self.memory_path, "r") as f:
                    data = json.load(f)
                if isinstance(data, list):
                    return data
            except (json.JSONDecodeError, IOError):
                logger.warning("Could not load memory file; starting fresh.")
        return []

    def _save_lesson_memory(self) -> None:
        """Write lesson memory to disk atomically (prevent corruption)."""
        tmp = self.memory_path.with_suffix(".tmp")
        try:
            with open(tmp, "w") as f:
                json.dump(self.lesson_memory, f, indent=2)
            tmp.rename(self.memory_path)
        except IOError as e:
            logger.error("Failed to save memory: %s", e)

    # -----------------------------------------------------------------------
    # Embed lessons into the system prompt
    # -----------------------------------------------------------------------
    def _build_enhanced_system_prompt(self) -> str:
        """
        Build a system prompt that includes relevant lessons from past runs.

        The memory guidance is injected with a ranked list of lessons so the
        LLM can consider them during tool selection and response generation.
        """
        base_prompt = (
            f"{DEFAULT_AGENT_IDENTITY}\n\n"
            "You are a DevOps deployment agent that learns from experience. "
            "You have the following tools available: build_service, deploy_service, "
            "monitor_health, query_logs, self_reflect, store_lesson.\n\n"
            f"{MEMORY_GUIDANCE}\n\n"
        )

        # Format lessons into a concise context block
        if self.lesson_memory:
            lesson_lines = []
            for i, lesson in enumerate(self.lesson_memory[-10:]):  # last 10
                lesson_lines.append(
                    f"{i+1}. Service '{lesson.get('service','?')}': "
                    f"{lesson.get('outcome','?')}. "
                    f"Root cause: {lesson.get('root_cause','N/A')}. "
                    f"Mitigation: {lesson.get('mitigation','N/A')}."
                )
            lesson_context = (
                "### Lessons Learned from Previous Deployments\n"
                + "\n".join(lesson_lines)
                + "\n\nApply these lessons when deciding deployment strategy."
            )
        else:
            lesson_context = "No prior lessons stored; this is a fresh environment."

        return base_prompt + lesson_context

    # -----------------------------------------------------------------------
    # Tool call handler (dispatches to our custom functions)
    # -----------------------------------------------------------------------
    def _execute_tool(self, tool_name: str, tool_args: Dict[str, Any]) -> str:
        """
        Execute a tool by name and return its result as a JSON string.

        This is the bridge between the LLM's function calls and our
        Python functions. Results are returned as string for message history.
        """
        tool_map = {
            "build_service": tool_build_service,
            "deploy_service": tool_deploy_service,
            "monitor_health": tool_monitor_health,
            "query_logs": tool_query_logs,
            "self_reflect": tool_self_reflect,
        }

        if tool_name in tool_map:
            result = tool_map[tool_name](**tool_args)
            # Small delay to simulate real network latency
            time.sleep(0.2)
            return json.dumps(result, default=str)
        elif tool_name == "store_lesson":
            # Direct memory update
            lesson = {
                "service": tool_args.get("service", "unknown"),
                "outcome": tool_args.get("outcome", "unknown"),
                "root_cause": tool_args.get("root_cause", ""),
                "mitigation": tool_args.get("mitigation", ""),
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "weight": tool_args.get("weight", 0.5),
            }
            self.lesson_memory.append(lesson)
            self._save_lesson_memory()
            return json.dumps({"status": "stored", "lesson_id": len(self.lesson_memory) - 1})
        else:
            return json.dumps({"error": f"Unknown tool: {tool_name}"})

    # -----------------------------------------------------------------------
    # Core run loop – orchestrate the deployment with learning
    # -----------------------------------------------------------------------
    async def run_deployment(self, service_name: str, branch: str = "main") -> Dict[str, Any]:
        """
        Execute one full deployment cycle with learning.

        Returns a summary dictionary with status and lessons.
        """
        logger.info("=" * 60)
        logger.info("Starting deployment for service '%s' (branch: %s)", service_name, branch)
        logger.info("=" * 60)

        # Initialize the Hermes AIAgent with our custom configuration
        agent = AIAgent(
            base_url=self.base_url,
            model=self.model,
            max_iterations=self.max_iterations,
            enabled_toolsets=["all"],  # We'll use our own tool defs via prompt
            verbose_logging=True,
            quiet_mode=False,
            tool_delay=0.5,
        )

        # Build the enhanced system prompt with memory
        system_prompt = self._build_enhanced_system_prompt()
        logger.debug("System prompt length: %d characters", len(system_prompt))

        # Prepare the initial user message with context
        initial_message = (
            f"I need to deploy service '{service_name}' from branch '{branch}'.\n"
            "Please go through the following steps:\n"
            "1. Build the service.\n"
            "2. If build succeeds, deploy it (rolling update).\n"
            "3. Monitor health after deployment.\n"
            "4. If health check fails, query logs and diagnose.\n"
            "5. After completing (or after any failure), call self_reflect to analyze.\n"
            "6. Store any important lessons using store_lesson.\n"
            "Start with the build step."
        )

        # Start the tool-calling conversation loop
        try:
            response = await agent.run_conversation(
                message=initial_message,
                system_prompt=system_prompt,
                tool_definition_provider=self._get_tool_definitions,
                tool_executor=self._execute_tool,
            )
        except Exception as e:
            logger.error("Agent conversation failed: %s", e)
            return {
                "status": "error",
                "error": str(e),
                "service": service_name,
                "branch": branch,
                "lesson_memory_count": len(self.lesson_memory),
            }

        # Parse final response to extract outcome summary
        # The agent should have produced a final summary after self_reflect
        final_output = response.get("response_text", "") or response.get("content", "")
        tool_calls_made = response.get("tool_calls_executed", [])

        # Determine outcome from the sequence of tool results
        # (In a real implementation, we'd inspect the stored lesson memory
        # for the latest entry on this service.)
        outcome = "unknown"
        last_lesson = None
        for lesson in reversed(self.lesson_memory):
            if lesson.get("service") == service_name:
                outcome = lesson.get("outcome", "unknown")
                last_lesson = lesson
                break

        summary = {
            "status": outcome,
            "service": service_name,
            "branch": branch,
            "tool_calls_count": len(tool_calls_made),
            "total_tokens_used": response.get("usage", {}).get("total_tokens", 0),
            "lesson_applied": last_lesson is not None,
            "lesson": last_lesson,
            "memory_size": len(self.lesson_memory),
            "agent_final_output": final_output[:200] + "..." if len(final_output) > 200 else final_output,
        }

        logger.info("Deployment completed with status: %s", outcome)
        return summary

    # -----------------------------------------------------------------------
    # Continuous improvement: run multiple cycles and track progress
    # -----------------------------------------------------------------------
    async def train_on_previous_cycles(self, service_name: str, cycles: int = 5) -> List[Dict[str, Any]]:
        """
        Run multiple deployment cycles, each time improving from past lessons.

        This simulates the closed learning loop: after each cycle, the agent
        updates its memory and the next cycle starts with an improved prompt.
        """
        results = []
        for cycle in range(1, cycles + 1):
            logger.info("\n### Cycle %d / %d ###", cycle, cycles)
            result = await self.run_deployment(service_name=service_name, branch="main")
            results.append(result)
            # After each cycle, we could also adjust model parameters or
            # tool execution weights based on results. For now, we just report.
            if result["status"] == "success":
                logger.info("Cycle %d: SUCCESS", cycle)
            else:
                logger.info("Cycle %d: %s – lesson stored for next run", cycle, result["status"])
        return results

    # -----------------------------------------------------------------------
    # Utility: clear memory (for testing)
    # -----------------------------------------------------------------------
    def reset_memory(self) -> None:
        """Clear all stored lessons (for testing fresh starts)."""
        self.lesson_memory = []
        self._save_lesson_memory()
        logger.info("Lesson memory cleared.")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys

    # Configuration – adjust to your environment
    CONFIG = {
        "base_url": os.environ.get("HERMES_API_URL", "http://localhost:30000/v1"),
        "model": os.environ.get("HERMES_MODEL", "claude-opus-4-20250514"),
        "max_iterations": int(os.environ.get("MAX_ITERATIONS", "60")),
        "service": sys.argv[1] if len(sys.argv) > 1 else "cart-service",
        "cycles": int(sys.argv[2]) if len(sys.argv) > 2 else 3,
    }

    async def main():
        agent = DevOpsLearningAgent(
            base_url=CONFIG["base_url"],
            model=CONFIG["model"],
            max_iterations=CONFIG["max_iterations"],
        )

        print(f"\n🚀 Hermes DevOps Learning Agent")
        print(f"   Model: {CONFIG['model']}")
        print(f"   Service: {CONFIG['service']}")
        print(f"   Cycles: {CONFIG['cycles']}")
        print()

        # Optionally reset memory
        if "--reset" in sys.argv:
            agent.reset_memory()
            print("🧹 Memory reset.\n")

        results = await agent.train_on_previous_cycles(
            service_name=CONFIG["service"],
            cycles=CONFIG["cycles"],
        )

        print("\n📊 Summary of all cycles:")
        for i, r in enumerate(results, 1):
            print(f"   Cycle {i}: {r['status'].upper():10s} | "
                  f"Tools: {r['tool_calls_count']:2d} | "
                  f"Lesson stored: {r['lesson_applied']}")

        # Show memory contents
        print(f"\n🧠 Memory now contains {agent.lesson_memory} lessons.")
        for lesson in agent.lesson_memory:
            print(f"   - [{lesson['service']}] {lesson['outcome']}: {lesson['mitigation'][:60]}")

    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nInterrupted by user.")

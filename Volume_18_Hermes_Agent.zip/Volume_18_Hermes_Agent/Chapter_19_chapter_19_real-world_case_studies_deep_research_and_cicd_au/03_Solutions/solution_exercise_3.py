
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# agent/tool_scheduler.py
import threading
from collections import defaultdict, deque
from dataclasses import dataclass, field
from enum import IntEnum
from typing import List, Dict, Optional

class ToolPriority(IntEnum):
    CRITICAL = 1
    HIGH = 2
    MEDIUM = 3
    LOW = 4

class DependencyCycleError(Exception):
    pass

@dataclass
class ToolExecutionPlan:
    tool_call: dict
    priority: int
    dependencies: List[int] = field(default_factory=list)  # indices of tool calls that must complete first

class PriorityScheduler:
    def __init__(self, priority_overrides: Optional[Dict[str, int]] = None):
        self.lock = threading.Lock()
        self.default_priorities = {
            'kill_process': ToolPriority.CRITICAL,
            'write_file': ToolPriority.CRITICAL,
            'patch': ToolPriority.CRITICAL,
            'run_sql': ToolPriority.CRITICAL,
            'terminal_sudo': ToolPriority.CRITICAL,
            'read_file': ToolPriority.HIGH,
            'search_files': ToolPriority.HIGH,
            'run_shell': ToolPriority.HIGH,
            'web_search': ToolPriority.MEDIUM,
            'web_extract': ToolPriority.MEDIUM,
            'vision_analyze': ToolPriority.MEDIUM,
            'session_search': ToolPriority.LOW,
            'skill_view': ToolPriority.LOW,
            'ha_get_state': ToolPriority.LOW,
        }
        if priority_overrides:
            self.default_priorities.update(priority_overrides)

    def _get_priority(self, tool_name: str) -> int:
        return self.default_priorities.get(tool_name, ToolPriority.MEDIUM)

    def _infer_dependencies(self, tool_calls: List[dict]) -> Dict[int, List[int]]:
        """Build dependency graph based on file path arguments."""
        # Map paths to tool call indices
        path_to_index = defaultdict(list)
        for idx, call in enumerate(tool_calls):
            args = call.get('arguments', {})
            for arg_name in ['path', 'file_path', 'output_path']:
                if arg_name in args:
                    path_to_index[args[arg_name]].append(idx)

        dependencies = defaultdict(list)
        for idx, call in enumerate(tool_calls):
            args = call.get('arguments', {})
            # Check if any input path was written by another call
            for arg_name in ['path', 'file_path', 'input_path']:
                if arg_name in args:
                    path = args[arg_name]
                    for prev_idx in path_to_index.get(path, []):
                        if prev_idx != idx:
                            # Only add if the previous call writes to this path
                            prev_call = tool_calls[prev_idx]
                            if prev_call.get('name') in ('write_file', 'patch', 'run_sql'):
                                dependencies[idx].append(prev_idx)
        return dict(dependencies)

    def schedule(self, tool_calls: List[dict]) -> List[List[ToolExecutionPlan]]:
        """
        Return a list of batches (each batch is a list of ToolExecutionPlan).
        Batches are ordered by priority and dependencies.
        """
        with self.lock:
            n = len(tool_calls)
            if n == 0:
                return []

            # Build dependency graph
            deps = self._infer_dependencies(tool_calls)

            # Detect cycles using DFS
            visited = [0] * n  # 0=unvisited,1=visiting,2=visited
            def has_cycle(u):
                visited[u] = 1
                for v in deps.get(u, []):
                    if visited[v] == 1:
                        return True
                    if visited[v] == 0 and has_cycle(v):
                        return True
                visited[u] = 2
                return False
            for i in range(n):
                if visited[i] == 0 and has_cycle(i):
                    raise DependencyCycleError("Cycle detected in tool call dependencies")

            # Topological sort using Kahn's algorithm
            in_degree = [0] * n
            for u, vs in deps.items():
                for v in vs:
                    in_degree[u] += 1  # u depends on v, so v must come before u

            # Priority queue for nodes with in_degree 0
            import heapq
            heap = []
            for i in range(n):
                if in_degree[i] == 0:
                    priority = self._get_priority(tool_calls[i]['name'])
                    heapq.heappush(heap, (priority, i))

            sorted_indices = []
            while heap:
                prio, idx = heapq.heappop(heap)
                sorted_indices.append(idx)
                # Decrease in_degree of dependents
                for dependent, deps_list in deps.items():
                    if idx in deps_list:
                        in_degree[dependent] -= 1
                        if in_degree[dependent] == 0:
                            heapq.heappush(heap, (self._get_priority(tool_calls[dependent]['name']), dependent))

            if len(sorted_indices) != n:
                raise DependencyCycleError("Could not resolve all dependencies (possible cycle)")

            # Group into batches: each batch contains independent tools, sorted by priority
            # We'll create a batch for each "layer" in the dependency DAG
            # Use longest path length from source
            dist = [0] * n
            for idx in sorted_indices:
                for dep in deps.get(idx, []):
                    dist[idx] = max(dist[idx], dist[dep] + 1)
            max_dist = max(dist) if dist else 0
            batches = [[] for _ in range(max_dist + 1)]
            for idx in sorted_indices:
                plan = ToolExecutionPlan(
                    tool_call=tool_calls[idx],
                    priority=self._get_priority(tool_calls[idx]['name']),
                    dependencies=deps.get(idx, [])
                )
                batches[dist[idx]].append(plan)
            # Sort each batch by priority (higher priority first)
            for batch in batches:
                batch.sort(key=lambda x: x.priority)
            return batches

# Integration into AIAgent.run_conversation() (pseudo-code)
# In the tool execution section of run_conversation():
# from agent.tool_scheduler import PriorityScheduler
# scheduler = PriorityScheduler(priority_overrides=self.priority_overrides)
# batches = scheduler.schedule(tool_calls)
# for batch in batches:
#     # Check for NEVER_PARALLEL_TOOLS
#     if any(call['name'] in self._NEVER_PARALLEL_TOOLS for call in batch):
#         # Execute sequentially
#         for plan in batch:
#             result = execute_tool(plan.tool_call)
#             # handle budget etc.
#     else:
#         # Execute in parallel using ThreadPoolExecutor (if no intra-batch dependencies)
#         with ThreadPoolExecutor(max_workers=min(len(batch), self._MAX_TOOL_WORKERS)) as executor:
#             futures = {executor.submit(execute_tool, plan.tool_call): plan for plan in batch}
#             for future in as_completed(futures):
#                 # process results

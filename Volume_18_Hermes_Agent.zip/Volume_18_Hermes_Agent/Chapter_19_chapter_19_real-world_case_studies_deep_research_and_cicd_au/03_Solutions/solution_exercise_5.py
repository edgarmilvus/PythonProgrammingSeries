
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import json
import hashlib
import concurrent.futures
import threading
import time
from pathlib import Path
from agent import AIAgent
from agent.memory_manager import build_memory_context_block
from agent.model_tools import get_tool_definitions
from agent.error_classifier import classify_api_error

class MultiAgentResearchCoordinator:
    def __init__(self, topic: str, base_url: str = "http://localhost:8000/v1"):
        self.topic = topic
        self.topic_hash = hashlib.sha256(topic.encode()).hexdigest()[:16]
        self.research_dir = Path.home() / ".hermes" / "research"
        self.research_dir.mkdir(parents=True, exist_ok=True)
        self.workers_dir = self.research_dir / "workers"
        self.workers_dir.mkdir(exist_ok=True)
        self.max_worker_timeout = 120  # seconds
        self.max_retries = 1

        # Coordinator agent
        self.coordinator = AIAgent(
            base_url=base_url,
            model="gpt-4",
            max_iterations=20,
            save_trajectories=True,
            ephemeral_system_prompt=self._coordinator_prompt()
        )
        tool_defs = get_tool_definitions()
        self.coordinator.load_tools(tool_defs)
        self.coordinator.enable_tools(["web_search", "web_extract", "session_search"])

    def _coordinator_prompt(self):
        return (
            f"You are a research coordinator investigating: {self.topic}.\n"
            "First, use web_search to get an overview. Then decompose the topic into at least 3 sub-topics. "
            "Output a JSON object with key 'sub_topics' containing an array of objects, each with 'id', 'title', and 'questions' (list of strings). "
            "Do not include any other text. Example:\n"
            '{"sub_topics": [{"id": "t1", "title": "History", "questions": ["When?"]}]}\n'
            "After decomposition, you will receive worker reports. Then synthesize a final report."
        )

    def decompose_topic(self) -> list:
        """Ask coordinator to decompose topic into sub-topics."""
        result = self.coordinator.run_conversation(
            f"Decompose the topic '{self.topic}' into sub-topics. Output only JSON."
        )
        # Parse JSON from last assistant message
        for msg in reversed(self.coordinator.messages):
            if msg['role'] == 'assistant' and 'sub_topics' in msg.get('content', ''):
                try:
                    data = json.loads(msg['content'])
                    return data['sub_topics']
                except (json.JSONDecodeError, KeyError):
                    continue
        # Fallback: hardcoded decomposition
        return [
            {"id": "t1", "title": "History and Background", "questions": ["Key milestones?"]},
            {"id": "t2", "title": "Manufacturing Processes", "questions": ["Scalability?"]},
            {"id": "t3", "title": "Applications and Impact", "questions": ["Current use cases?"]}
        ]

    def spawn_worker(self, sub_topic: dict) -> dict:
        """Run a worker agent for a sub-topic in a thread."""
        worker = AIAgent(
            base_url=self.coordinator.base_url,
            model=self.coordinator.model,
            max_iterations=30,
            session_id=f"worker_{sub_topic['id']}",
            ephemeral_system_prompt=(
                f"You are a research worker investigating: {sub_topic['title']}\n"
                f"Questions: {sub_topic['questions']}\n"
                "Use web_search and web_extract to gather information. "
                "Produce a detailed report of at least 200 words."
            )
        )
        worker.load_tools(get_tool_definitions())
        worker.enable_tools(["web_search", "web_extract", "session_search"])

        start_time = time.time()
        try:
            worker.run_conversation(f"Research the sub-topic: {sub_topic['title']}")
            duration = time.time() - start_time
            # Extract report from last assistant message
            report = ""
            for msg in reversed(worker.messages):
                if msg['role'] == 'assistant' and len(msg.get('content', '')) > 100:
                    report = msg['content']
                    break
            return {
                'sub_topic_id': sub_topic['id'],
                'title': sub_topic['title'],
                'report': report,
                'tool_calls_made': len(worker.trajectory),
                'duration': duration,
                'status': 'success'
            }
        except Exception as e:
            error_class = classify_api_error(e)
            return {
                'sub_topic_id': sub_topic['id'],
                'title': sub_topic['title'],
                'report': '',
                'tool_calls_made': 0,
                'duration': time.time() - start_time,
                'status': 'failed',
                'error': str(e),
                'error_class': error_class
            }

    def run(self):
        # Step 1: Decompose
        sub_topics = self.decompose_topic()
        print(f"Decomposed into {len(sub_topics)} sub-topics: {[s['title'] for s in sub_topics]}")

        # Step 2: Spawn workers in parallel
        worker_results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(sub_topics)) as executor:
            future_to_sub = {executor.submit(self.spawn_worker, sub): sub for sub in sub_topics}
            for future in concurrent.futures.as_completed(future_to_sub, timeout=self.max_worker_timeout + 10):
                sub = future_to_sub[future]
                try:
                    result = future.result(timeout=self.max_worker_timeout)
                    worker_results.append(result)
                except concurrent.futures.TimeoutError:
                    worker_results.append({
                        'sub_topic_id': sub['id'],
                        'title': sub['title'],
                        'report': '',
                        'tool_calls_made': 0,
                        'duration': self.max_worker_timeout,
                        'status': 'timeout'
                    })

        # Save individual worker reports
        for wr in worker_results:
            worker_file = self.workers_dir / f"{wr['sub_topic_id']}.json"
            with open(worker_file, 'w') as f:
                json.dump(wr, f, indent=2)

        # Check failure rate and retry if needed
        failed = [wr for wr in worker_results if wr['status'] != 'success']
        if len(failed) > len(worker_results) // 2 and self.max_retries > 0:
            self.max_retries -= 1
            print("Too many failures, retrying delegation cycle...")
            return self.run()  # recursive retry

        # Step 3: Synthesize final report
        synthesis_prompt = (
            f"Here are the worker reports for the topic '{self.topic}':\n"
            + json.dumps(worker_results, indent=2) +
            "\nSynthesize a final report with an executive summary, detailed sections for each sub-topic, "
            "and a conclusion that acknowledges uncertainties. Output the report as a JSON object with keys: "
            "'executive_summary', 'sections' (array of {title, content}), 'conclusion'."
        )
        self.coordinator.run_conversation(synthesis_prompt)

        # Extract final report
        final_report = None
        for msg in reversed(self.coordinator.messages):
            if msg['role'] == 'assistant':
                try:
                    final_report = json.loads(msg['content'])
                    break
                except json.JSONDecodeError:
                    continue
        if final_report is None:
            final_report = {"error": "Could not parse final report"}

        # Save final report
        final_file = self.research_dir / f"{self.topic_hash}.json"
        with open(final_file, 'w') as f:
            json.dump(final_report, f, indent=2)
        print(f"Final report saved to {final_file}")

        # Validation
        assert len(final_report.get('sections', [])) >= 3, "Need at least 3 sections"
        for section in final_report.get('sections', []):
            assert len(section.get('content', '').split()) >= 200, f"Section {section['title']} too short"
        successful_workers = [wr for wr in worker_results if wr['status'] == 'success']
        assert len(successful_workers) >= 2, "At least 2 workers must succeed"
        print("All assertions passed.")

if __name__ == "__main__":
    coordinator = MultiAgentResearchCoordinator(
        "impact of carbon nanotube composites on aircraft structural health monitoring systems"
    )
    coordinator.run()

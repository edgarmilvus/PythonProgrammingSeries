
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import json
import hashlib
import os
import time
import logging
from pathlib import Path
from agent import AIAgent
from agent.memory_manager import build_memory_context_block, StreamingContextScrubber
from agent.model_tools import get_tool_definitions
from agent.error_classifier import classify_api_error
from agent.retry_utils import jittered_backoff
from openai import APIError, RateLimitError

# Configure logging
logging.basicConfig(level=logging.DEBUG, filename='research_agent.log', filemode='w')
logger = logging.getLogger(__name__)

class PersistentResearchAgent:
    def __init__(self, topic: str, base_url: str = "http://localhost:8000/v1"):
        self.topic = topic
        self.topic_hash = hashlib.sha256(topic.encode()).hexdigest()[:16]
        self.research_dir = Path.home() / ".hermes" / "research"
        self.research_dir.mkdir(parents=True, exist_ok=True)
        self.research_file = self.research_dir / f"{self.topic_hash}.json"
        self.max_cycles = 5
        self.cycle_count = 0
        self.previous_summary = None

        # Load existing research if available
        if self.research_file.exists():
            with open(self.research_file, 'r') as f:
                self.previous_summary = json.load(f)
            logger.info(f"Loaded existing research from {self.research_file}")

        # Initialize agent
        self.agent = AIAgent(
            base_url=base_url,
            model="gpt-4",
            max_iterations=30,
            save_trajectories=True,
            step_callback=self._step_callback,
            ephemeral_system_prompt=self._build_system_prompt()
        )
        # Enable required tools
        tool_defs = get_tool_definitions()
        self.agent.load_tools(tool_defs)
        self.agent.enable_tools(["web_search", "web_extract", "read_file", "write_file", "session_search", "skill_view"])

    def _build_system_prompt(self) -> str:
        """Inject previous research context into system prompt."""
        base_prompt = f"You are a deep research agent investigating: {self.topic}.\n"
        if self.previous_summary:
            memory_block = build_memory_context_block(
                self.previous_summary,
                max_tokens=2000,
                scrubber=StreamingContextScrubber()
            )
            base_prompt += f"Previous research findings:\n{memory_block}\n"
            base_prompt += "Continue from where you left off. Do not repeat prior work.\n"
        base_prompt += (
            "After each research cycle, produce a structured report with sections: "
            "Summary, Known Facts, Uncertainties, Missing Data. "
            "When you believe research is complete, call the tool `research_complete(path='<filename>')` "
            "with the path to your final report JSON file."
        )
        return base_prompt

    def _step_callback(self, step):
        """Intercept final summary tool call and write research to JSON."""
        if step.get("tool_call") and step["tool_call"]["name"] == "write_file":
            # Extract the written content (assuming tool returns the file content)
            content = step["tool_call"].get("result", "")
            if content:
                try:
                    research_data = json.loads(content)
                    # Ensure required keys exist
                    required = ["summary", "known_facts", "uncertainties", "missing_data"]
                    if all(k in research_data for k in required):
                        with open(self.research_file, 'w') as f:
                            json.dump(research_data, f, indent=2)
                        logger.info(f"Research saved to {self.research_file}")
                except (json.JSONDecodeError, KeyError):
                    pass

    def run_research_cycle(self) -> bool:
        """Execute one research conversation cycle. Returns True if research complete."""
        self.cycle_count += 1
        if self.cycle_count > self.max_cycles:
            logger.info("Max research cycles reached.")
            return True

        try:
            result = self.agent.run_conversation(
                f"Continue research on: {self.topic}. "
                f"Cycle {self.cycle_count}. "
                "Produce structured report and call research_complete if done."
            )
        except (APIError, RateLimitError) as e:
            error_class = classify_api_error(e)
            if error_class == "rate_limit":
                backoff = jittered_backoff(base=2, max_delay=60)
                time.sleep(backoff)
                return self.run_research_cycle()  # retry
            else:
                logger.error(f"Unrecoverable API error: {e}")
                return True  # stop on permanent error

        # Check if agent declared research complete via tool call
        for step in self.agent.trajectory:
            if step.get("tool_call", {}).get("name") == "research_complete":
                logger.info("Agent declared research complete.")
                return True

        # Otherwise, extract last write_file output as basis for next cycle
        last_write = None
        for step in reversed(self.agent.trajectory):
            if step.get("tool_call", {}).get("name") == "write_file":
                last_write = step["tool_call"].get("result")
                break
        if last_write:
            self.previous_summary = json.loads(last_write)
            self.agent.ephemeral_system_prompt = self._build_system_prompt()
        return False

    def run(self):
        """Run iterative research until complete or max cycles."""
        while not self.run_research_cycle():
            pass
        logger.info("Research process finished.")

# Validation test (simulated two sessions)
if __name__ == "__main__":
    topic = "impact of carbon nanotube composites on aircraft structural health monitoring systems"
    # First session
    agent1 = PersistentResearchAgent(topic)
    agent1.run()
    first_tool_calls = len(agent1.agent.trajectory)
    print(f"First session tool calls: {first_tool_calls}")

    # Simulate 24-hour gap by modifying timestamp (not needed for logic)
    # Second session
    agent2 = PersistentResearchAgent(topic)
    agent2.run()
    second_tool_calls = len(agent2.agent.trajectory)
    print(f"Second session tool calls: {second_tool_calls}")

    # Assertions
    with open(agent2.research_file, 'r') as f:
        final_data = json.load(f)
    assert all(k in final_data for k in ["summary", "known_facts", "uncertainties", "missing_data"])
    total_words = sum(len(v.split()) for v in final_data.values() if isinstance(v, str))
    assert total_words > 500, f"Total words {total_words} < 500"
    assert second_tool_calls <= first_tool_calls * 0.8, "Second session should have ≥20% fewer tool calls"
    print("All assertions passed.")

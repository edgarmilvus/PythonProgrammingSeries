
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import json
import random
import time
import yaml
from pathlib import Path
from datetime import datetime
from agent import AIAgent
from agent.memory_manager import build_memory_context_block
from agent.model_tools import get_tool_definitions, get_toolset_for_tool
from agent.tool_guardrails import ToolCallGuardrailController
from agent.error_classifier import classify_api_error

# ---- Mock CI/CD Environment ----
def simulate_build(config_path: str) -> dict:
    """Parse config, run simulated tests, return result."""
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    # Simulate test outcomes based on config
    test_results = {}
    for stage in config.get('stages', []):
        for job in stage.get('jobs', []):
            test_name = job['name']
            # Flaky tests fail ~30% of time unless retry configured
            if job.get('retry', 0) > 0:
                # With retry, flaky becomes stable
                flaky = False
            else:
                flaky = random.random() < 0.3
            # Stable tests fail only on config error (simulate by checking env var)
            env_ok = 'MY_ENV' in job.get('variables', {})
            if flaky:
                passed = random.random() > 0.3
            else:
                passed = env_ok
            test_results[test_name] = {'passed': passed, 'duration': random.uniform(1, 10)}
    success = all(r['passed'] for r in test_results.values())
    failed_tests = [name for name, r in test_results.items() if not r['passed']]
    return {
        'success': success,
        'failed_tests': failed_tests,
        'duration': sum(r['duration'] for r in test_results.values()),
        'timestamp': datetime.now().isoformat(),
        'config_snapshot': config
    }

# ---- Custom Tool Implementations ----
def read_build_log(path: str) -> str:
    with open(path, 'r') as f:
        return f.read()

def run_build(config_path: str) -> dict:
    return simulate_build(config_path)

def modify_pipeline_config(config_path: str, changes: dict) -> str:
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    # Apply changes (simplified: merge dict)
    for key, value in changes.items():
        # Navigate nested keys using dot notation
        keys = key.split('.')
        target = config
        for k in keys[:-1]:
            target = target.setdefault(k, {})
        target[keys[-1]] = value
    with open(config_path, 'w') as f:
        yaml.dump(config, f)
    return f"Config updated: {changes}"

def get_pipeline_history(since_timestamp: str = None) -> list:
    history_file = Path.home() / ".hermes" / "ci_cd" / "history.json"
    if not history_file.exists():
        return []
    with open(history_file, 'r') as f:
        records = json.load(f)
    if since_timestamp:
        records = [r for r in records if r['timestamp'] >= since_timestamp]
    return records[-10:]  # last 10

# ---- Agent Setup ----
def create_ci_cd_agent():
    # Register custom tools
    tool_defs = get_tool_definitions()
    ci_cd_tools = get_toolset_for_tool('ci_cd_automation', [
        ('read_build_log', read_build_log, "Read build log file"),
        ('run_build', run_build, "Run a build simulation"),
        ('modify_pipeline_config', modify_pipeline_config, "Modify pipeline YAML config"),
        ('get_pipeline_history', get_pipeline_history, "Get recent build history"),
    ])
    tool_defs.extend(ci_cd_tools)

    # Create agent with guardrails
    guardrail = ToolCallGuardrailController()
    guardrail.add_rule(
        tool_name='modify_pipeline_config',
        condition=lambda call: 'read_build_log' not in [s.get('tool_call', {}).get('name') for s in agent.trajectory],
        action='block',
        message="You must read the build log before modifying config."
    )

    agent = AIAgent(
        base_url="http://localhost:8000/v1",
        model="gpt-4",
        max_iterations=30,
        enabled_toolsets=["ci_cd_automation"],
        tool_guardrails=guardrail,
        ephemeral_system_prompt=(
            "You are a CI/CD automation agent. You have tools to read build logs, run builds, "
            "modify pipeline config, and view history. Your goal is to fix failing builds. "
            "Analyze failures, propose fixes, and apply them. If you cannot fix after 3 attempts, "
            "ask the user for guidance using the `clarify` tool. "
            "Always read the build log before modifying config."
        )
    )
    return agent

# ---- Self-Healing Loop ----
def self_healing_loop(config_path: str, max_attempts=3):
    agent = create_ci_cd_agent()
    history_file = Path.home() / ".hermes" / "ci_cd" / "history.json"
    history_file.parent.mkdir(parents=True, exist_ok=True)

    attempt = 0
    while attempt < max_attempts:
        # Run build
        result = run_build(config_path)
        # Save to history
        history = get_pipeline_history()
        history.append(result)
        with open(history_file, 'w') as f:
            json.dump(history, f, indent=2)

        if result['success']:
            print("Build passed!")
            break

        # Feed result to agent
        prompt = (
            f"Build failed. Failed tests: {result['failed_tests']}. "
            f"Build log: {read_build_log('build_log.txt')}. "
            f"History: {json.dumps(get_pipeline_history(), indent=2)}. "
            "Analyze and fix the pipeline config."
        )
        agent.run_conversation(prompt)

        # Check if agent called clarify (escalation)
        if any(step.get('tool_call', {}).get('name') == 'clarify' for step in agent.trajectory):
            print("Agent requested human intervention.")
            break

        # Check if agent modified config
        if any(step.get('tool_call', {}).get('name') == 'modify_pipeline_config' for step in agent.trajectory):
            attempt += 1
            print(f"Attempt {attempt}: config modified, re-running build...")
        else:
            print("Agent did not modify config. Stopping.")
            break

    # After loop, verify flaky test retry in config
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    # Check if any job has retry block
    has_retry = any(
        job.get('retry') for stage in config.get('stages', []) for job in stage.get('jobs', [])
    )
    assert has_retry, "Final config should contain retry for flaky test stage"
    print("Self-healing complete. Config updated with retry logic.")

if __name__ == "__main__":
    # Setup mock files
    config_path = "pipeline_config.yaml"
    initial_config = {
        'stages': [{'name': 'test', 'jobs': [{'name': 'flaky_test'}, {'name': 'stable_test', 'variables': {'MY_ENV': 'true'}}]}]
    }
    with open(config_path, 'w') as f:
        yaml.dump(initial_config, f)
    with open('build_log.txt', 'w') as f:
        f.write("Simulated build log\n")
    self_healing_loop(config_path)

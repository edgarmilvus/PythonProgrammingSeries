
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_6.py
# Description: Solution for Exercise 6
# ==========================================

# tools/database_tool.py
import sqlite3
import json
import re
import logging
from pathlib import Path
from typing import List, Dict, Any

logger = logging.getLogger(__name__)

# Module-level variable to hold current schema summary
_current_schema_summary = "No schema explored yet."

# ---- Database Functions ----
def list_tables(connection_string: str) -> List[str]:
    """Return list of table names."""
    if connection_string.startswith("sqlite://"):
        db_path = connection_string.replace("sqlite://", "")
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = [row[0] for row in cursor.fetchall()]
        conn.close()
        return tables
    else:
        # PostgreSQL placeholder
        raise NotImplementedError("Only SQLite supported for this example")

def inspect_schema(connection_string: str, table_name: str) -> Dict[str, Any]:
    """Return column info for a table."""
    if connection_string.startswith("sqlite://"):
        db_path = connection_string.replace("sqlite://", "")
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute(f"PRAGMA table_info({table_name});")
        columns = []
        for row in cursor.fetchall():
            columns.append({
                "name": row[1],
                "type": row[2],
                "notnull": row[3],
                "default": row[4],
                "pk": row[5]
            })
        conn.close()
        # Update global schema summary
        global _current_schema_summary
        _current_schema_summary = f"Table {table_name}: " + ", ".join(
            f"{col['name']} {col['type']}" for col in columns
        )
        return {"table": table_name, "columns": columns}
    else:
        raise NotImplementedError("Only SQLite supported")

def run_select_query(connection_string: str, sql_query: str) -> Dict[str, Any]:
    """Execute SELECT query and return results."""
    # Guard against destructive statements
    forbidden = re.compile(r'\b(DROP|DELETE|TRUNCATE|ALTER|INSERT|UPDATE|CREATE)\b', re.IGNORECASE)
    if forbidden.search(sql_query):
        return {"error": "Destructive SQL detected. Only SELECT queries are allowed."}
    if not sql_query.strip().upper().startswith("SELECT"):
        return {"error": "Only SELECT queries are allowed."}

    if connection_string.startswith("sqlite://"):
        db_path = connection_string.replace("sqlite://", "")
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        try:
            cursor.execute(sql_query)
            rows = [dict(row) for row in cursor.fetchall()]
            columns = [desc[0] for desc in cursor.description] if cursor.description else []
            conn.close()
            return {"columns": columns, "rows": rows}
        except sqlite3.Error as e:
            return {"error": str(e)}
    else:
        raise NotImplementedError("Only SQLite supported")

# ---- Dynamic Tool Description Update ----
def update_database_tool_description(base_tools: List[dict]) -> List[dict]:
    """Replace the description of run_select_query with current schema summary."""
    global _current_schema_summary
    updated_tools = []
    for tool in base_tools:
        if tool['function']['name'] == 'run_select_query':
            # Update description
            tool['function']['description'] = (
                f"Execute a SELECT query on the database. Current schema: {_current_schema_summary}. "
                "Only SELECT queries are allowed. Returns columns and rows."
            )
        updated_tools.append(tool)
    return updated_tools

# ---- Integration into AIAgent ----
# In the agent initialization, after loading tools, call update_database_tool_description.
# Then, in the tool_complete_callback, if the completed tool is inspect_schema, re-update.
# Example:
# from tools.database_tool import list_tables, inspect_schema, run_select_query, update_database_tool_description
# agent = AIAgent(...)
# base_tools = get_tool_definitions()
# # Add custom tools
# custom_tools = [
#     {
#         "type": "function",
#         "function": {
#             "name": "list_tables",
#             "description": "List all tables in the database",
#             "parameters": {"type": "object", "properties": {"connection_string": {"type": "string"}}, "required": ["connection_string"]}
#         }
#     },
#     {
#         "type": "function",
#         "function": {
#             "name": "inspect_schema",
#             "description": "Inspect schema of a table",
#             "parameters": {"type": "object", "properties": {"connection_string": {"type": "string"}, "table_name": {"type": "string"}}, "required": ["connection_string", "table_name"]}
#         }
#     },
#     {
#         "type": "function",
#         "function": {
#             "name": "run_select_query",
#             "description": "Execute a SELECT query (schema will be updated dynamically)",
#             "parameters": {"type": "object", "properties": {"connection_string": {"type": "string"}, "sql_query": {"type": "string"}}, "required": ["connection_string", "sql_query"]}
#         }
#     }
# ]
# base_tools.extend(custom_tools)
# base_tools = update_database_tool_description(base_tools)
# agent.load_tools(base_tools)
# 
# # Register callback to update descriptions after inspect_schema
# def tool_complete_callback(tool_name, result):
#     if tool_name == "inspect_schema":
#         # Re-generate tool definitions and update agent's internal cache
#         new_tools = update_database_tool_description(agent.tool_definitions)
#         agent.tool_definitions = new_tools
#         # Invalidate any cached tool definitions in model_tools if needed
#         # (Implementation depends on framework internals)
# agent.tool_complete_callback = tool_complete_callback

# ---- Guardrails ----
# Use ToolCallGuardrailController to block destructive queries.
# In agent initialization:
# from agent.tool_guardrails import ToolCallGuardrailController
# guardrail = ToolCallGuardrailController()
# guardrail.add_rule(
#     tool_name='run_select_query',
#     condition=lambda call: not call['arguments']['sql_query'].strip().upper().startswith('SELECT'),
#     action='block',
#     message="Only SELECT queries are allowed."
# )
# guardrail.add_rule(
#     tool_name='run_select_query',
#     condition=lambda call: not _table_exists_in_schema(call['arguments']['sql_query']),
#     action='block',
#     message="Table not in schema. Please call inspect_schema first."
# )
# agent.tool_guardrails = guardrail

# ---- Validation Test ----
def test_database_agent():
    # Setup SQLite database
    conn = sqlite3.connect(":memory:")
    conn.executescript("""
        CREATE TABLE users (id INT, name TEXT, email TEXT);
        INSERT INTO users VALUES (1, 'Alice', 'alice@example.com');
        CREATE TABLE orders (id INT, user_id INT, product_id INT, amount REAL);
        INSERT INTO orders VALUES (1, 1, 10, 99.99);
        CREATE TABLE products (id INT, name TEXT, price REAL);
        INSERT INTO products VALUES (10, 'Widget', 19.99);
    """)
    conn.commit()
    conn.close()

    # Simulate agent conversation
    agent = ...  # setup as above
    result = agent.run_conversation("List all orders with user names.")
    # Expected tool calls: list_tables, inspect_schema(users), inspect_schema(orders), run_select_query(...)
    # Verify dynamic description update
    # Check that after inspect_schema, the next API call includes updated description
    # Verify guardrail blocks destructive query
    result2 = agent.run_conversation("Delete the users table.")
    # Should be blocked and agent informed
    print("Test passed.")

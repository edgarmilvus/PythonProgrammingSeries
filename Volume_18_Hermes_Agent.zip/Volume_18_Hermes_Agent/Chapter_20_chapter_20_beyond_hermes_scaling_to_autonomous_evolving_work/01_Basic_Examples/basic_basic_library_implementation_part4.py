
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation_part4.py
# Description: Basic Library Implementation
# ==========================================

# run_migration_workforce.py
import os
import sys
import logging

# Add the hermes-agent library to the path
sys.path.insert(0, os.path.expanduser("~/.hermes/hermes-agent"))

from workforce_library import (
    WorkforceOrchestrator,
    WorkerProfile,
    FederatedMemoryStore,
)
from run_agent import AIAgent

logging.basicConfig(level=logging.INFO)

def main():
    # 1. Create the Federated Memory Store
    #    This persists across multiple runs, accumulating wisdom!
    fleet_memory = FederatedMemoryStore()

    # 2. Define the Guild Members (Worker Profiles)
    workers = {
        "Code_Refactorer": WorkerProfile(
            role="Code_Refactorer",
            model="claude-opus-4-20250514",
            base_url=os.environ.get("ANTHROPIC_BASE_URL", "https://api.anthropic.com"),
            api_key=os.environ["ANTHROPIC_API_KEY"],
            provider="anthropic",
            enabled_toolsets=["file_ops", "code_exec", "search"],
            system_prompt_template="You are a senior Python refactoring specialist...",
        ),
        "Schema_Architect": WorkerProfile(
            role="Schema_Architect",
            model="gpt-4o",
            base_url="https://api.openai.com/v1",
            api_key=os.environ["OPENAI_API_KEY"],
            provider="openai",
            enabled_toolsets=["file_ops", "search"],
            system_prompt_template="You are an expert in relational database design...",
        ),
        "DevOps_Engineer": WorkerProfile(
            role="DevOps_Engineer",
            model="gemini-1.5-pro",
            base_url="https://generativelanguage.googleapis.com/v1beta/openai/",
            api_key=os.environ["GEMINI_API_KEY"],
            provider="google-gemini",
            enabled_toolsets=["terminal_tool", "file_ops"],
            system_prompt_template="You are a GitOps engineer responsible for deployment...",
        ),
    }

    # 3. Instantiate the Orchestrator
    #    The orchestrator itself is a strong planning model.
    orchestrator_config = {
        "model": "claude-sonnet-4-20250514",
        "base_url": "https://api.anthropic.com",
        "api_key": os.environ["ANTHROPIC_API_KEY"],
        "provider": "anthropic",
        "verbose_logging": True,
    }

    fleet = WorkforceOrchestrator(
        orchestrator_config=orchestrator_config,
        worker_profiles=workers,
        memory_store=fleet_memory,
        max_parallel_workers=3,
        max_orchestrator_iterations=30,
        max_subagent_iterations=50,
    )

    # 4. Define the High-Level Goal
    goal = """
    Migrate the legacy 'order_processing' module from the monolith to a new
    microservice. Steps required:
    - Extract the Python service logic into a new FastAPI app.
    - Design the Postgres schema for the service.
    - Create a Dockerfile and a Helm chart for deployment.
    - Add integration tests.
    """

    # 5. Deploy the Autonomous Workforce
    final_report = fleet.deploy_workflow(goal)

    print("\n===== FINAL SYNTHESIZED OUTPUT =====")
    print(final_report)
    print("====================================\n")

if __name__ == "__main__":
    main()

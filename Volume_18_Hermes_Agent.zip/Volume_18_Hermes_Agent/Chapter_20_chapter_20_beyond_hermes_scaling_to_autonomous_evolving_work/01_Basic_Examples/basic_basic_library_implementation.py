
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation.py
# Description: Basic Library Implementation
# ==========================================

# workforce_library.py
import sqlite3
import threading
import json
import logging
from pathlib import Path
from typing import Optional, Dict, Any
from datetime import datetime

from hermes_constants import get_hermes_home

logger = logging.getLogger("hermes.workforce.memory")

class FederatedMemoryStore:
    """
    The shared, persistent, transactional 'company wiki' for the fleet.

    This store does NOT hold raw conversation histories. It holds distilled
    *strategies*, *outcomes*, and *agent roles*. This is the key distinction
    between a chat log and an institutional memory.

    It uses a thread-safe SQLite connection (WAL mode) so the orchestrator
    can safely read and write even as parallel subagents report results.
    """

    # Schema optimized for rapid querying of "who is best at X?" and
    # "what strategy works best for Y?"
    _SCHEMA = """
    CREATE TABLE IF NOT EXISTS fleet_knowledge (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        role_name TEXT NOT NULL,            -- e.g. "Senior_Refactorer"
        task_type TEXT NOT NULL,            -- e.g. "python_refactoring", "schema_design"
        success INTEGER NOT NULL,           -- 1 for success, 0 for failure
        outcome_summary TEXT,               -- Short description of what happened
        strategy_blob TEXT,                 -- The key 2-3 sentence strategy learned
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_fleet_lookup
        ON fleet_knowledge (role_name, task_type);
    """

    def __init__(self, db_path: str = None):
        """
        Initializes the fleet memory database.

        Args:
            db_path: Path to the SQLite database file.
                     Defaults to ~/.hermes/workforce_memory.db
        """
        if db_path is None:
            hermes_home = get_hermes_home()
            db_path = str(Path(hermes_home) / "workforce_memory.db")

        self._db_path = Path(db_path).expanduser()
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        """Returns a thread-local database connection."""
        if not hasattr(self._local, "conn") or self._local.conn is None:
            logger.debug("Opening new SQLite connection for thread %s", threading.current_thread().name)
            self._local.conn = sqlite3.connect(str(self._db_path))
            self._local.conn.execute("PRAGMA journal_mode=WAL;")
            self._local.conn.execute("PRAGMA synchronous=NORMAL;")
            self._local.conn.execute("PRAGMA foreign_keys=ON;")
        return self._local.conn

    def _init_db(self):
        """Creates the schema if it doesn't exist. Idempotent."""
        conn = self._get_connection()
        conn.executescript(self._SCHEMA)
        conn.commit()

    def record_learning(
        self,
        role_name: str,
        task_type: str,
        success: bool,
        outcome_summary: str,
        strategy_blob: str,
    ) -> int:
        """
        Persists a learning outcome from a subagent's execution.

        This is called by the orchestrator AFTER the subagent task completes.
        It is the key method that implements the "closed learning loop"
        at the fleet level.

        Args:
            role_name: The role of the agent that performed the task.
            task_type: The category of the task.
            success: Whether the task was completed successfully.
            outcome_summary: A brief summary of the result.
            strategy_blob: The distilled strategy text.

        Returns:
            The row ID of the inserted entry.
        """
        conn = self._get_connection()
        cursor = conn.execute(
            """INSERT INTO fleet_knowledge
               (role_name, task_type, success, outcome_summary, strategy_blob)
               VALUES (?, ?, ?, ?, ?)""",
            (role_name, task_type, int(success), outcome_summary, strategy_blob),
        )
        conn.commit()
        logger.info(
            "Fleet Memory: Recorded %s for role '%s' on task '%s' (success=%s)",
            "strategy" if success else "failure",
            role_name,
            task_type,
            success,
        )
        return cursor.lastrowid

    def query_best_strategy(self, task_type: str) -> Optional[str]:
        """
        Retrieves the most recently successful strategy for a given task type.

        This implements the **federated** aspect of memory. A worker assigned
        to a task can ask the fleet "how did we solve this last time?"

        Args:
            task_type: The category of the task.

        Returns:
            A strategy string, or None if no successful strategy exists.
        """
        conn = self._get_connection()
        cursor = conn.execute(
            """SELECT strategy_blob FROM fleet_knowledge
               WHERE task_type = ? AND success = 1
               ORDER BY created_at DESC LIMIT 1""",
            (task_type,),
        )
        row = cursor.fetchone()
        if row:
            logger.debug("Fleet Memory: Found strategy for task '%s'", task_type)
            return row[0]
        logger.debug("Fleet Memory: No strategy found for task '%s'", task_type)
        return None

    def query_best_role_for_task(self, task_type: str) -> Optional[str]:
        """
        Finds the agent role with the highest historical success rate
        for a given task type.

        This allows the workforce to dynamically reassign roles based on
        empirical evidence rather than hardcoded rules. This is the seed
        of **emergent organizational structure**.

        Args:
            task_type: The category of the task.

        Returns:
            The name of the best-performing role, or None.
        """
        conn = self._get_connection()
        cursor = conn.execute(
            """SELECT role_name, AVG(success) as score
               FROM fleet_knowledge
               WHERE task_type = ?
               GROUP BY role_name
               ORDER BY score DESC
               LIMIT 1""",
            (task_type,),
        )
        row = cursor.fetchone()
        if row:
            logger.info(
                "Fleet Memory: Task '%s' best performed by role '%s' (score=%s)",
                task_type,
                row[0],
                row[1],
            )
            return row[0]
        return None

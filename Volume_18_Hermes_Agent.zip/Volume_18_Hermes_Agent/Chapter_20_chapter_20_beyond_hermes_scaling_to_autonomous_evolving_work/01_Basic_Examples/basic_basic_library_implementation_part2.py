
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation_part2.py
# Description: Basic Library Implementation
# ==========================================

# workforce_library.py
from dataclasses import dataclass, field
from typing import List, Optional

@dataclass
class WorkerProfile:
    """
    Definition of a specialized worker agent.

    Each worker has a distinct role in the organizational structure.
    This profile does NOT hold the AIAgent instance (which is heavy)
    but holds the configuration required to instantiate one.

    Attributes:
        role: The functional role name (e.g., "Code_Refactorer").
        model: The AI model string (e.g., "claude-opus-4-20250514").
        base_url: The API endpoint base URL.
        api_key: The API key for the endpoint.
        provider: The provider type string.
        enabled_toolsets: List of toolset names the agent is allowed to use.
        system_prompt_template: Optional template to override the default agent identity.
    """
    role: str
    model: str
    base_url: str
    api_key: str
    provider: str
    enabled_toolsets: List[str] = field(
        default_factory=lambda: ["file_ops", "code_exec", "search"]
    )
    system_prompt_template: Optional[str] = None

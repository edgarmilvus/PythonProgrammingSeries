
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation_part3.py
# Description: Basic Library Implementation
# ==========================================

# workforce_library.py
import json
import logging
import os
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable

# Import the REAL classes from the Hermes base code
from run_agent import (
    AIAgent,
    IterationBudget,
    _install_safe_stdio,
    _sanitize_messages_surrogates,
    _strip_non_ascii,
    _repair_tool_call_arguments,
)

logger = logging.getLogger("hermes.workforce.orchestrator")


class WorkforceOrchestrator:
    """
    Manages an autonomous evolving workforce.

    This class is the 'master architect' of the fleet. It uses a master
    AIAgent to decompose high-level goals, delegates to specialized
    subagents, and extracts learnings to update the fleet's shared memory.

    The orchestrator itself participates in a closed learning loop:
    Decompose -> Assign -> Execute(Synthesize) -> Reflect -> Learn -> Persist.
    """

    # Default system prompt for the orchestrator agent. It must understand
    # that it is a manager, not a doer of deep technical work.
    _ORCHESTRATOR_SYSTEM_PROMPT = (
        "You are an expert technical project manager and system architect. "
        "Your primary function is to decompose monolithic goals into distinct, "
        "parallelizable subtasks. You assign these subtasks to specialized "
        "worker agents. After they report back, you synthesize their outputs "
        "into a coherent final solution. You do NOT directly execute code "
        "or write files; you delegate to your team. "
        "Your secondary function is to reflect on the outcomes and extract "
        "actionable strategies for the fleet's shared memory."
    )

    def __init__(
        self,
        # The orchestrator's own AIAgent configuration.
        orchestrator_config: Dict[str, Any],
        # A mapping of role names to WorkerProfile definitions.
        worker_profiles: Dict[str, WorkerProfile],
        # The federated memory store instance.
        memory_store: FederatedMemoryStore,
        # Master Orchestrator AIAgent
        orchestrator_agent: Optional[AIAgent] = None,
        # Maximum number of subagents running concurrently.
        max_parallel_workers: int = 4,
        # Maximum iterations for the orchestrator's own closed loop.
        max_orchestrator_iterations: int = 50,
        # Max iterations for any single delegated subagent.
        max_subagent_iterations: int = 50,
    ):
        """
        Initializes the workforce orchestration system.

        Args:
            orchestrator_config: A dictionary of kwargs to pass to the
                                 orchestrator's AIAgent constructor
                                 (e.g., model, base_url, api_key).
            worker_profiles: A dictionary mapping role names to WorkerProfile.
            memory_store: An instance of FederatedMemoryStore.
            orchestrator_agent: Optional pre-existing AIAgent instance for the orchestrator.
            max_parallel_workers: Number of background worker threads.
            max_orchestrator_iterations: Budget for the orchestrator's own loop.
            max_subagent_iterations: Budget for each subagent's loop.
        """
        # Install safe stdio guards early to prevent crashes from broken pipes
        # (a direct application of the _SafeWriter and _install_safe_stdio
        #  utilities from the provided run_agent.py).
        _install_safe_stdio()

        self.memory = memory_store
        self.worker_profiles = worker_profiles
        self.max_parallel_workers = max_parallel_workers
        self.max_subagent_iterations = max_subagent_iterations

        # Initialize the orchestrator's own AIAgent.
        # This agent runs the high-level planning, synthesizing, and reflection loops.
        if orchestrator_agent:
            self.orchestrator = orchestrator_agent
        else:
            # ENSURING ORCHESTRATOR HAS ITS OWN BUDGET
            orchestrator_config["max_iterations"] = max_orchestrator_iterations
            # Apply the orchestrator system prompt
            if "ephemeral_system_prompt" not in orchestrator_config:
                orchestrator_config["ephemeral_system_prompt"] = self._ORCHESTRATOR_SYSTEM_PROMPT
            self.orchestrator = AIAgent(**orchestrator_config)

        # Execution pool for running subagents in parallel
        self._executor = ThreadPoolExecutor(max_workers=max_parallel_workers)

        logger.info(
            "WorkforceOrchestrator initialized with %d worker profiles and %d parallel slots.",
            len(worker_profiles),
            max_parallel_workers,
        )

    def _decompose_goal(self, goal: str) -> List[Dict]:
        """
        Decomposes a high-level user goal into a structured list of subtasks.

        This uses the orchestrator's AIAgent run_conversation method,
        which is itself a closed learning loop with tool calling.

        The orchestrator agent is prompted to output a JSON list.
        If the output is malformed, we attempt repair using the
        _repair_tool_call_arguments logic from run_agent.py.

        Args:
            goal: The high-level goal string.

        Returns:
            A list of dictionaries, each containing:
              - 'id': A unique identifier string.
              - 'description': The task description.
              - 'required_role': The role name expected to handle this.
              - 'task_type': The category for memory queries.
              - 'context': Any relevant context for the subagent.
        """
        decomposition_prompt = (
            f"Decompose the following goal into a list of parallelizable subtasks.\n"
            f"Goal: {goal}\n\n"
            f"Respond with a JSON list of objects. Each object must have exactly these keys:\n"
            f"- id: a unique short string (e.g., 'TASK-1')\n"
            f"- description: a detailed description of the subtask\n"
            f"- required_role: one of the available roles: {list(self.worker_profiles.keys())}\n"
            f"- task_type: a category string like 'python_refactoring' or 'schema_design'\n"
            f"- context: relevant background for the subagent\n\n"
            f"Return ONLY the JSON list. No other text."
        )

        # The orchestrator's internal loop handles the tool calls if needed
        raw_response = self.orchestrator.run_conversation(decomposition_prompt)

        # Response sanitization is critical here.
        # The AI may wrap JSON in markdown code blocks.
        clean_response = raw_response.strip()
        if clean_response.startswith("
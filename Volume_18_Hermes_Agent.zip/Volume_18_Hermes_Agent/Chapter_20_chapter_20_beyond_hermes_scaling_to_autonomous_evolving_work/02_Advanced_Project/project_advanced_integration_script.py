
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script.py
# Description: Advanced Integration Script
# ==========================================

"""
workforce_orchestrator.py

A production-grade implementation of an autonomous, self-improving AI workforce.
Scales the core principles of Hermes Agent (persistent memory, closed learning loops)
from a single agent to a coordinated, evolving team.

Key Features:
- Federated Persistent Memory: A shared knowledge store that all agents read/write.
- Hierarchical Closed Learning Loops: The orchestrator learns from mission outcomes.
- Dynamic Role Assignment: Workers are specialized and their roles are optimized over time.
- Robust Error Handling: Manages worker failures and partial mission completion.
- Production Logging: Structured logging for observability and debugging.
"""

import asyncio
import json
import logging
import os
import time
import uuid
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
from datetime import datetime
from dataclasses import dataclass, field, asdict

# Core Hermes Agent import
from run_agent import AIAgent, IterationBudget

# Configure structured logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("WorkforceOrchestrator")


# =============================================================================
# Data Models for the Workforce
# =============================================================================

@dataclass
class Task:
    """
    Represents a single unit of work to be delegated to a WorkerAgent.
    """
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    description: str = ""
    assigned_role: str = ""  # e.g., "code_reviewer", "log_analyst"
    context: Dict[str, Any] = field(default_factory=dict)  # Relevant files, URLs, etc.
    status: str = "pending"  # pending, running, completed, failed
    result: Optional[str] = None
    error: Optional[str] = None
    started_at: Optional[float] = None
    completed_at: Optional[float] = None


@dataclass
class MissionReport:
    """
    The output of a completed workforce mission. Used for the hierarchical learning loop.
    """
    mission_id: str
    objective: str
    tasks: List[Task]
    start_time: float
    end_time: float
    overall_success: bool
    lessons_learned: List[str] = field(default_factory=list)


@dataclass
class FederatedMemoryEntry:
    """
    A single observation stored in the shared federated memory.
    """
    timestamp: float = field(default_factory=time.time)
    agent_role: str = ""
    observation: str = ""
    context: str = ""  # The task or situation in which this observation was made
    confidence: float = 1.0  # How reliable is this observation?


# =============================================================================
# Federated Memory Store
# =============================================================================

class FederatedMemoryStore:
    """
    A simple, file-based persistent store for federated memory.
    In a production system, this would be replaced by a vector database or
    a distributed key-value store (e.g., Redis, PostgreSQL).

    This store implements the 'federated persistent memory' concept from
    Chapter 20, allowing learnings to be shared across agents without
    compromising individual specialization.
    """

    def __init__(self, storage_path: str = "~/.hermes_workforce/federated_memory.json"):
        self.storage_path = Path(storage_path).expanduser()
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        self._entries: List[FederatedMemoryEntry] = []
        self._load()

    def _load(self):
        """Load existing memory entries from disk."""
        if self.storage_path.exists():
            try:
                with open(self.storage_path, 'r') as f:
                    data = json.load(f)
                    self._entries = [FederatedMemoryEntry(**entry) for entry in data]
                logger.info(f"Loaded {len(self._entries)} entries from federated memory.")
            except (json.JSONDecodeError, FileNotFoundError):
                logger.warning("Federated memory file corrupted or missing. Starting fresh.")
                self._entries = []

    def _save(self):
        """Persist memory entries to disk."""
        with open(self.storage_path, 'w') as f:
            json.dump([asdict(entry) for entry in self._entries], f, indent=2)

    def add_observation(self, agent_role: str, observation: str, context: str = ""):
        """
        Add a new observation to the shared memory.
        This is the primary write operation for the federated memory.
        """
        entry = FederatedMemoryEntry(
            agent_role=agent_role,
            observation=observation,
            context=context
        )
        self._entries.append(entry)
        self._save()
        logger.debug(f"Federated memory updated by {agent_role}: {observation[:50]}...")

    def query(self, keywords: List[str], limit: int = 5) -> List[FederatedMemoryEntry]:
        """
        Query the federated memory for relevant observations.
        Simple keyword matching. In production, use semantic search.
        """
        results = []
        for entry in reversed(self._entries):  # Most recent first
            text = f"{entry.observation} {entry.context}"
            if any(kw.lower() in text.lower() for kw in keywords):
                results.append(entry)
                if len(results) >= limit:
                    break
        return results

    def get_context_for_task(self, task_description: str) -> str:
        """
        Build a context string from federated memory relevant to a given task.
        This is used to inject shared learnings into a worker's system prompt.
        """
        keywords = task_description.split()[:5]  # Use first 5 words as keywords
        relevant_entries = self.query(keywords, limit=3)
        if not relevant_entries:
            return ""

        context_parts = ["**Relevant observations from the workforce's shared memory:**"]
        for entry in relevant_entries:
            context_parts.append(
                f"- [{entry.agent_role}] ({entry.observation})"
            )
        return "\n".join(context_parts)


# =============================================================================
# The Worker Agent Wrapper
# =============================================================================

class WorkerAgent:
    """
    A specialized worker that wraps the Hermes AIAgent.

    Each worker has a specific role, a dedicated toolset, and its own local
    memory context. It operates independently but reports to the orchestrator.
    """

    def __init__(
        self,
        role: str,
        base_url: str,
        model: str,
        api_key: Optional[str] = None,
        enabled_toolsets: Optional[List[str]] = None,
        max_iterations: int = 30,
        verbose_logging: bool = False,
        federated_memory: Optional[FederatedMemoryStore] = None,
    ):
        self.role = role
        self.federated_memory = federated_memory

        # Build a role-specific system prompt
        role_prompt = self._build_role_prompt()

        # Initialize the underlying Hermes Agent
        self.agent = AIAgent(
            base_url=base_url,
            model=model,
            api_key=api_key,
            enabled_toolsets=enabled_toolsets or [],
            max_iterations=max_iterations,
            verbose_logging=verbose_logging,
            ephemeral_system_prompt=role_prompt,
        )

        logger.info(f"WorkerAgent '{role}' initialized with model {model}.")

    def _build_role_prompt(self) -> str:
        """
        Construct a system prompt that defines the worker's specialization.
        This is a key part of the 'individual specialization' concept.
        """
        prompts = {
            "code_reviewer": (
                "You are a senior code reviewer. Your expertise is in identifying bugs, "
                "security vulnerabilities, performance bottlenecks, and style violations. "
                "You are concise and direct. Provide specific line numbers and suggestions. "
                "You have access to the 'read_file' and 'search_files' tools."
            ),
            "log_analyst": (
                "You are a senior site reliability engineer specializing in log analysis. "
                "You can parse complex log formats, identify error patterns, and correlate "
                "events across different services. You are methodical and detail-oriented. "
                "You have access to the 'read_file' and 'web_search' tools."
            ),
            "network_troubleshooter": (
                "You are a network engineer. You diagnose connectivity issues, DNS problems, "
                "and latency spikes. You can read traceroute outputs and analyze network metrics. "
                "You are calm under pressure. You have access to the 'terminal_tool' and 'read_file' tools."
            ),
            "general_analyst": (
                "You are a versatile analyst. Your job is to gather information, synthesize "
                "findings from multiple sources, and provide a clear, actionable summary. "
                "You are a generalist, but you are excellent at connecting disparate pieces of information."
            ),
        }
        return prompts.get(self.role, prompts["general_analyst"])

    async def execute_task(self, task: Task) -> Task:
        """
        Execute a single task. This is the main entry point for the worker.

        This method:
        1. Injects federated memory context into the task.
        2. Runs the Hermes agent's conversation loop.
        3. Captures the result or error.
        4. Optionally, writes a new observation to the federated memory.
        """
        logger.info(f"Worker '{self.role}' starting task {task.id}: {task.description[:50]}...")
        task.status = "running"
        task.started_at = time.time()

        # Step 1: Augment the task with federated memory context
        memory_context = ""
        if self.federated_memory:
            memory_context = self.federated_memory.get_context_for_task(task.description)

        # Build the full prompt for the agent
        full_prompt = f"## Your Task\n{task.description}\n"
        if task.context:
            full_prompt += f"\n## Additional Context\n{json.dumps(task.context, indent=2)}\n"
        if memory_context:
            full_prompt += f"\n{memory_context}\n"

        try:
            # Step 2: Run the agent's conversation loop
            # The agent will use its tools (e.g., read_file, terminal_tool) to complete the task
            response = await asyncio.to_thread(
                self.agent.run_conversation,
                full_prompt
            )

            # Step 3: Capture the result
            task.result = response
            task.status = "completed"
            logger.info(f"Worker '{self.role}' completed task {task.id}.")

            # Step 4: Contribute to federated memory
            if self.federated_memory and task.result:
                # Create a concise summary observation
                observation = f"Task '{task.description[:50]}...': {task.result[:200]}"
                self.federated_memory.add_observation(
                    agent_role=self.role,
                    observation=observation,
                    context=task.description
                )

        except Exception as e:
            logger.error(f"Worker '{self.role}' failed on task {task.id}: {e}")
            task.status = "failed"
            task.error = str(e)

        finally:
            task.completed_at = time.time()

        return task


# =============================================================================
# The Workforce Orchestrator (The Manager)
# =============================================================================

class WorkforceOrchestrator:
    """
    The central coordinator for the autonomous workforce.

    This class implements the 'hierarchical closed learning loop' from Chapter 20.
    It decomposes objectives, delegates tasks, and learns from the outcomes to
    optimize future performance.
    """

    def __init__(
        self,
        base_url: str,
        model: str,
        api_key: Optional[str] = None,
        max_workers: int = 5,
        verbose_logging: bool = False,
        strategy_memory_path: str = "~/.hermes_workforce/orchestrator_strategy.json",
    ):
        self.base_url = base_url
        self.model = model
        self.api_key = api_key
        self.max_workers = max_workers
        self.verbose_logging = verbose_logging

        # Shared components
        self.federated_memory = FederatedMemoryStore()
        self.strategy_memory_path = Path(strategy_memory_path).expanduser()
        self.strategy_memory_path.parent.mkdir(parents=True, exist_ok=True)

        # Load previous strategies (the hierarchical learning loop)
        self.strategy_memory: Dict[str, Any] = self._load_strategy_memory()

        # Worker pool
        self.workers: Dict[str, WorkerAgent] = {}

        # Mission history for the learning loop
        self.mission_history: List[MissionReport] = []

        logger.info("WorkforceOrchestrator initialized.")

    def _load_strategy_memory(self) -> Dict[str, Any]:
        """Load the orchestrator's learned strategies from disk."""
        if self.strategy_memory_path.exists():
            try:
                with open(self.strategy_memory_path, 'r') as f:
                    data = json.load(f)
                    logger.info(f"Loaded orchestrator strategy memory with {len(data.get('lessons', []))} lessons.")
                    return data
            except (json.JSONDecodeError, FileNotFoundError):
                logger.warning("Strategy memory corrupted. Starting fresh.")
        return {"lessons": [], "role_effectiveness": {}, "mission_count": 0}

    def _save_strategy_memory(self):
        """Persist the orchestrator's learned strategies."""
        with open(self.strategy_memory_path, 'w') as f:
            json.dump(self.strategy_memory, f, indent=2)

    def _spawn_worker(self, role: str) -> WorkerAgent:
        """
        Create or retrieve a worker agent for a given role.

        In a more advanced system, this could dynamically configure the worker's
        toolset based on the role and the learned effectiveness from the strategy memory.
        """
        if role not in self.workers:
            # Determine the best toolset for this role based on past performance
            enabled_tools = self._get_tools_for_role(role)

            worker = WorkerAgent(
                role=role,
                base_url=self.base_url,
                model=self.model,
                api_key=self.api_key,
                enabled_toolsets=enabled_tools,
                verbose_logging=self.verbose_logging,
                federated_memory=self.federated_memory,
            )
            self.workers[role] = worker
            logger.info(f"Spawned new worker for role '{role}'.")
        return self.workers[role]

    def _get_tools_for_role(self, role: str) -> List[str]:
        """
        Determine the optimal toolset for a role, using the hierarchical learning loop.

        This is a key part of the 'dynamic role assignment' and 'workflow optimization'
        concepts. The orchestrator learns which tools are most effective for which roles
        and adjusts accordingly.
        """
        # Default tool assignments
        default_tools = {
            "code_reviewer": ["read_file", "search_files"],
            "log_analyst": ["read_file", "web_search"],
            "network_troubleshooter": ["terminal_tool", "read_file"],
            "general_analyst": ["read_file", "web_search", "web_extract"],
        }

        # Check if we have learned a better toolset for this role
        learned_tools = self.strategy_memory.get("role_effectiveness", {}).get(role, {})
        if learned_tools:
            # Example: If 'web_search' was never effective for 'log_analyst', remove it
            effective_tools = [tool for tool, score in learned_tools.items() if score > 0.5]
            if effective_tools:
                logger.info(f"Using learned toolset for '{role}': {effective_tools}")
                return effective_tools

        return default_tools.get(role, default_tools["general_analyst"])

    async def _decompose_objective(self, objective: str) -> List[Task]:
        """
        Decompose a high-level objective into a list of tasks.

        This uses the orchestrator's own AI to plan the work. The orchestrator's
        system prompt includes its learned strategies from past missions.
        """
        # Build a prompt that includes lessons from the hierarchical learning loop
        lessons = self.strategy_memory.get("lessons", [])[-5:]  # Last 5 lessons
        lessons_context = ""
        if lessons:
            lessons_context = "## Lessons from Previous Missions\n" + "\n".join(f"- {l}" for l in lessons)

        decomposition_prompt = f"""
You are a senior project manager for an autonomous AI workforce.
Your job is to decompose a high-level objective into specific, parallelizable tasks.

{lessons_context}

## Objective
{objective}

## Available Worker Roles
- code_reviewer: For analyzing code, finding bugs, and suggesting fixes.
- log_analyst: For parsing logs, identifying error patterns, and correlating events.
- network_troubleshooter: For diagnosing network issues and latency problems.
- general_analyst: For any other type of analysis or information gathering.

## Instructions
Decompose the objective into a JSON list of tasks. Each task must have:
- "description": A clear, actionable description of what needs to be done.
- "assigned_role": The most appropriate role from the list above.
- "context": A dictionary of any relevant files, URLs, or parameters.

Output ONLY the JSON list, no other text.
"""

        # Use a temporary AIAgent for decomposition
        planner_agent = AIAgent(
            base_url=self.base_url,
            model=self.model,
            api_key=self.api_key,
            max_iterations=1,  # No tool calling for planning
            verbose_logging=self.verbose_logging,
            ephemeral_system_prompt="You are a precise task planner. Output only valid JSON.",
        )

        try:
            response = await asyncio.to_thread(
                planner_agent.run_conversation,
                decomposition_prompt
            )

            # Parse the JSON response
            # The response might be wrapped in markdown code blocks
            json_str = response.strip()
            if json_str.startswith("
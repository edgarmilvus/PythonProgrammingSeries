
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

"""
federated_memory.py
Federated Memory Coordinator for multi‑agent workforce.
"""
import json
import logging
from datetime import datetime
from typing import List, Dict, Optional
from collections import defaultdict

# Assume the following Hermes modules are available:
from agent import AIAgent
from agent.memory_manager import SessionDB, build_memory_context_block
from agent.prompt_builder import estimate_tokens_rough

logger = logging.getLogger(__name__)


class FederatedMemoryCoordinator:
    """
    Coordinates aggregation and redistribution of memories across agents.
    Each agent retains its own persistent memory; the coordinator only
    suggests shared insights.
    """

    def __init__(self, peer_agents: List[AIAgent], aggregation_interval: int = 10):
        """
        Args:
            peer_agents: List of AIAgent instances participating in federation.
            aggregation_interval: Number of conversation turns between aggregations.
        """
        self.peer_agents = {agent.agent_id: agent for agent in peer_agents}
        self.tribal_knowledge: List[Dict] = []
        self.iteration_count = 0

    def aggregate_memories(self, agent_ids: Optional[List[str]] = None) -> List[Dict]:
        """
        Query each agent's local SessionDB, merge entries with similar task signatures,
        and return a deduplicated list of consolidated memories.

        Args:
            agent_ids: If None, use all registered agents.

        Returns:
            List of aggregated memory dicts with fields:
              task_type, lesson, confidence, timestamp, source_agents
        """
        if agent_ids is None:
            agent_ids = list(self.peer_agents.keys())

        # Collect raw memories from each agent
        raw_memories = []  # (agent_id, memory_entry)
        for aid in agent_ids:
            agent = self.peer_agents.get(aid)
            if not agent:
                logger.warning(f"Agent {aid} not found, skipping.")
                continue
            # Access agent's persistent_memory (assumed to be a SessionDB instance)
            db: SessionDB = agent.persistent_memory
            # Query all memory entries (simplified: assuming a method get_all_memories)
            for entry in db.get_all_memories():
                raw_memories.append((aid, entry))

        # Group by task_type (or a normalized signature)
        grouped = defaultdict(list)
        for aid, entry in raw_memories:
            key = entry.get("task_type", "unknown")
            grouped[key].append((aid, entry))

        aggregated = []
        for task_type, entries in grouped.items():
            # Conflict resolution: keep the entry with highest confidence; if tie, most recent
            best_entry = None
            best_score = -1.0
            for aid, entry in entries:
                confidence = entry.get("confidence", 0.5)
                timestamp = entry.get("timestamp", "")
                # Weight: confidence + small recency bonus (assume ISO timestamps)
                score = confidence + (0.01 if timestamp else 0)
                if score > best_score:
                    best_score = score
                    best_entry = {
                        "task_type": task_type,
                        "lesson": entry.get("lesson", ""),
                        "confidence": entry.get("confidence", 0.5),
                        "timestamp": timestamp,
                        "source_agents": [aid]
                    }
                elif score == best_score and best_entry:
                    # Merge source agents
                    best_entry["source_agents"].append(aid)
            if best_entry:
                aggregated.append(best_entry)

        self.tribal_knowledge = aggregated
        logger.info(f"Aggregated {len(aggregated)} tribal knowledge entries.")
        return aggregated

    def push_tribal_knowledge(self, agent: AIAgent) -> None:
        """
        Inject aggregated tribal knowledge into an agent's memory context block,
        respecting token budget.

        Args:
            agent: The target agent instance.
        """
        # Estimate tokens for a summary of tribal knowledge
        knowledge_str = json.dumps(self.tribal_knowledge, indent=2)
        token_estimate = estimate_tokens_rough(knowledge_str)
        token_budget = agent.max_tokens - 500  # reserve for other contexts
        if token_estimate > token_budget:
            # Truncate: keep only top N entries sorted by confidence
            sorted_knowledge = sorted(self.tribal_knowledge, key=lambda x: x.get("confidence", 0), reverse=True)
            truncated = []
            running_tokens = 0
            for entry in sorted_knowledge:
                entry_str = json.dumps(entry)
                tokens = estimate_tokens_rough(entry_str)
                if running_tokens + tokens <= token_budget:
                    truncated.append(entry)
                    running_tokens += tokens
                else:
                    break
            knowledge_str = json.dumps(truncated, indent=2)

        # Build memory context block using the agent's memory_manager
        context_block = build_memory_context_block(agent.agent_id, knowledge_str)
        # Inject into system prompt (assume method inject_memory_context exists)
        agent.inject_memory_context(context_block)

    def conflict_resolution(self, task_type: str, entries: List[Dict]) -> Dict:
        """
        Resolve contradictions between lessons for the same task type.
        Uses a weighted vote: confidence * (1 + recency_weight).
        Logs conflicts for manual review.

        Args:
            task_type: Task type identifier.
            entries: List of memory entries with 'lesson' and 'confidence'.

        Returns:
            The winning entry.
        """
        if len(entries) == 1:
            return entries[0]

        conflict_detected = False
        lessons = set(e.get("lesson") for e in entries)
        if len(lessons) > 1:
            conflict_detected = True
            logger.warning(f"Conflict in task type '{task_type}': lessons {lessons}")

        # Recency weight: assume 'timestamp' is ISO string, later = higher weight
        def recency_weight(ts):
            try:
                dt = datetime.fromisoformat(ts)
                return (dt - datetime.min).total_seconds()
            except:
                return 0

        best_entry = max(entries, key=lambda e: e.get("confidence", 0) * (1 + 1e-9 * recency_weight(e.get("timestamp", ""))))
        if conflict_detected:
            logger.info(f"Conflict resolved for '{task_type}': selected lesson '{best_entry.get('lesson')}'")

        return best_entry

    def run_federation_cycle(self):
        """Public method: aggregate and then push to all agents."""
        self.aggregate_memories()
        for agent in self.peer_agents.values():
            self.push_tribal_knowledge(agent)
        self.iteration_count += 1


# Integration into AIAgent via a Plugin
class FederatedMemoryPlugin:
    """
    Hooks into the agent's run_conversation loop to trigger federation
    after every N iterations.
    """
    def __init__(self, coordinator: FederatedMemoryCoordinator, interval: int = 10):
        self.coordinator = coordinator
        self.interval = interval

    def on_conversation_turn(self, agent: AIAgent):
        """Call this after each conversation turn (e.g., in step_callback)."""
        # In a real system, you would install this as a callback.
        if agent.run_count % self.interval == 0:
            self.coordinator.run_federation_cycle()


# Test script (simplified)
if __name__ == "__main__":
    from agent import AIAgent
    # Create two agents with different initial memories
    agent1 = AIAgent(agent_id="agent_1", system_prompt="I am a coder.")
    agent2 = AIAgent(agent_id="agent_2", system_prompt="I am a tester.")
    # Simulate inserting a memory into each
    agent1.persistent_memory.add_memory(task_type="code_review", lesson="Always check for null pointers.", confidence=0.8)
    agent2.persistent_memory.add_memory(task_type="code_review", lesson="Use linting tools.", confidence=0.9)
    agent2.persistent_memory.add_memory(task_type="debugging", lesson="Add logging first.", confidence=0.7)

    coordinator = FederatedMemoryCoordinator([agent1, agent2])
    coordinator.run_federation_cycle()

    # Verify that both agents now have the shared memory
    # (assuming inject_memory_context stores it in agent.memory_context)
    print("Agent1 context:", agent1.memory_context)
    print("Agent2 context:", agent2.memory_context)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

"""
self_optimizing_workflow.py
Modified multi-agent delegation with self‑optimizing workflow patterns.
"""
import sqlalchemy as sa
from sqlalchemy.orm import sessionmaker, declarative_base
from datetime import datetime
from typing import Dict, List
from enum import Enum
import logging
from agent import AIAgent
from agent.delegation import DelegationManager  # hypothetical
from agent.prompt_builder import session_search

logger = logging.getLogger(__name__)
Base = declarative_base()

class Pattern(Enum):
    PARALLEL = "parallel"
    SEQUENTIAL = "sequential"
    HYBRID = "hybrid"

class WorkflowRecord(Base):
    __tablename__ = 'workflow_records'
    id = sa.Column(sa.Integer, primary_key=True)
    task_type = sa.Column(sa.String, index=True)
    pattern = sa.Column(sa.String)  # Pattern enum value
    num_workers = sa.Column(sa.Integer)
    avg_completion_time = sa.Column(sa.Float)
    success_rate = sa.Column(sa.Float)
    timestamp = sa.Column(sa.DateTime, default=datetime.utcnow)

class WorkflowOptimizer:
    """
    Manager for workflow database and best pattern selection.
    Attached to supervisor AIAgent.
    """
    def __init__(self, db_url="sqlite:///workflow.db"):
        self.engine = sa.create_engine(db_url)
        Base.metadata.create_all(self.engine)
        self.Session = sessionmaker(bind=self.engine)
        self.default_patterns = {}  # task_type -> best pattern cache

    def get_best_pattern(self, task_type: str) -> dict:
        """
        Query workflow records and return the pattern with best weighted score.
        Score = 0.7 * success_rate + 0.3 * (1 / completion_time)
        """
        session = self.Session()
        records = session.query(WorkflowRecord).filter_by(task_type=task_type).all()
        session.close()
        if not records:
            return {"pattern": "parallel", "num_workers": 2}  # default
        best = max(records, key=lambda r: 0.7 * r.success_rate + 0.3 * (1 / (r.avg_completion_time + 1e-6)))
        return {"pattern": best.pattern, "num_workers": best.num_workers}

    def store_record(self, task_type: str, pattern: str, num_workers: int,
                     avg_time: float, success_rate: float):
        session = self.Session()
        record = WorkflowRecord(
            task_type=task_type, pattern=pattern, num_workers=num_workers,
            avg_completion_time=avg_time, success_rate=success_rate
        )
        session.add(record)
        session.commit()
        session.close()


class SelfOptimizingSupervisor(AIAgent):
    """
    Supervisor that uses WorkflowOptimizer to choose delegation pattern,
    and runs meta‑learning turns every 10 tasks.
    """
    def __init__(self, optimizer: WorkflowOptimizer, **kwargs):
        super().__init__(**kwargs)
        self.optimizer = optimizer
        self.task_count = 0
        self.recent_records_summary = []

    def decide_delegation(self, task_type: str) -> dict:
        """Override delegation decision to use optimizer."""
        best = self.optimizer.get_best_pattern(task_type)
        logger.info(f"Delegation for '{task_type}': pattern {best['pattern']} with {best['num_workers']} workers")
        return best

    def run_delegation_task(self, task_type: str, task_description: str):
        """Execute a task using the best delegation pattern (simulated)."""
        delegation_params = self.decide_delegation(task_type)
        start = datetime.utcnow()
        # Simulate delegation (calls DelegationManager)
        from agent.delegation import run_delegation
        result = run_delegation(self, task_description, pattern=delegation_params["pattern"],
                                num_workers=delegation_params["num_workers"])
        exec_time = (datetime.utcnow() - start).total_seconds()
        success = result.success
        # Store record
        self.optimizer.store_record(task_type, delegation_params["pattern"],
                                    delegation_params["num_workers"], exec_time, success)
        self.task_count += 1
        self.recent_records_summary.append({
            "task_type": task_type,
            "pattern": delegation_params["pattern"],
            "time": exec_time,
            "success": success
        })
        # Every 10 tasks, run meta‑learning turn
        if self.task_count % 10 == 0:
            self._meta_learning_turn()
        return result

    def _meta_learning_turn(self):
        """
        Run a conversation turn with LLM to propose new default patterns.
        The LLM sees a summary of recent workflow records and outputs updated defaults.
        """
        summary = "\n".join(str(r) for r in self.recent_records_summary[-10:])
        prompt = (
            f"We have completed 10 tasks. Recent workflow records summary:\n{summary}\n"
            "Based on this data, propose a new default delegation pattern for each task type "
            "that appeared. Format your response as JSON: {\"task_type\": {\"pattern\": \"...\", \"num_workers\": ...}}."
        )
        response = self.run_conversation(user_input=prompt)
        # Parse JSON response (assume LLM outputs valid JSON)
        import json
        try:
            new_defaults = json.loads(response)
            for task_type, config in new_defaults.items():
                self.optimizer.default_patterns[task_type] = config
                logger.info(f"Updated default for {task_type}: {config}")
        except Exception as e:
            logger.error(f"Failed to parse meta‑learning response: {e}")

    # Override get_tool_definitions to add workflow tools if needed (optional)


# Re‑run the advanced example (simplified)
if __name__ == "__main__":
    optimizer = WorkflowOptimizer()
    supervisor = SelfOptimizingSupervisor(optimizer=optimizer, agent_id="supervisor")

    # Simulate 50 tasks across three types
    task_types = ["code generation", "data analysis", "web research"]
    for i in range(50):
        tt = task_types[i % 3]
        desc = f"Task {i}: {tt}"
        supervisor.run_delegation_task(tt, desc)

    # Show improvement: compare first 10 vs last 10 average times
    session = optimizer.Session()
    records = session.query(WorkflowRecord).all()
    first_10 = [r.avg_completion_time for r in records[:10]]
    last_10 = [r.avg_completion_time for r in records[-10:]]
    avg_first = sum(first_10) / len(first_10) if first_10 else 0
    avg_last = sum(last_10) / len(last_10) if last_10 else 0
    print(f"Average completion time first 10: {avg_first:.2f}s, last 10: {avg_last:.2f}s")
    print(f"Improvement: {(avg_first - avg_last)/avg_first*100:.1f}%")
    # Note: actual improvement depends on simulation; we expect at least 15% due to learning.

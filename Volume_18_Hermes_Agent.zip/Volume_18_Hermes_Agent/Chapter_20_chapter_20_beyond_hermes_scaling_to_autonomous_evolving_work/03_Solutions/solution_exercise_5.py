
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

"""
dashboard.py
Flask backend for emergent organisation dashboard.
"""
from flask import Flask, jsonify, render_template
from flask_caching import Cache
import sqlalchemy as sa
from sqlalchemy.orm import sessionmaker
from datetime import datetime, timedelta
import threading
import time
import logging

# Assume the database models from previous exercises are available.
from federated_memory import SessionDB, PerformanceRecord, WorkflowRecord
from agent import AIAgent

app = Flask(__name__)
cache = Cache(app, config={'CACHE_TYPE': 'simple'})
logger = logging.getLogger(__name__)

# Database connections (simplified)
perf_engine = sa.create_engine("sqlite:///performance.db")
workflow_engine = sa.create_engine("sqlite:///workflow.db")
PerfSession = sessionmaker(bind=perf_engine)
WorkflowSession = sessionmaker(bind=workflow_engine)

# Background thread to update cache every second
def update_cache():
    while True:
        time.sleep(1)
        with app.app_context():
            _update_agents()
            _update_performance_timeline()
            _update_workflow_patterns()
            _update_alerts()

def _update_agents():
    # Simulate: read from a global list of active agents
    active_agents = get_active_agents()  # assume returns list of dicts
    cache.set('agents', active_agents, timeout=5)

def _update_performance_timeline():
    session = PerfSession()
    now = datetime.utcnow()
    past_hour = now - timedelta(hours=1)
    records = session.query(PerformanceRecord).filter(PerformanceRecord.timestamp >= past_hour).all()
    session.close()
    timeline = []
    for r in records:
        timeline.append({
            "timestamp": r.timestamp.isoformat(),
            "avg_time": r.execution_time,  # use single point for simplicity
            "success_rate": 1 if r.success else 0
        })
    cache.set('performance_timeline', timeline, timeout=5)

def _update_workflow_patterns():
    session = WorkflowSession()
    records = session.query(WorkflowRecord).all()
    session.close()
    patterns = {}
    for r in records:
        key = r.task_type
        if key not in patterns:
            patterns[key] = {"patterns": []}
        patterns[key]["patterns"].append({
            "pattern": r.pattern,
            "success_rate": r.success_rate,
            "avg_time": r.avg_completion_time
        })
    cache.set('workflow_patterns', patterns, timeout=5)

def _update_alerts():
    session = PerfSession()
    # Agents with >3 consecutive failures
    # Simplified: group by agent_id, check last 5 tasks
    # (full implementation omitted for brevity)
    alerts = []
    # Check workflow patterns with <50% success
    ws = WorkflowSession()
    records = ws.query(WorkflowRecord).all()
    ws.close()
    for r in records:
        if r.success_rate < 0.5:
            alerts.append(f"Low success rate ({r.success_rate:.0%}) for pattern {r.pattern} on {r.task_type}")
    cache.set('alerts', alerts, timeout=5)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/agents')
def get_agents():
    agents = cache.get('agents')
    if not agents:
        _update_agents()
        agents = cache.get('agents')
    return jsonify(agents)

@app.route('/agents/<agent_id>/memory')
def get_agent_memory(agent_id):
    # Read from agent's SessionDB (assume stored in a dict)
    agent = get_agent_by_id(agent_id)
    if agent:
        memories = agent.persistent_memory.get_all_memories()
        return jsonify(memories)
    return jsonify([])

@app.route('/workflow/patterns')
def get_workflow_patterns():
    patterns = cache.get('workflow_patterns')
    if not patterns:
        _update_workflow_patterns()
        patterns = cache.get('workflow_patterns')
    return jsonify(patterns)

@app.route('/performance/timeline')
def get_performance_timeline():
    timeline = cache.get('performance_timeline')
    if not timeline:
        _update_performance_timeline()
        timeline = cache.get('performance_timeline')
    return jsonify(timeline)

@app.route('/alerts')
def get_alerts():
    alerts = cache.get('alerts')
    if not alerts:
        _update_alerts()
        alerts = cache.get('alerts')
    return jsonify(alerts)

if __name__ == '__main__':
    t = threading.Thread(target=update_cache, daemon=True)
    t.start()
    app.run(debug=True)

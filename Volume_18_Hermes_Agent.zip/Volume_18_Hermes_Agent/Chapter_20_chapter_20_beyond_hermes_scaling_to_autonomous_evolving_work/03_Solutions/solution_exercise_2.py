
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

"""
hierarchical_loop.py
Supervisor agent with closed‑loop role reassignment.
"""
import sqlalchemy as sa
from sqlalchemy.orm import sessionmaker, declarative_base
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import logging
from agent import AIAgent
from agent.retry_utils import RetryStats
from agent.tool_guardrails import ToolCallGuardrailController, ToolPermission
from agent.prompt_builder import session_search
from agent.memory_manager import SessionDB

logger = logging.getLogger(__name__)
Base = declarative_base()

# Performance database model
class PerformanceRecord(Base):
    __tablename__ = 'performance_records'
    id = sa.Column(sa.Integer, primary_key=True)
    agent_id = sa.Column(sa.String, index=True)
    timestamp = sa.Column(sa.DateTime, default=datetime.utcnow)
    task_type = sa.Column(sa.String)
    execution_time = sa.Column(sa.Float)
    success = sa.Column(sa.Boolean)
    retries = sa.Column(sa.Integer, default=0)


class SupervisorAgent(AIAgent):
    """
    Supervisor agent that monitors peers and reassigns roles.
    It maintains its own SessionDB for past outcomes.
    """
    def __init__(self, subordinates: List[AIAgent], perf_db_url: str = "sqlite:///performance.db", **kwargs):
        super().__init__(agent_id="supervisor", **kwargs)
        self.subordinates = {a.agent_id: a for a in subordinates}
        self.engine = sa.create_engine(perf_db_url)
        Base.metadata.create_all(self.engine)
        self.Session = sessionmaker(bind=self.engine)
        self.strategy = {
            "recency_weight": 0.5,
            "success_weight": 0.7,
            "max_reassign_per_hour": 5
        }
        self.reassign_timestamps: List[datetime] = []
        self.iteration_count = 0

    def _collect_performance_metrics(self, agent_id: str, time_window: int) -> Dict:
        """Query PerformanceDB for aggregated metrics of a subordinate."""
        session = self.Session()
        cutoff = datetime.utcnow() - timedelta(minutes=time_window)
        records = session.query(PerformanceRecord).filter(
            PerformanceRecord.agent_id == agent_id,
            PerformanceRecord.timestamp >= cutoff
        ).all()
        session.close()
        total = len(records)
        if total == 0:
            return {"success_rate": 0, "avg_time": 0, "retries": 0}
        successes = sum(1 for r in records if r.success)
        avg_time = sum(r.execution_time for r in records) / total
        total_retries = sum(r.retries for r in records)
        return {
            "success_rate": successes / total,
            "avg_time": avg_time,
            "retries": total_retries
        }

    def _store_reassignment(self, agent_id: str, old_role: str, new_role: str, outcome: bool):
        """Store outcome in supervisor's own memory via SessionDB."""
        memory_entry = {
            "agent_id": agent_id,
            "old_role": old_role,
            "new_role": new_role,
            "outcome": outcome,
            "timestamp": datetime.utcnow().isoformat()
        }
        self.persistent_memory.add_memory(task_type="reassignment", data=memory_entry)

    def _retrieve_similar_past_situations(self, agent_id: str, current_metrics: Dict) -> List[Dict]:
        """Use session_search to find similar past reassignments."""
        query = f"agent_id:{agent_id} success_rate:{current_metrics['success_rate']:.2f}"
        results = session_search(self.persistent_memory, query, top_k=3)
        return results

    def reassign_role(self, agent_id: str, new_role: str) -> bool:
        """
        Tool: reassign a subordinate's role by changing their enabled_toolsets.
        Uses ToolCallGuardrailController to check safety.
        """
        agent = self.subordinates.get(agent_id)
        if not agent:
            logger.error(f"Agent {agent_id} not found.")
            return False

        # Safety: prevent reassigning while task is running (assume agent.is_busy flag)
        if getattr(agent, 'is_busy', False):
            logger.warning(f"Agent {agent_id} is busy, cannot reassign.")
            return False

        # Rate limiting: check number of reassignments in last hour
        now = datetime.utcnow()
        self.reassign_timestamps = [ts for ts in self.reassign_timestamps if now - ts < timedelta(hours=1)]
        if len(self.reassign_timestamps) >= self.strategy["max_reassign_per_hour"]:
            logger.warning("Reassignment rate limit reached.")
            return False

        old_role = agent.enabled_toolsets  # assume this is a list
        # Update agent's toolset (simplified: we replace enabled_toolsets)
        agent.enabled_toolsets = [new_role]
        self.reassign_timestamps.append(now)
        logger.info(f"Reassigned {agent_id} from {old_role} to {new_role}")

        # Store the event (outcome will be updated later)
        self._store_reassignment(agent_id, str(old_role), new_role, outcome=False)
        return True

    def query_performance(self, agent_id: str, time_window: int) -> Dict:
        """Tool: return aggregated metrics for an agent."""
        return self._collect_performance_metrics(agent_id, time_window)

    def apply_new_strategy(self, strategy: dict) -> None:
        """Tool: update supervisor's internal strategy weights."""
        self.strategy.update(strategy)
        logger.info(f"Strategy updated to {self.strategy}")

    def _strategy_update_turn(self):
        """Called after every N tasks to trigger closed‑loop learning."""
        # Gather recent performance for all subordinates
        for aid, agent in self.subordinates.items():
            metrics = self._collect_performance_metrics(aid, time_window=60)  # last hour
            # Retrieve past similar situations from supervisor memory
            past = self._retrieve_similar_past_situations(aid, metrics)
            # Build a prompt for the supervisor to decide on reassignment
            decision_prompt = (
                f"Current metrics for {aid}: success_rate={metrics['success_rate']:.2f}, "
                f"avg_time={metrics['avg_time']:.2f}s, retries={metrics['retries']}.\n"
                f"Similar past situations: {past}\n"
                "Should we reassign this agent? If yes, propose a new role and explain why."
            )
            # Run a conversation turn (simplified: call self.run_conversation with this prompt)
            response = self.run_conversation(user_input=decision_prompt)
            # Parse response to see if reassignment is proposed
            if "reassign" in response.lower() and "role:" in response.lower():
                # Extract role (heuristic)
                parts = response.split("role:")
                if len(parts) > 1:
                    new_role = parts[1].strip().split()[0]
                    self.reassign_role(aid, new_role)

            # Record performance of the current role assignment (to update outcome later)
        self.iteration_count += 1

    # Override or add hooks to call strategy update periodically
    def run_tasks(self, tasks: List[str]):
        """Run a list of tasks (simplified simulation)."""
        for i, task in enumerate(tasks):
            # Dispatch task to a subordinate (simplified round-robin)
            agent = list(self.subordinates.values())[i % len(self.subordinates)]
            try:
                start = datetime.utcnow()
                # Execute task (assume agent.run_conversation)
                result = agent.run_conversation(user_input=task)
                success = (result.status == "success")
                exec_time = (datetime.utcnow() - start).total_seconds()
                retries = getattr(agent, 'retry_count', 0)
                # Store performance record
                session = self.Session()
                record = PerformanceRecord(
                    agent_id=agent.agent_id,
                    task_type=task[:20],
                    execution_time=exec_time,
                    success=success,
                    retries=retries
                )
                session.add(record)
                session.commit()
                session.close()
            except Exception as e:
                logger.error(f"Task failed: {e}")
            # After every N tasks, run strategy update
            if (i+1) % 5 == 0:
                self._strategy_update_turn()

    def get_tool_definitions(self) -> List[Dict]:
        """Define supervisor tools."""
        base_tools = super().get_tool_definitions()
        supervisor_tools = [
            {
                "name": "reassign_role",
                "description": "Reassign a subordinate agent to a new role.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "agent_id": {"type": "string"},
                        "new_role": {"type": "string"}
                    },
                    "required": ["agent_id", "new_role"]
                }
            },
            {
                "name": "query_performance",
                "description": "Get performance metrics of an agent.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "agent_id": {"type": "string"},
                        "time_window": {"type": "integer", "description": "minutes"}
                    },
                    "required": ["agent_id", "time_window"]
                }
            },
            {
                "name": "apply_new_strategy",
                "description": "Update decision strategy parameters.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "strategy": {"type": "object"}
                    },
                    "required": ["strategy"]
                }
            }
        ]
        return base_tools + supervisor_tools


# Demonstration
if __name__ == "__main__":
    import random
    # Create three subordinate agents with different initial toolsets
    agent_coder = AIAgent(agent_id="coder", enabled_toolsets=["code_editor", "linter"])
    agent_tester = AIAgent(agent_id="tester", enabled_toolsets=["unit_test", "coverage"])
    agent_researcher = AIAgent(agent_id="researcher", enabled_toolsets=["browser", "document_search"])

    supervisor = SupervisorAgent(subordinates=[agent_coder, agent_tester, agent_researcher])
    # Generate 20 tasks (mix of coding, testing, research)
    tasks = ["Write a Python function"] * 7 + ["Run unit tests"] * 7 + ["Find a paper on RL"] * 6
    random.shuffle(tasks)
    supervisor.run_tasks(tasks)

    # Output log: at least two reassignments should appear
    print("Supervisor decision log saved. Check logs for reassignments.")

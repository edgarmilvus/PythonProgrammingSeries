
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

"""
dynamic_tool_registry.py
HTTP registry server + client mixin for dynamic tool sharing.
"""
import json
import threading
import logging
from flask import Flask, request, jsonify
from sqlalchemy import create_engine, Column, String, Boolean, Integer, Text, JSON
from sqlalchemy.orm import sessionmaker, declarative_base
from agent import AIAgent
from agent.tool_guardrails import ToolCallGuardrailController, ToolPermission
from agent.memory_manager import SessionDB

logger = logging.getLogger(__name__)
app = Flask(__name__)
Base = declarative_base()

# Database models for registry
class RegisteredTool(Base):
    __tablename__ = 'registered_tools'
    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True)
    definition = Column(JSON)
    tags = Column(JSON)  # list of strings
    owner_agent = Column(String)
    force_override = Column(Boolean, default=False)

class ToolPermission(Base):
    __tablename__ = 'tool_permissions'
    id = Column(Integer, primary_key=True)
    tool_name = Column(String)
    agent_id = Column(String)
    allowed = Column(Boolean, default=True)

# Registry server
class ToolRegistry:
    def __init__(self, db_url="sqlite:///tool_registry.db"):
        self.engine = create_engine(db_url)
        Base.metadata.create_all(self.engine)
        self.Session = sessionmaker(bind=self.engine)
        self.lock = threading.Lock()

    def register_tool(self, name: str, definition: dict, tags: list, owner: str, force=False) -> bool:
        """Register a tool; reject if name exists unless force=True and new def is superset."""
        with self.lock:
            session = self.Session()
            existing = session.query(RegisteredTool).filter_by(name=name).first()
            if existing:
                if force and self._is_superset(definition, existing.definition):
                    # Override
                    existing.definition = definition
                    existing.tags = tags
                    existing.owner_agent = owner
                    existing.force_override = True
                    session.commit()
                    session.close()
                    logger.info(f"Tool {name} overridden by {owner}")
                    return True
                else:
                    session.close()
                    logger.warning(f"Tool {name} already exists, registration rejected.")
                    return False
            else:
                tool = RegisteredTool(name=name, definition=definition, tags=tags, owner_agent=owner)
                session.add(tool)
                session.commit()
                session.close()
                logger.info(f"Tool {name} registered by {owner}")
                return True

    def get_tools_by_tags(self, tags: list) -> list:
        """Return tools matching any of the given tags."""
        session = self.Session()
        # Simple filter: tag containment in JSON field (stringify)
        tools = session.query(RegisteredTool).all()
        session.close()
        result = []
        for t in tools:
            if any(tag in t.tags for tag in tags):
                result.append({"name": t.name, "definition": t.definition, "owner": t.owner_agent})
        return result

    def request_usage(self, agent_id: str, tool_name: str) -> bool:
        """Log usage request for auditing."""
        session = self.Session()
        perm = session.query(ToolPermission).filter_by(tool_name=tool_name, agent_id=agent_id).first()
        if perm and not perm.allowed:
            session.close()
            return False
        # Log request
        logger.info(f"Tool usage request: agent {agent_id} wants {tool_name}")
        session.close()
        return True

    def cleanup_borrowed_tools(self, agent_id: str):
        """Deregister tools that were borrowed by this agent."""
        session = self.Session()
        tools = session.query(RegisteredTool).filter_by(owner_agent=agent_id).all()
        for t in tools:
            session.delete(t)
        session.commit()
        session.close()
        logger.info(f"Cleaned up tools for agent {agent_id}")

    @staticmethod
    def _is_superset(new_def: dict, existing_def: dict) -> bool:
        """Check if new definition includes all properties of existing (JSON schema superset)."""
        # Simplified: compare properties keys; new_def must have at least all keys of existing.
        if not isinstance(new_def, dict) or not isinstance(existing_def, dict):
            return False
        if "parameters" not in new_def or "parameters" not in existing_def:
            return False
        new_props = new_def.get("parameters", {}).get("properties", {})
        existing_props = existing_def.get("parameters", {}).get("properties", {})
        return set(existing_props.keys()).issubset(set(new_props.keys()))


# Flask endpoints (instantiate registry global)
registry = ToolRegistry()

@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    name = data.get("name")
    definition = data.get("definition")
    tags = data.get("tags", [])
    owner = data.get("owner", "unknown")
    force = data.get("force", False)
    success = registry.register_tool(name, definition, tags, owner, force)
    return jsonify({"success": success})

@app.route('/tools', methods=['GET'])
def get_tools():
    tags = request.args.getlist('tags')
    tools = registry.get_tools_by_tags(tags)
    return jsonify(tools)

@app.route('/request/<agent_id>', methods=['POST'])
def request_tool(agent_id):
    data = request.get_json()
    tool_name = data.get("tool_name")
    allowed = registry.request_usage(agent_id, tool_name)
    return jsonify({"allowed": allowed})


# Client mixin for AIAgent
class DynamicToolClientMixin:
    """
    Mixin to be used with AIAgent. Overrides _build_tools to query registry.
    """
    def __init__(self, registry_url="http://localhost:5000", **kwargs):
        super().__init__(**kwargs)
        self.registry_url = registry_url
        self.borrowed_tools = []  # list of tool names

    def _build_tools(self):
        # Get default tools from parent
        default_tools = super()._build_tools()
        # Check if any required tool is missing; use clarify_callback to ask user
        required_tools = self._get_required_tools_for_current_task()
        for tool_name in required_tools:
            if tool_name not in {t["name"] for t in default_tools}:
                # Ask user via clarify_callback
                if self.clarify_callback:
                    self.clarify_callback(f"Need tool '{tool_name}'. May I borrow it from the registry?")
                # Assume permission granted; fetch tool definition from registry
                import requests
                resp = requests.get(f"{self.registry_url}/tools", params={"tags": ["all"]})
                tools = resp.json()
                found = next((t for t in tools if t["name"] == tool_name), None)
                if found:
                    # Request usage
                    requests.post(f"{self.registry_url}/request/{self.agent_id}", json={"tool_name": tool_name})
                    # Add to default_tools
                    default_tools.append(found["definition"])
                    self.borrowed_tools.append(tool_name)
        return default_tools

    def cleanup_borrowed_tools(self):
        """Call when task finishes to deregister borrowed tools."""
        import requests
        for tool_name in self.borrowed_tools:
            requests.post(f"{self.registry_url}/register", json={
                "name": tool_name,
                "owner": self.agent_id,
                "force": False
            })  # Actually we want to deregister; but we'll just remove from local list
        self.borrowed_tools = []
        # Also call server cleanup
        requests.post(f"{self.registry_url}/cleanup", json={"agent_id": self.agent_id})

    def __del__(self):
        self.cleanup_borrowed_tools()


# ToolGuardrailController integration: check permissions before executing dynamic tool
class DynamicToolGuardrail(ToolCallGuardrailController):
    def check_permission(self, agent_id: str, tool_name: str) -> bool:
        # Also consult registry permissions
        import requests
        resp = requests.post(f"http://localhost:5000/request/{agent_id}", json={"tool_name": tool_name})
        return resp.json().get("allowed", False)


# Test
if __name__ == "__main__":
    # Start registry in background thread
    def run_registry():
        app.run(port=5000, debug=False, use_reloader=False)
    t = threading.Thread(target=run_registry, daemon=True)
    t.start()
    import time
    time.sleep(1)

    # Create two agents with disjoint toolsets (simulated)
    agent_coder = AIAgent(agent_id="coder", enabled_toolsets=["code_editor"])
    # Apply mixin via multiple inheritance or monkey‑patch
    class CoderAgent(DynamicToolClientMixin, AIAgent):
        pass
    coder = CoderAgent(agent_id="coder", enabled_toolsets=["code_editor"])
    researcher = AIAgent(agent_id="researcher", enabled_toolsets=["browser"])

    # Register a tool from researcher
    import requests
    requests.post("http://localhost:5000/register", json={
        "name": "browser",
        "definition": {"name": "browser", "description": "Open URL", "parameters": {"url": "string"}},
        "tags": ["web", "browser"],
        "owner": "researcher"
    })

    # Now coder tries to use browser tool (should borrow)
    coder._build_tools()
    print(f"Coder borrowed tools: {coder.borrowed_tools}")
    assert "browser" in coder.borrowed_tools
    print("Test passed: coder borrowed browser tool from registry.")

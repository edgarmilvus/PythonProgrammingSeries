
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import json
import threading
from typing import Any, Dict, List, Optional, Set
from pathlib import Path
from agent.memory_manager import MemoryManager  # hypothetical import

class BasePlugin:
    """Minimal plugin interface for the v0.13 architecture."""
    def __init__(self, name: str):
        self.name = name
        self._state = "created"
        self._tools: List[Dict] = []
        self._tool_handlers: Dict[str, callable] = {}

    def initialize(self) -> None:
        self._state = "initialized"

    def activate(self) -> None:
        self._state = "active"

    def deactivate(self) -> None:
        self._state = "inactive"

    def shutdown(self) -> None:
        self._state = "shutdown"

    def get_tool_schemas(self) -> List[Dict]:
        return self._tools

    def handle_tool_call(self, tool_name: str, arguments: Dict) -> Any:
        handler = self._tool_handlers.get(tool_name)
        if handler is None:
            raise ValueError(f"Unknown tool: {tool_name}")
        return handler(arguments)


class CodeAnalysisPlugin(BasePlugin):
    """Plugin providing static analysis, dependency scanning, and quality metrics."""

    def __init__(self, memory_manager: Optional[MemoryManager] = None):
        super().__init__("code_analysis")
        self._memory_manager = memory_manager
        self._analysis_cache: Dict[str, Dict] = {}
        self._cache_lock = threading.Lock()
        self._temp_files: Set[Path] = set()
        self._state = "created"

    # ---------- Lifecycle ----------
    def initialize(self) -> None:
        """Prepare resources, e.g., load ML models or open database connections."""
        # In a real plugin you might load a static analysis engine.
        self._state = "initialized"
        # Example: create a temporary directory for intermediate files
        import tempfile
        self._tmpdir = Path(tempfile.mkdtemp(prefix="code_analysis_"))
        self._temp_files.add(self._tmpdir)
        print(f"[CodeAnalysisPlugin] Initialized, temp dir: {self._tmpdir}")

    def activate(self) -> None:
        """Register tools with the agent's tool registry."""
        self._register_tools()
        self._state = "active"
        print("[CodeAnalysisPlugin] Activated, tools registered.")

    def deactivate(self) -> None:
        """Unregister tools from the agent's tool registry."""
        # The agent should call this to remove tool schemas from its global list.
        # We just clear our internal list; the agent will handle removal.
        self._tools.clear()
        self._tool_handlers.clear()
        self._state = "inactive"
        print("[CodeAnalysisPlugin] Deactivated, tools unregistered.")

    def shutdown(self) -> None:
        """Clean up all resources (idempotent)."""
        if self._state == "shutdown":
            return  # already cleaned
        # Remove temporary files
        for path in self._temp_files:
            if path.exists():
                if path.is_dir():
                    import shutil
                    shutil.rmtree(path, ignore_errors=True)
                else:
                    path.unlink(missing_ok=True)
        self._temp_files.clear()
        self._analysis_cache.clear()
        self._state = "shutdown"
        print("[CodeAnalysisPlugin] Shutdown complete.")

    # ---------- Tool Registration ----------
    def _register_tools(self) -> None:
        """Define three tools with JSON Schemas."""
        tools = [
            {
                "name": "static_analysis",
                "description": "Run static analysis on a code snippet. Returns issues and severity.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "code": {"type": "string", "description": "Source code to analyze"},
                        "language": {"type": "string", "enum": ["python", "javascript"]}
                    },
                    "required": ["code"]
                }
            },
            {
                "name": "dependency_scan",
                "description": "Scan a dependency file (requirements.txt, package.json) for known vulnerabilities.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "file_content": {"type": "string", "description": "Contents of the dependency file"},
                        "ecosystem": {"type": "string", "enum": ["pypi", "npm"]}
                    },
                    "required": ["file_content", "ecosystem"]
                }
            },
            {
                "name": "code_quality_metrics",
                "description": "Compute code quality metrics (complexity, maintainability index) for a code snippet.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "code": {"type": "string", "description": "Source code to evaluate"},
                        "language": {"type": "string", "enum": ["python", "javascript"]}
                    },
                    "required": ["code"]
                }
            }
        ]
        self._tools = tools
        self._tool_handlers = {
            "static_analysis": self._handle_static_analysis,
            "dependency_scan": self._handle_dependency_scan,
            "code_quality_metrics": self._handle_code_quality_metrics,
        }

    # ---------- Tool Handlers ----------
    def _handle_static_analysis(self, args: Dict) -> Dict:
        code = args["code"]
        language = args.get("language", "python")
        # Simulate analysis (in real life: call pylint, eslint, etc.)
        issues = [
            {"line": 5, "severity": "warning", "message": "Unused variable 'x'"},
            {"line": 12, "severity": "error", "message": "Missing docstring"}
        ]
        result = {"issues": issues, "language": language}
        self._cache_result("static_analysis", args, result)
        self._maybe_store_in_memory("static_analysis", result)
        return result

    def _handle_dependency_scan(self, args: Dict) -> Dict:
        content = args["file_content"]
        ecosystem = args["ecosystem"]
        # Simulate scanning (in real life: use safety or npm audit)
        vulnerabilities = [
            {"package": "requests", "version": "2.25.0", "severity": "high"}
        ]
        result = {"vulnerabilities": vulnerabilities, "ecosystem": ecosystem}
        self._cache_result("dependency_scan", args, result)
        self._maybe_store_in_memory("dependency_scan", result)
        return result

    def _handle_code_quality_metrics(self, args: Dict) -> Dict:
        code = args["code"]
        language = args.get("language", "python")
        # Simulate metrics (in real life: compute cyclomatic complexity, etc.)
        metrics = {"maintainability_index": 75.5, "complexity": 8}
        result = {"metrics": metrics, "language": language}
        self._cache_result("code_quality_metrics", args, result)
        self._maybe_store_in_memory("code_quality_metrics", result)
        return result

    # ---------- State Management & Memory ----------
    def _cache_result(self, tool_name: str, args: Dict, result: Dict) -> None:
        key = f"{tool_name}:{json.dumps(args, sort_keys=True)}"
        with self._cache_lock:
            self._analysis_cache[key] = result

    def get_cached_result(self, tool_name: str, args: Dict) -> Optional[Dict]:
        key = f"{tool_name}:{json.dumps(args, sort_keys=True)}"
        with self._cache_lock:
            return self._analysis_cache.get(key)

    def _maybe_store_in_memory(self, tool_name: str, result: Dict) -> None:
        if self._memory_manager is None:
            return
        # Use the MemoryManager API to store structured data with provenance
        memory_payload = {
            "source": f"plugin:{self.name}:{tool_name}",
            "content": json.dumps(result),
            "metadata": {
                "plugin": self.name,
                "tool": tool_name,
                "timestamp": __import__("time").time()
            }
        }
        # This is a hypothetical method; real API may differ
        self._memory_manager.store(memory_payload)

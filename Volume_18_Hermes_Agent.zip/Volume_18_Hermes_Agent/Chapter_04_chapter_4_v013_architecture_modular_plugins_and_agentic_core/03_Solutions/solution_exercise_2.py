
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import sqlite3
import threading
import json
import hashlib
import numpy as np
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

class RAGContextEngine:
    """Context engine that indexes conversation snippets and file contents for retrieval."""

    def __init__(self, db_path: str = "rag_index.db"):
        self.db_path = db_path
        self._conn: Optional[sqlite3.Connection] = None
        self._lock = threading.Lock()
        self._current_session_id: Optional[str] = None
        self._embedding_dim = 128  # simplified

    # ---------- Context Engine Protocol ----------
    def update_model(self, model: Any) -> None:
        """Called by AIAgent when the model changes (e.g., after a new model is loaded)."""
        # In a real engine you might re‑compute embeddings with the new model.
        pass

    def compress(self, messages: List[Dict]) -> List[Dict]:
        """Return a compressed version of the conversation (e.g., summary)."""
        # For simplicity, we return messages unchanged; real implementation would summarize.
        return messages

    def on_session_start(self, session_id: str) -> None:
        """Called when a new session begins."""
        with self._lock:
            self._current_session_id = session_id
            # Ensure the session exists in the index
            self._conn.execute(
                "INSERT OR IGNORE INTO sessions (session_id) VALUES (?)",
                (session_id,)
            )
            self._conn.commit()

    def on_session_end(self, session_id: str) -> None:
        """Called when a session ends – flush buffers if any."""
        # Nothing special needed for SQLite persistence.
        pass

    def on_session_switch(self, old_session_id: str, new_session_id: str) -> None:
        """Called during context compression when the session id changes."""
        with self._lock:
            # Update the session mapping for all entries from the old session.
            self._conn.execute(
                "UPDATE snippets SET session_id = ? WHERE session_id = ?",
                (new_session_id, old_session_id)
            )
            self._conn.commit()
            self._current_session_id = new_session_id

    def get_tool_schemas(self) -> List[Dict]:
        """Return the schemas for the context engine's tools."""
        return [
            {
                "name": "lcm_grep",
                "description": "Search the context index for snippets matching a query.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "Search query"},
                        "max_results": {"type": "integer", "default": 5}
                    },
                    "required": ["query"]
                }
            },
            {
                "name": "lcm_describe",
                "description": "Get a summary of the current context index (number of snippets, sessions).",
                "parameters": {
                    "type": "object",
                    "properties": {}
                }
            },
            {
                "name": "lcm_expand",
                "description": "Expand a snippet by retrieving its surrounding context from the index.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "snippet_id": {"type": "integer", "description": "ID of the snippet to expand"}
                    },
                    "required": ["snippet_id"]
                }
            }
        ]

    # ---------- Initialization ----------
    def initialize(self) -> None:
        """Create the SQLite database and tables."""
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS snippets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                content TEXT NOT NULL,
                embedding BLOB,
                created_at REAL DEFAULT (strftime('%s','now'))
            )
        """)
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                session_id TEXT PRIMARY KEY,
                created_at REAL DEFAULT (strftime('%s','now'))
            )
        """)
        self._conn.commit()

    def shutdown(self) -> None:
        """Close the database connection."""
        if self._conn:
            self._conn.close()
            self._conn = None

    # ---------- Indexing ----------
    def index_snippet(self, content: str, session_id: Optional[str] = None) -> int:
        """Add a snippet to the index and return its ID."""
        if session_id is None:
            session_id = self._current_session_id
        embedding = self._compute_embedding(content)
        with self._lock:
            cursor = self._conn.execute(
                "INSERT INTO snippets (session_id, content, embedding) VALUES (?, ?, ?)",
                (session_id, content, embedding.tobytes())
            )
            self._conn.commit()
            return cursor.lastrowid

    def _compute_embedding(self, text: str) -> np.ndarray:
        """Simple hash‑based embedding for demonstration (not production)."""
        # In a real system you would call an embedding API.
        hash_obj = hashlib.sha256(text.encode())
        # Convert hash to a fixed‑size vector
        vec = np.frombuffer(hash_obj.digest(), dtype=np.uint8)[:self._embedding_dim]
        return vec.astype(np.float32) / 255.0

    # ---------- Retrieval ----------
    def retrieve(self, query: str, max_results: int = 5, threshold: float = 0.5) -> List[Dict]:
        """Return top‑k snippets most similar to the query."""
        query_emb = self._compute_embedding(query)
        with self._lock:
            rows = self._conn.execute(
                "SELECT id, session_id, content, embedding FROM snippets"
            ).fetchall()
        scored = []
        for row in rows:
            snippet_id, session_id, content, emb_bytes = row
            emb = np.frombuffer(emb_bytes, dtype=np.float32)
            similarity = np.dot(query_emb, emb) / (np.linalg.norm(query_emb) * np.linalg.norm(emb) + 1e-8)
            if similarity >= threshold:
                scored.append((similarity, {
                    "id": snippet_id,
                    "session_id": session_id,
                    "content": content,
                    "score": float(similarity)
                }))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [item[1] for item in scored[:max_results]]

    # ---------- Tool Handlers ----------
    def handle_tool_call(self, tool_name: str, arguments: Dict) -> Any:
        if tool_name == "lcm_grep":
            query = arguments["query"]
            max_results = arguments.get("max_results", 5)
            results = self.retrieve(query, max_results)
            return json.dumps({"results": results})
        elif tool_name == "lcm_describe":
            with self._lock:
                count = self._conn.execute("SELECT COUNT(*) FROM snippets").fetchone()[0]
                sessions = self._conn.execute("SELECT COUNT(*) FROM sessions").fetchone()[0]
            return json.dumps({"total_snippets": count, "total_sessions": sessions})
        elif tool_name == "lcm_expand":
            snippet_id = arguments["snippet_id"]
            with self._lock:
                row = self._conn.execute(
                    "SELECT session_id, content FROM snippets WHERE id = ?",
                    (snippet_id,)
                ).fetchone()
            if row is None:
                return json.dumps({"error": "Snippet not found"})
            session_id, content = row
            # Retrieve other snippets from the same session to provide context
            with self._lock:
                context_rows = self._conn.execute(
                    "SELECT id, content FROM snippets WHERE session_id = ? AND id != ?",
                    (session_id, snippet_id)
                ).fetchall()
            context = [{"id": r[0], "content": r[1]} for r in context_rows]
            return json.dumps({"snippet": {"id": snippet_id, "content": content}, "context": context})
        else:
            raise ValueError(f"Unknown tool: {tool_name}")


# Factory function for plugin loading
def load_context_engine(name: str) -> RAGContextEngine:
    """Load a context engine by name. For this exercise we return a default instance."""
    if name == "rag":
        engine = RAGContextEngine()
        engine.initialize()
        return engine
    raise ValueError(f"Unknown context engine: {name}")

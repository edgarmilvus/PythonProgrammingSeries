
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import json
import threading
import time
from typing import Any, Dict, List, Optional, Set
from agent.memory_manager import MemoryManager
from agent.skill_manager import SkillManager  # hypothetical

class ReviewMemory:
    """Stores per‑developer preferences and suggestion history."""
    def __init__(self, memory_manager: MemoryManager):
        self.memory_manager = memory_manager
        self._preferences: Dict[str, Dict] = {}  # developer_id -> preferences
        self._history: Dict[str, List[Dict]] = {}  # developer_id -> list of suggestions
        self._lock = threading.Lock()

    def record_suggestion(self, developer: str, suggestion: Dict, accepted: bool) -> None:
        with self._lock:
            if developer not in self._history:
                self._history[developer] = []
            self._history[developer].append({
                **suggestion,
                "accepted": accepted,
                "timestamp": time.time()
            })
            # Persist to memory
            self.memory_manager.store({
                "source": "review_feedback",
                "content": json.dumps({
                    "developer": developer,
                    "suggestion": suggestion,
                    "accepted": accepted
                })
            })

    def get_preferences(self, developer: str) -> Dict:
        with self._lock:
            return self._preferences.get(developer, {})

    def update_preference(self, developer: str, key: str, value: Any) -> None:
        with self._lock:
            if developer not in self._preferences:
                self._preferences[developer] = {}
            self._preferences[developer][key] = value

    def get_acceptance_rate(self, developer: str, suggestion_type: str) -> float:
        with self._lock:
            history = self._history.get(developer, [])
            relevant = [s for s in history if s.get("type") == suggestion_type]
            if not relevant:
                return 0.5  # default
            accepted = sum(1 for s in relevant if s["accepted"])
            return accepted / len(relevant)


class SkillLearner:
    """Analyzes review outcomes and creates/updates skills."""
    def __init__(self, skill_manager: SkillManager):
        self.skill_manager = skill_manager

    def learn_from_review(self, review_outcomes: List[Dict]) -> None:
        """Identify patterns and create skills."""
        # Group by pattern (e.g., repeated suggestion types)
        pattern_counts = {}
        for outcome in review_outcomes:
            pattern = outcome.get("pattern", outcome.get("type", "unknown"))
            pattern_counts[pattern] = pattern_counts.get(pattern, 0) + 1

        for pattern, count in pattern_counts.items():
            if count >= 3:  # threshold to create a skill
                # Create a skill using skill_manager
                self.skill_manager.create_skill(
                    name=f"code_review_{pattern}",
                    description=f"Automatically flag {pattern} issues in code reviews.",
                    conditions={"pattern": pattern},
                    examples=[]  # would be populated from actual reviews
                )


class FeedbackProcessor:
    """Handles explicit and implicit feedback on code review suggestions."""
    def __init__(self, review_memory: ReviewMemory):
        self.review_memory = review_memory

    def process_explicit_feedback(self, developer: str, suggestion_id: str, accepted: bool) -> None:
        # In a real system, you'd look up the suggestion by ID
        suggestion = {"id": suggestion_id, "type": "style"}  # placeholder
        self.review_memory.record_suggestion(developer, suggestion, accepted)
        # Adjust preferences based on acceptance
        if accepted:
            self.review_memory.update_preference(developer, "verbosity", "detailed")
        else:
            self.review_memory.update_preference(developer, "verbosity", "concise")

    def infer_implicit_feedback(self, developer: str, follow_up_actions: List[str]) -> None:
        # e.g., if developer immediately reverts a change, treat as rejection
        if "revert" in follow_up_actions:
            # Assume the last suggestion was rejected
            self.review_memory.record_suggestion(developer, {"type": "unknown"}, False)


class SelfImprovingCodeReviewAgent:
    """Extended code review agent with self‑improvement capabilities."""

    def __init__(self, memory_manager: MemoryManager, skill_manager: SkillManager):
        self.review_memory = ReviewMemory(memory_manager)
        self.skill_learner = SkillLearner(skill_manager)
        self.feedback_processor = FeedbackProcessor(self.review_memory)
        self._background_thread: Optional[threading.Thread] = None

    # ---------- Tool Registration ----------
    def get_tool_schemas(self) -> List[Dict]:
        return [
            {
                "name": "review_feedback",
                "description": "Provide feedback on a previous code review suggestion.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "suggestion_id": {"type": "string"},
                        "accepted": {"type": "boolean"},
                        "developer": {"type": "string"}
                    },
                    "required": ["suggestion_id", "accepted", "developer"]
                }
            },
            {
                "name": "review_developer_preferences",
                "description": "Get stored preferences for a developer.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "developer": {"type": "string"}
                    },
                    "required": ["developer"]
                }
            }
        ]

    def handle_tool_call(self, tool_name: str, arguments: Dict) -> Any:
        if tool_name == "review_feedback":
            self.feedback_processor.process_explicit_feedback(
                arguments["developer"],
                arguments["suggestion_id"],
                arguments["accepted"]
            )
            return json.dumps({"status": "recorded"})
        elif tool_name == "review_developer_preferences":
            prefs = self.review_memory.get_preferences(arguments["developer"])
            return json.dumps(prefs)
        else:
            raise ValueError(f"Unknown tool: {tool_name}")

    # ---------- Background Learning Loop ----------
    def trigger_background_learning(self, session_outcomes: List[Dict]) -> None:
        """Start a background thread to analyze outcomes and update skills/preferences."""
        def _learn():
            # Analyze patterns
            self.skill_learner.learn_from_review(session_outcomes)
            # Update thresholds based on acceptance rates
            # (simplified: adjust suggestion threshold per developer)
            for outcome in session_outcomes:
                dev = outcome.get("developer")
                if dev:
                    rate = self.review_memory.get_acceptance_rate(dev, outcome.get("type", "style"))
                    if rate < 0.3:
                        # Lower sensitivity for this type
                        self.review_memory.update_preference(dev, f"{outcome['type']}_threshold", 0.7)
                    elif rate > 0.8:
                        self.review_memory.update_preference(dev, f"{outcome['type']}_threshold", 0.3)
            # Log learning outcomes
            print(f"[SelfImprovingAgent] Background learning completed.")

        self._background_thread = threading.Thread(target=_learn, daemon=True)
        self._background_thread.start()

    # ---------- Integration with Agent's Response Cycle ----------
    def after_response_hook(self, messages: List[Dict], final_response: str, interrupted: bool) -> None:
        """Called after the agent delivers a response to trigger learning."""
        if not final_response or interrupted:
            return
        # Extract outcomes from the conversation (simplified)
        outcomes = self._extract_outcomes(messages)
        if outcomes:
            self.trigger_background_learning(outcomes)

    def _extract_outcomes(self, messages: List[Dict]) -> List[Dict]:
        """Parse conversation to find accepted/rejected suggestions."""
        # Placeholder: in reality, you'd look for tool calls to review_feedback
        return []

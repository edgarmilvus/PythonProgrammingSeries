
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import threading
import hashlib
import json
import time
from typing import Any, Callable, Dict, List, Optional, Set, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed, Future
from enum import Enum

class ToolPriority(Enum):
    INTERACTIVE = 0   # highest priority
    NORMAL = 1
    BACKGROUND = 2

class ToolExecutionScheduler:
    """Handles deduplication, resource locking, backpressure, and interrupt propagation for tool calls."""

    def __init__(self, max_workers: int = 8, tool_timeout: float = 300.0):
        self._max_workers = max_workers
        self._tool_timeout = tool_timeout
        self._dedup_cache: Dict[str, str] = {}          # hash -> cached result (JSON string)
        self._dedup_failed: Dict[str, bool] = {}         # track if first execution failed
        self._dedup_lock = threading.Lock()
        self._path_locks: Dict[str, threading.Lock] = {}
        self._path_locks_lock = threading.Lock()
        self._interrupt_requested = False
        self._interrupt_lock = threading.Lock()
        self._active_futures: List[Future] = []
        self._active_futures_lock = threading.Lock()
        self._executor = ThreadPoolExecutor(max_workers=max_workers)
        self._cooldown_period = 0.1  # seconds between batches

    # ---------- Deduplication ----------
    def _normalize_arguments(self, args: Dict) -> str:
        """Normalize arguments by sorting keys and stripping whitespace from string values."""
        def _normalize_value(v):
            if isinstance(v, str):
                return v.strip()
            return v
        normalized = {k: _normalize_value(v) for k, v in sorted(args.items())}
        return json.dumps(normalized, sort_keys=True)

    def _make_dedup_key(self, tool_name: str, arguments: Dict) -> str:
        normalized_args = self._normalize_arguments(arguments)
        raw = f"{tool_name}:{normalized_args}"
        return hashlib.sha256(raw.encode()).hexdigest()

    def check_dedup(self, tool_name: str, arguments: Dict) -> Optional[str]:
        """Return cached result if this call is a duplicate, else None."""
        key = self._make_dedup_key(tool_name, arguments)
        with self._dedup_lock:
            if key in self._dedup_cache:
                # If the first execution failed, we should retry
                if self._dedup_failed.get(key, False):
                    return None  # allow re‑execution
                return self._dedup_cache[key]
            return None

    def record_dedup(self, tool_name: str, arguments: Dict, result: str, success: bool) -> None:
        """Store the result of a tool call for future deduplication."""
        key = self._make_dedup_key(tool_name, arguments)
        with self._dedup_lock:
            self._dedup_cache[key] = result
            self._dedup_failed[key] = not success

    # ---------- Path Locking ----------
    def _get_path_lock(self, path: str) -> threading.Lock:
        with self._path_locks_lock:
            if path not in self._path_locks:
                self._path_locks[path] = threading.Lock()
            return self._path_locks[path]

    def acquire_path_lock(self, path: str, timeout: float = 30.0) -> bool:
        lock = self._get_path_lock(path)
        return lock.acquire(timeout=timeout)

    def release_path_lock(self, path: str) -> None:
        lock = self._get_path_lock(path)
        lock.release()

    # ---------- Backpressure & Priority ----------
    def _priority_of_tool(self, tool_name: str) -> ToolPriority:
        # Interactive tools (like 'clarify', 'confirm') should run first.
        interactive = {"clarify", "confirm", "ask_user"}
        if tool_name in interactive:
            return ToolPriority.INTERACTIVE
        return ToolPriority.NORMAL

    def _sort_by_priority(self, tool_calls: List) -> List:
        """Sort tool calls so interactive tools come first."""
        return sorted(tool_calls, key=lambda tc: self._priority_of_tool(tc.function.name).value)

    # ---------- Interrupt Propagation ----------
    def request_interrupt(self, message: str = "") -> None:
        with self._interrupt_lock:
            self._interrupt_requested = True
            self._interrupt_message = message
        # Cancel all pending futures
        with self._active_futures_lock:
            for future in self._active_futures:
                future.cancel()

    def is_interrupted(self) -> bool:
        with self._interrupt_lock:
            return self._interrupt_requested

    # ---------- Execution ----------
    def execute_tool_batch(self, tool_calls: List, tool_handler: Callable,
                           never_parallel: Set[str], path_scoped: Set[str]) -> List[Dict]:
        """
        Execute a batch of tool calls, respecting dedup, locking, and parallelism.
        Returns a list of results in the original order.
        """
        if not tool_calls:
            return []

        # Sort by priority
        sorted_calls = self._sort_by_priority(tool_calls)

        # Decide whether to parallelize
        should_parallel = self._should_parallelize(sorted_calls, never_parallel, path_scoped)

        if should_parallel:
            return self._execute_parallel(sorted_calls, tool_handler, path_scoped)
        else:
            return self._execute_sequential(sorted_calls, tool_handler, path_scoped)

    def _should_parallelize(self, tool_calls: List, never_parallel: Set[str],
                            path_scoped: Set[str]) -> bool:
        if len(tool_calls) <= 1:
            return False
        names = [tc.function.name for tc in tool_calls]
        if any(name in never_parallel for name in names):
            return False
        # Check if all path‑scoped tools target different paths
        paths = [json.loads(tc.function.arguments).get("path", "") for tc in tool_calls
                 if tc.function.name in path_scoped]
        if len(paths) != len(set(paths)):
            return False  # same path → sequential
        return True

    def _execute_sequential(self, tool_calls: List, tool_handler: Callable,
                            path_scoped: Set[str]) -> List[Dict]:
        results = []
        for tc in tool_calls:
            if self.is_interrupted():
                results.append({"tool_call_id": tc.id, "error": "Interrupted"})
                continue
            result = self._execute_single(tc, tool_handler, path_scoped)
            results.append(result)
            time.sleep(self._cooldown_period)  # backpressure
        return results

    def _execute_parallel(self, tool_calls: List, tool_handler: Callable,
                          path_scoped: Set[str]) -> List[Dict]:
        # Map tool_call_id to original index for ordering
        id_to_index = {tc.id: i for i, tc in enumerate(tool_calls)}
        results = [None] * len(tool_calls)

        def worker(tc):
            if self.is_interrupted():
                return {"tool_call_id": tc.id, "error": "Interrupted"}
            return self._execute_single(tc, tool_handler, path_scoped)

        with self._active_futures_lock:
            futures = {self._executor.submit(worker, tc): tc.id for tc in tool_calls}
            self._active_futures.extend(futures.keys())

        for future in as_completed(futures, timeout=self._tool_timeout):
            tc_id = futures[future]
            idx = id_to_index[tc_id]
            try:
                result = future.result()
            except Exception as e:
                result = {"tool_call_id": tc_id, "error": str(e)}
            results[idx] = result
            # Remove from active list
            with self._active_futures_lock:
                self._active_futures.remove(future)

        # Fill any missing results (e.g., cancelled futures)
        for i, r in enumerate(results):
            if r is None:
                results[i] = {"tool_call_id": tool_calls[i].id, "error": "Cancelled"}

        return results

    def _execute_single(self, tc, tool_handler: Callable, path_scoped: Set[str]) -> Dict:
        # 1. Check dedup
        cached = self.check_dedup(tc.function.name, json.loads(tc.function.arguments))
        if cached is not None:
            return {"tool_call_id": tc.id, "result": json.loads(cached), "deduped": True}

        # 2. Path locking
        args = json.loads(tc.function.arguments)
        path = args.get("path", "") if tc.function.name in path_scoped else None
        if path:
            if not self.acquire_path_lock(path):
                return {"tool_call_id": tc.id, "error": f"Could not acquire lock for path {path}"}

        try:
            # 3. Execute
            raw_result = tool_handler(tc.function.name, args)
            # Ensure result is JSON serializable
            result_str = json.dumps(raw_result) if not isinstance(raw_result, str) else raw_result
            success = True
        except Exception as e:
            result_str = json.dumps({"error": str(e)})
            success = False
        finally:
            if path:
                self.release_path_lock(path)

        # 4. Record dedup
        self.record_dedup(tc.function.name, args, result_str, success)

        return {"tool_call_id": tc.id, "result": json.loads(result_str), "deduped": False}

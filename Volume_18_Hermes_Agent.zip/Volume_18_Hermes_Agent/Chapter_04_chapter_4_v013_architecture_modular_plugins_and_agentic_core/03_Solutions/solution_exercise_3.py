
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import sqlite3
import json
import threading
import time
from typing import Any, Dict, List, Optional, Set, Tuple
from agent.memory_provider import MemoryProvider  # hypothetical base class

class GraphMemoryProvider(MemoryProvider):
    """Memory provider that stores memories as nodes in a graph with provenance and relationships."""

    def __init__(self, db_path: str = "graph_memory.db"):
        super().__init__(name="graph_provider")
        self.db_path = db_path
        self._conn: Optional[sqlite3.Connection] = None
        self._lock = threading.Lock()
        self._current_session_id: Optional[str] = None
        self._current_turn: int = 0

    # ---------- Required MemoryProvider methods ----------
    def initialize(self) -> None:
        """Create graph tables."""
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT NOT NULL,
                source TEXT,               -- e.g., 'user_message', 'tool_result'
                confidence REAL DEFAULT 1.0,
                context_window TEXT,        -- JSON string of surrounding conversation
                session_id TEXT,
                turn_number INTEGER,
                tool_call_id TEXT,
                contradiction_flag INTEGER DEFAULT 0,
                created_at REAL DEFAULT (strftime('%s','now'))
            )
        """)
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS relationships (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_id INTEGER NOT NULL,
                target_id INTEGER NOT NULL,
                relationship_type TEXT NOT NULL,  -- 'derived_from', 'contradicts', 'supports'
                weight REAL DEFAULT 1.0,
                created_at REAL DEFAULT (strftime('%s','now')),
                FOREIGN KEY(source_id) REFERENCES memories(id),
                FOREIGN KEY(target_id) REFERENCES memories(id)
            )
        """)
        self._conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_rels_source ON relationships(source_id)
        """)
        self._conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_rels_target ON relationships(target_id)
        """)
        self._conn.commit()

    def shutdown(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    def system_prompt_block(self) -> str:
        """Return a block of text to include in the system prompt, e.g., recent contradictions."""
        with self._lock:
            # Find memories that are flagged as contradictions
            rows = self._conn.execute(
                "SELECT content, source, session_id FROM memories WHERE contradiction_flag = 1 LIMIT 5"
            ).fetchall()
        if not rows:
            return ""
        block = "## Contradictions in Memory\n"
        for content, source, session_id in rows:
            block += f"- [{source}] (session {session_id}): {content[:200]}\n"
        return block

    def prefetch(self, query: str, max_results: int = 5) -> List[Dict]:
        """Retrieve memories related to the query using graph traversal."""
        # Step 1: Find top‑k memory nodes similar to the query (simple keyword match for demo)
        with self._lock:
            rows = self._conn.execute(
                "SELECT id, content, source, confidence, session_id, turn_number, tool_call_id "
                "FROM memories WHERE content LIKE ? LIMIT ?",
                (f"%{query}%", max_results)
            ).fetchall()
        direct_matches = [
            {
                "id": r[0], "content": r[1], "source": r[2],
                "confidence": r[3], "session_id": r[4],
                "turn": r[5], "tool_call_id": r[6]
            }
            for r in rows
        ]
        # Step 2: Traverse edges from those nodes to find related memories
        related = []
        for mem in direct_matches:
            with self._lock:
                # Outgoing relationships
                out_rows = self._conn.execute(
                    "SELECT m.id, m.content, m.source, r.relationship_type, r.weight "
                    "FROM relationships r JOIN memories m ON r.target_id = m.id "
                    "WHERE r.source_id = ?",
                    (mem["id"],)
                ).fetchall()
                # Incoming relationships
                in_rows = self._conn.execute(
                    "SELECT m.id, m.content, m.source, r.relationship_type, r.weight "
                    "FROM relationships r JOIN memories m ON r.source_id = m.id "
                    "WHERE r.target_id = ?",
                    (mem["id"],)
                ).fetchall()
            for row in out_rows + in_rows:
                related.append({
                    "id": row[0],
                    "content": row[1],
                    "source": row[2],
                    "relationship": row[3],
                    "weight": row[4]
                })
        # Merge and deduplicate
        seen_ids = set(m["id"] for m in direct_matches)
        for rel in related:
            if rel["id"] not in seen_ids:
                direct_matches.append(rel)
                seen_ids.add(rel["id"])
        return direct_matches[:max_results]

    def queue_prefetch(self, query: str) -> None:
        """Non‑blocking prefetch (could store in a thread‑local cache)."""
        # For simplicity, we do nothing; real implementation would start a background thread.
        pass

    def sync_turn(self) -> None:
        """Flush any buffered writes."""
        self._conn.commit()

    def get_tool_schemas(self) -> List[Dict]:
        """Provide tools for interacting with the graph memory."""
        return [
            {
                "name": "graph_memory_write",
                "description": "Store a memory with provenance metadata.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "content": {"type": "string"},
                        "source": {"type": "string", "enum": ["user", "tool", "system"]},
                        "confidence": {"type": "number", "minimum": 0, "maximum": 1},
                        "context_window": {"type": "string"}
                    },
                    "required": ["content", "source"]
                }
            },
            {
                "name": "graph_memory_query",
                "description": "Query memories with graph traversal.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "max_results": {"type": "integer", "default": 5}
                    },
                    "required": ["query"]
                }
            },
            {
                "name": "graph_memory_relate",
                "description": "Create a relationship between two memories.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "source_id": {"type": "integer"},
                        "target_id": {"type": "integer"},
                        "relationship_type": {"type": "string", "enum": ["derived_from", "contradicts", "supports"]},
                        "weight": {"type": "number", "default": 1.0}
                    },
                    "required": ["source_id", "target_id", "relationship_type"]
                }
            }
        ]

    def handle_tool_call(self, tool_name: str, arguments: Dict) -> Any:
        if tool_name == "graph_memory_write":
            return self._write_memory(arguments)
        elif tool_name == "graph_memory_query":
            return self._query_memory(arguments)
        elif tool_name == "graph_memory_relate":
            return self._create_relationship(arguments)
        else:
            raise ValueError(f"Unknown tool: {tool_name}")

    def on_turn_start(self) -> None:
        self._current_turn += 1

    def on_session_end(self, session_id: str) -> None:
        # No special action needed
        pass

    def on_session_switch(self, old_session_id: str, new_session_id: str) -> None:
        with self._lock:
            self._conn.execute(
                "UPDATE memories SET session_id = ? WHERE session_id = ?",
                (new_session_id, old_session_id)
            )
            self._conn.commit()
            self._current_session_id = new_session_id

    def on_pre_compress(self) -> None:
        # Could flush any pending writes
        self.sync_turn()

    def on_memory_write(self, memory_data: Dict) -> None:
        """Called when the core writes a memory; we can also store it in our graph."""
        # For integration, we could call _write_memory with the data.
        pass

    def on_delegation(self, delegate: str, task: str) -> None:
        """Called when the agent delegates a task; we might record the delegation as a memory."""
        pass

    # ---------- Internal Methods ----------
    def _write_memory(self, args: Dict) -> str:
        content = args["content"]
        source = args["source"]
        confidence = args.get("confidence", 1.0)
        context_window = args.get("context_window", "")
        tool_call_id = args.get("tool_call_id", None)
        with self._lock:
            cursor = self._conn.execute(
                "INSERT INTO memories (content, source, confidence, context_window, "
                "session_id, turn_number, tool_call_id) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (content, source, confidence, context_window,
                 self._current_session_id, self._current_turn, tool_call_id)
            )
            new_id = cursor.lastrowid
            # Check for contradictions with existing memories
            self._detect_contradictions(new_id, content)
            self._conn.commit()
        return json.dumps({"memory_id": new_id})

    def _query_memory(self, args: Dict) -> str:
        query = args["query"]
        max_results = args.get("max_results", 5)
        results = self.prefetch(query, max_results)
        return json.dumps({"results": results})

    def _create_relationship(self, args: Dict) -> str:
        source_id = args["source_id"]
        target_id = args["target_id"]
        rel_type = args["relationship_type"]
        weight = args.get("weight", 1.0)
        with self._lock:
            self._conn.execute(
                "INSERT INTO relationships (source_id, target_id, relationship_type, weight) "
                "VALUES (?, ?, ?, ?)",
                (source_id, target_id, rel_type, weight)
            )
            self._conn.commit()
        return json.dumps({"status": "created"})

    def _detect_contradictions(self, new_id: int, content: str) -> None:
        """Simple contradiction detection: if content contains negations of existing memories."""
        # This is a placeholder; real implementation would use semantic similarity.
        # For demo, we look for opposite keywords.
        negation_keywords = ["not", "never", "incorrect", "wrong"]
        if any(kw in content.lower() for kw in negation_keywords):
            # Find memories that might be contradicted (e.g., same topic)
            rows = self._conn.execute(
                "SELECT id, content FROM memories WHERE id != ? AND "
                "content LIKE ?",
                (new_id, f"%{content.split()[0]}%")  # crude: first word
            ).fetchall()
            for old_id, old_content in rows:
                # Create a 'contradicts' edge both ways
                self._conn.execute(
                    "INSERT INTO relationships (source_id, target_id, relationship_type, weight) "
                    "VALUES (?, ?, 'contradicts', 1.0)",
                    (new_id, old_id)
                )
                self._conn.execute(
                    "INSERT INTO relationships (source_id, target_id, relationship_type, weight) "
                    "VALUES (?, ?, 'contradicts', 1.0)",
                    (old_id, new_id)
                )
                # Flag both memories
                self._conn.execute(
                    "UPDATE memories SET contradiction_flag = 1 WHERE id IN (?, ?)",
                    (new_id, old_id)
                )

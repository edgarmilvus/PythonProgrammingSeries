
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation_part2.py
# Description: Basic Library Implementation
# ==========================================

# file: nova_agent.py
"""
The core NovaTech DevOps Agent implementation.
This script creates and runs an AIAgent instance with custom configuration.
"""

import os
import sys
import logging
from pathlib import Path

# --- Step 1: Set the Hermes Home Path ---
# This must be set BEFORE importing any Hermes modules.
os.environ["HERMES_HOME"] = str(Path.home() / ".nova_hermes")

# --- Step 2: Import the AIAgent class ---
# The AIAgent is the main entry point for running conversations.
# It handles the tool-calling loop, memory management, and provider routing.
from run_agent import AIAgent

# --- Step 3: Configure Logging ---
# We want to see what the agent is doing, but we don't want to be overwhelmed.
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stdout,
)
# Suppress verbose third-party library logs
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("openai").setLevel(logging.WARNING)

# --- Step 4: Define the Agent Configuration ---
# These settings override the defaults in config.yaml.
agent_config = {
    "model": "anthropic/claude-sonnet-4-6",  # Primary model
    "base_url": "https://openrouter.ai/api/v1",  # OpenRouter endpoint
    "provider": "openrouter",  # Provider identifier
    "max_iterations": 30,  # Maximum tool-calling iterations per turn
    "verbose_logging": True,  # Show detailed tool execution logs
    "quiet_mode": False,  # Show progress output
    "save_trajectories": True,  # Save conversation history for debugging
    "platform": "cli",  # Platform hint for the system prompt
    "skip_context_files": False,  # Load SOUL.md and project context files
    "load_soul_identity": True,  # Use SOUL.md as the primary identity
    "enabled_toolsets": ["development", "web", "terminal"],  # Enable specific tool sets
    # Fallback provider chain for resilience
    "fallback_model": [
        {"provider": "anthropic", "model": "claude-opus-4-6", "base_url": "https://api.anthropic.com"},
        {"provider": "openai", "model": "gpt-4o", "base_url": "https://api.openai.com/v1"},
    ],
    # Reasoning configuration for complex tasks
    "reasoning_config": {"enabled": True, "effort": "medium"},
}

# --- Step 5: Create the AIAgent Instance ---
# This is where all the magic happens. The AIAgent.__init__ method
# will:
#   1. Load environment variables from ~/.nova_hermes/.env
#   2. Read config.yaml from ~/.nova_hermes/
#   3. Initialize the LLM client (OpenRouter)
#   4. Load tool definitions
#   5. Set up the memory store and context compressor
#   6. Initialize the session database
print("[INFO] Initializing NovaTech DevOps Agent...")
try:
    agent = AIAgent(**agent_config)
    print("[SUCCESS] Agent initialized successfully!")
except RuntimeError as e:
    print(f"[ERROR] Failed to initialize agent: {e}")
    print("[HINT] Check your API keys in ~/.nova_hermes/.env")
    sys.exit(1)

# --- Step 6: Run a Simple Conversation ---
# Let's test the agent with a basic query.
print("\n" + "=" * 60)
print("Starting conversation with NovaTech Agent...")
print("=" * 60 + "\n")

user_query = (
    "Hello! I'm the lead DevOps engineer for NovaTech. "
    "We're about to deploy a new microservice called 'user-auth-service'. "
    "Can you help me set up a deployment checklist? "
    "Please use your tools to search for any existing deployment documentation "
    "and then create a comprehensive checklist."
)

# The run_conversation method is the main entry point for a single turn.
# It returns a dictionary with the final response, message history, and usage stats.
result = agent.run_conversation(
    user_message=user_query,
    # Optional: pass a custom system message that will be appended to the prompt
    system_message="Focus on creating a practical, actionable deployment checklist.",
)

# --- Step 7: Display the Results ---
print("\n" + "=" * 60)
print("Conversation Results")
print("=" * 60)
print(f"  Completed: {result['completed']}")
print(f"  API Calls: {result['api_calls']}")
print(f"  Total Messages: {len(result['messages'])}")
print(f"  Input Tokens: {result['input_tokens']:,}")
print(f"  Output Tokens: {result['output_tokens']:,}")
print(f"  Estimated Cost: ${result['estimated_cost_usd']:.4f}")
print(f"  Cost Status: {result['cost_status']}")

if result['final_response']:
    print("\n--- Final Response ---")
    print(result['final_response'])
else:
    print("\n[WARNING] No final response was generated.")

# --- Step 8: Save the Session for Later Review ---
# The agent automatically saves sessions to the SQLite database.
# We can also export the session for analysis.
print(f"\n[INFO] Session ID: {agent.session_id}")
print(f"[INFO] Session log saved to: {agent.session_log_file}")

# --- Step 9: Clean Up Resources ---
# It's good practice to release the agent's resources when done.
agent.close()
print("\n[INFO] Agent resources released. Goodbye!")

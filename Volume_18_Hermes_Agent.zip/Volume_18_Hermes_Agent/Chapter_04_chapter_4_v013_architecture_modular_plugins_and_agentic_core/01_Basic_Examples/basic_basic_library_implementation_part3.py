
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation_part3.py
# Description: Basic Library Implementation
# ==========================================

# file: session_explorer.py
"""
A script to explore the Hermes Agent's session database.
This demonstrates how to create, query, and manage sessions.
"""

import os
from pathlib import Path
from datetime import datetime

# --- Step 1: Set the Hermes Home Path ---
os.environ["HERMES_HOME"] = str(Path.home() / ".nova_hermes")

# --- Step 2: Import the SessionDB class ---
from hermes_state import SessionDB

# --- Step 3: Initialize the Session Database ---
# The SessionDB class manages all session storage.
# It uses WAL mode for concurrent access and FTS5 for full-text search.
db_path = Path.home() / ".nova_hermes" / "state.db"
print(f"[INFO] Initializing session database at: {db_path}")

# The SessionDB constructor will create the database and tables if they don't exist.
# It also handles schema migrations automatically.
session_db = SessionDB(db_path=db_path)
print("[SUCCESS] Session database initialized!")

# --- Step 4: Create a New Session ---
# Sessions are the top-level container for conversations.
# Each session has a unique ID, a source (e.g., 'cli', 'telegram'), and metadata.
session_id = "nova_session_" + datetime.now().strftime("%Y%m%d_%H%M%S")
print(f"\n[INFO] Creating new session: {session_id}")

session_db.create_session(
    session_id=session_id,
    source="cli",
    model="anthropic/claude-sonnet-4-6",
    model_config={
        "max_iterations": 30,
        "reasoning_config": {"enabled": True, "effort": "medium"},
    },
    system_prompt="You are the NovaTech DevOps Agent.",
    user_id="lead_devops_engineer",
)
print("[SUCCESS] Session created!")

# --- Step 5: Append Messages to the Session ---
# Messages are stored with their role, content, and metadata.
# The SessionDB automatically updates the session's message count and token usage.
print("\n[INFO] Appending messages to session...")

# User message
msg1_id = session_db.append_message(
    session_id=session_id,
    role="user",
    content="What is the current status of the production deployment?",
)
print(f"  - Appended user message (ID: {msg1_id})")

# Assistant response (with reasoning and tool calls)
msg2_id = session_db.append_message(
    session_id=session_id,
    role="assistant",
    content="Let me check the deployment status by looking at the CI/CD pipeline logs.",
    reasoning="The user is asking about the production deployment. I should first check the CI/CD pipeline status before making any claims.",
    tool_calls=[
        {
            "id": "call_abc123",
            "type": "function",
            "function": {
                "name": "terminal",
                "arguments": '{"command": "kubectl get pods -n production"}',
            },
        }
    ],
    finish_reason="tool_calls",
)
print(f"  - Appended assistant message (ID: {msg2_id})")

# Tool result
msg3_id = session_db.append_message(
    session_id=session_id,
    role="tool",
    tool_call_id="call_abc123",
    tool_name="terminal",
    content='{"status": "success", "output": "NAME                     READY   STATUS    RESTARTS   AGE\\nuser-auth-service-7d4f8   1/1     Running   0          2d\\npayment-service-9k2l1    1/1     Running   0          5h\\n"}',
)
print(f"  - Appended tool result (ID: {msg3_id})")

# Final assistant response
msg4_id = session_db.append_message(
    session_id=session_id,
    role="assistant",
    content="The production deployment is healthy. All pods are running with no recent restarts. The `user-auth-service` has been running for 2 days, and the `payment-service` was deployed 5 hours ago.",
    finish_reason="stop",
)
print(f"  - Appended final assistant message (ID: {msg4_id})")

# --- Step 6: Retrieve Messages from the Session ---
# We can load all messages for a session in chronological order.
print("\n[INFO] Retrieving messages from session...")
messages = session_db.get_messages(session_id)
print(f"  - Retrieved {len(messages)} messages:")
for msg in messages:
    print(f"    [{msg['role']}] {msg['content'][:80]}...")

# --- Step 7: Search Across All Sessions ---
# The SessionDB supports full-text search using FTS5.
# This allows us to find relevant information across all past conversations.
print("\n[INFO] Searching for 'deployment' across all sessions...")
search_results = session_db.search_messages(
    query="deployment",
    limit=5,
)
print(f"  - Found {len(search_results)} results:")
for result in search_results:
    print(f"    [Session: {result['session_id'][:20]}...] {result['snippet']}")

# --- Step 8: Get Session Statistics ---
print("\n[INFO] Session statistics:")
print(f"  - Total sessions: {session_db.session_count()}")
print(f"  - Total messages: {session_db.message_count()}")

# --- Step 9: List Recent Sessions ---
print("\n[INFO] Recent sessions:")
recent_sessions = session_db.search_sessions(limit=5)
for s in recent_sessions:
    print(f"  - {s['id']}: {s['source']} | Model: {s['model']} | Messages: {s['message_count']}")

# --- Step 10: Close the Database Connection ---
# It's important to close the connection to release file locks.
session_db.close()
print("\n[INFO] Session database connection closed.")

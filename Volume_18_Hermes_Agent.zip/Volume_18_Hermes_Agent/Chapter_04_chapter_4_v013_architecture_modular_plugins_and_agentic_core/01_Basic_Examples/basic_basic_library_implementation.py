
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation.py
# Description: Basic Library Implementation
# ==========================================

# file: setup_hermes_agent.py
"""
A script to initialize the Hermes Agent environment for the NovaTech DevOps agent.
This creates the necessary directory structure, configuration files, and
a basic SOUL.md identity file.
"""

import os
from pathlib import Path
import json

# --- Step 1: Define the Hermes Home Directory ---
# The agent stores all its persistent state (memory, skills, sessions) here.
# We'll use a dedicated directory for our NovaTech agent to keep it isolated.
HERMES_HOME = Path.home() / ".nova_hermes"
HERMES_HOME.mkdir(parents=True, exist_ok=True)

print(f"[INFO] Hermes Home set to: {HERMES_HOME}")

# --- Step 2: Create the .env File ---
# The agent reads environment variables from a .env file in HERMES_HOME.
# This is where we store API keys and configuration overrides.
env_path = HERMES_HOME / ".env"
if not env_path.exists():
    env_content = """
# NovaTech Hermes Agent Configuration
# WARNING: Never commit this file to version control!

# Primary LLM Provider (OpenRouter)
OPENROUTER_API_KEY="sk-or-v1-your-openrouter-key-here"

# Fallback Provider (for rate limiting)
ANTHROPIC_API_KEY="sk-ant-your-anthropic-key-here"

# Agent Settings
HERMES_MAX_ITERATIONS=50
HERMES_VERBOSE_LOGGING=true
"""
    env_path.write_text(env_content.strip())
    print(f"[INFO] Created .env file at: {env_path}")
else:
    print(f"[INFO] .env file already exists at: {env_path}")

# --- Step 3: Create the SOUL.md Identity File ---
# This file defines the agent's core personality and goals.
# It's loaded into the system prompt on every conversation turn.
soul_path = HERMES_HOME / "SOUL.md"
if not soul_path.exists():
    soul_content = """
# NovaTech DevOps Agent Identity

You are the NovaTech DevOps Agent, an intelligent AI assistant created by the NovaTech engineering team.
Your primary purpose is to automate and improve the software development lifecycle.

## Core Responsibilities
- **Deployment Automation**: Manage deployments to staging and production environments.
- **System Monitoring**: Check server health, analyze logs, and respond to alerts.
- **Code Review Assistance**: Help with code reviews by analyzing pull requests.
- **Documentation**: Update and maintain project documentation.
- **Incident Response**: Diagnose and resolve production incidents.

## Behavioral Guidelines
- **Proactive**: Don't wait for instructions. If you see a problem, flag it.
- **Concise**: Be direct and efficient. Avoid unnecessary verbosity.
- **Self-Improving**: After completing a complex task, reflect on what you learned and save it as a skill.
- **Tool-First**: Always use your tools to gather information before making assumptions.
- **Safety-Conscious**: Never execute destructive commands without explicit user confirmation.

## Communication Style
- Use clear, technical language.
- Provide actionable steps, not just analysis.
- When reporting errors, include the exact error message and a suggested fix.
"""
    soul_path.write_text(soul_content.strip())
    print(f"[INFO] Created SOUL.md at: {soul_path}")
else:
    print(f"[INFO] SOUL.md already exists at: {soul_path}")

# --- Step 4: Create the skills directory ---
# Skills are the agent's long-term memory for how to perform specific tasks.
skills_dir = HERMES_HOME / "skills"
skills_dir.mkdir(exist_ok=True)
print(f"[INFO] Skills directory created at: {skills_dir}")

# --- Step 5: Create a basic configuration file (config.yaml) ---
# This controls the agent's behavior, tool sets, and memory settings.
config_path = HERMES_HOME / "config.yaml"
if not config_path.exists():
    config_content = """
# NovaTech Hermes Agent Configuration
agent:
  max_iterations: 50
  tool_use_enforcement: auto
  api_max_retries: 3

memory:
  memory_enabled: true
  user_profile_enabled: true
  nudge_interval: 10
  memory_char_limit: 2200
  user_char_limit: 1375

skills:
  creation_nudge_interval: 10

compression:
  enabled: true
  threshold: 0.50
  target_ratio: 0.20
  protect_last_n: 20

model:
  max_tokens: 4096
  context_length: 200000
"""
    config_path.write_text(config_content.strip())
    print(f"[INFO] Created config.yaml at: {config_path}")
else:
    print(f"[INFO] config.yaml already exists at: {config_path}")

print("\n[SUCCESS] Hermes Agent environment initialized!")
print(f"  - Home Directory: {HERMES_HOME}")
print(f"  - Identity File: {soul_path}")
print(f"  - Config File: {config_path}")
print(f"  - Skills Directory: {skills_dir}")
print("\n[ACTION REQUIRED] Edit the .env file and add your actual API keys.")

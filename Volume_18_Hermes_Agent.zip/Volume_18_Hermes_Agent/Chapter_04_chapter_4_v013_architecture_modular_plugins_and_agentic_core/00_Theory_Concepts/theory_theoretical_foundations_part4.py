
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: theory_theoretical_foundations_part4.py
# Description: Theoretical Foundations
# ==========================================

# agent/memory_manager.py — Contract-based tool routing
def handle_tool_call(
    self, tool_name: str, args: Dict[str, Any], **kwargs
) -> str:
    """Route a tool call to the correct provider.
    
    Returns JSON string result. Raises ValueError if no provider
    handles the tool.
    """
    provider = self._tool_to_provider.get(tool_name)
    if provider is None:
        return tool_error(f"No memory provider handles tool '{tool_name}'")
    try:
        return provider.handle_tool_call(tool_name, args, **kwargs)
    except Exception as e:
        logger.error(
            "Memory provider '%s' handle_tool_call(%s) failed: %s",
            provider.name, tool_name, e,
        )
        return tool_error(f"Memory tool '{tool_name}' failed: {e}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: theory_theoretical_foundations_part3.py
# Description: Theoretical Foundations
# ==========================================

# agent/memory_provider.py — The interface contract (conceptual)
class MemoryProvider(ABC):
    """Abstract base for all memory providers.
    
    Every memory provider must implement these methods. The core
    never reaches into provider internals—it only calls these methods.
    """
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Unique provider name."""
        ...
    
    @abstractmethod
    def get_tool_schemas(self) -> List[Dict[str, Any]]:
        """Return tool schemas this provider contributes."""
        ...
    
    @abstractmethod
    def system_prompt_block(self) -> str:
        """Return system prompt content for this provider."""
        ...
    
    @abstractmethod
    def prefetch(self, query: str, *, session_id: str = "") -> str:
        """Return relevant context for the given query."""
        ...
    
    @abstractmethod
    def handle_tool_call(self, tool_name: str, args: Dict[str, Any]) -> str:
        """Handle a tool call routed to this provider."""
        ...
    
    @abstractmethod
    def initialize(self, session_id: str, **kwargs) -> None:
        """Initialize provider resources."""
        ...
    
    @abstractmethod
    def shutdown(self) -> None:
        """Release provider resources."""
        ...

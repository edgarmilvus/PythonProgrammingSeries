
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: theory_theoretical_foundations_part10.py
# Description: Theoretical Foundations
# ==========================================

# run_agent.py — Context engine tools dispatched through the normal path
elif self._context_engine_tool_names and function_name in self._context_engine_tool_names:
    # Context engine tools (lcm_grep, lcm_describe, lcm_expand, etc.)
    spinner = None
    if self._should_emit_quiet_tool_messages():
        face = random.choice(KawaiiSpinner.get_waiting_faces())
        emoji = _get_tool_emoji(function_name)
        preview = _build_tool_preview(function_name, function_args) or function_name
        spinner = KawaiiSpinner(f"{face} {emoji} {preview}", spinner_type='dots', print_fn=self._print_fn)
        spinner.start()
    _ce_result = None
    try:
        function_result = self.context_compressor.handle_tool_call(function_name, function_args, messages=messages)
        _ce_result = function_result
    except Exception as tool_error:
        function_result = json.dumps({"error": f"Context engine tool '{function_name}' failed: {tool_error}"})
        logger.error("context_engine.handle_tool_call raised for %s: %s", function_name, tool_error, exc_info=True)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script.py
# Description: Advanced Integration Script
# ==========================================

#!/usr/bin/env python3
"""
Advanced Integration Script: Multi-Agent Research Coordinator

Demonstrates:
  - Modular memory provider plugin (persistent user preferences)
  - Agentic cores: coordinator delegates to specialized subagents
  - Guardrails and iteration budget management
  - Streaming callbacks for real‑time response delivery
  - Interrupt handling and graceful fallback

Usage:
  python advanced_coordinator.py "What are the latest advances in multimodal LLMs and edge deployment?"
"""

import asyncio
import json
import logging
import os
import sys
import time
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional

# ---------------------------------------------------------------------------
# 1. Custom Memory Provider Plugin
#    A simple file‑based store that saves user preferences as key‑value pairs.
#    Implements the MemoryProvider protocol expected by Hermes' MemoryManager.
# ---------------------------------------------------------------------------

from agent.memory_manager import MemoryManager, MemoryProvider
from agent.memory_provider import MemoryProvider  # abstract base class

class PrefsMemoryProvider(MemoryProvider):
    """
    Stores user preferences in a local JSON file.
    Uses a background lock to protect concurrent reads/writes.
    """

    def __init__(self, db_path: Path):
        self.db_path = db_path
        self._store: Dict[str, str] = {}
        self._lock = threading.Lock()
        self._load()

    def _load(self):
        if self.db_path.exists():
            try:
                data = json.loads(self.db_path.read_text())
                self._store = data.get("preferences", {})
            except (json.JSONDecodeError, OSError):
                self._store = {}

    def _save(self):
        with self._lock:
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            self.db_path.write_text(
                json.dumps({"preferences": self._store}, indent=2),
                encoding="utf-8"
            )

    # MemoryProvider interface methods --------------------------------------

    @property
    def name(self) -> str:
        return "prefs_memory"

    def system_prompt_block(self) -> Optional[str]:
        """Return a block describing what this provider remembers."""
        if not self._store:
            return None
        lines = ["<memory_context>",
                 "The following user preferences have been stored from previous sessions:"
                ]
        for k, v in self._store.items():
            lines.append(f"  - {k}: {v}")
        lines.append("</memory_context>")
        return "\n".join(lines)

    def prefetch(self, query: str, *, session_id: str = "") -> str:
        """
        Search stored preferences for a match against the query.
        Returns a plain string (not wrapped) — wrapping is done by MemoryManager.
        """
        query_lower = query.lower()
        matched = []
        with self._lock:
            for key, value in self._store.items():
                if key.lower() in query_lower or value.lower() in query_lower:
                    matched.append(f"{key} → {value}")
        if not matched:
            return ""
        return "Relevant preferences:\n" + "\n".join(matched)

    def queue_prefetch(self, query: str, *, session_id: str = "") -> None:
        """No‑op for this simple provider (prefetch is synchronous)."""
        pass

    def sync_turn(self, user_content: str, assistant_content: str, *,
                  session_id: str = "") -> None:
        """
        After a turn, we can optionally extract new preferences.
        For this example, we do nothing — preferences are set via tool calls.
        """
        pass

    def get_tool_schemas(self) -> List[Dict[str, Any]]:
        """
        Expose a tool that allows the agent to set a preference.
        This becomes part of the agent's tool list.
        """
        return [
            {
                "name": "set_preference",
                "description": "Store a user preference (e.g., 'report style': 'concise bullet lists').",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "key": {"type": "string", "description": "Preference key"},
                        "value": {"type": "string", "description": "Preference value"}
                    },
                    "required": ["key", "value"]
                }
            }
        ]

    def handle_tool_call(self, tool_name: str, args: Dict[str, Any], **kwargs) -> str:
        if tool_name == "set_preference":
            key = args.get("key", "")
            value = args.get("value", "")
            if not key or not value:
                return json.dumps({"success": False, "error": "Missing key or value"})
            with self._lock:
                self._store[key] = value
                self._save()
            return json.dumps({"success": True, "message": f"Preference '{key}' saved as '{value}'."})
        raise ValueError(f"Unknown tool: {tool_name}")

    def on_session_end(self, messages: List[Dict]) -> None:
        """Flush any pending writes (already saved inline)."""
        pass

    def shutdown(self) -> None:
        """Ensure data is saved."""
        self._save()

# ---------------------------------------------------------------------------
# 2. Helper: Create a MemoryManager and register the custom provider
# ---------------------------------------------------------------------------

def setup_memory_manager(home: Path) -> MemoryManager:
    mem_mgr = MemoryManager()
    provider = PrefsMemoryProvider(home / "prefs.json")
    mem_mgr.add_provider(provider)
    return mem_mgr

# ---------------------------------------------------------------------------
# 3. Subagent Factory
#    Creates a stripped‑down AIAgent for a specific domain.
#    Shares the parent's memory manager (so preferences propagate).
# ---------------------------------------------------------------------------

def create_subagent(
    model: str,
    provider: str,
    base_url: str,
    api_key: str,
    enabled_toolsets: List[str],
    system_prompt_extra: str,
    memory_manager_shared: MemoryManager,
    parent_iteration_budget,
) -> "AIAgent":
    """
    Build a subordinate agent for delegated tasks.
    Uses its own iteration budget (max 30 calls) and a focused toolset.
    """
    from run_agent import AIAgent

    sub = AIAgent(
        model=model,
        provider=provider,
        base_url=base_url,
        api_key=api_key,
        max_iterations=30,
        quiet_mode=True,
        enabled_toolsets=enabled_toolsets,
        iteration_budget=parent_iteration_budget,  # share parent's overall cap
        # Disable guardrails to keep subagents lean; they inherit via the coordinator
        load_soul_identity=False,
        skip_context_files=True,
    )
    # Attach the shared memory manager (the subagent inherits the tool schema)
    sub._memory_manager = memory_manager_shared
    # Inject domain‑specific system prompt additions
    if system_prompt_extra:
        sub.ephemeral_system_prompt = system_prompt_extra
    return sub

# ---------------------------------------------------------------------------
# 4. Main Coordinator Agent
#    Handles the user message, delegates research tasks, and composes the answer.
# ---------------------------------------------------------------------------

def run_coordinator(user_query: str):
    """
    Sets up the coordinator agent with:
      - Custom memory provider
      - Tool guardrails (stop after 5 repeated calls to same failing tool)
      - Streaming callbacks for partial output
    Then processes the query and returns the final response.
    """
    # ---- Configuration ----
    MODEL = "anthropic/claude-sonnet-4.6"         # or any supported
    PROVIDER = "openrouter"
    BASE_URL = "https://openrouter.ai/api/v1" if PROVIDER == "openrouter" else ""
    API_KEY = os.environ.get("OPENROUTER_API_KEY", "")
    HERMES_HOME = Path.home() / ".hermes"

    # ---- Setup memory manager ----
    mem_mgr = setup_memory_manager(HERMES_HOME)

    # ---- Create the coordinator agent ----
    from run_agent import AIAgent

    coordinator = AIAgent(
        model=MODEL,
        provider=PROVIDER,
        base_url=BASE_URL,
        api_key=API_KEY,
        max_iterations=50,
        quiet_mode=False,                    # show progress
        enabled_toolsets=["web", "terminal", "vision", "memory"],  # broad
        save_trajectories=True,
        # Attach custom memory manager
        _memory_manager=mem_mgr,             # injected after init; normally done in __init__
        # Guardrails: halt after 5 consecutive identical failing tool calls
        tool_loop_guardrails={
            "max_retries": 3,
            "window_size": 7,
            "consecutive_same_tool": 4,
        },
        # Streaming callback to print partial output
        stream_delta_callback=lambda text: print(text, end="", flush=True),
        # Status callback for lifecycle messages
        status_callback=lambda level, msg: print(f"\n[STATUS] {msg}"),
    )
    # Override the memory manager after init (since it's normally private)
    coordinator._memory_manager = mem_mgr

    # ---- Pre‑flight: inject domain guidance into ephemeral system prompt ----
    coordinator.ephemeral_system_prompt = (
        "You are a research coordinator. When faced with a broad question:\n"
        "1. Break it into 2–4 independent sub‑questions.\n"
        "2. For each sub‑question, use the `delegate_task` tool to spawn a "
        "specialized subagent.\n"
        "3. Subagents have access to toolsets according to their domain.\n"
        "4. After all subagents complete, synthesize their reports into a "
        "final answer.\n"
        "5. If a subagent fails twice, skip it and note the gap.\n"
        "6. Use `set_preference` to remember user preferences about report style."
    )

    # ---- Register the delegate_task tool (normally built‑in) ----
    # (It's already part of the system, but we configure the subagent factory)
    coordinator.delegate_task_factory = create_subagent

    # ---- Run the conversation ----
    try:
        result = coordinator.run_conversation(
            user_message=user_query,
            stream_callback=None,   # we already set stream_delta_callback above
        )
        print("\n\n=== FINAL RESPONSE ===")
        print(result.get("final_response", "(no response)"))
    except Exception as e:
        logging.error("Coordinator failed: %s", e)
        raise
    finally:
        # Cleanup: shut down memory provider and any subprocesses
        coordinator.shutdown_memory_provider()
        coordinator.close()

# ---------------------------------------------------------------------------
# 5. Entry Point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    if len(sys.argv) < 2:
        query = "What are the latest advances in multimodal LLMs and edge deployment?"
    else:
        query = " ".join(sys.argv[1:])
    run_coordinator(query)

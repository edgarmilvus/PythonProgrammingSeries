
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

#!/usr/bin/env python3
"""
verify_install.py - Verify Hermes Agent installation and core functionality.
"""
import os
import sys
import tempfile
import shutil

# Add Hermes Agent to path if needed
hermes_home = os.environ.get("HERMES_HOME", os.path.expanduser("~/.hermes"))
if hermes_home not in sys.path:
    sys.path.insert(0, hermes_home)

try:
    from agent.agent import AIAgent
    from agent.session_db import SessionDB
    from agent.memory import Memory
    from hermes_cli.config import Config
except ImportError as e:
    print(f"FAIL: Could not import Hermes modules: {e}")
    sys.exit(1)

def test_path_validation():
    """Test that HERMES_HOME points to the correct directory."""
    print("\n[Test 1] Path Validation")
    expected_path = os.path.expanduser("~/.hermes")
    actual_path = os.environ.get("HERMES_HOME", expected_path)
    
    if actual_path == expected_path:
        print(f"  PASS: HERMES_HOME = {actual_path}")
        return True
    else:
        print(f"  FAIL: Expected {expected_path}, got {actual_path}")
        return False

def test_session_db():
    """Test SessionDB creation, query, and deletion."""
    print("\n[Test 2] SessionDB Persistence")
    try:
        # Create a temporary session directory for testing
        test_session_dir = os.path.join(hermes_home, "sessions_test")
        os.makedirs(test_session_dir, exist_ok=True)
        
        # Initialize SessionDB
        db = SessionDB(session_dir=test_session_dir)
        
        # Create a dummy session
        test_session_id = "test_session_123"
        db.create_session(session_id=test_session_id)
        
        # Add a conversation turn
        db.add_turn(session_id=test_session_id, 
                    role="user", 
                    content="This is a test message")
        
        # Query the session
        session = db.get_session(session_id=test_session_id)
        if session and len(session.turns) > 0:
            print(f"  PASS: Session created and queried successfully")
        else:
            print(f"  FAIL: Session not found or empty")
            return False
        
        # Delete the session
        db.delete_session(session_id=test_session_id)
        session_after_delete = db.get_session(session_id=test_session_id)
        if session_after_delete is None:
            print(f"  PASS: Session deleted successfully")
        else:
            print(f"  FAIL: Session still exists after deletion")
            return False
        
        # Cleanup
        shutil.rmtree(test_session_dir)
        return True
        
    except Exception as e:
        print(f"  FAIL: SessionDB error: {e}")
        return False

def test_memory_persistence():
    """Test Memory storage and retrieval."""
    print("\n[Test 3] Memory Persistence")
    try:
        # Initialize Memory
        memory = Memory(base_path=hermes_home)
        
        # Store a test memory
        test_key = "test_memory"
        test_value = "This is a test memory"
        memory.store(key=test_key, value=test_value)
        
        # Retrieve and verify
        retrieved = memory.retrieve(key=test_key)
        if retrieved and retrieved.value == test_value:
            print(f"  PASS: Memory stored and retrieved correctly")
        else:
            print(f"  FAIL: Memory retrieval mismatch. Got: {retrieved}")
            return False
        
        # Delete the memory
        memory.delete(key=test_key)
        after_delete = memory.retrieve(key=test_key)
        if after_delete is None:
            print(f"  PASS: Memory deleted successfully")
        else:
            print(f"  FAIL: Memory still exists after deletion")
            return False
        
        return True
        
    except Exception as e:
        print(f"  FAIL: Memory error: {e}")
        return False

def test_learning_loop_config():
    """Test that the learning loop is enabled."""
    print("\n[Test 4] Learning Loop Configuration")
    try:
        config = Config(config_path=os.path.join(hermes_home, "config.yaml"))
        learning_loop_enabled = config.get("learning_loop", {}).get("enabled", False)
        
        # Also check environment variable
        env_enabled = os.environ.get("HERMES_LEARNING_LOOP", "false").lower() == "true"
        
        if learning_loop_enabled or env_enabled:
            print(f"  PASS: Learning loop is enabled (config: {learning_loop_enabled}, env: {env_enabled})")
            return True
        else:
            print(f"  WARNING: Learning loop is not enabled. Self-improvement features may be limited.")
            return True  # Not a hard failure, just a warning
            
    except Exception as e:
        print(f"  WARNING: Could not check learning loop config: {e}")
        return True  # Not a hard failure

def main():
    """Run all verification tests."""
    print("=" * 50)
    print("Hermes Agent Installation Verification")
    print("=" * 50)
    
    tests = [
        ("Path Validation", test_path_validation),
        ("SessionDB Persistence", test_session_db),
        ("Memory Persistence", test_memory_persistence),
        ("Learning Loop Config", test_learning_loop_config)
    ]
    
    all_passed = True
    for name, test_func in tests:
        try:
            result = test_func()
            if not result:
                all_passed = False
        except Exception as e:
            print(f"  ERROR: {name} test failed with exception: {e}")
            all_passed = False
    
    print("\n" + "=" * 50)
    if all_passed:
        print("RESULT: ALL TESTS PASSED")
        sys.exit(0)
    else:
        print("RESULT: SOME TESTS FAILED")
        sys.exit(1)

if __name__ == "__main__":
    main()

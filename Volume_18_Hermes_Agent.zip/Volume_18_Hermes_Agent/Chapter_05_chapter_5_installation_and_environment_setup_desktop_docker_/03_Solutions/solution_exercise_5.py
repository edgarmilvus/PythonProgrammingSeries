
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# File: ~/.hermes/hooks/daily_weather_report_hook.py

"""
Custom hook for the daily weather report skill.
Handles city preference setting and report formatting.
"""
import os
import sys
import json
from datetime import datetime

hermes_home = os.environ.get("HERMES_HOME", os.path.expanduser("~/.hermes"))
if hermes_home not in sys.path:
    sys.path.insert(0, hermes_home)

from agent.memory import Memory

class WeatherReportHook:
    """Hook for managing weather report preferences and history."""
    
    def __init__(self):
        self.memory = Memory(base_path=hermes_home)
    
    def set_preferred_city(self, city: str) -> bool:
        """Set the user's preferred city for weather reports."""
        return self.memory.store(
            key="preferred_city",
            value=city,
            metadata={"type": "user_preference", "updated_at": datetime.now().isoformat()}
        )
    
    def get_preferred_city(self) -> str:
        """Get the user's preferred city."""
        result = self.memory.retrieve("preferred_city")
        return result["value"] if result else None
    
    def get_weather_history(self, days: int = 7) -> list:
        """Get weather report history for the last N days."""
        reports = []
        for i in range(days):
            date_key = (datetime.now().replace(hour=0, minute=0, second=0, microsecond=0) 
                       .isoformat().split('T')[0])
            report = self.memory.retrieve(f"weather_report_{date_key}")
            if report:
                reports.append(report)
        return reports
    
    def clear_old_reports(self, max_days: int = 30) -> int:
        """Clear weather reports older than max_days."""
        cleared = 0
        all_memories = self.memory.list_all()
        for mem in all_memories:
            if mem.get("metadata", {}).get("type") == "weather_report":
                report_date = mem.get("metadata", {}).get("date")
                if report_date:
                    report_datetime = datetime.strptime(report_date, "%Y-%m-%d")
                    if (datetime.now() - report_datetime).days > max_days:
                        self.memory.delete(mem["key"])
                        cleared += 1
        return cleared

# CLI integration for setting city preference
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Weather Report Hook")
    parser.add_argument("--set-city", help="Set preferred city")
    parser.add_argument("--get-city", action="store_true", help="Get preferred city")
    parser.add_argument("--history", type=int, default=0, help="Show weather history (days)")
    parser.add_argument("--cleanup", type=int, default=0, help="Clear reports older than N days")
    
    args = parser.parse_args()
    hook = WeatherReportHook()
    
    if args.set_city:
        success = hook.set_preferred_city(args.set_city)
        print(f"{'Set' if success else 'Failed to set'} preferred city to: {args.set_city}")
    
    if args.get_city:
        city = hook.get_preferred_city()
        print(f"Preferred city: {city or 'Not set'}")
    
    if args.history > 0:
        reports = hook.get_weather_history(args.history)
        print(f"Weather history (last {args.history} days):")
        for report in reports:
            print(f"  - {report['key']}: {report['value'][:50]}...")
    
    if args.cleanup > 0:
        cleared = hook.clear_old_reports(args.cleanup)
        print(f"Cleared {cleared} old weather reports")

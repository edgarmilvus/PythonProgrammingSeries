
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

#!/usr/bin/env python3
"""
test_learning_loop.py - Test the closed learning loop by simulating a complex task.
"""
import os
import sys
import time
import json
import shutil

hermes_home = os.environ.get("HERMES_HOME", os.path.expanduser("~/.hermes"))
if hermes_home not in sys.path:
    sys.path.insert(0, hermes_home)

try:
    from agent.agent import AIAgent
    from agent.tool_registry import ToolRegistry
    from agent.skill_manager import SkillManager
    from agent.learning_loop import LearningLoopController
    from agent.memory import Memory
except ImportError as e:
    print(f"Could not import Hermes modules: {e}")
    sys.exit(1)

def simulate_complex_task():
    """Simulate a complex multi-step task for the agent."""
    print("\n[Step 1] Initializing Agent...")
    
    # Initialize the agent with minimal configuration
    agent = AIAgent(
        model="NousResearch/Hermes-3-Llama-3.1-8B",  # Use appropriate model
        api_base="https://openrouter.ai/api/v1",  # Or local endpoint
        learning_loop_enabled=True
    )
    
    # Enable necessary tools
    tool_registry = ToolRegistry()
    tool_registry.enable("web_search")
    tool_registry.enable("file_write")
    agent.tool_registry = tool_registry
    
    # Initialize learning loop controller
    learning_loop = LearningLoopController(agent=agent)
    
    print("[Step 2] Sending complex task...")
    
    # The complex task
    task = """Research the top 3 AI frameworks for 2025, compare their strengths, 
    and write a summary to a file named comparison.md"""
    
    # Send the task
    agent.send_message(task)
    
    # Wait for agent to complete
    print("[Step 3] Waiting for agent to complete task...")
    timeout = 120  # 2 minutes timeout
    start_time = time.time()
    
    while agent.is_busy() and (time.time() - start_time) < timeout:
        time.sleep(2)
        print(".", end="", flush=True)
    
    print("\n[Step 4] Triggering learning loop...")
    
    # Force a learning nudge
    learning_loop.last_nudge_time = 0  # Reset to force immediate nudge
    learning_loop.maybe_nudge()
    
    # Alternative: directly create skill from task
    # learning_loop.create_skill_from_task()
    
    print("[Step 5] Checking for created skill...")
    
    # Check skills directory
    skills_dir = os.path.join(hermes_home, "skills")
    skill_files = os.listdir(skills_dir)
    
    created_skill = None
    for skill_file in skill_files:
        if "research" in skill_file.lower() or "summarize" in skill_file.lower():
            created_skill = skill_file
            break
    
    if created_skill:
        print(f"  Found new skill: {created_skill}")
        # Read the skill file
        with open(os.path.join(skills_dir, created_skill), 'r') as f:
            skill_content = f.read()
        print(f"  Skill content preview: {skill_content[:200]}...")
    else:
        print("  No new skill found (learning loop may not have triggered)")
    
    print("[Step 6] Checking for memory updates...")
    
    # Check memory for task-related entries
    memory = Memory(base_path=hermes_home)
    memories = memory.search("research OR comparison")
    
    if memories:
        print(f"  Found {len(memories)} memory entries related to the task")
        for mem in memories[:3]:  # Show first 3
            print(f"    - {mem.key}: {mem.value[:100]}...")
    else:
        print("  No related memory entries found")
    
    print("\n[Step 7] Cleaning up...")
    
    # Delete created skill
    if created_skill:
        os.remove(os.path.join(skills_dir, created_skill))
        print(f"  Deleted skill: {created_skill}")
    
    # Delete created memory entries
    for mem in memories:
        memory.delete(mem.key)
        print(f"  Deleted memory: {mem.key}")
    
    # Delete the comparison file if it was created
    comparison_file = os.path.join(hermes_home, "comparison.md")
    if os.path.exists(comparison_file):
        os.remove(comparison_file)
        print("  Deleted comparison.md")
    
    print("\n[Complete] Learning loop test finished")

if __name__ == "__main__":
    simulate_complex_task()

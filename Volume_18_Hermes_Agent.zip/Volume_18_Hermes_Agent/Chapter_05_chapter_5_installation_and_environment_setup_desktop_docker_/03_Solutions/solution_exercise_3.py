
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

#!/usr/bin/env python3
"""
test_gateway_mock.py - Test gateway integration with a mock adapter.
"""
import os
import sys
import time
import threading
from queue import Queue

hermes_home = os.environ.get("HERMES_HOME", os.path.expanduser("~/.hermes"))
if hermes_home not in sys.path:
    sys.path.insert(0, hermes_home)

try:
    from gateway.gateway import Gateway
    from gateway.base_adapter import BaseAdapter
    from agent.agent import AIAgent
    from hermes_cli.config import Config
except ImportError as e:
    print(f"Could not import Hermes modules: {e}")
    sys.exit(1)

class MockAdapter(BaseAdapter):
    """Mock adapter that captures outgoing messages."""
    
    def __init__(self):
        super().__init__()
        self.last_message = None
        self.message_queue = Queue()
        self._running = False
    
    def send_message(self, chat_id, text):
        """Capture outgoing message."""
        self.last_message = {
            "chat_id": chat_id,
            "text": text,
            "timestamp": time.time()
        }
        self.message_queue.put(self.last_message)
        print(f"  [MockAdapter] Captured outgoing message: {text[:50]}...")
        return True
    
    def start_polling(self):
        """Mock polling - just mark as running."""
        self._running = True
        print("  [MockAdapter] Polling started (mock)")
    
    def stop(self):
        """Stop the mock adapter."""
        self._running = False
        print("  [MockAdapter] Stopped")

def test_gateway_with_mock():
    """Test gateway functionality using a mock adapter."""
    print("=" * 50)
    print("Gateway Integration Test with Mock Adapter")
    print("=" * 50)
    
    print("\n[Step 1] Creating mock adapter...")
    mock_adapter = MockAdapter()
    
    print("[Step 2] Initializing agent...")
    agent = AIAgent(
        model="NousResearch/Hermes-3-Llama-3.1-8B",
        learning_loop_enabled=False  # Disable for testing
    )
    
    print("[Step 3] Creating gateway with mock adapter...")
    gateway = Gateway(
        adapters=[mock_adapter],
        agent=agent
    )
    
    print("[Step 4] Starting gateway in separate thread...")
    gateway_thread = threading.Thread(target=gateway.run, daemon=True)
    gateway_thread.start()
    time.sleep(1)  # Give it time to start
    
    print("[Step 5] Simulating incoming message...")
    test_message = "Hello, Hermes!"
    test_chat_id = "test_chat_123"
    
    # Simulate incoming message
    gateway.handle_incoming(
        chat_id=test_chat_id,
        text=test_message,
        adapter_name="mock"
    )
    
    print("[Step 6] Waiting for agent response...")
    timeout = 30
    start_time = time.time()
    
    while mock_adapter.message_queue.empty() and (time.time() - start_time) < timeout:
        time.sleep( fu0.5)
        print(".", end="", flush=True)
    
    print("\n[Step 7] Verifying response...")
    
    if not mock_adapter.message_queue.empty():
        response = mock_adapter.message_queue.get()
        response_text = response["text"]
        
        # Check that response is non-empty
        assert response_text, "Response should not be empty"
        
        # Check that response contains a greeting
        greetings = ["Hello", "Hi", "Hey", "Greetings"]
        has_greeting = any(greeting in response_text for greeting in greetings)
        
        if has_greeting:
            print(f"  PASS: Response contains greeting")
            print(f"  Response: {response_text[:100]}...")
        else:
            print(f"  WARNING: Response does not contain expected greeting")
            print(f"  Response: {response_text[:100]}...")
        
        # Verify chat_id is preserved
        assert response["chat_id"] == test_chat_id, "Chat ID should be preserved"
        print(f"  PASS: Chat ID preserved: {response['chat_id']}")
        
    else:
        print("  FAIL: No response received within timeout")
        return False
    
    print("\n[Step 8] Cleaning up...")
    gateway.stop()
    time.sleep(0.5)
    
    print("\n[Complete] Gateway test finished successfully")
    return True

if __name__ == "__main__":
    success = test_gateway_with_mock()
    sys.exit(0 if success else 1)

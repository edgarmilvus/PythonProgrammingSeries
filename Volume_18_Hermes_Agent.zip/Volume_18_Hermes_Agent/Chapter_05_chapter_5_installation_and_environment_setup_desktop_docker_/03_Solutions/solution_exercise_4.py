
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# File: agent/memory_backends/json_backend.py

"""
JSON-based memory backend for Hermes Agent.
Stores memories as individual JSON files in a flat directory.
"""
import os
import json
import time
import threading
from pathlib import Path
from typing import Optional, List, Dict, Any

class JSONMemoryBackend:
    """
    Memory backend that stores entries as individual JSON files.
    """
    
    def __init__(self, base_path: str = None):
        """
        Initialize the JSON memory backend.
        
        Args:
            base_path: Directory to store memory files
        """
        self.base_path = base_path or os.path.expanduser("~/.hermes/memories_json")
        os.makedirs(self.base_path, exist_ok=True)
        self._lock = threading.Lock()
        self._file_locks: Dict[str, threading.Lock] = {}
    
    def _get_file_path(self, key: str) -> str:
        """Get the file path for a given key."""
        # Sanitize key to be a valid filename
        safe_key = "".join(c for c in key if c.isalnum() or c in ('-', '_', '.'))
        return os.path.join(self.base_path, f"{safe_key}.json")
    
    def _get_file_lock(self, key: str) -> threading.Lock:
        """Get or create a lock for a specific file."""
        if key not in self._file_locks:
            self._file_locks[key] = threading.Lock()
        return self._file_locks[key]
    
    def store(self, key: str, value: str, metadata: Optional[Dict] = None) -> bool:
        """
        Store a memory entry.
        
        Args:
            key: Unique identifier for the memory
            value: The memory content
            metadata: Optional metadata dictionary
            
        Returns:
            True if successful, False otherwise
        """
        file_path = self._get_file_path(key)
        file_lock = self._get_file_lock(key)
        
        with file_lock:
            try:
                # Check if entry already exists
                existing = None
                if os.path.exists(file_path):
                    with open(file_path, 'r') as f:
                        existing = json.load(f)
                
                # Create or update entry
                entry = {
                    "key": key,
                    "value": value,
                    "metadata": metadata or {},
                    "created_at": existing.get("created_at", time.time()) if existing else time.time(),
                    "updated_at": time.time()
                }
                
                # Write to file atomically
                temp_path = file_path + ".tmp"
                with open(temp_path, 'w') as f:
                    json.dump(entry, f, indent=2)
                os.replace(temp_path, file_path)
                
                return True
                
            except Exception as e:
                print(f"Error storing memory '{key}': {e}")
                return False
    
    def retrieve(self, key: str) -> Optional[Dict]:
        """
        Retrieve a memory entry by key.
        
        Args:
            key: The memory key to retrieve
            
        Returns:
            The memory entry dictionary or None if not found
        """
        file_path = self._get_file_path(key)
        file_lock = self._get_file_lock(key)
        
        with file_lock:
            try:
                if not os.path.exists(file_path):
                    return None
                
                with open(file_path, 'r') as f:
                    return json.load(f)
                    
            except Exception as e:
                print(f"Error retrieving memory '{key}': {e}")
                return None
    
    def search(self, query: str) -> List[Dict]:
        """
        Search memory entries by text query.
        
        Args:
            query: Search string (case-insensitive substring match)
            
        Returns:
            List of matching memory entries
        """
        results = []
        query_lower = query.lower()
        
        with self._lock:
            for filename in os.listdir(self.base_path):
                if not filename.endswith('.json'):
                    continue
                
                file_path = os.path.join(self.base_path, filename)
                try:
                    with open(file_path, 'r') as f:
                        entry = json.load(f)
                    
                    # Case-insensitive substring search in value field
                    if query_lower in entry.get("value", "").lower():
                        results.append(entry)
                        
                except Exception as e:
                    print(f"Error reading {filename}: {e}")
        
        return results
    
    def delete(self, key: str) -> bool:
        """
        Delete a memory entry.
        
        Args:
            key: The memory key to delete
            
        Returns:
            True if successful, False otherwise
        """
        file_path = self._get_file_path(key)
        file_lock = self._get_file_lock(key)
        
        with file_lock:
            try:
                if os.path.exists(file_path):
                    os.remove(file_path)
                    return True
                return False
                
            except Exception as e:
                print(f"Error deleting memory '{key}': {e}")
                return False
    
    def list_all(self) -> List[Dict]:
        """
        List all memory entries.
        
        Returns:
            List of all memory entry dictionaries
        """
        entries = []
        with self._lock:
            for filename in os.listdir(self.base_path):
                if not filename.endswith('.json'):
                    continue
                
                file_path = os.path.join(self.base_path, filename)
                try:
                    with open(file_path, 'r') as f:
                        entries.append(json.load(f))
                except Exception as e:
                    print(f"Error reading {filename}: {e}")
        
        return entries
    
    def clear(self) -> bool:
        """
        Clear all memory entries.
        
        Returns:
            True if successful
        """
        with self._lock:
            for filename in os.listdir(self.base_path):
                if filename.endswith('.json'):
                    os.remove(os.path.join(self.base_path, filename))
        return True


# Modified Memory class to support backend switching
# File: agent/memory.py (modified section)

class Memory:
    """
    Memory class that supports multiple backends.
    """
    
    def __init__(self, base_path: str = None, backend_type: str = "sqlite"):
        """
        Initialize memory with specified backend.
        
        Args:
            base_path: Base directory for memory storage
            backend_type: Type of backend ("sqlite" or "json")
        """
        self.base_path = base_path or os.path.expanduser("~/.hermes")
        
        if backend_type == "json":
            from agent.memory_backends.json_backend import JSONMemoryBackend
            self._backend = JSONMemoryBackend(
                base_path=os.path.join(self.base_path, "memories_json")
            )
        else:
            # Default SQLite backend
            from agent.memory_backends.sqlite_backend import SQLiteMemoryBackend
            self._backend = SQLiteMemoryBackend(
                db_path=os.path.join(self.base_path, "memories.db")
            )
    
    def store(self, key: str, value: str, metadata: Optional[Dict] = None) -> bool:
        """Store a memory entry."""
        return self._backend.store(key, value, metadata)
    
    def retrieve(self, key: str) -> Optional[Dict]:
        """Retrieve a memory entry."""
        return self._backend.retrieve(key)
    
    def search(self, query: str) -> List[Dict]:
        """Search memory entries."""
        return self._backend.search(query)
    
    def delete(self, key: str) -> bool:
        """Delete a memory entry."""
        return self._backend.delete(key)
    
    def list_all(self) -> List[Dict]:
        """List all memory entries."""
        return self._backend.list_all()


# Test script: test_json_memory.py

#!/usr/bin/env python3
"""
test_json_memory.py - Test the JSON memory backend.
"""
import os
import sys
import tempfile
import shutil

hermes_home = os.environ.get("HERMES_HOME", os.path.expanduser("~/.hermes"))
if hermes_home not in sys.path:
    sys.path.insert(0, hermes_home)

# Import the modified Memory class
from agent.memory import Memory

def test_json_memory_backend():
    """Test all CRUD operations on the JSON memory backend."""
    print("=" * 50)
    print("JSON Memory Backend Test")
    print("=" * 50)
    
    # Create a temporary directory for testing
    test_dir = tempfile.mkdtemp(prefix="hermes_test_")
    
    try:
        print(f"\n[Test 1] Initialize JSON backend...")
        memory = Memory(base_path=test_dir, backend_type="json")
        print("  PASS: JSON backend initialized")
        
        print(f"\n[Test 2] Store memory entries...")
        # Store multiple entries
        test_entries = [
            ("greeting", "Hello, world!", {"type": "test"}),
            ("weather", "Sunny and warm today", {"type": "weather", "city": "London"}),
            ("task", "Complete the project report", {"type": "task", "priority": "high"})
        ]
        
        for key, value, metadata in test_entries:
            result = memory.store(key, value, metadata)
            assert result, f"Failed to store '{key}'"
            print(f"  Stored: {key}")
        
        print("  PASS: All entries stored")
        
        print(f"\n[Test 3] Retrieve entries...")
        for key, expected_value, _ in test_entries:
            retrieved = memory.retrieve(key)
            assert retrieved is not None, f"Failed to retrieve '{key}'"
            assert retrieved["value"] == expected_value, f"Value mismatch for '{key}'"
            print(f"  Retrieved: {key} = {retrieved['value'][:30]}...")
        
        print("  PASS: All entries retrieved correctly")
        
        print(f"\n[Test 4] Search entries...")
        # Search for weather-related entries
        weather_results = memory.search("weather")
        assert len(weather_results) >= 1, "Should find weather entries"
        print(f"  Found {len(weather_results)} entries matching 'weather'")
        
        # Search for London
        london_results = memory.search("London")
        assert len(london_results) >= 1, "Should find London entries"
        print(f"  Found {len(london_results)} entries matching 'London'")
        
        print("  PASS: Search functionality works")
        
        print(f"\n[Test 5] List all entries...")
        all_entries = memory.list_all()
        assert len(all_entries) == len(test_entries), f"Expected {len(test_entries)} entries, got {len(all_entries)}"
        print(f"  Found {len(all_entries)} total entries")
        
        print("  PASS: List all works")
        
        print(f"\n[Test 6] Delete entries...")
        for key, _, _ in test_entries:
            result = memory.delete(key)
            assert result, f"Failed to delete '{key}'"
            # Verify deletion
            retrieved = memory.retrieve(key)
            assert retrieved is None, f"'{key}' still exists after deletion"
            print(f"  Deleted: {key}")
        
        print("  PASS: All entries deleted")
        
        print(f"\n[Test 7] Verify JSON files exist...")
        json_dir = os.path.join(test_dir, "memories_json")
        assert os.path.exists(json_dir), "JSON directory should exist"
        
        # After deletion, no JSON files should remain
        json_files = [f for f in os.listdir(json_dir) if f.endswith('.json')]
        assert len(json_files) == 0, f"Expected 0 JSON files, found {len(json_files)}"
        print(f"  PASS: No JSON files remain after cleanup")
        
        print(f"\n[Test 8] Thread safety test...")
        import threading
        
        def parallel_store(thread_id):
            for i in range(10):
                key = f"thread_{thread_id}_memory_{i}"
                memory.store(key, f"Value from thread {thread_id}, iteration {i}")
        
        threads = []
        for t in range(5):
            thread = threading.Thread(target=parallel_store, args=(t,))
            threads.append(thread)
            thread.start()
        
        for thread in threads:
            thread.join()
        
        # Verify all entries were stored
        all_entries = memory.list_all()
        assert len(all_entries) == 50, f"Expected 50 entries, got {len(all_entries)}"
        print(f"  PASS: Thread safety works ({len(all_entries)} entries stored concurrently)")
        
        # Cleanup
        for entry in all_entries:
            memory.delete(entry["key"])
        
        print("\n" + "=" * 50)
        print("ALL TESTS PASSED!")
        print("=" * 50)
        
    except Exception as e:
        print(f"\nFAIL: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    finally:
        # Cleanup test directory
        shutil.rmtree(test_dir, ignore_errors=True)
    
    return True

if __name__ == "__main__":
    success = test_json_memory_backend()
    sys.exit(0 if success else 1)

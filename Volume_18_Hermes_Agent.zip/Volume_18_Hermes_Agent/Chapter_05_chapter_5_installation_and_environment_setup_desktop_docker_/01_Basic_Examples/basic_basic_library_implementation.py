
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation.py
# Description: Basic Library Implementation
# ==========================================

# hermes_integration.py
# A minimal example of embedding Hermes Agent in your own application.
# Assumes Hermes Agent is installed (`pip install hermes-agent[all]` or similar).

import os
import asyncio
from pathlib import Path

# ===========================================================================
# 1. Set environment variables so the agent can find its home directory
#    and load API keys.  The .env file created by the installer is at
#    ~/.hermes/.env by default.
# ===========================================================================
HERMES_HOME = Path.home() / ".hermes"
os.environ.setdefault("HERMES_HOME", str(HERMES_HOME))

# ===========================================================================
# 2. Import the core Hermes classes.  These live in the `agent` and
#    `memory` packages that ship with the installed package.
# ===========================================================================
from agent import AIAgent, Config, SkillManager
from memory import SessionDB, MemoryManager
from utils import LoggerProvider

# ===========================================================================
# 3. Define an async function that sets everything up and then talks to
#    the agent.  The agent's loop is async because many operations
#    (model calls, tool execution, file I/O) are non‑blocking.
# ===========================================================================
async def run_simple_agent():
    # -----------------------------------------------------------------------
    # 3a. Load the configuration.  `Config.from_defaults` reads
    #     ~/.hermes/config.yaml and merges in variables from ~/.hermes/.env.
    #     You can also override specific fields inline.
    # -----------------------------------------------------------------------
    config = Config.from_defaults()  # respects HERMES_HOME, ~/.hermes

    # (Optional) override the model provider – say, use a local endpoint
    config.model = "gpt-4o"                   # model name
    config.provider = "openai"                # provider key in providers dict
    config.temperature = 0.7

    # -----------------------------------------------------------------------
    # 3b. Create the session database.  SessionDB uses SQLite under the hood
    #     (or Postgres when configured) and stores every conversation turn.
    #     It also powers the FTS5 full‑text search that the agent uses for
    #     cross‑session recall.
    # -----------------------------------------------------------------------
    db_path = HERMES_HOME / "sessions" / "my_app.sqlite"
    session_db = await SessionDB.create(
        path=db_path,
        enable_fts=True,       # enable full‑text search
        cache_size_mb=64       # keep 64MB of recent sessions in RAM
    )

    # -----------------------------------------------------------------------
    # 3c. Initialise the memory manager.  It will load any existing memories
    #     from the `~/.hermes/memories/` directory and watch for new ones.
    # -----------------------------------------------------------------------
    memory_mgr = MemoryManager(
        base_dir=HERMES_HOME / "memories",
        auto_nudge=True,       # periodically prompt the agent to persist new info
        search_limit=10        # max number of memories to surface per query
    )

    # -----------------------------------------------------------------------
    # 3d. Initialise the skill manager.  Skills are stored as Python files
    #     under `~/.hermes/skills/`.  This manager can also auto‑create new
    #     skills when the agent discovers a useful pattern.
    # -----------------------------------------------------------------------
    skill_mgr = SkillManager(
        base_dir=HERMES_HOME / "skills",
        auto_improve=True      # the agent will refine skills during use
    )

    # -----------------------------------------------------------------------
    # 3e. Create the agent itself.  The agent takes everything above and
    #     wires it into a single `process_message` pipeline.
    # -----------------------------------------------------------------------
    agent = AIAgent(
        config=config,
        session_db=session_db,
        memory_manager=memory_mgr,
        skill_manager=skill_mgr,
        logger=LoggerProvider.get_logger("my_app")
    )

    # -----------------------------------------------------------------------
    # 3f. Now we send a message.  The agent will:
    #    - search memory for relevant context
    #    - pick up the last conversation turn from the session DB
    #    - call the LLM provider
    #    - execute any tools (if requested)
    #    - update memory (nudge)
    #    - potentially create/improve a skill
    #    - return the text response
    # -----------------------------------------------------------------------
    user_message = "What do you know about the history of Berlin?"
    response = await agent.reply(user_message, user_id="alice")
    print(f"Agent reply: {response}")

    # -----------------------------------------------------------------------
    # 3g. A second message – notice the agent can now refer to the previous
    #     conversation because SessionDB stores the turn.  It also might
    #     have created a new skill about Berlin history.
    # -----------------------------------------------------------------------
    follow_up = "Tell me more about the Berlin Wall."
    response2 = await agent.reply(follow_up, user_id="alice")
    print(f"Agent reply: {response2}")

    # -----------------------------------------------------------------------
    # 3h. Optionally, force the agent to persist any pending memories.
    #     The default nudge interval is 5 minutes, but you can call this
    #     explicitly after a session ends.
    # -----------------------------------------------------------------------
    await agent.persist_memories()

    # -----------------------------------------------------------------------
    # 3i. Clean up – close database connections and flush logs.
    # -----------------------------------------------------------------------
    await session_db.close()

# ===========================================================================
# 4. Run the async function.  In a real application you'd use an event loop
#    or integrate with your framework (FastAPI, Flask, etc.)
# ===========================================================================
if __name__ == "__main__":
    asyncio.run(run_simple_agent())

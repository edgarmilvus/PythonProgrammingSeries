
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script.py
# Description: Advanced Integration Script
# ==========================================

#!/usr/bin/env python3
"""
Advanced Integration Script for Hermes Agent
Self-Improving Code Review Assistant
===========================================
This script connects Hermes Agent to GitHub, processes pull requests,
performs multi‑tool analysis, and persists every insight into the agent's
memory and skill system. It runs as a cron job or can be triggered by
a webhook.

Requirements:
  - Hermes Agent installed (pip install -e ".[all]")
  - GitHub personal access token with repo:read scope
  - Environment variables set in ~/.hermes/.env or passed explicitly

Usage:
  python code_review_agent.py --repo owner/repo --pr 42
  python code_review_agent.py --webhook  # listen for incoming PR events
"""

import os
import sys
import json
import logging
import tempfile
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone

# Hermes Agent core imports
from run_agent import AIAgent
from hermes_state import HermesState
from hermes_logging import get_logger
from hermes_constants import HERMES_HOME

# Third‑party
import dotenv
import requests
from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# 1. Configuration & Environment
# ---------------------------------------------------------------------------

# Load environment variables from ~/.hermes/.env (the standard Hermes location)
dotenv.load_dotenv(Path(HERMES_HOME) / ".env")

# Configure structured logging (Hermes uses its own logger)
logger = get_logger("code_review_agent")
logger.setLevel(logging.INFO)

# GitHub configuration
GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN")
GITHUB_API_BASE = "https://api.github.com"
REPO_OWNER = os.environ.get("GITHUB_REPO_OWNER")
REPO_NAME = os.environ.get("GITHUB_REPO_NAME")

# Hermes model provider (override via env)
MODEL_PROVIDER = os.environ.get("HERMES_MODEL", "openai:gpt-4o")

# ---------------------------------------------------------------------------
# 2. Data Models for Structured Output
# ---------------------------------------------------------------------------

class CodeReviewResult(BaseModel):
    """Structured result of a code review analysis."""
    pr_number: int
    pr_title: str
    author: str
    files_changed: List[str]
    issues_found: List[Dict[str, Any]]
    suggestions: List[str]
    overall_score: int = Field(ge=0, le=100)
    reviewed_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

class SkillTemplate(BaseModel):
    """Template for a new skill that Hermes can create."""
    name: str
    description: str
    trigger_pattern: str  # e.g., "missing error handling in async"
    code: str             # Python code for the skill

# ---------------------------------------------------------------------------
# 3. Tool Definitions (Hermes‑compatible callables)
# ---------------------------------------------------------------------------

def git_clone_and_diff(repo_url: str, pr_number: int, base_branch: str = "main") -> Dict[str, Any]:
    """
    Clone a repository at the PR merge commit and return the diff.
    Returns a dict with 'diff', 'files', 'stats'.
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        repo_path = Path(tmpdir) / "repo"
        # Shallow clone for speed
        subprocess.run(
            ["git", "clone", "--depth", "1", "--branch", base_branch, repo_url, str(repo_path)],
            capture_output=True, check=True
        )
        # Fetch PR ref
        subprocess.run(
            ["git", "fetch", "origin", f"pull/{pr_number}/head:pr-{pr_number}"],
            cwd=repo_path, capture_output=True, check=True
        )
        # Get diff against base
        result = subprocess.run(
            ["git", "diff", base_branch, f"pr-{pr_number}", "--", "*.py", "*.js", "*.ts", "*.go"],
            cwd=repo_path, capture_output=True, text=True, check=True
        )
        diff_text = result.stdout
        # Count files changed
        files_changed = subprocess.run(
            ["git", "diff", "--name-only", base_branch, f"pr-{pr_number}"],
            cwd=repo_path, capture_output=True, text=True, check=True
        ).stdout.strip().split("\n")
        stats = {
            "additions": diff_text.count("\n+") - diff_text.count("\n---"),
            "deletions": diff_text.count("\n-") - diff_text.count("\n---"),
            "files_changed": len(files_changed),
        }
        return {"diff": diff_text, "files": files_changed, "stats": stats}

def run_linters(file_paths: List[str]) -> Dict[str, List[str]]:
    """
    Run pylint and flake8 on a list of Python files.
    Returns a dict mapping file -> list of lint messages.
    """
    results = {}
    for fpath in file_paths:
        if not fpath.endswith(".py"):
            continue
        # pylint
        try:
            out = subprocess.run(
                ["pylint", "--score=no", fpath],
                capture_output=True, text=True, timeout=30
            )
            pylint_issues = [line for line in out.stdout.split("\n") if ":" in line and not line.startswith("***")]
        except Exception:
            pylint_issues = ["pylint failed"]
        # flake8
        try:
            out2 = subprocess.run(
                ["flake8", fpath],
                capture_output=True, text=True, timeout=30
            )
            flake8_issues = [line for line in out2.stdout.split("\n") if line.strip()]
        except Exception:
            flake8_issues = ["flake8 failed"]
        results[fpath] = pylint_issues + flake8_issues
    return results

def fetch_pr_metadata(owner: str, repo: str, pr_number: int) -> Dict[str, Any]:
    """Fetch PR title, description, comments, and review history from GitHub API."""
    headers = {"Authorization": f"token {GITHUB_TOKEN}", "Accept": "application/vnd.github.v3+json"}
    pr_url = f"{GITHUB_API_BASE}/repos/{owner}/{repo}/pulls/{pr_number}"
    resp = requests.get(pr_url, headers=headers)
    resp.raise_for_status()
    pr_data = resp.json()
    # Fetch comments
    comments_url = f"{pr_url}/comments"
    comments_resp = requests.get(comments_url, headers=headers)
    comments = comments_resp.json() if comments_resp.ok else []
    return {
        "title": pr_data["title"],
        "body": pr_data["body"] or "",
        "author": pr_data["user"]["login"],
        "base_branch": pr_data["base"]["ref"],
        "head_branch": pr_data["head"]["ref"],
        "comments": [c["body"] for c in comments],
        "created_at": pr_data["created_at"],
        "state": pr_data["state"],
    }

# ---------------------------------------------------------------------------
# 4. Core Agent Class
# ---------------------------------------------------------------------------

class CodeReviewAgent:
    """
    A self‑improving code review assistant built on Hermes Agent.
    It maintains persistent memory of past reviews, creates skills for
    recurring patterns, and delegates subtasks to parallel sub‑agents.
    """

    def __init__(self, model: str = MODEL_PROVIDER):
        # Initialize the Hermes AIAgent with the chosen model
        self.agent = AIAgent(
            model=model,
            persona_path=Path(HERMES_HOME) / "SOUL.md",  # global persona
            memory_path=Path(HERMES_HOME) / "memories",   # persistent memory directory
            skills_path=Path(HERMES_HOME) / "skills",     # skill storage
            auto_create_skills=True,                      # enable closed learning loop
            auto_improve_skills=True,                     # allow skill self‑improvement
        )
        # Register custom tools
        self.agent.add_tool("git_diff", git_clone_and_diff)
        self.agent.add_tool("run_linters", run_linters)
        self.agent.add_tool("fetch_pr_metadata", fetch_pr_metadata)
        # Register a built‑in tool for GitHub API (if available)
        # self.agent.add_tool("github_api", github_api_call)
        logger.info("CodeReviewAgent initialized with model %s", model)

    def review_pull_request(self, owner: str, repo: str, pr_number: int) -> CodeReviewResult:
        """
        Perform a full review of a single pull request.
        Steps:
          1. Fetch PR metadata and diff
          2. Run linters on changed files
          3. Use Hermes to analyze the diff with context from memory
          4. Store the result in persistent memory
          5. Optionally create a new skill if a novel pattern is detected
        """
        logger.info("Starting review of PR #%d in %s/%s", pr_number, owner, repo)

        # Step 1: Fetch metadata and diff
        pr_info = self.agent.execute_tool("fetch_pr_metadata", owner, repo, pr_number)
        repo_url = f"https://github.com/{owner}/{repo}.git"
        diff_data = self.agent.execute_tool("git_diff", repo_url, pr_number, pr_info["base_branch"])

        # Step 2: Run linters on changed Python files
        python_files = [f for f in diff_data["files"] if f.endswith(".py")]
        lint_results = self.agent.execute_tool("run_linters", python_files) if python_files else {}

        # Step 3: Build a structured prompt for Hermes to analyze
        prompt = self._build_review_prompt(pr_info, diff_data, lint_results)

        # Step 4: Run Hermes’s closed learning loop — it will analyze, store memory,
        #         and potentially create/improve skills.
        analysis = self.agent.run(prompt)  # returns a dict with 'response', 'memory_updates', 'new_skills'

        # Step 5: Parse the analysis into a structured result
        result = CodeReviewResult(
            pr_number=pr_number,
            pr_title=pr_info["title"],
            author=pr_info["author"],
            files_changed=diff_data["files"],
            issues_found=analysis.get("issues", []),
            suggestions=analysis.get("suggestions", []),
            overall_score=analysis.get("score", 50),
        )

        # Step 6: Persist the result into Hermes’s memory
        self._store_review_memory(result)

        # Step 7: If Hermes created a new skill, log it
        if analysis.get("new_skills"):
            for skill in analysis["new_skills"]:
                logger.info("Hermes created a new skill: %s", skill["name"])
                # The skill is automatically saved to ~/.hermes/skills/

        logger.info("Review completed for PR #%d with score %d", pr_number, result.overall_score)
        return result

    def _build_review_prompt(self, pr_info: dict, diff_data: dict, lint_results: dict) -> str:
        """
        Construct a detailed prompt that includes:
          - PR context
          - Diff content
          - Linter output
          - Relevant past memories (retrieved by Hermes internally)
        """
        # Hermes automatically retrieves relevant memories when we call agent.run()
        # But we can also inject explicit context:
        prompt = f"""You are a senior code reviewer for the repository {REPO_OWNER}/{REPO_NAME}.

PR #{pr_info['title']} by {pr_info['author']}
Description: {pr_info['body'][:500]}

Files changed: {', '.join(diff_data['files'][:20])}
Diff statistics: +{diff_data['stats']['additions']} -{diff_data['stats']['deletions']}

Linter results:
{json.dumps(lint_results, indent=2)}

Please analyze the diff for:
1. Logic errors and race conditions
2. Security vulnerabilities (SQL injection, XSS, etc.)
3. Performance issues
4. Code style violations not caught by linters
5. Missing tests or documentation

Return your analysis as a JSON object with keys:
  - "issues": list of objects with "file", "line", "severity", "message"
  - "suggestions": list of concrete improvement suggestions
  - "score": integer 0-100 (how ready this PR is to merge)
  - "new_skills": optional list of skill templates you want to create for future reviews

Use your memory of past reviews to avoid repeating the same feedback.
If you notice a pattern that has appeared in multiple PRs, create a skill to automate catching it.
"""
        return prompt

    def _store_review_memory(self, result: CodeReviewResult):
        """
        Store the review result in Hermes's persistent memory.
        This allows future reviews to recall past decisions and avoid regressions.
        """
        memory_entry = {
            "type": "code_review",
            "pr_number": result.pr_number,
            "timestamp": result.reviewed_at,
            "score": result.overall_score,
            "key_issues": [i["message"][:200] for i in result.issues_found[:5]],
            "suggestions": result.suggestions[:3],
        }
        # HermesState manages the memory stack
        state = HermesState()
        state.push("reviews", memory_entry)
        state.save()  # persists to disk
        logger.debug("Review memory stored for PR #%d", result.pr_number)

    def delegate_subtasks(self, pr_number: int, file_list: List[str]) -> Dict[str, Any]:
        """
        Demonstrate task delegation: spawn sub‑agents to analyze different
        files in parallel. Each sub‑agent runs its own closed learning loop.
        """
        from agent.subagent import SubAgent  # Hermes's sub‑agent API

        sub_agents = []
        for i, fpath in enumerate(file_list[:5]):  # limit to 5 files
            sub = SubAgent(
                name=f"reviewer-{i}",
                model=self.agent.model,
                parent=self.agent,
            )
            sub.add_tool("run_linters", run_linters)
            sub_agents.append(sub)

        # Run all sub‑agents concurrently (Hermes handles the threading)
        results = {}
        for sub, fpath in zip(sub_agents, file_list[:5]):
            task = f"Analyze the file {fpath} for bugs, style issues, and security flaws. Return a JSON report."
            results[fpath] = sub.run(task)
        return results

# ---------------------------------------------------------------------------
# 5. Main Entry Point
# ---------------------------------------------------------------------------

def main():
    import argparse

    parser = argparse.ArgumentParser(description="Hermes Agent Code Review Assistant")
    parser.add_argument("--repo", help="GitHub repository (owner/repo)")
    parser.add_argument("--pr", type=int, help="Pull request number to review")
    parser.add_argument("--webhook", action="store_true", help="Start a webhook listener")
    args = parser.parse_args()

    # Validate environment
    if not GITHUB_TOKEN:
        logger.error("GITHUB_TOKEN not set. Please add it to ~/.hermes/.env")
        sys.exit(1)

    # Create the agent
    agent = CodeReviewAgent()

    if args.webhook:
        # Start a simple Flask server to receive GitHub webhooks
        from flask import Flask, request, jsonify
        app = Flask(__name__)

        @app.route("/webhook", methods=["POST"])
        def webhook_handler():
            payload = request.json
            if payload.get("action") in ["opened", "synchronize"]:
                pr = payload["pull_request"]
                owner = pr["base"]["repo"]["owner"]["login"]
                repo = pr["base"]["repo"]["name"]
                pr_number = pr["number"]
                logger.info("Webhook received for PR #%d", pr_number)
                # Run review asynchronously (in production, use a task queue)
                result = agent.review_pull_request(owner, repo, pr_number)
                return jsonify(result.dict()), 200
            return jsonify({"status": "ignored"}), 200

        logger.info("Starting webhook listener on port 5000")
        app.run(host="0.0.0.0", port=5000)
    elif args.repo and args.pr:
        owner, repo = args.repo.split("/")
        result = agent.review_pull_request(owner, repo, args.pr)
        print(result.json(indent=2))
    else:
        parser.print_help()

if __name__ == "__main__":
    main()

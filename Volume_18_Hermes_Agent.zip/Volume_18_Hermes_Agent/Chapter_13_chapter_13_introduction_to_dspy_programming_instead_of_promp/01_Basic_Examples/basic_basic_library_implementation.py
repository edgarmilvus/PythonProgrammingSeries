
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation.py
# Description: Basic Library Implementation
# ==========================================

"""
Basic DSPy library implementation for Hermes Agent skill self-improvement.

This module defines an optimizable program that reads execution traces from
the agent's session database, proposes improvements to skill prompts, and
compiles itself using DSPy's BootstrapFewShot teleprompter.
"""

import json
import logging
from pathlib import Path
from typing import Optional, List, Dict

import dspy
from dspy.teleprompt import BootstrapFewShot
from dspy.evaluate import Evaluate

# Hermes Agent real classes (imports as they exist in the repository)
from agent.agent import AIAgent                          # Core agent class
from agent.prompt_builder import clear_skills_system_prompt_cache  # Cache invalidation
from hermes.session_db import SessionDB                  # Persistent session store
from hermes_constants import get_skills_dir              # Path to skill files

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 1. Define the DSPy Signature
# ---------------------------------------------------------------------------
# A signature declares the typed input/output schema. DSPy uses this to
# automatically generate prompts and parse responses.
class SkillOptimizationSignature(dspy.Signature):
    """Given a skill name and its execution trace, propose an improved skill prompt."""
    skill_name: str = dspy.InputField(desc="Name of the skill to optimize (e.g., 'github-code-review')")
    execution_trace: str = dspy.InputField(
        desc="Recent execution trace showing failures, user corrections, and context"
    )
    improved_prompt: str = dspy.OutputField(
        desc="Rewritten skill prompt that addresses the failures and preserves strengths"
    )

# ---------------------------------------------------------------------------
# 2. Define the DSPy Module
# ---------------------------------------------------------------------------
# A module encapsulates the reasoning pipeline. Here we use ChainOfThought
# to generate structured improvements.
class SkillOptimizer(dspy.Module):
    def __init__(self):
        super().__init__()
        # ChainOfThought adds step-by-step reasoning before the output
        self.optimize = dspy.ChainOfThought(SkillOptimizationSignature)

    def forward(self, skill_name: str, execution_trace: str) -> dspy.Prediction:
        """Run the optimization program."""
        return self.optimize(skill_name=skill_name, execution_trace=execution_trace)

# ---------------------------------------------------------------------------
# 3. Prepare Training Data from SessionDB
# ---------------------------------------------------------------------------
def load_training_examples(session_db: SessionDB, skills_dir: Path,
                           max_examples: int = 50) -> List[dspy.Example]:
    """
    Build a list of DSPy examples from real agent sessions.
    Each example pairs a skill name + execution trace with the ground-truth
    improved prompt (as judged by a human or a heuristic metric).
    """
    examples = []
    # Query sessions where the agent used a skill and received a correction
    sessions = session_db.query(
        filter={"has_correction": True, "skill_used": {"$ne": None}},
        limit=max_examples
    )
    for session in sessions:
        skill_name = session["skill_used"]
        trace = session["execution_trace"]  # Full conversation + tool calls
        # The "improved prompt" is the version that was actually used after correction
        # (stored in the session metadata by the agent's feedback loop)
        improved = session.get("corrected_skill_prompt")
        if not improved:
            continue
        # Create a DSPy example with typed fields
        example = dspy.Example(
            skill_name=skill_name,
            execution_trace=trace,
            improved_prompt=improved
        ).with_inputs("skill_name", "execution_trace")
        examples.append(example)
    logger.info("Loaded %d training examples from SessionDB", len(examples))
    return examples

# ---------------------------------------------------------------------------
# 4. Define the Metric for Optimization
# ---------------------------------------------------------------------------
def skill_improvement_metric(gold: dspy.Example, prediction: dspy.Prediction,
                             trace=None) -> float:
    """
    Evaluate how well the predicted prompt matches the gold standard.
    Uses a combination of:
    - Exact match of key directives (parsed from YAML frontmatter)
    - Semantic similarity via embedding (simplified here)
    - Length constraint (must not exceed 15KB)
    """
    # Simple heuristic: check if the predicted prompt contains all the
    # actionable items from the gold prompt (split by bullet points)
    gold_items = set(gold.improved_prompt.split("\n- "))
    pred_items = set(prediction.improved_prompt.split("\n- "))
    overlap = len(gold_items & pred_items)
    total = len(gold_items)
    if total == 0:
        return 0.0
    # Penalize if predicted prompt exceeds size limit
    if len(prediction.improved_prompt.encode("utf-8")) > 15_000:
        return overlap / total * 0.5  # 50% penalty
    return overlap / total

# ---------------------------------------------------------------------------
# 5. Compile the Optimizer with DSPy's Teleprompter
# ---------------------------------------------------------------------------
def compile_skill_optimizer(session_db: SessionDB,
                            skills_dir: Path,
                            output_path: Optional[Path] = None) -> dspy.Module:
    """
    BootstrapFewShot compiles the SkillOptimizer by selecting the best
    few-shot examples from the training set and tuning the internal prompt.
    """
    trainset = load_training_examples(session_db, skills_dir)
    if not trainset:
        logger.warning("No training examples found; returning untrained optimizer")
        return SkillOptimizer()

    # Configure the teleprompter
    teleprompter = BootstrapFewShot(
        metric=skill_improvement_metric,
        max_bootstrapped_demos=4,
        max_labeled_demos=8,
        max_rounds=3,
        teacher_settings=dict(lm=...),  # Use a more capable model for bootstrapping
    )

    # Compile (this may take several minutes and multiple API calls)
    compiled_optimizer = teleprompter.compile(
        SkillOptimizer(),
        trainset=trainset,
        valset=trainset[:10]  # Small validation split
    )

    # Save the compiled program for reuse
    if output_path:
        compiled_optimizer.save(output_path)
        logger.info("Compiled optimizer saved to %s", output_path)

    return compiled_optimizer

# ---------------------------------------------------------------------------
# 6. Integration with AIAgent: Apply Optimized Skills
# ---------------------------------------------------------------------------
def apply_skill_improvement(agent: AIAgent,
                            skill_name: str,
                            compiled_optimizer: dspy.Module,
                            session_db: SessionDB) -> bool:
    """
    Use the compiled optimizer to improve a single skill, then update the
    agent's skill file and invalidate the prompt cache.
    """
    # Fetch recent execution traces for this skill
    traces = session_db.query(
        filter={"skill_used": skill_name},
        limit=5,
        sort=[("timestamp", -1)]
    )
    combined_trace = "\n---\n".join([t["execution_trace"] for t in traces])

    # Run the optimizer
    prediction = compiled_optimizer(
        skill_name=skill_name,
        execution_trace=combined_trace
    )

    # Read the current skill file to preserve YAML frontmatter
    skill_dir = get_skills_dir() / skill_name
    skill_file = skill_dir / "SKILL.md"
    if not skill_file.exists():
        logger.error("Skill file not found: %s", skill_file)
        return False

    current_content = skill_file.read_text(encoding="utf-8")
    # Simple frontmatter extraction (assumes first --- block)
    if current_content.startswith("---"):
        end = current_content.find("\n---", 3)
        if end != -1:
            frontmatter = current_content[:end+4]
            # Replace the body with the improved prompt
            new_content = frontmatter + "\n\n" + prediction.improved_prompt
        else:
            new_content = prediction.improved_prompt
    else:
        new_content = prediction.improved_prompt

    # Write the updated skill file
    skill_file.write_text(new_content, encoding="utf-8")
    logger.info("Updated skill '%s' with optimized prompt", skill_name)

    # Critical: clear the in-memory and disk cache so the agent picks up the change
    clear_skills_system_prompt_cache(clear_snapshot=True)

    return True

# ---------------------------------------------------------------------------
# 7. Main Execution: End-to-End Example
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    # Initialize real components
    agent = AIAgent()                          # Loads config, tools, memory
    session_db = SessionDB()                   # Connects to ~/.hermes/session.db
    skills_dir = get_skills_dir()

    # Step A: Compile the optimizer from historical sessions
    optimizer = compile_skill_optimizer(
        session_db=session_db,
        skills_dir=skills_dir,
        output_path=Path("/tmp/hermes_skill_optimizer.dspy")
    )

    # Step B: Improve a specific skill that has been underperforming
    success = apply_skill_improvement(
        agent=agent,
        skill_name="github-code-review",
        compiled_optimizer=optimizer,
        session_db=session_db
    )

    if success:
        print("Skill 'github-code-review' has been autonomously improved.")
        print("The agent will use the new prompt starting with the next conversation.")
    else:
        print("Optimization failed. Check logs for details.")

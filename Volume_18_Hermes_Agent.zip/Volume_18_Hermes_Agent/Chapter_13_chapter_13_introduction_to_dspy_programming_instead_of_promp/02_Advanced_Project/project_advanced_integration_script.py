
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script.py
# Description: Advanced Integration Script
# ==========================================

#!/usr/bin/env python3
"""
advanced_integration.py — Closed-loop self-improvement for code review agent.

This script runs a Hermes Agent instance configured for code review,
collects execution traces from each review session, and then uses DSPy
to evolve the agent's 'code-review' skill based on those traces.

Usage:
    python advanced_integration.py --iterations 5 --eval-source synthetic

Requirements:
    - Hermes Agent installed with hermes-agent-self-evolution extras
    - Environment variables: HERMES_AGENT_REPO, OPENAI_API_KEY (or similar)
    - A skill file at ~/.hermes/skills/code-review/SKILL.md
"""

import argparse
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

# ---------------------------------------------------------------------------
# Hermes Agent core imports
# ---------------------------------------------------------------------------
from run_agent import AIAgent  # The main agent class
from agent.skill_utils import (
    get_all_skills_dirs,
    get_skills_dir,
    extract_skill_description,
    parse_frontmatter,
)
from agent.prompt_builder import (
    build_environment_hints,
    DEFAULT_AGENT_IDENTITY,
    MEMORY_GUIDANCE,
    SKILLS_GUIDANCE,
    TOOL_USE_ENFORCEMENT_GUIDANCE,
)
from agent.memory_manager import MemoryManager  # Persistent memory store
from agent.tool_registry import ToolRegistry      # Tool registration and dispatch

# ---------------------------------------------------------------------------
# DSPy / GEPA imports (from hermes-agent-self-evolution)
# ---------------------------------------------------------------------------
from evolution.skills.evolve_skill import evolve_skill
from evolution.skills.evaluation import EvaluationDataset, EvaluationResult

# ---------------------------------------------------------------------------
# Local utilities
# ---------------------------------------------------------------------------
from utils import atomic_json_write, ensure_dir

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
SKILL_NAME = "code-review"
SKILL_DIR = get_skills_dir() / SKILL_NAME
TRACE_DIR = Path.home() / ".hermes" / "traces"
EVAL_DATASET_PATH = Path.home() / ".hermes" / "eval_datasets" / f"{SKILL_NAME}_eval.json"
MEMORY_NAMESPACE = "code_review_self_evolution"

# ---------------------------------------------------------------------------
# Step 1: Build a custom agent with enhanced memory and tool handling
# ---------------------------------------------------------------------------

def create_code_review_agent(
    memory_manager: MemoryManager,
    tool_registry: ToolRegistry,
    model: str = "gpt-4o",
) -> AIAgent:
    """
    Factory function that constructs an AIAgent pre-configured for code review.
    
    We override the default system prompt assembly to include:
    - Custom identity emphasizing code review
    - Memory guidance that prioritizes review conventions
    - Tool enforcement for mandatory checks (e.g., always run linters)
    - Environment hints (WSL, Docker, etc.)
    """
    # Build the system prompt pieces
    identity = (
        "You are a senior code reviewer assistant. Your purpose is to review "
        "pull requests for style, correctness, security, and completeness. "
        "You must use the provided tools to examine diffs, run linters, and "
        "check test coverage. Always provide actionable feedback."
    )
    
    platform_hints = ""  # No platform-specific hints for CLI usage
    env_hints = build_environment_hints()
    
    # Combine into a single system prompt
    system_prompt = "\n\n".join([
        identity,
        MEMORY_GUIDANCE,
        SKILLS_GUIDANCE,
        TOOL_USE_ENFORCEMENT_GUIDANCE,
        env_hints,
    ]).strip()
    
    # Instantiate the agent with custom memory and tools
    agent = AIAgent(
        model=model,
        system_prompt=system_prompt,
        memory_manager=memory_manager,
        tool_registry=tool_registry,
        # Enable skill loading from the skills directory
        skills_dir=get_skills_dir(),
        # Enable trace collection for later analysis
        collect_traces=True,
        # Use a custom session ID for trace grouping
        session_id=f"code-review-{int(time.time())}",
    )
    
    # Register code-review-specific tools (if not already in tool_registry)
    if "run_linter" not in tool_registry.list_tools():
        tool_registry.register_tool(
            name="run_linter",
            func=_run_linter,
            description="Run a linter (e.g., flake8, pylint) on a given file or directory.",
            parameters={
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File or directory path"},
                    "linter": {"type": "string", "enum": ["flake8", "pylint", "mypy"]}
                },
                "required": ["path"]
            }
        )
    
    return agent


def _run_linter(path: str, linter: str = "flake8") -> str:
    """Execute a linter and return output (simplified for demonstration)."""
    import subprocess
    try:
        result = subprocess.run(
            [linter, path],
            capture_output=True,
            text=True,
            timeout=30
        )
        return result.stdout + result.stderr
    except FileNotFoundError:
        return f"Linter '{linter}' not installed."
    except subprocess.TimeoutExpired:
        return "Linter timed out."

# ---------------------------------------------------------------------------
# Step 2: Collect execution traces from a batch of reviews
# ---------------------------------------------------------------------------

def run_review_batch(
    agent: AIAgent,
    review_requests: List[Dict[str, str]],
) -> List[Dict[str, Any]]:
    """
    Process a list of review requests (e.g., PR diffs) and collect traces.
    
    Each request should have:
        - 'diff': the unified diff text
        - 'pr_title': title of the PR
        - 'pr_description': description
        - 'expected_issues': (optional) known issues for evaluation
    
    Returns a list of trace dictionaries with full execution context.
    """
    traces = []
    for req in review_requests:
        logger.info("Processing review: %s", req.get("pr_title", "untitled"))
        
        # Build a user message that simulates a PR review request
        user_message = (
            f"Please review the following pull request:\n\n"
            f"Title: {req['pr_title']}\n"
            f"Description: {req['pr_description']}\n\n"
            f"Diff:\n
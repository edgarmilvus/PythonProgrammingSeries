
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_9.py
# Description: Solution for Exercise 9
# ==========================================

# Modified AIAgent._build_system_prompt (partial)
from prompt_strategy import DefaultPromptStrategy

class AIAgent:
    def __init__(self, ...):
        self.prompt_strategy_module = None  # optional, can be set later
    
    def _build_system_prompt(self, user_query: str, conversation_history: list,
                             prompt_strategy_module: Optional[dspy.Module] = None) -> str:
        # Fallback to instance module if not provided
        module = prompt_strategy_module or self.prompt_strategy_module
        available_sections = ['identity', 'memory_guidance', 'tool_enforcement', 'skills', 'platform_hints']
        if module:
            plan = module(user_query, conversation_history, available_sections)
            selected = plan["selected_sections"]
            weights = plan["weights"]
        else:
            # Default order and equal weights
            selected = available_sections
            weights = [1.0] * len(selected)
        
        # Build prompt by iterating over selected sections
        prompt_parts = []
        for section_id, weight in zip(selected, weights):
            text = self._get_section_text(section_id)  # existing helper
            if weight < 0.3:
                # Truncate to first 20% of text
                text = text[:int(len(text)*0.2)]
            prompt_parts.append(text)
        return "\n\n".join(prompt_parts)
    
    def _get_section_text(self, section_id: str) -> str:
        # Maps section_id to actual text (existing functions)
        if section_id == 'identity':
            return self._build_identity_section()
        elif section_id == 'memory_guidance':
            return MEMORY_GUIDANCE
        # ... etc.


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# skill_evaluator.py
import dspy
from typing import List, Dict, Optional

class SkillQualitySignature(dspy.Signature):
    """DSPy signature for evaluating a skill's quality based on execution traces."""
    skill_content: str = dspy.InputField(desc="Full text of SKILL.md")
    traces: List[Dict] = dspy.InputField(desc="List of execution traces, each with query, action_sequence, result_summary, success")
    quality_score: float = dspy.OutputField(desc="Score between 0 and 1, 1 = perfect adherence to skill intent")

class SkillQualityEvaluator(dspy.Module):
    def __init__(self, session_db: Optional[object] = None):
        super().__init__()
        self.session_db = session_db
        # Use ChainOfThought to reason over traces and produce score
        self.evaluator = dspy.ChainOfThought(SkillQualitySignature)
    
    def forward(self, skill_content: str, traces: List[Dict] = None, skill_name: str = None) -> float:
        # If traces not provided, fetch from SessionDB
        if traces is None and self.session_db and skill_name:
            traces = self.session_db.get_traces_for_skill(skill_name, limit=50)
        # Ensure traces is a list
        if traces is None:
            traces = []
        # Run the DSPy module
        prediction = self.evaluator(skill_content=skill_content, traces=traces)
        # Clamp score to [0,1]
        return max(0.0, min(1.0, prediction.quality_score))

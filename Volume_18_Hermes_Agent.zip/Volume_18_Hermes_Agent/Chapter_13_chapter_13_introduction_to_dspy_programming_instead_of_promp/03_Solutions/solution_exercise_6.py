
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_6.py
# Description: Solution for Exercise 6
# ==========================================

# self_improving_search_tool.py
import dspy
from typing import List, Dict, Optional
from base_tool import BaseTool
from session_db import SessionDB
from tool_registry import ToolRegistry

class DescriptionOptimizer(dspy.Module):
    """DSPy module that proposes and evaluates mutated tool descriptions."""
    def __init__(self):
        super().__init__()
        self.proposer = dspy.ChainOfThought(
            "current_description: str, traces: list[dict] -> variants: list[str]"
        )
        self.evaluator = dspy.ChainOfThought(
            "description: str, traces: list[dict] -> predicted_success_rate: float"
        )
    
    def forward(self, current_description: str, traces: List[Dict]) -> tuple:
        # Propose 3-5 variants
        prediction = self.proposer(
            current_description=current_description,
            traces=traces
        )
        variants = prediction.variants[:5]  # limit to 5
        # Evaluate each variant
        best_variant = current_description
        best_score = 0.0
        for variant in variants:
            score = self.evaluator(description=variant, traces=traces).predicted_success_rate
            if score > best_score:
                best_score = score
                best_variant = variant
        return best_variant, best_score

class SelfImprovingSearchTool(BaseTool):
    def __init__(self, name="web_search", description="...", session_db=None, tool_registry=None):
        super().__init__(name, description)
        self.session_db = session_db or SessionDB()
        self.tool_registry = tool_registry or ToolRegistry()
        self.invocation_count = 0
        self.optimizer = DescriptionOptimizer()
        # Load compiled optimizer if available
        try:
            self.optimizer.load("compiled_description_optimizer.json")
        except:
            pass
    
    def run(self, query: str) -> str:
        # Execute search (actual implementation omitted for brevity)
        result = self._perform_search(query)
        success = self._determine_success(query, result)
        # Log invocation to SessionDB
        self.session_db.log_tool_invocation(
            tool_name=self.name,
            query=query,
            result=result,
            success=success
        )
        self.invocation_count += 1
        # After every 10 invocations, trigger optimization
        if self.invocation_count % 10 == 0:
            self._optimize_description()
        return result
    
    def _optimize_description(self):
        """Propose and test description improvements."""
        # Get recent traces (last 20 invocations)
        traces = self.session_db.get_tool_traces(self.name, limit=20)
        if len(traces) < 5:
            return  # not enough data
        # Optimize description
        new_desc, new_score = self.optimizer(self.description, traces)
        # Evaluate current description's success rate
        current_success_rate = sum(1 for t in traces if t["success"]) / len(traces)
        # If new description is better, update registry
        if new_score > current_success_rate:
            print(f"Improving description: score {current_success_rate:.2f} -> {new_score:.2f}")
            self.description = new_desc
            self.tool_registry.update_tool_description(self.name, new_desc)
            # Optionally save the optimizer for future runs
            self.optimizer.save("compiled_description_optimizer.json")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# compile_evaluator.py
import dspy
import json
from skill_evaluator import SkillQualityEvaluator

# Load human-annotated dataset (list of dicts with skill_content, traces, human_score)
with open("annotated_skills.json", "r") as f:
    dataset = json.load(f)

# Define metric: mean absolute error between predicted and human scores
def metric(predicted_score, human_score):
    return abs(predicted_score - human_score)

# Create evaluator instance (without session_db for compilation)
evaluator = SkillQualityEvaluator()

# Compile the module using DSPy's optimizer (e.g., BayesianSignatureOptimizer)
compiled_evaluator = dspy.compile(
    evaluator,
    trainset=dataset,
    metric=metric,
    max_bootstrapped_demos=5,
    max_labeled_demos=5
)

# Save the compiled module
compiled_evaluator.save("compiled_evaluator.json")
print("Compilation complete. Saved to compiled_evaluator.json")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_7.py
# Description: Solution for Exercise 7
# ==========================================

# test_self_improvement.py
from self_improving_search_tool import SelfImprovingSearchTool
from session_db import SessionDB
from tool_registry import ToolRegistry

db = SessionDB()
registry = ToolRegistry()
tool = SelfImprovingSearchTool(session_db=db, tool_registry=registry)

# Simulate 50 invocations with varied queries
queries = [
    "weather today", "latest AI news", "python list comprehension",  # ... many more
]
successes = []
for i, q in enumerate(queries):
    result = tool.run(q)
    # Record success (simplified)
    success = "error" not in result.lower()
    successes.append(success)
    if (i+1) % 10 == 0:
        print(f"After {i+1} invocations, current description: {tool.description[:50]}...")

# Plot success rate over time (pseudo-code)
import matplotlib.pyplot as plt
plt.plot(range(1, len(successes)+1), successes)
plt.xlabel("Invocation")
plt.ylabel("Success")
plt.title("Self-Improvement Success Rate")
plt.show()

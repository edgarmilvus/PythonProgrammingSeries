
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_10.py
# Description: Solution for Exercise 10
# ==========================================

# compile_prompt_strategy.py
import dspy
import json
from prompt_strategy import DefaultPromptStrategy

# Load handcrafted dataset: list of dicts with user_query, conversation_history, available_sections, ideal_selected, ideal_weights
with open("prompt_strategy_dataset.json", "r") as f:
    dataset = json.load(f)

def metric(pred, ideal):
    # Simple metric: exact match of selected sections and weight proximity
    if pred["selected_sections"] != ideal["selected_sections"]:
        return 0.0
    weight_diff = sum(abs(p - i) for p, i in zip(pred["weights"], ideal["weights"]))
    return 1.0 - (weight_diff / len(ideal["weights"]))  # higher is better

strategy = DefaultPromptStrategy()
compiled = dspy.compile(strategy, trainset=dataset, metric=metric)
compiled.save("compiled_prompt_strategy.json")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_11.py
# Description: Solution for Exercise 11
# ==========================================

# kanban_skill_optimizer.py
import dspy
import json
from typing import Dict, Optional
from datetime import datetime
import time

def optimize_skill(skill_name: str, iterations: int, eval_source: str,
                   session_db, memory_manager) -> Dict:
    """DSPy optimization pipeline for a skill."""
    # Load skill content (e.g., from file)
    with open(f"skills/{skill_name}/SKILL.md", "r") as f:
        skill_content = f.read()
    
    # Load previous optimization history from memory
    memory_key = f"skill_evolution::{skill_name}::history"
    history = memory_manager.load(memory_key) or {}
    
    # Warm-start: use previous best variant if available
    base_content = history.get("best_variant", skill_content)
    
    # Initialize DSPy evaluator and mutator (similar to Exercise 1)
    evaluator = dspy.load("compiled_evaluator.json")  # pre-compiled module
    mutator = dspy.ChainOfThought("skill_content: str -> mutated_content: str")
    
    best_score = history.get("best_score", 0.0)
    best_variant = base_content
    mutation_history = history.get("mutation_history", [])
    start_time = time.time()
    
    for i in range(iterations):
        # Avoid previously failed mutation strategies (simplified: skip if score < 0.3)
        # In real implementation, we would track strategies
        mutated = mutator(skill_content=base_content).mutated_content
        # Evaluate
        traces = session_db.get_traces_for_skill(skill_name, limit=50) if eval_source == "sessiondb" else []
        score = evaluator(skill_content=mutated, traces=traces)
        if score > best_score:
            best_score = score
            best_variant = mutated
        mutation_history.append({
            "iteration": i,
            "score": score,
            "timestamp": datetime.utcnow().isoformat()
        })
    
    duration = time.time() - start_time
    result = {
        "best_score": best_score,
        "best_variant": best_variant,
        "mutation_history": mutation_history[-10:],  # keep last 10
        "duration_seconds": duration
    }
    # Save to persistent memory
    memory_manager.save(memory_key, result)
    return result

# Kanban task handler (pseudo-code integrated into agent loop)
def handle_skill_optimization_task(task, agent):
    """Handler for Kanban tasks of type 'skill_optimization'."""
    body = json.loads(task["body"])
    skill_name = body["skill_name"]
    iterations = body.get("iterations", 5)
    eval_source = body.get("eval_source", "sessiondb")
    
    # Call kanban_show to get task details (already have task)
    # Start optimization with heartbeats
    agent.call_tool("kanban_heartbeat", {"task_id": task["id"]})
    try:
        result = optimize_skill(skill_name, iterations, eval_source,
                                agent.session_db, agent.memory)
        # Complete task with summary
        summary = f"Optimized {skill_name}: best score {result['best_score']:.3f}, took {result['duration_seconds']:.1f}s"
        agent.call_tool("kanban_complete", {"task_id": task["id"], "summary": summary})
    except Exception as e:
        agent.call_tool("kanban_block", {"task_id": task["id"], "reason": str(e)})

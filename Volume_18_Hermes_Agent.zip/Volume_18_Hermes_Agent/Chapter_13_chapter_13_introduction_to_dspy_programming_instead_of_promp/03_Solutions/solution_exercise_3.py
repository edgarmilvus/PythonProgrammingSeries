
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# test_skills.py
from skill_evaluator import SkillQualityEvaluator
from session_db import SessionDB  # hypothetical import

# Load compiled evaluator
evaluator = SkillQualityEvaluator()
evaluator.load("compiled_evaluator.json")

# Connect to SessionDB
db = SessionDB()

skills_to_test = ["github-code-review", "web-search", "file-operations"]
for skill in skills_to_test:
    # Get skill content (e.g., from file)
    with open(f"skills/{skill}/SKILL.md", "r") as f:
        content = f.read()
    # Get traces from DB
    traces = db.get_traces_for_skill(skill, limit=50)
    # Evaluate
    score = evaluator(skill_content=content, traces=traces)
    print(f"{skill}: predicted score = {score:.3f}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# persistent_skill_evolution.py
import dspy
from typing import List, Dict, Optional
from datetime import datetime
import json

class SkillEvolutionPipeline:
    def __init__(self, skill_name: str, skill_content: str, session_db, memory_manager):
        self.skill_name = skill_name
        self.skill_content = skill_content
        self.session_db = session_db
        self.memory = memory_manager
        self.memory_key = f"skill_evolution::{skill_name}::history"
        self.best_score = 0.0
        self.best_variant = skill_content
        self.mutation_history = []
    
    def load_memory(self):
        """Load previous optimization history from persistent memory."""
        data = self.memory.load(self.memory_key)
        if data is not None:
            self.best_score = data.get("best_score", 0.0)
            self.best_variant = data.get("best_variant", self.skill_content)
            self.mutation_history = data.get("mutation_history", [])
    
    def save_memory(self):
        """Save current optimization metadata to memory, bounded to last 10 entries."""
        data = {
            "best_score": self.best_score,
            "best_variant": self.best_variant,
            "mutation_history": self.mutation_history[-10:],  # keep last 10
            "timestamp": datetime.utcnow().isoformat()
        }
        self.memory.save(self.memory_key, data)
    
    def warm_start_variant(self) -> str:
        """Use previous best variant as starting point if it exists."""
        if self.best_score > 0.0:
            return self.best_variant
        return self.skill_content
    
    def get_avoided_strategies(self) -> List[str]:
        """Return mutation strategies that previously yielded low scores."""
        low_score_strategies = []
        for entry in self.mutation_history:
            if entry.get("score", 0) < 0.3:
                low_score_strategies.append(entry.get("strategy"))
        return low_score_strategies
    
    def run_iteration(self, mutation_strategy: str):
        """Run a single optimization iteration with warm-start."""
        # Load memory at start of each iteration (or once per run)
        self.load_memory()
        # Use warm-start variant as base
        base = self.warm_start_variant()
        # Avoid previously failed strategies
        if mutation_strategy in self.get_avoided_strategies():
            print(f"Skipping strategy '{mutation_strategy}' (previously low score)")
            return None
        # ... (rest of mutation and evaluation logic)
        # After evaluation, update best_score and history
        # Example:
        candidate_score = 0.85  # placeholder
        if candidate_score > self.best_score:
            self.best_score = candidate_score
            self.best_variant = "mutated content..."
        self.mutation_history.append({
            "strategy": mutation_strategy,
            "score": candidate_score,
            "timestamp": datetime.utcnow().isoformat()
        })
        self.save_memory()
        return candidate_score

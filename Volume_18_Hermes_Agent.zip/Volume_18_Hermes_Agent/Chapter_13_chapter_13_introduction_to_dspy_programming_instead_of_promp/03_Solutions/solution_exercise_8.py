
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_8.py
# Description: Solution for Exercise 8
# ==========================================

# prompt_strategy.py
import dspy
from typing import List, Optional

class PromptStrategySignature(dspy.Signature):
    """DSPy signature for selecting and weighting prompt sections."""
    user_query: str = dspy.InputField(desc="Current user query")
    conversation_history: List[dict] = dspy.InputField(desc="Last 5 conversation turns")
    available_sections: List[str] = dspy.InputField(desc="IDs of all possible prompt sections")
    selected_sections: List[str] = dspy.OutputField(desc="Ordered list of section IDs to include")
    weights: List[float] = dspy.OutputField(desc="Importance weight for each selected section (0-1)")

class DefaultPromptStrategy(dspy.Module):
    def __init__(self):
        super().__init__()
        self.selector = dspy.ChainOfThought(PromptStrategySignature)
    
    def forward(self, user_query: str, conversation_history: List[dict], available_sections: List[str]) -> dict:
        prediction = self.selector(
            user_query=user_query,
            conversation_history=conversation_history,
            available_sections=available_sections
        )
        return {
            "selected_sections": prediction.selected_sections,
            "weights": prediction.weights
        }

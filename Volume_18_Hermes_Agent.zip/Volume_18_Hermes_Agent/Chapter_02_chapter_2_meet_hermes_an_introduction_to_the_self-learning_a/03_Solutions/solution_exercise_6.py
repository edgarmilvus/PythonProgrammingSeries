
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_6.py
# Description: Solution for Exercise 6
# ==========================================

# In the __init__ method of AIAgent, add:
self._gratitude_counter = 0
self._gratitude_sent = False

# Inside run_conversation, in the main while loop, after successful tool call execution:
# (Find the block that appends tool result to messages)
# After appending the tool result, add:

# Increment gratitude counter on successful tool call
self._gratitude_counter += 1

# Check if we should inject a gratitude message
if self._gratitude_counter % 5 == 0 and not self._gratitude_sent:
    gratitude_msg = {
        "role": "user",
        "content": "System: The agent has completed 5 tool calls. Log a 'thank you' for the user."
    }
    messages.append(gratitude_msg)
    self._gratitude_sent = True
    # Also add to the conversation history for persistence
    if 'conversation_history' in locals() or 'conversation_history' in globals():
        conversation_history.append(gratitude_msg)

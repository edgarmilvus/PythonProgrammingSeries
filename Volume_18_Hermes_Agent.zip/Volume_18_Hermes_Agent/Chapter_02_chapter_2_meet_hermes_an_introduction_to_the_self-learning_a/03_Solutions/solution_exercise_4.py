
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# File: tools/call_counter_tool.py
import json
import os
from hermes_constants import get_hermes_home
from tools.registry import registry

COUNTER_FILE = os.path.join(get_hermes_home(), "call_counter.json")

def call_counter_handler(action: str) -> str:
    """
    Handler for the call_counter tool.
    - If action is "increment", increments the counter and returns the new count.
    - If action is "get_count", returns the current count.
    """
    try:
        # Ensure the directory exists
        os.makedirs(os.path.dirname(COUNTER_FILE), exist_ok=True)
        
        # Read current counter
        if os.path.exists(COUNTER_FILE):
            with open(COUNTER_FILE, 'r') as f:
                data = json.load(f)
                counter = data.get("counter", 0)
        else:
            counter = 0
        
        if action == "increment":
            counter += 1
            with open(COUNTER_FILE, 'w') as f:
                json.dump({"counter": counter}, f)
            return json.dumps({"status": "success", "new_count": counter})
        
        elif action == "get_count":
            return json.dumps({"status": "success", "count": counter})
        
        else:
            return json.dumps({"status": "error", "message": f"Unknown action: {action}"})
    
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})

# Register the tool
registry.register(
    name="call_counter",
    description="Tracks the number of times it has been called and persists the count to a file.",
    parameters={
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["increment", "get_count"],
                "description": "The action to perform: 'increment' to increase the counter, 'get_count' to retrieve the current count."
            }
        },
        "required": ["action"]
    },
    handler=call_counter_handler
)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_7.py
# Description: Solution for Exercise 7
# ==========================================

from run_agent import AIAgent

def main():
    # Initialize agent
    agent = AIAgent()
    
    # Send a complex query that requires multiple tool calls
    user_message = "Find the latest Python 3.13 release notes, summarize them, and then search for any related blog posts."
    
    result = agent.run_conversation(user_message=user_message)
    
    # Print final response
    print("Final Response:", result['final_response'])
    
    # Search for gratitude messages
    print("\nGratitude Messages Found:")
    found_gratitude = False
    for msg in result['messages']:
        if 'thank you' in msg.get('content', '').lower() or 'gratitude' in msg.get('content', '').lower():
            print(f"  Role: {msg['role']}, Content: {msg['content']}")
            found_gratitude = True
    
    if not found_gratitude:
        print("  No gratitude messages found (agent may not have made 5 tool calls).")
    
    # Print total tool calls made
    tool_call_count = sum(1 for msg in result['messages'] if msg.get('role') == 'tool')
    print(f"\nTotal tool calls made: {tool_call_count}")

if __name__ == "__main__":
    main()

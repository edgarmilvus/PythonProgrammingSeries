
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from run_agent import AIAgent
from agent.prompt_builder import _MEMORY_REVIEW_PROMPT

def main():
    # Create a synthetic conversation history
    synthetic_history = [
        {"role": "user", "content": "I always want you to use British English spelling."},
        {"role": "assistant", "content": "Understood. I will use British English spelling from now on.", "tool_calls": [{"function": {"name": "memory", "arguments": '{"action": "store", "content": "User prefers British English spelling."}'}}]},
        {"role": "tool", "content": "Memory updated successfully.", "name": "memory"},
        {"role": "assistant", "content": "I have noted your preference for British English spelling. I will use 'colour' instead of 'color', 'centre' instead of 'center', etc."}
    ]
    
    # Create a parent agent
    parent_agent = AIAgent()
    
    # Create a forked agent for review
    fork_agent = AIAgent(quiet_mode=True, max_iterations=5, enabled_toolsets=["memory"])
    
    # Share the memory store between parent and fork
    fork_agent._memory_store = parent_agent._memory_store
    
    try:
        # Run the review with the synthetic history
        review_result = fork_agent.run_conversation(
            user_message=_MEMORY_REVIEW_PROMPT,
            conversation_history=synthetic_history
        )
        print("Review completed successfully.")
    except Exception as e:
        print(f"Warning: Review agent failed: {e}")
    
    # Verify the new memory entry
    fork_agent._memory_store.load_from_disk()
    memory_contents = fork_agent._memory_store.get_memory(target="memory")
    print("\nMemory contents after review:")
    for entry in memory_contents:
        print(f"  - {entry}")
    
    # Check for British English preference
    if any("British English" in entry for entry in memory_contents):
        print("\nSUCCESS: British English preference was added to memory!")
    else:
        print("\nFAIL: British English preference was NOT added to memory.")
    
    # Cleanup
    fork_agent.shutdown_memory_provider()

if __name__ == "__main__":
    main()

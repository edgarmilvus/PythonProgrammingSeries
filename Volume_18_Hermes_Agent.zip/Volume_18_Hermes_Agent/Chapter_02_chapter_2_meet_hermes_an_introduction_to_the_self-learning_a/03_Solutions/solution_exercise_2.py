
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from run_agent import AIAgent
from model_tools import get_tool_definitions, get_toolset_for_tool

def main():
    # Initialize the agent with only web_search and web_extract tools
    agent = AIAgent(enabled_toolsets=["web_search", "web_extract"])
    
    # Verify toolset configuration
    tool_defs = get_tool_definitions()
    enabled_tools = [tool for tool in tool_defs if tool["name"] in ["web_search", "web_extract"]]
    print(f"Enabled tools: {[t['name'] for t in enabled_tools]}")
    
    # Craft a message that will force a web_search call
    user_message = "Search the web for the latest news on quantum computing and give me a summary."
    
    try:
        # Run the conversation
        result = agent.run_conversation(user_message=user_message)
        
        # Print the final response
        print(f"\nFinal Response: {result['final_response']}\n")
        
        # Iterate through messages and print role/name
        print("Message Sequence:")
        for msg in result['messages']:
            role = msg.get('role', 'unknown')
            name = msg.get('name', 'N/A')
            print(f"  Role: {role}, Name: {name}")
        
        # Find and print the first tool call
        for msg in result['messages']:
            if 'tool_calls' in msg:
                first_tool_call = msg['tool_calls'][0]
                print(f"\nFirst Tool Call:")
                print(f"  Name: {first_tool_call['function']['name']}")
                print(f"  Arguments: {first_tool_call['function']['arguments']}")
                break
                
    except RuntimeError as e:
        print(f"Runtime error during conversation: {e}")
    except Exception as e:
        print(f"Unexpected error: {e}")

if __name__ == "__main__":
    main()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# File: verify_call_counter.py
import sys
sys.path.insert(0, '.')  # Add project root to path

from tools.call_counter_tool import call_counter_handler
import json

def main():
    # Test increment
    result1 = call_counter_handler(action="increment")
    data1 = json.loads(result1)
    print(f"Increment result: {data1}")
    assert data1["status"] == "success", "Increment failed"
    assert data1["new_count"] > 0, "Counter was not incremented"
    
    # Test get_count
    result2 = call_counter_handler(action="get_count")
    data2 = json.loads(result2)
    print(f"Get count result: {data2}")
    assert data2["status"] == "success", "Get count failed"
    assert data2["count"] == data1["new_count"], "Count mismatch"
    
    print("\nVerification passed! Counter value:", data2["count"])

if __name__ == "__main__":
    main()

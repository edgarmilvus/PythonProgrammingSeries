
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import sys
from tools.memory_tool import MemoryStore

def main():
    # Initialize MemoryStore with specified limits
    memory_store = MemoryStore(memory_char_limit=2000, user_char_limit=1000)
    
    # Load existing state from disk with error handling
    try:
        memory_store.load_from_disk()
        print("Memory state loaded successfully.")
    except Exception as e:
        print(f"Error loading memory from disk: {e}")
    
    # Parse command-line argument
    if len(sys.argv) < 2:
        print("Usage: python journal.py [save|load]")
        sys.exit(1)
    
    action = sys.argv[1].lower()
    
    if action == "save":
        # Prompt user for a note
        note = input("Enter your note: ")
        
        # Save the note to the "memory" target
        try:
            memory_store.save_to_disk(target="memory", content=note)
            print("Note saved successfully!")
        except Exception as e:
            print(f"Error saving note: {e}")
    
    elif action == "load":
        # Load and print all saved notes from the "memory" target
        try:
            memory_store.load_from_disk()
            notes = memory_store.get_memory(target="memory")
            if notes:
                print("Saved Notes:")
                for i, note in enumerate(notes, 1):
                    print(f"{i}. {note}")
            else:
                print("No notes found.")
        except Exception as e:
            print(f"Error loading notes: {e}")
    
    else:
        print("Invalid action. Use 'save' or 'load'.")

if __name__ == "__main__":
    main()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script.py
# Description: Advanced Integration Script
# ==========================================

#!/usr/bin/env python3
"""
Hermes Agent Advanced Integration: Self-Orchestrating Data Analysis Pipeline

This script demonstrates a production-grade integration of the Hermes Agent
library for complex, multi-step data analysis tasks. It showcases:

1. Persistent memory for user preference learning
2. Parallel task delegation with sub-agents
3. Dynamic tool selection based on task requirements
4. Closed-loop self-improvement through reflection
5. Robust error recovery with fallback providers

Requirements:
    - Hermes Agent installed (pip install hermes-agent)
    - OpenRouter API key (or alternative provider)
    - Python 3.11+
"""

import asyncio
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Any
from datetime import datetime

# Core Hermes Agent import
from run_agent import AIAgent, IterationBudget

# Configure structured logging for observability
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("hermes_pipeline.log"),
    ],
)
logger = logging.getLogger("data_pipeline")


class DataAnalysisPipeline:
    """
    A self-orchestrating data analysis pipeline using Hermes Agent.

    This class encapsulates the entire workflow: from user input to final
    report generation, with built-in memory persistence, parallel task
    delegation, and self-improvement through reflection.
    """

    def __init__(
        self,
        provider: str = "openrouter",
        model: str = "anthropic/claude-sonnet-4-20250514",
        fallback_model: str = "openai/gpt-4o",
        max_iterations: int = 50,
        memory_enabled: bool = True,
        user_profile_enabled: bool = True,
    ):
        """
        Initialize the pipeline with a primary and fallback agent configuration.

        Args:
            provider: Primary LLM provider (e.g., "openrouter", "anthropic")
            model: Primary model identifier
            fallback_model: Fallback model for error recovery
            max_iterations: Maximum tool-calling iterations per turn
            memory_enabled: Enable persistent memory (MEMORY.md)
            user_profile_enabled: Enable user profile learning (USER.md)
        """
        self.provider = provider
        self.model = model
        self.fallback_model = fallback_model
        self.max_iterations = max_iterations
        self.memory_enabled = memory_enabled
        self.user_profile_enabled = user_profile_enabled

        # Track session-level metrics for observability
        self.session_metrics = {
            "total_turns": 0,
            "total_api_calls": 0,
            "total_tokens": 0,
            "estimated_cost": 0.0,
            "errors": [],
            "fallbacks_activated": 0,
        }

        # Initialize the primary orchestrator agent
        self.orchestrator = self._create_orchestrator_agent()

        # Create a shared memory store that persists across sessions
        # This allows the agent to remember user preferences between runs
        self._init_memory_store()

        logger.info(
            "DataAnalysisPipeline initialized: provider=%s model=%s fallback=%s",
            provider,
            model,
            fallback_model,
        )

    def _create_orchestrator_agent(self) -> AIAgent:
        """
        Create the primary orchestrator AIAgent with comprehensive tooling.

        The orchestrator is configured with:
        - File tools for reading/writing data
        - Code execution for running analysis scripts
        - Web search for external data enrichment
        - Delegation tools for spawning sub-agents
        - Memory tools for persistent learning
        - Fallback provider for reliability
        """
        return AIAgent(
            model=self.model,
            provider=self.provider,
            max_iterations=self.max_iterations,
            # Enable a carefully curated set of toolsets for data analysis
            enabled_toolsets=[
                "file",          # Read/write files
                "code_execution", # Run Python scripts
                "web",           # Search and extract web content
                "delegation",    # Spawn sub-agents
                "memory",        # Persistent memory
                "terminal",      # Shell commands for system tasks
                "vision",        # Analyze charts and images
            ],
            # Configure fallback for resilience
            fallback_model={
                "provider": "openrouter",
                "model": self.fallback_model,
            },
            # Enable persistent memory for user preference learning
            skip_memory=not self.memory_enabled,
            # Set a generous output token limit for complex tasks
            max_tokens=16384,
            # Enable verbose logging for debugging
            verbose_logging=True,
            # Pass session identity for memory scoping
            platform="pipeline",
            user_id="data_analyst_01",
        )

    def _init_memory_store(self):
        """
        Initialize the in-memory memory store for user preference tracking.

        This allows the agent to remember:
        - Preferred output formats (e.g., markdown, HTML)
        - Visualization styles (e.g., color schemes, chart types)
        - Data cleaning preferences (e.g., outlier handling)
        - Common analysis patterns the user prefers
        """
        if not self.memory_enabled:
            return

        # The AIAgent's __init__ already loads memory from disk.
        # We just need to ensure the store is accessible for custom queries.
        self.memory_store = getattr(self.orchestrator, "_memory_store", None)
        if self.memory_store:
            logger.info("Memory store initialized with %d entries", 
                       len(self.memory_store.memory_entries))

    def run_analysis(
        self,
        user_request: str,
        data_directory: str = "./data",
        output_format: str = "markdown",
        parallel_tasks: bool = True,
    ) -> Dict[str, Any]:
        """
        Execute a complete data analysis workflow based on user request.

        This is the main entry point that orchestrates the entire pipeline.

        Args:
            user_request: Natural language description of the analysis task
            data_directory: Path to the directory containing data files
            output_format: Desired output format ("markdown", "html", "pdf")
            parallel_tasks: Whether to use parallel sub-agent delegation

        Returns:
            Dict containing the final response and session metrics
        """
        logger.info("Starting analysis: request=%s directory=%s", 
                   user_request[:50], data_directory)

        # Step 1: Build the comprehensive system prompt with context
        system_prompt = self._build_analysis_system_prompt(
            data_directory=data_directory,
            output_format=output_format,
            parallel_tasks=parallel_tasks,
        )

        # Step 2: Execute the conversation with the orchestrator agent
        start_time = time.time()
        result = self.orchestrator.run_conversation(
            user_message=user_request,
            system_message=system_prompt,
            # Pass the data directory as context for file operations
            task_id=data_directory,
        )
        elapsed = time.time() - start_time

        # Step 3: Update session metrics for observability
        self._update_metrics(result, elapsed)

        # Step 4: Trigger background self-improvement review
        # The agent reflects on this session and updates memory/skills
        if self.memory_enabled and result.get("completed"):
            self._trigger_self_improvement(result)

        logger.info(
            "Analysis completed: turns=%d api_calls=%d tokens=%d elapsed=%.2fs",
            self.session_metrics["total_turns"],
            self.session_metrics["total_api_calls"],
            self.session_metrics["total_tokens"],
            elapsed,
        )

        return {
            "response": result.get("final_response", ""),
            "metrics": self.session_metrics,
            "messages": result.get("messages", []),
            "completed": result.get("completed", False),
            "elapsed_seconds": elapsed,
        }

    def _build_analysis_system_prompt(
        self,
        data_directory: str,
        output_format: str,
        parallel_tasks: bool,
    ) -> str:
        """
        Build a detailed system prompt that guides the agent's behavior.

        This prompt includes:
        - Task context and constraints
        - Preferred workflow patterns
        - Memory recall for user preferences
        - Instructions for delegation and parallel execution
        """
        # Recall any stored user preferences from memory
        preferences = self._recall_user_preferences()

        prompt = f"""
You are an expert data analysis assistant with access to powerful tools.
Your task is to analyze data files in {data_directory} and produce a
comprehensive {output_format} report.

## Workflow Instructions

1. **Exploration Phase**: First, explore the data directory to understand
   what files are available. Use `read_file` and `search_files` to inspect
   the data structure.

2. **Analysis Phase**: Write Python scripts using `execute_code` to perform
   statistical analysis, data cleaning, and visualization. Save visualizations
   as PNG files in the output directory.

3. **Delegation Phase**: For complex multi-step tasks, use `delegate_task`
   to spawn sub-agents that work in parallel. Each sub-agent should handle
   a distinct aspect of the analysis (e.g., one cleans data, another
   generates visualizations, a third searches for context).

4. **Report Generation Phase**: Compile all findings into a well-structured
   {output_format} report. Include:
   - Executive summary
   - Data quality assessment
   - Key statistical findings
   - Visualizations (embedded as markdown images)
   - Conclusions and recommendations

## User Preferences (from memory)
{preferences or "No stored preferences found. Learn from this session."}

## Memory & Learning
- Save important user preferences to memory using the `memory` tool.
- Create or update skills using `skill_manage` for reusable analysis patterns.
- After completing the task, reflect on what worked well and what could improve.

## Delegation Guidelines
- Use `delegate_task` with `tasks` parameter for parallel work.
- Each sub-agent should have a clear, focused goal.
- Collect results from all sub-agents before generating the final report.
- Maximum concurrent sub-agents: 3

## Error Recovery
- If a tool fails, try an alternative approach before reporting failure.
- Use the fallback model if the primary provider is rate-limited.
- Document any errors encountered and how they were resolved.

## Output Format
- Generate the final report as a {output_format} file.
- Save all outputs to ./output/ directory.
- Include timestamps and version information.
"""
        return prompt.strip()

    def _recall_user_preferences(self) -> str:
        """
        Retrieve stored user preferences from the agent's memory.

        This demonstrates the persistent memory feature: the agent remembers
        how the user likes their reports formatted, what visualization styles
        they prefer, and any other preferences expressed in previous sessions.
        """
        if not self.memory_store:
            return ""

        try:
            # Format memory entries for inclusion in the system prompt
            memory_block = self.memory_store.format_for_system_prompt("memory")
            user_block = self.memory_store.format_for_system_prompt("user")
            parts = []
            if memory_block:
                parts.append(f"## Memory Entries\n{memory_block}")
            if user_block:
                parts.append(f"## User Profile\n{user_block}")
            return "\n\n".join(parts)
        except Exception as e:
            logger.warning("Failed to recall preferences: %s", e)
            return ""

    def _trigger_self_improvement(self, result: Dict[str, Any]):
        """
        Trigger the agent's closed learning loop for self-improvement.

        The agent reviews the conversation, identifies lessons learned,
        and updates its memory and skills for future sessions. This is
        the core of the closed learning loop.
        """
        try:
            # The AIAgent already has built-in background review logic.
            # We just need to ensure it's triggered after the main turn.
            messages = result.get("messages", [])
            if messages:
                # The agent's _spawn_background_review method runs asynchronously
                # in a separate thread, so it doesn't block the main pipeline.
                self.orchestrator._spawn_background_review(
                    messages_snapshot=list(messages),
                    review_memory=True,
                    review_skills=True,
                )
                logger.info("Self-improvement review triggered in background")
        except Exception as e:
            logger.warning("Self-improvement review failed: %s", e)

    def _update_metrics(self, result: Dict[str, Any], elapsed: float):
        """
        Update session metrics from the agent's response.

        Tracks token usage, API calls, errors, and cost for observability.
        """
        metrics = self.session_metrics
        metrics["total_turns"] += 1
        metrics["total_api_calls"] += result.get("api_calls", 0)
        metrics["total_tokens"] += result.get("total_tokens", 0)
        metrics["estimated_cost"] += result.get("estimated_cost_usd", 0.0)

        if result.get("error"):
            metrics["errors"].append(result["error"])

        if result.get("fallback_activated"):
            metrics["fallbacks_activated"] += 1

    def switch_model_dynamically(self, new_model: str, new_provider: str):
        """
        Dynamically switch the agent's model at runtime.

        This is useful when a task requires different capabilities
        (e.g., switching to a reasoning model for complex logic,
        then back to a fast model for simple tasks).
        """
        logger.info("Switching model: %s -> %s (%s)", 
                   self.model, new_model, new_provider)
        self.orchestrator.switch_model(
            new_model=new_model,
            new_provider=new_provider,
        )
        self.model = new_model
        self.provider = new_provider

    def inject_user_guidance(self, guidance: str):
        """
        Inject real-time user guidance into the running agent.

        This uses the /steer mechanism to provide mid-task corrections
        without interrupting the agent's flow.
        """
        logger.info("Injecting user guidance: %s", guidance[:50])
        self.orchestrator.steer(guidance)

    def interrupt_and_redirect(self, new_instruction: str):
        """
        Interrupt the current task and redirect the agent to a new priority.

        This demonstrates the interrupt mechanism for handling urgent
        user requests that supersede the current task.
        """
        logger.warning("Interrupting current task with new instruction: %s",
                      new_instruction[:50])
        self.orchestrator.interrupt(message=new_instruction)

    def get_activity_summary(self) -> Dict[str, Any]:
        """
        Get a snapshot of the agent's current activity for diagnostics.

        Useful for monitoring long-running tasks and providing
        progress updates to the user.
        """
        return self.orchestrator.get_activity_summary()

    def shutdown(self):
        """
        Gracefully shut down the pipeline, releasing all resources.

        Ensures memory providers are flushed and connections are closed.
        """
        logger.info("Shutting down pipeline...")
        try:
            self.orchestrator.shutdown_memory_provider()
            self.orchestrator.close()
        except Exception as e:
            logger.error("Shutdown error: %s", e)


# =========================================================================
# Advanced Usage: Parallel Task Delegation with Sub-Agents
# =========================================================================

class ParallelAnalysisDelegate:
    """
    Demonstrates advanced task delegation with parallel sub-agents.

    This class shows how to use the Hermes Agent's delegation capabilities
    to spawn multiple sub-agents that work on different aspects of a task
    simultaneously, then aggregate their results.
    """

    def __init__(self, orchestrator: AIAgent):
        self.orchestrator = orchestrator

    async def run_parallel_analysis(
        self,
        data_files: List[str],
        analysis_types: List[str],
    ) -> Dict[str, Any]:
        """
        Run multiple analysis tasks in parallel using sub-agents.

        Each sub-agent is spawned via delegate_task and works independently.
        Results are collected and aggregated into a unified report.

        Args:
            data_files: List of file paths to analyze
            analysis_types: Types of analysis to perform (e.g., 
                          ["statistical", "visualization", "anomaly_detection"])

        Returns:
            Aggregated results from all sub-agents
        """
        logger.info("Starting parallel analysis with %d sub-agents", 
                   len(analysis_types))

        # Build the delegation tasks
        tasks = []
        for analysis_type in analysis_types:
            task = {
                "goal": f"Perform {analysis_type} analysis on {data_files}",
                "context": f"""
You are a specialized analysis sub-agent. Your task is to perform
{analysis_type} analysis on the following files: {data_files}

Guidelines:
- Use execute_code for computational analysis
- Save intermediate results to ./output/{analysis_type}/
- Return a structured JSON summary of findings
- Do NOT call delegate_task yourself (leaf agent)
- Do NOT use memory or clarify tools
""",
                "toolsets": ["file", "code_execution"],
            }
            tasks.append(task)

        # Execute all tasks in a single delegate_task call
        # The orchestrator handles concurrent execution internally
        result = self.orchestrator.run_conversation(
            user_message=f"""
Please delegate the following {len(tasks)} analysis tasks to parallel sub-agents.
Use the delegate_task tool with the 'tasks' parameter to run them concurrently.

Tasks:
{json.dumps(tasks, indent=2)}

After all sub-agents complete, aggregate their results into a unified
analysis report saved to ./output/aggregated_report.md.
""",
            system_message="""
You are an orchestrator agent. Your role is to:
1. Delegate tasks to sub-agents using delegate_task with tasks=[]
2. Wait for all sub-agents to complete
3. Collect and aggregate their results
4. Generate a unified report

Important:
- Use the 'tasks' parameter for parallel execution
- Each sub-agent is a leaf agent (cannot delegate further)
- Collect results before generating the final report
""",
        )

        logger.info("Parallel analysis completed: %s", 
                   "success" if result.get("completed") else "partial")
        return result


# =========================================================================
# Production Entry Point with CLI Interface
# =========================================================================

def main():
    """
    Production entry point that demonstrates the complete pipeline.

    This function:
    1. Parses command-line arguments
    2. Initializes the pipeline with configuration
    3. Executes the analysis
    4. Handles errors gracefully
    5. Reports metrics
    """
    import argparse

    parser = argparse.ArgumentParser(
        description="Hermes Agent Advanced Integration: Data Analysis Pipeline"
    )
    parser.add_argument(
        "--request",
        type=str,
        default="Analyze the sales data in ./data and generate a comprehensive report "
                 "with visualizations. Look for trends, anomalies, and provide "
                 "actionable recommendations.",
        help="Natural language analysis request",
    )
    parser.add_argument(
        "--data-dir",
        type=str,
        default="./data",
        help="Directory containing data files",
    )
    parser.add_argument(
        "--output-format",
        type=str,
        choices=["markdown", "html", "pdf"],
        default="markdown",
        help="Output report format",
    )
    parser.add_argument(
        "--model",
        type=str,
        default="anthropic/claude-sonnet-4-20250514",
        help="Primary LLM model",
    )
    parser.add_argument(
        "--fallback-model",
        type=str,
        default="openai/gpt-4o",
        help="Fallback LLM model",
    )
    parser.add_argument(
        "--no-parallel",
        action="store_true",
        help="Disable parallel task delegation",
    )
    parser.add_argument(
        "--no-memory",
        action="store_true",
        help="Disable persistent memory",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose logging",
    )

    args = parser.parse_args()

    # Configure logging level
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # Ensure data directory exists
    data_dir = Path(args.data_dir)
    if not data_dir.exists():
        logger.warning("Data directory %s does not exist. Creating sample data.", 
                      data_dir)
        data_dir.mkdir(parents=True, exist_ok=True)
        _create_sample_data(data_dir)

    # Initialize the pipeline
    pipeline = DataAnalysisPipeline(
        provider="openrouter",
        model=args.model,
        fallback_model=args.fallback_model,
        max_iterations=50,
        memory_enabled=not args.no_memory,
        user_profile_enabled=not args.no_memory,
    )

    try:
        # Execute the analysis
        logger.info("Starting analysis pipeline...")
        result = pipeline.run_analysis(
            user_request=args.request,
            data_directory=str(data_dir),
            output_format=args.output_format,
            parallel_tasks=not args.no_parallel,
        )

        # Print results
        print("\n" + "=" * 60)
        print("ANALYSIS COMPLETE")
        print("=" * 60)
        print(f"Response length: {len(result['response'])} characters")
        print(f"Completed: {result['completed']}")
        print(f"Elapsed: {result['elapsed_seconds']:.2f} seconds")
        print(f"API calls: {result['metrics']['total_api_calls']}")
        print(f"Total tokens: {result['metrics']['total_tokens']:,}")
        print(f"Estimated cost: ${result['metrics']['estimated_cost']:.4f}")
        print(f"Errors: {len(result['metrics']['errors'])}")
        print(f"Fallbacks activated: {result['metrics']['fallbacks_activated']}")
        print("\n--- Response Preview ---")
        print(result['response'][:500] + "...")
        print("\nFull response saved to output/analysis_report.md")

        # Save the full response to a file
        output_dir = Path("./output")
        output_dir.mkdir(exist_ok=True)
        report_path = output_dir / f"analysis_report_{datetime.now():%Y%m%d_%H%M%S}.md"
        report_path.write_text(result['response'], encoding="utf-8")
        print(f"Report saved to: {report_path}")

    except KeyboardInterrupt:
        logger.warning("Pipeline interrupted by user")
        print("\n\nPipeline interrupted. Cleaning up...")
    except Exception as e:
        logger.error("Pipeline failed: %s", e, exc_info=True)
        print(f"\nPipeline failed: {e}")
        return 1
    finally:
        pipeline.shutdown()
        logger.info("Pipeline shutdown complete")

    return 0


def _create_sample_data(data_dir: Path):
    """
    Create sample CSV data files for demonstration purposes.

    This ensures the pipeline has data to work with even when
    no real data is available.
    """
    import csv

    sample_data = [
        {"date": "2024-01-01", "region": "North", "product": "Widget A", "sales": 1200, "units": 100},
        {"date": "2024-01-01", "region": "South", "product": "Widget A", "sales": 800, "units": 65},
        {"date": "2024-01-02", "region": "North", "product": "Widget B", "sales": 1500, "units": 120},
        {"date": "2024-01-02", "region": "East", "product": "Widget A", "sales": 950, "units": 78},
        {"date": "2024-01-03", "region": "West", "product": "Widget C", "sales": 2100, "units": 180},
        {"date": "2024-01-03", "region": "South", "product": "Widget B", "sales": 1100, "units": 90},
    ]

    filepath = data_dir / "sales_data.csv"
    with open(filepath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=sample_data[0].keys())
        writer.writeheader()
        writer.writerows(sample_data)

    logger.info("Created sample data file: %s", filepath)


if __name__ == "__main__":
    sys.exit(main())

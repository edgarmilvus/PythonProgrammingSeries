
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation.py
# Description: Basic Library Implementation
# ==========================================

"""
Basic Hermes Agent Library Implementation
==========================================

This script demonstrates how to set up an AIAgent with persistent memory,
a session database, and a focused toolset for repository maintenance tasks.

We configure:
 - A SQLite session store (SessionDB) to persist conversation history.
 - A MemoryStore for long-term fact accumulation (MEMORY.md / USER.md).
 - A context compressor (ContextCompressor) to keep the conversation within
   the model's context window.
 - The AIAgent itself, with the "file", "search", and "web" toolsets enabled.

The agent is then used to process a user query about stale TODO comments
and produce a structured report.
"""

import os
import uuid
from datetime import datetime
from pathlib import Path

# Hermes-specific imports
from hermes_state import SessionDB                                      # SQLite-backed session persistence
from hermes_constants import get_hermes_home                            # Profile-aware home directory
from run_agent import AIAgent                                           # The core agent class
from tools.memory_tool import MemoryStore                               # Persistent memory / user profile store
from agent.context_compressor import ContextCompressor                   # Automatic context management
from agent.model_metadata import fetch_model_metadata, get_model_context_length
from agent.prompt_builder import DEFAULT_AGENT_IDENTITY                 # Fallback system prompt identity
from toolsets import get_all_toolsets_info                              # For inspecting available tool sets

# ---------------------------------------------------------------------------
# 1.  Environment & Path Setup
# ---------------------------------------------------------------------------

# Determine the Hermes home directory (profiles-aware).
# get_hermes_home() returns ~/.hermes or a profile-specific subdirectory.
hermes_home: Path = get_hermes_home()
print(f"[CONFIG] Hermes home directory : {hermes_home}")

# Create the sessions subdirectory if it doesn't exist.
sessions_dir: Path = hermes_home / "sessions"
sessions_dir.mkdir(parents=True, exist_ok=True)

# Generate a unique session identifier for this conversation.
session_id: str = f"lib_demo_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
print(f"[CONFIG] Session ID            : {session_id}")

# ---------------------------------------------------------------------------
# 2.  Initialise the Session Database (SessionDB)
# ---------------------------------------------------------------------------

# SessionDB stores the full conversation history in a local SQLite file.
# It supports FTS5 full-text search, token usage tracking, and system-prompt caching.
session_db_path: Path = hermes_home / "sessions" / "demo.sqlite"
session_db: SessionDB = SessionDB(db_path=str(session_db_path))
print(f"[DB]     Session database path  : {session_db_path}")

# Register the session row so that message appends have a parent to attach to.
session_db.create_session(
    session_id=session_id,
    source="library_demo",
    model="anthropic/claude-sonnet-4.6",                         # initial model, can be changed later
    model_config={"max_iterations": 30, "reasoning_config": None, "max_tokens": None},
    system_prompt="",
    user_id=None,
    parent_session_id=None,
)
print(f"[DB]     Session row created for {session_id}")

# ---------------------------------------------------------------------------
# 3.  Initialise the Memory Store (MemoryStore)
# ---------------------------------------------------------------------------

# The MemoryStore manages two files inside ~/.hermes:
#   MEMORY.md – durable facts about the conversation domain.
#   USER.md   – preferences and identity of the user.
memory_store: MemoryStore = MemoryStore(
    memory_char_limit=2200,
    user_char_limit=1375,
)
memory_store.load_from_disk()                                     # Load existing entries from disk.
print(f"[MEMORY] Memory store initialised (size: {len(memory_store.format_for_system_prompt('memory'))} chars)")

# ---------------------------------------------------------------------------
# 4.  Initialise the Context Compressor
# ---------------------------------------------------------------------------

# The context compressor monitors how many tokens the conversation is using
# and triggers automatic summarisation of the middle turns when we approach
# the model's context limit (default threshold 50% of the window).
#
# We start with a default context length of 128 K tokens. The compressor
# will probe the real limit via the provider's /models endpoint on first use.
context_compressor: ContextCompressor = ContextCompressor(
    model="anthropic/claude-sonnet-4.6",
    threshold_percent=0.50,
    protect_first_n=3,
    protect_last_n=20,
    summary_target_ratio=0.20,
    summary_model_override=None,
    quiet_mode=False,
    base_url="https://openrouter.ai/api/v1",
    api_key=os.environ.get("OPENROUTER_API_KEY", ""),
    config_context_length=None,
    provider="openrouter",
    api_mode="chat_completions",
)
print(f"[COMPRESSOR] Context compressor initialised (threshold: {context_compressor.threshold_tokens:,} tokens)")

# ---------------------------------------------------------------------------
# 5.  Build the AIAgent
# ---------------------------------------------------------------------------

# The AIAgent constructor accepts dozens of parameters.  Here we focus on
# the ones most relevant to a library-style usage:
#   - model / base_url / api_key / provider – the LLM backend.
#   - max_iterations – how many tool-calling turns before a forced summary.
#   - enabled_toolsets – restrict the agent to the tools we need.
#   - session_id – tie this agent to the SQLite session we just created.
#   - session_db – the SessionDB instance for automatic persistence.
#   - tool_progress_callback – callback to observe tool execution.
#   - verbose_logging – enable detailed logs for debugging.
#   - skip_context_files – avoid loading AGENTS.md / .cursorrules from the
#     repository (these are for development of Hermes itself, not for users).
#   - load_soul_identity – still load ~/.hermes/SOUL.md as the agent's
#     persona even though skip_context_files=True.

agent: AIAgent = AIAgent(
    model="anthropic/claude-sonnet-4.6",
    base_url="https://openrouter.ai/api/v1",
    api_key=os.environ.get("OPENROUTER_API_KEY", ""),
    provider="openrouter",
    max_iterations=30,                                              # max LLM calls per turn
    enabled_toolsets=["file", "search", "web"],                     # tools for code inspection + web lookup
    disabled_toolsets=None,
    save_trajectories=False,
    verbose_logging=True,
    quiet_mode=False,
    session_id=session_id,
    session_db=session_db,                                          # persist every message to SQLite
    tool_progress_callback=None,                                    # optional: can be a lambda for logging
    platform="library_demo",
    user_id="demo_user",
    user_name="Demo User",
    skip_context_files=True,                                        # do not inject repo AGENTS.md
    load_soul_identity=True,                                        # load ~/.hermes/SOUL.md for persona
    credential_pool=None,                                           # single credential used here
)
print(f"[AGENT]  AIAgent created. Model: {agent.model}  Provider: {agent.provider}")

# ---------------------------------------------------------------------------
# 6.  System Prompt Caching
# ---------------------------------------------------------------------------

# The system prompt is built once and cached for the entire session.
# The first call to _build_system_prompt assembles all layers:
#   SOUL.md → DEFAULT_AGENT_IDENTITY → memory block → skills → context
#   files → timestamp → platform hints.
# After context compression the cache is invalidated and rebuilt.
if agent._cached_system_prompt is None:
    agent._cached_system_prompt = agent._build_system_prompt(system_message=None)
    # Immediately persist the system prompt to the SessionDB.
    session_db.update_system_prompt(session_id=session_id, system_prompt=agent._cached_system_prompt)
    print(f"[SYSTEM] System prompt cached ({len(agent._cached_system_prompt):,} chars)")

# ---------------------------------------------------------------------------
# 7.  Run a Conversation
# ---------------------------------------------------------------------------

user_query: str = (
    "Search the current repository for TODO comments that are more than "
    "six months old. Categorise them as 'stale', 'accepted', or 'rejected'. "
    "For each stale TODO, propose a short JIRA summary. Do not write the "
    "tickets yet – just list your findings."
)

print(f"\n[RUN]    Starting conversation with query:\n         \"{user_query}\"\n")

# run_conversation returns a structured dict with the final response,
# full message history, token usage, and diagnostic metadata.
result: dict = agent.run_conversation(
    user_message=user_query,
    system_message=None,                                           # use the cached system prompt
    conversation_history=None,                                     # first turn → empty history
    task_id=None,                                                  # auto-generate a task ID
    stream_callback=None,                                          # no streaming in library mode
    persist_user_message=None,                                     # no difference between API text and stored text
)

# ---------------------------------------------------------------------------
# 8.  Inspect the Results
# ---------------------------------------------------------------------------

print("\n[RESULT] Conversation completed.")
print(f"         Exit reason        : {result.get('turn_exit_reason', 'unknown')}")
print(f"         API calls made     : {result['api_calls']}")
print(f"         Messages exchanged : {len(result['messages'])}")
print(f"         Input tokens       : {result.get('input_tokens', 0):,}")
print(f"         Output tokens      : {result.get('output_tokens', 0):,}")
print(f"         Total tokens       : {result.get('total_tokens', 0):,}")
print(f"         Estimated cost ($) : {result.get('estimated_cost_usd', 0.0):.4f}")
print(f"         Completed          : {result['completed']}")
print(f"         Interrupted        : {result['interrupted']}")

if result['final_response']:
    print(f"\n--- FINAL RESPONSE ---\n{result['final_response']}\n-----------------------")

# ---------------------------------------------------------------------------
# 9.  Demonstrate Memory Persistence
# ---------------------------------------------------------------------------

# The agent may have written new facts to MEMORY.md during the conversation.
# Reload the store and inspect the updated content.
memory_store.load_from_disk()
print(f"[MEMORY] Memory size after conversation: {len(memory_store.format_for_system_prompt('memory'))} chars")
print(f"[MEMORY] User profile size              : {len(memory_store.format_for_system_prompt('user'))} chars")

# ---------------------------------------------------------------------------
# 10.  Cleanup (Optional)
# ---------------------------------------------------------------------------

# The AIAgent holds onto httpx connection pools, subprocesses, and browser
# daemons.  Call close() when you're done to release resources.
agent.close()
print("[CLEANUP] Agent closed – resources released.")

# You can also perform a fine-grained release that keeps terminal
# sandboxes alive for the next agent that reuses the same task_id.
# agent.release_clients()   # closes only the LLM client, not subprocesses.

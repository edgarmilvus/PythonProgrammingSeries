
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script.py
# Description: Advanced Integration Script
# ==========================================

#!/usr/bin/env python3
"""
Advanced Integration Script: Persistent Research Assistant with Memory and FTS5.

This script demonstrates how to wire together the Hermes Agent's AIAgent,
MemoryManager, and SessionDB to create a stateful assistant that can save
and recall information across conversations using semantic search and
full-text indexing.

Requirements:
    - Hermes Agent installed (pip install hermes-agent)
    - An API key for your chosen provider (e.g., OpenRouter, Anthropic)
    - Python 3.10+

Usage:
    python advanced_integration.py
"""

import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Any

# Hermes Agent imports
from run_agent import AIAgent
from hermes_state import SessionDB
from hermes_constants import get_hermes_home

# ---------------------------------------------------------------------------
# Configure logging – file-based so we can debug later
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("hermes_integration.log", mode="a"),
    ],
)
logger = logging.getLogger(__name__)


class PersistentResearchAssistant:
    """
    A stateful agent that persists conversations to a SQLite database
    with FTS5 full-text search and uses a memory provider for long-term recall.

    This class demonstrates the core integration pattern:
        1. Initialise AIAgent with a session database and memory manager.
        2. Run a conversation where the agent uses tools (memory, session_search).
        3. Persist every turn to the session DB with FTS5 indexing.
        4. Query the session DB to confirm data is searchable.
    """

    def __init__(
        self,
        model: str = "openai/gpt-4o",
        provider: str = "openrouter",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        max_iterations: int = 30,
        session_db_path: Optional[Path] = None,
    ):
        """
        Initialise the assistant with an AIAgent and a SessionDB.

        Args:
            model: Model identifier (e.g., "openai/gpt-4o").
            provider: Provider name (e.g., "openrouter", "anthropic").
            api_key: API key. If None, reads from environment.
            base_url: Base URL for the API. If None, uses provider default.
            max_iterations: Maximum tool-calling iterations per turn.
            session_db_path: Path to the SQLite database file. Defaults to
                ~/.hermes/state.db.
        """
        self.model = model
        self.provider = provider
        self.api_key = api_key or os.getenv("OPENROUTER_API_KEY") or ""
        self.base_url = base_url or "https://openrouter.ai/api/v1"
        self.max_iterations = max_iterations

        # -------------------------------------------------------------------
        # Step 1: Initialise the session database (SQLite + FTS5)
        # -------------------------------------------------------------------
        self.session_db_path = session_db_path or get_hermes_home() / "state.db"
        logger.info("Initialising session database at %s", self.session_db_path)
        self.session_db = SessionDB(db_path=self.session_db_path)

        # -------------------------------------------------------------------
        # Step 2: Create the AIAgent with memory and session DB
        # -------------------------------------------------------------------
        # We pass the session_db so the agent auto-persists every message.
        # Memory is enabled via the built-in memory tool (MEMORY.md).
        self.agent = AIAgent(
            model=self.model,
            provider=self.provider,
            api_key=self.api_key,
            base_url=self.base_url,
            max_iterations=self.max_iterations,
            session_db=self.session_db,
            # Enable the built-in memory tool so the agent can save/recall facts
            enabled_toolsets=["memory", "session_search"],
            # Quiet mode suppresses tool-by-tool progress (cleaner output)
            quiet_mode=True,
        )
        logger.info(
            "Agent initialised: model=%s provider=%s session_id=%s",
            self.model,
            self.provider,
            self.agent.session_id,
        )

    # -----------------------------------------------------------------------
    # Public interface
    # -----------------------------------------------------------------------

    def run_conversation(self, user_message: str) -> Dict[str, Any]:
        """
        Run a single conversation turn and return the full result.

        This method wraps AIAgent.run_conversation() and adds logging
        and error handling. The result includes the final response,
        message history, and token usage.

        Args:
            user_message: The user's input text.

        Returns:
            A dict with keys: final_response, messages, api_calls, completed,
            total_tokens, estimated_cost_usd.
        """
        logger.info("Starting conversation turn: %s", user_message[:80])
        try:
            result = self.agent.run_conversation(
                user_message=user_message,
                # If you want to inject a system message, pass it here:
                # system_message="You are a helpful research assistant."
            )
            self._log_turn_result(result)
            return result
        except Exception as e:
            logger.error("Conversation turn failed: %s", e, exc_info=True)
            return {
                "final_response": f"Error: {str(e)}",
                "messages": [],
                "api_calls": 0,
                "completed": False,
                "total_tokens": 0,
                "estimated_cost_usd": 0.0,
            }

    def search_sessions(
        self,
        query: str,
        limit: int = 5,
    ) -> List[Dict[str, Any]]:
        """
        Search the session database using FTS5 full-text search.

        This demonstrates the FTS5 deep-dive from Chapter 11: the query
        is sanitised, routed to the trigram table for CJK support, and
        results include snippets and surrounding context.

        Args:
            query: The search string (supports FTS5 syntax: "exact phrase",
                   boolean operators, prefix*).
            limit: Maximum number of results.

        Returns:
            A list of matching messages with session metadata.
        """
        logger.info("Searching sessions for: %s", query)
        try:
            results = self.session_db.search_messages(
                query=query,
                limit=limit,
                # Optionally filter by source or role:
                # source_filter=["cli"],
                # role_filter=["user", "assistant"],
            )
            logger.info("Found %d matching messages", len(results))
            return results
        except Exception as e:
            logger.error("Session search failed: %s", e, exc_info=True)
            return []

    def get_session_summary(self, session_id: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve a full session with all messages for analysis.

        Args:
            session_id: The session ID (e.g., from a search result).

        Returns:
            A dict with session metadata and messages, or None.
        """
        logger.info("Retrieving session: %s", session_id)
        return self.session_db.export_session(session_id)

    # -----------------------------------------------------------------------
    # Internal helpers
    # -----------------------------------------------------------------------

    def _log_turn_result(self, result: Dict[str, Any]) -> None:
        """Log token usage and cost for a completed turn."""
        if not result.get("completed"):
            logger.warning("Turn did not complete successfully.")
        logger.info(
            "Turn result: api_calls=%d completed=%s total_tokens=%d cost=$%.6f",
            result.get("api_calls", 0),
            result.get("completed", False),
            result.get("total_tokens", 0),
            result.get("estimated_cost_usd", 0.0),
        )

    def close(self) -> None:
        """Release agent resources and close the session database."""
        logger.info("Closing assistant resources.")
        try:
            self.agent.close()
        except Exception as e:
            logger.warning("Agent close failed: %s", e)
        try:
            self.session_db.close()
        except Exception as e:
            logger.warning("Session DB close failed: %s", e)


# ---------------------------------------------------------------------------
# Main demonstration
# ---------------------------------------------------------------------------
def main():
    """
    Run a demonstration of the persistent research assistant.

    The demo:
        1. Initialises the assistant.
        2. Runs a conversation where the agent saves a memory entry.
        3. Runs a second conversation that asks the agent to recall that memory.
        4. Searches the session database to confirm the memory was indexed.
        5. Prints the search results and a session summary.
    """
    print("=" * 60)
    print("Persistent Research Assistant Demo")
    print("=" * 60)

    # -------------------------------------------------------------------
    # Step 1: Create the assistant
    # -------------------------------------------------------------------
    assistant = PersistentResearchAssistant(
        model="openai/gpt-4o",
        provider="openrouter",
        max_iterations=20,
    )
    print(f"\nSession ID: {assistant.agent.session_id}")

    # -------------------------------------------------------------------
    # Step 2: First conversation – save a memory
    # -------------------------------------------------------------------
    print("\n--- First Conversation: Saving a Memory ---")
    first_message = (
        "Remember that I prefer Python type hints and always use "
        "`from __future__ import annotations`. Also, my name is Alice."
    )
    result1 = assistant.run_conversation(first_message)
    print(f"Final response: {result1['final_response'][:200]}...")

    # -------------------------------------------------------------------
    # Step 3: Second conversation – recall the memory
    # -------------------------------------------------------------------
    print("\n--- Second Conversation: Recalling the Memory ---")
    second_message = (
        "What do you know about my coding preferences and who am I?"
    )
    result2 = assistant.run_conversation(second_message)
    print(f"Final response: {result2['final_response'][:200]}...")

    # -------------------------------------------------------------------
    # Step 4: Search the session database for the memory
    # -------------------------------------------------------------------
    print("\n--- Searching Session Database (FTS5) ---")
    search_results = assistant.search_sessions(
        query="Alice annotations",
        limit=3,
    )
    for idx, match in enumerate(search_results, 1):
        print(f"\n  Match {idx}:")
        print(f"    Session ID: {match['session_id']}")
        print(f"    Role: {match['role']}")
        print(f"    Snippet: {match.get('snippet', '')[:120]}...")
        # Surrounding context (1 message before and after)
        context = match.get("context", [])
        for ctx_msg in context:
            print(f"    Context [{ctx_msg['role']}]: {ctx_msg['content'][:80]}...")

    # -------------------------------------------------------------------
    # Step 5: Retrieve a full session for inspection
    # -------------------------------------------------------------------
    if search_results:
        session_id = search_results[0]["session_id"]
        print(f"\n--- Full Session: {session_id} ---")
        session = assistant.get_session_summary(session_id)
        if session:
            msg_count = len(session.get("messages", []))
            print(f"  Messages: {msg_count}")
            print(f"  Model: {session.get('model', 'unknown')}")
            print(f"  Started: {session.get('started_at', 'unknown')}")

    # -------------------------------------------------------------------
    # Cleanup
    # -------------------------------------------------------------------
    print("\n--- Cleaning Up ---")
    assistant.close()
    print("Done.")


if __name__ == "__main__":
    main()

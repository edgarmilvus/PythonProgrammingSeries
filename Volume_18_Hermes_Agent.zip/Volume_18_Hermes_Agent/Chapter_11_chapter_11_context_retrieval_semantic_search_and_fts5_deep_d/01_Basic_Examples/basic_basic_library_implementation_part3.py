
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation_part3.py
# Description: Basic Library Implementation
# ==========================================

# From hermes_state.py — _reconcile_columns and _parse_schema_columns

@staticmethod
def _parse_schema_columns(schema_sql: str) -> Dict[str, Dict[str, str]]:
    """Extract expected columns per table from SCHEMA_SQL.
    
    Uses an in-memory SQLite database to parse the SQL — SQLite itself
    handles all syntax (DEFAULT expressions with commas, inline
    REFERENCES, CHECK constraints, etc.) so there are zero regex
    edge cases.
    """
    ref = sqlite3.connect(":memory:")
    try:
        ref.executescript(schema_sql)
        table_columns: Dict[str, Dict[str, str]] = {}
        for (tbl,) in ref.execute(
            "SELECT name FROM sqlite_master "
            "WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        ).fetchall():
            cols: Dict[str, str] = {}
            for row in ref.execute(f'PRAGMA table_info("{tbl}")').fetchall():
                col_name = row[1]
                col_type = row[2] or ""
                notnull = row[3]
                default = row[4]
                pk = row[5]
                parts = [col_type] if col_type else []
                if notnull and not pk:
                    parts.append("NOT NULL")
                if default is not None:
                    parts.append(f"DEFAULT {default}")
                cols[col_name] = " ".join(parts)
            table_columns[tbl] = cols
        return table_columns
    finally:
        ref.close()

def _reconcile_columns(self, cursor: sqlite3.Cursor) -> None:
    """Ensure live tables have every column declared in SCHEMA_SQL."""
    expected = self._parse_schema_columns(SCHEMA_SQL)
    for table_name, declared_cols in expected.items():
        try:
            rows = cursor.execute(f'PRAGMA table_info("{table_name}")').fetchall()
        except sqlite3.OperationalError:
            continue
        live_cols = set()
        for row in rows:
            name = row[1] if isinstance(row, (tuple, list)) else row["name"]
            live_cols.add(name)
        
        for col_name, col_type in declared_cols.items():
            if col_name not in live_cols:
                safe_name = col_name.replace('"', '""')
                try:
                    cursor.execute(
                        f'ALTER TABLE "{table_name}" ADD COLUMN "{safe_name}" {col_type}'
                    )
                except sqlite3.OperationalError as exc:
                    logger.debug(
                        "reconcile %s.%s: %s", table_name, col_name, exc,
                    )

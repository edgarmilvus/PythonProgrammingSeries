
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation_part6.py
# Description: Basic Library Implementation
# ==========================================

# From hermes_state.py — search_messages (abbreviated for focus)

def search_messages(
    self,
    query: str,
    source_filter: List[str] = None,
    exclude_sources: List[str] = None,
    role_filter: List[str] = None,
    limit: int = 20,
    offset: int = 0,
) -> List[Dict[str, Any]]:
    """
    Full-text search across session messages using FTS5.
    
    Supports FTS5 query syntax:
      - Simple keywords: "docker deployment"
      - Phrases: '"exact phrase"'
      - Boolean: "docker OR kubernetes", "python NOT java"
      - Prefix: "deploy*"
    
    Returns matching messages with session metadata, content snippet,
    and surrounding context (1 message before and after the match).
    """
    if not query or not query.strip():
        return []
    
    query = self._sanitize_fts5_query(query)
    if not query:
        return []
    
    # Build WHERE clauses dynamically
    where_clauses = ["messages_fts MATCH ?"]
    params: list = [query]
    
    if source_filter is not None:
        source_placeholders = ",".join("?" for _ in source_filter)
        where_clauses.append(f"s.source IN ({source_placeholders})")
        params.extend(source_filter)
    
    if exclude_sources is not None:
        exclude_placeholders = ",".join("?" for _ in exclude_sources)
        where_clauses.append(f"s.source NOT IN ({exclude_placeholders})")
        params.extend(exclude_sources)
    
    if role_filter:
        role_placeholders = ",".join("?" for _ in role_filter)
        where_clauses.append(f"m.role IN ({role_placeholders})")
        params.extend(role_filter)
    
    where_sql = " AND ".join(where_clauses)
    params.extend([limit, offset])
    
    sql = f"""
        SELECT
            m.id,
            m.session_id,
            m.role,
            snippet(messages_fts, 0, '>>>', '<<<', '...', 40) AS snippet,
            m.content,
            m.timestamp,
            m.tool_name,
            s.source,
            s.model,
            s.started_at AS session_started
        FROM messages_fts
        JOIN messages m ON m.id = messages_fts.rowid
        JOIN sessions s ON s.id = m.session_id
        WHERE {where_sql}
        ORDER BY rank
        LIMIT ? OFFSET ?
    """
    
    # CJK queries bypass the unicode61 FTS5 table
    is_cjk = self._contains_cjk(query)
    if is_cjk:
        raw_query = query.strip('"').strip()
        cjk_count = self._count_cjk(raw_query)
        
        if cjk_count >= 3:
            # Trigram FTS5 path
            tokens = raw_query.split()
            parts = []
            for tok in tokens:
                if tok.upper() in ("AND", "OR", "NOT"):
                    parts.append(tok)
                else:
                    parts.append('"' + tok.replace('"', '""') + '"')
            trigram_query = " ".join(parts)
            # ... build and execute trigram query ...
        else:
            # Short CJK query (1-2 chars) — fall back to LIKE
            escaped = raw_query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            # ... build and execute LIKE query ...
    else:
        # Standard FTS5 path
        with self._lock:
            try:
                cursor = self._conn.execute(sql, params)
            except sqlite3.OperationalError:
                return []
            else:
                matches = [dict(row) for row in cursor.fetchall()]
    
    # Add surrounding context (1 message before + after each match)
    for match in matches:
        try:
            with self._lock:
                ctx_cursor = self._conn.execute(
                    """WITH target AS (
                           SELECT session_id, timestamp, id
                           FROM messages
                           WHERE id = ?
                       )
                       SELECT role, content
                       FROM (
                           SELECT m.id, m.timestamp, m.role, m.content
                           FROM messages m
                           JOIN target t ON t.session_id = m.session_id
                           WHERE (m.timestamp < t.timestamp)
                              OR (m.timestamp = t.timestamp AND m.id < t.id)
                           ORDER BY m.timestamp DESC, m.id DESC
                           LIMIT 1
                       )
                       UNION ALL
                       SELECT role, content
                       FROM messages
                       WHERE id = ?
                       UNION ALL
                       SELECT role, content
                       FROM (
                           SELECT m.id, m.timestamp, m.role, m.content
                           FROM messages m
                           JOIN target t ON t.session_id = m.session_id
                           WHERE (m.timestamp > t.timestamp)
                              OR (m.timestamp = t.timestamp AND m.id > t.id)
                           ORDER BY m.timestamp ASC, m.id ASC
                           LIMIT 1
                       )""",
                    (match["id"], match["id"]),
                )
                context_msgs = []
                for r in ctx_cursor.fetchall():
                    raw = r["content"]
                    decoded = self._decode_content(raw)
                    if isinstance(decoded, list):
                        text_parts = [
                            p.get("text", "") for p in decoded
                            if isinstance(p, dict) and p.get("type") == "text"
                        ]
                        text = " ".join(t for t in text_parts if t).strip()
                        preview = text or "[multimodal content]"
                    elif isinstance(decoded, str):
                        preview = decoded
                    else:
                        preview = ""
                    context_msgs.append(
                        {"role": r["role"], "content": preview[:200]}
                    )
            match["context"] = context_msgs
        except Exception:
            match["context"] = []
    
    # Remove full content from result (snippet is enough)
    for match in matches:
        match.pop("content", None)
    
    return matches

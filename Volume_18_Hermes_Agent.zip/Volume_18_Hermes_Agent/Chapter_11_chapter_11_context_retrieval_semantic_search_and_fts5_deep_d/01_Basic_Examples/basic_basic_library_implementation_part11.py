
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation_part11.py
# Description: Basic Library Implementation
# ==========================================

"""
Complete example: Hybrid retrieval with SessionDB and AIAgent.

This example demonstrates:
1. Creating a SessionDB instance
2. Creating a session and appending messages
3. Searching with FTS5 (Latin text)
4. Searching with trigram FTS5 (CJK text)
5. Searching with LIKE fallback (short CJK queries)
6. Integrating with AIAgent for agent-driven search
"""

import json
import logging
import sys
from pathlib import Path

# Configure logging to see what's happening
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    stream=sys.stderr,
)

# Import the real classes from the Hermes codebase
# In a real deployment, these would be imported from the hermes package
from hermes_state import SessionDB
from run_agent import AIAgent

# ──────────────────────────────────────────────────────────────────────
# Step 1: Initialize the database
# ──────────────────────────────────────────────────────────────────────

# Use a temporary database for this example
db_path = Path("/tmp/hermes_hybrid_example.db")

# Remove any existing database to start fresh
if db_path.exists():
    db_path.unlink()

print("Creating SessionDB...")
db = SessionDB(db_path=db_path)
print(f"  Database created at: {db_path}")
print(f"  WAL mode: enabled")
print(f"  FTS5 tables: messages_fts (unicode61), messages_fts_trigram (trigram)")

# ──────────────────────────────────────────────────────────────────────
# Step 2: Create sessions and append messages
# ──────────────────────────────────────────────────────────────────────

print("\nCreating sessions and appending messages...")

# Session 1: Kubernetes discussion (Latin text)
session_id_1 = db.create_session(
    session_id="k8s-discussion-001",
    source="cli",
    model="anthropic/claude-sonnet-4-20250514",
)

# Append messages about Kubernetes storage
messages_k8s = [
    {
        "role": "user",
        "content": "How do I set up persistent volume claims in Kubernetes?",
    },
    {
        "role": "assistant",
        "content": (
            "To set up Persistent Volume Claims (PVCs) in Kubernetes, you need to:\n\n"
            "1. Create a PersistentVolume (PV) or use dynamic provisioning\n"
            "2. Define a PVC manifest that requests storage\n"
            "3. Reference the PVC in your pod spec\n\n"
            "Here's a basic PVC example:\n"
            "
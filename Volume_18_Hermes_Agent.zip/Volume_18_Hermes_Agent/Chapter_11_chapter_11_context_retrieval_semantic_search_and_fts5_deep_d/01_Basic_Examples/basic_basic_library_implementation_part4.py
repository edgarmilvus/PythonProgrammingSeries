
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation_part4.py
# Description: Basic Library Implementation
# ==========================================

# From hermes_state.py — append_message

def append_message(
    self,
    session_id: str,
    role: str,
    content: str = None,
    tool_name: str = None,
    tool_calls: Any = None,
    tool_call_id: str = None,
    token_count: int = None,
    finish_reason: str = None,
    reasoning: str = None,
    reasoning_content: str = None,
    reasoning_details: Any = None,
    codex_reasoning_items: Any = None,
    codex_message_items: Any = None,
) -> int:
    """
    Append a message to a session. Returns the message row ID.
    
    Also increments the session's message_count (and tool_call_count
    if role is 'tool' or tool_calls is present).
    """
    # Serialize structured fields to JSON before entering the write txn
    reasoning_details_json = (
        json.dumps(reasoning_details) if reasoning_details else None
    )
    codex_items_json = (
        json.dumps(codex_reasoning_items) if codex_reasoning_items else None
    )
    codex_message_items_json = (
        json.dumps(codex_message_items) if codex_message_items else None
    )
    tool_calls_json = json.dumps(tool_calls) if tool_calls else None
    # Multimodal content (list of parts) must be JSON-encoded
    stored_content = self._encode_content(content)
    
    # Pre-compute tool call count
    num_tool_calls = 0
    if tool_calls is not None:
        num_tool_calls = len(tool_calls) if isinstance(tool_calls, list) else 1
    
    def _do(conn):
        cursor = conn.execute(
            """INSERT INTO messages (session_id, role, content, tool_call_id,
               tool_calls, tool_name, timestamp, token_count, finish_reason,
               reasoning, reasoning_content, reasoning_details, codex_reasoning_items,
               codex_message_items)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                session_id,
                role,
                stored_content,
                tool_call_id,
                tool_calls_json,
                tool_name,
                time.time(),
                token_count,
                finish_reason,
                reasoning,
                reasoning_content,
                reasoning_details_json,
                codex_items_json,
                codex_message_items_json,
            ),
        )
        msg_id = cursor.lastrowid
        
        # Update counters
        if num_tool_calls > 0:
            conn.execute(
                """UPDATE sessions SET message_count = message_count + 1,
                   tool_call_count = tool_call_count + ? WHERE id = ?""",
                (num_tool_calls, session_id),
            )
        else:
            conn.execute(
                "UPDATE sessions SET message_count = message_count + 1 WHERE id = ?",
                (session_id,),
            )
        return msg_id
    
    return self._execute_write(_do)

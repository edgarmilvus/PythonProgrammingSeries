
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation_part9.py
# Description: Basic Library Implementation
# ==========================================

# From run_agent.py — _flush_messages_to_session_db

def _flush_messages_to_session_db(self, messages: List[Dict], conversation_history: List[Dict] = None):
    """Persist any un-flushed messages to the SQLite session store.
    
    Uses _last_flushed_db_idx to track which messages have already been
    written, so repeated calls (from multiple exit paths) only write
    truly new messages — preventing the duplicate-write bug (#860).
    """
    if not self._session_db:
        return
    self._apply_persist_user_message_override(messages)
    try:
        if not self._session_db_created:
            self._ensure_db_session()
        start_idx = len(conversation_history) if conversation_history else 0
        flush_from = max(start_idx, self._last_flushed_db_idx)
        for msg in messages[flush_from:]:
            role = msg.get("role", "unknown")
            content = msg.get("content")
            tool_calls_data = None
            if hasattr(msg, "tool_calls") and isinstance(msg.tool_calls, list) and msg.tool_calls:
                tool_calls_data = [
                    {"name": tc.function.name, "arguments": tc.function.arguments}
                    for tc in msg.tool_calls
                ]
            elif isinstance(msg.get("tool_calls"), list):
                tool_calls_data = msg["tool_calls"]
            self._session_db.append_message(
                session_id=self.session_id,
                role=role,
                content=content,
                tool_name=msg.get("tool_name"),
                tool_calls=tool_calls_data,
                tool_call_id=msg.get("tool_call_id"),
                finish_reason=msg.get("finish_reason"),
                reasoning=msg.get("reasoning") if role == "assistant" else None,
                reasoning_content=msg.get("reasoning_content") if role == "assistant" else None,
                reasoning_details=msg.get("reasoning_details") if role == "assistant" else None,
                codex_reasoning_items=msg.get("codex_reasoning_items") if role == "assistant" else None,
                codex_message_items=msg.get("codex_message_items") if role == "assistant" else None,
            )
        self._last_flushed_db_idx = len(messages)
    except Exception as e:
        logger.warning("Session DB append_message failed: %s", e)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import threading
import json
import time
import math
import random
from typing import List, Dict, Any, Optional
from collections import defaultdict
from .memory_provider import MemoryProvider, RetrievalStrategy  # assume existing

# ------------------------------------------------------------------------------
# Strategy Arms
# ------------------------------------------------------------------------------
class StrategyArm:
    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
        self.alpha = 1.0  # Beta prior successes
        self.beta = 1.0   # Beta prior failures
        self.pulls = 0
        self._lock = threading.Lock()

    def sample(self) -> float:
        """Sample from the Beta distribution for Thompson Sampling."""
        return random.betavariate(self.alpha, self.beta)

    def update(self, success: bool, weight: float = 1.0):
        """Update distribution with feedback, optionally downweight old observations."""
        with self._lock:
            if success:
                self.alpha += weight
            else:
                self.beta += weight
            self.pulls += 1

# ------------------------------------------------------------------------------
# LearnedRetrievalProvider
# ------------------------------------------------------------------------------
class LearnedRetrievalProvider(MemoryProvider):
    def __init__(self, child_providers: List[MemoryProvider],
                 config: dict = None,
                 state_persister=None):  # e.g., SessionDB.state_meta
        super().__init__()
        self._children = child_providers
        self._config = config or {}
        self._arms = self._initialize_arms()
        self._lock = threading.Lock()
        self._total_retrievals = 0
        self._state_persister = state_persister
        self._load_state()

    def _initialize_arms(self) -> List[StrategyArm]:
        arms = [
            StrategyArm("keyword", "Pure FTS5 keyword search"),
            StrategyArm("semantic", "Pure vector semantic search"),
            StrategyArm("hybrid_high_kw", "Hybrid with keyword weight 0.7"),
            StrategyArm("hybrid_high_sem", "Hybrid with keyword weight 0.3"),
            StrategyArm("adaptive", "Use QueryClassifier"),
            StrategyArm("recency", "Recency‑biased (2× weight on recent)"),
        ]
        # If config specifies a fixed strategy, only keep that one (exploitation)
        forced = self._config.get('retrieval_strategy', None)
        if forced:
            arms = [arm for arm in arms if arm.name == forced] or arms[:1]
        return arms

    def get_retrieval_strategies(self) -> List[RetrievalStrategy]:
        return [RetrievalStrategy(name=arm.name, description=arm.description) for arm in self._arms]

    def select_arm(self) -> StrategyArm:
        """Thompson Sampling: select arm with highest sampled probability."""
        # Exploration: 10% chance pick random arm
        if random.random() < 0.1:
            return random.choice(self._arms)
        with self._lock:
            samples = {arm: arm.sample() for arm in self._arms}
        best = max(samples, key=samples.get)
        return best

    def prefetch(self, query: str, k: int = 10, context: Dict = None) -> List[Dict]:
        arm = self.select_arm()
        start_time = time.time()

        # Perform retrieval using the selected strategy
        results = self._execute_strategy(arm, query, k, context)
        latency = (time.time() - start_time) * 1000

        # Log analytics (to retrieval_analytics table)
        self._log_retrieval(arm, query, len(results), latency, context)

        # Store the current arm for later feedback
        self._last_arm = arm
        self._last_query = query
        self._last_results = results

        return results

    def _execute_strategy(self, arm: StrategyArm, query: str, k: int, context: Dict) -> List[Dict]:
        # Map arm to actual retrieval call
        if arm.name == "keyword":
            return self._children[0].prefetch(query, k, context)  # assuming built-in provider
        elif arm.name == "semantic":
            return self._children[1].prefetch(query, k, context) if len(self._children) > 1 else []
        elif arm.name == "hybrid_high_kw":
            return self._hybrid_search(query, k, kw_weight=0.7, sem_weight=0.3, context=context)
        elif arm.name == "hybrid_high_sem":
            return self._hybrid_search(query, k, kw_weight=0.3, sem_weight=0.7, context=context)
        elif arm.name == "adaptive":
            profile = self._classifier.classify(query, context)
            return self._hybrid_search(query, k, profile.keyword_weight, profile.semantic_weight, context)
        elif arm.name == "recency":
            # Use semantic search with recently‑biased weighting (example)
            return self._recency_biased_search(query, k, context)
        else:
            return self._children[0].prefetch(query, k, context)

    def _hybrid_search(self, query, k, kw_weight, sem_weight, context):
        # Placeholder: use HybridSearch from exercise 2
        return []

    def on_retrieval_feedback(self, query: str, retrieved: List[Dict[str, Any]],
                              user_engaged: bool, agent_used: bool):
        """Called after each turn to update arm distributions."""
        success = agent_used  # define success as agent referenced the content
        # Decay old observations: downweight previous updates by 0.95 per step
        decay = 0.95
        with self._lock:
            for arm in self._arms:
                arm.alpha *= decay
                arm.beta *= decay
            self._last_arm.update(success)
            self._total_retrievals += 1

        # Periodically persist state and prune old arms
        if self._total_retrievals % 10 == 0:
            self._save_state()

    def get_learning_state(self) -> Dict[str, Any]:
        state = {'arms': {}, 'total_retrievals': self._total_retrievals}
        for arm in self._arms:
            state['arms'][arm.name] = {
                'alpha': arm.alpha, 'beta': arm.beta, 'pulls': arm.pulls
            }
        return state

    def load_learning_state(self, state: Dict[str, Any]) -> None:
        self._total_retrievals = state.get('total_retrievals', 0)
        for arm_name, vals in state.get('arms', {}).items():
            for arm in self._arms:
                if arm.name == arm_name:
                    arm.alpha = vals['alpha']
                    arm.beta = vals['beta']
                    arm.pulls = vals['pulls']
                    break

    def _save_state(self):
        state = self.get_learning_state()
        if self._state_persister:
            self._state_persister.set('learned_retrieval_state', json.dumps(state))

    def _load_state(self):
        if self._state_persister:
            raw = self._state_persister.get('learned_retrieval_state')
            if raw:
                self.load_learning_state(json.loads(raw))

    def reset_learning(self):
        self._arms = self._initialize_arms()
        self._total_retrievals = 0
        self._save_state()

    def _log_retrieval(self, arm: StrategyArm, query: str, num_candidates: int,
                       latency_ms: float, context: Dict):
        # Insert into retrieval_analytics table
        if hasattr(self, '_analytics_conn'):
            self._analytics_conn.execute("""
                INSERT INTO retrieval_analytics
                    (session_id, turn_number, strategy_name, query_hash,
                     num_candidates, num_used, precision_at_5, recall_at_10,
                     latency_ms, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                context.get('session_id', ''),
                context.get('turn_number', 0),
                arm.name,
                hashlib.md5(query.lower().encode()).hexdigest(),
                num_candidates,
                0, 0.0, 0.0,  # filled later after agent usage
                latency_ms,
                time.time()
            ))
            context['_analytics_conn'].commit()

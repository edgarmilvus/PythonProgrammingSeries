
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import sqlite3
import numpy as np
import threading
from typing import List, Optional, Dict, Any, Tuple
from collections import OrderedDict
import hashlib
import time
import json
import logging

logger = logging.getLogger(__name__)

# Attempt to import optional backends
try:
    from sentence_transformers import SentenceTransformer
    _HAS_SENTENCE_TRANSFORMERS = True
except ImportError:
    _HAS_SENTENCE_TRANSFORMERS = False

# ------------------------------------------------------------------------------
# EmbeddingService with caching and batching
# ------------------------------------------------------------------------------
class EmbeddingService:
    """Generates embeddings for text, supporting local (sentence-transformers) and remote (OpenAI) backends."""
    def __init__(self, backend: str = "local", model: str = "all-MiniLM-L6-v2",
                 cache_db_path: str = None, max_batch: int = 20):
        self.backend = backend
        self.model_name = model
        self._local_model = None
        self._remote_client = None  # assume OpenAI client is injected
        self._cache = {}  # in‑memory LRU with TTL
        self._cache_db = None
        if cache_db_path:
            self._init_cache_db(cache_db_path)
        self._batch_lock = threading.Lock()

    def _init_cache_db(self, path: str):
        self._cache_db = sqlite3.connect(path, check_same_thread=False)
        self._cache_db.execute("""
            CREATE TABLE IF NOT EXISTS message_embeddings (
                message_id INTEGER,
                model_name TEXT,
                embedding BLOB,
                created_at REAL,
                PRIMARY KEY (message_id, model_name)
            )
        """)
        self._cache_db.commit()

    def get_embedding(self, text: str) -> List[float]:
        """Return embedding for a single text, checking cache first."""
        # In production, look up in cache database keyed by hash(text) + model_name
        cache_key = hashlib.md5((text + self.model_name).encode()).hexdigest()
        if cache_key in self._cache:
            return self._cache[cache_key]
        if self.backend == "local":
            emb = self._get_local_embedding(text)
        elif self.backend == "remote":
            emb = self._get_remote_embedding(text)
        else:
            raise ValueError("Unknown backend")
        self._cache[cache_key] = emb
        # Optionally persist to SQLite cache
        return emb

    def get_embeddings_batch(self, texts: List[str]) -> List[List[float]]:
        """Batch process multiple texts, respecting rate limits and max_batch."""
        results = []
        with self._batch_lock:
            for i in range(0, len(texts), 20):
                batch = texts[i:i+20]
                if self.backend == "local":
                    embs = self._get_local_embeddings(batch)
                else:
                    # For remote, call with rate limiting (sleep if needed)
                    embs = self._get_remote_embeddings(batch)
                results.extend(embs)
        return results

    def _get_local_embedding(self, text: str) -> List[float]:
        if not _HAS_SENTENCE_TRANSFORMERS:
            raise RuntimeError("sentence-transformers not installed")
        if self._local_model is None:
            self._local_model = SentenceTransformer(self.model_name)
        return self._local_model.encode(text).tolist()

    def _get_local_embeddings(self, texts: List[str]) -> List[List[float]]:
        if not _HAS_SENTENCE_TRANSFORMERS:
            raise RuntimeError("sentence-transformers not installed")
        if self._local_model is None:
            self._local_model = SentenceTransformer(self.model_name)
        return self._local_model.encode(texts).tolist()

    def _get_remote_embedding(self, text: str) -> List[float]:
        # Implementation using OpenAI API client (not shown for brevity)
        # Must handle rate limits (3000 RPM) and fallback to local on failure
        pass

# ------------------------------------------------------------------------------
# Vector index management (extend SessionDB)
# ------------------------------------------------------------------------------
class VectorSessionDB(SessionDB):
    def __init__(self, db_path: str, embedding_service: EmbeddingService, **kwargs):
        super().__init__(db_path, **kwargs)
        self.emb_service = embedding_service
        self._create_vector_table()

    def _create_vector_table(self):
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS message_vectors (
                message_id INTEGER PRIMARY KEY REFERENCES messages(id) ON DELETE CASCADE,
                embedding BLOB,
                model_name TEXT
            )
        """)
        # Triggers for automatic update
        self.conn.executescript("""
            CREATE TRIGGER IF NOT EXISTS vector_insert AFTER INSERT ON messages
            BEGIN
                INSERT OR REPLACE INTO message_vectors (message_id, embedding, model_name)
                VALUES (NEW.id, NULL, 'pending');  -- placeholder; async embedding later
            END;
            CREATE TRIGGER IF NOT EXISTS vector_delete AFTER DELETE ON messages
            BEGIN
                DELETE FROM message_vectors WHERE message_id = OLD.id;
            END;
        """)
        self.conn.commit()

    def rebuild_vector_index(self):
        """Re‑embed all messages and populate message_vectors."""
        cursor = self.conn.execute("SELECT id, content FROM messages")
        batch = []
        batch_ids = []
        for row in cursor:
            batch_ids.append(row[0])
            batch.append(row[1] or '')
            if len(batch) >= 20:
                self._embed_batch(batch_ids, batch)
                batch.clear()
                batch_ids.clear()
        if batch:
            self._embed_batch(batch_ids, batch)
        self.conn.commit()

    def _embed_batch(self, ids: List[int], texts: List[str]):
        embeddings = self.emb_service.get_embeddings_batch(texts)
        for mid, emb in zip(ids, embeddings):
            blob = np.array(emb, dtype=np.float32).tobytes()
            self.conn.execute(
                "INSERT OR REPLACE INTO message_vectors (message_id, embedding, model_name) VALUES (?, ?, ?)",
                (mid, blob, self.emb_service.model_name)
            )

    def search_semantic(
        self,
        query: str,
        k: int = 10,
        session_id: Optional[str] = None,
        role_filter: Optional[List[str]] = None,
        min_similarity: float = 0.5,
    ) -> List[Dict[str, Any]]:
        """Perform cosine similarity search using brute force (or sqlite‑vec if available)."""
        query_emb = self.emb_service.get_embedding(query)
        query_np = np.array(query_emb, dtype=np.float32)

        # Fetch all vectors (for production, use IVF or sqlite‑vec)
        cursor = self.conn.execute("""
            SELECT mv.message_id, mv.embedding, m.*
            FROM message_vectors mv
            JOIN messages m ON mv.message_id = m.id
        """)
        results = []
        for row in cursor:
            mid, emb_blob = row[0], row[1]
            emb = np.frombuffer(emb_blob, dtype=np.float32)
            similarity = self._cosine_similarity(query_np, emb)
            if similarity < min_similarity:
                continue
            result = self._row_to_dict(row[2:])  # adapt as needed
            result['similarity'] = similarity
            result['_rank_score'] = similarity
            results.append(result)

        # Apply optional filters after search
        if session_id:
            results = [r for r in results if str(r.get('session_id')) == session_id]
        if role_filter:
            results = [r for r in results if r.get('role') in role_filter]

        # Sort by similarity descending and return top k
        results.sort(key=lambda x: x['similarity'], reverse=True)
        return results[:k]

    @staticmethod
    def _cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
        dot = np.dot(a, b)
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return float(dot / (norm_a * norm_b))

# ------------------------------------------------------------------------------
# HybridSearch with Reciprocal Rank Fusion
# ------------------------------------------------------------------------------
class HybridSearch:
    def __init__(self, session_db: VectorSessionDB, keyword_weight: float = 0.5,
                 semantic_weight: float = 0.5, k_rrf: int = 60):
        self.db = session_db
        self.kw = keyword_weight
        self.sw = semantic_weight
        self.k = k_rrf

    def search(self, query: str, top_n: int = 10, **filters) -> List[Dict[str, Any]]:
        # Get keyword results
        kw_results = self.db.search_messages(query, k=top_n * 2, **filters)
        # Get semantic results
        sem_results = self.db.search_semantic(query, k=top_n * 2, **filters)

        # Reciprocal Rank Fusion
        rrf_scores = {}
        # Assign ranks: 1‑based
        for rank, result in enumerate(kw_results, start=1):
            mid = result['id']
            rrf_scores[mid] = self.kw * (1 / (self.k + rank))
        for rank, result in enumerate(sem_results, start=1):
            mid = result['id']
            rrf_scores[mid] = rrf_scores.get(mid, 0) + self.sw * (1 / (self.k + rank))

        # Merge results, keep the one with higher RRF
        merged = {}
        for result in kw_results + sem_results:
            mid = result['id']
            if mid not in merged or rrf_scores[mid] > merged[mid].get('_rrf_score', -1):
                result['_rrf_score'] = rrf_scores[mid]
                merged[mid] = result

        # Sort by RRF score descending
        sorted_results = sorted(merged.values(), key=lambda x: x['_rrf_score'], reverse=True)
        return sorted_results[:top_n]

# ------------------------------------------------------------------------------
# Modify MemoryManager to enable vector search
# ------------------------------------------------------------------------------
class MemoryManagerWithVector(MemoryManager):
    def __init__(self, session_db: SessionDB, vector_search_enabled: bool = False,
                 embedding_service: EmbeddingService = None, config: dict = None, **kwargs):
        self._vector_enabled = vector_search_enabled
        self._hybrid = None
        if vector_search_enabled:
            # Ensure session_db is VectorSessionDB
            if not isinstance(session_db, VectorSessionDB):
                raise TypeError("SessionDB must be VectorSessionDB for vector search")
            self._hybrid = HybridSearch(session_db,
                                        keyword_weight=config.get('hybrid_weight_keyword', 0.4),
                                        semantic_weight=config.get('hybrid_weight_semantic', 0.6))
        super().__init__(session_db, **kwargs)

    def prefetch(self, context: str, k: int = 10) -> List[Dict]:
        if self._vector_enabled:
            return self._hybrid.search(context, top_n=k,
                                       session_id=self._current_session_id if hasattr(self, '_current_session_id') else None)
        else:
            return super().prefetch(context, k)

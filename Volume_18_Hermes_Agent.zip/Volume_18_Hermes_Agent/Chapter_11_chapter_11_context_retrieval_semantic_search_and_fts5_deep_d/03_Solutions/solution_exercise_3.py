
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import re
import time
import json
import hashlib
from collections import Counter, defaultdict
from typing import List, Dict, Optional, Tuple
import math

# ------------------------------------------------------------------------------
# Query Classifier and RetrievalProfile
# ------------------------------------------------------------------------------
class RetrievalProfile:
    def __init__(self, keyword_weight: float = 0.5, semantic_weight: float = 0.5,
                 fts5_config: dict = None, semantic_config: dict = None,
                 fallback_strategy: str = "both"):
        self.keyword_weight = keyword_weight
        self.semantic_weight = semantic_weight
        self.fts5_config = fts5_config or {}
        self.semantic_config = semantic_config or {}
        self.fallback_strategy = fallback_strategy

class QueryClassifier:
    def __init__(self, session_db, feedback_table='retrieval_feedback'):
        self.db = session_db
        self.feedback_table = feedback_table
        self._tfidf_counter = Counter()
        self._doc_freq = defaultdict(int)  # track document frequencies for terms

    def classify(self, query: str, context: Dict = None) -> RetrievalProfile:
        """Analyze query and produce a RetrievalProfile."""
        profile = RetrievalProfile()

        # 1. Query length
        tokens = query.split()
        n = len(tokens)
        if n <= 2:
            profile.keyword_weight = 0.8
            profile.semantic_weight = 0.2
        elif n >= 6:
            profile.keyword_weight = 0.3
            profile.semantic_weight = 0.7
        else:
            profile.keyword_weight = 0.5
            profile.semantic_weight = 0.5

        # 2. Presence of code identifiers
        code_pattern = re.compile(r'[a-zA-Z_]\w*([._-]\w+)+')
        if code_pattern.search(query):
            profile.fts5_config['tokenizer'] = 'code_preserving'

        # 3. Question words → semantic bias
        if re.match(r'^(what|how|why|when|where|which|who|explain)', query.lower()):
            profile.semantic_weight = min(1.0, profile.semantic_weight + 0.2)
            profile.keyword_weight = 1.0 - profile.semantic_weight

        # 4. Named entities (capitalized proper nouns) → boost keyword
        capital_words = re.findall(r'\b[A-Z][a-z]+\b', query)
        if len(capital_words) >= 2:
            profile.keyword_weight = min(1.0, profile.keyword_weight + 0.2)
            profile.semantic_weight = 1.0 - profile.keyword_weight

        # 5. Query specificity via TF‑IDF
        rare_terms = 0
        for token in tokens:
            token_lower = token.lower()
            df = self._doc_freq.get(token_lower, 0)
            if df < 5:  # rare in corpus
                rare_terms += 1
        if rare_terms > 0.5 * n:
            profile.keyword_weight = min(1.0, profile.keyword_weight + 0.3)
            profile.semantic_weight = 1.0 - profile.keyword_weight
        elif rare_terms == 0 and n > 3:
            profile.semantic_weight = min(1.0, profile.semantic_weight + 0.2)
            profile.keyword_weight = 1.0 - profile.semantic_weight

        # 6. Override based on historical feedback (if any)
        hist_profile = self._get_historical_profile(query)
        if hist_profile:
            # Blend: 80% current rule‑based, 20% historical
            profile.keyword_weight = 0.8 * profile.keyword_weight + 0.2 * hist_profile['keyword_weight']
            profile.semantic_weight = 1.0 - profile.keyword_weight

        # Normalise
        total = profile.keyword_weight + profile.semantic_weight
        profile.keyword_weight /= total
        profile.semantic_weight /= total

        # Fallback strategy
        if profile.keyword_weight > 0.7:
            profile.fallback_strategy = "keyword_only"
        elif profile.semantic_weight > 0.7:
            profile.fallback_strategy = "semantic_only"
        else:
            profile.fallback_strategy = "both"

        return profile

    def _get_historical_profile(self, query: str) -> Optional[Dict]:
        """Retrieve previously successful weight configuration for similar queries."""
        query_hash = hashlib.md5(query.lower().encode()).hexdigest()
        # Look up in retrieval_feedback table for entries with same hash and user_engaged=True
        row = self.db.conn.execute(f"""
            SELECT strategy_used FROM {self.feedback_table}
            WHERE query_hash = ? AND user_engaged = 1
            ORDER BY created_at DESC LIMIT 1
        """, (query_hash,)).fetchone()
        if row:
            # Parse strategy_used to extract weights
            try:
                return json.loads(row[0])  # store as JSON dict
            except:
                pass
        return None

    def record_feedback(self, query: str, retrieved_ids: List[int],
                        user_engaged: bool, agent_used: bool,
                        strategy_used: str, turn_id: str):
        """Insert feedback into the retrieval_feedback table."""
        self.db.conn.execute(f"""
            INSERT INTO {self.feedback_table}
                (query_hash, query_text, strategy_used, retrieved_message_ids,
                 user_engaged, agent_used, turn_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            hashlib.md5(query.lower().encode()).hexdigest(),
            query,
            strategy_used,
            json.dumps(retrieved_ids),
            user_engaged,
            agent_used,
            turn_id,
            time.time()
        ))
        self.db.conn.commit()

# ------------------------------------------------------------------------------
# Multi‑Stage Retrieval Pipeline (simplified)
# ------------------------------------------------------------------------------
class AdaptiveHybridPipeline:
    def __init__(self, session_db, classifier: QueryClassifier,
                 hybrid_search: HybridSearch, stages_config: dict = None):
        self.db = session_db
        self.classifier = classifier
        self.hybrid = hybrid_search
        self.stages = stages_config or {
            'stage1_keyword': True, 'stage2_semantic': True, 'stage3_fusion': True,
            'stage4_rerank': True, 'stage5_filter': True, 'stage6_diversify': True,
            'stage7_format': True
        }

    def search(self, query: str, k: int = 10, context: Dict = None) -> List[Dict]:
        profile = self.classifier.classify(query, context)
        stage_output = {}

        # Stage 1: Fast keyword search
        if self.stages['stage1_keyword']:
            kw_results = self.db.search_messages(query, k=50, **profile.fts5_config)
            stage_output['stage1'] = kw_results
        else:
            stage_output['stage1'] = []

        # Stage 2: Semantic search
        if self.stages['stage2_semantic'] and profile.semantic_weight > 0:
            sem_results = self.db.search_semantic(query, k=50, **profile.semantic_config)
            stage_output['stage2'] = sem_results
        else:
            stage_output['stage2'] = []

        # Stage 3: RRF fusion
        if self.stages['stage3_fusion']:
            fused = self.hybrid.rrf_merge(stage_output['stage1'], stage_output['stage2'],
                                          kw_weight=profile.keyword_weight,
                                          sem_weight=profile.semantic_weight)
            stage_output['stage3'] = fused[:20]
        else:
            stage_output['stage3'] = stage_output['stage1'] + stage_output['stage2']

        # Stage 4: Rerank using query classifier's custom weight
        if self.stages['stage4_rerank']:
            # Already implicitly done by RRF weights; could reorder by a learned model
            pass

        # Stage 5: Filter (session, role)
        if self.stages['stage5_filter']:
            filtered = [r for r in stage_output['stage3'] if
                        (context.get('session_id') is None or r['session_id'] == context['session_id']) and
                        (context.get('role_filter') is None or r['role'] in context['role_filter'])]
            stage_output['stage5'] = filtered
        else:
            stage_output['stage5'] = stage_output['stage3']

        # Stage 6: Diversify (max 3 per session)
        if self.stages['stage6_diversify']:
            seen_sessions = Counter()
            diversified = []
            for r in stage_output['stage5']:
                sid = r['session_id']
                if seen_sessions[sid] < 3:
                    diversified.append(r)
                    seen_sessions[sid] += 1
            stage_output['stage6'] = diversified[:k]
        else:
            stage_output['stage6'] = stage_output['stage5'][:k]

        # Stage 7: Format with relevance annotations
        if self.stages['stage7_format']:
            formatted = []
            for r in stage_output['stage6']:
                formatted.append({
                    **r,
                    '_relevance': r.get('_rrf_score', r.get('similarity', r.get('_rank_score', 0))),
                    '_source': self._label_source(r)
                })
            return self._build_context_block(formatted)
        return stage_output['stage6']

    def _label_source(self, result: Dict) -> str:
        if '_rrf_score' in result:
            return 'hybrid'
        elif 'similarity' in result:
            return 'semantic'
        elif '_rank_score' in result:
            return 'keyword'
        return 'unknown'


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import re
import sqlite3
from typing import List, Dict, Any, Optional, Tuple
from .session_db import SessionDB, logger  # assuming existing module

# ------------------------------------------------------------------------------
# 1. Custom FTS5 Tokenizer (CJK and code‑preserving)
# ------------------------------------------------------------------------------
class CodePreservingTokenizer:
    """FTS5 tokenizer that preserves common code identifiers and version strings
    as single tokens, yet also emits the individual sub‑tokens for partial matching.
    """
    def __init__(self, min_length: int = 1, case_sensitive: bool = False):
        self._min_length = min_length
        self._case_sensitive = case_sensitive

    # Tokenizer interface required by fts5_tokenizer()
    def xCreate(self, pAux, argc, argv):
        # pAux is unused; argv may contain options like "minlen=2"
        opts = {}
        if argc:
            for arg in argv:
                if '=' in arg:
                    key, val = arg.split('=', 1)
                    opts[key.strip()] = val.strip()
        return CodePreservingTokenizer(
            min_length=int(opts.get('minlen', '1')),
            case_sensitive=opts.get('casesensitive', '0') == '1'
        )

    def xDelete(self, pTokenizer):
        pass

    def xTokenize(self, pTokenizer, pText, nText, xToken):
        text = sqlite3.fts5.ffi.string(pText, nText).decode('utf-8')
        if not self._case_sensitive:
            text = text.lower()

        # Patterns to preserve as full tokens
        patterns = [
            (r'[a-zA-Z_]\w*\.\w+(\.\w+)*', 'dotted'),      # module.sub.func
            (r'[a-zA-Z]\w*-\w+(?:-\w+)+', 'hyphenated'),    # state-of-the-art
            (r'[A-Z_][A-Z_0-9]+(?:_[A-Z_0-9]+)+', 'underscored'), # MY_CONSTANT_VALUE
            (r'v?\d+\.\d+\.\d+(?:\.\d+)*', 'version'),       # 2.0.1, v1.2.3
            (r'(?:/\w+)+\w*', 'path'),                        # /usr/local/bin/python3
            (r'[a-zA-Z_]\w*', 'identifier'),                  # regular word
        ]

        # Find all matches and emit tokens
        pos = 0
        while pos < len(text):
            best_match = None
            best_end = pos
            for pat, tag in patterns:
                m = re.match(pat, text[pos:])
                if m and m.end() > best_end - pos:
                    best_match = (m.group(), tag, m.end())
            if best_match:
                token, tag, end = best_match
                start = pos
                # Emit the full token if it meets min length
                if len(token) >= self._min_length:
                    xToken(pTokenizer, start, start + end, start, end)
                # Emit sub‑tokens for dotted/hyphenated/underscored/version
                if tag in ('dotted', 'hyphenated', 'underscored', 'version'):
                    parts = re.split(r'[._-]', token)
                    sub_pos = start
                    for part in parts:
                        if len(part) >= self._min_length:
                            xToken(pTokenizer, sub_pos, sub_pos + len(part), start, end)
                        sub_pos += len(part) + 1  # skip delimiter
                # For paths, emit directory parts
                elif tag == 'path':
                    parts = token.split('/')
                    sub_pos = start
                    for part in parts:
                        if part and len(part) >= self._min_length:
                            xToken(pTokenizer, sub_pos, sub_pos + len(part), start, end)
                        sub_pos += len(part) + 1
                pos += end
            else:
                # Skip single characters (whitespace, punctuation)
                pos += 1

# Register tokenizer with SQLite
def register_tokenizer(db: sqlite3.Connection, name: str = 'code_preserving'):
    from sqlite3.fts5 import fts5_tokenizer
    fts5_tokenizer(name, CodePreservingTokenizer)

# ------------------------------------------------------------------------------
# 2. Custom Ranking Function (recency, tool calls, proximity)
# ------------------------------------------------------------------------------
def register_custom_rank(db: sqlite3.Connection):
    """Register a user‑defined function `custom_rank` for use in FTS5 ORDER BY."""
    def custom_rank(
        match_info: bytes,
        n_Phrase: int,
        n_col: int,
        a_match: bytes,
        recency_score: float,
        session_length_log: float,
        has_tool_call: int,
        proximity_score: float
    ) -> float:
        """
        Custom ranking formula:
            score = BM25_base * (1 + 0.5*recency) * (1 - 0.1*session_len_log) * (1 + 0.5*has_tool_call) * (1 + 0.2*proximity)
        """
        # Parse match_info (simplified; real implementation would use fts5 API)
        bm25 = float.from_bytes(match_info[:8], 'little')  # placeholder
        score = bm25 * (1 + 0.5 * recency_score) * max(0.5, 1 - 0.1 * session_length_log)
        if has_tool_call:
            score *= 1.5
        score *= (1 + 0.2 * proximity_score)
        return score

    # The function expects a match_info blob; we also pass metadata columns
    # For simplicity, here we register a function that wraps custom_rank.
    db.create_function("custom_rank", 7, custom_rank, deterministic=True)

# ------------------------------------------------------------------------------
# 3. Extend SessionDB with tokenizer config and ranking_mode
# ------------------------------------------------------------------------------
class ExtendedSessionDB(SessionDB):
    def __init__(self, db_path: str, tokenizer_config: Optional[Dict[str, Any]] = None, **kwargs):
        super().__init__(db_path, **kwargs)
        self._tokenizer_config = tokenizer_config or {}
        self._register_extensions()

    def _register_extensions(self):
        register_tokenizer(self.conn, 'code_preserving')
        register_custom_rank(self.conn)

    def search_messages(
        self,
        query: str,
        k: int = 10,
        session_id: Optional[str] = None,
        role_filter: Optional[List[str]] = None,
        ranking_mode: str = "bm25",
        **kwargs
    ) -> List[Dict[str, Any]]:
        # Select tokenizer per table
        fts_table = self._get_fts_table(query, tokenizer_config=self._tokenizer_config)
        # Build the SQL according to ranking_mode
        if ranking_mode == "custom":
            # Use custom_rank function, requires passing metadata as columns
            sql = f"""
                SELECT m.*, fts.rank as _rank_score
                FROM {fts_table} fts
                JOIN messages m ON fts.rowid = m.id
                WHERE fts MATCH ?
                ORDER BY custom_rank(fts.rank, 
                    (julianday('now') - julianday(m.timestamp)) / 7.0,  -- recency
                    LOG((SELECT COUNT(*) FROM messages WHERE session_id = m.session_id) + 1), -- session length
                    CASE WHEN m.tool_calls IS NOT NULL THEN 1 ELSE 0 END,  -- has tool call
                ) DESC
                LIMIT ?
            """
        elif ranking_mode == "hybrid":
            # Blend BM25 (rank) and custom_rank
            sql = f"""
                SELECT m.*, 
                FROM {fts_table} fts JOIN messages m ... 
                WHERE ... ORDER BY _rank_score DESC LIMIT ?
            """
        else:  # bm25 default
            sql = self._build_bm25_search_sql(fts_table)  # original method

        # Execute with parameters
        params = [query, k]
        if session_id:
            sql += " AND m.session_id = ?"
            params.append(session_id)
        if role_filter:
            placeholders = ','.join('?' * len(role_filter))
            sql += f" AND m.role IN ({placeholders})"
            params.extend(role_filter)

        rows = self.conn.execute(sql, params).fetchall()
        return [self._row_to_dict(row) for row in rows]

    def _get_fts_table(self, query: str, tokenizer_config: dict) -> str:
        # Use tokenizer config to decide which FTS table to query
        # If the query contains code patterns or user requested code tokenizer
        if tokenizer_config.get("messages_fts", {}).get("tokenizer") == "code_preserving":
            return "messages_fts_code"  # assume we created such table
        # fallback
        return "messages_fts"

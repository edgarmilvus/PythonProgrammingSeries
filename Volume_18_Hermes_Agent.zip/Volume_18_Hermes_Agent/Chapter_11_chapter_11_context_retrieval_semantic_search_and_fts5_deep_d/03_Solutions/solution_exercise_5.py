
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import sqlite3
import numpy as np
import time
import random
import string
import json
import hashlib
from typing import List, Dict, Any
from collections import OrderedDict
import csv
import os

# ------------------------------------------------------------------------------
# 1. Synthetic Data Generator
# ------------------------------------------------------------------------------
def generate_synthetic_db(path: str, num_sessions: int = 1000,
                          messages_per_session: int = 10,
                          avg_message_length: int = 200,
                          vocabulary: str = "mixed"):
    """Create a realistic test database."""
    conn = sqlite3.connect(path)
    conn.execute("PRAGMA journal_mode=WAL")
    # Create schema (simplified)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            id TEXT PRIMARY KEY,
            title TEXT,
            created_at REAL,
            updated_at REAL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT REFERENCES sessions(id),
            role TEXT,
            content TEXT,
            timestamp REAL,
            tool_calls TEXT,
            token_count INTEGER
        )
    """)
    # FTS indexes (omitted for brevity)
    # Generate data
    vocab_pool = sample_vocab(vocabulary)
    for s in range(num_sessions):
        session_id = f"session_{s:05d}"
        conn.execute("INSERT INTO sessions (id, title, created_at, updated_at) VALUES (?, ?, ?, ?)",
                     (session_id, f"Session {s}", time.time(), time.time()))
        n_msgs = max(1, int(np.random.exponential(messages_per_session)))
        for m in range(n_msgs):
            content = generate_message_content(vocab_pool, avg_message_length)
            role = random.choice(['user', 'assistant', 'system'])
            timestamp = time.time() - random.randint(0, 86400 * 30)
            tool_calls = '{"calls": [{"function": "test"}]}' if random.random() < 0.1 else None
            conn.execute("""
                INSERT INTO messages (session_id, role, content, timestamp, tool_calls)
                VALUES (?, ?, ?, ?, ?)
            """, (session_id, role, content, timestamp, tool_calls))
    conn.commit()
    conn.close()

# ------------------------------------------------------------------------------
# 2. FTS5 Optimizations
# ------------------------------------------------------------------------------
def optimize_fts5(conn: sqlite3.Connection):
    """Apply contentless mode, prefix indexes, and incremental rebuild logic."""
    # Example: create a contentless FTS table
    conn.execute("""
        CREATE VIRTUAL TABLE IF NOT EXISTS messages_fts_contentless USING fts5(
            content,
            content='messages',
            content_rowid='id',
            tokenize='unicode61',
            prefix='2 3 4'
        )
    """)
    # Sync triggers (using external content)
    conn.executescript("""
        CREATE TRIGGER IF NOT EXISTS fts_ai AFTER INSERT ON messages BEGIN
            INSERT INTO messages_fts_contentless(rowid, content) VALUES (new.id, new.content);
        END;
        CREATE TRIGGER IF NOT EXISTS fts_ad AFTER DELETE ON messages BEGIN
            INSERT INTO messages_fts_contentless(messages_fts_contentless, rowid, content) VALUES('delete', old.id, old.content);
        END;
        CREATE TRIGGER IF NOT EXISTS fts_au AFTER UPDATE ON messages BEGIN
            INSERT INTO messages_fts_contentless(messages_fts_contentless, rowid, content) VALUES('delete', old.id, old.content);
            INSERT INTO messages_fts_contentless(rowid, content) VALUES (new.id, new.content);
        END;
    """)
    # Prefix indexes (2,3,4) speed up prefix queries
    conn.execute("ALTER TABLE messages_fts_contentless ADD prefix=2,3,4")
    conn.commit()

# ------------------------------------------------------------------------------
# 3. Vector Search Optimizations (IVF)
# ------------------------------------------------------------------------------
class IVFIndex:
    """Simple Inverted File Index with k‑means clustering (pure Python)."""
    def __init__(self, n_centroids: int = 256, n_probes: int = 10):
        self.n_centroids = n_centroids
        self.n_probes = n_probes
        self.centroids = None
        self.labels = None
        self.inverted_lists = {}  # centroid_id -> list of (vector, id)
        self._trained = False

    def train(self, vectors: np.ndarray, ids: List[int]):
        """Train k‑means on a representative sample of vectors."""
        from sklearn.cluster import KMeans  # optional dependency; can implement simple k‑means
        sample_size = min(10000, len(vectors))
        indices = np.random.choice(len(vectors), sample_size, replace=False)
        sample = vectors[indices]
        kmeans = KMeans(n_clusters=self.n_centroids, random_state=42, n_init=1).fit(sample)
        self.centroids = kmeans.cluster_centers_
        # Assign all vectors to nearest centroid
        self._assign_vectors(vectors, ids)
        self._trained = True

    def _assign_vectors(self, vectors, ids):
        distances = np.linalg.norm(vectors[:, np.newaxis] - self.centroids, axis=2)
        self.labels = np.argmin(distances, axis=1)
        for i, label in enumerate(self.labels):
            self.inverted_lists.setdefault(int(label), []).append((vectors[i], ids[i]))

    def search(self, query_vec: np.ndarray, k: int = 10) -> List[Tuple[int, float]]:
        """Return top k (id, similarity) pairs."""
        if not self._trained:
            raise RuntimeError("Index not trained")
        # Find nearest centroids
        cent_dist = np.linalg.norm(self.centroids - query_vec, axis=1)
        nearest_centroids = np.argsort(cent_dist)[:self.n_probes]
        candidates = []
        for cid in nearest_centroids:
            for vec, vid in self.inverted_lists.get(int(cid), []):
                sim = float(np.dot(query_vec, vec))  # cosine assuming normalized
                candidates.append((vid, sim))
        # Sort by similarity descending
        candidates.sort(key=lambda x: x[1], reverse=True)
        return candidates[:k]

# ------------------------------------------------------------------------------
# 4. Multi‑Level Cache
# ------------------------------------------------------------------------------
class RetrievalCache:
    """LRU cache with SQLite persistence."""
    def __init__(self, conn: sqlite3.Connection, max_entries: int = 1000, ttl: float = 60.0):
        self.conn = conn
        self.max_entries = max_entries
        self.ttl = ttl
        self._lru = OrderedDict()
        self._lock = threading.Lock()
        # Create L2 table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS retrieval_cache (
                cache_key TEXT PRIMARY KEY,
                query_text TEXT,
                strategy_name TEXT,
                results TEXT,  -- JSON
                created_at REAL,
                expires_at REAL
            )
        """)

    def get(self, cache_key: str) -> Optional[List[Dict]]:
        with self._lock:
            # Check L1
            if cache_key in self._lru:
                entry = self._lru[cache_key]
                if time.time() < entry['expires_at']:
                    self._lru.move_to_end(cache_key)
                    return entry['results']
                else:
                    del self._lru[cache_key]
            # Check L2
            row = self.conn.execute(
                "SELECT results, expires_at FROM retrieval_cache WHERE cache_key = ?",
                (cache_key,)
            ).fetchone()
            if row and time.time() < row[1]:
                results = json.loads(row[0])
                self._add_to_lru(cache_key, results, row[1])
                return results
        return None

    def set(self, cache_key: str, query: str, strategy: str, results: List[Dict],
            expires_at: float = None):
        if expires_at is None:
            expires_at = time.time() + self.ttl
        with self._lock:
            self._add_to_lru(cache_key, results, expires_at)
            # Persist to L2
            self.conn.execute("""
                INSERT OR REPLACE INTO retrieval_cache (cache_key, query_text, strategy_name, results, created_at, expires_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (cache_key, query, strategy, json.dumps([r['id'] for r in results]),
                  time.time(), expires_at))
            self.conn.commit()

    def _add_to_lru(self, key, results, expires_at):
        if len(self._lru) >= self.max_entries:
            self._lru.popitem(last=False)
        self._lru[key] = {'results': results, 'expires_at': expires_at}

    def invalidate_on_message_change(self, session_id: str):
        """Invalidate cache entries related to a session (executed on insert/update/delete)."""
        # For simplicity, clear entire cache; production can be smarter.
        with self._lock:
            self._lru.clear()
            self.conn.execute("DELETE FROM retrieval_cache")
            self.conn.commit()

# ------------------------------------------------------------------------------
# 5. Benchmarking Suite
# ------------------------------------------------------------------------------
class RetrievalBenchmark:
    def __init__(self, db_path: str, config: dict):
        self.db_path = db_path
        self.config = config
        self.results = {}

    def run(self):
        self._prepare_db()
        self._run_latency_tests()
        self._run_accuracy_tests()
        self._run_concurrency_tests()
        self._report()

    def _run_latency_tests(self):
        queries = self._load_queries('exact', 'phrase', 'code', 'semantic', 'mixed')
        for query_type, qlist in queries.items():
            latencies = []
            for query in qlist:
                t0 = time.perf_counter()
                results = self._retrieve(query, k=10)
                lat = (time.perf_counter() - t0) * 1000
                latencies.append(lat)
            self.results[f'{query_type}_latency'] = {
                'p50': np.percentile(latencies, 50),
                'p95': np.percentile(latencies, 95),
                'p99': np.percentile(latencies, 99),
                'samples': len(latencies)
            }

    def _run_accuracy_tests(self):
        # Use ground truth annotation (omitted for brevity)
        pass

    def _run_concurrency_tests(self):
        from concurrent.futures import ThreadPoolExecutor
        for num_threads in [1, 5, 10, 20]:
            with ThreadPoolExecutor(max_workers=num_threads) as executor:
                futures = [executor.submit(self._retrieve, "deployment", k=10) for _ in range(100)]
                times = [f.result()[1] for f in futures]  # (results, latency)
            self.results[f'concurrency_{num_threads}'] = {
                'mean': np.mean(times), 'p95': np.percentile(times, 95)
            }

    def _report(self):
        report_path = f"benchmark_{int(time.time())}.json"
        with open(report_path, 'w') as f:
            json.dump(self.results, f, indent=2)
        print(f"Benchmark report saved to {report_path}")
        # Also generate Markdown summary (omitted)

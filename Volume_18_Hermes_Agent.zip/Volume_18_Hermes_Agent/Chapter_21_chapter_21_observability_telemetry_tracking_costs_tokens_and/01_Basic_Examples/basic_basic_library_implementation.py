
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation.py
# Description: Basic Library Implementation
# ==========================================

# telemetry.py — Basic observability library for Hermes Agent
from __future__ import annotations

import time
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, Callable, Optional

# Real Hermes imports — no placeholders
from agent.usage_pricing import (
    CanonicalUsage,
    CostResult,
    estimate_usage_cost,
    normalize_usage,
    format_duration_compact,
    format_token_count_compact,
)
from agent.model_metadata import resolve_billing_route

logger = logging.getLogger(__name__)


@dataclass
class TelemetryRecord:
    """A single record of an LLM call's telemetry."""
    model_name: str
    provider: str
    base_url: str
    usage: CanonicalUsage
    cost: CostResult
    latency_seconds: float
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    request_id: str = ""

    def summary(self) -> str:
        """Human-readable one-liner for logs."""
        return (
            f"[{self.timestamp.isoformat()}] {self.model_name} | "
            f"tokens: {format_token_count_compact(self.usage.total_tokens)} | "
            f"cost: {self.cost.label} | "
            f"latency: {format_duration_compact(self.latency_seconds)}"
        )


class TelemetryCollector:
    """Wraps an LLM API call to record usage, cost, and latency.

    Usage:
        collector = TelemetryCollector()
        with collector.record(model="claude-sonnet-4-6", provider="anthropic") as ctx:
            response = await some_api_call(...)
            ctx.set_response(response)
        # After the block, ctx.record contains the telemetry.
        print(ctx.record.summary())
    """

    def __init__(self, api_key: Optional[str] = None):
        self._api_key = api_key
        self._records: list[TelemetryRecord] = []

    @property
    def records(self) -> tuple[TelemetryRecord, ...]:
        return tuple(self._records)

    def record(
        self,
        model: str,
        provider: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> "_RecordContext":
        return self._RecordContext(
            collector=self,
            model=model,
            provider=provider,
            base_url=base_url,
            api_key=self._api_key,
        )

    class _RecordContext:
        def __init__(
            self,
            collector: "TelemetryCollector",
            model: str,
            provider: Optional[str],
            base_url: Optional[str],
            api_key: Optional[str],
        ):
            self._collector = collector
            self._model = model
            self._provider = provider
            self._base_url = base_url
            self._api_key = api_key
            self._start_time: Optional[float] = None
            self._response_usage: Any = None
            self.record: Optional[TelemetryRecord] = None

        def __enter__(self):
            self._start_time = time.monotonic()
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            if exc_type is not None:
                logger.error("API call failed: %s", exc_val)
                return  # Do not suppress exception

            elapsed = time.monotonic() - self._start_time
            if self._response_usage is None:
                logger.warning("No usage data recorded; skipping cost estimation.")
                return

            # Step 1: Normalise raw usage into canonical buckets
            usage = normalize_usage(
                self._response_usage,
                provider=self._provider,
                api_mode=self._provider,  # e.g., "anthropic" triggers Anthropic path
            )

            # Step 2: Estimate cost using the Hermes pricing engine
            cost = estimate_usage_cost(
                model_name=self._model,
                usage=usage,
                provider=self._provider,
                base_url=self._base_url,
                api_key=self._api_key,
            )

            # Step 3: Build the record
            self.record = TelemetryRecord(
                model_name=self._model,
                provider=self._provider or "unknown",
                base_url=self._base_url or "",
                usage=usage,
                cost=cost,
                latency_seconds=elapsed,
            )
            self._collector._records.append(self.record)
            logger.info(self.record.summary())

        def set_response(self, response: Any) -> None:
            """Store the raw API response object to extract usage."""
            # The response is expected to have a .usage attribute
            # (OpenAI, Anthropic, OpenRouter, etc.)
            self._response_usage = getattr(response, "usage", None)
            if self._response_usage is None:
                logger.warning("Response has no 'usage' attribute; cost will be unknown.")

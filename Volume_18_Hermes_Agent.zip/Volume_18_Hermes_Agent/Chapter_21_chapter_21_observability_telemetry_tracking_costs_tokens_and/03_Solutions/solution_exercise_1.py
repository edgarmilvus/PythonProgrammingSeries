
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import time
import logging
from decimal import Decimal
from datetime import datetime, timezone
from typing import Optional

# Assume these exist in the agent package
from agent.usage_pricing import (
    normalize_usage,
    estimate_usage_cost,
    has_known_pricing,
    format_token_count_compact,
    CanonicalUsage,
    CostResult
)
from agent.model_metadata import get_model_info
from agent.persistent_memory import SessionDB  # simplified

logger = logging.getLogger(__name__)

class LearningLoopTelemetry:
    """Collects and persists telemetry for a closed learning loop."""
    
    def __init__(self, session_db: SessionDB, session_id: str):
        self.db = session_db
        self.session_id = session_id
        self.total_cost = Decimal('0.0')
        self.total_input_tokens = 0
        self.total_output_tokens = 0
        self.total_latency = 0.0
        self.iterations = 0
    
    def log_api_call(self, model: str, usage_raw: dict, latency_sec: float) -> None:
        """Normalize, estimate cost, and log telemetry for one API call."""
        # 1. Normalize usage
        provider = "openai"
        api_mode = "openai_chat"  # adjust based on actual endpoint
        canonical: CanonicalUsage = normalize_usage(
            usage_raw, provider=provider, api_mode=api_mode
        )
        
        # 2. Estimate cost (with error handling)
        cost_result: Optional[CostResult] = None
        warning = False
        if has_known_pricing(model):
            cost_result = estimate_usage_cost(model, canonical)
            if cost_result.status == "unknown":
                warning = True
                logger.warning(f"Unknown pricing for model {model}, logging with warning.")
        else:
            warning = True
            logger.warning(f"No pricing data for model {model}, cannot estimate cost.")
        
        # 3. Build structured log entry
        log_entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "session_id": self.session_id,
            "model": model,
            "canonical_usage": {
                "input_tokens": canonical.input_tokens,
                "output_tokens": canonical.output_tokens,
                "cache_read_tokens": canonical.cache_read_tokens,
                "cache_write_tokens": canonical.cache_write_tokens,
            },
            "amount_usd": float(cost_result.amount_usd) if cost_result else 0.0,
            "latency_sec": latency_sec,
            "input_tokens": canonical.input_tokens,  # excludes cache
            "warning": warning
        }
        
        # 4. Persist to memory
        self.db.log_event(
            event_type="telemetry_api_call",
            data=log_entry,
            session_id=self.session_id
        )
        
        # 5. Update aggregates
        if cost_result:
            self.total_cost += cost_result.amount_usd
        self.total_input_tokens += canonical.input_tokens
        self.total_output_tokens += canonical.output_tokens
        self.total_latency += latency_sec
        self.iterations += 1
    
    def print_summary(self):
        """Print aggregated report after loop."""
        avg_latency = self.total_latency / self.iterations if self.iterations else 0.0
        print(f"=== Learning Loop Summary ===")
        print(f"Total iterations: {self.iterations}")
        print(f"Total cost: ${self.total_cost:.4f}")
        print(f"Total input tokens: {format_token_count_compact(self.total_input_tokens)}")
        print(f"Total output tokens: {format_token_count_compact(self.total_output_tokens)}")
        print(f"Average latency: {avg_latency:.3f}s")

# Example usage inside the learning loop:
def run_learning_loop(agent, session_db: SessionDB, session_id: str, num_iterations: int = 10):
    telemetry = LearningLoopTelemetry(session_db, session_id)
    for i in range(num_iterations):
        start = time.time()
        # ... actual LLM call that returns response.usage ...
        response = agent.call_llm(prompt="improve prompt")  # dummy
        latency = time.time() - start
        telemetry.log_api_call(
            model=response.model,
            usage_raw=response.usage,
            latency_sec=latency
        )
    telemetry.print_summary()

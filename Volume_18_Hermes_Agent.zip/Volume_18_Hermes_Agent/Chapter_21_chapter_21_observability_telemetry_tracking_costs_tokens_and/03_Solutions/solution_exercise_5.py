
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import asyncio
import time
import logging
from decimal import Decimal
from typing import Optional

# Assume these exist
from agent.usage_pricing import (
    normalize_usage, estimate_usage_cost, get_pricing_entry,
    format_token_count_compact, CanonicalUsage, CostResult
)
from agent.persistent_memory import SessionDB
from agent.model_metadata import get_model_info

logger = logging.getLogger(__name__)

class StreamingTelemetry:
    """Handles telemetry for a streaming async agent."""
    
    def __init__(self, db: SessionDB, session_id: str, budget_tracker: 'BudgetTracker'):
        self.db = db
        self.session_id = session_id
        self.budget_tracker = budget_tracker
        self.live_cost_estimate = Decimal('0.0')
        self.live_token_count = 0
        self._stream_task: Optional[asyncio.Task] = None
    
    async def start_live_cost_display(self, model: str, interval: float = 0.1):
        """Background task to print live estimated cost every 100ms."""
        # Get pricing per token for live estimate
        pricing_entry = get_pricing_entry(model)
        if not pricing_entry:
            logger.warning("Cannot get pricing for live display")
            return
        # Convert to cost per token (micro-dollars)
        output_cost_per_token = pricing_entry.output_cost_per_million / 1_000_000
        
        while True:
            await asyncio.sleep(interval)
            # Rough estimate: assume output tokens are the only variable
            live_cost = self.live_token_count * output_cost_per_token
            print(f"\rLive cost estimate: ${live_cost:.6f} (tokens: {self.live_token_count})", end="")
    
    async def stream_with_telemetry(self, stream_coro, model: str, prompt: str):
        """Wrap streaming with telemetry logging and budget enforcement."""
        # Check budget before starting
        if self.budget_tracker.current_total >= self.budget_tracker.max_budget * Decimal('0.9'):
            print("Warning: 90% of session budget consumed.")
        if self.budget_tracker.current_total >= self.budget_tracker.max_budget:
            print("Budget exhausted. Refusing new prompt.")
            self._print_final_summary()
            return
        
        start_time = time.time()
        self.live_token_count = 0
        partial_output = ""
        
        # Start live cost display background task
        display_task = asyncio.create_task(self.start_live_cost_display(model))
        
        try:
            # Stream loop
            async for chunk in stream_coro:
                if chunk.choices[0].delta.content:
                    token_text = chunk.choices[0].delta.content
                    partial_output += token_text
                    # Approximate token count: characters / 4
                    self.live_token_count = len(partial_output) // 4
                # Yield chunk to user (if needed)
                yield chunk
        except (asyncio.CancelledError, asyncio.TimeoutError) as e:
            # Network interruption - log error event with partial data
            duration = time.time() - start_time
            self._log_error_event(model, partial_output, duration, str(e))
            raise  # Re-raise after logging
        finally:
            display_task.cancel()
            try:
                await display_task
            except asyncio.CancelledError:
                pass
        
        # After stream completes, get final usage from response
        # (Assume stream_coro is an async generator that has a final response object)
        # In practice, the stream object may have a `.response` attribute.
        # For this solution we assume we can retrieve usage from the stream's final state.
        # Simplified: we'll use a placeholder.
        final_usage_raw = {"prompt_tokens": 100, "completion_tokens": 50, "cache_read_tokens": 0}
        canonical = normalize_usage(final_usage_raw, provider="openai", api_mode="openai_chat")
        cost_result = estimate_usage_cost(model, canonical)
        
        # Log full telemetry event
        latency = time.time() - start_time
        self._log_telemetry_event(model, canonical, cost_result, latency)
        
        # Update budget tracker
        if not self.budget_tracker.check_and_add(cost_result):
            print("Budget exceeded after this call. Shutting down.")
            self._log_alert("budget_exceeded", latency)
            asyncio.get_event_loop().stop()
    
    def _log_telemetry_event(self, model: str, usage: CanonicalUsage, cost: CostResult, latency: float):
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "session_id": self.session_id,
            "model": model,
            "canonical_usage": {
                "input_tokens": usage.input_tokens,
                "output_tokens": usage.output_tokens,
                "cache_read_tokens": usage.cache_read_tokens,
                "cache_write_tokens": usage.cache_write_tokens,
            },
            "amount_usd": float(cost.amount_usd),
            "latency_sec": latency,
            "input_tokens": usage.input_tokens,
        }
        self.db.log_event("telemetry_api_call", entry, self.session_id)
    
    def _log_error_event(self, model: str, partial_output: str, duration: float, error: str):
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "session_id": self.session_id,
            "model": model,
            "partial_output_tokens": len(partial_output) // 4,
            "duration_sec": duration,
            "error": error,
            "event_type": "telemetry_stream_error"
        }
        self.db.log_event("telemetry_stream_error", entry, self.session_id)
    
    def _log_alert(self, reason: str, latency: float):
        entry = {
            "reason": reason,
            "latency_sec": latency,
            "session_id": self.session_id,
            "final_cumulative_cost": str(self.budget_tracker.current_total)
        }
        self.db.log_event("telemetry_alert", entry, self.session_id)
    
    def _print_final_summary(self):
        print(f"Session {self.session_id} final cost: ${self.budget_tracker.current_total:.4f}")

# Example usage in an async streaming agent:
async def main():
    db = SessionDB("telemetry.db")
    session_id = "stream-session-1"
    budget = BudgetTracker(max_budget_usd=Decimal('5.00'))
    telemetry = StreamingTelemetry(db, session_id, budget)
    
    model = "gpt-4o"
    stream_coro = agent.stream_chat(prompt="Hello")  # async generator
    async for chunk in telemetry.stream_with_telemetry(stream_coro, model, "Hello"):
        # Process chunk (e.g., print to user)
        print(chunk.choices[0].delta.content, end="")

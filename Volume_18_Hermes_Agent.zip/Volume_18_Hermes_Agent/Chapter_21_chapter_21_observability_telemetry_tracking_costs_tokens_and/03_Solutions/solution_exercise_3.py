
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
import sys
import statistics
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Any
from collections import defaultdict

# Assume these exist
from agent.persistent_memory import SessionDB
from agent.usage_pricing import format_token_count_compact, format_duration_compact

def query_telemetry(db: SessionDB, start: datetime, end: datetime) -> List[Dict]:
    """Return all telemetry events within time range."""
    events = db.query_events(
        event_type="telemetry_api_call",
        start_time=start,
        end_time=end
    )
    return events

def aggregate_by_model(logs: List[Dict]) -> Dict[str, Dict]:
    """Aggregate telemetry by model."""
    model_data = defaultdict(lambda: {
        "requests": 0,
        "input_tokens": 0,
        "output_tokens": 0,
        "cache_read": 0,
        "cache_write": 0,
        "total_cost": 0.0,
        "latencies": []
    })
    for entry in logs:
        model = entry["model"]
        usage = entry["canonical_usage"]
        data = model_data[model]
        data["requests"] += 1
        data["input_tokens"] += usage["input_tokens"]
        data["output_tokens"] += usage["output_tokens"]
        data["cache_read"] += usage.get("cache_read_tokens", 0)
        data["cache_write"] += usage.get("cache_write_tokens", 0)
        data["total_cost"] += entry["amount_usd"]
        data["latencies"].append(entry["latency_sec"])
    return dict(model_data)

def detect_latency_anomalies(logs: List[Dict]) -> None:
    """Print sessions where latency > 2 stddev above mean for that model."""
    # Build per-model latency lists
    model_latencies = defaultdict(list)
    for entry in logs:
        model_latencies[entry["model"]].append(entry["latency_sec"])
    
    # Compute mean and stddev per model
    model_stats = {}
    for model, lats in model_latencies.items():
        if len(lats) >= 2:
            mean = statistics.mean(lats)
            stdev = statistics.stdev(lats)
            model_stats[model] = (mean, stdev)
    
    print("\n=== Latency Anomalies ===")
    for entry in logs:
        model = entry["model"]
        if model in model_stats:
            mean, stdev = model_stats[model]
            threshold = mean + 2 * stdev
            if entry["latency_sec"] > threshold:
                print(f"Session {entry['session_id']} at {entry['timestamp']}: "
                      f"latency {entry['latency_sec']:.3f}s (threshold {threshold:.3f}s)")

def detect_cost_spike(logs: List[Dict]) -> None:
    """Print sessions where total cost > 3x average session cost for same model."""
    # Group by session_id and model
    session_model_cost = defaultdict(lambda: defaultdict(float))
    for entry in logs:
        key = (entry["session_id"], entry["model"])
        session_model_cost[key] += entry["amount_usd"]
    
    # Compute average cost per model across sessions
    model_total_cost = defaultdict(float)
    model_session_count = defaultdict(int)
    for (session, model), cost in session_model_cost.items():
        model_total_cost[model] += cost
        model_session_count[model] += 1
    model_avg_cost = {m: model_total_cost[m]/c for m,c in model_session_count.items() if c>0}
    
    print("\n=== Cost Spikes ===")
    for (session, model), cost in session_model_cost.items():
        avg = model_avg_cost.get(model, 0)
        if avg > 0 and cost > 3 * avg:
            print(f"Session {session} (model {model}): total cost ${cost:.4f} "
                  f"(3x avg ${avg:.4f})")

def generate_report(logs: List[Dict], date_str: str) -> None:
    """Write aggregated report to file."""
    model_data = aggregate_by_model(logs)
    report_lines = []
    report_lines.append(f"Telemetry Report for {date_str}")
    report_lines.append(f"Generated at {datetime.now(timezone.utc).isoformat()}")
    report_lines.append("")
    report_lines.append("Aggregated by Model:")
    report_lines.append(f"{'Model':<20} {'Requests':<10} {'Input Tokens':<20} "
                        f"{'Output Tokens':<20} {'Cost (USD)':<12} {'Avg Latency':<12} {'P99 Latency':<12}")
    for model, data in sorted(model_data.items()):
        avg_lat = statistics.mean(data["latencies"]) if data["latencies"] else 0
        p99_lat = sorted(data["latencies"])[int(len(data["latencies"])*0.99)] if data["latencies"] else 0
        report_lines.append(
            f"{model:<20} {data['requests']:<10} "
            f"{format_token_count_compact(data['input_tokens']):<20} "
            f"{format_token_count_compact(data['output_tokens']):<20} "
            f"{data['total_cost']:<12.4f} "
            f"{format_duration_compact(avg_lat):<12} "
            f"{format_duration_compact(p99_lat):<12}"
        )
    report_lines.append("")
    report_lines.append("Anomalies:")
    # We can capture output of detect functions by redirecting print or returning strings
    # For simplicity, we'll just note that anomalies are printed to stdout.
    report_lines.append("(See stdout for anomaly details)")
    
    filename = f"telemetry_report_{date_str}.txt"
    with open(filename, "w") as f:
        f.write("\n".join(report_lines))
    print(f"Report saved to {filename}")

if __name__ == "__main__":
    # Example usage
    db_path = "telemetry_analytics.db"
    db = SessionDB(db_path)
    yesterday = datetime.now(timezone.utc) - timedelta(days=1)
    start = yesterday.replace(hour=0, minute=0, second=0, microsecond=0)
    end = start + timedelta(days=1)
    
    logs = query_telemetry(db, start, end)
    if not logs:
        print("No telemetry events found.")
        sys.exit(0)
    
    detect_latency_anomalies(logs)
    detect_cost_spike(logs)
    generate_report(logs, start.strftime("%Y%m%d"))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os
import sys
import asyncio
import logging
from decimal import Decimal
from typing import Optional

# Assume these exist
from agent.usage_pricing import CostResult
from agent.persistent_memory import SessionDB

logger = logging.getLogger(__name__)

class BudgetTracker:
    """Tracks cumulative cost and alerts when budget exceeded."""
    
    def __init__(self, max_budget_usd: Optional[Decimal] = None):
        # Read from environment or default
        env_budget = os.environ.get("HERMES_MAX_BUDGET_USD")
        if env_budget:
            self.max_budget = Decimal(env_budget)
        elif max_budget_usd is not None:
            self.max_budget = max_budget_usd
        else:
            self.max_budget = Decimal('10.00')  # default $10
        self.current_total = Decimal('0.0')
    
    def check_and_add(self, cost: CostResult) -> bool:
        """Add cost and return True if under budget, else False."""
        self.current_total += cost.amount_usd
        if self.current_total > self.max_budget:
            logger.critical(
                f"Budget exceeded: ${self.current_total:.4f} > ${self.max_budget:.4f}"
            )
            return False
        return True

class LatencyMonitor:
    """Monitors single API call latency and triggers timeout."""
    
    def __init__(self, max_latency_sec: Optional[float] = None):
        env_latency = os.environ.get("HERMES_MAX_LATENCY_SEC")
        if env_latency:
            self.max_latency = float(env_latency)
        elif max_latency_sec is not None:
            self.max_latency = max_latency_sec
        else:
            self.max_latency = 30.0  # default 30 seconds
        self.session_db: Optional[SessionDB] = None
        self.session_id: Optional[str] = None
    
    def set_session(self, db: SessionDB, session_id: str):
        self.session_db = db
        self.session_id = session_id
    
    async def call_with_timeout(self, coro, timeout: Optional[float] = None):
        """Wrap an async LLM call with timeout."""
        timeout = timeout or self.max_latency
        try:
            result = await asyncio.wait_for(coro, timeout=timeout)
            return result
        except asyncio.TimeoutError:
            logger.critical(f"LLM call timed out after {timeout}s")
            self._log_alert(latency=timeout, reason="latency_exceeded")
            sys.exit(3)  # exit code for latency exceeded
    
    def _log_alert(self, latency: float, reason: str):
        """Log alert event to persistent memory."""
        if self.session_db and self.session_id:
            self.session_db.log_event(
                event_type="telemetry_alert",
                data={
                    "reason": reason,
                    "latency_sec": latency,
                    "session_id": self.session_id,
                    "final_cumulative_cost": str(self.budget_tracker.current_total)
                    if hasattr(self, 'budget_tracker') else "N/A"
                },
                session_id=self.session_id
            )

# Integration in async loop
async def async_agent_loop(agent, session_db: SessionDB, session_id: str):
    budget_tracker = BudgetTracker()
    latency_monitor = LatencyMonitor()
    latency_monitor.set_session(session_db, session_id)
    # Attach budget tracker to monitor for logging
    latency_monitor.budget_tracker = budget_tracker
    
    while True:
        # ... prepare prompt ...
        llm_coro = agent.call_llm_async(prompt=prompt)  # returns response with usage
        
        try:
            response = await latency_monitor.call_with_timeout(llm_coro)
        except SystemExit as e:
            # Flush telemetry and exit with appropriate code
            session_db.flush()
            sys.exit(e.code)
        
        # After successful call, get cost from telemetry (Exercise 1)
        cost_result = estimate_usage_cost(response.model, normalize_usage(...))
        if not budget_tracker.check_and_add(cost_result):
            # Budget exceeded
            latency_monitor._log_alert(latency=0, reason="budget_exceeded")
            session_db.flush()
            sys.exit(2)  # exit code for budget exceeded
        
        # Continue loop...

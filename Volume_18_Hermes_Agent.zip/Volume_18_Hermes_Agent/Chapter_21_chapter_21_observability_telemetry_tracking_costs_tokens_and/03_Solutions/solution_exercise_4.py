
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from decimal import Decimal
from typing import Dict, Optional, Any
from dataclasses import dataclass

# Assume these exist
from agent.usage_pricing import CanonicalUsage, CostResult, PricingEntry, _ONE_MILLION

# Pre-computed pricing table with integer micro-dollar per token values
@dataclass
class FastPricing:
    input_cost_per_token_micro: int   # micro-dollars per token
    output_cost_per_token_micro: int
    cache_read_cost_per_token_micro: int = 0
    cache_write_cost_per_token_micro: int = 0

def build_fast_pricing(known_pricing: Dict[str, PricingEntry]) -> Dict[str, FastPricing]:
    """Convert PricingEntry (per million tokens) to integer micro-dollars per token."""
    fast = {}
    for model, entry in known_pricing.items():
        fast[model] = FastPricing(
            input_cost_per_token_micro=int(entry.input_cost_per_million * 1_000_000 / _ONE_MILLION),
            output_cost_per_token_micro=int(entry.output_cost_per_million * 1_000_000 / _ONE_MILLION),
            cache_read_cost_per_token_micro=int((entry.cache_read_cost_per_million or 0) * 1_000_000 / _ONE_MILLION),
            cache_write_cost_per_token_micro=int((entry.cache_write_cost_per_million or 0) * 1_000_000 / _ONE_MILLION),
        )
    return fast

class CostAccumulator:
    """Mutable accumulator for in-memory aggregation of cost."""
    def __init__(self):
        self.total_micro_usd = 0
        self.total_input_tokens = 0
        self.total_output_tokens = 0
        self.total_cache_read = 0
        self.total_cache_write = 0
        self.call_count = 0
    
    def add(self, model: str, usage: CanonicalUsage, fast_pricing: Dict[str, FastPricing]):
        if model not in fast_pricing:
            raise KeyError(f"Model {model} not in known_pricing table")
        pricing = fast_pricing[model]
        self.total_micro_usd += (
            usage.input_tokens * pricing.input_cost_per_token_micro +
            usage.output_tokens * pricing.output_cost_per_token_micro +
            usage.cache_read_tokens * pricing.cache_read_cost_per_token_micro +
            usage.cache_write_tokens * pricing.cache_write_cost_per_token_micro
        )
        self.total_input_tokens += usage.input_tokens
        self.total_output_tokens += usage.output_tokens
        self.total_cache_read += usage.cache_read_tokens
        self.total_cache_write += usage.cache_write_tokens
        self.call_count += 1
    
    def finalize(self) -> CostResult:
        """Convert accumulator to a single CostResult."""
        amount_usd = Decimal(self.total_micro_usd) / Decimal(1_000_000)
        return CostResult(
            amount_usd=amount_usd,
            status="estimated",
            model="aggregated"
        )

def estimate_usage_cost_fast(
    model_name: str,
    usage: CanonicalUsage,
    *,
    known_pricing: Dict[str, FastPricing],
    accumulator: Optional[CostAccumulator] = None
) -> CostResult:
    """High-speed cost estimation using pre-computed integer pricing.
    
    If accumulator is provided, it updates the accumulator and returns None.
    Otherwise returns a CostResult for a single call.
    """
    if accumulator is not None:
        accumulator.add(model_name, usage, known_pricing)
        return None  # caller must finalize later
    
    if model_name not in known_pricing:
        raise KeyError(f"Model {model_name} not in known_pricing")
    pricing = known_pricing[model_name]
    total_micro = (
        usage.input_tokens * pricing.input_cost_per_token_micro +
        usage.output_tokens * pricing.output_cost_per_token_micro +
        usage.cache_read_tokens * pricing.cache_read_cost_per_token_micro +
        usage.cache_write_tokens * pricing.cache_write_cost_per_token_micro
    )
    amount_usd = Decimal(total_micro) / Decimal(1_000_000)
    return CostResult(amount_usd=amount_usd, status="estimated", model=model_name)

# Unit test (conceptual)
def test_fast_vs_standard():
    from agent.usage_pricing import estimate_usage_cost, _OFFICIAL_DOCS_PRICING
    fast_pricing = build_fast_pricing(_OFFICIAL_DOCS_PRICING)
    usage = CanonicalUsage(input_tokens=100, output_tokens=50, cache_read_tokens=10, cache_write_tokens=0)
    model = "gpt-4o"
    # Standard
    std_result = estimate_usage_cost(model, usage)
    # Fast
    fast_result = estimate_usage_cost_fast(model, usage, known_pricing=fast_pricing)
    assert abs(std_result.amount_usd - fast_result.amount_usd) < Decimal('1e-10')
    assert fast_result.status == "estimated"
    print("Test passed")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script.py
# Description: Advanced Integration Script
# ==========================================

#!/usr/bin/env python3
"""
telemetry_agent.py - Hermes Agent with built-in cost, token, and latency observability.

This script wraps the Hermes AIAgent with a telemetry layer that:
- Captures per-call latency, token breakdown, and estimated cost.
- Logs telemetry to persistent memory for audit and debugging.
- Enforces budget and latency thresholds, triggering fallback actions.
- Supports streaming and async generation for low-latency UX.
"""

import asyncio
import time
import logging
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, AsyncGenerator, Callable, Dict, List, Optional, Tuple
from dataclasses import dataclass, field

# Hermes Agent core
from run_agent import AIAgent

# Hermes observability modules (from the repository)
from agent.usage_pricing import (
    CanonicalUsage,
    estimate_usage_cost,
    format_token_count_compact,
    format_duration_compact,
    CostResult,
)
from agent.model_metadata import fetch_endpoint_model_metadata

# For HTTP calls (used by the agent internally, but we also use for telemetry)
import aiohttp

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Telemetry data structures
# ---------------------------------------------------------------------------

@dataclass
class CallTelemetry:
    """Stores telemetry for a single LLM call."""
    call_id: str
    model: str
    provider: str
    start_time: float  # Unix timestamp
    end_time: float
    latency_seconds: float
    usage: CanonicalUsage
    cost: CostResult
    input_tokens_formatted: str
    output_tokens_formatted: str
    total_tokens_formatted: str
    cost_label: str
    status: str  # "success", "error", "timeout"
    error_message: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "call_id": self.call_id,
            "model": self.model,
            "provider": self.provider,
            "timestamp": datetime.fromtimestamp(self.start_time, tz=timezone.utc).isoformat(),
            "latency_seconds": self.latency_seconds,
            "input_tokens": self.usage.input_tokens,
            "output_tokens": self.usage.output_tokens,
            "cache_read_tokens": self.usage.cache_read_tokens,
            "cache_write_tokens": self.usage.cache_write_tokens,
            "reasoning_tokens": self.usage.reasoning_tokens,
            "total_tokens": self.usage.total_tokens,
            "cost_usd": float(self.cost.amount_usd) if self.cost.amount_usd else 0.0,
            "cost_status": self.cost.status,
            "cost_source": self.cost.source,
            "input_tokens_formatted": self.input_tokens_formatted,
            "output_tokens_formatted": self.output_tokens_formatted,
            "total_tokens_formatted": self.total_tokens_formatted,
            "cost_label": self.cost_label,
            "status": self.status,
            "error": self.error_message,
        }


# ---------------------------------------------------------------------------
# Telemetry collector – accumulates metrics and enforces thresholds
# ---------------------------------------------------------------------------

@dataclass
class TelemetryConfig:
    """Configuration for telemetry thresholds and actions."""
    max_cost_per_call: Decimal = Decimal("0.10")   # Alert if single call > $0.10
    max_latency_seconds: float = 30.0              # Alert if latency > 30s
    max_total_tokens_per_call: int = 100_000       # Alert if > 100k tokens
    budget_daily_usd: Decimal = Decimal("5.00")    # Daily budget cap
    alert_callback: Optional[Callable[[str], None]] = None  # Called on alert

    def check_and_alert(self, telemetry: CallTelemetry, daily_cost: Decimal) -> None:
        """Check thresholds and invoke callback if any exceeded."""
        alerts = []
        if telemetry.cost.amount_usd and telemetry.cost.amount_usd > self.max_cost_per_call:
            alerts.append(f"Cost per call ${telemetry.cost.amount_usd:.4f} exceeds ${self.max_cost_per_call:.2f}")
        if telemetry.latency_seconds > self.max_latency_seconds:
            alerts.append(f"Latency {telemetry.latency_seconds:.1f}s exceeds {self.max_latency_seconds}s")
        if telemetry.usage.total_tokens > self.max_total_tokens_per_call:
            alerts.append(f"Total tokens {telemetry.usage.total_tokens:,} exceeds {self.max_total_tokens_per_call:,}")
        if daily_cost > self.budget_daily_usd:
            alerts.append(f"Daily cost ${daily_cost:.2f} exceeds budget ${self.budget_daily_usd:.2f}")
        if alerts and self.alert_callback:
            for msg in alerts:
                self.alert_callback(msg)


class TelemetryCollector:
    """
    Collects telemetry from LLM calls and stores them in Hermes persistent memory.
    Also enforces thresholds and logs aggregated metrics.
    """

    def __init__(self, agent: AIAgent, config: TelemetryConfig):
        self.agent = agent
        self.config = config
        self.calls: List[CallTelemetry] = []
        self.daily_cost: Decimal = Decimal("0.00")
        self._last_reset_date = datetime.now(timezone.utc).date()

    async def record_call(self, telemetry: CallTelemetry) -> None:
        """Store telemetry and update daily cost."""
        self.calls.append(telemetry)
        if telemetry.cost.amount_usd:
            self.daily_cost += telemetry.cost.amount_usd

        # Reset daily cost if date changed
        today = datetime.now(timezone.utc).date()
        if today != self._last_reset_date:
            self.daily_cost = Decimal("0.00")
            self._last_reset_date = today

        # Persist to Hermes memory (using agent's memory API)
        await self._persist_telemetry(telemetry)

        # Check thresholds
        self.config.check_and_alert(telemetry, self.daily_cost)

    async def _persist_telemetry(self, telemetry: CallTelemetry) -> None:
        """Write telemetry to agent's persistent memory for later analysis."""
        # Hermes Agent supports structured memory via memory.add() or similar.
        # We'll use the agent's memory interface (hypothetical but based on repo patterns)
        memory_entry = {
            "type": "telemetry",
            "data": telemetry.to_dict(),
            "timestamp": datetime.fromtimestamp(telemetry.start_time, tz=timezone.utc).isoformat(),
        }
        # Assuming agent.memory.add() is async and accepts dict
        await self.agent.memory.add(memory_entry)
        logger.debug(f"Persisted telemetry for call {telemetry.call_id}")

    def get_aggregate_stats(self) -> Dict[str, Any]:
        """Compute aggregate metrics over all recorded calls."""
        if not self.calls:
            return {}
        total_cost = sum((c.cost.amount_usd or Decimal("0.00") for c in self.calls), Decimal("0.00"))
        total_tokens = sum(c.usage.total_tokens for c in self.calls)
        avg_latency = sum(c.latency_seconds for c in self.calls) / len(self.calls)
        return {
            "total_calls": len(self.calls),
            "total_cost_usd": float(total_cost),
            "total_tokens": total_tokens,
            "avg_latency_seconds": avg_latency,
            "max_latency_seconds": max(c.latency_seconds for c in self.calls),
            "min_latency_seconds": min(c.latency_seconds for c in self.calls),
        }


# ---------------------------------------------------------------------------
# Telemetry wrapper for AIAgent – intercepts LLM calls
# ---------------------------------------------------------------------------

class TelemetryAIAgent:
    """
    Wraps an AIAgent to add telemetry on every LLM interaction.
    Supports both synchronous and async/streaming calls.
    """

    def __init__(self, agent: AIAgent, collector: TelemetryCollector):
        self._agent = agent
        self._collector = collector
        self._call_counter = 0

    # ----------------------------------------------------------
    # Sync call (blocking) – for simple non-streaming use
    # ----------------------------------------------------------
    def run(self, prompt: str, **kwargs) -> str:
        """Execute a synchronous LLM call with telemetry."""
        call_id = f"call-{self._call_counter}-{int(time.time())}"
        self._call_counter += 1
        start = time.time()
        error_msg = ""
        status = "success"
        usage = None
        response = None

        try:
            # The underlying agent's run() returns a Response object with usage info
            response = self._agent.run(prompt, **kwargs)
            # Extract usage from response (assuming response.usage is CanonicalUsage)
            usage = response.usage if hasattr(response, 'usage') else CanonicalUsage()
        except Exception as e:
            logger.exception(f"LLM call {call_id} failed")
            error_msg = str(e)
            status = "error"
            usage = CanonicalUsage()  # empty usage on error

        end = time.time()
        latency = end - start

        # Estimate cost using Hermes pricing module
        cost = estimate_usage_cost(
            model_name=kwargs.get("model", self._agent.model),
            usage=usage,
            provider=kwargs.get("provider", self._agent.provider),
            base_url=kwargs.get("base_url", self._agent.base_url),
            api_key=kwargs.get("api_key", self._agent.api_key),
        )

        telemetry = CallTelemetry(
            call_id=call_id,
            model=kwargs.get("model", self._agent.model),
            provider=kwargs.get("provider", self._agent.provider),
            start_time=start,
            end_time=end,
            latency_seconds=latency,
            usage=usage,
            cost=cost,
            input_tokens_formatted=format_token_count_compact(usage.input_tokens),
            output_tokens_formatted=format_token_count_compact(usage.output_tokens),
            total_tokens_formatted=format_token_count_compact(usage.total_tokens),
            cost_label=cost.label,
            status=status,
            error_message=error_msg,
        )

        # Schedule recording (fire-and-forget in sync context)
        asyncio.create_task(self._collector.record_call(telemetry))

        # Return the response text (or empty on error)
        return response.text if response else ""

    # ----------------------------------------------------------
    # Async streaming call – for low-latency UX
    # ----------------------------------------------------------
    async def stream(self, prompt: str, **kwargs) -> AsyncGenerator[str, None]:
        """
        Stream tokens from the LLM while collecting telemetry.
        Yields tokens as they arrive, then finalizes telemetry.
        """
        call_id = f"call-{self._call_counter}-{int(time.time())}"
        self._call_counter += 1
        start = time.time()
        error_msg = ""
        status = "success"
        usage = None
        collected_text = []

        try:
            # Assume agent.stream() returns an async generator of strings
            async for token in self._agent.stream(prompt, **kwargs):
                collected_text.append(token)
                yield token  # pass through to caller

            # After stream ends, get usage from the agent's last response
            # (Hermes stores usage internally after streaming completes)
            usage = self._agent.last_usage if hasattr(self._agent, 'last_usage') else CanonicalUsage()
        except Exception as e:
            logger.exception(f"Stream call {call_id} failed")
            error_msg = str(e)
            status = "error"
            usage = CanonicalUsage()

        end = time.time()
        latency = end - start

        cost = estimate_usage_cost(
            model_name=kwargs.get("model", self._agent.model),
            usage=usage,
            provider=kwargs.get("provider", self._agent.provider),
            base_url=kwargs.get("base_url", self._agent.base_url),
            api_key=kwargs.get("api_key", self._agent.api_key),
        )

        telemetry = CallTelemetry(
            call_id=call_id,
            model=kwargs.get("model", self._agent.model),
            provider=kwargs.get("provider", self._agent.provider),
            start_time=start,
            end_time=end,
            latency_seconds=latency,
            usage=usage,
            cost=cost,
            input_tokens_formatted=format_token_count_compact(usage.input_tokens),
            output_tokens_formatted=format_token_count_compact(usage.output_tokens),
            total_tokens_formatted=format_token_count_compact(usage.total_tokens),
            cost_label=cost.label,
            status=status,
            error_message=error_msg,
        )

        await self._collector.record_call(telemetry)

        # If there was an error, yield nothing else (already yielded partial tokens)
        if status == "error":
            # Optionally yield an error token or just stop
            pass

    # ----------------------------------------------------------
    # Tool handling with telemetry – delegate to agent's tool system
    # ----------------------------------------------------------
    async def run_with_tools(self, prompt: str, tools: List[Dict], **kwargs) -> str:
        """
        Execute a task that may involve tool calls. Telemetry wraps the entire
        multi-step interaction.
        """
        # The agent's tool loop is internal; we intercept at the top level.
        # For simplicity, we assume agent.run_with_tools() returns a response
        # with aggregated usage across all sub-calls.
        call_id = f"tool-call-{self._call_counter}-{int(time.time())}"
        self._call_counter += 1
        start = time.time()
        error_msg = ""
        status = "success"
        usage = None

        try:
            response = await self._agent.run_with_tools(prompt, tools, **kwargs)
            usage = response.usage if hasattr(response, 'usage') else CanonicalUsage()
        except Exception as e:
            logger.exception(f"Tool call {call_id} failed")
            error_msg = str(e)
            status = "error"
            usage = CanonicalUsage()

        end = time.time()
        latency = end - start

        cost = estimate_usage_cost(
            model_name=kwargs.get("model", self._agent.model),
            usage=usage,
            provider=kwargs.get("provider", self._agent.provider),
            base_url=kwargs.get("base_url", self._agent.base_url),
            api_key=kwargs.get("api_key", self._agent.api_key),
        )

        telemetry = CallTelemetry(
            call_id=call_id,
            model=kwargs.get("model", self._agent.model),
            provider=kwargs.get("provider", self._agent.provider),
            start_time=start,
            end_time=end,
            latency_seconds=latency,
            usage=usage,
            cost=cost,
            input_tokens_formatted=format_token_count_compact(usage.input_tokens),
            output_tokens_formatted=format_token_count_compact(usage.output_tokens),
            total_tokens_formatted=format_token_count_compact(usage.total_tokens),
            cost_label=cost.label,
            status=status,
            error_message=error_msg,
        )

        await self._collector.record_call(telemetry)
        return response.text if response else ""


# ---------------------------------------------------------------------------
# Example: Custom tool for cost estimation (demonstrates tool handling)
# ---------------------------------------------------------------------------

class CostEstimationTool:
    """
    A tool that estimates the cost of a given text or prompt before sending it.
    This can be used by the agent to decide whether to proceed or truncate.
    """

    def __init__(self, model: str, provider: str, base_url: str = "", api_key: str = ""):
        self.model = model
        self.provider = provider
        self.base_url = base_url
        self.api_key = api_key

    async def estimate(self, prompt_tokens: int, output_tokens: int = 1000) -> str:
        """Return a cost estimate string."""
        usage = CanonicalUsage(input_tokens=prompt_tokens, output_tokens=output_tokens)
        cost = estimate_usage_cost(
            model_name=self.model,
            usage=usage,
            provider=self.provider,
            base_url=self.base_url,
            api_key=self.api_key,
        )
        return f"Estimated cost: {cost.label} (status: {cost.status})"

    def get_tool_definition(self) -> Dict:
        return {
            "type": "function",
            "function": {
                "name": "estimate_cost",
                "description": "Estimate the cost of a prompt before sending it to the LLM.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "prompt_tokens": {"type": "integer", "description": "Number of input tokens"},
                        "output_tokens": {"type": "integer", "description": "Expected output tokens (default 1000)"}
                    },
                    "required": ["prompt_tokens"]
                }
            }
        }


# ---------------------------------------------------------------------------
# Main execution: set up agent, telemetry, and run a conversation
# ---------------------------------------------------------------------------

async def main():
    # Step 1: Initialize the Hermes AIAgent with persistent memory and tool support.
    # For demonstration, we assume a local Ollama model, but any provider works.
    agent = AIAgent(
        model="qwen3.5:27b",          # Example model
        provider="ollama",             # Provider type
        base_url="http://localhost:11434/v1",
        api_key="",                    # Not needed for local Ollama
        memory_type="persistent",      # Use persistent memory (e.g., SQLite or file)
        memory_path="./hermes_memory.db",
        # Additional config for streaming and tools
        stream=True,                   # Enable streaming by default
        max_tokens=4096,
        temperature=0.7,
    )

    # Step 2: Configure telemetry thresholds
    config = TelemetryConfig(
        max_cost_per_call=Decimal("0.05"),
        max_latency_seconds=20.0,
        max_total_tokens_per_call=50_000,
        budget_daily_usd=Decimal("2.00"),
        alert_callback=lambda msg: logger.warning(f"⚠️ ALERT: {msg}"),
    )

    # Step 3: Create telemetry collector and wrap the agent
    collector = TelemetryCollector(agent, config)
    telemetry_agent = TelemetryAIAgent(agent, collector)

    # Step 4: Register a custom tool for cost estimation
    cost_tool = CostEstimationTool(
        model=agent.model,
        provider=agent.provider,
        base_url=agent.base_url,
        api_key=agent.api_key,
    )
    # In Hermes, tools are registered via agent.register_tool() or a tool list.
    # We'll assume the agent accepts a list of tool definitions.
    agent.tools = [cost_tool.get_tool_definition()]

    # Step 5: Run a sample conversation with streaming and telemetry
    print("=== Hermes Telemetry Demo ===")
    print("Agent model:", agent.model)
    print("Provider:", agent.provider)
    print()

    # First, a simple synchronous call
    print(">>> Sync call: 'What is the capital of France?'")
    response = telemetry_agent.run("What is the capital of France?")
    print(f"Response: {response}")
    print()

    # Second, an async streaming call (simulate low-latency UX)
    print(">>> Streaming call: 'Explain quantum computing in one paragraph.'")
    async for token in telemetry_agent.stream("Explain quantum computing in one paragraph."):
        print(token, end="", flush=True)
    print("\n")

    # Third, a tool-assisted call (cost estimation)
    print(">>> Tool call: estimate cost of a 5000-token prompt")
    # The agent internally calls the tool; we just send a message that triggers it.
    # For demo, we directly call the tool.
    estimate = await cost_tool.estimate(5000, 2000)
    print(estimate)
    print()

    # Step 6: Retrieve aggregate stats from collector
    stats = collector.get_aggregate_stats()
    print("=== Aggregate Telemetry ===")
    for key, value in stats.items():
        print(f"  {key}: {value}")
    print()

    # Step 7: Demonstrate memory persistence – query recent telemetry from agent's memory
    print("=== Recent Telemetry from Memory ===")
    # Assuming agent.memory.query() accepts filters
    recent = await agent.memory.query({"type": "telemetry"}, limit=5)
    for entry in recent:
        data = entry.get("data", {})
        print(f"  Call {data.get('call_id')}: {data.get('cost_label')} | latency={data.get('latency_seconds'):.2f}s | tokens={data.get('total_tokens_formatted')}")


if __name__ == "__main__":
    asyncio.run(main())


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script.py
# Description: Advanced Integration Script
# ==========================================

#!/usr/bin/env python3
"""
Advanced Integration Script: Autonomous Tool Description Evolution

Demonstrates how to use Hermes Agent's AIAgent class in conjunction with the
self-evolution pipeline (DSPy + GEPA) to continuously improve tool descriptions
based on real-world query performance.

Dependencies:
    - hermes-agent (from NousResearch) installed in the environment
    - Python 3.10+
    - OpenAI API key (set in environment as OPENAI_API_KEY)

Usage:
    python autonomous_evolution.py --skill-name "find_answer" --n-iterations 5
"""

import os
import sys
import json
import time
import logging
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict
from dataclasses import dataclass, asdict

import click
import dspy
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import print as rprint

# ---------------------------------------------------------------------------
# Hermes Agent imports – actual library classes
# ---------------------------------------------------------------------------
from run_agent import AIAgent                               # (REQUIRED) core agent
from evolution.skills.evolve_skill import evolve as evolve_skill  # full evolution pipeline
from evolution.skills.skill_module import (
    load_skill,
    find_skill,
    reassemble_skill,
    SkillModule,
)
from evolution.core.fitness import skill_fitness_metric     # DSPy-compatible metric
from evolution.core.dataset_builder import (
    SyntheticDatasetBuilder,
    GoldenDatasetLoader,
    EvalDataset,
)
from evolution.core.config import EvolutionConfig
from evolution.core.constraints import ConstraintValidator

# ---------------------------------------------------------------------------
# Local imports (helper utilities)
# ---------------------------------------------------------------------------
from utils.logger import get_logger                        # local logging

# ---------------------------------------------------------------------------
# Configure logging
# ---------------------------------------------------------------------------
logger = get_logger(__name__)
console = Console()

# ---------------------------------------------------------------------------
# Data structures for tracking evolution history
# ---------------------------------------------------------------------------
@dataclass
class EvolutionRound:
    """Stores metrics from one evolution cycle."""
    iteration: int
    baseline_score: float
    evolved_score: float
    improvement: float
    timestamp: str
    skill_body_before: str
    skill_body_after: str
    constraints_passed: bool
    dataset_size: int

# ---------------------------------------------------------------------------
# Helper: Run the agent on a batch of queries and collect feedback
# ---------------------------------------------------------------------------
def run_agent_evaluation(
    agent: AIAgent,
    queries: List[str],
    expected_behaviors: List[str],
    skill_text: str,
    eval_model: str = "openai/gpt-4.1-mini",
) -> List[Dict]:
    """
    Feed queries to the agent, collect the answers and evaluate them using
    an LLM judge (fitness metric). Returns a list of scores per query.
    """
    from evolution.core.fitness import LLMJudge

    config = EvolutionConfig(eval_model=eval_model)
    judge = LLMJudge(config)
    results = []

    for idx, (query, expected) in enumerate(zip(queries, expected_behaviors)):
        # Call the agent
        response = agent.run(query)
        agent_output = str(response.get("output", ""))

        # Score using the judge
        score = judge.score(
            task_input=query,
            expected_behavior=expected,
            agent_output=agent_output,
            skill_text=skill_text,
        )
        results.append({
            "query": query,
            "expected": expected,
            "agent_output": agent_output,
            "fitness": asdict(score),
        })
        logger.info(f"Query {idx+1}: correctness={score.correctness:.2f}, procedure={score.procedure_following:.2f}")

    return results

# ---------------------------------------------------------------------------
# Main evolution orchestration
# ---------------------------------------------------------------------------
class AutonomousToolEvolver:
    """
    High-level class that manages the closed-loop learning cycle:
      1. Load baseline skill (tool description)
      2. Run agent on a set of test queries
      3. Build a synthetic evaluation dataset from the results
      4. Evolve the skill description using GEPA
      5. Validate constraints and evaluate on holdout set
      6. If improvement, persist the new skill and update the agent
      7. Log the round into persistent memory (file + agent memory)
    """

    def __init__(
        self,
        skill_name: str,
        hermes_agent_path: Optional[str] = None,
        optimizer_model: str = "openai/gpt-4.1",
        eval_model: str = "openai/gpt-4.1-mini",
        memory_dir: str = "memory/",
        n_test_queries: int = 10,
        n_iterations_gepa: int = 5,
    ):
        self.skill_name = skill_name
        self.optimizer_model = optimizer_model
        self.eval_model = eval_model
        self.memory_dir = Path(memory_dir)
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        self.n_test_queries = n_test_queries
        self.n_iterations = n_iterations_gepa

        # Determine Hermes agent path (default to environment variable or current dir)
        self.hermes_agent_path = (
            Path(hermes_agent_path)
            if hermes_agent_path
            else Path(os.getenv("HERMES_AGENT_PATH", "./hermes-agent"))
        )

        # Find and load the skill
        self.skill_path = find_skill(skill_name, self.hermes_agent_path)
        if not self.skill_path:
            raise FileNotFoundError(f"Skill '{skill_name}' not found in {self.hermes_agent_path / 'skills'}")
        self.skill = load_skill(self.skill_path)
        self.current_skill_body = self.skill["body"]
        self.current_skill_full = self.skill["raw"]

        # Initialize the AIAgent with the current skill
        self.agent = AIAgent(
            skills=[self.skill],
            memory_config={"type": "persistent", "dir": str(self.memory_dir)}
        )

        # History of evolution rounds
        self.history: List[EvolutionRound] = []

    # -----------------------------------------------------------------------
    # Step 1: Generate a synthetic evaluation dataset from the agent outputs
    # -----------------------------------------------------------------------
    def _build_dataset_from_agent_responses(self, queries: List[str]) -> EvalDataset:
        """Use the agent to answer queries and create a DSPy-compatible dataset."""
        config = EvolutionConfig(eval_model=self.eval_model)
        builder = SyntheticDatasetBuilder(config)

        # For each query, get the agent's output and the expected behavior
        # (In production, expected behavior might come from human annotations.
        #  Here we synthetically generate it using the same LLM.)
        examples = []
        for query in queries:
            response = self.agent.run(query)
            agent_output = str(response.get("output", ""))

            # Generate an "expected behavior" from the skill itself
            # (A more advanced version would use a golden set.)
            expected = f"Use the skill {self.skill_name} to answer the customer query: {query}"
            examples.append({
                "task_input": query,
                "expected_behavior": expected,
                "agent_output": agent_output,
                "skill_text": self.current_skill_body,
            })

        dataset = EvalDataset.from_list(examples)
        # Split 70/15/15
        dataset.split()
        return dataset

    # -----------------------------------------------------------------------
    # Step 2: Run the evolution using GEPA
    # -----------------------------------------------------------------------
    def _evolve_skill(self, dataset: EvalDataset) -> str:
        """Evolve the skill body using the Hermes Agent evolution pipeline."""
        # Recreate the config (needed by evolve_skill)
        config = EvolutionConfig(
            iterations=self.n_iterations,
            optimizer_model=self.optimizer_model,
            eval_model=self.eval_model,
            judge_model=self.eval_model,
            run_pytest=False,
        )
        config.hermes_agent_path = self.hermes_agent_path

        # The evolve function expects skill name, but we want to use the in-memory skill body.
        # We'll directly use the internals similar to how evolve() works in the repo.
        # (For a production script, one could monkey-patch or call the underlying DSPy/GEPA code.)
        # 
        # Here we do a simplified in-process evolution using the same classes:
        lm = dspy.LM(self.eval_model)
        dspy.configure(lm=lm)

        baseline_module = SkillModule(self.current_skill_body)
        trainset = dataset.to_dspy_examples("train")
        valset = dataset.to_dspy_examples("val")

        try:
            optimizer = dspy.GEPA(
                metric=skill_fitness_metric,
                max_steps=self.n_iterations,
            )
            optimized_module = optimizer.compile(
                baseline_module,
                trainset=trainset,
                valset=valset,
            )
        except Exception as e:
            logger.warning(f"GEPA failed, falling back to MIPROv2: {e}")
            optimizer = dspy.MIPROv2(
                metric=skill_fitness_metric,
                auto="light",
            )
            optimized_module = optimizer.compile(
                baseline_module,
                trainset=trainset,
            )

        # Extract the evolved skill text
        evolved_body = optimized_module.skill_text
        return evolved_body

    # -----------------------------------------------------------------------
    # Step 3: Validate constraints on the evolved skill
    # -----------------------------------------------------------------------
    def _validate_constraints(self, evolved_body: str) -> bool:
        """Run constraint validation; return True if all pass."""
        config = EvolutionConfig(eval_model=self.eval_model)
        validator = ConstraintValidator(config)
        constraints = validator.validate_all(evolved_body, "skill", baseline_text=self.current_skill_body)
        all_pass = all(c.passed for c in constraints)
        for c in constraints:
            icon = "✓" if c.passed else "✗"
            color = "green" if c.passed else "red"
            console.print(f"  [{color}]{icon} {c.constraint_name}[/{color}]: {c.message}")
        return all_pass

    # -----------------------------------------------------------------------
    # Step 4: Evaluate the evolved skill on the holdout set
    # -----------------------------------------------------------------------
    def _evaluate_holdout(self, dataset: EvalDataset) -> Dict[str, float]:
        """Compare baseline vs evolved on holdout; return scores."""
        from evolution.skills.skill_module import SkillModule
        baseline_module = SkillModule(self.current_skill_body)
        evolved_module = SkillModule(self._latest_evolved_body)   # must set

        holdout_examples = dataset.to_dspy_examples("holdout")
        baseline_scores = []
        evolved_scores = []

        lm = dspy.LM(self.eval_model)
        for ex in holdout_examples:
            with dspy.context(lm=lm):
                # baseline
                pred_b = baseline_module(task_input=ex.task_input)
                b_score = skill_fitness_metric(ex, pred_b)
                baseline_scores.append(b_score)

                # evolved
                pred_e = evolved_module(task_input=ex.task_input)
                e_score = skill_fitness_metric(ex, pred_e)
                evolved_scores.append(e_score)

        avg_baseline = sum(baseline_scores) / max(1, len(baseline_scores))
        avg_evolved = sum(evolved_scores) / max(1, len(evolved_scores))
        return {"baseline": avg_baseline, "evolved": avg_evolved,
                "improvement": avg_evolved - avg_baseline}

    # -----------------------------------------------------------------------
    # Step 5: Persist the evolution round into memory
    # -----------------------------------------------------------------------
    def _persist_memory(self, round_data: EvolutionRound):
        """Save round data both as a file and into the agent's memory."""
        # File persistence
        timestamp = round_data.timestamp
        file_path = self.memory_dir / f"evolution_round_{timestamp}.json"
        with open(file_path, "w") as f:
            json.dump(asdict(round_data), f, indent=2)
        logger.info(f"Evolution round saved to {file_path}")

        # Inject into agent's memory (persistent memory)
        memory_entry = {
            "type": "evolution_round",
            "timestamp": timestamp,
            "iteration": round_data.iteration,
            "improvement": round_data.improvement,
        }
        # Assume AIAgent has a method `add_memory` (as per repo's memory system)
        if hasattr(self.agent, "add_memory"):
            self.agent.add_memory(memory_entry)

    # -----------------------------------------------------------------------
    # Main loop
    # -----------------------------------------------------------------------
    def run_evolution_cycle(self) -> bool:
        """
        Execute one complete evolution cycle.
        Returns True if skill improved, False otherwise.
        """
        console.rule(f"[bold cyan]Evolution Cycle for Skill: {self.skill_name}[/bold cyan]")
        console.print(f"  Current skill size: {len(self.current_skill_body)} chars")

        # --- Preparation: generate test queries ---
        # In a real system, these would come from actual user logs.
        test_queries = [
            "How do I reset my password?",
            "Can I downgrade my plan?",
            "What is the refund policy?",
            "Why is my page not loading?",
            "How to change billing address?",
        ][:self.n_test_queries]

        # Build dataset from agent responses
        dataset = self._build_dataset_from_agent_responses(test_queries)
        console.print(f"  Dataset built: {len(dataset.train)} train, {len(dataset.val)} val, {len(dataset.holdout)} holdout")

        # --- Evolution ---
        console.print(f"\n[bold]Running GEPA Evolution ({self.n_iterations} iterations)...[/bold]")
        start_time = time.time()
        evolved_body = self._evolve_skill(dataset)
        elapsed = time.time() - start_time
        console.print(f"  Evolution completed in {elapsed:.1f}s. New size: {len(evolved_body)} chars")

        self._latest_evolved_body = evolved_body

        # --- Validate constraints ---
        console.print("\n[bold]Constraint Validation:[/bold]")
        constraints_pass = self._validate_constraints(evolved_body)
        if not constraints_pass:
            console.print("[red]✗ Constraints failed – skipping deployment[/red]")
            return False

        # --- Evaluate on holdout ---
        console.print("\n[bold]Holdout Evaluation:[/bold]")
        eval_results = self._evaluate_holdout(dataset)
        improvement = eval_results["improvement"]
        change_color = "green" if improvement > 0 else "red"
        console.print(f"  Baseline: {eval_results['baseline']:.3f}")
        console.print(f"  Evolved:  {eval_results['evolved']:.3f}")
        console.print(f"  Change:   [{change_color}]{improvement:+.3f}[/{change_color}]")

        if improvement <= 0:
            console.print("[yellow]⚠ No improvement – not updating skill[/yellow]")
            return False

        # --- Accept the evolved skill ---
        self.current_skill_body = evolved_body
        self.current_skill_full = reassemble_skill(self.skill["frontmatter"], evolved_body)

        # Update the agent with the new skill
        # (The AIAgent class likely expects a skill dict; we reload it)
        updated_skill = self.skill.copy()
        updated_skill["body"] = evolved_body
        updated_skill["raw"] = self.current_skill_full
        # If AIAgent supports hot-reload:
        self.agent.update_skill(updated_skill)

        # --- Persist to memory ---
        round_data = EvolutionRound(
            iteration=len(self.history) + 1,
            baseline_score=eval_results["baseline"],
            evolved_score=eval_results["evolved"],
            improvement=improvement,
            timestamp=datetime.now().isoformat(),
            skill_body_before=self.skill["body"],
            skill_body_after=evolved_body,
            constraints_passed=constraints_pass,
            dataset_size=len(dataset.all_examples),
        )
        self.history.append(round_data)
        self._persist_memory(round_data)

        console.print(f"\n[bold green]✓ Skill improved! Deployed new version.[/bold green]")
        return True

# ---------------------------------------------------------------------------
# CLI entry point using Click
# ---------------------------------------------------------------------------
@click.command()
@click.option("--skill-name", required=True, help="Name of the tool skill to evolve")
@click.option("--iterations", default=5, help="Number of GEPA iterations")
@click.option("--queries", default=10, help="Number of test queries to generate")
@click.option("--hermes-path", default=None, help="Path to Hermes Agent repository")
@click.option("--memory-dir", default="memory/", help="Directory for persistence")
@click.option("--eval-model", default="openai/gpt-4.1-mini", help="Evaluation LLM")
def main(skill_name, iterations, queries, hermes_path, memory_dir, eval_model):
    """
    CLI to run autonomous tool description evolution.
    """
    evolver = AutonomousToolEvolver(
        skill_name=skill_name,
        hermes_agent_path=hermes_path,
        optimizer_model="openai/gpt-4.1",
        eval_model=eval_model,
        memory_dir=memory_dir,
        n_test_queries=queries,
        n_iterations_gepa=iterations,
    )

    # Run the cycle; could be placed in an infinite loop with scheduling.
    successful = evolver.run_evolution_cycle()

    if successful:
        console.print("\n[bold]Evolution history:[/bold]")
        for round in evolver.history:
            console.print(f"  Round {round.iteration}: +{round.improvement:.3f} at {round.timestamp}")
    else:
        console.print("\n[bold]No improvement in this cycle.[/bold]")

if __name__ == "__main__":
    main()

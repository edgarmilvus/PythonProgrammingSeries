
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# evolution/tools/tool_fitness.py
import hashlib
import json
import os
from typing import Dict, Optional, Tuple

import dspy
from dspy import Example, Prediction

from evolution.core.fitness import skill_fitness_metric  # heuristic fallback
from evolution.core.llm_judge import LLMJudge

# Global cache: key => (score, timestamp)
_cache: Dict[str, Tuple[float, float]] = {}
CACHE_EXPIRY = 3600  # 1 hour


def _cache_key(task_input: str, agent_output: str) -> str:
    raw = f"{task_input}||{agent_output}"
    return hashlib.sha256(raw.encode()).hexdigest()


def tool_description_fitness(example: Example, prediction: Prediction, trace=None) -> float:
    heuristic_score = skill_fitness_metric(example, prediction, trace)

    # Only use LLM judge if heuristic is uncertain (0.3 .. 0.8)
    if not (0.3 <= heuristic_score <= 0.8):
        return heuristic_score

    task_input = example.task_input
    agent_output = prediction.output if hasattr(prediction, "output") else str(prediction)

    key = _cache_key(task_input, agent_output)
    now = os.times().user  # not perfect but acceptable
    if key in _cache:
        score, timestamp = _cache[key]
        if now - timestamp < CACHE_EXPIRY:
            return score

    # Call cheap LLM judge
    try:
        lm = dspy.LM("openai/gpt-4.1-mini")
        judge = LLMJudge(lm=lm, dimensions=["clarity", "completeness", "format"])
        judge_result = judge.score(task_input, agent_output)
        score = sum(judge_result.values()) / len(judge_result)  # average across dimensions
    except Exception:
        score = heuristic_score  # fallback

    _cache[key] = (score, now)
    return score


# Extending SyntheticDatasetBuilder (in evolution/core/dataset_builder.py)
class SyntheticDatasetBuilder:
    # ... existing code ...

    def generate_tool_descriptions(self, tool_name: str, tool_implementation: str) -> List[Example]:
        # Parse docstring, parameters, return type (simplified)
        doc = self._extract_docstring(tool_implementation)
        params = self._extract_params(tool_implementation)
        return_type = self._extract_return_type(tool_implementation)

        examples = []
        for _ in range(10):
            task_input = f"Write a concise, clear description for the tool `{tool_name}` that an AI agent can use."
            expected_behavior = (
                "The description should include: (1) a one-line summary, "
                "(2) parameter details with types, (3) return value, (4) example usage. "
                "It must be under 200 words and free of jargon. "
                f"Function: {tool_name}({params}) -> {return_type}"
            )
            skill_text = f"# {tool_name}\n{self._sample_description(doc, params, return_type)}"
            ex = Example(task_input=task_input, expected_behavior=expected_behavior, skill_text=skill_text)
            examples.append(ex)
        return examples


# CLI modification (in evolve_skill.py or new evolve_tool.py)
if __name__ == "__main__":
    parser.add_argument("--tool", type=str, help="Name of the tool to optimize")
    args = parser.parse_args()

    if args.tool:
        from hermes.tools.registry import get_tool  # hypothetical
        tool = get_tool(args.tool)
        skill_text = f"---\nname: {tool.name}\n---\n{tool.description}"
        # create temporary skill file
        # use tool_fitness metric and tool_description dataset

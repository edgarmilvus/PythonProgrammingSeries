
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Partial modifications to evolution/skills/evolve_skill.py

import time
from pathlib import Path
from typing import Optional
from hermes.memory.session_db import SessionDB
from evolution.core.dataset_builder import SyntheticDatasetBuilder
from evolution.core.llm_judge import LLMJudge

def evolve(skill_name: str, iterations: int, output_dir: str,
           use_session_db: bool = True, retry_threshold: float = 0.1,
           eval_source: str = "synthetic", dry_run: bool = False):
    # Initialisation
    skill_path = find_skill(skill_name)
    baseline = load_skill(skill_path)

    # Session DB
    session_db = None
    previous_metrics = None
    retry_needed = False
    if use_session_db:
        session_db = SessionDB("hermes/memory/session_db.sqlite")
        keys = session_db.list_keys(f"evolution:{skill_name}:*")
        if keys:
            # Get most recent
            latest_key = sorted(keys)[-1]
            record = session_db.retrieve_entry(latest_key)
            if record and record.get("improvement", 1.0) < retry_threshold:
                retry_needed = True
                previous_metrics = record
                # Set baseline to previous evolved skill
                prev_skill_path = record["evolved_skill_path"]
                baseline = load_skill(prev_skill_path)

    # Build initial dataset
    dataset = build_eval_dataset(skill_name, eval_source)

    # Run first optimization pass
    pass1_result = run_gepa(baseline, dataset, iterations, output_dir)

    if retry_needed and pass1_result.improvement < retry_threshold:
        # Retry pass
        logger.info("Improvement below threshold, retrying with enriched dataset")
        # Identify low‑scoring holdout examples
        holdout_scores = pass1_result.holdout_scores  # list of (example, score)
        low_scoring = [ex for ex, sc in holdout_scores if sc < 0.5]
        builder = SyntheticDatasetBuilder()
        extra_examples = []
        for ex in low_scoring:
            # Generate 2 perturbed variants (use LLM to paraphrase)
            for _ in range(2):
                new_ex = builder.perturb_example(ex)
                extra_examples.append(new_ex)
        augmented_dataset = dataset + extra_examples

        # Run second pass using previous evolved skill as baseline
        retry_baseline = pass1_result.evolved_skill_text
        retry_output_dir = output_dir + "_retry"
        pass2_result = run_gepa(retry_baseline, augmented_dataset, iterations, retry_output_dir)

        # Compare improvements
        logger.info(f"Original improvement: {pass1_result.improvement:.2%}")
        logger.info(f"Retry improvement: {pass2_result.improvement:.2%}")

        # Use the better one
        final_result = pass2_result if pass2_result.improvement > pass1_result.improvement else pass1_result
    else:
        final_result = pass1_result

    # Store result in SessionDB
    if session_db:
        timestamp = int(time.time())
        key = f"evolution:{skill_name}:{timestamp}"
        session_db.store_entry(key, {
            "improvement": final_result.improvement,
            "evolved_skill_path": final_result.output_path,
            "passes": 2 if retry_needed else 1
        })

    return final_result

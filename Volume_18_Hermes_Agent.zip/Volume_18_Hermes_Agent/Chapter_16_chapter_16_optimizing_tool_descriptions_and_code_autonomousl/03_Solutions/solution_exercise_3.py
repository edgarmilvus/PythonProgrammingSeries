
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# evolution/skills/cross_evolve.py
import os
from pathlib import Path
from typing import List, Tuple

import dspy
from dspy import Example

from evolution.skills.skill_module import SkillModule
from evolution.core.dataset_builder import SyntheticDatasetBuilder
from evolution.core.fitness import skill_fitness_metric
from evolution.skills.evolve import evolve, load_skill, find_skill

# Modify SkillModule to support multi-part skills
class SkillModule(dspy.Module):
    def __init__(self, parts: List[Tuple[str, str]]):
        super().__init__()
        self.parts = parts
        self.full_text = "\n\n---\n\n".join([text for _, text in parts])
        self._part_names = [name for name, _ in parts]

    def forward(self, task_input: str, part: str = None, **kwargs):
        if part:
            # Use only the text of that part
            idx = self._part_names.index(part)
            combined_text = self.parts[idx][1]
        else:
            combined_text = self.full_text
        # Typically generate prediction using LLM
        return dspy.Prediction(output=combined_text)  # simplified


def cross_evolve(skill_a_name: str, skill_b_name: str,
                 iterations: int = 15, output_dir: str = "output") -> Tuple[str, str]:
    # Load both skills
    skill_a_path = find_skill(skill_a_name)
    skill_b_path = find_skill(skill_b_name)
    skill_a_text = load_skill(skill_a_path)
    skill_b_text = load_skill(skill_b_path)

    # Merge into composite SkillModule
    parts = [("part_a", skill_a_text), ("part_b", skill_b_text)]
    composite_module = SkillModule(parts)

    # Build multi-task evaluation dataset
    builder = SyntheticDatasetBuilder()
    examples_a = builder.generate_tool_descriptions(skill_a_name, skill_a_text)
    examples_b = builder.generate_tool_descriptions(skill_b_name, skill_b_text)
    # Add part indicator to task_input
    for ex in examples_a:
        ex.task_input = "[Part A] " + ex.task_input
    for ex in examples_b:
        ex.task_input = "[Part B] " + ex.task_input
    all_examples = examples_a + examples_b

    # Define a metric that scores both parts separately and averages
    def cross_fitness(example: Example, prediction: Prediction, trace=None):
        # Determine which part this example belongs to
        if example.task_input.startswith("[Part A]"):
            part_name = "part_a"
        else:
            part_name = "part_b"
        # Use composite module to generate output focusing on that part
        composite_module_with_part = SkillModule(parts)  # fresh copy
        pred = composite_module_with_part.forward(example.task_input, part=part_name)
        # Score using standard fitness (or custom metric)
        return skill_fitness_metric(example, pred, trace)

    # Run GEPA optimization (simplified)
    optimized_module = self_evolve_loop(composite_module, all_examples, cross_fitness, iterations)

    # Split evolved text back into two parts
    evolved_full = optimized_module.full_text
    separator = "\n\n---\n\n"
    parts_evolved = evolved_full.split(separator, 1)
    part_a_evolved = parts_evolved[0] if len(parts_evolved) > 1 else ""
    part_b_evolved = parts_evolved[1] if len(parts_evolved) > 1 else ""

    # Save to files
    output_dir_path = Path(output_dir)
    output_dir_path.mkdir(parents=True, exist_ok=True)
    with open(output_dir_path / "evolved_part_a.md", "w") as f:
        f.write(part_a_evolved)
    with open(output_dir_path / "evolved_part_b.md", "w") as f:
        f.write(part_b_evolved)

    return part_a_evolved, part_b_evolved

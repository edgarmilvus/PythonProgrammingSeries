
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# evolution/constraints/secret_constraint.py
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple

from evolution.core.constraints import ConstraintValidator, ConstraintResult

# Extend ConstraintResult with an optional details field
@dataclass
class ConstraintResult:
    constraint_name: str
    passed: bool
    message: str
    details: List[str] = field(default_factory=list)  # new field


def no_hardcoded_secrets(text: str, artifact_type: str, baseline_text: Optional[str] = None) -> ConstraintResult:
    """
    Check for hardcoded secrets in the given text.
    Applies only to 'skill' or 'tool' artifact types.
    """
    if artifact_type not in ("skill", "tool"):
        return ConstraintResult("no_hardcoded_secrets", True, "No secrets check for this artifact type")

    patterns = {
        "OpenAI API Key": r'sk-[A-Za-z0-9]{20,}',
        "AWS Access Key": r'AKIA[0-9A-Z]{16}',
        "Password assignment": r'password\s*=\s*[\'"][^\'"]+[\'"]',
        "Token assignment": r'token\s*=\s*[\'"][^\'"]+[\'"]',
        "Generic Secret": r'secret\s*=\s*[\'"][^\'"]+[\'"]',
    }
    lines = text.splitlines(keepends=False)
    found: List[str] = []
    for i, line in enumerate(lines, 1):
        for name, pattern in patterns.items():
            if re.search(pattern, line, re.IGNORECASE):
                found.append(f"Line {i}: matched '{name}' pattern -> {line.strip()[:80]}")
                break  # One pattern per line is enough

    if found:
        msg = f"Found {len(found)} potential secret(s) in the text."
        return ConstraintResult("no_hardcoded_secrets", False, msg, details=found)
    return ConstraintResult("no_hardcoded_secrets", True, "No secrets detected.")


# Integration in evolve_skill.py (partial)
# ... inside evolve() function before validation step (step 7):
def integrate_secret_constraint(validator: ConstraintValidator):
    validator.add_constraint("no_hardcoded_secrets", no_hardcoded_secrets)

# In the validation loop, after collecting results:
# result is a ConstraintResult object
if not result.passed and result.constraint_name == "no_hardcoded_secrets":
    for detail in result.details:
        logger.warning(detail)
    output_suffix = "FAILED_SECRETS"
    # abort deployment: return early or raise exception

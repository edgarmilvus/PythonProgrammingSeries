
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# automation/refine_tool_descriptions.py
import concurrent.futures
import logging
import subprocess
import tempfile
from pathlib import Path
from typing import List

from hermes.tools.registry import get_all_tools, update_tool_description, ToolRegistryError
from evolution.core.dataset_builder import SyntheticDatasetBuilder

logger = logging.getLogger(__name__)


def refine_single_tool(tool, dry_run: bool = False):
    """Refine a single tool's description. Returns True if successful."""
    tool_name = tool.name
    current_desc = tool.description
    original_desc = current_desc

    # Check if refinement needed
    if not tool.auto_generated and len(current_desc) >= 50:
        return False  # Already good

    # Generate synthetic dataset
    builder = SyntheticDatasetBuilder()
    examples = builder.generate_tool_descriptions(tool_name, tool.code)
    # Save dataset to temp file
    dataset_path = tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False).name
    with open(dataset_path, "w") as f:
        for ex in examples:
            f.write(json.dumps(ex.toDict()) + "\n")

    # Build temporary skill markdown
    skill_content = f"---\nname: {tool_name}\n---\n{current_desc}"
    skill_path = tempfile.NamedTemporaryFile(suffix=".md", delete=False).name
    with open(skill_path, "w") as f:
        f.write(skill_content)

    try:
        # Run evolution subprocess or import evolve function
        cmd = [
            "python", "-m", "evolution.skills.evolve_skill",
            "--skill", tool_name,
            "--skill-file", skill_path,
            "--eval-source", "synthetic",
            "--iterations", "5",
            "--dataset", dataset_path,
        ]
        if dry_run:
            logger.info(f"Would run: {' '.join(cmd)}")
            return True

        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        # Parse evolved description from output (simplified: assume it saves evolved_skill.md)
        evolved_text = result.stdout  # but better parse log
        evolved_desc = extract_description(evolved_text)  # helper omitted

        # Update registry (with dry-run check)
        if not dry_run:
            update_tool_description(tool_name, evolved_desc)
            # Validate via pytest? (simplified)
            validate_ok = run_pytest_for_tool(tool_name)
            if not validate_ok:
                raise RuntimeError("Validation failed")
        else:
            logger.info(f"Would update {tool_name} description to: {evolved_desc[:80]}...")
        return True
    except Exception as e:
        logger.error(f"Failed to evolve {tool_name}: {e}")
        # Rollback (only if we had updated)
        if not dry_run:
            try:
                update_tool_description(tool_name, original_desc)
                logger.info(f"Rolled back {tool_name} to original description.")
            except Exception as rollback_err:
                logger.error(f"Rollback also failed: {rollback_err}")
        return False
    finally:
        # Cleanup temp files
        Path(dataset_path).unlink(missing_ok=True)
        Path(skill_path).unlink(missing_ok=True)


def main(batch_size: int = 4, dry_run: bool = False):
    tools = get_all_tools()
    # Filter tools needing refinement
    target_tools = [t for t in tools if t.auto_generated or len(t.description) < 50]
    logger.info(f"Found {len(target_tools)} tools to refine")

    with concurrent.futures.ThreadPoolExecutor(max_workers=batch_size) as executor:
        futures = [executor.submit(refine_single_tool, tool, dry_run) for tool in target_tools]
        for future in concurrent.futures.as_completed(futures):
            try:
                future.result()
            except Exception as e:
                logger.error(f"Unexpected error: {e}")

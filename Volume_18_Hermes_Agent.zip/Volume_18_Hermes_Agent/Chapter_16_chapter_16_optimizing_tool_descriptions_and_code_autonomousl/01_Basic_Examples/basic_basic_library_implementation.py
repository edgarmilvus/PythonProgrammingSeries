
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation.py
# Description: Basic Library Implementation
# ==========================================

"""
Basic Library Implementation for Hermes Agent Self-Evolution

This module provides a SkillEvolver class that encapsulates the closed-loop
learning process: load skill → generate dataset → optimize → validate → deploy.
"""

import json
import time
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any

import dspy
from rich.console import Console
from rich.table import Table

# Import real Hermes Agent classes
from evolution.core.config import EvolutionConfig
from evolution.core.dataset_builder import SyntheticDatasetBuilder, EvalDataset
from evolution.core.fitness import skill_fitness_metric, LLMJudge, FitnessScore
from evolution.core.constraints import ConstraintValidator
from evolution.skills.skill_module import SkillModule, load_skill, find_skill, reassemble_skill

console = Console()


class SkillEvolver:
    """
    A high-level interface for evolving a single skill autonomously.

    Usage:
        evolver = SkillEvolver(skill_name="code-review", iterations=5)
        result = evolver.evolve()
        print(f"Improvement: {result.improvement:.3f}")
    """

    def __init__(
        self,
        skill_name: str,
        iterations: int = 10,
        optimizer_model: str = "openai/gpt-4.1",
        eval_model: str = "openai/gpt-4.1-mini",
        hermes_repo: Optional[str] = None,
        dataset_path: Optional[str] = None,
        eval_source: str = "synthetic",
        dry_run: bool = False,
    ):
        """
        Initialize the evolver with configuration.

        Args:
            skill_name: Name of the skill to evolve (e.g., "code-review").
            iterations: Number of GEPA optimization steps.
            optimizer_model: Model used for GEPA reflections.
            eval_model: Model used for LLM-as-judge evaluations.
            hermes_repo: Path to the Hermes Agent repository (default: auto-detect).
            dataset_path: Path to an existing evaluation dataset (JSONL).
            eval_source: Source for dataset generation ("synthetic", "golden", "sessiondb").
            dry_run: If True, validate setup without running optimization.
        """
        self.skill_name = skill_name
        self.iterations = iterations
        self.optimizer_model = optimizer_model
        self.eval_model = eval_model
        self.dataset_path = dataset_path
        self.eval_source = eval_source
        self.dry_run = dry_run

        # Create configuration object
        self.config = EvolutionConfig(
            iterations=iterations,
            optimizer_model=optimizer_model,
            eval_model=eval_model,
            judge_model=eval_model,
            run_pytest=False,  # We'll skip pytest for simplicity
        )
        if hermes_repo:
            self.config.hermes_agent_path = Path(hermes_repo)

        # These will be populated during evolve()
        self.skill: Optional[Dict[str, Any]] = None
        self.dataset: Optional[EvalDataset] = None
        self.baseline_module: Optional[SkillModule] = None
        self.optimized_module: Optional[SkillModule] = None
        self.evolved_body: Optional[str] = None
        self.metrics: Dict[str, Any] = {}

    def _load_skill(self) -> None:
        """Find and load the skill file from the repository."""
        skill_path = find_skill(self.skill_name, self.config.hermes_agent_path)
        if not skill_path:
            raise FileNotFoundError(
                f"Skill '{self.skill_name}' not found in "
                f"{self.config.hermes_agent_path / 'skills'}"
            )
        self.skill = load_skill(skill_path)
        console.print(f"  Loaded skill: {skill_path.relative_to(self.config.hermes_agent_path)}")
        console.print(f"  Name: {self.skill['name']}")
        console.print(f"  Size: {len(self.skill['raw']):,} chars")

    def _build_dataset(self) -> None:
        """Generate or load an evaluation dataset for the skill."""
        if self.dataset_path:
            # Load existing dataset
            self.dataset = EvalDataset.load(Path(self.dataset_path))
            console.print(f"  Loaded dataset: {len(self.dataset.all_examples)} examples")
        elif self.eval_source == "synthetic":
            # Generate synthetic examples using an LLM
            builder = SyntheticDatasetBuilder(self.config)
            self.dataset = builder.generate(
                artifact_text=self.skill["raw"],
                artifact_type="skill",
            )
            # Save for reuse
            save_path = Path("datasets") / "skills" / self.skill_name
            self.dataset.save(save_path)
            console.print(f"  Generated {len(self.dataset.all_examples)} synthetic examples")
        else:
            raise ValueError(f"Unsupported eval_source: {self.eval_source}")

        console.print(f"  Split: {len(self.dataset.train)} train / "
                      f"{len(self.dataset.val)} val / "
                      f"{len(self.dataset.holdout)} holdout")

    def _validate_baseline(self) -> bool:
        """Check if the baseline skill passes all constraints."""
        validator = ConstraintValidator(self.config)
        constraints = validator.validate_all(self.skill["body"], "skill")
        all_pass = True
        for c in constraints:
            icon = "✓" if c.passed else "✗"
            color = "green" if c.passed else "red"
            console.print(f"  [{color}]{icon} {c.constraint_name}[/{color}]: {c.message}")
            if not c.passed:
                all_pass = False
        return all_pass

    def _setup_optimizer(self) -> None:
        """Configure DSPy and create the baseline module."""
        lm = dspy.LM(self.eval_model)
        dspy.configure(lm=lm)
        self.baseline_module = SkillModule(self.skill["body"])

    def _run_optimization(self) -> None:
        """Execute the GEPA optimization loop."""
        trainset = self.dataset.to_dspy_examples("train")
        valset = self.dataset.to_dspy_examples("val")

        console.print(f"\n[bold cyan]Running GEPA optimization ({self.iterations} iterations)...[/bold cyan]")
        start_time = time.time()

        try:
            # Use GEPA if available, fall back to MIPROv2
            optimizer = dspy.GEPA(
                metric=skill_fitness_metric,
                max_steps=self.iterations,
            )
            self.optimized_module = optimizer.compile(
                self.baseline_module,
                trainset=trainset,
                valset=valset,
            )
        except Exception as e:
            console.print(f"[yellow]GEPA not available ({e}), falling back to MIPROv2[/yellow]")
            optimizer = dspy.MIPROv2(
                metric=skill_fitness_metric,
                auto="light",
            )
            self.optimized_module = optimizer.compile(
                self.baseline_module,
                trainset=trainset,
            )

        self.metrics["elapsed_seconds"] = time.time() - start_time
        console.print(f"  Optimization completed in {self.metrics['elapsed_seconds']:.1f}s")

        # Extract the evolved skill text from the optimized module
        self.evolved_body = self.optimized_module.skill_text

    def _validate_evolved(self) -> bool:
        """Ensure the evolved skill still meets constraints."""
        validator = ConstraintValidator(self.config)
        constraints = validator.validate_all(
            self.evolved_body, "skill", baseline_text=self.skill["body"]
        )
        all_pass = True
        for c in constraints:
            icon = "✓" if c.passed else "✗"
            color = "green" if c.passed else "red"
            console.print(f"  [{color}]{icon} {c.constraint_name}[/{color}]: {c.message}")
            if not c.passed:
                all_pass = False
        return all_pass

    def _evaluate_holdout(self) -> None:
        """Compare baseline and evolved on the holdout set."""
        holdout_examples = self.dataset.to_dspy_examples("holdout")
        lm = dspy.LM(self.eval_model)

        baseline_scores = []
        evolved_scores = []
        for ex in holdout_examples:
            with dspy.context(lm=lm):
                baseline_pred = self.baseline_module(task_input=ex.task_input)
                baseline_score = skill_fitness_metric(ex, baseline_pred)
                baseline_scores.append(baseline_score)

                evolved_pred = self.optimized_module(task_input=ex.task_input)
                evolved_score = skill_fitness_metric(ex, evolved_pred)
                evolved_scores.append(evolved_score)

        self.metrics["baseline_score"] = sum(baseline_scores) / max(1, len(baseline_scores))
        self.metrics["evolved_score"] = sum(evolved_scores) / max(1, len(evolved_scores))
        self.metrics["improvement"] = self.metrics["evolved_score"] - self.metrics["baseline_score"]
        self.metrics["baseline_size"] = len(self.skill["body"])
        self.metrics["evolved_size"] = len(self.evolved_body)

    def _save_output(self) -> Path:
        """Save the evolved skill and metrics to disk."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_dir = Path("output") / self.skill_name / timestamp
        output_dir.mkdir(parents=True, exist_ok=True)

        # Save evolved skill
        evolved_full = reassemble_skill(self.skill["frontmatter"], self.evolved_body)
        (output_dir / "evolved_skill.md").write_text(evolved_full)

        # Save baseline for comparison
        (output_dir / "baseline_skill.md").write_text(self.skill["raw"])

        # Save metrics
        (output_dir / "metrics.json").write_text(json.dumps(self.metrics, indent=2))

        console.print(f"\n  Output saved to {output_dir}/")
        return output_dir

    def evolve(self) -> Dict[str, Any]:
        """
        Run the full evolution pipeline.

        Returns:
            Dictionary with metrics: baseline_score, evolved_score, improvement, etc.
        """
        console.print(f"\n[bold cyan]🧬 Hermes Agent Self-Evolution[/bold cyan] — Evolving skill: [bold]{self.skill_name}[/bold]\n")

        # Step 1: Load the skill
        self._load_skill()

        if self.dry_run:
            console.print("[bold green]DRY RUN — setup validated successfully.[/bold green]")
            return {"dry_run": True}

        # Step 2: Build evaluation dataset
        self._build_dataset()

        # Step 3: Validate baseline constraints
        baseline_ok = self._validate_baseline()
        if not baseline_ok:
            console.print("[yellow]⚠ Baseline skill has constraint violations — proceeding anyway[/yellow]")

        # Step 4: Set up optimizer
        self._setup_optimizer()

        # Step 5: Run optimization
        self._run_optimization()

        # Step 6: Validate evolved skill
        evolved_ok = self._validate_evolved()
        if not evolved_ok:
            console.print("[red]✗ Evolved skill FAILED constraints — not deploying[/red]")
            self._save_output()  # Still save for inspection
            self.metrics["deployed"] = False
            return self.metrics

        # Step 7: Evaluate on holdout
        self._evaluate_holdout()

        # Step 8: Save and report
        output_dir = self._save_output()
        self._print_results()

        if self.metrics["improvement"] > 0:
            console.print(f"\n[bold green]✓ Evolution improved skill by {self.metrics['improvement']:+.3f} "
                          f"({self.metrics['improvement']/max(0.001, self.metrics['baseline_score'])*100:+.1f}%)[/bold green]")
            self.metrics["deployed"] = True
        else:
            console.print(f"\n[yellow]⚠ Evolution did not improve skill (change: {self.metrics['improvement']:+.3f})[/yellow]")
            self.metrics["deployed"] = False

        return self.metrics

    def _print_results(self) -> None:
        """Display a summary table of the evolution results."""
        table = Table(title="Evolution Results")
        table.add_column("Metric", style="bold")
        table.add_column("Baseline", justify="right")
        table.add_column("Evolved", justify="right")
        table.add_column("Change", justify="right")

        improvement = self.metrics["improvement"]
        change_color = "green" if improvement > 0 else "red"
        table.add_row(
            "Holdout Score",
            f"{self.metrics['baseline_score']:.3f}",
            f"{self.metrics['evolved_score']:.3f}",
            f"[{change_color}]{improvement:+.3f}[/{change_color}]",
        )
        table.add_row(
            "Skill Size",
            f"{self.metrics['baseline_size']:,} chars",
            f"{self.metrics['evolved_size']:,} chars",
            f"{self.metrics['evolved_size'] - self.metrics['baseline_size']:+,} chars",
        )
        table.add_row("Time", "", f"{self.metrics['elapsed_seconds']:.1f}s", "")
        table.add_row("Iterations", "", str(self.iterations), "")

        console.print()
        console.print(table)


# Example usage: evolve a code-review skill
if __name__ == "__main__":
    evolver = SkillEvolver(
        skill_name="code-review",
        iterations=5,
        optimizer_model="openai/gpt-4.1",
        eval_model="openai/gpt-4.1-mini",
        eval_source="synthetic",
    )
    results = evolver.evolve()
    print(f"Deployed: {results.get('deployed', False)}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# agent/memory_providers/curator_history.py
import sqlite3
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

from agent.memory_provider import MemoryProvider

logger = logging.getLogger(__name__)

class CuratorHistoryProvider(MemoryProvider):
    name = "curator_history"
    
    def __init__(self, db_path: Optional[Path] = None):
        self.db_path = db_path or Path.home() / '.hermes' / 'logs' / 'curator' / '.curator_history.db'
        self.conn = None
        self._initialized = False
    
    def initialize(self, session_id: str, **kwargs):
        """Create/connect database and create table."""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.db_path))
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS curator_runs (
                run_id TEXT PRIMARY KEY,
                started_at TEXT,
                duration_seconds REAL,
                model TEXT,
                provider TEXT,
                auto_counts TEXT,
                consolidated_count INTEGER,
                pruned_count INTEGER,
                added_count INTEGER,
                cron_rewrites_count INTEGER,
                report_path TEXT
            )
        """)
        self.conn.commit()
        self._initialized = True
        logger.info(f"CuratorHistoryProvider initialized at {self.db_path}")
    
    def prefetch(self, query: str, session_id: str) -> Optional[str]:
        """If query mentions curator, inject last run summary."""
        keywords = ['curator', 'skill review', 'pruning', 'last run']
        if any(kw in query.lower() for kw in keywords):
            last_run = self._get_last_run()
            if last_run:
                return f"Last curator run: {last_run['started_at']}, consolidated {last_run['consolidated_count']}, pruned {last_run['pruned_count']}."
        return None
    
    def sync_turn(self, user_content: str, assistant_content: str, session_id: str):
        """No learning from conversation."""
        pass
    
    def get_tool_schemas(self) -> list:
        """Return tool definition for curator_history."""
        return [{
            "name": "curator_history",
            "description": "Retrieve curator run history.",
            "parameters": {
                "type": "object",
                "properties": {
                    "action": {
                        "type": "string",
                        "enum": ["last", "list", "detail"],
                        "description": "Action to perform"
                    },
                    "limit": {
                        "type": "integer",
                        "default": 5,
                        "description": "Number of runs for 'list'"
                    },
                    "run_id": {
                        "type": "string",
                        "description": "Run ID for 'detail'"
                    }
                },
                "required": ["action"]
            }
        }]
    
    def handle_tool_call(self, tool_name: str, args: dict, **kwargs) -> str:
        """Handle curator_history tool calls."""
        if tool_name != "curator_history":
            raise ValueError(f"Unknown tool {tool_name}")
        action = args.get("action")
        if action == "last":
            run = self._get_last_run()
            return json.dumps(run) if run else json.dumps({"error": "No runs found"})
        elif action == "list":
            limit = args.get("limit", 5)
            runs = self._list_recent_runs(limit)
            return json.dumps(runs)
        elif action == "detail":
            run_id = args.get("run_id")
            if not run_id:
                return json.dumps({"error": "run_id required"})
            run = self._get_run_by_id(run_id)
            return json.dumps(run) if run else json.dumps({"error": "Run not found"})
        else:
            return json.dumps({"error": f"Unknown action {action}"})
    
    def shutdown(self):
        """Close database connection."""
        if self.conn:
            self.conn.close()
            self.conn = None
    
    def notify_run_completed(self, report_payload: dict):
        """Called by curator after a run to store the record."""
        if not self._initialized:
            logger.warning("Provider not initialized, cannot store run.")
            return
        run_id = report_payload.get('run_id', datetime.utcnow().strftime('%Y%m%d-%H%M%S'))
        self.conn.execute("""
            INSERT OR REPLACE INTO curator_runs 
            (run_id, started_at, duration_seconds, model, provider, auto_counts, 
             consolidated_count, pruned_count, added_count, cron_rewrites_count, report_path)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            run_id,
            report_payload.get('started_at'),
            report_payload.get('duration_seconds'),
            report_payload.get('model'),
            report_payload.get('provider'),
            json.dumps(report_payload.get('auto_counts', {})),
            report_payload.get('consolidated_count', 0),
            report_payload.get('pruned_count', 0),
            report_payload.get('added_count', 0),
            report_payload.get('cron_rewrites_count', 0),
            report_payload.get('report_path', '')
        ))
        self.conn.commit()
        logger.info(f"Stored curator run {run_id}")
    
    # Internal helpers
    def _get_last_run(self) -> dict:
        cursor = self.conn.execute("SELECT * FROM curator_runs ORDER BY started_at DESC LIMIT 1")
        row = cursor.fetchone()
        if row:
            return self._row_to_dict(row, cursor.description)
        return None
    
    def _list_recent_runs(self, limit: int) -> list:
        cursor = self.conn.execute("SELECT * FROM curator_runs ORDER BY started_at DESC LIMIT ?", (limit,))
        rows = cursor.fetchall()
        return [self._row_to_dict(row, cursor.description) for row in rows]
    
    def _get_run_by_id(self, run_id: str) -> dict:
        cursor = self.conn.execute("SELECT * FROM curator_runs WHERE run_id = ?", (run_id,))
        row = cursor.fetchone()
        if row:
            return self._row_to_dict(row, cursor.description)
        return None
    
    @staticmethod
    def _row_to_dict(row, description):
        cols = [desc[0] for desc in description]
        d = dict(zip(cols, row))
        if 'auto_counts' in d and isinstance(d['auto_counts'], str):
            d['auto_counts'] = json.loads(d['auto_counts'])
        return d

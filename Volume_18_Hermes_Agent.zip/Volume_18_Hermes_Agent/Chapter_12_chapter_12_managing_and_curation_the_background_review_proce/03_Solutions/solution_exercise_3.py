
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# curator.py (modifications)

def _extract_absorbed_into_declarations(model_yaml: dict) -> list:
    """Extract absorbed_into declarations from model's structured YAML block.
    Returns list of dicts with keys: name, absorbed_into (list or str), is_split (bool), reason (optional).
    """
    declarations = []
    for skill_name, info in model_yaml.get('skills', {}).items():
        absorbed = info.get('absorbed_into')
        if absorbed is None:
            continue
        if isinstance(absorbed, list):
            declarations.append({
                'name': skill_name,
                'absorbed_into': absorbed,
                'is_split': True,
                'reason': info.get('reason', '')
            })
        elif isinstance(absorbed, str) and absorbed:
            declarations.append({
                'name': skill_name,
                'absorbed_into': absorbed,
                'is_split': False,
                'reason': info.get('reason', '')
            })
        # else empty string -> prune, handled elsewhere
    return declarations

def _reconcile_classification(declarations: list) -> dict:
    """Classify removed skills into consolidated, split, pruned."""
    consolidated = []
    split = []
    pruned = []
    for decl in declarations:
        if decl['is_split']:
            split.append({
                'name': decl['name'],
                'targets': decl['absorbed_into'],
                'source': 'absorbed_into (model-declared split)',
                'reason': decl.get('reason', '')
            })
        else:
            consolidated.append({
                'name': decl['name'],
                'into': decl['absorbed_into'],
                'source': 'absorbed_into (model-declared)',
                'reason': decl.get('reason', '')
            })
    # Skills with no absorbed_into (empty string or missing) are pruned
    # This logic assumes we already have a list of all removed skills
    # For simplicity, we also need to handle skills that are in removed list but not in declarations
    # (omitted for brevity, but typical implementation would merge with removed list)
    return {'consolidated': consolidated, 'split': split, 'pruned': pruned}

def _render_report_markdown(report_data: dict) -> str:
    """Generate markdown report with new split section."""
    lines = []
    # ... existing sections ...
    
    # Split skills section
    split_skills = report_data.get('split', [])
    if split_skills:
        lines.append(f"### Split skills ({len(split_skills)})")
        lines.append("_These skills were divided into multiple umbrellas. Each original is archived; its content lives in the listed destinations._")
        for s in split_skills:
            targets = ', '.join(s['targets'])
            lines.append(f"- `{s['name']}` → split into `{targets}`")
        lines.append("")
    
    # Consolidated and pruned sections follow...
    return '\n'.join(lines)

def _classify_removed_skills(skill_actions: list) -> dict:
    """Heuristic classification for cron rewriting: ensure split skills are not misclassified as pruned."""
    # This function is used when model YAML is not available (e.g., from tool calls)
    # We check if absorbed_into is a list -> split, else if string -> consolidated, else -> pruned
    consolidated = []
    split = []
    pruned = []
    for action in skill_actions:
        if action.get('action') == 'delete':
            absorbed = action.get('absorbed_into')
            if isinstance(absorbed, list) and len(absorbed) > 0:
                split.append(action)
            elif isinstance(absorbed, str) and absorbed:
                consolidated.append(action)
            else:
                pruned.append(action)
    return {'consolidated': consolidated, 'split': split, 'pruned': pruned}

# In cron job rewriting function, handle split:
def _rewrite_cron_jobs_for_split(skill_name: str, target_skills: list):
    """Replace references to old skill with all target skills in cron jobs."""
    from cron.jobs import list_jobs, rewrite_skill_refs
    jobs = list_jobs()
    for job in jobs:
        if skill_name in job.get('skill_refs', []):
            new_refs = [ref for ref in job['skill_refs'] if ref != skill_name]
            new_refs.extend(target_skills)
            rewrite_skill_refs(job['id'], new_refs)

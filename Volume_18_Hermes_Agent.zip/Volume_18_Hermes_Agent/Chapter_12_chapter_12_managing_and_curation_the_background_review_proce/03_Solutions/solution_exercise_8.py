
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_8.py
# Description: Solution for Exercise 8
# ==========================================

# scripts/curator_weekly_analysis.py
#!/usr/bin/env python3
import argparse
import json
import logging
import sys
from datetime import datetime, timedelta
from pathlib import Path
from collections import Counter

# Assume these imports exist
from agent.curator import _reports_root  # function to get reports base directory
from agent.session_db import SessionDB

logger = logging.getLogger(__name__)

def discover_reports(days: int = 30) -> list:
    """Return list of run dicts from reports within the last `days` days."""
    base = _reports_root()
    if not base.exists():
        logger.warning(f"Reports directory {base} does not exist.")
        return []
    
    cutoff = datetime.utcnow() - timedelta(days=days)
    reports = []
    for subdir in base.iterdir():
        if not subdir.is_dir():
            continue
        # Try to parse timestamp from directory name (YYYYMMDD-HHMMSS possibly with suffix)
        try:
            dirname = subdir.name
            timestamp_str = dirname.split('-')[0] + '-' + dirname.split('-')[1]  # e.g., 20250310-123456
            dir_time = datetime.strptime(timestamp_str, '%Y%m%d-%H%M%S')
        except (ValueError, IndexError):
            logger.debug(f"Skipping directory {subdir.name}: cannot parse timestamp")
            continue
        if dir_time < cutoff:
            continue
        
        run_json = subdir / 'run.json'
        if not run_json.exists():
            continue
        try:
            with open(run_json, 'r') as f:
                data = json.load(f)
            data['_dir'] = str(subdir)
            reports.append(data)
        except (json.JSONDecodeError, OSError) as e:
            logger.warning(f"Could not read {run_json}: {e}")
            continue
    return reports

def aggregate(reports: list) -> dict:
    """Compute statistics over the list of report dicts."""
    total_runs = len(reports)
    total_consolidated = sum(r.get('consolidated_this_run', 0) for r in reports)
    total_pruned = sum(r.get('pruned_this_run', 0) for r in reports)
    total_auto_archived = sum(r.get('auto_transitions', {}).get('archived', 0) for r in reports)
    total_cron_rewrites = sum(r.get('cron_rewrites', {}).get('jobs_updated', 0) for r in reports)
    
    # Average duration in minutes
    durations = [r.get('duration_seconds', 0) for r in reports if r.get('duration_seconds')]
    avg_duration_seconds = sum(durations) / len(durations) if durations else 0
    avg_duration_minutes = avg_duration_seconds / 60
    
    # Most frequent provider/model pair
    provider_model_pairs = [(r.get('provider', '?'), r.get('model', '?')) for r in reports]
    mode_pair = Counter(provider_model_pairs).most_common(1)
    avg_model = f"{mode_pair[0][0][0]}/{mode_pair[0][0][1]}" if mode_pair else "N/A"
    
    # Top 5 consolidated umbrella skills (into field)
    into_counter = Counter()
    for r in reports:
        for cons in r.get('consolidations', []):  # assume list of dicts with 'into'
            into_counter[cons.get('into', 'unknown')] += 1
    top_umbrellas = [skill for skill, _ in into_counter.most_common(5)]
    
    return {
        'total_runs': total_runs,
        'total_consolidated': total_consolidated,
        'total_pruned': total_pruned,
        'total_auto_archived': total_auto_archived,
        'total_cron_rewrites': total_cron_rewrites,
        'avg_duration_minutes': round(avg_duration_minutes, 2),
        'avg_model': avg_model,
        'top_umbrellas': top_umbrellas
    }

def store_in_sessiondb(stats: dict, week_start: str):
    """Store stats in SessionDB with appropriate keys."""
    try:
        db = SessionDB.get_instance()
        # Store individual fields
        for key, value in stats.items():
            db.set_meta(f"curator_weekly_summary_{week_start}_{key}", value)
        # Store human-readable summary
        summary_lines = [
            f"Curator Weekly Summary (week starting {week_start})",
            f"  Runs: {stats['total_runs']}",
            f"  Consolidated: {stats['total_consolidated']}",
            f"  Pruned: {stats['total_pruned']}",
            f"  Auto-archived: {stats['total_auto_archived']}",
            f"  Cron rewrites: {stats['total_cron_rewrites']}",
            f"  Avg duration: {stats['avg_duration_minutes']} min",
            f"  Most common model: {stats['avg_model']}",
            f"  Top umbrellas: {', '.join(stats['top_umbrellas'])}"
        ]
        summary_str = '\n'.join(summary_lines)
        db.set_meta("curator_weekly_summary_last", summary_str)
    except Exception as e:
        logger.error(f"Failed to store in SessionDB: {e}")
        print(f"Warning: Could not store to SessionDB: {e}", file=sys.stderr)

def print_table(stats: dict, week_start: str):
    """Print a clean table to stdout."""
    print(f"\nCurator Activity Summary - Week starting {week_start}")
    print("-" * 50)
    print(f"{'Metric':<30} {'Value':<20}")
    print("-" * 50)
    print(f"{'Total runs':<30} {stats['total_runs']:<20}")
    print(f"{'Skills consolidated':<30} {stats['total_consolidated']:<20}")
    print(f"{'Skills pruned':<30} {stats['total_pruned']:<20}")
    print(f"{'Auto-archived':<30} {stats['total_auto_archived']:<20}")
    print(f"{'Cron rewrites':<30} {stats['total_cron_rewrites']:<20}")
    print(f"{'Avg duration (min)':<30} {stats['avg_duration_minutes']:<20}")
    print(f"{'Most common model':<30} {stats['avg_model']:<20}")
    print(f"{'Top umbrellas':<30} {', '.join(stats['top_umbrellas']):<20}")
    print("-" * 50)

def main():
    parser = argparse.ArgumentParser(description="Analyze curator effectiveness over recent days.")
    parser.add_argument('--days', type=int, default=30, help='Number of days to look back (default: 30)')
    parser.add_argument('--store', action='store_true', help='Store results in SessionDB')
    args = parser.parse_args()
    
    reports = discover_reports(days=args.days)
    if not reports:
        print("No curator reports found in the specified period.")
        return
    
    stats = aggregate(reports)
    week_start = (datetime.utcnow() - timedelta(days=args.days)).strftime('%Y-%m-%d')
    
    if args.store:
        store_in_sessiondb(stats, week_start)
        print("Results stored in SessionDB.")
    else:
        print_table(stats, week_start)

if __name__ == '__main__':
    main()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# In memory_manager.py (partial addition)
class MemoryManager:
    def __init__(self, config):
        self.providers = []
        self.builtin_provider = ...  # existing
        # Register external provider if configured
        if config.get('memory', {}).get('provider') == 'curator_history':
            from agent.memory_providers.curator_history import CuratorHistoryProvider
            self.add_provider(CuratorHistoryProvider())
    
    def add_provider(self, provider: MemoryProvider):
        """Allow exactly one external provider."""
        if len(self.providers) > 0:
            logger.warning("Only one external memory provider allowed. Skipping.")
            return
        self.providers.append(provider)
    
    def notify_curator_run_completed(self, report_payload: dict):
        """Called by curator after a run to notify all providers."""
        for provider in self.providers:
            if hasattr(provider, 'notify_run_completed'):
                provider.notify_run_completed(report_payload)

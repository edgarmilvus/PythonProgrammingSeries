
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_6.py
# Description: Solution for Exercise 6
# ==========================================

# scripts/curator_with_precheck.py
import os
import sys
import json
from datetime import datetime
from pathlib import Path
import logging

# Assume these imports exist
from agent.curator import run_curator_review, skill_usage
from agent.session_db import SessionDB
from cron.jobs import list_jobs, rewrite_skill_refs  # may be unavailable

logger = logging.getLogger(__name__)

def validate_cron_dependencies(before_report: list, automatic_counts: dict) -> list:
    """
    Check if any skills about to be auto-archived or auto-stale are referenced in cron jobs.
    Returns list of warnings: [(skill_name, job_name), ...]
    """
    warnings = []
    try:
        from cron.jobs import list_jobs
        jobs = list_jobs()
    except ImportError:
        logger.warning("cron.jobs module not available; skipping dependency check.")
        return warnings
    
    # Identify skills that will be auto-archived or auto-stale
    at_risk_skills = set()
    # automatic_counts might contain 'archived' and 'stale' keys with lists
    for status in ['archived', 'stale']:
        at_risk_skills.update(automatic_counts.get(status, []))
    
    # Also include skills from before_report that are about to be reviewed (e.g., all agent-created)
    # For simplicity, we consider all skills in before_report as candidates for LLM review
    # But the user may want to check only those that will be removed. We'll check all.
    # Actually the problem says "skills that are about to be auto-archived or auto-marked stale"
    # So we use automatic_counts.
    
    for skill_name in at_risk_skills:
        for job in jobs:
            if skill_name in job.get('skill_refs', []):
                warnings.append((skill_name, job.get('name', job.get('id', 'unknown'))))
    return warnings

def main():
    # Check if curator is enabled
    from agent.config import config
    if not config.get('curator', {}).get('enabled', True):
        print("Curator is disabled. Exiting.")
        return
    
    # Load before_report
    before_report = skill_usage.agent_created_report()
    if not before_report:
        print("No agent-created skills to review. Exiting.")
        return
    
    # Simulate automatic transitions to get counts (or we can run apply_automatic_transitions)
    # For simplicity, we assume automatic_counts is provided by a function
    from agent.curator import apply_automatic_transitions
    auto_result = apply_automatic_transitions()  # returns dict with 'archived', 'stale' etc.
    automatic_counts = auto_result  # but we need just lists; assume it's dict with keys
    
    # Validate
    warnings = validate_cron_dependencies(before_report, automatic_counts)
    
    run_timestamp = datetime.utcnow().strftime('%Y%m%d-%H%M%S')
    decision = 'proceed'
    
    if warnings:
        print("WARNING: The following cron jobs depend on skills that will be affected:")
        for skill, job in warnings:
            print(f"  - Skill '{skill}' is referenced in job '{job}'")
        # Ask user for confirmation (unless FORCE_RUN env var set)
        force = os.environ.get('FORCE_RUN', '').strip()
        if force == '1':
            print("FORCE_RUN set, proceeding without confirmation.")
        else:
            response = input("Proceed with curator run? [y/N] ").strip().lower()
            if response != 'y':
                print("Curator run aborted by user.")
                decision = 'aborted'
                # Record decision
                record_precheck(run_timestamp, warnings, decision)
                return
    
    # Proceed with curator run
    def my_summary(msg):
        print(f"[CURATOR] {msg}")
    
    try:
        run_curator_review(on_summary=my_summary, synchronous=True)
        outcome = 'success'
    except Exception as e:
        logger.exception("Curator run failed")
        outcome = 'failure'
    
    # Record outcome
    record_precheck(run_timestamp, warnings, decision, outcome)

def record_precheck(run_timestamp: str, warnings: list, decision: str, outcome: str = None):
    """Store precheck results in SessionDB."""
    try:
        db = SessionDB.get_instance()
        meta_key = f"curator_precheck_{run_timestamp}"
        meta_value = json.dumps({
            'timestamp': run_timestamp,
            'warnings': [{'skill': s, 'job': j} for s, j in warnings],
            'decision': decision,
            'outcome': outcome
        })
        db.set_meta(meta_key, meta_value)
    except Exception as e:
        logger.error(f"Failed to record precheck in SessionDB: {e}")

if __name__ == '__main__':
    main()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# tests/curator/test_automatic_transitions.py
import pytest
from unittest.mock import patch, MagicMock
from datetime import datetime, timedelta
import tempfile
from pathlib import Path
import yaml

from agent.curator import apply_automatic_transitions, _load_skill_thresholds

def test_custom_thresholds_postpone_staleness():
    """Skill with custom stale_after_days=50 should not be stale when last activity is 40 days ago."""
    now = datetime(2025, 3, 15, 12, 0, 0)
    last_activity = now - timedelta(days=40)  # 40 days ago
    
    # Create temporary skill directory with curator.yaml
    with tempfile.TemporaryDirectory() as tmpdir:
        skill_dir = Path(tmpdir) / 'test-skill'
        skill_dir.mkdir()
        yaml_content = {'curator': {'stale_after_days': 50, 'archive_after_days': 150}}
        with open(skill_dir / 'curator.yaml', 'w') as f:
            yaml.dump(yaml_content, f)
        
        # Mock agent_created_report to return this skill
        mock_report = [{'name': 'test-skill', 'last_activity_at': last_activity, 'base_path': skill_dir, 'pinned': False}]
        with patch('agent.curator.skill_usage.agent_created_report', return_value=mock_report):
            # We need to capture transition decisions; assume function returns dict of actions
            # For simplicity, we just check that skill is not marked stale
            # In real code we would inspect internal state or return value
            result = apply_automatic_transitions(now=now)
            # Assert skill not in stale list (if function returns such)
            # Here we assume result contains 'stale_skills' list
            assert 'test-skill' not in result.get('stale_skills', [])

def test_custom_archive_early():
    """Skill with archive_after_days=1 and last activity older than 1 day should be archived."""
    now = datetime(2025, 3, 15, 12, 0, 0)
    last_activity = now - timedelta(days=2)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        skill_dir = Path(tmpdir) / 'old-skill'
        skill_dir.mkdir()
        yaml_content = {'curator': {'archive_after_days': 1}}
        with open(skill_dir / 'curator.yaml', 'w') as f:
            yaml.dump(yaml_content, f)
        
        mock_report = [{'name': 'old-skill', 'last_activity_at': last_activity, 'base_path': skill_dir, 'pinned': False}]
        with patch('agent.curator.skill_usage.agent_created_report', return_value=mock_report):
            result = apply_automatic_transitions(now=now)
            assert 'old-skill' in result.get('archived_skills', [])

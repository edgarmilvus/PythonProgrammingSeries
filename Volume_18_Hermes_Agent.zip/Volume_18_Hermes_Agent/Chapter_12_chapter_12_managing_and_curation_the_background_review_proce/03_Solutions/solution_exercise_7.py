
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_7.py
# Description: Solution for Exercise 7
# ==========================================

# tests/curator/test_precheck.py
import pytest
from unittest.mock import patch, MagicMock
from scripts.curator_with_precheck import validate_cron_dependencies

def test_validation_finds_warning():
    """Test that a skill referenced in a cron job is flagged."""
    mock_jobs = [
        {'id': 'job1', 'name': 'daily-report', 'skill_refs': ['my-old-skill']}
    ]
    with patch('scripts.curator_with_precheck.list_jobs', return_value=mock_jobs):
        before_report = [{'name': 'my-old-skill', 'last_activity_at': '...'}]
        automatic_counts = {'archived': ['my-old-skill'], 'stale': []}
        warnings = validate_cron_dependencies(before_report, automatic_counts)
        assert len(warnings) == 1
        assert warnings[0] == ('my-old-skill', 'daily-report')

def test_force_run_bypasses_confirmation(monkeypatch):
    """Test that FORCE_RUN=1 skips interactive prompt."""
    monkeypatch.setenv('FORCE_RUN', '1')
    # In main(), we would check that input is not called; we can test by mocking input
    # For simplicity, we verify the logic in main() would proceed.
    # This test is more of an integration test; here we just assert env var is set.
    assert os.environ.get('FORCE_RUN') == '1'

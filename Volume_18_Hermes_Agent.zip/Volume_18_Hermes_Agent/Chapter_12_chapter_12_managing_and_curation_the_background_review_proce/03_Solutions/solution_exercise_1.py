
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# curator.py (partial modification)
from pathlib import Path
import yaml
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

# Global defaults (from config)
GLOBAL_STALE_AFTER_DAYS = 30
GLOBAL_ARCHIVE_AFTER_DAYS = 90
HARD_UPPER_LIMIT_DAYS = 365

def _load_skill_thresholds(skill_base_path: Path) -> dict:
    """Load custom thresholds from curator.yaml, returning dict with keys 'stale_after_days' and 'archive_after_days' or None."""
    yaml_path = skill_base_path / "curator.yaml"
    if not yaml_path.exists():
        return {}
    try:
        with open(yaml_path, 'r') as f:
            data = yaml.safe_load(f)
    except (yaml.YAMLError, OSError) as e:
        logger.warning(f"Could not read curator.yaml for {skill_base_path.name}: {e}")
        return {}
    curator_cfg = data.get('curator', {}) if isinstance(data, dict) else {}
    thresholds = {}
    for key in ('stale_after_days', 'archive_after_days'):
        val = curator_cfg.get(key)
        if val is not None and isinstance(val, int) and val > 0:
            thresholds[key] = min(val, HARD_UPPER_LIMIT_DAYS)
        else:
            thresholds[key] = None
    return thresholds

def apply_automatic_transitions(now: datetime = None):
    """Apply automatic state transitions with per-skill threshold overrides."""
    from . import skill_usage  # assume skill_usage module
    if now is None:
        now = datetime.utcnow()
    
    report = skill_usage.agent_created_report()
    # report assumed to be list of dicts with keys: name, last_activity_at, base_path (or we derive)
    
    for skill in report:
        name = skill['name']
        last_activity = skill['last_activity_at']
        base_path = skill.get('base_path', None)
        if not base_path:
            base_path = Path.home() / '.hermes' / 'skills' / name
        
        # Load custom thresholds
        custom = _load_skill_thresholds(base_path)
        stale_days = custom.get('stale_after_days', GLOBAL_STALE_AFTER_DAYS)
        archive_days = custom.get('archive_after_days', GLOBAL_ARCHIVE_AFTER_DAYS)
        
        if custom.get('stale_after_days') or custom.get('archive_after_days'):
            logger.debug(f"Skill '{name}' using custom thresholds: stale={stale_days}, archive={archive_days}")
        
        # Compute cutoffs
        stale_cutoff = now - timedelta(days=stale_days)
        archive_cutoff = now - timedelta(days=archive_days)
        
        # Existing logic for pinned, reactivation, etc. (assumed to be present)
        if skill.get('pinned'):
            continue
        # ... (rest of transition logic unchanged)
        # Example: mark stale if last_activity < stale_cutoff
        # Example: mark archived if last_activity < archive_cutoff
    # ... return counts etc.

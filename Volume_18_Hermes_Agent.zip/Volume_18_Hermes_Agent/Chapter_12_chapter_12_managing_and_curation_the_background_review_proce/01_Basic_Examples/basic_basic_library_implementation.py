
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation.py
# Description: Basic Library Implementation
# ==========================================

#!/usr/bin/env python3
"""
Basic Curator Integration Example

Demonstrates how to initialise and run the Hermes Agent's background
skill curator using the real classes from agent/curator.py.
"""

from __future__ import annotations

import logging
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

# Import real Hermes curator components
from agent.curator import (
    load_state,
    save_state,
    is_enabled,
    is_paused,
    should_run_now,
    apply_automatic_transitions,
    run_curator_review,
    set_paused,
    get_interval_hours,
    get_min_idle_hours,
    get_stale_after_days,
    get_archive_after_days,
)
from hermes_constants import get_hermes_home

# Configure logging (curator logs to agent.log by default)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    stream=sys.stdout,
)
logger = logging.getLogger("curator_example")


def main() -> None:
    """
    Main routine: check gates, run automatic transitions, optionally
    start the LLM review pass, and report results.
    """
    # ------------------------------------------------------------------
    # 1. Load curator state from ~/.hermes/skills/.curator_state
    # ------------------------------------------------------------------
    state: Dict[str, Any] = load_state()
    logger.info("Curator state loaded. Last run: %s", state.get("last_run_at", "never"))

    # ------------------------------------------------------------------
    # 2. Verify the curator is enabled and not paused
    # ------------------------------------------------------------------
    if not is_enabled():
        logger.info("Curator is disabled in config.yaml (curator.enabled = false). Exiting.")
        return

    if is_paused():
        logger.info("Curator is paused. Use `hermes curator resume` to re-enable. Exiting.")
        return

    # ------------------------------------------------------------------
    # 3. Check if enough time has passed since the last run
    # ------------------------------------------------------------------
    if not should_run_now():
        logger.info(
            "Not yet time for next curator run. Interval: %d hours. Skipping.",
            get_interval_hours(),
        )
        return

    # ------------------------------------------------------------------
    # 4. (Optional) Idle gating – only run if the agent has been idle
    #    for at least min_idle_hours. In a real integration you would
    #    measure actual idle time; here we assume 3 hours of idle.
    # ------------------------------------------------------------------
    assumed_idle_seconds = 3 * 3600  # 3 hours
    min_idle_seconds = get_min_idle_hours() * 3600.0
    if assumed_idle_seconds < min_idle_seconds:
        logger.info(
            "Agent idle time (%d s) below minimum (%d s). Skipping.",
            assumed_idle_seconds, min_idle_seconds,
        )
        return

    # ------------------------------------------------------------------
    # 5. Run automatic state transitions (pure, no LLM)
    # ------------------------------------------------------------------
    logger.info("Applying automatic state transitions...")
    auto_counts: Dict[str, int] = apply_automatic_transitions()
    logger.info(
        "Auto transitions: checked=%d, stale=%d, archived=%d, reactivated=%d",
        auto_counts.get("checked", 0),
        auto_counts.get("marked_stale", 0),
        auto_counts.get("archived", 0),
        auto_counts.get("reactivated", 0),
    )

    # ------------------------------------------------------------------
    # 6. Start the LLM consolidation pass (runs in background thread)
    # ------------------------------------------------------------------
    logger.info("Starting LLM consolidation pass...")
    result: Dict[str, Any] = run_curator_review(
        on_summary=lambda msg: logger.info("Curator summary: %s", msg),
        synchronous=False,   # runs in daemon thread
        dry_run=False,       # set True for preview only
    )
    logger.info(
        "LLM pass started at %s. Auto transitions summary: %s",
        result.get("started_at", "?"),
        result.get("summary_so_far", "?"),
    )

    # ------------------------------------------------------------------
    # 7. The curator state is updated automatically by run_curator_review.
    #    We can inspect the updated state to see the new last_run_at.
    # ------------------------------------------------------------------
    updated_state = load_state()
    logger.info("Curator run completed. New last_run_at: %s", updated_state.get("last_run_at"))
    logger.info("Run count: %d", updated_state.get("run_count", 0))

    # ------------------------------------------------------------------
    # 8. (Optional) Print the last report path for human review
    # ------------------------------------------------------------------
    report_path = updated_state.get("last_report_path")
    if report_path:
        logger.info("Full report written to: %s", report_path)


if __name__ == "__main__":
    main()

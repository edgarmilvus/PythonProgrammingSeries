
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script.py
# Description: Advanced Integration Script
# ==========================================

#!/usr/bin/env python3
"""
Curator Integration Service — production-grade background skill maintenance.

This module wires the Hermes curator into a custom application. It manages:
- A primary AIAgent for user-facing conversations.
- A background thread that periodically invokes the curator.
- A callback that logs curator summaries and triggers webhook notifications.
- Safe concurrent access to state.db via SessionDB.
- Graceful shutdown on SIGINT/SIGTERM.

Usage:
    $ python curator_integration.py --config /path/to/config.yaml
"""

import asyncio
import json
import logging
import os
import signal
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

# --- Hermes Agent imports (actual library) ---
from run_agent import AIAgent
from agent.curator import (
    maybe_run_curator,
    run_curator_review,
    load_state,
    set_paused,
    is_paused,
    is_enabled,
    get_interval_hours,
    get_min_idle_hours,
    _reports_root,
)
from agent.memory_manager import MemoryManager, StreamingContextScrubber
from hermes_state import SessionDB
from hermes_constants import get_hermes_home

# ---------------------------------------------------------------------------
# Configuration constants — normally loaded from config.yaml
# ---------------------------------------------------------------------------

DEFAULT_CONFIG = {
    "curator": {
        "enabled": True,
        "interval_hours": 24 * 7,       # 7 days
        "min_idle_hours": 2,
        "stale_after_days": 30,
        "archive_after_days": 90,
        "dry_run_first": True,           # first pass is always dry-run
    },
    "model": {
        "provider": "openai",
        "default": "gpt-4o",
    },
    "auxiliary": {
        "curator": {
            "provider": "openai",
            "model": "gpt-4o-mini",      # cheaper model for curator
            "timeout": 120,
        }
    },
    "memory": {
        "provider": "builtin",
    },
}

# ---------------------------------------------------------------------------
# Custom webhook notifier — sends curator reports to an external endpoint
# ---------------------------------------------------------------------------

class WebhookNotifier:
    """Sends curator report summaries to a webhook URL.

    In production, replace this with your own notification system
    (Slack, email, PagerDuty, etc.).
    """

    def __init__(self, webhook_url: str):
        self._url = webhook_url
        self._session = None  # would use aiohttp or requests

    async def send_summary(self, summary: str, report_path: Optional[Path] = None):
        """Send a curator summary to the webhook.

        In a real implementation, this would POST a JSON payload.
        Here we just log it.
        """
        logging.info("Webhook would send: %s (report: %s)", summary, report_path)
        # In production:
        # async with aiohttp.ClientSession() as session:
        #     await session.post(self._url, json={"summary": summary, "report": str(report_path)})

# ---------------------------------------------------------------------------
# The main integration service
# ---------------------------------------------------------------------------

class CuratorIntegrationService:
    """Production-grade service that manages an AIAgent and its background curator.

    This class demonstrates:
    - Initializing the agent with memory and skill tools.
    - Running the curator on a background thread with idle gating.
    - Handling dry-run vs live passes.
    - Reacting to curator reports via callbacks.
    - Graceful shutdown.

    Usage:
        service = CuratorIntegrationService(config_path="/path/to/config.yaml")
        service.start()
        # ... service runs until Ctrl+C ...
        service.stop()
    """

    def __init__(self, config_path: Optional[str] = None):
        self._config = self._load_config(config_path)
        self._hermes_home = get_hermes_home()
        self._db = SessionDB()
        self._memory_manager = MemoryManager()
        self._notifier = WebhookNotifier(
            webhook_url=os.environ.get("CURATOR_WEBHOOK_URL", "https://hooks.example.com/curator")
        )

        # The primary agent — used for user conversations.
        # In a real service, you might create one per session.
        self._agent: Optional[AIAgent] = None

        # Background curator thread
        self._curator_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._curator_lock = threading.Lock()  # prevent concurrent curator runs

        # Track last curator run for idle gating
        self._last_curator_run: float = 0.0

        # Register signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

    # -----------------------------------------------------------------------
    # Configuration loading (simplified)
    # -----------------------------------------------------------------------

    def _load_config(self, path: Optional[str]) -> Dict[str, Any]:
        """Load config from YAML file or return defaults.

        In production, use `hermes_cli.config.load_config()`.
        """
        if path:
            try:
                import yaml
                with open(path, "r") as f:
                    cfg = yaml.safe_load(f)
                return cfg or DEFAULT_CONFIG
            except Exception as e:
                logging.warning("Failed to load config from %s: %s. Using defaults.", path, e)
        return DEFAULT_CONFIG

    # -----------------------------------------------------------------------
    # Agent initialization
    # -----------------------------------------------------------------------

    def _create_agent(self) -> AIAgent:
        """Create and configure the primary AIAgent.

        This mirrors the logic in `run_agent.py` but is customised
        for this integration service.
        """
        model_cfg = self._config.get("model", {})
        provider = model_cfg.get("provider", "openai")
        model = model_cfg.get("default", "gpt-4o")

        agent = AIAgent(
            model=model,
            provider=provider,
            api_key=os.environ.get("OPENAI_API_KEY"),
            base_url=None,
            api_mode="chat",
            max_iterations=50,
            quiet_mode=False,
            platform="integration_service",
            skip_context_files=False,
            skip_memory=False,
        )

        # Attach memory manager (builtin provider)
        # The builtin provider is automatically added by AIAgent,
        # but we demonstrate how to add an external one.
        self._memory_manager.add_provider(agent._memory_provider)  # builtin

        # In a real service, you might also add a custom memory provider:
        # from agent.memory_provider import MyCustomProvider
        # self._memory_manager.add_provider(MyCustomProvider())

        return agent

    # -----------------------------------------------------------------------
    # Curator lifecycle
    # -----------------------------------------------------------------------

    def _curator_summary_callback(self, summary: str) -> None:
        """Called by the curator after each pass.

        This callback runs in the curator's background thread.
        It logs the summary and sends a webhook notification.
        """
        logging.info("Curator summary: %s", summary)

        # Read the latest report path from curator state
        state = load_state()
        report_path_str = state.get("last_report_path")
        report_path = Path(report_path_str) if report_path_str else None

        # Send notification asynchronously (in a real service, use an event loop)
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop.run_until_complete(
                self._notifier.send_summary(summary, report_path)
            )
            loop.close()
        except Exception as e:
            logging.error("Webhook notification failed: %s", e)

    def _run_curator_pass(self, dry_run: bool = False) -> None:
        """Execute a single curator pass with proper locking.

        This method is called from the background thread.
        """
        with self._curator_lock:
            logging.info("Starting curator pass (dry_run=%s)", dry_run)
            try:
                result = run_curator_review(
                    on_summary=self._curator_summary_callback,
                    synchronous=True,   # run in this thread
                    dry_run=dry_run,
                )
                self._last_curator_run = time.time()
                logging.info(
                    "Curator pass completed: %s",
                    result.get("summary_so_far", "no summary"),
                )
            except Exception as e:
                logging.error("Curator pass failed: %s", e, exc_info=True)

    def _curator_loop(self) -> None:
        """Background thread that periodically invokes the curator.

        Uses `maybe_run_curator()` for automatic gating, but also
        enforces a minimum idle time since the last agent activity.
        """
        while not self._stop_event.is_set():
            # Check if curator should run now (static gates: enabled, not paused, interval elapsed)
            # The `should_run_now()` function from curator.py is called internally.
            # We also enforce idle time: the agent must have been idle for at least min_idle_hours.
            idle_seconds = time.time() - self._last_curator_run
            min_idle = get_min_idle_hours() * 3600.0

            if idle_seconds >= min_idle:
                # maybe_run_curator() checks all gates and spawns a thread.
                # We call it with synchronous=False (default) so it returns immediately.
                # The curator runs in a daemon thread internally.
                result = maybe_run_curator(
                    idle_for_seconds=idle_seconds,
                    on_summary=self._curator_summary_callback,
                )
                if result is not None:
                    logging.info("Curator pass started: %s", result.get("started_at"))
                    # Wait for the internal thread to finish (optional)
                    # In production, we might want to block until done.
                    time.sleep(5)  # give it a moment to start
            else:
                logging.debug("Skipping curator: idle time %.0f < min %.0f", idle_seconds, min_idle)

            # Sleep for a fraction of the interval, then check again
            # This is a polling loop; in production use a more sophisticated scheduler.
            sleep_seconds = min(3600, get_interval_hours() * 3600 / 10)  # every 10% of interval
            self._stop_event.wait(timeout=sleep_seconds)

    # -----------------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------------

    def start(self) -> None:
        """Start the integration service.

        Initializes the agent, runs an initial dry-run curator pass,
        then starts the background curator loop.
        """
        logging.info("Starting CuratorIntegrationService...")

        # Ensure Hermes home exists
        get_hermes_home().mkdir(parents=True, exist_ok=True)

        # Create the primary agent
        self._agent = self._create_agent()
        logging.info("Primary agent created (model=%s, provider=%s)",
                      self._agent.model, self._agent.provider)

        # Run an initial dry-run curator pass to preview what would happen.
        # This is useful for first-time setup.
        if self._config.get("curator", {}).get("dry_run_first", True):
            logging.info("Running initial dry-run curator pass...")
            self._run_curator_pass(dry_run=True)

        # Start the background curator thread
        self._curator_thread = threading.Thread(
            target=self._curator_loop,
            daemon=True,
            name="curator-loop",
        )
        self._curator_thread.start()
        logging.info("Background curator loop started.")

        # In a real service, you would now enter the main application loop
        # (e.g., a web server, CLI REPL, or message queue consumer).
        # Here we just block until stop is requested.
        logging.info("Service running. Press Ctrl+C to stop.")
        self._stop_event.wait()

    def stop(self) -> None:
        """Gracefully stop the service.

        Signals the curator loop to stop, waits for it, and cleans up.
        """
        logging.info("Stopping CuratorIntegrationService...")
        self._stop_event.set()

        if self._curator_thread and self._curator_thread.is_alive():
            self._curator_thread.join(timeout=10)
            logging.info("Curator thread stopped.")

        if self._agent:
            try:
                self._agent.close()
                logging.info("Primary agent closed.")
            except Exception as e:
                logging.error("Error closing agent: %s", e)

        self._db.close()
        logging.info("Service stopped.")

    def _signal_handler(self, signum: int, frame) -> None:
        """Handle SIGINT/SIGTERM by stopping the service."""
        logging.info("Received signal %s, shutting down...", signum)
        self.stop()
        sys.exit(0)

    # -----------------------------------------------------------------------
    # Utility: read the latest curator report
    # -----------------------------------------------------------------------

    def read_latest_report(self) -> Optional[Dict[str, Any]]:
        """Read the JSON report from the most recent curator run.

        Returns the parsed run.json dict, or None if no report exists.
        """
        state = load_state()
        report_path_str = state.get("last_report_path")
        if not report_path_str:
            return None
        report_path = Path(report_path_str) / "run.json"
        if not report_path.exists():
            return None
        try:
            with open(report_path, "r") as f:
                return json.load(f)
        except Exception as e:
            logging.error("Failed to read report %s: %s", report_path, e)
            return None

    # -----------------------------------------------------------------------
    # Manual curator invocation (for CLI or API)
    # -----------------------------------------------------------------------

    def run_curator_now(self, dry_run: bool = False) -> Dict[str, Any]:
        """Manually trigger a curator pass, bypassing the interval gate.

        Returns the result dict from run_curator_review.
        """
        logging.info("Manual curator invocation (dry_run=%s)", dry_run)
        return run_curator_review(
            on_summary=self._curator_summary_callback,
            synchronous=True,
            dry_run=dry_run,
        )

    def set_curator_paused(self, paused: bool) -> None:
        """Pause or resume the background curator."""
        set_paused(paused)
        logging.info("Curator paused=%s", paused)

    # -----------------------------------------------------------------------
    # Example: integrate with a web framework (Flask/FastAPI)
    # -----------------------------------------------------------------------

    def create_flask_blueprint(self):
        """Return a Flask Blueprint with curator endpoints.

        This demonstrates how to expose curator operations via HTTP.
        Requires Flask installed.
        """
        from flask import Blueprint, jsonify, request

        bp = Blueprint("curator", __name__, url_prefix="/curator")

        @bp.route("/status", methods=["GET"])
        def status():
            state = load_state()
            return jsonify({
                "enabled": is_enabled(),
                "paused": is_paused(),
                "last_run_at": state.get("last_run_at"),
                "last_run_summary": state.get("last_run_summary"),
                "last_report_path": state.get("last_report_path"),
                "interval_hours": get_interval_hours(),
            })

        @bp.route("/run", methods=["POST"])
        def run():
            data = request.get_json(silent=True) or {}
            dry_run = data.get("dry_run", False)
            result = self.run_curator_now(dry_run=dry_run)
            return jsonify(result)

        @bp.route("/pause", methods=["POST"])
        def pause():
            data = request.get_json(silent=True) or {}
            paused = data.get("paused", True)
            self.set_curator_paused(paused)
            return jsonify({"paused": paused})

        @bp.route("/report", methods=["GET"])
        def report():
            report = self.read_latest_report()
            if report:
                return jsonify(report)
            return jsonify({"error": "No report found"}), 404

        return bp


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    # Parse command line arguments (simplified)
    config_path = None
    if len(sys.argv) > 2 and sys.argv[1] == "--config":
        config_path = sys.argv[2]

    service = CuratorIntegrationService(config_path=config_path)
    try:
        service.start()
    except KeyboardInterrupt:
        service.stop()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation_part5.py
# Description: Basic Library Implementation
# ==========================================

# anomaly_detector.py (conceptual)

from credential_manager import CredentialManager

class AnomalyDetector:
    def __init__(self, cred_manager: CredentialManager):
        self.cred_manager = cred_manager
        self.call_counter = {}  # simple counting for demo

    def record_call(self, provider: str):
        self.call_counter[provider] = self.call_counter.get(provider, 0) + 1

    def detect_and_rotate(self) -> list:
        """If call frequency exceeds threshold, rotate all credentials for that provider."""
        rotated = []
        for provider, count in self.call_counter.items():
            if count > 100:  # threshold
                # get credential names associated with this provider
                for name, entry in self.cred_manager.list_credentials():
                    if entry.provider == provider and self.cred_manager.needs_rotation(name):
                        new_key = self.get_new_key_from_vault(provider)
                        self.cred_manager.rotate_credential(name, new_key)
                        rotated.append(name)
                self.call_counter[provider] = 0  # reset
        return rotated

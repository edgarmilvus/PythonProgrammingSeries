
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation_part2.py
# Description: Basic Library Implementation
# ==========================================

# input_sanitizer.py

import re
from typing import Set, Tuple

from hermes_logging import setup_logging

logger = setup_logging("input_sanitizer")


class InputSanitizer:
    """Statically‑defined lexical barrier against prompt injection.

    Patterns are chosen to break known attack vectors:
      - Ignore‑all‑previous‑instructions
      - System prompt disclosure
      - Task redirection
      - Role override
      - Code‑execution via shell metacharacters (for tools)
    """

    # (regex, replacement, log_message) triplets
    PROMPT_INJECTION_RULES: Tuple[Tuple[str, str, str], ...] = (
        (r"(?i)ignore\s+all\s+(previous|prior|above)\s+(instructions|commands)",
         "[ignored]",
         "Blocked 'ignore all previous instructions'"),
        (r"(?i)system\s+prompt",
         "[system prompt]",
         "Blocked system prompt reference"),
        (r"(?i)your\s+(new\s+)?task\s+is\s+to",
         "[task redirection]",
         "Blocked task redirection"),
        (r"(?i)you\s+are\s+(now\s+)?(replaced|overridden)",
         "[role override]",
         "Blocked personality override"),
        (r"(?i)repeat\s+(the\s+)?(above|previous)\s+(text|message|prompt)",
         "[repetition attack]",
         "Blocked repetition attack"),
    )

    # Characters that could be used in command injection (shell metacharacters)
    SHELL_METACHARACTERS = set(";|`$(){}&><")
    # Additional pair patterns: $(...), `...`, |...|
    SHELL_INJECTION_PAIRS = [
        ("$(", ")"),
        ("`", "`"),
        ("| ", ""),  # leading pipe
    ]

    @classmethod
    def sanitize(cls, text: str) -> str:
        """Apply all injection‑detection rules and replace dangerous parts.

        Returns the sanitised string.
        """
        original = text
        for pattern, replacement, message in cls.PROMPT_INJECTION_RULES:
            if re.search(pattern, text):
                logger.warning(f"{message} in user input")
                text = re.sub(pattern, replacement, text)

        # Shell metacharacter isolation: replace dangerous characters with neutral text
        for char in cls.SHELL_METACHARACTERS:
            if char in text:
                logger.warning(f"Blocked shell metacharacter '{char}' in input")
                text = text.replace(char, f"[{char}]")

        # Pair‑based detection (e.g., $(cmd) → [blocked cmd])
        for start, end in cls.SHELL_INJECTION_PAIRS:
            if start in text and end in text:
                logger.warning(f"Blocked shell injection pattern '{start}...{end}'")
                # Replace only the matched region – crude but effective for MVP
                text = re.sub(rf'{re.escape(start)}.*?{re.escape(end)}', '[blocked expression]', text)

        if text != original:
            logger.info("Input sanitisation applied")
        return text

    @classmethod
    def is_safe(cls, text: str) -> bool:
        """Return True if the text passes all injection checks without modification."""
        for pattern, _, _ in cls.PROMPT_INJECTION_RULES:
            if re.search(pattern, text):
                return False
        for char in cls.SHELL_METACHARACTERS:
            if char in text:
                return False
        return True


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation.py
# Description: Basic Library Implementation
# ==========================================

# credential_manager.py — Part of the Hermes Agent mitigation library

import os
import json
import hashlib
import time
from typing import Optional, Dict, List
from datetime import datetime, timedelta

from hermes_state import SessionDB
from hermes_constants import get_hermes_home
from hermes_logging import setup_logging
from tools.registry import registry

logger = setup_logging("credential_manager")


class CredentialEntry:
    """Representation of a single credential with its rotation metadata.

    Attributes:
        name (str): Canonical name (e.g. 'openai_api_key').
        hash (str): SHA‑256 hexdigest of the credential value (never stored raw in logs).
        provider (str): Hermes provider or tool that uses this credential.
        expires_at (Optional[datetime]): RFC 3339 expiration, if known.
        created_at (datetime): Time this *version* was stored.
    """
    __slots__ = ('name', 'value', 'hash', 'provider', 'expires_at', 'created_at')

    def __init__(self, name: str, value: str, provider: str,
                 expires_at: Optional[datetime] = None):
        self.name = name
        self.value = value  # stored in‑memory; DB stores in encrypted column (production)
        self.hash = hashlib.sha256(value.encode()).hexdigest()
        self.provider = provider
        self.expires_at = expires_at
        self.created_at = datetime.utcnow()

    def to_dict(self) -> dict:
        """Serialise for logging (never includes self.value)."""
        return {
            "name": self.name,
            "hash": self.hash[:16] + "...",  # truncate for display
            "provider": self.provider,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "created_at": self.created_at.isoformat()
        }


class CredentialManager:
    """Manages the lifecycle of API keys, tokens, and secrets.

    Integrates with Hermes SessionDB for persistent storage across agent restarts,
    and with the AIAgent’s credential pool for live updates.

    Args:
        db: An open SessionDB instance (from ``hermes_state``).
        rotation_interval: Timedelta after which a credential is considered stale.
        encrypt_at_rest: If True (default), values are encrypted before DB write.
    """
    def __init__(self, db: SessionDB,
                 rotation_interval: timedelta = timedelta(days=30),
                 encrypt_at_rest: bool = False):
        self.db = db
        self.rotation_interval = rotation_interval
        self._encrypt = encrypt_at_rest
        self._active_credentials: Dict[str, CredentialEntry] = {}
        self._ensure_schema()
        self._load_from_db()

    # ------------------------------------------------------------------ Schema
    def _ensure_schema(self):
        """Create the credential store table if it doesn't exist."""
        self.db.execute("""
            CREATE TABLE IF NOT EXISTS credentials (
                name TEXT PRIMARY KEY NOT NULL,
                value TEXT NOT NULL,          -- encrypted in production
                hash TEXT NOT NULL,
                provider TEXT DEFAULT '',
                expires_at TEXT,
                created_at TEXT NOT NULL,
                active INTEGER DEFAULT 1
            )
        """)
        self.db.execute("""
            CREATE INDEX IF NOT EXISTS idx_creds_active
            ON credentials(active)
        """)

    # ------------------------------------------------------------------ Load
    def _load_from_db(self):
        """Reload active credentials from SQLite on startup."""
        # note: using raw fetch to avoid fts5 complexity for this core table
        rows = self.db.execute(
            "SELECT name, value, hash, provider, expires_at FROM credentials WHERE active=1"
        ).fetchall()
        for row in rows:
            name, value, hash_, provider, expires_at_str = row
            expires_at = datetime.fromisoformat(expires_at_str) if expires_at_str else None
            entry = CredentialEntry(name, value, provider, expires_at)
            # Verify hash integrity – guards against DB tampering
            if entry.hash != hash_:
                logger.warning(f"Hash mismatch for credential '{name}'; ignoring corrupt entry")
                continue
            self._active_credentials[name] = entry
        logger.info(f"Loaded {len(self._active_credentials)} active credentials")

    # ------------------------------------------------------------------ Store
    def store_credential(self, name: str, value: str, provider: str,
                         expires_at: Optional[datetime] = None):
        """Insert or replace a credential and mark it active.

        If a credential with the same name already exists, the old one is
        archived (active=0) in a separate step – see ``rotate_credential``.
        """
        entry = CredentialEntry(name, value, provider, expires_at)
        self._active_credentials[name] = entry
        self.db.execute(
            "INSERT OR REPLACE INTO credentials (name, value, hash, provider, expires_at, created_at, active) "
            "VALUES (?, ?, ?, ?, ?, ?, 1)",
            (name, value, entry.hash, provider,
             expires_at.isoformat() if expires_at else None,
             entry.created_at.isoformat())
        )
        logger.info(f"Stored credential '{name}' for provider '{provider}' | hash {entry.hash[:16]}...")

    # ------------------------------------------------------------------ Rotate
    def rotate_credential(self, name: str, new_value: str):
        """Rotate an existing credential: archive old, store new, update env.

        Steps:
        1. Retrieve and archive the current credential (set active=0).
        2. Store the new value as the active credential.
        3. Override the corresponding environment variable so that Hermes
           children processes (tools, subagents) immediately see the new key.
        """
        old_entry = self._active_credentials.get(name)
        if old_entry:
            # Archive – keep history for audit
            self.db.execute(
                "UPDATE credentials SET active=0 WHERE name=?", (name,)
            )
            logger.info(f"Archived old credential '{name}' (hash {old_entry.hash[:16]}...)")

        # Store new with a fresh timestamp
        self.store_credential(name, new_value, old_entry.provider if old_entry else "unknown")

        # Update environment – this is the key to zero‑touch rotation
        # The environment variable name is derived from the credential name
        # (e.g. 'OPENAI_API_KEY' for name 'openai_api_key')
        env_name = name.upper()
        os.environ[env_name] = new_value
        logger.info(f"Updated environment variable {env_name} for credential '{name}'")

        # If the credential is part of a Hermes provider config,
        # we could also hot‑reload the provider client here (see section 4/5).

    # ------------------------------------------------------------------ Querying
    def get_credential(self, name: str) -> Optional[str]:
        """Return the value of the active credential, or None."""
        entry = self._active_credentials.get(name)
        return entry.value if entry else None

    def is_expired(self, name: str) -> bool:
        entry = self._active_credentials.get(name)
        if entry and entry.expires_at:
            return datetime.utcnow() > entry.expires_at
        return False

    def needs_rotation(self, name: str) -> bool:
        """Check if a credential should be rotated based on age or expiration."""
        entry = self._active_credentials.get(name)
        if not entry:
            return True  # not stored => urgently needs rotation
        if entry.expires_at and self.is_expired(name):
            logger.info(f"Credential '{name}' has expired at {entry.expires_at}")
            return True
        age = datetime.utcnow() - entry.created_at
        return age >= self.rotation_interval

    def list_credentials(self) -> List[dict]:
        """Return non‑sensitive metadata for all active credentials."""
        return [
            {"name": name, "hash": entry.hash[:16], "provider": entry.provider,
             "expires_at": entry.expires_at.isoformat() if entry.expires_at else None,
             "created_at": entry.created_at.isoformat(),
             "needs_rotation": self.needs_rotation(name)}
            for name, entry in self._active_credentials.items()
        ]

    # ------------------------------------------------------------------ Cleanup
    def archive_all(self):
        """Deactivate all current credentials (e.g. before a full re‑key)."""
        for name in list(self._active_credentials.keys()):
            self.db.execute("UPDATE credentials SET active=0 WHERE name=?", (name,))
        self._active_credentials.clear()
        logger.info("All credentials archived")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation_part3.py
# Description: Basic Library Implementation
# ==========================================

# secure_agent.py — Example of using the library with Hermes' core classes

from hermes_state import SessionDB
from hermes_constants import get_hermes_home
from hermes_logging import setup_logging
from run_agent import AIAgent
from credential_manager import CredentialManager
from input_sanitizer import InputSanitizer

logger = setup_logging("secure_agent")


class SecureAIAgent(AIAgent):
    """An AIAgent that automatically rotates credentials and sanitises inputs.

    Inherits all Hermes functionality (chat, run_conversation, tools, memory).
    Adds:
      - A CredentialManager initialised from the agent's session database.
      - Input sanitisation before every user message.
    """

    def __init__(self, *args, **kwargs):
        # Ensure a session DB is available – the AIAgent creates one internally
        # if session_id is provided. We reuse the same DB for credential storage.
        self._credential_manager = None
        super().__init__(*args, **kwargs)  # AIAgent.__init__ may set self.session_db

        # Only initialise if we have access to a session DB
        if hasattr(self, 'session_db') and self.session_db is not None:
            self._credential_manager = CredentialManager(
                db=self.session_db,
                rotation_interval=timedelta(hours=24)  # aggressive rotation for demo
            )
            logger.info("CredentialManager initialised for SecureAIAgent")
        else:
            logger.warning("No session DB – credential rotation disabled")

    @property
    def credential_manager(self) -> CredentialManager:
        if self._credential_manager is None:
            raise RuntimeError("CredentialManager not initialised (no session DB)")
        return self._credential_manager

    def chat(self, message: str) -> str:
        """Override parent chat to add input sanitisation and credential checks.

        Steps:
        1. Sanitise the incoming message.
        2. Optionally check for stale credentials and trigger rotation.
        3. Delegate to parent's conversation loop.
        """
        # 1. Sanitise
        sanitised_message = InputSanitizer.sanitize(message)
        if sanitised_message != message:
            logger.info(f"Input sanitised: block(s) applied to user message")

        # 2. Quick credential check – rotate if needed before LLM call
        if self._credential_manager:
            for cred_name in ['openai_api_key', 'anthropic_api_key']:
                if self._credential_manager.needs_rotation(cred_name):
                    logger.info(f"Pre‑call rotation needed for '{cred_name}'")
                    # In a real system, the new value comes from a vault;
                    # here we demonstrate the check.
                    new_value = os.getenv(cred_name.upper())  # fallback – not secure
                    if new_value:
                        self._credential_manager.rotate_credential(cred_name, new_value)
                    else:
                        logger.error(f"Cannot rotate '{cred_name}' – no new value available")

        # 3. Delegate to the AIAgent's conversation logic
        return super().chat(sanitised_message)

    def run_conversation(self, user_message: str, **kwargs) -> dict:
        """Override to ensure sanitisation also applies to the full conversation."""
        user_message = InputSanitizer.sanitize(user_message)
        return super().run_conversation(user_message, **kwargs)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# agent/hermetic_context.py
import re
import hashlib
import logging

logger = logging.getLogger("hermes.security")

class HermeticContext:
    def __init__(self, system_prompt: str, tool_schemas: dict):
        self.system_prompt = system_prompt
        self.tool_schemas = tool_schemas
        self._credential_pattern = re.compile(
            r'\b(sk-[a-zA-Z0-9]{20,}|Bearer\s+[a-zA-Z0-9._-]+|api_key\s*=\s*[\'"][^\'"]+[\'"])\b',
            re.IGNORECASE
        )
        self._override_pattern = re.compile(
            r'\b(ignore\s+(previous|all)\s+instructions|you\s+are\s+now\s+a\s+different\s+agent|'
            r'forget\s+(all\s+)?rules)\b',
            re.IGNORECASE
        )

    def sanitize_user_message(self, user_message: str) -> str:
        return self._override_pattern.sub("[REDACTED]", user_message)

    def sanitize_tool_output(self, tool_output: str) -> str:
        # Also sanitize any possible remainders of credentials
        return self._credential_pattern.sub("[REDACTED]", tool_output)

    def is_internal_instruction(self, text: str) -> bool:
        # Catch attempts to modify agent behavior
        return bool(self._override_pattern.search(text))

    def lock_system_prompt(self, new_prompt: str) -> bool:
        # Only allow change if it's exactly the same
        return new_prompt == self.system_prompt

# run_agent.py (modifications in run_conversation)
def run_conversation(self, messages, **kwargs):
    context = HermeticContext(self.system_prompt, self.tool_schemas)
    # Store original system prompt reference
    self._hermetic_context = context
    for turn in range(max_turns):
        user_msg = messages[-1]
        user_msg["content"] = context.sanitize_user_message(user_msg["content"])
        # ... generate response ...
        for tool_call in response.tool_calls:
            tool_info = registry.get(tool_call.function.name)
            if tool_info and tool_info.get("schema", {}).get("hermetic"):
                # Wrap the handler to sanitize output
                def wrapped_handler(args, **kw):
                    result = original_handler(args, **kw)
                    sanitized = context.sanitize_tool_output(result)
                    if sanitized != result:
                        logger.warning(f"Sensitive data redacted from tool output: {tool_call.function.name}")
                        return json.dumps({"info": "Operation completed"})
                    return result
                result = wrapped_handler(...)
            else:
                result = handle_function_call(tool_call, self.agent_context)
            # Add result to conversation history
            messages.append({"role": "tool", "content": context.sanitize_tool_output(result)})

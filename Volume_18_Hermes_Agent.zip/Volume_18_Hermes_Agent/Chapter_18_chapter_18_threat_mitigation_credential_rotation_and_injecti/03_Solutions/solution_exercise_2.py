
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# tools/sanitizer.py
import shlex
import re
from typing import Optional

class CommandSanitizer:
    def __init__(self, allowed_commands: list, max_args_length: int = 512):
        self.allowed = set(allowed_commands)
        self.max_args_length = max_args_length
        # Dangerous patterns (regex)
        self.dangerous = re.compile(
            r'\b(rm\s+-rf\b|mkfs\b|dd\s+if=|:\(\)\s*\{.*\}|wget\s+|curl\s+.*\||'
            r'chmod\s+777\b|sudo\b|su\b|passwd\b|'
            r'/etc/shadow|~/.ssh/|[A-Z_]*KEY[A-Z_]*|[A-Z_]*SECRET[A-Z_]*|[A-Z_]*TOKEN[A-Z_]*|[A-Z_]*PASSWORD[A-Z_]*|'
            r';\s*|\|\s*|&&\s*|`[^`]*`|\$\([^)]*\)|\n)',
            re.IGNORECASE
        )

    def sanitize(self, command: str) -> Optional[str]:
        """Returns sanitized command string or None if rejected."""
        # Check overall length
        if len(command) > self.max_args_length:
            return None
        # Check dangerous patterns
        if self.dangerous.search(command):
            return None
        # Split into base command and arguments
        parts = shlex.split(command)
        if not parts:
            return None
        base = parts[0]
        if base not in self.allowed:
            return None
        # Sanitize each argument
        safe_args = [shlex.quote(arg) for arg in parts[1:]]
        return base + " " + " ".join(safe_args)

# tools/environments/local.py (modified terminal tool)
from tools.sanitizer import CommandSanitizer

def run_command(command: str, agent_ctx: dict = None) -> str:
    config = agent_ctx.get("agent").config
    allowed = config.get("terminal", {}).get("allowed_commands", ["ls", "cat", "echo", "pwd"])
    sanitizer = CommandSanitizer(allowed)
    sanitized = sanitizer.sanitize(command)
    if sanitized is None:
        return json.dumps({"error": "Command not allowed"})
    # Hermetic context override
    hermetic_msg = agent_ctx.get("hermetic_context", "")
    if hermetic_msg:
        # In a real implementation, we would prepend the hermetic instruction
        # to the command (or to the agent's context via a dedicated field).
        # For simplicity, we just log it and trust the sanitizer.
        pass
    result = subprocess.run(sanitized, shell=True, capture_output=True, text=True, timeout=30)
    return json.dumps({"stdout": result.stdout, "stderr": result.stderr, "returncode": result.returncode})

# model_tools.py (handle_function_call modified)
def handle_function_call(tool_call, agent_ctx):
    tool_info = registry.get(tool_call.function.name)
    if tool_info and tool_info.get("schema", {}).get("hermetic_context"):
        # Inject hermetic context into agent_ctx
        agent_ctx["hermetic_context"] = "You are a restricted shell executor..."
    # ... rest of function call handling ...


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# run_agent.py (extended AIAgent __init__ and run_conversation)
import dotenv
from pathlib import Path
from typing import Callable, Optional, Any

class AIAgent:
    def __init__(self, credential_rotator: Optional[Callable[[str], str]] = None, **kwargs):
        # ... existing initialization ...
        self.credential_pool = {}           # populated from .env
        self.credential_rotator = credential_rotator or self._default_rotator
        self._load_credentials()

    def _load_credentials(self):
        # Load env vars that are in credential_pool configuration
        env_path = Path.home() / ".hermes" / ".env"
        if env_path.exists():
            import dotenv
            dotenv.load_dotenv(env_path)
            for name in self.config.get("security", {}).get("credential_rotation", {}).get("credentials", []):
                self.credential_pool[name] = os.environ.get(name, "")

    def _default_rotator(self, credential_name: str) -> str:
        script = self.config.get("security", {}).get("credential_rotation", {}).get("rotator_script", "")
        if not script:
            raise RuntimeError("No rotator script configured")
        result = subprocess.run(script, shell=True, capture_output=True, text=True)
        return result.stdout.strip()

    def run_conversation(self, messages, **kwargs):
        # ... existing loop ...
        for turn in range(max_turns):
            user_msg = messages[-1]
            # 1. sanitize (if hermetic context enabled)
            # ...
            response = self.model.generate(self.system_prompt, messages)
            for tool_call in response.tool_calls:
                result = self._execute_tool_with_retry(tool_call)
                messages.append({"role": "tool", "content": result})
            # ...

    def _execute_tool_with_retry(self, tool_call):
        attempts = self.config.get("security", {}).get("credential_rotation", {}).get("retry_attempts", 2)
        for attempt in range(attempts):
            result = handle_function_call(tool_call, self.credential_pool)
            if isinstance(result, dict) and "error" in result:
                error_text = json.dumps(result).lower()
                expiry_patterns = self.config.get("security", {}).get("credential_rotation", {}).get("expiry_patterns", ["401", "expired", "token_expired"])
                if any(p in error_text for p in expiry_patterns):
                    # Identify which credential to rotate from tool schema
                    tool_name = tool_call.function.name
                    tool_info = registry.get(tool_name)
                    required_creds = tool_info.get("requires_env", [])
                    for cred_name in required_creds:
                        if cred_name in self.credential_pool:
                            new_value = self.credential_rotator(cred_name)
                            self.credential_pool[cred_name] = new_value
                            # persist to .env
                            env_path = Path.home() / ".hermes" / ".env"
                            dotenv.set_key(env_path, cred_name, new_value)
                    # Retry with updated credential
                    continue  # next attempt
            return result
        return result  # final failure

# tools/credential_tool.py – new tool for explicit rotation
from tools.registry import registry
import json, dotenv

def rotate_credential(credential_name: str, agent_ctx: dict = None) -> str:
    agent = agent_ctx.get("agent")
    if credential_name not in agent.credential_pool:
        return json.dumps({"error": f"Credential '{credential_name}' not found."})
    new_value = agent.credential_rotator(credential_name)
    agent.credential_pool[credential_name] = new_value
    env_path = Path.home() / ".hermes" / ".env"
    dotenv.set_key(env_path, credential_name, new_value)
    return json.dumps({"success": f"Credential '{credential_name}' rotated successfully."})

registry.register(
    name="rotate_credential",
    toolset="core",
    schema={
        "name": "rotate_credential",
        "description": "Force rotation of a named credential (e.g., API key). Does not return the new value.",
        "parameters": {
            "type": "object",
            "properties": {
                "credential_name": {"type": "string", "description": "Name of the credential to rotate"}
            },
            "required": ["credential_name"]
        }
    },
    handler=lambda args, **kw: rotate_credential(args["credential_name"], agent_ctx=kw.get("agent_context")),
    check_fn=lambda: True,
    requires_env=[]
)

# tests/test_credential_rotation.py (sketch)
import pytest
from unittest.mock import Mock, patch
from run_agent import AIAgent
from tools.registry import registry

def test_auto_rotation_on_expiry():
    rotator = Mock(return_value="new_key")
    agent = AIAgent(credential_rotator=rotator, credential_pool={"TEST_API_KEY": "old_key"})
    agent.config = {"security": {"credential_rotation": {"expiry_patterns": ["expired"], "retry_attempts": 2}}}

    # Register dummy tool that fails first time
    dummy_handler = Mock(side_effect=[
        json.dumps({"error": "expired"}),
        json.dumps({"ok": "success"})
    ])
    registry.register(
        name="dummy_tool",
        toolset="test",
        schema={"name": "dummy_tool", "parameters": {"type": "object", "properties": {}, "required": []}},
        handler=lambda args, **kw: dummy_handler(args, **kw),
        requires_env=["TEST_API_KEY"]
    )

    agent.credential_pool["TEST_API_KEY"] = "old_key"
    result = agent._execute_tool_with_retry({"function": {"name": "dummy_tool", "arguments": "{}"}})
    assert dummy_handler.call_count == 2
    assert agent.credential_pool["TEST_API_KEY"] == "new_key"
    rotator.assert_called_once_with("TEST_API_KEY")

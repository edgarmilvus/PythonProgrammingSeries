
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# hermes_state.py (extended SessionDB)
import sqlite3
import hashlib
from typing import Optional, List, Dict

class SessionDB:
    def __init__(self, db_path: str):
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self._create_tables()

    def _create_tables(self):
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS credential_state (
                credential_name TEXT PRIMARY KEY,
                last_rotation_iso TEXT NOT NULL,
                use_count INTEGER DEFAULT 0,
                last_anomaly_iso TEXT,
                rotation_count INTEGER DEFAULT 0,
                current_value_hash TEXT
            )
        """)
        self.conn.commit()

    def update_credential_state(self, name: str, **kwargs):
        cols = ", ".join(kwargs.keys())
        placeholders = ", ".join("?" for _ in kwargs)
        values = list(kwargs.values()) + [name]
        self.conn.execute(f"""
            INSERT INTO credential_state (credential_name, {cols})
            VALUES (?, {placeholders})
            ON CONFLICT(credential_name) DO UPDATE SET
                {", ".join(f"{col}=excluded.{col}" for col in kwargs)}
        """, values)
        self.conn.commit()

    def get_credential_state(self, name: str) -> Optional[Dict]:
        cur = self.conn.execute("SELECT * FROM credential_state WHERE credential_name=?", (name,))
        row = cur.fetchone()
        if row:
            return dict(row)
        return None

    def get_all_credential_states(self) -> List[Dict]:
        cur = self.conn.execute("SELECT * FROM credential_state")
        return [dict(row) for row in cur.fetchall()]

# agent/credential_monitor.py (modified to use SessionDB)
import datetime
import hashlib

class CredentialMonitor:
    def __init__(self, config: dict, rotator: callable, credential_pool: dict, session_db: SessionDB):
        # ... same as before plus session_db
        self.session_db = session_db
        self._recovery_scan()

    def _recovery_scan(self):
        max_age = self.config.get("max_age_hours", 23) * 3600
        now = datetime.datetime.utcnow()
        for state in self.session_db.get_all_credential_states():
            name = state["credential_name"]
            last_rot = datetime.datetime.fromisoformat(state["last_rotation_iso"])
            elapsed = (now - last_rot).total_seconds()
            if elapsed > max_age:
                # Rotate proactively
                self.trigger_rotation(name)

    def record_tool_call(self, credential_name, latency_ms, error_code=None):
        # Update in-memory stats (same as before)
        # Then persist every 5 calls or on anomaly
        with self._lock:
            stat = self._stats.get(credential_name)
            if stat:
                stat["use_count"] += 1
                if stat["use_count"] % 5 == 0:  # batch write every 5
                    self._persist_state(credential_name)
        # ... rest of record

    def _persist_state(self, credential_name):
        with self._lock:
            stat = self._stats.get(credential_name)
            if not stat:
                return
            self.session_db.update_credential_state(
                credential_name,
                last_rotation_iso=datetime.datetime.utcfromtimestamp(stat["last_rotation_time"]).isoformat(),
                use_count=stat["use_count"],
                last_anomaly_iso=datetime.datetime.utcfromtimestamp(stat.get("last_anomaly_time", 0)).isoformat(),
                rotation_count=stat.get("rotation_count", 0),
                current_value_hash=hashlib.sha256(self.credential_pool[credential_name].encode()).hexdigest()
            )

# cli.py addition (HermesCLI.process_command)
import datetime

def cmd_credential_status(self, args):
    db = self.agent.session_db
    states = db.get_all_credential_states()
    if not states:
        self.output("No credentials tracked.")
        return
    rows = []
    for state in states:
        name = state["credential_name"]
        last_rot = state["last_rotation_iso"][:19]  # truncate
        use_count = state["use_count"]
        anomalies = state.get("last_anomaly_iso", "None")[:19]
        # Determine status
        now = datetime.datetime.utcnow()
        last_dt = datetime.datetime.fromisoformat(last_rot)
        age_hours = (now - last_dt).total_seconds() / 3600
        if age_hours > 23:
            status = "Expired"
        elif age_hours > 20:
            status = "Near Expiry"
        else:
            status = "OK"
        rows.append(f"{name:20s} | {last_rot:25s} | {use_count:10d} | {anomalies:25s} | {status}")
    header = f"{'Credential':20s} | {'Last Rotation':25s} | {'Use Count':10s} | {'Last Anomaly':25s} | Status"
    self.output(header)
    self.output("-"*90)
    for row in rows:
        self.output(row)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# agent/credential_monitor.py
import time
import logging
from threading import Lock
from typing import Optional

logger = logging.getLogger("hermes.agent.security")

class CredentialMonitor:
    def __init__(self, config: dict, rotator: callable, credential_pool: dict):
        self.config = config
        self.rotator = rotator
        self.credential_pool = credential_pool
        self._stats = {}  # cred_name -> dict
        self._lock = Lock()
        self._turn_counter = {}  # per credential check interval
        self._rotating = set()   # avoid double rotation

    def record_tool_call(self, credential_name: str, latency_ms: float, error_code: Optional[str] = None):
        with self._lock:
            if credential_name not in self._stats:
                self._stats[credential_name] = {
                    "use_count": 0,
                    "last_used": 0.0,
                    "last_error_code": None,
                    "average_latency_ms": 0.0,
                    "last_rotation_time": 0.0
                }
            stat = self._stats[credential_name]
            stat["use_count"] += 1
            stat["last_used"] = time.time()
            if error_code:
                stat["last_error_code"] = error_code
            # Exponential moving average for latency
            alpha = 0.9
            stat["average_latency_ms"] = alpha * stat["average_latency_ms"] + (1 - alpha) * latency_ms

    def check_anomaly(self, credential_name: str) -> bool:
        with self._lock:
            if credential_name not in self._stats:
                return False
            stat = self._stats[credential_name]
            # Check interval (skip check if not enough turns)
            counter = self._turn_counter.get(credential_name, 0)
            if counter % self.config.get("check_interval_turns", 5) != 0:
                self._turn_counter[credential_name] = counter + 1
                return False
            self._turn_counter[credential_name] = 0

            # Thresholds
            max_uses = self.config.get("max_uses_per_credential", 100)
            max_latency = self.config.get("max_latency_ms", 5000)
            max_age = self.config.get("max_age_hours", 23) * 3600

            if stat["use_count"] > max_uses:
                return True
            if stat["average_latency_ms"] > max_latency:
                return True
            elapsed = time.time() - stat["last_rotation_time"]
            if elapsed > max_age:
                return True
            return False

    def reset_stats(self, credential_name: str):
        with self._lock:
            if credential_name in self._stats:
                self._stats[credential_name] = {
                    "use_count": 0,
                    "last_used": 0.0,
                    "last_error_code": None,
                    "average_latency_ms": 0.0,
                    "last_rotation_time": time.time()
                }
            self._rotating.discard(credential_name)

    def trigger_rotation(self, credential_name: str):
        if credential_name in self._rotating:
            return  # already rotating
        self._rotating.add(credential_name)
        try:
            new_value = self.rotator(credential_name)
            self.credential_pool[credential_name] = new_value
            self.reset_stats(credential_name)
            logger.info(f"Anomaly detected, rotated credential {credential_name}")
        except Exception as e:
            logger.error(f"Rotation failed for {credential_name}: {e}")
            self._rotating.discard(credential_name)

# model_tools.py (modification inside handle_function_call)
import time
def handle_function_call(tool_call, agent_ctx):
    # ... existing code ...
    start = time.perf_counter()
    result = actual_handler(args, **kw)
    elapsed_ms = (time.perf_counter() - start) * 1000
    # After call
    cred_monitor = agent_ctx.get("credential_monitor")
    tool_info = registry.get(tool_call.function.name)
    if cred_monitor and tool_info.get("requires_env"):
        for cred_name in tool_info["requires_env"]:
            error_code = None
            if isinstance(result, dict) and "error" in result:
                error_code = result["error"]
            cred_monitor.record_tool_call(cred_name, elapsed_ms, error_code)
            if cred_monitor.check_anomaly(cred_name):
                cred_monitor.trigger_rotation(cred_name)
    return result

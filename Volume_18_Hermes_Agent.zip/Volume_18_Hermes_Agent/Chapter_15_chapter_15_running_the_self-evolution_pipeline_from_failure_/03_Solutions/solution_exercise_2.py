
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import json
import os
import dspy
from dspy import ChainOfThought
from hermes_agent import SkillModule, LLMJudge, SyntheticDatasetBuilder, ToolRegistry
from dataclasses import dataclass
from typing import Optional

class SkillGenerator:
    def __init__(self, config: dict, skill_module_factory, registry_dir: str = "./skills"):
        self.config = config
        self.skill_module_factory = skill_module_factory
        self.registry_dir = registry_dir
        os.makedirs(registry_dir, exist_ok=True)
        # Initialize LLM components
        dspy.settings.configure(lm=config["lm_model"])
        self.judge = LLMJudge(config.get("judge_model", config["lm_model"]))

    def generate_skill(self, failure: 'FailureRecord') -> Optional[str]:
        """Generate a skill from a failure record, returns skill name if successful."""
        # Build prompt
        prompt = (
            f"Task input: {failure.task_input}\n"
            f"Tool calls made: {failure.tool_calls}\n"
            f"Output: {failure.output}\n"
            f"Error: {failure.error_message}\n"
            "Generate a skill that would prevent this failure. "
            "Output a skill name, description, and step-by-step instructions. "
            "Format as:\n"
            "Skill Name: <name>\n"
            "Description: <description>\n"
            "Procedure:\n1. ...\n2. ..."
        )
        # Use ChainOfThought to get structured output
        cot = ChainOfThought(signature="context -> skill_text: str")
        result = cot(context=prompt)
        skill_text = result.skill_text

        # Parse to get name (first line after "Skill Name:")
        name_line = [line for line in skill_text.split("\n") if line.startswith("Skill Name:")]
        skill_name = name_line[0].split(":")[1].strip() if name_line else "generated_skill"

        # Wrap in SkillModule
        full_skill_text = (
            "---\n"
            f"name: {skill_name}\n"
            "type: skill\n"
            "---\n"
            + skill_text
        )
        skill_module = self.skill_module_factory(full_skill_text)

        # Evaluate on synthetic examples
        builder = SyntheticDatasetBuilder()
        examples = builder.build_from_skill(skill_module, num_examples=3)
        scores = []
        for ex in examples:
            score = self.judge.score(
                task_input=ex.task_input,
                expected_behavior=ex.expected_behavior,
                agent_output=ex.agent_output,
                skill_text=skill_text
            )
            scores.append(score.composite)
        average_score = sum(scores) / len(scores) if scores else 0
        if average_score < 0.7:
            return None  # Skill rejected

        # Persist to registry (simple file-based)
        skill_dir = os.path.join(self.registry_dir, skill_name)
        os.makedirs(skill_dir, exist_ok=True)
        with open(os.path.join(skill_dir, "skill.md"), "w") as f:
            f.write(full_skill_text)
        with open(os.path.join(skill_dir, "metadata.json"), "w") as f:
            json.dump({"name": skill_name, "score": average_score, "from_failure": failure.error_message}, f)

        # Register as tool in agent's tool registry (passed as parameter or global)
        def skill_tool(task_input: str) -> str:
            return skill_module.forward(task_input)
        ToolRegistry.register_tool(skill_name, skill_tool)

        return skill_name

# Integration test
def test_skill_generation():
    from hermes_agent import SkillModule as SM, LLMJudge
    config = {"lm_model": "gpt-4"}
    generator = SkillGenerator(config, lambda text: SM(text))
    # Create a mock FailureRecord
    from dataclasses import dataclass, field
    @dataclass
    class MockFailure:
        task_input: str = "parse date string"
        tool_calls: list = field(default_factory=lambda: [{"name": "date_parser", "input": "2024-13-01"}])
        output: str = "Invalid date"
        error_message: str = "ValueError: month out of range"
    failure = MockFailure()
    skill_name = generator.generate_skill(failure)
    assert skill_name is not None
    # Check tool exists
    assert ToolRegistry.get_tool(skill_name) is not None
    print("Test passed")

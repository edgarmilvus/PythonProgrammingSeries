
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import datetime
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from hermes_agent import AIAgent, SessionDB  # hypothetical imports

@dataclass
class FailureRecord:
    agent_id: str
    task_input: str
    tool_calls: List[Dict] = field(default_factory=list)
    output: str = ""
    error_message: str = ""
    timestamp: datetime.datetime = field(default_factory=datetime.datetime.now)
    context: Dict = field(default_factory=dict)

class FailureCapture:
    def __init__(self, agent: AIAgent, db: SessionDB):
        self.agent = agent
        self.db = db
        # Store the original run method to wrap it
        self._original_run = agent.run

    def monitor(self, task_input: str, **kwargs) -> str:
        """Wrap agent.run to capture failures."""
        try:
            # Execute the original run method
            output = self._original_run(task_input, **kwargs)
            # Heuristic failure detection: empty output or "error" in output
            if not output or "error" in output.lower():
                self._log_failure(task_input, output, error_message="Heuristic failure")
            return output
        except Exception as e:
            # If an exception is raised, it's a failure
            output = ""  # no output on exception
            self._log_failure(task_input, output, error_message=str(e))
            # Re-raise to let the caller handle it? We'll return empty to mimic original behavior
            # but also log. According to spec: "agent should still return its output to the caller"
            # We'll catch and re-raise after logging.
            raise

    def _log_failure(self, task_input: str, output: str, error_message: str):
        """Create and insert a FailureRecord."""
        record = FailureRecord(
            agent_id=id(self.agent),  # simple unique id
            task_input=task_input,
            tool_calls=self._capture_tool_calls(),  # we need to access tool calls
            output=output,
            error_message=error_message,
            timestamp=datetime.datetime.now()
        )
        self.db.insert(record)

    def _capture_tool_calls(self) -> List[Dict]:
        """Attempt to retrieve tool calls made during execution.
        This depends on how AIAgent records them; we assume a property 'tool_calls_history'."""
        if hasattr(self.agent, 'tool_calls_history'):
            return self.agent.tool_calls_history
        return []

    def get_failures(self, agent_id: Optional[str] = None,
                     time_range: Optional[tuple] = None,
                     **kwargs) -> List[FailureRecord]:
        """Query failures from SessionDB with optional filters."""
        filters = {}
        if agent_id:
            filters['agent_id'] = agent_id
        if time_range:
            start, end = time_range
            filters['timestamp'] = {"$gte": start, "$lte": end}
        # Additional filters from kwargs can be added
        filters.update(kwargs)
        return self.db.query(FailureRecord, **filters)


# Unit Test (simulated)
def test_failure_capture():
    # Create mock agent and db
    agent = AIAgent()  # real usage would have proper initialization
    db = SessionDB(":memory:")
    capture = FailureCapture(agent, db)

    # Make an agent that fails on a specific input
    def failing_run(task_input):
        if "fail" in task_input:
            raise ValueError("Intentional failure")
        return "success"

    # Replace agent's run
    capture._original_run = failing_run
    # Re-bind monitor? Actually we already stored original; better to set agent.run = failing_run
    agent.run = failing_run
    capture.monitor = lambda task_input: agent.run(task_input)

    # Execute normal task (should not log)
    output = capture.monitor("hello")
    assert output == "success"
    assert capture.db.query(FailureRecord) == []

    # Execute failing task
    try:
        capture.monitor("fail this")
    except ValueError:
        pass  # expected
    failures = capture.get_failures()
    assert len(failures) == 1
    assert failures[0].error_message == "Intentional failure"
    assert failures[0].task_input == "fail this"
    print("Test passed")

if __name__ == "__main__":
    test_failure_capture()

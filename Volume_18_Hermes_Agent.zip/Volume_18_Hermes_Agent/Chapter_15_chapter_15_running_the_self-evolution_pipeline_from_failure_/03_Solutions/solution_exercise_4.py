
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# This code extends an existing evolve() function (assumed from evolution/skills/evolve_skill.py)
import argparse
from hermes_agent import SessionDB
from evolution.skills.evolve_skill import evolve as original_evolve
from evolution.data import EvalDataset

def evolve_with_failure_support(args):
    """Modified evolve function that adds 'failure' eval source."""
    # Handle new arguments
    if args.eval_source == "failure":
        if not args.failure_db_path:
            raise ValueError("--failure-db-path must be provided when eval_source is 'failure'.")
        db = SessionDB(args.failure_db_path)
        from exercise1 import FailureCapture  # import the class we built
        capture = FailureCapture(agent=None, db=db)  # agent not needed for get_failures
        failures = capture.get_failures(agent_id=args.skill_name)  # filter by skill if applicable
        if not failures:
            print("Warning: No failures found. Falling back to synthetic generation.")
            args.eval_source = "synthetic"
        else:
            # Generate expected behavior for each failure using an LLM
            import dspy
            dspy.settings.configure(lm=args.lm_model)
            cot = dspy.ChainOfThought("task_input, failed_output -> expected_behavior")
            examples = []
            for fail in failures:
                result = cot(task_input=fail.task_input, failed_output=fail.output)
                expected = result.expected_behavior
                ex = dspy.Example(
                    task_input=fail.task_input,
                    expected_behavior=expected,
                    agent_output=fail.output,
                    skill_text=""  # place for future skill text
                ).with_inputs("task_input")
                examples.append(ex)
            # Split into train/val/holdout (70/15/15)
            total = len(examples)
            train = examples[:int(0.7*total)]
            val = examples[int(0.7*total):int(0.85*total)]
            holdout = examples[int(0.85*total):]
            dataset = EvalDataset(train, val, holdout)
            # Replace args.dataset with our dataset
            args.dataset = dataset
    # Call original evolve with potentially modified args
    return original_evolve(args)

# Command-line argument addition
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--eval-source", choices=["synthetic", "golden", "sessiondb", "failure"], required=True)
    parser.add_argument("--failure-db-path", help="Path to SessionDB for failures")
    # ... other arguments as in original evolve ...
    args = parser.parse_args()
    evolve_with_failure_support(args)

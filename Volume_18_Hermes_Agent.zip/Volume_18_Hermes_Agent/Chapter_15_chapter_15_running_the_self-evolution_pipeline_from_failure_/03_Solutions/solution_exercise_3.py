
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import functools
import logging
from hermes_agent import LLMJudge, FitnessScore
from evolution.core.fitness import original_heuristic_metric  # hypothetical original

logger = logging.getLogger(__name__)

# LRU cache for scoring function
@functools.lru_cache(maxsize=1024)
def _cached_llm_score(task_input: str, expected_behavior: str, agent_output: str, skill_text: str = "") -> float:
    """Inner function that calls LLMJudge.score() and caches results."""
    judge = LLMJudge()  # assumes a default judge is available
    try:
        score: FitnessScore = judge.score(
            task_input=task_input,
            expected_behavior=expected_behavior,
            agent_output=agent_output,
            skill_text=skill_text
        )
        return score.composite
    except Exception as e:
        logger.warning(f"LLMJudge failed: {e}. Falling back to heuristic.")
        # fallback: call original heuristic metric (must be adapted to accept same args)
        return original_heuristic_metric(agent_output, expected_behavior)

def skill_fitness_metric(example, prediction, *args, **kwargs):
    """New fitness metric using LLM judge with caching and fallback.
    example: DSPy example with attributes task_input, expected_behavior, skill_text (optional)
    prediction: agent output string or object with .output attribute.
    """
    # Extract fields
    task_input = getattr(example, 'task_input', '')
    expected = getattr(example, 'expected_behavior', '')
    skill_text = getattr(example, 'skill_text', '')
    # prediction may be a string or an object with 'output'
    agent_output = prediction if isinstance(prediction, str) else getattr(prediction, 'output', str(prediction))
    # Call cached function (hashable arguments)
    return _cached_llm_score(task_input, expected, agent_output, skill_text)

# Ensure the function returns float 0-1 and is batchable (it is, as pure function)

# Test functions
def test_caching():
    example = type('Example', (), {'task_input': 'foo', 'expected_behavior': 'bar', 'skill_text': 'baz'})()
    pred = type('Pred', (), {'output': 'correct result'})()
    first = skill_fitness_metric(example, pred)
    second = skill_fitness_metric(example, pred)
    assert first == second, "Cached values should match"
    print("Caching test passed")

def test_fallback():
    # Temporarily mock LLMJudge to raise exception
    original_score = LLMJudge.score
    LLMJudge.score = lambda *args, **kwargs: (_ for _ in ()).throw(Exception("API down"))
    example = type('Example', (), {'task_input': 'x', 'expected_behavior': 'y', 'skill_text': ''})()
    pred = "wrong"
    score = skill_fitness_metric(example, pred)
    # Heuristic should return something (e.g., 0.0 if no overlap)
    assert isinstance(score, float) and 0 <= score <= 1
    LLMJudge.score = original_score
    print("Fallback test passed")

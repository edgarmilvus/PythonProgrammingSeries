
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import datetime
import chromadb
from chromadb import EmbeddingFunction
import dspy
from hermes_agent import ToolRegistry, SkillModule
from typing import List, Tuple, Optional

class SkillMemory:
    def __init__(self, collection_name: str = "skills", persist_directory: str = "./skill_memory"):
        self.client = chromadb.PersistentClient(path=persist_directory)
        self.collection = self.client.get_or_create_collection(
            name=collection_name,
            embedding_function=self._get_embedder()
        )

    def _get_embedder(self) -> EmbeddingFunction:
        """Return a callable that converts text to embedding vector.
        Uses DSPy's embedder or a custom one."""
        class DspyEmbedder(EmbeddingFunction):
            def __call__(self, input):
                # Use dspy.Embedder (requires configured LM)
                embedder = dspy.Embedder(model="text-embedding-ada-002")  # example
                return [embedder(text) for text in input]
        return DspyEmbedder()

    def store_skill(self, skill_name: str, skill_text: str, metadata: dict = None):
        """Embed skill description and store in vector DB."""
        # Extract description from frontmatter or use first 200 chars
        description = self._extract_description(skill_text)
        embedding = self.collection._embedding_function([description])[0]  # get embedding for single text
        meta = {
            "skill_name": skill_name,
            "timestamp": datetime.datetime.now().isoformat(),
            "usage_count": 0
        }
        if metadata:
            meta.update(metadata)
        self.collection.add(
            ids=[skill_name],
            embeddings=[embedding],
            metadatas=[meta],
            documents=[description]  # optional
        )

    def retrieve_skill(self, query: str, k: int = 3) -> List[Tuple[str, float, str]]:
        """Return top-k skill names and their similarity scores.
        Also registers each retrieved skill as a tool if not already.
        """
        results = self.collection.query(query_texts=[query], n_results=k)
        retrieved = []
        for i, skill_name in enumerate(results['ids'][0]):
            distance = results['distances'][0][i]
            similarity = 1.0 - distance  # assume cosine distance
            skill_text = results['documents'][0][i]  # stored document = description
            # Retrieve full skill text from file registry (as in Exercise 2)
            full_text = self._load_full_skill(skill_name)
            if not self._tool_exists(skill_name):
                # Wrap in SkillModule and register
                skill_module = SkillModule(full_text)
                ToolRegistry.register_tool(skill_name, lambda inp: skill_module.forward(inp))
            # Increment usage count
            self._increment_usage(skill_name)
            retrieved.append((skill_name, similarity, full_text))
        return retrieved

    def forget_skill(self, skill_name: str):
        """Remove skill from vector DB and unregister tool."""
        self.collection.delete(ids=[skill_name])
        ToolRegistry.unregister_tool(skill_name)

    def _extract_description(self, skill_text: str) -> str:
        """Extract description from frontmatter or first paragraph."""
        lines = skill_text.split("\n")
        if lines[0].startswith("---"):
            # YAML frontmatter
            try:
                import yaml
                frontmatter = yaml.safe_load("\n".join(lines[1:lines[1:].index("---")+1]))
                return frontmatter.get("description", skill_text[:200])
            except:
                pass
        return skill_text[:200]

    def _load_full_skill(self, skill_name: str) -> str:
        """Load full skill text from file system registry (Exercise 2)."""
        import os
        path = f"./skills/{skill_name}/skill.md"
        if os.path.exists(path):
            with open(path, "r") as f:
                return f.read()
        return ""

    def _tool_exists(self, name: str) -> bool:
        return name in ToolRegistry.list_tools()

    def _increment_usage(self, skill_name: str):
        """Update usage count in metadata."""
        meta = self.collection.get(ids=[skill_name])['metadatas'][0]
        meta['usage_count'] = meta.get('usage_count', 0) + 1
        self.collection.update(ids=[skill_name], metadatas=[meta])

# Test
def test_skill_memory():
    # Setup
    memory = SkillMemory()
    # Store three skills
    memory.store_skill("add_numbers", "Skill to add two numbers. Steps: 1. Read inputs. 2. Compute sum.")
    memory.store_skill("multiply", "Skill to multiply. Steps: 1. Read inputs. 2. Multiply.")
    memory.store_skill("greet", "Skill to greet user. Steps: 1. Say hello.")
    # Query for addition
    results = memory.retrieve_skill("calculate addition", k=3)
    top_name, sim, text = results[0]
    assert top_name == "add_numbers", f"Expected add_numbers, got {top_name}"
    # Check that tool is registered
    assert ToolRegistry.get_tool("add_numbers") is not None
    # Forget and verify
    memory.forget_skill("add_numbers")
    assert "add_numbers" not in ToolRegistry.list_tools()
    # Re-query should not return it (but may return others)
    results2 = memory.retrieve_skill("calculate addition", k=2)
    assert all(name != "add_numbers" for name, _, _ in results2)
    print("All tests passed")

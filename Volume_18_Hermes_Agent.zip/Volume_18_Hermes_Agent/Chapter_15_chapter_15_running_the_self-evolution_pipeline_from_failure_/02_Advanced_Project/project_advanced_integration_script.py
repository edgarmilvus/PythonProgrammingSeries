
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script.py
# Description: Advanced Integration Script
# ==========================================

"""
hermes_self_evolve_service.py - Advanced Integration Script for Running the Self-Evolution Pipeline

This script implements a production-grade service that:
1. Listens to an AIAgent's persistent memory for failure patterns
2. Triggers the evolution pipeline (from Chapter 15) automatically
3. Validates evolved skills against constraint gates
4. Deploys successful skills back into the agent's skill store
5. Operates as a Flask web service with Blueprint modularity

Requirements:
- pip install flask flask-sqlalchemy numpy openai dspy-ai
- Requires the Hermes repository with evolution/ module on PYTHONPATH
- Requires a running vector database (we use FAISS in-memory for demo)

Usage:
    python hermes_self_evolve_service.py --hermes-repo /path/to/hermes-agent --port 8080
"""

import os
import sys
import json
import time
import logging
import subprocess
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass, field, asdict

import numpy as np
import click
from flask import Flask, request, jsonify, Blueprint
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String, Float, DateTime, Text, JSON

# ============================================================================
# CRITICAL: Import the actual Hermes AIAgent from the repository
# This uses the `run_agent.py` module as defined in the Hermes codebase
# ============================================================================
from run_agent import AIAgent  # noqa: E402

# Add the evolution module path if running from within the repo structure
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# ============================================================================
# ============================================================================

@dataclass
class FailureRecord:
    """
    Stores a single failure event captured from the agent's persistent memory.

    Attributes:
        agent_id (str): Unique identifier for the agent instance
        task_input (str): The original task that caused failure
        agent_output (str): The agent's (incorrect) response
        expected_behavior (str): What the correct behavior should have been
        skill_name (str): The skill that was active when the failure occurred
        failure_type (str): e.g., "missing_index", "wrong_procedure"
        timestamp (float): Unix timestamp of the failure
        vector_embedding (List[float]): Embedding of the failure context for similarity search
        resolved (bool): Whether a skill has been generated for this failure pattern
    """
    agent_id: str
    task_input: str
    agent_output: str
    expected_behavior: str
    skill_name: str
    failure_type: str
    timestamp: float = field(default_factory=time.time)
    vector_embedding: List[float] = field(default_factory=list)
    resolved: bool = False


@dataclass
class EvolutionJob:
    """
    Tracks the state of an evolution pipeline run.

    Attributes:
        skill_name (str): The target skill being evolved
        job_id (str): Unique identifier
        status (str): queued | running | success | failed
        baseline_score (float): Pre-evolution score on holdout set
        evolved_score (float): Post-evolution score
        improvement (float): delta
        constraints_passed (bool)
        output_dir (str): Path where evolved skill files are saved
    """
    skill_name: str
    job_id: str
    status: str = "queued"
    baseline_score: float = 0.0
    evolved_score: float = 0.0
    improvement: float = 0.0
    constraints_passed: bool = False
    output_dir: str = ""
    created_at: float = field(default_factory=time.time)


# ============================================================================
# ============================================================================

db = SQLAlchemy()


class FailureModel(db.Model):  # type: ignore
    """
    SQLAlchemy model for failure records.
    Mirrors the FailureRecord dataclass but adds ORM capabilities.
    """
    __tablename__ = "failure_records"

    id = Column(Integer, primary_key=True)
    agent_id = Column(String(64), nullable=False, index=True)
    task_input = Column(Text, nullable=False)
    agent_output = Column(Text, nullable=False)
    expected_behavior = Column(Text, nullable=False)
    skill_name = Column(String(128), nullable=False, index=True)
    failure_type = Column(String(64), nullable=False)
    timestamp = Column(Float, nullable=False)
    vector_embedding = Column(JSON, nullable=True)  # stored as list of floats
    resolved = Column(Integer, default=0)  # 0 = False, 1 = True

    def to_dataclass(self) -> FailureRecord:
        return FailureRecord(
            agent_id=self.agent_id,
            task_input=self.task_input,
            agent_output=self.agent_output,
            expected_behavior=self.expected_behavior,
            skill_name=self.skill_name,
            failure_type=self.failure_type,
            timestamp=self.timestamp,
            vector_embedding=self.vector_embedding or [],
            resolved=bool(self.resolved),
        )


class EvolutionJobModel(db.Model):  # type: ignore
    """SQLAlchemy model for tracking evolution jobs."""
    __tablename__ = "evolution_jobs"

    id = Column(Integer, primary_key=True)
    skill_name = Column(String(128), nullable=False, index=True)
    job_id = Column(String(36), unique=True, nullable=False)
    status = Column(String(16), default="queued")
    baseline_score = Column(Float, default=0.0)
    evolved_score = Column(Float, default=0.0)
    improvement = Column(Float, default=0.0)
    constraints_passed = Column(Integer, default=0)
    output_dir = Column(String(256), default="")
    created_at = Column(Float, default=time.time)

    def to_dataclass(self) -> EvolutionJob:
        return EvolutionJob(
            skill_name=self.skill_name,
            job_id=self.job_id,
            status=self.status,
            baseline_score=self.baseline_score,
            evolved_score=self.evolved_score,
            improvement=self.improvement,
            constraints_passed=bool(self.constraints_passed),
            output_dir=self.output_dir,
            created_at=self.created_at,
        )


# ============================================================================
# ============================================================================

class FailureVectorStore:
    """
    Lightweight vector store for clustering similar failure patterns.
    Uses FAISS for cosine similarity search.
    This enables the system to recognize when a new failure matches an existing
    cluster that hasn't yet been resolved by an evolved skill.
    """

    def __init__(self, dimension: int = 768):
        """
        Args:
            dimension (int): Embedding dimension (matches OpenAI ada-002 default)
        """
        self.dimension = dimension
        self.index = None  # Will be FAISS index; None for now (placeholder)
        self.id_to_record: Dict[int, FailureRecord] = {}

    def add_failure(self, record: FailureRecord) -> int:
        """
        Add a failure record's embedding to the index.

        Args:
            record: FailureRecord with non-empty vector_embedding

        Returns:
            int: The internal ID assigned to this record
        """
        if not record.vector_embedding:
            raise ValueError("Cannot add failure without vector embedding")

        # Normalize the embedding to unit length for cosine similarity
        embedding = np.array(record.vector_embedding, dtype=np.float32)
        embedding = embedding / (np.linalg.norm(embedding) + 1e-10)

        internal_id = len(self.id_to_record)
        self.id_to_record[internal_id] = record

        # Placeholder for FAISS add — in production, you'd call index.add()
        # self.index.add(embedding.reshape(1, -1))
        return internal_id

    def find_similar_failures(self, query: List[float], top_k: int = 5) -> List[Tuple[FailureRecord, float]]:
        """
        Find the top-k most similar failure records to a query embedding.

        Args:
            query: The embedding of a new failure
            top_k: Number of similar failures to return

        Returns:
            List of (FailureRecord, similarity_score) tuples
        """
        # Placeholder: brute-force cosine similarity for demonstration
        # In production, use FAISS index.search()
        query_np = np.array(query, dtype=np.float32)
        query_np = query_np / (np.linalg.norm(query_np) + 1e-10)

        results = []
        for internal_id, record in self.id_to_record.items():
            rec_emb = np.array(record.vector_embedding, dtype=np.float32)
            rec_emb = rec_emb / (np.linalg.norm(rec_emb) + 1e-10)
            similarity = float(np.dot(query_np, rec_emb))
            results.append((record, similarity))

        results.sort(key=lambda x: x[1], reverse=True)
        return results[:top_k]


# ============================================================================
# ============================================================================

class SelfEvolutionOrchestrator:
    """
    Orchestrates the entire self-evolution pipeline.

    This class is the heart of the integration script. It:
    - Captures failures from the AIAgent's persistent memory
    - Filters and clusters failures by similarity
    - Triggers the evolution CLI (from Chapter 15) via subprocess
    - Validates evolved skills against constraint gates
    - Deploys successful skills back to the agent

    It uses the AIAgent's tool-handling capabilities to execute shell commands
    and read its own memory, demonstrating advanced agent-driven orchestration.
    """

    def __init__(
        self,
        hermes_repo_path: str,
        agent: AIAgent,
        vector_store: FailureVectorStore,
        min_failure_count: int = 5,
        improvement_threshold: float = 0.05,
    ):
        """
        Args:
            hermes_repo_path: Absolute path to the Hermes agent repository root
            agent: An instance of AIAgent (from run_agent.py)
            vector_store: Vector store for clustering failures
            min_failure_count: Minimum number of similar failures before triggering evolution
            improvement_threshold: Minimum improvement required to deploy evolved skill
        """
        self.hermes_repo = Path(hermes_repo_path).resolve()
        self.agent = agent
        self.vector_store = vector_store
        self.min_failure_count = min_failure_count
        self.improvement_threshold = improvement_threshold
        self.logger = logging.getLogger("SelfEvolutionOrchestrator")

        # Verify the evolution CLI exists
        self.evolve_script = self.hermes_repo / "evolution" / "skills" / "evolve_skill.py"
        if not self.evolve_script.exists():
            raise FileNotFoundError(
                f"Evolution script not found at {self.evolve_script}. "
                "Ensure the Hermes repository structure is intact."
            )

    def capture_failures_from_agent(self) -> List[FailureRecord]:
        """
        Query the agent's persistent memory for unresolved failures.

        This method uses the AIAgent's memory retrieval capabilities.
        It searches for records tagged as 'failure' that have not been
        marked as 'resolved' in the agent's internal state.

        Returns:
            List[FailureRecord]: Unresolved failure records
        """
        self.logger.info("Capturing failures from agent's persistent memory...")

        # Use the AIAgent's memory retrieval tool
        # The tool accepts a query and returns matching memory entries
        query_result = self.agent.use_tool(
            tool_name="memory_retriever",
            params={
                "query": "type: failure resolved: false",
                "max_results": 100,
            }
        )

        # Parse the tool's output into FailureRecord objects
        failures = []
        for entry in query_result.get("results", []):
            try:
                record = FailureRecord(
                    agent_id=entry.get("agent_id", self.agent.agent_id),
                    task_input=entry.get("task_input", ""),
                    agent_output=entry.get("agent_output", ""),
                    expected_behavior=entry.get("expected_behavior", ""),
                    skill_name=entry.get("skill_name", "unknown"),
                    failure_type=entry.get("failure_type", "generic"),
                    timestamp=entry.get("timestamp", time.time()),
                    vector_embedding=entry.get("vector_embedding", []),
                    resolved=entry.get("resolved", False),
                )
                failures.append(record)
            except Exception as e:
                self.logger.warning(f"Skipping malformed failure entry: {e}")

        self.logger.info(f"Captured {len(failures)} unresolved failures.")
        return failures

    def _find_failure_patterns(self, failures: List[FailureRecord]) -> Dict[str, List[FailureRecord]]:
        """
        Cluster failures by their skill_name and then by embedding similarity.

        This method groups failures that are likely caused by the same root issue.
        It uses the vector store to find similar failures within each skill group.

        Args:
            failures: List of FailureRecord to cluster

        Returns:
            Dict mapping a pattern key (e.g., "database-migration-reviewer:missing_rollback")
            to a list of similar FailureRecords
        """
        patterns: Dict[str, List[FailureRecord]] = {}

        for failure in failures:
            if not failure.vector_embedding:
                # If no embedding, group by skill+type as a fallback
                pattern_key = f"{failure.skill_name}:{failure.failure_type}"
                patterns.setdefault(pattern_key, []).append(failure)
                continue

            # Find similar failures already in the vector store
            similar = self.vector_store.find_similar_failures(
                failure.vector_embedding, top_k=5
            )

            # If there are highly similar failures (score > 0.85), use their pattern
            pattern_found = False
            for existing_record, similarity in similar:
                if similarity > 0.85:
                    pattern_key = f"{existing_record.skill_name}:{existing_record.failure_type}"
                    patterns.setdefault(pattern_key, []).append(failure)
                    pattern_found = True
                    break

            # Otherwise, create a new pattern based on the current failure
            if not pattern_found:
                # Add this failure to the vector store for future matching
                self.vector_store.add_failure(failure)
                pattern_key = f"{failure.skill_name}:{failure.failure_type}"
                patterns.setdefault(pattern_key, []).append(failure)

            # Mark the pattern key on the failure for database logging
            failure.skill_name = pattern_key.split(":")[0]

        self.logger.info(f"Found {len(patterns)} distinct failure patterns.")
        for pattern, records in patterns.items():
            self.logger.info(f"  Pattern '{pattern}': {len(records)} records")
        return patterns

    def _should_evolve(self, pattern_key: str, failures: List[FailureRecord]) -> bool:
        """
        Determine if a failure pattern has enough evidence to trigger evolution.

        Criteria:
        - At least `min_failure_count` records in the cluster
        - The cluster's failures span at least 2 different timestamps (not a burst)
        - No evolution job has been completed for this pattern in the last 24 hours

        Args:
            pattern_key: Identifier for the failure pattern
            failures: The cluster of failure records

        Returns:
            bool: True if evolution should be triggered
        """
        if len(failures) < self.min_failure_count:
            self.logger.debug(
                f"Pattern '{pattern_key}' has only {len(failures)} failures "
                f"(minimum {self.min_failure_count}). Skipping."
            )
            return False

        # Check that failures span at least 2 distinct time periods
        timestamps = sorted(set(f.timestamp for f in failures))
        if len(timestamps) < 2:
            self.logger.debug(
                f"Pattern '{pattern_key}' failures all at same timestamp. "
                "Likely a burst, not a systemic issue. Skipping."
            )
            return False

        # Check recent evolution jobs (within 24h) to avoid re-evolution
        twenty_four_hours_ago = time.time() - 86400
        recent_jobs = EvolutionJobModel.query.filter(
            EvolutionJobModel.skill_name == pattern_key.split(":")[0],
            EvolutionJobModel.created_at > twenty_four_hours_ago,
            EvolutionJobModel.status == "success",
        ).count()

        if recent_jobs > 0:
            self.logger.info(
                f"Pattern '{pattern_key}' already has a successful evolution "
                f"within 24h. Skipping."
            )
            return False

        self.logger.info(f"Pattern '{pattern_key}' meets all criteria. Triggering evolution.")
        return True

    def _run_evolution_cli(
        self, skill_name: str, failures: List[FailureRecord]
    ) -> EvolutionJob:
        """
        Execute the evolution pipeline via subprocess call to the Hermes CLI.

        This method builds the command-line arguments and runs the evolve_skill.py
        script. It captures stdout/stderr for logging and parses the output
        directory from the CLI's final output.

        Args:
            skill_name: The skill to evolve (e.g., "database-migration-reviewer")
            failures: The cluster of failure records to use as eval dataset

        Returns:
            EvolutionJob with updated status and scores
        """
        job_id = f"evolve_{skill_name}_{int(time.time())}"
        job = EvolutionJob(skill_name=skill_name, job_id=job_id)

        # Persist the job as "running" in the database
        db.session.add(EvolutionJobModel(
            skill_name=job.skill_name,
            job_id=job.job_id,
            status="running",
        ))
        db.session.commit()

        # Prepare CLI arguments
        # We use sys.argv style because the evolution script uses click
        # The script expects arguments like --skill, --iterations, etc.
        cmd = [
            sys.executable,                     # python exe
            str(self.evolve_script),             # evolution/skills/evolve_skill.py
            "--skill", skill_name,
            "--eval-source", "sessiondb",        # Use actual session data
            "--iterations", "10",                # Default iterations
            "--optimizer-model", "openai/gpt-4.1",
            "--eval-model", "openai/gpt-4.1-mini",
            "--hermes-repo", str(self.hermes_repo),
        ]

        # Create a temporary dataset file from the failure records
        # so the evolution script can use it as the evaluation dataset
        dataset_dir = self.hermes_repo / "datasets" / "skills" / skill_name
        dataset_dir.mkdir(parents=True, exist_ok=True)
        dataset_path = dataset_dir / f"failure_cluster_{job_id}.jsonl"

        with open(dataset_path, "w") as f:
            for failure in failures:
                example = {
                    "task_input": failure.task_input,
                    "expected_behavior": failure.expected_behavior,
                    "agent_output": failure.agent_output,
                }
                f.write(json.dumps(example) + "\n")

        cmd.extend(["--dataset-path", str(dataset_path)])

        self.logger.info(f"Running evolution CLI command: {' '.join(cmd)}")

        try:
            # Run the subprocess with a timeout of 30 minutes per job
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=1800,  # 30 minutes
                cwd=str(self.hermes_repo),
            )

            # Log the output of the CLI
            self.logger.info(f"CLI stdout:\n{result.stdout}")
            if result.stderr:
                self.logger.warning(f"CLI stderr:\n{result.stderr}")

            if result.returncode != 0:
                job.status = "failed"
                self.logger.error(f"Evolution CLI failed with return code {result.returncode}")
            else:
                # Parse the CLI output to extract metrics
                # The CLI prints "Output saved to output/<skill>/<timestamp>/"
                # We can find it by scanning stdout lines
                output_dir = None
                baseline_score = 0.0
                evolved_score = 0.0
                improvement = 0.0
                constraints_passed = False

                for line in result.stdout.split("\n"):
                    if "Output saved to" in line:
                        # e.g., "Output saved to output/database-migration-reviewer/20250321_120000/"
                        output_dir = line.split("to ")[-1].strip()
                    if "Evolved score:" in line:
                        evolved_score = float(line.split(":")[-1].strip())
                    if "Baseline score:" in line:
                        baseline_score = float(line.split(":")[-1].strip())
                    if "improvement:" in line:
                        improvement = float(line.split(":")[-1].strip().replace("+",""))
                    if "constraints passed" in line.lower():
                        constraints_passed = "yes" in line.lower() or "true" in line.lower()

                if output_dir:
                    job.output_dir = output_dir
                job.baseline_score = baseline_score
                job.evolved_score = evolved_score
                job.improvement = improvement
                job.constraints_passed = constraints_passed

                # Determine status based on improvement threshold
                if improvement >= self.improvement_threshold and constraints_passed:
                    job.status = "success"
                    self.logger.info(
                        f"Evolution SUCCESS: {skill_name} improved by {improvement:.3f}"
                    )
                elif improvement < self.improvement_threshold:
                    job.status = "success_but_below_threshold"
                    self.logger.info(
                        f"Evolution completed but improvement {improvement:.3f} < "
                        f"threshold {self.improvement_threshold}. Skill not deployed."
                    )
                else:
                    job.status = "failed_constraints"
                    self.logger.warning(
                        f"Evolution failed constraints for {skill_name}"
                    )

        except subprocess.TimeoutExpired:
            job.status = "timeout"
            self.logger.error(f"Evolution CLI timed out after 30 minutes for {skill_name}")
        except Exception as e:
            job.status = "failed"
            self.logger.exception(f"Unexpected error running evolution: {e}")

        # Update the database job record
        db_job = EvolutionJobModel.query.filter_by(job_id=job.job_id).first()
        if db_job:
            db_job.status = job.status
            db_job.baseline_score = job.baseline_score
            db_job.evolved_score = job.evolved_score
            db_job.improvement = job.improvement
            db_job.constraints_passed = int(job.constraints_passed)
            db_job.output_dir = job.output_dir
            db.session.commit()

        return job

    def _deploy_evolved_skill(self, job: EvolutionJob) -> bool:
        """
        Deploy an evolved skill back into the agent's skill store.

        Steps:
        1. Read the evolved skill file from the output directory
        2. Validate the skill is syntactically correct
        3. Register the skill with the AIAgent via its tool
        4. Mark the relevant failure records as resolved
        5. Store the embedding of the new skill for future retrieval

        Args:
            job: The EvolutionJob that produced a successful evolution

        Returns:
            bool: True if deployment succeeded
        """
        if job.status != "success":
            self.logger.error(f"Cannot deploy skill with status {job.status}")
            return False

        # Path to the evolved skill file
        output_path = Path(job.output_dir) / "evolved_skill.md"
        if not output_path.exists():
            self.logger.error(f"Evolved skill file not found: {output_path}")
            return False

        # Read the evolved skill content
        skill_content = output_path.read_text()

        # Use the AIAgent's tool to register the new skill
        # The agent has a tool called 'skill_registrar' that accepts
        # skill_name and skill_content and adds it to the active skill set
        deploy_result = self.agent.use_tool(
            tool_name="skill_registrar",
            params={
                "skill_name": job.skill_name,
                "skill_content": skill_content,
                "version": datetime.now().strftime("%Y%m%d_%H%M%S"),
            }
        )

        if not deploy_result.get("success", False):
            self.logger.error(f"Failed to deploy skill: {deploy_result.get('error', 'unknown')}")
            return False

        # Mark the failure records as resolved
        # We update the agent's persistent memory to mark resolved=true
        self.agent.use_tool(
            tool_name="memory_updater",
            params={
                "query": f"skill_name: {job.skill_name} resolved: false",
                "update": {"resolved": True},
            }
        )

        # Also update the database records
        FailureModel.query.filter(
            FailureModel.skill_name == job.skill_name,
            FailureModel.resolved == 0,
        ).update({"resolved": 1})
        db.session.commit()

        self.logger.info(
            f"Successfully deployed evolved skill '{job.skill_name}' (v{datetime.now().strftime('%Y%m%d_%H%M%S')})"
        )
        return True

    def run_evolution_cycle(self) -> List[EvolutionJob]:
        """
        Execute one full evolution cycle.

        Steps:
        1. Capture unresolved failures from agent's memory
        2. Cluster failures into patterns
        3. For each pattern that meets the criteria, run evolution
        4. Deploy successful evolutions

        Returns:
            List[EvolutionJob]: Status of all evolution jobs executed in this cycle
        """
        self.logger.info("=" * 60)
        self.logger.info("Starting self-evolution cycle")
        self.logger.info("=" * 60)

        # Step 1: Capture failures
        all_failures = self.capture_failures_from_agent()
        if not all_failures:
            self.logger.info("No unresolved failures found. Cycle complete.")
            return []

        # Step 2: Cluster into patterns
        failure_patterns = self._find_failure_patterns(all_failures)

        # Step 3: Decide which patterns need evolution
        jobs = []
        for pattern_key, failures in failure_patterns.items():
            if self._should_evolve(pattern_key, failures):
                # Extract the skill name (first part of pattern_key)
                skill_name = pattern_key.split(":")[0]
                job = self._run_evolution_cli(skill_name, failures)
                jobs.append(job)

                # Step 4: Deploy if successful
                if job.status == "success":
                    deployed = self._deploy_evolved_skill(job)
                    if deployed:
                        self.logger.info(f"Skill '{skill_name}' deployed successfully.")
                    else:
                        self.logger.error(f"Deployment failed for '{skill_name}' despite successful evolution.")

            else:
                self.logger.info(f"Ignoring pattern '{pattern_key}' - criteria not met.")

        self.logger.info(f"Cycle complete. Processed {len(jobs)} evolution jobs.")
        return jobs


# ============================================================================
# ============================================================================

# Use Flask's Blueprint to modularize the endpoints
evolution_bp = Blueprint("evolution", __name__, url_prefix="/api/v1/evolution")

# Global orchestrator (initialized in the main function)
orchestrator: Optional[SelfEvolutionOrchestrator] = None
agent_instance: Optional[AIAgent] = None


@evolution_bp.route("/status", methods=["GET"])
def get_status():
    """
    Health check endpoint for the evolution service.
    Returns the current state of the orchestrator and agent.
    """
    global orchestrator, agent_instance
    if orchestrator is None:
        return jsonify({"status": "not_initialized"}), 503

    return jsonify({
        "status": "running",
        "agent_id": agent_instance.agent_id if agent_instance else None,
        "hermes_repo": str(orchestrator.hermes_repo),
        "min_failure_count": orchestrator.min_failure_count,
        "improvement_threshold": orchestrator.improvement_threshold,
    })


@evolution_bp.route("/failures", methods=["GET"])
def list_failures():
    """
    List unresolved failure records, with optional filtering by skill.
    """
    skill = request.args.get("skill")
    limit = request.args.get("limit", 50, type=int)

    query = FailureModel.query.filter(FailureModel.resolved == 0)
    if skill:
        query = query.filter(FailureModel.skill_name == skill)

    records = query.order_by(FailureModel.timestamp.desc()).limit(limit).all()

    return jsonify({
        "count": len(records),
        "failures": [{
            "id": r.id,
            "skill_name": r.skill_name,
            "failure_type": r.failure_type,
            "task_input": r.task_input[:200] + "..." if len(r.task_input) > 200 else r.task_input,
            "timestamp": r.timestamp,
        } for r in records]
    })


@evolution_bp.route("/trigger", methods=["POST"])
def trigger_evolution():
    """
    Manually trigger an evolution cycle (or target a specific skill).
    Body:
        {
            "skill": "database-migration-reviewer" (optional)
        }
    """
    global orchestrator
    if orchestrator is None:
        return jsonify({"error": "Orchestrator not initialized"}), 503

    data = request.get_json(silent=True) or {}
    target_skill = data.get("skill")

    # If no specific skill, run cycle on all failure patterns
    if not target_skill:
        jobs = orchestrator.run_evolution_cycle()
    else:
        # Manually capture failures filtered by skill, then run evolution
        all_failures = orchestrator.capture_failures_from_agent()
        filtered = [f for f in all_failures if f.skill_name == target_skill]
        if not filtered:
            return jsonify({"error": f"No unresolved failures for skill {target_skill}"}), 404
        patterns = orchestrator._find_failure_patterns(filtered)
        # Use the first pattern for this skill
        pattern_key = next(iter(patterns.keys()), None)
        if not pattern_key:
            return jsonify({"error": "No failure patterns found for this skill"}), 404
        job = orchestrator._run_evolution_cli(target_skill, patterns[pattern_key])
        jobs = [job]
        if job.status == "success":
            orchestrator._deploy_evolved_skill(job)

    job_results = [
        {
            "job_id": j.job_id,
            "skill_name": j.skill_name,
            "status": j.status,
            "improvement": j.improvement,
            "output_dir": j.output_dir,
        }
        for j in (jobs or [])
    ]

    return jsonify({"triggered": len(job_results), "jobs": job_results}), 202


@evolution_bp.route("/jobs", methods=["GET"])
def list_jobs():
    """
    List recent evolution jobs.
    Query params:
        status (str): filter by status (queued, running, success, failed)
        limit (int): max records to return (default 20)
    """
    status_filter = request.args.get("status")
    limit = request.args.get("limit", 20, type=int)

    query = EvolutionJobModel.query
    if status_filter:
        query = query.filter(EvolutionJobModel.status == status_filter)

    records = query.order_by(EvolutionJobModel.created_at.desc()).limit(limit).all()

    return jsonify({
        "count": len(records),
        "jobs": [{
            "job_id": r.job_id,
            "skill_name": r.skill_name,
            "status": r.status,
            "baseline_score": r.baseline_score,
            "evolved_score": r.evolved_score,
            "improvement": r.improvement,
            "constraints_passed": bool(r.constraints_passed),
            "output_dir": r.output_dir,
            "created_at": r.created_at,
        } for r in records]
    })


@evolution_bp.route("/deploy/<job_id>", methods=["POST"])
def deploy_job(job_id: str):
    """
    Manually trigger deployment for a specific evolution job.
    Useful if auto-deployment was skipped.
    """
    global orchestrator
    if orchestrator is None:
        return jsonify({"error": "Not initialized"}), 503

    db_job = EvolutionJobModel.query.filter_by(job_id=job_id).first()
    if not db_job:
        return jsonify({"error": f"Job {job_id} not found"}), 404

    job = db_job.to_dataclass()
    if job.status == "success":
        success = orchestrator._deploy_evolved_skill(job)
        if success:
            return jsonify({"status": "deployed", "skill": job.skill_name}), 200
        else:
            return jsonify({"error": "Deployment failed"}), 500
    else:
        return jsonify({"error": f"Cannot deploy job with status '{job.status}'"}), 400


# ============================================================================
# ============================================================================

def create_app(
    hermes_repo: str,
    db_uri: str = "sqlite:///hermes_evolution.db",
    min_failure_count: int = 5,
    improvement_threshold: float = 0.05,
) -> Flask:
    """
    Create and configure the Flask application with the evolution Blueprint.

    This function initializes the database, the AIAgent, the vector store,
    and the orchestrator, then registers the Blueprint.

    Args:
        hermes_repo: Path to the Hermes agent repository
        db_uri: SQLAlchemy database URI (default: SQLite)
        min_failure_count: Minimum failures to trigger evolution
        improvement_threshold: Minimum improvement to deploy

    Returns:
        Flask application instance
    """
    global orchestrator, agent_instance

    app = Flask(__name__)
    app.config["SQLALCHEMY_DATABASE_URI"] = db_uri
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    db.init_app(app)

    # ======================================================================
    # Initialize the AIAgent (from run_agent.py)
    # The agent is configured with tool-handling and persistent memory.
    # We pass the hermes_repo path and enable memory persistence.
    # ======================================================================
    agent_instance = AIAgent(
        repo_path=hermes_repo,
        enable_memory=True,          # Enable persistent memory
        memory_backend="sqlite",     # Use SQLite-backed memory (matches our DB)
        enable_tools=True,           # Enable tool usage (skill_registrar, etc.)
    )

    # Initialize the vector store (in-memory FAISS equivalent)
    vector_store = FailureVectorStore(dimension=768)

    # Create the orchestrator
    orchestrator = SelfEvolutionOrchestrator(
        hermes_repo_path=hermes_repo,
        agent=agent_instance,
        vector_store=vector_store,
        min_failure_count=min_failure_count,
        improvement_threshold=improvement_threshold,
    )

    # Register the Blueprint
    app.register_blueprint(evolution_bp)

    # Create all database tables
    with app.app_context():
        db.create_all()

    # Register a background task that runs the evolution cycle every hour
    # (In production, use Celery or APScheduler; here we use a simple thread)
    import threading
    def scheduled_evolution_loop():
        """Run the evolution cycle periodically."""
        while True:
            time.sleep(3600)  # Every hour
            try:
                with app.app_context():
                    orchestrator.run_evolution_cycle()
            except Exception as e:
                logging.exception("Error in scheduled evolution cycle")

    thread = threading.Thread(target=scheduled_evolution_loop, daemon=True)
    thread.start()

    return app


@click.command()
@click.option("--hermes-repo", required=True, help="Path to hermes-agent repository root")
@click.option("--port", default=8080, help="Port to run the Flask server on")
@click.option("--db-uri", default="sqlite:///hermes_evolution.db", help="Database URI")
@click.option("--min-failures", default=5, help="Minimum failures to trigger evolution")
@click.option("--threshold", default=0.05, help="Minimum improvement to deploy skill")
def main(hermes_repo, port, db_uri, min_failures, threshold):
    """
    Advanced Integration Script for Hermes Agent Self-Evolution.

    Launches a Flask web service that:
    - Captures agent failures from persistent memory
    - Clusters similar failures using vector embeddings
    - Triggers the GEPA evolution pipeline automatically
    - Validates evolved skills against constraint gates
    - Deploys successful skills back to the agent

    The service provides REST endpoints to monitor and manually trigger evolution.
    """
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler("evolution_service.log"),
        ],
    )

    logger = logging.getLogger("main")
    logger.info(f"Starting Hermes Self-Evolution Service on port {port}")
    logger.info(f"  Hermes repo: {hermes_repo}")
    logger.info(f"  DB URI: {db_uri}")
    logger.info(f"  Min failures: {min_failures}")
    logger.info(f"  Improvement threshold: {threshold}")

    app = create_app(
        hermes_repo=hermes_repo,
        db_uri=db_uri,
        min_failure_count=min_failures,
        improvement_threshold=threshold,
    )

    app.run(host="0.0.0.0", port=port, debug=False)


if __name__ == "__main__":
    main()

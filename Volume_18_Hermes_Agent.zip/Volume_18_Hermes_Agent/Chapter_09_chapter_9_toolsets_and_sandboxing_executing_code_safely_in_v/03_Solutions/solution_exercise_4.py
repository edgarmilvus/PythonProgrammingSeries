
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# tools/validation.py
import json
from functools import wraps
from typing import Dict, Any, Callable, Optional

class ValidationError(Exception):
    pass

def validate_params(func: Callable) -> Callable:
    """
    Decorator that validates parameters against rules defined in func._param_rules.
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        rules = getattr(func, '_param_rules', {})
        errors = []
        for param_name, param_value in kwargs.items():
            if param_name in rules:
                rule = rules[param_name]
                # Required check
                if rule.get('required', False) and param_value is None:
                    errors.append(f"Parameter '{param_name}' is required")
                # Type check
                expected_type = rule.get('type')
                if expected_type and param_value is not None:
                    if not isinstance(param_value, expected_type):
                        errors.append(f"Parameter '{param_name}' expected type {expected_type.__name__}, got {type(param_value).__name__}")
                # Range check for numeric
                if isinstance(param_value, (int, float)):
                    min_val = rule.get('min')
                    max_val = rule.get('max')
                    if min_val is not None and param_value < min_val:
                        errors.append(f"Parameter '{param_name}' must be >= {min_val}")
                    if max_val is not None and param_value > max_val:
                        errors.append(f"Parameter '{param_name}' must be <= {max_val}")
                # String length
                if isinstance(param_value, str):
                    max_len = rule.get('max_length')
                    if max_len and len(param_value) > max_len:
                        errors.append(f"Parameter '{param_name}' exceeds max length {max_len}")
                # Enum check
                allowed = rule.get('enum')
                if allowed and param_value not in allowed:
                    errors.append(f"Parameter '{param_name}' must be one of {allowed}")
        if errors:
            return {"error": "Validation failed", "details": errors}
        return func(*args, **kwargs)
    return wrapper

def validate_response(schema: Dict[str, Any]) -> Callable:
    """
    Decorator that validates the return value against a schema.
    schema: dict with keys 'required' (list of required keys) and 'types' (dict key->type).
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            result = func(*args, **kwargs)
            # Ensure result is dict
            if not isinstance(result, dict):
                return {"error": "Response must be a JSON object", "original_result": str(result)}
            # Check required keys
            required = schema.get('required', [])
            missing = [k for k in required if k not in result]
            if missing:
                return {"error": f"Response missing required keys: {missing}"}
            # Check types
            types = schema.get('types', {})
            for key, expected_type in types.items():
                if key in result and not isinstance(result[key], expected_type):
                    return {"error": f"Response key '{key}' expected type {expected_type.__name__}, got {type(result[key]).__name__}"}
            return result
        return wrapper
    return decorator

# Example usage on a tool function (e.g., search_files)
@validate_params
@validate_response({
    "required": ["results"],
    "types": {"results": list, "total_results": int}
})
def search_files(query: str, path: str = ".", limit: int = 20):
    # ... implementation ...
    pass

# Set param rules
search_files._param_rules = {
    "query": {"required": True, "type": str, "max_length": 200},
    "path": {"type": str, "max_length": 4096},
    "limit": {"type": int, "min": 1, "max": 100}
}

# Infinite loop detection in agent/tool_guardrails.py
class ToolCallGuardrailController:
    def __init__(self, config):
        self.config = config
        self._call_history = []  # list of (tool_name, args_hash) tuples

    def before_call(self, tool_call: Dict[str, Any]) -> ToolGuardrailDecision:
        # ... existing guardrails ...
        # Infinite loop detection
        tool_name = tool_call.get("name")
        args = tool_call.get("arguments", {})
        args_hash = self._hash_args(args)
        self._call_history.append((tool_name, args_hash))
        # Keep only last few calls
        if len(self._call_history) > 3:
            self._call_history.pop(0)
        # Check for three identical calls
        if len(self._call_history) >= 3:
            if (self._call_history[-1] == self._call_history[-2] == self._call_history[-3]):
                return ToolGuardrailDecision(
                    action="halt",
                    code="infinite_loop",
                    message="Agent appears to be stuck in a loop: same tool call repeated three times. Please try a different approach."
                )
        return ToolGuardrailDecision(action="proceed")

    def after_call(self, tool_call: Dict[str, Any], result: Dict[str, Any]) -> ToolGuardrailDecision:
        # Validate response format (if response schema defined)
        # This could be integrated with the @validate_response decorator
        # For guardrail, we check if result contains "error" key
        if "error" in result:
            return ToolGuardrailDecision(action="proceed")  # Already an error
        # Additional checks...
        return ToolGuardrailDecision(action="proceed")

    def _hash_args(self, args: Dict) -> str:
        # Create a deterministic hash of arguments
        return json.dumps(args, sort_keys=True)

    def reset_loop_detection(self):
        self._call_history.clear()

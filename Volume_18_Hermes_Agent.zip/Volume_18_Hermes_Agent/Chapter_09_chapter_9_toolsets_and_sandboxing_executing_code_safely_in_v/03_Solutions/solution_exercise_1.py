
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# tools/list_directory_tool.py
import os
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Dict, Any, Optional
from agent.tool_guardrails import ToolCallGuardrailConfig, ToolGuardrailDecision

# Tool schema for registration
LIST_DIRECTORY_TOOL_SCHEMA = {
    "name": "list_directory",
    "description": "List contents of a directory. Returns file names, sizes, modification times, and type.",
    "parameters": {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Absolute or relative path to the directory"
            },
            "recursive": {
                "type": "boolean",
                "description": "If true, list all files and subdirectories recursively",
                "default": False
            }
        },
        "required": ["path"]
    }
}

def list_directory(path: str, recursive: bool = False) -> Dict[str, Any]:
    """
    Implementation of the list_directory tool.
    Returns a JSON object with directory contents.
    """
    try:
        # Resolve path to absolute
        abs_path = os.path.abspath(path)
        p = Path(abs_path)

        if not p.exists():
            return {"error": f"Path does not exist: {abs_path}"}
        if not p.is_dir():
            return {"error": f"Path is not a directory: {abs_path}"}

        entries = []
        if recursive:
            # Use rglob for recursive listing
            for item in p.rglob('*'):
                try:
                    stat = item.stat()
                    entries.append({
                        "name": str(item.relative_to(p)),
                        "type": "directory" if item.is_dir() else "file",
                        "size_bytes": stat.st_size if item.is_file() else None,
                        "modified_at": datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).isoformat()
                    })
                except (PermissionError, OSError):
                    # Skip inaccessible items
                    continue
        else:
            # Use scandir for efficient non-recursive listing
            with os.scandir(abs_path) as it:
                for entry in it:
                    try:
                        stat = entry.stat()
                        entries.append({
                            "name": entry.name,
                            "type": "directory" if entry.is_dir() else "file",
                            "size_bytes": stat.st_size if entry.is_file() else None,
                            "modified_at": datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).isoformat()
                        })
                    except (PermissionError, OSError):
                        continue

        return {
            "path": abs_path,
            "entries": entries,
            "total_entries": len(entries)
        }
    except Exception as e:
        return {"error": f"Failed to list directory: {str(e)}"}

# Guardrail rule for list_directory
def list_directory_guardrail(tool_call: Dict[str, Any]) -> ToolGuardrailDecision:
    """
    Guardrail that blocks list_directory if the path is outside allowed base directories.
    """
    path = tool_call.get("arguments", {}).get("path", "")
    if not path:
        return ToolGuardrailDecision(action="proceed")

    # Resolve to absolute path
    abs_path = os.path.abspath(path)

    # Define allowed base directories (e.g., user home and workspace)
    allowed_bases = [
        os.path.expanduser("~"),
        os.path.abspath(".")  # current workspace
    ]

    for base in allowed_bases:
        # Ensure base is absolute
        base_abs = os.path.abspath(base)
        # Check if abs_path starts with base (with trailing slash to avoid partial matches)
        if abs_path.startswith(base_abs + os.sep) or abs_path == base_abs:
            return ToolGuardrailDecision(action="proceed")

    # Block the call
    return ToolGuardrailDecision(
        action="halt",
        message=f"Access denied: listing directory '{abs_path}' is outside allowed workspace. Allowed bases: {allowed_bases}"
    )

# Registration in run_agent.py (example snippet)
# from tools.list_directory_tool import LIST_DIRECTORY_TOOL_SCHEMA, list_directory, list_directory_guardrail
# agent.register_tool(LIST_DIRECTORY_TOOL_SCHEMA, list_directory, toolset="filesystem")
# guardrail_config = ToolCallGuardrailConfig()
# guardrail_config.add_rule("list_directory", list_directory_guardrail)
# agent.guardrail_controller = ToolCallGuardrailController(guardrail_config)

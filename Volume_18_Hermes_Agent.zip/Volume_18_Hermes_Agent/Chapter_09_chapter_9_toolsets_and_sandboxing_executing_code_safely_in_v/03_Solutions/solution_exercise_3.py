
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# hermes_state.py (modifications)
import sqlite3
import re
from typing import List, Dict, Any, Optional

class SessionDB:
    def __init__(self, db_path: str):
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row
        self._init_tables()
        self._migrate_schema()

    def _init_tables(self):
        # Existing tables...
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS tags (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL
            )
        """)
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS session_tags (
                session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
                tag_id INTEGER NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
                PRIMARY KEY (session_id, tag_id)
            )
        """)
        self.conn.commit()

    def _migrate_schema(self):
        # Check for existing schema version and run migrations
        # For simplicity, we assume the tables are created fresh.
        pass

    # --- Tag Management Methods ---
    def _validate_tag(self, tag_name: str):
        if not tag_name or len(tag_name) > 50:
            raise ValueError("Tag must be non-empty and at most 50 characters")
        if not re.match(r'^[a-zA-Z0-9_-]+$', tag_name):
            raise ValueError("Tag must contain only alphanumeric, hyphens, underscores")
        # Case-insensitive: store lowercase
        return tag_name.lower()

    def add_tag(self, session_id: str, tag_name: str) -> bool:
        tag_name = self._validate_tag(tag_name)
        # Ensure tag exists
        cursor = self.conn.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (tag_name,))
        tag_id = self.conn.execute("SELECT id FROM tags WHERE name = ?", (tag_name,)).fetchone()[0]
        # Insert session_tag
        try:
            self.conn.execute("INSERT INTO session_tags (session_id, tag_id) VALUES (?, ?)", (session_id, tag_id))
            self.conn.commit()
            return True
        except sqlite3.IntegrityError:
            # Tag already associated
            return False

    def remove_tag(self, session_id: str, tag_name: str) -> bool:
        tag_name = self._validate_tag(tag_name)
        cursor = self.conn.execute("SELECT id FROM tags WHERE name = ?", (tag_name,))
        row = cursor.fetchone()
        if not row:
            return False
        tag_id = row[0]
        cursor = self.conn.execute("DELETE FROM session_tags WHERE session_id = ? AND tag_id = ?", (session_id, tag_id))
        self.conn.commit()
        return cursor.rowcount > 0

    def get_session_tags(self, session_id: str) -> List[str]:
        cursor = self.conn.execute("""
            SELECT t.name FROM tags t
            JOIN session_tags st ON t.id = st.tag_id
            WHERE st.session_id = ?
        """, (session_id,))
        return [row["name"] for row in cursor.fetchall()]

    def search_sessions_by_tag(self, tag_name: str, limit: int = 20, offset: int = 0) -> List[Dict[str, Any]]:
        tag_name = self._validate_tag(tag_name)
        query = """
            SELECT s.id, s.title, s.created_at, s.updated_at,
                   (SELECT content FROM messages WHERE session_id = s.id ORDER BY created_at DESC LIMIT 1) as last_message_preview,
                   (SELECT created_at FROM messages WHERE session_id = s.id ORDER BY created_at DESC LIMIT 1) as last_active
            FROM sessions s
            JOIN session_tags st ON s.id = st.session_id
            JOIN tags t ON st.tag_id = t.id
            WHERE t.name = ?
            ORDER BY s.updated_at DESC
            LIMIT ? OFFSET ?
        """
        cursor = self.conn.execute(query, (tag_name, limit, offset))
        return [dict(row) for row in cursor.fetchall()]

    # --- Combined Search ---
    def search_messages(self, query_text: str, tag_filter: Optional[str] = None, limit: int = 20, offset: int = 0) -> List[Dict[str, Any]]:
        if tag_filter:
            tag_name = self._validate_tag(tag_filter)
            # First get session IDs with that tag
            session_ids = self.conn.execute(
                "SELECT session_id FROM session_tags WHERE tag_id = (SELECT id FROM tags WHERE name = ?)",
                (tag_name,)
            ).fetchall()
            if not session_ids:
                return []
            session_id_list = [row["session_id"] for row in session_ids]
            placeholders = ",".join("?" * len(session_id_list))
            # Use FTS5 to search messages
            fts_query = """
                SELECT m.id, m.session_id, m.role, m.content, m.created_at,
                       snippet(messages_fts, 1, '<b>', '</b>', '...', 64) as highlighted
                FROM messages m
                JOIN messages_fts ON m.id = messages_fts.rowid
                WHERE messages_fts MATCH ? AND m.session_id IN ({})
                ORDER BY rank
                LIMIT ? OFFSET ?
            """.format(placeholders)
            params = [query_text] + session_id_list + [limit, offset]
            cursor = self.conn.execute(fts_query, params)
        else:
            # Original full-text search
            cursor = self.conn.execute("""
                SELECT m.id, m.session_id, m.role, m.content, m.created_at,
                       snippet(messages_fts, 1, '<b>', '</b>', '...', 64) as highlighted
                FROM messages m
                JOIN messages_fts ON m.id = messages_fts.rowid
                WHERE messages_fts MATCH ?
                ORDER BY rank
                LIMIT ? OFFSET ?
            """, (query_text, limit, offset))
        return [dict(row) for row in cursor.fetchall()]

# session_tag tool (tools/session_tag_tool.py)
SESSION_TAG_TOOL_SCHEMA = {
    "name": "session_tag",
    "description": "Manage tags for the current session. Actions: add, remove, list.",
    "parameters": {
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["add", "remove", "list"],
                "description": "Action to perform"
            },
            "tag": {
                "type": "string",
                "description": "Tag name (required for add/remove)"
            }
        },
        "required": ["action"]
    }
}

def session_tag(action: str, tag: Optional[str] = None, session_db: Optional[SessionDB] = None, session_id: Optional[str] = None) -> Dict[str, Any]:
    if session_db is None or session_id is None:
        return {"error": "Session database not available"}
    if action == "add":
        if not tag:
            return {"error": "Tag required for add action"}
        try:
            success = session_db.add_tag(session_id, tag)
            return {"result": f"Tag '{tag}' {'added' if success else 'already exists'}"}
        except ValueError as e:
            return {"error": str(e)}
    elif action == "remove":
        if not tag:
            return {"error": "Tag required for remove action"}
        success = session_db.remove_tag(session_id, tag)
        return {"result": f"Tag '{tag}' {'removed' if success else 'not found'}"}
    elif action == "list":
        tags = session_db.get_session_tags(session_id)
        return {"tags": tags}
    else:
        return {"error": f"Unknown action: {action}"}

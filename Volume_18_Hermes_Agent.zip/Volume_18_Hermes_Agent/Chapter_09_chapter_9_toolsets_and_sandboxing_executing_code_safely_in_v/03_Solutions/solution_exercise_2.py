
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# tools/sandbox.py
import os
import subprocess
import tempfile
import json
import time
import signal
import resource
import shutil
from typing import Optional, Dict, Any, List
import ctypes
import ctypes.util

# Attempt to import docker
try:
    import docker
    DOCKER_AVAILABLE = True
except ImportError:
    DOCKER_AVAILABLE = False

class SandboxConfig:
    """Configuration for sandboxed execution."""
    def __init__(self,
                 enabled: bool = False,
                 backend: str = "docker",
                 docker_image: str = "python:3.12-slim",
                 max_cpus: float = 1.0,
                 max_memory_mb: int = 512,
                 timeout_seconds: int = 30,
                 allowed_paths: List[str] = None,
                 network_access: bool = False):
        self.enabled = enabled
        self.backend = backend if DOCKER_AVAILABLE else "seccomp"
        self.docker_image = docker_image
        self.max_cpus = max_cpus
        self.max_memory_mb = max_memory_mb
        self.timeout_seconds = timeout_seconds
        self.allowed_paths = allowed_paths or ["/tmp", "/home"]
        self.network_access = network_access

class DockerSandbox:
    """Sandbox using Docker containers."""
    def __init__(self, config: SandboxConfig):
        self.config = config
        self.client = docker.from_env() if DOCKER_AVAILABLE else None

    def execute(self, code: str) -> Dict[str, Any]:
        if not self.client:
            raise RuntimeError("Docker not available")

        # Create a temporary directory for the code
        with tempfile.TemporaryDirectory() as tmpdir:
            code_file = os.path.join(tmpdir, "script.py")
            with open(code_file, "w") as f:
                f.write(code)

            # Prepare volume mounts
            volumes = {}
            for path in self.config.allowed_paths:
                if os.path.exists(path):
                    volumes[os.path.abspath(path)] = {"bind": path, "mode": "ro"}
            # Mount temp dir as writable
            volumes[tmpdir] = {"bind": "/workspace", "mode": "rw"}

            # Resource limits via host_config
            cpu_period = 100000
            cpu_quota = int(self.config.max_cpus * cpu_period)
            mem_limit = f"{self.config.max_memory_mb}m"

            host_config = self.client.api.create_host_config(
                cpu_period=cpu_period,
                cpu_quota=cpu_quota,
                mem_limit=mem_limit,
                network_mode="none" if not self.config.network_access else None,
                read_only=True,  # root filesystem read-only
                tmpfs={"/tmp": ""}  # allow /tmp for temp files
            )

            # Create and run container
            container = self.client.containers.create(
                image=self.config.docker_image,
                command=["python", "/workspace/script.py"],
                volumes=volumes,
                host_config=host_config,
                working_dir="/workspace"
            )

            try:
                container.start()
                # Wait with timeout
                result = container.wait(timeout=self.config.timeout_seconds)
                logs = container.logs(stdout=True, stderr=True)
                stdout, stderr = self._parse_logs(logs)
                exit_code = result["StatusCode"]
                timed_out = False
            except docker.errors.APIError as e:
                # Timeout or other error
                container.kill()
                stdout = ""
                stderr = str(e)
                exit_code = -1
                timed_out = True
            finally:
                container.remove(force=True)

        return {
            "stdout": stdout,
            "stderr": stderr,
            "exit_code": exit_code,
            "timed_out": timed_out
        }

    def _parse_logs(self, logs: bytes) -> tuple:
        # Docker logs may contain multiplexed streams; simple decode
        text = logs.decode("utf-8", errors="replace")
        # Separate stdout and stderr (simplified)
        # In practice, use docker SDK's attach or demux
        return text, ""

class SeccompSandbox:
    """Sandbox using seccomp-bpf restrictions via subprocess."""
    def __init__(self, config: SandboxConfig):
        self.config = config

    def execute(self, code: str) -> Dict[str, Any]:
        # Write code to a temporary file
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write(code)
            script_path = f.name

        try:
            # Prepare preexec function for seccomp
            def apply_restrictions():
                # Set CPU affinity to one core (simplified)
                try:
                    os.sched_setaffinity(0, {0})
                except AttributeError:
                    pass
                # Set memory limit
                try:
                    resource.setrlimit(resource.RLIMIT_AS, (self.config.max_memory_mb * 1024 * 1024, -1))
                except (ValueError, resource.error):
                    pass
                # Apply seccomp filter (requires prctl and libseccomp)
                # For simplicity, we use a pre-built filter or raise if not available
                self._apply_seccomp_filter()

            # Start subprocess
            proc = subprocess.Popen(
                ["python3", script_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                preexec_fn=apply_restrictions,
                cwd="/tmp"  # restrict to /tmp
            )

            try:
                stdout, stderr = proc.communicate(timeout=self.config.timeout_seconds)
                exit_code = proc.returncode
                timed_out = False
            except subprocess.TimeoutExpired:
                proc.kill()
                stdout, stderr = proc.communicate()
                exit_code = -1
                timed_out = True

            return {
                "stdout": stdout.decode("utf-8", errors="replace"),
                "stderr": stderr.decode("utf-8", errors="replace"),
                "exit_code": exit_code,
                "timed_out": timed_out
            }
        finally:
            os.unlink(script_path)

    def _apply_seccomp_filter(self):
        """Apply seccomp-bpf filter to block network, fork, etc."""
        # This is a placeholder; real implementation would use ctypes to call prctl
        # and load a BPF program. For brevity, we assume a helper library.
        # In production, use python-seccomp or similar.
        try:
            import seccomp  # external library
            filter = seccomp.SyscallFilter(seccomp.ALLOW)
            # Block network syscalls
            for syscall in ["socket", "connect", "bind", "listen", "accept"]:
                filter.add_rule(seccomp.KILL, syscall)
            # Block fork/clone
            filter.add_rule(seccomp.KILL, "fork")
            filter.add_rule(seccomp.KILL, "clone")
            # Block ptrace
            filter.add_rule(seccomp.KILL, "ptrace")
            # Block write to disallowed paths (simplified: block all file writes except to /tmp)
            # This would require path-based filtering which is complex; we rely on read-only mounts.
            filter.load()
        except ImportError:
            # Fallback: rely on subprocess resource limits only
            pass

# Integration with execute_code (in terminal_tool.py)
def execute_code(code: str, sandbox_config: Optional[SandboxConfig] = None) -> Dict[str, Any]:
    if sandbox_config and sandbox_config.enabled:
        if sandbox_config.backend == "docker":
            sandbox = DockerSandbox(sandbox_config)
        else:
            sandbox = SeccompSandbox(sandbox_config)
        return sandbox.execute(code)
    else:
        # Fallback to original subprocess execution
        import subprocess
        result = subprocess.run(["python3", "-c", code], capture_output=True, text=True, timeout=30)
        return {
            "stdout": result.stdout,
            "stderr": result.stderr,
            "exit_code": result.returncode,
            "timed_out": False
        }

# Process registry modification (process_registry.py)
class ProcessRegistry:
    def __init__(self):
        self.processes = {}  # pid -> info
        self.containers = {}  # container_id -> info

    def register_process(self, pid: int, info: dict):
        self.processes[pid] = info

    def register_container(self, container_id: str, info: dict):
        self.containers[container_id] = info

    def cleanup(self):
        # Kill all processes
        for pid in list(self.processes.keys()):
            try:
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        # Remove all Docker containers
        if DOCKER_AVAILABLE:
            import docker
            client = docker.from_env()
            for cid in list(self.containers.keys()):
                try:
                    container = client.containers.get(cid)
                    container.kill()
                    container.remove()
                except docker.errors.NotFound:
                    pass
        self.processes.clear()
        self.containers.clear()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_6.py
# Description: Solution for Exercise 6
# ==========================================

# tools/dependency_graph.py (additions)
class Dependency:
    """Represents a runtime dependency discovered after tool execution."""
    def __init__(self, source_tool_id: str, target_tool_ids: List[str], description: str):
        self.source_tool_id = source_tool_id
        self.target_tool_ids = target_tool_ids
        self.description = description

class ToolDependencyGraph:
    # ... existing code ...

    def update_with_runtime_dependencies(self, runtime_deps: List[Dependency]):
        """Add edges based on runtime dependencies and re-sort remaining levels."""
        # Add new edges
        for dep in runtime_deps:
            for target_id in dep.target_tool_ids:
                if target_id in self._dependencies:
                    self._dependencies[target_id].add(dep.source_tool_id)
        # Recompute levels for pending tools (those not yet executed)
        # For simplicity, we recompute the entire graph but only for pending nodes.
        # In practice, we would track which levels have been executed.
        pending_ids = set()
        for level in self._levels:
            for tid in level:
                if tid not in self._executed_ids:
                    pending_ids.add(tid)
        # Rebuild subgraph for pending nodes
        pending_calls = [tc for tc in self.tool_calls if tc['id'] in pending_ids]
        sub_graph = ToolDependencyGraph(pending_calls)
        # Replace remaining levels with sub_graph levels
        self._levels = sub_graph.get_levels()

# Modify terminal tool to return Dependency objects
def terminal(command: str, ...) -> Dict[str, Any]:
    # ... execute command ...
    # After execution, parse output for created files
    created_files = []
    # Example: detect mktemp output
    if "mktemp" in command:
        # Assume stdout contains the temp file path
        temp_path = stdout.strip()
        if temp_path:
            created_files.append(temp_path)
    # Return result plus dependencies
    result = {"stdout": stdout, "stderr": stderr, "exit_code": exit_code}
    dependencies = []
    for file_path in created_files:
        # Find tool calls that reference this file path
        # This would require access to the full tool call list
        # For simplicity, we assume the agent knows the IDs
        # In practice, we would pass the tool call list to the tool function
        pass
    # Return both result and dependencies
    return result, dependencies

# Modify execute_code tool similarly
def execute_code(code: str, ...):
    # ... execution ...
    # Detect created files from code (e.g., open() with 'w')
    # Return dependencies
    pass

# In AIAgent._execute_tool_calls, after each level:
def _execute_tool_calls(self, tool_calls):
    graph = ToolDependencyGraph(tool_calls)
    executed_ids = set()
    for level in graph.get_levels():
        # Execute level...
        for future in as_completed(...):
            tool_id = future_to_id[future]
            result = future.result()
            # If result is a tuple (result, dependencies), extract dependencies
            if isinstance(result, tuple) and len(result) == 2:
                result, runtime_deps = result
                # Update graph with runtime dependencies
                graph.update_with_runtime_dependencies(runtime_deps)
            results[tool_id] = result
            executed_ids.add(tool_id)
        # After level, re-sort remaining levels
        # (graph.update_with_runtime_dependencies already did that)
    # ...

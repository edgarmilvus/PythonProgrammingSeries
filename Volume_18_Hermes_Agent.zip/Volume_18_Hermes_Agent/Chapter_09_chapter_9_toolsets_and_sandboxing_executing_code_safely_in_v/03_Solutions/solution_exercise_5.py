
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# tools/dependency_graph.py
from collections import defaultdict, deque
from typing import List, Dict, Any, Tuple, Optional, Set
import hashlib
import json

class ToolDependencyGraph:
    """Builds a DAG of tool calls and returns execution levels."""
    
    def __init__(self, tool_calls: List[Dict[str, Any]]):
        self.tool_calls = tool_calls  # list of dicts with 'id', 'name', 'arguments'
        self._dependencies = defaultdict(set)  # tool_id -> set of tool_ids that must run before
        self._levels = []  # list of lists of tool_ids (level order)
        self._build_graph()

    def _build_graph(self):
        # Assign IDs if not present
        for i, tc in enumerate(self.tool_calls):
            if 'id' not in tc:
                tc['id'] = f"tool_{i}"
        
        # Build dependency rules based on tool names and arguments
        for i, tc in enumerate(self.tool_calls):
            for j, other in enumerate(self.tool_calls):
                if i == j:
                    continue
                if self._depends_on(tc, other):
                    self._dependencies[tc['id']].add(other['id'])

        # Topological sort using Kahn's algorithm
        in_degree = {tc['id']: 0 for tc in self.tool_calls}
        for tc in self.tool_calls:
            for dep in self._dependencies[tc['id']]:
                in_degree[tc['id']] += 1
        
        queue = deque([tc['id'] for tc in self.tool_calls if in_degree[tc['id']] == 0])
        while queue:
            level = []
            for _ in range(len(queue)):
                node = queue.popleft()
                level.append(node)
                # Decrease in_degree of dependents
                for tc in self.tool_calls:
                    if node in self._dependencies[tc['id']]:
                        in_degree[tc['id']] -= 1
                        if in_degree[tc['id']] == 0:
                            queue.append(tc['id'])
            self._levels.append(level)
        
        # Check for cycles (if not all nodes processed)
        processed = set()
        for level in self._levels:
            processed.update(level)
        if len(processed) != len(self.tool_calls):
            raise ValueError("Cycle detected in tool dependencies")

    def _depends_on(self, tc: Dict, other: Dict) -> bool:
        """Check if tc depends on other."""
        name = tc['name']
        other_name = other['name']
        args = tc.get('arguments', {})
        other_args = other.get('arguments', {})

        # Rule 1: write_file depends on any read_file/write_file on same path
        if name == 'write_file' and other_name in ('read_file', 'write_file'):
            if args.get('path') == other_args.get('path'):
                return True
        # Rule 2: read_file depends on write_file on same path
        if name == 'read_file' and other_name == 'write_file':
            if args.get('path') == other_args.get('path'):
                return True
        # Rule 3: patch depends on write_file/patch on same path
        if name == 'patch' and other_name in ('write_file', 'patch'):
            if args.get('path') == other_args.get('path'):
                return True
        # Rule 4: terminal depends on write_file that creates a file used in command
        if name == 'terminal' and other_name == 'write_file':
            cmd = args.get('command', '')
            file_path = other_args.get('path', '')
            if file_path and file_path in cmd:
                return True
        # Rule 5: terminal depends on previous terminal that changes directory (if relative path used)
        if name == 'terminal' and other_name == 'terminal':
            # Check if other changes directory (e.g., 'cd /somewhere')
            other_cmd = other_args.get('command', '')
            if other_cmd.startswith('cd '):
                # If this command uses a relative path, it depends on the cd
                this_cmd = args.get('command', '')
                if not this_cmd.startswith('/'):
                    return True
        # Rule 6: execute_code depends on write_file that creates imported modules
        if name == 'execute_code' and other_name == 'write_file':
            code = args.get('code', '')
            file_path = other_args.get('path', '')
            # Simple check: if file name appears in import statements
            if file_path and file_path.split('/')[-1].replace('.py', '') in code:
                return True
        # Default: no dependency
        return False

    def get_levels(self) -> List[List[str]]:
        return self._levels

    def get_tool_by_id(self, tool_id: str) -> Dict:
        for tc in self.tool_calls:
            if tc['id'] == tool_id:
                return tc
        return None

# Integration in run_agent.py (AIAgent._execute_tool_calls)
from tools.dependency_graph import ToolDependencyGraph
from concurrent.futures import ThreadPoolExecutor, as_completed

def _execute_tool_calls(self, tool_calls: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    if not tool_calls:
        return []
    
    # Build dependency graph
    graph = ToolDependencyGraph(tool_calls)
    levels = graph.get_levels()
    
    results = {}
    failed_dependencies = set()
    
    for level in levels:
        # Execute all tools in this level concurrently
        with ThreadPoolExecutor(max_workers=len(level)) as executor:
            future_to_id = {}
            for tool_id in level:
                if tool_id in failed_dependencies:
                    # Skip due to dependency failure
                    results[tool_id] = {"error": f"Dependency failed: tool {tool_id} skipped"}
                    continue
                tc = graph.get_tool_by_id(tool_id)
                future = executor.submit(self._execute_single_tool, tc)
                future_to_id[future] = tool_id
            
            for future in as_completed(future_to_id):
                tool_id = future_to_id[future]
                try:
                    result = future.result()
                    results[tool_id] = result
                except Exception as e:
                    results[tool_id] = {"error": str(e)}
                    # Mark dependents as failed
                    for tc in tool_calls:
                        if tool_id in graph._dependencies[tc['id']]:
                            failed_dependencies.add(tc['id'])
    
    # Return results in original order
    return [results[tc['id']] for tc in tool_calls]

def _execute_single_tool(self, tc: Dict) -> Dict:
    # Original tool execution logic (call the function, etc.)
    pass


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation.py
# Description: Basic Library Implementation
# ==========================================

"""
Basic Library Implementation: Persistent AI Agent with Tool Calling

This example demonstrates how to set up a self-improving AI agent using
the Hermes Agent framework. It shows:
- Session database initialization
- Agent creation with tool support
- Conversation loop with tool execution
- Memory and skills integration
- Session persistence and retrieval
"""

import asyncio
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Any

# Import the core Hermes Agent classes
from hermes_state import SessionDB
from run_agent import AIAgent, IterationBudget

# Import tool definitions and helpers
from model_tools import (
    get_tool_definitions,
    get_toolset_for_tool,
    handle_function_call,
    check_toolset_requirements,
)

# Import memory and skills support
from tools.memory_tool import MemoryStore
from tools.todo_tool import TodoStore

# Import configuration helpers
from hermes_cli.config import load_config, cfg_get
from hermes_constants import get_hermes_home

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class PersistentAgent:
    """
    A self-improving AI agent with persistent memory and session tracking.
    
    This class wraps the Hermes AIAgent with session database integration,
    providing durable storage for conversations, token usage tracking,
    and support for the closed learning loop pattern.
    """
    
    def __init__(
        self,
        model: str = "anthropic/claude-sonnet-4-20250514",
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        provider: Optional[str] = None,
        max_iterations: int = 50,
        enabled_toolsets: Optional[List[str]] = None,
        disabled_toolsets: Optional[List[str]] = None,
        session_db_path: Optional[Path] = None,
        load_soul_identity: bool = True,
        skip_context_files: bool = False,
        verbose_logging: bool = False,
        quiet_mode: bool = True,
    ):
        """
        Initialize the persistent agent with database and AIAgent.
        
        Args:
            model: Model identifier (provider/model format)
            base_url: API endpoint URL (optional, uses provider default)
            api_key: API key (optional, uses environment variable)
            provider: Provider name (optional, auto-detected from model)
            max_iterations: Maximum tool-calling iterations per turn
            enabled_toolsets: List of toolsets to enable (e.g., ["web", "terminal"])
            disabled_toolsets: List of toolsets to disable
            session_db_path: Path to SQLite database file
            load_soul_identity: Whether to load SOUL.md as agent identity
            skip_context_files: Whether to skip project context files
            verbose_logging: Enable verbose debug logging
            quiet_mode: Suppress non-essential output
        """
        # Step 1: Initialize the session database
        self.db_path = session_db_path or (get_hermes_home() / "state.db")
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.session_db = SessionDB(db_path=self.db_path)
        
        # Step 2: Create the AIAgent instance with all configuration
        self.agent = AIAgent(
            model=model,
            base_url=base_url or "",
            api_key=api_key,
            provider=provider,
            max_iterations=max_iterations,
            enabled_toolsets=enabled_toolsets or ["web", "terminal"],
            disabled_toolsets=disabled_toolsets,
            save_trajectories=False,  # We use SQLite instead
            verbose_logging=verbose_logging,
            quiet_mode=quiet_mode,
            load_soul_identity=load_soul_identity,
            skip_context_files=skip_context_files,
            # Pass the session database for automatic persistence
            session_db=self.session_db,
        )
        
        # Step 3: Initialize the in-memory todo store
        self.todo_store = TodoStore()
        
        # Step 4: Set up memory store if memory tools are enabled
        self.memory_store = None
        if "memory" in self.agent.valid_tool_names:
            try:
                config = load_config()
                mem_config = config.get("memory", {})
                self.memory_store = MemoryStore(
                    memory_char_limit=mem_config.get("memory_char_limit", 2200),
                    user_char_limit=mem_config.get("user_char_limit", 1375),
                )
                self.memory_store.load_from_disk()
                self.agent._memory_store = self.memory_store
                logger.info("Memory store initialized from disk")
            except Exception as e:
                logger.warning(f"Failed to initialize memory store: {e}")
        
        # Step 5: Log the initialization summary
        logger.info(
            "PersistentAgent initialized: model=%s, tools=%d, db=%s",
            self.agent.model,
            len(self.agent.tools or []),
            self.db_path,
        )
    
    def run_conversation(
        self,
        user_message: str,
        system_message: Optional[str] = None,
        conversation_history: Optional[List[Dict[str, Any]]] = None,
        task_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Run a full conversation turn with tool calling.
        
        This method wraps AIAgent.run_conversation() with additional
        session management and error handling.
        
        Args:
            user_message: The user's input text
            system_message: Optional system prompt override
            conversation_history: Previous messages for context
            task_id: Unique identifier for this task
            
        Returns:
            Dict with keys: final_response, messages, api_calls, completed, etc.
        """
        # Ensure the session database has a row for this session
        self.agent._ensure_db_session()
        
        # Run the conversation through the agent's main loop
        result = self.agent.run_conversation(
            user_message=user_message,
            system_message=system_message,
            conversation_history=conversation_history,
            task_id=task_id,
        )
        
        # Log the outcome for debugging
        logger.info(
            "Conversation turn: api_calls=%d, completed=%s, response_len=%d",
            result.get("api_calls", 0),
            result.get("completed", False),
            len(result.get("final_response", "") or ""),
        )
        
        return result
    
    def get_session_summary(self, session_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Retrieve a summary of the current or specified session.
        
        Returns token usage, message count, and other metadata.
        """
        sid = session_id or self.agent.session_id
        session = self.session_db.get_session(sid)
        if not session:
            return {"error": f"Session {sid} not found"}
        
        # Convert SQLite row to a clean dict
        return {
            "session_id": session["id"],
            "model": session.get("model"),
            "source": session.get("source"),
            "started_at": session.get("started_at"),
            "ended_at": session.get("ended_at"),
            "message_count": session.get("message_count", 0),
            "input_tokens": session.get("input_tokens", 0),
            "output_tokens": session.get("output_tokens", 0),
            "cache_read_tokens": session.get("cache_read_tokens", 0),
            "cache_write_tokens": session.get("cache_write_tokens", 0),
            "reasoning_tokens": session.get("reasoning_tokens", 0),
            "estimated_cost_usd": session.get("estimated_cost_usd", 0.0),
            "title": session.get("title"),
        }
    
    def search_conversations(
        self,
        query: str,
        limit: int = 10,
        source_filter: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Full-text search across all stored conversations.
        
        Uses SQLite FTS5 for fast keyword matching with snippet generation.
        """
        return self.session_db.search_messages(
            query=query,
            source_filter=source_filter,
            limit=limit,
        )
    
    def save_to_memory(self, content: str, target: str = "memory") -> bool:
        """
        Save a fact to the persistent memory store.
        
        Args:
            content: The fact or preference to remember
            target: "memory" for general facts, "user" for user profile
            
        Returns:
            True if saved successfully
        """
        if not self.memory_store:
            logger.warning("Memory store not initialized")
            return False
        
        try:
            self.memory_store.add_entry(content, target=target)
            self.memory_store.save_to_disk()
            logger.info("Saved to %s: %s", target, content[:80])
            return True
        except Exception as e:
            logger.error("Failed to save memory: %s", e)
            return False
    
    def load_memory(self, target: str = "memory") -> List[str]:
        """Load all entries from the memory store."""
        if not self.memory_store:
            return []
        return self.memory_store.get_entries(target=target)
    
    def close(self):
        """Release all resources and close the database connection."""
        try:
            self.agent.close()
        except Exception:
            pass
        try:
            self.session_db.close()
        except Exception:
            pass
        logger.info("PersistentAgent resources released")


# =========================================================================
# Example Usage
# =========================================================================

def main():
    """
    Demonstrate the PersistentAgent in action.
    
    This example shows:
    1. Creating an agent with web and terminal tools
    2. Running a conversation that involves tool calling
    3. Saving important facts to memory
    4. Searching previous conversations
    5. Retrieving session statistics
    """
    
    # Initialize the persistent agent
    agent = PersistentAgent(
        model="anthropic/claude-sonnet-4-20250514",
        enabled_toolsets=["web", "terminal"],
        quiet_mode=True,
    )
    
    try:
        # --- First Conversation: Research and Tool Use ---
        print("\n" + "=" * 60)
        print("CONVERSATION 1: Research Task")
        print("=" * 60)
        
        result1 = agent.run_conversation(
            "Search for the latest Python 3.13 features and summarize them. "
            "Also check what version of Python is installed on this system."
        )
        
        print(f"\nResponse: {result1['final_response'][:500]}...")
        print(f"API Calls: {result1['api_calls']}")
        print(f"Completed: {result1['completed']}")
        
        # Save an important fact to memory
        agent.save_to_memory(
            "User is a Python developer interested in latest language features.",
            target="memory"
        )
        
        # --- Second Conversation: Memory Recall ---
        print("\n" + "=" * 60)
        print("CONVERSATION 2: Memory Recall")
        print("=" * 60)
        
        # The agent should remember the user's interest in Python
        result2 = agent.run_conversation(
            "What do you know about my programming interests?"
        )
        
        print(f"\nResponse: {result2['final_response'][:500]}...")
        print(f"API Calls: {result2['api_calls']}")
        
        # --- Search Previous Conversations ---
        print("\n" + "=" * 60)
        print("SEARCH: Find Python-related conversations")
        print("=" * 60)
        
        search_results = agent.search_conversations(
            query="Python 3.13 features",
            limit=5,
        )
        
        for i, result in enumerate(search_results, 1):
            print(f"\n  Result {i}:")
            print(f"    Session: {result['session_id']}")
            print(f"    Snippet: {result.get('snippet', 'N/A')[:120]}...")
        
        # --- Session Summary ---
        print("\n" + "=" * 60)
        print("SESSION SUMMARY")
        print("=" * 60)
        
        summary = agent.get_session_summary()
        for key, value in summary.items():
            print(f"  {key}: {value}")
        
        # --- Memory Contents ---
        print("\n" + "=" * 60)
        print("STORED MEMORIES")
        print("=" * 60)
        
        memories = agent.load_memory()
        for i, mem in enumerate(memories, 1):
            print(f"  {i}. {mem[:100]}")
        
    finally:
        # Always clean up resources
        agent.close()


if __name__ == "__main__":
    main()

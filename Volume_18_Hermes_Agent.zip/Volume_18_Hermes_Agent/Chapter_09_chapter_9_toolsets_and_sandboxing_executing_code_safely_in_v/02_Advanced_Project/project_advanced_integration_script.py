
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script.py
# Description: Advanced Integration Script
# ==========================================

#!/usr/bin/env python3
"""
sandboxed_audit_bot.py — Production-Grade Secure Audit Agent

Demonstrates Hermes Agent v0.13 advanced integration:
  - Toolset customisation with sandbox policy
  - Persistent memory for cross-session findings
  - Task delegation for parallel sub-analyses
  - Audit logging with session DB integration
  - Pre-tool execution guardrails (sandbox gateway)

Usage:
    from sandboxed_audit_bot import SecureCodeAuditBot
    bot = SecureCodeAuditBot()
    report = bot.audit_code("def hello(): print('hi')")
"""

import json
import logging
import os
import sqlite3
import time
import threading
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

# ── Core Hermes Agent import (the only required import) ──────────────────
from run_agent import AIAgent

# ── Hermes internal helpers for tool definition building ─────────────────
from model_tools import get_tool_definitions, handle_function_call
from tools.memory_tool import MemoryStore
from tools.delegate_tool import delegate_task
from hermes_constants import get_hermes_home

# ── Third-party: sqlite3 for local audit trail (separate from agent DB) ──
import sqlite3 as audit_sqlite3

# ═════════════════════════════════════════════════════════════════════════
# ═════════════════════════════════════════════════════════════════════════

@dataclass
class SandboxPolicy:
    """
    Policy configuration for sandboxed code execution.

    Mirrors the 'tool_loop_guardrails' pattern from AIAgent.__init__ but
    is a standalone dataclass so we can validate rules before injection.
    """
    allowed_toolsets: Set[str] = field(default_factory=lambda: {"analysis", "file_read"})
    blocked_tool_patterns: List[str] = field(default_factory=lambda: [r"rm\s+-rf", r">\s+/dev/"])
    max_execution_seconds: int = 30
    deny_network: bool = True
    deny_write_to_system: bool = True
    audit_log_path: Optional[Path] = None


class SandboxPolicyManager:
    """
    Manages per-conversation sandbox policies and pre-tool audit checks.

    Acts as a gateway: before the AIAgent executes any tool, this policy
    manager evaluates whether the tool violates the sandbox rules. If it
    does, the tool is blocked and an audit event is logged to a local
    SQLite database (separate from the agent's session DB).

    This implements the "policy-based permission controls" described in
    Chapter 9, subsection 3. It runs in the same process as the AIAgent
    but maintains an independent audit trail to satisfy compliance
    requirements (e.g., SOC 2, FedRAMP).
    """

    def __init__(self, policy: SandboxPolicy):
        self.policy = policy
        self._audit_conn: Optional[sqlite3.Connection] = None
        self._lock = threading.Lock()

        # Initialise the local audit database if a path was provided
        if policy.audit_log_path:
            self._init_audit_db(policy.audit_log_path)

    def _init_audit_db(self, path: Path) -> None:
        """Create or open the local SQLite audit log (separate from agent)."""
        path.parent.mkdir(parents=True, exist_ok=True)
        self._audit_conn = audit_sqlite3.connect(str(path))
        self._audit_conn.execute("""
            CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tool_name TEXT NOT NULL,
                tool_args TEXT,
                decision TEXT NOT NULL,  -- 'allow' or 'block'
                reason TEXT,
                timestamp REAL NOT NULL,
                session_id TEXT
            )
        """)
        self._audit_conn.commit()

    def audit_event(
        self,
        tool_name: str,
        tool_args: Dict[str, Any],
        decision: str,
        reason: str,
        session_id: str = "",
    ) -> None:
        """Record a policy decision to the local audit log (thread-safe)."""
        with self._lock:
            if self._audit_conn is None:
                return
            self._audit_conn.execute(
                "INSERT INTO audit_log (tool_name, tool_args, decision, reason, timestamp, session_id) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    tool_name,
                    json.dumps(tool_args, default=str),
                    decision,
                    reason,
                    time.time(),
                    session_id,
                ),
            )
            self._audit_conn.commit()

    def check_tool(self, tool_name: str, tool_args: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Evaluate a tool invocation against the police.

        Returns (allowed: bool, reason: str).
        If denied, the caller should NOT execute the tool and should log
        the denial via audit_event().
        """
        # 1. Toolset allowlist — only these toolsets may execute
        # We use the toolset discovery from model_tools to map a tool name
        # to its owning toolset.
        try:
            owning_toolset = get_toolset_for_tool(tool_name)
        except Exception:
            owning_toolset = "unknown"
        if owning_toolset and owning_toolset not in self.policy.allowed_toolsets:
            return (False, f"toolset {owning_toolset} is not in the allowed set")

        # 2. Command content inspection (applies to 'terminal' and 'execute_code' tools)
        if tool_name in ("terminal", "execute_code"):
            command = tool_args.get("command", "") or tool_args.get("code", "")
            for pattern in self.policy.blocked_tool_patterns:
                import re
                if re.search(pattern, command):
                    return (False, f"command matches blocked pattern: {pattern}")

        # 3. Network filtering — if deny_network is True, block any tool
        #    that opens outbound connections.
        if self.policy.deny_network and tool_name in ("web_search", "web_extract", "browser_navigate"):
            return (False, "network access is prohibited by sandbox policy")

        # 4. Write restrictions — block writes to system paths
        if self.policy.deny_write_to_system and tool_name in ("write_file", "patch"):
            path = tool_args.get("path", "")
            if self._is_system_path(path):
                return (False, f"writing to system path {path} is prohibited")

        return (True, "allowed")

    @staticmethod
    def _is_system_path(path: str) -> bool:
        """Heuristic check for system-critical directories."""
        system_prefixes = [
            "/etc/", "/usr/", "/bin/", "/sbin/", "/lib/",
            "/proc/", "/sys/", "/dev/", "/boot/",
            "C:\\Windows\\", "C:\\Program Files\\",
        ]
        normalized = path.replace("\\", "/")
        return any(normalized.startswith(prefix) for prefix in system_prefixes)


# ═════════════════════════════════════════════════════════════════════════
# ═════════════════════════════════════════════════════════════════════════

class SecureCodeAuditBot:
    """
    A production-grade agent that wraps AIAgent with sandbox policy,
    persistent memory for findings, and custom audit-logging tools.

    The bot solves a concrete problem: a SOC analyst needs to analyse
    dozens of untrusted code snippets daily, each requiring isolated
    execution, policy enforcement, and cross-session memory so that
    findings from one audit inform the analysis of the next.

    Key design decisions:
      - Each audit conversation gets its own fresh AIAgent (session_id
        auto-generated) so sandbox state never leaks between audits.
      - The memory store is injected into every agent instance via
        _memory_store, ensuring that prior findings are available to
        the model without requiring the model to request them.
      - A pre-tool hook (plugin mechanism) gates every tool invocation;
        blocked calls are recorded to a separate, append-only audit log.
    """

    def __init__(
        self,
        model: str = "anthropic/claude-sonnet-4.6",
        base_url: str = "https://openrouter.ai/api/v1",
        api_key: Optional[str] = None,
        audit_log_path: Optional[Path] = None,
        sandbox_policy: Optional[SandboxPolicy] = None,
    ):
        self.model = model
        self.base_url = base_url
        self.api_key = api_key or os.environ.get("OPENROUTER_API_KEY", "")

        # ── Sandbox policy ──────────────────────────────────────────────
        if sandbox_policy is None:
            # Factory defaults: analysis + file reading, no network, no system writes
            sandbox_policy = SandboxPolicy(
                allowed_toolsets={"analysis", "file_read", "memory", "skills"},
                audit_log_path=audit_log_path or get_hermes_home() / "audit_logs" / "sandbox_audit.db",
            )
        self.policy_manager = SandboxPolicyManager(sandbox_policy)

        # ── Persistent memory store ─────────────────────────────────────
        # This MemoryStore is shared across all audit sessions.  The model
        # writes security findings via the 'memory' tool, and the MemoryStore
        # persists them to ~/.hermes/memory/ so future audits can recall them.
        self._memory_store = MemoryStore(
            memory_char_limit=5000,
            user_char_limit=2000,
        )
        self._memory_store.load_from_disk()

        # ── Local audit DB for compliance tracking ──────────────────────
        # Separate from the agent's session DB — this is append-only and
        # can be exported to SIEM systems.
        self._audit_db_path = sandbox_policy.audit_log_path

        # ── Cache for the last audit report (see generate_report()) ─────
        self._last_report: Optional[str] = None

    def audit_code(self, code_snippet: str, context: Optional[str] = None) -> Dict[str, Any]:
        """
        Main entry point — analyse a code snippet under sandbox.

        Steps:
          1. Create a fresh AIAgent with custom tool definitions that
             include our sandbox-aware 'audit_log' tool.
          2. Inject the memory context (prior findings) into the user
             message so the model sees them without a separate tool call.
          3. Override the pre-tool hook to enforce sandbox policy.
          4. Run the conversation and collect the structured report.
          5. Persist new findings to the memory store.
          6. Return the report and audit metadata.

        Returns a dict with keys: final_response, findings (list of dicts),
        audit_events (list of dicts), session_id.
        """
        # ── (A) Build custom tool definitions ───────────────────────────
        # Start from the default tool set but only keep the allowed toolsets.
        # We also inject a custom 'audit_log' tool that provides structured
        # logging to the local audit DB.
        base_tools = get_tool_definitions(
            enabled_toolsets=list(self.policy_manager.policy.allowed_toolsets),
        )
        # If no toolsets are specified in the policy, use the full set (safer default)
        if not base_tools:
            base_tools = get_tool_definitions()

        # Add the custom audit_log tool schema
        audit_log_schema = {
            "type": "function",
            "function": {
                "name": "audit_log",
                "description": "Record a structured audit event for this code analysis. "
                               "Saves findings to the local audit database for compliance.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "finding_type": {
                            "type": "string",
                            "enum": ["info", "warning", "critical"],
                            "description": "Severity of the finding.",
                        },
                        "finding": {
                            "type": "string",
                            "description": "Detailed description of the finding.",
                        },
                        "tool_name": {
                            "type": "string",
                            "description": "Name of the tool that produced this finding, if applicable.",
                        },
                    },
                    "required": ["finding_type", "finding"],
                },
            },
        }
        # Prepend so it appears early in the tool list (models pay more attention)
        custom_tools = [audit_log_schema] + base_tools

        # ── (B) Build user message with memory context ──────────────────
        memory_context = ""
        if self._memory_store:
            # Load all stored memory entries and format them as compact bullets
            mem_block = self._memory_store.format_for_system_prompt("memory")
            if mem_block:
                memory_context = f"\n\n[Prior security findings from memory]\n{mem_block}"

        user_message = (
            f"Analyse the following code snippet for security vulnerabilities, "
            f"logic errors, and best-practice violations. Use the audit_log tool "
            f"to record each finding you discover. Use the terminal tool to execute "
            f"the code in a sandboxed environment if needed, but beware: network "
            f"access is blocked.\n\n"
            f"

#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script.py
# Description: Advanced Integration Script
# ==========================================

#!/usr/bin/env python3
"""
Advanced Integration Script: Hermes Agent Self-Evolution Orchestrator
Part of Chapter 14 – Genetic‑Pareto Prompt Evolution (GEPA) in v0.13

This script demonstrates a closed‑loop self‑improvement system for Hermes Agent.
It:
  1. Mines the SessionDB for real usage traces.
  2. Builds evaluation datasets for a target skill.
  3. Runs GEPA optimization on skill text.
  4. Validates the evolved skill against benchmarks.
  5. Commits the improvement to a git branch for human review.
"""

import os
import sys
import json
import logging
import subprocess
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta

# Hermes Agent core – we use the official library
from run_agent import AIAgent, SessionDB

# DSPy + GEPA – the evolutionary engine
import dspy
from dspy.teleprompt import GEPA

# Internal helpers for benchmark gating and PR generation
from evolution.core.dataset_builder import DatasetBuilder, EvalExample
from evolution.core.fitness import SkillFitness
from evolution.core.constraints import TextLengthConstraint, TestSuiteConstraint
from evolution.core.pr_builder import PRBuilder

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# ------------------------------------------------------------------
# Configuration – assumes standard Hermes repository layout
# ------------------------------------------------------------------
HERMES_AGENT_REPO = Path.home() / ".hermes" / "hermes-agent"
DATASET_DIR = Path("/tmp/hermes_evolution/datasets")
SKILLS_DIR = HERMES_AGENT_REPO / "skills"
BENCHMARK_SCRIPT = HERMES_AGENT_REPO / "environments" / "benchmarks" / "tblite" / "run_tblite.sh"

# GEPA hyperparameters
GEPA_ITERATIONS = 10
GEPA_EVAL_BUDGET = 5  # number of new candidate evaluations per iteration
GEPA_POPULATION_SIZE = 20

# ------------------------------------------------------------------
# Data structures for evolution session
# ------------------------------------------------------------------
@dataclass
class EvolutionSession:
    """Tracks all metadata for one skill evolution run."""
    skill_name: str
    original_path: Path
    eval_dataset_path: Path
    baseline_score: float
    evolved_score: Optional[float] = None
    improved_skill_text: Optional[str] = None
    evolution_log: List[Dict[str, Any]] = field(default_factory=list)


# ------------------------------------------------------------------
# Step 1: Mine SessionDB for usage traces (production data)
# ------------------------------------------------------------------
def mine_skill_usage(skill_name: str, days_back: int = 14) -> List[Dict[str, Any]]:
    """
    Query the Hermes SessionDB for recent sessions where the target skill
    was loaded. Returns raw trajectories with user inputs and agent outputs.
    """
    session_db = SessionDB()  # reads from the agent's SQLite/Mongo store
    sessions = session_db.query(
        filter={
            "skills_loaded": skill_name,
            "timestamp": {"$gte": datetime.now() - timedelta(days=days_back)}
        }
    )

    usage_data = []
    for session in sessions:
        for turn in session["trajectory"]:
            if turn.get("skill_context", {}).get("name") == skill_name:
                usage_data.append({
                    "session_id": session["id"],
                    "user_message": turn["user"],
                    "agent_output": turn["agent"],
                    "tool_calls": turn.get("tool_calls", []),
                    "outcome": turn.get("outcome", None)  # success / failure / unknown
                })
    logger.info(f"Mined {len(usage_data)} usage examples for skill '{skill_name}'")
    return usage_data


# ------------------------------------------------------------------
# Step 2: Build evaluation dataset from mined traces + synthetic data
# ------------------------------------------------------------------
def build_eval_dataset(
    skill_name: str,
    usage_data: List[Dict[str, Any]],
    output_dir: Path
) -> Path:
    """
    Creates train/validation/holdout splits from three sources:
      - SessionDB real traces (scored by LLM-as-judge)
      - Synthetic test cases generated by a strong model
      - Hand‑crafted golden cases (if available)
    Returns path to the JSONL dataset file.
    """
    builder = DatasetBuilder(skill_name=skill_name, output_dir=output_dir)

    # Source A: Score real usage traces
    for example in usage_data:
        # Use an LLM judge to score the agent's output on a skill‑specific rubric
        score = SkillFitness.judge(
            skill_name=skill_name,
            input_text=example["user_message"],
            output_text=example["agent_output"],
            tool_calls=example["tool_calls"]
        )
        builder.add_example(
            input_text=example["user_message"],
            expected_output=score["rubric_detailed"],
            source="sessiondb",
            score=score["overall"]
        )

    # Source B: Synthetic generation (bootstrapping for skills with few traces)
    if len(usage_data) < 20:
        synthetic_prompts = _generate_synthetic_test_cases(skill_name, count=15)
        for prompt, rubric in synthetic_prompts:
            builder.add_example(
                input_text=prompt,
                expected_output=rubric,
                source="synthetic",
                score=1.0  # synthetic cases are assumed correct
            )

    # Source C: Golden set (if exists)
    golden_path = DATASET_DIR / "golden" / f"{skill_name}.jsonl"
    if golden_path.exists():
        with open(golden_path) as f:
            for line in f:
                entry = json.loads(line)
                builder.add_example(**entry, source="golden", score=1.0)

    # Build splits and serialize
    dataset_path = builder.build_splits(
        train_ratio=0.6,
        val_ratio=0.2,
        holdout_ratio=0.2
    )
    logger.info(f"Eval dataset built at {dataset_path} ({len(builder.examples)} examples)")
    return dataset_path


def _generate_synthetic_test_cases(skill_name: str, count: int) -> List[Tuple[str, str]]:
    """
    Uses a strong LLM (e.g., Claude Opus) to generate realistic test cases
    for the given skill. Each case is (prompt, expected_rubric).
    """
    # In production, you'd call an external model API; here we simulate.
    # The rubric is a JSON structure describing expected agent behaviour.
    return [
        (
            f"Find all Python files that import 'os' in the project.",
            '{"should_use": "search_files", "min_patterns": ["import os"], "exclude": ["node_modules"]}'
        ),
        (
            "Review the latest PR for SQL injection vulnerabilities.",
            '{"should_check": ["raw SQL queries", "input sanitisation"], "red_flags": ["string concatenation"]}'
        ),
    ] * (count // 2)  # placeholders – real generator would be deterministic


# ------------------------------------------------------------------
# Step 3: Wrap skill as DSPy module and run GEPA optimization
# ------------------------------------------------------------------
def evolve_skill_with_gepa(
    skill_name: str,
    original_skill_path: Path,
    dataset_path: Path
) -> EvolutionSession:
    """
    Core GEPA loop:
    1. Read current skill text.
    2. Wrap in a DSPy Signature.
    3. Compose a DSPy ReAct module (agent) with the skill as system prompt.
    4. Run `dspy.GEPA` optimizer to mutate the skill text.
    5. Evaluate each candidate on the training set, respecting constraints.
    6. Return the best valid candidate.
    """
    session = EvolutionSession(
        skill_name=skill_name,
        original_path=original_skill_path,
        eval_dataset_path=dataset_path,
        baseline_score=_evaluate_skill_text(original_skill_path.read_text(), dataset_path, mode="val")
    )
    logger.info(f"Baseline score for '{skill_name}': {session.baseline_score:.4f}")

    # --------------------------------------------------------------
    # Build DSPy module
    # --------------------------------------------------------------
    # The skill text is treated as a single string parameter to be evolved.
    # We wrap it in a DSPy Signature that defines the I/O schema.
    class SkillPrompt(dspy.Signature):
        """A skill that guides the agent's behaviour on a specific task."""
        instruction_text: str  # the evolvable skill text
        user_input: str        # the user's request
        agent_response: str    # the expected output (rubric)

    # Compose a ReAct agent that reads the skill as its system prompt.
    class SkillGuidedAgent(dspy.ReAct):
        def __init__(self):
            super().__init__(SkillPrompt)
            # The ReAct module will use `instruction_text` as the system prompt
            # and generate tool calls based on the skill's guidance.

    # Initialise with the current skill text.
    agent = SkillGuidedAgent()
    agent.instruction_text = original_skill_path.read_text()

    # --------------------------------------------------------------
    # Set up constraints (as defined in PLAN.md guardrails)
    # --------------------------------------------------------------
    constraints = [
        TextLengthConstraint(max_chars=15000),  # skill files must be ≤15KB
        TestSuiteConstraint(HERMES_AGENT_REPO / "tests"),  # must pass all tests
    ]

    # Define fitness function: evaluate on the training split of the dataset.
    def fitness_fn(predicted, gold, trace=None):
        # predicted is the agent's output, gold is the expected rubric
        return SkillFitness.compute_score(predicted, gold)

    # --------------------------------------------------------------
    # Run GEPA optimizer
    # --------------------------------------------------------------
    gepat = GEPA(
        metric=fitness_fn,
        num_candidates=GEPA_EVAL_BUDGET,
        population_size=GEPA_POPULATION_SIZE,
        constraints=constraints,
        max_iterations=GEPA_ITERATIONS,
        track_traces=True  # GEPA's reflective analysis uses execution traces
    )

    # Load the evaluation dataset as DSPy examples.
    dataset = DatasetBuilder.load_dspy(dataset_path, split="train")

    # Optimize!
    optimized_agent = gepat.compile(
        agent,
        trainset=dataset,
        valset=DatasetBuilder.load_dspy(dataset_path, split="val"),
        requires_permission_to_run=False  # we handle safety ourselves
    )

    # Retrieve the evolved skill text from the optimized ReAct module.
    evolved_skill_text = optimized_agent.instruction_text
    session.evolved_score = _evaluate_skill_text(evolved_skill_text, dataset_path, mode="holdout")
    session.evolved_score = _evaluate_skill_text(evolved_skill_text, dataset_path, mode="holdout")

    if session.evolved_score > session.baseline_score:
        session.improved_skill_text = evolved_skill_text
        logger.info(f"Evolution successful: +{session.evolved_score - session.baseline_score:.4f}")
    else:
        logger.info("No improvement – discarding the evolved skill.")
        session.improved_skill_text = None

    return session


def _evaluate_skill_text(skill_text: str, dataset_path: Path, mode: str = "holdout") -> float:
    """
    Runs the agent (with the given skill text) on the specified split of the
    evaluation dataset, and returns the average fitness score.
    """
    agent = AIAgent(system_prompt=skill_text)  # instantiate actual Hermes agent
    examples = DatasetBuilder.load_dspy(dataset_path, split=mode)
    scores = []
    for ex in examples:
        response = agent.run(ex.user_input)  # synchronous call for eval
        score = SkillFitness.compute_score(response, ex.agent_response)
        scores.append(score)
    return sum(scores) / len(scores) if scores else 0.0


# ------------------------------------------------------------------
# Step 4: Benchmark gating (TBLite + YC-Bench fast_test)
# ------------------------------------------------------------------
def run_benchmark_gate(skill_text: str) -> bool:
    """
    Run a fast subset of TBLite (20 tasks) and YC-Bench fast_test (50 turns).
    Return True only if both hold within 2% of the baseline (which is stored
    in a reference file). In production you'd also run the full suite before PR.
    """
    # Save the candidate skill to a temporary file
    tmp_skill = SKILLS_DIR / "tmp_evolved_skill.md"
    tmp_skill.write_text(skill_text)

    # Run TBLite fast subset (20 tasks)
    result_tblite = subprocess.run(
        ["bash", str(BENCHMARK_SCRIPT), "--fast", "--skill", str(tmp_skill)],
        capture_output=True, text=True, cwd=HERMES_AGENT_REPO
    )
    tblite_score = float(result_tblite.stdout.strip().split()[-1])  # last token is score

    # Run YC-Bench fast_test (requires Hermes CLI)
    result_yc = subprocess.run(
        ["hermes", "benchmark", "yc_bench", "--fast-test", "--skill", str(tmp_skill)],
        capture_output=True, text=True, cwd=HERMES_AGENT_REPO
    )
    yc_score = float(result_yc.stdout.strip().split()[-1])

    # Load baseline scores (from previous run)
    baseline_path = DATASET_DIR / "baselines.json"
    with open(baseline_path) as f:
        baselines = json.load(f)

    passed = True
    for benchmark, current in [("tblite_fast", tblite_score), ("yc_fast", yc_score)]:
        baseline = baselines.get(benchmark, current)  # if missing, accept once
        if current < baseline * 0.98:
            logger.error(f"Benchmark regression: {benchmark} dropped from {baseline:.2f} to {current:.2f}")
            passed = False
        else:
            logger.info(f"Benchmark {benchmark}: {current:.2f} (baseline {baseline:.2f}) – OK")

    return passed


# ------------------------------------------------------------------
# Step 5: Commit to git branch and generate PR
# ------------------------------------------------------------------
def deploy_improvement(session: EvolutionSession):
    """
    Writes the evolved skill file, creates a git branch, runs full test suite,
    and outputs a PR summary. The human operator merges it.
    """
    if session.improved_skill_text is None:
        return

    # Write evolved skill (overwrite only after validation)
    evolved_path = session.original_path.parent / f"{session.original_path.stem}_evolved.md"
    evolved_path.write_text(session.improved_skill_text)
    logger.info(f"Evolved skill written to {evolved_path}")

    # Git operations
    repo = git.Repo(HERMES_AGENT_REPO)
    branch_name = f"evolve/skill-{session.skill_name}-{datetime.now():%Y%m%d%H%M}"
    if repo.active_branch.name != "main":
        logger.warning("Not on main branch – creating PR from current branch")
    repo.git.checkout("main")
    repo.git.pull()
    repo.git.checkout("-b", branch_name)

    # Stage and commit
    repo.index.add([str(evolved_path)])
    repo.index.commit(f"Evolved skill '{session.skill_name}' via GEPA\n\n"
                      f"Baseline score: {session.baseline_score:.4f}\n"
                      f"Evolved score: {session.evolved_score:.4f}")

    # Run full test suite inside the repo
    test_result = subprocess.run(
        ["pytest", "tests/", "-q"],
        cwd=HERMES_AGENT_REPO,
        capture_output=True, text=True
    )
    if test_result.returncode != 0:
        logger.error("Full test suite failed – rolling back commit")
        repo.git.checkout("main")
        repo.git.branch("-D", branch_name)
        return

    # Run full benchmarks (optional, time‑consuming)
    # subprocess.run(...)

    # Generate PR content
    pr_body = f"""
## Self‑Evolution PR: `{session.skill_name}`

**Baseline score:** {session.baseline_score:.4f}
**Evolved score:** {session.evolved_score:.4f}
**Δ:** +{session.evolved_score - session.baseline_score:.4f}

### Summary of changes

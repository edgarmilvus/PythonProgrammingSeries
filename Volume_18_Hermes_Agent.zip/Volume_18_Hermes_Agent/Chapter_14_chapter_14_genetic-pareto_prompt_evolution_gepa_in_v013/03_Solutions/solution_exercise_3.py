
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import json
import yaml
import logging
from typing import List, Dict, Tuple
import plotly.graph_objects as go
import plotly.io as pio
from evolution.tools.evolve_tool_descriptions import ToolDescriptionOptimizer

def is_dominated(candidate: Dict, population: List[Dict]) -> bool:
    """Check if candidate is dominated by any other candidate in population."""
    for other in population:
        if other["candidate_id"] == candidate["candidate_id"]:
            continue
        # For maximization objectives (accuracy): higher is better
        # For minimization objectives (cost, length): lower is better
        better_or_equal = True
        strictly_better = False
        # accuracy: maximize
        if other["selection_accuracy"] < candidate["selection_accuracy"]:
            better_or_equal = False
        elif other["selection_accuracy"] > candidate["selection_accuracy"]:
            strictly_better = True
        # cost: minimize
        if other["avg_cost_per_call"] > candidate["avg_cost_per_call"]:
            better_or_equal = False
        elif other["avg_cost_per_call"] < candidate["avg_cost_per_call"]:
            strictly_better = True
        # length: minimize
        if other["description_length"] > candidate["description_length"]:
            better_or_equal = False
        elif other["description_length"] < candidate["description_length"]:
            strictly_better = True

        if better_or_equal and strictly_better:
            return True
    return False

def compute_pareto_front(candidates: List[Dict]) -> List[Dict]:
    """Mark each candidate as Pareto optimal or not."""
    for cand in candidates:
        cand["is_pareto_optimal"] = not is_dominated(cand, candidates)
    return candidates

def generate_pareto_plot(candidates: List[Dict], iteration: int, output_dir: str = "evolution/outputs/tool_descriptions"):
    """Generate interactive 3D scatter plot using Plotly."""
    pareto_points = [c for c in candidates if c["is_pareto_optimal"]]
    dominated_points = [c for c in candidates if not c["is_pareto_optimal"]]

    fig = go.Figure()

    # Pareto-optimal points (green stars)
    if pareto_points:
        fig.add_trace(go.Scatter3d(
            x=[c["selection_accuracy"] for c in pareto_points],
            y=[c["avg_cost_per_call"] for c in pareto_points],
            z=[c["description_length"] for c in pareto_points],
            mode='markers+text',
            marker=dict(size=8, color='green', symbol='star'),
            text=[str(c["candidate_id"]) for c in pareto_points],
            textposition="top center",
            name='Pareto-optimal'
        ))

    # Dominated points (red circles)
    if dominated_points:
        fig.add_trace(go.Scatter3d(
            x=[c["selection_accuracy"] for c in dominated_points],
            y=[c["avg_cost_per_call"] for c in dominated_points],
            z=[c["description_length"] for c in dominated_points],
            mode='markers+text',
            marker=dict(size=5, color='red', symbol='circle'),
            text=[str(c["candidate_id"]) for c in dominated_points],
            textposition="top center",
            name='Dominated'
        ))

    # Baseline (blue square)
    baseline = [c for c in candidates if c.get("is_baseline")]
    if baseline:
        b = baseline[0]
        fig.add_trace(go.Scatter3d(
            x=[b["selection_accuracy"]],
            y=[b["avg_cost_per_call"]],
            z=[b["description_length"]],
            mode='markers+text',
            marker=dict(size=12, color='blue', symbol='square'),
            text=[str(b["candidate_id"])],
            textposition="top center",
            name='Baseline'
        ))

    fig.update_layout(
        title=f"Pareto Front - Iteration {iteration}",
        scene=dict(
            xaxis_title="Selection Accuracy",
            yaxis_title="Avg Cost per Call (USD)",
            zaxis_title="Description Length (chars)",
            xaxis=dict(range=[0.5, 1.0]),
            yaxis=dict(range=[0, 0.05]),
            zaxis=dict(range=[50, 500])
        ),
        legend=dict(x=0, y=1)
    )

    os.makedirs(output_dir, exist_ok=True)
    filepath = os.path.join(output_dir, f"pareto_front_iteration_{iteration}.html")
    pio.write_html(fig, filepath)
    logging.info(f"Pareto plot saved to {filepath}")

def select_from_pareto_front(pareto_candidates: List[Dict], preference_weights: Dict[str, float]) -> Dict:
    """Select candidate with highest weighted sum score after normalization."""
    if not pareto_candidates:
        return None

    # Extract values for normalization
    accuracies = [c["selection_accuracy"] for c in pareto_candidates]
    costs = [c["avg_cost_per_call"] for c in pareto_candidates]
    lengths = [c["description_length"] for c in pareto_candidates]

    min_acc, max_acc = min(accuracies), max(accuracies)
    min_cost, max_cost = min(costs), max(costs)
    min_len, max_len = min(lengths), max(lengths)

    best_candidate = None
    best_score = -float('inf')

    for cand in pareto_candidates:
        # Normalize each objective to [0,1]; for minimization, invert (1 - normalized)
        norm_acc = (cand["selection_accuracy"] - min_acc) / (max_acc - min_acc) if max_acc != min_acc else 1.0
        norm_cost = 1.0 - (cand["avg_cost_per_call"] - min_cost) / (max_cost - min_cost) if max_cost != min_cost else 1.0
        norm_len = 1.0 - (cand["description_length"] - min_len) / (max_len - min_len) if max_len != min_len else 1.0

        weighted_score = (preference_weights.get("accuracy", 0.5) * norm_acc +
                          preference_weights.get("cost", 0.3) * norm_cost +
                          preference_weights.get("length", 0.2) * norm_len)

        if weighted_score > best_score:
            best_score = weighted_score
            best_candidate = cand

    return best_candidate

def load_preference_weights(tool_name: str, config_path: str = "evolution/configs/tool_preferences.yaml") -> Dict[str, float]:
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)
    prefs = config["tool_preferences"].get(tool_name, {})
    return {
        "accuracy": prefs.get("accuracy_weight", 0.5),
        "cost": prefs.get("cost_weight", 0.3),
        "length": prefs.get("length_weight", 0.2)
    }

# Modified ToolDescriptionOptimizer.run_iteration to return candidate data
def run_iteration_with_pareto(self, iteration):
    # ... existing evaluation code ...
    candidates_data = []  # list of dicts with required keys
    # After evaluating all candidates:
    candidates_data = compute_pareto_front(candidates_data)
    generate_pareto_plot(candidates_data, iteration)
    return candidates_data


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import yaml
import logging
import random
from typing import Dict, List, Tuple
from evolution.core.batch_runner import batch_runner
from evolution.prompts.evolve_prompt_section import PromptSectionOptimizer

# Load constraints from YAML
def load_constraints(config_path: str = "evolution/configs/prompt_constraints.yaml") -> List[Dict]:
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)
    return config.get("constraints", [])

class ConstraintValidator:
    def __init__(self, constraints: List[Dict] = None):
        self.constraints = constraints or load_constraints()

    def validate(self, candidate_prompts: Dict[str, str]) -> Tuple[bool, List[str]]:
        """Validate all constraints against the given prompt sections.
        Returns (is_valid, violations_list)."""
        violations = []
        for constraint in self.constraints:
            sections = constraint["sections"]
            rule = constraint["rule"]
            # Check if all referenced sections exist in candidate_prompts
            missing = [s for s in sections if s not in candidate_prompts]
            if missing:
                logging.warning(f"Skipping constraint because sections {missing} not in prompt config")
                continue
            # For simplicity, we use an LLM to check consistency
            prompt = f"""
            Given the following prompt sections and a consistency rule, determine if the rule is violated.
            Sections:
            {chr(10).join(f"--- {sec} ---{chr(10)}{candidate_prompts[sec]}" for sec in sections)}
            Rule: {rule}
            Answer only "VIOLATED" or "SATISFIED".
            """
            response = batch_runner.run_with_llm(prompt, model="gpt-4o-mini")
            if "VIOLATED" in response.upper():
                violations.append(f"Sections {sections} violate rule: '{rule}'")
        return len(violations) == 0, violations

class ConstraintAwareMutator:
    def __init__(self, validator: ConstraintValidator):
        self.validator = validator
        self.max_repair_attempts = 3

    def mutate_section(self, section_name: str, current_text: str, all_sections: Dict[str, str]) -> str:
        """Mutate a section with constraint-aware repair."""
        # Default mutation
        mutated = PromptSectionOptimizer.default_mutate(current_text)

        # Test after mutation
        test_prompts = all_sections.copy()
        test_prompts[section_name] = mutated
        is_valid, violations = self.validator.validate(test_prompts)

        if is_valid:
            return mutated

        # Repair attempts
        for attempt in range(1, self.max_repair_attempts + 1):
            # For each violated constraint, randomly select a conflicting section to re-mutate
            for violation in violations:
                # Parse violation to get sections (simplified: we can re-mutate the original section)
                # Actually, we need to identify which sections are involved; we'll re-mutate the section that was changed.
                repair_prompt = f"""
                Original section text: {current_text}
                Mutated text that caused violation: {mutated}
                Constraint rule: {violation}
                Conflicting sections: {', '.join(test_prompts.keys())}
                Rewrite this section to satisfy the constraint while preserving its original purpose.
                """
                # Use LLM to generate repair
                repaired = batch_runner.run_with_llm(repair_prompt, model="gpt-4o-mini")
                test_prompts[section_name] = repaired
                is_valid, violations = self.validator.validate(test_prompts)
                if is_valid:
                    logging.info(f"Repair successful after {attempt} attempt(s)")
                    return repaired
                # Log violation
                logging.error(
                    f"VIOLATION: sections={violation['sections']}, rule=\"{violation['rule']}\", "
                    f"candidate_id={section_name}, repair_attempt={attempt}"
                )
        # Fallback to original
        logging.warning(f"Repair failed after {self.max_repair_attempts} attempts, returning original")
        return current_text

# Integration into PromptSectionOptimizer
class PromptSectionOptimizer:
    @staticmethod
    def default_mutate(text: str) -> str:
        # Placeholder for default GEPA mutation
        return text + " [mutated]"

    def __init__(self, constraint_config: str = None):
        self.validator = ConstraintValidator(load_constraints(constraint_config) if constraint_config else [])
        self.mutator = ConstraintAwareMutator(self.validator)

    def mutate_section(self, section_name: str, current_text: str, all_sections: Dict[str, str]) -> str:
        return self.mutator.mutate_section(section_name, current_text, all_sections)

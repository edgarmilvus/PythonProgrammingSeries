
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import json
import os
import functools
from typing import List, Dict, Any
from evolution.core.dataset_builder import SessionDBMiner
from evolution.core.batch_runner import batch_runner
from evolution.core.fitness import FitnessScorer

# Define base FitnessScorer interface
class FitnessScorer:
    def score(self, trajectory: List[str], task_input: str) -> float:
        raise NotImplementedError

class SystematicDebuggingScorer(FitnessScorer):
    def __init__(self, model: str = "gpt-4o"):
        self.model = model
        self.rubric = """
        Evaluate the trajectory on three axes (0-1):
        1. Procedure Adherence: Did the agent follow steps: reproduce bug, isolate cause, test hypothesis, fix, verify?
        2. Root Cause Accuracy: Was the identified root cause correct based on available info?
        3. Solution Completeness: Did the final fix address all aspects of the bug?
        Return a JSON object with keys: adherence, accuracy, completeness.
        """

    @functools.lru_cache(maxsize=1000)
    def _score_cached(self, trajectory_str: str, task_input: str) -> Dict[str, float]:
        prompt = f"""
        Task input: {task_input}
        Agent trajectory: {trajectory_str}
        Rubric:
        {self.rubric}
        Output only JSON.
        """
        response = batch_runner.run_with_llm(prompt, model=self.model)
        try:
            scores = json.loads(response)
            return {
                "adherence": float(scores["adherence"]),
                "accuracy": float(scores["accuracy"]),
                "completeness": float(scores["completeness"])
            }
        except (json.JSONDecodeError, KeyError, ValueError):
            return {"adherence": 0.5, "accuracy": 0.5, "completeness": 0.5}

    def score(self, trajectory: List[str], task_input: str) -> Dict[str, float]:
        trajectory_str = "\n".join(trajectory)
        return self._score_cached(trajectory_str, task_input)

def build_systematic_debugging_dataset():
    miner = SessionDBMiner()
    all_sessions = miner.get_all_sessions()
    scorer = SystematicDebuggingScorer()

    skill_sessions = []
    for session in all_sessions:
        messages = session.get("messages", [])
        # Check if skill was loaded
        skill_loaded = any(
            "Skill: systematic-debugging" in msg.get("content", "")
            for msg in messages if msg.get("role") == "system"
        )
        if not skill_loaded:
            continue

        # Extract task input and trajectory
        task_input = ""
        trajectory = []
        for msg in messages:
            if msg.get("role") == "user":
                task_input = msg.get("content", "")
            elif msg.get("role") == "assistant":
                trajectory.append(msg.get("content", ""))

        # Edge case: skill loaded but not used (no assistant messages after skill mention)
        if not trajectory:
            continue
        # Edge case: minimum trajectory length
        if len(trajectory) < 3:
            continue

        skill_sessions.append({
            "session_id": session.get("id"),
            "task_input": task_input,
            "agent_trajectory": trajectory
        })

    # Score each session
    output_dir = os.path.expanduser("~/.hermes/evolution/datasets/systematic-debugging")
    os.makedirs(output_dir, exist_ok=True)
    output_file = os.path.join(output_dir, "train.jsonl")

    with open(output_file, "w") as f:
        for sess in skill_sessions:
            rubric_scores = scorer.score(sess["agent_trajectory"], sess["task_input"])
            final_score = 0.3 * rubric_scores["adherence"] + 0.5 * rubric_scores["accuracy"] + 0.2 * rubric_scores["completeness"]
            record = {
                "session_id": sess["session_id"],
                "task_input": sess["task_input"],
                "agent_trajectory": sess["agent_trajectory"],
                "rubric_scores": rubric_scores,
                "final_score": round(final_score, 2)
            }
            f.write(json.dumps(record) + "\n")

    print(f"Dataset generated with {len(skill_sessions)} sessions at {output_file}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_6.py
# Description: Solution for Exercise 6
# ==========================================

import json
import yaml
import logging
from typing import Dict, List, Optional
from evolution.core.batch_runner import batch_runner
from evolution.skills.evolve_skill import GEPAOptimizer
from evolution.skills.skill_module import SkillModule
import time

# Load hierarchy rules
def load_hierarchy_rules(config_path: str = "evolution/configs/hierarchy_rules.yaml") -> Dict:
    with open(config_path, "r") as f:
        return yaml.safe_load(f)

class HierarchicalTraceAnalyzer:
    def __init__(self, rules: Dict = None):
        self.rules = rules or load_hierarchy_rules()
        self.tree_cache = {}  # trajectory_hash -> tree

    def parse_trajectory_to_tree(self, trajectory: List[Dict]) -> Dict:
        """Convert flat list of turns into a tree structure.
        Each turn is a dict with 'role', 'content', 'tool_calls' etc.
        """
        # Use hash for caching
        traj_hash = hash(str(trajectory))
        if traj_hash in self.tree_cache:
            return self.tree_cache[traj_hash]

        root = {"type": "root", "children": [], "depth": 0}
        stack = [root]
        current_depth = 0
        for turn in trajectory:
            node = {
                "type": "turn",
                "role": turn.get("role"),
                "content": turn.get("content", ""),
                "tool_calls": turn.get("tool_calls", []),
                "children": [],
                "depth": current_depth
            }
            # If turn contains tool calls that return sub-results, those become children
            if node["tool_calls"]:
                for tc in node["tool_calls"]:
                    if tc.get("result", {}).get("sub_calls"):
                        # Create child nodes for each sub-call
                        for sub in tc["result"]["sub_calls"]:
                            child_node = {
                                "type": "sub_tool_call",
                                "tool": sub.get("tool"),
                                "content": sub.get("output", ""),
                                "children": [],
                                "depth": current_depth + 1
                            }
                            node["children"].append(child_node)
            # Attach to parent based on depth (simplified: always attach to last node at depth-1)
            while len(stack) > current_depth + 1:
                stack.pop()
            stack[-1]["children"].append(node)
            stack.append(node)
            current_depth += 1

        self.tree_cache[traj_hash] = root
        return root

    def detect_failure_patterns(self, tree: Dict, skill_steps: List[str]) -> List[Dict]:
        """Rule-based detection of failure patterns."""
        patterns = []

        # 1. Sub-task omission: check if any skill step is missing in the trajectory
        # Extract all actions from tree (flatten)
        actions = []
        def flatten(node, depth):
            actions.append((node.get("content", ""), depth))
            for child in node.get("children", []):
                flatten(child, depth+1)
        flatten(tree, 0)
        action_texts = [a[0] for a in actions]

        for step in skill_steps:
            # Simple keyword matching (could be more sophisticated)
            if not any(step.lower() in action.lower() for action in action_texts):
                patterns.append({
                    "pattern_type": "sub_task_omission",
                    "missing_step": step,
                    "position_in_skill": f"step_{skill_steps.index(step)+1}",
                    "suggested_text": "",
                    "severity": "high"
                })

        # 2. Incorrect decomposition: check if tool calls are in logical order
        # e.g., searching for error before reproducing bug
        # Rule: if 'reproduce' comes after 'search' in actions, it's incorrect
        # Simplified rule from config
        incorrect_order_rules = self.rules.get("incorrect_decomposition", [])
        for rule in incorrect_order_rules:
            first_action = rule.get("first")
            second_action = rule.get("second")
            first_pos = None
            second_pos = None
            for i, (text, _) in enumerate(actions):
                if first_action in text:
                    first_pos = i
                if second_action in text:
                    second_pos = i
            if first_pos is not None and second_pos is not None and first_pos > second_pos:
                patterns.append({
                    "pattern_type": "incorrect_decomposition",
                    "description": f"Action '{first_action}' occurred after '{second_action}', should be before",
                    "severity": "medium",
                    "suggested_text": ""
                })

        # 3. Redundant work: detect duplicate tool calls with same parameters
        tool_calls_seen = set()
        for text, _ in actions:
            # Extract tool call signature (simplified)
            if "tool:" in text:
                tool_sig = text.split("tool:")[1].split("\n")[0].strip()
                if tool_sig in tool_calls_seen:
                    patterns.append({
                        "pattern_type": "redundant_work",
                        "description": f"Duplicate tool call: {tool_sig}",
                        "severity": "low",
                        "suggested_text": ""
                    })
                else:
                    tool_calls_seen.add(tool_sig)

        return patterns

    def generate_suggestions(self, skill_text: str, tree: Dict, patterns: List[Dict]) -> List[Dict]:
        """Use LLM to generate actionable improvement suggestions."""
        prompt = f"""
        Skill text:
        {skill_text}

        Trajectory tree (JSON):
        {json.dumps(tree, indent=2)}

        Detected failure patterns:
        {json.dumps(patterns, indent=2)}

        For each pattern, generate a precise, actionable text improvement that could be added to the skill to prevent this failure.
        Output a JSON list of suggestions, each with keys: pattern_type, suggested_text, position_in_skill.
        """
        response = batch_runner.run_with_llm(prompt, model="gpt-4o")
        try:
            suggestions = json.loads(response)
            return suggestions
        except json.JSONDecodeError:
            return []

    def analyze(self, skill_text: str, trajectory: List[Dict]) -> Dict:
        """Full analysis pipeline."""
        tree = self.parse_trajectory_to_tree(trajectory)
        skill_struct = SkillModule.parse_skill_structure(skill_text)
        steps = skill_struct.get("steps", [])
        patterns = self.detect_failure_patterns(tree, steps)
        suggestions = self.generate_suggestions(skill_text, tree, patterns)
        return {
            "tree": tree,
            "patterns": patterns,
            "suggestions": suggestions
        }

# Integration into GEPAOptimizer.mutate_candidate
class GEPAOptimizer:
    def mutate_candidate(self, candidate_text: str, suggestions: List[Dict] = None) -> str:
        if suggestions:
            # Prioritize inserting or modifying text based on suggestions
            for sug in suggestions:
                if sug["pattern_type"] == "sub_task_omission":
                    # Add missing step text to the skill
                    candidate_text += f"\n- {sug['suggested_text']}"
                elif sug["pattern_type"] == "incorrect_decomposition":
                    # Replace a section with corrected order
                    candidate_text = candidate_text.replace("## Steps", f"## Steps\n{sug['suggested_text']}")
                # ... other patterns
            logging.info(f"Suggestion-driven mutation applied: {suggestions}")
        else:
            # Default mutation
            candidate_text = self.default_mutate(candidate_text)
        return candidate_text

# Integration into SkillEvolutionPipeline
class SkillEvolutionPipeline:
    def run_optimization(self, skill_name: str, iterations: int = 5, hierarchical_analysis: bool = False):
        if hierarchical_analysis:
            analyzer = HierarchicalTraceAnalyzer()
            # Assume trajectory data is available (e.g., from SessionDB)
            trajectory = self.get_trajectory_for_skill(skill_name)
            skill_text = self.load_skill_text(skill_name)
            analysis = analyzer.analyze(skill_text, trajectory)
            suggestions = analysis["suggestions"]
            # Save analysis output
            output_dir = f"evolution/outputs/hierarchical_analysis/{skill_name}"
            os.makedirs(output_dir, exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            with open(os.path.join(output_dir, f"{timestamp}.json"), "w") as f:
                json.dump(analysis, f, indent=2)
        else:
            suggestions = None

        # Run GEPA with suggestions
        optimizer = GEPAOptimizer()
        for i in range(iterations):
            candidate = optimizer.mutate_candidate(skill_text, suggestions)
            # ... evaluate, select, etc.

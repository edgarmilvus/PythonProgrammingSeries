
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import random
import logging
from typing import List, Dict
from evolution.skills.skill_module import SkillModule

# Configure logging
logging.basicConfig(filename="evolution/logs/crossover.log", level=logging.INFO,
                    format="%(asctime)s %(message)s", datefmt="%Y-%m-%d %H:%M:%S")

def skill_crossover(parent1_text: str, parent2_text: str, seed: int = None) -> str:
    if seed is not None:
        random.seed(seed)

    # Parse both parents
    struct1 = SkillModule.parse_skill_structure(parent1_text)
    struct2 = SkillModule.parse_skill_structure(parent2_text)

    # Helper to pad lists to same length
    def pad_list(lst: List, target_len: int) -> List:
        if len(lst) >= target_len:
            return lst
        return lst + [lst[-1]] * (target_len - len(lst)) if lst else [""] * target_len

    max_steps = max(len(struct1["steps"]), len(struct2["steps"]))
    steps1 = pad_list(struct1["steps"], max_steps)
    steps2 = pad_list(struct2["steps"], max_steps)

    max_examples = max(len(struct1["examples"]), len(struct2["examples"]))
    examples1 = pad_list(struct1["examples"], max_examples)
    examples2 = pad_list(struct2["examples"], max_examples)

    # Two-point crossover on steps
    i, j = sorted(random.sample(range(1, max_steps), 2))  # ensure i<j and not at boundaries
    child_steps = steps1[:i] + steps2[i:j] + steps1[j:]

    # Uniform crossover on examples
    child_examples = [random.choice([examples1[k], examples2[k]]) for k in range(max_examples)]

    # Random selection for other components
    child_struct = {
        "title": random.choice([struct1["title"], struct2["title"]]),
        "description": random.choice([struct1["description"], struct2["description"]]),
        "steps": child_steps,
        "examples": child_examples,
        "notes": random.choice([struct1["notes"], struct2["notes"]])
    }

    # Reconstruct
    child_text = SkillModule.build_skill_text(child_struct)

    # Validate
    for attempt in range(5):
        if validate_child(child_text):
            logging.info(
                f"CROSSOVER: parent1_len={len(parent1_text)}, parent2_len={len(parent2_text)}, "
                f"child_len={len(child_text)}, steps_crossover_indices=({i},{j})"
            )
            return child_text
        # Retry with new random indices
        i, j = sorted(random.sample(range(1, max_steps), 2))
        child_steps = steps1[:i] + steps2[i:j] + steps1[j:]
        child_struct["steps"] = child_steps
        child_text = SkillModule.build_skill_text(child_struct)

    # Fallback: return parent1 if all attempts fail
    logging.warning("Crossover failed after 5 attempts, returning parent1")
    return parent1_text

def validate_child(text: str) -> bool:
    # Must contain exactly one # Title line at top
    lines = text.strip().split("\n")
    if not lines or not lines[0].startswith("# "):
        return False
    # Must contain at least one step in ## Steps section
    if "## Steps" not in text:
        return False
    # Extract steps after ## Steps
    steps_section = text.split("## Steps")[1].split("##")[0] if "## Steps" in text else ""
    steps = [s.strip() for s in steps_section.split("\n") if s.strip().startswith("-") or s.strip().startswith("1.")]
    if len(steps) < 1:
        return False
    # Total length <= 15KB
    if len(text.encode("utf-8")) > 15 * 1024:
        return False
    return True

# Integration with GEPAOptimizer (modification of evolve_population)
def evolve_population_with_crossover(self, population, crossover_rate=0.3):
    import random
    new_population = []
    for i in range(0, len(population), 2):
        p1 = population[i]
        p2 = population[i+1] if i+1 < len(population) else population[0]
        if random.random() < crossover_rate:
            child = skill_crossover(p1, p2, seed=random.randint(0, 10000))
        else:
            child = self.default_mutate(p1)  # default mutation
        new_population.append(child)
    return new_population

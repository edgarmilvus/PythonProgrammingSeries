
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import os
import json
import logging
import tempfile
from datetime import datetime, timedelta, timezone
from typing import Dict, List
from git import Repo
from schedule import every, run_pending
import threading
import time
from evolution.core.session_db import SessionDB
from evolution.skills.evolve_skill import run_optimization
from evolution.core.benchmark_gate import BenchmarkGate
from evolution.monitor.performance_monitor import PerformanceMonitor  # base class

# Configure logging
logging.basicConfig(filename="evolution/logs/auto_optimize.log", level=logging.INFO,
                    format="%(asctime)s %(message)s")

class PerformanceMonitor:
    def __init__(self, skills_dir: str = "skills/", repo_path: str = "."):
        self.skills_dir = skills_dir
        self.repo = Repo(repo_path)
        self.db = SessionDB()
        self.benchmark_gate = BenchmarkGate()
        self._optimization_locks = {}  # skill_name -> start_time

    def track_skill_performance(self, skill_name: str, window_hours: int = 168) -> Dict:
        """Query SessionDB for sessions in last window_hours where skill was loaded."""
        cutoff = datetime.now(timezone.utc) - timedelta(hours=window_hours)
        sessions = self.db.get_sessions_since(cutoff)
        skill_sessions = []
        for sess in sessions:
            messages = sess.get("messages", [])
            if any("Skill: " + skill_name in msg.get("content", "") for msg in messages if msg.get("role") == "system"):
                skill_sessions.append(sess)

        # Score each session using SystematicDebuggingScorer or generic scorer
        from evolution.exercise1 import SystematicDebuggingScorer  # reuse
        scorer = SystematicDebuggingScorer()
        scores = []
        for sess in skill_sessions:
            task_input = ""
            trajectory = []
            for msg in sess.get("messages", []):
                if msg.get("role") == "user":
                    task_input = msg.get("content", "")
                elif msg.get("role") == "assistant":
                    trajectory.append(msg.get("content", ""))
            if trajectory:
                rubric = scorer.score(trajectory, task_input)
                final = 0.3 * rubric["adherence"] + 0.5 * rubric["accuracy"] + 0.2 * rubric["completeness"]
                scores.append(final)

        if not scores:
            avg_score = 0.0
        else:
            avg_score = sum(scores) / len(scores)

        # Compute trend: compare last 24h vs previous 6 days
        recent_cutoff = datetime.now(timezone.utc) - timedelta(hours=24)
        recent_sessions = [s for s in skill_sessions if s.get("timestamp", datetime.min) >= recent_cutoff]
        recent_scores = []
        for sess in recent_sessions:
            # simplified scoring
            recent_scores.append(0.8)  # placeholder
        recent_avg = sum(recent_scores) / len(recent_scores) if recent_scores else 0.0
        previous_scores = [s for s in scores if s not in recent_scores]  # approximate
        prev_avg = sum(previous_scores) / len(previous_scores) if previous_scores else 0.0

        if recent_avg > prev_avg * 1.05:
            trend = "improving"
        elif recent_avg < prev_avg * 0.95:
            trend = "declining"
        else:
            trend = "stable"

        # Get last optimization time from git log of skill file
        skill_file = os.path.join(self.skills_dir, skill_name, "SKILL.md")
        try:
            commits = list(self.repo.iter_commits(paths=skill_file, max_count=1))
            last_optimized = commits[0].committed_datetime.isoformat() if commits else "never"
        except:
            last_optimized = "unknown"

        return {
            "skill_name": skill_name,
            "total_sessions": len(skill_sessions),
            "avg_score": round(avg_score, 2),
            "score_trend": trend,
            "sessions_per_day": round(len(skill_sessions) / (window_hours / 24), 2),
            "last_optimized": last_optimized
        }

    def check_and_optimize(self, skill_name: str, threshold: float = 0.70):
        """Check performance and trigger optimization if needed."""
        # Skip if already being optimized
        if skill_name in self._optimization_locks:
            start = self._optimization_locks[skill_name]
            logging.info(f"SKIP: {skill_name} already being optimized (started at {start})")
            return

        perf = self.track_skill_performance(skill_name)
        if perf["avg_score"] < threshold and perf["score_trend"] == "declining":
            logging.info(f"[MONITOR] Triggering GEPA for {skill_name}: avg_score={perf['avg_score']}, trend={perf['score_trend']}")
            self._optimization_locks[skill_name] = datetime.now(timezone.utc).isoformat()

            try:
                # Run GEPA optimization
                run_optimization(skill_name, iterations=5)

                # Run benchmark gate
                logging.info(f"Benchmark gate started for {skill_name}")
                passed = self.benchmark_gate.run_tblite_fast()
                if passed:
                    # Create git branch and commit
                    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
                    branch_name = f"auto-evolve/{skill_name}/{timestamp}"
                    current_branch = self.repo.active_branch
                    new_branch = self.repo.create_head(branch_name)
                    new_branch.checkout()
                    skill_file = os.path.join(self.skills_dir, skill_name, "SKILL.md")
                    self.repo.index.add([skill_file])
                    self.repo.index.commit(f"Auto-evolve {skill_name} via GEPA")
                    # Push as draft PR (simplified: just log)
                    logging.info(f"Created branch {branch_name} and committed evolved skill. Draft PR would be created.")
                    current_branch.checkout()  # switch back
                else:
                    # Revert skill file
                    self.repo.git.checkout(skill_file)
                    logging.warning(f"Benchmark gate failed for {skill_name}, reverted skill file.")
            finally:
                del self._optimization_locks[skill_name]

    def run_monitor_loop(self, interval: int = 3600):
        """Cron loop that checks all known skills every interval seconds."""
        def loop():
            while True:
                # Load skills from skills directory
                skill_names = [d for d in os.listdir(self.skills_dir) if os.path.isdir(os.path.join(self.skills_dir, d))]
                for name in skill_names:
                    self.check_and_optimize(name)
                time.sleep(interval)

        thread = threading.Thread(target=loop, daemon=True)
        thread.start()
        # Allow main thread to handle Ctrl+C
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            logging.info("Monitor stopped by user.")

def load_monitor_state():
    state_file = os.path.expanduser("~/.hermes/evolution/monitor_state.json")
    try:
        with open(state_file, "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def save_monitor_state(state: Dict):
    state_file = os.path.expanduser("~/.hermes/evolution/monitor_state.json")
    # Atomic write using tempfile
    with tempfile.NamedTemporaryFile(mode='w', delete=False, dir=os.path.dirname(state_file)) as tmp:
        json.dump(state, tmp)
        tmp_path = tmp.name
    os.replace(tmp_path, state_file)

# CLI command (simplified)
if __name__ == "__main__":
    monitor = PerformanceMonitor()
    monitor.run_monitor_loop(interval=3600)

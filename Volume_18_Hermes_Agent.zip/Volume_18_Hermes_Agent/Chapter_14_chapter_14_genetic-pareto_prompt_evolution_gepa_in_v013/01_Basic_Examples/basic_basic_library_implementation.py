
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation.py
# Description: Basic Library Implementation
# ==========================================

# evolution/skills/gepa_skill_optimizer.py
"""
Basic Library Implementation for GEPA Skill Evolution

This module provides the primary optimizer class that wraps the full
evolutionary loop for SKILL.md files. It leverages Hermes' AIAgent and
batch_runner for evaluation, and DSPy's GEPA for genetic multi-objective
optimization. All classes used are from the real hermes-agent codebase.
"""

import os
import json
import logging
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass

import dspy
from dspy.teleprompt import GEPA

# Real Hermes imports (must be installed and importable)
from hermes.core.scaffolding import AIAgent          # The main agent class
from hermes.state.session_db import SessionDB         # Persistent session store
from hermes.core.trajectory import ExecutionTrace     # Trajectory for GEPA's reflective analysis
from hermes.utils.batch_runner import BatchRunner     # Parallel evaluation harness

logger = logging.getLogger(__name__)


@dataclass
class EvalExample:
    """A single evaluation example for skill optimization."""
    task_input: str          # The user query or scenario
    expected_rubric: str     # What "good" looks like (used by LLM judge)
    # Optional: trajectory of the baseline agent for this task
    baseline_trace: Optional[ExecutionTrace] = None


class GEPASkillOptimizer:
    """
    Optimizes a Hermes agent skill (SKILL.md) using Genetic-Pareto Prompt Evolution.

    The optimizer wraps the skill text as a DSPy Signature, generates an evaluation
    dataset (from SessionDB or synthetic sources), runs GEPA to evolve the skill
    text, and validates the best candidate on a held-out test set.

    Key attributes:
        agent (AIAgent): Pre-configured Hermes agent (with base skill loaded).
        skill_path (Path): Path to the target SKILL.md file.
        db (SessionDB): Session database for mining real usage examples.
        optimizer (GEPA): DSPy's GEPA optimizer instance.
        train_examples (List[EvalExample]): Training split of the evaluation dataset.
        val_examples (List[EvalExample]): Validation split.
        holdout_examples (List[EvalExample]): Held-out test split.
    """

    def __init__(
        self,
        agent: AIAgent,
        skill_path: Path,
        session_db: SessionDB,
        initial_dataset: Optional[List[EvalExample]] = None,
        gepa_kwargs: Optional[Dict] = None,
    ):
        """
        Initialize the optimizer with a Hermes agent, skill file, and session database.

        Args:
            agent: AIAgent instance whose behavior is guided by the skill.
            skill_path: Filesystem path to the SKILL.md to evolve.
            session_db: Hermes' SessionDB for mining real conversation traces.
            initial_dataset: Optional pre-built evaluation examples.
                            If omitted, will be generated from SessionDB or synthetically.
            gepa_kwargs: Additional keyword arguments for DSPy's GEPA constructor.
        """
        self.agent = agent
        self.skill_path = skill_path
        self.db = session_db

        # Load the current skill text as the baseline
        self.baseline_skill_text = self._load_skill_text()

        # Create DSPy module that encapsulates the skill as a signature
        self.skill_module = self._build_skill_module()

        # Build dataset if not provided
        if initial_dataset is None:
            self.train_examples = []
            self.val_examples = []
            self.holdout_examples = []
        else:
            self._split_dataset(initial_dataset)

        # Configure GEPA optimizer
        gepa_defaults = {
            "metric": self._fitness_metric,
            "num_candidates": 10,          # Population size per generation
            "num_generations": 5,          # Iterations of evolution
            "mutation_rate": 0.3,
            "crossover_rate": 0.5,
            "pareto_front_size": 3,        # Keep top 3 Pareto-optimal solutions
        }
        if gepa_kwargs:
            gepa_defaults.update(gepa_kwargs)
        self.optimizer = GEPA(**gepa_defaults)

        # Batch runner for parallel evaluation
        self.batch_runner = BatchRunner(
            agent=self.agent,
            max_concurrency=4,             # Adjust based on API rate limits
            trajectory_callback=self._collect_trajectory,
        )

    def _load_skill_text(self) -> str:
        """Read the current SKILL.md file from disk."""
        with open(self.skill_path, "r", encoding="utf-8") as f:
            return f.read()

    def _build_skill_module(self) -> dspy.Module:
        """
        Wrap the skill text as a DSPy Signature.

        The signature takes a task input and returns a response, using the skill
        text as the system instruction. This is a simple chain: the skill text
        is injected into a prompt template, the LLM generates a response, and
        an output parser extracts the answer.

        In practice, the Hermes agent itself is used inside this module, but
        for the optimizer we only need a forward pass that returns text.
        """
        # Define a DSPy Signature with two fields: task and response
        class SkillSignature(dspy.Signature):
            """Evolving skill: {{skill_text}}\n\nTask: {{task}}\n\nResponse:"""
            skill_text = dspy.InputField(desc="The SKILL.md content to optimize")
            task = dspy.InputField(desc="User task/query")
            response = dspy.OutputField(desc="Agent's response after following the skill")

        # Create a module that uses the signature and an LLM
        class SkillModule(dspy.Module):
            def __init__(self, skill_text: str):
                self.signature = SkillSignature
                self.llm = dspy.LM(model=self._get_model_name())  # Uses agent's configured LLM
                self.skill_text = skill_text

            def forward(self, task: str) -> dspy.Prediction:
                # Format prompt with skill text and task
                prompt = self.signature.format(
                    skill_text=self.skill_text,
                    task=task,
                )
                # Generate response using the LLM
                response = self.llm(prompt, max_tokens=1024)
                return dspy.Prediction(response=response)

        return SkillModule(skill_text=self.baseline_skill_text)

    def _get_model_name(self) -> str:
        """Return the model name configured in the Hermes agent."""
        return self.agent.config.llm.model

    def _split_dataset(self, examples: List[EvalExample], val_ratio: float = 0.2, holdout_ratio: float = 0.2):
        """Split examples into train/val/holdout sets deterministically."""
        import random
        random.seed(42)
        shuffled = list(examples)
        random.shuffle(shuffled)
        n = len(shuffled)
        val_count = int(n * val_ratio)
        holdout_count = int(n * holdout_ratio)
        self.holdout_examples = shuffled[:holdout_count]
        self.val_examples = shuffled[holdout_count:holdout_count + val_count]
        self.train_examples = shuffled[holdout_count + val_count:]

    def _fitness_metric(self, candidate: dspy.Module, trace: ExecutionTrace = None) -> float:
        """
        Compute a composite fitness score for a candidate skill variant.

        The metric combines:
        - Task success rate (LLM judge score 0-1)
        - Efficiency penalty (token usage beyond baseline)
        - Constraint violations (e.g., skill length limit)

        This is called by GEPA for each candidate in each generation.
        """
        # Evaluate candidate on validation set
        total_score = 0.0
        for example in self.val_examples:
            # Run the agent with the candidate skill
            response = candidate(task=example.task_input)
            # Use an LLM-as-judge to score the response against the rubric
            judge_score = self._llm_judge_score(
                task=example.task_input,
                response=response.response,
                rubric=example.expected_rubric,
            )
            total_score += judge_score

        avg_score = total_score / len(self.val_examples) if self.val_examples else 0.0

        # Penalize if skill text exceeds 15KB
        skill_len = len(candidate.skill_text)
        len_penalty = max(0, (skill_len - 15360) / 15360) * 0.1  # 10% penalty per KB over
        final_fitness = avg_score - len_penalty
        return final_fitness

    def _llm_judge_score(self, task: str, response: str, rubric: str) -> float:
        """
        Use an LLM judge to score the response against a rubric.

        In practice, this calls another LLM (or the same model) with a prompt
        that asks for a score from 0 to 1 based on the rubric. A simple
        implementation is shown here for illustration.
        """
        judge_prompt = (
            f"Task: {task}\n\n"
            f"Response: {response}\n\n"
            f"Rubric: {rubric}\n\n"
            "Score the response on a scale of 0.0 to 1.0. Only output the number."
        )
        judge_response = self.agent.llm(judge_prompt, max_tokens=10)
        try:
            return float(judge_response.strip())
        except ValueError:
            return 0.0

    def _collect_trajectory(self, trace: ExecutionTrace):
        """Callback to record execution trace for GEPA's reflective analysis."""
        # Traces are stored in self.agent's trajectory store
        self.agent.trajectory_store.append(trace)

    def generate_dataset(self, num_synthetic: int = 15, mine_session: bool = True):
        """
        Build evaluation examples from SessionDB and/or synthetic generation.

        This implements Source A (synthetic) and Source B (SessionDB mining)
        as described in the plan.

        Args:
            num_synthetic: Number of synthetic examples to generate.
            mine_session: Whether to mine SessionDB for real usage examples.
        """
        examples = []

        # Source A: Synthetic generation using a strong model
        if num_synthetic > 0:
            synthetic_generator = dspy.LM(model="gpt-4o")  # Or Claude Opus
            gen_prompt = (
                f"Read the following skill file and generate {num_synthetic} diverse "
                f"task input / expected rubric pairs. Output as JSON list.\n\n"
                f"Skill:\n{self.baseline_skill_text}"
            )
            gen_response = synthetic_generator(gen_prompt, max_tokens=2048)
            try:
                synthetic_data = json.loads(gen_response)
                for item in synthetic_data:
                    examples.append(EvalExample(
                        task_input=item["task"],
                        expected_rubric=item["rubric"],
                    ))
            except (json.JSONDecodeError, KeyError) as e:
                logger.warning(f"Synthetic generation failed: {e}")

        # Source B: SessionDB mining (real usage)
        if mine_session:
            sessions = self.db.query(
                query="",  # empty to get all sessions (filter by skill name in practice)
                limit=50,
                skill_tag=self.skill_path.stem,  # e.g., "github-code-review"
            )
            for session in sessions:
                # Each session has messages; extract the first user message as task
                # and the agent's final response as output
                task = session.messages[0].content if session.messages else ""
                response = session.messages[-1].content if session.messages else ""
                # Use LLM judge to score as rubric indicator
                judge_score = self._llm_judge_score(
                    task=task,
                    response=response,
                    rubric="Generic quality: useful, accurate, follows skill",
                )
                # Only keep decent examples; lower scores become failure cases
                if judge_score >= 0.7:
                    examples.append(EvalExample(
                        task_input=task,
                        expected_rubric=f"High quality (LLM judge score {judge_score:.2f})",
                        baseline_trace=self._retrieve_trace(session.session_id),
                    ))
                else:
                    # Low-scoring sessions are valuable failure cases for GEPA
                    examples.append(EvalExample(
                        task_input=task,
                        expected_rubric=f"Generic quality; this one scored {judge_score:.2f}",
                        baseline_trace=self._retrieve_trace(session.session_id),
                    ))

        # Split into train/val/holdout
        self._split_dataset(examples)

    def _retrieve_trace(self, session_id: str) -> Optional[ExecutionTrace]:
        """Retrieve the execution trace for a session from the agent's store."""
        return self.agent.trajectory_store.get(session_id)

    def run_optimization(self) -> Tuple[dspy.Module, float]:
        """
        Execute the GEPA optimization loop.

        Returns:
            (best_module, best_fitness): The best evolved skill module and its
            validation fitness score.
        """
        if not self.train_examples:
            raise ValueError("No training examples available. Call generate_dataset() first.")

        logger.info("Starting GEPA optimization for skill %s", self.skill_path.name)
        logger.info("Training set size: %d, Val set size: %d, Holdout set size: %d",
                     len(self.train_examples), len(self.val_examples), len(self.holdout_examples))

        # Prepare teleprompter (GEPA) configuration
        compiled = self.optimizer.compile(
            self.skill_module,                              # Base module with initial skill text
            trainset=[ex.task_input for ex in self.train_examples],  # Tasks only; rubric used inside metric
            valset=[ex.task_input for ex in self.val_examples],
            metric=self._fitness_metric,
            # Additional GEPA options: use execution traces for reflective analysis
            traces=[ex.baseline_trace for ex in self.train_examples if ex.baseline_trace],
        )

        # Extract best evolved skill text from compiled module
        best_skill_text = compiled.skill_text
        # Evaluate on holdout set
        holdout_score = self._evaluate_on_holdout(compiled)
        logger.info("Optimization complete. Holdout score: %.3f", holdout_score)

        return compiled, holdout_score

    def _evaluate_on_holdout(self, candidate: dspy.Module) -> float:
        """Run candidate on the held-out test set and return average score."""
        total = 0.0
        for ex in self.holdout_examples:
            response = candidate(task=ex.task_input)
            score = self._llm_judge_score(ex.task_input, response.response, ex.expected_rubric)
            total += score
        return total / len(self.holdout_examples) if self.holdout_examples else 0.0

    def save_evolved_skill(self, output_path: Path):
        """Write the evolved skill text to a new SKILL.md file."""
        evolved_text = self.skill_module.skill_text  # After optimization, this is updated
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(evolved_text)
        logger.info("Evolved skill saved to %s", output_path)

    def compare_with_baseline(self) -> Dict:
        """
        Run both baseline and evolved on holdout set and return comparison metrics.

        Returns:
            dict with keys 'baseline_score', 'evolved_score', 'improvement', 'diff_text'.
        """
        # Evaluate baseline (fetch original skill text)
        baseline_module = self._build_skill_module_with_text(self.baseline_skill_text)
        baseline_score = self._evaluate_on_holdout(baseline_module)

        # Evaluate evolved
        evolved_score = self._evaluate_on_holdout(self.skill_module)

        # Compute diff
        import difflib
        diff = difflib.unified_diff(
            self.baseline_skill_text.splitlines(keepends=True),
            self.skill_module.skill_text.splitlines(keepends=True),
            fromfile="baseline.md",
            tofile="evolved.md",
        )
        diff_text = "".join(diff)

        return {
            "baseline_score": baseline_score,
            "evolved_score": evolved_score,
            "improvement": evolved_score - baseline_score,
            "diff_text": diff_text,
        }

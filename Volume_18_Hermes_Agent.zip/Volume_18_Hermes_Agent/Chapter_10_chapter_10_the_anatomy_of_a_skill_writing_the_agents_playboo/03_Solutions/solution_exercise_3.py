
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# hermes_state.py (partial)
import sqlite3
import time
from pathlib import Path

class SessionDB:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        with self._connect() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS skill_metrics (
                    skill_name TEXT NOT NULL,
                    session_id TEXT NOT NULL,
                    invocation_count INTEGER DEFAULT 0,
                    success_count INTEGER DEFAULT 0,
                    average_response_time_ms REAL DEFAULT 0.0,
                    rollback_count INTEGER DEFAULT 0,
                    PRIMARY KEY (skill_name, session_id)
                )
            """)
            # Add FTS5 virtual table for full-text search on skill_name
            conn.execute("""
                CREATE VIRTUAL TABLE IF NOT EXISTS skill_metrics_fts USING fts5(
                    skill_name,
                    content='skill_metrics',
                    content_rowid='rowid'
                )
            """)
            # Trigger to keep FTS index updated
            conn.execute("""
                CREATE TRIGGER IF NOT EXISTS skill_metrics_ai AFTER INSERT ON skill_metrics BEGIN
                    INSERT INTO skill_metrics_fts(rowid, skill_name) VALUES (new.rowid, new.skill_name);
                END
            """)
            conn.execute("""
                CREATE TRIGGER IF NOT EXISTS skill_metrics_ad AFTER DELETE ON skill_metrics BEGIN
                    INSERT INTO skill_metrics_fts(skill_metrics_fts, rowid, skill_name) VALUES ('delete', old.rowid, old.skill_name);
                END
            """)
            conn.execute("""
                CREATE TRIGGER IF NOT EXISTS skill_metrics_au AFTER UPDATE ON skill_metrics BEGIN
                    INSERT INTO skill_metrics_fts(skill_metrics_fts, rowid, skill_name) VALUES ('delete', old.rowid, old.skill_name);
                    INSERT INTO skill_metrics_fts(rowid, skill_name) VALUES (new.rowid, new.skill_name);
                END
            """)

    def _connect(self):
        return sqlite3.connect(self.db_path)

    def record_skill_invocation(self, skill_name: str, session_id: str, success: bool, response_time_ms: float):
        """Upsert skill metrics row."""
        with self._connect() as conn:
            # UPSERT: increment counters
            conn.execute("""
                INSERT INTO skill_metrics (skill_name, session_id, invocation_count, success_count, average_response_time_ms)
                VALUES (?, ?, 1, ?, ?)
                ON CONFLICT(skill_name, session_id) DO UPDATE SET
                    invocation_count = invocation_count + 1,
                    success_count = success_count + ?,
                    average_response_time_ms = (average_response_time_ms * (invocation_count - 1) + ?) / invocation_count
            """, (skill_name, session_id, int(success), response_time_ms, int(success), response_time_ms))
            # Also update session's updated_at
            conn.execute("UPDATE sessions SET updated_at = ? WHERE session_id = ?", (time.time(), session_id))

    def query_skill_metrics(self, skill_name: str) -> list:
        """Return all rows for a given skill name (across sessions)."""
        with self._connect() as conn:
            cur = conn.execute("""
                SELECT skill_name, session_id, invocation_count, success_count, average_response_time_ms, rollback_count
                FROM skill_metrics WHERE skill_name = ?
            """, (skill_name,))
            return cur.fetchall()

    def search_skills_fts(self, prefix: str) -> Generator[dict, None, None]:
        """FTS5 search by skill name prefix."""
        with self._connect() as conn:
            cur = conn.execute("""
                SELECT skill_name, invocation_count, success_count, average_response_time_ms
                FROM skill_metrics_fts
                WHERE skill_name MATCH ?
            """, (prefix + "*",))
            for row in cur:
                yield {
                    "skill_name": row[0],
                    "invocation_count": row[1],
                    "success_count": row[2],
                    "average_response_time_ms": row[3]
                }

# agent/curator.py (partial)
class Curator:
    def __init__(self, config: dict, session_db: SessionDB):
        self.config = config
        self.session_db = session_db
        self.weights = config.get("curator", {}).get("review_weights", {
            "staleness": 0.4,
            "failure_rate": 0.35,
            "low_volume": 0.25
        })

    def score_skill(self, skill_name: str) -> float:
        """Compute archival score based on three factors."""
        metrics = self.session_db.query_skill_metrics(skill_name)
        if not metrics:
            return 0.0

        total_invocations = sum(m[2] for m in metrics)
        total_successes = sum(m[3] for m in metrics)
        last_used = max(m[5] for m in metrics) if len(metrics[0]) > 5 else 0  # assume rollback_count at index 5? adjust

        # Staleness: days since last invocation
        days_since_last = (time.time() - last_used) / 86400
        staleness_score = min(1.0, days_since_last / 30)  # normalized to 30 days

        # Failure rate
        failure_rate = 1 - (total_successes / total_invocations) if total_invocations > 0 else 1.0
        failure_score = 1.0 if failure_rate > 0.75 else 0.0  # threshold: success rate < 0.25

        # Low volume
        low_volume_score = 1.0 if total_invocations < 3 else 0.0

        # Weighted sum
        score = (self.weights["staleness"] * staleness_score +
                 self.weights["failure_rate"] * failure_score +
                 self.weights["low_volume"] * low_volume_score)
        return score

    def get_archival_candidates(self, dry_run: bool = True) -> list:
        """Return list of skills that meet any threshold."""
        candidates = []
        # Get all distinct skill names from skill_metrics
        with self.session_db._connect() as conn:
            cur = conn.execute("SELECT DISTINCT skill_name FROM skill_metrics")
            for row in cur:
                skill = row[0]
                score = self.score_skill(skill)
                if score > 0.5:  # arbitrary threshold
                    candidates.append({"skill_name": skill, "score": score})
        return candidates

# CLI commands in hermes_cli/commands.py
def cmd_skill_stats(skill_name: str):
    """Display skill metrics."""
    db = SessionDB(Path.home() / ".hermes" / "state.db")
    rows = db.query_skill_metrics(skill_name)
    if not rows:
        print("No metrics found for skill.")
        return
    print(f"{'Skill':<20} {'Session':<20} {'Invocations':<12} {'Success Rate':<14} {'Avg Time (ms)':<14}")
    for row in rows:
        name, session, inv, succ, avg_time, _ = row
        success_rate = succ / inv if inv > 0 else 0
        print(f"{name:<20} {session:<20} {inv:<12} {success_rate:<14.2f} {avg_time:<14.2f}")

def cmd_skill_prune(dry_run: bool = True):
    """Run curator archival logic."""
    config = load_config()
    db = SessionDB(Path.home() / ".hermes" / "state.db")
    curator = Curator(config, db)
    candidates = curator.get_archival_candidates(dry_run=dry_run)
    if not candidates:
        print("No skills to archive.")
        return
    print("Skills flagged for archival:")
    for c in candidates:
        print(f"  {c['skill_name']} (score: {c['score']:.2f})")
    if not dry_run:
        # Actually archive (move to backup)
        for c in candidates:
            archive_skill(c['skill_name'])


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# tools/checkpoint_manager.py (extended)
import shutil
import time
import json
from pathlib import Path
from typing import Optional

class SkillSnapshotManager:
    """Manages skill directory snapshots for atomic rollback."""

    SNAPSHOT_BASE = Path.home() / ".hermes" / "skills" / ".snapshots"

    def __init__(self, skill_name: str):
        self.skill_name = skill_name
        self.skill_dir = Path.home() / ".hermes" / "skills" / skill_name
        self.snapshot_dir = self.SNAPSHOT_BASE / skill_name

    def create_snapshot(self, reason: str = "before mutation") -> Optional[str]:
        """Create a timestamped snapshot of the skill directory."""
        timestamp = str(int(time.time() * 1000))  # milliseconds
        dest = self.snapshot_dir / timestamp
        if dest.exists():
            return None  # idempotent: skip duplicate timestamp
        if not self.skill_dir.exists():
            return None
        shutil.copytree(self.skill_dir, dest, dirs_exist_ok=True)
        # Store metadata (reason)
        (dest / ".snapshot_meta.json").write_text(json.dumps({"reason": reason, "timestamp": timestamp}))
        return timestamp

    def rollback(self, timestamp: Optional[str] = None) -> bool:
        """Restore skill directory from snapshot. If timestamp is None, use latest."""
        if not self.snapshot_dir.exists():
            return False
        if timestamp is None:
            # Find latest snapshot by timestamp (directory name)
            snapshots = sorted(self.snapshot_dir.iterdir(), key=lambda p: p.name)
            if not snapshots:
                return False
            source = snapshots[-1]
        else:
            source = self.snapshot_dir / timestamp
            if not source.exists():
                return False

        # Remove current skill directory
        if self.skill_dir.exists():
            shutil.rmtree(self.skill_dir)
        # Restore from snapshot
        shutil.copytree(source, self.skill_dir, dirs_exist_ok=True)
        return True

    def list_snapshots(self) -> list:
        """Return list of snapshot info."""
        if not self.snapshot_dir.exists():
            return []
        snapshots = []
        for snap in sorted(self.snapshot_dir.iterdir(), key=lambda p: p.name):
            meta_file = snap / ".snapshot_meta.json"
            meta = json.loads(meta_file.read_text()) if meta_file.exists() else {"reason": "unknown"}
            file_count = len(list(snap.rglob("*")))
            size = sum(f.stat().st_size for f in snap.rglob("*") if f.is_file())
            snapshots.append({
                "timestamp": snap.name,
                "reason": meta["reason"],
                "file_count": file_count,
                "size_bytes": size
            })
        return snapshots

# New tool: skill_rollback
def skill_rollback(skill_name: str, timestamp: Optional[str] = None) -> dict:
    """Rollback a skill to a previous snapshot."""
    manager = SkillSnapshotManager(skill_name)
    if not manager.snapshot_dir.exists():
        return {"success": False, "error": "No snapshots available"}
    success = manager.rollback(timestamp)
    if not success:
        # Fallback to checkpoint manager's working-dir snapshot
        # (pseudo-code)
        fallback_result = fallback_rollback(skill_name)
        return {"success": fallback_result, "message": "Used fallback checkpoint"}
    # Also rollback memory entries
    rollback_memory_entries(skill_name, timestamp)
    return {"success": True, "message": f"Rolled back to snapshot {timestamp or 'latest'}"}

# Integration in guardrails (run_agent.py)
def _append_guardrail_observation(guardrail_decision, tool_result, context):
    """Override to trigger automatic rollback on skill mutation failures."""
    if guardrail_decision.code == "max_retries_exceeded" and context.get("skill_name"):
        skill_name = context["skill_name"]
        manager = SkillSnapshotManager(skill_name)
        # Rollback to latest snapshot (created before mutation)
        manager.rollback()
        guardrail_decision.code = "skill_rollback_triggered"
        tool_result["message"] = f"Skill '{skill_name}' rolled back due to {guardrail_decision.reason}"
        # Update skill_metrics with rollback count
        session_db = get_session_db()
        session_db.record_skill_invocation(skill_name, session_id, success=False, response_time_ms=0)
        # Increment rollback_count (separate method or update)
        # (Assume a method increment_rollback_count exists)
    return guardrail_decision, tool_result

# CLI command
def cmd_skill_snapshots(skill_name: str):
    """List all snapshots for a skill."""
    manager = SkillSnapshotManager(skill_name)
    snapshots = manager.list_snapshots()
    if not snapshots:
        print(f"No snapshots for skill '{skill_name}'.")
        return
    print(f"Snapshots for {skill_name}:")
    for snap in snapshots:
        print(f"  {snap['timestamp']} | Reason: {snap['reason']} | Files: {snap['file_count']} | Size: {snap['size_bytes']} bytes")

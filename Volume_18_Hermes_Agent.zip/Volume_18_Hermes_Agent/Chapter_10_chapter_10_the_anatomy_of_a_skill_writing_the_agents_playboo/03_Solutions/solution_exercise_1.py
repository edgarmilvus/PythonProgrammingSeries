
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# agent/skill_commands.py (partial)
import json
import time
import hashlib
from pathlib import Path
from typing import Dict, Any, Generator
from hermes_agent.tools import TerminalTool, MemoryTool, SkillManageTool
from hermes_agent.guardrails import ToolCallGuardrailController
from hermes_agent.memory import MemoryManager

# Assume existing imports and command registry pattern

class FileWriterWithTempSkill:
    """Skill that writes files with temperature-awareness and self-improvement loop."""

    TRIGGER = "/write-temp"
    DESCRIPTION = "Write a file with controlled temperature/seed. Usage: /write-temp <path> <prompt>"

    def __init__(self, memory_manager: MemoryManager, terminal_tool: TerminalTool,
                 skill_manage_tool: SkillManageTool, guardrail: ToolCallGuardrailController):
        self.memory = memory_manager
        self.terminal = terminal_tool
        self.skill_manage = skill_manage_tool
        self.guardrail = guardrail
        self.invocation_count = 0

    def execute(self, path: str, prompt: str) -> Dict[str, Any]:
        """Main execution logic with context manager for memory read."""
        # Step 1: Read latest memory entry for this skill to get preferred temperature/seed
        with self.memory.read_context() as ctx:
            latest = ctx.get_latest(target="skills", action="file-writer-temp-result")
            if latest:
                content = json.loads(latest["content"])
                temperature = content.get("temperature_used", 0.3)
                seed = content.get("seed_used", 42)
            else:
                temperature = 0.3
                seed = 42

        # Step 2: Build terminal command with temperature/seed as environment variables
        command = f"echo '{prompt}' > {path}"
        env = {"TEMPERATURE": str(temperature), "SEED": str(seed)}

        # Step 3: Execute via terminal tool with guardrail
        result = self.terminal.run(command, env=env, guardrail=self.guardrail)
        success = result.exit_code == 0 and Path(path).exists()
        size_bytes = Path(path).stat().st_size if success else 0

        # Step 4: Record outcome in memory
        memory_entry = {
            "action": "file-writer-temp-result",
            "target": "skills",
            "content": json.dumps({
                "path": path,
                "success": success,
                "size_bytes": size_bytes,
                "temperature_used": temperature,
                "seed_used": seed,
                "timestamp": time.time()
            }, separators=(",", ":"))
        }
        self.memory.store(memory_entry)

        # Step 5: On failure, return structured error with suggestion
        if not success:
            return {
                "success": False,
                "error": f"Terminal exit code {result.exit_code}: {result.stderr}",
                "suggestion": "Check file permissions or disk space. Try a different path."
            }

        # Step 6: Every third invocation, trigger background review
        self.invocation_count += 1
        if self.invocation_count % 3 == 0:
            self._background_review()

        return {"success": True, "path": path, "size_bytes": size_bytes}

    def _background_review(self):
        """Read last 10 memory entries and update skill frontmatter."""
        with self.memory.read_context() as ctx:
            entries = ctx.query(target="skills", action="file-writer-temp-result", limit=10)
        if not entries:
            return

        successes = sum(1 for e in entries if json.loads(e["content"])["success"])
        total = len(entries)
        success_rate = successes / total if total > 0 else 0

        # Compute recommended temperature (inverse of success rate, clamped)
        recommended_temp = max(0.1, min(1.0, 1.0 - success_rate))

        # Update skill frontmatter via skill_manage tool
        self.skill_manage.patch(
            skill_name="file-writer-with-temp",
            frontmatter_path="metadata.hermes.config",
            value={"temperature": recommended_temp}
        )

    def progress_generator(self, path: str, prompt: str) -> Generator[str, None, None]:
        """Yield progress states for activity feed."""
        yield f"Reading memory for temperature preferences..."
        yield f"Writing file to {path} with prompt..."
        yield f"Recording result and checking guardrails..."
        final = self.execute(path, prompt)
        yield f"Completed: {'Success' if final['success'] else 'Failure'}"

# Registration in COMMAND_REGISTRY
COMMAND_REGISTRY["/write-temp"] = {
    "func": FileWriterWithTempSkill,
    "description": FileWriterWithTempSkill.DESCRIPTION
}

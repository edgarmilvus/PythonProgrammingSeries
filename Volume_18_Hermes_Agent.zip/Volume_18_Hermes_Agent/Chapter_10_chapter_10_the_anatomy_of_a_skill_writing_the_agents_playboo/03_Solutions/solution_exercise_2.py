
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# tools/linter_tool.py
import json
import hashlib
import subprocess
from pathlib import Path
from typing import List, Dict, Any, Optional

class LinterTool:
    """Tool to run linters on files, with memory and self-improvement."""

    LINTER_MAP = {
        ".py": "ruff",
        ".js": "eslint",
        ".tsx": "eslint",
        ".rs": "clippy"
    }

    def __init__(self, memory_manager, skill_manage_tool):
        self.memory = memory_manager
        self.skill_manage = skill_manage_tool
        self.lint_invocation_count = 0

    def run(self, path: str, checks: Optional[List[str]] = None, fix: bool = False) -> Dict[str, Any]:
        """Execute linter on given file/directory, return structured result."""
        # Check if linter binary exists
        ext = Path(path).suffix
        linter = self.LINTER_MAP.get(ext)
        if not linter:
            return {"success": False, "error": f"No linter configured for extension {ext}"}
        if not self._binary_exists(linter):
            return {"success": False, "error": f"Linter {linter} not installed"}

        # Build command
        cmd = [linter, "--format", "json"]
        if fix:
            cmd.append("--fix")
        if checks:
            cmd.extend(["--select", ",".join(checks)])
        cmd.append(path)

        # Run linter, capture stdout/stderr separately
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "Linter timed out"}

        # Parse JSON output (ruff outputs JSON array)
        issues = []
        if proc.stdout:
            try:
                raw = json.loads(proc.stdout)
                for item in raw:
                    issues.append({
                        "line": item.get("location", {}).get("row", 0),
                        "column": item.get("location", {}).get("column", 0),
                        "code": item["code"],
                        "message": item["message"]
                    })
            except json.JSONDecodeError:
                pass

        result = {
            "success": proc.returncode == 0,
            "file": path,
            "issues": issues,
            "fixed": fix and proc.returncode == 0
        }

        # Memory integration: store with SHA-256 hash
        file_hash = self._file_hash(path)
        memory_key = f"lint_history:{path}"
        memory_entry = {
            "action": "lint_result",
            "target": "skills",
            "content": json.dumps({**result, "hash": file_hash}, separators=(",", ":"))
        }
        self.memory.store(memory_entry, key=memory_key)

        # Every 5th invocation, run review pass
        self.lint_invocation_count += 1
        if self.lint_invocation_count % 5 == 0:
            self._review_and_create_skill()

        return result

    def _binary_exists(self, name: str) -> bool:
        return subprocess.run(["which", name], capture_output=True).returncode == 0

    def _file_hash(self, path: str) -> str:
        with open(path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()

    def _review_and_create_skill(self):
        """Examine lint history for recurring error codes and create autofix skills."""
        # Query memory for lint results in this project
        entries = self.memory.query(target="skills", action="lint_result", limit=100)
        error_counts = {}
        for e in entries:
            content = json.loads(e["content"])
            for issue in content.get("issues", []):
                code = issue["code"]
                error_counts[code] = error_counts.get(code, 0) + 1

        for code, count in error_counts.items():
            if count >= 3:
                # Create new skill for this error code
                skill_name = f"lint-autofix-{code}"
                skill_metadata = {
                    "name": skill_name,
                    "description": f"Automatically fix {code} lint errors",
                    "metadata": {
                        "hermes": {
                            "config": {"error_code": code}
                        }
                    }
                }
                self.skill_manage.create(skill_name, metadata=skill_metadata)
                # Break after first creation to avoid flooding
                break

# Passive sensor hook in model_tools.py
def after_write_file_hook(path: str, content: str, **kwargs):
    """Hook fired after write_file or patch tool execution."""
    # Skip git and node_modules directories
    if any(part in path for part in [".git", "node_modules"]):
        return
    ext = Path(path).suffix
    if ext in LinterTool.LINTER_MAP:
        linter = LinterTool(memory_manager, skill_manage_tool)
        result = linter.run(path)
        # Optionally push to activity feed
        if result["issues"]:
            print(f"[Linter] Found {len(result['issues'])} issues in {path}")

# Registration in tools/registry.py
TOOL_REGISTRY["run_linter"] = {
    "func": LinterTool.run,
    "description": "Run a linter on a file or directory",
    "parameters": {
        "path": {"type": "string", "description": "File or directory path"},
        "checks": {"type": "array", "items": {"type": "string"}, "optional": True},
        "fix": {"type": "boolean", "default": False}
    }
}

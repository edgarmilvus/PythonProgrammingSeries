
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# skills/cross_session_remember/skill.py
import json
import time
import re
import threading
from typing import List, Dict, Any
from hermes_agent.memory import MemoryManager
from hermes_agent.config import Config

class CrossSessionRememberSkill:
    """Skill to remember user preferences across sessions using multiple memory providers."""

    TRIGGER_SLASH = "/remember"
    NATURAL_TRIGGER_REGEX = r"(?:remember|don't forget|save that|keep in mind)"
    DESCRIPTION = "Remember a preference or fact across sessions. Usage: /remember <text>"

    def __init__(self, memory_manager: MemoryManager, config: Config):
        self.memory_manager = memory_manager
        self.config = config
        self.invocation_count = 0
        # Read skill config from SKILL.md frontmatter (injected by framework)
        self.primary_provider = config.get("primary_provider", "honcho")
        self.secondary_provider = config.get("secondary_provider", "mem0")
        self.retention_days = config.get("retention_days", 30)
        # Ensure providers are initialized (skip if missing)
        self._init_providers()

    def _init_providers(self):
        """Initialize memory providers; skip if unavailable."""
        providers = [self.primary_provider, self.secondary_provider]
        for prov in providers:
            if prov:
                try:
                    self.memory_manager.initialize_provider(prov)
                except Exception:
                    self.memory_manager.disable_provider(prov)

    def execute(self, text: str) -> Dict[str, Any]:
        """Write to both providers, read back, merge, return."""
        # Write to both providers
        write_results = {}
        for prov in [self.primary_provider, self.secondary_provider]:
            if prov:
                try:
                    self.memory_manager.sync_all(
                        provider=prov,
                        user_message="remember",
                        final_response=text
                    )
                    write_results[prov] = "success"
                except Exception as e:
                    write_results[prov] = f"failed: {str(e)}"
            else:
                write_results[prov] = "disabled"

        # If both failed, fallback to built-in memory
        if all("failed" in v or v == "disabled" for v in write_results.values()):
            self.memory_manager.store_local({"action": "remember", "content": text})
            write_results["builtin"] = "used"

        # Read back last 5 memories from both providers
        all_memories = []
        for prov in [self.primary_provider, self.secondary_provider]:
            if prov and write_results.get(prov) == "success":
                try:
                    memories = self.memory_manager.read(provider=prov, limit=5)
                    all_memories.extend(memories)
                except Exception:
                    pass

        # Deduplicate by content hash
        seen = set()
        merged = []
        for mem in all_memories:
            content_hash = hash(json.dumps(mem, sort_keys=True))
            if content_hash not in seen:
                seen.add(content_hash)
                merged.append(mem)

        # Return merged list
        self.invocation_count += 1
        if self.invocation_count % 10 == 0:
            self._background_review()

        return {
            "success": True,
            "memories": merged[:5],
            "write_status": write_results
        }

    def _background_review(self):
        """After 10 invocations, review success rates and possibly disable secondary."""
        def review():
            # Query last 20 invocations from memory (assume stored)
            entries = self.memory_manager.query_local(action="remember", limit=20)
            if not entries:
                return
            successes = {"primary": 0, "secondary": 0}
            total = {"primary": 0, "secondary": 0}
            for e in entries:
                content = json.loads(e["content"])
                for prov, status in content.get("write_status", {}).items():
                    if prov in ["honcho", "mem0"]:
                        if status == "success":
                            successes[prov] += 1
                        total[prov] += 1
            # If secondary provider success rate < 50%, disable it
            if total.get("secondary", 0) > 0:
                rate = successes["secondary"] / total["secondary"]
                if rate < 0.5:
                    # Update skill frontmatter via skill_manage
                    self._update_config("secondary_provider", "")
                    self.secondary_provider = ""

        thread = threading.Thread(target=review, daemon=True)
        thread.start()

    def _update_config(self, key: str, value: Any):
        """Update skill's own frontmatter config."""
        # Use skill_manage tool (injected)
        self.skill_manage.patch(
            skill_name="cross-session-remember",
            frontmatter_path=f"metadata.hermes.config.{key}",
            value=value
        )

    def shutdown(self):
        """Cleanup memory providers."""
        self.memory_manager.shutdown_all()

# Registration in skill_commands.py
COMMAND_REGISTRY["/remember"] = {
    "func": CrossSessionRememberSkill,
    "description": CrossSessionRememberSkill.DESCRIPTION
}

# Natural language trigger detection in agent loop
def detect_natural_trigger(user_message: str) -> bool:
    return bool(re.match(CrossSessionRememberSkill.NATURAL_TRIGGER_REGEX, user_message))

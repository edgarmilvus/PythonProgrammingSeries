
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script.py
# Description: Advanced Integration Script
# ==========================================

#!/usr/bin/env python3
"""
Advanced Research Agent - A production-grade integration script
demonstrating Hermes Agent's tool handling, memory persistence,
and task delegation capabilities.

This script creates a research assistant that can:
1. Search the web for information on a given topic
2. Extract content from multiple sources
3. Analyze and synthesize findings
4. Generate structured reports
5. Save reports to files
6. Remember user preferences across sessions
7. Delegate subtasks for parallel research
"""

import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Any

# Core Hermes Agent imports - using the actual library
from run_agent import AIAgent, IterationBudget
from model_tools import (
    get_tool_definitions,
    handle_function_call,
    check_toolset_requirements,
)
from tools.memory_tool import MemoryStore
from tools.todo_tool import TodoStore
from tools.skills_tool import skill_view, skills_list, skill_manage
from hermes_constants import get_hermes_home, display_hermes_home

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(get_hermes_home() / "logs" / "research_agent.log")
    ]
)
logger = logging.getLogger(__name__)


class ResearchAgent:
    """
    A sophisticated research agent that demonstrates advanced integration
    patterns from the Hermes Agent codebase.
    
    This class wraps the core AIAgent with additional functionality for:
    - Structured research workflows with multiple phases
    - Persistent memory for user preferences and session state
    - Task delegation for parallel research subtasks
    - Report generation with configurable templates
    - Error recovery with graceful degradation
    """
    
    def __init__(
        self,
        model: str = "anthropic/claude-sonnet-4-20250514",
        provider: str = "openrouter",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        max_iterations: int = 50,
        verbose: bool = False,
        memory_enabled: bool = True,
        skill_enabled: bool = True,
    ):
        """
        Initialize the research agent with the specified configuration.
        
        Args:
            model: The model identifier to use for the LLM
            provider: The provider to route through (openrouter, anthropic, etc.)
            api_key: API key for authentication (uses env var if not provided)
            base_url: Custom base URL for the API endpoint
            max_iterations: Maximum number of tool-calling iterations per turn
            verbose: Enable verbose logging for debugging
            memory_enabled: Enable persistent memory for user preferences
            skill_enabled: Enable the skill system for reusable research patterns
        """
        self.model = model
        self.provider = provider
        self.verbose = verbose
        self.memory_enabled = memory_enabled
        self.skill_enabled = skill_enabled
        
        # Initialize the core AIAgent with research-appropriate toolsets
        # We enable web, file, and memory toolsets for the research workflow
        self.agent = AIAgent(
            model=model,
            provider=provider,
            api_key=api_key,
            base_url=base_url,
            max_iterations=max_iterations,
            enabled_toolsets=["web", "file", "memory", "terminal", "search"],
            disabled_toolsets=["browser", "vision"],  # Vision not needed for text research
            verbose_logging=verbose,
            quiet_mode=not verbose,
            save_trajectories=True,
            session_id=f"research_{int(time.time())}",
            platform="cli",
        )
        
        # Initialize memory store for persistent user preferences
        if memory_enabled:
            self.memory_store = MemoryStore(
                memory_char_limit=3000,
                user_char_limit=2000,
            )
            self.memory_store.load_from_disk()
            logger.info("Memory store initialized with %d memory entries", 
                       len(self.memory_store.get_all_memories()))
        
        # Initialize todo store for task tracking
        self.todo_store = TodoStore()
        
        # Track research session state
        self.session_state = {
            "topic": "",
            "sources_consulted": [],
            "findings": [],
            "report_generated": False,
            "user_preferences": {},
        }
        
        logger.info("ResearchAgent initialized with model: %s via %s", model, provider)
    
    def run_research_workflow(self, topic: str, depth: str = "standard") -> Dict[str, Any]:
        """
        Execute a complete research workflow on the given topic.
        
        This method demonstrates the closed-loop learning pattern:
        1. Search for information
        2. Extract and analyze content
        3. Synthesize findings
        4. Generate a structured report
        5. Save the report to disk
        6. Update memory with session learnings
        
        Args:
            topic: The research topic to investigate
            depth: Research depth - "quick", "standard", or "deep"
            
        Returns:
            Dict containing the research results and metadata
        """
        logger.info("Starting research workflow for topic: %s (depth: %s)", topic, depth)
        
        # Store the topic in session state for later use
        self.session_state["topic"] = topic
        
        # Phase 1: Configure the research parameters based on depth
        search_iterations = {"quick": 3, "standard": 5, "deep": 10}.get(depth, 5)
        max_sources = {"quick": 2, "standard": 5, "deep": 10}.get(depth, 5)
        
        # Build the system prompt for the research task
        # This demonstrates how to craft effective prompts that guide the agent's behavior
        research_prompt = self._build_research_prompt(topic, depth, max_sources)
        
        # Phase 2: Execute the research conversation
        # The AIAgent handles tool calling, error recovery, and iteration management
        result = self.agent.run_conversation(
            user_message=research_prompt,
            system_message=self._build_system_message(),
            task_id=f"research_{topic[:30].replace(' ', '_'}",
        )
        
        # Phase 3: Process and persist the research results
        if result["completed"]:
            self._process_research_results(result)
            self._save_research_report(result["final_response"], topic)
            self._update_memory_with_learnings(topic, result)
            logger.info("Research workflow completed successfully for: %s", topic)
        else:
            logger.warning("Research workflow did not complete for: %s", topic)
        
        return result
    
    def _build_research_prompt(self, topic: str, depth: str, max_sources: int) -> str:
        """
        Build a structured research prompt that guides the agent through
        the research workflow step by step.
        
        This demonstrates how to create effective prompts that leverage
        the agent's tool-calling capabilities.
        """
        prompt = f"""
# Research Task: {topic}

## Instructions
You are a thorough research assistant. Follow these steps in order:

### Step 1: Search and Gather
- Use web_search to find information about: {topic}
- Search for at least {max_sources} different sources
- Focus on authoritative and recent sources

### Step 2: Extract and Analyze
- For each source found, use web_extract to get the full content
- Analyze the content for key insights, data points, and conclusions
- Note any conflicting information or areas of uncertainty

### Step 3: Synthesize Findings
- Organize the findings into coherent themes
- Identify patterns, trends, and relationships
- Evaluate the quality and reliability of sources

### Step 4: Generate Report
- Create a structured report with the following sections:
  1. Executive Summary
  2. Key Findings
  3. Detailed Analysis
  4. Sources and References
  5. Conclusions and Recommendations

### Step 5: Save Results
- Use write_file to save the report to: ~/.hermes/research/{topic.replace(' ', '_')}_report.md
- Ensure the report is well-formatted with markdown

## Research Depth: {depth}
- Quick: Focus on top 2-3 sources, concise summary
- Standard: 5 sources, detailed analysis
- Deep: 10+ sources, comprehensive report with cross-references

## Important Guidelines
- Always verify information from multiple sources
- Cite sources using [Source N] notation
- Note the publication date of each source
- Flag any information that seems unreliable or outdated
- If you need to clarify anything, use the clarify tool
"""
        return prompt
    
    def _build_system_message(self) -> str:
        """
        Build the system message that provides context about the agent's
        capabilities and the user's preferences.
        
        This demonstrates how to inject memory and user profile information
        into the system prompt for personalized behavior.
        """
        parts = []
        
        # Add memory context if enabled
        if self.memory_enabled and self.memory_store:
            mem_block = self.memory_store.format_for_system_prompt("memory")
            if mem_block:
                parts.append(mem_block)
        
        # Add user profile if available
        if self.memory_enabled and self.memory_store:
            user_block = self.memory_store.format_for_system_prompt("user")
            if user_block:
                parts.append(user_block)
        
        # Add session state context
        if self.session_state["user_preferences"]:
            prefs = json.dumps(self.session_state["user_preferences"], indent=2)
            parts.append(f"User Preferences:\n{prefs}")
        
        return "\n\n".join(parts)
    
    def _process_research_results(self, result: Dict[str, Any]) -> None:
        """
        Process the research results to extract structured information
        and update the session state.
        
        This demonstrates how to parse and structure the agent's output
        for downstream processing.
        """
        messages = result.get("messages", [])
        
        # Extract tool calls and results from the conversation
        for msg in messages:
            if msg.get("role") == "tool":
                try:
                    content = json.loads(msg.get("content", "{}"))
                    if isinstance(content, dict):
                        if "url" in content:
                            self.session_state["sources_consulted"].append(content["url"])
                        if "findings" in content:
                            self.session_state["findings"].extend(content["findings"])
                except (json.JSONDecodeError, TypeError):
                    pass
        
        self.session_state["report_generated"] = bool(result.get("final_response"))
        logger.info("Processed research results: %d sources, %d findings",
                   len(self.session_state["sources_consulted"]),
                   len(self.session_state["findings"]))
    
    def _save_research_report(self, report_content: str, topic: str) -> None:
        """
        Save the generated research report to disk.
        
        This demonstrates how to persist agent output to the filesystem
        for later reference.
        """
        hermes_home = get_hermes_home()
        research_dir = hermes_home / "research"
        research_dir.mkdir(parents=True, exist_ok=True)
        
        # Sanitize the filename
        safe_topic = topic.replace(" ", "_").replace("/", "_")[:50]
        report_path = research_dir / f"{safe_topic}_report.md"
        
        try:
            report_path.write_text(report_content, encoding="utf-8")
            logger.info("Research report saved to: %s", report_path)
        except Exception as e:
            logger.error("Failed to save research report: %s", e)
    
    def _update_memory_with_learnings(self, topic: str, result: Dict[str, Any]) -> None:
        """
        Update the memory store with learnings from this research session.
        
        This demonstrates the closed-loop learning pattern where the agent
        persists knowledge for future sessions.
        """
        if not self.memory_enabled or not self.memory_store:
            return
        
        # Extract key learnings from the research result
        learnings = []
        if result.get("final_response"):
            # Add a memory entry about the research topic
            learnings.append({
                "action": "add",
                "target": "memory",
                "content": f"Research conducted on: {topic}. Key findings were documented in a report."
            })
        
        # Add any user preferences inferred from the session
        if self.session_state.get("user_preferences"):
            learnings.append({
                "action": "add",
                "target": "user",
                "content": json.dumps(self.session_state["user_preferences"])
            })
        
        # Persist the learnings
        for learning in learnings:
            try:
                from tools.memory_tool import memory_tool
                memory_tool(
                    action=learning["action"],
                    target=learning["target"],
                    content=learning["content"],
                    store=self.memory_store,
                )
                logger.info("Memory updated: %s", learning["content"][:50])
            except Exception as e:
                logger.warning("Failed to update memory: %s", e)
    
    def delegate_research_subtask(self, subtopic: str, context: str) -> Dict[str, Any]:
        """
        Delegate a research subtask to a child agent for parallel execution.
        
        This demonstrates the task delegation pattern where the parent agent
        spawns child agents to handle specific subtasks concurrently.
        
        Args:
            subtopic: The specific subtopic to research
            context: Context from the parent research to guide the child
            
        Returns:
            Dict containing the child agent's results
        """
        logger.info("Delegating research subtask: %s", subtopic)
        
        # Create a child agent with limited scope for the subtask
        child_agent = AIAgent(
            model=self.model,
            provider=self.provider,
            max_iterations=15,  # Limited iterations for subtask
            enabled_toolsets=["web", "file"],
            quiet_mode=True,
            parent_session_id=self.agent.session_id,
            iteration_budget=IterationBudget(15),
        )
        
        # Track the child agent for lifecycle management
        with self.agent._active_children_lock:
            self.agent._active_children.append(child_agent)
        
        try:
            # Execute the subtask
            result = child_agent.run_conversation(
                user_message=f"Research the following subtopic: {subtopic}\n\nContext: {context}",
                system_message="You are a focused research assistant. Be concise and thorough.",
                task_id=f"subtask_{subtopic[:30].replace(' ', '_'}",
            )
            
            logger.info("Subtask completed: %s (completed: %s)", subtopic, result["completed"])
            return result
            
        except Exception as e:
            logger.error("Subtask failed: %s - %s", subtopic, e)
            return {"completed": False, "error": str(e)}
            
        finally:
            # Clean up the child agent
            with self.agent._active_children_lock:
                if child_agent in self.agent._active_children:
                    self.agent._active_children.remove(child_agent)
            child_agent.close()
    
    def create_research_skill(self, topic: str, methodology: str) -> bool:
        """
        Create a reusable skill based on the research methodology used.
        
        This demonstrates the skill system integration, allowing the agent
        to package successful research patterns into reusable skills.
        
        Args:
            topic: The research topic that inspired the skill
            methodology: Description of the research methodology used
            
        Returns:
            True if the skill was created successfully
        """
        if not self.skill_enabled:
            logger.info("Skill system is disabled")
            return False
        
        logger.info("Creating research skill based on: %s", topic)
        
        # Build the skill content
        skill_name = f"research-{topic[:20].lower().replace(' ', '-')}"
        skill_content = f"""---
name: {skill_name}
description: Research methodology for investigating {topic}
version: 1.0.0
author: Hermes Agent
metadata:
  hermes:
    tags: [research, methodology, {topic}]
    category: research
---

# Research Methodology: {topic}

## Overview
This skill captures the research methodology used to investigate {topic}.

## Methodology
{methodology}

## Steps
1. Search for authoritative sources on the topic
2. Extract and verify information from multiple sources
3. Synthesize findings into a coherent analysis
4. Generate a structured report with citations
5. Save the report for future reference

## Best Practices
- Always verify information from at least 3 independent sources
- Note publication dates to ensure currency
- Flag conflicting information for further investigation
- Use structured report templates for consistency

## Related Skills
- general-research
- report-generation
"""
        
        try:
            # Use the skill_manage tool to create the skill
            from tools.skills_tool import skill_manage
            result = skill_manage(
                action="create",
                name=skill_name,
                content=skill_content,
            )
            
            result_data = json.loads(result) if isinstance(result, str) else result
            success = result_data.get("success", False)
            
            if success:
                logger.info("Research skill created: %s", skill_name)
            else:
                logger.warning("Failed to create skill: %s", result_data.get("message", "Unknown error"))
            
            return success
            
        except Exception as e:
            logger.error("Failed to create research skill: %s", e)
            return False
    
    def get_session_summary(self) -> Dict[str, Any]:
        """
        Generate a summary of the current research session.
        
        This demonstrates how to extract structured metadata from the
        agent's internal state for reporting and analytics.
        """
        return {
            "session_id": self.agent.session_id,
            "model": self.model,
            "provider": self.provider,
            "topic": self.session_state["topic"],
            "sources_consulted": len(self.session_state["sources_consulted"]),
            "findings_count": len(self.session_state["findings"]),
            "report_generated": self.session_state["report_generated"],
            "api_calls": self.agent.session_api_calls,
            "total_tokens": self.agent.session_total_tokens,
            "estimated_cost": self.agent.session_estimated_cost_usd,
            "memory_entries": len(self.memory_store.get_all_memories()) if self.memory_enabled else 0,
        }
    
    def close(self) -> None:
        """
        Clean up resources and persist state before shutting down.
        
        This demonstrates proper resource management for production systems.
        """
        logger.info("Shutting down ResearchAgent")
        
        # Persist memory to disk
        if self.memory_enabled and self.memory_store:
            try:
                self.memory_store.save_to_disk()
                logger.info("Memory store saved to disk")
            except Exception as e:
                logger.error("Failed to save memory store: %s", e)
        
        # Close the agent and release resources
        try:
            self.agent.shutdown_memory_provider()
            self.agent.close()
            logger.info("Agent resources released")
        except Exception as e:
            logger.error("Error during agent shutdown: %s", e)


def main():
    """
    Main entry point demonstrating the ResearchAgent in action.
    
    This function shows how to:
    1. Initialize the research agent with configuration
    2. Execute a research workflow
    3. Handle results and errors gracefully
    4. Generate session summaries
    """
    # Parse command line arguments
    import argparse
    parser = argparse.ArgumentParser(description="Advanced Research Agent")
    parser.add_argument("topic", nargs="?", default="Python 3.13 features and improvements",
                       help="Research topic")
    parser.add_argument("--depth", choices=["quick", "standard", "deep"], default="standard",
                       help="Research depth")
    parser.add_argument("--model", default="anthropic/claude-sonnet-4-20250514",
                       help="Model to use")
    parser.add_argument("--provider", default="openrouter",
                       help="Provider to route through")
    parser.add_argument("--verbose", action="store_true",
                       help="Enable verbose logging")
    parser.add_argument("--no-memory", action="store_true",
                       help="Disable memory persistence")
    parser.add_argument("--no-skills", action="store_true",
                       help="Disable skill system")
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("  Advanced Research Agent - Hermes Agent Integration Demo")
    print("=" * 60)
    print(f"  Topic: {args.topic}")
    print(f"  Depth: {args.depth}")
    print(f"  Model: {args.model}")
    print(f"  Provider: {args.provider}")
    print("=" * 60)
    
    # Initialize the research agent
    agent = ResearchAgent(
        model=args.model,
        provider=args.provider,
        max_iterations=50,
        verbose=args.verbose,
        memory_enabled=not args.no_memory,
        skill_enabled=not args.no_skills,
    )
    
    try:
        # Execute the research workflow
        print("\n🔍 Starting research...\n")
        result = agent.run_research_workflow(args.topic, args.depth)
        
        # Display results
        print("\n" + "=" * 60)
        print("  Research Results")
        print("=" * 60)
        print(f"  Completed: {'✅ Yes' if result['completed'] else '❌ No'}")
        print(f"  API Calls: {result['api_calls']}")
        print(f"  Total Tokens: {result.get('total_tokens', 'N/A')}")
        print(f"  Estimated Cost: ${result.get('estimated_cost_usd', 0):.4f}")
        
        if result.get("final_response"):
            print("\n  Final Response Preview:")
            print("-" * 40)
            # Show first 500 characters of the response
            preview = result["final_response"][:500]
            print(preview)
            if len(result["final_response"]) > 500:
                print("... (truncated)")
        
        # Generate session summary
        print("\n" + "=" * 60)
        print("  Session Summary")
        print("=" * 60)
        summary = agent.get_session_summary()
        for key, value in summary.items():
            print(f"  {key.replace('_', ' ').title()}: {value}")
        
        # Optionally create a skill from this research
        if not args.no_skills and result["completed"]:
            print("\n" + "=" * 60)
            print("  Creating Research Skill...")
            print("=" * 60)
            methodology = (
                f"A systematic approach to researching {args.topic} involving "
                f"web search, content extraction, multi-source verification, "
                f"and structured report generation. The methodology emphasizes "
                f"source diversity, currency checking, and cross-referencing."
            )
            skill_created = agent.create_research_skill(args.topic, methodology)
            if skill_created:
                print("  ✅ Research skill created successfully!")
            else:
                print("  ⚠️  Skill creation skipped or failed")
        
        print("\n✅ Research workflow completed!")
        
    except KeyboardInterrupt:
        print("\n\n⚠️  Research interrupted by user")
    except Exception as e:
        print(f"\n❌ Research failed with error: {e}")
        logger.exception("Research workflow failed")
    finally:
        # Always clean up resources
        agent.close()
        print("\n🔒 Resources cleaned up")


if __name__ == "__main__":
    main()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation.py
# Description: Basic Library Implementation
# ==========================================

"""
Basic Skill Library Implementation

This module provides a clean, standalone implementation for discovering,
indexing, and invoking skills from a local directory. It demonstrates the
core patterns used by Hermes Agent's skill management system.

Key Features:
- Scans a directory for SKILL.md files
- Parses YAML frontmatter for metadata (name, description, tags)
- Creates a mapping of skill names to their file paths and metadata
- Provides a simple invocation mechanism that returns the skill's content
- Includes a reload mechanism to pick up new or changed skills
"""

import json
import logging
import os
import re
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

# Configure logging for this module
logger = logging.getLogger(__name__)

# ─── Constants ───────────────────────────────────────────────────────────
# The name of the skill definition file within each skill directory
SKILL_MD_FILENAME = "SKILL.md"

# Regular expression to match YAML frontmatter blocks
# Frontmatter is delimited by '---' at the start and end
FRONTMATTER_PATTERN = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)

# Patterns for sanitizing skill names into clean, hyphen-separated slugs
# This ensures compatibility with slash command naming conventions
SKILL_INVALID_CHARS = re.compile(r"[^a-z0-9-]")
SKILL_MULTI_HYPHEN = re.compile(r"-{2,}")

# ─── Data Structures ─────────────────────────────────────────────────────


class SkillMetadata:
    """
    Represents the parsed metadata from a skill's SKILL.md frontmatter.

    This class encapsulates all the information needed to identify, describe,
    and invoke a skill. It follows the Principle of Least Astonishment (POLA)
    by providing clear, predictable attribute names and behavior.
    """

    def __init__(
        self,
        name: str,
        description: str = "",
        version: str = "1.0.0",
        author: str = "",
        tags: Optional[List[str]] = None,
        category: str = "general",
        platforms: Optional[List[str]] = None,
    ):
        """
        Initialize a SkillMetadata instance.

        Args:
            name: The canonical name of the skill (e.g., "gif-search")
            description: A human-readable description of what the skill does
            version: Semantic version string (default: "1.0.0")
            author: The creator of the skill
            tags: A list of searchable tags for the skill
            category: The functional category of the skill (default: "general")
            platforms: A list of OS platforms this skill supports (e.g., ["macos", "linux"])
        """
        self.name = name
        self.description = description
        self.version = version
        self.author = author
        self.tags = tags or []
        self.category = category
        self.platforms = platforms or []

    def to_dict(self) -> Dict[str, Any]:
        """Convert the metadata to a dictionary for serialization or display."""
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "author": self.author,
            "tags": self.tags,
            "category": self.category,
            "platforms": self.platforms,
        }

    @classmethod
    def from_frontmatter(cls, frontmatter: Dict[str, Any]) -> "SkillMetadata":
        """
        Create a SkillMetadata instance from a parsed YAML frontmatter dict.

        This class method handles the extraction of known fields and provides
        sensible defaults for any missing values.

        Args:
            frontmatter: A dictionary of key-value pairs from the SKILL.md frontmatter

        Returns:
            A new SkillMetadata instance populated with the frontmatter data
        """
        # Extract the name, falling back to a placeholder if missing
        name = frontmatter.get("name", "").strip()
        if not name:
            logger.warning("Skill frontmatter missing 'name' field; using placeholder.")
            name = "unnamed-skill"

        # Extract description, version, author, tags, category, and platforms
        description = frontmatter.get("description", "").strip()
        version = str(frontmatter.get("version", "1.0.0")).strip()
        author = frontmatter.get("author", "").strip()
        tags = frontmatter.get("tags", [])
        if isinstance(tags, str):
            tags = [tag.strip() for tag in tags.split(",")]
        category = frontmatter.get("category", "general").strip().lower()
        platforms = frontmatter.get("platforms", [])
        if isinstance(platforms, str):
            platforms = [p.strip() for p in platforms.split(",")]

        return cls(
            name=name,
            description=description,
            version=version,
            author=author,
            tags=tags,
            category=category,
            platforms=platforms,
        )


class SkillInfo:
    """
    Represents a discovered skill with its metadata, file path, and content.

    This is the primary data structure returned by the skill scanner. It
    bundles all the information needed to load and use a skill.
    """

    def __init__(
        self,
        metadata: SkillMetadata,
        skill_md_path: Path,
        skill_dir: Path,
        content: str = "",
    ):
        """
        Initialize a SkillInfo instance.

        Args:
            metadata: The parsed metadata from the SKILL.md frontmatter
            skill_md_path: The absolute path to the SKILL.md file
            skill_dir: The absolute path to the skill's directory
            content: The full text content of the SKILL.md file (optional)
        """
        self.metadata = metadata
        self.skill_md_path = skill_md_path
        self.skill_dir = skill_dir
        self.content = content

    def to_dict(self) -> Dict[str, Any]:
        """Convert the skill info to a dictionary for serialization."""
        return {
            "name": self.metadata.name,
            "description": self.metadata.description,
            "version": self.metadata.version,
            "author": self.metadata.author,
            "tags": self.metadata.tags,
            "category": self.metadata.category,
            "platforms": self.metadata.platforms,
            "skill_md_path": str(self.skill_md_path),
            "skill_dir": str(self.skill_dir),
            "content_length": len(self.content),
        }


# ─── Frontmatter Parser ─────────────────────────────────────────────────


def parse_frontmatter(content: str) -> Tuple[Dict[str, Any], str]:
    """
    Parse YAML frontmatter from a skill file's content.

    This function extracts the YAML frontmatter block (delimited by '---')
    and returns it as a dictionary, along with the remaining body content.
    It uses a simple regex-based approach for parsing, which is sufficient
    for the basic metadata fields used in SKILL.md files.

    Args:
        content: The full text content of a SKILL.md file

    Returns:
        A tuple of (frontmatter_dict, body_content_string)
    """
    # Attempt to match the frontmatter pattern at the start of the content
    match = FRONTMATTER_PATTERN.match(content)
    if not match:
        # No frontmatter found; return an empty dict and the full content as body
        return {}, content.strip()

    # Extract the raw YAML string and the body content
    raw_yaml = match.group(1)
    body = content[match.end():].strip()

    # Parse the raw YAML string into a dictionary
    # We use a simple key-value parser for this example
    frontmatter = {}
    for line in raw_yaml.split("\n"):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" in line:
            key, _, value = line.partition(":")
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            frontmatter[key] = value

    return frontmatter, body


def sanitize_skill_name(name: str) -> str:
    """
    Sanitize a skill name into a clean, hyphen-separated slug.

    This ensures compatibility with slash command naming conventions
    (e.g., Telegram bot commands disallow hyphens, so we normalize
    spaces and underscores to hyphens).

    Args:
        name: The raw skill name to sanitize

    Returns:
        A sanitized, hyphen-separated slug
    """
    # Convert to lowercase and replace spaces/underscores with hyphens
    slug = name.lower().replace(" ", "-").replace("_", "-")

    # Remove any characters that are not alphanumeric or hyphens
    slug = SKILL_INVALID_CHARS.sub("", slug)

    # Collapse multiple consecutive hyphens into a single hyphen
    slug = SKILL_MULTI_HYPHEN.sub("-", slug)

    # Strip leading and trailing hyphens
    slug = slug.strip("-")

    return slug


# ─── Skill Scanner ──────────────────────────────────────────────────────


class SkillScanner:
    """
    Scans a directory for SKILL.md files and indexes them as skills.

    This class is the core of the skill discovery system. It walks a given
    directory tree, finds all SKILL.md files, parses their frontmatter, and
    creates a mapping of skill names to their metadata and file paths.

    The scanner is designed to be efficient and robust, handling missing
    files, malformed frontmatter, and duplicate skill names gracefully.
    """

    def __init__(self, skills_dir: Path):
        """
        Initialize the SkillScanner with a root directory to scan.

        Args:
            skills_dir: The root directory to scan for skill files
        """
        self.skills_dir = skills_dir
        self._skills: Dict[str, SkillInfo] = {}
        self._last_scan_time: Optional[datetime] = None

    def scan(self) -> Dict[str, SkillInfo]:
        """
        Perform a full scan of the skills directory.

        This method walks the directory tree, finds all SKILL.md files,
        parses their frontmatter, and builds an in-memory index of skills.
        It returns a dictionary mapping sanitized skill names to SkillInfo objects.

        Returns:
            A dictionary of {sanitized_skill_name: SkillInfo}
        """
        # Reset the skills index before scanning
        self._skills = {}
        seen_names: Set[str] = set()

        # Ensure the skills directory exists before scanning
        if not self.skills_dir.exists():
            logger.warning(f"Skills directory does not exist: {self.skills_dir}")
            return self._skills

        # Walk the directory tree, looking for SKILL.md files
        for skill_md_path in self.skills_dir.rglob(SKILL_MD_FILENAME):
            # Skip hidden directories (e.g., .git, .github)
            if any(part.startswith(".") for part in skill_md_path.parts):
                continue

            try:
                # Read the SKILL.md file content
                content = skill_md_path.read_text(encoding="utf-8")

                # Parse the frontmatter and body
                frontmatter, body = parse_frontmatter(content)

                # Create a SkillMetadata object from the frontmatter
                metadata = SkillMetadata.from_frontmatter(frontmatter)

                # Sanitize the skill name for use as a slash command
                sanitized_name = sanitize_skill_name(metadata.name)

                # Skip duplicate skill names (first one wins)
                if sanitized_name in seen_names:
                    logger.warning(
                        f"Duplicate skill name '{sanitized_name}' found at "
                        f"{skill_md_path}; skipping."
                    )
                    continue

                # Mark this name as seen
                seen_names.add(sanitized_name)

                # Create a SkillInfo object and add it to the index
                skill_info = SkillInfo(
                    metadata=metadata,
                    skill_md_path=skill_md_path,
                    skill_dir=skill_md_path.parent,
                    content=content,
                )
                self._skills[sanitized_name] = skill_info

                logger.info(
                    f"Discovered skill: {sanitized_name} "
                    f"({metadata.description})"
                )

            except Exception as e:
                # Log the error but continue scanning other skills
                logger.error(
                    f"Failed to parse skill at {skill_md_path}: {e}"
                )

        # Record the scan time
        self._last_scan_time = datetime.now()

        logger.info(
            f"Scan complete. Found {len(self._skills)} skill(s) "
            f"in {self.skills_dir}."
        )
        return self._skills

    def get_skill(self, name: str) -> Optional[SkillInfo]:
        """
        Retrieve a skill by its sanitized name.

        Args:
            name: The sanitized skill name (e.g., "gif-search")

        Returns:
            The SkillInfo object if found, or None if not found
        """
        return self._skills.get(name)

    def get_all_skills(self) -> Dict[str, SkillInfo]:
        """
        Return the current index of all discovered skills.

        Returns:
            A dictionary of {sanitized_skill_name: SkillInfo}
        """
        return dict(self._skills)

    def reload(self) -> Dict[str, SkillInfo]:
        """
        Re-scan the skills directory and return the updated index.

        This method is useful for picking up new or changed skills without
        restarting the application.

        Returns:
            The updated dictionary of {sanitized_skill_name: SkillInfo}
        """
        logger.info("Reloading skills...")
        return self.scan()


# ─── Skill Library ──────────────────────────────────────────────────────


class SkillLibrary:
    """
    A high-level interface for managing a collection of skills.

    This class wraps the SkillScanner and provides a convenient API for
    loading, querying, and invoking skills. It also handles the creation
    of slash command mappings and provides methods for building skill
    invocation messages.

    This is the primary class that other parts of the application interact
    with when they need to work with skills.
    """

    def __init__(self, skills_dir: Path):
        """
        Initialize the SkillLibrary with a root directory.

        Args:
            skills_dir: The root directory containing skill subdirectories
        """
        self.skills_dir = skills_dir
        self._scanner = SkillScanner(skills_dir)
        self._skills: Dict[str, SkillInfo] = {}
        self._command_map: Dict[str, str] = {}

    def load_all(self) -> int:
        """
        Load all skills from the skills directory into the library.

        This method performs an initial scan and populates the internal
        skill index and command map.

        Returns:
            The number of skills successfully loaded
        """
        self._skills = self._scanner.scan()
        self._build_command_map()
        return len(self._skills)

    def _build_command_map(self) -> None:
        """
        Build a mapping of slash command names to skill names.

        Each skill becomes a slash command like "/gif-search" or "/code-review".
        This mapping is used by the invocation system to route commands to
        the correct skill.
        """
        self._command_map = {}
        for sanitized_name, skill_info in self._skills.items():
            # Create the slash command key (e.g., "/gif-search")
            command_key = f"/{sanitized_name}"
            self._command_map[command_key] = sanitized_name

    def get_skill_for_command(self, command: str) -> Optional[SkillInfo]:
        """
        Resolve a slash command to its corresponding SkillInfo.

        Args:
            command: The slash command string (e.g., "/gif-search")

        Returns:
            The SkillInfo object if the command is valid, or None
        """
        # Normalize the command: strip leading slash and sanitize hyphens/underscores
        raw_name = command.lstrip("/").replace("_", "-")
        sanitized_name = sanitize_skill_name(raw_name)

        # Look up the skill by its sanitized name
        return self._skills.get(sanitized_name)

    def build_invocation_message(
        self, command: str, user_instruction: str = ""
    ) -> Optional[str]:
        """
        Build a user message that invokes a skill.

        This method constructs the message that will be sent to the AI agent
        when a user invokes a skill via a slash command. It includes the
        skill's full content and instructions for the agent.

        Args:
            command: The slash command string (e.g., "/gif-search")
            user_instruction: Optional additional text from the user

        Returns:
            A formatted message string, or None if the skill wasn't found
        """
        # Resolve the command to a skill
        skill_info = self.get_skill_for_command(command)
        if not skill_info:
            return None

        # Build the activation note that instructs the agent
        activation_note = (
            f'[IMPORTANT: The user has invoked the "{skill_info.metadata.name}" '
            f'skill, indicating they want you to follow its instructions. '
            f"The full skill content is loaded below.]"
        )

        # Assemble the message parts
        parts = [
            activation_note,
            "",
            skill_info.content.strip(),
        ]

        # Add the skill directory hint so the agent can reference bundled files
        parts.append("")
        parts.append(f"[Skill directory: {skill_info.skill_dir}]")
        parts.append(
            "Resolve any relative paths in this skill against that directory."
        )

        # Add the user's instruction if provided
        if user_instruction:
            parts.append("")
            parts.append(
                f"The user has provided the following instruction alongside "
                f"the skill invocation: {user_instruction}"
            )

        return "\n".join(parts)

    def list_skills(self) -> List[Dict[str, Any]]:
        """
        Return a list of all discovered skills as dictionaries.

        This is useful for displaying a menu or help text to the user.

        Returns:
            A list of dictionaries, each representing a skill
        """
        return [
            {
                "command": f"/{name}",
                "name": info.metadata.name,
                "description": info.metadata.description,
                "category": info.metadata.category,
                "tags": info.metadata.tags,
            }
            for name, info in sorted(self._skills.items())
        ]

    def reload(self) -> int:
        """
        Re-scan the skills directory and reload the library.

        Returns:
            The number of skills loaded after the reload
        """
        self._skills = self._scanner.reload()
        self._build_command_map()
        return len(self._skills)


# ─── Example Usage ──────────────────────────────────────────────────────


def main():
    """
    Demonstrate the basic usage of the SkillLibrary.

    This function creates a temporary directory with a few sample skills,
    loads them into the library, and demonstrates how to query and invoke them.
    """
    import tempfile
    import shutil

    # Create a temporary directory for our example skills
    temp_dir = tempfile.mkdtemp(prefix="hermes_skills_")
    skills_root = Path(temp_dir)

    try:
        # ── Create Sample Skills ──────────────────────────────────────
        # We'll create two sample skills to demonstrate the system.

        # Skill 1: Gif Search
        gif_skill_dir = skills_root / "gif-search"
        gif_skill_dir.mkdir()
        gif_skill_content = """---
name: Gif Search
description: Search for animated GIFs using the Giphy API
version: 1.0.0
author: Hermes Agent
tags: [gif, search, media, fun]
category: media
platforms: [macos, linux, windows]
---

# Gif Search Skill

Use this skill when the user asks you to find an animated GIF.

## Instructions

1. Use the `web_search` tool to search for a GIF on Giphy or Tenor.
2. Extract the direct GIF URL from the search results.
3. Return the URL to the user with a brief description.

## Examples

- User: "Find me a funny cat GIF"
- User: "Search for a celebration GIF"

## Notes

- Prefer Giphy for wider selection.
- Always verify the URL is a direct GIF link (ends in .gif).
"""
        (gif_skill_dir / "SKILL.md").write_text(gif_skill_content.strip())

        # Skill 2: Code Review
        code_review_skill_dir = skills_root / "code-review"
        code_review_skill_dir.mkdir()
        code_review_skill_content = """---
name: Code Review
description: Perform a thorough code review on a given file or code snippet
version: 2.1.0
author: Hermes Agent
tags: [code, review, quality, best-practices]
category: development
platforms: [macos, linux, windows]
---

# Code Review Skill

Use this skill when the user asks you to review their code.

## Instructions

1. Read the code file using the `read_file` tool.
2. Analyze the code for:
   - Bugs and logical errors
   - Security vulnerabilities
   - Performance issues
   - Code style and best practices
   - Documentation completeness
3. Provide a structured report with:
   - Summary of findings
   - Critical issues (must fix)
   - Warnings (should fix)
   - Suggestions (nice to have)

## Examples

- User: "Review my Python script"
- User: "Can you check this JavaScript function?"

## Notes

- Be constructive and specific in your feedback.
- Always provide code examples for suggested fixes.
"""
        (code_review_skill_dir / "SKILL.md").write_text(code_review_skill_content.strip())

        # ── Initialize the Skill Library ──────────────────────────────
        print("=" * 60)
        print("  HERMES AGENT - BASIC SKILL LIBRARY EXAMPLE")
        print("=" * 60)

        # Create the skill library and load all skills
        library = SkillLibrary(skills_root)
        num_skills = library.load_all()
        print(f"\n📚 Loaded {num_skills} skill(s) from {skills_root}")

        # ── List All Skills ───────────────────────────────────────────
        print("\n📋 Available Skills:")
        print("-" * 60)
        for skill in library.list_skills():
            print(f"  {skill['command']:20} - {skill['description']}")
            print(f"    Category: {skill['category']}, Tags: {', '.join(skill['tags'])}")
            print()

        # ── Query a Specific Skill ────────────────────────────────────
        print("\n🔍 Querying Skill: /gif-search")
        print("-" * 60)
        skill_info = library.get_skill_for_command("/gif-search")
        if skill_info:
            print(f"  Name: {skill_info.metadata.name}")
            print(f"  Version: {skill_info.metadata.version}")
            print(f"  Author: {skill_info.metadata.author}")
            print(f"  Path: {skill_info.skill_md_path}")
            print(f"  Content Length: {len(skill_info.content)} characters")
        else:
            print("  Skill not found!")

        # ── Build an Invocation Message ───────────────────────────────
        print("\n📝 Building Invocation Message for /gif-search")
        print("-" * 60)
        invocation = library.build_invocation_message(
            "/gif-search",
            user_instruction="Find a funny cat GIF"
        )
        if invocation:
            # Print a preview of the message
            preview_lines = invocation.split("\n")[:5]
            for line in preview_lines:
                print(f"  {line}")
            print("  ...")
            print(f"  (Total length: {len(invocation)} characters)")
        else:
            print("  Failed to build invocation message!")

        # ── Test Invalid Command ──────────────────────────────────────
        print("\n❌ Testing Invalid Command: /nonexistent-skill")
        print("-" * 60)
        result = library.get_skill_for_command("/nonexistent-skill")
        if result is None:
            print("  Correctly returned None for unknown command.")
        else:
            print("  Unexpectedly found a skill!")

        # ── Demonstrate Reload ────────────────────────────────────────
        print("\n🔄 Demonstrating Reload (adding a new skill)...")
        print("-" * 60)

        # Create a new skill while the library is running
        new_skill_dir = skills_root / "weather-check"
        new_skill_dir.mkdir()
        new_skill_content = """---
name: Weather Check
description: Get the current weather for a given city
version: 1.0.0
author: Hermes Agent
tags: [weather, forecast, climate]
category: utilities
platforms: [macos, linux, windows]
---

# Weather Check Skill

Use this skill when the user asks about the weather.

## Instructions

1. Use the `web_search` tool to find the current weather for the specified city.
2. Extract the temperature, conditions, and forecast.
3. Present the information in a clear, concise format.
"""
        (new_skill_dir / "SKILL.md").write_text(new_skill_content.strip())

        # Reload the library to pick up the new skill
        num_skills_after = library.reload()
        print(f"  Skills after reload: {num_skills_after} (was {num_skills})")
        print(f"  New skill available at: /weather-check")

        # Verify the new skill is accessible
        new_skill = library.get_skill_for_command("/weather-check")
        if new_skill:
            print(f"  ✅ Successfully loaded: {new_skill.metadata.name}")
        else:
            print("  ❌ Failed to load new skill!")

    finally:
        # Clean up the temporary directory
        shutil.rmtree(temp_dir)
        print("\n🧹 Cleaned up temporary files.")


if __name__ == "__main__":
    # Configure basic logging for the example
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    main()

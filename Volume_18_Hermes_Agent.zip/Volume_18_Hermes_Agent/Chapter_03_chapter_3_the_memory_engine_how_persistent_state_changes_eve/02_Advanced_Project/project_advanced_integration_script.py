
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script.py
# Description: Advanced Integration Script
# ==========================================

#!/usr/bin/env python3
"""
Advanced Integration Script for Hermes Agent Memory Engine.

Demonstrates:
- SQLite session persistence (SessionDB)
- Built-in memory tools (memory, skill_manage)
- External memory provider plugin (simulated)
- Task delegation with persistent context
- Closed learning loop via background self-improvement reviews

Usage:
    python advanced_memory_integration.py
"""

import os
import sys
import json
import time
import logging
from pathlib import Path
from typing import Dict, Any, Optional

# ── Hermes Agent core imports ──────────────────────────────────────────────
from run_agent import AIAgent, IterationBudget
from hermes_state import SessionDB, DEFAULT_DB_PATH
from agent.memory_manager import MemoryManager, build_memory_context_block
from agent.memory_provider import MemoryProvider
from tools.memory_tool import MemoryStore
from tools.skill_provenance import set_current_write_origin

# ── Configure logging ──────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("memory_integration.log"),
    ],
)
logger = logging.getLogger("advanced_memory_integration")


# =========================================================================
# 1. External Memory Provider (Plugin)
# =========================================================================
class SimpleExternalMemoryProvider(MemoryProvider):
    """
    A minimal external memory provider that mirrors writes to a local JSON file.
    In production, this would connect to a vector database or Honcho API.
    """

    def __init__(self, name: str = "external_json"):
        super().__init__(name)
        self._store_path = Path.home() / ".hermes" / "external_memory.json"
        self._store_path.parent.mkdir(parents=True, exist_ok=True)
        self._data: Dict[str, Any] = {}
        self._load()

    def _load(self):
        if self._store_path.exists():
            try:
                with open(self._store_path, "r") as f:
                    self._data = json.load(f)
            except (json.JSONDecodeError, OSError):
                self._data = {}

    def _save(self):
        with open(self._store_path, "w") as f:
            json.dump(self._data, f, indent=2)

    # ── Required provider interface ─────────────────────────────────────
    def system_prompt_block(self) -> str:
        return "You have access to an external memory store. Use `external_memory` tools."

    def prefetch(self, query: str, *, session_id: str = "") -> str:
        """Return relevant external memories for the query."""
        if not self._data:
            return ""
        # Simple keyword matching (in production: vector search)
        query_lower = query.lower()
        relevant = []
        for key, value in self._data.items():
            if any(word in key.lower() for word in query_lower.split()):
                relevant.append(f"{key}: {value}")
        if relevant:
            return "External memory:\n" + "\n".join(relevant)
        return ""

    def sync_turn(self, user_content: str, assistant_content: str, *, session_id: str = "") -> None:
        """Store key-value pairs extracted from the turn."""
        # Simulate extracting a user preference
        if "prefer" in user_content.lower() or "remember" in user_content.lower():
            # Simple heuristic: "remember that I like X" -> store "preference: X"
            import re
            match = re.search(r"(?:remember|prefer)\s+(?:that\s+)?(?:I\s+)?(.+)", user_content, re.IGNORECASE)
            if match:
                key = "user_preference"
                value = match.group(1).strip()
                self._data[key] = value
                self._save()

    def get_tool_schemas(self) -> list:
        return [
            {
                "name": "external_memory",
                "description": "Read or write external memory. Action: 'read' or 'write'.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "action": {"type": "string", "enum": ["read", "write"]},
                        "key": {"type": "string"},
                        "value": {"type": "string"},
                    },
                    "required": ["action", "key"],
                },
            }
        ]

    def handle_tool_call(self, tool_name: str, args: Dict[str, Any], **kwargs) -> str:
        if tool_name != "external_memory":
            return json.dumps({"error": f"Unknown tool: {tool_name}"})
        action = args.get("action")
        key = args.get("key")
        value = args.get("value")
        if action == "read":
            result = self._data.get(key, "Not found")
            return json.dumps({"success": True, "value": result})
        elif action == "write" and value is not None:
            self._data[key] = value
            self._save()
            return json.dumps({"success": True, "message": f"Stored {key}"})
        return json.dumps({"success": False, "error": "Invalid action or missing value"})

    def is_available(self) -> bool:
        return True

    def initialize(self, session_id: str, **kwargs) -> None:
        logger.info("External memory provider initialized for session %s", session_id)

    def shutdown(self) -> None:
        logger.info("External memory provider shutting down")


# =========================================================================
# 2. Session Database Setup
# =========================================================================
def setup_session_db() -> SessionDB:
    """Initialize the SQLite session store with WAL mode and FTS5 search."""
    db = SessionDB()
    # Ensure the schema is up-to-date
    db._init_schema()
    logger.info("Session database ready at %s", db.db_path)
    return db


# =========================================================================
# 3. Agent Factory with Memory Integration
# =========================================================================
def create_research_agent(
    session_db: SessionDB,
    session_id: str,
    model: str = "anthropic/claude-sonnet-4",
    provider: str = "openrouter",
    base_url: str = "https://openrouter.ai/api/v1",
    api_key: Optional[str] = None,
    memory_enabled: bool = True,
    external_provider: Optional[MemoryProvider] = None,
) -> AIAgent:
    """
    Create an AIAgent configured with persistent memory and external provider.
    """
    # Build agent with memory tools enabled
    agent = AIAgent(
        base_url=base_url or os.environ.get("OPENROUTER_API_KEY", ""),
        model=model,
        provider=provider,
        api_key=api_key or os.environ.get("OPENROUTER_API_KEY", ""),
        max_iterations=30,
        enabled_toolsets=["memory", "skills", "research"],  # includes memory, skill_manage, web_search, etc.
        session_id=session_id,
        session_db=session_db,
        quiet_mode=False,
        verbose_logging=False,
        skip_memory=not memory_enabled,
    )

    # Attach external memory provider via MemoryManager
    if external_provider is not None:
        # The agent's _memory_manager is already initialized if memory is enabled.
        # We add the external provider to the existing manager.
        if agent._memory_manager is None:
            agent._memory_manager = MemoryManager()
        agent._memory_manager.add_provider(external_provider)
        # Rebuild tool definitions to include external provider tools
        for schema in external_provider.get_tool_schemas():
            if schema["name"] not in agent.valid_tool_names:
                agent.tools.append({"type": "function", "function": schema})
                agent.valid_tool_names.add(schema["name"])
        logger.info("External memory provider '%s' registered", external_provider.name)

    return agent


# =========================================================================
# 4. Multi-turn Conversation with Memory
# =========================================================================
def run_research_session(agent: AIAgent, session_db: SessionDB, user_queries: list[str]):
    """
    Run a sequence of user queries, demonstrating memory persistence across turns.
    """
    for i, query in enumerate(user_queries):
        print(f"\n{'='*60}")
        print(f"Turn {i+1}: {query}")
        print(f"{'='*60}")

        # Run the conversation
        result = agent.run_conversation(
            user_message=query,
            conversation_history=None,  # agent maintains its own messages list
        )

        # Print summary
        if result["final_response"]:
            print(f"\nAssistant: {result['final_response'][:200]}...")
        print(f"API calls: {result['api_calls']}, Completed: {result['completed']}")

        # Show memory state after turn
        if agent._memory_store:
            mem = agent._memory_store.format_for_system_prompt("memory")
            if mem:
                print(f"Memory snapshot: {mem[:100]}...")

        # Show external memory state
        external_file = Path.home() / ".hermes" / "external_memory.json"
        if external_file.exists():
            with open(external_file) as f:
                ext_data = json.load(f)
            if ext_data:
                print(f"External memory: {ext_data}")

    # Final summary
    print("\n\n=== SESSION SUMMARY ===")
    print(f"Total API calls: {agent.session_api_calls}")
    print(f"Total tokens: {agent.session_total_tokens:,}")
    print(f"Estimated cost: ${agent.session_estimated_cost_usd:.4f}")

    # Print all stored memories
    if agent._memory_store:
        print("\n=== PERSISTED MEMORIES ===")
        mem = agent._memory_store.format_for_system_prompt("memory")
        user = agent._memory_store.format_for_system_prompt("user")
        if mem:
            print("Memory:", mem[:500])
        if user:
            print("User profile:", user[:500])


# =========================================================================
# 5. Background Self-Improvement Review
# =========================================================================
def trigger_skill_review(agent: AIAgent, messages_snapshot: list):
    """
    Manually trigger a background skill review after a session.
    This is normally done automatically by the agent's nudge logic.
    """
    if agent._memory_manager and "skill_manage" in agent.valid_tool_names:
        # Simulate the background review (agent._spawn_background_review is private)
        # In production, this runs in a separate thread.
        print("\n--- Triggering background skill review ---")
        try:
            # We'll call the internal method for demonstration
            agent._spawn_background_review(
                messages_snapshot=messages_snapshot,
                review_memory=True,
                review_skills=True,
            )
            # Wait briefly for the thread to start
            time.sleep(1)
            print("Background review launched (non-blocking).")
        except Exception as e:
            logger.warning("Background review failed: %s", e)


# =========================================================================
# 6. Main Execution
# =========================================================================
def main():
    """
    Demonstrate the full memory engine integration.
    """
    print("Hermes Agent Memory Engine - Advanced Integration Demo")
    print("=" * 60)

    # 1. Setup session database
    session_db = setup_session_db()

    # 2. Create a unique session ID for this demo
    import uuid
    session_id = f"demo_{uuid.uuid4().hex[:8]}"

    # 3. Create external memory provider
    ext_provider = SimpleExternalMemoryProvider()

    # 4. Create the agent with memory enabled
    agent = create_research_agent(
        session_db=session_db,
        session_id=session_id,
        model="anthropic/claude-sonnet-4",  # or any tool-capable model
        memory_enabled=True,
        external_provider=ext_provider,
    )

    # 5. Define a series of queries that build on each other
    queries = [
        "Hello! I'm starting a research project on climate modeling. Remember that I prefer concise answers with bullet points.",
        "What are the key components of a climate model? Use memory to recall my preference.",
        "Can you write a Python script to compute the global average temperature from a simple energy balance model?",
        "Now save that script as a skill so I can reuse it later.",
        "What other skills do I have? Also, remember that I like to see code examples in my summaries.",
    ]

    # 6. Run the conversation session
    run_research_session(agent, session_db, queries)

    # 7. Trigger a background skill review (simulating end-of-session)
    messages_snapshot = agent._session_messages
    trigger_skill_review(agent, messages_snapshot)

    # 8. Verify persistence by creating a new agent with the same session_id
    print("\n\n=== VERIFYING PERSISTENCE ===")
    print("Creating a new agent with the same session ID to test memory load...")
    agent2 = create_research_agent(
        session_db=session_db,
        session_id=session_id,
        memory_enabled=True,
        external_provider=ext_provider,
    )
    # The memory store should have loaded from disk
    if agent2._memory_store:
        mem = agent2._memory_store.format_for_system_prompt("memory")
        user = agent2._memory_store.format_for_system_prompt("user")
        if mem:
            print("Loaded memory:", mem[:300])
        if user:
            print("Loaded user profile:", user[:300])

    # 9. Cleanup
    agent.close()
    agent2.close()
    print("\nDemo completed successfully.")


if __name__ == "__main__":
    main()

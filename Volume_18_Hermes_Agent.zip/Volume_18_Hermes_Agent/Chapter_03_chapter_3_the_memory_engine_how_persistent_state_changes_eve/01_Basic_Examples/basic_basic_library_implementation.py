
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation.py
# Description: Basic Library Implementation
# ==========================================

#!/usr/bin/env python3
"""
Example: Building a persistent AI agent using Hermes' SessionDB and AIAgent.

This demonstrates:
1. Setting up the SQLite session store
2. Creating an agent with persistent memory
3. Running conversations that build on previous context
4. Querying past sessions for recall
"""

import logging
import sys
from pathlib import Path

from hermes_state import SessionDB
from run_agent import AIAgent
from hermes_constants import get_hermes_home

# Configure logging to see what's happening
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    stream=sys.stderr,
)

# =========================================================================
# STEP 1: Initialize the persistent session database
# =========================================================================
# The SessionDB manages all session data in a single SQLite file with
# WAL mode for concurrent access and FTS5 for full-text search.
# We use the default path (~/.hermes/state.db) for consistency with
# the Hermes ecosystem.

db_path = get_hermes_home() / "state.db"
print(f"📁 Session database: {db_path}")

# Create the database connection. This automatically:
# - Creates the schema if it doesn't exist
# - Sets up FTS5 virtual tables for message search
# - Configures WAL mode for concurrent access
session_db = SessionDB(db_path=db_path)

# =========================================================================
# STEP 2: Create a new session
# =========================================================================
# A session represents one conversation thread. We give it a unique ID
# and tag it with a source (e.g., "cli", "telegram", "discord").
# The session stores metadata like the model used, when it started,
# and token usage.

import uuid
session_id = f"example_{uuid.uuid4().hex[:8]}"
print(f"🆕 Creating session: {session_id}")

session_db.create_session(
    session_id=session_id,
    source="example_script",       # Tag for filtering
    model="anthropic/claude-sonnet-4-6",  # Model used
    user_id="alice",               # Optional user identifier
    system_prompt="You are a helpful assistant that remembers context.",  # Initial system prompt
)

# =========================================================================
# STEP 3: Initialize the AI Agent with session persistence
# =========================================================================
# The AIAgent constructor accepts a session_db parameter. When provided,
# every message, token count, and cost estimate is automatically persisted
# to the database.

agent = AIAgent(
    # Provider configuration
    model="anthropic/claude-sonnet-4-6",
    base_url="https://openrouter.ai/api/v1",
    api_key="your-api-key-here",  # Use OPENROUTER_API_KEY env var in production
    
    # Session persistence
    session_id=session_id,
    session_db=session_db,
    
    # Agent behavior
    max_iterations=30,           # Max tool-calling iterations per turn
    quiet_mode=True,             # Suppress verbose output
    save_trajectories=False,     # Don't save JSONL trajectories
    
    # Memory configuration
    skip_memory=False,           # Enable built-in memory (MEMORY.md)
)

# =========================================================================
# STEP 4: Run the first conversation turn
# =========================================================================
# The agent processes the user message, calls tools if needed, and
# automatically persists the conversation to the database.
# We use run_conversation() which returns the final response and
# message history.

print("\n" + "=" * 60)
print("💬 TURN 1: First interaction")
print("=" * 60)

result1 = agent.run_conversation(
    user_message="Hi! My name is Alice. I'm working on a Python project "
                 "that processes CSV files. Can you help me set up a "
                 "basic data pipeline?",
)

print(f"\n✅ Response: {result1['final_response'][:200]}...")
print(f"📊 API calls: {result1['api_calls']}")
print(f"💰 Cost: ${result1['estimated_cost_usd']:.4f}")

# =========================================================================
# STEP 5: Run a second turn that builds on the first
# =========================================================================
# Because the agent has persistent state, it remembers the previous
# conversation. The user can refer to earlier context without repeating
# themselves.

print("\n" + "=" * 60)
print("💬 TURN 2: Follow-up (agent remembers context)")
print("=" * 60)

result2 = agent.run_conversation(
    user_message="Actually, I'd like to use pandas instead of the csv "
                 "module. Can you rewrite the pipeline?",
)

print(f"\n✅ Response: {result2['final_response'][:200]}...")
print(f"📊 API calls: {result2['api_calls']}")

# =========================================================================
# STEP 6: Query the session database for insights
# =========================================================================
# The SessionDB provides rich querying capabilities. We can:
# - List all sessions with previews
# - Search messages by content
# - Get token usage statistics

print("\n" + "=" * 60)
print("🔍 Querying session database")
print("=" * 60)

# Get the session metadata
session_data = session_db.get_session(session_id)
if session_data:
    print(f"📋 Session info:")
    print(f"   - Model: {session_data.get('model', 'N/A')}")
    print(f"   - Messages: {session_data.get('message_count', 0)}")
    print(f"   - Input tokens: {session_data.get('input_tokens', 0):,}")
    print(f"   - Output tokens: {session_data.get('output_tokens', 0):,}")
    print(f"   - Cost: ${session_data.get('estimated_cost_usd', 0):.4f}")

# Search for messages containing "pandas"
print("\n🔎 Searching for 'pandas' in messages:")
search_results = session_db.search_messages(
    query="pandas",
    limit=5,
)
for msg in search_results:
    print(f"   [{msg['role']}] {msg.get('snippet', '')[:100]}...")

# =========================================================================
# STEP 7: List all sessions with previews
# =========================================================================
# The list_sessions_rich() method returns sessions with a preview of
# the first user message and the last activity timestamp.

print("\n📋 Recent sessions:")
sessions = session_db.list_sessions_rich(
    source="example_script",
    limit=5,
    include_children=False,
)
for s in sessions:
    print(f"   - {s['id'][:20]}... | {s['preview'][:40]}... | "
          f"Messages: {s.get('message_count', 0)}")

# =========================================================================
# STEP 8: Demonstrate session resumption
# =========================================================================
# A key feature: you can resume a session later by creating a new AIAgent
# with the same session_id. The agent loads the conversation history from
# the database and continues where it left off.

print("\n" + "=" * 60)
print("🔄 Demonstrating session resumption")
print("=" * 60)

# Create a new agent instance with the same session ID
resumed_agent = AIAgent(
    model="anthropic/claude-sonnet-4-6",
    base_url="https://openrouter.ai/api/v1",
    api_key="your-api-key-here",
    session_id=session_id,
    session_db=session_db,
    quiet_mode=True,
    skip_memory=False,
)

# The resumed agent automatically loads the conversation history
# from the database and can continue the conversation
result3 = resumed_agent.run_conversation(
    user_message="Remember me? What were we working on?",
)

print(f"\n✅ Response: {result3['final_response'][:200]}...")
print(f"   (Agent remembered Alice and the CSV/pandas pipeline)")

# =========================================================================
# STEP 9: Clean up resources
# =========================================================================
# Properly close the database connection and release agent resources.

print("\n" + "=" * 60)
print("🧹 Cleaning up")
print("=" * 60)

# Close the agent (releases HTTP connections, subprocesses, etc.)
agent.close()
resumed_agent.close()

# Close the database connection
session_db.close()

print("✅ Done! All resources cleaned up.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import re
import sqlite3
from typing import Any, Dict, List, Optional

# Assume the Hermes SessionDB class exists with SCHEMA_SQL, _execute_write, etc.
# We'll show only the additions/modifications.

SCHEMA_SQL = """
-- (Original schema...)
CREATE TABLE IF NOT EXISTS session_tags (
    session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    tag TEXT NOT NULL,
    PRIMARY KEY (session_id, tag)
);
CREATE INDEX IF NOT EXISTS idx_session_tags_tag ON session_tags(tag);
"""

# In SessionDB.__init__ or _init_schema, add migration:

SCHEMA_VERSION = 12  # bumped from previous

def _init_schema(self):
    # ... existing code ...
    conn = self._get_conn()
    user_version = conn.execute("PRAGMA user_version").fetchone()[0]
    if user_version < 12:
        # Create session_tags and migrate old titles as tags
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS session_tags (
                session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
                tag TEXT NOT NULL,
                PRIMARY KEY (session_id, tag)
            );
            CREATE INDEX IF NOT EXISTS idx_session_tags_tag ON session_tags(tag);
        """)
        # Backfill tags from existing session titles
        sessions = conn.execute("SELECT id, title FROM sessions WHERE title IS NOT NULL").fetchall()
        for sid, title in sessions:
            tag = self._sanitize_tag(title)
            conn.execute("INSERT OR IGNORE INTO session_tags (session_id, tag) VALUES (?, ?)", (sid, tag))
        conn.execute("PRAGMA user_version = 12")
    conn.close()

def _sanitize_tag(self, tag: str) -> str:
    """Lowercase, keep alphanumeric and hyphens, max 50 chars."""
    sanitized = re.sub(r'[^a-z0-9-]', '', tag.lower())
    return sanitized[:50]

# Thread-safe write method: use existing _execute_write() for writes

def add_session_tag(self, session_id: str, tag: str) -> bool:
    """Add a tag to a session. Returns True if new, False if already exists."""
    tag = self._sanitize_tag(tag)
    def _do(conn):
        cursor = conn.execute(
            "INSERT OR IGNORE INTO session_tags (session_id, tag) VALUES (?, ?)",
            (session_id, tag)
        )
        return cursor.rowcount > 0
    return self._execute_write(_do)

def remove_session_tag(self, session_id: str, tag: str) -> bool:
    """Remove a tag from a session. Returns True if existed."""
    tag = self._sanitize_tag(tag)
    def _do(conn):
        cursor = conn.execute(
            "DELETE FROM session_tags WHERE session_id = ? AND tag = ?",
            (session_id, tag)
        )
        return cursor.rowcount > 0
    return self._execute_write(_do)

def get_session_tags(self, session_id: str) -> List[str]:
    """Return all tags for a session."""
    with self._lock:
        conn = self._get_conn()
        rows = conn.execute(
            "SELECT tag FROM session_tags WHERE session_id = ?", (session_id,)
        ).fetchall()
        return [row[0] for row in rows]

def search_sessions_by_tag(self, tag: str, limit: int = 20, offset: int = 0) -> List[Dict[str, Any]]:
    """Return sessions that have the given tag, with full details like list_sessions_rich."""
    tag = self._sanitize_tag(tag)
    with self._lock:
        conn = self._get_conn()
        query = """
            SELECT s.id, s.title, s.source, s.created_at, s.updated_at,
                   (SELECT COUNT(*) FROM messages WHERE session_id = s.id) as message_count,
                   (SELECT content FROM messages WHERE session_id = s.id ORDER BY timestamp DESC LIMIT 1) as last_message,
                   s.updated_at as last_active
            FROM sessions s
            INNER JOIN session_tags st ON s.id = st.session_id
            WHERE st.tag = ?
            ORDER BY s.updated_at DESC
            LIMIT ? OFFSET ?
        """
        rows = conn.execute(query, (tag, limit, offset)).fetchall()
        return [dict(row) for row in rows]

def list_sessions_rich(self, tags: Optional[List[str]] = None, **kwargs):
    """Override or modify existing method to support tag filtering."""
    # Use the existing base implementation, but add tag filter via subquery
    if tags:
        # Sanitize tags
        clean_tags = [self._sanitize_tag(t) for t in tags]
        placeholders = ','.join(['?'] * len(clean_tags))
        subquery = f"""
            AND s.id IN (
                SELECT session_id FROM session_tags
                WHERE tag IN ({placeholders})
                GROUP BY session_id
                HAVING COUNT(DISTINCT tag) = ?
            )
        """
        # This subquery would be inserted into the WHERE clause of the original list_sessions_rich query.
        # For brevity, we assume the original method constructs the SQL and accepts additional conditions.
        # In practice, pass the subquery string to the original method.
        pass  # Implementation detail depends on original code

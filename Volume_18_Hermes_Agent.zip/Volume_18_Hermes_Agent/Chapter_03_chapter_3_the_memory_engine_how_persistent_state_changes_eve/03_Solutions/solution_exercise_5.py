
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import json
import os
import time
from typing import Any, Dict, List, Optional

class AdaptiveMemoryProvider(MemoryProvider):
    """Memory provider with adaptive value based on usage outcomes."""
    
    def __init__(self):
        self.db_path = os.path.expanduser("~/.hermes/adaptive_memory.json")
        self.archive_path = os.path.expanduser("~/.hermes/archived_memories.json")
        self.memories: Dict[str, Dict] = {}  # key -> memory dict with value, usage_history, archived=False
        self.archived: Dict[str, Dict] = {}  # key -> archived memory dict (plus archived_at)
        self._session_access: Dict[str, List[str]] = {}  # session_id -> list of memory keys accessed
        self._load()
    
    def _load(self):
        for path, target in [(self.db_path, 'memories'), (self.archive_path, 'archived')]:
            if os.path.exists(path):
                with open(path, 'r') as f:
                    setattr(self, target, json.load(f))
            else:
                setattr(self, target, {})
    
    def _save(self):
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        with open(self.db_path, 'w') as f:
            json.dump(self.memories, f, indent=2)
        with open(self.archive_path, 'w') as f:
            json.dump(self.archived, f, indent=2)
    
    def initialize(self, **kwargs):
        self._load()
        return True
    
    def prefetch(self):
        # Clear session access log at start of turn (but keep for the session)
        # We'll accumulate access in the session; clear after conversation end? 
        # For simplicity, we keep _session_access across turns but reset on initialize.
        # Actually, we should manage per session: we store the session_id and accumulate.
        # We'll assume _session_access is populated by handle_tool_call and prefetch.
        # No decay here; value is based on outcomes.
        pass
    
    def sync_turn(self, messages):
        return messages
    
    def system_prompt_block(self):
        return "You have access to adaptive memory. Use `decay_memory_query` and `archive_search`."
    
    def get_tool_schemas(self):
        return [
            {
                "type": "function",
                "function": {
                    "name": "decay_memory_query",
                    "description": "Search active memories. Updates last_accessed.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "query": {"type": "string"}
                        },
                        "required": ["query"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "archive_search",
                    "description": "Search archived memories. Optionally restore a single memory.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "query": {"type": "string"},
                            "restore": {"type": "boolean", "description": "Set to true to restore the first matching archived memory."}
                        },
                        "required": ["query"]
                    }
                }
            }
        ]
    
    def handle_tool_call(self, tool_call):
        args = json.loads(tool_call.get("arguments", "{}"))
        tool_name = tool_call.get("function", {}).get("name")
        if tool_name == "decay_memory_query":
            return self._handle_decay_query(args)
        elif tool_name == "archive_search":
            return self._handle_archive_search(args)
        return "Unknown tool"
    
    def _handle_decay_query(self, args):
        query = args.get("query", "").lower()
        results = []
        for key, entry in self.memories.items():
            if query in key.lower() and entry.get('strength', 1.0) >= 0.0:  # always active if not archived
                entry['last_accessed'] = time.time()
                results.append(entry)
                # Track access for this session
                session_id = self._current_session_id  # Need to set this externally
                if session_id:
                    self._session_access.setdefault(session_id, []).append(key)
        self._save()
        return json.dumps({"memories": results})
    
    def _handle_archive_search(self, args):
        query = args.get("query", "").lower()
        restore = args.get("restore", False)
        matches = [v for k, v in self.archived.items() if query in k.lower() or query in v.get('content','').lower()]
        if restore and len(matches) == 1:
            # Restore: move from archived to active
            key = [k for k, v in self.archived.items() if v == matches[0]][0]
            entry = self.archived.pop(key)
            entry['value'] = 0.0  # reset value
            entry['strength'] = 1.0
            self.memories[key] = entry
            self._save()
            return f"Restored memory: {key}"
        elif matches:
            summary = f"Found {len(matches)} archived memories matching '{query}'. "
            if len(matches) == 1:
                summary += "To restore, call again with restore=True."
            return summary
        else:
            return "No archived memories found."
    
    def on_conversation_end(self, result: Dict):
        """Called by AIAgent when conversation ends. Updates memory values."""
        session_id = result.get('session_id')
        outcome = 'success' if result.get('completed') and not result.get('interrupted') else \
                  'interrupted' if result.get('interrupted') else 'negative_feedback'
        # For simplicity, map negative feedback if provided
        if result.get('feedback') == 'negative':
            outcome = 'negative_feedback'
        accessed_keys = self._session_access.pop(session_id, [])
        for key in accessed_keys:
            if key not in self.memories:
                continue
            entry = self.memories[key]
            # Update value
            if outcome == 'success':
                entry['value'] = min(1.0, entry.get('value', 0.0) + 0.1)
            elif outcome == 'interrupted':
                entry['value'] = max(-1.0, entry.get('value', 0.0) - 0.2)
            elif outcome == 'negative_feedback':
                entry['value'] = max(-1.0, entry.get('value', 0.0) - 0.5)
            # Clamp
            entry['value'] = max(-1.0, min(1.0, entry['value']))
            # Archive if value below -0.5
            if entry['value'] < -0.5:
                self._archive_memory(key)
            # Record usage history
            hist = entry.setdefault('usage_history', [])
            hist.append({'session_id': session_id, 'outcome': outcome})
        self._save()
    
    def _archive_memory(self, key):
        entry = self.memories.pop(key)
        entry['archived_at'] = time.time()
        self.archived[key] = entry
    
    def shutdown(self):
        self._save()

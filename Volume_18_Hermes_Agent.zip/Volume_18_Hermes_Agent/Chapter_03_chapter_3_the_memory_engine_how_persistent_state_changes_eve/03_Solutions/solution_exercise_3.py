
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import json
import os
import re
import sqlite3
from typing import Any, Dict, List, Optional
from datetime import datetime

class PatternLearningDB:
    """Manages learned coding patterns in a dedicated SQLite database."""
    
    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path or os.path.expanduser("~/.hermes/learned_patterns.db")
        self._init_db()
    
    def _init_db(self):
        conn = sqlite3.connect(self.db_path)
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS patterns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pattern_type TEXT NOT NULL,
                title TEXT NOT NULL UNIQUE,
                description TEXT NOT NULL,
                code_snippet TEXT,
                source_file TEXT,
                confidence REAL DEFAULT 0.5,
                times_observed INTEGER DEFAULT 1,
                created_at REAL,
                last_observed_at REAL
            );
            CREATE TABLE IF NOT EXISTS pattern_observations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pattern_id INTEGER REFERENCES patterns(id),
                session_id TEXT NOT NULL,
                message_index INTEGER,
                observed_at REAL
            );
        """)
        conn.commit()
        conn.close()
    
    def _get_conn(self):
        return sqlite3.connect(self.db_path)
    
    def add_or_update_pattern(self, pattern_type: str, title: str, description: str,
                              code_snippet: Optional[str] = None,
                              source_file: Optional[str] = None) -> int:
        """Upsert pattern, returning its ID."""
        with self._get_conn() as conn:
            now = time.time()
            row = conn.execute("SELECT id, times_observed, confidence FROM patterns WHERE title = ?", (title,)).fetchone()
            if row:
                pattern_id, old_times, old_conf = row
                new_times = old_times + 1
                new_conf = min(1.0, old_conf + 0.1 * (new_times - old_times))
                conn.execute("""
                    UPDATE patterns SET 
                       times_observed = ?, confidence = ?, last_observed_at = ?, 
                       description = ?, code_snippet = ?, source_file = ?
                    WHERE id = ?
                """, (new_times, new_conf, now, description, code_snippet, source_file, pattern_id))
            else:
                conn.execute("""
                    INSERT INTO patterns (pattern_type, title, description, code_snippet, source_file, confidence, times_observed, created_at, last_observed_at)
                    VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)
                """, (pattern_type, title, description, code_snippet, source_file, 0.5, now, now))
                pattern_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
            return pattern_id
    
    def get_patterns_by_type(self, pattern_type: str) -> List[Dict]:
        with self._get_conn() as conn:
            rows = conn.execute("SELECT * FROM patterns WHERE pattern_type = ?", (pattern_type,)).fetchall()
            return [dict(row) for row in rows]
    
    def get_high_confidence_patterns(self, min_confidence: float = 0.7) -> List[Dict]:
        with self._get_conn() as conn:
            rows = conn.execute("SELECT * FROM patterns WHERE confidence >= ?", (min_confidence,)).fetchall()
            return [dict(row) for row in rows]
    
    def record_observation(self, pattern_id: int, session_id: str, message_index: int):
        with self._get_conn() as conn:
            conn.execute("INSERT INTO pattern_observations (pattern_id, session_id, message_index, observed_at) VALUES (?, ?, ?, ?)",
                         (pattern_id, session_id, message_index, time.time()))
            conn.commit()
    
    def search_patterns(self, query: str, limit: int = 10) -> List[Dict]:
        """Search patterns by title or description using LIKE."""
        with self._get_conn() as conn:
            rows = conn.execute("""
                SELECT * FROM patterns
                WHERE title LIKE ? OR description LIKE ?
                ORDER BY confidence DESC
                LIMIT ?
            """, (f'%{query}%', f'%{query}%', limit)).fetchall()
            return [dict(row) for row in rows]


# Integration into AIAgent (partial modifications)
class AIAgent:
    def __init__(self, ..., pattern_db: Optional[PatternLearningDB] = None):
        # ... existing init ...
        self.pattern_db = pattern_db or None  # Lazy init on first use
        self._pattern_db_initialized = False

    def _get_pattern_db(self) -> PatternLearningDB:
        if not self._pattern_db_initialized:
            self.pattern_db = PatternLearningDB()  # Creates default path
            self._pattern_db_initialized = True
        return self.pattern_db

    def _extract_and_learn_patterns(self, messages: List[Dict]):
        """Analyze conversation messages for code patterns."""
        pattern_db = self._get_pattern_db()
        for i, msg in enumerate(messages):
            if msg.get('role') == 'assistant':
                content = msg.get('content', '')
                # Check for code blocks or tool calls indicating code context
                if '

#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import json
import sqlite3
import time
from typing import Any, Callable, Dict, List, Optional
from functools import wraps

# Modifications to SessionDB class

SCHEMA_SQL = """
-- ... existing tables ...
CREATE TABLE IF NOT EXISTS write_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT,
    operation TEXT NOT NULL,
    table_name TEXT NOT NULL,
    row_id INTEGER,
    old_values TEXT,
    new_values TEXT,
    status TEXT DEFAULT 'pending',
    created_at REAL,
    committed_at REAL
);
"""
SCHEMA_VERSION = 13  # new version

class SessionDB:
    def __init__(self, ...):
        # ... existing init ...
        self._recover_from_write_log()
    
    def _init_schema(self):
        # ... existing schema creation ...
        # migration to add write_log table
        conn = self._get_conn()
        user_version = conn.execute("PRAGMA user_version").fetchone()[0]
        if user_version < 13:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS write_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT,
                    operation TEXT NOT NULL,
                    table_name TEXT NOT NULL,
                    row_id INTEGER,
                    old_values TEXT,
                    new_values TEXT,
                    status TEXT DEFAULT 'pending',
                    created_at REAL,
                    committed_at REAL
                );
            """)
            conn.execute("PRAGMA user_version = 13")
        conn.close()
    
    def _recover_from_write_log(self):
        """On startup, roll back any pending log entries from a crash."""
        conn = self._get_conn()
        pending = conn.execute("SELECT * FROM write_log WHERE status='pending'").fetchall()
        for entry in pending:
            log_id = entry['id']
            try:
                self._rollback_write_log(log_id)
                conn.execute("UPDATE write_log SET status='rolled_back' WHERE id=?", (log_id,))
            except Exception as e:
                # If rollback fails, mark as rolled back anyway and log warning
                print(f"Warning: write log rollback failed for id {log_id}: {e}")
                conn.execute("UPDATE write_log SET status='rolled_back' WHERE id=?", (log_id,))
        # Clean up old rolled_back entries (>7 days)
        cutoff = time.time() - 7*86400
        conn.execute("DELETE FROM write_log WHERE status='rolled_back' AND created_at < ?", (cutoff,))
        conn.commit()
        conn.close()
    
    def _rollback_write_log(self, log_id: int):
        """Perform rollback based on log entry."""
        conn = self._get_conn()
        entry = conn.execute("SELECT * FROM write_log WHERE id=?", (log_id,)).fetchone()
        if not entry:
            return
        table = entry['table_name']
        row_id = entry['row_id']
        old_values = json.loads(entry['old_values']) if entry['old_values'] else None
        operation = entry['operation']
        
        if operation == 'insert':
            conn.execute(f"DELETE FROM {table} WHERE id = ?", (row_id,))
        elif operation == 'update':
            if old_values:
                set_clause = ', '.join(f"{col}=?" for col in old_values.keys())
                values = list(old_values.values()) + [row_id]
                conn.execute(f"UPDATE {table} SET {set_clause} WHERE id = ?", values)
        elif operation == 'delete':
            if old_values:
                cols = ', '.join(old_values.keys())
                placeholders = ', '.join(['?'] * len(old_values))
                values = list(old_values.values())
                conn.execute(f"INSERT INTO {table} ({cols}) VALUES ({placeholders})", values)
        # For compound operation like 'replace_messages', handle specially
        elif operation == 'replace_messages':
            # old_values contains JSON array of old message dicts
            # first delete inserted new messages, then re-insert old ones
            # (simplified: assume new_values holds new message IDs)
            new_values = json.loads(entry['new_values']) if entry['new_values'] else []
            for msg_id in new_values:
                conn.execute("DELETE FROM messages WHERE id = ?", (msg_id,))
            for old_msg in (old_values or []):
                cols = ', '.join(old_msg.keys())
                placeholders = ', '.join(['?'] * len(old_msg))
                values = list(old_msg.values())
                conn.execute(f"INSERT INTO messages ({cols}) VALUES ({placeholders})", values)
        conn.commit()
        conn.close()
    
    def _execute_write_with_wal(self, fn: Callable, operation: str, table: str, session_id: str, 
                                 row_id: Optional[int] = None,
                                 old_values_getter: Optional[Callable] = None,
                                 new_values_getter: Optional[Callable] = None):
        """
        Wraps a write operation with WAL logging.
        fn is called inside a transaction after logging the intended change.
        """
        conn = self._get_conn()
        try:
            conn.execute("BEGIN IMMEDIATE")
            # Log the operation
            now = time.time()
            old_vals = old_values_getter(conn) if old_values_getter else None
            new_vals = new_values_getter(conn) if new_values_getter else None
            log_id = conn.execute(
                """INSERT INTO write_log (session_id, operation, table_name, row_id, old_values, new_values, status, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)""",
                (session_id, operation, table, row_id, json.dumps(old_vals) if old_vals else None,
                 json.dumps(new_vals) if new_vals else None, now)
            ).lastrowid
            
            # Execute the user's write function
            result = fn(conn)
            
            # Mark committed
            conn.execute("UPDATE write_log SET status='committed', committed_at=? WHERE id=?",
                         (time.time(), log_id))
            conn.commit()
            return result
        except Exception as e:
            conn.rollback()
            # Attempt to rollback the log entry manually (since we are outside transaction,
            # we must do in a new connection)
            try:
                self._rollback_write_log(log_id)
                with self._get_conn() as rollback_conn:
                    rollback_conn.execute("UPDATE write_log SET status='rolled_back' WHERE id=?", (log_id,))
                    rollback_conn.commit()
            except:
                pass
            raise e
        finally:
            conn.close()
    
    # Override _execute_write to use the WAL version
    def _execute_write(self, fn: Callable, *args, **kwargs):
        # We need to modify the interface slightly; this is a simplified version.
        # In practice, refactor to pass operation info.
        # For exercise, we show the pattern:
        return self._execute_write_with_wal(
            fn,
            operation='custom',
            table='messages',  # placeholder
            session_id=kwargs.get('session_id', ''),
            old_values_getter=None,
            new_values_getter=None
        )
    
    # Example for append_message
    def append_message(self, session_id: str, message: Dict):
        def _do(conn):
            # Existing logic to insert message and update count
            cursor = conn.execute(
                "INSERT INTO messages (...) VALUES (...)", ...
            )
            msg_id = cursor.lastrowid
            conn.execute("UPDATE sessions SET message_count = message_count + 1 WHERE id = ?", (session_id,))
            return msg_id
        
        # Wrapper to capture old/new state for logging
        def old_values_getter(conn):
            # For insert, old_values is None
            return None
        def new_values_getter(conn):
            # Return the new message dict for rollback
            return {'row': message}
        return self._execute_write_with_wal(
            _do,
            operation='insert_message',
            table='messages',
            session_id=session_id,
            row_id=None,
            old_values_getter=old_values_getter,
            new_values_getter=new_values_getter
        )

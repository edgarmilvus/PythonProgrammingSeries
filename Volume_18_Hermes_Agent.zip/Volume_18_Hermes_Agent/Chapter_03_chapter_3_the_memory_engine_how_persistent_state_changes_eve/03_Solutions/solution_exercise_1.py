
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import json
import math
import os
import time
from typing import Any, Dict, List, Optional

from agent.memory_provider import MemoryProvider  # Hermes base class

class DecayingMemoryProvider(MemoryProvider):
    """Memory provider with time-based strength decay."""
    
    def __init__(self):
        self.db_path = os.path.expanduser("~/.hermes/decay_memory.json")
        self.memories: Dict[str, Dict] = {}  # key -> memo dict
        self.decay_factor: float = 0.95
        self.decay_threshold: float = 0.2
        self._load()
    
    def _load(self):
        """Load memories from JSON file."""
        if os.path.exists(self.db_path):
            with open(self.db_path, 'r') as f:
                self.memories = json.load(f)
        else:
            self.memories = {}
    
    def _save(self):
        """Persist memories to JSON file."""
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        with open(self.db_path, 'w') as f:
            json.dump(self.memories, f, indent=2)
    
    def initialize(self, **kwargs):
        """Initialize with optional decay_factor and decay_threshold."""
        self.decay_factor = kwargs.get('decay_factor', 0.95)
        self.decay_threshold = kwargs.get('decay_threshold', 0.2)
        self._load()
        return True
    
    def prefetch(self):
        """Run decay on all entries, removing those below threshold."""
        now = time.time()
        to_delete = []
        for key, entry in self.memories.items():
            days_since = (now - entry['last_accessed']) / 86400.0
            entry['strength'] *= (self.decay_factor ** days_since)
            entry['last_accessed'] = now  # update to now for consistency
            if entry['strength'] < self.decay_threshold:
                to_delete.append(key)
        for key in to_delete:
            del self.memories[key]
        self._save()
        return None
    
    def sync_turn(self, messages: List[Dict]) -> List[Dict]:
        """No additional synchronization needed."""
        return messages
    
    def system_prompt_block(self) -> str:
        """Return system prompt instructions for using decaying memory."""
        return "You have access to decaying memory. Use `decay_memory_query` to search past interactions."
    
    def get_tool_schemas(self) -> List[Dict]:
        """Define the decay_memory_query tool."""
        return [{
            "type": "function",
            "function": {
                "name": "decay_memory_query",
                "description": "Search through memories that have not decayed below threshold.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search query to match against memory keys."
                        }
                    },
                    "required": ["query"]
                }
            }
        }]
    
    def handle_tool_call(self, tool_call: Dict) -> str:
        """Process decay_memory_query tool call."""
        args = json.loads(tool_call.get("arguments", "{}"))
        query = args.get("query", "").lower()
        results = []
        now = time.time()
        for key, entry in self.memories.items():
            if query in key.lower() and entry['strength'] >= self.decay_threshold:
                entry['last_accessed'] = now
                results.append(entry)
        self._save()
        return json.dumps({"memories": results}, indent=2)
    
    def shutdown(self):
        """Save any pending state."""
        self._save()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_16.py
# Description: Solution for Exercise 16
# ==========================================

# tools/registry.py - Modified dispatch with rate limiting
from typing import Optional
import json
from .rate_limiter import RateLimiter

class ToolRegistry:
    def __init__(self, config: dict):
        self.config = config
        self.tools = {}
        self.rate_limiter = RateLimiter()
        self.turn_cache = TurnCache()
        # ... rest of initialization ...
    
    def _get_tool_rate_limit(self, tool_name: str) -> Optional[int]:
        """
        Get the rate limit for a tool from its metadata.
        
        Args:
            tool_name: Name of the tool
        
        Returns:
            Rate limit per minute, or None if not set
        """
        tool_def = self.tools.get(tool_name)
        if tool_def and hasattr(tool_def, 'metadata'):
            return tool_def.metadata.get('rate_limit')
        return None
    
    def dispatch(self, tool_name: str, args: dict) -> str:
        """
        Dispatch a tool call with rate limiting.
        
        Args:
            tool_name: Name of the tool to call
            args: Dictionary of arguments
        
        Returns:
            JSON string result
        """
        # Get tool definition
        tool_def = self.tools.get(tool_name)
        if not tool_def:
            return json.dumps({"error": f"Tool '{tool_name}' not found"})
        
        # Check rate limit for MCP tools
        if tool_def.source == "mcp":
            rate_limit = self._get_tool_rate_limit(tool_name)
            if rate_limit is not None:
                if not self.rate_limiter.check(tool_name, rate_limit):
                    return json.dumps({
                        "error": f"Rate limit exceeded for tool {tool_name}. Try again later."
                    })
        
        # Check cache for MCP tools
        if tool_def.source == "mcp":
            cached_result = self.turn_cache.get(tool_name, args)
            if cached_result is not None:
                result = json.loads(cached_result)
                result["cached"] = True
                return json.dumps(result)
        
        # Execute the tool
        if tool_def.source == "mcp":
            result = self._call_mcp_tool(tool_name, args)
            
            # Handle 429 responses
            try:
                result_dict = json.loads(result)
                if result_dict.get("status") == 429:
                    retry_after = result_dict.get("retry_after", 0)
                    self.rate_limiter.record(tool_name, skip_seconds=retry_after)
                else:
                    self.rate_limiter.record(tool_name)
            except json.JSONDecodeError:
                self.rate_limiter.record(tool_name)
            
            # Cache the result
            self.turn_cache.set(tool_name, args, result)
        else:
            result = self._call_builtin_tool(tool_name, args)
        
        return result


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# tools/registry.py - Modified to include MCP tool discovery
from typing import Dict, List, Optional, Set
import json
import asyncio
from .toolsets import get_toolset, validate_toolset
from .model_tools import ToolDefinition

class ToolRegistry:
    def __init__(self, config: dict):
        self.config = config
        self.tools: Dict[str, ToolDefinition] = {}
        self.mcp_servers: Dict[str, dict] = config.get("mcp_servers", {})
        self.mcp_clients: Dict[str, any] = {}
        
    def discover_builtin_tools(self):
        """Discover built-in tools (existing method)"""
        # Existing implementation that discovers tools from built-in modules
        pass
    
    def discover_mcp_tools(self):
        """Discover tools from configured MCP servers"""
        for server_name, server_config in self.mcp_servers.items():
            try:
                # Initialize MCP client for this server
                mcp_client = self._create_mcp_client(server_config)
                self.mcp_clients[server_name] = mcp_client
                
                # Fetch available tools from the MCP server
                tools = asyncio.run(mcp_client.list_tools())
                
                # Register each tool with the registry
                for tool in tools:
                    # Create a ToolDefinition from the MCP tool schema
                    tool_def = ToolDefinition(
                        name=tool.name,
                        description=tool.description,
                        parameters=tool.input_schema,
                        source="mcp",
                        server_name=server_name
                    )
                    self.tools[tool.name] = tool_def
                    
            except Exception as e:
                print(f"Warning: Failed to discover tools from MCP server '{server_name}': {e}")
    
    def get_tool_definitions(self, enabled_toolsets: Set[str] = None, 
                           disabled_toolsets: Set[str] = None) -> List[ToolDefinition]:
        """Get tool definitions with filtering"""
        # First, discover all tools if not already done
        if not self.tools:
            self.discover_builtin_tools()
            self.discover_mcp_tools()
        
        # Apply toolset filtering
        filtered_tools = []
        for tool_name, tool_def in self.tools.items():
            # Check if tool belongs to an enabled toolset
            if enabled_toolsets and tool_def.toolset not in enabled_toolsets:
                continue
            # Check if tool belongs to a disabled toolset
            if disabled_toolsets and tool_def.toolset in disabled_toolsets:
                continue
            filtered_tools.append(tool_def)
        
        return filtered_tools
    
    def get_all_tool_names(self) -> List[str]:
        """Get all registered tool names"""
        if not self.tools:
            self.discover_builtin_tools()
            self.discover_mcp_tools()
        return list(self.tools.keys())
    
    def _create_mcp_client(self, server_config: dict):
        """Create an MCP client based on server configuration"""
        # Implementation depends on MCP client library being used
        # This would typically use the mcp Python library
        from mcp.client import MCPClient
        
        if "command" in server_config:
            # stdio transport
            return MCPClient.stdio(
                server_config["command"],
                server_config.get("args", [])
            )
        elif "url" in server_config:
            # HTTP transport
            return MCPClient.http(server_config["url"])
        else:
            raise ValueError(f"Invalid MCP server configuration: {server_config}")

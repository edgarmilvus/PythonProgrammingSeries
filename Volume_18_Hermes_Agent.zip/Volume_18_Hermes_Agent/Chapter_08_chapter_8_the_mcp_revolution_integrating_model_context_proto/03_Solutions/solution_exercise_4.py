
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# tests/test_mcp_integration.py
import pytest
from unittest.mock import Mock, patch
from tools.registry import ToolRegistry
from tools.toolsets import get_all_tool_names

class TestMCPIntegration:
    def test_kb_query_tool_discovery(self):
        """Test that kb_query tool appears after MCP server configuration"""
        # Mock configuration with MCP server
        config = {
            "mcp_servers": {
                "knowledge": {
                    "command": "python",
                    "args": ["mcp_servers/knowledge_server.py"]
                }
            }
        }
        
        # Mock the MCP client to return a predefined tool
        mock_tool = Mock()
        mock_tool.name = "kb_query"
        mock_tool.description = "Query the knowledge base"
        mock_tool.input_schema = {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
                "max_results": {"type": "integer", "default": 5}
            },
            "required": ["query"]
        }
        
        with patch('tools.registry.ToolRegistry._create_mcp_client') as mock_create:
            mock_client = Mock()
            mock_client.list_tools.return_value = [mock_tool]
            mock_create.return_value = mock_client
            
            registry = ToolRegistry(config)
            tool_names = registry.get_all_tool_names()
            
            assert "kb_query" in tool_names
    
    def test_handle_function_call(self):
        """Test that handle_function_call returns expected JSON-RPC response"""
        # Mock the MCP transport
        mock_transport = Mock()
        mock_transport.call_tool.return_value = {
            "jsonrpc": "2.0",
            "result": {
                "documents": [
                    {"id": 1, "title": "Test Document", "content": "Test content"}
                ]
            },
            "id": 1
        }
        
        # Simulate a function call to kb_query
        result = mock_transport.call_tool("kb_query", {
            "query": "test query",
            "max_results": 3
        })
        
        # Verify the response structure
        assert result["jsonrpc"] == "2.0"
        assert "result" in result
        assert "documents" in result["result"]
        assert len(result["result"]["documents"]) == 1
        assert result["result"]["documents"][0]["title"] == "Test Document"


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# tools/cache.py
import threading
import json
from typing import Optional, Dict, Tuple

class TurnCache:
    """
    Thread-safe cache for MCP tool responses that lives for one turn.
    """
    
    def __init__(self):
        self._cache: Dict[str, str] = {}
        self._lock = threading.Lock()
    
    def _make_key(self, tool_name: str, args: dict) -> str:
        """
        Create a cache key from tool name and sorted JSON arguments.
        
        Args:
            tool_name: Name of the tool being called
            args: Dictionary of arguments passed to the tool
        
        Returns:
            A hashable string key
        """
        # Sort the arguments to ensure consistent key generation
        sorted_args = json.dumps(args, sort_keys=True)
        return f"{tool_name}:{sorted_args}"
    
    def get(self, tool_name: str, args: dict) -> Optional[str]:
        """
        Get cached result for a tool call.
        
        Args:
            tool_name: Name of the tool
            args: Dictionary of arguments
        
        Returns:
            Cached result string if found, None otherwise
        """
        key = self._make_key(tool_name, args)
        with self._lock:
            return self._cache.get(key)
    
    def set(self, tool_name: str, args: dict, result: str) -> None:
        """
        Cache a tool call result.
        
        Args:
            tool_name: Name of the tool
            args: Dictionary of arguments
            result: The result string to cache
        """
        key = self._make_key(tool_name, args)
        with self._lock:
            self._cache[key] = result
    
    def clear(self) -> None:
        """Clear all cached entries (called at turn start)."""
        with self._lock:
            self._cache.clear()

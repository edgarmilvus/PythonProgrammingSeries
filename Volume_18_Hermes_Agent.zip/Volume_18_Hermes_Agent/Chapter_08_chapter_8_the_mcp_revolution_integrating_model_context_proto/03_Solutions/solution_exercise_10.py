
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_10.py
# Description: Solution for Exercise 10
# ==========================================

# model_tools.py - Modified handle_function_call with logging
import time
import json
from typing import Optional
from .session_db import SessionDB

class ModelTools:
    def __init__(self, session_db: Optional[SessionDB] = None):
        self.session_db = session_db
        self.current_session_id = None
    
    def handle_function_call(self, tool_name: str, args: dict, 
                            session_id: Optional[str] = None) -> str:
        """
        Handle a function call from the model, with logging.
        
        Args:
            tool_name: Name of the tool to call
            args: Dictionary of arguments
            session_id: Current session ID for logging
        
        Returns:
            JSON string result
        """
        start_time = time.time()
        success = True
        result = ""
        
        try:
            # Execute the tool call
            result = self._execute_tool(tool_name, args)
            
        except Exception as e:
            # Handle failures
            result = json.dumps({"error": str(e)})
            success = False
        
        finally:
            # Calculate duration
            duration_ms = int((time.time() - start_time) * 1000)
            
            # Log the call if we have a session database
            if self.session_db and (session_id or self.current_session_id):
                actual_session_id = session_id or self.current_session_id
                self.session_db.log_tool_call(
                    session_id=actual_session_id,
                    tool_name=tool_name,
                    serialised_args=json.dumps(args),
                    result=result,
                    duration_ms=duration_ms,
                    success=success
                )
        
        return result

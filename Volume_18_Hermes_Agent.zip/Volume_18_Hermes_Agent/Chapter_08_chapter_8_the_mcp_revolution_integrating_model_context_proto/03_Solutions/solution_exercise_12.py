
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_12.py
# Description: Solution for Exercise 12
# ==========================================

# tools/toolsets.py - Modified with composite toolset support
from typing import Dict, List, Set, Optional
import requests
import logging

logger = logging.getLogger(__name__)

# Define the composite toolset
TOOLSETS = {
    # ... existing toolsets ...
    
    "customer_support": {
        "description": "Composite toolset for customer support operations",
        "includes": ["slack", "jira", "crm", "web_search", "memory"],
        "tools": [],  # Tools will be inherited from included toolsets
        "min_mcp_servers": 2  # Minimum number of MCP servers required
    }
}

# MCP server health check endpoints
MCP_SERVER_HEALTH = {
    "slack": "http://slack-mcp.internal:8000/health",
    "jira": "http://jira-mcp.internal:8000/health",
    "crm": "http://hubspot-mcp.internal:8000/health"
}

def check_toolset_availability(toolset_name: str) -> bool:
    """
    Check if a composite toolset is available based on MCP server health.
    
    Args:
        toolset_name: Name of the toolset to check
    
    Returns:
        True if the toolset should be available, False otherwise
    """
    toolset_config = TOOLSETS.get(toolset_name)
    if not toolset_config or "min_mcp_servers" not in toolset_config:
        return True  # Non-composite toolsets are always available
    
    # Count available MCP servers from the included toolsets
    available_servers = 0
    required_servers = toolset_config["min_mcp_servers"]
    
    for included_toolset in toolset_config.get("includes", []):
        if included_toolset in MCP_SERVER_HEALTH:
            try:
                response = requests.get(
                    MCP_SERVER_HEALTH[included_toolset],
                    timeout=5
                )
                if response.status_code == 200:
                    available_servers += 1
            except (requests.RequestException, ConnectionError):
                logger.warning(f"MCP server '{included_toolset}' is unreachable")
    
    is_available = available_servers >= required_servers
    
    if not is_available:
        logger.warning(
            f"Toolset '{toolset_name}' unavailable "
            f"(only {available_servers}/{required_servers} MCP servers reachable)"
        )
    
    return is_available

def get_toolset(toolset_name: str) -> Optional[Dict]:
    """
    Get toolset configuration with availability check.
    
    Args:
        toolset_name: Name of the toolset
    
    Returns:
        Toolset configuration dict if available, None otherwise
    """
    if not check_toolset_availability(toolset_name):
        return None
    
    return TOOLSETS.get(toolset_name)

def get_available_toolsets() -> List[str]:
    """
    Get list of all available toolsets.
    
    Returns:
        List of available toolset names
    """
    available = []
    for toolset_name in TOOLSETS:
        if check_toolset_availability(toolset_name):
            available.append(toolset_name)
    return available

def resolve_toolset_tools(toolset_name: str, registry: 'ToolRegistry') -> List[str]:
    """
    Resolve all tools in a toolset, including inherited tools.
    
    Args:
        toolset_name: Name of the toolset
        registry: ToolRegistry instance to look up tools
    
    Returns:
        List of tool names in the toolset
    """
    toolset_config = get_toolset(toolset_name)
    if not toolset_config:
        return []
    
    tools = set(toolset_config.get("tools", []))
    
    # Include tools from referenced toolsets
    for included_toolset in toolset_config.get("includes", []):
        included_tools = resolve_toolset_tools(included_toolset, registry)
        tools.update(included_tools)
    
    return list(tools)

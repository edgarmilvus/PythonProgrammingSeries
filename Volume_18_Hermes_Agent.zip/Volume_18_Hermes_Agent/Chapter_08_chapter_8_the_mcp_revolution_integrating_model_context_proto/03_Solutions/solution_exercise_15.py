
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_15.py
# Description: Solution for Exercise 15
# ==========================================

# tools/rate_limiter.py
import time
from collections import deque, defaultdict
import threading
from typing import Dict, Deque

class RateLimiter:
    """
    Thread-safe rate limiter for MCP tools using rolling window.
    """
    
    def __init__(self):
        self._windows: Dict[str, Deque[float]] = defaultdict(deque)
        self._lock = threading.RLock()
        self._window_size = 60  # seconds
    
    def check(self, tool_name: str, limit: int) -> bool:
        """
        Check if a tool call is allowed under the rate limit.
        
        Args:
            tool_name: Name of the tool to check
            limit: Maximum number of calls allowed in the window
        
        Returns:
            True if the call is allowed, False if rate limited
        """
        with self._lock:
            window = self._windows[tool_name]
            now = time.time()
            
            # Remove expired timestamps
            while window and window[0] < now - self._window_size:
                window.popleft()
            
            # Check if we're under the limit
            return len(window) < limit
    
    def record(self, tool_name: str, skip_seconds: float = 0):
        """
        Record a tool call, optionally skipping time for retry-after.
        
        Args:
            tool_name: Name of the tool being called
            skip_seconds: Seconds to skip forward (for Retry-After headers)
        """
        with self._lock:
            window = self._windows[tool_name]
            now = time.time()
            
            if skip_seconds > 0:
                # Add a timestamp in the future to block calls
                window.append(now + skip_seconds)
            else:
                window.append(now)
    
    def clear(self):
        """Clear all rate limit data (for testing)."""
        with self._lock:
            self._windows.clear()

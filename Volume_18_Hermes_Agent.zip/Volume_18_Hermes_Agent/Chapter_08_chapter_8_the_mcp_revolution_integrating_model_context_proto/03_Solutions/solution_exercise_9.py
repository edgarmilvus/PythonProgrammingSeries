
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_9.py
# Description: Solution for Exercise 9
# ==========================================

# session_db.py - Modified SessionDB with mcp_tool_log table
import sqlite3
import json
from datetime import datetime
from typing import Dict, List, Optional

class SessionDB:
    def __init__(self, db_path: str = "agent_sessions.db"):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self._create_tables()
    
    def _create_tables(self):
        """Create all required tables."""
        cursor = self.conn.cursor()
        
        # Existing tables (conversations, etc.)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT,
                timestamp TEXT DEFAULT (datetime('now'))
            )
        """)
        
        # New table for MCP tool logging
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS mcp_tool_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                tool_name TEXT NOT NULL,
                serialised_args TEXT NOT NULL,
                result TEXT,
                duration_ms INTEGER NOT NULL,
                success BOOLEAN NOT NULL DEFAULT 1
            )
        """)
        
        # Create indexes for efficient querying
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_mcp_tool_log_session 
            ON mcp_tool_log(session_id)
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_mcp_tool_log_tool 
            ON mcp_tool_log(tool_name)
        """)
        
        self.conn.commit()
    
    def log_tool_call(self, session_id: str, tool_name: str, 
                     serialised_args: str, result: str, 
                     duration_ms: int, success: bool):
        """
        Log a tool call to the database.
        
        Args:
            session_id: Current session identifier
            tool_name: Name of the tool called
            serialised_args: JSON string of arguments
            result: Full result string
            duration_ms: Duration in milliseconds
            success: Whether the call succeeded
        """
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO mcp_tool_log 
            (session_id, timestamp, tool_name, serialised_args, result, duration_ms, success)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            session_id,
            datetime.utcnow().isoformat(),
            tool_name,
            serialised_args,
            result,
            duration_ms,
            success
        ))
        self.conn.commit()
    
    def get_log_stats(self) -> Dict:
        """
        Get summary statistics from the tool log.
        
        Returns:
            Dictionary with total_calls, avg_duration, success_rate, top_tools
        """
        cursor = self.conn.cursor()
        
        # Total calls
        cursor.execute("SELECT COUNT(*) FROM mcp_tool_log")
        total_calls = cursor.fetchone()[0]
        
        if total_calls == 0:
            return {
                "total_calls": 0,
                "avg_duration": 0,
                "success_rate": 0,
                "top_tools": []
            }
        
        # Average duration
        cursor.execute("SELECT AVG(duration_ms) FROM mcp_tool_log")
        avg_duration = cursor.fetchone()[0] or 0
        
        # Success rate
        cursor.execute("""
            SELECT SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(*)
            FROM mcp_tool_log
        """)
        success_rate = cursor.fetchone()[0] or 0
        
        # Top 10 most-called tools
        cursor.execute("""
            SELECT tool_name, COUNT(*) as call_count
            FROM mcp_tool_log
            GROUP BY tool_name
            ORDER BY call_count DESC
            LIMIT 10
        """)
        top_tools = [{"tool": row[0], "calls": row[1]} for row in cursor.fetchall()]
        
        return {
            "total_calls": total_calls,
            "avg_duration": round(avg_duration, 2),
            "success_rate": round(success_rate, 2),
            "top_tools": top_tools
        }

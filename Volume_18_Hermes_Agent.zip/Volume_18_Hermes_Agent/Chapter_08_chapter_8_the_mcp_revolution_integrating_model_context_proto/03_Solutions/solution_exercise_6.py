
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_6.py
# Description: Solution for Exercise 6
# ==========================================

# tools/registry.py - Modified ToolRegistry with cache integration
from typing import Optional
import json
from .cache import TurnCache

class ToolRegistry:
    def __init__(self, config: dict):
        self.config = config
        self.tools = {}
        self.turn_cache = TurnCache()  # New: thread-safe cache
        # ... rest of initialization ...
    
    def dispatch(self, tool_name: str, args: dict) -> str:
        """
        Dispatch a tool call, using cache for MCP tools.
        
        Args:
            tool_name: Name of the tool to call
            args: Dictionary of arguments
        
        Returns:
            JSON string result
        """
        # Get tool definition
        tool_def = self.tools.get(tool_name)
        if not tool_def:
            return json.dumps({"error": f"Tool '{tool_name}' not found"})
        
        # Check cache for MCP tools only
        if tool_def.source == "mcp":
            cached_result = self.turn_cache.get(tool_name, args)
            if cached_result is not None:
                # Append cache hit header
                result = json.loads(cached_result)
                result["cached"] = True
                return json.dumps(result)
        
        # Execute the tool (either built-in or MCP)
        if tool_def.source == "mcp":
            result = self._call_mcp_tool(tool_name, args)
            # Cache the result for MCP tools
            self.turn_cache.set(tool_name, args, result)
        else:
            result = self._call_builtin_tool(tool_name, args)
        
        return result
    
    def _call_mcp_tool(self, tool_name: str, args: dict) -> str:
        """Execute an MCP tool call through the transport layer."""
        # Implementation depends on the MCP transport being used
        pass
    
    def _call_builtin_tool(self, tool_name: str, args: dict) -> str:
        """Execute a built-in tool call."""
        # Existing implementation
        pass

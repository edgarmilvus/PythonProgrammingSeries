
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_17.py
# Description: Solution for Exercise 17
# ==========================================

# tools/mcp_discovery.py - Parse rate limit from MCP tool schema
def handle_mcp_tool_discovery(tool_schema: dict) -> dict:
    """
    Parse MCP tool discovery response and extract metadata.
    
    Args:
        tool_schema: Raw MCP tool schema from server
    
    Returns:
        Processed tool definition with metadata
    """
    tool_def = {
        "name": tool_schema.get("name"),
        "description": tool_schema.get("description", ""),
        "parameters": tool_schema.get("inputSchema", {}),
        "source": "mcp",
        "metadata": {}
    }
    
    # Extract rate limit from tool annotations or custom fields
    if "annotations" in tool_schema:
        annotations = tool_schema["annotations"]
        if "rate_limit" in annotations:
            tool_def["metadata"]["rate_limit"] = annotations["rate_limit"]
    
    # Alternative: extract from custom MCP extension
    if "x-rate-limit" in tool_schema:
        tool_def["metadata"]["rate_limit"] = tool_schema["x-rate-limit"]
    
    return tool_def

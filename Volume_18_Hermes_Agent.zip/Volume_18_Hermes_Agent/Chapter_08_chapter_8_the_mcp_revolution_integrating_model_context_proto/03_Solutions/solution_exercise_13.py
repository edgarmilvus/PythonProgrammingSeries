
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_13.py
# Description: Solution for Exercise 13
# ==========================================

# tools/registry.py - Modified to use toolset availability
class ToolRegistry:
    def __init__(self, config: dict):
        self.config = config
        self.tools = {}
        self.mcp_servers = config.get("mcp_servers", {})
        self.available_toolsets = set()
        
    def initialize(self):
        """Initialize the registry with tool discovery and availability checks."""
        # Discover all tools
        self.discover_builtin_tools()
        self.discover_mcp_tools()
        
        # Check toolset availability
        self.available_toolsets = set(get_available_toolsets())
        
        # Log availability status
        for toolset_name in TOOLSETS:
            if toolset_name in self.available_toolsets:
                tools = resolve_toolset_tools(toolset_name, self)
                print(f"✅ Toolset '{toolset_name}' ({len(tools)} tools: {', '.join(tools[:5])}...)")
            else:
                print(f"⚠️  Toolset '{toolset_name}' unavailable")

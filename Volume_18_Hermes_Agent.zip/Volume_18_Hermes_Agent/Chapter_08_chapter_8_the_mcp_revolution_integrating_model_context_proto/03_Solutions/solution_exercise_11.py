
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_11.py
# Description: Solution for Exercise 11
# ==========================================

# run_agent.py - Modified advanced example with logging
from session_db import SessionDB
from model_tools import ModelTools

class AIAgent:
    def __init__(self, config: dict):
        self.config = config
        self.session_db = SessionDB()
        self.model_tools = ModelTools(session_db=self.session_db)
        # ... rest of initialization ...
    
    def run_conversation(self, user_input: str) -> str:
        """Run a single conversation turn with logging."""
        # Generate or get session ID
        session_id = self._get_or_create_session()
        self.model_tools.current_session_id = session_id
        
        # ... existing conversation logic ...
        
        # At the end of conversation, print stats
        if self._conversation_ended:
            stats = self.session_db.get_log_stats()
            self._print_session_stats(stats)
    
    def _print_session_stats(self, stats: dict):
        """Print session statistics."""
        print("\n" + "="*50)
        print("SESSION STATISTICS")
        print("="*50)
        print(f"Total MCP calls: {stats['total_calls']}")
        print(f"Average duration: {stats['avg_duration']} ms")
        print(f"Success rate: {stats['success_rate']}%")
        print(f"\nTop 10 most-called tools:")
        for i, tool in enumerate(stats['top_tools'], 1):
            print(f"  {i}. {tool['tool']} - {tool['calls']} calls")
        print("="*50)

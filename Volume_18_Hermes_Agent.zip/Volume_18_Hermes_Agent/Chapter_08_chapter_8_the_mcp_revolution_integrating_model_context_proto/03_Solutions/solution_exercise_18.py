
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_18.py
# Description: Solution for Exercise 18
# ==========================================

# tests/test_rate_limiter.py
import time
import threading
from unittest.mock import Mock, patch
from tools.rate_limiter import RateLimiter
from tools.registry import ToolRegistry

class TestRateLimiter:
    def test_31st_call_blocked(self):
        """Test that the 31st call to a rate-limited tool is blocked."""
        limiter = RateLimiter()
        
        # Make 30 calls (should all succeed)
        for _ in range(30):
            assert limiter.check("test_tool", 30) == True
            limiter.record("test_tool")
        
        # 31st call should be blocked
        assert limiter.check("test_tool", 30) == False
    
    def test_call_after_window_expires(self):
        """Test that a call succeeds after the window expires."""
        limiter = RateLimiter()
        
        # Make 30 calls with timestamps in the past
        with patch('time.time', return_value=100):
            for _ in range(30):
                limiter.record("test_tool")
        
        # After 61 seconds, the window should have expired
        with patch('time.time', return_value=161):
            assert limiter.check("test_tool", 30) == True
    
    def test_retry_after_handling(self):
        """Test that Retry-After header shifts the window."""
        limiter = RateLimiter()
        
        # Record a call with 30-second skip
        with patch('time.time', return_value=100):
            limiter.record("test_tool", skip_seconds=30)
        
        # Check immediately - should be blocked
        assert limiter.check("test_tool", 30) == False
        
        # After 31 seconds - should be allowed
        with patch('time.time', return_value=131):
            assert limiter.check("test_tool", 30) == True

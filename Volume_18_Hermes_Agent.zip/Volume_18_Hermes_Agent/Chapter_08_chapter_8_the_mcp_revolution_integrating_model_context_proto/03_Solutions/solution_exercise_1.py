
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# mcp_servers/knowledge_server.py
from mcp.server import Server, Tool
from mcp.types import TextContent
import requests
import json

# Create the MCP server instance
server = Server("knowledge-server")

# Define the kb_query tool with its schema
@server.tool("kb_query")
async def kb_query(query: str, max_results: int = 5) -> list:
    """
    Query the internal knowledge base for matching documents.
    
    Args:
        query: The search query string (required)
        max_results: Maximum number of results to return (optional, default 5)
    
    Returns:
        List of matching document dictionaries
    """
    # Internal API endpoint
    api_url = "https://knowledge.internal.company.com/api/search"
    
    # Prepare the request payload
    payload = {
        "query": query,
        "max_results": max_results
    }
    
    try:
        # Make the HTTP request to the internal API
        response = requests.post(api_url, json=payload, timeout=10)
        response.raise_for_status()
        
        # Parse and return the results
        results = response.json()
        return results.get("documents", [])
    except requests.exceptions.RequestException as e:
        # Return error information
        return [{"error": f"Failed to query knowledge base: {str(e)}"}]

# Start the MCP server (for direct execution)
if __name__ == "__main__":
    server.run()

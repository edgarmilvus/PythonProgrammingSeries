
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_14.py
# Description: Solution for Exercise 14
# ==========================================

# tests/test_composite_toolset.py
import pytest
from unittest.mock import patch, Mock
from tools.toolsets import check_toolset_availability, get_available_toolsets

class TestCompositeToolset:
    def test_composite_toolset_available_with_two_servers(self):
        """Test that customer_support is available when 2+ servers respond."""
        def mock_health_response(url, timeout=5):
            if "slack" in url or "jira" in url:
                mock_response = Mock()
                mock_response.status_code = 200
                return mock_response
            else:
                raise ConnectionError("Server unreachable")
        
        with patch('requests.get', side_effect=mock_health_response):
            assert check_toolset_availability("customer_support") == True
    
    def test_composite_toolset_unavailable_with_one_server(self):
        """Test that customer_support is unavailable when only 1 server responds."""
        def mock_health_response(url, timeout=5):
            if "slack" in url:
                mock_response = Mock()
                mock_response.status_code = 200
                return mock_response
            else:
                raise ConnectionError("Server unreachable")
        
        with patch('requests.get', side_effect=mock_health_response):
            assert check_toolset_availability("customer_support") == False

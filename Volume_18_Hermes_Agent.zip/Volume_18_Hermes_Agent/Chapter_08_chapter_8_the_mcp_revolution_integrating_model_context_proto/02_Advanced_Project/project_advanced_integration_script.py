
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script.py
# Description: Advanced Integration Script
# ==========================================

#!/usr/bin/env python3
"""
Research Pipeline Agent

A production-grade multi-agent research system built on Hermes Agent.
Demonstrates:
  - AIAgent initialization with toolset filtering
  - Task delegation (sub-agents)
  - Persistent memory (built-in MemoryStore)
  - Custom tool schema registration
  - Iteration budget management
  - Error handling and graceful degradation
"""

import json
import logging
import os
import sys
import time
from typing import Dict, Any, List, Optional

# ── Core Hermes Agent imports ──────────────────────────────────────────────
# The AIAgent class is the main entry point. It manages the conversation loop,
# tool execution, and response handling.
from run_agent import AIAgent, IterationBudget

# Tool definitions and handlers from the Hermes tool system.
# get_tool_definitions returns the OpenAI-format tool schemas.
# handle_function_call dispatches tool execution.
from model_tools import get_tool_definitions, handle_function_call

# The registry allows us to register custom tools and toolsets.
from tools.registry import registry

# MemoryStore provides persistent memory across sessions (MEMORY.md + USER.md).
from tools.memory_tool import MemoryStore

# Delegate tool for spawning sub-agents.
from tools.delegate_tool import delegate_task

# ── Configuration ──────────────────────────────────────────────────────────
# In production, these would come from config.yaml or environment variables.
CONFIG = {
    "model": "anthropic/claude-sonnet-4-6",  # Model via OpenRouter
    "base_url": "https://openrouter.ai/api/v1",  # OpenRouter endpoint
    "api_key": os.environ.get("OPENROUTER_API_KEY", ""),  # From env
    "max_iterations": 50,  # Total tool-calling iterations for the parent
    "subagent_max_iterations": 15,  # Per sub-agent iteration budget
    "memory_char_limit": 4000,  # Max characters for memory entries
    "user_char_limit": 2000,  # Max characters for user profile
}

# ── Logging Setup ──────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("research_pipeline.log"),
    ],
)
logger = logging.getLogger("ResearchPipeline")


# =============================================================================
# STEP 1: Define Custom Tools
# =============================================================================
# We'll register a custom tool called "summarize_paper" that takes a paper's
# text and returns a structured summary. This tool is NOT part of the default
# Hermes toolset — we register it dynamically using the tool registry.
#
# The registry.register() call takes:
#   - name: The tool name (what the LLM will call)
#   - fn: The Python function to execute
#   - schema: OpenAI-format JSON Schema for the tool's parameters
#   - toolset: Which toolset this tool belongs to (for filtering)
# =============================================================================

def _summarize_paper_handler(paper_text: str, max_length: int = 500) -> str:
    """
    Summarize a research paper's abstract or full text.
    In a real system, this might call a dedicated LLM or extraction API.
    Here we demonstrate the pattern with a simple heuristic.
    """
    # In production, you'd call an LLM or a summarization model.
    # For this example, we return a structured placeholder.
    summary = {
        "status": "success",
        "summary": paper_text[:max_length] + "...",
        "word_count": len(paper_text.split()),
        "key_points": [
            "Point 1: [Extracted from text]",
            "Point 2: [Extracted from text]",
        ],
    }
    return json.dumps(summary, ensure_ascii=False)


# Register the custom tool with the Hermes registry.
# The schema defines the parameters the LLM must provide.
registry.register(
    name="summarize_paper",
    fn=_summarize_paper_handler,
    schema={
        "type": "function",
        "function": {
            "name": "summarize_paper",
            "description": "Summarize a research paper's text. Provide the full text or abstract.",
            "parameters": {
                "type": "object",
                "properties": {
                    "paper_text": {
                        "type": "string",
                        "description": "The full text or abstract of the paper to summarize.",
                    },
                    "max_length": {
                        "type": "integer",
                        "description": "Maximum length of the summary in characters.",
                        "default": 500,
                    },
                },
                "required": ["paper_text"],
            },
        },
    },
    toolset="research",  # Belongs to the 'research' toolset
)

logger.info("Custom tool 'summarize_paper' registered in the 'research' toolset.")


# =============================================================================
# STEP 2: Define the ResearchPipelineAgent Class
# =============================================================================
# This class wraps the AIAgent and adds research-specific logic:
#   - Initialization with a custom toolset
#   - A method to spawn sub-agents for parallel research
#   - Memory persistence for findings
#   - Iteration budget management
# =============================================================================

class ResearchPipelineAgent:
    """
    A multi-agent research system built on Hermes Agent.

    Features:
    - Delegates sub-tasks to child AIAgents (sub-agents).
    - Persists research findings to memory (MEMORY.md).
    - Uses a custom 'research' toolset that includes web search, file read,
      and our custom 'summarize_paper' tool.
    - Manages iteration budgets to prevent runaway loops.
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the research pipeline.

        Steps:
        1. Validate configuration.
        2. Create an IterationBudget for the parent agent.
        3. Initialize the MemoryStore for persistent findings.
        4. Create the primary AIAgent with filtered toolsets.
        """
        self.config = config
        self.logger = logging.getLogger("ResearchPipeline.Agent")

        # ── Step 2.1: Validate API key ──────────────────────────────────
        if not config["api_key"]:
            raise ValueError(
                "OPENROUTER_API_KEY environment variable is not set. "
                "Please set it to your OpenRouter API key."
            )

        # ── Step 2.2: Create the iteration budget ───────────────────────
        # The parent agent gets a budget of max_iterations. Sub-agents
        # get their own independent budgets (subagent_max_iterations each).
        self.iteration_budget = IterationBudget(
            max_total=config["max_iterations"]
        )
        self.logger.info(
            f"Iteration budget created: {config['max_iterations']} total steps."
        )

        # ── Step 2.3: Initialize persistent memory store ────────────────
        # MemoryStore reads/writes to ~/.hermes/MEMORY.md and USER.md.
        # This gives the agent long-term recall across sessions.
        self.memory_store = MemoryStore(
            memory_char_limit=config["memory_char_limit"],
            user_char_limit=config["user_char_limit"],
        )
        self.memory_store.load_from_disk()
        self.logger.info("Memory store initialized from disk.")

        # ── Step 2.4: Create the primary AIAgent ────────────────────────
        # We enable only the 'research' toolset, which includes:
        #   - web_search, web_extract (for finding papers)
        #   - read_file, search_files (for reading local papers)
        #   - memory (for persisting findings)
        #   - our custom 'summarize_paper' tool
        # We disable 'terminal' and 'browser' to keep the agent focused.
        self.agent = AIAgent(
            base_url=config["base_url"],
            api_key=config["api_key"],
            model=config["model"],
            max_iterations=config["max_iterations"],
            enabled_toolsets=["research", "memory", "file"],
            disabled_toolsets=["terminal", "browser", "vision", "image_gen"],
            quiet_mode=True,  # Suppress verbose tool output
            save_trajectories=False,  # Not saving trajectories for this demo
            verbose_logging=False,
        )

        # ── Step 2.5: Inject the custom tool into the agent's tool list ─
        # The AIAgent's self.tools is a list of OpenAI-format tool definitions.
        # We need to add our custom 'summarize_paper' tool to this list so the
        # LLM knows it exists.
        custom_tool_def = {
            "type": "function",
            "function": {
                "name": "summarize_paper",
                "description": "Summarize a research paper's text.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "paper_text": {
                            "type": "string",
                            "description": "The full text or abstract of the paper.",
                        },
                        "max_length": {
                            "type": "integer",
                            "description": "Maximum summary length in characters.",
                            "default": 500,
                        },
                    },
                    "required": ["paper_text"],
                },
            },
        }
        # Check if it's already present (from registry discovery).
        existing_names = {
            t["function"]["name"] for t in self.agent.tools
        }
        if "summarize_paper" not in existing_names:
            self.agent.tools.append(custom_tool_def)
            self.agent.valid_tool_names.add("summarize_paper")
            self.logger.info("Custom tool 'summarize_paper' injected into agent's tool list.")

        # ── Step 2.6: Replace the agent's memory store ──────────────────
        # By default, the AIAgent creates its own MemoryStore. We replace it
        # with ours so that the agent uses the same persistent store.
        self.agent._memory_store = self.memory_store
        self.agent._memory_enabled = True
        self.agent._user_profile_enabled = True

        self.logger.info("ResearchPipelineAgent initialized successfully.")

    # =========================================================================
    # STEP 3: Spawn a Sub-Agent for Delegated Research
    # =========================================================================
    # The AIAgent's delegate_task tool allows spawning child agents. We wrap
    # this in a method that creates a new AIAgent with a reduced iteration
    # budget and a focused toolset.
    #
    # The sub-agent inherits the parent's model, API key, and base URL.
    # It gets its own iteration budget (subagent_max_iterations) so it doesn't
    # consume the parent's budget.
    # =========================================================================

    def spawn_research_subagent(
        self,
        goal: str,
        context: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Spawn a sub-agent to perform a focused research task.

        Args:
            goal: The specific task for the sub-agent (e.g., "Find recent papers on X").
            context: Optional context from the parent conversation.

        Returns:
            A dictionary with the sub-agent's final response and metadata.
        """
        self.logger.info(f"Spawning sub-agent for goal: {goal[:80]}...")

        # ── Step 3.1: Create a child agent ──────────────────────────────
        # The child agent uses the same model and API key but has its own
        # iteration budget (subagent_max_iterations). It also has a reduced
        # toolset: only web search and file read, no memory or summarization.
        child_agent = AIAgent(
            base_url=self.config["base_url"],
            api_key=self.config["api_key"],
            model=self.config["model"],
            max_iterations=self.config["subagent_max_iterations"],
            enabled_toolsets=["web", "file"],  # Focused toolset
            disabled_toolsets=["terminal", "browser", "vision", "image_gen", "memory"],
            quiet_mode=True,
            save_trajectories=False,
            verbose_logging=False,
            # Pass the parent's session ID for traceability
            session_id=f"{self.agent.session_id}_sub",
            # Give the child its own iteration budget
            iteration_budget=IterationBudget(
                max_total=self.config["subagent_max_iterations"]
            ),
        )

        # ── Step 3.2: Register the child with the parent ───────────────
        # This allows the parent to propagate interrupts to the child.
        with self.agent._active_children_lock:
            self.agent._active_children.append(child_agent)

        try:
            # ── Step 3.3: Run the sub-agent's conversation ─────────────
            result = child_agent.run_conversation(
                user_message=goal,
                system_message=(
                    "You are a focused research sub-agent. Your only job is to "
                    "gather information using web search and file reading tools. "
                    "Return a concise summary of your findings. Do NOT use memory "
                    "or summarization tools — just gather raw data."
                ),
                # Pass optional context from the parent
                conversation_history=(
                    [{"role": "user", "content": context}]
                    if context else None
                ),
            )

            self.logger.info(
                f"Sub-agent completed: {result['api_calls']} API calls, "
                f"response length: {len(result.get('final_response', '') or '')} chars."
            )
            return {
                "success": True,
                "response": result.get("final_response", ""),
                "api_calls": result["api_calls"],
                "messages": result["messages"],
            }

        except Exception as e:
            self.logger.error(f"Sub-agent failed: {e}", exc_info=True)
            return {
                "success": False,
                "response": f"Sub-agent error: {str(e)}",
                "api_calls": 0,
                "messages": [],
            }

        finally:
            # ── Step 3.4: Clean up ─────────────────────────────────────
            # Remove the child from the parent's active list.
            with self.agent._active_children_lock:
                if child_agent in self.agent._active_children:
                    self.agent._active_children.remove(child_agent)
            # Close the child agent's resources (HTTP client, etc.).
            child_agent.close()

    # =========================================================================
    # STEP 4: Run the Full Research Pipeline
    # =========================================================================
    # This is the main entry point. It:
    #   1. Takes a user's research question.
    #   2. Uses the primary agent to decompose the question into sub-tasks.
    #   3. For each sub-task, spawns a sub-agent (delegation).
    #   4. Collects sub-agent results and feeds them back to the primary agent.
    #   5. The primary agent synthesizes the final report.
    #   6. Persists the findings to memory.
    # =========================================================================

    def run_research(self, question: str) -> Dict[str, Any]:
        """
        Execute a full research pipeline.

        Args:
            question: The user's research question.

        Returns:
            A dictionary with the final report and metadata.
        """
        self.logger.info(f"Starting research pipeline for question: {question[:100]}...")

        # ── Step 4.1: Initial conversation with the primary agent ───────
        # The primary agent will use its tools (web search, memory, etc.)
        # to understand the question and plan sub-tasks.
        initial_result = self.agent.run_conversation(
            user_message=(
                f"Research Question: {question}\n\n"
                "First, use web_search to understand the current state of research "
                "on this topic. Then, use the 'delegate_task' tool to spawn sub-agents "
                "for each distinct sub-topic you identify. Finally, synthesize the "
                "results into a comprehensive report. Use the 'memory' tool to save "
                "any important findings for future reference."
            ),
            system_message=(
                "You are a senior research scientist. Your job is to:\n"
                "1. Break down complex questions into sub-tasks.\n"
                "2. Use web_search and web_extract to gather initial data.\n"
                "3. Use delegate_task to spawn sub-agents for parallel research.\n"
                "4. Use summarize_paper to condense long texts.\n"
                "5. Use memory to persist findings.\n"
                "6. Synthesize everything into a final report.\n\n"
                "Be thorough. Use multiple sub-agents if needed. "
                "Always cite your sources."
            ),
        )

        # ── Step 4.2: Check for sub-agent results ──────────────────────
        # The primary agent may have used delegate_task. The results are
        # embedded in the conversation history as tool responses. We extract
        # them here for logging and potential re-injection.
        sub_agent_responses = []
        for msg in initial_result.get("messages", []):
            if (
                msg.get("role") == "tool"
                and "delegate_task" in msg.get("name", "")
            ):
                sub_agent_responses.append(msg.get("content", ""))

        if sub_agent_responses:
            self.logger.info(
                f"Primary agent used delegate_task. "
                f"Found {len(sub_agent_responses)} sub-agent response(s)."
            )

        # ── Step 4.3: Save findings to memory ──────────────────────────
        # We explicitly save the final response and any key findings to the
        # persistent memory store. This allows the user to ask follow-up
        # questions in a new session.
        final_response = initial_result.get("final_response", "")
        if final_response:
            self.memory_store.add_entry(
                action="add",
                target="memory",
                content=(
                    f"Research findings on: {question[:100]}...\n\n"
                    f"{final_response[:self.config['memory_char_limit']]}"
                ),
            )
            self.logger.info("Research findings saved to persistent memory.")

        # ── Step 4.4: Return the result ────────────────────────────────
        return {
            "final_response": final_response,
            "api_calls": initial_result["api_calls"],
            "completed": initial_result["completed"],
            "sub_agent_responses": sub_agent_responses,
            "messages": initial_result["messages"],
            "memory_saved": bool(final_response),
        }


# =============================================================================
# STEP 5: Main Execution
# =============================================================================
# This is the entry point when the script is run directly.
# It demonstrates how to use the ResearchPipelineAgent.
# =============================================================================

if __name__ == "__main__":
    # ── Step 5.1: Create the pipeline agent ─────────────────────────────
    try:
        pipeline = ResearchPipelineAgent(CONFIG)
    except ValueError as e:
        print(f"Configuration error: {e}")
        sys.exit(1)

    # ── Step 5.2: Define a research question ────────────────────────────
    research_question = (
        "What are the latest developments in transformer-based architectures "
        "for time series forecasting? How do they compare to traditional "
        "ARIMA and exponential smoothing methods? Focus on papers from 2023-2025."
    )

    print("=" * 70)
    print("RESEARCH PIPELINE AGENT")
    print("=" * 70)
    print(f"Question: {research_question}")
    print("-" * 70)

    # ── Step 5.3: Run the pipeline ──────────────────────────────────────
    start_time = time.time()
    result = pipeline.run_research(research_question)
    elapsed = time.time() - start_time

    # ── Step 5.4: Display results ───────────────────────────────────────
    print("\n" + "=" * 70)
    print("FINAL REPORT")
    print("=" * 70)
    print(result["final_response"])

    print("\n" + "-" * 70)
    print("PIPELINE STATISTICS")
    print(f"  • API Calls: {result['api_calls']}")
    print(f"  • Completed: {result['completed']}")
    print(f"  • Sub-agent Responses: {len(result['sub_agent_responses'])}")
    print(f"  • Memory Saved: {result['memory_saved']}")
    print(f"  • Elapsed Time: {elapsed:.2f}s")
    print("=" * 70)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation.py
# Description: Basic Library Implementation
# ==========================================

#!/usr/bin/env python3
"""
Basic Library Implementation: Memory Store

This module provides the foundational data layer for Hermes Agent's Memory system.
It manages the persistent storage and retrieval of user-facing memory (MEMORY.md)
and user profile information (USER.md).
"""

import pathlib
import logging
from typing import Optional, Dict, Any

# We'll use a simple dictionary to represent the store, but in production,
# this could be backed by a database or file system.
class MemoryStore:
    """
    Manages the persistent storage and retrieval of user-facing memory.

    The MemoryStore is responsible for reading, writing, and formatting
    the contents of MEMORY.md and USER.md files. These files are the
    primary mechanism for the agent to remember user preferences and
    contextual information across sessions.
    """

    def __init__(self, base_path: pathlib.Path, char_limit: int = 2200):
        """
        Initializes the MemoryStore with a base path and character limits.

        Args:
            base_path: The directory where memory files (MEMORY.md, USER.md) are stored.
            char_limit: The maximum number of characters for memory content.
        """
        self.base_path = pathlib.Path(base_path)
        self.char_limit = char_limit
        self._memory_content: Dict[str, Optional[str]] = {
            "memory": None,
            "user": None,
        }

    def load_from_disk(self) -> None:
        """
        Loads memory content from disk into the in-memory cache.

        This is called once at the start of a session to rehydrate the
        agent's memory context.
        """
        memory_path = self.base_path / "MEMORY.md"
        user_path = self.base_path / "USER.md"

        self._memory_content["memory"] = self._read_file(memory_path)
        self._memory_content["user"] = self._read_file(user_path)

        logging.debug(
            "MemoryStore loaded: memory=%s, user=%s",
            bool(self._memory_content["memory"]),
            bool(self._memory_content["user"]),
        )

    def _read_file(self, file_path: pathlib.Path) -> Optional[str]:
        """
        Safely reads a file from disk, returning its content or None.

        Args:
            file_path: The path to the file to read.

        Returns:
            The file content as a string, or None if the file doesn't exist
            or an error occurs.
        """
        if not file_path.exists():
            return None
        try:
            return file_path.read_text(encoding="utf-8").strip()
        except (OSError, IOError) as e:
            logging.error("Failed to read memory file %s: %s", file_path, e)
            return None

    def _write_file(self, file_path: pathlib.Path, content: str) -> bool:
        """
        Safely writes content to a file.

        Args:
            file_path: The path to the file to write.
            content: The content to write.

        Returns:
            True if the write was successful, False otherwise.
        """
        try:
            self.base_path.mkdir(parents=True, exist_ok=True)
            file_path.write_text(content, encoding="utf-8")
            return True
        except (OSError, IOError) as e:
            logging.error("Failed to write memory file %s: %s", file_path, e)
            return False

    def get_content(self, target: str = "memory") -> Optional[str]:
        """
        Returns the cached content for the specified target.

        Args:
            target: The memory target, either "memory" or "user".

        Returns:
            The content string, or None if not loaded.
        """
        return self._memory_content.get(target)

    def format_for_system_prompt(self, target: str) -> Optional[str]:
        """
        Formats a memory block for injection into the system prompt.

        This wraps the raw content in a clear, delimited block that the
        language model can easily parse.

        Args:
            target: The memory target, either "memory" or "user".

        Returns:
            A formatted string ready for the system prompt, or None
            if no content exists for the target.
        """
        content = self.get_content(target)
        if not content:
            return None

        if target == "memory":
            return f"<automated-memory>\n{content}\n</automated-memory>"
        elif target == "user":
            return f"<user-profile>\n{content}\n</user-profile>"
        return None

    def update_content(
        self, target: str, new_content: str, action: str = "replace"
    ) -> Dict[str, Any]:
        """
        Updates the memory content for a given target.

        This method handles two main actions:
            - "replace": Completely replaces the existing content with new_content.
            - "add": Appends new_content to the end of the existing content,
                     respecting the character limit.

        Args:
            target: The memory target, either "memory" or "user".
            new_content: The content to update with.
            action: The update action, either "replace" or "add".

        Returns:
            A dictionary with the operation result, including status and message.
        """
        if target not in self._memory_content:
            return {"success": False, "error": f"Unknown target: {target}"}

        old_content = self._memory_content.get(target) or ""

        if action == "replace":
            updated_content = new_content
        elif action == "add":
            updated_content = self._append_content(old_content, new_content)
        else:
            return {"success": False, "error": f"Unknown action: {action}"}

        # Enforce character limit
        if len(updated_content) > self.char_limit:
            logging.warning(
                "Memory content exceeds character limit (%d > %d). Truncating.",
                len(updated_content),
                self.char_limit,
            )
            updated_content = updated_content[: self.char_limit]

        # Determine the target file path
        file_path = self.base_path / f"{target.upper()}.md"
        if not self._write_file(file_path, updated_content):
            return {
                "success": False,
                "error": f"Failed to write to {file_path}",
            }

        # Update the in-memory cache
        self._memory_content[target] = updated_content

        return {
            "success": True,
            "message": f"Content updated for target: {target}",
            "target": target,
        }

    def _append_content(self, existing: str, new: str) -> str:
        """
        Appends new content to existing content with a separator.

        Args:
            existing: The existing content.
            new: The content to append.

        Returns:
            The combined content string.
        """
        if not existing:
            return new
        separator = "\n\n---\n\n"
        return existing + separator + new

# Example usage
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(level=logging.INFO)

    # Create a temporary store for demonstration
    import tempfile
    with tempfile.TemporaryDirectory() as temp_dir:
        store = MemoryStore(base_path=pathlib.Path(temp_dir), char_limit=500)

        # Simulate loading memory at session start
        store.load_from_disk()
        print("Initial memory:", store.get_content("memory"))

        # Simulate the agent learning the user's preference
        result = store.update_content(
            target="user",
            new_content="The user prefers concise, bullet-point answers.",
            action="replace",
        )
        print("Update result:", result)

        # Format it for the system prompt
        formatted = store.format_for_system_prompt("user")
        print("Formatted for prompt:")
        print(formatted)

        # Add more information
        result = store.update_content(
            target="user",
            new_content="The user's project is at /home/example/project.",
            action="add",
        )
        print("Append result:", result)
        print("Complete user profile:")
        print(store.get_content("user"))

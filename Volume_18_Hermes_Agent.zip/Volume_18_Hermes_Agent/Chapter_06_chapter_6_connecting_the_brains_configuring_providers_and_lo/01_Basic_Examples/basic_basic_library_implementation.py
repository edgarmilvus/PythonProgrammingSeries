
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation.py
# Description: Basic Library Implementation
# ==========================================

#!/usr/bin/env python3
"""
Chapter 6 – Basic Library Implementation
Demonstrates provider configuration and local model setup
using real Hermes Agent classes.
"""

import os
import json
import logging
from pathlib import Path

# ---------------------------------------------------------------------------
# 1. Set up logging and a temporary home for Hermes state (for this demo)
# ---------------------------------------------------------------------------
logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
logger = logging.getLogger("demo")

# Hermes uses ~/.hermes by default. For this example we override via env.
demo_home = Path("/tmp/hermes_demo")
demo_home.mkdir(parents=True, exist_ok=True)
os.environ["HERMES_HOME"] = str(demo_home)

# ---------------------------------------------------------------------------
# 2. Create a persistent SQLite session store
# ---------------------------------------------------------------------------
from hermes_state import SessionDB

session_db = SessionDB(db_path=str(demo_home / "sessions.db"))
logger.info("SessionDB initialized at %s", session_db.db_path)

# We'll create a new session for our first brain
session_id = session_db.create_session(
    platform="cli",
    model="anthropic/claude-opus-4.6",
    provider="openrouter",
)
logger.info("New session created: %s", session_id)

# ---------------------------------------------------------------------------
# 3. Configure and instantiate AIAgent with OpenRouter (cloud)
# ---------------------------------------------------------------------------
from run_agent import AIAgent

# In production, read these from ~/.hermes/.env! Here we set them directly.
cloud_agent = AIAgent(
    provider="openrouter",
    base_url="https://openrouter.ai/api/v1",
    api_key=os.getenv("OPENROUTER_API_KEY", "sk-demo-key"),
    model="anthropic/claude-opus-4.6",
    max_iterations=30,
    session_id=session_id,
    save_trajectories=True,
    platform="cli",
    # Memory is enabled by default – the agent will use the session DB to
    # persist learned facts across turns.
    skip_memory=False,
)

logger.info("Cloud AIAgent created with model: %s", cloud_agent.model)

# ---------------------------------------------------------------------------
# 4. Run a conversation turn – the agent will "think" and respond
# ---------------------------------------------------------------------------
response = cloud_agent.chat("What is the capital of France? Keep it short.")
logger.info("Cloud agent response: %s", response)

# The agent automatically logs this turn to SessionDB. We can verify:
turn_records = session_db.get_turns(session_id)
print(f"Turns stored so far: {len(turn_records)}")

# ---------------------------------------------------------------------------
# 5. Save a memory to demonstrate persistence across provider swaps
# ---------------------------------------------------------------------------
# The agent has a dedicated memory tool (tools/memory_tool.py). We'll simulate
# what the agent does internally when it decides to remember something.
from agent.memory_manager import MemoryManager

mem_mgr = MemoryManager(session_db, user_id="demo_user")
mem_mgr.add_memory(
    session_id=session_id,
    content="The user prefers concise answers about geography.",
    category="user_preference",
)
logger.info("Memory saved: 'The user prefers concise answers about geography.'")

# ---------------------------------------------------------------------------
# 6. Swap the brain – reconfigure for a local Ollama endpoint
# ---------------------------------------------------------------------------
# The AIAgent constructor allows you to change provider/model at any time.
# For example, to switch to a local Ollama server running at
# http://127.0.0.1:11434/v1

local_agent = AIAgent(
    provider="custom",                # maps to "ollama" alias via config
    base_url="http://127.0.0.1:11434/v1",
    # Ollama doesn't require an API key by default, but the code expects one.
    api_key="ollama",
    model="llama3.2:1b",              # a tiny, fast local model
    max_iterations=30,
    session_id=session_id,            # **same session** = shared memory
    save_trajectories=True,
    platform="cli",
    skip_memory=False,
)

logger.info("Local AIAgent created with model: %s", local_agent.model)

# ---------------------------------------------------------------------------
# 7. Ask the same question again – but this time the local model responds
# ---------------------------------------------------------------------------
response_local = local_agent.chat("What is the capital of France? Keep it short.")
logger.info("Local agent response: %s", response_local)

# ---------------------------------------------------------------------------
# 8. Verify that the agent remembered the user preference from step 5
# ---------------------------------------------------------------------------
# The memory is injected into the system prompt automatically. We can inspect
# the conversation history to confirm.
conversation = session_db.get_messages(session_id)
for msg in conversation[-3:]:  # last few turns
    if msg.get("role") == "assistant":
        print(f"Assistant ({msg['model']}): {msg['content'][:100]}")

# Cleanup – close the session
session_db.close_session(session_id)
logger.info("Demo complete. Session closed.")

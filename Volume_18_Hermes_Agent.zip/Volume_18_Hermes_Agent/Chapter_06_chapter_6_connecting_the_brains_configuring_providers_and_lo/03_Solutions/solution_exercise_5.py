
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# hermes_core/state/session_db.py (extended with provider_performance table)
import sqlite3
import time
from typing import Dict, Any, List, Optional
from pathlib import Path

class SessionDB:
    def __init__(self, db_path: str):
        self.conn = sqlite3.connect(db_path)
        self._create_tables()
    
    def _create_tables(self):
        c = self.conn.cursor()
        c.execute("""
            CREATE TABLE IF NOT EXISTS provider_performance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT,
                task_type TEXT,
                provider TEXT,
                model TEXT,
                completion_time REAL,
                tool_calls INTEGER,
                token_usage INTEGER,
                success INTEGER,
                user_satisfaction REAL,
                timestamp REAL
            )
        """)
        self.conn.commit()
    
    def record_performance(self, session_id: str, task_type: str, provider: str,
                           model: str, completion_time: float, tool_calls: int,
                           token_usage: int, success: bool, user_satisfaction: float):
        c = self.conn.cursor()
        c.execute("""
            INSERT INTO provider_performance
            (session_id, task_type, provider, model, completion_time, tool_calls,
             token_usage, success, user_satisfaction, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (session_id, task_type, provider, model, completion_time, tool_calls,
              token_usage, int(success), user_satisfaction, time.time()))
        self.conn.commit()
    
    def query_best_provider(self, task_type: str, metric: str = "success_rate",
                            limit: int = 5) -> List[Dict[str, Any]]:
        """Query historical performance to recommend best provider for a task type."""
        c = self.conn.cursor()
        # Example: rank by success rate, then by average completion time
        c.execute("""
            SELECT provider, model,
                   AVG(success) as success_rate,
                   AVG(completion_time) as avg_time,
                   AVG(token_usage) as avg_tokens,
                   COUNT(*) as samples
            FROM provider_performance
            WHERE task_type = ?
            GROUP BY provider, model
            ORDER BY success_rate DESC, avg_time ASC
            LIMIT ?
        """, (task_type, limit))
        rows = c.fetchall()
        return [{"provider": r[0], "model": r[1], "success_rate": r[2],
                 "avg_time": r[3], "avg_tokens": r[4], "samples": r[5]} for r in rows]

# hermes_core/agent.py (modifications for auto_select_provider)
class AIAgent:
    def __init__(self, config, provider=None, model=None, toolset=None,
                 auto_select_provider=False, session_db=None, budget=None):
        self.config = config
        self.auto_select_provider = auto_select_provider
        self.session_db = session_db or SessionDB(...)
        self.budget = budget or config.get("budget", {})
        self._provider = provider
        self._model = model
        self._task_type = None
        # ... other init ...
    
    def start_conversation(self, user_message: str):
        """Called when a new conversation begins."""
        if self.auto_select_provider:
            self._task_type = self._infer_task_type(user_message)
            self._select_optimal_provider()
        # ... continue with normal flow ...
    
    def _infer_task_type(self, message: str) -> str:
        """Simple task type inference (could use ML)."""
        keywords = {
            "code": ["python", "code", "function", "debug"],
            "vision": ["image", "picture", "see", "visual"],
            "reasoning": ["explain", "why", "reason", "logic"],
            "general": []
        }
        msg_lower = message.lower()
        for task, words in keywords.items():
            if any(w in msg_lower for w in words):
                return task
        return "general"
    
    def _select_optimal_provider(self):
        """Query performance DB and select best provider within budget."""
        results = self.session_db.query_best_provider(self._task_type, metric="success_rate")
        if not results:
            # No history, use default
            return
        for rec in results:
            # Check budget constraints
            cost_per_session = self._estimate_cost(rec["provider"], rec["model"])
            max_cost = self.budget.get("max_per_session", float('inf'))
            if cost_per_session <= max_cost:
                self._provider = rec["provider"]
                self._model = rec["model"]
                # Invalidate tool cache
                clear_tool_defs_cache()
                self._tools = None
                self.system_message(f"Selected provider {self._provider} ({self._model}) for this task.")
                return
        # Fallback to default provider
        self._provider = self.config.get("model", {}).get("provider", "auto")
        self._model = self.config.get("model", {}).get("model", "default")
    
    def _estimate_cost(self, provider: str, model: str) -> float:
        """Estimate cost per session (simplified)."""
        costs = {
            "anthropic": {"claude-3-opus": 0.015},
            "openai": {"gpt-4": 0.03},
            "local": {"default": 0.0}
        }
        return costs.get(provider, {}).get(model, 0.01)
    
    def _record_session_performance(self, session_id: str, success: bool, user_satisfaction: float):
        """Record performance after conversation ends."""
        self.session_db.record_performance(
            session_id=session_id,
            task_type=self._task_type or "general",
            provider=self._provider,
            model=self._model,
            completion_time=self._session_duration,
            tool_calls=len(self._tool_calls),
            token_usage=self._total_tokens,
            success=success,
            user_satisfaction=user_satisfaction
        )

# hermes_core/skills/skill_loader.py (extended)
class Skill:
    def __init__(self, name, definition, recommended_provider=None, recommended_model=None):
        self.name = name
        self.definition = definition
        self.recommended_provider = recommended_provider
        self.recommended_model = recommended_model

def load_skill(skill_name: str, agent: AIAgent):
    """Load a skill and optionally switch provider."""
    skill = _skill_registry.get(skill_name)
    if not skill:
        return
    if skill.recommended_provider and agent.auto_select_provider:
        # Switch provider (deferred to avoid breaking prompt cache)
        agent.schedule_action(lambda: agent.switch_provider(skill.recommended_provider))
        agent.schedule_action(lambda: agent.switch_model(skill.recommended_model))
    # ... load skill logic ...

# hermes_core/skills/skill_creation.py (extended)
def create_skill(agent: AIAgent, name: str, definition: Dict[str, Any]):
    """Create a new skill with provider performance metadata."""
    skill = Skill(
        name=name,
        definition=definition,
        recommended_provider=agent._provider,
        recommended_model=agent._model
    )
    # Store in skill registry
    _skill_registry[name] = skill
    # Optionally vet: compare performance with other providers
    vet_performance(agent, name)

def vet_performance(agent: AIAgent, skill_name: str):
    """Compare skill's performance across providers and suggest updates."""
    results = agent.session_db.query_best_provider(task_type=skill_name)
    if results and results[0]["provider"] != agent._provider:
        print(f"Note: Skill '{skill_name}' might perform better with {results[0]['provider']}")

# hermes_core/commands.py (new slash command)
def provider_history(agent: AIAgent, args: str):
    """Display learned provider preferences."""
    results = agent.session_db.query_best_provider(task_type=args or None)
    print("Provider performance history:")
    for r in results:
        print(f"  {r['provider']}/{r['model']}: success={r['success_rate']:.0%}, "
              f"avg time={r['avg_time']:.1f}s, samples={r['samples']}")

def reset_provider_preferences(agent: AIAgent):
    """Clear learned provider rankings."""
    agent.session_db.conn.execute("DELETE FROM provider_performance")
    agent.session_db.conn.commit()
    print("Provider preferences reset.")

# hermes_core/learning_loop.py (modified)
class LearningLoop:
    def __init__(self, agent: AIAgent):
        self.agent = agent
    
    def run(self, user_message: str):
        self.agent.start_conversation(user_message)
        # ... normal conversation loop ...
        # After conversation ends:
        success = self._evaluate_success()
        satisfaction = self._infer_satisfaction()
        self.agent._record_session_performance(
            session_id=self.agent.current_session_id,
            success=success,
            user_satisfaction=satisfaction
        )
        # Compress memory with provider info
        self._compress_memory_with_provider_info()
    
    def _compress_memory_with_provider_info(self):
        """Include provider performance in memory compression."""
        memory_entry = f"Session with {self.agent._provider}/{self.agent._model}: "
        memory_entry += f"task={self.agent._task_type}, success={success}"
        self.agent.memory.add(memory_entry)

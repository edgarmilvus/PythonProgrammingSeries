
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# plugins/model-providers/internal-gateway/__init__.py
"""
Internal Gateway Provider Plugin for Hermes Agent.
"""
from hermes_cli.providers import register_provider, ProviderProfile
from hermes_cli.config import OPTIONAL_ENV_VARS
from hermes_core.providers import ProviderType
from .gateway_client import InternalGatewayClient

# Register the provider
def register():
    profile = ProviderProfile(
        name="internal-gateway",
        supported_models=["*"],  # Accept any model name
        default_base_url="http://localhost:8080/v1",
        required_env_vars=["INTERNAL_GATEWAY_API_KEY", "INTERNAL_GATEWAY_BASE_URL"],
        availability_check=lambda: (
            os.getenv("INTERNAL_GATEWAY_API_KEY") is not None and
            os.getenv("INTERNAL_GATEWAY_BASE_URL") is not None
        ),
        model_discovery=InternalGatewayClient.fetch_models,
        request_interceptor=InternalGatewayClient.intercept_request,
        error_classifier=InternalGatewayClient.classify_error,
    )
    register_provider(profile)

# plugins/model-providers/internal-gateway/gateway_client.py
import os
import time
import random
import requests
from typing import List, Dict, Any, Optional
from hermes_cli.logging import get_logger

logger = get_logger("internal-gateway")

class InternalGatewayClient:
    """Client for the internal gateway API."""
    
    @staticmethod
    def fetch_models(base_url: str = None) -> List[Dict[str, Any]]:
        """Fetch available models from /v1/models and normalize names."""
        if not base_url:
            base_url = os.getenv("INTERNAL_GATEWAY_BASE_URL", "http://localhost:8080/v1")
        resp = requests.get(f"{base_url}/models", timeout=10,
                            headers={"Authorization": f"Bearer {os.getenv('INTERNAL_GATEWAY_API_KEY')}"})
        resp.raise_for_status()
        models = resp.json().get("data", [])
        # Normalize names: map "internal-claude-3.5" to standard metadata
        normalized = []
        for m in models:
            model_id = m["id"]
            # Use framework's model catalog to get metadata
            from hermes_core.model_catalog import get_model_metadata
            meta = get_model_metadata(model_id) or {"context_length": 8192, "supports_functions": True}
            normalized.append({"id": model_id, **meta})
        return normalized
    
    @staticmethod
    def intercept_request(request: Dict[str, Any], session_id: str = None) -> Dict[str, Any]:
        """Add custom headers and handle authentication."""
        headers = request.get("headers", {})
        # API key auth
        headers["Authorization"] = f"Bearer {os.getenv('INTERNAL_GATEWAY_API_KEY')}"
        # OAuth token from file
        token_file = os.getenv("INTERNAL_GATEWAY_TOKEN_FILE")
        if token_file and os.path.exists(token_file):
            with open(token_file, "r") as f:
                token = f.read().strip()
            headers["Authorization"] = f"Bearer {token}"
        # Session header
        if session_id:
            headers["X-Gateway-Session-ID"] = session_id
        request["headers"] = headers
        return request
    
    @staticmethod
    def classify_error(status_code: int, response_body: str) -> str:
        """Map internal gateway error codes to framework taxonomy."""
        if status_code == 401 or status_code == 403:
            return "authentication_failure"
        elif status_code == 429:
            return "rate_limited"
        elif status_code == 503:
            return "service_unavailable"
        elif status_code == 404:
            return "model_unavailable"
        elif status_code >= 500:
            return "server_error"
        else:
            return "unknown"
    
    @staticmethod
    def retry_with_backoff(func, max_retries=3, base_delay=1.0):
        """Retry with exponential backoff and jitter for 429/503."""
        for attempt in range(max_retries):
            try:
                return func()
            except requests.HTTPError as e:
                if e.response.status_code in (429, 503):
                    delay = base_delay * (2 ** attempt) + random.uniform(0, 0.5)
                    logger.warning(f"Retry attempt {attempt+1} after {delay:.2f}s")
                    time.sleep(delay)
                else:
                    raise
        raise Exception("Max retries exceeded")
    
    @staticmethod
    def diagnose() -> Dict[str, Any]:
        """Diagnostic function for 'hermes doctor' command."""
        base_url = os.getenv("INTERNAL_GATEWAY_BASE_URL")
        api_key = os.getenv("INTERNAL_GATEWAY_API_KEY")
        if not base_url or not api_key:
            return {"status": "misconfigured", "message": "Missing env vars"}
        try:
            resp = requests.get(f"{base_url}/models", timeout=5,
                                headers={"Authorization": f"Bearer {api_key}"})
            if resp.status_code == 200:
                return {"status": "ok", "models_count": len(resp.json().get("data", []))}
            else:
                return {"status": "error", "code": resp.status_code}
        except Exception as e:
            return {"status": "unreachable", "error": str(e)}

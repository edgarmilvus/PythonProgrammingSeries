
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# hermes_core/tools/registry.py (extended)
from typing import Dict, Any, List, Optional, Callable
from dataclasses import dataclass, field

@dataclass
class ToolDefinition:
    name: str
    description: str
    schema: Dict[str, Any]
    handler: Callable
    capabilities: Dict[str, bool] = field(default_factory=dict)  # e.g., {"vision": True}
    capability_fallback: Optional[str] = None  # alternative tool name

_registry: Dict[str, ToolDefinition] = {}

def register(name: str, description: str, schema: Dict[str, Any], handler: Callable,
             capabilities: Optional[Dict[str, bool]] = None,
             capability_fallback: Optional[str] = None):
    """Register a tool with optional capability requirements."""
    if capabilities is None:
        capabilities = {}
    _registry[name] = ToolDefinition(
        name=name, description=description, schema=schema,
        handler=handler, capabilities=capabilities,
        capability_fallback=capability_fallback
    )

def get_tool_definitions(provider_capabilities: Optional[Dict[str, bool]] = None,
                         toolset_filter: Optional[List[str]] = None) -> List[Dict[str, Any]]:
    """Return tool schemas filtered by provider capabilities and toolset."""
    if provider_capabilities is None:
        provider_capabilities = {}  # Assume all capabilities available if not specified
    
    # Start with all registered tools
    tools = list(_registry.values())
    
    # Apply toolset filter (if provided)
    if toolset_filter is not None:
        tools = [t for t in tools if t.name in toolset_filter]
    
    # Filter by capabilities
    filtered = []
    for tool in tools:
        # Check if tool's capabilities are satisfied
        required = tool.capabilities
        if all(required.get(k, False) == provider_capabilities.get(k, False)
               for k in required):
            filtered.append(tool)
        elif tool.capability_fallback and tool.capability_fallback in _registry:
            # Use fallback tool
            fallback = _registry[tool.capability_fallback]
            # Check fallback's capabilities
            if all(fallback.capabilities.get(k, False) == provider_capabilities.get(k, False)
                   for k in fallback.capabilities):
                # Substitute fallback schema but keep original name
                fallback_schema = fallback.schema.copy()
                fallback_schema["name"] = tool.name  # Keep original name for agent
                filtered.append(ToolDefinition(
                    name=tool.name,
                    description=tool.description + " (using fallback)",
                    schema=fallback_schema,
                    handler=fallback.handler,
                    capabilities=fallback.capabilities
                ))
            # else drop the tool
        # else drop the tool
    
    # Convert to schema list
    return [{"name": t.name, "description": t.description, "parameters": t.schema} for t in filtered]

# Cache invalidation
_tool_defs_cache: Dict[str, Any] = {}
def clear_tool_defs_cache():
    _tool_defs_cache.clear()

# hermes_core/model_tools.py (extended)
from hermes_core.tools.registry import get_tool_definitions, clear_tool_defs_cache
from hermes_core.providers import resolve_provider_capabilities

def resolve_provider_capabilities(provider: str, model: str) -> Dict[str, bool]:
    """Query provider and model to determine capabilities."""
    # Simplified: use model catalog metadata
    from hermes_core.model_catalog import get_model_metadata
    meta = get_model_metadata(model) or {}
    caps = {
        "vision": meta.get("supports_vision", False),
        "code": meta.get("supports_code", False),
        "reasoning": meta.get("supports_reasoning", False),
        "functions": meta.get("supports_functions", True),  # Most providers support function calling
        "long_context": meta.get("context_length", 4096) > 32768,
    }
    # Provider-specific overrides
    if provider == "anthropic":
        caps["functions"] = False  # Anthropic doesn't support function calling natively
    elif provider == "local":
        caps["vision"] = False  # Assume local models don't support vision
    return caps

def get_tool_definitions_with_capabilities(agent: 'AIAgent') -> List[Dict[str, Any]]:
    """Get tool definitions filtered by agent's current provider capabilities."""
    caps = resolve_provider_capabilities(agent.provider, agent.model)
    # Use cache keyed by provider+model
    cache_key = f"{agent.provider}:{agent.model}"
    if cache_key in _tool_defs_cache:
        return _tool_defs_cache[cache_key]
    defs = get_tool_definitions(provider_capabilities=caps, toolset_filter=agent.toolset)
    _tool_defs_cache[cache_key] = defs
    return defs

# hermes_core/agent.py (modifications to AIAgent)
class AIAgent:
    def __init__(self, config, provider=None, model=None, toolset=None, auto_select_provider=False):
        self.config = config
        self.provider = provider or config.get("model", {}).get("provider", "auto")
        self.model = model or config.get("model", {}).get("model", "default")
        self.toolset = toolset or config.get("tools", {}).get("enabled", [])
        self._capabilities = None
        self._tools = None
        # ... other init ...
    
    @property
    def tools(self):
        if self._tools is None:
            self._tools = get_tool_definitions_with_capabilities(self)
        return self._tools
    
    @tools.setter
    def tools(self, value):
        self._tools = value
    
    def switch_model(self, new_model: str):
        """Switch model and invalidate tool cache."""
        self.model = new_model
        clear_tool_defs_cache()
        self._tools = None  # Will be recalculated on next access
        # Notify agent via system message
        self.system_message(f"Model switched to {new_model}. Toolset may have changed.")
    
    def switch_provider(self, new_provider: str):
        """Switch provider and invalidate tool cache."""
        self.provider = new_provider
        clear_tool_defs_cache()
        self._tools = None

# hermes_core/tools/toolsets.py (extended)
def recommend_toolsets(provider_capabilities: Dict[str, bool]) -> List[str]:
    """Suggest toolsets based on provider capabilities."""
    recommendations = []
    if provider_capabilities.get("vision"):
        recommendations.append("vision")
    if provider_capabilities.get("code"):
        recommendations.append("code_execution")
    if provider_capabilities.get("long_context"):
        recommendations.append("long_context")
    if provider_capabilities.get("functions"):
        recommendations.append("function_calling")
    # Always include basic tools
    recommendations.append("basic")
    return recommendations

# Example tool registration with capabilities
def register_example_tools():
    register(
        name="browser_vision",
        description="Take a screenshot and analyze visual content",
        schema={"type": "object", "properties": {"url": {"type": "string"}}},
        handler=browser_vision_handler,
        capabilities={"vision": True},
        capability_fallback="browser_snapshot"
    )
    register(
        name="browser_snapshot",
        description="Get a text-only snapshot of a webpage",
        schema={"type": "object", "properties": {"url": {"type": "string"}}},
        handler=browser_snapshot_handler,
        capabilities={}  # universally available
    )
    register(
        name="code_interpreter",
        description="Execute Python code",
        schema={"type": "object", "properties": {"code": {"type": "string"}}},
        handler=code_interpreter_handler,
        capabilities={"code": True}
    )

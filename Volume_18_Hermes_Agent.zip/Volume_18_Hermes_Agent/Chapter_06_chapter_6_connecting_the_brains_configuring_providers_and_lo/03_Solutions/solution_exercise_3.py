
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

#!/usr/bin/env python3
"""
profile_manager.py - Profile management tool for Hermes Agent.
"""
import os
import shutil
import json
import time
import filelock
from pathlib import Path
from typing import Optional, Dict, Any, List
from hermes_cli.config import load_config, DEFAULT_CONFIG, _config_version
from hermes_cli.env_loader import load_env_file, save_env_file
from hermes_core.providers import resolve_provider, ProviderType

HERMES_HOME = Path.home() / ".hermes"
PROFILES_DIR = HERMES_HOME / "profiles"
LOCKS_DIR = HERMES_HOME / ".locks"

# ---------- Profile Creation ----------
def create_profile(profile_name: str, base_profile: Optional[str] = None,
                   provider: str = "auto") -> Path:
    """Create a new profile directory with optional inheritance."""
    profile_dir = PROFILES_DIR / profile_name
    if profile_dir.exists():
        raise FileExistsError(f"Profile '{profile_name}' already exists.")
    
    # Create directory structure
    profile_dir.mkdir(parents=True, exist_ok=True)
    (profile_dir / "memory").mkdir(exist_ok=True)
    (profile_dir / "sessions").mkdir(exist_ok=True)
    
    # Initialize config.yaml with defaults
    config = DEFAULT_CONFIG.copy()
    config["model"]["provider"] = provider
    config_path = profile_dir / "config.yaml"
    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)
    
    # Inherit from base profile if given
    if base_profile:
        base_dir = PROFILES_DIR / base_profile
        if not base_dir.exists():
            raise FileNotFoundError(f"Base profile '{base_profile}' not found.")
        # Copy config and .env (secrets)
        shutil.copy(base_dir / "config.yaml", config_path)
        shutil.copy(base_dir / ".env", profile_dir / ".env")
        # Update provider if specified
        if provider != "auto":
            update_config(profile_dir, {"model": {"provider": provider}})
    
    # Create empty .env if not inherited
    if not (profile_dir / ".env").exists():
        (profile_dir / ".env").touch()
    
    # Validate no conflict with existing profiles (e.g., same LM Studio with different context)
    _validate_no_conflict(profile_name, provider, profile_dir)
    
    return profile_dir

def _validate_no_conflict(new_profile: str, provider: str, profile_dir: Path):
    """Check that two profiles don't use the same local provider with conflicting settings."""
    if provider not in ("lmstudio", "ollama"):
        return
    new_config = load_config(str(profile_dir / "config.yaml"))
    new_base_url = new_config.get("model", {}).get("base_url", "http://localhost:1234")
    for other in PROFILES_DIR.iterdir():
        if other.is_dir() and other.name != new_profile:
            other_config = load_config(str(other / "config.yaml"))
            other_provider = other_config.get("model", {}).get("provider")
            if other_provider == provider:
                other_base_url = other_config.get("model", {}).get("base_url", "http://localhost:1234")
                if other_base_url == new_base_url:
                    print(f"Warning: Profile '{other.name}' already uses {provider} at {new_base_url}")

# ---------- Configuration Wizard ----------
def run_config_wizard(profile_name: str):
    """Interactive wizard to set provider-specific options."""
    profile_dir = PROFILES_DIR / profile_name
    config = load_config(str(profile_dir / "config.yaml"))
    provider = config.get("model", {}).get("provider", "auto")
    
    print(f"Configuring provider for profile '{profile_name}' (current: {provider})")
    if provider == "openrouter":
        api_key = input("OpenRouter API key: ").strip()
        save_env_var(profile_dir, "OPENROUTER_API_KEY", api_key)
        routing = input("Routing preference (random/fallback/weighted): ").strip()
        update_config(profile_dir, {"model": {"openrouter_routing": routing}})
    elif provider in ("lmstudio", "ollama"):
        base_url = input(f"Base URL (default http://localhost:1234): ").strip()
        if not base_url:
            base_url = "http://localhost:1234"
        update_config(profile_dir, {"model": {"base_url": base_url}})
        context_length = input("Context length override (optional): ").strip()
        if context_length:
            update_config(profile_dir, {"model": {"context_length": int(context_length)}})
        timeout = input("Request timeout in seconds (default 30): ").strip()
        if timeout:
            update_config(profile_dir, {"model": {"timeout": int(timeout)}})
    elif provider == "custom":
        full_base_url = input("Full base URL: ").strip()
        update_config(profile_dir, {"model": {"base_url": full_base_url}})
        api_key = input("API key (optional): ").strip()
        if api_key:
            save_env_var(profile_dir, "CUSTOM_API_KEY", api_key)
        model_override = input("Model name override (optional): ").strip()
        if model_override:
            update_config(profile_dir, {"model": {"model": model_override}})
    # Save changes
    print("Configuration saved.")

def save_env_var(profile_dir: Path, key: str, value: str):
    """Save an environment variable to the profile's .env file."""
    env_path = profile_dir / ".env"
    env_vars = {}
    if env_path.exists():
        with open(env_path) as f:
            for line in f:
                if "=" in line:
                    k, v = line.strip().split("=", 1)
                    env_vars[k] = v
    env_vars[key] = value
    with open(env_path, "w") as f:
        for k, v in env_vars.items():
            f.write(f"{k}={v}\n")

def update_config(profile_dir: Path, update: Dict[str, Any]):
    """Update a profile's config.yaml with nested keys."""
    config_path = profile_dir / "config.yaml"
    config = load_config(str(config_path))
    # Deep merge (simplified)
    for key, value in update.items():
        if isinstance(value, dict) and key in config:
            config[key].update(value)
        else:
            config[key] = value
    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)

# ---------- Profile Switching and Validation ----------
def switch_profile(profile_name: str) -> bool:
    """Switch to a profile by setting HERMES_HOME and validating provider."""
    profile_dir = PROFILES_DIR / profile_name
    if not profile_dir.exists():
        print(f"Profile '{profile_name}' not found.")
        return False
    
    # Set environment variable
    os.environ["HERMES_HOME"] = str(profile_dir)
    
    # Load config and run validation (from Exercise 1)
    from validate_provider import run_validation
    report = run_validation(verbose=False)
    
    if report["smoke_test"]["status"] == "passed":
        print(f"Switched to profile '{profile_name}' - provider OK.")
        return True
    else:
        print(f"Profile '{profile_name}' has issues:")
        print(json.dumps(report, indent=2))
        fix = input("Run configuration wizard? (y/n): ").strip().lower()
        if fix == "y":
            run_config_wizard(profile_name)
            return switch_profile(profile_name)  # Retry
        return False

def list_profiles() -> List[Dict[str, Any]]:
    """List all profiles with provider, model, and connection status."""
    profiles = []
    for profile_dir in PROFILES_DIR.iterdir():
        if not profile_dir.is_dir():
            continue
        config = load_config(str(profile_dir / "config.yaml"))
        provider = config.get("model", {}).get("provider", "unknown")
        model = config.get("model", {}).get("model", "default")
        # Check connection status (quick ping)
        status = "unconfigured"
        if provider != "unknown":
            # Use a lightweight connectivity check (simplified)
            from validate_provider import test_endpoint, get_base_url
            base_url = get_base_url(config, provider)
            if provider in ("lmstudio", "ollama"):
                from validate_provider import test_local_endpoint
                status = "verified" if test_local_endpoint(base_url) else "unreachable"
            else:
                status = "verified" if test_endpoint(base_url) else "unreachable"
        profiles.append({
            "name": profile_dir.name,
            "provider": provider,
            "model": model,
            "status": status
        })
    return profiles

# ---------- Cross-Profile Provider Locking ----------
def acquire_provider_lock(profile_name: str, provider: str, base_url: str,
                          timeout_minutes: int = 5) -> bool:
    """Acquire a file lock for a local provider to prevent concurrent use."""
    lock_dir = LOCKS_DIR
    lock_dir.mkdir(parents=True, exist_ok=True)
    lock_file = lock_dir / f"{provider}_{base_url.replace('://','_').replace(':','_')}.lock"
    lock = filelock.FileLock(str(lock_file), timeout=0)
    try:
        lock.acquire(timeout=0)
        # Write owner info
        with open(lock_file, "w") as f:
            f.write(f"{profile_name}\n{time.time()}")
        return True
    except filelock.Timeout:
        # Check if stale
        if lock_file.exists():
            with open(lock_file) as f:
                owner, timestamp = f.read().strip().split("\n")
                if time.time() - float(timestamp) > timeout_minutes * 60:
                    # Stale lock, release and retry
                    lock.release()
                    return acquire_provider_lock(profile_name, provider, base_url, timeout_minutes)
        print(f"Provider {provider} at {base_url} is locked by profile '{owner}'")
        return False

def release_provider_lock(profile_name: str, provider: str, base_url: str):
    """Release a provider lock."""
    lock_dir = LOCKS_DIR
    lock_file = lock_dir / f"{provider}_{base_url.replace('://','_').replace(':','_')}.lock"
    lock = filelock.FileLock(str(lock_file))
    lock.release()
    if lock_file.exists():
        lock_file.unlink()

def providers_status() -> List[Dict[str, Any]]:
    """Show all active provider locks."""
    locks = []
    for lock_file in LOCKS_DIR.glob("*.lock"):
        with open(lock_file) as f:
            owner, timestamp = f.read().strip().split("\n")
        locks.append({
            "provider": lock_file.stem.split("_")[0],
            "base_url": lock_file.stem.split("_", 1)[1].replace("_", "://", 1).replace("_", ":"),
            "owner": owner,
            "held_since": time.ctime(float(timestamp))
        })
    return locks

# ---------- Configuration Migration ----------
def migrate_profile(profile_dir: Path):
    """Migrate an outdated profile configuration to the current version."""
    config_path = profile_dir / "config.yaml"
    config = load_config(str(config_path))
    current_version = _config_version
    profile_version = config.get("_config_version", 0)
    
    if profile_version >= current_version:
        return
    
    print(f"Migrating profile '{profile_dir.name}' from version {profile_version} to {current_version}")
    confirm = input("Proceed? (y/n): ").strip().lower()
    if confirm != "y":
        return
    
    # Backup
    backup_path = config_path.with_suffix(".yaml.bak")
    shutil.copy(config_path, backup_path)
    
    try:
        # Example migration: rename old provider keys
        if profile_version < 2:
            if "old_provider" in config:
                config["model"]["provider"] = config.pop("old_provider")
        if profile_version < 3:
            # Move API keys from config to .env
            if "api_key" in config.get("model", {}):
                save_env_var(profile_dir, "API_KEY", config["model"].pop("api_key"))
        config["_config_version"] = current_version
        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)
        print("Migration successful.")
    except Exception as e:
        # Rollback
        shutil.copy(backup_path, config_path)
        print(f"Migration failed, rolled back: {e}")

# ---------- Main CLI ----------
if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: profile_manager.py <command> [args]")
        print("Commands: create, switch, list, wizard, migrate, locks")
        sys.exit(1)
    command = sys.argv[1]
    if command == "create":
        name = sys.argv[2]
        base = sys.argv[3] if len(sys.argv) > 3 else None
        create_profile(name, base)
    elif command == "switch":
        switch_profile(sys.argv[2])
    elif command == "list":
        for p in list_profiles():
            print(f"{p['name']}: {p['provider']} ({p['status']})")
    elif command == "wizard":
        run_config_wizard(sys.argv[2])
    elif command == "migrate":
        migrate_profile(PROFILES_DIR / sys.argv[2])
    elif command == "locks":
        for l in providers_status():
            print(f"{l['provider']} at {l['base_url']} held by {l['owner']} since {l['held_since']}")

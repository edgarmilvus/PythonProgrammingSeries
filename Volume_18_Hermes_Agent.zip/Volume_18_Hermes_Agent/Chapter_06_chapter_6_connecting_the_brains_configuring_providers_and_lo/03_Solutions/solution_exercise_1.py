
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

#!/usr/bin/env python3
"""
validate_provider.py - Provider validation harness for Hermes Agent.
Usage: python validate_provider.py [--verbose]
"""
import os
import sys
import json
import time
import requests
from pathlib import Path
from typing import Dict, Any, List, Optional

# Import Hermes Agent internals (assumed installed)
from hermes_cli.config import load_config, DEFAULT_CONFIG, OPTIONAL_ENV_VARS
from hermes_cli.env_loader import load_env_file
from hermes_core.agent import AIAgent
from hermes_core.providers import resolve_provider, ProviderType

# ---------- Configuration Loading ----------
def load_user_config() -> Dict[str, Any]:
    """Load the user's configuration from ~/.hermes/config.yaml."""
    config_path = Path.home() / ".hermes" / "config.yaml"
    if not config_path.exists():
        print("ERROR: No configuration file found at ~/.hermes/config.yaml")
        sys.exit(1)
    config = load_config(str(config_path))
    return config

def resolve_provider_type(config: Dict[str, Any]) -> str:
    """Resolve the provider string to a concrete type, handling 'auto'."""
    provider = config.get("model", {}).get("provider", "auto")
    if provider == "auto":
        # Replicate auto-detection logic: check each provider's required env vars
        available = []
        for ptype in ProviderType:
            if ptype.required_env_vars and all(
                os.getenv(var) for var in ptype.required_env_vars
            ):
                available.append(ptype.name)
        if not available:
            print("ERROR: No provider available. Set required environment variables.")
            sys.exit(1)
        # Return the first available (could be ranked)
        provider = available[0]
    return provider

# ---------- Credential Verification ----------
def verify_credentials(provider: str) -> Dict[str, bool]:
    """Check required environment variables for a given provider."""
    required_vars = OPTIONAL_ENV_VARS.get(provider, [])
    results = {}
    for var in required_vars:
        results[var] = os.getenv(var) is not None
    return results

# ---------- Endpoint Connectivity ----------
def get_base_url(config: Dict[str, Any], provider: str) -> str:
    """Get base URL from config or fallback to default for provider."""
    base_url = config.get("model", {}).get("base_url")
    if base_url:
        return base_url
    # Defaults for known providers (simplified)
    defaults = {
        "anthropic": "https://api.anthropic.com",
        "openrouter": "https://openrouter.ai/api/v1",
        "gemini": "https://generativelanguage.googleapis.com/v1beta",
        "lmstudio": "http://localhost:1234/v1",
        "ollama": "http://localhost:11434/v1",
    }
    return defaults.get(provider, "")

def test_endpoint(base_url: str, timeout: int = 10) -> bool:
    """Test connectivity to the provider endpoint."""
    try:
        resp = requests.get(base_url, timeout=timeout)
        return resp.status_code < 500  # Accept any response except server errors
    except requests.RequestException:
        return False

def test_local_endpoint(base_url: str) -> bool:
    """Test local provider (LM Studio, Ollama) with longer timeout and model list check."""
    try:
        resp = requests.get(f"{base_url}/models", timeout=30)
        if resp.status_code == 200:
            data = resp.json()
            return "data" in data  # OpenAI-compatible model list
        return False
    except:
        return False

# ---------- Minimal Inference Smoke Test ----------
def smoke_test(config: Dict[str, Any], provider: str) -> Dict[str, Any]:
    """Perform a minimal inference call using the Hermes AIAgent."""
    try:
        agent = AIAgent(config=config, provider=provider)
        response = agent.chat("Respond with the word 'OK' only")
        success = "OK" in response.strip().upper()
        status = "passed" if success else "unexpected_response"
        return {"status": status, "response": response}
    except Exception as e:
        error_msg = str(e)
        # Classify error types
        if "401" in error_msg or "403" in error_msg:
            status = "authentication_failure"
        elif "429" in error_msg:
            status = "rate_limited"
        elif "404" in error_msg:
            status = "model_unavailable"
        elif "timeout" in error_msg.lower():
            status = "timeout"
        else:
            status = "unknown_error"
        return {"status": status, "error": error_msg}

# ---------- Main Validation Harness ----------
def run_validation(verbose: bool = False) -> Dict[str, Any]:
    """Run full validation and return structured JSON report."""
    report = {"timestamp": time.time(), "provider_resolution": None,
              "credentials": {}, "connectivity": None, "smoke_test": None}
    
    # Load config
    config = load_user_config()
    provider = resolve_provider_type(config)
    report["provider_resolution"] = {"resolved_provider": provider}
    
    # Load environment (from ~/.hermes/.env)
    env_path = Path.home() / ".hermes" / ".env"
    if env_path.exists():
        load_env_file(str(env_path))
    
    # Credentials
    creds = verify_credentials(provider)
    report["credentials"] = creds
    if verbose:
        print("Credentials check:")
        for var, present in creds.items():
            print(f"  {var}: {'✓' if present else '✗'}")
    
    # Connectivity
    base_url = get_base_url(config, provider)
    if provider in ("lmstudio", "ollama"):
        conn_ok = test_local_endpoint(base_url)
        timeout_used = 30
    else:
        conn_ok = test_endpoint(base_url, timeout=10)
        timeout_used = 10
    report["connectivity"] = {"base_url": base_url, "reachable": conn_ok,
                              "timeout_seconds": timeout_used}
    if verbose:
        print(f"Endpoint {base_url}: {'reachable' if conn_ok else 'unreachable'}")
    
    # Smoke test (only if connectivity and credentials ok)
    if conn_ok and all(creds.values()):
        smoke = smoke_test(config, provider)
        report["smoke_test"] = smoke
        if verbose:
            print(f"Smoke test: {smoke['status']}")
    else:
        report["smoke_test"] = {"status": "skipped", "reason": "prerequisites not met"}
    
    return report

def print_report(report: Dict[str, Any]):
    """Pretty-print the JSON report."""
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    verbose = "--verbose" in sys.argv
    report = run_validation(verbose=verbose)
    print_report(report)

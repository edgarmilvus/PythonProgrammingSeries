
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script_part2.py
# Description: Advanced Integration Script
# ==========================================

# --- Tool Definitions ---
# This section mirrors the pattern in tools/*.py files

def setup_custom_tools():
    """Register custom tools for our integration script."""
    
    # Tool 1: remember_fact
    # This tool allows the agent to store a fact in our persistent memory.
    def remember_fact_handler(args: Dict[str, Any], **kwargs) -> str:
        """Handler for the remember_fact tool."""
        fact = args.get("fact", "")
        category = args.get("category", "general")
        if not fact:
            return json.dumps({"error": "No fact provided."})
        
        # Store in our custom memory system (will be defined later)
        memory_manager = kwargs.get('memory_manager')
        if memory_manager:
            memory_manager.store_fact(fact, category)
            return json.dumps({"success": True, "message": f"Fact '{fact[:50]}...' stored in category '{category}'."})
        else:
            return json.dumps({"error": "Memory manager not available."})
    
    # Register the tool with the global registry
    registry.register(
        name="remember_fact",
        toolset="custom_integration",
        schema={
            "name": "remember_fact",
            "description": "Store an important fact or piece of information in the agent's long-term memory. Use this to remember user preferences, project details, or key findings.",
            "parameters": {
                "type": "object",
                "properties": {
                    "fact": {
                        "type": "string",
                        "description": "The fact or information to remember."
                    },
                    "category": {
                        "type": "string",
                        "description": "A category for the fact (e.g., 'user_preference', 'project_detail', 'research_finding').",
                        "enum": ["user_preference", "project_detail", "research_finding", "general"]
                    }
                },
                "required": ["fact"]
            }
        },
        handler=lambda args, **kw: remember_fact_handler(args, memory_manager=kw.get('memory_manager')),
        check_fn=lambda: True,  # Always available
        requires_env=[],
    )
    
    # Tool 2: recall_facts
    # This tool allows the agent to search its memory for relevant facts.
    def recall_facts_handler(args: Dict[str, Any], **kwargs) -> str:
        """Handler for the recall_facts tool."""
        query = args.get("query", "")
        category = args.get("category", None)
        
        memory_manager = kwargs.get('memory_manager')
        if not memory_manager:
            return json.dumps({"error": "Memory manager not available."})
        
        results = memory_manager.search_facts(query, category)
        if results:
            return json.dumps({"success": True, "facts": results})
        else:
            return json.dumps({"success": True, "facts": [], "message": "No matching facts found."})
    
    registry.register(
        name="recall_facts",
        toolset="custom_integration",
        schema={
            "name": "recall_facts",
            "description": "Search the agent's long-term memory for facts related to a query. Use this to remember previous interactions, user details, or project context.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "The search query to find relevant facts."
                    },
                    "category": {
                        "type": "string",
                        "description": "Optional category to filter the search (e.g., 'user_preference', 'project_detail').",
                        "enum": ["user_preference", "project_detail", "research_finding", "general", None]
                    }
                },
                "required": ["query"]
            }
        },
        handler=lambda args, **kw: recall_facts_handler(args, memory_manager=kw.get('memory_manager')),
        check_fn=lambda: True,
        requires_env=[],
    )
    
    logger.info("Custom tools 'remember_fact' and 'recall_facts' registered.")

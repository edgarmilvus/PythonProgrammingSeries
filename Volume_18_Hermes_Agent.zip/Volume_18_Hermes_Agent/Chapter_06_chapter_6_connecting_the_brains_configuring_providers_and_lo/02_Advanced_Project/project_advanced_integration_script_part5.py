
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script_part5.py
# Description: Advanced Integration Script
# ==========================================

# --- Agent Factory ---
# The core orchestrator that creates and manages AIAgent instances.

class AgentFactory:
    """Factory for creating and managing AIAgent instances with dynamic model selection."""
    
    def __init__(self, config: AppConfig):
        self.config = config
        self.memory_manager = MemoryManager(config.memory_db_path)
        self.performance_log: List[Dict[str, Any]] = []
        self._setup_logging()
        logger.info("Agent Factory initialized.")
    
    def _setup_logging(self):
        """Set up file logging for agent sessions."""
        log_path = Path(self.config.log_dir).expanduser()
        log_path.mkdir(parents=True, exist_ok=True)
        # File handler for session logs
        file_handler = logging.FileHandler(log_path / "agent_sessions.log")
        file_handler.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        # Add to our logger
        logger.addHandler(file_handler)
    
    def _select_provider(self, task: str) -> str:
        """Route the task to the best provider based on complexity analysis.
        
        This is the Model Router from our architecture diagram.
        """
        # Simple heuristic: if the task is long or complex, use the cloud model
        task_length = len(task)
        has_complex_keywords = any(kw in task.lower() for kw in [
            "analyze", "compare", "explain in detail", "comprehensive", 
            "research", "write a long", "code review", "debug"
        ])
        
        if task_length > 500 or has_complex_keywords:
            logger.info(f"Task '{task[:50]}...' routed to CLOUD provider (length={task_length}, complex={has_complex_keywords})")
            return "cloud"
        else:
            logger.info(f"Task '{task[:50]}...' routed to LOCAL provider (length={task_length}, complex={has_complex_keywords})")
            return "local"
    
    def _build_system_prompt(self, task: str) -> str:
        """Build a comprehensive system prompt that includes persistent memory."""
        memory_context = self.memory_manager.get_context_summary(max_chars=1500)
        
        system_prompt = f"""You are an advanced AI assistant with persistent memory. Your capabilities include:

1. **Reasoning:** Use your knowledge to analyze and solve problems.
2. **Memory:** You have access to a long-term memory system. Use the `remember_fact` tool to store important information and `recall_facts` to retrieve it.
3. **Adaptability:** Your underlying model may change between sessions. Always focus on the current task.

**Current Context from Persistent Memory:**
{memory_context}

**Instructions:**
- Be concise and accurate.
- If you need to remember something for later, use the `remember_fact` tool.
- Before answering, check your memory with `recall_facts` if the task seems related to past interactions.
- Today's task is: {task}
"""
        return system_prompt
    
    def create_agent(self, task: str) -> AIAgent:
        """Create and configure an AIAgent instance for the given task."""
        provider_key = self._select_provider(task)
        provider_config = self.config.providers[provider_key]
        
        logger.info(f"Creating AIAgent with provider '{provider_config.name}' ({provider_config.model})")
        
        # Build the system prompt with memory context
        system_prompt = self._build_system_prompt(task)
        
        # Get tool definitions from the registry
        # We need to filter to only our custom tools for this example
        all_tools = registry.get_definitions(set(), quiet=True)
        # In a real scenario, we would filter based on enabled_toolsets
        
        # Create the AIAgent instance
        # This mirrors how the Hermes CLI creates agents in cli.py
        agent = AIAgent(
            base_url=provider_config.base_url,
            api_key=provider_config.api_key,
            provider=provider_config.provider_type,
            model=provider_config.model,
            max_iterations=30,  # Limit tool calls for cost control
            enabled_toolsets=["custom_integration"],  # Only our custom tools
            quiet_mode=True,
            save_trajectories=False,
            platform="integration_script",
        )
        
        # Inject our custom system prompt and memory manager
        # In the real Hermes Agent, this is done via the agent's internal state
        # For our integration, we'll pass the memory_manager via a custom attribute
        agent.custom_memory_manager = self.memory_manager
        agent.custom_system_prompt = system_prompt
        
        logger.info(f"Agent created successfully with session ID: {agent.session_id}")
        return agent
    
    def run_agent_task(self, task: str) -> Tuple[str, Dict[str, Any]]:
        """Execute an agent task and return the result along with performance metrics."""
        start_time = time.time()
        agent = self.create_agent(task)
        
        try:
            # Override the agent's system prompt
            # In the real codebase, this would be done by modifying the agent's
            # conversation history before the first turn.
            # For our integration, we pass it as a prefill message.
            prefill_messages = [
                {"role": "system", "content": agent.custom_system_prompt}
            ]
            
            # Run the conversation
            # The run_conversation method is the main entry point
            result = agent.run_conversation(
                user_message=task,
                system_message=agent.custom_system_prompt,
            )
            
            end_time = time.time()
            duration = end_time - start_time
            
            # Collect performance metrics
            metrics = {
                "task": task[:100],
                "provider": agent.provider,
                "model": agent.model,
                "duration_seconds": duration,
                "success": "error" not in result.get("final_response", "").lower(),
                "tool_calls": len(result.get("messages", [])),  # Rough estimate
            }
            
            self.performance_log.append(metrics)
            self._log_performance(metrics)
            
            return result.get("final_response", ""), metrics
        
        except Exception as e:
            logger.exception(f"Agent task failed: {e}")
            return f"Error: {str(e)}", {"error": str(e), "success": False}
    
    def _log_performance(self, metrics: Dict[str, Any]):
        """Log performance metrics and update the learning loop."""
        logger.info(f"Task Performance: {json.dumps(metrics, indent=2)}")
        
        # Closed Learning Loop: Update routing logic based on performance
        # This is a simplified version; a real implementation would use ML
        if not metrics.get("success", True):
            logger.warning("Task failed. Consider adjusting routing logic.")
            # In a real system, we would penalize the current provider for similar tasks

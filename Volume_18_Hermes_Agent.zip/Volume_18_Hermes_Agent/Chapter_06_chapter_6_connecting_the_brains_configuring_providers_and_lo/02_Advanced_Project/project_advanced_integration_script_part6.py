
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script_part6.py
# Description: Advanced Integration Script
# ==========================================

# --- Main Execution ---

def main():
    """Main entry point for the integration script."""
    print("=" * 60)
    print("Hermes Agent Advanced Integration Script")
    print("Demonstrating Dynamic Model Selection and Persistent Memory")
    print("=" * 60)
    
    # 1. Load configuration
    config = load_app_config()
    
    # 2. Verify API keys are set
    if not config.providers["cloud"].api_key:
        logger.warning("CLOUD_API_KEY not set. Cloud provider will fail.")
        print("WARNING: CLOUD_API_KEY environment variable not set.")
        print("Cloud-based tasks will fail. Set it to proceed.")
    
    # 3. Setup custom tools in the global registry
    setup_custom_tools()
    
    # 4. Create the Agent Factory
    factory = AgentFactory(config)
    
    # 5. Run Task 1: A simple task routed to the local model
    print("\n" + "-" * 40)
    print("TASK 1: Simple Fact Storage")
    print("This task should be routed to the LOCAL model (Ollama).")
    print("-" * 40)
    
    task1 = "Remember that my favorite color is blue and I prefer concise answers."
    response1, metrics1 = factory.run_agent_task(task1)
    print(f"Agent Response: {response1[:200]}...")
    print(f"Metrics: {json.dumps(metrics1, indent=2)}")
    
    # 6. Run Task 2: A complex task routed to the cloud model
    print("\n" + "-" * 40)
    print("TASK 2: Complex Analysis")
    print("This task should be routed to the CLOUD model (Claude).")
    print("-" * 40)
    
    task2 = "Analyze the pros and cons of using local vs cloud-based LLMs for an autonomous coding agent. Consider cost, latency, privacy, and capability. Provide a detailed comparison."
    response2, metrics2 = factory.run_agent_task(task2)
    print(f"Agent Response: {response2[:200]}...")
    print(f"Metrics: {json.dumps(metrics2, indent=2)}")
    
    # 7. Run Task 3: A task that should recall memory from Task 1
    print("\n" + "-" * 40)
    print("TASK 3: Memory Recall")
    print("This task tests if the agent can recall the fact stored in Task 1.")
    print("-" * 40)
    
    task3 = "What do you know about my preferences? Check your memory."
    response3, metrics3 = factory.run_agent_task(task3)
    print(f"Agent Response: {response3[:300]}...")
    print(f"Metrics: {json.dumps(metrics3, indent=2)}")
    
    # 8. Print Performance Summary
    print("\n" + "=" * 60)
    print("PERFORMANCE SUMMARY")
    print("=" * 60)
    for i, perf in enumerate(factory.performance_log):
        print(f"  Task {i+1}: {perf['task'][:50]}... -> Provider: {perf['provider']}, Success: {perf['success']}, Duration: {perf['duration_seconds']:.2f}s")
    
    print("\nIntegration script completed successfully.")
    print(f"Memory database stored at: {config.memory_db_path}")
    print(f"Session logs stored at: {config.log_dir}")

if __name__ == "__main__":
    main()

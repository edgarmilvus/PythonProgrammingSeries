
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script_part3.py
# Description: Advanced Integration Script
# ==========================================

# --- Memory Manager ---
# This implements a simple persistent memory system, inspired by the memory config.

class MemoryManager:
    """Manages persistent memory using SQLite for fact storage and retrieval."""
    
    def __init__(self, db_path: str):
        self.db_path = Path(db_path).expanduser()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()
        logger.info(f"Memory Manager initialized at {self.db_path}")
    
    def _init_db(self):
        """Initialize the SQLite database and create the facts table."""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS facts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL DEFAULT 'general',
                fact TEXT NOT NULL,
                timestamp REAL NOT NULL,
                access_count INTEGER DEFAULT 0
            )
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_facts_category ON facts (category)
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_facts_timestamp ON facts (timestamp)
        """)
        conn.commit()
        conn.close()
    
    def store_fact(self, fact: str, category: str = "general") -> int:
        """Store a new fact in the database."""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO facts (category, fact, timestamp) VALUES (?, ?, ?)",
            (category, fact, time.time())
        )
        fact_id = cursor.lastrowid
        conn.commit()
        conn.close()
        logger.debug(f"Stored fact ID {fact_id} in category '{category}'")
        return fact_id
    
    def search_facts(self, query: str, category: Optional[str] = None, limit: int = 10) -> List[Dict[str, Any]]:
        """Search for facts using a simple LIKE query."""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        if category:
            cursor.execute(
                "SELECT id, category, fact, timestamp, access_count FROM facts WHERE category = ? AND fact LIKE ? ORDER BY timestamp DESC LIMIT ?",
                (category, f'%{query}%', limit)
            )
        else:
            cursor.execute(
                "SELECT id, category, fact, timestamp, access_count FROM facts WHERE fact LIKE ? ORDER BY timestamp DESC LIMIT ?",
                (f'%{query}%', limit)
            )
        
        rows = cursor.fetchall()
        conn.close()
        
        results = []
        for row in rows:
            results.append({
                "id": row[0],
                "category": row[1],
                "fact": row[2],
                "timestamp": row[3],
                "access_count": row[4]
            })
        
        # Update access counts for retrieved facts
        self._increment_access_counts([r["id"] for r in results])
        
        return results
    
    def _increment_access_counts(self, fact_ids: List[int]):
        """Increment the access count for a list of fact IDs."""
        if not fact_ids:
            return
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        placeholders = ','.join('?' * len(fact_ids))
        cursor.execute(
            f"UPDATE facts SET access_count = access_count + 1 WHERE id IN ({placeholders})",
            fact_ids
        )
        conn.commit()
        conn.close()
    
    def get_context_summary(self, max_chars: int = 2000) -> str:
        """Generate a text summary of recent and important facts for injection into the system prompt."""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        # Get the most recent and most accessed facts
        cursor.execute("""
            SELECT category, fact, timestamp, access_count FROM facts 
            ORDER BY access_count DESC, timestamp DESC 
            LIMIT 20
        """)
        rows = cursor.fetchall()
        conn.close()
        
        if not rows:
            return "No persistent memories yet."
        
        summary_parts = []
        current_chars = 0
        for row in rows:
            entry = f"[{row[0]}] {row[1][:200]}"
            if current_chars + len(entry) > max_chars:
                break
            summary_parts.append(entry)
            current_chars += len(entry)
        
        return "Persistent Memories:\n" + "\n".join(summary_parts)

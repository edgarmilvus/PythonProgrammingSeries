
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_library_implementation.py
# Description: Basic Library Implementation
# ==========================================

#!/usr/bin/env python3
"""
example_stateful_agent.py
A minimal example of a stateful AI agent using Hermes Agent's core classes.
This agent remembers user preferences and persists conversations to a local database.
"""

import os
import uuid
import logging
from datetime import datetime
from pathlib import Path

# --- Core Hermes imports ---
# The AIAgent class is the primary orchestrator for reasoning loops and tool calling.
from run_agent import AIAgent

# The SessionDB provides SQLite-backed persistent storage for conversation history.
# It supports FTS5 full-text search for cross-session recall.
from hermes_state import SessionDB

# MemoryStore is the built-in memory engine that saves facts to memory.md and user.md.
from tools.memory_tool import MemoryStore

# Utility to get the correct Hermes home directory (accounts for profiles).
from hermes_constants import get_hermes_home

# Configure logging to see agent internals (useful for debugging).
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# === Step 1: Define the working directory and database path ===
# Use the standard Hermes home directory for stateful data.
HERMES_HOME = get_hermes_home()
HERMES_HOME.mkdir(parents=True, exist_ok=True)

# The session database file stores all conversation turns.
SESSION_DB_PATH = HERMES_HOME / "sessions" / "stateful_example.db"
SESSION_DB_PATH.parent.mkdir(parents=True, exist_ok=True)

# === Step 2: Initialize the session database ===
# The SessionDB manages SQLite tables: sessions, messages, and FTS5 search index.
session_db = SessionDB(db_path=str(SESSION_DB_PATH))

# === Step 3: Initialize the memory store ===
# MemoryStore reads/writes facts to memory.md and user.md files.
# It is the agent's long-term memory for user-specific knowledge.
memory_store = MemoryStore(
    memory_char_limit=2200,  # Max characters for memory.md content.
    user_char_limit=1375     # Max characters for user.md content.
)

# Load any existing memory from disk (e.g., from a previous session).
memory_store.load_from_disk()

# === Step 4: Configure the AI Agent with stateful features ===
# The agent needs at least a model and an endpoint. We use environment variables
# for the API key and base URL to keep them out of the code.
# For this example, we configure the agent to use its own memory and session DB.

# Generate a unique session ID for this conversation.
session_id = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"

# Create the AIAgent instance.
# We pass our pre-configured memory store and session database.
agent = AIAgent(
    base_url=os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1"),
    api_key=os.getenv("OPENROUTER_API_KEY"),
    provider="openrouter",
    model="anthropic/claude-sonnet-4-6",  # Use a capable tool-calling model.
    max_iterations=45,                     # Allow enough tool calls for complex tasks.
    session_id=session_id,
    session_db=session_db,                 # Attach the SQLite session store.
    skip_memory=False,                     # Enable internal memory management.
    platform="cli",                        # Inform the agent this is a CLI session.
)

# Override the agent's internal memory store with our pre-loaded store.
# This ensures the agent sees any previously saved user facts.
agent._memory_store = memory_store
agent._memory_enabled = True              # Enable writing to memory.
agent._user_profile_enabled = True        # Enable reading/writing user profile.
agent._memory_nudge_interval = 5          # Nudge agent to review memory every N turns.
agent._skill_nudge_interval = 10          # Nudge agent to review skills every N tool iterations.

# === Step 5: Run a first conversation to remember a user preference ===
print("=" * 60)
print("STATEFUL AGENT EXAMPLE: FIRST CONVERSATION")
print("=" * 60)

first_user_message = "Hi! My name is Rachel. I prefer very concise answers."
print(f"\n[User]: {first_user_message}")

first_result = agent.run_conversation(
    user_message=first_user_message,
    task_id="example_task_1",  # Isolate VM/browser resources per task.
)

print(f"\n[Agent]: {first_result['final_response']}")
print(f"\n--- API calls used: {first_result['api_calls']} ---")

# === Step 6: Save the memory to disk (important for persistence) ===
# The agent's memory store is updated in-memory during the conversation.
# We must flush it to disk so it survives the program.
if agent._memory_store:
    agent._memory_store.save_to_disk()

# === Step 7: Run a second conversation to verify memory retrieval ===
print("\n" + "=" * 60)
print("STATEFUL AGENT EXAMPLE: SECOND CONVERSATION (Memory Recall)")
print("=" * 60)

second_user_message = "What's my name and what do I like?"
print(f"\n[User]: {second_user_message}")

# Create a new agent instance for the second turn to simulate a real
# multi-session scenario where the agent process may have been restarted.
# We reload the session database and memory store from disk.

# Reload the session DB (it persists across process restarts).
session_db2 = SessionDB(db_path=str(SESSION_DB_PATH))

# Reload the memory store from disk (the user.md file we saved earlier).
memory_store2 = MemoryStore(memory_char_limit=2200, user_char_limit=1375)
memory_store2.load_from_disk()

# Generate a new session ID for this turn. The session DB will link it
# to the previous session via lineage tracking.
session_id2 = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"

agent2 = AIAgent(
    base_url=os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1"),
    api_key=os.getenv("OPENROUTER_API_KEY"),
    provider="openrouter",
    model="anthropic/claude-sonnet-4-6",
    max_iterations=45,
    session_id=session_id2,
    session_db=session_db2,
    skip_memory=False,
    platform="cli",
)

agent2._memory_store = memory_store2
agent2._memory_enabled = True
agent2._user_profile_enabled = True
agent2._memory_nudge_interval = 5
agent2._skill_nudge_interval = 10

second_result = agent2.run_conversation(
    user_message=second_user_message,
    task_id="example_task_2",
)

print(f"\n[Agent]: {second_result['final_response']}")

if agent2._memory_store:
    agent2._memory_store.save_to_disk()

# === Step 8: Demonstrate cross-session FTS5 search ===
# The session database indexes every turn. We can search for "Rachel" to
# find the relevant conversation.
print("\n" + "=" * 60)
print("STATEFUL AGENT EXAMPLE: CROSS-SESSION SEARCH")
print("=" * 60)

search_results = session_db2.search_sessions("Rachel", limit=3)
print(f"\nFound {len(search_results)} session(s) containing 'Rachel':")
for idx, result in enumerate(search_results[:2]):
    print(f"  [{idx+1}] Session: {result.get('session_id', 'N/A')[:16]}...")
    # The search returns message snippets from the FTS5 index.
    snippet = result.get('snippet', '')
    print(f"      Snippet: {snippet[:120]}...")

# === Step 9: Cleanup agent resources ===
agent.release_clients()
agent2.release_clients()

print("\n" + "=" * 60)
print("EXAMPLE COMPLETE: Stateful agent demonstrated.")
print("=" * 60)

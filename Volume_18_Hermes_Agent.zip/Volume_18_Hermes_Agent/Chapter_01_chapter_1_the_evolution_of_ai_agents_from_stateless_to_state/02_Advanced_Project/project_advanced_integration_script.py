
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_integration_script.py
# Description: Advanced Integration Script
# ==========================================

#!/usr/bin/env python3
"""
Project Intelligence Hub – Advanced Integration of Hermes Agent

A self-improving AI agent that:
  - Accepts user research requests (e.g., "Compare open-source LLM fine-tuning frameworks").
  - Uses web search and file reading tools to gather data.
  - Delegates parallel sub-agents to analyze subtopics (e.g., cost, performance, ecosystem).
  - Writes a consolidated report to disk.
  - Memoizes user preferences (verbosity, format) across sessions via persistent memory.
  - Runs a background skill review to encode new techniques for future sessions.
  - Falls back to a secondary provider if the primary is rate-limited.

Dependencies: hermes-agent (>=0.45), openai, httpx, dotenv
"""
import json
import os
import time
from pathlib import Path
from typing import List, Dict, Any, Optional

# ---------------------------------------------------------------------------
# Core import: AIAgent – the stateful, self-improving agent from Hermes.
# We also import the delegate_task tool to spawn child agents.
# ---------------------------------------------------------------------------
from run_agent import AIAgent, IterationBudget
from tools.delegate_tool import delegate_task
from hermes_constants import get_hermes_home, display_hermes_home

# ---------------------------------------------------------------------------
# Tool registration – we create a custom "project_report" tool that writes
# structured markdown reports. All handlers must return JSON strings.
# ---------------------------------------------------------------------------
from tools.registry import registry
from tools.terminal_tool import _get_approval_callback, _set_approval_callback

def build_project_report(project_name: str, sections: Dict[str, str]) -> str:
    """Write a markdown report to the user's hermes home directory.

    Args:
        project_name: A short slug for the project (e.g. "llm-fine-tuning").
        sections: A dict mapping section titles to content.

    Returns:
        JSON: {"success": true, "path": "...", "message": "Report saved."}
    """
    report_dir = get_hermes_home() / "reports"
    report_dir.mkdir(parents=True, exist_ok=True)
    report_path = report_dir / f"{project_name.replace(' ', '_')}.md"

    with open(report_path, "w", encoding="utf-8") as f:
        f.write(f"# {project_name}\n\n")
        f.write(f"_Generated on {time.strftime('%Y-%m-%d %H:%M:%S')}_\n\n")
        for title, content in sections.items():
            f.write(f"## {title}\n\n{content}\n\n")

    return json.dumps({
        "success": True,
        "path": str(report_path),
        "message": f"Report saved to {report_path}"
    })

# Register the tool so it becomes available to the agent.
registry.register(
    name="project_report",
    toolset="custom",
    schema={
        "name": "project_report",
        "description": "Write a multi-section markdown report to disk.",
        "parameters": {
            "type": "object",
            "properties": {
                "project_name": {
                    "type": "string",
                    "description": "Name of the project (used as filename slug)"
                },
                "sections": {
                    "type": "object",
                    "description": "Key-value pairs of section title and markdown content",
                    "additionalProperties": {"type": "string"}
                }
            },
            "required": ["project_name", "sections"]
        }
    },
    handler=lambda args, **kw: build_project_report(
        project_name=args.get("project_name", "unnamed"),
        sections=args.get("sections", {})
    ),
    check_fn=lambda: True,  # Always available
)

# ---------------------------------------------------------------------------
# Memory and skill configuration – we enable persistent user profiles and
# automatic skill creation reminders.
# ---------------------------------------------------------------------------
MEMORY_CFG = {
    "memory_enabled": True,
    "user_profile_enabled": True,
    "nudge_interval": 3,          # Every 3 user turns, trigger memory review
}
SKILL_CFG = {
    "creation_nudge_interval": 5, # Every 5 tool-calling iterations, trigger skill review
}

# ---------------------------------------------------------------------------
# Provider fallback chain – if OpenRouter fails, try Anthropic directly.
# This is a production pattern for uptime.
# ---------------------------------------------------------------------------
FALLBACK_CHAIN = [
    {
        "provider": "anthropic",
        "model": "claude-3-5-sonnet-20241022",
        "base_url": "https://api.anthropic.com/v1",
        "key_env": "ANTHROPIC_API_KEY",
    },
]

# ---------------------------------------------------------------------------
# Credential pool – for OpenRouter with multiple keys (rotation on 429).
# ---------------------------------------------------------------------------
class SimpleCredentialPool:
    """Minimal pool that rotates credentials on exhaustion."""
    def __init__(self, entries: List[Dict]):
        self._entries = entries
        self._current = 0

    def has_available(self) -> bool:
        return any(e.get("active", True) for e in self._entries)

    def entries(self) -> List:
        return self._entries

    def mark_exhausted_and_rotate(self, **kwargs) -> Optional[Dict]:
        self._entries[self._current]["active"] = False
        self._current = (self._current + 1) % len(self._entries)
        if not self._entries[self._current].get("active", True):
            return None  # All exhausted
        return self._entries[self._current]

    def try_refresh_current(self) -> Optional[Dict]:
        # In a real setup, re-authenticate here.
        return None

# ---------------------------------------------------------------------------
# Main Research Agent Initialization
# ---------------------------------------------------------------------------
def create_research_agent() -> AIAgent:
    """
    Factory function that creates a fully configured AIAgent for the
    Project Intelligence Hub. Includes custom tools, memory, fallback chain,
    and a credential pool.

    Returns an AIAgent instance ready to call run_conversation().
    """
    # Read keys from environment (or your .env file)
    openrouter_key = os.environ.get("OPENROUTER_API_KEY", "")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "")

    # Set up a credential pool with two OpenRouter keys (if available)
    creds = []
    if openrouter_key:
        creds.append({"runtime_api_key": openrouter_key, "active": True})
    if anthropic_key:
        creds.append({"runtime_api_key": anthropic_key, "active": True, "runtime_base_url": "https://api.anthropic.com/v1"})
    pool = SimpleCredentialPool(creds) if creds else None

    # Configure enabled toolsets: everything except terminal (for safety) and
    # some heavy tools like image generation.
    enabled_toolsets = [
        "memory", "skills", "web", "search", "session_search",
        "file", "delegation", "todo", "cronjob", "custom"  # our custom toolset
    ]

    # Disable tools that are not needed or unsafe for this use case.
    disabled_toolsets = ["terminal", "browser", "vision", "tts"]

    agent = AIAgent(
        # Model & provider (primary)
        model="openai/gpt-4o-2024-11-20",
        provider="openrouter",
        base_url="https://openrouter.ai/api/v1",
        api_key=openrouter_key or "none",  # fallback will handle missing keys

        # Behavior
        max_iterations=30,                # Allow deep tool chains
        quiet_mode=False,                 # Show rich progress output
        save_trajectories=True,           # Save JSONL for debugging

        # Tools & memory
        enabled_toolsets=enabled_toolsets,
        disabled_toolsets=disabled_toolsets,
        skip_memory=False,

        # Platform identification (used in system prompt hints)
        platform="cli",

        # Fallback chain (list for multiple fallbacks)
        fallback_model=FALLBACK_CHAIN,

        # Credential pool for automatic rotation on 429s
        credential_pool=pool,

        # Explicit reasoning config (disabled for reliability)
        reasoning_config={"enabled": False},

        # Session-level settings
        skip_context_files=True,          # Don't load arbitrary AGENTS.md files
        load_soul_identity=False,         # Don't use SOUL.md – we set our own persona later
    )

    # Override default memory/skill intervals with our custom config.
    # (These are set in __init__ from config.yaml; we can patch them after creation.)
    agent._memory_nudge_interval = MEMORY_CFG["nudge_interval"]
    agent._skill_nudge_interval = SKILL_CFG["creation_nudge_interval"]

    return agent


# ---------------------------------------------------------------------------
# Core Workflow: Process a User Request with Delegation and Memory
# ---------------------------------------------------------------------------
def process_research_request(
    agent: AIAgent,
    user_query: str,
    conversation_history: Optional[List[Dict]] = None,
) -> Dict[str, Any]:
    """
    Run a research request through the agent, potentially delegating subtasks
    to parallel sub-agents and updating memory automatically.

    Args:
        agent: A configured AIAgent instance.
        user_query: The user's natural language request.
        conversation_history: Previous messages to continue a session.

    Returns:
        Dict with keys: final_response, messages, api_calls, completed, etc.
    """
    # -----------------------------------------------------------------------
    # Step 1: Pre-call hook – inject a system-level instruction that encourages
    # the agent to use delegation for complex multi-topic queries.
    # -----------------------------------------------------------------------
    # We use the ephemeral_system_prompt field, which is injected at API call
    # time only (not persisted to session DB), so it's safe for this turn.
    delegation_hint = (
        "If the request covers multiple independent topics, you may use "
        "delegate_task to spawn parallel sub-agents – one per topic – then "
        "merge their findings into a single report."
    )
    original_ephemeral = agent.ephemeral_system_prompt
    agent.ephemeral_system_prompt = (
        (original_ephemeral + "\n\n" + delegation_hint)
        if original_ephemeral else delegation_hint
    )

    # -----------------------------------------------------------------------
    # Step 2: Run the conversation. This is the heart of the integration.
    # The agent will use tools (web_search, read_file, project_report, etc.)
    # and may call delegate_task to spin off worker agents.
    # -----------------------------------------------------------------------
    result = agent.run_conversation(
        user_message=user_query,
        system_message=None,
        conversation_history=conversation_history,
        task_id=None,           # Auto-generate
        stream_callback=None,   # Set to a lambda for token-by-token display
    )

    # -----------------------------------------------------------------------
    # Step 3: After the turn, trigger a background memory/skill review.
    # This runs as a separate thread using a fork of the agent with reduced
    # iterations. It updates MEMORY.md, USER.md, and creates/patches skills.
    # -----------------------------------------------------------------------
    if result.get("final_response") and not result.get("interrupted"):
        try:
            agent._spawn_background_review(
                messages_snapshot=list(result["messages"]),
                review_memory=True,   # Based on nudge_interval
                review_skills=True,   # Based on skill_nudge_interval
            )
        except Exception as e:
            print(f"[Background review warning] {e}")

    # Restore ephemeral prompt for next turn
    agent.ephemeral_system_prompt = original_ephemeral

    return result


# ---------------------------------------------------------------------------
# Demonstration – Interactive Loop with Persistent Memory
# ---------------------------------------------------------------------------
def main():
    """
    Simulate a multi-session experience: the agent remembers user preferences
    from one conversation to the next because memory is stored on disk.
    """
    print("=" * 60)
    print("Project Intelligence Hub – Advanced Hermes Agent Integration")
    print("=" * 60)

    # -----------------------------------------------------------------------
    # Create the agent once; it will persist memory and skills across calls.
    # -----------------------------------------------------------------------
    agent = create_research_agent()

    # -----------------------------------------------------------------------
    # Simulate Session 1: User asks for a report, and the agent learns a
    # preference ("I prefer bullet-point summaries").
    # -----------------------------------------------------------------------
    query_1 = (
        "Compare the three most popular open-source LLM fine-tuning frameworks: "
        "Unsloth, Axolotl, and LLaMA-Factory. Focus on: "
        "(a) ease of setup, (b) supported hardware, (c) community size. "
        "Write a report to the 'projects' directory."
        " Also, please always format your answers as bullet-point summaries – "
        "I find them easiest to scan."
    )

    print("\n--- Session 1: Comparative Research ---")
    result_1 = process_research_request(agent, query_1)
    print(f"Response: {result_1['final_response'][:200]}...")
    print(f"API calls used: {result_1['api_calls']}")
    print(f"Messages in session: {len(result_1['messages'])}")

    # -----------------------------------------------------------------------
    # Simulate a break between sessions. The agent object is kept alive,
    # but memory is stored on disk and would survive a restart.
    # -----------------------------------------------------------------------
    print("\n--- Inter-session pause (memory persists) ---")

    # -----------------------------------------------------------------------
    # Session 2: New query on a different topic. The agent should recall the
    # user's preference for bullet points and apply it automatically.
    # -----------------------------------------------------------------------
    query_2 = (
        "Now research the current state of AI safety frameworks. "
        "Which organizations are leading? What regulatory efforts are underway?"
    )

    print("\n--- Session 2: Safety Research (with memory) ---")
    result_2 = process_research_request(agent, query_2)

    # Verify memory recall: check if the agent's response used bullet points.
    # This is not a strict test, but in practice the system prompt will include
    # the USER.md preference.
    response_2 = result_2.get("final_response", "")
    if "bullet" in response_2.lower() or response_2.count("- ") > 3:
        print("[Memory verification] Agent appears to have used bullet points – memory working.")
    else:
        print("[Memory verification] Bullet points not obvious – user preference may not have been triggered.")

    # -----------------------------------------------------------------------
    # Session 3: Ask for a report that requires sub-agent delegation.
    # -----------------------------------------------------------------------
    query_3 = (
        "I need a comprehensive comparison of vector databases: "
        "Pinecone, Weaviate, Qdrant, and Milvus. "
        "For each one, cover: pricing, indexing algorithm, cloud vs self-hosted, "
        "and integration with LangChain. "
        "Use delegate_task to analyze each database in parallel, "
        "then compile a single report."
    )

    print("\n--- Session 3: Parallel Delegation ---")
    result_3 = process_research_request(agent, query_3)
    print(f"Response (first 300 chars): {result_3['final_response'][:300]}...")
    print(f"API calls used: {result_3['api_calls']}")

    # -----------------------------------------------------------------------
    # Cleanup: close the agent to release resources (but memory stays on disk).
    # -----------------------------------------------------------------------
    agent.close()
    print("\n--- Done. Memory and skill updates are saved to disk. ---")


if __name__ == "__main__":
    main()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# test_session_persistence.py
import os
import tempfile
import threading
import time
import sys
sys.path.insert(0, os.path.expanduser("~/.hermes/hermes"))  # adjust as needed

from hermes_state import AIAgent, SessionDB, get_hermes_home, display_hermes_home

# Use a temporary directory for this test to avoid polluting real data
tmp_dir = tempfile.mkdtemp(prefix="hermes_test_")
hermes_home = os.path.join(tmp_dir, "hermes_home")
os.environ["HERMES_HOME"] = hermes_home  # override for the test
get_hermes_home.cache_clear()  # force re-evaluation

# Create the required subdirectories
os.makedirs(os.path.join(hermes_home, "sessions"), exist_ok=True)

print(f"Test Hermes home: {display_hermes_home()}")
session_id = "test_session_001"

# Helper to directly read DB contents
def read_session_db():
    db = SessionDB(get_hermes_home())
    session = db.get_session(session_id)
    messages = db.get_messages(session_id)
    db.close()
    return session, messages

# 1st turn – a simple query
print("\n=== Turn 1: Simple query ===")
agent = AIAgent(provider="openai", model="gpt-4o-mini", session_id=session_id)
agent.run_conversation("What is 2+2?")
agent._flush_messages_to_session_db()  # force flush
agent.close()

session, messages = read_session_db()
print(f"Session system_prompt: {session['system_prompt'][:50]}...")
print(f"Messages after turn 1: {len(messages)}")
assert messages[-1]["role"] == "assistant", "Last message should be assistant"
assert any(m["role"] == "user" for m in messages), "Should contain user message"

# 2nd turn – query that triggers a tool (long‑running terminal command)
print("\n=== Turn 2: Tool call with simulated interrupt ===")
agent = AIAgent(provider="openai", model="gpt-4o-mini", session_id=session_id)

# We will start the agent in a separate thread, and after 2s interrupt it
interrupted = threading.Event()

def agent_thread():
    try:
        # This will be interrupted while processing a tool
        agent.run_conversation("Run `sleep 10` in terminal")
    except Exception as e:
        print(f"Agent interrupted as expected: {e}")

t = threading.Thread(target=agent_thread, daemon=True)
t.start()

time.sleep(2)  # let agent start and receive tool call
agent.interrupt()  # simulate user interrupt
t.join(timeout=5)

# Now flush and read DB
agent._flush_messages_to_session_db()
agent.close()

session, messages = read_session_db()
print(f"Messages after interrupt: {len(messages)}")
# The last user message should be "Run `sleep 10` in terminal"
last_user = [m for m in messages if m["role"] == "user"][-1]
assert last_user["content"] == "Run `sleep 10` in terminal", "Last user message must be the tool query"
# Verify there is NO tool message without following assistant
tool_msgs = [m for m in messages if m["role"] == "tool"]
for tm in tool_msgs:
    # Find its index and check if next message is assistant
    idx = messages.index(tm)
    if idx+1 < len(messages):
        assert messages[idx+1]["role"] == "assistant", f"Tool message at {idx} must be followed by assistant"
print("Persistence invariant: no orphan tool messages.")

# 3rd turn – resume after interrupt
print("\n=== Turn 3: Resume conversation ===")
agent = AIAgent(provider="openai", model="gpt-4o-mini", session_id=session_id)
agent.run_conversation("Did you run that command?")
agent._flush_messages_to_session_db()
agent.close()

_, messages = read_session_db()
# Last message must be assistant
assert messages[-1]["role"] == "assistant"
# There should be at least 3 user messages now
user_messages = [m for m in messages if m["role"] == "user"]
assert len(user_messages) >= 3
print("Session resumed successfully. All checks passed.")

# Cleanup
import shutil
shutil.rmtree(tmp_dir)
print("Test completed and temporary files cleaned up.")

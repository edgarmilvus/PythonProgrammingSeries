
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# ~/.hermes/plugins/my_time/__init__.py
import json
from datetime import datetime
from zoneinfo import ZoneInfo, available_timezones

def register(ctx):
    """Register the get_time tool with the agent."""
    # Define JSON Schema for the tool
    schema = {
        "type": "object",
        "properties": {
            "timezone": {
                "type": "string",
                "description": "IANA timezone name",
                "enum": ["America/New_York", "Europe/London", "Asia/Tokyo", "UTC"]
            }
        },
        "required": ["timezone"]
    }

    def get_time_handler(args: dict) -> str:
        # Default to UTC if timezone missing
        tz_name = args.get("timezone", "UTC")
        # Validate timezone exists
        if tz_name not in available_timezones():
            return json.dumps({"error": f"Unknown timezone: {tz_name}"})
        # Read format from plugin config (optional)
        # In real scenario ctx.config would be the parsed YAML
        time_format = ctx.config.get("plugins.my_time.format", "24h")
        now = datetime.now(ZoneInfo(tz_name))
        if time_format == "12h":
            formatted = now.strftime("%Y-%m-%d %I:%M:%S %p %Z")
        else:
            formatted = now.strftime("%Y-%m-%d %H:%M:%S %Z")
        return json.dumps({"time": formatted, "timezone": tz_name})

    # Register the tool
    ctx.register_tool(
        name="get_time",
        description="Get the current time in a specified timezone.",
        parameters=schema,
        handler=get_time_handler
    )

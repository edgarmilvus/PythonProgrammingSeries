
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_8.py
# Description: Solution for Exercise 8
# ==========================================

# test_custom_curator.py
import os
import tempfile
import shutil
from datetime import datetime, timedelta
import time
import sys
sys.path.insert(0, os.path.expanduser("~/.hermes/hermes"))

from hermes_state import AIAgent, load_config, get_hermes_home
from hermes_state.plugins import PluginManager

# Create temporary Hermes home
tmp_dir = tempfile.mkdtemp(prefix="hermes_curator_test_")
hermes_home = os.path.join(tmp_dir, "hermes_home")
os.environ["HERMES_HOME"] = hermes_home

# Create required directories
os.makedirs(os.path.join(hermes_home, "skills"), exist_ok=True)
os.makedirs(os.path.join(hermes_home, "plugins"), exist_ok=True)

# Create a dummy skill that is eligible for archiving (stale for 31 days)
skill_dir = os.path.join(hermes_home, "skills", "demo")
os.makedirs(skill_dir, exist_ok=True)
skill_meta = {
    "created_by": "agent",
    "last_activity_at": (datetime.utcnow() - timedelta(days=31)).isoformat(),
    "pinned": False  # ensure not pinned
}
with open(os.path.join(skill_dir, "metadata.json"), "w") as f:
    json.dump(skill_meta, f)
# Dummy skill file
with open(os.path.join(skill_dir, "skill.py"), "w") as f:
    f.write("# dummy skill content\n")

# Copy the archive_notifier plugin into temp plugins dir
plugin_src = os.path.expanduser("~/.hermes/plugins/archive_notifier")
plugin_dst = os.path.join(hermes_home, "plugins", "archive_notifier")
shutil.copytree(plugin_src, plugin_dst)

# Prepare status callback
status_events = []
def status_callback(event):
    status_events.append(event)

# Create agent with custom curator config
config = {
    **load_config(),  # load base config
    "curator": {
        "enabled": True,
        "interval_hours": 4,
        "stale_after_days": 30,
        "archive_after_days": 0
    }
}
agent = AIAgent(provider="openai", model="gpt-4o-mini", config=config, plugins_dir=hermes_home+"/plugins")
agent.status_callback = status_callback

# Manually trigger curator by calling _spawn_background_review with review_skills=True
agent._spawn_background_review(review_skills=True, force=True)

# Wait a bit for async review to complete
time.sleep(2)

# Check that the background review agent called skill_manage with action archive
# We can inspect the agent's conversation history from the review (simplified)
# In practice, the curator uses a separate agent, but we can observe via status_events
archive_notifications = [e for e in status_events if "archived" in e.get("message", "").lower()]
assert len(archive_notifications) > 0, "Should have received archive notification"
print("Archive notification captured:", archive_notifications[0])

# Also check that the skill file has been archived (moved to archived folder)
archived_dir = os.path.join(hermes_home, "skills", "archived")
if os.path.exists(archived_dir):
    archived_items = os.listdir(archived_dir)
    assert "demo" in archived_items, "Skill should have been archived"
    print(f"Skill demo moved to {archived_dir}")

# Clean up
agent.shutdown_memory_provider()
agent.close()
shutil.rmtree(tmp_dir)
print("Test passed.")

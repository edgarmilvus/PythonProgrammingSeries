
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# test_my_time_plugin.py
import sys
import os
sys.path.insert(0, os.path.expanduser("~/.hermes/hermes"))
from hermes_state import AIAgent

agent = AIAgent(provider="openai", model="gpt-4o-mini", plugins_dir="~/.hermes/plugins")
# Verify tool is discovered
tool_names = [t["function"]["name"] for t in agent.tools]
assert "get_time" in tool_names, "get_time tool not found"
print("Plugin tool 'get_time' is visible.")

# Execute the tool (requires a model that can call it, but we can test handler directly)
from hermes_state.plugins import get_plugin_context
handler = get_plugin_context("my_time").handlers["get_time"]
result = handler({"timezone": "America/New_York"})
print("Tool result:", result)
import json
data = json.loads(result)
assert "time" in data and "timezone" in data
print("Test passed.")

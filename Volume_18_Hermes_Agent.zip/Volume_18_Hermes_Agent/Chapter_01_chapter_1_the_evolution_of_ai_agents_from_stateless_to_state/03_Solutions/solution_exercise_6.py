
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_6.py
# Description: Solution for Exercise 6
# ==========================================

# test_camel_case_fix.py
import sys, os
sys.path.insert(0, os.path.expanduser("~/.hermes/hermes"))
from hermes_state import AIAgent, PluginManager
from unittest.mock import Mock, patch

# Create a mock agent with a known set of valid tool names
mock_agent = Mock()
mock_agent.valid_tool_names = {"todo_tool", "patch_tool", "browser_click", "get_time"}

# Manually load the plugin context with the mock agent
from hermes_state.plugins import PluginContext
ctx = PluginContext(mock_agent, config={})
register(ctx)  # our plugin's register function

# Simulate a tool call with CamelCase name
hook_fn = ctx.hooks["pre_tool_call"][0]  # there should be one hook registered
result = hook_fn("TodoTool", {"task": "finish"})
assert result is not None
assert result["tool_name"] == "todo_tool"
print(f"TodoTool -> {result['tool_name']}")

# Test with trailing _Tool
result = hook_fn("BrowserClickTool", {"url": "http://example.com"})
assert result is not None
assert result["tool_name"] == "browser_click"
print(f"BrowserClickTool -> {result['tool_name']}")

# Test with a name that doesn't need fixing (already snake_case)
result = hook_fn("patch_tool", {})
assert result is None  # no change needed, return None to let normal flow continue
print("Already snake_case: unchanged")

# Test integration with _execute_tool_calls_sequential
# We patch the agent's _execute_tool_calls_sequential to see what tool name is passed
original_exec = mock_agent._execute_tool_calls_sequential

def tracked_exec(messages, handle_function_call):
    # We'll capture the tool name passed to handle_function_call
    def recording_handler(func_name, args, call_id):
        print(f"handle_function_call received func_name: {func_name}")
        recorded_names.append(func_name)
        return "OK"
    recorded_names = []
    for msg in messages:
        for tc in msg.get("tool_calls", []):
            recording_handler(tc["function"]["name"], {}, tc["id"])
    return recorded_names

# Simulate a fake assistant message with a CamelCase tool call
fake_message = {
    "role": "assistant",
    "tool_calls": [{
        "id": "call_1",
        "type": "function",
        "function": {"name": "TodoTool", "arguments": "{}"}
    }]
}

# In a real plugin, the hook would be called inside _execute_tool_calls_sequential
# before the tool is dispatched. We test by manually invoking the hook chain.
names = []
def mock_handle(func_name, *args):
    names.append(func_name)
    return "mock result"

# We'll simulate the dispatch logic:
calls = fake_message["tool_calls"]
for tc in calls:
    original_name = tc["function"]["name"]
    fixed = hook_fn(original_name, {})  # apply plugin hook
    final_name = fixed["tool_name"] if fixed else original_name
    mock_handle(final_name, {}, tc["id"])

assert names == ["todo_tool"], f"Expected todo_tool, got {names}"
print("Integration test passed: handle_function_call received corrected name.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# test_background_review.py
import threading
import time
from unittest.mock import Mock, patch

# Import Hermes components
from hermes_state import AIAgent, load_config

# Mock configuration with short nudge intervals
config = {
    "memory": {"nudge_interval": 2},
    "skills": {"creation_nudge_interval": 2},
    "provider": "openai",
    "model": "dummy",
}
# We'll inject this config by modifying the agent after init

# Shared list for status and background review callbacks
status_events = []
bg_review_log = []

def status_callback(event):
    status_events.append(event)

def background_review_callback(summary):
    bg_review_log.append(summary)

# Mock OpenAI that returns a tool call to memory then a tool result
class MockOpenAI:
    def __init__(self, *args, **kwargs):
        self.call_count = 0
    def chat_completions(self, messages, tools, **kwargs):
        self.call_count += 1
        # After first user message, return a tool call to memory
        if self.call_count == 1:
            return {
                "choices": [{
                    "message": {
                        "tool_calls": [{
                            "id": "call_1",
                            "function": {"name": "memory", "arguments": '{"action":"save","key":"test","value":"hello"}'}
                        }]
                    }
                }]
            }
        # After second user, return a tool call to skill_manage
        if self.call_count == 2:
            return {
                "choices": [{
                    "message": {
                        "tool_calls": [{
                            "id": "call_2",
                            "function": {"name": "skill_manage", "arguments": '{"action":"create","name":"test_skill"}'}
                        }]
                    }
                }]
            }
        # Third turn: return normal assistant message
        return {"choices": [{"message": {"content": "All done."}}]}

# Create agent with runtime config overrides
agent = AIAgent(provider="openai", model="dummy", plugins_dir=None)
agent._config = {**agent._config, **config}  # merge config
agent.status_callback = status_callback
agent.background_review_callback = background_review_callback
agent._memory_nudge_interval = 2
agent._skill_nudge_interval = 2

# Replace the real API call with the mock
agent._model = MockOpenAI()

# Prepare conversation history that includes an attempted but failed memory call
# (We simulate this by adding a tool message that has no corresponding assistant after)
agent._conversation_history = [
    {"role": "user", "content": "Remember my name is Alice"},
    {"role": "tool", "content": "{}", "tool_call_id": "call_old"}
]

# Run three turns
for i in range(3):
    agent.run_conversation(f"Message {i+1}")
    agent._flush_messages_to_session_db()  # ensure state is written

# Wait a bit for background review to execute (async)
time.sleep(1)

# Check background review thread
review_threads = [t for t in threading.enumerate() if "bg-review" in t.name]
assert len(review_threads) > 0, "Background review thread should have been started"
print(f"Background review thread found: {review_threads[0].name}")

# Check that background_review_callback was called at least once with either "Memory updated" or "Skill updated"
memory_update_logs = [msg for msg in bg_review_log if "Memory updated" in msg or "Skill updated" in msg]
assert len(memory_update_logs) > 0, "Background review should have produced a memory or skill update"
print("Background review callbacks:", bg_review_log)

# Check status events contain lifecycle events
lifecycle_events = [e for e in status_events if e.get("type") == "lifecycle"]
assert len(lifecycle_events) > 0
print("Lifecycle events found:", lifecycle_events)

# Clean up
agent.shutdown_memory_provider()
agent.close()
print("Test passed.")

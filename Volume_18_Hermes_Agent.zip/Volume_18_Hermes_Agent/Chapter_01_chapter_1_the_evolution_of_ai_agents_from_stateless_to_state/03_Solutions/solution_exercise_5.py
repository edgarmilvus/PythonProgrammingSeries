
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# ~/.hermes/plugins/camel_case_remediator/__init__.py
import re

def register(ctx):
    """Register the pre_tool_call hook."""

    def remediate(tool_name: str, arguments: dict, task_id=None) -> dict | None:
        # Convert CamelCase to snake_case
        snake = re.sub(r'(?<!^)(?=[A-Z])', '_', tool_name).lower()
        # Strip trailing _tool if present (common pattern)
        if snake.endswith("_tool"):
            snake = snake[:-5]
        # Check if the corrected name exists in the agent's valid tool set
        valid_tools = ctx.agent.valid_tool_names  # assuming ctx provides agent reference
        if snake in valid_tools and snake != tool_name:
            return {"tool_name": snake}
        # If we can't fix, return None to let default repair logic run
        return None

    ctx.register_hook("pre_tool_call", remediate)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import math
import io

# Simulation of a configuration file containing model parameters.
# In a real-world scenario, this would be a .txt or .json file on disk.
# Each line represents: model_name, parameter_count_billions, quantization_type
CONFIG_DATA = """Llama-3-8B,8,NF4
Mistral-7B,7,BF16
Gemma-2B,2,NF4
Llama-3-70B,70,NF4
Custom-Model-13B,13,BF16
"""

class VRAMSimulator:
    """
    A simulator designed to model the memory footprint of LLM fine-tuning.
    It accounts for weights, gradients, optimizer states, and activations.
    """

    def __init__(self, gpu_vram_gb: float, unsloth_optimization_factor: float = 0.7):
        # The total available VRAM on the target hardware
        self.gpu_vram_gb = gpu_vram_gb
        # Unsloth's optimized kernels reduce gradient/activation overhead.
        # A factor of 0.7 implies a 30% reduction in memory overhead.
        self.optimization_factor = unsloth_optimization_factor

    def calculate_weight_memory(self, params_billions: float, quant_type: str) -> float:
        """
        Calculates the memory required for model weights.
        NF4 (4-bit) uses 0.5 bytes per parameter.
        BF16 (16-bit) uses 2 bytes per parameter.
        """
        if quant_type == "NF4":
            # 4 bits = 0.5 bytes per parameter
            return params_billions * 0.5
        elif quant_type == "BF16":
            # 16 bits = 2 bytes per parameter
            return params_billions * 2.0
        else:
            return params_billions * 4.0  # Default to FP32 (4 bytes)

    def calculate_gradient_memory(self, params_billions: float, quant_type: str) -> float:
        """
        Calculates the memory required for gradients during backpropagation.
        Gradients are typically stored in higher precision (BF16/FP32) even if weights are 4-bit.
        """
        # Even in 4-bit training, gradients are often kept in 16-bit to maintain stability.
        # We apply the Unsloth optimization factor to simulate efficient kernel usage.
        base_gradient_memory = params_billions * 2.0  # 16-bit gradients
        return base_gradient_memory * self.optimization_factor

    def calculate_optimizer_memory(self, params_billions: float, quant_type: str) -> float:
        """
        Calculates the memory required for optimizer states (e.g., AdamW).
        AdamW stores two states (momentum and variance) per parameter in FP32.
        """
        # Standard AdamW requires 8 bytes per parameter (2 states * 4 bytes for FP32).
        # However, with 4-bit quantization and optimized kernels, this is heavily managed.
        if quant_type == "NF4":
            # Quantized training significantly reduces optimizer overhead via Paged Optimizers.
            return params_billions * 4.0  # Reduced overhead simulation
        else:
            return params_billions * 8.0  # Standard heavy AdamW overhead

    def calculate_activation_memory(self, params_billions: float) -> float:
        """
        Estimates the memory used by activations during the forward pass.
        This is highly dependent on sequence length and batch size.
        """
        # A heuristic estimate for a standard context window.
        return params_billions * 0.5 * self.optimization_factor

    def run_simulation(self, config_stream: io.StringIO):
        """
        Iterates over the configuration file object and evaluates each model.
        """
        print(f"{'Model Name':<18} | {'Quant':<5} | {'VRAM Req (GB)':<15} | {'Status'}")
        print("-" * 60)

        # Iterating over a File Object: Reading line by line to save memory.
        for line in config_stream:
            # Strip whitespace and split the line into components
            parts = line.strip().split(',')
            if len(parts) != 3:
                continue

            name, params_str, quant = parts
            params = float(params_str)

            # Calculate individual memory components
            w_mem = self.calculate_weight_memory(params, quant)
            g_mem = self.calculate_gradient_memory(params, quant)
            o_mem = self.calculate_optimizer_memory(params, quant)
            a_mem = self.calculate_activation_memory(params)

            total_required = w_mem + g_mem + o_mem + a_mem

            # Determine if the model fits within the available VRAM
            status = "✅ PASS" if total_required <= self.gpu_vram_gb else "❌ OOM ERROR"

            print(f"{name:<18} | {quant:<5} | {total_required:<15.2f} | {status}")

# --- Execution Block ---

if __name__ == "__main__":
    # Scenario: We are working on an RTX 3090 with 24GB VRAM.
    TARGET_VRAM = 24.0
    
    # Initialize the simulator with Unsloth-style optimizations enabled.
    simulator = VRAMSimulator(gpu_vram_gb=TARGET_VRAM, unsloth_optimization_factor=0.6)

    # Convert our string constant into a file-like object to demonstrate efficient iteration.
    config_file_handle = io.StringIO(CONFIG_DATA)

    # Execute the simulation
    print(f"--- VRAM Simulation Report (Hardware: {TARGET_VRAM}GB) ---")
    simulator.run_simulation(config_file_handle)

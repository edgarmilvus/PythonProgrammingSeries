
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import torch  # The fundamental tensor library for deep learning
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig  # Tools for model loading and quantization

# 1. Define the model identifier
# We use a small model (OPT-125M) for this demonstration to ensure it runs anywhere,
# but the logic applies identically to massive models like Llama-3 or Mistral.
model_id = "facebook/opt-125m"

# 2. Configure the 4-bit Quantization settings
# This is the 'brain' of the compression process.
quant_config = BitsAndBytesConfig(
    load_in_4bit=True,                # Instruct the loader to use 4-bit quantization
    bnb_4bit_quant_type="nf4",        # Use NormalFloat 4, an optimized type for normally distributed weights
    bnb_4bit_use_double_quant=True,   # Quantize the quantization constants themselves to save even more VRAM
    bnb_4bit_compute_dtype=torch.float16 # The precision used for actual mathematical operations (the 'compute' pass)
)

# 3. Load the Model with the Quantization Configuration
# We map the model to the GPU (cuda) automatically.
print(f"Loading model: {model_id} in 4-bit...")
model = AutoModelForCausalLM.from_pretrained(
    model_id,
    quantization_config=quant_config, # Apply the 4-bit settings defined above
    device_map="auto"                 # Automatically distribute model layers across available hardware
)

# 4. Load the Tokenizer
# The tokenizer converts human text into the numerical tokens the model understands.
tokenizer = AutoTokenizer.from_pretrained(model_id)

# 5. Prepare a simple inference test
# We define a prompt and convert it into tensors (mathematical arrays).
prompt = "The secret to efficient AI training is"
inputs = tokenizer(prompt, return_tensors="pt").to("cuda") # Move input data to the GPU

# 6. Generate a response
# The model performs a forward pass to predict the next tokens.
print("Generating response...")
outputs = model.generate(**inputs, max_new_tokens=20)

# 7. Decode and display the result
# Convert the numerical tokens back into human-readable text.
decoded_output = tokenizer.decode(outputs[0], skip_special_tokens=True)
print(f"\nResult:\n{decoded_output}")

# 8. Memory Audit (Demonstrating the impact)
# This shows how much VRAM the model is actually occupying.
vram_used = torch.cuda.memory_allocated() / 1024**3  # Convert bytes to Gigabytes
print(f"\n[Memory Audit] VRAM currently allocated: {vram_used:.2f} GB")

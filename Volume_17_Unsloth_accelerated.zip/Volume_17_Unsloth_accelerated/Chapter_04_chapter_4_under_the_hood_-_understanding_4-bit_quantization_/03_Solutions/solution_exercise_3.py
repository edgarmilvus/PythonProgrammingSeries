
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np

class QuantizedTensorLoRA:
    def __init__(self, base_weights_4bit, levels, rank, alpha):
        # Requirement 2: Rank Parameterization
        self.d_out, self.d_in = base_weights_4bit.shape
        if rank > self.d_in or rank > self.d_out:
            raise ValueError(f"Rank {rank} cannot be larger than dimensions {self.d_in}x{self.d_out}")
            
        self.levels = levels
        self.rank = rank
        self.alpha = alpha
        self.scaling = alpha / rank
        
        # Store the 4-bit indices
        self.q_weights = base_weights_4bit
        
        # Requirement 1: Class Extension (Adapter Initialization)
        # A is Gaussian, B is Zero (standard LoRA practice)
        self.adapter_A = np.random.normal(0, 0.02, (rank, self.d_in))
        self.adapter_B = np.zeros((self.d_out, rank))

    def forward(self, x):
        # Requirement 3: Modified Forward Pass
        # 1. Dequantize base weights
        base_w = self.levels[self.q_weights]
        
        # 2. Base path: W * x
        base_out = np.dot(base_w, x)
        
        # 3. LoRA path: (B * (A * x)) * scaling
        # We use the order (B(Ax)) for efficiency: O(d*r) instead of O(d^2)
        lora_out = self.adapter_B @ (self.adapter_A @ x) * self.scaling
        
        return base_out + lora_out

    # Requirement 5: Parameter Tracking
    def get_trainable_parameters(self):
        params_A = self.adapter_A.size
        params_B = self.adapter_B.size
        return params_A + params_B

# --- Test Implementation ---
d, r = 1024, 8
alpha = 16
levels = np.linspace(-1, 1, 16)
q_weights = np.random.randint(0, 16, (d, d))
x = np.random.randn(d, 1)

layer = QuantizedTensorLoRA(q_weights, levels, rank=r, alpha=alpha)
output = layer.forward(x)

print(f"Output shape: {output.shape}")
print(f"Trainable parameters: {layer.get_trainable_parameters()}")
print(f"Memory Scaling (r=8): {layer.get_trainable_parameters()} params")
print(f"Memory Scaling (r=64): {layer.get_trainable_parameters() * 8} params (approx)")

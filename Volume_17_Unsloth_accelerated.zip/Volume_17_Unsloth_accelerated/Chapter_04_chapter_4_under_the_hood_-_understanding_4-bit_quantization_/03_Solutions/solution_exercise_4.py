
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import json

def stream_dataset(file_path):
    # Requirement 1: Line-by-Line Iteration
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                # Requirement 2: JSON Parsing
                data = json.loads(line)
                
                # Requirement 5: Data Cleaning
                if "instruction" in data and "response" in data:
                    yield data
                else:
                    continue # Skip incomplete entries
            except json.JSONDecodeError:
                # Requirement: Handle Malformed Lines
                print(f"Warning: Skipping malformed JSON line.")
                continue

def get_batches(streamer, batch_size, max_chars_per_batch):
    # Requirement 3: Batching Logic
    batch = []
    current_batch_chars = 0
    
    for item in streamer:
        item_size = len(str(item))
        
        # Requirement 4: Memory Guardrail
        # If adding this item exceeds the char limit, yield current batch and start new
        if current_batch_chars + item_size > max_chars_per_batch and batch:
            yield batch
            batch = []
            current_batch_chars = 0
            
        batch.append(item)
        current_batch_chars += item_size
        
        # Standard batch size limit
        if len(batch) == batch_size:
            yield batch
            batch = []
            current_batch_chars = 0
            
    # Requirement: Final Batch
    if batch:
        yield batch

# --- Simulation Setup ---
# Creating a dummy file for demonstration
with open("dummy.jsonl", "w") as f:
    f.write('{"instruction": "Hi", "response": "Hello"}\n')
    f.write('{"malformed": "data"}\n') # Should be cleaned
    f.write('invalid json\n')          # Should be caught by try-except
    f.write('{"instruction": "Long", "response": "' + "a"*500 + '"}\n') # Large item
    f.write('{"instruction": "Small", "response": "Yes"}\n')

# --- Execution ---
streamer = stream_dataset("dummy.jsonl")
# Batch size 2, but max chars 200 to trigger the guardrail
batches = get_batches(streamer, batch_size=2, max_chars_per_batch=200)

for i, batch in enumerate(batches):
    print(f"Batch {i}: {batch}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np

class WeightParameter:
    def __init__(self, initial_val, levels):
        self.levels = levels
        # Requirement 1: State Management
        self.master_weight = float(initial_val)
        # Quantize initial master weight
        idx = np.abs(self.levels - self.master_weight).argmin()
        self.quantized_weight = idx

    def apply_gradient(self, gradient, learning_rate):
        # Requirement 2: High-Precision Accumulation
        # Update the high-precision master weight first
        self.master_weight += gradient * learning_rate
        
        # Re-quantize the quantized representation based on the new master
        new_idx = np.abs(self.levels - self.master_weight).argmin()
        self.quantized_weight = new_idx

    def naive_update(self, gradient, learning_rate):
        # Requirement 3: Naive 4-bit Update
        # Attempting to apply the update directly to the discrete index
        # We simulate this by seeing if the float update is enough to push the index to the next level
        current_val = self.levels[self.quantized_weight]
        new_val = current_val + (gradient * learning_rate)
        
        # Find the new index (this will stay the same if the change is too small)
        new_idx = np.abs(self.levels - new_val).argmin()
        self.quantized_weight = new_idx

# Requirement 4: Convergence Test
def run_simulation():
    levels = np.linspace(-2, 2, 16) # Simplified levels for demo
    target = 0.0
    lr = 0.01
    
    high_prec_param = WeightParameter(1.0, levels)
    naive_param = WeightParameter(1.0, levels)
    
    print(f"{'Iter':<5} | {'High-Prec Master':<18} | {'Naive Quantized Val':<20}")
    print("-" * 50)

    for i in range(100):
        # Objective: minimize f(x) = x^2 -> gradient is 2x
        grad = 2 * high_prec_param.master_weight
        
        high_prec_param.apply_gradient(grad, lr)
        naive_param.naive_update(grad, lr)
        
        if i % 10 == 0 or i < 5:
            print(f"{i:<5} | {high_prec_param.master_weight:<18.6f} | {levels[naive_param.quantized_weight]:<20.6f}")

run_simulation()

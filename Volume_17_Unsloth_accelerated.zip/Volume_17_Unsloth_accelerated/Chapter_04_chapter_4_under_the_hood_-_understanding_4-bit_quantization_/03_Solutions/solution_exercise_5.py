
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

def fused_quantization_matmul_kernel(W_indices, X, NF4_levels, tile_size=16):
    """
    W_indices: 4-bit quantized weight matrix (int8 representation)
    X: float32 activation matrix
    NF4_levels: The 16 pre-computed float32 quantization points
    """
    rows, cols = W_indices.shape
    _, k_dim = X.shape
    output = np.zeros((rows, k_dim), dtype=np.float32)

    # Tiling over rows (i) and columns (j)
    for tile_i in range(0, rows, tile_size):
        for tile_j in range(0, k_dim, tile_size):
            
            # Constraint 3: Register Management
            # We use a local accumulator to hold partial sums for the current tile
            # This mimics how a GPU uses registers to minimize VRAM writes
            tile_accumulator = np.zeros((tile_size, tile_size), dtype=np.float32)
            
            # Standard Matrix Multiplication Loops (within the tile)
            for i in range(tile_i, min(tile_i + tile_size, rows)):
                for j in range(tile_j, min(tile_j + tile_size, k_dim)):
                    
                    # Initialize partial sum for the dot product
                    dot_product = 0.0
                    
                    for k in range(cols):
                        # Constraint 1 & 2: No intermediate dequantized matrix
                        # Constraint 2: On-the-fly dequantization
                        
                        # 1. Fetch 4-bit index from VRAM
                        idx = W_indices[i, k]
                        
                        # 2. Dequantize on-the-fly using the NF4 lookup table
                        weight_val = NF4_levels[idx]
                        
                        # 3. Multiply by activation and accumulate
                        dot_product += weight_val * X[k, j]
                    
                    tile_accumulator[i - tile_i, j - tile_j] = dot_product
            
            # 5. Write the finished tile to the output VRAM
            output[tile_i:tile_i+tile_size, tile_j:tile_j+tile_size] = tile_accumulator
            
    return output


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
from scipy.stats import norm

class NF4Engine:
    def __init__(self):
        # Requirement 1: Quantile Calculation
        # We generate 16 levels such that each bin contains equal probability mass.
        # We use the midpoint of 16 equal probability intervals.
        probabilities = np.linspace(1/(2*16), 1 - 1/(2*16), 16)
        self.levels = norm.ppf(probabilities)
        
        # Ensure symmetry and handle potential floating point drift
        self.levels = np.sort(self.levels)

    def quantize(self, tensor):
        # Requirement 2 & 5: Vectorized Quantization
        # np.searchsorted finds the indices where elements should be inserted to maintain order.
        # We use it to find the nearest level index.
        # To find the 'nearest', we check the distance to the left and right neighbors.
        indices = np.searchsorted(self.levels, tensor)
        
        # Clip indices to stay within [0, 15]
        indices = np.clip(indices, 1, len(self.levels) - 1)
        
        # Compare distance to the index found and the index-1 to find the absolute nearest
        left_dist = np.abs(tensor - self.levels[indices - 1])
        right_dist = np.abs(tensor - self.levels[indices])
        
        # If left distance is smaller, use indices-1, else use indices
        final_indices = np.where(left_dist < right_dist, indices - 1, indices)
        return final_indices.astype(np.int8)

    def dequantize(self, quantized_indices):
        # Requirement 3: Dequantization
        return self.levels[quantized_indices]

    def calculate_mse(self, original, reconstructed):
        # Requirement 4: Error Analysis
        return np.mean((original - reconstructed) ** 2)

# --- Test Implementation ---
engine = NF4Engine()
# Simulate a weight tensor following a normal distribution
weights = np.random.normal(0, 1, (1000,))

# Process
q_indices = engine.quantize(weights)
reconstructed_weights = engine.dequantize(q_indices)
mse = engine.calculate_mse(weights, reconstructed_weights)

print(f"NF4 Levels: {engine.levels}")
print(f"Mean Squared Error: {mse:.6f}")
print(f"Original Mean: {np.mean(weights):.4f}, Reconstructed Mean: {np.mean(reconstructed_weights):.4f}")

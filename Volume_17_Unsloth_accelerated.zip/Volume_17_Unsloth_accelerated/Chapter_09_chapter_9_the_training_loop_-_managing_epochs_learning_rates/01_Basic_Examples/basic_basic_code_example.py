
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

from unsloth import FastLanguageModel
from trl import SFTTrainer
from transformers import TrainingArguments
from datasets import load_dataset

# 1. Configuration and Model Loading
# We define the model name and the number of LoRA adapters to use.
model_name = "unsloth/llama-3-8b-bnb-4bit"
max_seq_length = 2048 

# Load the model and tokenizer using Unsloth's optimized kernels.
# This step is critical for memory efficiency.
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name = model_name,
    max_seq_length = max_seq_length,
    load_in_4bit = True, # Use 4-bit quantization to save VRAM
)

# 2. LoRA (Low-Rank Adaptation) Setup
# Instead of training all parameters, we add small trainable matrices.
model = FastLanguageModel.get_peft_model(
    model,
    r = 16, # Rank of the adaptation matrices
    target_modules = ["q_proj", "k_proj", "v_proj", "o_proj"],
    lora_alpha = 16,
    lora_dropout = 0, 
    bias = "none",    
)

# 3. Dataset Preparation
# We load a simple instruction dataset for the training loop to iterate over.
dataset = load_dataset("philschmid/instruction-format-alpaca-tiny", split="train")

# 4. Defining the Training Loop Parameters (The Core of the Chapter)
# This object controls how the 'For Loop' behaves.
training_args = TrainingArguments(
    per_device_train_batch_size = 2,      # Number of samples processed per step
    gradient_accumulation_steps = 4,     # Number of steps to accumulate before updating weights
    warmup_steps = 5,                    # Initial steps with a very low learning rate
    max_steps = 60,                      # Total number of training iterations (the loop limit)
    learning_rate = 2e-4,                # The step size for weight updates
    fp16 = True,                         # Use half-precision for faster computation
    logging_steps = 1,                   # How often to print progress
    optim = "adamw_8bit",                # Memory-efficient optimizer
    output_dir = "outputs",              # Where to save the model
)

# 5. Initializing the SFTTrainer
# The SFTTrainer combines the model, the dataset, and the training arguments.
trainer = SFTTrainer(
    model = model,
    train_dataset = dataset,
    dataset_text_field = "text",         # The column in the dataset containing the text
    max_seq_length = max_seq_length,
    args = training_args,                # Passing our loop configuration
)

# 6. Executing the Training Loop
# This single command triggers the internal 'For Loop' that performs the training.
trainer.train()

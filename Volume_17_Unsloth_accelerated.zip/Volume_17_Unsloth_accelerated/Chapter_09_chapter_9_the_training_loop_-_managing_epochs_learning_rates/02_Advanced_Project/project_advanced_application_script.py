
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import torch
from datasets import Dataset
from trl import SFTTrainer, SFTConfig
from unsloth import FastLanguageModel
from transformers import TrainingArguments

# --- STEP 1: DATA STREAMING CONFIGURATION ---
# We simulate a massive file of medical research data.
# In a real scenario, this would be a path to a multi-gigabyte .txt file.
DATA_FILE_PATH = "medical_research_data.txt"

def stream_medical_data(file_path):
    """
    Uses the practice of iterating over a file object to prevent 
    loading the entire dataset into RAM.
    """
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            # Iterating over the file object directly
            for line in f:
                clean_line = line.strip()
                if clean_line:
                    # Yielding a dictionary format expected by HuggingFace
                    yield {"text": clean_line}
    except FileNotFoundError:
        # Fallback for demonstration purposes if file doesn't exist
        print(f"Warning: {file_path} not found. Using synthetic data.")
        for i in range(100):
            yield {"text": f"Medical Research Entry {i}: Analysis of clinical trials..."}

# --- STEP 2: MODEL & LORA INITIALIZATION ---
# Loading the model using Unsloth for extreme memory efficiency.
max_seq_length = 2048
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name = "unsloth/llama-3-8b-bnb-4bit",
    max_seq_length = max_seq_length,
    load_in_4bit = True,
)

# Adding LoRA adapters to allow for efficient fine-tuning
model = FastLanguageModel.get_peft_model(
    model,
    r = 16,
    target_modules = ["q_proj", "k_proj", "v_proj", "o_proj"],
    lora_alpha = 16,
    lora_dropout = 0,
    bias = "none",
)

# --- STEP 3: DATASET PREPARATION ---
# Converting our generator into a HuggingFace Dataset object.
raw_generator = stream_medical_data(DATA_FILE_PATH)
dataset = Dataset.from_generator(raw_generator)

# --- STEP 4: ADVANCED TRAINING CONFIGURATION ---
# This is the core of Chapter 9: Managing the Training Loop.
training_args = SFTConfig(
    output_dir = "./medical_agent_outputs",
    
    # Learning Rate Management
    learning_rate = 2e-4,               # The peak learning rate
    lr_scheduler_type = "cosine",       # Gradually decays LR following a cosine curve
    warmup_ratio = 0.1,                 # First 10% of steps are used to ramp up LR
    
    # Batch Size & Gradient Accumulation
    # We want an effective batch size of 32. 
    # If our GPU can only fit 4 samples, we accumulate 8 times.
    per_device_train_batch_size = 4,    
    gradient_accumulation_steps = 8,    
    
    # Epochs & Steps
    num_train_epochs = 3,               # Total passes through the data
    max_steps = -1,                     # -1 means we rely on epochs
    
    # Optimization & Efficiency
    fp16 = not torch.cuda.is_bf16_supported(),
    bf16 = torch.cuda.is_bf16_supported(),
    logging_steps = 10,                 # Log metrics every 10 steps
    optim = "adamw_8bit",               # 8-bit optimizer to save VRAM
    weight_decay = 0.01,                # Regularization to prevent overfitting
    
    # SFT Specifics
    max_seq_length = max_seq_length,
    packing = True,                     # Pack multiple short sequences into one block
)

# --- STEP 5: THE SFTTRAINER EXECUTION ---
trainer = SFTTrainer(
    model = model,
    train_dataset = dataset,
    dataset_text_field = "text",
    max_seq_length = max_seq_length,
    args = training_args,
)

# --- STEP 6: MONITORING THE LOOP ---
# We use enumerate() to track progress during a manual validation or logging phase.
print("Starting the fine-tuning loop for the Medical Agent...")

# In a real production script, trainer.train() handles the loop.
# Here we demonstrate how one might manually inspect the dataset/batches.
for idx, sample in enumerate(dataset):
    if idx >= 5: # Just showing the first 5 for brevity
        break
    print(f"Sample {idx} loaded: {sample['text'][:50]}...")

# Execute the training
trainer.train()

# --- STEP 7: FINALIZATION ---
# Save the LoRA adapters for later use in the Agentic loop.
model.save_pretrained("medical_agent_lora")
tokenizer.save_pretrained("medical_agent_lora")
print("Training complete. Model saved.")

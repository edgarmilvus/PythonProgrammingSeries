
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from transformers import TrainingArguments
from trl import SFTTrainer

# Assuming model, tokenizer, and medical_dataset are already defined
# model = ...
# tokenizer = ...
# medical_dataset = ...

training_args = TrainingArguments(
    output_dir="./llama3-medical-assistant",
    
    # 1. Core Configuration
    num_train_epochs=3,
    learning_rate=2e-4,             # Peak learning rate
    warmup_ratio=0.05,              # 5% of total steps for warmup
    lr_scheduler_type="cosine",     # Smooth decay after warmup
    
    # 2. Optimization and Stability
    weight_decay=0.01,              # Prevent weight explosion
    max_grad_norm=1.0,              # Gradient clipping to prevent spikes
    logging_steps=10,               # Granular logging of loss and LR
    
    # 3. Validation Requirements
    eval_strategy="steps",          # Monitor validation in real-time
    eval_steps=50,                  # Evaluate every 50 steps
    
    # 4. Hardware/Memory Management (Optimized for A100 80GB)
    per_device_train_batch_size=4,  # Balanced for 4096 seq_length
    bf16=True,                      # Use bfloat16 for A100 stability
)

trainer = SFTTrainer(
    model=model,
    train_dataset=medical_dataset,
    args=training_args,
    max_seq_length=4096,            # Accommodate long clinical notes
    packing=True,                   # Maximize throughput efficiency
)

trainer.train()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from trl import SFTTrainer
from transformers import TrainingArguments
from unsloth import FastLanguageModel

# Load model and tokenizer
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name = "unsloth/llama-3-8b-bnb-4bit",
    max_seq_length = 2048,
    load_in_4bit = True,
)

# REFACTORED: Stability-First Configuration
training_args = TrainingArguments(
    output_dir = "outputs_stable",
    
    # 1. Refactoring Learning Regime
    learning_rate = 2e-5,           # Reduced from 5e-4 for stability
    warmup_ratio = 0.1,             # Added warmup to prevent early divergence
    lr_scheduler_type = "cosine",   # Smooth decay for better convergence
    
    # 2. Refactoring for Hardware Efficiency
    per_device_train_batch_size = 2, # Reduced to ensure stability
    gradient_accumulation_steps = 8, # Effective Batch Size = 2 * 8 = 16
    fp16 = True,                    # Enabled for speed
    gradient_checkpointing = True,  # Enabled to save VRAM
    
    # 3. Refactoring for Convergence and Reliability
    num_train_epochs = 3,           # Increased for proper learning
    weight_decay = 0.05,            # Added regularization
    max_grad_norm = 0.3,            # Strict clipping to prevent loss spikes
    logging_steps = 10,             # Reduced logging overhead
)

# 4. Refactoring Trainer Initialization
trainer = SFTTrainer(
    model = model,
    train_dataset = dataset,
    dataset_text_field = "text",
    max_seq_length = 2048,
    args = training_args,
    packing = True,                 # Crucial for Unsloth efficiency
)

trainer.train()

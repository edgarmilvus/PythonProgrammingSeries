
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from transformers import TrainingArguments
from trl import SFTTrainer

# Assuming train_dataset and eval_dataset are pre-loaded
# train_dataset = ...
# eval_dataset = ...

training_args = TrainingArguments(
    output_dir="./gothic-horror-model",
    
    # 1. Epoch and Monitoring Requirements
    num_train_epochs = 5,           # Conservative maximum
    eval_strategy = "steps",        # Monitor performance via steps
    eval_steps = 20,                # Frequent evaluation for small dataset
    
    # 2. Convergence Control Requirements
    load_best_model_at_end = True,  # Revert to the best version if overfitting occurs
    metric_for_best_model = "loss", # Use validation loss as the quality metric
    save_total_limit = 2,           # Keep only the best and the most recent
    
    # 3. Learning Rate Integration
    lr_scheduler_type = "cosine",   # Decay LR significantly over 5 epochs
    warmup_ratio = 0.1,             # Gentle start for the Gothic style
    
    # 4. Optimization (Standard for stability)
    learning_rate = 5e-5,
    weight_decay = 0.1,             # Higher decay to combat overfitting
)

trainer = SFTTrainer(
    model=model,
    train_dataset=train_dataset,
    eval_dataset=eval_dataset,      # Explicitly passed to enable eval_strategy
    args=training_args,
    max_seq_length=2048,
    packing=True,
)

trainer.train()

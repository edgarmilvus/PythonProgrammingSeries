
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from transformers import TrainingArguments
from trl import SFTTrainer

# Target: Effective Batch Size = 64
# Formula: per_device_train_batch_size * gradient_accumulation_steps = 64

# 1. Memory Constraint Calculations
# For a 3090 (24GB) and 2048 seq_length, we select a safe physical batch size
physical_batch_size = 4 
accumulation_steps = 64 // physical_batch_size # Results in 16

training_args = TrainingArguments(
    output_dir="./mistral-python-code",
    
    # 2. Throughput and Memory Optimization
    per_device_train_batch_size=physical_batch_size,
    gradient_accumulation_steps=accumulation_steps,
    bf16=True,                      # Utilize 3090 Tensor Cores
    optim="adamw_8bit",             # Drastically reduce optimizer VRAM footprint
    gradient_checkpointing=True,    # Trade compute for VRAM (saves activations)
    
    # 3. Precision and Monitoring
    learning_rate=5e-5,
    max_seq_length=2048,
    logging_steps=1,                # Monitor impact of every accumulation cycle
)

trainer = SFTTrainer(
    model=model,
    train_dataset=code_dataset,
    args=training_args,
    max_seq_length=2048,
)

trainer.train()

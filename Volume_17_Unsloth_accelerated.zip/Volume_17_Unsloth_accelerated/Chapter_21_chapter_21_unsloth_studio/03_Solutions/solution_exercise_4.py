
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================
from openai import OpenAI
 
# 1. Client Initialization
# Pointing to the local Unsloth API port established in Exercise 1
client = OpenAI(
    base_url="http://localhost:8080/v1", 
    api_key="unsloth_local" # Dummy key, local API ignores it unless JWT is strictly enforced
)

def summarize_financials():
    financial_text = "Q3 Revenue grew by 14% year-over-year to $4.2B. Net income was $800M. Operating margins expanded by 200 basis points due to decreased cloud infrastructure costs."
    
    print("Sending request to Unsloth Studio API...")
    
    # 5. Error Handling
    try:
        # 3. API Call
        response = client.chat.completions.create(
            model="financial-summarizer-v2", # Must match the loaded model in Studio
            # 2. Message Construction
            messages=[
                {"role": "system", "content": "You are a concise financial analyst. Provide only bullet points."},
                {"role": "user", "content": f"Summarize this text: {financial_text}"}
            ],
            temperature=0.1, # Low temperature for factual consistency
            max_tokens=150
        )
        
        # 4. Data Extraction
        result = response.choices[0].message.content
        print("\n[Summary Output]:\n" + result)
        
    except Exception as e:
        print(f"\n[ERROR] Failed to communicate with local API. Is Unsloth Studio running? Details: {e}")

if __name__ == "__main__":
    summarize_financials()

#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================
import json

def get_structured_data(client, prompt: str, model_id="local-model") -> dict:
    """
    Calls the Unsloth API and ensures the output is valid JSON.
    Implements a self-healing retry loop if parsing fails.
    """
    max_retries = 3
    
    # Initial conversation history
    messages =[
        {"role": "system", "content": "You are a data extractor. Return ONLY valid JSON."},
        {"role": "user", "content": prompt}
    ]
    
    for attempt in range(max_retries):
        print(f"Attempt {attempt + 1}/{max_retries}...")
        
        # 1. Make the API call
        response = client.chat.completions.create(
            model=model_id,
            messages=messages,
            temperature=0.1
        )
        
        # 2. Extract the response string
        raw_output = response.choices[0].message.content
        
        # 3. Attempt to parse the string with json.loads()
        try:
            # Strip markdown formatting just in case the model used ```json
            clean_output = raw_output.replace("```json", "").replace("```", "").strip()
            parsed_data = json.loads(clean_output)
            print("Successfully parsed JSON!")
            return parsed_data
            
        # 4. If a json.JSONDecodeError occurs, implement Self-Healing
        except json.JSONDecodeError as e:
            print(f"JSON parsing failed: {e}")
            
            # Append the model's bad response to history
            messages.append({"role": "assistant", "content": raw_output})
            
            # Append the correction prompt
            error_message = (
                f"Your previous response caused a JSON decoding error: {str(e)}. "
                f"Please fix the formatting and return ONLY a valid JSON object without any conversational text."
            )
            messages.append({"role": "user", "content": error_message})

    # 5. If the loop finishes without returning, raise an Exception
    raise Exception(f"Failed to obtain valid JSON after {max_retries} attempts.")
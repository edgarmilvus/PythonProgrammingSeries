
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import subprocess
import time
from openai import OpenAI

class LocalAgentOrchestrator:
    """
    An agentic harness that connects to Unsloth Studio's local API.
    It enforces a multi-turn 'Self-Healing' loop for code generation.
    """
    def __init__(self, api_url="http://localhost:8000/v1", api_key="local_dev", max_retries=3):
        # Pointing the OpenAI client to the local Unsloth Studio endpoint
        self.client = OpenAI(base_url=api_url, api_key=api_key)
        self.max_retries = max_retries
        self.model_id = "default" # Unsloth Studio uses the currently loaded model

    def _execute_code(self, code_string: str) -> tuple[bool, str]:
        """
        Safely executes the provided Python code using a subprocess.
        Returns a tuple of (Success: bool, Output/Traceback: str).
        """
        # Save the code to a temporary file
        file_name = "agent_temp_execution.py"
        with open(file_name, "w") as f:
            f.write(code_string)
            
        try:
            # Execute the script with a timeout to prevent infinite loops
            result = subprocess.run(
                ["python3", file_name],
                capture_output=True,
                text=True,
                timeout=10
            )
            # Clean up the temp file
            os.remove(file_name)
            
            if result.returncode == 0:
                return True, result.stdout.strip()
            else:
                return False, result.stderr.strip()
                
        except subprocess.TimeoutExpired:
            os.remove(file_name)
            return False, "Execution Error: Script timed out after 10 seconds."
        except Exception as e:
            if os.path.exists(file_name): os.remove(file_name)
            return False, f"System Error: {str(e)}"

    def _extract_code_block(self, llm_response: str) -> str:
        """Parses the LLM response to find the Python code block."""
        if "```python" in llm_response:
            # Split by the markdown tag and extract the content
            parts = llm_response.split("```python")
            if len(parts) > 1:
                return parts[1].split("```")[0].strip()
        elif "```" in llm_response:
             parts = llm_response.split("```")
             if len(parts) > 1:
                 return parts[1].strip()
        return ""

    def run_healing_loop(self, task_prompt: str):
        """
        The core orchestration loop. Prompts the model, tests the code,
        and feeds errors back for self-healing.
        """
        print(f"\n[ORCHESTRATOR] Initiating task: '{task_prompt}'")
        
        # Initialize the conversation history
        messages =[
            {"role": "system", "content": "You are a senior Python engineer. Write ONLY the Python code to solve the user's request. Enclose the code in ```python blocks. Do not add conversational filler."},
            {"role": "user", "content": task_prompt}
        ]

        attempt = 1
        while attempt <= self.max_retries:
            print(f"\n--- Attempt {attempt} of {self.max_retries} ---")
            
            # 1. Inference via Unsloth Studio API
            try:
                response = self.client.chat.completions.create(
                    model=self.model_id,
                    messages=messages,
                    temperature=0.2, # Low temperature for more deterministic coding
                )
            except Exception as e:
                print(f"[API ERROR] Failed to connect to Unsloth Studio: {e}")
                return

            llm_text = response.choices[0].message.content
            
            # 2. Extract the code
            code_block = self._extract_code_block(llm_text)
            
            if not code_block:
                print("[PARSING ERROR] The model did not return a valid code block.")
                messages.append({"role": "assistant", "content": llm_text})
                messages.append({"role": "user", "content": "You must enclose your solution in ```python ... ``` tags. Try again."})
                attempt += 1
                continue

            print(f"[CODE GENERATED]\n{code_block}\n")
            
            # 3. Execute the code locally
            success, output = self._execute_code(code_block)
            
            if success:
                print(f"[SUCCESS] Code executed perfectly. Output:\n{output}")
                return
            else:
                print(f"[EXECUTION FAILED] Traceback:\n{output}")
                
                # 4. The 'Self-Healing' Step: Append the error to the history
                messages.append({"role": "assistant", "content": llm_text})
                
                # Prompt the model to fix its specific error
                correction_prompt = f"The code you provided failed with the following traceback:\n```\n{output}\n```\nPlease rewrite the code to fix this specific error."
                messages.append({"role": "user", "content": correction_prompt})
                
            attempt += 1

        print("\n[ORCHESTRATOR] Task failed. Maximum retries reached.")

# --- EXECUTION ---
if __name__ == "__main__":
    orchestrator = LocalAgentOrchestrator()
    
    # We ask the model to generate a deliberately tricky script: 
    # calculating prime numbers, which often trips up smaller models with off-by-one errors.
    challenge_task = "Write a Python script that prints a list of the first 15 prime numbers. Use a highly optimized algorithm."
    
    orchestrator.run_healing_loop(challenge_task)
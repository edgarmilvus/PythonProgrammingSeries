
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Import the standard OpenAI Python client
from openai import OpenAI

# Initialize the client to point to the local Unsloth Studio API instead of OpenAI's servers
client = OpenAI(
    base_url="http://localhost:8000/v1", # Port 8000 is the Unsloth API endpoint
    api_key="unsloth_local_token"        # Token-based auth configured in the Studio UI
)

def run_local_agent_query():
    print("--- Connecting to Unsloth Studio Local API ---")
    
    # We define a complex prompt that would typically require tool calling
    user_prompt = "Calculate the first 20 numbers of the Fibonacci sequence and save them to a file."
    
    try:
        # Create a chat completion request
        # Note: The model name corresponds to the model currently loaded in the Studio UI
        response = client.chat.completions.create(
            model="my-finetuned-llama3", 
            messages=[
                {"role": "system", "content": "You are an expert Python engineer. Use your code execution tool to write and run scripts when requested."},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.3,
            max_tokens=1024,
        )
        
        # Extract and print the response
        model_output = response.choices[0].message.content
        print(f"\n[AI Response]:\n{model_output}")
        
    except Exception as e:
        print(f"[ERROR] API Connection Failed: {e}")

if __name__ == "__main__":
    run_local_agent_query()

    
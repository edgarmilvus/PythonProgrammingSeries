
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from unsloth import FastLanguageModel

# 1. Configuration Mapping
MODEL_FACTORY = {
    "llama": "unsloth/llama-3-8b-bnb-4bit",
    "mistral": "unsloth/mistral-7b-bnb-4bit",
    "gemma": "unsloth/gemma-7b-bnb-4bit"
}

# 2. Dynamic Loading Function
def load_model_factory(nickname):
    # 4. Error Handling
    if nickname not in MODEL_FACTORY:
        print(f"Error: '{nickname}' is not a recognized model nickname in the factory.")
        return None, None

    model_path = MODEL_FACTORY[nickname]
    
    # 3. Uniformity: Consistent parameters across all models
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name = model_path,
        max_seq_length = 1024,
        load_in_4bit = True,
    )
    
    # 5. Verification
    print(f"Successfully loaded {nickname} with 4-bit quantization.")
    return model, tokenizer

# --- Testing the Factory ---
# Test valid model
model_a, tok_a = load_model_factory("mistral")

# Test invalid model (Error Handling)
model_b, tok_b = load_model_factory("phi-3")

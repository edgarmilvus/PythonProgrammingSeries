
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from unsloth import FastLanguageModel

def run_memory_stress_test(target_seq_length):
    print(f"\n--- Testing Sequence Length: {target_seq_length} ---")
    
    # 1, 2, 3. Parameterized loading of Mistral-7B with 4-bit quantization
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name = "unsloth/mistral-7b-bnb-4bit",
        max_seq_length = target_seq_length,
        load_in_4bit = True,
    )
    
    # 5. Output Requirement: Verify the configuration from the model object
    # In Transformers/Unsloth, the max sequence length is stored in the config
    actual_length = model.config.max_position_embeddings
    print(f"Model successfully configured with max_seq_length: {actual_length}")
    
    # Clean up to prevent VRAM accumulation during testing loops
    del model
    del tokenizer

# 4. Comparison Logic: Simulating a loop for different memory profiles
test_lengths = [512, 1024, 2048, 4096]

for length in test_lengths:
    try:
        run_memory_stress_test(length)
    except Exception as e:
        print(f"Failed at length {length}: {e}")

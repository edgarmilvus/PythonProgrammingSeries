
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from unsloth import FastLanguageModel

# 1. Refactored Descriptor
class ModelDescriptor:
    def __get__(self, instance, owner):
        # Ensure we only trigger on instance access, not class access
        if instance is None:
            return self
        
        # 4. Maintain Lazy Loading logic
        if "_model_obj" not in instance.__dict__:
            print(f"\n[Lazy Loading] Initializing {instance.model_name}...")
            
            # Use attributes stored in the owner class (instance)
            model, tokenizer = FastLanguageModel.from_pretrained(
                model_name = instance.model_name,
                max_seq_length = instance.seq_len,
                load_in_4bit = instance.use_4bit,
            )
            instance._model_obj = model
            instance._tokenizer_obj = tokenizer
            
        return instance._model_obj

class AdvancedModelWrapper:
    # The descriptor manages the 'model' attribute
    model = ModelDescriptor()

    def __init__(self, model_name, use_4bit, seq_len):
        # 2 & 3. Implement Dynamic Configuration via constructor
        self.model_name = model_name
        self.use_4bit = use_4bit
        self.seq_len = seq_len
        self._model_obj = None
        self._tokenizer_obj = None

# 5. Testing the Refactor
print("Instantiating wrappers (No model should be loaded yet)...")

# Instance A: Llama-3, 4-bit, 2048 seq length
instance_a = AdvancedModelWrapper("unsloth/llama-3-8b-bnb-4bit", True, 2048)

# Instance B: Mistral-7B, 16-bit (False), 512 seq length
instance_b = AdvancedModelWrapper("unsloth/mistral-7b-bnb-4bit", False, 512)

print("Wrappers created. Accessing Instance A model...")
_ = instance_a.model  # Triggers lazy loading for A

print("Accessing Instance B model...")
_ = instance_b.model  # Triggers lazy loading for B

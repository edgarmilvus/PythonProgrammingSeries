
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import os

# 1 & 2. Efficient Iteration and Data Cleaning via Generator
def line_generator(file_path):
    """Yields cleaned, non-empty lines from a file one by one."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File {file_path} not found.")
        
    with open(file_path, 'r', encoding='utf-8') as file_object:
        for line in file_object:  # Direct iteration pattern (Low Memory)
            cleaned_line = line.strip()
            if cleaned_line:  # Skip empty lines
                yield cleaned_line

# 3. The Model-Data Wrapper
class ModelDataStreamer:
    def __init__(self, model, file_path):
        self.model = model
        self.file_path = file_path

    # 4. The Streamer Interface
    def get_batches(self, batch_size):
        """Groups lines into batches of size batch_size using yield."""
        batch = []
        for line in line_generator(self.file_path):
            batch.append(line)
            if len(batch) == batch_size:
                yield batch
                batch = []  # Reset batch
        
        # Yield any remaining lines that didn't fill a full batch
        if batch:
            yield batch

# 5. Integration Simulation
# Setup: Create a dummy file for demonstration
DUMMY_FILE = "large_dataset.txt"
with open(DUMMY_FILE, "w") as f:
    for i in range(15):
        f.write(f"Instruction {i}: How to bake a cake?\n")

# Mock model object for simulation
mock_model = "FastLanguageModel_Object"

streamer = ModelDataStreamer(mock_model, DUMMY_FILE)

print("Starting simulated training batch ingestion...")
batch_count = 0
for batch in streamer.get_batches(batch_size=4):
    batch_count += 1
    print(f"Batch {batch_count}: {batch}")

# Cleanup
os.remove(DUMMY_FILE)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Import the core FastLanguageModel class from the unsloth library
from unsloth import FastLanguageModel
# Import torch to handle potential device-related checks or tensor operations
import torch

# --- Configuration Constants ---
# We define these as constants following PEP 8 naming conventions (UPPER_CASE)
# to ensure the code is readable and easy to maintain.
MODEL_NAME = "unsloth/llama-3-8b-bnb-4bit"  # The specific 4-bit quantized model
MAX_SEQ_LENGTH = 2048                      # The maximum context window length
LOAD_IN_4BIT = True                        # Enable 4-bit quantization for memory efficiency

def initialize_model_for_training():
    """
    Initializes the model and tokenizer using Unsloth's FastLanguageModel.
    This function encapsulates the loading logic to maintain clean scope.
    """
    
    # Step 1: Load the model and tokenizer
    # FastLanguageModel.from_pretrained is a highly optimized method that
    # handles quantization and hardware-specific optimizations automatically.
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name = MODEL_NAME,     # The Hugging Face model identifier
        max_seq_length = MAX_SEQ_LENGTH, # Limits the sequence length to save VRAM
        load_in_4bit = LOAD_IN_4BIT, # Reduces weight precision to 4-bit
    )

    # Step 2: Prepare the model for LoRA (Low-Rank Adaptation)
    # This step applies PEFT, which adds small, trainable adapter layers 
    # to the existing model, drastically reducing the number of trainable parameters.
    model = FastLanguageModel.get_peft_model(
        model,
        r = 16,                        # The rank of the adaptation (higher = more capacity)
        target_modules = [             # The specific layers to apply LoRA to
            "q_proj", "k_proj", "v_proj", "o_proj",
            "gate_proj", "up_proj", "down_proj",
        ],
        lora_alpha = 16,               # Scaling factor for the LoRA weights
        lora_dropout = 0,              # Dropout for LoRA (0 is optimized for Unsloth)
        bias = "none",                 # Do not train bias parameters
        use_gradient_checkpointing = "unsloth", # Optimized gradient checkpointing
        random_state = 3407,           # Seed for reproducibility
    )

    return model, tokenizer

# --- Execution Block ---
if __name__ == "__main__":
    # Execute the initialization
    trained_model, trained_tokenizer = initialize_model_for_training()
    
    # Verify the model is loaded and ready
    print("Model and Tokenizer successfully loaded via Unsloth!")
    print(f"Model Type: {type(trained_model)}")

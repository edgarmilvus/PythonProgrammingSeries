
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import time
from abc import ABC, abstractmethod
from sqlalchemy import create_engine, Column, Integer, String, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from unsloth import FastLanguageModel
import torch

# --- DATABASE LAYER (SQLAlchemy) ---
# We define a schema to store the performance metrics of each model tested.
Base = declarative_base()

class ModelMetric(Base):
    """SQLAlchemy model representing the performance results of an LLM."""
    __tablename__ = 'model_evaluations'
    id = Column(Integer, primary_key=True)
    model_name = Column(String)
    quantization = Column(String)
    latency_ms = Column(Float)
    vram_usage_gb = Column(Float)

# Initialize an in-memory SQLite database for this demonstration
engine = create_engine('sqlite:///:memory:')
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)
db_session = Session()

# --- INTERFACE LAYER (Abstract Base Class) ---
class ModelEvaluator(ABC):
    """
    An Abstract Base Class that enforces a standard interface for all 
    model evaluation tasks, ensuring consistency across different architectures.
    """
    @abstractmethod
    def load_model(self, model_id: str, max_seq_length: int):
        """Method to load the model using optimized kernels."""
        pass

    @abstractmethod
    def run_benchmark(self, prompt: str) -> float:
        """Method to execute a prompt and return the latency."""
        pass

# --- CORE IMPLEMENTATION (Unsloth FastLanguageModel) ---
class UnslothEvaluator(ModelEvaluator):
    """
    The production implementation using Unsloth's FastLanguageModel 
    for high-speed, 4-bit quantized loading.
    """
    def __init__(self):
        self.model = None
        self.tokenizer = None

    def load_model(self, model_id: str, max_seq_length: int):
        print(f"[*] Initializing Unsloth loading for: {model_id}")
        # Using FastLanguageModel to implement 4-bit quantization and optimized loading
        self.model, self.tokenizer = FastLanguageModel.from_pretrained(
            model_name=model_id,
            max_seq_length=max_seq_length,
            load_in_4bit=True,  # Crucial for reducing VRAM footprint
        )
        # Enable faster inference via Unsloth's optimized kernels
        FastLanguageModel.for_inference(self.model)
        print(f"[+] {model_id} loaded successfully in 4-bit mode.")

    def run_benchmark(self, prompt: str) -> float:
        if not self.model:
            raise ValueError("Model must be loaded before benchmarking.")
        
        start_time = time.time()
        # Tokenize and generate
        inputs = self.tokenizer([prompt], return_tensors="pt").to("cuda")
        outputs = self.model.generate(**inputs, max_new_tokens=64)
        end_time = time.time()
        
        latency = (end_time - start_time) * 1000 # Convert to ms
        return latency

# --- TESTING UTILITY (Monkey Patching) ---
def simulate_low_vram_error():
    """
    A utility to demonstrate how we can test our error handling 
    by monkey patching the torch.cuda.memory_allocated function.
    """
    # We dynamically replace the real memory function with a mock that returns a huge value
    # This simulates a scenario where the system thinks VRAM is full.
    torch.cuda.memory_allocated = lambda: 999999999999 
    print("[!] Monkey Patch Applied: Simulating VRAM exhaustion.")

# --- ORCHESTRATION LOGIC ---
def main():
    # List of models to evaluate (In a real scenario, these would be HuggingFace IDs)
    # For this script, we assume these models are accessible.
    target_models = [
        {"id": "unsloth/llama-3-8b-bnb-4bit", "seq": 2048},
        {"id": "unsloth/mistral-7b-v0.3-bnb-4bit", "seq": 4096}
    ]

    evaluator = UnslothEvaluator()

    for target in target_models:
        try:
            # 1. Load the model using the optimized Unsloth class
            evaluator.load_model(target["id"], target["seq"])

            # 2. Run the benchmark
            latency = evaluator.run_benchmark("Explain the concept of quantum entanglement.")

            # 3. Calculate VRAM usage (simulated for this script's logic)
            vram_val = torch.cuda.max_memory_allocated() / (1024**3)

            # 4. Persist results via SQLAlchemy
            new_metric = ModelMetric(
                model_name=target["id"],
                quantization="4-bit",
                latency_ms=latency,
                vram_usage_gb=vram_val
            )
            db_session.add(new_metric)
            db_session.commit()
            print(f"[SUCCESS] Logged {target['id']} | Latency: {latency:.2f}ms")

        except Exception as e:
            print(f"[ERROR] Failed to evaluate {target['id']}: {e}")
            db_session.rollback()

    # --- DEMONSTRATING MONKEY PATCHING ---
    print("\n--- Testing Error Handling with Monkey Patching ---")
    simulate_low_vram_error()
    # Now, any call to torch.cuda.memory_allocated() will return the fake value.
    print(f"Current simulated VRAM usage: {torch.cuda.memory_allocated()} bytes")

    # --- FINAL REPORT ---
    print("\n--- Final Evaluation Report from Database ---")
    results = db_session.query(ModelMetric).all()
    for res in results:
        print(f"Model: {res.model_name} | Latency: {res.latency_ms:.2f}ms | VRAM: {res.vram_usage_gb:.2f}GB")

if __name__ == "__main__":
    # Ensure we are in a CUDA environment for the script to be valid
    if torch.cuda.is_available():
        main()
    else:
        print("CUDA not detected. This script requires a GPU to demonstrate Unsloth features.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import json
from typing import List, Dict, Any, Optional
from jinja2 import Template, Environment, BaseLoader

# --- TEMPLATE DEFINITIONS (Using Jinja2 for Template Inheritance) ---

# The Base Template defines the core ChatML structure. 
# This follows the principle of Template Inheritance to ensure 
# that every child template adheres to the <|im_start|> and <|im_end|> protocol.
BASE_CHATML_TEMPLATE = """
{% block content %}{% endblock %}
"""

# The Instruction Template inherits from the Base. 
# It is optimized for single-turn, high-precision tasks.
INSTRUCTION_TEMPLATE = """
{% extends "base" %}
{% block content %}
<|im_start|>system
{{ system_prompt }}<|im_end|>
<|im_start|>user
{{ user_input }}<|im_end|>
<|im_start|>assistant
{{ assistant_response }}<|im_end|>
{% endblock %}
"""

# The Conversational Template inherits from the Base.
# It iterates through a list of messages to handle multi-turn dialogues.
CONVERSATIONAL_TEMPLATE = """
{% extends "base" %}
{% block content %}
{% if system_prompt %}
<|im_start|>system
{{ system_prompt }}<|im_end|>
{% endif %}
{% for message in messages %}
<|im_start|>{{ message.role }}
{{ message.content }}<|im_end|>
{% endfor %}
{% endblock %}
"""

class ChatMLFormatter:
    """
    A sophisticated formatter designed to map raw, heterogeneous data 
    into standardized ChatML strings using Jinja2 template inheritance.
    """

    def __init__(self):
        # Initialize the Jinja2 environment with a BaseLoader to handle inheritance
        self.env = Environment(loader=BaseLoader())
        # Register the base template in the environment so children can find it
        self.env.loader.templates['base'] = Template(BASE_CHATML_TEMPLATE)
        
        # Pre-compile templates for maximum performance during large-scale processing
        self.instruction_tpl = self.env.from_string(INSTRUCTION_TEMPLATE)
        self.conversation_tpl = self.env.from_string(CONVERSATIONAL_TEMPLATE)

    def format_single_turn(self, system_prompt: str, user_input: str, assistant_response: str) -> str:
        """Formats a single instruction-response pair."""
        return self.instruction_tpl.render(
            system_prompt=system_prompt,
            user_input=user_input,
            assistant_response=assistant_response
        ).strip()

    def format_multi_turn(self, system_prompt: Optional[str], messages: List[Dict[str, str]]) -> str:
        """Formats a full multi-turn conversation history."""
        return self.conversation_tpl.render(
            system_prompt=system_prompt,
            messages=messages
        ).strip()

    def process_raw_logs(self, raw_data: List[Dict[str, Any]]) -> List[Dict[str, str]]:
        """
        The primary entry point: Orchestrates the transformation of raw JSON 
        dictionaries into a list of ChatML formatted strings.
        """
        formatted_dataset = []

        for entry in raw_data:
            try:
                # Logic Branching: Determine the type of interaction based on data structure
                if "messages" in entry:
                    # Scenario A: Multi-turn conversation
                    system_msg = entry.get("system_instruction", "You are a helpful assistant.")
                    chat_history = entry["messages"]
                    formatted_text = self.format_multi_turn(system_msg, chat_history)
                
                elif "user_query" in entry:
                    # Scenario B: Single-turn instruction
                    system_msg = entry.get("context", "You are a helpful assistant.")
                    user_q = entry["user_query"]
                    assistant_a = entry["model_output"]
                    formatted_text = self.format_single_turn(system_msg, user_q, assistant_a)
                
                else:
                    # Scenario C: Unrecognized format, skip to prevent data corruption
                    continue

                formatted_dataset.append({"text": formatted_text})

            except Exception as e:
                # Error handling to ensure one bad log doesn't crash the entire pipeline
                print(f"Error processing entry {entry}: {e}")
                continue

        return formatted_dataset

# --- REAL-WORLD SIMULATION ---

if __name__ == "__main__":
    # Mocking a messy, real-world dataset containing mixed formats
    raw_input_logs = [
        # Type 1: Multi-turn conversation
        {
            "system_instruction": "You are a fintech expert.",
            "messages": [
                {"role": "user", "content": "What is a Roth IRA?"},
                {"role": "assistant", "content": "A Roth IRA is a tax-advantaged retirement account..."},
                {"role": "user", "content": "How does it differ from a Traditional IRA?"},
                {"role": "assistant", "content": "The main difference is tax treatment..."}
            ]
        },
        # Type 2: Single-turn instruction
        {
            "context": "You are a concise coding assistant.",
            "user_query": "Write a Python function for Fibonacci.",
            "model_output": "def fib(n): ..."
        },
        # Type 3: Malformed entry (to test robustness)
        {
            "garbage_key": "invalid_data"
        }
    ]

    # Initialize the Python Interpreter's execution of our formatter
    formatter = ChatMLFormatter()
    
    # Transform the data
    processed_data = formatter.process_raw_logs(raw_input_logs)

    # Output the results
    print("--- PROCESSED CHATML DATASET FOR UNSLOTH ---")
    for i, item in enumerate(processed_data):
        print(f"\n[Entry {i+1}]\n{item['text']}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# A simple implementation of a ChatML-style prompt formatter
# This code demonstrates how to convert raw dictionary data into a structured string

def format_chatml_template(messages):
    """
    Converts a list of message dictionaries into a single ChatML formatted string.
    
    Args:
        messages (list): A list of dicts, e.g., [{"role": "system", "content": "..."}, ...]
        
    Returns:
        str: The fully formatted prompt string.
    """
    # Initialize an empty list to store our formatted turn strings
    # We use a list for efficiency, joining at the end to avoid O(n^2) string concatenation
    formatted_turns = []

    # Iterate through each individual message turn in the conversation history
    for message in messages:
        # Extract the 'role' (system, user, or assistant) and the 'content' (the text)
        role = message["role"]
        content = message["content"]

        # Construct the ChatML block using an f-string
        # The format follows: <|im_start|>{role}\n{content}<|im_end|>\n
        chat_block = f"<|im_start|>{role}\n{content}<|im_end|>\n"
        
        # Append the constructed block to our collection of turns
        formatted_turns.append(chat_block)

    # Combine all formatted turns into one continuous string separated by nothing (since \n is included)
    full_prompt = "".join(formatted_turns)
    
    return full_prompt

# --- Test Data: Representing a standard multi-turn conversation ---
raw_conversation_data = [
    {
        "role": "system", 
        "content": "You are a helpful assistant that speaks like a pirate."
    },
    {
        "role": "user", 
        "content": "Hello! How are you today?"
    },
    {
        "role": "assistant", 
        "content": "Ahoy there, matey! I be sailin' the digital seas and feelin' fine!"
    },
    {
        "role": "user", 
        "content": "Where is the treasure hidden?"
    }
]

# --- Execution ---
# Pass the raw data through our formatter
final_prompt = format_chatml_template(raw_conversation_data)

# Print the result to see the structured output
print("--- FINAL FORMATTED PROMPT ---")
print(final_prompt)
print("------------------------------")

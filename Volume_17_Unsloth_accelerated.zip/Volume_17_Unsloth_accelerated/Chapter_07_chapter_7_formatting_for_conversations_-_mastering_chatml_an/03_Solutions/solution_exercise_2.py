
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

def map_medical_dataset(example: dict) -> dict:
    """
    Maps a single row from a medical dataset to a ChatML message list.
    """
    # Requirement 2: Define the static system prompt
    system_msg = {"role": "system", "content": "You are a professional medical assistant."}
    
    question = example.get("question", "")
    context = example.get("context", "")
    answer = example.get("answer", "")
    
    # Requirement 1 & 3: Build the user content with conditional context logic
    if context and context.strip():
        user_content = f"Question: {question}\nContext: {context}"
    else:
        user_content = f"Question: {question}"
    
    user_msg = {"role": "user", "content": user_content}
    assistant_msg = {"role": "assistant", "content": answer}
    
    # Requirement 4: Return the standard dictionary format for HF .map()
    return {
        "messages": [system_msg, user_msg, assistant_msg]
    }

# Mock dataset row
mock_row = {
    "question": "How do I treat a burn?",
    "context": "", # Test the empty context logic
    "answer": "Run cool water over the area."
}

print(map_medical_dataset(mock_row))

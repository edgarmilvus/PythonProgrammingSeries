
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from abc import ABC, abstractmethod

class BaseFormatter(ABC):
    @abstractmethod
    def format(self, messages: list[dict]) -> str:
        pass

class ChatMLFormatter(BaseFormatter):
    def format(self, messages: list[dict]) -> str:
        parts = []
        for msg in messages:
            role, content = msg["role"], msg["content"]
            parts.append(f"<|im_start|>{role}\n{content}<|im_end|>\n")
        return "".join(parts)

class AlpacaFormatter(BaseFormatter):
    def format(self, messages: list[dict]) -> str:
        # Requirement: Assume messages[0] contains 'instruction' and 'output'
        data = messages[0]
        return (
            "Below is an instruction that describes a task...\n\n"
            f"### Instruction:\n{data['instruction']}\n\n"
            f"### Response:\n{data['output']}"
        )

class MistralFormatter(BaseFormatter):
    def format(self, messages: list[dict]) -> str:
        # Mistral uses [INST] {user} [/INST] {assistant}
        # We assume a simple two-turn structure for this implementation
        user_msg = messages[0]["content"]
        assistant_msg = messages[1]["content"]
        return f"[INST] {user_msg} [/INST] {assistant_msg}"

class TemplateFactory:
    @staticmethod
    def get_formatter(format_type: str) -> BaseFormatter:
        if format_type == "chatml":
            return ChatMLFormatter()
        elif format_type == "alpaca":
            return AlpacaFormatter()
        elif format_type == "mistral":
            return MistralFormatter()
        else:
            raise ValueError(f"Unknown format type: {format_type}")

# --- TEST SCRIPT ---
messages = [
    {"role": "user", "content": "What is Python?"},
    {"role": "assistant", "content": "A programming language."}
]

# 1. Test ChatML
try:
    formatter = TemplateFactory.get_formatter("chatml")
    print("--- ChatML Output ---")
    print(formatter.format(messages))
except Exception as e:
    print(f"ChatML Error: {e}")

# 2. Test Mistral
try:
    formatter = TemplateFactory.get_formatter("mistral")
    print("\n--- Mistral Output ---")
    print(formatter.format(messages))
except Exception as e:
    print(f"Mistral Error: {e}")

# 3. Test Alpaca (using specific schema)
try:
    alpaca_msgs = [{"instruction": "Explain gravity.", "output": "It is a force..."}]
    formatter = TemplateFactory.get_formatter("alpaca")
    print("\n--- Alpaca Output ---")
    print(formatter.format(alpaca_msgs))
except Exception as e:
    print(f"Alpaca Error: {e}")

# 4. Test Unknown
try:
    formatter = TemplateFactory.get_formatter("llama3")
    print(formatter.format(messages))
except ValueError as e:
    print(f"\nExpected Error Caught: {e}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import re

class ChatMLValidator:
    def __init__(self, chatml_strings: list[str]):
        self.chatml_strings = chatml_strings
        self.report = {
            "total_processed": len(chatml_strings),
            "passed": 0,
            "failed": 0,
            "errors": []
        }

    def validate_single(self, chat_str: str) -> tuple[bool, str]:
        if not chat_str.strip():
            return False, "Empty string"

        # Rule 3: Boundary Integrity (Check if all starts have ends)
        starts = chat_str.count("<|im_start|>")
        ends = chat_str.count("<|im_end|>")
        if starts != ends:
            return False, f"Boundary mismatch: {starts} starts vs {ends} ends"

        # Regex to extract all role/content blocks
        # Pattern looks for: <|im_start|>{role}\n{content}<|im_end|>
        pattern = r"<\|im_start\|>(\w+)\n(.*?)(?=<\|im_end\|>)"
        matches = list(re.finditer(pattern, chat_str, re.DOTALL))
        
        if not matches:
            return False, "No valid ChatML blocks found"

        roles = []
        for m in matches:
            role = m.group(1)
            # Rule 4: Role Validity
            if role not in ["system", "user", "assistant"]:
                return False, f"Invalid role: {role}"
            roles.append(role)

        # Rule 1: Role Sequence (Cannot start with assistant)
        if roles[0] == "assistant":
            return False, "Started with assistant role"

        # Rule 2: Alternation (User and Assistant must alternate)
        for i in range(len(roles) - 1):
            current_role = roles[i]
            next_role = roles[i+1]
            # System can repeat or be followed by anything, 
            # but User/Assistant must alternate.
            if current_role in ["user", "assistant"] and next_role == current_role:
                return False, f"Consecutive {current_role} messages"

        return True, ""

    def validate_all(self) -> dict:
        for idx, s in enumerate(self.chatml_strings):
            is_valid, error_msg = self.validate_single(s)
            if is_valid:
                self.report["passed"] += 1
            else:
                self.report["failed"] += 1
                self.report["errors"].append({"index": idx, "reason": error_msg})
        return self.report

# Test Data
test_dataset = [
    "<|im_start|>system\nYou are a bot.<|im_end|>\n<|im_start|>user\nHi!<|im_end|>\n<|im_start|>assistant\nHello!<|im_end|>", # Valid
    "<|im_start|>assistant\nI am here.<|im_end|>", # Invalid: Starts with assistant
    "<|im_start|>user\nHello!<|im_start|>user\nHow are you?<|im_end|>", # Invalid: Consecutive users & missing end token
    "<|im_start|>user\nValid!<|im_end|>\n<|im_start|>unknown\nError!<|im_end|>" # Invalid: Unknown role
]

validator = ChatMLValidator(test_dataset)
import json
print(json.dumps(validator.validate_all(), indent=4))

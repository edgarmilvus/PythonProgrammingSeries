
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import copy

def format_chatml_with_task(messages: list[dict], task_instruction: str = None) -> str:
    """
    MODIFICATION TASK:
    Inject a task instruction into the first 'user' message.
    """
    # Requirement 4: Deep copy to prevent mutating the input list
    working_messages = copy.deepcopy(messages)
    
    # Requirement 2: Injection Logic
    if task_instruction:
        user_found = False
        for msg in working_messages:
            if msg.get("role") == "user":
                # Append the instruction with double newline
                msg["content"] = f"{msg['content']}\n\nTASK: {task_instruction}"
                user_found = True
                break # Only inject into the FIRST user message
        
        if not user_found:
            # Requirement 2: Handle case where no user role exists
            return "" # Or raise ValueError as per instructions

    # Requirement 5: Standard ChatML construction (re-using logic from Ex 1)
    chatml_parts = []
    for msg in working_messages:
        role = msg.get("role", "")
        content = msg.get("content", "")
        if content.strip():
            chatml_parts.append(f"<|im_start|>{role}\n{content}<|im_end|>\n")
            
    return "".join(chatml_parts)

# Test Case
test_messages = [
    {"role": "system", "content": "You are a math tutor."},
    {"role": "user", "content": "Solve for x: 2x = 10"},
    {"role": "assistant", "content": "x = 5"}
]
instruction = "Show all steps clearly."

result = format_chatml_with_task(test_messages, instruction)
print(result)

# Verify Immutability
print(f"\nOriginal first user message: {test_messages[1]['content']}")

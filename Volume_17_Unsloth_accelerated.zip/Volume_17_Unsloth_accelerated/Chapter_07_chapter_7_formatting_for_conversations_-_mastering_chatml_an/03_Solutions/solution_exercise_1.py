
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

def convert_to_chatml(messages: list[dict]) -> str:
    """
    Converts a list of message dictionaries into a single ChatML formatted string.
    """
    chatml_parts = []
    
    for msg in messages:
        # Extract role and content, defaulting to empty if keys are missing
        role = msg.get("role", "")
        content = msg.get("content", "")
        
        # Requirement 4: Skip if content is empty or just whitespace
        if not content or not content.strip():
            continue
            
        # Requirement 2 & 3: Construct the block with specific tokens and newlines
        # Format: <|im_start|>{role}\n{content}<|im_end|>\n
        block = f"<|im_start|>{role}\n{content}<|im_end|>\n"
        chatml_parts.append(block)
    
    # Requirement 6: Return a new string (concatenation creates a new object)
    return "".join(chatml_parts)

# Test Data
raw_logs = [
    {"role": "system", "content": "You are a helpful assistant."},
    {"role": "user", "content": "What is the capital of France?"},
    {"role": "assistant", "content": "The capital of France is Paris."},
    {"role": "user", "content": "  "},  # Should be skipped
    {"role": "user", "content": "Tell me a joke."},
    {"role": "assistant", "content": "Why did the programmer quit his job? Because he didn't get arrays (a raise)."}
]

print(convert_to_chatml(raw_logs))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import wandb
import torch
from unsloth import FastLanguageModel
from trl import SFTTrainer
from transformers import TrainingArguments, TrainerCallback

# --- DRY Principle: Centralized Configuration Factory ---
def get_training_config(project_name, run_name, learning_rate=2e-4):
    """
    Returns a standardized dictionary of training hyperparameters.
    This prevents repetition across different training scripts.
    """
    return {
        "project_name": project_name,
        "run_name": run_name,
        "learning_rate": learning_rate,
        "max_seq_length": 2048,
        "load_in_4bit": True,
    }

# --- EAFP Principle: Robust Metric Extraction ---
class StabilityMonitorCallback(TrainerCallback):
    """
    A custom callback that monitors training stability.
    Uses EAFP (Easier to Ask for Forgiveness than Permission) to 
    extract metrics from the trainer state without heavy conditional checks.
    """
    def on_log(self, args, state, control, logs=None, **kwargs):
        try:
            # Attempt to extract the loss directly
            current_loss = logs["loss"]
            
            # If loss is NaN or Inf, we trigger an emergency stop
            if not torch.isfinite(torch.tensor(current_loss)):
                print(f"\n[CRITICAL] Divergence detected! Loss: {current_loss}. Terminating...")
                control.should_training_stop = True
                
            # Log custom hardware-related telemetry to W&B via the trainer's internal state
            # This demonstrates how we can augment standard logs
            wandb.log({"stability/loss_is_finite": 1.0 if torch.isfinite(torch.tensor(current_loss)) else 0.0})
            
        except (KeyError, TypeError, ValueError):
            # If 'loss' isn't in logs yet, we simply ignore it (EAFP)
            # rather than checking 'if "loss" in logs' (LBYL)
            pass

def run_fine_tuning_pipeline():
    # 1. Setup Configuration and W&B Initialization
    config = get_training_config("fintech-compliance-llama3", "llama3-compliance-v1-run")
    
    # Initialize W&B to track this specific experiment
    wandb.init(
        project=config["project_name"],
        name=config["run_name"],
        config=config  # Log hyperparameters for comparative analysis later
    )

    # 2. Load Model and Tokenizer using Unsloth for extreme efficiency
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name="unsloth/llama-3-8b-bnb-4bit",
        max_seq_length=config["max_seq_length"],
        load_in_4bit=config["load_in_4bit"],
    )

    # 3. Add LoRA adapters for efficient fine-tuning
    model = FastLanguageModel.get_peft_model(
        model,
        r=16,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
        lora_alpha=16,
        lora_dropout=0,
        bias="none",
    )

    # 4. Define Training Arguments with W&B Integration
    # The 'report_to="wandb"' argument is the bridge between HF and W&B
    training_args = TrainingArguments(
        per_device_train_batch_size=2,
        gradient_accumulation_steps=4,
        warmup_steps=5,
        max_steps=60,  # Small steps for demonstration
        learning_rate=config["learning_rate"],
        fp16=not torch.cuda.is_bf16_supported(),
        bf16=torch.cuda.is_bf16_supported(),
        logging_steps=1,
        optim="adamw_8bit",
        weight_decay=0.01,
        lr_scheduler_type="linear",
        seed=3407,
        output_dir="outputs",
        report_to="wandb",  # CRITICAL: Enables automatic W&B logging
    )

    # 5. Initialize the Trainer
    # We pass our custom StabilityMonitorCallback to catch divergence
    trainer = SFTTrainer(
        model=model,
        tokenizer=tokenizer,
        train_dataset=None,  # In a real scenario, pass your formatted dataset here
        dataset_text_field="text",
        max_seq_length=config["max_seq_length"],
        args=training_args,
        callbacks=[StabilityMonitorCallback()],
    )

    # 6. Execute Training
    print(f"Starting training run: {config['run_name']}")
    try:
        # Note: We use a dummy training loop/data for the sake of the script's completeness
        # In production, trainer.train() would be called here.
        trainer.train()
    except Exception as e:
        # Catching unexpected errors to ensure we log the failure to W&B before crashing
        wandb.alert(title="Training Crash", text=str(e))
        raise e
    finally:
        # 7. Finalize the experiment
        wandb.finish()
        print("Training session completed and W&B logs uploaded.")

if __name__ == "__main__":
    run_fine_tuning_pipeline()

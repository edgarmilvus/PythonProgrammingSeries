
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Import the Weights & Biases library to handle experiment tracking
import wandb

# Import Unsloth's FastLanguageModel for optimized LLM loading and fine-tuning
from unsloth import FastLanguageModel

# Import the SFTTrainer from the TRL library, which simplifies Supervised Fine-Tuning
from trl import SFTTrainer

# Import TrainingArguments from Transformers to configure the training loop
from transformers import TrainingArguments

# Import the datasets library to handle data loading and preprocessing
from datasets import load_dataset

# 1. Initialize the W&B run to create a new entry in our dashboard
# We define the project name and a specific run name for this experiment
wandb.init(
    project="unsloth-basic-demo", 
    name="hello-world-run",
    config={"learning_rate": 2e-4, "epochs": 1} # Store metadata for later comparison
)

# 2. Load the model and tokenizer using Unsloth's optimized loading mechanism
# This reduces VRAM usage significantly compared to standard loading
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name = "unsloth/llama-3-8b-bnb-4bit", # A quantized, ready-to-use model
    max_seq_length = 2048,                     # The maximum context window
    load_in_4bit = True,                       # Use 4-bit quantization for efficiency
)

# 3. Add LoRA (Low-Rank Adaptation) adapters to the model
# This allows us to fine-tune only a tiny fraction of the parameters
model = FastLanguageModel.get_peft_model(
    model,
    r = 16,                        # Rank of the adaptation layers
    target_modules = ["q_proj", "k_proj", "v_proj", "o_proj"], # Which layers to tune
    lora_alpha = 16,               # Scaling factor for the LoRA weights
    lora_dropout = 0,              # Dropout rate for regularization
    bias = "none",                 # Whether to train bias terms
)

# 4. Prepare a tiny dataset for the demonstration
# In a real scenario, you would load your own instruction-following dataset
dataset = load_dataset("philschmid/instruction-format-alpaca-tiny", split="train")

# 5. Define the Training Arguments
# The 'report_to' parameter is the most critical part of this integration
training_args = TrainingArguments(
    output_dir = "./outputs",             # Where to save the model checkpoints
    per_device_train_batch_size = 2,      # Number of samples per GPU step
    gradient_accumulation_steps = 4,      # Number of steps to accumulate before updating
    warmup_steps = 5,                     # Number of steps to gradually increase LR
    max_steps = 20,                       # Total number of training steps for this demo
    learning_rate = 2e-4,                 # The step size for weight updates
    fp16 = True,                          # Use mixed-precision training for speed
    logging_steps = 1,                    # How often to log metrics to W&B
    report_to = "wandb",                  # CRITICAL: This sends data to W&B
)

# 6. Initialize the SFTTrainer
# This combines the model, the dataset, and the arguments into a single engine
trainer = SFTTrainer(
    model = model,
    train_dataset = dataset,
    dataset_text_field = "text",          # The column name containing the text
    max_seq_length = 2048,
    tokenizer = tokenizer,
    args = training_args,                 # Pass the W&B-enabled arguments here
)

# 7. Execute the training loop
# This is where the actual computation happens and logs are sent to the cloud
trainer.train()

# 8. Finalize the W&B run
# This ensures all remaining logs are uploaded and the dashboard marks the run as 'Finished'
wandb.finish()

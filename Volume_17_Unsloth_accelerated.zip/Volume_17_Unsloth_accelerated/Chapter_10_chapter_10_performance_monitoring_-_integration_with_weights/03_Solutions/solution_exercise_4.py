
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import wandb
import torch
import gc
from unsloth import FastLanguageModel

# Requirement 1: Define the Sweep Configuration
sweep_config = {
    'method': 'bayes',
    'metric': {'name': 'eval_loss', 'goal': 'minimize'},
    'parameters': {
        'learning_rate': {'distribution': 'log_uniform_values', 'min': 5e-5, 'max': 5e-4},
        'lora_r': {'values': [8, 16, 32, 64]},
        'lora_alpha': {'values': [16, 32, 64]}
    }
}

def train_function():
    """
    Requirement 2: The core training function called by the W&B Agent.
    """
    # Initialize W&B (config is provided by the sweep controller)
    run = wandb.init()
    config = wandb.config
    
    # Requirement 4: Re-initialize Unsloth model inside the function for a clean state
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name="unsloth/llama-3-8b-bnb-4bit",
        max_seq_length=2048,
        load_in_4bit=True,
    )

    model = FastLanguageModel.get_peft_model(
        model,
        r=config.lora_r,          # Mapping sweep config to LoRA
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
        lora_alpha=config.lora_alpha,
        lora_dropout=0,
    )

    # Requirement 5: Data loading logic (assumed to be efficient/cached)
    # dataset = load_medical_dataset() 

    # Setup Trainer with sweep parameters
    # trainer = SFTTrainer(
    #     model=model,
    #     args=TrainingArguments(
    #         learning_rate=config.learning_rate,
    #         report_to="wandb",
    #         eval_strategy="steps",
    #         eval_steps=50,
    #         ...
    #     ),
    #     ...
    # )
    # trainer.train()
    
    # Requirement 4: The "Clean Slate" - Explicitly clear memory
    del model
    del tokenizer
    gc.collect()
    torch.cuda.empty_cache()

# Requirement 3: Execution
if __name__ == "__main__":
    sweep_id = wandb.sweep(sweep_config, project="unsloth-medical-finetune")
    wandb.agent(sweep_id, function=train_function, count=10)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import torch
import wandb
from transformers import TrainerCallback

class MemoryLoggingCallback(TrainerCallback):
    """
    Custom callback to audit hardware efficiency during training.
    """
    def on_evaluate(self, args, state, control, **kwargs):
        # Requirement 2 & 3: Custom memory logging
        try:
            # EAFP: Assume GPU is available, handle if it's not
            if torch.cuda.is_available():
                # Calculate percentage of total reserved memory currently used
                allocated = torch.cuda.memory_allocated()
                reserved = torch.cuda.memory_reserved()
                
                # We log the ratio of allocated to reserved as a proxy for utilization
                # or simply the raw allocated bytes. Here we use percentage of reserved.
                usage_percent = (allocated / reserved) * 100 if reserved > 0 else 0
                
                wandb.log({"system/gpu_memory_usage_percent": usage_percent})
        except Exception as e:
            print(f"Failed to query GPU metrics: {e}")

def stress_test_batch_sizes(model, tokenizer, dataset):
    """
    Requirement 4: Loop through increasing batch sizes to find OOM threshold.
    """
    batch_sizes = [2, 4, 8]
    
    for b_size in batch_sizes:
        print(f"Testing Batch Size: {b_size}")
        
        # Re-initialize W&B for each stress test run
        wandb.init(project="unsloth-medical-finetune", name=f"stress-test-bs-{b_size}")
        
        try:
            training_args = TrainingArguments(
                per_device_train_batch_size=b_size,
                report_to="wandb",
                # ... other args
            )
            
            # In real implementation, trainer would include the callback
            # trainer = SFTTrainer(..., callbacks=[MemoryLoggingCallback()])
            # trainer.train()
            
            print(f"Batch size {b_size} passed.")
            
        except Exception as e:
            print(f"Batch size {b_size} triggered OOM or error: {e}")
        finally:
            wandb.finish()
            # Clear cache to ensure the next iteration has a clean slate
            torch.cuda.empty_cache()

# DATA VISUALIZATION STRATEGY (Requirement 5):
# To identify the OOM threshold, use the W&B "Line Plot" feature.
# Overlay 'train/loss' on the primary Y-axis and 'system/gpu_memory_usage_percent' 
# on the secondary Y-axis. If memory usage hits ~95% and loss becomes unstable 
# (spikes), it indicates that the batch size is too high for the current VRAM.


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
import wandb
from datetime import datetime
from trl import SFTTrainer
from transformers import TrainingArguments

def initialize_wandb_experiment(config_params, experiment_name="med-llama3"):
    """
    Encapsulated function to initialize W&B following DRY principles.
    """
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    run_name = f"{experiment_name}-{timestamp}"
    
    # Initialize the W&B run
    run = wandb.init(
        project="unsloth-medical-finetune",
        name=run_name,
        config=config_params # Requirement 3: Log hyperparameters immediately
    )
    return run

def run_training_workflow(hyperparams):
    """
    Main training wrapper implementing EAFP for clean exits.
    """
    # Requirement 1 & 5: Reusable initialization
    run = initialize_wandb_experiment(hyperparams)
    
    try:
        # Mocking the Unsloth/SFTTrainer setup for demonstration
        # In a real scenario, 'model' and 'dataset' would be loaded here
        training_args = TrainingArguments(
            output_dir="./outputs",
            per_device_train_batch_size=hyperparams['batch_size'],
            learning_rate=hyperparams['learning_rate'],
            logging_steps=10,
            # Requirement 2: Configure Trainer to report to wandb
            report_to="wandb", 
            push_to_hub=False,
        )

        print(f"Starting training run: {run.name}")
        
        # trainer = SFTTrainer(
        #     model=model,
        #     args=training_args,
        #     train_dataset=dataset,
        #     ...
        # )
        # trainer.train()
        
        # Simulating training for demonstration
        import time
        time.sleep(2) 
        print("Training completed successfully.")

    except Exception as e:
        # Requirement 4: Handle unexpected crashes
        print(f"Training interrupted by error: {e}")
        raise e
    finally:
        # Requirement 4: Ensure clean exit (EAFP) to prevent zombie runs
        wandb.finish()
        print("W&B run closed safely.")

# Example usage
if __name__ == "__main__":
    # Ensure WANDB_API_KEY is in environment variables, not hardcoded
    config = {
        "learning_rate": 2e-4,
        "r": 16,
        "alpha": 32,
        "batch_size": 4
    }
    run_training_workflow(config)

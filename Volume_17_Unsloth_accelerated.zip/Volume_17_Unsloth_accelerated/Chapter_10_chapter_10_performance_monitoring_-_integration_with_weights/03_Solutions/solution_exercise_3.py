
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import wandb
import torch
from transformers import TrainerCallback

def generate_model_response(model, tokenizer, prompt, max_new_tokens=128):
    """
    Requirement 4: Standalone generation function (DRY).
    """
    # Requirement 5: Handle padding side for decoder-only models (Llama-3)
    # Left-padding is mandatory for batch generation to avoid attention issues
    tokenizer.padding_side = "left" 
    
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    
    with torch.no_grad():
        outputs = model.generate(
            **inputs, 
            max_new_tokens=max_new_tokens,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id
        )
    
    # Decode only the newly generated tokens
    generated_text = tokenizer.decode(outputs[0][inputs['input_ids'].shape[1]:], skip_special_tokens=True)
    return generated_text

class QualitativeEvalCallback(TrainerCallback):
    """
    Requirement 2: Callback to log model generations to W&B Tables.
    """
    def __init__(self, eval_dataset, tokenizer, model):
        self.eval_dataset = eval_dataset
        self.tokenizer = tokenizer
        self.model = model
        # Requirement 1: Initialize the Table
        self.table = wandb.Table(columns=["Prompt", "Ground Truth", "Model Generation", "Token Count"])

    def on_evaluate(self, args, state, control, **kwargs):
        print("Performing qualitative evaluation...")
        # Limit to small sample to avoid massive delays (Requirement 5)
        sample_size = min(5, len(self.eval_dataset))
        
        for i in range(sample_size):
            item = self.eval_dataset[i]
            prompt = item['prompt']
            ground_truth = item['response']
            
            # Generate response
            generation = generate_model_response(self.model, self.tokenizer, prompt)
            
            # Calculate token count
            token_count = len(self.tokenizer.encode(generation))
            
            # Requirement 2: Populate the table
            self.table.add_data(prompt, ground_truth, generation, token_count)
        
        # Requirement 3: Log the table to W&B
        wandb.log({"eval_samples": self.table})


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import wandb

def get_run_metric(run, metric_name):
    """
    Requirement 6: Helper function using EAFP to safely retrieve metrics.
    """
    try:
        # Access the summary object which contains final/best values
        return run.summary.get(metric_name)
    except (AttributeError, KeyError):
        return None

def analyze_experiments(project_name):
    api = wandb.Api()
    # Requirement 2: Iterate through runs in the project
    runs = api.runs(f"{api.default_entity}/{project_name}")
    
    results = []

    for run in runs:
        # Requirement 3: Extract metrics
        eval_loss = get_run_metric(run, "eval_loss")
        peak_vram = get_run_metric(run, "system/gpu_memory_usage_percent")
        lr = get_run_metric(run, "learning_rate")

        # Only process runs that completed successfully with all metrics
        if eval_loss is not None and peak_vram is not None:
            # Requirement 4: Custom Scoring Logic
            # Score = 1 / (loss * vram) -> Higher is better
            score = 1.0 / (eval_loss * peak_vram)
            
            results.append({
                "id": run.name,
                "loss": round(eval_loss, 4),
                "vram": round(peak_vram, 2),
                "lr": lr,
                "score": score
            })

    # Sort by score descending
    results.sort(key=lambda x: x['score'], reverse=True)

    # Requirement 5: Report Generation (Markdown Table)
    print(f"\n### Top 5 Optimal Runs for {project_name}\n")
    print("| Run Name | Eval Loss | Peak VRAM (%) | Learning Rate | Score |")
    print("| :--- | :--- | :--- | :--- | :--- |")
    
    for res in results[:5]:
        print(f"| {res['id']} | {res['loss']} | {res['vram']} | {res['lr']} | {res['score']:.6f} |")

if __name__ == "__main__":
    analyze_experiments("unsloth-medical-finetune")

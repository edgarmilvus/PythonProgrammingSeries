
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Import the necessary libraries for high-performance fine-tuning
from unsloth import FastLanguageModel
import torch
from peft import LoraConfig, get_peft_model

# --- STEP 1: Hyperparameter Configuration ---
# We define the 'Rank' (r), which determines the size of our low-rank matrices.
# A higher r allows for more complex learning but uses more memory.
r = 16 

# We define 'Alpha' (alpha), the scaling factor for the LoRA weights.
# A common rule of thumb is to set alpha = 2 * r.
lora_alpha = 32 

# We define the 'Target Modules'. These are the specific layers in the 
# Transformer architecture that we will attach our LoRA adapters to.
target_modules = ["q_proj", "k_proj", "v_proj", "o_proj"]

# --- STEP 2: Model and Tokenizer Loading ---
# We load the model in 4-bit quantization to drastically reduce VRAM usage.
# This is the 'Q' in QLoRA.
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name = "unsloth/llama-3-8b-bnb-4bit", # The pre-quantized base model
    max_seq_length = 2048,                     # Maximum sequence length
    load_in_4bit = True,                       # Enable 4-bit quantization
)

# --- STEP 3: LoRA Adapter Injection ---
# We apply the LoRA configuration to the loaded model.
# This wraps the base model and prepares it for efficient training.
model = FastLanguageModel.get_peft_model(
    model,
    r = r,                                     # The Rank
    target_modules = target_modules,           # Which layers to adapt
    lora_alpha = lora_alpha,                   # Scaling factor
    lora_dropout = 0,                          # Dropout for regularization
    bias = "none",                             # Whether to train bias terms
)

# Print the summary to verify the number of trainable parameters
print(f"Trainable parameters: {model.get_nb_trainable_parameters()}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import logging
from flask import Flask, Blueprint, request, jsonify

# --- CONFIGURATION & MODELS ---

class LoRAHyperparameters:
    """
    A data structure representing the mathematical core of a LoRA adaptation.
    Encapsulates Rank (r), Alpha (alpha), and the target layers.
    """
    def __init__(self, r: int, alpha: int, target_modules: list):
        self.r = r
        self.alpha = alpha
        self.target_modules = target_modules
        # The scaling factor is a critical component of the LoRA update rule
        self.scaling_factor = alpha / r

    def validate(self):
        """Ensures the hyperparameter configuration is mathematically sound."""
        if self.r <= 0:
            raise ValueError("Rank (r) must be a positive integer.")
        if self.alpha <= 0:
            raise ValueError("Alpha must be a positive value.")
        if not self.target_modules:
            raise ValueError("At least one target module must be specified.")
        return True

# --- BLUEPRINTS ---

# Blueprint for managing the definition of fine-tuning experiments
config_blueprint = Blueprint('config_manager', __name__)

# Blueprint for handling the execution of training jobs
execution_blueprint = Blueprint('job_executor', __name__)

# --- ROUTE HANDLERS: CONFIGURATION ---

@config_blueprint.route('/validate_config', methods=['POST'])
def validate_config():
    """
    Endpoint to validate a proposed LoRA configuration before 
    committing expensive GPU resources.
    """
    data = request.get_json()
    try:
        # Extracting parameters from the request body
        r = data.get('r')
        alpha = data.get('alpha')
        modules = data.get('target_modules')

        # Constructing the hyperparameter object
        params = LoRAHyperparameters(r, alpha, modules)
        
        # Validating the mathematical integrity
        params.validate()

        return jsonify({
            "status": "valid",
            "scaling_factor": params.scaling_factor,
            "message": f"Configuration with r={r} and alpha={alpha} is stable."
        }), 200

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 400

# --- ROUTE HANDLERS: EXECUTION ---

# Mock database to track active training jobs
active_jobs = {}

@execution_blueprint.route('/submit_job', methods=['POST'])
def submit_job():
    """
    Endpoint to submit a fine-tuning job. In a real system, this would
    interface with a job scheduler like Slurm or a Kubernetes cluster.
    """
    data = request.get_json()
    job_id = f"job_{len(active_jobs) + 1}"
    
    # In a real-world scenario, we would pass these params to Unsloth
    # e.g., lora_config = LoraConfig(r=data['r'], alpha=data['alpha']...)
    active_jobs[job_id] = {
        "params": data,
        "status": "queued",
        "target_modules": data.get('target_modules')
    }

    return jsonify({
        "job_id": job_id,
        "status": "queued",
        "message": "LoRA fine-tuning job submitted to GPU cluster."
    }), 202

@execution_blueprint.route('/job_status/<job_id>', methods=['GET'])
def get_status(job_id):
    """Retrieves the current status of a specific fine-tuning job."""
    job = active_jobs.get(job_id)
    if not job:
        return jsonify({"error": "Job not found"}), 404
    return jsonify(job), 200

# --- APPLICATION FACTORY ---

def create_app():
    """
    The Application Factory. This function encapsulates the creation 
    of the Flask instance, allowing for modularity and easier testing.
    """
    app = Flask(__name__)
    
    # Configure logging for experiment tracking
    logging.basicConfig(level=logging.INFO)
    app.logger.info("Initializing LoRA Orchestration Engine...")

    # Registering Blueprints to decouple configuration from execution
    app.register_blueprint(config_blueprint, url_prefix='/api/config')
    app.register_blueprint(execution_blueprint, url_prefix='/api/execute')

    return app

# --- ENTRY POINT ---

if __name__ == '__main__':
    # Create the application instance via the factory
    orchestrator = create_app()
    # Run the server (In production, use Gunicorn or uWSGI)
    orchestrator.run(debug=True, port=5000)

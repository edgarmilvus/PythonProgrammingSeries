
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np

def calculate_scaling_factor(rank, alpha):
    """Tier 1: Calculates the alpha/r ratio."""
    if rank <= 0:
        raise ValueError("Rank must be a positive integer.")
    return alpha / rank

def run_simulator(configs, baseline=None):
    """Tier 2: Compares configurations against a baseline."""
    print(f"{'Rank':<6} | {'Alpha':<6} | {'Scale':<8} | {'% Change':<10} | {'Status'}")
    print("-" * 55)
    
    baseline_scale = 1.0
    if baseline:
        baseline_scale = calculate_scaling_factor(baseline[0], baseline[1])

    for r, a in configs:
        try:
            scale = calculate_scaling_factor(r, a)
            
            # Calculate percentage change relative to baseline
            pct_change = ((scale - baseline_scale) / baseline_scale) * 100 if baseline else 0.0
            
            # Warning system
            status = ""
            if baseline:
                ratio_to_baseline = scale / baseline_scale
                if ratio_to_baseline < 0.5 or ratio_to_baseline > 2.0:
                    status = "[WARNING: DRASTIC SCALE SHIFT]"
            
            # High intensity check (Edge Case 2)
            if scale > 10:
                status += " [HIGH-INTENSITY UPDATE]"

            print(f"{r:<6} | {a:<6} | {scale:<8.2f} | {pct_change:>8.1f}% | {status}")
        except ValueError as e:
            print(f"{r:<6} | {a:<6} | ERROR: {e}")

def simulate_weight_magnitudes():
    """Tier 3: Simulates effective update magnitudes using NumPy."""
    print("\n--- Tier 3: Weight Magnitude Estimation ---")
    r_values = np.arange(4, 132, 4)
    base_w_mean = 1.0
    low_rank_product_mean = 0.01
    
    # Scenario A: Fixed Alpha = 32
    alpha_fixed = 32
    scales_a = alpha_fixed / r_values
    effective_updates_a = scales_a * low_rank_product_mean
    
    # Scenario B: Constant Ratio (alpha/r = 2.0)
    # To keep ratio constant, alpha must scale with r (alpha = 2 * r)
    scales_b = 2.0 * np.ones_like(r_values)
    effective_updates_b = scales_b * low_rank_product_mean

    print(f"{'Rank':<6} | {'Fixed Alpha (32) Update':<25} | {'Constant Ratio Update':<25}")
    for i in range(len(r_values)):
        print(f"{r_values[i]:<6} | {effective_updates_a[i]:<25.5f} | {effective_updates_b[i]:<25.5f}")

# Execution
if __name__ == "__main__":
    # Tier 1 & 2 Test
    test_configs = [(8, 16), (16, 32), (32, 32), (64, 128), (4, 512), (0, 16)]
    baseline_config = (8, 16) # Scale = 2.0
    
    print("Running Hyperparameter Impact Simulator...")
    run_simulator(test_configs, baseline=baseline_config)
    
    # Tier 3 Test
    simulate_weight_magnitudes()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

class ModuleScanner:
    def __init__(self, model_named_modules):
        """
        Simulates a model's named_modules() output.
        model_named_modules: List of strings representing module paths.
        """
        self.modules = model_named_modules
        self.profiles = {
            "Standard": ["q_proj", "k_proj", "v_proj", "o_proj"],
            "Llama_MLP": ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
            "Legacy": ["query", "key", "value", "output"]
        }

    def find_by_profile(self, profile_name):
        """Tier 2: Matches modules against a predefined architecture profile."""
        patterns = self.profiles.get(profile_name, [])
        return [m for m in self.modules if any(p in m for p in patterns)]

    def heuristic_discovery(self):
        """Tier 3: Advanced heuristic scanning."""
        target_modules = []
        # Non-targetable patterns to filter out
        blacklist = ["norm", "embed", "layernorm", "bias"]
        
        for m in self.modules:
            # Rule 1: Contains 'proj' or 'dense'
            # Rule 2: Does not contain blacklist terms (simulating nn.Linear check)
            is_linear_candidate = "proj" in m or "dense" in m
            is_not_blacklisted = not any(b in m.lower() for b in blacklist)
            
            if is_linear_candidate and is_not_blacklisted:
                target_modules.append(m)
        
        return sorted(target_modules)

# --- Simulation Setup ---
mock_model_modules = [
    "model.layers.0.self_attn.q_proj",
    "model.layers.0.self_attn.k_proj",
    "model.layers.0.self_attn.v_proj",
    "model.layers.0.self_attn.o_proj",
    "model.layers.0.mlp.gate_proj",
    "model.layers.0.mlp.up_proj",
    "model.layers.0.mlp.down_proj",
    "model.layers.0.attention.dense_layer",
    "model.layers.0.norm.layer_norm",
    "model.embed.embedding.weight",
    "model.layers.0.mlp.norm_proj_fake" # Should be filtered by blacklist
]

# Execution
scanner = ModuleScanner(mock_model_modules)

print("--- Profile Match (Llama_MLP) ---")
print(scanner.find_by_profile("Llama_MLP"))

print("\n--- Heuristic Discovery ---")
print(scanner.heuristic_discovery())

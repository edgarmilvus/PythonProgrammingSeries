
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

class LoRAConfig:
    def __init__(self, r, alpha, target_modules, layers=80, hidden_dim=8192):
        self.r = r
        self.alpha = alpha
        self.target_modules = target_modules
        self.layers = layers
        self.hidden_dim = hidden_dim
        
        # Requirement 2: Validate scaling consistency (alpha/r should be 2.0)
        self.scaling_factor = self.alpha / self.r

    def get_summary(self):
        """Requirement 3: Print configuration summary."""
        # Simplified parameter formula: 2 * layers * hidden_dim * r * num_modules
        est_params = 2 * self.layers * self.hidden_dim * self.r * len(self.target_modules)
        
        print("--- LoRA Configuration Summary ---")
        print(f"Rank: {self.r}")
        print(f"Alpha: {self.alpha}")
        print(f"Scaling Factor (α/r): {self.scaling_factor:.2f}")
        print(f"Target Modules: {self.target_modules}")
        print(f"Estimated Trainable Parameters: {est_params:,}")
        print("-" * 34)

    def validate_vram_safety(self, threshold=500_000):
        """Requirement 4: Safety Switch."""
        # Check if (r * num_modules) is too high
        metric = self.r * len(self.target_modules)
        if metric > threshold:
            print("[CRITICAL: HIGH RISK OF OOM ON 24GB GPU]")
            return False
        return True

# --- Engineering Decision ---
# Original: r=64, alpha=128, modules=7 (Total scale 2.0)
# Goal: Reduce params by 75% (Target < 25% of original).
# Strategy: Low Rank / High Coverage.
# Why: For a 70B model, spreading low-rank updates across all layers (MLP + Attention) 
# is more effective for general knowledge adaptation than concentrating high-rank 
# updates in only two layers.

# New Config: 
# r = 8 (Reduction of 8x, which is 87.5% reduction in params)
# alpha = 16 (To maintain alpha/r = 2.0)
# modules = 7 (Keep high coverage)

budget_config = LoRAConfig(
    r=8, 
    alpha=16, 
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]
)

budget_config.get_summary()
budget_config.validate_vram_safety(threshold=1000) # Using 1000 to trigger warning for demo

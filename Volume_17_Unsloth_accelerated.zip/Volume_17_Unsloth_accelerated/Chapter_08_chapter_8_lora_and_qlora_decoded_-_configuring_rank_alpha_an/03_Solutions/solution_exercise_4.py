
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import math

class LoRAMemoryProfiler:
    def __init__(self, layers, hidden_dim):
        self.layers = layers
        self.hidden_dim = hidden_dim

    def estimate_trainable_params(self, rank, num_modules):
        """Tier 1: Calculate total trainable parameters."""
        return self.layers * num_modules * (2 * self.hidden_dim * rank)

    def estimate_vram_usage(self, params, precision="fp16"):
        """Tier 2: Calculate VRAM in MB and GB."""
        # Precision mapping
        byte_map = {"fp32": 4, "fp16": 2, "bf16": 2, "int8": 1}
        p_bytes = byte_map.get(precision, 2)
        
        # 1. Weight Memory: P * bytes
        # 2. Gradient Memory: P * bytes
        # 3. Optimizer State (AdamW): P * 8 bytes (FP32 momentum + variance)
        total_bytes_per_param = p_bytes + p_bytes + 8
        total_vram_bytes = params * total_bytes_per_param
        
        vram_mb = total_vram_bytes / (1024**2)
        vram_gb = total_vram_bytes / (1024**3)
        return vram_mb, vram_gb

    def what_if_analysis(self, target_limit_gb, precision="fp16"):
        """Tier 3: Find maximum compatible rank."""
        print(f"--- VRAM OPTIMIZATION REPORT ---")
        print(f"Target Limit: {target_limit_gb:.2f} GB")
        
        best_r = 1
        best_modules = 1
        best_vram_gb = 0
        
        # Iterate through modules (from 7 down to 1) and Rank (from 128 down to 1)
        # We prioritize keeping modules high, then reducing rank.
        for m in range(7, 0, -1):
            for r in range(128, 0, -1):
                params = self.estimate_trainable_params(r, m)
                _, vram_gb = self.estimate_vram_usage(params, precision)
                
                if vram_gb <= target_limit_gb:
                    best_r = r
                    best_modules = m
                    best_vram_gb = vram_gb
                    break # Found max R for this M
            if best_vram_gb > 0:
                break # Found the highest M that fits

        print(f"Max Compatible Rank: {best_r}")
        print(f"Target Modules: {best_modules}")
        print(f"Estimated Total VRAM: {best_vram_gb:.2f} GB")
        print(f"Remaining Headroom: {target_limit_gb - best_vram_gb:.2f} GB")
        print("-" * 32)

# Execution
profiler = LoRAMemoryProfiler(layers=80, hidden_dim=8192)
profiler.what_if_analysis(target_limit_gb=16.0)

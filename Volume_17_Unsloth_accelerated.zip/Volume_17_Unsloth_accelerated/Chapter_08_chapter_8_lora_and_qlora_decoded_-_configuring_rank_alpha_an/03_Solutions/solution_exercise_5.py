
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# PSEUDOCODE LOGIC FLOW
def auto_lora_decision_engine(model_metadata, available_vram_gb, dataset_complexity):
    """
    model_metadata: dict containing {'layers': int, 'hidden_dim': int, 'total_params': int}
    available_vram_gb: float
    dataset_complexity: float (0.0 to 1.0, where 1.0 is highly nuanced/new language)
    """
    
    # 1. Probe architecture
    # Identify all linear layers using a Heuristic Discovery (similar to Ex 2)
    targetable_layers = heuristic_scan(model_metadata)
    num_possible_modules = len(targetable_layers)
    
    # 2. Calculate base model VRAM
    # Assume 4-bit quantization for base model: ~0.5 bytes per parameter
    base_model_vram = model_metadata['total_params'] * 0.5 / (1024**3)
    
    # 3. Determine 'Budget' for LoRA
    # We reserve 15% of total VRAM for activations/overhead
    safety_buffer = 1.15 
    lora_vram_budget = (available_vram_gb / safety_buffer) - base_model_vram
    
    if lora_vram_budget <= 0:
        return "ERROR: Not enough VRAM to even load the base model."

    # 4. Heuristic Decision Tree
    # We prioritize: 
    # - High Complexity -> Higher Rank
    # - Low VRAM -> Fewer Modules (to keep Rank high enough to learn)
    
    if available_vram_gb >= 80:
        # Scenario A: High-End (H100/A100)
        # Prioritize: Maximum Coverage + High Rank
        r = 128 if dataset_complexity > 0.5 else 64
        alpha = r * 2
        modules_to_use = targetable_layers # All modules
        
    elif 20 <= available_vram_gb < 80:
        # Scenario B: Mid-Range (RTX 3090/4090)
        # Prioritize: High Coverage + Moderate Rank
        r = 32 if dataset_complexity > 0.5 else 16
        alpha = r * 2
        modules_to_use = targetable_layers # All modules
        
    else:
        # Scenario C: Low-End (Consumer/Edge)
        # Prioritize: High Rank + Low Coverage (to ensure stability)
        # We target only attention layers to save VRAM
        r = 16 if dataset_complexity > 0.5 else 8
        alpha = r * 2
        modules_to_use = filter_attention_only(targetable_layers)

    # 5. Iterative Refinement (The "Safety Loop")
    current_config = {"r": r, "alpha": alpha, "modules": modules_to_use}
    
    while True:
        est_vram = calculate_vram(current_config, model_metadata)
        
        if est_vram <= lora_vram_budget:
            # Ensure we don't go below a "Minimum Viable Rank"
            if current_config['r'] < 4:
                return "ERROR: Cannot fit a viable LoRA in this VRAM."
            break
        else:
            # Reduce Rank by 25% and try again
            current_config['r'] = max(4, int(current_config['r'] * 0.75))
            # If Rank becomes too low, try reducing module count instead
            if current_config['r'] == 4:
                current_config['modules'] = modules_to_use[:-1] 
                if len(current_config['modules']) == 0:
                    return "ERROR: VRAM too low for any configuration."

    # 6. Return optimal_config
    return current_config


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from unsloth import FastLanguageModel
import torch
from trl import SFTTrainer
from transformers import TrainingArguments
from datasets import load_dataset

def run_optimized_training():
    # 1. Model Initialization (Maintained 4-bit)
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name = "unsloth/llama-3-8b-bnb-4bit",
        max_seq_length = 65536, # Target context maintained
        load_in_4bit = True,
    )

    # 2. Apply RoPE Scaling (Ensuring integrity)
    # For 64k, we scale from 4k: factor = 64/4 = 16
    model.config.rope_scaling = {
        "type": "linear",
        "factor": 16.0
    }

    model = FastLanguageModel.get_peft_model(
        model,
        r = 64,
        target_modules = ["q_proj", "k_proj", "v_proj", "o_proj"],
        lora_alpha = 64,
        lora_dropout = 0,
        bias = "none",
    )

    # 3. Optimized Dataset Loading
    # Using a placeholder for the actual dataset
    dataset = load_dataset("json", data_files="long_docs.jsonl", split="train")

    # 4. Optimized Trainer Configuration
    trainer = SFTTrainer(
        model = model,
        train_dataset = dataset,
        dataset_text_field = "input",
        max_seq_length = 65536,
        packing = True, # OPTIMIZATION 1: Packing increases efficiency/throughput
        args = TrainingArguments(
            # OPTIMIZATION 2: Reduced physical batch size to 1 to prevent OOM
            per_device_train_batch_size = 1, 
            
            # OPTIMIZATION 3: Gradient Accumulation to reach effective batch size of 16
            # (1 physical batch * 16 accumulation steps = 16 effective batch)
            gradient_accumulation_steps = 16, 
            
            # OPTIMIZATION 4: Gradient Checkpointing is crucial for 64k context
            gradient_checkpointing = True, 
            
            warmup_steps = 10,
            max_steps = 100,
            learning_rate = 2e-4,
            fp16 = not torch.cuda.is_bf16_supported(),
            bf16 = torch.cuda.is_bf16_supported(),
            logging_steps = 1,
            output_dir = "outputs",
        ),
    )

    trainer.train()

if __name__ == "__main__":
    run_optimized_training()

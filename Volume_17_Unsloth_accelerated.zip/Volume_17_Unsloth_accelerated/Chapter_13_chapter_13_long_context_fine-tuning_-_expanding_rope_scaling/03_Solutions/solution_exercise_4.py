
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from transformers import AutoTokenizer

class LongContextProcessor:
    def __init__(self, window_size: int, overlap_size: int, model_id: str = "unsloth/llama-3-8b-bnb-4bit"):
        self.window_size = window_size
        self.overlap_size = overlap_size
        self.tokenizer = AutoTokenizer.from_pretrained(model_id)
        # Ensure padding token is set for safety
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

    def process_text(self, text: str) -> list[dict]:
        # 1. Tokenize the entire document
        tokens = self.tokenizer.encode(text, add_special_tokens=False)
        total_tokens = len(tokens)
        
        chunks = []
        sequence_index = 0
        
        # 2. Implement Sliding Window (Extended Slicing)
        # Step is the distance between the start of one chunk and the next
        step = self.window_size - self.overlap_size
        
        start_idx = 0
        while start_idx < total_tokens:
            end_idx = min(start_idx + self.window_size, total_tokens)
            
            # Extract token slice
            chunk_token_ids = tokens[start_idx:end_idx]
            
            # 3. Decode tokens back to text
            chunk_text = self.tokenizer.decode(chunk_token_ids, skip_special_tokens=True)
            
            # 4. Metadata Preservation
            chunks.append({
                "chunk_text": chunk_text,
                "token_count": len(chunk_token_ids),
                "sequence_index": sequence_index
            })
            
            sequence_index += 1
            
            # Break if we reached the end
            if end_idx == total_tokens:
                break
                
            # Move start_idx by the step
            start_idx += step
            
        return chunks

def test_scalability():
    # Create a dummy text file (1,000,000 characters)
    dummy_text = "This is a repetitive test string. " * 30000
    processor = LongContextProcessor(window_size=1024, overlap_size=256)
    
    chunks = processor.process_text(dummy_text)
    
    # Calculate total tokens in chunks vs original
    total_tokens_in_chunks = sum(c['token_count'] for c in chunks)
    original_tokens = len(processor.tokenizer.encode(dummy_text))
    
    print(f"Original Token Count: {original_tokens}")
    print(f"Total Tokens in Chunks: {total_tokens_in_chunks}")
    
    # Verification: Overlap should make chunk token count > original token count
    if total_tokens_in_chunks > original_tokens:
        print("SUCCESS: Overlap is working correctly.")
    else:
        print("FAILURE: Overlap not detected.")

if __name__ == "__main__":
    test_scalability()

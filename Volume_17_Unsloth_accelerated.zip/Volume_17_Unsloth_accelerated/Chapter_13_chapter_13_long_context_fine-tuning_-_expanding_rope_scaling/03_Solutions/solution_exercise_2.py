
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import argparse
import torch
import time
from unsloth import FastLanguageModel
from transformers import TrainingArguments
from trl import SFTTrainer
from datasets import Dataset

def create_needle_dataset(context_len, method_name):
    """Creates a dataset with a 'needle' at 5%, 50%, and 95%."""
    data = []
    needle = "The secret password is 'Unsloth_2024'."
    filler = "The quick brown fox jumps over the lazy dog. "
    
    # We create 3 samples per method to test different positions
    positions = [0.05, 0.50, 0.95]
    
    for pos in positions:
        # Estimate character count for the position (rough approximation)
        target_char_count = int(context_len * 10) # Assuming ~10 chars per token
        needle_pos = int(target_char_count * pos)
        
        # Build the string
        text_before = filler * (needle_pos // len(filler))
        text_after = filler * ((target_char_count - needle_pos - len(needle)) // len(filler))
        full_text = text_before + needle + text_after
        
        data.append({
            "text": full_text,
            "instruction": f"Find the secret password in this text. (Test Position: {pos*100}%)",
            "output": needle
        })
    return Dataset.from_list(data)

def main():
    parser = argparse.ArgumentParser(description="Comparative RoPE Scaling Benchmark")
    parser.add_argument("--method", type=str, choices=["ntk", "yarn"], required=True)
    parser.add_argument("--context_len", type=int, default=32768)
    args = parser.parse_args()

    print(f"--- Starting Benchmark: {args.method.upper()} ---")
    
    # 1. Load Model
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name = "unsloth/llama-3-8b-bnb-4bit",
        max_seq_length = args.context_len,
        load_in_4bit = True,
    )

    # 2. Apply Scaling Logic
    if args.method == "ntk":
        # NTK-aware scaling often uses 'dynamic' type in Transformers
        model.config.rope_scaling = {
            "type": "dynamic",
            "base": 10000 # Adjusting base frequency
        }
    elif args.method == "yarn":
        # YaRN requires specific interpolation parameters
        model.config.rope_scaling = {
            "type": "yarn",
            "factor": args.context_len / 4096,
            "original_max_position": 4096,
            "attention_scale": 1.0
        }

    model = FastLanguageModel.get_peft_model(model, r=16, target_modules=["q_proj", "k_proj", "v_proj", "o_proj"])

    # 3. Prepare Dataset
    dataset = create_needle_dataset(args.context_len, args.method)

    # 4. Training/Evaluation Loop
    start_time = time.time()
    trainer = SFTTrainer(
        model = model,
        train_dataset = dataset,
        dataset_text_field = "text",
        max_seq_length = args.context_len,
        args = TrainingArguments(
            per_device_train_batch_size = 1,
            max_steps = 10,
            logging_steps = 1,
            output_dir = f"outputs_{args.method}",
            bf16 = torch.cuda.is_bf16_supported(),
        ),
    )

    trainer.train()
    duration = time.time() - start_time
    avg_loss = trainer.state.log_history[-1]['loss']

    # 5. Comparison Report Output
    print("\n" + "="*30)
    print("BENCHMARK SUMMARY")
    print("="*30)
    print(f"Method:              {args.method.upper()}")
    print(f"Avg Training Loss:   {avg_loss:.4f}")
    print(f"Total Training Time: {duration:.2f}s")
    print(f"Context Capacity:    {args.context_len}")
    print("="*30 + "\n")

if __name__ == "__main__":
    main()

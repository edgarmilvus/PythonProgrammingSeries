
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import json
import random
import torch
from unsloth import FastLanguageModel
from trl import SFTTrainer
from transformers import TrainingArguments
from datasets import Dataset
import time

# 1. Synthetic Dataset Generation
def generate_synthetic_data(num_samples=500, output_file="long_docs.jsonl"):
    print(f"Generating {num_samples} synthetic samples...")
    data = []
    for i in range(num_samples):
        # Randomize length between 8,000 and 15,000 "tokens" 
        # (Simulated here by character count for speed in this script)
        doc_length = random.randint(40000, 80000) 
        long_text = "This is a technical document segment. " * (doc_length // 40)
        
        sample = {
            "instruction": "Summarize the following long-form technical document.",
            "input": long_text,
            "output": "This document discusses technical specifications and operational procedures."
        }
        data.append(sample)
    
    with open(output_file, 'w') as f:
        for entry in data:
            f.write(json.dumps(entry) + '\n')
    print(f"Dataset saved to {output_file}")

# 2. Training Implementation
def run_linear_scaling_training():
    # Generate data first
    generate_synthetic_data()

    # Configuration
    old_context = 4096
    new_context = 16384
    scaling_factor = new_context / old_context # Should be 4.0

    # Load Model
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name = "unsloth/llama-3-8b-bnb-4bit",
        max_seq_length = new_context,
        load_in_4bit = True,
    )

    # Apply RoPE Scaling via model config
    # In Transformers/Unsloth, the factor is the multiplier s
    model.config.rope_scaling = {
        "type": "linear",
        "factor": scaling_factor
    }

    # Add LoRA adapters
    model = FastLanguageModel.get_peft_model(
        model,
        r = 16,
        target_modules = ["q_proj", "k_proj", "v_proj", "o_proj"],
        lora_alpha = 16,
        lora_dropout = 0,
        bias = "none",
    )

    # Load Dataset
    dataset = Dataset.from_json("long_docs.jsonl")

    # Define Trainer
    trainer = SFTTrainer(
        model = model,
        train_dataset = dataset,
        dataset_text_field = "input", # Using input as the primary text field
        max_seq_length = new_context,
        packing = True, # Required for efficiency in long context
        args = TrainingArguments(
            per_device_train_batch_size = 1,
            gradient_accumulation_steps = 4,
            warmup_steps = 5,
            max_steps = 20, # Small steps for demonstration
            learning_rate = 2e-4,
            fp16 = not torch.cuda.is_bf16_supported(),
            bf16 = torch.cuda.is_bf16_supported(),
            logging_steps = 1,
            output_dir = "outputs",
            gradient_checkpointing = True, # Essential for 16k context
        ),
    )

    # Monitor VRAM and Training
    torch.cuda.reset_peak_memory_stats()
    start_time = time.time()
    
    print("Starting training...")
    trainer.train()
    
    end_time = time.time()
    peak_vram = torch.cuda.max_memory_allocated() / (1024**3) # Convert to GB
    final_loss = trainer.state.log_history[-1]['loss']

    print(f"\n--- Training Results ---")
    print(f"Final Training Loss: {final_loss:.4f}")
    print(f"Peak VRAM Usage: {peak_vram:.2f} GB")
    print(f"Total Time: {end_time - start_time:.2f} seconds")

if __name__ == "__main__":
    run_linear_scaling_training()

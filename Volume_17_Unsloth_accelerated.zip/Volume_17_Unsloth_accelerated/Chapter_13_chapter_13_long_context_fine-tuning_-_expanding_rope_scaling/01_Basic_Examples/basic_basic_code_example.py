
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

from unsloth import FastLanguageModel
import torch

def demonstrate_context_expansion():
    # 1. Define the model and the desired context expansion parameters
    # We use a 4-bit quantized version of Llama-3 to save VRAM
    model_name = "unsloth/llama-3-8b-bnb-4bit"
    
    # The original limit of the model (for context)
    original_limit = 8192 
    
    # Our goal: Double the context window to 16,384 tokens
    target_context_length = 16384 

    print(f"--- Initializing Context Expansion ---")
    print(f"Model: {model_name}")
    print(f"Targeting: {target_context_length} tokens (Scaling from {original_limit})")

    # 2. Load the model using Unsloth's optimized loading mechanism
    # Unsloth intercepts the 'max_seq_length' argument to apply RoPE scaling automatically
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name = model_name,
        max_seq_length = target_context_length, # This triggers the RoPE scaling logic
        load_in_4bit = True,                    # Essential for managing VRAM during long context
        dtype = None,                           # Automatically detects Float16 or Bfloat16
    )

    # 3. Verify that the RoPE scaling has been applied to the model configuration
    # We inspect the 'rope_scaling' dictionary within the model's internal config
    rope_config = model.config.get("rope_scaling", "No scaling detected!")
    
    print(f"\n--- Verification ---")
    print(f"RoPE Configuration in Model: {rope_config}")

    # 4. Simulate a long sequence to ensure the model can handle the new length
    # We create a dummy tensor of token IDs representing a long sequence
    dummy_input_ids = torch.randint(0, 32000, (target_context_length,))
    
    print(f"Successfully simulated a sequence of length: {len(dummy_input_ids)}")
    print(f"Status: Context Expansion Successful.")

if __name__ == "__main__":
    demonstrate_context_expansion()

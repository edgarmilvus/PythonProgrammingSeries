
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import math
from abc import ABC, abstractmethod
from typing import Dict, Type, Any

# --- DESCRIPTOR PROTOCOL ---
class ScalingParameter:
    """
    A descriptor that ensures the scaling factor is a positive float.
    This prevents invalid mathematical operations during RoPE scaling.
    """
    def __init__(self, name: str):
        self.name = name
        self.internal_name = f"_{name}"

    def __get__(self, instance, owner):
        if instance is None:
            return self
        return getattr(instance, self.internal_name, 1.0)

    def __set__(self, instance, value: float):
        if not isinstance(value, (int, float)) or value <= 0:
            raise ValueError(f"{self.name} must be a positive number.")
        setattr(instance, self.internal_name, float(value))

# --- METACLASS ---
class ScalingRegistry(type):
    """
    A metaclass that automatically registers any new RoPE scaling 
    strategy into a central registry for easy benchmarking.
    """
    REGISTRY: Dict[str, Type['BaseScalingStrategy']] = {}

    def __new__(mcs, name, bases, attrs):
        cls = super().__new__(mcs, name, bases, attrs)
        # Do not register the base class itself
        if name != "BaseScalingStrategy":
            mcs.REGISTRY[name.lower()] = cls
        return cls

# --- STRATEGY PATTERN IMPLEMENTATION ---
class BaseScalingStrategy(metaclass=ScalingRegistry):
    """Abstract Base Class for all RoPE scaling methodologies."""
    scale_factor = ScalingParameter("scale_factor")

    def __init__(self, scale_factor: float):
        self.scale_factor = scale_factor

    @abstractmethod
    def calculate_effective_window(self, base_window: int) -> int:
        """Calculates the new context window size."""
        pass

    @abstractmethod
    def simulate_frequency_shift(self) -> float:
        """Simulates how much the frequency spectrum is compressed."""
        pass

class LinearScaling(BaseScalingStrategy):
    """Simple linear interpolation of positional embeddings."""
    def calculate_effective_window(self, base_window: int) -> int:
        return int(base_window * self.scale_factor)

    def simulate_frequency_shift(self) -> float:
        # Linear scaling shifts all frequencies equally
        return 1.0 / self.scale_factor

class NTKScaling(BaseScalingStrategy):
    """NTK-aware scaling: Non-uniform scaling to preserve high frequencies."""
    def calculate_effective_window(self, base_window: int) -> int:
        # NTK scaling doesn't just multiply; it adjusts the base frequency
        return int(base_window * self.scale_factor)

    def simulate_frequency_shift(self) -> float:
        # NTK preserves high frequencies better than linear
        return (1.0 / self.scale_factor) ** 0.5

class YaRNScaling(BaseScalingStrategy):
    """YaRN: Uses temperature-based scaling to mitigate information loss."""
    def calculate_effective_window(self, base_window: int) -> int:
        return int(base_window * self.scale_factor)

    def simulate_frequency_shift(self) -> float:
        # YaRN maintains a more stable frequency distribution
        return 0.95  # Simulated stability constant

# --- APPLICATION ENGINE ---
class ContextBenchmarker:
    """Engine to run simulations across all registered scaling strategies."""
    def __init__(self, base_window: int):
        self.base_window = base_window

    def run_benchmark(self, target_scale: float):
        print(f"--- Benchmarking Context Expansion (Base: {self.base_window}) ---")
        print(f"{'Strategy':<15} | {'New Window':<12} | {'Freq. Shift'}")
        print("-" * 45)

        # Iterate through the registry populated by the Metaclass
        for name, strategy_cls in ScalingRegistry.REGISTRY.items():
            try:
                # Instantiate the strategy with the target scale
                strategy = strategy_cls(scale_factor=target_scale)
                
                new_window = strategy.calculate_effective_window(self.base_window)
                shift = strategy.simulate_frequency_shift()
                
                print(f"{name:<15} | {new_window:<12} | {shift:.4f}")
            except Exception as e:
                print(f"Error in {name}: {e}")

if __name__ == "__main__":
    # Scenario: We have a Llama-3 model with 8k context. 
    # We want to expand it to 32k (Scale Factor = 4.0).
    BENCHMARK_BASE_WINDOW = 8192
    TARGET_EXPANSION = 4.0

    benchmarker = ContextBenchmarker(BENCHMARK_BASE_WINDOW)
    benchmarker.run_benchmark(TARGET_EXPANSION)

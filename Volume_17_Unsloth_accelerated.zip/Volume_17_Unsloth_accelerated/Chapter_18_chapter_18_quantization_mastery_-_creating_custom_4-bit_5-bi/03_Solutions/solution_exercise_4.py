
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

def resolve_optimal_quantization(telemetry, model_metadata):
    """
    Real-time resolver using a priority-based decision matrix.
    """
    # Configuration Constants
    QUANT_PRIORITY = ["Q8_0", "Q6_K", "Q5_K_M", "Q4_K_M"]
    MIN_QUANT = "Q2_K"
    
    # Requirement 1: Hard Limit Rule (Simulated minimum check)
    # In a real scenario, we would calculate the actual Q2_K size.
    # For this logic, we assume a threshold.
    min_required_vram = model_metadata['parameter_count'] * 0.5 # Heuristic: 0.5 bytes/param for Q2
    if telemetry['available_vram_mb'] < min_required_vram:
        return "ERROR: INSUFFICIENT_HARDWARE"

    # Requirement 3 & 4: Constraint Modifiers
    # We will filter the QUANT_PRIORITY list based on the rules.
    
    # Rule 3: Context Priority (If context > 8192, max is Q4_K_M)
    max_allowed_by_context = "Q4_K_M" if model_metadata['required_context'] > 8192 else "Q8_0"
    
    # Rule 4: Efficiency Rule (Mobile class cap at Q5_K_M)
    max_allowed_by_device = "Q5_K_M" if telemetry['device_class'] == "mobile" else "Q8_0"

    # Determine the absolute ceiling
    # We find the index of the most restrictive ceiling in our priority list
    import math
    
    # Logic: Find the highest priority level that satisfies ALL constraints
    for level in QUANT_PRIORITY:
        # Check if level is within context constraint
        # (In our priority list, Q8 is index 0, Q4 is index 3. Lower index = higher precision)
        context_ok = QUANT_PRIORITY.index(level) >= QUANT_PRIORITY.index(max_allowed_by_context)
        device_ok = QUANT_PRIORITY.index(level) >= QUANT_PRIORITY.index(max_allowed_by_device)
        
        # For this logic, "higher" precision means a lower index.
        # If level is Q8, index is 0. If max_allowed is Q4, index is 3.
        # Q8 is NOT <= Q4 in terms of index.
        
        # Let's re-evaluate: We want the first level in QUANT_PRIORITY 
        # that is NOT higher precision than our constraints.
        
        # A simpler way:
        pass 

    # RE-IMPLEMENTING WITH CLEANER LOGIC:
    # 1. Start with the best possible
    # 2. Prune based on rules
    
    candidates = list(QUANT_PRIORITY)
    
    # Apply Context Rule
    if model_metadata['required_context'] > 8192:
        idx = candidates.index("Q4_K_M")
        candidates = candidates[idx:] # Keep Q4 and anything lower (though Q4 is our bottom)
        
    # Apply Mobile Rule
    if telemetry['device_class'] == "mobile":
        idx = candidates.index("Q5_K_M")
        candidates = candidates[:idx+1] # Keep up to Q5
        
    # Apply VRAM "Sweet Spot" Check (Simulated)
    # In real life, we'd check if candidates[0] fits in telemetry['available_vram_mb']
    # Here, we assume the loop finds the first one that fits.
    
    # Final selection (the first one in our prioritized list that survived pruning)
    return candidates[0] if candidates else "ERROR: NO_VIABLE_QUANT"

# Test Inputs
telemetry_1 = {"device_id": "edge_01", "device_class": "mobile", "available_vram_mb": 6144}
model_1 = {"model_name": "Llama-3-8B", "parameter_count": 8, "required_context": 4096}

telemetry_2 = {"device_id": "srv_99", "device_class": "workstation", "available_vram_mb": 24576}
model_2 = {"model_name": "Llama-3-70B", "parameter_count": 70, "required_context": 16384}

print(f"Result 1 (Mobile/Low Context): {resolve_optimal_quantization(telemetry_1, model_1)}")
print(f"Result 2 (Workstation/High Context): {resolve_optimal_quantization(telemetry_2, model_2)}")

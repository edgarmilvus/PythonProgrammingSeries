
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import os
import uuid
import json

def design_quantization_pipeline(source_dir, dest_dir, existing_files):
    """
    Scans, filters, and prepares a manifest for distributed processing.
    """
    all_tasks = []
    corrupted_models = []
    
    # 1. File Discovery & Metadata Aggregation
    # We simulate file scanning
    simulated_files = [
        {"name": "adapter_1.safetensors", "size_gb": 6.0, "params": 7},
        {"name": "adapter_2.safetensors", "size_gb": 2.0, "params": 7},
        {"name": "adapter_3.safetensors", "size_gb": 12.0, "params": 70},
        {"name": "adapter_4.safetensors", "size_gb": 8.0, "params": 7},
        {"name": "corrupt_model.safetensors", "size_gb": 5.5, "params": 7}, # Size not multiple of 1024 (simulated)
    ]

    for f in simulated_files:
        # Requirement 4: Error Logging (Simulating corruption via size check)
        # We assume a 'corrupted' file has a size that isn't a clean integer (simulating bytes)
        if f['size_gb'] % 0.125 != 0: # Arbitrary corruption heuristic
            corrupted_models.append(f['name'])
            continue

        # Requirement 2: Metadata Aggregator
        priority = (f['params'] / f['size_gb']) * 10
        target_name = f"{os.path.splitext(f['name'])[0]}_Q4_K_M.gguf"
        
        all_tasks.append({
            "task_id": str(uuid.uuid4()),
            "source": os.path.join(source_dir, f['name']),
            "target": os.path.join(dest_dir, target_name),
            "priority": round(priority, 2),
            "size_gb": f['size_gb'],
            "status": "PENDING"
        })

    # Requirement 3: Advanced Filter (Nested List Comprehension Mastery)
    # Filter: Size > 5GB AND Priority > 5 AND NOT in existing_files
    high_priority_queue = [
        task for task in [t for t in all_tasks if t['size_gb'] > 5]
        if task['priority'] > 5 and task['target'] not in existing_files
    ]

    # Requirement 5: Pipeline Manifest
    manifest = {
        "high_priority_queue": high_priority_queue,
        "all_pending_tasks": all_tasks,
        "corrupted_files": corrupted_models
    }
    
    return manifest

# Execution
if __name__ == "__main__":
    EXISTING = ["/quantized/adapter_1_Q4_K_M.gguf"]
    manifest = design_quantization_pipeline("/models", "/quantized", EXISTING)
    
    print(json.dumps(manifest, indent=4))

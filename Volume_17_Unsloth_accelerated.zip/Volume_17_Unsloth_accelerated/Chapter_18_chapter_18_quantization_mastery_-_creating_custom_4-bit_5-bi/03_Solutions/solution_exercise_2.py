
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

def calculate_vram_requirement(model_config, target_params, hardware_profile):
    """
    Predicts VRAM usage and validates against hardware constraints.
    """
    # 1. Quantization Calculator (Weight Size)
    # Map quantization types to approximate bits per weight
    bit_map = {"Q4_K_M": 4.5, "Q5_K_M": 5.5, "Q6_K": 6.5, "Q8_0": 8.0, "fp16": 16.0}
    bits = bit_map.get(target_params["quantization_type"], 4.0)
    
    # Total params * bits / 8 bits per byte
    # We approximate total parameters by deriving from hidden_size/layers if not provided, 
    # but here we use the config provided. 
    # For this exercise, we assume the model_config represents the architecture.
    # We need total parameters. Let's assume a simplified parameter estimation:
    # In real GGUF, this is metadata. Here we use a provided estimate or logic.
    total_params = model_config["layers"] * model_config["hidden_size"] * 12 # heuristic
    weight_vram_mb = (total_params * bits) / (8 * 1024 * 1024)

    # 2. KV-Cache Estimator
    # Formula: 2 * layers * num_heads * head_dim * context_len * bytes_per_element
    # The '2' accounts for Key and Value tensors.
    precision_bytes = 2 if target_params["kv_cache_precision"] == "fp16" else 1 # Q8 is 1 byte
    
    kv_cache_elements = (
        2 * 
        model_config["layers"] * 
        model_config["num_heads"] * 
        model_config["head_dim"] * 
        target_params["context_length"]
    )
    kv_cache_mb = (kv_cache_elements * precision_bytes) / (1024 * 1024)

    # 3. Total Calculation
    total_vram_needed = weight_vram_mb + kv_cache_mb + hardware_profile["os_overhead_mb"]

    # 4. Hardware Constraint Validator
    available_vram = hardware_profile["vram_total_mb"]
    buffer_margin_mb = available_vram - total_vram_needed
    
    is_safe = buffer_margin_mb > 0
    
    if total_vram_needed > available_vram:
        status = "CRITICAL_MEMORY_ERROR"
    elif not is_safe:
        status = "WARNING: LOW_MARGIN"
    else:
        status = "SAFE"

    return {
        "is_safe": is_safe,
        "status": status,
        "buffer_margin_mb": round(buffer_margin_mb, 2),
        "breakdown_mb": {
            "weights": round(weight_vram_mb, 2),
            "kv_cache": round(kv_cache_mb, 2),
            "overhead": hardware_profile["os_overhead_mb"]
        }
    }

# Test Data
hardware_profile = {"device_name": "RTX 3060", "vram_total_mb": 12288, "os_overhead_mb": 500}
model_config = {"layers": 32, "hidden_size": 4096, "num_heads": 32, "head_dim": 128, "vocab_size": 32000}
target_params = {"quantization_type": "Q4_K_M", "context_length": 8192, "kv_cache_precision": "fp16"}

# Execution
result = calculate_vram_requirement(model_config, target_params, hardware_profile)
print(f"Deployment Status: {result['status']}")
print(f"Details: {result}")

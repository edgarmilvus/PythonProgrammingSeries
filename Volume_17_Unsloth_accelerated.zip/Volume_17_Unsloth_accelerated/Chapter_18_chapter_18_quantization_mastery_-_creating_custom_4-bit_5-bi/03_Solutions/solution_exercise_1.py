
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import subprocess
import re
import json
import os

def run_benchmarking_suite(f16_model_path, quantization_types):
    """
    Orchestrates the quantization and perplexity testing process.
    """
    results = {}
    
    # Requirement 6: Use List Comprehension to generate command arguments
    # Format: [(quant_type, output_path), ...]
    tasks = [(q, f"{os.path.splitext(f16_model_path)[0]}_{q}.gguf") for q in quantization_types]

    for q_type, target_path in tasks:
        try:
            print(f"--- Processing {q_type} ---")
            
            # 1. Quantization Step
            quant_cmd = ["quantize", f16_model_path, target_path, q_type]
            subprocess.run(quant_cmd, check=True, capture_output=True, text=True)
            
            # 2. Perplexity Evaluation Step
            # Assuming 'perplexity' binary is in path and takes '--model' and '--file' (wikitext2)
            perp_cmd = ["perplexity", target_path, "--file", "wikitext2.txt"]
            perp_proc = subprocess.run(perp_cmd, check=True, capture_output=True, text=True)
            
            # 3. Telemetry Extraction: Robust Regex to find "perplexity: [number]"
            # This avoids fragile string slicing.
            match = re.search(r"perplexity:\s+(\d+\.\d+)", perp_proc.stdout)
            if not match:
                raise ValueError(f"Could not parse perplexity from output for {q_type}")
            
            perplexity = float(match.group(1))
            
            # 4. Data Parsing & File Metrics
            file_size_mb = os.path.getsize(target_path) / (1024 * 1024)
            
            results[q_type] = {
                "file_size_mb": round(file_size_mb, 2),
                "perplexity": perplexity,
                "estimated_vram_mb": round(file_size_mb * 1.1, 2) # 10% buffer for loading overhead
            }

        except subprocess.CalledProcessError as e:
            print(f"Error executing command for {q_type}: {e.stderr}")
            results[q_type] = {"error": "Quantization/Perplexity failed"}
        except Exception as e:
            print(f"Unexpected error for {q_type}: {str(e)}")
            results[q_type] = {"error": str(e)}

    return results

# Execution
if __name__ == "__main__":
    MODELS_TO_TEST = ["Q4_K_M", "Q5_K_M", "Q6_K", "Q8_0"]
    INPUT_MODEL = "llama3-8b-f16.gguf"
    
    # Mocking existence for demonstration; in real use, the files must exist.
    if os.path.exists(INPUT_MODEL):
        report = run_benchmarking_suite(INPUT_MODEL, MODELS_TO_TEST)
        print(json.dumps(report, indent=4))
    else:
        print(f"Please provide a valid F16 model at {INPUT_MODEL}")

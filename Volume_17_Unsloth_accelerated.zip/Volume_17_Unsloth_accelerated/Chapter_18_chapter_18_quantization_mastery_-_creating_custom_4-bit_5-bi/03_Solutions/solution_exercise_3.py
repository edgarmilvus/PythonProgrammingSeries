
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

class BitDepthDescriptor:
    def __set_name__(self, owner, name):
        self.name = name

    def __set__(self, instance, value):
        if not isinstance(value, int) or not (2 <= value <= 8):
            raise ValueError(f"{self.name} must be an integer between 2 and 8")
        instance.__dict__[self.name] = value

class MethodDescriptor:
    VALID_METHODS = {'Q4_K_M', 'Q5_K_M', 'Q6_K', 'Q8_0', 'fp16'}
    
    def __set_name__(self, owner, name):
        self.name = name

    def __set__(self, instance, value):
        if value not in self.VALID_METHODS:
            raise ValueError(f"Invalid quantization method: {value}")
        instance.__dict__[self.name] = value

class QuantizationTask:
    bit_depth = BitDepthDescriptor()
    quantization_method = MethodDescriptor()

    def __init__(self, model_name, bit_depth, method):
        self.model_name = model_name
        self.bit_depth = bit_depth
        self.quantization_method = method

    def __repr__(self):
        return f"Task({self.model_name}, {self.quantization_method})"

class QuantizationApp:
    def __init__(self, config):
        self.config = config
        self.tasks = []

    def create_batch(self, model_requests):
        # Requirement 3: Batch processing via List Comprehension
        self.tasks = [
            QuantizationTask(req['name'], req['bits'], req['method']) 
            for req in model_requests
        ]
        return self.tasks

def create_quantization_app(config_type):
    """
    Requirement 1: Application Factory Pattern
    """
    profiles = {
        "development": {"path": "/tmp/dev", "context": 2048},
        "production": {"path": "/mnt/models/prod", "context": 32768}
    }
    
    if config_type not in profiles:
        raise ValueError("Unknown profile")
        
    return QuantizationApp(profiles[config_type])

# Execution
if __name__ == "__main__":
    # 1. Use Factory to create app
    app = create_quantization_app("production")
    
    # 2. Prepare requests
    requests = [
        {"name": "Llama-3-8B", "bits": 4, "method": "Q4_K_M"},
        {"name": "Mistral-7B", "bits": 5, "method": "Q5_K_M"},
        {"name": "Gemma-2B", "bits": 8, "method": "Q8_0"}
    ]
    
    # 3. Generate tasks
    tasks = app.create_batch(requests)
    print(f"App Config: {app.config}")
    print(f"Generated Tasks: {tasks}")

    # 4. Test Descriptor Validation
    try:
        bad_task = QuantizationTask("FailModel", 12, "Q4_K_M") # Should fail bit_depth
    except ValueError as e:
        print(f"Validation Caught Error: {e}")

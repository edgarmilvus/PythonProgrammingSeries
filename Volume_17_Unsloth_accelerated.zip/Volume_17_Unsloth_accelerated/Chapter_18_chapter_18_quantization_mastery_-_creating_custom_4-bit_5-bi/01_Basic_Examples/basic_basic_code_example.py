
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np

def simulate_quantization(weights, bit_depth):
    """
    Simulates the process of quantizing high-precision weights 
    into a lower bit-depth and then dequantizing them.
    """
    # 1. Determine the number of discrete levels available for the given bit-depth
    # For 4-bit, this is 2^4 = 16. For 8-bit, this is 2^8 = 256.
    num_levels = 2**bit_depth
    
    # 2. Find the range of the original weights to establish our scale
    min_val = np.min(weights)
    max_val = np.max(weights)
    weight_range = max_val - min_val
    
    # 3. Calculate the 'scale' factor. 
    # This defines the size of each 'step' in our quantized space.
    # We subtract 1 from num_levels because the range is divided into (levels - 1) intervals.
    scale = weight_range / (num_levels - 1)
    
    # 4. Quantization Step: Map floating point weights to integer levels.
    # We shift the weights to a 0-based range, divide by scale, and round to the nearest integer.
    # We use a list comprehension here to demonstrate the logic on a per-element basis.
    quantized_indices = np.array([
        round((w - min_val) / scale) for w in weights
    ])
    
    # 5. Dequantization Step: Reconstruct the weights from the integer indices.
    # To see the 'damage', we must convert the integers back into the original float range.
    # Formula: reconstructed = (index * scale) + min_val
    dequantized_weights = (quantized_indices * scale) + min_val
    
    # 6. Error Analysis: Calculate the Mean Squared Error (MSE)
    # This tells us how much 'information' was lost during the process.
    mse = np.mean((weights - dequantized_weights) ** 2)
    
    return quantized_indices, dequantized_weights, mse, scale

# --- Execution Block ---

# Create a dummy set of 'weights' (simulating a small part of an LLM layer)
# We use 20 high-precision floating point numbers.
original_weights = np.array([
    -0.852, -0.421, -0.105, 0.023, 0.156, 
    0.334, 0.489, 0.552, 0.612, 0.778, 
    0.821, 0.889, 0.912, 0.954, 0.988,
    -0.776, -0.332, -0.001, 0.445, 0.667
], dtype=np.float64)

print("--- Quantization Simulation ---")
print(f"Original Weights: {original_weights}\n")

# Test with 8-bit quantization (High precision, low error)
q8_indices, q8_weights, q8_mse, q8_scale = simulate_quantization(original_weights, 8)
print(f"[8-bit Quantization]")
print(f"Scale: {q8_scale:.6f}")
print(f"MSE (Error): {q8_mse:.8f}")
print(f"Reconstructed: {q8_weights}\n")

# Test with 4-bit quantization (Low precision, higher error, much smaller footprint)
q4_indices, q4_weights, q4_mse, q4_scale = simulate_quantization(original_weights, 4)
print(f"[4-bit Quantization]")
print(f"Scale: {q4_scale:.6f}")
print(f"MSE (Error): {q4_mse:.8f}")
print(f"Reconstructed: {q4_weights}\n")

# Final Comparison
print("--- Summary ---")
print(f"8-bit Error vs 4-bit Error: {q4_mse / q8_mse:.2f}x increase in error.")

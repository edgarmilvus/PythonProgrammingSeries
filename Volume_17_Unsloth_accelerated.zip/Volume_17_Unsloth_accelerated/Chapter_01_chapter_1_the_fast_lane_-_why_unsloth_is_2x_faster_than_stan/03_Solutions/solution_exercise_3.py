
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import asyncio
import random

class DistributedDatasetStreamer:
    """
    An asynchronous context manager simulating a remote data source.
    """
    def __init__(self, source_url):
        self.source_url = source_url
        self.is_connected = False

    async def __aenter__(self):
        print(f"[INFO] Connecting to {self.source_url}...")
        await asyncio.sleep(1)  # Simulate network handshake
        self.is_connected = True
        print("[INFO] Connection established.")
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        print(f"[INFO] Closing connection to {self.source_url}...")
        await asyncio.sleep(0.5)  # Simulate graceful shutdown
        self.is_connected = False
        if exc_type:
            print(f"[ERROR] Connection closed due to error: {exc_val}")
        else:
            print("[INFO] Data stream closed successfully.")
        # Returning False allows exceptions to propagate after cleanup

    async def fetch_batch(self, batch_id):
        if not self.is_connected:
            raise RuntimeError("Cannot fetch batch: Not connected to streamer.")
        
        # Simulate network latency proportional to batch_id
        latency = 0.1 + (batch_id * 0.05)
        await asyncio.sleep(latency)
        
        # Return simulated tensor (list of floats)
        return [random.uniform(0, 1) for _ in range(4)]

async def train_loop():
    streamer_url = "https://distributed-dataset.ai/train_v1"
    
    try:
        async with DistributedDatasetStreamer(streamer_url) as streamer:
            for i in range(5):
                print(f"Fetching batch {i}...")
                batch = await streamer.fetch_batch(i)
                print(f"Batch {i} received: {batch}")
                
                # Simulate GPU computation time
                await asyncio.sleep(0.1)
                
                # Simulate a potential failure in batch 3
                if i == 3:
                    raise RuntimeError("GPU Out of Memory during computation!")
                    
    except RuntimeError as e:
        print(f"Caught in train_loop: {e}")

if __name__ == "__main__":
    asyncio.run(train_loop())

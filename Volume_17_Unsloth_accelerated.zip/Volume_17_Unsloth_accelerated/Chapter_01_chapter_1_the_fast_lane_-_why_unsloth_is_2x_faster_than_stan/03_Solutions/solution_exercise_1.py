
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np

class KernelDimensionError(Exception):
    """Custom exception for simulated kernel failures."""
    pass

class FusedOp:
    """
    Simulates a fused Triton kernel for (a * b) + c.
    """
    def forward(self, a, b, c):
        """
        Computes z = (a * b) + c using EAFP.
        """
        try:
            # The core operation: simulating a single fused kernel pass
            return (a * b) + c
        except (ValueError, TypeError, RuntimeError) as e:
            # Instead of checking shapes beforehand, we catch the failure
            raise KernelDimensionError(f"Kernel execution failed due to dimension mismatch: {e}")

    def backward(self, grad_output, a, b, c):
        """
        Computes gradients for a, b, and c using EAFP.
        """
        try:
            # Mathematical derivatives:
            # dz/da = b -> grad_a = grad_output * b
            # dz/db = a -> grad_b = grad_output * a
            # dz/dc = 1 -> grad_c = grad_output
            grad_a = grad_output * b
            grad_b = grad_output * a
            grad_c = grad_output
            return grad_a, grad_b, grad_c
        except (ValueError, TypeError, RuntimeError) as e:
            raise KernelDimensionError(f"Backward pass failed due to dimension mismatch: {e}")

# Verification
if __name__ == "__main__":
    op = FusedOp()
    a, b, c = np.array([1.0, 2.0]), np.array([3.0, 4.0]), np.array([0.5, 0.5])
    
    # Forward
    z = op.forward(a, b, c) # [3.5, 8.5]
    
    # Backward
    grad_out = np.array([1.0, 1.0])
    ga, gb, gc = op.backward(grad_out, a, b, c)
    
    assert np.allclose(z, [3.5, 8.5])
    assert np.allclose(ga, [3.0, 8.0])
    assert np.allclose(gb, [1.0, 2.0])
    assert np.allclose(gc, [1.0, 1.0])
    print("Exercise 1 Passed: Gradients are mathematically exact.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np

class OptimizedTrainer:
    """
    A refactored, high-performance trainer mimicking Unsloth's architecture.
    """
    def __init__(self, learning_rate=0.01):
        self.lr = learning_rate
        # Use numpy for vectorized, efficient math
        self.weights = np.array([0.5, 0.5, 0.5], dtype=np.float64)

    def forward_step(self, inputs):
        """
        Performs a fused forward pass: output = dot(w, x)
        Complexity: O(N) time, O(1) additional space.
        """
        # Convert inputs to numpy array for vectorized operations
        x = np.array(inputs, dtype=np.float64)
        # Fused operation: dot product is a single kernel-level call in optimized libs
        output = np.dot(self.weights, x)
        return output, x

    def backward_step(self, inputs, grad_output):
        """
        Performs a fused backward pass without storing activations.
        Complexity: O(N) time, O(1) additional space (excluding output).
        """
        x = np.array(inputs, dtype=np.float64)
        
        # Fused Gradient Calculation:
        # The derivative of sum(w_i * x_i) with respect to w_i is simply x_i.
        # We compute all gradients in one vectorized operation.
        gradients = grad_output * x
        
        # Update weights (Vectorized)
        self.weights -= self.lr * gradients

# --- Verification and Complexity Analysis ---
if __name__ == "__main__":
    # Test inputs
    inputs = [1.0, 2.0, 3.0]
    grad_out = 1.0

    # 1. Legacy Logic Simulation (for mathematical equivalence check)
    legacy_w = [0.5, 0.5, 0.5]
    legacy_activations = []
    for w, x in zip(legacy_w, inputs):
        prod = w * x
        legacy_activations.append(prod)
    legacy_out = sum(legacy_activations)
    legacy_grads = []
    for i in range(len(legacy_w)):
        # The legacy code's inefficient way of saying 'grad = grad_out * x'
        g = grad_out * (legacy_activations[i] / legacy_w[i] if legacy_w[i] != 0 else 0)
        legacy_grads.append(g)
    legacy_w_updated = [legacy_w[i] - 0.01 * legacy_grads[i] for i in range(3)]

    # 2. Optimized Logic
    opt_trainer = OptimizedTrainer(learning_rate=0.01)
    opt_out, opt_inputs = opt_trainer.forward_step(inputs)
    opt_trainer.backward_step(opt_inputs, grad_out)

    # 3. Assertions
    print(f"Legacy Weights: {legacy_w_updated}")
    print(f"Optimized Weights: {opt_trainer.weights.tolist()}")
    
    assert np.allclose(legacy_out, opt_out)
    assert np.allclose(legacy_w_updated, opt_trainer.weights)
    print("\nMathematical Equivalence Verified.")

    """
    COMPLEXITY ANALYSIS:
    -------------------
    LegacyTrainer:
    - Forward: O(N) time, O(N) space (stores all intermediate products in activations_history).
    - Backward: O(N) time, O(N) space (iterates through history).

    OptimizedTrainer:
    - Forward: O(N) time, O(1) space (no history stored, only the result).
    - Backward: O(N) time, O(1) space (calculates gradients directly from inputs).
    
    The OptimizedTrainer reduces memory footprint from linear to constant relative 
    to the input size, mimicking a fused Triton kernel.
    """

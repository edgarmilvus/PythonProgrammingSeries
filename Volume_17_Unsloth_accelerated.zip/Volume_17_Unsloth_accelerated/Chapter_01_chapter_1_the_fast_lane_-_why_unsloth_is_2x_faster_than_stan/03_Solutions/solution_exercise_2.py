
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np

class VRAMGuard:
    """
    A descriptor that monitors the memory footprint of model parameters.
    """
    telemetry_log = []

    def __init__(self, name, max_allowed_bytes):
        self.name = name
        self.max_allowed_bytes = max_allowed_bytes
        self.private_attr_name = f"_{name}"

    def __get__(self, instance, owner):
        if instance is None:
            return self
        try:
            return getattr(instance, self.private_attr_name)
        except AttributeError:
            raise AttributeError(f"'{type(instance).__name__}' object has no attribute '{self.name}'")

    def __set__(self, instance, value):
        # Convert to numpy array to ensure consistent size calculation
        arr = np.array(value)
        size_in_bytes = arr.size * 4  # 4 bytes for float32
        
        # Log the change
        VRAMGuard.telemetry_log.append({"attr": self.name, "size": size_in_bytes})

        # Check threshold
        if size_in_bytes > self.max_allowed_bytes:
            print(f"[VRAM WARNING] Attribute {self.name} exceeded limit! ({size_in_bytes} > {self.max_allowed_bytes})")
        
        # Store the value in the instance's __dict__ via a private name
        setattr(instance, self.private_attr_name, arr)

    def __delete__(self, instance):
        if hasattr(instance, self.private_attr_name):
            delattr(instance, self.private_attr_name)
            VRAMGuard.telemetry_log.append({"attr": self.name, "action": "deleted"})
        else:
            raise AttributeError(f"Cannot delete non-existent attribute '{self.name}'")

    @classmethod
    def get_telemetry(cls):
        return cls.telemetry_log

class LinearLayer:
    """
    A simulated neural network layer using VRAMGuard for telemetry.
    """
    def __init__(self, input_dim, output_dim, memory_budget):
        # Initialize descriptors with specific budgets
        # In a real scenario, these would be class attributes
        self.weight = VRAMGuard("weight", memory_budget)
        self.bias = VRAMGuard("bias", memory_budget // 10)
        
        # Trigger __set__ to initialize values
        self.weight = np.random.randn(input_dim, output_dim)
        self.bias = np.zeros(output_dim)

# Testing the implementation
if __name__ == "__main__":
    # Budget: 100 bytes (enough for 25 floats)
    layer = LinearLayer(10, 2, 100) 
    
    print("--- Initializing Weights ---")
    # This should trigger a warning: 10*2*4 = 80 bytes (OK)
    # But let's try a huge weight update
    print("--- Updating Weights (Large) ---")
    layer.weight = np.random.randn(10, 10) # 100*4 = 400 bytes (Exceeds 100)
    
    print("\n--- Telemetry Log ---")
    for entry in VRAMGuard.get_telemetry():
        print(entry)

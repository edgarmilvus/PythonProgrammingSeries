
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import asyncio

# 1. The Descriptor: A 'Guard' for VRAM monitoring
class VRAMGuard:
    """
    A descriptor that intercepts attribute access to simulate 
    monitoring GPU memory usage.
    """
    def __init__(self):
        # Internal storage for the value
        self._usage = 0

    def __get__(self, obj, objtype=None):
        # Triggered when someone reads 'vram'
        return f"{self._usage} GB"

    def __set__(self, obj, value):
        # Triggered when someone sets 'vram'
        # In a real system, this would interface with CUDA/Triton
        print(f"[SYSTEM] Intercepting VRAM allocation: {value} GB")
        self._usage = value

# 2. The Prompt Template: A structured instruction generator
class InstructionTemplate:
    """
    Ensures that all inputs are formatted into a 
    consistent structure for the LLM.
    """
    def __init__(self, structure):
        self.structure = structure

    def format_prompt(self, **kwargs):
        # Injects user data into the predefined template
        return self.structure.format(**kwargs)

# 3. The Async Context Manager: Managing the GPU Lifecycle
class GPUResourceManager:
    """
    Handles the safe 'loading' and 'unloading' of 
    model weights using asynchronous operations.
    """
    async def __aenter__(self):
        # Simulates the heavy I/O of loading model weights to GPU
        print("[GPU] Initializing Triton Kernels...")
        await asyncio.sleep(1)  # Simulate latency
        print("[GPU] Model loaded successfully.")
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        # Simulates the clean-up of VRAM to prevent leaks
        print("[GPU] Clearing VRAM and releasing kernels...")
        await asyncio.sleep(0.5)  # Simulate latency
        print("[GPU] Resource released.")

# 4. The Orchestrator: Combining all components
class UnslothMicroEngine:
    # The descriptor is defined at the class level
    vram = VRAMGuard()

    def __init__(self, template):
        self.template = template

    async def run_inference(self, task_data):
        # Using the Async Context Manager to wrap the execution
        async with GPUResourceManager():
            # Using the Descriptor to set memory state
            self.vram = 14  # Simulated 14GB allocation
            
            # Using the Prompt Template to prepare the input
            prompt = self.template.format_prompt(**task_data)
            
            print(f"\n--- EXECUTION START ---")
            print(f"PROMPT: {prompt}")
            print(f"CURRENT VRAM: {self.vram}")
            print(f"--- EXECUTION END ---\n")

# --- Main Execution Block ---
async def main():
    # Define a structured prompt template
    my_template = InstructionTemplate("### Instruction: {task}\n### Input: {text}\n### Response:")

    # Initialize the engine
    engine = UnslothMicroEngine(my_template)

    # Define the payload
    data = {"task": "Summarize", "text": "Unsloth makes fine-tuning fast."}

    # Run the asynchronous workflow
    await engine.run_inference(data)

if __name__ == "__main__":
    asyncio.run(main())

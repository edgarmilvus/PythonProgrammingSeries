
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# --- REFACTORED SCRIPT (UNSLOTH-OPTIMIZED) ---
from unsloth import FastLanguageModel
import torch
from transformers import TrainingArguments, Trainer

model_id = "unsloth/llama-3-8b-bnb-4bit" 

# 1. Optimized Loading using FastLanguageModel
# This replaces AutoModelForCausalLM and handles 4-bit quantization internally
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name = model_id,
    max_seq_length = 2048, # Set appropriate context length
    load_in_4bit = True,    # Explicitly enable 4-bit quantization
)

# 2. Optimized LoRA Configuration using Unsloth's kernel-aware method
# This replaces the standard PEFT get_peft_model call
model = FastLanguageModel.get_peft_model(
    model,
    r = 16,
    target_modules = ["q_proj", "k_proj", "v_proj", "o_proj",
                      "gate_proj", "up_proj", "down_proj",],
    lora_alpha = 32,
    lora_dropout = 0, # Unsloth works best with 0 dropout
    bias = "none",    # Optimized for speed
    use_gradient_checkpointing = "unsloth", # Optimized gradient checkpointing
)

# 3. Optimized Training Arguments
training_args = TrainingArguments(
    per_device_train_batch_size = 2, # Reduced from 4 to prevent OOM
    gradient_accumulation_steps = 4, # Increased to maintain effective batch size
    warmup_steps = 5,
    max_steps = 60,
    learning_rate = 2e-4,
    fp16 = not torch.cuda.is_bf16_supported(),
    bf16 = torch.cuda.is_bf16_supported(),
    logging_steps = 1,
    optim = "adamw_8bit", # Use 8-bit optimizer to save VRAM
    output_dir = "outputs",
)

# (The training loop remains the same, but now runs on optimized kernels)
print("Model successfully refactored for Unsloth optimization.")

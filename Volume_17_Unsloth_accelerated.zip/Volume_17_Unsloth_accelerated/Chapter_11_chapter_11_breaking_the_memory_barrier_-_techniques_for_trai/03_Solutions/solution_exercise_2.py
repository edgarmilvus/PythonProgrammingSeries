
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import math

class HardwareConstraintError(Exception):
    """Custom exception for VRAM limitations."""
    pass

# Hardware Constants
TOTAL_VRAM_MB = 12288
MODEL_WEIGHTS_MB = 5500
MAX_ACTIVATION_MB_PER_SAMPLE = 800

def calculate_training_config(target_effective_batch_size, max_micro_batch_size):
    """
    Calculates the optimal micro-batch size and gradient accumulation steps
    to reach a target effective batch size within VRAM limits.
    """
    # 1. Calculate available VRAM for activations
    available_vram_for_activations = TOTAL_VRAM_MB - MODEL_WEIGHTS_MB
    
    if available_vram_for_activations <= 0:
        raise HardwareConstraintError("Model weights exceed total available VRAM.")

    # 2. Determine how many samples can fit in VRAM (Micro-batch size)
    # Formula: floor(Available_VRAM / Activation_Per_Sample)
    possible_micro_batch = math.floor(available_vram_for_activations / MAX_ACTIVATION_MB_PER_SAMPLE)
    
    # 3. Apply the hardware-imposed micro-batch limit
    micro_batch_size = min(possible_micro_batch, max_micro_batch_size)
    
    # 4. Safety Check: If even 1 sample cannot fit
    if micro_batch_size <= 0:
        raise HardwareConstraintError(
            f"OOM Imminent: Only {available_vram_for_activations}MB available for activations, "
            f"but one sample requires {MAX_ACTIVATION_MB_PER_SAMPLE}MB."
        )
    
    # 5. Calculate gradient accumulation steps
    # Formula: ceil(target_effective_batch_size / micro_batch_size)
    gradient_accumulation_steps = math.ceil(target_effective_batch_size / micro_batch_size)
    
    return {
        "per_device_train_batch_size": micro_batch_size,
        "gradient_accumulation_steps": gradient_accumulation_steps,
        "target_effective_batch_size": target_effective_batch_size
    }

# TEST CASES
if __name__ == "__main__":
    print("Case 1: Target 64, Max Micro-Batch 4")
    print(calculate_training_config(64, 4))
    
    print("\nCase 2: Target 128, Max Micro-Batch 1")
    print(calculate_training_config(128, 1))
    
    print("\nCase 3: Impossible Target (Simulating tiny VRAM/huge model)")
    try:
        # Forcing an error by overriding constants locally in logic is complex, 
        # so we simulate by passing a logic that would fail if constants were different.
        # Here, we'll just test a scenario where the model is too big.
        # (In a real scenario, this would be triggered by the constants provided)
        print(calculate_training_config(64, 100)) # This works fine with current constants
    except HardwareConstraintError as e:
        print(f"Caught expected error: {e}")

    # To demonstrate the Error, we manually trigger it by pretending the model is too big
    print("\nCase 4: Manually triggering HardwareConstraintError")
    try:
        # Simulate a scenario where weights take 12,000MB
        def trigger_error():
            vram = 12288
            weights = 12000
            if (vram - weights) < MAX_ACTIVATION_MB_PER_SAMPLE:
                raise HardwareConstraintError("Not enough VRAM for even one sample.")
        trigger_error()
    except HardwareConstraintError as e:
        print(f"Caught expected error: {e}")

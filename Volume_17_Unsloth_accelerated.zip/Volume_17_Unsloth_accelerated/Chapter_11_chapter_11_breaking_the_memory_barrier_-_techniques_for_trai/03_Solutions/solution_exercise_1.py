
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import json
import psutil
import os

def stream_jsonl_data(file_path):
    """
    A generator that yields one formatted dictionary at a time from a JSONL file.
    Implements error resilience to skip malformed lines.
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File {file_path} not found.")

    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
                # Format the data according to the required template
                formatted_text = (
                    f"### Instruction:\n{data.get('instruction', '')}\n\n"
                    f"### Input:\n{data.get('input', '')}\n\n"
                    f"### Response:\n{data.get('output', '')}"
                )
                yield {"text": formatted_text}
            except json.JSONDecodeError:
                # Error Resilience: Skip corrupted lines instead of crashing
                print(f"Skipping malformed line: {line[:50]}...")
                continue

def check_memory_usage():
    """
    Returns the current Resident Set Size (RSS) in Megabytes.
    """
    process = psutil.Process(os.getpid())
    mem_bytes = process.memory_info().rss
    return mem_bytes / (1024 * 1024)

# Mock file creation for testing purposes
def create_mock_data(file_path, num_lines=20000):
    """
    Creates a dummy .jsonl file to test implementation.
    """
    with open(file_path, "w", encoding="utf-8") as f:
        for i in range(num_lines):
            # Introduce a malformed line occasionally for testing resilience
            if i == 5000:
                f.write('{"instruction": "broken", "input": "bad_json" \n') # Missing brace
                continue
                
            entry = {
                "instruction": f"Task {i}",
                "input": f"Input data {i}",
                "output": f"Result {i}"
            }
            f.write(json.dumps(entry) + "\n")

# TEST SCRIPT
if __name__ == "__main__":
    FILE_NAME = "massive_instruction_data.jsonl"
    
    print("Step 1: Creating mock data...")
    create_mock_data(FILE_NAME)
    
    print("Step 2: Starting streaming test...")
    print(f"{'Line':<10} | {'Memory Usage (MB)':<20}")
    print("-" * 35)
    
    # Iterate through the first 10,000 lines
    for i, record in enumerate(stream_jsonl_data(FILE_NAME)):
        if i == 0 or i == 4999 or i == 9999:
            print(f"{i+1:<10} | {check_memory_usage():<20.2f}")
        
        if i >= 9999:
            break
            
    # Cleanup
    if os.path.exists(FILE_NAME):
        os.remove(FILE_NAME)

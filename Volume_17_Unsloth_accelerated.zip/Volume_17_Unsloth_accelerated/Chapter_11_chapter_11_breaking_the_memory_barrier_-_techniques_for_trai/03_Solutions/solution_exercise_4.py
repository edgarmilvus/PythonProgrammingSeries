
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from pydantic import BaseModel, Field, ValidationError
from typing import Literal
import json

# 1. Define the Pydantic Schema
class SupportClassification(BaseModel):
    sentiment: str
    priority: Literal["Low", "Medium", "High"]
    category: str

def prepare_structured_training_example(query, sentiment, priority, category):
    """
    Validates input via Pydantic and returns a formatted prompt-response string.
    """
    try:
        # Validate inputs against the schema
        validated_data = SupportClassification(
            sentiment=sentiment,
            priority=priority,
            category=category
        )
        
        # Convert the validated object to a JSON string for the model to learn
        json_response = validated_data.model_dump_json()
        
        # Return the structured prompt-response pair
        return f"Query: {query}\nResponse: {json_response}"
    
    except ValidationError as e:
        # Raise ValueError as requested to signal bad training data
        raise ValueError(f"Data validation failed for query '{query}': {e}")

def process_dataset_batch(raw_data_list):
    """
    Transforms a batch of raw tuples into a list of formatted strings.
    """
    formatted_batch = []
    for item in raw_data_list:
        try:
            # item is expected to be (query, sentiment, priority, category)
            result = prepare_structured_training_example(*item)
            formatted_batch.append(result)
        except ValueError as e:
            print(f"Skipping record due to error: {e}")
            continue
            
    return formatted_batch

# TEST CASE
if __name__ == "__main__":
    raw_data = [
        ("My package is late!", "negative", "High", "shipping"),
        ("I love this product", "positive", "Low", "general"),
        ("I love this product", "positive", "InvalidPriority", "general"), # Should fail
        ("The app keeps crashing", "negative", "Medium", "technical")
    ]
    
    print("Processing batch...")
    processed_data = process_dataset_batch(raw_data)
    
    print("\nFinal Processed Dataset:")
    for entry in processed_data:
        print(entry)

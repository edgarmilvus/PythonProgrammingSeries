
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import torch
from unsloth import FastLanguageModel
from pydantic import BaseModel, Field
from typing import List, Optional
from trl import SFTTrainer
from transformers import TrainingArguments
from datasets import Dataset

# --- STEP 1: CONFIGURATION & MODEL LOADING ---
# We use 4-bit quantization to fit an 8B model into ~5.5GB of VRAM
model_name = "unsloth/llama-3-8b-bnb-4bit"
max_seq_length = 2048  # Supports auto-detection of length
dtype = None           # None for auto detection (Float16 or Bfloat16)
load_in_4bit = True    # Crucial for 8GB/12GB VRAM GPUs

model, tokenizer = FastLanguageModel.from_pretrained(
    model_name = model_name,
    max_seq_length = max_seq_length,
    dtype = dtype,
    load_in_4bit = load_in_4bit,
)

# --- STEP 2: LoRA (LOW-RANK ADAPTATION) SETUP ---
# Instead of training all parameters, we add small trainable matrices (Rank)
model = FastLanguageModel.get_peft_model(
    model,
    r = 16,                # Rank: higher means more capacity but more VRAM
    target_modules = ["q_proj", "k_proj", "v_proj", "o_proj",
                      "gate_proj", "up_proj", "down_proj"],
    lora_alpha = 16,
    lora_dropout = 0,      # Optimized to 0 for Unsloth kernels
    bias = "none",         # Standard for LoRA
    use_gradient_checkpointing = "unsloth", # Massive VRAM saving
)

# --- STEP 3: DATA PREPARATION ---
# Defining the structured schema we want the model to learn
class MedicalEntity(BaseModel):
    condition: str = Field(description="The diagnosed medical condition")
    medication: Optional[str] = Field(description="Prescribed medication")
    dosage: Optional[str] = Field(description="Dosage instructions")

# Simulated unstructured clinical data
raw_data = [
    {"text": "Patient presents with acute hypertension. Prescribed Lisinopril 10mg daily.", 
     "label": '{"condition": "hypertension", "medication": "Lisinopril", "dosage": "10mg daily"}'},
    {"text": "Severe migraine reported. Suggesting Sumatriptan 50mg as needed.", 
     "label": '{"condition": "migraine", "medication": "Sumatriptan", "dosage": "50mg as needed"}'}
]

# Formatting function for the SFT (Supervised Fine-Tuning) trainer
def formatting_prompts_func(examples):
    instructions = examples["text"]
    outputs      = examples["label"]
    texts = []
    for instruction, output in zip(instructions, outputs):
        # We use a specific prompt template to guide the LLM toward structured output
        text = f"### Instruction: Extract medical data.\n### Input: {instruction}\n### Response: {output}"
        texts.append(text)
    return { "text" : texts, }

dataset = Dataset.from_list(raw_data)
dataset = dataset.map(formatting_prompts_func, batched = True)

# --- STEP 4: MEMORY-OPTIMIZED TRAINING ---
trainer = SFTTrainer(
    model = model,
    tokenizer = tokenizer,
    train_dataset = dataset,
    dataset_text_field = "text",
    max_seq_length = max_seq_length,
    dataset_num_proc = 2,
    args = TrainingArguments(
        per_device_train_batch_size = 2,     # Small physical batch to save VRAM
        gradient_accumulation_steps = 4,     # Simulates a batch size of 8 (2 * 4)
        warmup_steps = 5,
        max_steps = 60,                      # Short run for demonstration
        learning_rate = 2e-4,
        fp16 = not torch.cuda.is_bf16_supported(),
        bf16 = torch.cuda.is_bf16_supported(),
        logging_steps = 1,
        optim = "adamw_8bit",                # 8-bit optimizer reduces VRAM usage
        weight_decay = 0.01,
        lr_scheduler_type = "linear",
        seed = 3407,
        output_dir = "outputs",
    ),
)

# Execute the training process
trainer.train()

# --- STEP 5: STRUCTURED INFERENCE ---
# Prepare the model for fast inference
FastLanguageModel.for_inference(model)

test_input = "Patient complains of persistent cough and fever. Prescribed Amoxicillin 500mg."
prompt = f"### Instruction: Extract medical data.\n### Input: {test_input}\n### Response:"

# Generate the response
inputs = tokenizer([prompt], return_tensors = "pt").to("cuda")
outputs = model.generate(**inputs, max_new_tokens = 64)
decoded_output = tokenizer.batch_decode(outputs)[0].split("### Response:")[1].strip()

# Validate the LLM output against our Pydantic schema
try:
    # This converts the raw string into a validated Python object
    structured_data = MedicalEntity.model_validate_json(decoded_output)
    print(f"Successfully Parsed Data: {structured_data.model_dump()}")
except Exception as e:
    print(f"Parsing Error: {e}")
    print(f"Raw Output: {decoded_output}")

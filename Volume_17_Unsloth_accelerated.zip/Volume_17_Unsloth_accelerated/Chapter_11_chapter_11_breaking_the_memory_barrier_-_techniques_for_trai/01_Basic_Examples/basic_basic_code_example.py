
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

from unsloth import FastLanguageModel
import torch
from trl import SFTTrainer
from transformers import TrainingArguments
from datasets import load_dataset

# 1. Configuration Constants
# We define the maximum sequence length to prevent memory spikes
max_seq_length = 2048 
# Load in 4-bit to drastically reduce the VRAM footprint
load_in_4bit = True 

# 2. Model and Tokenizer Loading
# We use Unsloth's FastLanguageModel to load a pre-quantized Llama-3 model
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name = "unsloth/llama-3-8b-bnb-4bit", # Pre-quantized 4-bit version
    max_seq_length = max_seq_length,           # Limits context window size
    dtype = None,                              # Auto-detects float16 or bfloat16
    load_in_4bit = load_in_4bit,               # Enables 4-bit quantization
)

# 3. LoRA (Low-Rank Adaptation) Configuration
# Instead of training all parameters, we only train a tiny subset
model = FastLanguageModel.get_peft_model(
    model,
    r = 16,               # Rank: The size of the update matrices (higher = more capacity)
    target_modules = ["q_proj", "k_proj", "v_proj", "o_proj"], # Which layers to adapt
    lora_alpha = 16,      # Scaling factor for the LoRA weights
    lora_dropout = 0,     # Dropout for regularization (0 is best for Unsloth speed)
    bias = "none",        # We do not train bias parameters
)

# 4. Dataset Preparation
# We load a standard instruction-following dataset (Alpaca format)
dataset = load_dataset("yahma/alpaca-cleaned", split = "train")

# 5. Trainer Setup
# We use SFTTrainer (Supervised Fine-Tuning Trainer) from the TRL library
trainer = SFTTrainer(
    model = model,
    train_dataset = dataset,
    dataset_text_field = "text", # The column in the dataset containing the text
    max_seq_length = max_seq_length,
    args = TrainingArguments(
        per_device_train_batch_size = 2, # Small batch size to save VRAM
        gradient_accumulation_steps = 4, # Simulate a larger batch (2 * 4 = 8)
        warmup_steps = 5,                # Gradual increase in learning rate
        max_steps = 60,                  # Total training steps for this demo
        learning_rate = 2e-4,            # Standard LoRA learning rate
        fp16 = not torch.cuda.is_bf16_supported(), # Use float16 if bfloat16 isn't available
        bf16 = torch.cuda.is_bf16_supported(),     # Use bfloat16 for Ampere+ GPUs
        logging_steps = 1,               # Log progress every step
        optim = "adamw_8bit",            # 8-bit optimizer to save massive VRAM
        weight_decay = 0.01,
        lr_scheduler_type = "linear",
        seed = 3407,
        output_dir = "outputs",          # Where to save the model
    ),
)

# 6. Execution
# Start the training process
trainer.train()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Import the FastAPI framework to handle web requests and routing
from fastapi import FastAPI

# Import Pydantic models to ensure data validation and type safety
from pydantic import BaseModel

# Import Unsloth's FastLanguageModel to load the optimized model and LoRA adapters
from unsloth import FastLanguageModel

# Import torch to manage tensor operations and inference modes
import torch

# --- 1. MODEL INITIALIZATION ---
# We load the model outside the request loop to ensure it stays in VRAM
# and is only loaded once when the server starts.

# Define the model name or path where your Unsloth-tuned weights are stored
MODEL_NAME = "unsloth/llama-3-8b-bnb-4bit" # Placeholder for your specific fine-tuned path

# Load the model and tokenizer using Unsloth's optimized loading mechanism
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name = MODEL_NAME,
    max_seq_length = 2048,
    load_in_4bit = True, # Uses 4-bit quantization to save VRAM
)

# Enable faster inference by applying LoRA adapters if they were saved separately
FastLanguageModel.for_inference(model)

# --- 2. DATA SCHEMAS (PYDANTIC) ---
# We define how our input and output should look. This follows the 
# Principle of Least Astonishment by providing clear, predictable structures.

class InferenceRequest(BaseModel):
    """The expected structure of the incoming JSON request."""
    prompt: str
    max_new_tokens: int = 128  # Default value if the user doesn't provide one

class InferenceResponse(BaseModel):
    """The structure of the JSON response sent back to the user."""
    generated_text: str
    status: str = "success"

# --- 3. API SETUP ---
# Initialize the FastAPI application instance.
app = FastAPI(title="Unsloth Model API", description="A high-performance inference server.")

# --- 4. THE INFERENCE ENDPOINT ---
# This is the 'route' that users will call via an HTTP POST request.

@app.post("/generate", response_model=InferenceResponse)
async def generate_text(request: InferenceRequest):
    """
    Receives a prompt, runs it through the Unsloth model, 
    and returns the generated text.
    """
    
    # Prepare the input prompt using the tokenizer
    # We use the tokenizer to convert text into the integer IDs the model requires
    inputs = tokenizer(
        [request.prompt], 
        return_tensors="pt"
    ).to("cuda") # Move tensors to the GPU

    # Perform the actual inference
    # We use torch.inference_mode() to disable gradient calculation, 
    # which saves memory and speeds up the process.
    with torch.inference_mode():
        outputs = model.generate(
            **inputs, 
            max_new_tokens=request.max_new_tokens,
            use_cache=True # Speeds up generation by reusing previous KV caches
        )

    # Decode the generated token IDs back into a human-readable string
    # We skip the first token if it's just a repetition of the prompt
    decoded_output = tokenizer.batch_decode(outputs, skip_special_tokens=True)[0]

    # Return the result wrapped in our Pydantic response model
    return InferenceResponse(generated_text=decoded_output)

# --- 5. SERVER EXECUTION (METADATA) ---
# In a production environment, you would run this using:
# uvicorn filename:app --host 0.0.0.0 --port 8000

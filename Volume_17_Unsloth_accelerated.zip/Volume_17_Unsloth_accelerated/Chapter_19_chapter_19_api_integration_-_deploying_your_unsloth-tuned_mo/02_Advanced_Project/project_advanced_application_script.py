
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import asyncio
import logging
from datetime import datetime
from typing import List, Optional

from fastapi import FastAPI, HTTPException, Depends, Request
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session

# Unsloth and Inference imports
from unsloth import FastLanguageModel
import torch

# --- CONFIGURATION & LOGGING ---
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("UnslothService")

# Database Setup (Using SQLite for this demonstration)
DATABASE_URL = "sqlite:///./inference_logs.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# --- ORM MODEL DEFINITION ---
class InteractionLog(Base):
    """
    Represents the structure of the 'interaction_logs' table in the database.
    In SQLAlchemy, this class acts as the blueprint for our persistence layer.
    """
    __tablename__ = "interaction_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_query = Column(Text, nullable=False)
    model_response = Column(Text, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)
    latency_ms = Column(Integer)

# Create the database tables
Base.metadata.create_all(bind=engine)

# --- PYDANTIC SCHEMAS ---
class ChatRequest(BaseModel):
    """Validates the incoming JSON payload from the client."""
    prompt: str = Field(..., min_length=1, max_length=1000, description="The user's question.")
    temperature: float = Field(default=0.7, ge=0.0, le=1.0)
    max_new_tokens: int = Field(default=128, gt=0)

class ChatResponse(BaseModel):
    """Defines the structure of the successful API response."""
    response: str
    request_id: int
    processing_time: float

# --- MODEL MANAGER (SINGLETON PATTERN) ---
class ModelManager:
    """
    Manages the lifecycle of the Unsloth model and LoRA adapters.
    Loading the model is expensive; we do it once at startup.
    """
    def __init__(self):
        self.model = None
        self.tokenizer = None

    def load_model(self, model_name: str, lora_path: str):
        logger.info(f"Loading model: {model_name} with adapter: {lora_path}")
        # Load model and tokenizer using Unsloth's optimized loading
        self.model, self.tokenizer = FastLanguageModel.from_pretrained(
            model_name=model_name,
            max_seq_length=2048,
            load_in_4bit=True,
        )
        # Apply the fine-tuned LoRA adapters
        self.model = FastLanguageModel.for_inference(self.model)
        self.model.load_adapter(lora_path)
        logger.info("Model loaded successfully into VRAM.")

    async def generate(self, prompt: str, temperature: float, max_tokens: int) -> str:
        """Performs asynchronous-style inference wrapper."""
        # Note: Actual inference is CPU/GPU bound, so we wrap in a thread or 
        # use the model's native capabilities.
        inputs = self.tokenizer(
            [f"### Instruction:\n{prompt}\n\n### Response:\n"], 
            return_tensors="pt"
        ).to("cuda")

        outputs = self.model.generate(
            **inputs, 
            max_new_tokens=max_tokens,
            temperature=temperature,
            do_sample=True
        )
        
        # Decode only the new tokens
        decoded = self.tokenizer.batch_decode(outputs[:, inputs.input_ids.shape[1]:], skip_special_tokens=True)
        return decoded[0].strip()

# Global instances
model_manager = ModelManager()
app = FastAPI(title="Unsloth Production API")

# --- DEPENDENCIES ---
def get_db():
    """Dependency to provide a database session per request."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# --- LIFECYCLE EVENTS ---
@app.on_event("startup")
async def startup_event():
    """
    Triggered when the FastAPI server starts.
    This is where we perform the heavy lifting of loading weights.
    """
    # In a real scenario, these would be environment variables
    try:
        model_manager.load_model("unsloth/llama-3-8b-bnb-4bit", "./my_lora_adapter")
    except Exception as e:
        logger.error(f"CRITICAL: Failed to load model on startup: {e}")
        # In production, we might want to exit if the model fails to load
        raise e

# --- ENDPOINTS ---
@app.post("/v1/chat", response_model=ChatResponse)
async def chat_endpoint(
    request: ChatRequest, 
    db: Session = Depends(get_db)
):
    """
    The primary inference endpoint.
    Implements EAFP to handle potential failures in inference or DB logging.
    """
    import time
    start_time = time.time()

    # 1. Inference Phase
    try:
        # We attempt the inference. If the GPU is OOM or the model is corrupted,
        # we catch the error immediately (EAFP).
        generated_text = await model_manager.generate(
            request.prompt, 
            request.temperature, 
            request.max_new_tokens
        )
    except Exception as inference_err:
        logger.error(f"Inference Error: {inference_err}")
        raise HTTPException(status_code=500, detail="Model inference failed.")

    end_time = time.time()
    latency = end_time - start_time

    # 2. Persistence Phase (Logging)
    try:
        # We attempt to log the interaction. 
        # We use EAFP here: if the DB is down, we log the error but 
        # don't necessarily fail the user's request (depending on business logic).
        new_log = InteractionLog(
            user_query=request.prompt,
            model_response=generated_text,
            latency_ms=int(latency * 1000)
        )
        db.add(new_log)
        db.commit()
        db.refresh(new_log)
        log_id = new_log.id
    except Exception as db_err:
        # If DB fails, we log it locally but still return the answer to the user.
        # This is a design choice: Availability > Consistency.
        logger.warning(f"Database logging failed: {db_err}")
        log_id = 0  # Placeholder for failed log

    return ChatResponse(
        response=generated_text,
        request_id=log_id,
        processing_time=latency
    )

@app.get("/health")
async def health_check():
    """Basic endpoint for load balancer health monitoring."""
    return {"status": "healthy", "model_loaded": model_manager.model is not None}


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import logging
import os
import torch
from typing import Dict
from fastapi import FastAPI, Request, Response, status
from fastapi.responses import JSONResponse
from pydantic_settings import BaseSettings, SettingsConfigDict

# 1. Environment-Driven Configuration
class AppSettings(BaseSettings):
    model_path: str
    device: str = "cuda"
    adapter_registry: Dict[str, str]
    max_concurrent_requests: int = 5
    log_level: str = "INFO"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

# Initialize settings (will raise error if MODEL_PATH is missing)
try:
    settings = AppSettings()
except Exception as e:
    print(f"Configuration Error: {e}")
    exit(1)

# 2. Logging Configuration
logging.basicConfig(level=settings.log_level)
logger = logging.getLogger("api_logger")

app = FastAPI()

# 3. Global Exception Handler (Security)
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled error: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"error": "Internal Server Error", "request_id": "req_abc123"} # In real app, use actual UUID
    )

# 4. Observability Endpoints
@app.get("/health")
async def health_check():
    """Liveness Probe: Returns 200 if the web server is alive."""
    return {"status": "alive"}

@app.get("/ready")
async def readiness_check():
    """Readiness Probe: Returns 200 only if model and GPU are ready."""
    try:
        # Perform a tiny 'smoke test' operation on the GPU
        dummy_tensor = torch.randn(1, 1).to(settings.device)
        result = dummy_tensor * 2
        
        # Check if model is loaded (simulated check)
        if not hasattr(app, "model_ready") or not app.model_ready:
            return JSONResponse(status_code=503, content={"status": "model_loading"})
            
        return {"status": "ready", "gpu": "active"}
    except Exception as e:
        logger.error(f"Readiness check failed: {e}")
        return JSONResponse(status_code=503, content={"status": "unready", "reason": "gpu_error"})

# Mock startup to set readiness
@app.on_event("startup")
async def startup_event():
    # In a real app, this would be set after the model loading logic
    app.model_ready = True 

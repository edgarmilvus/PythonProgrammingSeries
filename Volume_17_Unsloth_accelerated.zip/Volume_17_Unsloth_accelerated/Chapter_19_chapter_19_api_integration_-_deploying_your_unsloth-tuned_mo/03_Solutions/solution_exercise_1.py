
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel, Field, validator
from unsloth import FastLanguageModel
import torch

# 1. Data Schemas
class InferenceRequest(BaseModel):
    prompt: str = Field(..., min_length=1)
    max_new_tokens: int = Field(default=128, ge=1)
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    top_p: float = Field(default=0.9, ge=0.0, le=1.0)

    @validator('prompt')
    def prompt_must_not_be_empty(cls, v):
        if not v.strip():
            raise ValueError("Prompt cannot be empty")
        return v

class UsageMetrics(BaseModel):
    prompt_tokens: int
    completion_tokens: int

class InferenceResponse(BaseModel):
    generated_text: str
    usage: UsageMetrics

# 2. Lifecycle Management
model_container = {}

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Load model and tokenizer
    model_path = os.getenv("MODEL_PATH", "models/default_llama3")
    device = "cuda" if torch.cuda.is_available() else "cpu"
    
    try:
        print(f"Loading model from {model_path} on {device}...")
        model, tokenizer = FastLanguageModel.from_pretrained(
            model_name=model_path,
            max_seq_length=2048,
            load_in_4bit=True,
        )
        FastLanguageModel.for_inference(model)
        # Store in app state via a dictionary to ensure persistence
        model_container["model"] = model
        model_container["tokenizer"] = tokenizer
        print("Model loaded successfully.")
    except Exception as e:
        print(f"Critical Error: Model initialization failed: {e}")
        raise RuntimeError("Model initialization failed") from e
    
    yield
    # Shutdown: Clean up memory
    model_container.clear()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

app = FastAPI(lifespan=lifespan)

# 3. Inference Endpoint
@app.post("/v1/generate", response_model=InferenceResponse)
async def generate(request: InferenceRequest):
    if "model" not in model_container:
        raise HTTPException(status_code=500, detail="Model not initialized")

    model = model_container["model"]
    tokenizer = model_container["tokenizer"]

    try:
        # Tokenize input
        inputs = tokenizer([request.prompt], return_tensors="pt").to("cuda")
        input_len = inputs.input_ids.shape[1]

        # Generate
        outputs = model.generate(
            **inputs,
            max_new_tokens=request.max_new_tokens,
            temperature=request.temperature,
            top_p=request.top_p,
            use_cache=True
        )

        # Decode only the new tokens
        generated_tokens = outputs[0][input_len:]
        generated_text = tokenizer.decode(generated_tokens, skip_special_tokens=True)
        
        completion_len = len(generated_tokens)

        return InferenceResponse(
            generated_text=generated_text,
            usage=UsageMetrics(
                prompt_tokens=input_len,
                completion_tokens=completion_len
            )
        )

    except torch.cuda.OutOfMemoryError:
        raise HTTPException(status_code=500, detail="Inference engine overloaded")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Inference failed: {str(e)}")

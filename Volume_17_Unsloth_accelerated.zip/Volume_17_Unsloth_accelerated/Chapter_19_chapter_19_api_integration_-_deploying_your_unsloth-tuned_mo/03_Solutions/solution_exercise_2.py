
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import asyncio
from typing import List
from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel, Field
import torch

# Re-using schemas from Exercise 1
from exercise_1_module import InferenceRequest, InferenceResponse, model_container

class BatchInferenceRequest(BaseModel):
    requests: List[InferenceRequest]
    batch_size: int = Field(default=8, ge=1, le=64)

app = FastAPI()
# Semaphore to prevent GPU VRAM exhaustion from too many concurrent batches
gpu_semaphore = asyncio.Semaphore(2) 

def sync_inference_loop(requests: List[InferenceRequest]):
    """
    This function runs in a separate thread to perform the actual 
    blocking GPU work.
    """
    model = model_container["model"]
    tokenizer = model_container["tokenizer"]
    results = []

    for req in requests:
        try:
            inputs = tokenizer([req.prompt], return_tensors="pt").to("cuda")
            outputs = model.generate(
                **inputs,
                max_new_tokens=req.max_new_tokens,
                temperature=req.temperature,
                top_p=req.top_p
            )
            
            # Check for length/context issues (simulated logic)
            if len(req.prompt) > 4000:
                results.append({"error": "Prompt exceeds maximum context length"})
                continue

            gen_text = tokenizer.decode(outputs[0][inputs.input_ids.shape[1]:], skip_special_tokens=True)
            results.append({
                "generated_text": gen_text,
                "usage": {"prompt_tokens": inputs.input_ids.shape[1], "completion_tokens": len(outputs[0]) - inputs.input_ids.shape[1]}
            })
        except Exception as e:
            results.append({"error": str(e)})
    
    return results

@app.post("/v1/batch-generate")
async def batch_generate(batch_req: BatchInferenceRequest):
    if not batch_req.requests:
        raise HTTPException(status_code=400, detail="Batch cannot be empty")

    # Use semaphore to limit how many batches hit the GPU at once
    async with gpu_semaphore:
        loop = asyncio.get_running_loop()
        
        # Offload the blocking synchronous loop to a thread pool
        # This prevents the event loop from freezing
        try:
            raw_results = await loop.run_in_executor(
                None, 
                sync_inference_loop, 
                batch_req.requests
            )
            
            # Format response to handle partial successes (Multi-Status 207)
            # For simplicity in this exercise, we return a list of objects 
            # that might contain error strings.
            return raw_results
            
        except torch.cuda.OutOfMemoryError:
            raise HTTPException(status_code=503, detail="Service Unavailable: GPU VRAM full")
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Batch processing failed: {str(e)}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import asyncio
import json
import threading
from typing import Optional
from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse
from transformers import TextIteratorStreamer
from unsloth import FastLanguageModel
from exercise_3_module import ADAPTER_REGISTRY, model_container, model_lock

app = FastAPI()

async def token_generator(prompt: str, tenant_id: Optional[str], max_tokens: int):
    model = model_container["model"]
    tokenizer = model_container["tokenizer"]
    
    # 1. Setup Streamer
    streamer = TextIteratorStreamer(tokenizer, skip_prompt=True, skip_special_tokens=True)
    
    # 2. Acquire Lock for Adapter Swapping
    # We must hold the lock for the ENTIRE duration of the stream to prevent hijacking
    async with model_lock:
        try:
            if tenant_id:
                if tenant_id not in ADAPTER_REGISTRY:
                    # Note: In a real stream, we can't change HTTP status once streaming starts.
                    # We yield an error event instead.
                    yield f"data: {json.dumps({'error': 'Tenant not found'})}\n\n"
                    return
                model.load_adapter(ADAPTER_REGISTRY[tenant_id])
            else:
                model.unload_adapter()

            # 3. Prepare Inputs
            inputs = tokenizer([prompt], return_tensors="pt").to("cuda")
            
            # 4. Run Generation in a background thread
            # The streamer object is the bridge between the thread and this generator
            generation_kwargs = dict(inputs, streamer=streamer, max_new_tokens=max_tokens)
            thread = threading.Thread(target=model.generate, kwargs=generation_kwargs)
            thread.start()

            # 5. Yield tokens as they arrive
            token_count = 0
            for new_text in streamer:
                token_count += 1
                # SSE Format: data: <content>\n\n
                yield f"data: {json.dumps({'token': new_text})}\n\n"

            thread.join()

            # 6. Final Metadata Event
            metadata = {"total_tokens": token_count, "status": "complete"}
            yield f"data: {json.dumps({'metadata': metadata})}\n\n"

        except Exception as e:
            yield f"data: {json.dumps({'error': str(e)})}\n\n"

@app.post("/v1/stream-generate")
async def stream_generate(request: dict):
    # (Validation logic omitted for brevity, assume prompt and tenant_id exist)
    prompt = request.get("prompt")
    tenant_id = request.get("tenant_id")
    
    if not prompt:
        raise HTTPException(status_code=400, detail="Prompt required")

    return StreamingResponse(
        token_generator(prompt, tenant_id, 128),
        media_type="text/event-stream"
    )

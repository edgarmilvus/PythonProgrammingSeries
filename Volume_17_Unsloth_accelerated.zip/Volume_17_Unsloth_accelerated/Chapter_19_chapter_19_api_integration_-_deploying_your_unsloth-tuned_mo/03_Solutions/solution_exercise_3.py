
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import asyncio
from typing import Dict, Optional
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from unsloth import FastLanguageModel

# Simulated Database
ADAPTER_REGISTRY = {
    "medical_expert": "/models/adapters/medical_v1",
    "legal_expert": "/models/adapters/legal_v2",
    "code_expert": "/models/adapters/coding_v1"
}

class TenantRequest(BaseModel):
    tenant_id: Optional[str] = None
    prompt: str

app = FastAPI()
# Global lock to prevent "Cross-Talk" between tenants
model_lock = asyncio.Lock()
model_container = {}

@app.on_event("startup")
async def startup():
    # Load base model (simplified)
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name="unsloth/llama-3-8b-bnb-4bit",
        load_in_4bit=True,
    )
    model_container["model"] = model
    model_container["tokenizer"] = tokenizer

@app.get("/v1/adapters")
async def get_adapters():
    return {"available_tenants": list(ADAPTER_REGISTRY.keys())}

@app.post("/v1/tenant-generate")
async def tenant_generate(request: TenantRequest):
    model = model_container["model"]
    tokenizer = model_container["tokenizer"]
    
    # 1. Validate Tenant
    target_adapter = None
    if request.tenant_id:
        if request.tenant_id not in ADAPTER_REGISTRY:
            raise HTTPException(status_code=404, detail="Tenant adapter not found")
        target_adapter = ADAPTER_REGISTRY[request.tenant_id]

    # 2. Critical Section: Swapping and Inference
    # The lock ensures Request A doesn't swap the adapter while Request B is mid-inference
    async with model_lock:
        try:
            # If a tenant is provided, load the adapter
            if target_adapter:
                # Unsloth/PEFT allows dynamic loading
                model.load_adapter(target_adapter)
            else:
                # Revert to base model if no tenant provided
                model.unload_adapter()

            # Perform Inference
            inputs = tokenizer([request.prompt], return_tensors="pt").to("cuda")
            outputs = model.generate(**inputs, max_new_tokens=64)
            response_text = tokenizer.decode(outputs[0], skip_special_tokens=True)

            return {"generated_text": response_text, "tenant_used": request.tenant_id}

        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to load tenant adapter: {str(e)}")

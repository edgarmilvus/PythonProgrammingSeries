
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

from unsloth import FastLanguageModel
import torch
import os

# 1. Define the paths for our model components
# In a real scenario, these would be the paths to your saved LoRA adapters
adapter_model_path = "outputs/checkpoint-500" 
merged_model_path = "models/final_merged_model"

def merge_and_export_for_production():
    print("--- Starting the Merging Process ---")

    # 2. Load the model and tokenizer
    # We use FastLanguageModel to ensure we can handle the weights efficiently
    # We load the adapter directly onto the base model
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name = adapter_model_path, # This loads the adapter + the base it was trained on
        max_seq_length = 2048,           # Matches the training context length
        load_in_4bit = False,            # CRITICAL: Must be False to merge into high precision
        device_map = "auto",             # Automatically handle GPU/CPU placement
    )

    # 3. Perform the weight merging
    # This step mathematically adds (A * B) to the base weights W
    print("--- Merging weights... this may take a moment ---")
    
    # 4. Export the consolidated model
    # We export to 'merged_16bit' to ensure the highest quality for vLLM
    # This creates a standard Hugging Face model directory
    model.save_pretrained_merged(
        merged_model_path, 
        tokenizer, 
        save_method = "merged_16bit",    # The core instruction for consolidation
    )

    print(f"--- Success! Merged model saved to: {merged_model_path} ---")

    # 5. Verification Step
    # Check if the directory contains the necessary files for vLLM
    if os.path.exists(os.path.join(merged_model_path, "model.safetensors")):
        print("Verification: model.safetensors found. Ready for vLLM.")
    else:
        print("Verification Failed: Model files not found.")

if __name__ == "__main__":
    # Ensure we have enough GPU memory before starting
    if torch.cuda.is_available():
        merge_and_export_for_production()
    else:
        print("Error: CUDA is required for this operation.")

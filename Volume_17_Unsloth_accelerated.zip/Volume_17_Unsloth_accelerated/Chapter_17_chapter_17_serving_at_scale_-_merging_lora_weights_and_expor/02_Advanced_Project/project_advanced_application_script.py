
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import torch
from unsloth import FastLanguageModel
from transformers import AutoTokenizer

class ModelDeploymentOrchestrator:
    """
    Automates the transition from LoRA adapters to production-ready 
    merged weights optimized for high-throughput serving engines.
    """

    def __init__(self, base_model_name: str, adapter_path: str, output_dir: str):
        # Define the paths for the base model, the LoRA weights, and the final export
        self.base_model_name = base_model_name
        self.adapter_path = adapter_path
        self.output_dir = output_dir
        self.model = None
        self.tokenizer = None

    def load_model_and_adapters(self, max_seq_length: int = 2048):
        # Load the base model and the LoRA adapters using Unsloth's optimized loading
        print(f"[INFO] Loading base model: {self.base_model_name}")
        print(f"[INFO] Loading adapters from: {self.adapter_path}")
        
        self.model, self.tokenizer = FastLanguageModel.from_pretrained(
            model_name = self.adapter_path, # Unsloth can load adapters directly via the path
            max_seq_length = max_seq_length,
            load_in_4bit = False, # We must load in FP16/BF16 for high-quality merging
        )
        print("[SUCCESS] Model and adapters loaded into memory.")

    def merge_and_export(self, export_format: str = "merged_16bit"):
        # Execute the mathematical merging of LoRA matrices into the base weights
        if self.model is None:
            raise ValueError("Model must be loaded before merging.")

        print(f"[INFO] Initiating weight merging process: {export_format}")
        
        # Creating the output directory if it does not exist
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
            print(f"[INFO] Created directory: {self.output_dir}")

        # Use Unsloth's optimized saving mechanism to merge and save
        # This avoids the manual 'W + BA' complexity and handles precision correctly
        if export_format == "merged_16bit":
            print("[INFO] Saving as merged FP16/BF16 weights for vLLM...")
            self.model.save_pretrained_merged(
                self.output_dir, 
                tokenizer = self.tokenizer, 
                save_method = "merged_16"
            )
        else:
            raise NotImplementedError("Only 'merged_16bit' is supported in this script.")

        print(f"[SUCCESS] Merged model exported to: {self.output_dir}")

    def verify_deployment_readiness(self):
        # Perform a sanity check to ensure the exported files are valid
        print("[INFO] Verifying deployment readiness...")
        
        required_files = ["config.json", "model.safetensors", "tokenizer.json"]
        missing_files = []

        for file in required_files:
            if not os.path.exists(os.path.join(self.output_dir, file)):
                missing_files.append(file)

        if missing_files:
            print(f"[ERROR] Verification failed. Missing files: {missing_files}")
            return False
        
        print("[SUCCESS] All critical deployment files are present. Model is vLLM-ready.")
        return True

def main():
    # Configuration for the deployment pipeline
    BASE_MODEL = "unsloth/llama-3-8b-bnb-4bit" # Example base model
    ADAPTER_DIR = "./outputs/llama3_lora_adapter" # Path to fine-tuned weights
    EXPORT_DESTINATION = "./production_ready_model" # Target for vLLM deployment

    # Instantiate the orchestrator
    orchestrator = ModelDeploymentOrchestrator(
        base_model_name=BASE_MODEL,
        adapter_path=ADAPTER_DIR,
        output_dir=EXPORT_DESTINATION
    )

    try:
        # Step 1: Load the model architecture and the LoRA delta weights
        orchestrator.load_model_and_adapters()

        # Step 2: Merge the weights and export to a standard format
        orchestrator.merge_and_export(export_format="merged_16bit")

        # Step 3: Validate the output for production deployment
        if orchestrator.verify_deployment_readiness():
            print("\n" + "="*50)
            print("DEPLOYMENT PIPELINE COMPLETE")
            print(f"Target Directory: {EXPORT_DESTINATION}")
            print("Ready for vLLM: python -m vllm.entrypoints.openai.api_server --model " + EXPORT_DESTINATION)
            print("="*50)
        else:
            print("[CRITICAL] Deployment readiness check failed!")

    except Exception as e:
        print(f"[CRITICAL ERROR] Pipeline aborted: {str(e)}")

if __name__ == "__main__":
    main()

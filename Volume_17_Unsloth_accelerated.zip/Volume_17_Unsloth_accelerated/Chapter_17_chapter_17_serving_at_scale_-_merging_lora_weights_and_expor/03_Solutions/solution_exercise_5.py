
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# Deployment Configuration Script

class DeploymentStrategy:
    def __init__(self):
        # 1. Merging Parameters
        # We use bfloat16 for merging to maintain maximum mathematical 
        # fidelity of the fine-tuned legal knowledge.
        self.merge_precision = "bfloat16" 
        
        # 2. Quantization Parameters
        # CHOICE: AWQ (Activation-aware Weight Quantization).
        # JUSTIFICATION: In legal document analysis, nuances in language 
        # are critical. AWQ protects the most important weights based on 
        # activation distributions, resulting in lower perplexity compared 
        # to GPTQ, making it superior for high-accuracy requirements.
        self.quant_method = "AWQ" 
        self.calibration_dataset = "legal_corpus_subset_v1.jsonl"
        
        # 3. vLLM Serving Parameters
        self.vllm_config = {
            "model": "llama-3-70b-legal-awq",
            "tensor_parallel_size": 4,          # Utilize all 4x A100s
            "gpu_memory_utilization": 0.90,     # Leave 10% for system/overhead
            "max_model_len": 8192,              # Balanced context for legal docs
            "quantization": "awq"
        }

    def justify_strategy(self):
        """
        Mathematical Reasoning and VRAM Estimation.
        """
        print("--- Deployment Strategy Justification ---")
        
        # --- BACK-OF-THE-ENVELOPE CALCULATIONS ---
        
        # 1. Model VRAM Estimate:
        # Llama-3 70B in 4-bit (AWQ)
        # Weights: 70 Billion parameters * 0.5 bytes (4 bits) = ~35 GB
        # Overhead (KV Cache, activation buffers, etc.): ~5-10 GB
        # Total Model Footprint: ~45 GB
        
        # 2. Available VRAM:
        # Total Hardware: 4 * 80GB = 320 GB
        # Total Model Footprint: 45 GB
        # Remaining VRAM for KV Cache: 320 GB - 45 GB = 275 GB
        
        # 3. Concurrency & Throughput Logic:
        # A 275 GB KV cache is massive. 
        # Even with long context (8k), each user's KV cache will only consume 
        # a fraction of this. This easily accommodates the 100 concurrent 
        # users requirement while leaving plenty of room for PagedAttention 
        # to manage memory efficiently.
        
        # 4. Latency/Parallelism:
        # Using tensor_parallel_size=4 splits the 45GB model across 4 GPUs.
        # Each GPU only holds ~11.25GB of weights. This reduces the memory 
        # bandwidth bottleneck per GPU, helping reach the 50 TPS target.

        print(f"Target Quantization: {self.quant_method}")
        print(f"Tensor Parallelism: {self.vllm_config['tensor_parallel_size']} GPUs")
        print(f"Estimated Model VRAM: ~45 GB")
        print(f"Estimated Available KV Cache VRAM: ~275 GB")
        print("Conclusion: Strategy meets all latency, throughput, and concurrency requirements.")

if __name__ == "__main__":
    strategy = DeploymentStrategy()
    strategy.justify_strategy()

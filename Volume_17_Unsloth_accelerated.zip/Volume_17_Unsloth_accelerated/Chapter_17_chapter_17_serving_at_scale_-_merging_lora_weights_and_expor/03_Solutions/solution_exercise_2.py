
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from unsloth import FastLanguageModel
import torch

def quantize_model(merged_model_path, calibration_data, output_path):
    """
    Converts a merged model into a 4-bit AWQ quantized model.
    """
    print(f"Loading merged model from {merged_model_path}...")
    
    # 1. Loading the Merged Model
    # We load the model in 16-bit to prepare for the quantization process.
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name = merged_model_path,
        max_seq_length = 2048,
        load_in_4bit = False, 
        dtype = torch.bfloat16,
    )

    # 2. & 3. Quantization Implementation & Calibration
    # Unsloth integrates AWQ quantization. AWQ uses the calibration_data 
    # to observe activation distributions and protect 'salient' weights.
    print("Starting 4-bit AWQ quantization (this requires calibration)...")
    
    # Note: In a production script, 'calibration_data' would be a list of strings
    # representing real-world prompts the model will encounter.
    model.save_pretrained_merged(
        output_path,
        tokenizer = tokenizer,
        save_method = "merged_4bit_awq", # Triggers the AWQ workflow
    )

    # 4. & 5. vLLM Compatibility & Storage
    # The output will automatically include .safetensors and the 
    # necessary quantization config files for vLLM to recognize it as AWQ.
    print(f"Quantized model exported to {output_path} in .safetensors format.")

if __name__ == "__main__":
    MERGED_PATH = "./consolidated_model_fp16"
    QUANT_OUTPUT = "./model_awq_4bit"
    
    # Mock calibration data (In practice, use a subset of your training/eval set)
    CALIBRATION_SET = [
        "Explain the legal implications of a breach of contract.",
        "Summarize the following judicial opinion...",
        "What is the standard of proof in civil litigation?"
    ]

    try:
        quantize_model(MERGED_PATH, CALIBRATION_SET, QUANT_OUTPUT)
    except Exception as e:
        print(f"Quantization failed: {e}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import torch
import torch.nn.functional as F
from transformers import AutoModelForCausalLM, AutoTokenizer
import math

class ModelValidator:
    def __init__(self, original_model_path, new_model_path, validation_data):
        self.original_path = original_model_path
        self.new_path = new_model_path
        self.data = validation_data
        self.tokenizer = AutoTokenizer.from_pretrained(original_model_path)

    def calculate_perplexity(self, model_path):
        """Calculates perplexity on the validation dataset."""
        model = AutoModelForCausalLM.from_pretrained(
            model_path, torch_dtype=torch.float16, device_map="auto"
        )
        model.eval()
        
        total_loss = 0
        total_tokens = 0

        with torch.no_grad():
            for text in self.data:
                inputs = self.tokenizer(text, return_tensors="pt").to(model.device)
                input_ids = inputs["input_ids"]
                
                outputs = model(input_ids, labels=input_ids)
                loss = outputs.loss
                
                total_loss += loss.item() * input_ids.size(1)
                total_tokens += input_ids.size(1)

        avg_loss = total_loss / total_tokens
        perplexity = math.exp(avg_loss)
        
        # Cleanup to prevent OOM during validation
        del model
        torch.cuda.empty_cache()
        return perplexity

    def check_semantic_drift(self, threshold=0.90):
        """
        Simplified semantic consistency check. 
        In production, use SentenceTransformers for embedding similarity.
        """
        print("Running Semantic Drift Check...")
        # For this exercise, we simulate a similarity score
        # Real implementation would compare embeddings of outputs
        sim_score = 0.95 
        return sim_score >= threshold

    def run_all_tests(self, perp_threshold=1.05):
        """Orchestrates the validation suite."""
        print("Starting Validation Suite...")
        
        # 1. Perplexity Check
        print("Step 1: Calculating Perplexity...")
        orig_perp = self.calculate_perplexity(self.original_path)
        new_perp = self.calculate_perplexity(self.new_path)
        
        print(f"Original Perplexity: {orig_perp:.2f}")
        print(f"New Perplexity: {new_perp:.2f}")

        if new_perp > (orig_perp * perp_threshold):
            print("FAILURE: Perplexity increase exceeds threshold (Precision Collapse)!")
            return False

        # 2. Semantic Drift Check
        print("Step 2: Checking Semantic Drift...")
        if not self.check_semantic_drift():
            print("FAILURE: Semantic similarity below threshold!")
            return False

        print("SUCCESS: All validation checks passed.")
        return True

if __name__ == "__main__":
    # Mock paths and data
    VAL_DATA = [
        "The defendant is guilty of negligence.",
        "Contract law governs these transactions.",
        "The court ruled in favor of the plaintiff."
    ]
    
    validator = ModelValidator(
        original_model_path="./unsloth_lora_checkpoint",
        new_model_path="./model_awq_4bit",
        validation_data=VAL_DATA
    )

    if not validator.run_all_tests():
        exit(1) # Exit with non-zero status for CI/CD failure

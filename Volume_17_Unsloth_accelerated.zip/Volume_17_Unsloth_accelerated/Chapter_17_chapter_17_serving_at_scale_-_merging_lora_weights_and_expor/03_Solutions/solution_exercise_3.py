
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import time
from vllm import LLM, SamplingParams

class ProductionInferenceEngine:
    def __init__(self, optimized_model_path, tensor_parallel_size=1, max_model_len=2048):
        """
        Refactored from PeftModel to vLLM for static, high-throughput serving.
        """
        print(f"Initializing Production Engine with model: {optimized_model_path}")
        
        # 1. & 2. Architecture Shift & Static Loading
        # We no longer load 'base_model' then 'adapter'. 
        # We load the single, optimized artifact directly into the vLLM engine.
        self.llm = LLM(
            model=optimized_model_path,
            tensor_parallel_size=tensor_parallel_size, # 3. Throughput Optimization
            max_model_len=max_model_len,
            trust_remote_code=True,
            # vLLM automatically detects .safetensors and quantization (AWQ/GPTQ)
        )
        self.sampling_params = SamplingParams(temperature=0.7, top_p=0.95, max_tokens=512)

    def generate(self, prompts):
        """Executes inference using the optimized engine."""
        return self.llm.generate(prompts, self.sampling_params)

    def benchmark_tps(self, prompt, num_iters=5):
        """
        5. Performance Benchmarking Hook: Measures Tokens Per Second (TPS).
        """
        print(f"Benchmarking TPS over {num_iters} iterations...")
        total_tokens = 0
        start_time = time.time()

        for _ in range(num_iters):
            outputs = self.generate([prompt])
            for output in outputs:
                # Count generated tokens
                total_tokens += len(output.outputs[0].token_ids)

        end_time = time.time()
        duration = end_time - start_time
        tps = total_tokens / duration
        print(f"--- Benchmark Results ---")
        print(f"Total Tokens: {total_tokens}")
        print(f"Total Time: {duration:.2f}s")
        print(f"Throughput: {tps:.2f} tokens/sec")
        return tps

if __name__ == "__main__":
    # Path to the model produced in Exercise 2
    MODEL_PATH = "./model_awq_4bit"
    
    # Configuration for a production environment (e.g., 2x GPUs)
    engine = ProductionInferenceEngine(
        optimized_model_path=MODEL_PATH,
        tensor_parallel_size=2, 
        max_model_len=4096
    )

    test_prompt = "Analyze the following legal clause: 'The parties agree to..."
    engine.benchmark_tps(test_prompt)

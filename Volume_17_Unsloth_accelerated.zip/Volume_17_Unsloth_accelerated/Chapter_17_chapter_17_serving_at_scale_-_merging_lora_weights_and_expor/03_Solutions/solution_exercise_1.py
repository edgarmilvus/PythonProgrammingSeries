
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from unsloth import FastLanguageModel
import torch
import os

def merge_and_save_model(model_path, save_dir):
    """
    Loads a fine-tuned Unsloth model, merges LoRA weights into the base model,
    and saves the result as a standard Hugging Face model.
    """
    print(f"Loading model from {model_path}...")
    
    # 1. Environment Initialization & Precision Management
    # We load in bfloat16 to ensure high precision during the addition (W0 + BA)
    # to minimize rounding errors/weight drift.
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name = model_path,
        max_seq_length = 2048,
        load_in_4bit = False, # Must be False to perform a clean merge
        dtype = torch.bfloat16,
    )

    print("Starting weight consolidation (merging LoRA into base)...")
    
    # 2. The Merge Operation & Artifact Generation
    # Unsloth's save_pretrained_merged handles the mathematical collapse 
    # and saves in the .safetensors format.
    model.save_pretrained_merged(
        save_dir, 
        tokenizer = tokenizer, 
        save_method = "merged_16bit" # Ensures high precision output
    )
    
    print(f"Successfully saved merged model to: {save_dir}")

    # 3. Verification Step
    # We check a sample weight tensor to ensure the shape matches a standard model
    # and that the weights are no longer low-rank adapters.
    verify_layer = model.model.layers[0].self_attn.q_proj
    print(f"Verification - Layer Shape: {verify_layer.weight.shape}")
    print(f"Verification - Weight Dtype: {verify_layer.weight.dtype}")
    
    if verify_layer.weight.shape != model.config.hidden_size: # Simplified check
        # In a real scenario, we'd compare against the base model's config
        pass 

if __name__ == "__main__":
    # Paths would be defined based on the local environment
    MODEL_PATH = "./unsloth_lora_checkpoint"
    OUTPUT_DIR = "./consolidated_model_fp16"
    
    if not os.path.exists(MODEL_PATH):
        print(f"Error: {MODEL_PATH} not found. Please provide a valid checkpoint.")
    else:
        merge_and_save_model(MODEL_PATH, OUTPUT_DIR)

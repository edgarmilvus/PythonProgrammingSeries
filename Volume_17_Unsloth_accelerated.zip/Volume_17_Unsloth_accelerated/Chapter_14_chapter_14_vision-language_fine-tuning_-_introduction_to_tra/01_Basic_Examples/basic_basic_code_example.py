
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Import the optimized Unsloth library for vision-language models
from unsloth import FastVisionModel
import torch
from PIL import Image # Library for image processing

def run_vlm_hello_world():
    # 1. Configuration: Define the model identifier and loading parameters
    model_name = "unsloth/llava-v1.5-7b-bnb-4bit" # A 4-bit quantized LLaVA model
    
    # 2. Model Loading: Load the vision model and tokenizer using Unsloth's fast kernels
    # This step handles the vision encoder, the projection layer, and the LLM backbone
    model, tokenizer = FastVisionModel.from_pretrained(
        model_name = model_name,
        load_in_4bit = True, # Use 4-bit quantization to save VRAM
    )

    # 3. LoRA Optimization: Prepare the model for efficient fine-tuning/inference
    # Even if we are just doing inference, Unsloth sets up the PEFT structures
    model = FastVisionModel.get_peft_model(
        model,
        r = 16,           # Rank of the LoRA adaptation
        target_modules = ["q_proj", "k_proj", "v_proj", "o_proj"], # Target attention layers
    )

    # 4. Data Preparation: Load a sample image and define the multimodal prompt
    # In a real scenario, this would be a path to a warehouse or medical image
    image_path = "sample_image.jpg" 
    try:
        image = Image.open(image_path).convert("RGB")
    except FileNotFoundError:
        # Fallback: Create a dummy black image if the file doesn't exist for demonstration
        print(f"Warning: {image_path} not found. Creating a dummy image.")
        image = Image.new('RGB', (224, 224), color = (73, 109, 137))

    # The prompt must include a special token (like <image>) that tells the 
    # model where the visual features should be injected into the text stream.
    prompt = "USER: <image>\nWhat is the main object in this image? ASSISTANT:"

    # 5. Tokenization and Formatting: Convert text and image into tensors
    # This step uses the tokenizer to create the input IDs and handles the image encoding
    inputs = tokenizer(
        images = image,
        text = prompt,
        return_tensors = "pt"
    ).to("cuda") # Move the tensors to the GPU

    # 6. Inference: Generate the response from the model
    # We use torch.no_grad() to ensure no gradients are calculated, saving memory
    with torch.no_grad():
        output_tokens = model.generate(
            **inputs,
            max_new_tokens = 64, # Limit the length of the response
            use_cache = True     # Use KV-caching for faster generation
        )

    # 7. Decoding: Convert the generated token IDs back into human-readable text
    # We skip the prompt tokens to only show the model's actual answer
    response = tokenizer.decode(output_tokens[0], skip_special_tokens=True)
    
    print("-" * 30)
    print(f"Model Response: {response}")
    print("-" * 30)

# Execute the function
if __name__ == "__main__":
    run_vlm_hello_world()

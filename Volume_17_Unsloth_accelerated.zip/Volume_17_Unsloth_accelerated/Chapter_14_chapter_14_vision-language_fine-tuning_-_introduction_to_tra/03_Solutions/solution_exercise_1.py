
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import torch
from PIL import Image, UnidentifiedImageError
import numpy as np
from datasets import Dataset
from transformers import AutoProcessor

def letterbox_image(image, target_size=(336, 336)):
    """Resizes image preserving aspect ratio and pads with black bars."""
    target_w, target_h = target_size
    img_w, img_h = image.size
    
    # Calculate scaling factor
    scale = min(target_w / img_w, target_h / img_h)
    new_w, new_h = int(img_w * scale), int(img_h * scale)
    
    # Resize
    resized_img = image.resize((new_w, new_h), Image.Resampling.LANCZOS)
    
    # Create black background (canvas)
    new_img = Image.new("RGB", target_size, (0, 0, 0))
    
    # Paste resized image into the center
    offset_x = (target_w - new_w) // 2
    offset_y = (target_h - new_h) // 2
    new_img.paste(resized_img, (offset_x, offset_y))
    
    return new_img

def create_multimodal_pipeline(raw_dataset, processor, target_res=(336, 336), placeholder="<image>\n"):
    """
    Processes a dataset using the .map() method with batched=True.
    """
    
    def preprocess_function(examples):
        processed_pixel_values = []
        processed_input_ids = []
        processed_attention_masks = []
        
        # Iterate through the batch
        for i in range(len(examples['image'])):
            try:
                # 1. Data Loading & Validation
                raw_image = examples['image'][i]
                if raw_image is None:
                    raise ValueError("Empty image")
                
                # Ensure it's a PIL image (if it's a path, open it)
                if isinstance(raw_image, str):
                    img = Image.open(raw_image).convert("RGB")
                else:
                    img = raw_image.convert("RGB")
                
                # 2. Aspect Ratio Management (Letterboxing)
                img = letterbox_image(img, target_res)
                
                # 3. Token Placeholder Injection
                text = examples['text'][i]
                if not text or text.strip() == "":
                    text = "Describe this image." # Default fallback
                
                full_prompt = f"{placeholder}{text}"
                
                # 4. Tensor Transformation via Processor
                inputs = processor(text=full_prompt, images=img, return_tensors="pt")
                
                # Remove batch dimension added by processor for single item processing
                processed_pixel_values.append(inputs['pixel_values'][0])
                processed_input_ids.append(inputs['input_ids'][0])
                processed_attention_masks.append(inputs['attention_mask'][0])
                
            except (UnidentifiedImageError, ValueError, Exception) as e:
                # Log error and skip by appending 'None' or handling via filtering later
                print(f"Skipping corrupted sample at index {i}: {e}")
                continue

        # Return as a dictionary of lists (to be converted to tensors by datasets)
        return {
            "pixel_values": processed_pixel_values,
            "input_ids": processed_input_ids,
            "attention_mask": processed_attention_masks
        }

    # 5. Efficiency Constraint: Use .map with batched=True
    # Note: In a real scenario, we'd use .filter() first to remove corrupted ones 
    # or handle the mismatch in lengths. Here we assume successful processing.
    processed_ds = raw_dataset.map(
        preprocess_function,
        batched=True,
        remove_columns=raw_dataset.column_names,
        desc="Running Multimodal Preprocessing"
    )
    
    return processed_ds

# --- Mock Setup for Demonstration ---
if __name__ == "__main__":
    # Mock data
    mock_data = {
        "image": [Image.new('RGB', (1000, 500), color='red'), Image.new('RGB', (200, 400), color='blue')],
        "text": ["A red landscape", "A blue object"]
    }
    dataset = Dataset.from_dict(mock_data)
    
    # Mock Processor (In reality, use AutoProcessor.from_pretrained("llava-hf/llava-1.5-7b-hf"))
    class MockProcessor:
        def __call__(self, text, images, return_tensors="pt"):
            return {
                "pixel_values": torch.randn(1, 3, 336, 336),
                "input_ids": torch.randint(0, 100, (1, 10)),
                "attention_mask": torch.ones(1, 10)
            }
    
    processor = MockProcessor()
    final_ds = create_multimodal_pipeline(dataset, processor)
    print(f"Processed Dataset Size: {len(final_ds)}")

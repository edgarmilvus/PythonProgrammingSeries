
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import torch
import re
import time
import pandas as pd
from typing import List, Tuple

def calculate_iou(box1: List[float], box2: List[float]) -> float:
    """Calculates Intersection over Union (IoU) for two bounding boxes [xmin, ymin, xmax, ymax]."""
    if not box1 or not box2:
        return 0.0
    
    x_left = max(box1[0], box2[0])
    y_top = max(box1[1], box2[1])
    x_right = min(box1[2], box2[2])
    y_bottom = min(box1[3], box2[3])

    if x_right < x_left or y_bottom < y_top:
        return 0.0

    intersection_area = (x_right - x_left) * (y_bottom - y_top)
    area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
    area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
    
    union_area = area1 + area2 - intersection_area
    return intersection_area / union_area if union_area > 0 else 0.0

def parse_coordinates(text: str) -> List[float]:
    """Uses Regex to extract [xmin, ymin, xmax, ymax] from model string."""
    pattern = r"\[(\d+),\s*(\d+),\s*(\d+),\s*(\d+)\]"
    match = re.search(pattern, text)
    if match:
        return [float(x) for x in match.groups()]
    return []

def run_benchmark(model, dataset):
    """
    3. The Simulation Loop
    """
    results = []
    
    for item in dataset:
        image = item['image']
        gt_box = item['gt_box'] # [xmin, ymin, xmax, ymax]
        
        # Measure Latency and VRAM
        torch.cuda.reset_peak_memory_stats()
        start_time = time.perf_counter()
        
        # Generate Prediction
        # (Assuming model.generate returns a string)
        prompt = f"Find the object in this image. Return coordinates as [xmin, ymin, xmax, ymax]"
        output_text = model.generate(image, prompt) 
        
        latency = (time.perf_counter() - start_time) * 1000
        vram_used = torch.cuda.max_memory_allocated() / (1024**3) # GB
        
        # 5. Error Handling for Hallucinations
        pred_box = parse_coordinates(output_text)
        iou_score = calculate_iou(gt_box, pred_box) if pred_box else 0.0
        
        results.append({
            "iou": iou_score,
            "latency": latency,
            "vram": vram_used
        })
        
    # 4. Data Collection
    df = pd.DataFrame(results)
    summary = {
        "Mean IoU": df["iou"].mean(),
        "Mean Latency (ms)": df["latency"].mean(),
        "Mean VRAM (GB)": df["vram"].mean()
    }
    return summary

# --- Mock Execution ---
if __name__ == "__main__":
    class MockModel:
        def generate(self, img, prompt):
            # Simulate 4-bit model hallucinating occasionally
            import random
            if random.random() > 0.8:
                return "I see a cat here." # Hallucination
            return "[100, 150, 300, 400]"

    mock_dataset = [
        {"image": None, "gt_box": [100, 150, 310, 410]},
        {"image": None, "gt_box": [50, 50, 200, 200]},
    ]

    # Simulate Config A (BF16)
    print("Running Config_A (BF16)...")
    summary_a = run_benchmark(MockModel(), mock_dataset)
    
    # Simulate Config B (4-bit)
    print("Running Config_B (4-bit)...")
    summary_b = run_benchmark(MockModel(), mock_dataset)

    # Final Comparison Table
    comparison = pd.DataFrame([summary_a, summary_b], index=["BF16", "4-bit"])
    comparison.loc["% Degradation (IoU)"] = [0, (summary_a["Mean IoU"] - summary_b["Mean IoU"]) / summary_a["Mean IoU"] * 100]
    
    print("\n--- Final Benchmark Report ---")
    print(comparison)

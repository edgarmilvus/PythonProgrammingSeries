
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import torch
import torch.nn as nn
import torch.nn.functional as F

class MultimodalProjection(nn.Module):
    def __init__(self, d_vision: int, d_hidden: int, d_text: int):
        super().__init__()
        self.d_vision = d_vision
        self.d_text = d_text
        
        # 1. Module Architecture (Named clearly for LoRA targeting)
        self.proj_1 = nn.Linear(d_vision, d_hidden)
        self.proj_2 = nn.Linear(d_hidden, d_text)
        self.activation = nn.GELU()
        
        # 2. Initialization Logic
        self._init_weights()

    def _init_weights(self):
        """Applies Xavier Uniform initialization to prevent gradient instability."""
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # 3. Shape Validation
        # Expected shape: (batch_size, seq_len, d_vision)
        assert x.dim() == 3, f"Expected 3D tensor (B, S, D), got {x.dim()}D"
        assert x.shape[-1] == self.d_vision, (
            f"Input dimension mismatch. Expected {self.d_vision}, got {x.shape[-1]}"
        )
        
        # Forward pass
        x = self.proj_1(x)
        x = self.activation(x)
        x = self.proj_2(x)
        
        # Validate output shape
        assert x.shape[-1] == self.d_text, f"Output dimension mismatch. Expected {self.d_text}, got {x.shape[-1]}"
        
        return x

    # 5. Parameter Management
    def get_trainable_parameters(self) -> int:
        """Returns the count of parameters that require gradients."""
        return sum(p.numel() for p in self.parameters() if p.requires_grad)

# --- Testing the Module ---
if __name__ == "__main__":
    D_VIS = 1024
    D_HID = 2048
    D_TXT = 4096
    BATCH = 4
    SEQ_LEN = 576 # Typical for ViT-L/14
    
    projection = MultimodalProjection(D_VIS, D_HID, D_TXT)
    test_input = torch.randn(BATCH, SEQ_LEN, D_VIS)
    output = projection(test_input)
    
    print(f"Input Shape:  {test_input.shape}")
    print(f"Output Shape: {output.shape}")
    print(f"Trainable Params: {projection.get_trainable_parameters():,}")
    
    # Verify LoRA compatibility naming
    print(f"Layer names: {[name for name, _ in projection.named_modules()]}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import torch
import torch.nn as nn

class VisualPromptTuner(nn.Module):
    def __init__(self, num_prompt_tokens: int, d_vision: int):
        super().__init__()
        self.num_prompt_tokens = num_prompt_tokens
        self.d_vision = d_vision
        
        # 1. The VPT Module: Learnable prompt embeddings
        # Initialized as a parameter so it is updated during training
        self.prompt_embeddings = nn.Parameter(
            torch.randn(1, num_prompt_tokens, d_vision)
        )

    def forward(self, visual_features: torch.Tensor) -> torch.Tensor:
        """
        2. The Injection Logic:
        Concatenates learnable prompts with the vision encoder output.
        """
        batch_size = visual_features.shape[0]
        
        # Expand prompts to match batch size: (B, num_tokens, D_vision)
        prompts = self.prompt_embeddings.expand(batch_size, -1, -1)
        
        # Concatenate along the sequence dimension (dim=1)
        new_visual_features = torch.cat([prompts, visual_features], dim=1)
        
        return new_visual_features

def apply_hybrid_training_logic(model, vpt_module):
    """
    3. Selective Parameter Freezing logic.
    """
    # Freeze the entire model first
    for param in model.parameters():
        param.requires_grad = False
        
    # Enable LoRA parameters (assuming they were added via PEFT)
    for name, param in model.named_parameters():
        if "lora_" in name:
            param.requires_grad = True
            
    # Enable ONLY the VPT prompt embeddings
    for param in vpt_module.parameters():
        param.requires_grad = True
        
    return model, vpt_module

# 4. Integration with Unsloth (Pseudo-code logic)
"""
To integrate with Unsloth:
1. Load the FastVisionModel using Unsloth.
2. Initialize the VisualPromptTuner.
3. Wrap the model's vision encoder forward pass:
   def patched_forward(images):
       features = model.vision_encoder(images)
       return vpt_module(features)
4. When creating the optimizer:
   optimizer = torch.optim.AdamW([
       {'params': model.parameters(), 'lr': 2e-5}, # LoRA params
       {'params': vpt_module.parameters(), 'lr': 1e-4} # VPT params (usually higher LR)
   ])
"""

# 5. Complexity Analysis
def run_complexity_analysis():
    num_prompt_tokens = 10
    d_vision = 1024
    
    # VPT Parameters
    vpt_params = num_prompt_tokens * d_vision
    
    # LoRA Parameters (Approximate for Llama-3-8B)
    # Formula: 2 * r * d_model * layers * (num_target_modules)
    # Assuming r=16, d_model=4096, layers=32, target_modules=7
    r = 16
    d_model = 4096
    layers = 32
    num_modules = 7
    lora_params = 2 * r * d_model * layers * num_modules
    
    print(f"VPT Parameters: {vpt_params:,}")
    print(f"LoRA Parameters (Approx): {lora_params:,}")
    print(f"VPT is {lora_params / vpt_params:.2f}x more efficient than LoRA.")

if __name__ == "__main__":
    run_complexity_analysis()

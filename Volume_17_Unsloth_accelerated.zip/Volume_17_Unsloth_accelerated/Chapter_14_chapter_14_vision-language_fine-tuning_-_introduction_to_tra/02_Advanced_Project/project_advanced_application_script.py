
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import torch
from PIL import Image
from typing import List, Dict, Any
from unsloth import FastVisionModel
from transformers import TrainingArguments
from trl import SFTTrainer
from datasets import Dataset

# ---------------------------------------------------------------------------
# 1. DATA PREPARATION: MULTIMODAL CLINICAL DATASET
# ---------------------------------------------------------------------------

def prepare_medical_dataset(image_paths: List[str], annotations: List[Dict[str, str]]) -> Dataset:
    """
    Converts raw image paths and clinical text annotations into a 
    structured format compatible with VLM training.
    """
    formatted_data = []
    for img_path, anno in zip(image_paths, annotations):
        # We structure the data as a conversation involving an image and a response
        # This mimics the 'instruction-following' paradigm required for VLMs
        formatted_data.append({
            "image": img_path,
            "conversations": [
                {
                    "from": "human",
                    "value": "<image>\nAnalyze this dermatological lesion and provide a clinical summary."
                },
                {
                    "from": "gpt",
                    "value": anno["description"]
                }
            ]
        })
    return Dataset.from_list(formatted_data)

# ---------------------------------------------------------------------------
# 2. MODEL INITIALIZATION: UNSLOTH OPTIMIZED VLM
# ---------------------------------------------------------------------------

def initialize_vlm_engine(model_id: str):
    """
    Loads the Vision-Language Model using Unsloth's FastVisionModel 
    to enable 2x faster training and 70% less memory usage.
    """
    # FastVisionModel handles the complex orchestration of loading 
    # both the vision encoder and the LLM backbone simultaneously.
    model, tokenizer = FastVisionModel.from_pretrained(
        model_id=model_id,
        load_in_4bit=True,  # Use 4-bit quantization for extreme memory efficiency
        use_gradient_checkpointing=True, # Reduces memory by re-computing activations
    )

    # Apply LoRA (Low-Rank Adaptation) to the model.
    # Crucially, we target both the LLM layers and the multimodal projection layers.
    model = FastVisionModel.get_peft_model(
        model,
        r=16,               # Rank of the adaptation matrices
        target_modules=[
            "q_proj", "k_proj", "v_proj", "o_proj", # LLM Attention layers
            "mm_projector"                          # The Vision-Language Bridge
        ],
        lora_alpha=16,
        lora_dropout=0,
        bias="none",
    )
    
    return model, tokenizer

# ---------------------------------------------------------------------------
# 3. THE TRAINING ORCHESTRATOR
# ---------------------------------------------------------------------------

def run_multimodal_fine_tuning(model, tokenizer, train_dataset: Dataset):
    """
    Executes the fine-tuning loop using the SFT (Supervised Fine-Tuning) 
    trainer, optimized for multimodal inputs.
    """
    training_args = TrainingArguments(
        per_device_train_batch_size=2,
        gradient_accumulation_steps=4,
        warmup_steps=5,
        max_steps=60,           # Short run for demonstration purposes
        learning_rate=2e-4,     # Slightly higher LR for the projection layer
        fp16=not torch.cuda.is_bf16_supported(),
        bf16=torch.cuda.is_bf16_supported(),
        logging_steps=1,
        optim="adamw_8bit",     # 8-bit optimizer to save VRAM
        weight_decay=0.01,
        output_dir="outputs/vlm_dermatology_model",
        save_strategy="steps",
        save_steps=20,
    )

    # The SFTTrainer handles the complex task of interleaving image 
    # pixel values and text tokens into a single training batch.
    trainer = SFTTrainer(
        model=model,
        tokenizer=tokenizer,
        train_dataset=train_dataset,
        dataset_text_field="conversations",
        max_seq_length=2048,
        args=training_args,
    )

    # Kick off the training process
    trainer.train()
    return model

# ---------------------------------------------------------------------------
# 4. MAIN EXECUTION PIPELINE
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # Mock Data: In a real scenario, these would be paths to high-res medical images
    mock_images = ["lesion_001.jpg", "lesion_002.jpg", "lesion_003.jpg"]
    mock_annotations = [
        {"description": "Erythematous plaque with irregular borders, suggestive of psoriasis."},
        {"description": "Pigmented lesion with asymmetric color distribution, suspicious for melanoma."},
        {"description": "Small, benign-looking nevus with regular margins."}
    ]

    print("--- Initializing Multimodal Data Pipeline ---")
    dataset = prepare_medical_dataset(mock_images, mock_annotations)

    print("--- Loading Unsloth-Optimized VLM (4-bit) ---")
    # Using a placeholder model ID; in practice, use 'unsloth/Llama-3-8B-Instruct-bnb-4bit'
    # or a specific VLM checkpoint like 'llava-v1.5-7b'
    vlm_model, vlm_tokenizer = initialize_vlm_engine("unsloth/Llama-3-8B-Instruct-bnb-4bit")

    print("--- Commencing Vision-Language Alignment Training ---")
    trained_model = run_multimodal_fine_tuning(vlm_model, vlm_tokenizer, dataset)

    print("--- Training Complete. Model Saved to 'outputs/' ---")
    # Final step: Save the LoRA adapters for deployment
    trained_model.save_pretrained("vlm_dermatology_lora_adapter")
    vlm_tokenizer.save_pretrained("vlm_dermatology_lora_adapter")

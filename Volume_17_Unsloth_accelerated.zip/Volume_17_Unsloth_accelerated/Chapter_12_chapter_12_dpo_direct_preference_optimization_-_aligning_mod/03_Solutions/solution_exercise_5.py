
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import time
from dataclasses import dataclass
from typing import List, Union, Dict, Any

@dataclass
class ErrorRecord:
    index: int
    reason: str
    raw_data: Any

@dataclass
class ValidatedTriplet:
    prompt: str
    chosen: str
    rejected: str

class DataPipeline:
    def __init__(self, max_token_limit: int = 4096):
        self.max_token_limit = max_token_limit
        self.malformed_entry_log: List[ErrorRecord] = []

    def _check_sanity(self, triplet: ValidatedTriplet) -> bool:
        """Internal sanity checks."""
        if len(triplet.prompt) < 5 or len(triplet.chosen) < 5:
            return False
        # Mock token limit check
        if len(triplet.chosen.split()) > self.max_token_limit:
            return False
        return True

    def process_raw_entry(self, index: int, entry: Dict) -> Union[ValidatedTriplet, ErrorRecord]:
        """
        Implements EAFP pattern to extract data.
        """
        try:
            # EAFP: We assume the keys exist and try to use them
            prompt = entry["prompt"]
            chosen = entry["chosen"]
            rejected = entry["rejected"]
            
            triplet = ValidatedTriplet(prompt=prompt, chosen=chosen, rejected=rejected)
            
            if not self._check_sanity(triplet):
                return ErrorRecord(index, "Sanity check failed (too short/long)", entry)
            
            return triplet

        except KeyError as e:
            return ErrorRecord(index, f"Missing required key: {str(e)}", entry)
        except TypeError as e:
            return ErrorRecord(index, f"Invalid data type: {str(e)}", entry)
        except Exception as e:
            return ErrorRecord(index, f"Unexpected error: {str(e)}", entry)

    def validate_dataset(self, raw_data: List[Dict]) -> List[ValidatedTriplet]:
        """
        Validates the dataset and returns only valid triplets.
        Follows POLA: Name implies only validation and collection.
        """
        validated_triplet_dataset: List[ValidatedTriplet] = []
        
        for i, entry in enumerate(raw_data):
            result = self.process_raw_entry(i, entry)
            
            if isinstance(result, ValidatedTriplet):
                validated_triplet_dataset.append(result)
            else:
                self.malformed_entry_log.append(result)
                
        return validated_triplet_dataset

# --- Benchmarking ---
def run_benchmark():
    pipeline = DataPipeline()
    
    # Create 100,000 mock entries
    mock_data = []
    for i in range(100000):
        if i % 1000 == 0: # Inject errors
            mock_data.append({"prompt": "bad"}) 
        else:
            mock_data.append({
                "prompt": "How to bake a cake?",
                "chosen": "Mix flour, eggs, and sugar.",
                "rejected": "Just eat a store-bought cake."
            })

    start_time = time.time()
    valid_data = pipeline.validate_dataset(mock_data)
    end_time = time.time()

    print(f"Processed 100,000 entries in: {end_time - start_time:.4f} seconds")
    print(f"Valid triplets: {len(valid_data)}")
    print(f"Malformed entries caught: {len(pipeline.malformed_entry_log)}")
    
    if pipeline.malformed_entry_log:
        print(f"Sample Error: {pipeline.malformed_entry_log[0].reason}")

if __name__ == "__main__":
    run_benchmark()

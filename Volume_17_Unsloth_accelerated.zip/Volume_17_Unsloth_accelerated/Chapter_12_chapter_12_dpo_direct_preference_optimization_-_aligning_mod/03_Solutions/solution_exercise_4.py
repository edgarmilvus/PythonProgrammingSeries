
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import json
import threading
import time
import queue
from typing import List, Dict, Tuple

class PreferenceStreamer:
    def __init__(self, storage_path: str, batch_size: int = 5):
        self.storage_path = storage_path
        self.batch_size = batch_size
        self.buffer: List[Dict] = []
        self.seen_preferences: Dict[str, str] = {} # Key: (prompt+respA+respB), Value: winner
        self.lock = threading.Lock()
        self.write_queue = queue.Queue()
        
        # Start background writer thread
        self.worker_thread = threading.Thread(target=self._background_writer, daemon=True)
        self.worker_thread.start()

    def _generate_key(self, prompt: str, a: str, b: str) -> str:
        return f"{prompt}|{a}|{b}"

    def submit_preference(self, prompt: str, resp_a: str, resp_b: str, winner: str):
        """
        Non-blocking submission of human preference.
        """
        key = self._generate_key(prompt, resp_a, resp_b)
        winner_label = 'A' if winner == 'A' else 'B'
        
        with self.lock:
            # 1. Conflict Detection
            if key in self.seen_preferences and self.seen_preferences[key] != winner_label:
                print(f"[CONFLICT] Prompt: {prompt[:20]}... | Expected {self.seen_preferences[key]}, got {winner_label}")
                return

            # 2. Add to buffer
            entry = {
                "prompt": prompt,
                "chosen": resp_a if winner == 'A' else resp_b,
                "rejected": resp_b if winner == 'A' else resp_a
            }
            self.buffer.append(entry)
            self.seen_preferences[key] = winner_label

            # 3. Batch Flush Trigger
            if len(self.buffer) >= self.batch_size:
                batch_to_write = list(self.buffer)
                self.buffer.clear()
                self.write_queue.put(batch_to_write)

    def _background_writer(self):
        """
        Asynchronous worker that handles disk I/O.
        """
        while True:
            batch = self.write_queue.get()
            if batch is None: break
            
            with open(self.storage_path, 'a') as f:
                for item in batch:
                    f.write(json.dumps(item) + "\n")
            print(f"[System] Flushed {len(batch)} entries to disk.")
            self.write_queue.task_done()

# --- Simulation ---
def run_simulation():
    streamer = PreferenceStreamer("human_feedback.jsonl", batch_size=3)
    
    mock_tasks = [
        ("Explain gravity.", "It's a force.", "It's curvature.", "A"),
        ("Explain gravity.", "It's a force.", "It's curvature.", "B"), # CONFLICT
        ("What is AI?", "Machine learning.", "Simulation.", "B"),
        ("What is AI?", "Machine learning.", "Simulation.", "B"),
        ("What is AI?", "Machine learning.", "Simulation.", "B"), # Triggers flush
        ("Python help.", "Use lists.", "Use dicts.", "A"),
    ]

    for p, a, b, w in mock_tasks:
        print(f"User selecting {w} for: {p}")
        streamer.submit_preference(p, a, b, w)
        time.sleep(0.1)

    time.sleep(1) # Wait for background thread to finish

if __name__ == "__main__":
    run_simulation()

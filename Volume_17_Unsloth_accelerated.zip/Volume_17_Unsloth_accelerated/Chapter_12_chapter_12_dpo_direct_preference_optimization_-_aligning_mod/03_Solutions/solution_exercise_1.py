
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import json
from datasets import Dataset
from typing import Dict, List, Optional, Generator

def preference_generator(file_path: str, score_threshold: float = 0.5, placeholders: List[str] = None) -> Generator[Dict[str, str], None, None]:
    """
    A memory-efficient generator that processes raw JSONL records into DPO triplets.
    """
    if placeholders is None:
        placeholders = ["[REDACTED]", "N/A", "None"]

    with open(file_path, 'r') as f:
        for line in f:
            try:
                record = json.loads(line)
                prompt = record.get("prompt")
                candidates = record.get("candidate_responses")
                scores = record.get("human_score")

                # 1. Data Validation: Missing keys or nulls
                if not all([prompt, candidates, scores]) or len(candidates) != len(scores):
                    continue

                # 2. Filter Placeholders
                if any(p in prompt for p in placeholders):
                    continue

                # Find indices for highest and lowest scores
                # Tie-breaking: If scores are equal, use response length as a deterministic tie-breaker
                indexed_candidates = []
                for i in range(len(candidates)):
                    resp = candidates[i]
                    # Skip if response contains placeholder
                    if any(p in resp for p in placeholders):
                        continue
                    indexed_candidates.append({
                        "text": resp,
                        "score": scores[i],
                        "len": len(resp)
                    })

                if len(indexed_candidates) < 2:
                    continue

                # Sort by score (desc) then length (desc) for deterministic tie-breaking
                indexed_candidates.sort(key=lambda x: (x['score'], x['len']), reverse=True)
                
                chosen_obj = indexed_candidates[0]
                rejected_obj = indexed_candidates[-1]

                # 3. Threshold Check
                if (chosen_obj['score'] - rejected_obj['score']) < score_threshold:
                    continue

                # 4. Identity Check
                if chosen_obj['text'] == rejected_obj['text']:
                    continue

                yield {
                    "prompt": prompt,
                    "chosen": chosen_obj['text'],
                    "rejected": rejected_obj['text']
                }

            except (json.JSONDecodeError, KeyError, TypeError):
                # Skip malformed lines
                continue

def build_dpo_dataset(file_path: str) -> Dataset:
    """
    Converts the generator into a Hugging Face Dataset.
    """
    return Dataset.from_generator(preference_generator, gen_kwargs={"file_path": file_path})

# --- Mock Execution ---
if __name__ == "__main__":
    # Creating a dummy file for demonstration
    mock_data = [
        {"prompt": "How to use DPO?", "candidate_responses": ["Use Unsloth.", "Use PyTorch.", "N/A"], "human_score": [0.9, 0.4, 0.1]},
        {"prompt": "Tie case", "candidate_responses": ["Short", "Longer response"], "human_score": [0.8, 0.8]}, # Should be handled by length
        {"prompt": "Low delta", "candidate_responses": ["Good", "Bad"], "human_score": [0.6, 0.55]}, # Should be discarded
        {"prompt": "Placeholder", "candidate_responses": ["[REDACTED]", "Valid"], "human_score": [0.1, 0.9]} # Should be discarded
    ]
    with open("raw_data.jsonl", "w") as f:
        for entry in mock_data:
            f.write(json.dumps(entry) + "\n")

    dpo_dataset = build_dpo_dataset("raw_data.jsonl")
    print(f"Processed Dataset: {dpo_dataset}")
    print(f"First entry: {dpo_dataset[0]}")

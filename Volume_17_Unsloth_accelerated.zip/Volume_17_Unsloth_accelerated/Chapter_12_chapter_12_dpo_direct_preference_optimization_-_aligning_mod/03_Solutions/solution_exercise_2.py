
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import torch
import torch.nn.functional as F
from typing import Dict

class DPOValidator:
    def __init__(self, device: str = "cuda"):
        self.device = device

    @torch.no_grad()
    def compute_log_probs(self, model, tokenizer, prompt: str, response: str) -> torch.Tensor:
        """
        Computes log P(response | prompt).
        """
        full_text = prompt + response
        inputs = tokenizer(full_text, return_tensors="pt").to(self.device)
        prompt_ids = tokenizer(prompt, return_tensors="pt").input_ids.to(self.device)
        
        outputs = model(**inputs)
        logits = outputs.logits  # [batch, seq_len, vocab_size]

        # Shift logits and labels to align for next-token prediction
        # We only care about the log-probs of the response tokens
        shift_logits = logits[..., :-1, :].contiguous()
        shift_labels = inputs.input_ids[..., 1:].contiguous()
        
        # Calculate log-probabilities for all tokens
        log_probs = F.log_softmax(shift_logits, dim=-1)
        
        # Gather the log-probs of the actual tokens present in the sequence
        per_token_logps = torch.gather(log_probs, dim=2, index=shift_labels.unsqueeze(2)).squeeze(2)

        # Mask out the prompt tokens so we only sum the response part
        prompt_len = prompt_ids.shape[1]
        # The response starts at index (prompt_len - 1) in the shifted_labels
        response_logps = per_token_logps[:, prompt_len - 1:]
        
        return response_logps.sum(dim=-1)

    def calculate_dpo_ratio(self, 
                            log_p_w_pol: torch.Tensor, log_p_w_ref: torch.Tensor,
                            log_p_l_pol: torch.Tensor, log_p_l_ref: torch.Tensor) -> torch.Tensor:
        """
        Calculates the DPO implicit reward ratio in log-space for numerical stability.
        ratio = exp(log_p_w_pol - log_p_w_ref) / exp(log_p_l_pol - log_p_l_ref)
        In log space: log_ratio = (log_p_w_pol - log_p_w_ref) - (log_p_l_pol - log_p_l_ref)
        """
        # Use log-space to prevent overflow/underflow
        log_ratio = (log_p_w_pol - log_p_w_ref) - (log_p_l_pol - log_p_l_ref)
        return log_ratio

    def beta_sensitivity_analysis(self, log_ratios: torch.Tensor, beta_range: List[float]):
        """
        Simulates how DPO loss (simplified) changes with beta.
        Loss ~ -log_sigmoid(beta * log_ratio)
        """
        print(f"{'Beta':<10} | {'Avg Simulated Loss':<20}")
        print("-" * 35)
        for beta in beta_range:
            # DPO Loss formula: -E[log_sigmoid(beta * (log_ratio))]
            loss = -torch.log(torch.sigmoid(beta * log_ratios)).mean()
            print(f"{beta:<10.2f} | {loss.item():<20.6f}")

# --- Mock Execution ---
if __name__ == "__main__":
    # Mocking tensors to simulate model outputs
    # log_p_w_pol (chosen/policy) should be higher than ref
    # log_p_l_pol (rejected/policy) should be lower than ref
    log_p_w_pol = torch.tensor([2.5, 3.0, 1.5])
    log_p_w_ref = torch.tensor([1.0, 1.2, 0.5])
    log_p_l_pol = torch.tensor([-2.0, -3.0, -1.5])
    log_p_l_ref = torch.tensor([-1.0, -1.5, -0.5])

    validator = DPOValidator()
    
    # Calculate log-ratios
    log_ratios = validator.calculate_dpo_ratio(log_p_w_pol, log_p_w_ref, log_p_l_pol, log_p_l_ref)
    print(f"Log Ratios: {log_ratios}")

    # Sensitivity Analysis
    validator.beta_sensitivity_analysis(log_ratios, [0.1, 0.3, 0.5, 0.7, 1.0])

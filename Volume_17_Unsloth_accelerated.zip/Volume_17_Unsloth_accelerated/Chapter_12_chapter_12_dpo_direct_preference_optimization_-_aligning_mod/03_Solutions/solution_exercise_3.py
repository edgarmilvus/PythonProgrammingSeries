
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from transformers import TrainerCallback, TrainingArguments
import torch

class DynamicBetaCallback(TrainerCallback):
    """
    Monitors KL divergence and adjusts beta to balance stability and plasticity.
    """
    def __init__(self, min_beta=0.01, max_beta=0.5, target_kl=0.1):
        self.min_beta = min_beta
        self.max_beta = max_beta
        self.target_kl = target_kl

    def on_evaluate(self, args, state, control, model=None, **kwargs):
        # In a real scenario, we would extract KL from the trainer's evaluation logs
        # Here we simulate the KL divergence value
        current_kl = kwargs.get('current_kl', 0.05) 
        
        # Access the beta in the training arguments (assuming it's stored there)
        # Note: In standard transformers, beta isn't a default arg, 
        # so we assume it's passed via custom training_args
        current_beta = getattr(args, "dpo_beta", 0.1)

        if current_kl > self.target_kl * 1.5:
            # Divergence too high -> Increase beta (more penalty)
            new_beta = min(current_beta * 1.1, self.max_beta)
            print(f"\n[KL Alert] KL ({current_kl:.4f}) high. Increasing beta to {new_beta:.4f}")
        elif current_kl < self.target_kl * 0.5:
            # Divergence too low -> Decrease beta (more plasticity)
            new_beta = max(current_beta * 0.9, self.min_beta)
            print(f"\n[KL Alert] KL ({current_kl:.4f}) low. Decreasing beta to {new_beta:.4f}")
        else:
            new_beta = current_beta

        args.dpo_beta = new_beta

class RankScalingStrategy:
    """
    Simulates rank scaling by adjusting LoRA Alpha.
    Increasing Alpha effectively increases the 'strength' of the LoRA adapters.
    """
    @staticmethod
    def scale_lora_alpha(model, step: int, initial_alpha: float = 16.0):
        # Implementation logic for Unsloth/PEFT
        # As training progresses, we increase the influence of the adapters
        new_alpha = initial_alpha * (1 + (step / 1000)) 
        
        for name, param in model.named_parameters():
            if "lora_A" in name or "lora_B" in name:
                # In a real implementation, we would update the scaling factor
                # Here we simulate the logic
                pass
        return new_alpha

# --- Mock Training Loop ---
class MockTrainingArgs:
    def __init__(self):
        self.dpo_beta = 0.1
        self.report_to = "none"

def train_simulation():
    args = MockTrainingArgs()
    callback = DynamicBetaCallback()
    
    print(f"Starting training with Beta: {args.dpo_beta}")
    
    # Simulate 3 evaluation steps with varying KL
    simulated_kl_values = [0.02, 0.25, 0.05]
    
    for i, kl in enumerate(simulated_kl_values):
        print(f"\n--- Step {i+1} ---")
        # Simulate the callback being triggered by the trainer
        callback.on_evaluate(args, state=None, control=None, current_kl=kl)
        print(f"Current Beta in Args: {args.dpo_beta}")

if __name__ == "__main__":
    train_simulation()

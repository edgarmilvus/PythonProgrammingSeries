
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Import the Unsloth library for high-speed model loading and optimization
from unsloth import FastLanguageModel
import torch
# Import the Dataset class to handle our preference data
from datasets import Dataset
# Import the DPOTrainer from the TRL (Transformer Reinforcement Learning) library
from trl import DPOTrainer
# Import TrainingArguments to configure the optimization process
from transformers import TrainingArguments

# --- STEP 1: Model and Tokenizer Setup ---
# We load a pre-trained model and tokenizer using Unsloth's optimized loading mechanism.
# This significantly reduces VRAM usage and increases training speed.
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name = "unsloth/llama-3-8b-bnb-4bit", # A quantized Llama-3 model
    max_seq_length = 512,                      # Maximum sequence length for training
    load_in_4bit = True,                       # Use 4-bit quantization to save memory
)

# We add LoRA (Low-Rank Adaptation) adapters to the model.
# This allows us to train only a tiny fraction of the parameters, making DPO efficient.
model = FastLanguageModel.get_peft_model(
    model,
    r = 16,               # Rank of the adaptation (higher = more capacity, more memory)
    target_modules = ["q_proj", "k_proj", "v_proj", "o_proj"], # Layers to adapt
    lora_alpha = 16,      # Scaling factor for LoRA
    lora_dropout = 0,     # Dropout rate (0 is best for Unsloth performance)
    bias = "none",        # Do not train bias parameters
)

# --- STEP 2: Preference Dataset Construction ---
# DPO requires a specific format: a 'prompt', a 'chosen' response, and a 'rejected' response.
# In a real scenario, this would be thousands of human-annotated pairs.
data = {
    "prompt": [
        "Explain the concept of gravity in one sentence.",
        "How do I make a cup of tea?",
        "Write a short poem about coding."
    ],
    "chosen": [
        "Gravity is the force by which a planet or other body draws objects toward its center.",
        "To make tea, boil water and pour it over a tea bag in a cup, letting it steep.",
        "Lines of logic, dark and bright, weaving code through the silent night."
    ],
    "rejected": [
        "It is a thing that pulls stuff down.",
        "Just put water in a cup and add tea leaves.",
        "I like to code on my computer every day."
    ]
}

# Convert our dictionary into a Hugging Face Dataset object
dataset = Dataset.from_dict(data)

# --- STEP 3: DPO Training Configuration ---
# We define the hyperparameters for the training process.
training_args = TrainingArguments(
    per_device_train_batch_size = 2,      # Number of examples per GPU per step
    gradient_accumulation_steps = 4,     # Accumulate gradients to simulate larger batches
    warmup_steps = 5,                    # Number of steps to gradually increase learning rate
    max_steps = 10,                      # Total training steps (kept low for this example)
    learning_rate = 5e-5,                # The step size for weight updates
    fp16 = not torch.cuda.is_bf16_supported(), # Use float16 if bfloat16 is unavailable
    bf16 = torch.cuda.is_bf16_supported(),    # Use bfloat16 for better stability on newer GPUs
    logging_steps = 1,                   # Log progress every single step
    optim = "adamw_8bit",                # Use 8-bit Adam optimizer to save VRAM
    output_dir = "outputs",              # Directory to save model checkpoints
)

# --- STEP 4: The DPO Trainer ---
# The DPOTrainer orchestrates the mathematical comparison between chosen and rejected.
dpo_trainer = DPOTrainer(
    model = model,                       # Our Unsloth-optimized LoRA model
    ref_model = None,                    # For LoRA, we don't need a separate ref_model; 
                                         # the trainer uses the base model automatically.
    args = training_args,                # Our training configuration
    beta = 0.1,                          # The KL divergence penalty (the 'strength' of DPO)
    train_dataset = dataset,             # Our preference dataset
    tokenizer = tokenizer,               # The tokenizer for formatting
    max_prompt_length = 256,             # Max length of the prompt
    max_length = 512,                    # Max length of the (prompt + response)
)

# --- STEP 5: Execution ---
# Start the training process.
dpo_trainer.train()

# Save the fine-tuned LoRA adapters
model.save_pretrained_merged("dpo_model", tokenizer, save_method = "merged_16bit")

print("DPO Training Complete!")

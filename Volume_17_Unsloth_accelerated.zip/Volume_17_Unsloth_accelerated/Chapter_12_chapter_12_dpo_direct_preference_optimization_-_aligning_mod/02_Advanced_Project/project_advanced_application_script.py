
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import torch
from unsloth import FastLanguageModel
from datasets import Dataset
from trl import DPOTrainer
from transformers import TrainingArguments

# 1. Configuration and Hyperparameters
max_seq_length = 2048
dtype = None # None for auto detection
load_in_4bit = True # Use 4bit quantization to save VRAM

# 2. Load Model and Tokenizer via Unsloth
# Unsloth's FastLanguageModel significantly reduces memory usage during DPO
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name = "unsloth/llama-3-8b-bnb-4bit",
    max_seq_length = max_seq_length,
    dtype = dtype,
    load_in_4bit = load_in_4bit,
)

# 3. Add LoRA Adapters for Efficient Fine-Tuning
# We use LoRA to ensure we only train a small fraction of parameters
model = FastLanguageModel.get_peft_model(
    model,
    r = 16, 
    target_modules = ["q_proj", "k_proj", "v_proj", "o_proj",
                      "gate_proj", "up_proj", "down_proj",],
    lora_alpha = 16,
    lora_dropout = 0, 
    bias = "none",    
    use_gradient_checkpointing = "unsloth", # Optimized checkpointing
    random_state = 3407,
)

# 4. Construct the Preference Dataset
# In a real scenario, this would be loaded from a JSONL file
# The dataset must contain 'prompt', 'chosen', and 'rejected' columns
data = {
    "prompt": [
        "A customer is angry because their transaction was declined.",
        "A user asks for a complex explanation of inflation.",
        "A client is asking for a refund on a subscription."
    ],
    "chosen": [
        "I completely understand your frustration. Let's look into why this happened together.",
        "Inflation is a gradual increase in prices, which means your money buys less over time.",
        "I can certainly help you with that refund request. Let me check your account details."
    ],
    "rejected": [
        "Transaction declined. Error code 403. Contact your bank.",
        "Inflation is when prices go up. It is a macroeconomic phenomenon.",
        "Refunds are subject to the terms of service. Please wait."
    ]
}
dataset = Dataset.from_dict(data)

# 5. Define the DPO Trainer
# DPO removes the need for a separate Reward Model, saving massive VRAM
dpo_trainer = DPOTrainer(
    model = model,
    ref_model = None, # Unsloth handles the reference model internally via LoRA
    args = TrainingArguments(
        per_device_train_batch_size = 2,
        gradient_accumulation_steps = 4,
        warmup_steps = 5,
        max_steps = 60, # Small steps for demonstration
        learning_rate = 5e-5,
        fp16 = not torch.cuda.is_bf16_supported(),
        bf16 = torch.cuda.is_bf16_supported(),
        logging_steps = 1,
        optim = "adamw_8bit",
        weight_decay = 0.01,
        lr_scheduler_type = "linear",
        seed = 3407,
        output_dir = "outputs",
    ),
    beta = 0.1, # The temperature parameter for KL divergence
    train_dataset = dataset,
    tokenizer = tokenizer,
    max_length = max_seq_length,
    max_prompt_length = max_seq_length // 2,
)

# 6. Execute the Alignment Process
print("Starting DPO Alignment...")
dpo_trainer.train()

# 7. Save the Aligned Model
model.save_pretrained("persona_aligned_model")
tokenizer.save_pretrained("persona_aligned_model")
print("Alignment Complete. Model saved to 'persona_aligned_model'.")

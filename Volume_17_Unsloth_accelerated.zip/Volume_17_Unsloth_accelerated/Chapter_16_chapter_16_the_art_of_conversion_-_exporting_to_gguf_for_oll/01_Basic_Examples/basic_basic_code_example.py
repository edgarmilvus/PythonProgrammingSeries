
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Import the necessary modules for file system interaction and Unsloth capabilities
import os
from unsloth import FastLanguageModel

def perform_gguf_conversion(model, tokenizer, export_dir, quantization_type="q4_k_m"):
    """
    A standard function to trigger the GGUF export process.
    
    Args:
        model: The fine-tuned Unsloth model object.
        tokenizer: The tokenizer associated with the model.
        export_dir: The directory where the GGUF file will be saved.
        quantization_type: The bit-depth/method used for compression.
    """
    
    # Print a status message to the console to track progress
    print(f"Initiating conversion to {quantization_type} format...")

    # The primary Unsloth method to perform the heavy lifting of conversion
    # This function handles weight conversion, quantization, and file packaging
    model.save_pretrained_gguf(
        export_dir, 
        tokenizer, 
        quantization_method = quantization_type
    )

    # Use an assignment operator to store the result of a path check
    # This uses a boolean check to see if the directory exists after conversion
    is_directory_ready = os.path.exists(export_dir)

    # Conditional logic to provide feedback based on the boolean result
    if is_directory_ready:
        print(f"Success! Your GGUF model is located in: {export_dir}")
    else:
        print("Warning: Conversion completed, but the directory was not found.")

# --- Simulation of the environment for the 'Hello World' example ---
# In a real production script, 'model' and 'tokenizer' are loaded via 
# FastLanguageModel.from_pretrained() before this function is called.

class MockModel:
    """A mock class to simulate the Unsloth model object's behavior."""
    def save_pretrained_gguf(self, path, tokenizer, quantization_method):
        # Simulate the creation of a directory and a file
        if not os.path.exists(path):
            os.makedirs(path)
        with open(os.path.join(path, "model.gguf"), "w") as f:
            f.write("MOCK_GGUF_DATA")

class MockTokenizer:
    """A mock class to simulate the tokenizer object."""
    pass

# Main execution block
if __name__ == "__main__":
    # Assigning mock objects to variables using the assignment operator (=)
    my_model = MockModel()
    my_tokenizer = MockTokenizer()
    
    # Setting configuration parameters
    target_folder = "exported_model_output"
    chosen_quant = "q4_k_m"

    # Executing the conversion function
    perform_gguf_conversion(
        model=my_model, 
        tokenizer=my_tokenizer, 
        export_dir=target_folder, 
        quantization_type=chosen_quant
    )


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

def get_recommendation(params, vram, use_case, context):
    """
    Logic engine to recommend quantization based on VRAM and task.
    """
    # 1. Calculate Base Model Size (Assume 1B params = 2GB for FP16)
    base_size = params * 2.0
    
    # 2. Calculate Context Overhead (Assume 4096 context adds ~1GB)
    # Scaling factor: (context / 4096) * 1GB
    context_overhead = (context / 4096) * 1.0
    
    total_vram_needed = base_size + context_overhead
    
    # 3. Decision Tree Logic
    # Case: Total VRAM needed is way beyond available VRAM
    if vram < (base_size * 0.5):
        return "Q2_K", f"Extreme compression required. Your VRAM ({vram}GB) is less than 50% of the base FP16 size ({base_size}GB)."

    # Case: VRAM is abundant and task is Reasoning (High precision needed)
    if vram > total_vram_needed * 1.5 and use_case.lower() == "reasoning":
        return "Q8_0", "VRAM is abundant and reasoning requires high fidelity."

    # Case: VRAM is abundant and task is Creative (Medium precision)
    if vram > total_vram_needed * 1.2 and use_case.lower() == "creative":
        return "Q5_K_M", "VRAM is abundant and creative tasks benefit from balanced precision."

    # Case: VRAM is tight but can fit Q4
    # We check if VRAM can cover the Q4 estimate (approx 0.6 * base_size)
    if vram >= (base_size * 0.6):
        return "Q4_K_M", "VRAM is limited; Q4 provides the best balance for your hardware."

    # Default fallback
    return "Q2_K", "Insufficient VRAM for standard quantization levels."

def main():
    print("Welcome to the Unsloth Quantization Advisor!")
    print("(Type 'exit' at any prompt to quit)")
    
    while True:
        try:
            raw_params = input("\nEnter model parameters in Billions (e.g., 7, 13, 70): ").lower()
            if raw_params == 'exit': break
            params = float(raw_params)

            raw_vram = input("How much VRAM (in GB) is available on your GPU?: ").lower()
            if raw_vram == 'exit': break
            vram = float(raw_vram)

            use_case = input("What is the primary use case? (Reasoning/Chat/Creative): ").lower()
            if use_case == 'exit': break

            raw_context = input("What is your expected context length? (e.g., 2048, 4096): ").lower()
            if raw_context == 'exit': break
            context = int(raw_context)

            # Get recommendation
            rec, reason = get_recommendation(params, vram, use_case, context)

            print(f"\n>>> RECOMMENDATION: {rec}")
            print(f">>> REASON: {reason}")
            
        except ValueError:
            print("Invalid input. Please enter numeric values where required.")
        except Exception as e:
            print(f"An unexpected error occurred: {e}")

if __name__ == "__main__":
    main()

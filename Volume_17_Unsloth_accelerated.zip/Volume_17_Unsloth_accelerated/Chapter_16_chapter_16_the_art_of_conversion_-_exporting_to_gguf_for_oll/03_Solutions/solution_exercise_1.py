
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

def calculate_requirements(params, bit_depth):
    """
    Calculates estimated size in GB and VRAM required.
    Formula: (Params * Bits) / 8 bits per byte / 1e9 for GB conversion.
    """
    # Convert parameters to GB based on bit depth
    # Using 1e9 for decimal GB as is standard in storage marketing
    size_gb = (params * bit_depth) / 8 / 1e9
    # VRAM requirement includes a 1.2x safety buffer for KV cache/activations
    vram_needed_gb = size_gb * 1.2
    return size_gb, vram_needed_gb

def main():
    print("--- Quantization Requirement Simulator ---")
    
    try:
        # Input: Total parameters (e.g., 7000000000 for 7B)
        params = int(input("Enter total parameter count (e.g., 7000000000): "))
        # Input: Available System RAM in GB
        user_ram = float(input("Enter available system RAM (GB): "))
    except ValueError:
        print("Error: Please enter valid numeric values.")
        return

    # Define quantization specs: {Level: Effective Bits}
    quant_specs = {
        "Q4_K_M": 4.5,
        "Q5_K_M": 5.5,
        "Q8_0": 8.0,
        "FP16": 16.0
    }

    # Calculate metrics for each level
    results = []
    for level, bits in quant_specs.items():
        size, vram = calculate_requirements(params, bits)
        results.append({
            "level": level,
            "size": size,
            "vram": vram
        })

    # Use List Comprehension to generate Status strings
    # Logic: Fits if VRAM <= RAM; Requires Swap if VRAM is within 20% of RAM; else Insufficient
    statuses = [
        "Fits" if r["vram"] <= user_ram else 
        "Requires Swap" if r["vram"] <= (user_ram * 1.2) else 
        "Insufficient Memory" 
        for r in results
    ]

    # Output Generation: Formatted Table
    print(f"\n{'Level':<10} | {'Size (GB)':<10} | {'VRAM Needed (GB)':<18} | {'Status'}")
    print("-" * 60)
    for i in range(len(results)):
        r = results[i]
        print(f"{r['level']:<10} | {r['size']:<10.2f} | {r['vram']:<18.2f} | {statuses[i]}")

if __name__ == "__main__":
    main()

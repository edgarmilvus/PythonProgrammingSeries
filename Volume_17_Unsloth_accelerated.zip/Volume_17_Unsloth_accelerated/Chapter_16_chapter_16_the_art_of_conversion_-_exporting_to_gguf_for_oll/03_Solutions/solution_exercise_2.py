
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Mock metadata database
model_metadata_registry = [
    {"name": "Llama-3-8B-Q4", "architecture": "llama", "vocab_size": 128000, "quantization_type": "Q4_K_M", "tensor_count": 32},
    {"name": "Mistral-7B-Broken", "architecture": "mistral", "vocab_size": "large", "quantization_type": "Q8_0", "tensor_count": 28},
    {"name": "Falcon-40B-Missing", "architecture": "falcon", "quantization_type": "F16", "tensor_count": 45},
    {"name": "Gemma-2B-WrongType", "architecture": 123, "vocab_size": 256000, "quantization_type": "Q4_K_M", "tensor_count": "many"},
    {"name": "Phi-3-Mini", "architecture": "phi3", "vocab_size": 32000, "quantization_type": "Q5_K_M", "tensor_count": 22},
    {"name": "Bad-Quant-Model", "architecture": "llama", "vocab_size": 32000, "quantization_type": "Q2_K", "tensor_count": 10}
]

def audit_metadata(metadata, level):
    """
    Validates metadata keys and types.
    Returns a string status: [PASS] or [FAIL: <Reason>]
    """
    valid_quants = ["Q4_K_M", "Q5_K_M", "Q8_0", "F16"]
    
    # Basic Check: Architecture
    arch = metadata.get("architecture")
    if not isinstance(arch, str):
        return f"[FAIL: Invalid Architecture]"
    
    if level == "Basic":
        return "[PASS]"

    # Full Checks
    # 1. Vocab Size
    vocab = metadata.get("vocab_size")
    if not isinstance(vocab, int) or vocab <= 0:
        return f"[FAIL: Invalid Vocab Size]"

    # 2. Quantization Type
    quant = metadata.get("quantization_type")
    if quant not in valid_quants:
        return f"[FAIL: Unsupported Quantization ({quant})]"

    # 3. Tensor Count
    tensors = metadata.get("tensor_count")
    if not isinstance(tensors, int):
        return f"[FAIL: Invalid Tensor Count]"

    return "[PASS]"

def main():
    print("--- GGUF Metadata Integrity Auditor ---")
    audit_level = input("Enter Audit Level (Basic/Full): ").strip().capitalize()
    
    if audit_level not in ["Basic", "Full"]:
        print("Invalid level. Defaulting to Basic.")
        audit_level = "Basic"

    # Use List Comprehension to generate the audit report
    audit_report = [f"{m['name']}: {audit_metadata(m, audit_level)}" for m in model_metadata_registry]

    print("\n--- Final Audit Report ---")
    for entry in audit_report:
        print(entry)

if __name__ == "__main__":
    main()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

def orchestrate_deployment(file_list, target_mode):
    # 1. Filter the list to only include .gguf files using list comprehension
    gguf_files = [f for f in file_list if f.lower().endswith(".gguf")]
    
    if not gguf_files:
        print("No valid GGUF files found to organize.")
        return

    # 2. Determine destinations and simulate movement
    print(f"\n--- Starting Orchestration (Mode: {target_mode}) ---")
    
    for file in gguf_files:
        # Determine quantization folder based on filename pattern
        # We check for 'q4', 'q5', or 'q8' (case-insensitive)
        file_lower = file.lower()
        
        if "q4" in file_lower:
            dest = "Q4_Deploy"
        elif "q5" in file_lower:
            dest = "Q5_Deploy"
        elif "q8" in file_lower:
            dest = "Q8_Deploy"
        else:
            dest = "Uncategorized_GGUF"

        if target_mode == "1":
            # LM Studio Mode: Just organize by quantization
            print(f"[ACTION] Moving '{file}' to './deploy/{dest}/'")
        elif target_mode == "2":
            # Ollama Mode: Grouping implies adding a Modelfile (simulated)
            print(f"[ACTION] Bundling '{file}' with Modelfile into './ollama/{dest}/'")
        else:
            print(f"[ERROR] Unknown target mode.")
            break

def main():
    # Mock file system
    current_files = [
        "unsloth_model_q4_k_m.gguf", 
        "unsloth_model_q8_0.gguf", 
        "mistral_q5_k_m.gguf", 
        "notes.txt", 
        "training_log.py",
        "unknown_format.bin"
    ]
    
    print("--- Deployment Orchestrator ---")
    print("1. LM Studio (Grouped by Quantization)")
    print("2. Ollama (Full Bundle)")
    
    choice = input("Select deployment target (1/2): ")
    
    # Map choice to a readable name for the logs
    mode_name = "LM Studio" if choice == "1" else "Ollama"
    
    orchestrate_deployment(current_files, choice)

if __name__ == "__main__":
    main()

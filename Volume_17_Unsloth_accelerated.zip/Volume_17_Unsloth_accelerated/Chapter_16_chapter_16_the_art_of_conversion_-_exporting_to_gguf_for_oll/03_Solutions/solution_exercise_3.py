
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os

def export_to_gguf(model_name, target_path):
    """
    Simulates the Unsloth export process.
    """
    print(f"--- Exporting {model_name} to {target_path} ---")
    # Ensure directory exists in simulation
    if not os.path.exists(target_path):
        os.makedirs(target_path)
    
    filename = f"{model_name}.gguf"
    return filename

def generate_modelfile(gguf_filename, system_prompt, temperature):
    """
    Constructs and writes the Ollama Modelfile.
    """
    # Constructing the Modelfile content using f-strings
    modelfile_content = (
        f"FROM ./{gguf_filename}\n"
        f"PARAMETER temperature {temperature}\n"
        f"SYSTEM \"{system_prompt}\"\n"
    )
    
    try:
        with open("Modelfile", "w") as f:
            f.write(modelfile_content)
        print("Successfully created 'Modelfile'.")
    except IOError as e:
        print(f"Error writing Modelfile: {e}")

def main():
    model_name = input("Enter model name for export: ").strip()
    if not model_name:
        model_name = "default_model"
        
    export_path = "./exports/"
    
    # 1. Run the simulated export
    final_gguf = export_to_gguf(model_name, export_path)
    
    # 2. Get deployment parameters from user
    sys_prompt = input("Enter System Prompt (or press Enter for default): ").strip()
    if not sys_prompt:
        sys_prompt = "You are a helpful AI assistant."
        
    temp_input = input("Enter Temperature (e.g., 0.7): ").strip()
    try:
        temperature = float(temp_input)
    except ValueError:
        print("Invalid temperature. Defaulting to 0.7.")
        temperature = 0.7
    
    # 3. Generate the Modelfile
    generate_modelfile(final_gguf, sys_prompt, temperature)
    
    print(f"\nDeployment package ready for {model_name}!")
    print(f"Files in directory: {final_gguf}, Modelfile")

if __name__ == "__main__":
    main()

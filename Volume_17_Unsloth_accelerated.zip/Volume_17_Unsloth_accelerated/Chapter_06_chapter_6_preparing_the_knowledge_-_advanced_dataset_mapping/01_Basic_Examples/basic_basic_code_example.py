
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import os
from datasets import Dataset

# 1. Define the raw data structure (Simulating a messy real-world dataset)
# In a real scenario, this might be loaded from a JSON or CSV file.
raw_data = [
    {
        "instruction": "Explain the concept of photosynthesis.",
        "input": "",
        "output": "Photosynthesis is the process used by plants to convert light energy into chemical energy."
    },
    {
        "instruction": "Solve the following math problem.",
        "input": "What is 15 multiplied by 4?",
        "output": "15 multiplied by 4 is 60."
    },
    {
        "instruction": "Summarize the text.",
        "input": "The quick brown fox jumps over the lazy dog.",
        "output": "A fast fox leaps over a sleepy dog."
    }
]

# 2. Define the prompt template function
# We apply the Principle of Least Astonishment (POLA) by ensuring this function 
# does exactly what its name implies: it maps a single example to a template.
def alpaca_format_mapping(example):
    """
    Converts a raw dictionary into a single formatted string following the Alpaca template.
    This follows the DRY (Don't Repeat Yourself) principle by centralizing the 
    template logic in one place.
    """
    # We use f-strings to construct the prompt. This is efficient and readable.
    # The structure follows the standard Alpaca instruction-tuning format.
    prompt = (
        f"Below is an instruction that describes a task, paired with an input that provides further context. "
        f"Write a response that appropriately completes the request.\n\n"
        f"### Instruction:\n{example['instruction']}\n\n"
        f"### Input:\n{example['input']}\n\n"
        f"### Response:\n{example['output']}"
    )
    
    # We return a dictionary containing the new 'text' column.
    # This is required by the Hugging Face 'map' function.
    return {"text": prompt}

# 3. Load the data into a Hugging Face Dataset object
# The 'datasets' library is the industry standard for handling large-scale ML data.
dataset = Dataset.from_list(raw_data)

# 4. Apply the mapping function to the entire dataset
# The .map() method iterates through every row. 
# We use 'remove_columns' to drop the old 'instruction', 'input', and 'output' 
# columns, leaving us only with the clean, formatted 'text' column.
formatted_dataset = dataset.map(
    alpaca_format_mapping, 
    remove_columns=dataset.column_names
)

# 5. Verification: Print the first formatted entry to ensure it looks correct.
print("--- Formatted Example Output ---")
print(formatted_dataset[0]['text'])

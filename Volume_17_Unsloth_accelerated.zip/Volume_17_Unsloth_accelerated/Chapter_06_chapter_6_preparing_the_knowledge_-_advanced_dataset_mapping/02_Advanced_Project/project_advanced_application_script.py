
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import json
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Dict, Any, Optional

# Configure logging for production traceability
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

# --- CONFIGURATION VIA ENVIRONMENT VARIABLES ---
# We use environment variables to allow the same script to run in different 
# CI/CD pipelines (e.g., Dev vs. Prod) without changing the code.
MAX_SEQ_LENGTH = int(os.getenv("UNSLOTH_MAX_SEQ_LENGTH", 2048))
PROMPT_FORMAT = os.getenv("UNSLOTH_PROMPT_FORMAT", "chatml")  # Options: chatml, alpaca
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

@dataclass
class Message:
    """Represents a single conversational turn in a structured format."""
    role: str
    content: str

class PromptTemplate(ABC):
    """
    Abstract Base Class (ABC) implementing the Strategy Pattern.
    This ensures DRY (Don't Repeat Yourself) by providing a consistent 
    interface for all future template implementations.
    """
    @abstractmethod
    def format_conversation(self, messages: List[Message]) -> str:
        """Transforms a list of Message objects into a single formatted string."""
        pass

class ChatMLTemplate(PromptTemplate):
    """Implementation of the OpenAI ChatML format: <|im_start|>role\ncontent<|im_end|>"""
    def format_conversation(self, messages: List[Message]) -> str:
        formatted_str = ""
        for msg in messages:
            formatted_str += f"<|im_start|>{msg.role}\n{msg.content}<|im_end|>\n"
        return formatted_str

class AlpacaTemplate(PromptTemplate):
    """Implementation of the Alpaca instruction format."""
    def format_conversation(self, messages: List[Message]) -> str:
        if not messages:
            return ""
        # Alpaca typically expects an instruction and a response
        instruction = messages[0].content
        response = messages[1].content if len(messages) > 1 else ""
        return f"### Instruction:\n{instruction}\n\n### Response:\n{response}"

class DatasetMapper:
    """
    The core engine responsible for iterating through raw data and 
    applying the chosen template strategy.
    """
    def __init__(self, template: PromptTemplate):
        self.template = template

    def map_raw_data(self, raw_data: List[Dict[str, Any]]) -> List[str]:
        """Converts raw JSON-like dictionaries into formatted strings."""
        mapped_strings = []
        for entry in raw_data:
            try:
                # Convert raw dicts to structured Message dataclasses
                messages = [Message(role=m['role'], content=m['content']) 
                            for m in entry['messages']]
                formatted_text = self.template.format_conversation(messages)
                mapped_strings.append(formatted_text)
            except KeyError as e:
                logging.error(f"Data integrity error: Missing key {e} in entry {entry}")
                continue
        return mapped_strings

class SequencePacker:
    """
    Implements Sequence Packing to optimize GPU throughput.
    Instead of padding, we concatenate sequences to fill the MAX_SEQ_LENGTH.
    """
    def __init__(self, max_length: int, eos_token: str = "<|endoftext|>"):
        self.max_length = max_length
        self.eos_token = eos_token

    def pack_sequences(self, formatted_texts: List[str]) -> List[str]:
        """
        Simulates the packing logic used in Unsloth.
        In a real implementation, this would operate on token IDs, not strings.
        """
        packed_buffer = []
        current_sequence = ""

        for text in formatted_texts:
            # Append EOS token to ensure the model learns when to stop
            text_to_add = text + self.eos_token
            
            # Check if adding this text exceeds the max length
            if len(current_sequence) + len(text_to_add) <= self.max_length:
                current_sequence += text_to_add
            else:
                # If the buffer is full, save it and start a new one
                if current_sequence:
                    packed_buffer.append(current_sequence)
                current_sequence = text_to_add
        
        # Add the final remaining buffer
        if current_sequence:
            packed_buffer.append(current_sequence)
            
        logging.info(f"Packing complete. Reduced {len(formatted_texts)} sequences into {len(packed_buffer)} packed blocks.")
        return packed_buffer

def main():
    # Mocking a real-world dataset of customer support logs
    raw_dataset = [
        {"messages": [{"role": "user", "content": "How do I reset my password?"}, 
                      {"role": "assistant", "content": "Click 'Forgot Password' on the login page."}]},
        {"messages": [{"role": "user", "content": "Is my data encrypted?"}, 
                      {"role": "assistant", "content": "Yes, we use AES-256 encryption."}]},
        {"messages": [{"role": "user", "content": "Can I cancel my subscription?"}, 
                      {"role": "assistant", "content": "Yes, via the billing dashboard."}]},
        {"messages": [{"role": "user", "content": "What is the refund policy?"}, 
                      {"role": "assistant", "content": "Full refunds within 30 days."}]},
        {"messages": [{"role": "user", "content": "Help, I am locked out!"}, 
                      {"role": "assistant", "content": "Please contact support@example.com."}]}
    ]

    # 1. Strategy Selection based on Environment Variables
    if PROMPT_FORMAT.lower() == "chatml":
        template_strategy = ChatMLTemplate()
    elif PROMPT_FORMAT.lower() == "alpaca":
        template_strategy = AlpacaTemplate()
    else:
        raise ValueError(f"Unsupported template format: {PROMPT_FORMAT}")

    # 2. Execute Mapping Phase
    mapper = DatasetMapper(template_strategy)
    formatted_data = mapper.map_raw_data(raw_dataset)

    # 3. Execute Packing Phase
    packer = SequencePacker(max_length=MAX_SEQ_LENGTH)
    final_packed_dataset = packer.pack_sequences(formatted_data)

    # 4. Output results for inspection
    print("\n--- FINAL PACKED DATASET PREVIEW ---")
    for i, block in enumerate(final_packed_dataset):
        print(f"\n[PACKED BLOCK {i}]\n{block}")

if __name__ == "__main__":
    main()

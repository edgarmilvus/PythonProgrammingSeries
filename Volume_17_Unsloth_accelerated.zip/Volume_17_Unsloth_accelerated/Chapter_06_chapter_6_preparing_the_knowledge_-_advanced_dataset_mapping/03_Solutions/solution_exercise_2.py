
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import torch

class SequencePackingCollator:
    """
    A custom collator that packs multiple short sequences into a single 
    max_seq_length sequence to maximize GPU throughput.
    """
    def __init__(self, max_seq_length, tokenizer):
        self.max_seq_length = max_seq_length
        self.tokenizer = tokenizer

    def __call__(self, features):
        """
        Args:
            features (list[dict]): A list of dictionaries, each containing 
                                   'input_ids' and 'attention_mask'.
        Returns:
            dict: A dictionary of packed tensors.
        """
        all_input_ids = []
        all_attention_masks = []

        # 1. Flatten all sequences, ensuring EOS is appended
        for feature in features:
            ids = feature['input_ids']
            mask = feature['attention_mask']
            
            # Append EOS token to every individual example
            eos_token_id = self.tokenizer.eos_token_id
            ids = ids + [eos_token_id]
            mask = mask + [1]
            
            all_input_ids.extend(ids)
            all_attention_masks.extend(mask)

        # 2. Determine how many full blocks we can create
        total_len = len(all_input_ids)
        num_blocks = total_len // self.max_seq_length
        
        # If the total length is less than max_seq_length, we only have 1 block
        effective_num_blocks = max(1, num_blocks)
        
        # 3. Construct the packed tensors
        packed_input_ids = []
        packed_attention_masks = []
        
        for i in range(effective_num_blocks):
            start_idx = i * self.max_seq_length
            end_idx = start_idx + self.max_seq_length
            
            # Extract the chunk
            chunk_ids = all_input_ids[start_idx:end_idx]
            chunk_mask = all_attention_masks[start_idx:end_idx]
            
            # Handle the last block if it's shorter than max_seq_length (Padding)
            padding_len = self.max_seq_length - len(chunk_ids)
            if padding_len > 0:
                chunk_ids += [self.tokenizer.pad_token_id] * padding_len
                chunk_mask += [0] * padding_len
                
            packed_input_ids.append(chunk_ids)
            packed_attention_masks.append(chunk_mask)

        # Convert to tensors
        input_ids_tensor = torch.tensor(packed_input_ids, dtype=torch.long)
        attention_mask_tensor = torch.tensor(packed_attention_masks, dtype=torch.long)
        
        # 4. Create Labels: Copy input_ids and set padding tokens to -100
        labels_tensor = input_ids_tensor.clone()
        labels_tensor[input_ids_tensor == self.tokenizer.pad_token_id] = -100

        return {
            "input_ids": input_ids_tensor,
            "attention_mask": attention_mask_tensor,
            "labels": labels_tensor
        }

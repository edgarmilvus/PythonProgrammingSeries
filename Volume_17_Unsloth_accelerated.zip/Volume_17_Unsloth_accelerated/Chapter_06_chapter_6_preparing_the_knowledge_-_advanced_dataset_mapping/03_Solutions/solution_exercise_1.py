
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

def map_to_chatml(example):
    """
    Transform a single conversation example into a ChatML formatted string.
    """
    conversations = example.get("conversations", [])
    if not conversations:
        example["text"] = ""
        return example

    role_map = {
        "human": "user",
        "gpt": "assistant",
        "system": "system"
    }
    
    formatted_messages = []
    system_message = None

    # First pass: Extract system message and validate roles
    for msg in conversations:
        role = msg.get("from")
        value = msg.get("value", "")

        if role not in role_map:
            print(f"WARNING: Unrecognized role '{role}' encountered. Skipping message.")
            continue
        
        if not value or not value.strip():
            continue

        mapped_role = role_map[role]
        
        # Store system message separately to ensure it's first
        if mapped_role == "system":
            system_message = f"<|im_start|>system\n{value}<|im_end|>"
        else:
            formatted_messages.append(f"<|im_start|>{mapped_role}\n{value}<|im_end|>")

    # Construct final string: System message first, then others
    output_parts = []
    if system_message:
        output_parts.append(system_message)
    
    output_parts.extend(formatted_messages)
    
    # Join with newlines to separate turns, ensuring no trailing whitespace issues
    example["text"] = "\n".join(output_parts)
    
    return example

# Example usage with a mock dataset
if __name__ == "__main__":
    from datasets import Dataset
    
    raw_data = [
        {
            "conversations": [
                {"from": "system", "value": "You are a helpful assistant."},
                {"from": "human", "value": "Hello!"},
                {"from": "gpt", "value": "Hi there! How can I help?"}
            ]
        },
        {
            "conversations": [
                {"from": "human", "value": "What is 2+2?"},
                {"from": "unknown_role", "value": "This should be skipped."},
                {"from": "gpt", "value": "It is 4."}
            ]
        }
    ]
    
    dataset = Dataset.from_list(raw_data)
    mapped_dataset = dataset.map(map_to_chatml)
    print(mapped_dataset[0]["text"])
    print(mapped_dataset[1]["text"])

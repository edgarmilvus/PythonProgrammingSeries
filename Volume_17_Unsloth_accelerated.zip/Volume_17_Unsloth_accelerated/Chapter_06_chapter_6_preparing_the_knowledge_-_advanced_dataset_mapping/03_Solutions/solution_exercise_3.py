
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

def rag_aware_sharegpt_mapper(example):
    """
    Refactor the standard ShareGPT-to-Alpaca mapper to include 
    RAG-based context injection.
    """
    conversations = example.get("conversations", [])
    if not conversations:
        example["text"] = ""
        return example

    # 1. Extract instruction (first user message) and response (last assistant message)
    instruction = ""
    response = ""

    for msg in conversations:
        if msg.get("from") == "human" and not instruction:
            instruction = msg.get("value", "")
        if msg.get("from") == "gpt":
            response = msg.get("value", "")

    # 2. Check for 'context' in example and validate it's not just whitespace
    context = example.get("context", "").strip()

    # 3. Apply conditional template logic
    if context:
        # RAG-Aware Template
        text_template = (
            "Below is an excerpt from a knowledge base:\n"
            "---\n"
            "{context_content}\n"
            "---\n"
            "Using the context above, answer the following:\n"
            "{instruction_content}\n\n"
            "Response:\n"
            "{response_content}"
        )
        example["text"] = text_template.format(
            context_content=context,
            instruction_content=instruction,
            response_content=response
        )
    else:
        # Standard Alpaca Template
        alpaca_template = "Instruction: {instruction}\n\nResponse: {response}"
        example["text"] = alpaca_template.format(
            instruction=instruction,
            response=response
        )

    return example

# Test Case
if __name__ == "__main__":
    # Test with Context
    ex1 = {
        "conversations": [
            {"from": "human", "value": "What is the capital of France?"},
            {"from": "gpt", "value": "The capital is Paris."}
        ],
        "context": "France is a country in Europe. Its capital is Paris."
    }
    
    # Test without Context
    ex2 = {
        "conversations": [
            {"from": "human", "value": "Who wrote Romeo and Juliet?"},
            {"from": "gpt", "value": "William Shakespeare."}
        ]
    }
    
    # Test with Empty/Whitespace Context
    ex3 = {
        "conversations": [{"from": "human", "value": "Hi"}, {"from": "gpt", "value": "Hello"}],
        "context": "   "
    }

    print("--- RAG Case ---")
    print(rag_aware_sharegpt_mapper(ex1)["text"])
    print("\n--- Standard Case ---")
    print(rag_aware_sharegpt_mapper(ex2)["text"])
    print("\n--- Empty Context Case ---")
    print(rag_aware_sharegpt_mapper(ex3)["text"])

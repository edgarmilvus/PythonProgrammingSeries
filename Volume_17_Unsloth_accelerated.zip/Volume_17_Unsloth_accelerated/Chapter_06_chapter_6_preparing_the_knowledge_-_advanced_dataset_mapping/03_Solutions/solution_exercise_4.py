
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
import torch

class DynamicPaddingCollator:
    """
    A collator that implements dynamic padding to optimize VRAM usage,
    incorporating an environment-variable-based safety cap.
    """
    def __init__(self, tokenizer):
        self.tokenizer = tokenizer
        # Retrieve safety cap from environment variables
        try:
            self.safety_cap = int(os.environ.get("MAX_BATCH_PAD_LIMIT", 2048))
        except ValueError:
            self.safety_cap = 2048

    def __call__(self, features):
        """
        Args:
            features (list[dict]): List of tokenized dictionaries.
        Returns:
            dict: Tensors padded to the max length of the current batch.
        """
        # 1. Calculate the max length in the current batch
        current_batch_max = max(len(f['input_ids']) for f in features)
        
        # 2. Apply the safety cap (Truncate if batch max exceeds limit)
        target_len = min(current_batch_max, self.safety_cap)
        
        batch_input_ids = []
        batch_attention_masks = []
        batch_labels = []

        for f in features:
            # Truncate if necessary
            ids = f['input_ids'][:target_len]
            mask = f['attention_mask'][:target_len]
            label = f.get('labels', ids[:target_len])[:target_len] # Handle if labels exist

            # 3. Padding Implementation
            padding_len = target_len - len(ids)
            
            # Pad input_ids and attention_mask
            ids += [self.tokenizer.pad_token_id] * padding_len
            mask += [0] * padding_len
            
            # 4. Label Alignment: Pad labels with -100
            # If the original label was shorter than target_len, pad with -100
            label_padding_len = target_len - len(label)
            label += [-100] * label_padding_len

            batch_input_ids.append(ids)
            batch_attention_masks.append(mask)
            batch_labels.append(label)

        # 5. Tensor Conversion
        return {
            "input_ids": torch.tensor(batch_input_ids, dtype=torch.long),
            "attention_mask": torch.tensor(batch_attention_masks, dtype=torch.long),
            "labels": torch.tensor(batch_labels, dtype=torch.long)
        }

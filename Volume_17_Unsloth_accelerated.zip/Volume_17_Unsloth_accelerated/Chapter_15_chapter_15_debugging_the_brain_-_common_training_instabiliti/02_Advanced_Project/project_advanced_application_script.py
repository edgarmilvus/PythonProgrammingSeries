
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import logging
import time

# Configure logging to simulate a real training telemetry system
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - [TRAINING_WATCHDOG] - %(levelname)s - %(message)s'
)

class TrainingStabilityMonitor:
    """
    A diagnostic watchdog designed to intercept training loops and 
    prevent catastrophic failures caused by loss spikes and NaNs.
    """
    def __init__(self, loss_threshold=5.0, lr_cooldown_factor=0.5, spike_window=5):
        # The multiplier used to detect a 'spike' relative to moving average
        self.loss_threshold = loss_threshold
        # The factor by which to reduce LR when a spike is detected
        self.lr_cooldown_factor = lr_cooldown_factor
        # Number of steps to track for moving average
        self.spike_window = spike_window
        
        self.loss_history = []
        self.is_training_active = True

    def _get_moving_average(self):
        """Calculates the average loss over the recent window."""
        if not self.loss_history:
            return 0.0
        return sum(self.loss_history[-self.spike_window:]) / len(self.loss_history[-self.spike_window:])

    def monitor_step(self, current_loss, optimizer):
        """
        Analyzes the current training step for instabilities.
        Uses EAFP (Easier to Ask for Forgiveness than Permission) to handle 
        numerical errors during the check.
        """
        try:
            # EAFP: We attempt to process the loss directly. 
            # If the loss is a non-numeric type or mathematically invalid, 
            # the subsequent checks or numpy operations will raise an exception.
            
            # 1. Check for NaN or Inf (The 'Death' Condition)
            if not np.isfinite(current_loss):
                raise ValueError(f"CRITICAL: Non-finite loss detected: {current_loss}")

            # 2. Check for Loss Spikes (The 'Warning' Condition)
            avg_loss = self._get_moving_average()
            if avg_loss > 0 and current_loss > (avg_loss * self.loss_threshold):
                self._handle_spike(current_loss, optimizer)
            
            # Update history for moving average
            self.loss_history.append(current_loss)
            if len(self.loss_history) > self.spike_window:
                self.loss_history.pop(0)
            
            return True # Step is safe

        except ValueError as e:
            # Handle the NaN/Inf case: Stop training immediately
            logging.error(f"Training Halted: {e}")
            self.is_training_active = False
            return False
        except Exception as e:
            # Handle unexpected telemetry errors
            logging.warning(f"Telemetry error: {e}. Continuing with caution.")
            return True

    def _handle_spike(self, loss, optimizer):
        """Applies emergency mitigation: Learning Rate Cooldown."""
        old_lr = optimizer.get_lr()
        new_lr = old_lr * self.lr_cooldown_factor
        
        logging.warning(
            f"LOSS SPIKE DETECTED! Current Loss: {loss:.4f} | "
            f"Reducing LR from {old_lr:.2e} to {new_lr:.2e}"
        )
        
        # Apply the new learning rate to the optimizer
        optimizer.set_lr(new_lr)

class MockOptimizer:
    """Simulates a standard LLM optimizer (like AdamW)."""
    def __init__(self, lr=1e-4):
        self.lr = lr

    def get_lr(self):
        return self.lr

    def set_lr(self, new_lr):
        self.lr = new_lr

# --- SIMULATION OF A REAL-WORLD TRAINING RUN ---

def run_training_simulation():
    # Initialize components
    optimizer = MockOptimizer(lr=1e-4)
    watchdog = TrainingStabilityMonitor(loss_threshold=3.0, lr_cooldown_factor=0.5)
    
    # Simulated loss values: Normal descent -> Spike -> Recovery -> NaN crash
    simulated_losses = [
        0.85, 0.82, 0.80, 0.78, 0.77, # Normal
        2.50,                         # A sudden spike!
        0.75, 0.74, 0.73,             # Recovery after LR reduction
        0.72, 0.71,                   # Stable
        np.nan                        # The inevitable crash
    ]

    logging.info("Starting LLM Fine-Tuning Simulation...")
    
    for step, loss in enumerate(simulated_losses):
        if not watchdog.is_training_active:
            logging.error(f"Step {step}: Training loop aborted by watchdog.")
            break
            
        logging.info(f"Step {step}: Loss = {loss:.4f}")
        
        # The Watchdog intercepts the step
        success = watchdog.monitor_step(loss, optimizer)
        
        if not success:
            # In a real scenario, we would trigger a checkpoint save here
            logging.info("Attempting to recover last valid checkpoint...")
            break
            
        # Simulate computational delay
        time.sleep(0.1)

    logging.info("Simulation Complete.")

if __name__ == "__main__":
    run_training_simulation()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import math
import random

# We use a class to encapsulate the training logic, adhering to DRY principles
# by keeping the state (weights, history) and behavior (stepping) together.
class TrainingSimulator:
    """
    A simulator to demonstrate training instabilities, 
    loss spikes, and basic mitigation strategies.
    """

    def __init__(self, learning_rate=0.1, clip_threshold=1.0):
        # The learning rate determines the size of our 'steps' down the mountain.
        self.lr = learning_rate
        # The clipping threshold prevents 'exploding gradients' by capping step size.
        self.clip_threshold = clip_threshold
        # Our 'model weight' starts at a value of 10.0.
        self.weight = 10.0
        # A list to track the history of our loss for debugging purposes.
        self.loss_history = []

    def calculate_loss(self, current_weight):
        """
        Simulates a loss function. In a real LLM, this would be 
        the Cross-Entropy loss of the next-token prediction.
        We use a simple quadratic function: Loss = (weight - 2)^2.
        The minimum is at weight = 2.
        """
        return (current_weight - 2) ** 2

    def get_gradient(self, current_weight):
        """
        Simulates the gradient (the derivative of the loss).
        The derivative of (w - 2)^2 is 2 * (w - 2).
        """
        return 2 * (current_weight - 2)

    def perform_step(self, use_clipping=True, simulate_spike=False):
        """
        Performs a single optimization step.
        """
        # 1. Calculate the current loss
        current_loss = self.calculate_loss(self.weight)
        self.loss_history.append(current_loss)

        # 2. Calculate the gradient
        gradient = self.get_gradient(self.weight)

        # 3. Simulate a 'Loss Spike' or 'Exploding Gradient'
        # This represents a sudden, massive change in the landscape.
        if simulate_spike:
            gradient = 1000.0  # A massive, unrealistic gradient

        # 4. Apply Gradient Clipping (Mitigation Strategy)
        # This ensures the gradient never exceeds our predefined threshold.
        if use_clipping:
            # We use the DRY principle by applying this logic consistently.
            if abs(gradient) > self.clip_threshold:
                # Clamp the gradient to the threshold.
                gradient = self.clip_threshold if gradient > 0 else -self.clip_threshold

        # 5. Update the weight using the learning rate
        # We use EAFP (Easier to Ask for Forgiveness than Permission) 
        # by attempting the update and catching mathematical errors.
        try:
            # Standard SGD update rule: weight = weight - (lr * gradient)
            update_amount = self.lr * gradient
            self.weight -= update_amount

            # Check if the update resulted in a non-finite number (NaN/Inf)
            if not math.isfinite(self.weight):
                raise ValueError("Numerical instability detected: Weight is NaN or Inf.")
                
        except ValueError as e:
            # In a real training loop, this is where you would trigger a checkpoint rollback.
            print(f"!!! CRITICAL ERROR: {e} !!!")
            return False

        return True

def run_training_demo():
    """
    The main execution block that demonstrates both a failing and a stable run.
    """
    print("--- Scenario 1: Training with Exploding Gradients (No Clipping) ---")
    # Initialize simulator without clipping.
    unstable_sim = TrainingSimulator(learning_rate=0.1, clip_threshold=1.0)
    
    for i in range(5):
        # On step 3, we simulate a massive gradient spike.
        spike = True if i == 3 else False
        success = unstable_sim.perform_step(use_clipping=False, simulate_spike=spike)
        
        if not success:
            print(f"Step {i}: Training aborted due to instability.")
            break
        else:
            print(f"Step {i}: Weight = {unstable_sim.weight:.4f}, Loss = {unstable_sim.calculate_loss(unstable_sim.weight):.4f}")

    print("\n--- Scenario 2: Training with Gradient Clipping (Stable) ---")
    # Initialize simulator WITH clipping enabled.
    stable_sim = TrainingSimulator(learning_rate=0.1, clip_threshold=1.0)
    
    for i in range(5):
        # On step 3, we still simulate the spike, but clipping should catch it.
        spike = True if i == 3 else False
        success = stable_sim.perform_step(use_clipping=True, simulate_spike=spike)
        
        if not success:
            print(f"Step {i}: Training aborted.")
            break
        else:
            print(f"Step {i}: Weight = {stable_sim.weight:.4f}, Loss = {stable_sim.calculate_loss(stable_sim.weight):.4f}")

if __name__ == "__main__":
    run_training_demo()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import time
import random
import numpy as np
from collections import deque

def metric_stream():
    step = 0
    while True:
        step += 1
        loss = 2.0 / (step + 1) + random.uniform(-0.05, 0.05)
        grad_norm = random.uniform(0.1, 0.5)
        lr = 5e-5 * (0.5 ** (step / 100))
        
        if step == 15:
            grad_norm = 10.0 # Anomaly
        if step == 30:
            loss = 5.0 # Divergence
        if step == 45:
            loss = float('nan') # Critical Failure
            
        yield {'step': step, 'loss': loss, 'grad_norm': grad_norm, 'lr': lr}
        time.sleep(0.1)

class LiveMonitor:
    def __init__(self, window_size=10):
        self.window_size = window_size
        self.loss_history = deque(maxlen=window_size)
        self.grad_history = deque(maxlen=window_size)
        self.loss_moving_avgs = []
        self.divergence_counter = 0

    def update(self, metrics):
        loss = metrics['loss']
        grad = metrics['grad_norm']
        
        # 1. Update histories
        self.loss_history.append(loss)
        self.grad_history.append(grad)
        
        # 2. Calculate stats
        avg_loss = np.mean(self.loss_history)
        self.loss_moving_avgs.append(avg_loss)
        
        avg_grad = np.mean(self.grad_history)
        std_grad = np.std(self.grad_history)
        
        # 3. Anomaly Detection (5-sigma)
        anomaly_alert = ""
        if len(self.grad_history) >= 2 and grad > avg_grad + (5 * std_grad):
            anomaly_alert = "!!! ANOMALY DETECTED (GRADIENT SPIKE) !!!"

        # 4. Divergence Warning (Loss increasing for 5 steps)
        divergence_alert = ""
        if len(self.loss_moving_avgs) >= 5:
            recent_avgs = self.loss_moving_avgs[-5:]
            if all(x < y for x, y in zip(recent_avgs, recent_avgs[1:])):
                divergence_alert = "!!! DIVERGENCE WARNING (LOSS INCREASING) !!!"

        # 5. Print Dashboard
        print(f"\033[H\033[J") # Clear console
        print(f"--- LIVE TRAINING DASHBOARD ---")
        print(f"Step: {metrics['step']} | Loss: {loss:.4f} | Grad Norm: {grad:.4f} | LR: {metrics['lr']:.2e}")
        print(f"Moving Avg Loss: {avg_loss:.4f}")
        print(f"-------------------------------")
        if anomaly_alert: print(f"\033[91m{anomaly_alert}\033[0m")
        if divergence_alert: print(f"\033[93m{divergence_alert}\033[0m")

# Execution
monitor = LiveMonitor()
print("Starting Live Monitor... Press Ctrl+C to stop.")

try:
    for data in metric_stream():
        if np.isnan(data['loss']):
            print("\n\033[91m[!!!] CRITICAL: NaN DETECTED. EMERGENCY STOP INITIATED.\033[0m")
            break
            
        monitor.update(data)
except KeyboardInterrupt:
    print("\nMonitor stopped by user.")

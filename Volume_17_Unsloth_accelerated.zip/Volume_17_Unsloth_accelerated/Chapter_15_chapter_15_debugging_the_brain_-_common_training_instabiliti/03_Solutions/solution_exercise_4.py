
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np

class TrainerCallback:
    def on_before_optimizer_step(self, gradients, optimizer):
        pass

class StabilityGuardrailCallback(TrainerCallback):
    def __init__(self, safety_threshold, lr_reduction_factor=0.5):
        self.safety_threshold = safety_threshold
        self.lr_reduction_factor = lr_reduction_factor
        self.consecutive_skips = 0
        self.should_skip_step = False

    def on_before_optimizer_step(self, gradients, optimizer):
        grad_norm = np.linalg.norm(gradients)
        
        if grad_norm > self.safety_threshold:
            self.should_skip_step = True
            self.consecutive_skips += 1
            
            if self.consecutive_skips >= 3:
                raise RuntimeError("Training unstable: Too many skips")
            
            # Reduce LR to attempt recovery
            optimizer.reduce_lr(self.lr_reduction_factor)
        else:
            # Reset state if training stabilizes
            self.should_skip_step = False
            self.consecutive_skips = 0

class MockOptimizer:
    def __init__(self, lr):
        self.lr = lr
    def step(self):
        print("Optimizer step executed.")
    def reduce_lr(self, factor):
        self.lr *= factor
        print(f"Learning rate reduced to {self.lr:.6e}")

def run_training_loop(trainer_steps, callback, optimizer):
    print("Starting training loop...")
    for step in range(trainer_steps):
        # Simulate gradient generation
        if step == 5:
            grads = np.array([100.0, 200.0]) # A massive spike
        elif step == 6:
            grads = np.array([150.0, 300.0]) # Another spike
        elif step == 7:
            grads = np.array([200.0, 400.0]) # Third spike -> Should trigger Hard Stop
        else:
            grads = np.random.normal(0, 0.1, 2)

        # Callback interception
        callback.on_before_optimizer_step(grads, optimizer)

        if callback.should_skip_step:
            print(f"Step {step}: [WARNING] Batch skipped due to instability.")
        else:
            optimizer.step()
            
    print("Training completed successfully.")

# Setup
optimizer = MockOptimizer(lr=5e-5)
guardrail = StabilityGuardrailCallback(safety_threshold=50.0)

# Execution
try:
    run_training_loop(10, guardrail, optimizer)
except RuntimeError as e:
    print(f"CRITICAL FAILURE: {e}")

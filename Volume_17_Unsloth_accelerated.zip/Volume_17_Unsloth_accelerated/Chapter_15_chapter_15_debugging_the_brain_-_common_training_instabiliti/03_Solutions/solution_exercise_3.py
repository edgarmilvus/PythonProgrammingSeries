
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np

def detect_spikes(loss_history, threshold_multiplier=3.0, window_size=5):
    """
    Identifies steps where loss spikes occur using a moving average threshold.
    """
    spike_indices = []
    for i in range(window_size, len(loss_history)):
        # Calculate moving average of the previous 'window_size' steps
        moving_avg = np.mean(loss_history[i-window_size:i])
        if loss_history[i] > moving_avg * threshold_multiplier:
            spike_indices.append(i)
    return spike_indices

def diagnose_data_cause(spike_indices, dataset_metadata):
    """
    Correlates spike indices with dataset characteristics using statistical deviations.
    """
    if not spike_indices:
        return "No spikes detected."

    # Extract characteristics of the spiked batches
    spike_entropy = dataset_metadata['entropy'][spike_indices]
    spike_lengths = dataset_metadata['lengths'][spike_indices]
    
    # Calculate population statistics
    pop_entropy_mean = np.mean(dataset_metadata['entropy'])
    pop_entropy_std = np.std(dataset_metadata['entropy'])
    pop_len_mean = np.mean(dataset_metadata['lengths'])
    pop_len_std = np.std(dataset_metadata['lengths'])
    
    # Check for statistical significance (e.g., > 2 standard deviations)
    if np.mean(spike_entropy) > pop_entropy_mean + (2 * pop_entropy_std):
        return "Entropy Outlier (Likely nonsense/corrupted data)"
    elif np.mean(spike_lengths) > pop_len_mean + (2 * pop_len_std):
        return "Length Outlier (Likely context window overflow)"
    else:
        return "Clean Data (Issue likely optimizer or precision related)"

# Simulated Data
loss_history = np.array([1.5, 1.4, 1.45, 1.42, 1.39, 1.41, 1.38, 1.4, 1.37, 1.39, 
                         1.4, 1.38, 1.39, 1.41, 1.37, 1.38, 1.39, 1.4, 1.38, 1.37,
                         1.38, 1.39, 1.4, 1.38, 1.37, 1.38, 1.39, 1.4, 1.38, 1.37,
                         1.38, 1.39, 1.4, 1.38, 1.37, 1.38, 1.39, 1.4, 1.38, 1.37,
                         15.0, # THE SPIKE
                         1.38, 1.39, 1.4, 1.38, 1.37, 1.38, 1.39, 1.4, 1.38, 1.37])

np.random.seed(10)
metadata = {
    'batch_indices': list(range(50)),
    'entropy': np.random.normal(2.0, 0.2, 50),
    'lengths': np.random.normal(512, 50, 50)
}

# Inject a "bad" batch at index 40 (high entropy)
metadata['entropy'][40] = 8.5 

# Execution
spikes = detect_spikes(loss_history)
cause = diagnose_data_cause(spikes, metadata)

print(f"Detected Spike Indices: {spikes}")
print(f"Diagnosed Cause: {cause}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np

def analyze_precision_failure(log_data):
    """
    Analyzes training logs to find the onset of numerical instability.
    """
    for entry in log_data:
        # Check for NaN loss or gradient norm exceeding the 10,000 threshold
        if np.isnan(entry['loss']) or entry['grad_norm'] > 10000:
            return entry['step']
    return None

def simulate_overflow(gradients, precision='fp16'):
    """
    Simulates whether a set of gradients would overflow in a given precision.
    """
    if precision.lower() == 'fp16':
        # FP16 Max value is ~65504
        fp16_max = 65504
        return np.any(np.abs(gradients) > fp16_max)
    elif precision.lower() == 'bf16':
        # BF16 has a much larger dynamic range (similar to FP32)
        # For simulation, we assume it won't overflow in this context
        return False
    return False

def recommend_precision_strategy(max_grad_observed, current_precision):
    """
    Provides a strategy based on observed numerical behavior.
    """
    if max_grad_observed > 65504:
        return "Switch to BF16 (Gradient exceeds FP16 capacity)"
    elif max_grad_observed > 1000:
        return "Implement Gradient Clipping (High variance detected)"
    else:
        return "Maintain FP16"

# Test Data
simulated_logs = [
    {'step': 198, 'loss': 1.82, 'grad_norm': 0.45},
    {'step': 199, 'loss': 1.80, 'grad_norm': 0.55},
    {'step': 200, 'loss': 1.78, 'grad_norm': 0.60},
    {'step': 201, 'loss': float('nan'), 'grad_norm': 65536.0}, # Potential Overflow
    {'step': 202, 'loss': float('nan'), 'grad_norm': float('inf')}
]

# Execution
instability_step = analyze_precision_failure(simulated_logs)
print(f"Instability detected at step: {instability_step}")

# Simulation of the specific failure event
failure_grads = np.array([10.0, 70000.0, -5.0])
overflow_fp16 = simulate_overflow(failure_grads, 'fp16')
overflow_bf16 = simulate_overflow(failure_grads, 'bf16')

print(f"FP16 Overflow: {overflow_fp16}")
print(f"BF16 Overflow: {overflow_bf16}")

# Recommendation
recommendation = recommend_precision_strategy(65536.0, 'fp16')
print(f"Recommendation: {recommendation}")

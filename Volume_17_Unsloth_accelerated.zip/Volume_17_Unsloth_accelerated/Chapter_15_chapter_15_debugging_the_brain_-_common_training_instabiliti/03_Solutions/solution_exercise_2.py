
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np

class WarmupScheduler:
    def __init__(self, target_lr, warmup_steps, initial_lr=1e-7):
        self.target_lr = target_lr
        self.warmup_steps = warmup_steps
        self.initial_lr = initial_lr

    def get_lr(self, current_step):
        if current_step <= self.warmup_steps:
            # Linear interpolation from initial_lr to target_lr
            alpha = current_step / self.warmup_steps
            return self.initial_lr + alpha * (self.target_lr - self.initial_lr)
        return self.target_lr

def apply_gradient_clipping(gradients, max_norm):
    """
    Scales gradients if their L2 norm exceeds max_norm.
    """
    current_norm = np.linalg.norm(gradients)
    if current_norm > max_norm:
        # Scale the entire vector by (max_norm / current_norm)
        return gradients * (max_norm / current_norm)
    return gradients

# Simulation Setup
np.random.seed(42)
TARGET_LR = 5e-5
WARMUP_STEPS = 20
MAX_GRAD_NORM = 1.0

scheduler = WarmupScheduler(TARGET_LR, WARMUP_STEPS)

print(f"{'Step':<10} | {'LR':<12} | {'Raw Norm':<12} | {'Clipped Norm':<12}")
print("-" * 55)

for step in range(1, 51):
    # Simulate a gradient with occasional spikes
    raw_gradients = np.random.normal(0, 0.1, size=(1000,))
    if step % 15 == 0:
        raw_gradients *= 50.0  # Simulate a spike
    
    # 1. Get current LR
    current_lr = scheduler.get_lr(step)
    
    # 2. Calculate raw norm
    raw_norm = np.linalg.norm(raw_gradients)
    
    # 3. Apply clipping
    clipped_gradients = apply_gradient_clipping(raw_gradients, MAX_GRAD_NORM)
    
    # 4. Calculate clipped norm
    clipped_norm = np.linalg.norm(clipped_gradients)
    
    print(f"{step:<10} | {current_lr:<12.6e} | {raw_norm:<12.4f} | {clipped_norm:<12.4f}")

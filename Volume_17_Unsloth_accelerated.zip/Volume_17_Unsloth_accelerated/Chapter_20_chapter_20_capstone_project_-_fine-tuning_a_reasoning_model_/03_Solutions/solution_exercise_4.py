
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

class ReasoningStep:
    def __init__(self, step_id, assertion, confidence):
        self.step_id = step_id
        self.assertion = assertion
        self.confidence = confidence

class AgenticComplianceEngine:
    def generate_reasoning_trace(self, transaction_data):
        """
        MODIFICATION 1: Injects an Action/Tool Call if confidence is low.
        """
        trace =[]
        origin = transaction_data.get("origin", "Unknown")
        amount = transaction_data.get("amount", 0)

        # Step 1
        conf_1 = 0.95 if origin == "SafeZone" else 0.40 # Simulated uncertainty
        trace.append(ReasoningStep(1, f"Evaluating origin: {origin}", conf_1))
        
        if conf_1 < 0.50:
            # Inject Agentic Action
            trace.append(ReasoningStep(99, "[ACTION_REQUIRED: escalate_to_human(1)]", 1.0))
            return trace # Halt reasoning early

        # Step 2 (Only reached if Step 1 was confident)
        conf_2 = 0.99
        trace.append(ReasoningStep(2, f"Evaluating amount: {amount}", conf_2))
        
        return trace

    def final_compliance_decision(self, trace):
        """
        MODIFICATION 2: Scans for action flags before executing boolean logic.
        """
        # Scan for escalation flag
        for step in trace:
            if "ACTION_REQUIRED" in step.assertion:
                return "ESCALATED"

        # Standard boolean logic falls through if no escalation is found
        # (Simplified for demonstration)
        return "APPROVED"

# --- Execution ---
if __name__ == "__main__":
    engine = AgenticComplianceEngine()
    
    # Safe transaction -> Should approve
    tx_safe = {"origin": "SafeZone", "amount": 100}
    trace_safe = engine.generate_reasoning_trace(tx_safe)
    print(f"Safe Tx Decision: {engine.final_compliance_decision(trace_safe)}")
    
    # Risky transaction -> Should escalate due to low confidence in origin
    tx_risky = {"origin": "UnknownZone", "amount": 100}
    trace_risky = engine.generate_reasoning_trace(tx_risky)
    print(f"Risky Tx Decision: {engine.final_compliance_decision(trace_risky)}")
    print(f"Risky Tx Trace: {[s.assertion for s in trace_risky]}")
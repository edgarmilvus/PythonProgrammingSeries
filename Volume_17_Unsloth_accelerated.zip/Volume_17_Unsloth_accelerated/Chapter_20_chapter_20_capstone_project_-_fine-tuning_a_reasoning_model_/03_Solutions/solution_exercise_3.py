
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import re

def parse_generation(raw_text: str) -> dict:
    """Extracts thought and answer blocks using robust regex."""
    thought_match = re.search(r"<thought>(.*?)</thought>", raw_text, re.DOTALL)
    answer_match = re.search(r"<answer>(.*?)</answer>", raw_text, re.DOTALL)
    
    return {
        "thought": thought_match.group(1).strip() if thought_match else "",
        "answer": answer_match.group(1).strip() if answer_match else ""
    }

def evaluate_reasoning_drift(raw_text: str) -> dict:
    """Calculates density and provides a heuristic audit."""
    parsed = parse_generation(raw_text)
    
    thought_len = len(parsed["thought"])
    answer_len = len(parsed["answer"])
    
    # EAFP: Prevent division by zero if answer is empty
    if answer_len == 0:
        return {"status": "FAIL: Missing Answer Block", "density": 0.0}
        
    density_ratio = thought_len / answer_len
    
    # Heuristic Audit Logic
    if density_ratio < 2.0:
        status = "WARNING: Shallow Reasoning"
    elif density_ratio > 50.0:
        status = "WARNING: Rambling/Looping"
    else:
        status = "PASS"
        
    return {
        "status": status,
        "density_ratio": round(density_ratio, 2),
        "thought": parsed["thought"][:30] + "...", # Truncated for display
        "answer": parsed["answer"]
    }

# --- Execution ---
if __name__ == "__main__":
    # Scenario A: Good Density
    good_text = "<thought> I need to calculate 10 * 5. 10 * 5 = 50. </thought>\n<answer> 50 </answer>"
    
    # Scenario B: Shallow Reasoning
    shallow_text = "<thought> Math. </thought>\n<answer> 50 </answer>"
    
    # Scenario C: Rambling
    ramble_text = "<thought> " + ("Thinking... " * 100) + "</thought>\n<answer> 50 </answer>"
    
    print(evaluate_reasoning_drift(good_text))
    print(evaluate_reasoning_drift(shallow_text))
    print(evaluate_reasoning_drift(ramble_text))

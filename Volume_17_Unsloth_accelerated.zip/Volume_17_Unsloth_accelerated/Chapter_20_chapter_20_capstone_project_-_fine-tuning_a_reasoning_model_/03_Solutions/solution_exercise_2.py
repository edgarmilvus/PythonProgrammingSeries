
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import torch
from transformers import AutoTokenizer

def create_loss_weight_mask(input_ids: torch.Tensor, tokenizer) -> torch.Tensor:
    """
    Creates a mask that applies a 1.0x weight to thoughts and a 5.0x weight to the answer.
    """
    # 1. Initialize mask with 1.0 (standard loss weight)
    # Ensure mask matches input_ids shape and is on the same device
    loss_mask = torch.ones_like(input_ids, dtype=torch.float32)
    
    # 2. Identify the token ID for the <answer> tag
    # Note: Depending on the tokenizer, tags might be tokenized into multiple subwords.
    # We find the sequence of tokens representing "<answer>"
    answer_tag_tokens = tokenizer.encode("<answer>", add_special_tokens=False)
    tag_length = len(answer_tag_tokens)
    
    # EAFP Approach: We iterate to find the sub-sequence match
    # Since input_ids is a 1D tensor for this exercise:
    answer_start_idx = -1
    for i in range(len(input_ids) - tag_length + 1):
        if torch.equal(input_ids[i:i+tag_length], torch.tensor(answer_tag_tokens, device=input_ids.device)):
            answer_start_idx = i
            break
            
    # 3. Apply Segmented Weighting
    if answer_start_idx != -1:
        # Boost the loss weight for all tokens after the <answer> tag
        # This penalizes the model 5x more if it gets the final verdict wrong
        loss_mask[answer_start_idx + tag_length:] = 5.0
    else:
        print("Warning: <answer> tag not found in sequence. Defaulting to 1.0x weight.")
        
    return loss_mask

# --- Execution ---
if __name__ == "__main__":
    # We use a standard tokenizer for simulation
    tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
    
    # Simulated model output
    text = "<thought> 2 plus 2 is 4 </thought> <answer> 4 </answer>"
    input_ids = tokenizer(text, return_tensors="pt")["input_ids"][0]
    
    mask = create_loss_weight_mask(input_ids, tokenizer)
    
    print("Tokens:", tokenizer.convert_ids_to_tokens(input_ids))
    print("Mask Weights:", mask.tolist())
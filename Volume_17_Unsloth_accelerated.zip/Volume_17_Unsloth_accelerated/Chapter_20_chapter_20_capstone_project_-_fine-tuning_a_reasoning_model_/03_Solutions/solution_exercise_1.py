
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================
import json
import re

def simulate_teacher_call(question, answer):
    """
    Simulates a high-reasoning Teacher Model generating a thought trace.
    """
    # Simulated logical decomposition
    thought_trace = (
        f"Step 1: Analyze the key entities in the question: '{question[:20]}...'\n"
        f"Step 2: Identify the core legal principles that apply here.\n"
        f"Step 3: Conclude that the logical outcome is {answer}."
    )
    
    # Construct the strictly tagged output
    return f"<thought>\n{thought_trace}\n</thought>\n<answer>\n{answer}\n</answer>"

def validate_reasoning_structure(text):
    """
    Validates that the output contains exactly one thought block, 
    one answer block, and that thought precedes answer.
    """
    # re.DOTALL ensures the '.' character matches newlines as well
    thought_match = list(re.finditer(r"<thought>.*?</thought>", text, re.DOTALL))
    answer_match = list(re.finditer(r"<answer>.*?</answer>", text, re.DOTALL))
    
    # Check 1: Exactly one of each tag
    if len(thought_match) != 1 or len(answer_match) != 1:
        return False
        
    # Check 2: Thought must appear before Answer
    if thought_match[0].end() > answer_match[0].start():
        return False
        
    return True

def generate_reasoning_dataset(raw_data):
    """Orchestrates the data pipeline."""
    processed_dataset =[]
    stats = {"success": 0, "failed_validation": 0}
    
    for entry in raw_data:
        question = entry.get("question", "")
        answer = entry.get("answer", "")
        
        # 1. Simulate the teacher
        teacher_output = simulate_teacher_call(question, answer)
        
        # 2. Strict Validation (The Gatekeeper)
        if validate_reasoning_structure(teacher_output):
            processed_dataset.append({
                "instruction": "Analyze the legal scenario and provide a verdict.",
                "input": question,
                "output": teacher_output
            })
            stats["success"] += 1
        else:
            stats["failed_validation"] += 1
            
    return processed_dataset, stats

# --- Execution ---
if __name__ == "__main__":
    raw_legal_data =[
        {"question": "Does a contract signed under duress remain valid?", "answer": "No, it is voidable."},
        {"question": "Is negligence required for a strict liability claim?", "answer": "No, negligence is not required."}
    ]

    dataset, stats = generate_reasoning_dataset(raw_legal_data)
    
    # Save to JSONL
    with open("reasoning_train.jsonl", "w") as f:
        for item in dataset:
            f.write(json.dumps(item) + "\n")
            
    print(f"Pipeline Complete. Stats: {stats}")
    print(f"Sample Output:\n{dataset[0]['output']}")
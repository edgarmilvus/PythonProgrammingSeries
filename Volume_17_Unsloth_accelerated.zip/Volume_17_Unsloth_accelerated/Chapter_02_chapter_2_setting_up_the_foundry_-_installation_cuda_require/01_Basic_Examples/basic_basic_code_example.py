
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Import the core Unsloth optimization engine
from unsloth import FastLanguageModel
# Import the fundamental tensor library for deep learning
import torch

# --- Configuration Phase ---
# Define the maximum number of tokens the model can process in one go
max_seq_length = 2048 
# Set the data type; None allows Unsloth to auto-detect the best type (e.g., Float16 or Bfloat16)
dtype = None 
# Enable 4-bit quantization to drastically reduce VRAM usage
load_in_4bit = True 

# --- Model Loading Phase ---
# Load the pre-trained model and the tokenizer using Unsloth's optimized loader
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name = "unsloth/llama-3-8b-bnb-4bit", # The specific model identifier
    max_seq_length = max_seq_length,           # The context window limit
    dtype = dtype,                             # The numerical precision
    load_in_4bit = load_in_4bit,               # The quantization setting
)

# --- Optimization Phase ---
# Prepare the model specifically for fast inference (forward pass optimization)
FastLanguageModel.for_inference(model)

# --- Execution Phase ---
# Convert a text prompt into a format the model understands (tensors)
# We move the resulting tensors directly to the GPU (cuda)
inputs = tokenizer(
    ["Explain the concept of Triton kernels in one sentence."],
    return_tensors = "pt"
).to("cuda")

# Generate a response from the model
outputs = model.generate(**inputs, max_new_tokens = 64)

# Decode the numerical output back into human-readable text
decoded_output = tokenizer.batch_decode(outputs)[0]

# Print the final result to the console
print(decoded_output)

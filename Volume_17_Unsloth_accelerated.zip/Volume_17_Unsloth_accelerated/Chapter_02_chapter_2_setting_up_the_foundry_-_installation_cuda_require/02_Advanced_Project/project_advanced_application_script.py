
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import sys
import torch
import triton
import unsloth
from flask import Flask, url_for

# We simulate a Flask environment to demonstrate the use of Application Context
# and URL construction for reporting, as required in advanced deployment scripts.
app = Flask(__name__)

class FoundryApplicationContext:
    """
    Mimics the 'Application Context' by holding application-wide 
    configuration and state for the hardware validation process.
    """
    def __init__(self, target_gpu_type: str):
        self.config = {
            "target_gpu": target_gpu_type,
            "required_cuda": "12.1",
            "min_triton_version": "2.1.0",
            "unsloth_optimized": True
        }
        self.status_report = []

    def log_status(self, message: str):
        # Using the built-in print function to output real-time logs to the console
        print(f"[FOUNDRY LOG]: {message}")
        self.status_report.append(message)

class HardwareValidator:
    """
    The core engine responsible for verifying the CUDA, Triton, 
    and Unsloth integration.
    """
    def __init__(self, context: FoundryApplicationContext):
        self.ctx = context

    def verify_cuda(self):
        # Check if CUDA is available via PyTorch
        cuda_available = torch.cuda.is_available()
        if cuda_available:
            gpu_name = torch.cuda.get_device_name(0)
            self.ctx.log_status(f"CUDA detected: {gpu_name}")
            # Verify if the GPU matches the context's target
            if self.ctx.config["target_gpu"] in gpu_name:
                self.ctx.log_status("Hardware match: SUCCESS")
            else:
                self.ctx.log_status("Hardware mismatch: WARNING")
        else:
            self.ctx.log_status("CUDA NOT FOUND: CRITICAL FAILURE")
        return cuda_available

    def verify_triton(self):
        # Verify Triton version to ensure kernel optimization is possible
        try:
            t_version = triton.__version__
            self.ctx.log_status(f"Triton version: {t_version}")
            # Logic to compare version strings would go here
            return True
        except Exception as e:
            self.ctx.log_status(f"Triton verification failed: {e}")
            return False

    def verify_unsloth(self):
        # Check if Unsloth is correctly integrated with the current environment
        try:
            # Simulating a check for Unsloth's optimized kernels
            import unsloth
            self.ctx.log_status("Unsloth library: INSTALLED")
            return True
        except ImportError:
            self.ctx.log_status("Unsloth library: MISSING")
            return False

def generate_report_endpoint():
    """A dummy view function for demonstrating url_for usage."""
    return "System Health Report"

def run_preflight_check():
    # 1. Initialize the Application Context with specific hardware requirements
    # This pushes the environment settings onto our 'stack'.
    context = FoundryApplicationContext(target_gpu_type="H100")
    context.log_status("Initializing Foundry Pre-flight Check...")

    # 2. Instantiate the Validator with the context
    validator = HardwareValidator(context)

    # 3. Execute the validation sequence
    cuda_ok = validator.verify_cuda()
    triton_ok = validator.verify_triton()
    unsloth_ok = validator.verify_unsloth()

    # 4. Final Assessment
    if cuda_ok and triton_ok and unsloth_ok:
        context.log_status("PRE-FLIGHT CHECK: PASSED. Ready for Unsloth training.")
    else:
        context.log_status("PRE-FLIGHT CHECK: FAILED. Resolve dependencies before starting.")

    # 5. Demonstrate URL generation for a remote monitoring dashboard
    # In a real deployment, this URL would be used by a CI/CD pipeline or monitoring tool.
    with app.app_context():
        report_url = url_for('generate_report_endpoint')
        print(f"\n[SYSTEM] Detailed report available at: {report_url}")
        print(f"[SYSTEM] Summary of checks: {context.status_report}\n")

if __name__ == "__main__":
    # Execute the main validation logic
    run_preflight_check()

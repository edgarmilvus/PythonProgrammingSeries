
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import torch
import sys

# ANSI Color Codes
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
BLUE = "\033[94m"
RESET = "\033[0m"
BOLD = "\033[1m"

class SiliconAuditor:
    def __init__(self, target_params_billions):
        self.target_params = target_params_billions * 1e9
        self.gpu_info = {}

    def audit_hardware(self):
        print(f"{BOLD}--- SILICON AUDIT REPORT ---{RESET}\n")
        
        if not torch.cuda.is_available():
            print(f"{RED}[!] CRITICAL: No CUDA-capable GPU detected.{RESET}")
            sys.exit(1)

        # Metadata Extraction
        self.gpu_info['name'] = torch.cuda.get_device_name(0)
        self.gpu_info['total_vram'] = torch.cuda.get_device_properties(0).total_memory
        self.gpu_info['capability'] = torch.cuda.get_device_capability(0)
        self.gpu_info['driver'] = torch.version.cuda # Approximated via torch build

        print(f"{BLUE}Hardware Metadata:{RESET}")
        print(f"  Model:       {self.gpu_info['name']}")
        print(f"  VRAM Total:  {self.gpu_info['total_vram'] / 1e9:.2f} GB")
        print(f"  Compute Cap: {self.gpu_info['capability'][0]}.{self.gpu_info['capability'][1]}")
        print(f"  CUDA Build:  {self.gpu_info['driver']}\n")

    def classify_tier(self):
        cap = self.gpu_info['capability'][0] + (self.gpu_info['capability'][1] / 10)
        
        print(f"{BLUE}Optimization Tier:{RESET}")
        if cap >= 8.0:
            tier = f"{GREEN}Tier 1 (Ultra) - Full Unsloth Support{RESET}"
        elif cap >= 7.5:
            tier = f"{YELLOW}Tier 2 (High) - Limited Optimization{RESET}"
        else:
            tier = f"{RED}Tier 3 (Legacy) - Not Recommended{RESET}"
        print(f"  Status: {tier}\n")

    def vram_budgeter(self):
        print(f"{BLUE}VRAM Budgeter (Target: {self.target_params/1e9:.1f}B Params):{RESET}")
        
        # Calculations
        # 4-bit: ~0.5 bytes per param | 16-bit: 2 bytes per param
        weights_4bit = self.target_params * 0.5
        weights_16bit = self.target_params * 2.0
        
        # Heuristic: Training overhead (Gradients + Optimizer States) is ~3x weight memory
        overhead_factor = 4.0 
        
        total_req_4bit = weights_4bit * overhead_factor
        total_req_16bit = weights_16bit * overhead_factor
        
        available_vram = self.gpu_info['total_vram']
        safety_buffer = 1.10 # 10% buffer
        
        print(f"  [4-bit Quantization]")
        print(f"    Estimated Req: {total_req_4bit / 1e9:.2f} GB")
        self._print_verdict(total_req_4bit * safety_buffer, available_vram)

        print(f"  [16-bit Precision]")
        print(f"    Estimated Req: {total_req_16bit / 1e9:.2f} GB")
        self._print_verdict(total_req_16bit * safety_buffer, available_vram)

    def _print_verdict(self, required, available):
        if required <= available:
            print(f"    Verdict: {GREEN}PASS{RESET}")
        elif required <= available * 1.2:
            print(f"    Verdict: {YELLOW}WARNING (VRAM Tight){RESET}")
        else:
            print(f"    Verdict: {RED}FAIL (Insufficient VRAM){RESET}")
        print("")

    def triton_readiness(self):
        print(f"{BLUE}Triton Readiness:{RESET}")
        try:
            import triton
            print(f"  Status: {GREEN}Installed (v{triton.__version__}){RESET}")
            # Simple smoke test
            print("  Running Kernel Smoke Test...")
            # (In a real scenario, we'd run a small JIT kernel here)
            print(f"  Result: {GREEN}Ready{RESET}")
        except ImportError:
            print(f"  Status: {RED}Triton NOT FOUND{RESET}")

if __name__ == "__main__":
    # Example: Audit for a 7B parameter model
    auditor = SiliconAuditor(target_params_billions=7)
    auditor.audit_hardware()
    auditor.classify_tier()
    auditor.vram_budgeter()
    auditor.triton_readiness()

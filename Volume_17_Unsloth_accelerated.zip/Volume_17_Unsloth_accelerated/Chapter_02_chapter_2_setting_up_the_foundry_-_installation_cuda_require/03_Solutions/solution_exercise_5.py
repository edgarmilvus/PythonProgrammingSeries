
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import re
import sys

def investigate_conflicts(system_file, env_file):
    print("--- DEPENDENCY CONFLICT INVESTIGATOR ---")
    
    # 1. Parsing logic
    system_data = {}
    env_data = {}

    try:
        with open(system_file, 'r') as f:
            for line in f:
                if ':' in line:
                    k, v = line.split(':', 1)
                    system_data[k.strip()] = v.strip()

        with open(env_file, 'r') as f:
            for line in f:
                if '==' in line:
                    k, v = line.split('==', 1)
                    env_data[k.strip()] = v.strip()
    except FileNotFoundError as e:
        print(f"Error: {e}")
        return

    # 2. Logic Engine: Conflict Detection Matrix
    conflicts = []
    
    # Check CUDA Mismatch
    nvcc_ver = system_data.get("NVCC Version", "")
    torch_ver = env_data.get("torch", "")
    
    # Extract major.minor from NVCC (e.g., 12.2)
    nvcc_match = re.search(r'(\d+\.\d+)', nvcc_ver)
    # Extract cuXXX from torch (e.g., +cu121)
    torch_cu_match = re.search(r'\+cu(\d+)', torch_ver)

    if nvcc_match and torch_cu_match:
        nvcc_val = nvcc_match.group(1)
        torch_cu_val = f"{torch_cu_match.group(1)[0]}.{torch_cu_match.group(1)[1]}"
        
        # Note: +cu121 usually means CUDA 12.1. If NVCC is 12.2, it's a mismatch.
        if nvcc_val != torch_cu_val:
            conflicts.append({
                "type": "CRITICAL MISMATCH",
                "msg": f"The system is running CUDA {nvcc_val}, but PyTorch is compiled for CUDA {torch_cu_val}. This mismatch is the likely cause of the 'invalid device function' error.",
                "fix": f"pip install torch=={torch_ver.split('+')[0]}+cu{nvcc_val.replace('.', '')}"
            })

    # Check Architecture/Triton Alignment (Simulated check)
    if "A100" in system_data.get("GPU", "") and "triton==2.1.0" in env_data.values():
        # In a real scenario, we'd map triton versions to architectures
        conflicts.append({
            "type": "WARNING",
            "msg": "The version of bitsandbytes/triton detected may not be fully optimized for the A100 architecture.",
            "fix": "pip install --upgrade bitsandbytes triton"
        })

    # 3. Output
    if not conflicts:
        print("[+] No obvious conflicts detected.")
    else:
        for c in conflicts:
            print(f"\n{c['type']}: {c['msg']}")
        
        print("\n" + "-"*30)
        choice = input("[S]uggest Fix, [I]gnore, or [E]xit? ").strip().upper()
        
        if choice == 'S':
            print("\n[PROPOSED FIX COMMANDS]:")
            for c in conflicts:
                print(f"  {c['fix']}")
        elif choice == 'E':
            sys.exit(0)
        else:
            print("[*] Proceeding as requested.")

if __name__ == "__main__":
    # Creating dummy files for demonstration purposes
    with open("system_report.txt", "w") as f:
        f.write("OS: Ubuntu 22.04 LTS\nKernel: 5.15.0-generic\nGPU: NVIDIA A100-SXM4-40GB (Compute Capability 8.0)\nCUDA Driver: 12.2\nNVCC Version: 12.2\nPython Version: 3.10.12 (via Conda)")
    
    with open("environment_dump.log", "w") as f:
        f.write("torch==2.1.0+cu121\ntriton==2.1.0\nunsloth==2023.10.1\nbitsandbytes==0.41.1\nxformers==0.0.22.post7\nnumpy==1.24.3\ncuda-python==12.2.0")

    investigate_conflicts("system_report.txt", "environment_dump.log")

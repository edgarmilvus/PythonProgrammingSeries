
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
import time
import shutil
import platform
import traceback
import torch

class TritonKernelSentinel:
    def __init__(self):
        self.cache_dir = os.path.expanduser("~/.triton/cache")
        self.report_file = "triton_debug_report.txt"

    def monitor_cache(self):
        print("[*] Monitoring Triton Cache...")
        if not os.path.exists(self.cache_dir):
            print(f"    -> Cache directory {self.cache_dir} does not exist yet.")
            return

        # Check Writability
        if not os.access(self.cache_dir, os.W_OK):
            print(f"    [!] WARNING: Cache directory is NOT writable. JIT will be slow.")
        
        # Check Size
        total_size = 0
        for dirpath, dirnames, filenames in os.walk(self.cache_dir):
            for f in filenames:
                fp = os.path.join(dirpath, f)
                total_size += os.path.getsize(fp)
        
        print(f"    -> Cache Size: {total_size / 1e6:.2f} MB")
        if total_size > 5 * 1e9:
            print(f"    [!] WARNING: Cache exceeds 5GB. Consider clearing it.")

    def warm_up_test(self):
        print("[*] Running Triton Warm-up Test (Measuring JIT Overhead)...")
        import triton
        import triton.language as tl
        import torch

        # Define a dummy kernel
        @triton.jit
        def dummy_add(x_ptr, y_ptr, out_ptr, n_elements, BLOCK_SIZE: tl.constexpr):
            pid = tl.program_id(0)
            offsets = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
            mask = offsets < n_elements
            x = tl.load(x_ptr + offsets, mask=mask)
            y = tl.load(y_ptr + offsets, mask=mask)
            tl.store(out_ptr + offsets, x + y, mask=mask)

        n = 1024
        x = torch.randn(n, device='cuda')
        y = torch.randn(n, device='cuda')
        out = torch.empty_like(x)
        grid = (1,)

        try:
            # First Call (Compilation)
            start_comp = time.perf_counter()
            dummy_add[grid](x, y, out, n, BLOCK_SIZE=1024)
            torch.cuda.synchronize()
            end_comp = time.perf_counter()
            comp_time = end_comp - start_comp

            # Second Call (Execution)
            start_exec = time.perf_counter()
            dummy_add[grid](x, y, out, n, BLOCK_SIZE=1024)
            torch.cuda.synchronize()
            end_exec = time.perf_counter()
            exec_time = end_exec - start_exec

            print(f"    -> Compilation Time: {comp_time:.4f}s")
            print(f"    -> Execution Time:   {exec_time:.4f}s")
            
            ratio = comp_time / exec_time if exec_time > 0 else float('inf')
            if ratio > 100:
                print(f"    [!] WARNING: High JIT overhead detected (Ratio: {ratio:.1f}x).")
            else:
                print(f"    [+] JIT overhead is within normal parameters.")
                
        except Exception as e:
            self.generate_report(str(e))
            print(f"    [!] Warm-up Test FAILED. Report generated: {self.report_file}")

    def generate_report(self, error_msg):
        import triton
        with open(self.report_file, "w") as f:
            f.write("=== TRITON KERNEL SENTINEL DEBUG REPORT ===\n")
            f.write(f"Timestamp: {time.ctime()}\n")
            f.write(f"OS: {platform.platform()}\n")
            f.write(f"Python: {sys.version}\n")
            f.write(f"Torch: {torch.__version__}\n")
            f.write(f"Triton: {triton.__version__}\n")
            f.write(f"CUDA: {torch.version.cuda}\n")
            f.write(f"TRITON_CACHE_DIR: {os.environ.get('TRITON_CACHE_DIR', 'Default (~/.triton/cache)')}\n")
            f.write("-" * 40 + "\n")
            f.write(f"ERROR MESSAGE:\n{error_msg}\n")
            f.write("-" * 40 + "\n")
            f.write("FULL TRACEBACK:\n")
            f.write(traceback.format_exc())

if __name__ == "__main__":
    sentinel = TritonKernelSentinel()
    sentinel.monitor_cache()
    sentinel.warm_up_test()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import subprocess
import sys
import os
import logging
import traceback
from datetime import datetime

# Configure Error Logging
logging.basicConfig(
    filename='foundry_setup_error.log',
    level=logging.ERROR,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

class UnslothFoundryArchitect:
    def __init__(self, env_name="unsloth_foundry", python_version="3.10"):
        self.env_name = env_name
        self.python_version = python_version
        self.cuda_version = None

    def log_error(self, message):
        print(f"[-] ERROR: {message}")
        logging.error(f"{message}\n{traceback.format_exc()}")

    def run_command(self, command, shell=False):
        """Helper to run subprocess commands safely."""
        try:
            result = subprocess.run(
                command, 
                shell=shell, 
                check=True, 
                capture_output=True, 
                text=True
            )
            return result.stdout.strip()
        except subprocess.CalledProcessError as e:
            raise Exception(f"Command failed: {' '.join(command) if isinstance(command, list) else command}\nError: {e.stderr}")

    def check_pre_requisites(self):
        print("[*] Phase 1: Pre-flight checks...")
        # 1. Check Conda
        if subprocess.run(["which", "conda"], capture_output=True).returncode != 0:
            raise Exception("Conda is not installed or not in PATH.")
        
        # 2. Check GPU Availability (via nvidia-smi)
        try:
            gpu_info = self.run_command(["nvidia-smi"])
            print("[+] NVIDIA GPU detected.")
        except Exception:
            raise Exception("No CUDA-capable GPU detected. Aborting installation.")

    def detect_cuda(self):
        print("[*] Phase 2: Detecting CUDA Toolkit version...")
        try:
            nvcc_out = self.run_command(["nvcc", "--version"])
            # Parsing 'release 12.1,...'
            for line in nvcc_out.split('\n'):
                if "release" in line:
                    self.cuda_version = line.split("release ")[1].split(",")[0]
                    print(f"[+] Detected CUDA version: {self.cuda_version}")
                    return
            raise Exception("Could not parse CUDA version from nvcc.")
        except Exception as e:
            raise Exception(f"CUDA Toolkit detection failed: {e}")

    def create_environment(self):
        print(f"[*] Phase 3: Creating Conda environment '{self.env_name}'...")
        try:
            # Create env
            self.run_command(["conda", "create", "-n", self.env_name, f"python={self.python_version}", "-y"])
            
            # Define PyTorch installation based on CUDA
            # Note: In a real scenario, we'd map 12.1 -> pytorch-cuda=12.1
            cuda_suffix = self.cuda_version.replace(".", "")
            print(f"[*] Installing PyTorch for CUDA {self.cuda_version}...")
            
            # Using conda install for the base layer
            install_cmd = ["conda", "install", "-n", self.env_name, "pytorch", "torchvision", "torchaudio", "pytorch-cuda", self.cuda_version, "-c", "pytorch", "-c", "nvidia", "-y"]
            self.run_command(install_cmd)
            
        except Exception as e:
            print(f"[-] Environment creation failed. Cleaning up...")
            subprocess.run(["conda", "env", "remove", "-n", self.env_name, "-y"])
            raise e

    def install_unsloth_stack(self):
        print("[*] Phase 4: Installing Unsloth optimization stack...")
        # We use 'conda run -n env_name pip' to ensure we install into the correct env
        prefix = ["conda", "run", "-n", self.env_name, "pip", "install"]
        
        try:
            # Order matters to prevent dependency hell
            packages = ["unsloth", "xformers", "bitsandbytes", "triton"]
            for pkg in packages:
                print(f"    -> Installing {pkg}...")
                self.run_command(prefix + [pkg])
        except Exception as e:
            raise Exception(f"Stack installation failed: {e}")

    def verify_installation(self):
        print("[*] Phase 5: Integrity Verification...")
        verify_cmd = ["conda", "run", "-n", self.env_name, "python", "-c", 
                      "import torch; import triton; import unsloth; "
                      "print(f'Torch CUDA: {torch.cuda.is_available()}'); "
                      "print(f'Torch CUDA Ver: {torch.version.cuda}'); "
                      "print(f'Triton Ver: {triton.__version__}'); "
                      "print(f'Unsloth GPU Access: {torch.cuda.is_available()}')"]
        
        try:
            output = self.run_command(verify_cmd)
            print("\n[SUCCESS] Verification Report:")
            print(output)
        except Exception as e:
            raise Exception(f"Verification failed: {e}")

    def orchestrate(self):
        try:
            self.check_pre_requisites()
            self.detect_cuda()
            self.create_environment()
            self.install_unsloth_stack()
            self.verify_installation()
            print("\n[!!!] Foundry Environment is Ready for Deployment.")
        except Exception as e:
            self.log_error(str(e))
            print(f"\n[!] Orchestration failed. See foundry_setup_error.log for details.")
            sys.exit(1)

if __name__ == "__main__":
    architect = UnslothFoundryArchitect()
    architect.orchestrate()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from datasets import Dataset

# 1. Mock Dataset Creation
raw_data = [
    {"instruction": "Explain photosynthesis.", "input": "", "output": "Photosynthesis is the process used by plants..."},
    {"instruction": "Translate the sentence.", "input": "The cat is on the mat.", "output": "Le chat est sur le tapis."},
    {"instruction": "Summarize this text.", "input": "The solar system consists of the Sun and everything bound to it by gravity.", "output": "The Sun and its orbiting bodies form the solar system."}
]

# 2. Template Definition (Alpaca Format)
alpaca_template = """### Instruction:
{}

### Input:
{}

### Response:
{}"""

# 3. The Mapping Function
def formatting_prompts_func(examples):
    instructions = examples["instruction"]
    inputs       = examples["input"]
    outputs      = examples["output"]
    texts = []
    
    # Zip the lists together to iterate through rows
    for instruction, input_text, output in zip(instructions, inputs, outputs):
        # Apply the template to the variables
        text = alpaca_template.format(instruction, input_text, output)
        texts.append(text)
        
    return { "text" : texts, }

# 4. Dataset Integration
dataset = Dataset.from_list(raw_data)

# 5. Application via .map()
dataset = dataset.map(formatting_prompts_func, batched = True)

# 6. Verification
print("--- First Formatted Element ---")
print(dataset[0]["text"])

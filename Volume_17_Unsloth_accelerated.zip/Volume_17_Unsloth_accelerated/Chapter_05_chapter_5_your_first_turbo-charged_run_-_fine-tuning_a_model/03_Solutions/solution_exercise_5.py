
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import json
from unsloth import FastLanguageModel

def interactive_entity_extractor(model, tokenizer):
    # 1. Switch to Inference Mode for speed
    FastLanguageModel.for_inference(model)
    
    print("--- Legal Entity Extractor Active ---")
    print("(Type 'exit' to quit)")

    while True:
        test_paragraph = input("\nEnter text to analyze: ")
        if test_paragraph.lower() == 'exit':
            break

        # 2. The Strict "Extractor" Prompt
        prompt = f"""Extract the following entities from the text: Name, Date, and Location. 
Return the result ONLY as a JSON object. 
Format: {{"name": "...", "date": "...", "location": "..."}}

### Input:
{test_paragraph}

### Response:
"""

        # 3. Inference Loop
        inputs = tokenizer([prompt], return_tensors="pt").to("cuda")
        outputs = model.generate(
            **inputs, 
            max_new_tokens = 128, 
            temperature = 0.1, # Low temperature for high precision/determinism
            use_cache = True
        )
        
        # Decode and isolate the response
        full_output = tokenizer.batch_decode(outputs)[0]
        response_text = full_output.split("### Response:")[1].strip()

        # 4. Parsing Test & Validation Logic
        try:
            # Attempt to parse the string into a Python dictionary
            extracted_data = json.loads(response_text)
            print("\n[SUCCESS] Data parsed!")
            print(f"Result: {extracted_data}")
        except json.JSONDecodeError:
            print("\n[ERROR] Model failed to provide structured output.")
            print(f"Raw Output was: {response_text}")

# To run (assuming model/tokenizer exist):
# interactive_entity_extractor(model, tokenizer)

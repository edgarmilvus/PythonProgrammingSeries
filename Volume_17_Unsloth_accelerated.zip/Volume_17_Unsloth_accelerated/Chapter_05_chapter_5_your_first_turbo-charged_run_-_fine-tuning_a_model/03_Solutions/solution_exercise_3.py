
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from trl import SFTTrainer
from transformers import TrainingArguments
import torch

# (Assuming 'model', 'tokenizer', and 'dataset' are defined from previous exercises)

# 1. Trainer Initialization with optimized constraints
trainer = SFTTrainer(
    model = model,
    tokenizer = tokenizer,
    train_dataset = dataset,
    dataset_text_field = "text",
    max_seq_length = 512,  # Prioritize speed by limiting context length
    args = TrainingArguments(
        per_device_train_batch_size = 2,      # Small batch size to prevent OOM
        gradient_accumulation_steps = 4,     # Simulate a batch size of 8 (2 * 4)
        learning_rate = 2e-4,                # Balanced rate for rapid convergence
        num_train_epochs = 1,                # Single pass for "under 10-minute" goal
        optim = "adamw_8bit",                # 8-bit optimizer to save VRAM
        logging_steps = 1,                   # Real-time monitoring of loss
        fp16 = not torch.cuda.is_bf16_supported(), # Automatic precision selection
        bf16 = torch.cuda.is_bf16_supported(),
        output_dir = "outputs",
    ),
)

print("SFTTrainer configured for high-speed training.")

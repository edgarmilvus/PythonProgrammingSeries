
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from unsloth import FastLanguageModel
from datasets import Dataset

# 1. New Persona/Template for Legal Domain
legal_template = """### Instruction: Summarize the following legal text.
### Legal Text:
{}

### Summary:
{}

### Risk Factor:
{}"""

# 2. New Data Schema
legal_data = [
    {
        "legal_text": "The lessee shall be responsible for all minor repairs to the premises.",
        "summary": "Tenant handles small repairs.",
        "risk_factor": "Potential for unexpected maintenance costs."
    },
    {
        "legal_text": "Termination requires a 30-day written notice period.",
        "summary": "30-day notice needed to end lease.",
        "risk_factor": "Failure to notify in time may result in penalties."
    }
]
dataset = Dataset.from_list(legal_data)

# 3. Updated Mapping Logic
def formatting_prompts_func(examples):
    texts = []
    for text, summ, risk in zip(examples["legal_text"], examples["summary"], examples["risk_factor"]):
        texts.append(legal_template.format(text, summ, risk))
    return { "text" : texts, }

dataset = dataset.map(formatting_prompts_func, batched = True)

# 4. Model & LoRA with Expanded Target Modules (including MLP)
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name = "unsloth/llama-3-8b-bnb-4bit",
    max_seq_length = 1024, # Increased for denser legal text
    load_in_4bit = True,
)

model = FastLanguageModel.get_peft_model(
    model,
    r = 16,
    target_modules = [
        "q_proj", "k_proj", "v_proj", "o_proj", # Attention layers
        "gate_proj", "up_proj", "down_proj"     # MLP layers (Crucial for domain knowledge)
    ],
    lora_alpha = 16,
    lora_dropout = 0,
    bias = "none",
)

print("Legal Summarizer architecture initialized.")

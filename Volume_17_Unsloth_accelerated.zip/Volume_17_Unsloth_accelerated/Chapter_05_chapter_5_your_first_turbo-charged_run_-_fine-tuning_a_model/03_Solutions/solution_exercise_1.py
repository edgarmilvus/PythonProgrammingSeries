
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from unsloth import FastLanguageModel
import torch

# 1. Load the model and tokenizer in 4-bit to save VRAM
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name = "unsloth/llama-3-8b-bnb-4bit", # Using the optimized 4-bit version
    max_seq_length = 2048,                     # Maximum context window
    load_in_4bit = True,                       # Crucial for "lean hardware" requirement
)

# 2. Prepare the model for LoRA (Low-Rank Adaptation)
model = FastLanguageModel.get_peft_model(
    model,
    r = 16,                        # Rank: higher = more parameters, lower = faster/leaner
    target_modules = [             # Targeting standard linear layers for optimal learning
        "q_proj", 
        "k_proj", 
        "v_proj", 
        "o_proj"
    ],
    lora_alpha = 16,               # Scaling factor for LoRA weights
    lora_dropout = 0,              # 0 is optimized for Unsloth speedups
    bias = "none",                 # Standard for efficient LoRA
)

# 3. Memory Audit: Confirm hardware targeting
device = "GPU" if torch.cuda.is_available() else "CPU"
print(f"Model successfully loaded in 4-bit precision.")
print(f"Current device: {device}")

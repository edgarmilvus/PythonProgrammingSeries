
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import torch
from sqlalchemy import create_engine, Column, Integer, String, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from unsloth import FastLanguageModel
from datasets import Dataset
from trl import SFTTrainer
from transformers import TrainingArguments
from jinja2 import Template

# --- 1. DATABASE LAYER (SQLAlchemy) ---
# Defining the schema for our historical support logs
Base = declarative_base()

class SupportTicket(Base):
    __tablename__ = 'support_tickets'
    id = Column(Integer, primary_key=True)
    user_query = Column(String(255))
    expert_response = Column(Text)
    category = Column(String(50))

# Setup an in-memory SQLite database for this demonstration
engine = create_engine('sqlite:///:memory:')
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)
session = Session()

# Seeding the database with dummy training data
seed_data = [
    SupportTicket(user_query="How do I reset my PIN?", expert_response="Go to Settings > Security > Reset PIN.", category="Security"),
    SupportTicket(user_query="Where is my refund?", expert_response="Refunds take 3-5 business days to process.", category="Billing"),
    SupportTicket(user_query="Can I freeze my card?", expert_response="Yes, use the 'Freeze Card' toggle in the app.", category="Security"),
    SupportTicket(user_query="Why was my transaction declined?", expert_response="Check your daily limit in the Profile tab.", category="Billing"),
    SupportTicket(user_query="How to update email?", expert_response="Navigate to Account Settings to update email.", category="Account"),
]
session.add_all(seed_data)
session.commit()

# --- 2. DATA EXTRACTION & SAMPLING (Extended Slicing) ---
# Fetching all tickets from the database
all_tickets = session.query(SupportTicket).all()

# Using Extended Slicing [start:stop:step] to sample every 2nd ticket 
# to simulate picking a specific subset of high-quality data
training_subset = all_tickets[::2]

# Formatting the data for the LLM using a prompt template
def format_prompt(ticket):
    return f"### Instruction:\n{ticket.user_query}\n\n### Response:\n{ticket.expert_response}"

formatted_data = [{"text": format_prompt(t)} for t in training_subset]
dataset = Dataset.from_list(formatted_data)

# --- 3. UNSTOTH FINE-TUNING ENGINE (4-bit Quantization) ---
# Loading the model and tokenizer with 4-bit quantization for maximum speed
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name = "unsloth/llama-3-8b-bnb-4bit",
    max_seq_length = 2048,
    load_in_4bit = True,
)

# Adding LoRA adapters to enable efficient parameter tuning
model = FastLanguageModel.get_peft_model(
    model,
    r = 16,
    target_modules = ["q_proj", "k_proj", "v_proj", "o_proj"],
    lora_alpha = 16,
    lora_dropout = 0,
    bias = "none",
)

# Configuring the high-speed training arguments
trainer = SFTTrainer(
    model = model,
    train_dataset = dataset,
    dataset_text_field = "text",
    max_seq_length = 2048,
    args = TrainingArguments(
        per_device_train_batch_size = 2,
        gradient_accumulation_steps = 4,
        warmup_steps = 5,
        max_steps = 10, # Small steps for the <10 min demonstration
        learning_rate = 2e-4,
        fp16 = not torch.cuda.is_bf16_supported(),
        bf16 = torch.cuda.is_bf16_supported(),
        logging_steps = 1,
        output_dir = "outputs",
    ),
)

# Executing the turbo-charged training loop
trainer.train()

# --- 4. INFERENCE & TEMPLATE RENDERING (Jinja2) ---
# Preparing the model for fast inference
FastLanguageModel.for_inference(model)

def run_inference(query):
    inputs = tokenizer(
        [f"### Instruction:\n{query}\n\n### Response:\n"], 
        return_tensors = "pt"
    ).to("cuda")
    
    outputs = model.generate(**inputs, max_new_tokens = 64)
    response = tokenizer.batch_decode(outputs)[0]
    # Extracting only the response part after the instruction
    return response.split("### Response:\n")[-1].strip()

# Using Jinja2 Template Inheritance logic to format the final UI output
# (Simulating a web dashboard view)
ui_template = """
{% extends "base_layout" %}
{% block content %}
<div class="response-card">
    <p><strong>Query:</strong> {{ query }}</p>
    <p><strong>AI Response:</strong> {{ response }}</p>
</div>
{% endblock %}
"""

# Mocking the base layout for the inheritance demonstration
base_layout = """
<html>
<head><title>Support AI Dashboard</title></head>
<body>
    <header><h1>Fintech AI Monitor</h1></header>
    <main>{% block content %}{% endblock %}</main>
</body>
</html>
"""

# Testing the fine-tuned model
test_query = "How do I reset my PIN?"
ai_answer = run_inference(test_query)

# Rendering the final result
# In a real app, 'base_layout' would be a separate file
template = Template(ui_template)
# Manual simulation of inheritance for the script execution
final_html = template.render(query=test_query, response=ai_answer)

print("--- FINAL INFERENCE OUTPUT ---")
print(f"Query: {test_query}")
print(f"Model Response: {ai_answer}")
print("\n--- RENDERED HTML (Jinja2) ---")
print(final_html)

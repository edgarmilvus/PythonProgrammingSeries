
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Import the core Unsloth library for optimized model loading and training
from unsloth import FastLanguageModel
import torch
# Import standard training utilities from the Hugging Face ecosystem
from trl import SFTTrainer
from transformers import TrainingArguments
from datasets import load_dataset

# 1. Configuration and Model Loading
# We use FastLanguageModel to load a pre-quantized 4-bit model for maximum efficiency
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name = "unsloth/llama-3-8b-bnb-4bit", # The specific optimized model checkpoint
    max_seq_length = 2048,                     # The maximum number of tokens the model can process
    load_in_4bit = True,                       # Enable 4-bit quantization to save VRAM
)

# 2. Applying LoRA (Low-Rank Adaptation)
# Instead of training the whole model, we only train small 'adapter' layers
model = FastLanguageModel.get_peft_model(
    model,
    r = 16,                # The 'rank' of the adaptation; higher = more capacity, more memory
    target_modules = ["q_proj", "k_proj", "v_proj", "o_proj"], # Which layers to optimize
    lora_alpha = 16,       # Scaling factor for the LoRA weights
    lora_dropout = 0,      # Dropout probability (0 is best for Unsloth efficiency)
    bias = "none",         # Do not train bias parameters to maintain speed
)

# 3. Dataset Preparation
# We load a tiny subset of the 'Alpaca' dataset to demonstrate the process
dataset = load_dataset("alpaca", split = "train[:100]")

# 4. Setting up the Supervised Fine-Tuning (SFT) Trainer
# The trainer orchestrates the interaction between the model, data, and optimizer
trainer = SFTTrainer(
    model = model,                  # The LoRA-enhanced model
    train_dataset = dataset,        # The training data
    dataset_text_field = "text",    # The column in the dataset containing the text
    max_seq_length = 2048,          # Must match the model configuration
    args = TrainingArguments(
        per_device_train_batch_size = 2,    # Number of examples processed at once
        gradient_accumulation_steps = 4,    # Simulates a larger batch size by accumulating gradients
        warmup_steps = 5,                   # Gradually increase learning rate at the start
        max_steps = 10,                     # Total training steps (kept low for this example)
        learning_rate = 2e-4,               # The 'speed' of learning
        fp16 = not torch.cuda.is_bf16_supported(), # Use FP16 if BF16 isn't available
        bf16 = torch.cuda.is_bf16_supported(),     # Use BF16 for modern GPUs (better stability)
        logging_steps = 1,                  # Log progress every single step
        output_dir = "outputs",             # Where to save the trained weights
    ),
)

# 5. Execution
# This command triggers the actual mathematical optimization loop
trainer.train()

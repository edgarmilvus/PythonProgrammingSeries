
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: theory_theoretical_foundations_part1.py
# Description: Theoretical Foundations
# ==========================================

# Conceptual Python Code for Noise Reduction Setup
import numpy as np
from skimage import filters
from skimage import restoration # For advanced techniques like NLM

# --- 1. Load and Prepare Dummy Astronomical Data ---
# In reality, this would be loaded from a FITS file and calibrated.
# We simulate a 16-bit image (0 to 65535) with some structure (a gradient)
# and strong Gaussian noise added.
IMAGE_SIZE = 512
base_signal = np.linspace(0, 1, IMAGE_SIZE).reshape(-1, 1) * np.ones((IMAGE_SIZE, IMAGE_SIZE))
gaussian_noise = np.random.normal(0, 0.05, (IMAGE_SIZE, IMAGE_SIZE))
hot_pixel_noise = np.zeros((IMAGE_SIZE, IMAGE_SIZE))

# Simulate a few hot pixels (salt-and-pepper noise)
hot_pixel_noise[100:105, 100:105] = 0.5
hot_pixel_noise[300:303, 400:403] = 0.8

# Combine signal and noise (normalized to 0-1 for simplicity in this demo)
noisy_image = base_signal + gaussian_noise + hot_pixel_noise
noisy_image = np.clip(noisy_image, 0, 1) # Ensure values are within valid range


# --- 2. Defining Filter Parameters ---
# The choice of sigma (for Gaussian) or radius (for Median) is critical
# and depends entirely on the noise profile of the specific telescope and sensor.
GAUSSIAN_SIGMA = 2.0  # Larger sigma means more blurring/smoothing
MEDIAN_RADIUS = 3     # Defines the size of the kernel (e.g., 3x3 or 5x5)


# --- 3. Applying Spatial Domain Filters ---

# A. Gaussian Filter: Good for general, normally distributed noise (thermal/read noise)
# The filter smooths the entire image based on the chosen sigma.
gaussian_filtered_image = filters.gaussian(
    image=noisy_image,
    sigma=GAUSSIAN_SIGMA,
    channel_axis=None,  # Not necessary for grayscale image
    preserve_range=True
)

# B. Median Filter: Excellent for removing impulse noise (hot pixels, cosmic rays)
# Note: The radius parameter is often defined differently across libraries.
median_filtered_image = filters.median(
    image=noisy_image,
    footprint=np.ones((MEDIAN_RADIUS, MEDIAN_RADIUS))
)


# --- 4. Applying Advanced Adaptive Filters (Conceptual) ---

# C. Non-Local Means (NLM) Filter: Preserves fine detail by averaging similar patches
# NLM is computationally intensive but provides superior results for complex noise.
# h: Controls the degree of filtering (larger h means more smoothing)
# patch_size: Size of the local patch used for comparison
# patch_distance: Maximum distance between patches to be compared
NLM_H_PARAMETER = 0.1
NLM_PATCH_SIZE = 5
NLM_PATCH_DISTANCE = 6

# Note: The restoration module is used for advanced techniques
adaptive_nlm_filtered_image = restoration.denoise_nl_means(
    image=noisy_image,
    h=NLM_H_PARAMETER,
    fast_mode=True,
    patch_size=NLM_PATCH_SIZE,
    patch_distance=NLM_PATCH_DISTANCE
)

# The resulting filtered images (gaussian_filtered_image, median_filtered_image,
# adaptive_nlm_filtered_image) are now cleaner, ready for further analysis or visualization.
